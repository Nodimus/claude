import * as THREE from 'three';
import { globalAuthoringModel } from './core/authoring';
import { globalCommandManager } from './core/commandManager';
import { useEditorStore } from './core/editorStore';
import { globalResourceRegistry } from './core/resources/global';
import { nodeObjectRegistry } from './core/rendering/nodeObjectRegistry';
import { globalDiagnosticService } from './core/diagnostics/global';
import { globalInputManager } from './runtime/input/global';
import { getActiveRuntimeSession } from './runtime/RuntimeSession';
import type { EditorCameraController } from './components/viewports/editorCamera';

/**
 * Gancho de TESTE (somente `vite dev`: `import.meta.env.DEV`; nunca entra no build). Expõe `window.__nodimus` para os testes
 * e2e (Playwright) lerem o estado e localizarem objetos na tela sem importar módulos. É só leitura/consulta: o e2e continua
 * agindo pela interface com mouse e teclado reais; mutações de teste passam pelos mesmos Commands do editor.
 */

export interface ViewportProbe {
  editor: EditorCameraController;
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
}

let probe: ViewportProbe | null = null;

/** A Viewport registra o que o e2e precisa (câmera, renderer, cena); devolve o disposer. */
export function registerViewportProbe(next: ViewportProbe): () => void {
  probe = next;
  return () => {
    if (probe === next) probe = null;
  };
}

import { setTerrainSplatEnabled } from './core/terrainSplat';

export interface NodimusE2E {
  authoring: typeof globalAuthoringModel;
  commands: typeof globalCommandManager;
  store: typeof useEditorStore;
  resources: typeof globalResourceRegistry;
  input: typeof globalInputManager;
  diagnostics: typeof globalDiagnosticService;
  /** Objetos Three por id de nó (somente leitura). */
  objects: ReadonlyMap<string, THREE.Object3D>;
  runtime: () => ReturnType<typeof getActiveRuntimeSession>;
  viewport: () => ViewportProbe | null;
  /** Posição do centro do nó na PÁGINA (px), para clicar/arrastar com o mouse real; `null` se fora da vista. */
  screenOf: (nodeId: string, localOffset?: { x: number; y: number; z: number }) => { x: number; y: number } | null;
  /** Estatísticas do renderer (draw calls, triângulos, geometrias e texturas vivas). */
  rendererInfo: () => { calls: number; triangles: number; geometries: number; textures: number } | null;
  /** Liga/desliga as texturas reais do terreno (os roteiros usam a cor sólida: GL por software é lento com 3 texturas por pixel). */
  setTerrainSplat: (enabled: boolean) => void;
}

export function installDevHooks(): void {
  if (!import.meta.env.DEV || typeof window === 'undefined') return;
  const hook: NodimusE2E = {
    authoring: globalAuthoringModel,
    commands: globalCommandManager,
    store: useEditorStore,
    resources: globalResourceRegistry,
    input: globalInputManager,
    diagnostics: globalDiagnosticService,
    objects: nodeObjectRegistry,
    runtime: () => getActiveRuntimeSession(),
    setTerrainSplat: setTerrainSplatEnabled,
    viewport: () => probe,
    screenOf: (nodeId, localOffset) => {
      const object = nodeObjectRegistry.get(nodeId);
      if (!object || !probe) return null;
      object.updateWorldMatrix(true, false);
      const world = new THREE.Vector3(localOffset?.x ?? 0, localOffset?.y ?? 0, localOffset?.z ?? 0).applyMatrix4(object.matrixWorld);
      const camera = probe.editor.camera;
      camera.updateMatrixWorld();
      const ndc = world.clone().project(camera);
      if (ndc.z > 1 || Math.abs(ndc.x) > 1 || Math.abs(ndc.y) > 1) return null;
      const rect = probe.renderer.domElement.getBoundingClientRect();
      return { x: rect.left + ((ndc.x + 1) / 2) * rect.width, y: rect.top + ((1 - ndc.y) / 2) * rect.height };
    },
    rendererInfo: () => {
      if (!probe) return null;
      const i = probe.renderer.info;
      return { calls: i.render.calls, triangles: i.render.triangles, geometries: i.memory.geometries, textures: i.memory.textures };
    },
  };
  (window as unknown as { __nodimus: NodimusE2E }).__nodimus = hook;
}
