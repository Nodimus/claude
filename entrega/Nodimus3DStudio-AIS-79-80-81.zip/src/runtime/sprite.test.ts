import { describe, expect, it } from 'vitest';
import { clipDurationMs, clipFinishedAt, clipFrameIndexAtTime, clipLoopsAt } from './sprite';

/** AIS-76-C05 — a função canônica de frame (editor, Play e publish). 10 fps = 100 ms por frame. */
const clip = (frameIndices: number[], loopMode: 'loop' | 'once' | 'ping-pong' = 'loop', extra: { fps?: number; frameDurations?: number[] } = {}) => ({ frameIndices, loopMode, fps: extra.fps ?? 10, frameDurations: extra.frameDurations });

describe('clipFrameIndexAtTime', () => {
  it('t = 0 devolve o primeiro frame; lista vazia devolve -1', () => {
    expect(clipFrameIndexAtTime(clip([3, 4, 5]), 0)).toBe(3);
    expect(clipFrameIndexAtTime(clip([]), 500)).toBe(-1);
    expect(clipFrameIndexAtTime(clip([], 'once'), 0)).toBe(-1);
  });

  it('loop cicla', () => {
    const c = clip([0, 1, 2]);
    expect([0, 99, 100, 199, 200, 299, 300, 399, 600].map((t) => clipFrameIndexAtTime(c, t))).toEqual([0, 0, 1, 1, 2, 2, 0, 0, 0]);
  });

  it('once para no último frame e NÃO repete (bug do publish: módulo antes de checar o modo)', () => {
    const c = clip([0, 1, 2], 'once');
    expect([0, 150, 250, 299, 300, 301, 10_000, 1e9].map((t) => clipFrameIndexAtTime(c, t))).toEqual([0, 1, 2, 2, 2, 2, 2, 2]);
  });

  it('ping-pong vai e volta sem repetir as pontas (ciclo de 2n-2 posições)', () => {
    const c = clip([0, 1, 2, 3], 'ping-pong');
    const seq = Array.from({ length: 12 }, (_, i) => clipFrameIndexAtTime(c, i * 100 + 1));
    expect(seq).toEqual([0, 1, 2, 3, 2, 1, 0, 1, 2, 3, 2, 1]);
  });

  it('índices fora de ordem e repetidos devolvem o índice GLOBAL', () => {
    const c = clip([7, 2, 2, 9]);
    expect([0, 100, 200, 300].map((t) => clipFrameIndexAtTime(c, t))).toEqual([7, 2, 2, 9]);
  });

  it('um único frame é sempre ele (qualquer tempo, qualquer modo)', () => {
    for (const m of ['loop', 'once', 'ping-pong'] as const) expect(clipFrameIndexAtTime(clip([5], m), 12345)).toBe(5);
  });

  it('frameDurations pesam o tempo de cada uso do frame', () => {
    const c = clip([0, 1, 2], 'loop', { frameDurations: [1, 3, 1] }); // 100 + 300 + 100 ms
    expect([0, 99, 100, 399, 400, 499, 500].map((t) => clipFrameIndexAtTime(c, t))).toEqual([0, 0, 1, 1, 2, 2, 0]);
    expect(clipDurationMs(c)).toBe(500);
  });

  it('frameDurations também valem na volta do ping-pong', () => {
    const c = clip([0, 1, 2], 'ping-pong', { frameDurations: [1, 2, 1] }); // 0:100 1:200 2:100 depois 1:200
    expect([0, 100, 299, 300, 399, 400, 599, 600].map((t) => clipFrameIndexAtTime(c, t))).toEqual([0, 1, 1, 2, 2, 1, 1, 0]);
  });

  it('fps <= 0 ou inválido é tratado (mínimo 0,1 fps), sem NaN nem exceção', () => {
    for (const fps of [0, -5, Number.NaN]) {
      const v = clipFrameIndexAtTime(clip([0, 1, 2], 'loop', { fps }), 4000);
      expect(Number.isInteger(v)).toBe(true);
      expect(v).toBeGreaterThanOrEqual(0);
    }
    expect(clipFrameIndexAtTime(clip([0, 1], 'loop', { fps: 0 }), 9_999)).toBe(0); // 0,1 fps = 10 s por frame
  });

  it('tempo negativo ou inválido vira 0; multiplicador inválido vira 1', () => {
    expect(clipFrameIndexAtTime(clip([4, 5]), -50)).toBe(4);
    expect(clipFrameIndexAtTime(clip([4, 5]), Number.NaN)).toBe(4);
    expect(clipFrameIndexAtTime(clip([4, 5], 'loop', { frameDurations: [Number.NaN, 1] }), 150)).toBe(5);
  });
});

describe('apoios de sinais (clipFinishedAt / clipLoopsAt)', () => {
  it('once termina exatamente ao fim da passada; loop/ping-pong nunca terminam', () => {
    const once = clip([0, 1, 2], 'once');
    expect(clipFinishedAt(once, 299)).toBe(false);
    expect(clipFinishedAt(once, 300)).toBe(true);
    expect(clipFinishedAt(clip([0, 1], 'loop'), 1e9)).toBe(false);
    expect(clipFinishedAt(clip([0, 1], 'ping-pong'), 1e9)).toBe(false);
    expect(clipFinishedAt(clip([], 'once'), 1e9)).toBe(false);
  });
  it('conta voltas de loop e ping-pong; once e frame único não têm voltas', () => {
    expect(clipLoopsAt(clip([0, 1, 2]), 299)).toBe(0);
    expect(clipLoopsAt(clip([0, 1, 2]), 300)).toBe(1);
    expect(clipLoopsAt(clip([0, 1, 2]), 950)).toBe(3);
    expect(clipLoopsAt(clip([0, 1, 2], 'ping-pong'), 400)).toBe(1); // 4 posições = 400 ms
    expect(clipLoopsAt(clip([0, 1, 2], 'once'), 5000)).toBe(0);
    expect(clipLoopsAt(clip([0], 'loop'), 5000)).toBe(0);
  });
});

describe('clipStartMsOfPosition (ir para um frame no editor)', () => {
  it('soma os pesos das posições anteriores e cai de volta no mesmo frame', async () => {
    const { clipStartMsOfPosition } = await import('./sprite');
    const c = clip([5, 6, 7], 'loop', { frameDurations: [1, 3, 1] }); // 100 / 300 / 100
    expect([0, 1, 2].map((p) => clipStartMsOfPosition(c, p))).toEqual([0, 100, 400]);
    expect([0, 1, 2].map((p) => clipFrameIndexAtTime(c, clipStartMsOfPosition(c, p)))).toEqual([5, 6, 7]);
    expect(clipStartMsOfPosition(c, 99)).toBe(400); // clamp
    expect(clipStartMsOfPosition(clip([]), 3)).toBe(0);
  });
});
