/**
 * @file nodeSignalSources.ts
 * @module runtime
 *
 * AIS-57 — emissores de sinais de nó que dependem do TEMPO/ESTADO do runtime (os demais emissores moram onde o evento nasce:
 * física, interação, lógica, áudio, partículas, destruição de nós):
 *  - `timeout` do `Timer` (autostart, `oneShot`, `waitTime`; `start`/`stop` por método);
 *  - `visibility_changed` (nós que declaram o sinal): emitido quando `visible` muda, seja quem for que escreveu;
 *  - `environment_changed` (`Environment`): emitido quando as propriedades do nó mudam durante o jogo.
 * Detecção por comparação a cada quadro (barata: só os tipos que declaram o sinal), então Actions, Behaviors e scripts futuros
 * não precisam lembrar de emitir. Tudo é estado de runtime descartável; nada escreve no autoral.
 */

import type { SignalBus } from '../core/signalBus';
import type { RuntimeInstance } from './RuntimeScene';
import { getNodeMetadata } from '../nodes/registry';

/** Menor `waitTime` aceito (como no Godot): evita laço de milhares de `timeout` por quadro. */
export const MIN_TIMER_WAIT = 0.01;
/** Teto de disparos por quadro para um mesmo Timer (dt enorme ou `waitTime` mínimo). */
const MAX_FIRES_PER_FRAME = 8;

interface TimerState {
  instance: RuntimeInstance;
  running: boolean;
  left: number;
}

export interface TimerControl {
  /** Inicia (ou reinicia) o Timer; `wait` opcional substitui o `waitTime` desta contagem (Godot `start(time_sec)`). */
  start(nodeId: string, wait?: number): void;
  stop(nodeId: string): void;
}

export class NodeSignalSources implements TimerControl {
  private readonly timers = new Map<string, TimerState>();
  private readonly visibility = new Map<string, boolean>();
  private environment: { instance: RuntimeInstance; signature: string } | null = null;

  constructor(private readonly bus: SignalBus, instances: readonly RuntimeInstance[]) {
    for (const instance of instances) {
      const signals = getNodeMetadata(instance.type).availableSignals;
      if (instance.type === 'Timer') {
        const state: TimerState = { instance, running: false, left: 0 };
        this.timers.set(instance.persistentNodeId, state);
        if (instance.properties.autostart !== false) this.begin(state);
      }
      if (signals.includes('visibility_changed')) this.visibility.set(instance.id, instance.visible);
      if (instance.type === 'Environment') this.environment = { instance, signature: JSON.stringify(instance.properties) };
    }
  }

  private waitOf(state: TimerState, override?: number): number {
    const raw = override ?? state.instance.properties.waitTime;
    return Math.max(MIN_TIMER_WAIT, typeof raw === 'number' && Number.isFinite(raw) ? raw : 1);
  }

  private begin(state: TimerState, wait?: number): void {
    state.running = true;
    state.left = this.waitOf(state, wait);
  }

  start(nodeId: string, wait?: number): void {
    const state = this.timers.get(nodeId);
    if (state && !state.instance.disposed) this.begin(state, wait);
  }

  stop(nodeId: string): void {
    const state = this.timers.get(nodeId);
    if (state) state.running = false;
  }

  /** Um quadro de simulação (o `dt` da sessão; em pausa não é chamado). */
  update(instancesById: (handle: string) => RuntimeInstance | undefined, dt: number): void {
    for (const state of this.timers.values()) {
      if (!state.running) continue;
      if (state.instance.disposed) {
        state.running = false;
        continue;
      }
      state.left -= dt;
      let fires = 0;
      while (state.left <= 0 && state.running && fires < MAX_FIRES_PER_FRAME) {
        fires++;
        if (state.instance.properties.oneShot === true) state.running = false;
        else state.left += this.waitOf(state);
        this.bus.emit('timeout', { source: state.instance.persistentNodeId, origin: 'timer' });
      }
      if (state.left < 0 && state.running) state.left = 0; // excedeu o teto de disparos: descarta o atraso
    }

    for (const [handle, previous] of this.visibility) {
      const instance = instancesById(handle);
      if (!instance) {
        this.visibility.delete(handle);
        continue;
      }
      if (instance.visible !== previous) {
        this.visibility.set(handle, instance.visible);
        this.bus.emit('visibility_changed', { source: instance.persistentNodeId, args: [instance.visible], origin: 'state' });
      }
    }

    if (this.environment && !this.environment.instance.disposed) {
      const signature = JSON.stringify(this.environment.instance.properties);
      if (signature !== this.environment.signature) {
        this.environment.signature = signature;
        this.bus.emit('environment_changed', { source: this.environment.instance.persistentNodeId, origin: 'state' });
      }
    }
  }
}
