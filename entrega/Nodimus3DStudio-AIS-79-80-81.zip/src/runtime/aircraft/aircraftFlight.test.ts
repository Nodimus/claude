import { describe, expect, it } from 'vitest';
import { AIRCRAFT_KEYS, ANGULAR_RESPONSE, GRAVITY, LIFT_ONSET, bodyAxes, flightStep, liftFactorAt, readAircraftParams, type AircraftParams, type FlightBody, type FlightInput } from './aircraftFlight';

/** AIS-73b — voo arcade em funções puras (sem Rapier, sem Three). */

const P: AircraftParams = { thrust: 4800, lift: 1, drag: 1.2, pitchSpeed: 40, yawSpeed: 22, rollSpeed: 80, minSpeedToFly: 18, mass: 800 };
const LEVEL = { x: 0, y: 0, z: 0, w: 1 }; // frente = -Z
const body = (speed: number, over: Partial<FlightBody> = {}): FlightBody => ({ rotation: LEVEL, linearVelocity: { x: 0, y: 0, z: -speed }, angularVelocity: { x: 0, y: 0, z: 0 }, mass: 800, ...over });
const IDLE: FlightInput = { throttle: 0, pitch: 0, yaw: 0, roll: 0 };
const step = (input: Partial<FlightInput>, b: FlightBody, p = P, dt = 1 / 60) => flightStep(p, { ...IDLE, ...input }, b, dt);

describe('eixos do corpo', () => {
  it('em pé: frente -Z, cima +Y, direita +X; girar 90° em torno de +Y leva a frente para -X', () => {
    const a = bodyAxes(LEVEL);
    expect(a.forward).toEqual({ x: -0, y: -0, z: -1 });
    expect(a.up).toEqual({ x: 0, y: 1, z: 0 });
    expect(a.right).toEqual({ x: 1, y: 0, z: 0 });
    const q = { x: 0, y: Math.SQRT1_2, z: 0, w: Math.SQRT1_2 };
    expect(bodyAxes(q).forward.x).toBeCloseTo(-1);
  });
});

describe('sustentação (AIS-73b-C01)', () => {
  it('some abaixo de 0,85·minSpeedToFly, cresce até minSpeedToFly e fica cheia acima', () => {
    expect(liftFactorAt(0, 18)).toBe(0);
    expect(liftFactorAt(LIFT_ONSET * 18, 18)).toBe(0);
    expect(liftFactorAt(0.925 * 18, 18)).toBeCloseTo(0.5);
    expect(liftFactorAt(18, 18)).toBe(1);
    expect(liftFactorAt(90, 18)).toBe(1);
    expect(liftFactorAt(-20, 18)).toBe(0); // de ré não sustenta
  });

  it('a partir de minSpeedToFly a sustentação é o PESO (voo nivelado se sustenta); abaixo, é zero e a aeronave cai', () => {
    const cruise = step({}, body(30));
    expect(cruise.force.y).toBeCloseTo(800 * GRAVITY, 3);
    expect(cruise.info).toMatchObject({ stalled: false, liftFactor: 1 });
    const slow = step({}, body(10));
    expect(slow.force.y).toBeCloseTo(0);
    expect(slow.info.stalled).toBe(true);
    // lift = 0.5 sustenta metade do peso
    expect(step({}, body(30), { ...P, lift: 0.5 }).force.y).toBeCloseTo(0.5 * 800 * GRAVITY, 3);
    // parada ou de ré: nenhuma sustentação
    expect(step({}, body(0)).force.y).toBeCloseTo(0);
    expect(step({}, body(-10)).force.y).toBeCloseTo(0);
  });
});

describe('empuxo e arrasto (AIS-73b)', () => {
  it('Throttle empurra para a frente (-Z); o arrasto é quadrático e se opõe ao movimento; sem Throttle só freia', () => {
    expect(step({ throttle: 1 }, body(0)).force.z).toBeCloseTo(-4800);
    expect(step({ throttle: 0.5 }, body(0)).force.z).toBeCloseTo(-2400);
    const cruising = step({}, body(20)); // arrasto 1,2·400 = 480 N contra a frente (+Z)
    expect(cruising.force.z).toBeCloseTo(480);
    expect(step({}, body(40)).force.z).toBeCloseTo(4 * 480);
    // empuxo e arrasto se igualam na velocidade máxima = sqrt(thrust/drag)
    const vmax = Math.sqrt(4800 / 1.2);
    expect(step({ throttle: 1 }, body(vmax)).force.z).toBeCloseTo(0, 3);
  });

  it('o deslizamento lateral é amortecido (o caminho segue o nariz) e some sem sustentação', () => {
    const sliding = step({}, body(30, { linearVelocity: { x: 6, y: 0, z: -30 } })); // desliza para +X
    expect(sliding.force.x).toBeLessThan(0);
    const stalled = step({}, body(5, { linearVelocity: { x: 6, y: 0, z: -5 } }));
    expect(stalled.force.x).toBeCloseTo(0);
  });
});

describe('controles (AIS-73b-C01)', () => {
  const settle = (input: Partial<FlightInput>, speed = 30) => {
    let b = body(speed);
    for (let i = 0; i < 120; i++) b = { ...b, angularVelocity: step(input, b).angularVelocity };
    return b.angularVelocity;
  };

  it('PitchUp = giro + em torno de +X (nariz para cima); PitchDown o oposto; Yaw esquerda = + em torno de +Y; Roll esquerda = − em torno da frente', () => {
    const w = (deg: number) => (deg * Math.PI) / 180;
    expect(settle({ pitch: 1 }).x).toBeCloseTo(w(40), 3);
    expect(settle({ pitch: -1 }).x).toBeCloseTo(-w(40), 3);
    expect(settle({ yaw: 1 }).y).toBeCloseTo(w(22), 3);
    expect(settle({ yaw: -1 }).y).toBeCloseTo(-w(22), 3);
    // frente = -Z: giro negativo em torno da frente = +Z
    expect(settle({ roll: 1 }).z).toBeCloseTo(w(80), 3);
    expect(settle({ roll: -1 }).z).toBeCloseTo(-w(80), 3);
  });

  it('a velocidade angular é suavizada (não salta) e tem menos autoridade em baixa velocidade', () => {
    const first = step({ pitch: 1 }, body(30)).angularVelocity.x;
    expect(first).toBeGreaterThan(0);
    expect(first).toBeLessThan(((40 * Math.PI) / 180) * (1 - Math.exp(-ANGULAR_RESPONSE / 60)) + 1e-9 + 1e-3);
    // contribuição do comando = com − sem (a queda do nariz da perda de sustentação entra nos dois e se cancela)
    const authority = (speed: number) => settle({ pitch: 1 }, speed).x - settle({}, speed).x;
    expect(authority(6)).toBeLessThan(authority(30));
    expect(authority(6)).toBeGreaterThan(0); // ainda responde (autoridade mínima)
  });

  it('sem sustentação o nariz CAI sozinho (a menos que já esteja apontando para baixo)', () => {
    const falling = { linearVelocity: { x: 0, y: -8, z: -5 } }; // sem sustentação e já descendo
    expect(step({}, body(5, falling)).angularVelocity.x).toBeLessThan(0);
    expect(step({}, body(5)).angularVelocity.x).toBeCloseTo(0); // parada na pista (sem descer): o nariz NÃO afunda
    const diving = body(5, { rotation: { x: Math.sin(-0.7), y: 0, z: 0, w: Math.cos(-0.7) } }); // giro de -1,4 rad em X: nariz quase vertical para baixo (frente.y ≈ -0,985)
    expect(Math.abs(step({}, { ...diving, linearVelocity: { x: 0, y: -8, z: -5 } }).angularVelocity.x)).toBeLessThan(0.01);
  });
});

describe('entradas e parâmetros inválidos nunca geram NaN (AIS-73b)', () => {
  it('entrada fora de faixa é limitada; NaN vira zero', () => {
    const r = step({ throttle: 9, pitch: -9, yaw: Number.NaN, roll: 5 }, body(30));
    for (const v of [...Object.values(r.force), ...Object.values(r.angularVelocity)]) expect(Number.isFinite(v)).toBe(true);
    expect(r.force.z).toBeLessThan(0); // throttle limitado a 1: ainda empurra
    expect(step({ throttle: 9 }, body(0)).force.z).toBeCloseTo(-4800);
  });

  it('readAircraftParams usa os padrões em dado ruim e respeita os limites', () => {
    const p = readAircraftParams({ thrust: 'x', minSpeedToFly: -4, pitchSpeed: 9999, lift: -1, mass: 0 });
    expect(p.thrust).toBe(4800);
    expect(p.minSpeedToFly).toBeGreaterThanOrEqual(1);
    expect(p.pitchSpeed).toBeLessThanOrEqual(360);
    expect(p.lift).toBe(0);
    expect(p.mass).toBeGreaterThanOrEqual(1);
    expect(AIRCRAFT_KEYS).toEqual(['thrust', 'lift', 'drag', 'pitchSpeed', 'yawSpeed', 'rollSpeed', 'minSpeedToFly', 'mass']);
    expect(AIRCRAFT_KEYS.some((k) => /altitude/i.test(k))).toBe(false); // não existe altitude alvo
  });
});

describe('auto-nivelamento (AIS-73b)', () => {
  const pitched = (deg: number) => ({ x: Math.sin((deg * Math.PI) / 360), y: 0, z: 0, w: Math.cos((deg * Math.PI) / 360) }); // + = nariz para cima
  const banked = (deg: number) => ({ x: 0, y: 0, z: Math.sin((deg * Math.PI) / 360), w: Math.cos((deg * Math.PI) / 360) }); // + = topo para -X (esquerda)
  const w = (deg: number) => (deg * Math.PI) / 180;

  it('sem comando, nariz para cima gera giro para BAIXO (e o oposto), limitado a 80% da taxa do eixo', () => {
    const up = step({}, body(30, { rotation: pitched(30) }));
    const down = step({}, body(30, { rotation: pitched(-30) }));
    const axes = bodyAxes(pitched(30));
    const rate = (r: ReturnType<typeof step>, ax: { x: number; y: number; z: number }) => r.angularVelocity.x * ax.x + r.angularVelocity.y * ax.y + r.angularVelocity.z * ax.z;
    expect(rate(up, axes.right)).toBeLessThan(0);
    expect(rate(down, bodyAxes(pitched(-30)).right)).toBeGreaterThan(0);
    // taxa alvo máxima = 0,8 · pitchSpeed (a velocidade angular já suavizada fica abaixo disso)
    expect(Math.abs(rate(step({}, body(30, { rotation: pitched(80) })), bodyAxes(pitched(80)).right))).toBeLessThanOrEqual(w(P.pitchSpeed) * 0.8 + 1e-9);
  });

  it('sem comando, asa inclinada gera giro de volta; de cabeça para baixo volta pelo caminho mais curto; nivelada não gira', () => {
    const left = step({}, body(30, { rotation: banked(40) }));
    const fwd = bodyAxes(banked(40)).forward;
    const alongForward = left.angularVelocity.x * fwd.x + left.angularVelocity.y * fwd.y + left.angularVelocity.z * fwd.z;
    expect(alongForward).toBeGreaterThan(0); // + em torno da frente = inclina para a direita = desfaz a inclinação à esquerda
    const level = step({}, body(30));
    expect(Math.hypot(level.angularVelocity.x, level.angularVelocity.y, level.angularVelocity.z)).toBeCloseTo(0, 9);
    const inverted = step({}, body(30, { rotation: banked(170) }));
    expect(Math.hypot(inverted.angularVelocity.x, inverted.angularVelocity.y, inverted.angularVelocity.z)).toBeGreaterThan(0.01); // desvira
  });

  it('o comando do piloto tem prioridade: com o eixo comandado o nivelamento daquele eixo some', () => {
    const rotation = pitched(30);
    const hold = step({ pitch: 1 }, body(30, { rotation }));
    const free = step({}, body(30, { rotation }));
    const axis = bodyAxes(rotation).right;
    const along = (r: ReturnType<typeof step>) => r.angularVelocity.x * axis.x + r.angularVelocity.y * axis.y + r.angularVelocity.z * axis.z;
    expect(along(hold)).toBeGreaterThan(along(free)); // segurando PitchUp não é puxado de volta
    expect(along(hold)).toBeGreaterThan(0);
  });

  it('sem sustentação (estol) não nivela: o nariz continua livre para cair e ganhar velocidade', () => {
    const stalled = step({}, body(5, { rotation: pitched(-40), linearVelocity: { x: 0, y: -2, z: -5 } }));
    expect(stalled.info.stalled).toBe(true);
    const fwdAxes = bodyAxes(pitched(-40)).right;
    const rateX = stalled.angularVelocity.x * fwdAxes.x + stalled.angularVelocity.y * fwdAxes.y + stalled.angularVelocity.z * fwdAxes.z;
    expect(rateX).toBeLessThanOrEqual(1e-9); // nenhum giro de nariz-para-cima forçado
  });
});
