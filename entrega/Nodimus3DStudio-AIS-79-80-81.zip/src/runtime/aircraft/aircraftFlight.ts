import { clamp, DEG, finite } from '../controllers/controllerMath';
import type { Quat, V3 } from '../controllers/controllerMath';

/**
 * AIS-73b — voo ARCADE, em funções PURAS (sem Rapier, sem Three, sem DOM). NÃO é aerodinâmica real: empuxo ao longo da frente, arrasto
 * quadrático na frente, sustentação ao longo do "para cima" do corpo proporcional à velocidade para a frente (e igual ao PESO a partir de
 * `minSpeedToFly`), amortecimento lateral para o caminho acompanhar o nariz, e taxas de rotação comandadas nos 3 eixos. Abaixo de
 * `minSpeedToFly` a sustentação some e a aeronave cai. O `aircraft_controller` só lê a entrada, chama `flightStep` e aplica o resultado
 * pela `PhysicsBridge` (força contínua + velocidade angular).
 */

export interface AircraftParams {
  /** Empuxo máximo (N). */
  thrust: number;
  /** Sustentação em frações do PESO a partir de `minSpeedToFly` (1 = sustenta exatamente o peso). */
  lift: number;
  /** Arrasto quadrático na frente: F = drag · v² (N·s²/m²). */
  drag: number;
  /** Taxas máximas de rotação (graus/s). */
  pitchSpeed: number;
  yawSpeed: number;
  rollSpeed: number;
  /** Velocidade (m/s) para a frente abaixo da qual a sustentação some. */
  minSpeedToFly: number;
  /** Massa (kg): autoridade em jogo é o bloco de Colisão; vale aqui só como padrão para o peso. */
  mass: number;
}

export const AIRCRAFT_KEYS = ['thrust', 'lift', 'drag', 'pitchSpeed', 'yawSpeed', 'rollSpeed', 'minSpeedToFly', 'mass'] as const satisfies readonly (keyof AircraftParams)[];

/** Entrada lógica de um quadro. `pitch`: + = nariz para cima; `yaw`: + = esquerda; `roll`: + = inclina para a esquerda. */
export interface FlightInput {
  throttle: number;
  pitch: number;
  yaw: number;
  roll: number;
}

export interface FlightBody {
  rotation: Quat;
  linearVelocity: V3;
  angularVelocity: V3;
  /** Massa real do corpo (kg). */
  mass: number;
}

export interface FlightResult {
  /** Força MUNDIAL (N) a aplicar neste quadro (contínua). */
  force: V3;
  /** Velocidade angular MUNDIAL (rad/s) a definir. */
  angularVelocity: V3;
  info: { forwardSpeed: number; liftFactor: number; stalled: boolean };
}

export const GRAVITY = 9.81;
/** A sustentação nasce em `LIFT_ONSET · minSpeedToFly` e chega ao valor cheio em `minSpeedToFly`. */
export const LIFT_ONSET = 0.85;
/** Amortecimento (1/s) do deslizamento lateral e vertical em relação ao corpo (só com sustentação): o caminho segue o nariz. */
export const SIDE_DAMPING = 1.6;
/** Resposta (1/s) da velocidade angular ao comando e autoridade mínima dos controles em baixa velocidade. */
export const ANGULAR_RESPONSE = 6;
export const MIN_AUTHORITY = 0.35;
/**
 * Auto-nivelamento (fly-by-wire arcade): sem comando num eixo, a aeronave volta sozinha às asas niveladas e ao nariz no horizonte, em vez de
 * manter a atitude em que ficou. Ganho (1/s), fração da taxa máxima do eixo usada para voltar e peso pela sustentação (em estol não nivela).
 */
export const LEVEL_GAIN = 1.5;
export const LEVEL_RATE_FRACTION = 0.8;
/** Queda do nariz (rad/s) quando perde a sustentação. */
export const STALL_NOSE_DROP = 0.6;
/** Velocidade de descida (fração de `minSpeedToFly`) em que a queda do nariz chega ao valor cheio. */
export const STALL_DESCENT_RATIO = 0.3;

export const readAircraftParams = (properties: Record<string, unknown>): AircraftParams => ({
  thrust: Math.max(0, finite(properties.thrust, 4800)),
  lift: clamp(finite(properties.lift, 1), 0, 3),
  drag: Math.max(0, finite(properties.drag, 1.2)),
  pitchSpeed: clamp(finite(properties.pitchSpeed, 40), 0, 360),
  yawSpeed: clamp(finite(properties.yawSpeed, 22), 0, 360),
  rollSpeed: clamp(finite(properties.rollSpeed, 80), 0, 720),
  minSpeedToFly: Math.max(1, finite(properties.minSpeedToFly, 18)),
  mass: Math.max(1, finite(properties.mass, 800)),
});

const dot = (a: V3, b: V3): number => a.x * b.x + a.y * b.y + a.z * b.z;
const scale = (a: V3, k: number): V3 => ({ x: a.x * k, y: a.y * k, z: a.z * k });
const add = (a: V3, b: V3): V3 => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z });

/** Eixos do corpo no mundo: frente (-Z), cima (+Y) e direita (+X). */
export function bodyAxes(q: Quat): { forward: V3; up: V3; right: V3 } {
  return {
    forward: { x: -2 * (q.x * q.z + q.w * q.y), y: -2 * (q.y * q.z - q.w * q.x), z: -(1 - 2 * (q.x * q.x + q.y * q.y)) },
    up: { x: 2 * (q.x * q.y - q.w * q.z), y: 1 - 2 * (q.x * q.x + q.z * q.z), z: 2 * (q.y * q.z + q.w * q.x) },
    right: { x: 1 - 2 * (q.y * q.y + q.z * q.z), y: 2 * (q.x * q.y + q.w * q.z), z: 2 * (q.x * q.z - q.w * q.y) },
  };
}

/** Fator de sustentação (0..1): 0 abaixo de `LIFT_ONSET·minSpeed`, 1 a partir de `minSpeed`. */
export function liftFactorAt(forwardSpeed: number, minSpeedToFly: number): number {
  return clamp((forwardSpeed - LIFT_ONSET * minSpeedToFly) / ((1 - LIFT_ONSET) * minSpeedToFly), 0, 1);
}

/** Um quadro de voo: força contínua e velocidade angular alvo (suavizada). Entrada fora de faixa e valores inválidos nunca geram NaN. */
export function flightStep(params: AircraftParams, input: FlightInput, body: FlightBody, dt: number): FlightResult {
  const { forward, up, right } = bodyAxes(body.rotation);
  const v = body.linearVelocity;
  const vf = dot(v, forward);
  const vu = dot(v, up);
  const vr = dot(v, right);
  const factor = liftFactorAt(vf, params.minSpeedToFly);
  const throttle = clamp(finite(input.throttle, 0), 0, 1);
  const mass = Math.max(1, finite(body.mass, params.mass));

  // empuxo e arrasto na frente
  let force: V3 = scale(forward, params.thrust * throttle - params.drag * vf * Math.abs(vf));
  // sustentação: o peso, proporcional à velocidade (cheia a partir de minSpeedToFly), ao longo do "para cima" do corpo
  const speedRatio = Math.min(1, (vf / params.minSpeedToFly) ** 2);
  if (vf > 0) force = add(force, scale(up, mass * GRAVITY * params.lift * factor * speedRatio));
  // o caminho segue o nariz: amortece o deslizamento lateral e o vertical RELATIVOS AO CORPO (some quando perde a sustentação)
  force = add(force, scale(right, -mass * SIDE_DAMPING * vr * factor));
  force = add(force, scale(up, -mass * SIDE_DAMPING * vu * factor * 0.5));

  // rotação: taxas comandadas; menos autoridade devagar; sem sustentação o nariz cai
  const authority = clamp(vf / params.minSpeedToFly, MIN_AUTHORITY, 1);
  // o nariz só cai quando a aeronave já está DESCENDO sem sustentação (na pista, devagar, não enterra o nariz)
  const descending = clamp(-v.y / (STALL_DESCENT_RATIO * params.minSpeedToFly), 0, 1);
  const stallDrop = (1 - factor) * descending * STALL_NOSE_DROP * (forward.y > -0.9 ? 1 : 0);
  const pitchInput = clamp(finite(input.pitch, 0), -1, 1);
  const rollInput = clamp(finite(input.roll, 0), -1, 1);
  // auto-nivelamento: sem comando o eixo volta a zero (nariz no horizonte, asas niveladas), com peso pela sustentação
  const pitchAngle = Math.asin(clamp(forward.y, -1, 1));
  const rollAngle = Math.atan2(right.y, up.y); // + = asa direita para cima; perto de ±180° (de cabeça para baixo) volta pelo caminho mais curto
  const levelPitch = -clamp(LEVEL_GAIN * pitchAngle, -LEVEL_RATE_FRACTION * params.pitchSpeed * DEG, LEVEL_RATE_FRACTION * params.pitchSpeed * DEG) * (1 - Math.abs(pitchInput)) * factor;
  const levelRoll = clamp(LEVEL_GAIN * rollAngle, -LEVEL_RATE_FRACTION * params.rollSpeed * DEG, LEVEL_RATE_FRACTION * params.rollSpeed * DEG) * (1 - Math.abs(rollInput)) * factor;
  const pitchRate = pitchInput * params.pitchSpeed * DEG * authority - stallDrop + levelPitch;
  const yawRate = clamp(finite(input.yaw, 0), -1, 1) * params.yawSpeed * DEG * authority;
  const rollRate = rollInput * params.rollSpeed * DEG * authority;
  // + pitch = giro em torno de +X (direita); + yaw = giro em torno de +Y; + roll (esquerda) = giro NEGATIVO em torno da frente
  // (o nivelamento de rolagem é um giro POSITIVO em torno da frente: baixa a asa direita quando ela está para cima)
  const target = add(add(scale(right, pitchRate), scale(up, yawRate)), scale(forward, -rollRate + levelRoll));
  const k = 1 - Math.exp(-ANGULAR_RESPONSE * Math.max(0, dt));
  const w = body.angularVelocity;
  const angularVelocity = { x: w.x + (target.x - w.x) * k, y: w.y + (target.y - w.y) * k, z: w.z + (target.z - w.z) * k };

  return { force, angularVelocity, info: { forwardSpeed: vf, liftFactor: factor, stalled: factor < 1 } };
}
