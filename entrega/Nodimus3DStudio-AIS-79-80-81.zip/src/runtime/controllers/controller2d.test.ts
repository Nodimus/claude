import { describe, expect, it } from 'vitest';
import {
  facingAngleDeg,
  initialPlatformerState,
  initialTopDownState,
  planeAxes,
  pointerDirection,
  readPlatformer2DParams,
  readTopDown2DParams,
  resolvePlane,
  stepPlatformer,
  stepTopDown,
  turnFacing,
  PLATFORMER_2D_DEFAULTS as D,
  type PlatformerInput,
  type PlatformerState,
} from './controller2d';

const DT = 1 / 60;
const idle: PlatformerInput = { move: 0, jumpPressed: false, jumpHeld: false, grounded: true, vy: 0, gravity: 9.8 };
const p = { ...D, smoothing: 0 };

describe('planos 2D (AIS-75)', () => {
  it('eixos de cada plano; W/↑ no plano XZ vai para -Z', () => {
    expect(planeAxes('xy')).toMatchObject({ right: 'x', up: 'y', normal: 'z', upSign: 1 });
    expect(planeAxes('xz')).toMatchObject({ right: 'x', up: 'z', normal: 'y', upSign: -1 });
    expect(planeAxes('yz')).toMatchObject({ right: 'z', up: 'y', normal: 'x', upSign: 1 });
  });
  it('resolvePlane cai no padrão quando none/ausente/não permitido', () => {
    expect(resolvePlane('none', 'xy')).toEqual({ plane: 'xy', explicit: false });
    expect(resolvePlane(undefined, 'xz')).toEqual({ plane: 'xz', explicit: false });
    expect(resolvePlane('yz', 'xy', ['xy', 'yz'])).toEqual({ plane: 'yz', explicit: true });
    expect(resolvePlane('xz', 'xy', ['xy', 'yz'])).toEqual({ plane: 'xy', explicit: false });
  });
});

describe('Platformer2D — pulo, coyote time e buffer', () => {
  it('no chão, Jump pula com jumpSpeed e pede a velocidade vertical', () => {
    const r = stepPlatformer(initialPlatformerState(), p, { ...idle, jumpPressed: true, jumpHeld: true }, DT);
    expect(r.jumped).toBe(true);
    expect(r.setVy).toBe(p.jumpSpeed);
  });

  it('sem chão e sem coyote, Jump não pula', () => {
    const r = stepPlatformer(initialPlatformerState(), p, { ...idle, grounded: false, jumpPressed: true, vy: -1 }, DT);
    expect(r.jumped).toBe(false);
  });

  it('coyote time: logo depois de sair da borda ainda pula; passado o tempo, não', () => {
    let s: PlatformerState = stepPlatformer(initialPlatformerState(), p, idle, DT).state; // no chão: enche o coyote
    s = stepPlatformer(s, p, { ...idle, grounded: false, vy: -0.1 }, DT).state; // saiu da borda
    const cedo = stepPlatformer(s, p, { ...idle, grounded: false, jumpPressed: true, vy: -0.1 }, DT);
    expect(cedo.jumped).toBe(true);
    let tarde = s;
    for (let i = 0; i < Math.ceil(p.coyoteTime / DT) + 2; i++) tarde = stepPlatformer(tarde, p, { ...idle, grounded: false, vy: -3 }, DT).state;
    expect(stepPlatformer(tarde, p, { ...idle, grounded: false, jumpPressed: true, vy: -3 }, DT).jumped).toBe(false);
  });

  it('buffer de pulo: Jump um pouco antes de pousar pula assim que toca o chão; fora da janela, não', () => {
    let s = initialPlatformerState();
    s = stepPlatformer(s, p, { ...idle, grounded: false, jumpPressed: true, vy: -5 }, DT).state; // apertou no ar
    const pousou = stepPlatformer(s, p, { ...idle, grounded: true }, DT);
    expect(pousou.jumped).toBe(true);
    let velho = stepPlatformer(initialPlatformerState(), p, { ...idle, grounded: false, jumpPressed: true, vy: -5 }, DT).state;
    for (let i = 0; i < Math.ceil(p.jumpBuffer / DT) + 3; i++) velho = stepPlatformer(velho, p, { ...idle, grounded: false, vy: -5 }, DT).state;
    expect(stepPlatformer(velho, p, { ...idle, grounded: true }, DT).jumped).toBe(false);
  });

  it('não dá pulo duplo: o chão "atrasado" depois do pulo não recarrega o coyote', () => {
    let s = stepPlatformer(initialPlatformerState(), p, { ...idle, jumpPressed: true }, DT).state; // pulou
    const mesmoQuadro = stepPlatformer(s, p, { ...idle, grounded: true, jumpPressed: true, vy: p.jumpSpeed }, DT); // ponte ainda diz "chão"
    expect(mesmoQuadro.jumped).toBe(false);
    s = mesmoQuadro.state;
    for (let i = 0; i < 10; i++) s = stepPlatformer(s, p, { ...idle, grounded: false, vy: 5 }, DT).state; // saiu do chão: destrava (e o buffer vence)
    expect(stepPlatformer(s, p, { ...idle, grounded: true }, DT).state.coyote).toBeGreaterThan(0); // pousou: recarrega
  });

  it('gravidade configurável: scale 1 não mexe; scale 2 acelera a queda; 0 flutua', () => {
    const air = { ...idle, grounded: false, vy: -2 };
    expect(stepPlatformer(initialPlatformerState(), { ...p, gravityScale: 1 }, air, DT).setVy).toBeNull();
    expect(stepPlatformer(initialPlatformerState(), { ...p, gravityScale: 2 }, air, DT).setVy!).toBeCloseTo(-2 - 9.8 * DT, 6);
    expect(stepPlatformer(initialPlatformerState(), { ...p, gravityScale: 0 }, air, DT).setVy!).toBeCloseTo(-2 + 9.8 * DT, 6);
  });

  it('pulo variável: soltar Jump na subida corta a velocidade; desligado, não', () => {
    const held: PlatformerState = { ...initialPlatformerState(), jumpHeld: true };
    const air = { ...idle, grounded: false, vy: 6, jumpHeld: false };
    expect(stepPlatformer(held, { ...p, gravityScale: 1 }, air, DT).setVy).toBeCloseTo(3, 6);
    expect(stepPlatformer(held, { ...p, gravityScale: 1, variableJump: false }, air, DT).setVy).toBeNull();
  });

  it('movimento horizontal: velocidade, suavização e direção', () => {
    expect(stepPlatformer(initialPlatformerState(), p, { ...idle, move: 1 }, DT).dx).toBeCloseTo(p.moveSpeed * DT, 6);
    expect(stepPlatformer(initialPlatformerState(), p, { ...idle, move: -1 }, DT).dx).toBeLessThan(0);
    const suave = stepPlatformer(initialPlatformerState(), { ...p, smoothing: 10 }, { ...idle, move: 1 }, DT);
    expect(suave.dx).toBeGreaterThan(0);
    expect(suave.dx).toBeLessThan(p.moveSpeed * DT);
  });

  it('parâmetros inválidos viram padrão/limites', () => {
    expect(readPlatformer2DParams({ moveSpeed: 'x', coyoteTime: 99, gravityScale: -4, variableJump: 'false' })).toMatchObject({ moveSpeed: D.moveSpeed, coyoteTime: 1, gravityScale: 0, variableJump: false });
  });
});

describe('TopDown2D', () => {
  const p2 = { ...readTopDown2DParams({}), smoothing: 0 };

  it('livre nos 2 eixos, diagonal normalizada, sem gravidade; XZ: ↑ vai para -Z', () => {
    const r = stepTopDown(initialTopDownState(), p2, { right: 1, up: 1 }, -1, DT);
    expect(Math.hypot(r.dRight, r.dUp)).toBeCloseTo(p2.moveSpeed * DT, 6);
    expect(r.dRight).toBeGreaterThan(0);
    expect(r.dUp).toBeLessThan(0); // upSign -1 (XZ)
    expect(stepTopDown(initialTopDownState(), p2, { right: 0, up: 1 }, 1, DT).dUp).toBeGreaterThan(0); // XY: +Y
  });

  it('parado: sem movimento e sem direção', () => {
    const r = stepTopDown(initialTopDownState(), p2, { right: 0, up: 0 }, 1, DT);
    expect(r).toMatchObject({ moving: false, dirRight: 0, dirUp: 0, speed: 0 });
  });

  it('facing por movimento: direção → ângulo (0° = cima); caminho mais curto', () => {
    expect(facingAngleDeg(0, 1)).toBeCloseTo(0);
    expect(facingAngleDeg(1, 0)).toBeCloseTo(-90);
    expect(facingAngleDeg(-1, 0)).toBeCloseTo(90);
    const t = turnFacing(170, -170, 1e6, DT); // atravessa 180° (170 → 190), não volta pelo outro lado
    expect(t).toBeGreaterThan(170);
    expect(((t + 540) % 360) - 180).toBeCloseTo(-170, 0);
  });

  it('facing por mouse: direção em relação ao centro da viewport; sem bounds/ponteiro = null', () => {
    const bounds = { left: 100, top: 50, width: 400, height: 200 }; // centro (300,150)
    expect(pointerDirection({ x: 400, y: 150 }, bounds)).toEqual({ right: 1, up: 0 });
    expect(pointerDirection({ x: 300, y: 50 }, bounds)).toEqual({ right: 0, up: 1 }); // acima na tela
    expect(pointerDirection({ x: 300, y: 150 }, bounds)).toBeNull();
    expect(pointerDirection(undefined, bounds)).toBeNull();
    expect(pointerDirection({ x: 1, y: 1 }, null)).toBeNull();
  });

  it('parâmetros inválidos', () => {
    expect(readTopDown2DParams({ facing: 'x', moveSpeed: -3 })).toMatchObject({ facing: 'movement', moveSpeed: 0 });
    expect(readTopDown2DParams({ facing: 'mouse' }).facing).toBe('mouse');
  });
});
