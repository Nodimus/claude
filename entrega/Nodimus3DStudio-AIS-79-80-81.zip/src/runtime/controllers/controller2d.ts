import { clamp, finite, lerpAngleDeg, RAD, smoothingFactor } from './controllerMath';

/**
 * AIS-75 — matemática PURA dos controladores de movimento 2D (sem Three, sem Rapier, sem DOM). 2D é o MESMO mundo 3D restrito a um plano
 * (`properties.physics.constrainToPlane`, AIS-74): aqui só se decide a INTENÇÃO de movimento dentro do plano; gravidade, chão e colisão
 * continuam da `PhysicsBridge` (corpo `character`). O eixo normal ao plano nunca se move.
 */

export type Plane2D = 'xy' | 'xz' | 'yz';
export type Axis = 'x' | 'y' | 'z';

/** Eixos de um plano: `right` (+ para a direita da tela), `up` (+ para "cima" da tela) e `normal` (perpendicular, congelado). */
export interface PlaneAxes {
  plane: Plane2D;
  right: Axis;
  up: Axis;
  normal: Axis;
  /** Sinal do mundo para "cima" da tela: no plano `xz` (visto de cima) W/↑ vai para -Z, como no resto do editor. */
  upSign: 1 | -1;
}

export function planeAxes(plane: Plane2D): PlaneAxes {
  if (plane === 'xz') return { plane, right: 'x', up: 'z', normal: 'y', upSign: -1 };
  if (plane === 'yz') return { plane, right: 'z', up: 'y', normal: 'x', upSign: 1 };
  return { plane: 'xy', right: 'x', up: 'y', normal: 'z', upSign: 1 };
}

/** `constrainToPlane` do nó → plano do controlador; `none`/ausente/inválido cai no padrão do controlador. */
export function resolvePlane(value: unknown, fallback: Plane2D, allowed: readonly Plane2D[] = ['xy', 'xz', 'yz']): { plane: Plane2D; explicit: boolean } {
  return value === 'xy' || value === 'xz' || value === 'yz' ? (allowed.includes(value) ? { plane: value, explicit: true } : { plane: fallback, explicit: false }) : { plane: fallback, explicit: false };
}

// ───────────────────────────────── Platformer2D ─────────────────────────────────

export interface Platformer2DParams {
  /** m/s no chão. */
  moveSpeed: number;
  /** Velocidade vertical do pulo (m/s). */
  jumpSpeed: number;
  /** Suavização horizontal (1/s); 0 = resposta imediata. */
  smoothing: number;
  /** Tolerância (s) para pular logo depois de sair de uma borda. */
  coyoteTime: number;
  /** Janela (s) em que um Jump apertado um pouco antes de pousar ainda vale. */
  jumpBuffer: number;
  /** Multiplicador da gravidade do mundo (1 = a do mundo). */
  gravityScale: number;
  /** Soltar Jump durante a subida corta o pulo (altura variável). */
  variableJump: boolean;
}

export const PLATFORMER_2D_DEFAULTS: Platformer2DParams = {
  moveSpeed: 6,
  jumpSpeed: 9,
  smoothing: 14,
  coyoteTime: 0.1,
  jumpBuffer: 0.12,
  gravityScale: 2,
  variableJump: true,
};

const readBool = (v: unknown, fallback: boolean): boolean => (typeof v === 'boolean' ? v : v === 'true' ? true : v === 'false' ? false : fallback);

export function readPlatformer2DParams(raw: Record<string, unknown> | undefined): Platformer2DParams {
  const d = PLATFORMER_2D_DEFAULTS;
  return {
    moveSpeed: Math.max(0, finite(raw?.moveSpeed, d.moveSpeed)),
    jumpSpeed: Math.max(0, finite(raw?.jumpSpeed, d.jumpSpeed)),
    smoothing: Math.max(0, finite(raw?.smoothing, d.smoothing)),
    coyoteTime: clamp(finite(raw?.coyoteTime, d.coyoteTime), 0, 1),
    jumpBuffer: clamp(finite(raw?.jumpBuffer, d.jumpBuffer), 0, 1),
    gravityScale: clamp(finite(raw?.gravityScale, d.gravityScale), 0, 10),
    variableJump: readBool(raw?.variableJump, d.variableJump),
  };
}

export interface PlatformerState {
  /** Velocidade horizontal atual (m/s). */
  vx: number;
  /** Tempo restante (s) em que ainda vale pular depois de sair do chão. */
  coyote: number;
  /** Tempo restante (s) do Jump apertado e ainda não consumido. */
  buffer: number;
  /** Depois de pular o chão deixa de contar até o corpo realmente sair dele (impede o pulo duplo por chão "atrasado"). */
  airLock: boolean;
  /** Jump estava segurado no quadro anterior (para detectar a soltura). */
  jumpHeld: boolean;
}

export const initialPlatformerState = (): PlatformerState => ({ vx: 0, coyote: 0, buffer: 0, airLock: false, jumpHeld: false });

export interface PlatformerInput {
  /** -1..1 (esquerda..direita). */
  move: number;
  /** Jump foi apertado neste quadro. */
  jumpPressed: boolean;
  /** Jump está segurado. */
  jumpHeld: boolean;
  /** Corpo no chão (vem da ponte). */
  grounded: boolean;
  /** Velocidade vertical atual do corpo (m/s). */
  vy: number;
  /** Módulo da gravidade do mundo (m/s²). */
  gravity: number;
}

export interface PlatformerStep {
  state: PlatformerState;
  /** Deslocamento horizontal do quadro (m, no eixo `right` do plano). */
  dx: number;
  /** Pulou neste quadro. */
  jumped: boolean;
  /** Nova velocidade vertical a pedir à ponte; `null` = não mexer. */
  setVy: number | null;
  moving: boolean;
  speed: number;
}

/** Um quadro do Platformer2D: movimento horizontal suavizado, coyote time, buffer de pulo, pulo variável e gravidade extra. */
export function stepPlatformer(state: PlatformerState, p: Platformer2DParams, input: PlatformerInput, dt: number): PlatformerStep {
  const move = clamp(input.move, -1, 1);
  const k = p.smoothing > 0 ? smoothingFactor(p.smoothing, dt) : 1;
  const vx = state.vx + (move * p.moveSpeed - state.vx) * k;

  // airLock: ligado no quadro do pulo e mantido enquanto o chão ainda é reportado; some assim que o corpo sai dele
  let airLock = state.airLock && input.grounded;
  const onGround = input.grounded && !state.airLock;
  let coyote = onGround ? p.coyoteTime : Math.max(0, state.coyote - dt);
  let buffer = input.jumpPressed ? p.jumpBuffer : Math.max(0, state.buffer - dt);

  let jumped = false;
  let setVy: number | null = null;
  if (buffer > 0 && coyote > 0 && p.jumpSpeed > 0) {
    jumped = true;
    setVy = p.jumpSpeed;
    buffer = 0;
    coyote = 0;
    airLock = true;
  } else if (!input.grounded) {
    let vy = input.vy;
    if (p.variableJump && state.jumpHeld && !input.jumpHeld && vy > 0) vy *= 0.5;
    const extra = (p.gravityScale - 1) * input.gravity * dt;
    const next = vy - extra;
    if (next !== input.vy) setVy = next;
  }
  return {
    state: { vx, coyote, buffer, airLock, jumpHeld: input.jumpHeld },
    dx: vx * dt,
    jumped,
    setVy,
    moving: Math.abs(move) > 1e-6,
    speed: Math.abs(vx),
  };
}

// ───────────────────────────────── TopDown2D ─────────────────────────────────

export type TopDownFacing = 'movement' | 'mouse';

export interface TopDown2DParams {
  moveSpeed: number;
  smoothing: number;
  /** Para onde o personagem olha: a direção do movimento (teclado/analógico) ou a do mouse em relação ao centro da viewport. */
  facing: TopDownFacing;
  /** Suavização do giro (1/s). */
  turnSpeed: number;
}

export const TOP_DOWN_2D_DEFAULTS: TopDown2DParams = { moveSpeed: 5, smoothing: 14, facing: 'movement', turnSpeed: 16 };

export function readTopDown2DParams(raw: Record<string, unknown> | undefined): TopDown2DParams {
  const d = TOP_DOWN_2D_DEFAULTS;
  return {
    moveSpeed: Math.max(0, finite(raw?.moveSpeed, d.moveSpeed)),
    smoothing: Math.max(0, finite(raw?.smoothing, d.smoothing)),
    facing: raw?.facing === 'mouse' ? 'mouse' : 'movement',
    turnSpeed: Math.max(0, finite(raw?.turnSpeed, d.turnSpeed)),
  };
}

export interface TopDownState {
  vr: number;
  vu: number;
}
export const initialTopDownState = (): TopDownState => ({ vr: 0, vu: 0 });

export interface TopDownStep {
  state: TopDownState;
  /** Deslocamento do quadro nos eixos `right` e `up` do plano (m, já com o sinal do mundo em `up`). */
  dRight: number;
  dUp: number;
  /** Direção desejada (unitária ou nula) em coordenadas de TELA: x = direita, y = cima. */
  dirRight: number;
  dirUp: number;
  moving: boolean;
  speed: number;
}

/** Um quadro do TopDown2D: movimento livre nos 2 eixos do plano (diagonal normalizada), sem gravidade. */
export function stepTopDown(state: TopDownState, p: TopDown2DParams, input: { right: number; up: number }, upSign: 1 | -1, dt: number): TopDownStep {
  let r = clamp(input.right, -1, 1);
  let u = clamp(input.up, -1, 1);
  const len = Math.hypot(r, u);
  if (len > 1) {
    r /= len;
    u /= len;
  }
  const k = p.smoothing > 0 ? smoothingFactor(p.smoothing, dt) : 1;
  const vr = state.vr + (r * p.moveSpeed - state.vr) * k;
  const vu = state.vu + (u * p.moveSpeed - state.vu) * k;
  const mag = Math.hypot(r, u);
  return {
    state: { vr, vu },
    dRight: vr * dt,
    dUp: vu * upSign * dt,
    dirRight: mag > 1e-6 ? r / mag : 0,
    dirUp: mag > 1e-6 ? u / mag : 0,
    moving: mag > 1e-6,
    speed: Math.hypot(vr, vu),
  };
}

/**
 * Direção (em coordenadas de tela: x direita, y cima) do ponteiro em relação ao CENTRO da viewport — a câmera top-down costuma seguir o
 * personagem, então o centro é onde ele está. `null` se o ponteiro/área são desconhecidos (testes, sem DOM) ou o mouse está no centro.
 */
export function pointerDirection(
  pointer: { x: number; y: number } | undefined,
  bounds: { left: number; top: number; width: number; height: number } | null | undefined
): { right: number; up: number } | null {
  if (!pointer || !bounds || !(bounds.width > 0) || !(bounds.height > 0)) return null;
  const dx = pointer.x - (bounds.left + bounds.width / 2);
  const dy = (bounds.top + bounds.height / 2) - pointer.y; // tela cresce para baixo
  const len = Math.hypot(dx, dy);
  return len < 1e-6 ? null : { right: dx / len, up: dy / len };
}

/** Ângulo de "frente" (graus) para uma direção de tela: 0° = frente para CIMA da tela, positivo = sentido anti-horário visto de frente. */
export const facingAngleDeg = (dirRight: number, dirUp: number): number => Math.atan2(-dirRight, dirUp) * RAD;

/** Gira suavemente (caminho mais curto) o ângulo de frente em direção ao alvo. */
export const turnFacing = (current: number, target: number, turnSpeed: number, dt: number): number => lerpAngleDeg(current, target, smoothingFactor(turnSpeed, dt));
