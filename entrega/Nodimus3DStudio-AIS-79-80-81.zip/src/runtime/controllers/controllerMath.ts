/**
 * AIS-47 — matemática PURA dos controladores de personagem (sem Three, sem Rapier, sem DOM): olhar, movimento relativo à câmera,
 * suavização e orientação. Convenção de Three: yaw em torno de +Y, a câmera olha para -Z com yaw = 0; pitch > 0 olha para cima.
 */

export interface V3 {
  x: number;
  y: number;
  z: number;
}
export interface Quat {
  x: number;
  y: number;
  z: number;
  w: number;
}

export const DEG = Math.PI / 180;
export const RAD = 180 / Math.PI;

export const clamp = (v: number, min: number, max: number): number => Math.min(max, Math.max(min, v));

/** Número finito ou o padrão (parâmetros vindos de arquivo nunca produzem NaN no jogo). */
export const finite = (v: unknown, fallback: number): number => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);

/** Leva um ângulo em graus para (-180, 180]. */
export function wrapDeg(a: number): number {
  const m = ((a + 180) % 360 + 360) % 360 - 180;
  return m === -180 ? 180 : m;
}

/**
 * Yaw (graus) de uma rotação Euler XYZ em graus. A pose que volta do Rapier é decomposta em Euler: um giro puro em Y acima de 90° vira
 * `(180, 180 - yaw, 180)`, então ler `rotation[1]` direto dá o yaw errado (e reescrever só o Y com o X/Z relidos gira o corpo para o espelho).
 */
export function yawOfEulerXYZ(rotation: readonly [number, number, number]): number {
  const a = rotation[0] * DEG;
  const b = rotation[1] * DEG;
  return Math.atan2(Math.sin(b), Math.cos(a) * Math.cos(b)) * RAD;
}

/** Rotação de um ator que só gira em Y: mantém a inclinação AUTORAL (X/Z do transform inicial), nunca a relida da pose simulada. */
export const yawKeepingAuthoredTilt = (authored: readonly [number, number, number], yawDeg: number): [number, number, number] => [authored[0], yawDeg, authored[2]];

/** Interpola ângulos em graus pelo CAMINHO MAIS CURTO (359° → 1° passa por 0°, não por 180°). */
export function lerpAngleDeg(from: number, to: number, t: number): number {
  return from + wrapDeg(to - from) * clamp(t, 0, 1);
}

/** Fator de suavização independente da taxa de quadros: `speed` (1/s) — 0 = não segue, ∞ = cola. */
export const smoothingFactor = (speed: number, dt: number): number => (speed <= 0 || dt <= 0 ? 0 : 1 - Math.exp(-speed * dt));

/** Direções no plano XZ para um yaw (graus): `forward` (-Z em yaw 0) e `right` (+X em yaw 0). */
export function planarBasis(yawDeg: number): { forward: V3; right: V3 } {
  const y = yawDeg * DEG;
  return { forward: { x: -Math.sin(y), y: 0, z: -Math.cos(y) }, right: { x: Math.cos(y), y: 0, z: -Math.sin(y) } };
}

/** Quaternion de rotação de `angle` (radianos) em torno de um eixo UNITÁRIO. */
export function quatFromAxisAngle(axis: V3, angle: number): Quat {
  const s = Math.sin(angle / 2);
  return { x: axis.x * s, y: axis.y * s, z: axis.z * s, w: Math.cos(angle / 2) };
}

/** Quaternion de Euler 'YXZ' (yaw em Y, depois pitch em X) — a ordem de uma câmera de jogador. Ângulos em graus. */
export function quatFromYawPitch(yawDeg: number, pitchDeg: number): Quat {
  const hy = (yawDeg * DEG) / 2;
  const hp = (pitchDeg * DEG) / 2;
  const cy = Math.cos(hy);
  const sy = Math.sin(hy);
  const cp = Math.cos(hp);
  const sp = Math.sin(hp);
  return { x: cy * sp, y: sy * cp, z: -sy * sp, w: cy * cp };
}

/** Yaw/pitch (graus) de quem olha de `from` para `to`. */
export function lookAngles(from: V3, to: V3): { yaw: number; pitch: number } {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const dz = to.z - from.z;
  return { yaw: Math.atan2(-dx, -dz) * RAD, pitch: Math.atan2(dy, Math.hypot(dx, dz)) * RAD };
}

/** Normaliza as entradas de eixo para que a diagonal não seja mais rápida que o eixo puro. */
export function normalizeAxes(forward: number, strafe: number): { forward: number; strafe: number } {
  const len = Math.hypot(forward, strafe);
  return len > 1 ? { forward: forward / len, strafe: strafe / len } : { forward, strafe };
}

/** Rotaciona um vetor por um quaternion (mesma fórmula do Three), para testes e para a câmera. */
export function rotateByQuat(v: V3, q: Quat): V3 {
  const ix = q.w * v.x + q.y * v.z - q.z * v.y;
  const iy = q.w * v.y + q.z * v.x - q.x * v.z;
  const iz = q.w * v.z + q.x * v.y - q.y * v.x;
  const iw = -q.x * v.x - q.y * v.y - q.z * v.z;
  return {
    x: ix * q.w + iw * -q.x + iy * -q.z - iz * -q.y,
    y: iy * q.w + iw * -q.y + iz * -q.x - ix * -q.z,
    z: iz * q.w + iw * -q.z + ix * -q.y - iy * -q.x,
  };
}
