import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { ensureRapier } from '../core/physics/rapierInit';
import { RuntimeSession } from './RuntimeSession';

/**
 * Actions que escrevem a pose (`set_position`, `move_by`, `rotate_by`, `look_at`, `tween_to`) num corpo DINÂMICO. A física é a dona da
 * pose (o `PhysicsHost` copiava a do Rapier por cima no mesmo quadro): elas não tinham efeito e não avisavam. Decisão do usuário: fazê-las
 * FUNCIONAR pela física — a escrita da lógica é empurrada para o corpo (posição e rotação), preservando as velocidades, e a simulação
 * continua dona do corpo depois do empurrão.
 */

beforeAll(async () => {
  await ensureRapier();
});

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[]): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters: {}, conditions: [], actions });
const rules = (...r: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'Regras', behaviorType: 'custom_rules', enabled: true, properties: {}, rules: r });

const DYNAMIC = { enabled: true, bodyMode: 'dynamic', shape: 'auto' };

function play(physics: Record<string, any> | undefined, actions: LogicAction | LogicAction[], opts: { gravity?: boolean; seconds?: number; event?: string; parent?: boolean } = {}) {
  const { gravity = false, seconds = 1.5, event = 'on_start' } = opts;
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const node = {
    id: 'b', name: 'b', type: 'MeshInstance', parentId: root.id, childrenIds: [], visible: true, locked: false,
    behaviors: [rules(rule(event, Array.isArray(actions) ? actions : [actions]))],
    properties: { meshType: 'CubeMesh', position: { x: 0, y: 5, z: 0 }, ...(physics ? { physics } : {}) },
  } as unknown as GameNode;
  const data = { ...scene, nodes: { [root.id]: { ...root, childrenIds: ['b'] }, b: node }, ...(gravity ? {} : { environmentSettings: { gravity: { x: 0, y: 0, z: 0 } } }) } as unknown as SceneData;
  const logs: { level: string; message: string; code?: string }[] = [];
  const session = new RuntimeSession({
    snapshot: createRuntimeSnapshot(data),
    input: { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never,
    onLog: (e) => e.level !== 'info' && logs.push({ level: e.level, message: e.message, code: e.code }),
  });
  session.start();
  for (let i = 0; i < Math.round(seconds * 60); i++) session.step(1 / 60);
  return { session, logs, t: session.getSimulatedTransform('b')! };
}

describe('Actions de pose em corpo dinâmico: funcionam pela física', () => {
  it('set_position leva o corpo à posição pedida', () => {
    const { session, logs, t } = play(DYNAMIC, act('set_position', { x: 7, y: 5, z: 0 }));
    expect(t.position[0]).toBeCloseTo(7, 1);
    expect(t.position[1]).toBeCloseTo(5, 1);
    expect(logs.filter((l) => l.level === 'error')).toEqual([]);
    session.dispose();
  });

  it('move_by desloca o corpo', () => {
    const { session, logs, t } = play(DYNAMIC, act('move_by', { dx: 3, dy: 0, dz: 0 }));
    expect(t.position[0]).toBeCloseTo(3, 1);
    expect(logs.filter((l) => l.level === 'error')).toEqual([]);
    session.dispose();
  });

  it('rotate_by gira o corpo', () => {
    const { session, t } = play(DYNAMIC, act('rotate_by', { degrees: 60 }));
    expect(t.rotation[1]).toBeCloseTo(60, 0);
    session.dispose();
  });

  it('look_at vira o corpo para o alvo', () => {
    const { session, t } = play(DYNAMIC, act('look_at', { target: 'b', position: { x: 10, y: 5, z: 0 } }));
    expect(Math.abs(t.rotation[1])).toBeGreaterThan(20);
    session.dispose();
  });

  it('tween_to anima a posição de um corpo dinâmico até o destino', () => {
    const { session, t } = play(DYNAMIC, act('tween_to', { target: 'b', property: 'position', x: 6, y: 5, z: 0, duration: 0.5 }), { seconds: 2 });
    expect(t.position[0]).toBeCloseTo(6, 1);
    session.dispose();
  });

  it('depois do empurrão a simulação continua dona do corpo: a gravidade segue atuando', () => {
    const { session, t } = play(DYNAMIC, act('set_position', { x: 2, y: 5, z: 0 }), { gravity: true });
    expect(t.position[0]).toBeCloseTo(2, 1);
    expect(t.position[1]).toBeLessThan(2); // 1,5 s de queda a partir de y = 5
    session.dispose();
  });

  it('preserva a velocidade do corpo: um deslocamento não "para" o corpo', () => {
    const { session, t } = play(DYNAMIC, [act('set_linear_velocity', { velocity: { x: 0, y: 0, z: 2 } }), act('set_position', { x: 4, y: 5, z: 0 })]);
    expect(t.position[0]).toBeCloseTo(4, 1);
    expect(t.position[2]).toBeGreaterThan(2); // seguiu andando em Z a ~2 m/s
    session.dispose();
  });

  it('numa regra por quadro (on_update) o corpo acompanha o deslocamento contínuo', () => {
    const { session, t } = play(DYNAMIC, act('move_by', { dx: 0.05, dy: 0, dz: 0 }), { event: 'on_update', seconds: 1 });
    expect(t.position[0]).toBeGreaterThan(2.5); // ~60 quadros × 0,05
    session.dispose();
  });
});

describe('regressões', () => {
  const CASES: [string, Record<string, any>][] = [
    ['set_position', { x: 7, y: 5, z: 0 }],
    ['move_by', { dx: 3, dy: 0, dz: 0 }],
    ['rotate_by', { degrees: 60 }],
  ];
  it.each(CASES)('%s sem física e com sólido parado seguem funcionando pelo transform', (type, params) => {
    for (const physics of [undefined, { enabled: true, bodyMode: 'static', shape: 'auto' }]) {
      const { session, logs, t } = play(physics, act(type, params));
      expect(logs.filter((l) => l.level === 'error')).toEqual([]);
      expect(t.position[0] !== 0 || t.rotation[1] !== 0, `${type} sem efeito em ${physics ? 'static' : 'sem física'}`).toBe(true);
      session.dispose();
    }
  });

  it('teleport_physics_body (a Action de física) continua funcionando', () => {
    const { session, t } = play(DYNAMIC, act('teleport_physics_body', { position: { x: 7, y: 5, z: 0 } }));
    expect(t.position[0]).toBeCloseTo(7, 1);
    session.dispose();
  });
});
