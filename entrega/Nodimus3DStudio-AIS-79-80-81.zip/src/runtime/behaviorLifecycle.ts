import { tNow } from '../core/i18n';
import type { GameNode } from '../types/node';
import type { AuthoringSceneSnapshot } from '../types/runtime';
import type { BehaviorInstance } from '../types/visualLogic';
import type { BehaviorRuntime, BehaviorRuntimeContext, BehaviorRuntimeModule } from '../logic/types';
import { createEngineCore, deriveBehaviorContext, type EngineCore } from './engineScope';
import type { EngineHost } from './engineApi';
import type { BehaviorRuntimeLookup } from '../logic/behaviorRuntime';
import type { RawInputReader } from './input/inputTriggers';
import type { VariableManager } from '../core/variableManager';
import type { PhysicsBridge, PhysicsEvent, PhysicsEventName } from '../core/physics/PhysicsBridge';
import type { LogicLogMeta } from './logicRunner';
import type { SubscriptionOwner } from './subscriptions';
import type { GameCameraPose } from './controllers/gameCamera';
import type { LocomotionState, ViewBasis } from './cameraRig';
import type { AnimationControl } from './animationRuntime';
import type { WeaponService } from './weapons/weaponService';
import type { RuntimeInstance, RuntimeScene } from './RuntimeScene';
import { BehaviorRuntimeStates } from './behaviorRuntimeState';

/**
 * AIS-44b — dono do LIFECYCLE dos Behaviors em execução: `attach → onPlayStart → onUpdate* → onPlayStop → detach → dispose`.
 *
 * Uma entrada por (nó × `BehaviorInstance`): cada uma tem o seu `BehaviorRuntime` (criado por `create()`) e o seu estado
 * (`BehaviorRuntimeStates`), então duas instâncias do mesmo tipo — no mesmo nó ou em nós distintos — nunca compartilham
 * estado. O tipo registrado (a pasta em `src/logic/behaviors/<id>/`) é só a fábrica. Erros de um callback viram log e
 * nunca derrubam a sessão nem os outros Behaviors.
 */

type EntryPhase = 'attached' | 'playing' | 'stopped' | 'detached';

interface Entry {
  nodeId: string;
  behavior: BehaviorInstance;
  module: BehaviorRuntimeModule;
  runtime: BehaviorRuntime;
  phase: EntryPhase;
}

/** AIS-48b: porta de inscrições da sessão. Todo callback do Behavior entra com o owner `behavior`; `disposeOwner` cancela só o dele. */
export interface BehaviorSubscriptionPort {
  onPhysicsEvent(owner: SubscriptionOwner, name: PhysicsEventName | '*', cb: (event: PhysicsEvent) => void): () => void;
  onFrame(owner: SubscriptionOwner, cb: (dt: number) => void): () => void;
  onInput(owner: SubscriptionOwner, cb: (input: RawInputReader) => void): () => void;
  onSignal(owner: SubscriptionOwner, name: string, cb: (name: string) => void): () => void;
  disposeOwner(owner: SubscriptionOwner): number;
}

export const behaviorOwner = (nodeId: string, behaviorId: string): SubscriptionOwner => ({ kind: 'behavior', id: `${nodeId}::${behaviorId}` });

export interface BehaviorLifecycleDeps {
  scene: RuntimeScene;
  snapshot: AuthoringSceneSnapshot;
  states: BehaviorRuntimeStates;
  input: RawInputReader;
  variables: VariableManager | null;
  sceneTime(): number;
  log(level: 'info' | 'warn' | 'error', message: string, node?: RuntimeInstance, meta?: LogicLogMeta): void;
  catalog: BehaviorRuntimeLookup;
  /** AIS-47: ponte física atual (pode surgir depois). */
  physics?: () => PhysicsBridge | null;
  /** AIS-47: câmera de jogo do nó (`null` a retira). */
  setGameCamera?: (nodeId: string, pose: Omit<GameCameraPose, 'nodeId'> | null) => void;
  /** AIS-47c: orientação de visão da câmera ativa (leitura). */
  view?: () => ViewBasis | null;
  /** AIS-78c: o host da EngineApi da SESSÃO (áudio, partículas, animação, sprites, tweens, agenda, cena): os Behaviors os recebem pela EngineApi, sem membros próprios no contexto. */
  engine?: () => EngineHost;
  /** AIS-47c: estado de locomoção do nó (`null` o retira). */
  setLocomotion?: (nodeId: string, state: LocomotionState | null) => void;
  /** AIS-60b: host de animação da sessão (leitura tardia: nasce depois dos Behaviors). */
  animation?: () => AnimationControl | null;
  /** AIS-69: núcleo de armas da sessão. */
  weapons?: () => WeaponService | null;
  /** AIS-48b: registry de inscrições da sessão (frame, input, física, sinais), por owner. */
  subscriptions?: BehaviorSubscriptionPort;
}

export class BehaviorLifecycleHost {
  private entries: Entry[] = [];
  /** AIS-78c: a EngineApi deste lifecycle. Behaviors assinam por dono (`subscriptions`); não emitem sinal pela API (o runner é o dono disso). */
  private readonly engine: EngineCore = createEngineCore({
    instanceById: (ref) => this.deps.scene.getInstance(ref),
    instanceByName: (name) => this.deps.scene.getAllInstances().find((i) => i.name === name),
    variables: () => this.deps.variables,
    input: () => this.deps.input,
    physics: () => this.deps.physics?.() ?? null,
    sceneTime: () => this.deps.sceneTime(),
    emitSignal: (name, args, source) => this.deps.engine?.().emitSignal(name, args, source), // AIS-78d: o SignalBus da sessão (ai_state_changed, actor_died…)
    connectSignal: (name, listener, owner, source) => this.deps.engine?.().connectSignal(name, listener, owner, source) ?? (() => undefined), // com args e filtro de origem (damage_taken)
    onPhysicsEvent: (name, cb, owner) => (owner ? this.deps.subscriptions?.onPhysicsEvent(owner, name, cb) : undefined) ?? (() => undefined),
    log: (level, message, node, o) => this.deps.log(level, message, node, { code: o?.code, behaviorId: o?.behaviorId, logicId: o?.logicId }),
    commitTransform: (instance) => this.deps.scene.applyInstanceTransform(instance),
    audio: () => this.deps.engine?.().audio?.() ?? null,
    particles: () => this.deps.engine?.().particles?.() ?? null,
    animation: () => this.deps.animation?.() ?? null,
    sprites: () => this.deps.engine?.().sprites?.() ?? null,
    tweens: () => this.deps.engine?.().tweens?.() ?? null,
    after: (seconds, fn) => this.deps.engine?.().after?.(seconds, fn),
    destroy: (instance) => this.deps.engine?.().destroy?.(instance),
    setWorldPosition: (instance, position) => this.deps.engine?.().setWorldPosition?.(instance, position),
    sceneRequest: (request) => this.deps.engine?.().sceneRequest?.(request),
    weapons: () => this.deps.weapons?.() ?? null,
    actors: () => this.deps.engine?.().actors?.() ?? null,
    fireHook: (ownerId, behaviorId, trigger, detail, params) => this.deps.engine?.().fireHook?.(ownerId, behaviorId, trigger, detail, params),
    reportOnce: (key, severity, code, message, nodeId) => this.deps.engine?.().reportOnce?.(key, severity, code, message, nodeId),
    resolveRoute: (containerId) => this.deps.engine?.().resolveRoute?.(containerId) ?? { ok: false, code: 'route.container_missing', message: tNow('sharedMsgCore.routesAreNotAvailableIn') },
    random: () => this.deps.engine?.().random?.() ?? Math.random(),
    scripts: () => this.deps.engine?.().scripts?.() ?? null,
    attachments: () => this.deps.engine?.().attachments?.() ?? null,
    view: () => this.deps.view?.() ?? null,
    behaviorProperties: (nodeId, behaviorType) => this.propertiesOf(nodeId, behaviorType),
    nodeOps: () => this.deps.engine?.().nodeOps?.() ?? null,
    onFrame: (cb, owner) => (owner ? this.deps.subscriptions?.onFrame(owner, cb) : undefined) ?? (() => undefined),
    onInput: (cb, owner) => (owner ? this.deps.subscriptions?.onInput(owner, cb) : undefined) ?? (() => undefined),
    setGameCamera: (nodeId, pose) => this.deps.setGameCamera?.(nodeId, pose),
    setLocomotion: (nodeId, state) => this.deps.setLocomotion?.(nodeId, state),
    interpolate: (text, selfNodeId) => this.deps.engine?.().interpolate?.(text, selfNodeId) ?? text,
    markUiDirty: () => this.deps.engine?.().markUiDirty?.(),
    setContinuousRotation: (instance, axis, dps) => this.deps.engine?.().setContinuousRotation?.(instance, axis, dps),
    setContinuousVelocity: (instance, velocity, space) => this.deps.engine?.().setContinuousVelocity?.(instance, velocity, space),
  });
  private playing = false;
  private disposed = false;

  constructor(private readonly deps: BehaviorLifecycleDeps) {}

  get size(): number {
    return this.entries.length;
  }

  /** O executor por propriedades deste Behavior substitui as regras de preset (o `LogicRunner` não as roda). */
  replacesRules(behavior: BehaviorInstance): boolean {
    return this.deps.catalog.get(behavior.behaviorType)?.replacesRules === true;
  }

  /** Cria e conecta os executores de todos os Behaviors ligados dos nós vivos. */
  attach(): void {
    this.attachNodes(Object.values(this.deps.snapshot.nodes));
  }

  /**
   * AIS-29g — Behaviors de nós criados DEPOIS do início (`spawnPrefab`): attach e, com o Play em curso, start imediato. Devolve
   * quantos Behaviors entraram.
   */
  addNodes(nodes: Iterable<GameNode>): number {
    if (this.disposed) return 0;
    const before = this.entries.length;
    this.attachNodes(nodes);
    const added = this.entries.slice(before);
    if (this.playing) for (const e of added) this.start(e);
    return added.length;
  }

  private attachNodes(nodes: Iterable<GameNode>): void {
    for (const node of nodes) {
      const instance = this.deps.scene.getInstance(node.id);
      if (!instance) continue;
      for (const behavior of node.behaviors ?? []) {
        if (!behavior.enabled) continue;
        const module = this.deps.catalog.get(behavior.behaviorType);
        if (!module) continue;
        const entry: Entry = { nodeId: node.id, behavior, module, runtime: module.create(), phase: 'attached' };
        this.entries.push(entry);
        this.call(entry, 'attach', (r, ctx) => r.attach?.(ctx));
      }
    }
  }

  playStart(): void {
    if (this.disposed) return;
    this.playing = true;
    for (const e of this.entries) this.start(e);
  }

  /**
   * AIS-48b — Behaviors cujo nó foi destruído no jogo morrem JUNTO: detach/dispose uma vez e todas as inscrições do dono
   * (`behavior` e `instance`) canceladas. Roda no começo de cada quadro; nenhum callback sobre nó destruído.
   */
  reap(): number {
    let n = 0;
    for (const e of [...this.entries]) {
      if (this.deps.scene.getInstance(e.nodeId)) continue;
      this.retire(e);
      n++;
    }
    return n;
  }

  /** AIS-48b: remove UM Behavior (nó × id) em execução: `onPlayStop → detach → dispose` e cancela só as inscrições dele. */
  removeBehavior(nodeId: string, behaviorId: string): boolean {
    const e = this.entries.find((x) => x.nodeId === nodeId && x.behavior.id === behaviorId);
    if (!e) return false;
    this.retire(e);
    return true;
  }

  private retire(e: Entry): void {
    this.stop(e);
    this.detachEntry(e);
    try {
      e.runtime.dispose?.();
    } catch (error) {
      this.fail(e, 'dispose', error);
    }
    this.entries = this.entries.filter((x) => x !== e);
    this.deps.states.reset(e.nodeId, e.behavior.id);
    if (!this.entries.some((x) => x.nodeId === e.nodeId)) this.deps.subscriptions?.disposeOwner({ kind: 'instance', id: e.nodeId });
  }

  update(dt: number): void {
    if (this.disposed || !this.playing) return;
    this.reap();
    for (const e of this.entries) if (e.phase === 'playing') this.call(e, 'onUpdate', (r, ctx) => r.onUpdate?.(ctx, dt));
  }

  /** Depois do passo da física (AIS-47): câmeras que seguem o corpo leem a pose simulada já na instância. */
  lateUpdate(dt: number): void {
    if (this.disposed || !this.playing) return;
    for (const e of this.entries) if (e.phase === 'playing') this.call(e, 'onLateUpdate', (r, ctx) => r.onLateUpdate?.(ctx, dt));
  }

  playStop(): void {
    this.playing = false;
    for (const e of this.entries) this.stop(e);
  }

  detach(): void {
    for (const e of this.entries) this.detachEntry(e);
  }

  /** Stop/troca de cena: `onPlayStop → detach → dispose` de todos, uma única vez (idempotente). */
  dispose(): void {
    if (this.disposed) return;
    this.playStop();
    this.detach();
    for (const e of this.entries) {
      try {
        e.runtime.dispose?.();
      } catch (error) {
        this.fail(e, 'dispose', error);
      }
    }
    this.entries = [];
    this.disposed = true;
    this.deps.states.dispose();
  }

  /** "Restart Behavior": recomeça SÓ este (nó × Behavior): estado novo, runtime novo; o resto da cena não é tocado. */
  restart(nodeId: string, behaviorId: string): boolean {
    const index = this.entries.findIndex((e) => e.nodeId === nodeId && e.behavior.id === behaviorId);
    if (index < 0) return false;
    const old = this.entries[index];
    this.stop(old);
    this.detachEntry(old);
    try {
      old.runtime.dispose?.();
    } catch (error) {
      this.fail(old, 'dispose', error);
    }
    this.deps.states.reset(nodeId, behaviorId);
    const fresh: Entry = { ...old, runtime: old.module.create(), phase: 'attached' };
    this.entries[index] = fresh;
    this.call(fresh, 'attach', (r, ctx) => r.attach?.(ctx));
    if (this.playing) this.start(fresh);
    return true;
  }

  private start(e: Entry): void {
    if (e.phase !== 'attached' && e.phase !== 'stopped') return;
    e.phase = 'playing';
    this.call(e, 'onPlayStart', (r, ctx) => r.onPlayStart?.(ctx));
  }

  private stop(e: Entry): void {
    if (e.phase !== 'playing') return;
    e.phase = 'stopped';
    this.call(e, 'onPlayStop', (r, ctx) => r.onPlayStop?.(ctx));
  }

  private detachEntry(e: Entry): void {
    if (e.phase === 'detached') return;
    if (e.phase === 'playing') this.stop(e);
    e.phase = 'detached';
    this.call(e, 'detach', (r, ctx) => r.detach?.(ctx));
    this.deps.setLocomotion?.(e.nodeId, null); // AIS-47c: o estado de locomoção some com o Behavior
    this.deps.setGameCamera?.(e.nodeId, null); // a câmera de jogo do Behavior some com ele (Stop, restart, troca de cena)
    this.deps.subscriptions?.disposeOwner(behaviorOwner(e.nodeId, e.behavior.id)); // AIS-48b: nenhuma inscrição sobrevive ao Behavior
  }

  /**
   * AIS-78c (decisão 32): a interseção com a Action (nó, variáveis, `sceneTime`, transform, sinal, física, input, log) sai da `EngineApi` pelo
   * `deriveBehaviorContext`; aqui só os EXTRAS que a EngineApi v1 ainda não cobre (`BEHAVIOR_CONTEXT_SOURCE`). Os getters tardios (`view`,
   * `animation`, `weapons`, `ai`) continuam lidos só quando o Behavior os usa.
   */
  private context(e: Entry): BehaviorRuntimeContext | null {
    const node = this.deps.scene.getInstance(e.nodeId);
    if (!node) return null; // destruído no jogo: o Behavior morre junto, sem callback sobre cena/nó destruído
    const state = this.deps.states.ensure(e.nodeId, e.behavior);
    const owner = behaviorOwner(e.nodeId, e.behavior.id);
    return deriveBehaviorContext(this.engine, { self: node, behavior: e.behavior, state, initialTransform: this.initialTransformOf(e.nodeId, node), owner });
  }

  /** AIS-73 / 78c: properties de trabalho (somente leitura) do Behavior do tipo `behaviorType` em execução no nó; `undefined` se não houver. */
  propertiesOf(nodeId: string, behaviorType: string): Readonly<Record<string, unknown>> | undefined {
    const found = this.entries.find((x) => x.nodeId === nodeId && x.behavior.behaviorType === behaviorType && x.phase !== 'detached');
    return found ? this.deps.states.ensure(nodeId, found.behavior).properties : undefined;
  }

  /** Pose inicial do snapshot (o authoring), ou a atual se o nó não existir nele. */
  private initialTransformOf(nodeId: string, node: RuntimeInstance): BehaviorRuntimeContext['initialTransform'] {
    const t = (this.deps.snapshot.nodes[nodeId] as { transform?: { position?: number[]; rotation?: number[]; scale?: number[] } } | undefined)?.transform;
    const v = (a: number[] | undefined, fallback: [number, number, number]): [number, number, number] => (a && a.length === 3 ? [a[0], a[1], a[2]] : [...fallback]);
    return { position: v(t?.position, node.transform.position), rotation: v(t?.rotation, node.transform.rotation), scale: v(t?.scale, node.transform.scale) };
  }

  private call(e: Entry, name: string, fn: (runtime: BehaviorRuntime, ctx: BehaviorRuntimeContext) => void): void {
    const ctx = this.context(e);
    if (!ctx) return;
    try {
      fn(e.runtime, ctx);
    } catch (error) {
      this.fail(e, name, error);
    }
  }

  private fail(e: Entry, name: string, error: unknown): void {
    const node = this.deps.scene.getInstance(e.nodeId);
    this.deps.log('error', tNow('behaviorLifecycleMsgCore.errorIn', { name: e.behavior.name, name2: name, value: error instanceof Error ? error.message : String(error) }), node, { code: 'behavior.failed', behaviorId: e.behavior.id, logicId: e.behavior.behaviorType });
  }
}
