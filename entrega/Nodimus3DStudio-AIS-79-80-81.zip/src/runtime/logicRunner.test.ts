import { describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { VariableManager } from '../core/variableManager';
import { ActionRuntime } from '../logic/actionRuntime';
import { LogicRegistry } from '../logic/registry';
import { RuntimeObjectFactory } from './RuntimeObjectFactory';
import { RuntimeScene } from './RuntimeScene';
import { LogicRunner, type LogicLogEntry } from './logicRunner';
import type { RawInputReader } from './input/inputTriggers';

/** Input falso: só o que os Triggers consultam. */
class FakeInput implements RawInputReader {
  down = new Set<string>();
  just = new Set<string>();
  released = new Set<string>();
  isActionPressed = () => false;
  isActionJustPressed = () => false;
  isActionJustReleased = () => false;
  getAxis = () => 0;
  isBindingPressed = (b: string) => this.down.has(b);
  isBindingJustPressed = (b: string) => this.just.has(b);
  isBindingJustReleased = (b: string) => this.released.has(b);
  press(code: string) {
    this.down.add(code);
    this.just.add(code);
  }
  endFrame() {
    this.just.clear();
    this.released.clear();
  }
}

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[], parameters: Record<string, any> = {}, conditions: LogicEventRule['conditions'] = []): LogicEventRule => ({
  id: `r${++seq}`,
  eventType,
  parameters,
  conditions,
  actions,
});
const behavior = (...rules: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'Regras', behaviorType: 'custom_rules', enabled: true, properties: {}, rules });

function node(id: string, type: string, extra: Partial<GameNode> = {}): GameNode {
  return { id, name: id, type, parentId: null, childrenIds: [], visible: true, locked: false, properties: {}, ...extra } as unknown as GameNode;
}

/** Cena do starter + nós extras filhos da raiz (`parent` opcional por nó). */
function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes = { ...scene.nodes };
  const rootChildren = [...root.childrenIds];
  for (const n of extra) {
    const parentId = n.parentId ?? root.id;
    nodes[n.id] = { ...n, parentId } as GameNode;
    if (parentId === root.id) rootChildren.push(n.id);
    else nodes[parentId] = { ...nodes[parentId], childrenIds: [...nodes[parentId].childrenIds, n.id] };
  }
  nodes[root.id] = { ...root, childrenIds: rootChildren };
  return { ...scene, nodes };
}

function setup(scene: SceneData, globals: { name: string; type: string; value: unknown }[] = []) {
  const snapshot = createRuntimeSnapshot(scene);
  const live = new RuntimeScene(snapshot, new RuntimeObjectFactory());
  const variables = new VariableManager(globals);
  for (const i of live.getAllInstances()) variables.registerLocals(i.persistentNodeId, i.variables);
  const input = new FakeInput();
  const logs: LogicLogEntry[] = [];
  const host = { quits: 0, restarts: 0, ui: 0 };
  const runner = new LogicRunner({
    scene: live,
    snapshot,
    variables,
    input,
    random: () => 0.5,
    host: {
      onLog: (e) => logs.push(e),
      onQuitGame: () => host.quits++,
      onRestartScene: () => host.restarts++,
      onUiChanged: () => host.ui++,
    },
  });
  const frame = (dt = 1 / 60) => {
    runner.step(dt);
    input.endFrame();
  };
  return { runner, live, variables, input, logs, frame, snapshot, host };
}

const messages = (logs: LogicLogEntry[]) => logs.map((l) => l.message);

describe('triggers on_start / on_update (AIS-44-C03)', () => {
  it('on_start dispara uma vez; on_update a cada quadro, em ordem', () => {
    const scene = sceneWith(
      node('hero', 'Spatial', {
        variables: { starts: 0, ticks: 0 },
        behaviors: [
          behavior(
            rule('on_start', [act('add_to_variable', { scope: 'local', target: 'hero', variable: 'starts', amount: 1 })]),
            rule('on_update', [act('add_to_variable', { scope: 'local', target: 'hero', variable: 'ticks', amount: 1 })])
          ),
        ],
      })
    );
    const { frame, variables } = setup(scene);
    frame();
    frame();
    frame();
    expect(variables.getVariable('local', 'starts', 'hero')).toBe(1);
    expect(variables.getVariable('local', 'ticks', 'hero')).toBe(3);
  });

  it('Actions executam em ordem: o resultado final depende da sequência', () => {
    const scene = sceneWith(
      node('hero', 'Spatial', {
        behaviors: [behavior(rule('on_start', [act('set_variable', { variable: 'x', value: 5 }), act('add_to_variable', { variable: 'x', amount: 2 }), act('set_variable', { variable: 'order', value: 'a$x$' })]))],
      })
    );
    const { frame, variables } = setup(scene, [
      { name: 'x', type: 'number', value: 0 },
      { name: 'order', type: 'string', value: '' },
    ]);
    frame();
    expect(variables.getVariable('global', 'x')).toBe(7);
    expect(variables.getVariable('global', 'order')).toBe('a7');
  });
});

describe('input, variáveis e UI (AIS-44 · emenda v5.4)', () => {
  it('uma variável incrementada atualiza o texto do Overlay2D sem tocar na cena autoral', () => {
    const scene = sceneWith(
      node('hud', 'TextOverlay2D', { properties: { text: 'Score: 0' } }),
      node('player', 'Spatial', {
        behaviors: [
          behavior(
            rule('on_key_down', [act('add_to_variable', { variable: 'score', amount: 1 })], { key: 'space' }),
            rule('on_variable_changed', [act('change_text', { target: 'hud', text: 'Score: $score$' })], { scope: 'global', variable: 'score' })
          ),
        ],
      })
    );
    const before = JSON.stringify(scene);
    const { frame, input, live, runner, host } = setup(scene, [{ name: 'score', type: 'number', value: 0 }]);
    frame();
    expect(live.getInstance('hud')!.properties.text).toBe('Score: 0');
    input.press('Space');
    frame();
    expect(live.getInstance('hud')!.properties.text).toBe('Score: 1');
    input.press('Space');
    frame();
    expect(live.getInstance('hud')!.properties.text).toBe('Score: 2');
    expect(runner.uiRevision).toBe(2);
    expect(host.ui).toBe(2);
    expect(JSON.stringify(scene)).toBe(before); // nada voltou para o autoral
  });

  it('move_by em nó de UI soma nos offsets do layout (não em transform)', () => {
    const scene = sceneWith(node('btn', 'ButtonOverlay2D', { properties: { posX: 10, posY: 20 }, behaviors: [behavior(rule('on_start', [act('move_by', { dx: 5, dy: -3 })]))] }));
    const { frame, live } = setup(scene);
    frame();
    expect(live.getInstance('btn')!.properties.posX).toBe(15);
    expect(live.getInstance('btn')!.properties.posY).toBe(17);
  });

  it('on_click sobe pela hierarquia até o nó com a regra; o botão é respeitado', () => {
    const scene = sceneWith(
      node('door', 'Spatial', { behaviors: [behavior(rule('on_click', [act('set_variable', { variable: 'clicks', value: 1 })], { button: 'left' }))] }),
      node('doorMesh', 'Spatial', { parentId: 'door' })
    );
    const { frame, runner, variables } = setup(scene, [{ name: 'clicks', type: 'number', value: 0 }]);
    runner.notifyClick('doorMesh', 'right');
    frame();
    expect(variables.getVariable('global', 'clicks')).toBe(0);
    runner.notifyClick('doorMesh', 'left');
    frame();
    expect(variables.getVariable('global', 'clicks')).toBe(1);
  });

  it('on_hover dispara na entrada e na saída do ponteiro', () => {
    const scene = sceneWith(
      node('card', 'ButtonOverlay2D', {
        behaviors: [
          behavior(
            rule('on_hover', [act('add_to_variable', { variable: 'in', amount: 1 })], { phase: 'enter' }),
            rule('on_hover', [act('add_to_variable', { variable: 'out', amount: 1 })], { phase: 'exit' })
          ),
        ],
      })
    );
    const { frame, runner, variables } = setup(scene, [
      { name: 'in', type: 'number', value: 0 },
      { name: 'out', type: 'number', value: 0 },
    ]);
    runner.setPointerTarget('card');
    runner.setPointerTarget('card'); // mesmo alvo: não repete
    frame();
    expect([variables.getVariable('global', 'in'), variables.getVariable('global', 'out')]).toEqual([1, 0]);
    runner.setPointerTarget(null);
    frame();
    expect([variables.getVariable('global', 'in'), variables.getVariable('global', 'out')]).toEqual([1, 1]);
  });

  it('sinal emitido por uma Action dispara on_signal no mesmo quadro', () => {
    const scene = sceneWith(
      node('a', 'Spatial', { behaviors: [behavior(rule('on_start', [act('emit_signal', { signal: 'boom' })]))] }),
      node('b', 'Spatial', { behaviors: [behavior(rule('on_signal', [act('set_variable', { variable: 'heard', value: true })], { signal: 'boom' }))] })
    );
    const { frame, variables } = setup(scene, [{ name: 'heard', type: 'boolean', value: false }]);
    frame();
    expect(variables.getVariable('global', 'heard')).toBe(true);
  });
});

describe('tempo, delays e pausa', () => {
  it('on_timeout respeita o intervalo e `repeat`', () => {
    const scene = sceneWith(
      node('t', 'Spatial', {
        behaviors: [
          behavior(
            rule('on_timeout', [act('add_to_variable', { variable: 'rep', amount: 1 })], { interval: 1, repeat: true }),
            rule('on_timeout', [act('add_to_variable', { variable: 'once', amount: 1 })], { interval: 1, repeat: false })
          ),
        ],
      })
    );
    const { runner, variables } = setup(scene, [
      { name: 'rep', type: 'number', value: 0 },
      { name: 'once', type: 'number', value: 0 },
    ]);
    runner.step(0.5);
    expect(variables.getVariable('global', 'rep')).toBe(0);
    runner.step(0.5);
    runner.step(1);
    runner.step(1);
    expect(variables.getVariable('global', 'rep')).toBe(3);
    expect(variables.getVariable('global', 'once')).toBe(1);
  });

  it('schedule() é um delay não bloqueante, em tempo de jogo: pausar (não chamar step) congela', () => {
    const { runner } = setup(sceneWith());
    const fired: number[] = [];
    runner.schedule(1, () => fired.push(runner.sceneTime));
    runner.step(0.4);
    expect(fired).toEqual([]);
    // "pausa": nenhum step por um tempo qualquer
    runner.step(0.4);
    expect(fired).toEqual([]);
    runner.step(0.4);
    expect(fired).toHaveLength(1);
  });

  it('dispose cancela timers e fila: nada dispara depois do Stop', () => {
    const scene = sceneWith(node('t', 'Spatial', { behaviors: [behavior(rule('on_update', [act('add_to_variable', { variable: 'n', amount: 1 })]))] }));
    const { runner, variables } = setup(scene, [{ name: 'n', type: 'number', value: 0 }]);
    let late = 0;
    runner.schedule(0.1, () => late++);
    runner.step(0.05);
    runner.dispose();
    runner.step(1);
    runner.dispatchSignal('x');
    expect(late).toBe(0);
    expect(variables.getVariable('global', 'n')).toBe(1);
    expect(runner.isDisposed).toBe(true);
  });

  it('rotate_continuous gira a cada quadro enquanto há step', () => {
    const scene = sceneWith(node('fan', 'Spatial', { behaviors: [behavior(rule('on_start', [act('rotate_continuous', { target: 'fan', axis: 'y', degreesPerSecond: 90 })]))] }));
    const { runner, live } = setup(scene);
    runner.step(1);
    expect(live.getInstance('fan')!.transform.rotation[1]).toBeCloseTo(90, 5);
    runner.step(1);
    expect(live.getInstance('fan')!.transform.rotation[1]).toBeCloseTo(180, 5);
    expect(live.getInstance('fan')!.object!.rotation.y).toBeCloseTo(Math.PI, 5); // o objeto vivo acompanha
    // pausa = nenhum step: nada gira
    expect(live.getInstance('fan')!.transform.rotation[1]).toBeCloseTo(180, 5);
  });
});

describe('Conditions, erros explícitos e cadeia', () => {
  it('Condition falsa impede a regra; desconhecida avisa e também impede', () => {
    const scene = sceneWith(
      node('n', 'Spatial', {
        behaviors: [
          behavior(
            rule('on_start', [act('set_variable', { variable: 'a', value: 1 })], {}, [{ id: 'c', type: 'variable_compare', parameters: { variable: 'gate', operator: '==', value: 1 } }]),
            rule('on_start', [act('set_variable', { variable: 'b', value: 1 })], {}, [{ id: 'c2', type: 'condition_que_nao_existe', parameters: {} }])
          ),
        ],
      })
    );
    const { frame, variables, logs } = setup(scene, [
      { name: 'a', type: 'number', value: 0 },
      { name: 'b', type: 'number', value: 0 },
      { name: 'gate', type: 'number', value: 0 },
    ]);
    frame();
    expect(variables.getVariable('global', 'a')).toBe(0);
    expect(variables.getVariable('global', 'b')).toBe(0);
    expect(logs.some((l) => l.level === 'warn' && l.message.includes('condition_que_nao_existe'))).toBe(true);
  });

  it('Action inválida vira erro explícito e NÃO derruba o resto; run_script sem sandbox na sessão também é erro explícito', () => {
    const scene = sceneWith(
      node('n', 'Spatial', {
        behaviors: [
          behavior(
            rule('on_start', [
              act('add_force', { x: 1, y: 0, z: 0 }), // sem corpo físico
              act('run_script', { scriptRef: 'res://scripts/a.js' }), // habilitada no AIS-79: sem sandbox na sessão do teste vira `scripts.unavailable`
              act('add_force_inexistente'), // ID fora do catálogo
              act('set_variable', { variable: 'done', value: true }),
            ])
          ),
        ],
      })
    );
    const { frame, variables, logs } = setup(scene, [{ name: 'done', type: 'boolean', value: false }]);
    frame();
    expect(variables.getVariable('global', 'done')).toBe(true);
    const errors = logs.filter((l) => l.level === 'error');
    expect(errors.length).toBeGreaterThanOrEqual(3);
    const script = logs.find((l) => l.message.toLowerCase().includes('run script'));
    expect(script?.level).toBe('error'); // AIS-79: a Action executa; sem sandbox disponível falha com código estável, nunca em silêncio
  });

  it('erro lançado por uma Action é logado e o Play segue', () => {
    const scene = sceneWith(node('n', 'Spatial', { behaviors: [behavior(rule('on_update', [act('set_variable', { variable: 'v', value: 1 })]))] }));
    const { runner, variables } = setup(scene, [{ name: 'v', type: 'number', value: 0 }]);
    (variables as any).setVariable = () => {
      throw new Error('falha simulada');
    };
    expect(() => runner.step(0.016)).not.toThrow();
  });

  it('destruir o próprio nó aborta o resto da cadeia; destruir outro não', () => {
    const scene = sceneWith(
      node('victim', 'Spatial'),
      node('suicide', 'Spatial', {
        behaviors: [behavior(rule('on_start', [act('destroy_node', { target: 'victim' }), act('add_to_variable', { variable: 'n', amount: 1 }), act('destroy_node', { target: 'suicide' }), act('add_to_variable', { variable: 'n', amount: 10 })]))],
      })
    );
    const { frame, variables, live } = setup(scene, [{ name: 'n', type: 'number', value: 0 }]);
    frame();
    expect(live.getInstance('victim')).toBeUndefined();
    expect(live.getInstance('suicide')).toBeUndefined();
    expect(variables.getVariable('global', 'n')).toBe(1);
  });

  it('restart_scene / quit_game pedem ao host só no fim do quadro e abortam a cadeia', () => {
    const scene = sceneWith(node('n', 'Spatial', { behaviors: [behavior(rule('on_start', [act('restart_scene'), act('set_variable', { variable: 'after', value: true })]))] }));
    const { frame, variables, host } = setup(scene, [{ name: 'after', type: 'boolean', value: false }]);
    frame();
    expect(host.restarts).toBe(1);
    expect(variables.getVariable('global', 'after')).toBe(false);
  });

  it('Behavior desligado não executa', () => {
    const b = behavior(rule('on_start', [act('set_variable', { variable: 'x', value: 1 })]));
    b.enabled = false;
    const { frame, variables } = setup(sceneWith(node('n', 'Spatial', { behaviors: [b] })), [{ name: 'x', type: 'number', value: 0 }]);
    frame();
    expect(variables.getVariable('global', 'x')).toBe(0);
  });

  it('loop de variável/sinal não trava o quadro (teto de lotes) e é avisado', () => {
    const scene = sceneWith(node('n', 'Spatial', { behaviors: [behavior(rule('on_variable_changed', [act('add_to_variable', { variable: 'x', amount: 1 })], { scope: 'global', variable: 'x' }))] }));
    const { runner, variables, logs } = setup(scene, [{ name: 'x', type: 'number', value: 0 }]);
    runner.dispatchSignal('start');
    variables.setVariable('global', 'x', 1);
    runner.step(0.016);
    expect(logs.some((l) => l.level === 'warn' && l.message.includes('lotes de eventos'))).toBe(true);
  });
});

describe('log de execução (Debugger)', () => {
  it('registra a regra disparada; on_update só aparece em modo verbose', () => {
    const scene = sceneWith(
      node('n', 'Spatial', { behaviors: [behavior(rule('on_start', [act('print_log', { text: 'oi $x$' })]), rule('on_update', [act('set_variable', { variable: 'x', value: 2 })]))] })
    );
    const { frame, logs } = setup(scene, [{ name: 'x', type: 'number', value: 1 }]);
    frame();
    const text = messages(logs).join('\n');
    expect(text).toContain('on_start');
    expect(text).toContain('oi 1');
    expect(text).not.toContain('on_update');
    expect(logs.find((l) => l.message === 'oi 1')?.toOutput).toBe(true); // print_log também vai ao Output
  });
});

describe('log de teclas (regressão)', () => {
  it('on_key_down / on_key_up registram cada disparo no log (são eventos, não polling)', () => {
    const scene = sceneWith(
      node('p', 'Spatial', {
        behaviors: [
          behavior(
            rule('on_key_down', [act('add_to_variable', { variable: 'k', amount: 1 })], { key: 'space' }),
            rule('on_key_up', [act('add_to_variable', { variable: 'k', amount: 10 })], { key: 'space' })
          ),
        ],
      })
    );
    const { frame, input, logs, variables } = setup(scene, [{ name: 'k', type: 'number', value: 0 }]);
    input.press('Space');
    frame();
    input.down.delete('Space');
    input.released.add('Space');
    frame();
    expect(variables.getVariable('global', 'k')).toBe(11);
    const text = messages(logs).join('\n');
    expect(text).toContain('on_key_down');
    expect(text).toContain('on_key_up');
  });
});

describe('catálogo', () => {
  it('on_hover existe no LogicRegistry', () => {
    expect(LogicRegistry.isKnownTrigger('on_hover')).toBe(true);
  });
  it('todo executor registrado pertence a uma Action do catálogo e ela não está desabilitada', () => {
    for (const id of ActionRuntime.list()) {
      const def = LogicRegistry.getAction(id);
      expect(def, id).toBeDefined();
      expect(def!.status, id).not.toBe('disabled');
    }
    expect(ActionRuntime.list().length).toBeGreaterThanOrEqual(18);
  });
});
