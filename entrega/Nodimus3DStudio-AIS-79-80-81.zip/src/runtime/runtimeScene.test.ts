import { describe, expect, it, vi } from 'vitest';
import * as THREE from 'three';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { AuthoringModel } from '../core/authoring/AuthoringModel';
import { CommandManager } from '../core/commandManager';
import { RuntimeObjectFactory } from './RuntimeObjectFactory';
import { RuntimeScene } from './RuntimeScene';
import { RuntimeSceneManager, type RuntimeSceneEvent } from './RuntimeSceneManager';

const starter = (): SceneData => createDefault3DStarterScene();
const snapshotOf = (scene: SceneData) => createRuntimeSnapshot(scene);
const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v));

/** Estado das instâncias de uma cena viva, por id autoral (para comparar "estado inicial"). */
const stateOf = (scene: RuntimeScene) =>
  Object.fromEntries(scene.getAllInstances().map((i) => [i.persistentNodeId, clone({ t: i.transform, p: i.properties, tags: i.tags, v: i.variables, vis: i.visible })]));

describe('instanciar uma cena cria uma árvore runtime separada (AIS-29d-C01)', () => {
  it('uma instância por nó, hierarquia espelhada e objetos próprios (nenhum compartilhado com o autoral)', () => {
    const scene = starter();
    const manager = new RuntimeSceneManager();
    const runtime = manager.load(snapshotOf(scene));
    expect(runtime.getAllInstances()).toHaveLength(Object.keys(scene.nodes).length);
    expect(runtime.rootObject).toBeInstanceOf(THREE.Group);
    expect(runtime.rootObject.parent).toBeNull(); // não é filha de nenhuma cena do editor
    for (const node of Object.values(scene.nodes)) {
      const instance = runtime.getInstance(node.id)!;
      expect(instance.persistentNodeId).toBe(node.id);
      expect(instance.id).not.toBe(node.id); // handle de runtime ≠ id autoral
      expect(instance.object).toBeInstanceOf(THREE.Object3D);
      expect(instance.object!.parent).toBe(node.parentId ? runtime.getInstance(node.parentId)!.object : runtime.rootObject);
      expect(instance.parent?.persistentNodeId ?? null).toBe(node.parentId);
      expect(instance.children.map((c) => c.persistentNodeId)).toEqual(node.childrenIds);
    }
    expect(runtime.getInstance(runtime.getInstance(scene.rootNodeId)!.id)).toBe(runtime.getInstance(scene.rootNodeId)); // por handle ou por id autoral
    manager.dispose();
  });
  it('MeshInstance vira malha, luzes e câmera viram os objetos certos; outros viram Group', () => {
    const runtime = new RuntimeSceneManager().load(snapshotOf(starter()));
    const types = new Set(runtime.getAllInstances().map((i) => i.type));
    for (const instance of runtime.getAllInstances()) {
      if (instance.type === 'MeshInstance') expect(instance.object).toBeInstanceOf(THREE.Mesh);
      if (instance.type === 'DirectionalLight') expect(instance.object).toBeInstanceOf(THREE.DirectionalLight);
      if (instance.type === 'Camera') expect(instance.object).toBeInstanceOf(THREE.PerspectiveCamera);
      if (instance.type === 'Spatial') expect(instance.object).toBeInstanceOf(THREE.Group);
    }
    expect(types.has('MeshInstance')).toBe(true);
    expect(runtime.findInstancesByType('MeshInstance').length).toBeGreaterThan(0);
  });
  it('o transform da instância vai para o objeto (rotação em graus)', () => {
    const scene = starter();
    const id = Object.values(scene.nodes).find((n) => n.type === 'MeshInstance')!.id;
    scene.nodes[id].properties.position = { x: 1, y: 2, z: 3 };
    scene.nodes[id].properties.rotation = { x: 0, y: 90, z: 0 };
    const runtime = new RuntimeSceneManager().load(snapshotOf(scene));
    const obj = runtime.getInstance(id)!.object!;
    expect(obj.position.toArray()).toEqual([1, 2, 3]);
    expect(obj.rotation.y).toBeCloseTo(Math.PI / 2);
  });
  it('nó Missing não tem instância; os filhos dele sobem para o pai mais próximo', () => {
    const scene = starter();
    const root = scene.nodes[scene.rootNodeId];
    const miss = { id: 'miss', name: 'Futuro', type: 'Missing', parentId: root.id, childrenIds: ['kid'], visible: true, locked: false, properties: {} } as unknown as GameNode;
    const kid = { id: 'kid', name: 'Filho', type: 'Spatial', parentId: 'miss', childrenIds: [], visible: true, locked: false, properties: {} } as GameNode;
    scene.nodes = { ...scene.nodes, miss, kid, [root.id]: { ...root, childrenIds: [...root.childrenIds, 'miss'] } };
    const runtime = new RuntimeSceneManager().load(snapshotOf(scene));
    expect(runtime.getInstance('miss')).toBeUndefined();
    expect(runtime.getInstance('kid')!.object!.parent).toBe(runtime.getInstance(root.id)!.object);
  });
});

describe('destruir o runtime não remove nodes autorais (AIS-29d-C02)', () => {
  it('descartar a cena viva libera todos os objetos e não toca na cena autoral nem no histórico', () => {
    const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, starter());
    const commands = new CommandManager();
    const before = clone(model.getScene());
    const historyBefore = commands.getHistory().length;
    const manager = new RuntimeSceneManager();
    const runtime = manager.load(model.createSceneSnapshot());
    expect(manager.liveObjectCount).toBeGreaterThan(Object.keys(before.nodes).length - 1);
    manager.unload();
    expect(runtime.disposed).toBe(true);
    expect(runtime.getAllInstances()).toEqual([]);
    expect(manager.liveObjectCount).toBe(0);
    expect(manager.current).toBeNull();
    expect(model.getScene().nodes).toEqual(before.nodes);
    expect(Object.keys(model.getScene().nodes)).toHaveLength(Object.keys(before.nodes).length);
    expect(commands.getHistory().length).toBe(historyBefore); // runtime nunca gera Undo
  });
  it('destruir uma instância durante o jogo remove a subárvore do runtime e só dela', () => {
    const scene = starter();
    const runtime = new RuntimeSceneManager().load(snapshotOf(scene));
    const parentWithKids = runtime.getAllInstances().find((i) => i.children.length > 0 && i.persistentNodeId !== scene.rootNodeId)!;
    const kidIds = parentWithKids.children.map((c) => c.persistentNodeId);
    const total = runtime.getAllInstances().length;
    runtime.destroyInstance(parentWithKids.id);
    expect(runtime.getInstance(parentWithKids.persistentNodeId)).toBeUndefined();
    for (const k of kidIds) expect(runtime.getInstance(k)).toBeUndefined();
    expect(runtime.getAllInstances().length).toBe(total - 1 - kidIds.length);
    expect(Object.keys(scene.nodes)).toContain(parentWithKids.persistentNodeId); // o autoral continua lá
  });
  it('dispose é idempotente', () => {
    const runtime = new RuntimeSceneManager().load(snapshotOf(starter()));
    runtime.dispose();
    expect(() => runtime.dispose()).not.toThrow();
  });
});

describe('reload produz estado inicial equivalente (AIS-29d-C03)', () => {
  it('restart reconstrói do mesmo snapshot: o estado de jogo não sobrevive', () => {
    const snapshot = snapshotOf(starter());
    const manager = new RuntimeSceneManager();
    const first = manager.load(snapshot);
    const initial = stateOf(first);
    // "joga": muda estado e destrói uma instância
    const some = first.getAllInstances().find((i) => i.type === 'MeshInstance')!;
    some.transform.position[0] += 100;
    some.properties.nested = { gameState: 'x' };
    some.tags.push('ferido');
    first.destroyInstance(first.getAllInstances().filter((i) => i.type === 'MeshInstance')[1].id);
    const second = manager.restart()!;
    expect(second).not.toBe(first);
    expect(first.disposed).toBe(true);
    expect(stateOf(second)).toEqual(initial);
    expect(manager.liveObjectCount).toBeGreaterThan(0);
    expect(manager.status).toBe('loaded');
  });
  it('restart sem cena devolve null; descarregar duas vezes não falha', () => {
    const manager = new RuntimeSceneManager();
    expect(manager.restart()).toBeNull();
    manager.load(snapshotOf(starter()));
    manager.unload();
    expect(() => manager.unload()).not.toThrow();
    expect(manager.restart()).toBeNull();
  });
});

describe('duas instâncias não compartilham estado mutável (AIS-29d-C04)', () => {
  it('mutar uma instância não altera outra, nem o snapshot, nem o autoral', () => {
    const scene = starter();
    const snapshot = snapshotOf(scene);
    const frozen = clone(snapshot);
    const runtime = new RuntimeSceneManager().load(snapshot);
    const [a, b] = runtime.findInstancesByType('MeshInstance');
    expect(a.properties).not.toBe(b.properties);
    expect(a.transform).not.toBe(b.transform);
    expect(a.transform.position).not.toBe(b.transform.position);
    expect(a.tags).not.toBe(b.tags);
    const bBefore = clone({ t: b.transform, p: b.properties });
    a.transform.position[1] = 999;
    (a.properties as any).materialOverride = { color: 'vermelho' };
    a.tags.push('mutado');
    a.variables.vida = 1;
    expect(clone({ t: b.transform, p: b.properties })).toEqual(bBefore);
    expect(clone(snapshot)).toEqual(frozen);
    expect(scene.nodes[a.persistentNodeId].properties.materialOverride).not.toEqual({ color: 'vermelho' });
  });
  it('duas cenas vivas do mesmo snapshot são independentes (cada uma com a sua fábrica)', () => {
    const snapshot = snapshotOf(starter());
    const f1 = new RuntimeObjectFactory();
    const f2 = new RuntimeObjectFactory();
    const s1 = new RuntimeScene(snapshot, f1);
    const s2 = new RuntimeScene(snapshot, f2);
    const id = s1.findInstancesByType('MeshInstance')[0].persistentNodeId;
    s1.getInstance(id)!.transform.position[0] = 42;
    expect(s2.getInstance(id)!.transform.position[0]).not.toBe(42);
    expect(s1.getInstance(id)!.object).not.toBe(s2.getInstance(id)!.object);
    s1.dispose();
    expect(f1.liveCount).toBe(0);
    expect(f2.liveCount).toBeGreaterThan(0);
    s2.dispose();
    expect(f2.liveCount).toBe(0);
  });
});

describe('RuntimeSceneManager: load/unload/change com ponto de aborto', () => {
  it('load sempre descarta a anterior (nunca duas cenas vivas)', () => {
    const manager = new RuntimeSceneManager();
    const a = manager.load(snapshotOf(starter()));
    const b = manager.load(snapshotOf(starter()));
    expect(a.disposed).toBe(true);
    expect(b.disposed).toBe(false);
    expect(manager.current).toBe(b);
  });
  it('change: a nova só entra depois de pronta; a anterior é descartada na troca', async () => {
    const manager = new RuntimeSceneManager();
    const a = manager.load(snapshotOf(starter()));
    const other = starter();
    other.id = 'outra';
    other.name = 'Outra';
    const result = await manager.change(async () => snapshotOf(other));
    expect(result.committed).toBe(true);
    expect(a.disposed).toBe(true);
    expect(manager.current?.sceneId).toBe('outra');
    expect(manager.status).toBe('loaded');
  });
  it('abortar antes ou depois de construir mantém a cena atual e não deixa objeto vivo da parcial', async () => {
    const manager = new RuntimeSceneManager();
    const a = manager.load(snapshotOf(starter()));
    const liveBefore = manager.liveObjectCount;
    const early = new AbortController();
    early.abort();
    const r1 = await manager.change(snapshotOf(starter()), { signal: early.signal });
    expect(r1).toMatchObject({ committed: false });
    const late = new AbortController();
    const r2 = await manager.change(async () => {
      late.abort(); // aborta enquanto a cena está sendo obtida
      return snapshotOf(starter());
    }, { signal: late.signal });
    expect(r2).toMatchObject({ committed: false });
    expect(manager.current).toBe(a);
    expect(a.disposed).toBe(false);
    expect(manager.liveObjectCount).toBe(liveBefore);
    expect(manager.status).toBe('loaded');
  });
  it('falha ao obter a nova cena não derruba a atual', async () => {
    const manager = new RuntimeSceneManager();
    const a = manager.load(snapshotOf(starter()));
    const r = await manager.change(async () => {
      throw new Error('arquivo ausente');
    });
    expect(r).toMatchObject({ committed: false });
    expect((r as { reason: string }).reason).toContain('arquivo ausente');
    expect(manager.current).toBe(a);
  });
  it('eventos com disposer: loaded, change_started, change_aborted, unloaded, restarted', async () => {
    const manager = new RuntimeSceneManager();
    const events: RuntimeSceneEvent['type'][] = [];
    const off = manager.subscribe((e) => events.push(e.type));
    manager.load(snapshotOf(starter()));
    const c = new AbortController();
    c.abort();
    await manager.change(snapshotOf(starter()), { signal: c.signal });
    manager.restart();
    manager.unload();
    off();
    manager.load(snapshotOf(starter()));
    expect(events).toEqual(['loaded', 'change_started', 'change_aborted', 'unloaded', 'loaded', 'restarted', 'unloaded']);
  });
  it('o manager só lê o snapshot: o autoral e o histórico ficam intactos depois de um ciclo completo', () => {
    const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, starter());
    const before = JSON.stringify(model.getScene());
    const manager = new RuntimeSceneManager();
    const runtime = manager.load(model.createSceneSnapshot());
    runtime.getAllInstances()[1].transform.position[0] = 1234;
    manager.restart();
    manager.unload();
    expect(JSON.stringify(model.getScene())).toBe(before);
  });
});

describe('RuntimeObjectFactory: criação e destruição centralizadas', () => {
  it('contabiliza o que cria e libera geometria e material ao destruir', () => {
    const factory = new RuntimeObjectFactory();
    const object = factory.create({ persistentNodeId: 'm', name: 'M', type: 'MeshInstance', properties: { meshType: 'SphereMesh' } });
    const mesh = object as THREE.Mesh;
    const geoDispose = vi.spyOn(mesh.geometry, 'dispose');
    const matDispose = vi.spyOn(mesh.material as THREE.Material, 'dispose');
    expect(factory.liveCount).toBe(1);
    expect(mesh.geometry).toBeInstanceOf(THREE.SphereGeometry);
    factory.destroy(object);
    expect(geoDispose).toHaveBeenCalled();
    expect(matDispose).toHaveBeenCalled();
    expect(factory.liveCount).toBe(0);
  });
  it('tipos sem objeto próprio viram Group; dispose() limpa tudo', () => {
    const factory = new RuntimeObjectFactory();
    factory.create({ persistentNodeId: 'a', name: 'A', type: 'Spatial', properties: {} });
    factory.create({ persistentNodeId: 'b', name: 'B', type: 'OmniLight', properties: {} });
    expect(factory.liveCount).toBe(2);
    factory.dispose();
    expect(factory.liveCount).toBe(0);
  });
});

describe('AIS-43 — variáveis da sessão de Play', () => {
  const withLocals = (): SceneData => {
    const scene = starter();
    const id = Object.keys(scene.nodes).find((k) => k !== scene.rootNodeId)!;
    scene.nodes[id] = { ...scene.nodes[id], variables: { ammo: 5 } };
    return scene;
  };

  it('globais sobrevivem a restart/change; locais são as da instância viva e somem com a cena; o autoral não muda', async () => {
    const scene = withLocals();
    const nodeId = Object.keys(scene.nodes).find((k) => scene.nodes[k].variables)!;
    const manager = new RuntimeSceneManager();
    const vm = manager.beginSession([{ name: 'score', type: 'number', value: 0 }]);
    manager.load(snapshotOf(scene));
    expect(vm.getVariable('local', 'ammo', nodeId)).toBe(5);
    vm.addToVariable('global', 'score', 3);
    vm.setVariable('local', 'ammo', 1, nodeId);

    manager.restart(); // locais reinicializam com a cena; global fica
    expect(vm.getVariable('global', 'score')).toBe(3);
    expect(vm.getVariable('local', 'ammo', nodeId)).toBe(5);

    await manager.change(snapshotOf(starter())); // troca de Scene: o nó some, a global fica
    expect(vm.getVariable('global', 'score')).toBe(3);
    expect(vm.getVariable('local', 'ammo', nodeId)).toBeUndefined();

    expect(scene.nodes[nodeId].variables).toEqual({ ammo: 5 }); // autoral intacto
    manager.endSession();
    expect(manager.variables).toBeNull();
    manager.dispose();
  });
});
