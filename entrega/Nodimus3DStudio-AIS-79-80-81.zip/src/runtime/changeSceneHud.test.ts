import { describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { createDefaultNode } from '../nodes/registry';
import { mergeRuntimeHudNodes } from './runtimeHudNodes';
import { RuntimeSession } from './RuntimeSession';

/**
 * AIS-73 — Change Scene em jogo: o HUD, os cliques e o ambiente têm de seguir a cena VIVA (o `snapshot` da sessão), não a cena aberta
 * no editor. Antes, o Viewport redesenhava sempre os nós autorais: depois de trocar de cena o jogo mostrava (e clicava) os botões da
 * cena anterior e nunca o HUD da nova.
 */

const sceneWithButton = (id: string, name: string, label: string): SceneData => {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const button = createDefaultNode('ButtonOverlay2D', `Botao_${name}`, root.id);
  button.properties.text = label;
  return { ...scene, id, name, nodes: { [root.id]: { ...root, childrenIds: [button.id] } as GameNode, [button.id]: button }, environmentNodeId: undefined } as unknown as SceneData;
};

const input = { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never;

describe('HUD segue a cena viva depois de Change Scene (AIS-73)', () => {
  it('o snapshot da sessão passa a ser o da cena nova e o HUD mesclado traz só os nós dela', async () => {
    const a = sceneWithButton('scene_a', 'A', 'Abrir B');
    const b = sceneWithButton('scene_b', 'B', 'Voltar');
    const snapB = createRuntimeSnapshot(b);
    const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(a), input, diagnostics: new DiagnosticService(), resolveScene: () => snapB });
    session.start();
    const idsA = Object.keys(session.snapshot.nodes);
    expect(session.snapshot.sceneId).toBe('scene_a');
    const result = await session.changeScene('res://scenes/B.scene.json');
    expect(result.committed).toBe(true);
    expect(session.snapshot.sceneId).toBe('scene_b');
    expect(session.snapshot).toBe(snapB);

    const hud = mergeRuntimeHudNodes(session.snapshot.nodes as never, session.currentScene);
    const buttons = Object.values(hud).filter((n) => n.type === 'ButtonOverlay2D');
    expect(buttons.map((n) => n.name)).toEqual(['Botao_B']);
    expect(buttons[0].properties?.text).toBe('Voltar');
    // o que o editor desenhava antes (nós autorais da cena A) não é mais o HUD
    const stale = mergeRuntimeHudNodes(a.nodes as never, session.currentScene);
    expect(Object.values(stale).some((n) => n.name === 'Botao_A')).toBe(true); // era o bug: o botão da cena anterior seguia no HUD
    expect(idsA.some((id) => !(id in hud) || hud[id] === undefined)).toBe(true);
    session.dispose();
  });
});
