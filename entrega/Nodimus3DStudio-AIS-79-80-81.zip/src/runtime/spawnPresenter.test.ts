import { beforeAll, describe, expect, it } from 'vitest';
import * as THREE from 'three';
import type { GameNode, ResourceRef } from '../types/node';
import type { SceneData } from '../types/scene';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { ensureRapier } from '../core/physics/rapierInit';
import { ViewportParticles } from '../components/viewports/viewportParticles';
import { RuntimeSession } from './RuntimeSession';
import { HIDDEN_RUNTIME_LAYER, SpawnPresenter } from './spawnPresenter';

/**
 * AIS-44e — objetos criados em jogo aparecem no Play: a rootObject da RuntimeScene entra na cena Three, o que o espelho da viewport já
 * desenha sai pela camada, e o spawn é desenhado (inclusive sob um pai escondido), acompanha o pai, é removido com o despawn e some no Stop.
 */

beforeAll(async () => {
  await ensureRapier();
});

const node = (id: string, type: string, at: [number, number, number], extra: Record<string, any> = {}, over: Partial<GameNode> = {}): GameNode =>
  ({
    id,
    name: id,
    type,
    parentId: null,
    childrenIds: [],
    visible: true,
    locked: false,
    properties: { position: { x: at[0], y: at[1], z: at[2] }, ...(type === 'MeshInstance' ? { meshType: 'CubeMesh' } : {}), ...extra },
    ...over,
  }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: [] } as GameNode };
  for (const n of extra) {
    nodes[n.id] = { ...n, parentId: n.parentId ?? root.id } as GameNode;
    nodes[root.id].childrenIds.push(n.id);
  }
  return { ...scene, nodes };
}

const fakeInput = () => ({
  isActionPressed: () => false,
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: () => 0,
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
});

const ref = (id: string): ResourceRef => ({ id: `pf_${id}`, type: 'prefab', path: `res://prefabs/${id}.prefab.json` });
const prefabOf = (id: string, root: GameNode) => ({ schemaVersion: 1, id: `pf_${id}`, name: id, rootNodeId: root.id, nodes: { [root.id]: root } });

const FLOOR = node('floor', 'MeshInstance', [0, -0.5, 0], { scale: { x: 40, y: 1, z: 40 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } });
const HOLDER = node('holder', 'MeshInstance', [5, 0, 0]);
const BULLET = node('bullet', 'MeshInstance', [0, 0, 0], { scale: { x: 0.2, y: 0.2, z: 0.2 } });

function open(scene: SceneData) {
  const diagnostics = new DiagnosticService();
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input: fakeInput(), diagnostics });
  session.start();
  return { session, diagnostics };
}

/** O objeto está na cena Three e a câmera da viewport (camada 0) o enxerga, incluindo `visible` herdado? */
const isDrawn = (root: THREE.Object3D, object: THREE.Object3D | null, camera = new THREE.PerspectiveCamera()): boolean => {
  if (!object) return false;
  let inScene = false;
  for (let o: THREE.Object3D | null = object; o; o = o.parent) if (o === root) inScene = true;
  if (!inScene) return false;
  for (let o: THREE.Object3D | null = object; o; o = o.parent) if (!o.visible) return false;
  return camera.layers.test(object.layers);
};

describe('SpawnPresenter (AIS-44e-C01)', () => {
  it('monta a rootObject uma vez; o que já é desenhado pelo espelho sai da câmera; o spawn é desenhado', () => {
    const { session } = open(sceneWith(FLOOR));
    session.registerPrefab(ref('bullet'), prefabOf('bullet', BULLET));
    const three = new THREE.Scene();
    const presenter = new SpawnPresenter();
    const runtime = session.sceneManager.current!;

    expect(presenter.mount(runtime, three)).toBe(true);
    expect(presenter.mount(runtime, three)).toBe(false); // idempotente
    expect(runtime.rootObject.parent).toBe(three);
    const floor = runtime.getInstance('floor')!;
    expect(isDrawn(three, floor.object)).toBe(false); // o espelho da viewport já o desenha: não duplica
    expect(floor.object!.layers.isEnabled(HIDDEN_RUNTIME_LAYER)).toBe(true);

    expect(presenter.takeChanged()).toBe(true); // primeira leitura
    expect(presenter.takeChanged()).toBe(false);
    const h = session.spawnPrefab(ref('bullet'), { position: [1, 3, 0] });
    expect(presenter.takeChanged()).toBe(true); // um spawn novo
    const spawned = runtime.getInstance(h.rootId)!;
    expect(isDrawn(three, spawned.object)).toBe(true);
    expect(presenter.spawnedInstances().map((i) => i.persistentNodeId)).toEqual([h.rootId]);
    session.dispose();
  });

  it('spawn feito ANTES do mount também é desenhado (não é escondido junto com a cena)', () => {
    const { session } = open(sceneWith(FLOOR));
    session.registerPrefab(ref('bullet'), prefabOf('bullet', BULLET));
    const h = session.spawnPrefab(ref('bullet'), { position: [0, 2, 0] });
    const three = new THREE.Scene();
    const presenter = new SpawnPresenter();
    presenter.mount(session.sceneManager.current!, three);
    expect(isDrawn(three, session.sceneManager.current!.getInstance(h.rootId)!.object)).toBe(true);
    session.dispose();
  });

  it('despawn tira o objeto da cena Three e avisa a mudança', () => {
    const { session } = open(sceneWith(FLOOR));
    session.registerPrefab(ref('bullet'), prefabOf('bullet', BULLET));
    const three = new THREE.Scene();
    const presenter = new SpawnPresenter();
    presenter.mount(session.sceneManager.current!, three);
    const h = session.spawnPrefab(ref('bullet'), { position: [0, 2, 0] });
    const object = session.sceneManager.current!.getInstance(h.rootId)!.object!;
    presenter.takeChanged();
    session.despawn(h.rootId);
    session.step(1 / 60);
    expect(presenter.takeChanged()).toBe(true);
    expect(presenter.spawnedInstances()).toEqual([]);
    expect(object.parent).toBeNull(); // liberado pela fábrica
    session.dispose();
  });
});

describe('desmontar e trocar de cena (AIS-44e-C02)', () => {
  it('unmount devolve a cena Three ao estado anterior; restart monta a nova RuntimeScene e solta a antiga', () => {
    const { session } = open(sceneWith(FLOOR));
    const three = new THREE.Scene();
    const before = three.children.length;
    const presenter = new SpawnPresenter();
    const first = session.sceneManager.current!;
    presenter.mount(first, three);
    expect(three.children.length).toBe(before + 1);

    session.restartScene();
    const second = session.sceneManager.current!;
    expect(second).not.toBe(first);
    presenter.mount(second, three);
    expect(first.rootObject.parent).toBeNull();
    expect(second.rootObject.parent).toBe(three);
    expect(three.children.length).toBe(before + 1);

    presenter.unmount();
    expect(three.children.length).toBe(before);
    expect(presenter.mounted).toBeNull();
    presenter.unmount(); // idempotente
    session.dispose();
  });
});

describe('pai em movimento e camadas (AIS-44e-C03)', () => {
  it('um spawn sob um pai (escondido pela camada) continua desenhado e acompanha a matriz mundial do pai', () => {
    const { session } = open(sceneWith(FLOOR, HOLDER));
    session.registerPrefab(ref('bullet'), prefabOf('bullet', BULLET));
    const three = new THREE.Scene();
    const presenter = new SpawnPresenter();
    const runtime = session.sceneManager.current!;
    presenter.mount(runtime, three);
    const h = session.spawnPrefab(ref('bullet'), { parentId: 'holder' });
    const child = runtime.getInstance(h.rootId)!;
    expect(isDrawn(three, runtime.getInstance('holder')!.object)).toBe(false); // o pai é só espelho
    expect(isDrawn(three, child.object)).toBe(true); // o filho de spawn aparece mesmo assim (layers não é herdada)

    const world = (o: THREE.Object3D) => {
      three.updateMatrixWorld(true);
      return o.getWorldPosition(new THREE.Vector3());
    };
    const x0 = world(child.object!).x;
    const holder = runtime.getInstance('holder')!;
    holder.transform.position = [9, 0, 0];
    runtime.applyInstanceTransform(holder);
    expect(world(child.object!).x - x0).toBeCloseTo(4, 3); // pai andou 4 m (5 → 9): o filho foi junto
    session.dispose();
  });
});

describe('tipos sem desenho em runtime (AIS-44e-C04)', () => {
  it('Billboard criado em jogo gera `spawn.node_not_presentable` uma vez por tipo e sessão; o Play segue', () => {
    const { session, diagnostics } = open(sceneWith(FLOOR));
    session.registerPrefab(ref('sprite'), prefabOf('sprite', node('bullet', 'Billboard', [0, 0, 0])));
    session.spawnPrefab(ref('sprite'), { position: [0, 2, 0] });
    session.spawnPrefab(ref('sprite'), { position: [1, 2, 0] });
    const codes = diagnostics.list({ ephemeral: true }).map((d) => d.code);
    expect(codes.filter((c) => c === 'spawn.node_not_presentable')).toHaveLength(1);
    expect(() => session.step(1 / 60)).not.toThrow();
    session.dispose();
  });
});

describe('partículas de spawn (decisão B do AIS-44e)', () => {
  it('ParticleSystem criado em jogo ganha o sistema de partículas da viewport e o perde ao sumir', () => {
    // `getParticleMaskCanvas` usa `document`: um canvas mínimo basta para o motor rodar em Node (sem GPU)
    (globalThis as any).document ??= { createElement: () => ({ width: 0, height: 0, getContext: () => null }) };
    const { session } = open(sceneWith(FLOOR));
    session.registerPrefab(ref('fx'), prefabOf('fx', node('bullet', 'ParticleSystem', [0, 0, 0], { presetId: 'fire' })));
    const three = new THREE.Scene();
    const presenter = new SpawnPresenter();
    const runtime = session.sceneManager.current!;
    presenter.mount(runtime, three);
    const particles = new ViewportParticles();

    const h = session.spawnPrefab(ref('fx'), { position: [0, 1, 0] });
    presenter.takeChanged();
    particles.syncSpawned(presenter.spawnedInstances());
    const host = runtime.getInstance(h.rootId)!.object!;
    expect(host.children.some((c) => c.name === '__particles')).toBe(true);
    particles.syncSpawned(presenter.spawnedInstances()); // idempotente: não duplica
    expect(host.children.filter((c) => c.name === '__particles')).toHaveLength(1);

    session.despawn(h.rootId);
    session.step(1 / 60);
    particles.syncSpawned(presenter.spawnedInstances());
    expect(host.children.some((c) => c.name === '__particles')).toBe(false);
    particles.dispose();
    session.dispose();
  });
});

describe('o authoring nunca é tocado (AIS-44e-C05)', () => {
  it('a cena autoral fica idêntica depois de montar, criar, destruir e desmontar', () => {
    const scene = sceneWith(FLOOR, HOLDER);
    const before = JSON.stringify(scene);
    const { session } = open(scene);
    session.registerPrefab(ref('bullet'), prefabOf('bullet', BULLET));
    const presenter = new SpawnPresenter();
    presenter.mount(session.sceneManager.current!, new THREE.Scene());
    const h = session.spawnPrefab(ref('bullet'), { parentId: 'holder', position: [1, 2, 3] });
    session.despawn(h.rootId);
    session.step(1 / 60);
    presenter.unmount();
    session.dispose();
    expect(JSON.stringify(scene)).toBe(before);
  });
});

describe('Change Scene em jogo (AIS-73)', () => {
  it('showAll desenha a cena viva INTEIRA (nada vai para a camada escondida); sem ele só os spawns aparecem', async () => {
    const THREEmod = await import('three');
    const { RuntimeScene } = await import('./RuntimeScene');
    const { RuntimeObjectFactory } = await import('./RuntimeObjectFactory');
    const { createRuntimeSnapshot } = await import('../core/authoring/snapshot');
    const { createDefault3DStarterScene } = await import('../core/defaultProject');
    const { SpawnPresenter: Presenter, HIDDEN_RUNTIME_LAYER: HIDDEN } = await import('./spawnPresenter');
    const build = () => new RuntimeScene(createRuntimeSnapshot(createDefault3DStarterScene()), new RuntimeObjectFactory());
    const hiddenCount = (scene: InstanceType<typeof RuntimeScene>) => scene.getAllInstances().filter((i) => i.object && i.object.layers.isEnabled(HIDDEN)).length;
    const parent = new THREEmod.Group();
    const normal = build();
    new Presenter().mount(normal, parent);
    expect(hiddenCount(normal)).toBeGreaterThan(0); // o espelho do editor já desenha estes objetos
    const foreign = build();
    new Presenter().mount(foreign, parent, true);
    expect(hiddenCount(foreign)).toBe(0); // cena que o editor NÃO desenha: aparece inteira
    expect(foreign.rootObject.parent).toBe(parent);
  });
});
