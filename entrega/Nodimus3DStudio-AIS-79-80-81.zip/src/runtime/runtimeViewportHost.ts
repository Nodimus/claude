import * as THREE from 'three';
import type { InputReader } from './input/InputManager';
import type { RuntimeInstance, RuntimeScene } from './RuntimeScene';
import type { RuntimeSession } from './RuntimeSession';
import type { GameCameraPose } from './controllers/gameCamera';

/**
 * AIS-44c — RuntimeViewportHost: o Play acontece no MESMO canvas/renderer do editor, sem segundo renderer, sem modal de Play e
 * sem o runtime dentro de hooks do React. A `RuntimeSession` (AIS-44b) é a autoridade do estado de jogo; este módulo só
 * APRESENTA esse estado nos objetos que a viewport já desenha (fidelidade total de material, billboard, luz, partículas…):
 *
 *   RuntimeSession (pose/visibilidade vivas) ──mirror──▶ objetos Three do Viewport ──▶ renderer único
 *
 * Em Edit o Viewport mostra o autoral; em Play mostra a sessão; no Stop o autoral volta (o Viewport restaura as poses e o
 * `activeScene` autoral reaplica tudo). Nada aqui escreve no authoring nem no CommandManager. Funções puras (sem React/DOM).
 */

/** Rig orbital da câmera de edição, reaproveitado para seguir o jogador no Play. */
export interface OrbitCameraRig {
  camera: THREE.PerspectiveCamera;
  target: THREE.Vector3;
  spherical: { radius: number; theta: number; phi: number };
}

/** Posiciona a câmera a partir das coordenadas esféricas em torno do alvo. */
export function applyOrbit(rig: OrbitCameraRig): void {
  const { camera, target, spherical: s } = rig;
  camera.position.x = target.x + s.radius * Math.sin(s.phi) * Math.sin(s.theta);
  camera.position.y = target.y + s.radius * Math.cos(s.phi);
  camera.position.z = target.z + s.radius * Math.sin(s.phi) * Math.cos(s.theta);
  camera.lookAt(target);
}

/**
 * Copia a pose e a visibilidade VIVAS (instância de runtime) para os objetos de apresentação do mesmo nó. Instância destruída
 * no jogo some da tela. Não toca em objetos sem instância (helpers de edição) e devolve quantos objetos atualizou.
 */
export function mirrorSessionToObjects(scene: RuntimeScene, objects: ReadonlyMap<string, THREE.Object3D>): number {
  let updated = 0;
  for (const instance of scene.getAllInstances()) {
    const object = objects.get(instance.persistentNodeId);
    if (!object) continue;
    const t = instance.transform;
    object.position.set(t.position[0], t.position[1], t.position[2]);
    if (!(object as any).__isBillboard) {
      object.rotation.set(THREE.MathUtils.degToRad(t.rotation[0]), THREE.MathUtils.degToRad(t.rotation[1]), THREE.MathUtils.degToRad(t.rotation[2]));
    }
    object.scale.set(t.scale[0], t.scale[1], t.scale[2]);
    object.visible = instance.visible;
    updated++;
  }
  for (const [nodeId, object] of objects) if (scene.wasDestroyed(nodeId)) object.visible = false;
  return updated;
}

/**
 * AIS-47 — aplica a câmera de jogo (controlador de personagem) à câmera da viewport. Chamar DEPOIS da atualização da câmera orbital do
 * editor (que reescreve a pose a cada quadro). Só perspectiva; ortográfica (projeção do editor) não é tocada.
 */
export function applyGameCameraPose(camera: THREE.Camera, pose: GameCameraPose): void {
  camera.position.set(pose.position.x, pose.position.y, pose.position.z);
  camera.quaternion.set(pose.quaternion.x, pose.quaternion.y, pose.quaternion.z, pose.quaternion.w);
  const persp = camera as THREE.PerspectiveCamera;
  if (persp.isPerspectiveCamera && typeof pose.fov === 'number' && persp.fov !== pose.fov) {
    persp.fov = pose.fov;
    persp.updateProjectionMatrix();
  }
}

/** Behaviors de controlador de personagem (AIS-47) e de movimento (AIS-47c): quem os tem é movido por eles, então o jogador implícito cede a vez. */
const CONTROLLER_TYPES: ReadonlySet<string> = new Set(['first_person_movement', 'third_person_movement', 'platformer_2d_movement', 'top_down_2d_movement']);
const hasControllerBehavior = (session: RuntimeSession, nodeId: string): boolean =>
  (session.snapshot.nodes[nodeId]?.behaviors ?? []).some((b) => b.enabled && CONTROLLER_TYPES.has(b.behaviorType));

/**
 * Jogador "implícito" (comportamento herdado da casca): sem nenhum Behavior de movimento, o nó com corpo `character` (ou
 * chamado "player") anda pelas ações MoveForward/… — operando na INSTÂNCIA da sessão, nunca no objeto de edição.
 */
function implicitPlayer(session: RuntimeSession, scene: RuntimeScene): RuntimeInstance | undefined {
  const nodes = Object.values(session.snapshot.nodes);
  if (nodes.some((n) => hasControllerBehavior(session, n.id))) return undefined;
  const found = nodes.find((n) => n.properties?.physics?.bodyMode === 'character' || n.name.toLowerCase().includes('player'));
  return found ? scene.getInstance(found.id) : undefined;
}

export interface RuntimeViewportStep {
  dt: number;
  /** AIS-40b: ações lógicas (MoveForward…), nunca `KeyboardEvent.code`. */
  input: InputReader;
  session: RuntimeSession;
  /** Objetos de apresentação do Viewport por ID autoral. */
  objects: ReadonlyMap<string, THREE.Object3D>;
  rig: OrbitCameraRig;
  /** AIS-46: "Avançar 1 Quadro" — a sessão está pausada e roda exatamente um quadro (`session.stepFrame`). */
  singleStep?: boolean;
}

/**
 * Um quadro do Play na viewport: avança a sessão (Behaviors e regras), aplica o jogador implícito, espelha o estado vivo nos
 * objetos e faz a câmera seguir quem andou. Pausa: o host simplesmente não é chamado (o renderer segue desenhando).
 */
export function stepRuntimeViewportHost({ dt, input, session, objects, rig, singleStep = false }: RuntimeViewportStep): void {
  const scene = session.currentScene;
  if (!scene) return;

  // jogadores explícitos: quem tem Behavior de movimento e se mexeu neste quadro (antes/depois do passo da sessão)
  const watched = scene.getAllInstances().filter((i) => hasControllerBehavior(session, i.persistentNodeId));
  const before = new Map(watched.map((i) => [i.id, i.transform.position.join(',')]));

  if (singleStep) session.stepFrame(dt);
  else session.step(dt);

  let moved: RuntimeInstance | undefined = watched.find((i) => i.transform.position.join(',') !== before.get(i.id));

  if (!moved && (session.status === 'running' || singleStep)) {
    const player = implicitPlayer(session, scene);
    const sx = input.getAxis('MoveLeft', 'MoveRight') * 6 * dt;
    const sz = input.getAxis('MoveForward', 'MoveBackward') * 6 * dt;
    if (player && (sx !== 0 || sz !== 0)) {
      const [x, y, z] = player.transform.position;
      player.transform.position = [x + sx, y, z + sz];
      player.transform.rotation = [player.transform.rotation[0], THREE.MathUtils.radToDeg(Math.atan2(sx, sz)), player.transform.rotation[2]];
      scene.applyInstanceTransform(player);
      moved = player;
    }
  }

  mirrorSessionToObjects(scene, objects);

  // câmera suave segue o jogador durante o gameplay — a menos que um controlador (AIS-47) entregue a câmera de jogo
  if (moved && !session.gameCamera) {
    const [x, y, z] = moved.transform.position;
    rig.target.lerp(new THREE.Vector3(x, y + 0.8, z), 0.08);
    applyOrbit(rig);
  }
}
