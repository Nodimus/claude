import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { Behavior } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { ensureRapier } from '../core/physics/rapierInit';
import { LogicRegistry } from '../logic/registry';
import { buildWheel, controllerProperties, defaultVehicleForm, drivePreset, wheelSlots, type VehicleFormValues } from '../core/vehicles/vehiclePresets';
import { RuntimeSession } from './RuntimeSession';

/**
 * AIS-73 — sessão com Rapier REAL: o carro gerado pelo mesmo `buildWheel` do `VehicleDialog` acelera, freia, vira e não atravessa o chão;
 * com e sem a câmera de perseguição o resultado é IDÊNTICO (decisão 28); o visual das rodas só existe no runtime (o authoring não muda).
 */

beforeAll(async () => {
  await ensureRapier();
});

const held = new Set<string>();
const input = {
  isActionPressed: (a: string) => held.has(a),
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: (neg: string, pos: string) => (held.has(pos) ? 1 : 0) - (held.has(neg) ? 1 : 0),
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
} as never;

const BOX = { size: { x: 1.8, y: 0.6, z: 4 }, center: { x: 0, y: 0, z: 0 } };

const node = (id: string, type: string, parentId: string | null, props: Record<string, unknown>, behaviors: Behavior[] = []): GameNode =>
  ({ id, name: id, type, parentId, childrenIds: [], visible: true, locked: false, properties: props, behaviors }) as unknown as GameNode;

const behavior = (type: string, owner: string, props: Record<string, unknown> = {}): Behavior => {
  const b = (LogicRegistry.getBehavior(type) as any).create({ targetNodeId: owner }) as Behavior;
  return { ...b, targetNodeId: owner, properties: { ...b.properties, ...props } };
};

/** Cena: chão + veículo (Spatial dinâmico com colisor explícito) + rodas filhas (+ câmera de perseguição opcional). */
function vehicleScene(opts: { camera?: boolean; form?: VehicleFormValues; at?: [number, number, number]; withBehaviorOnWheels?: boolean } = {}): SceneData {
  const form = opts.form ?? defaultVehicleForm('car');
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const list: GameNode[] = [];
  const at = opts.at ?? [0, 0.9, 0];
  list.push(node('floor', 'MeshInstance', root.id, { position: { x: 0, y: -0.5, z: 0 }, meshType: 'CubeMesh', scale: { x: 2000, y: 1, z: 2000 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } }));
  const wheelIds: string[] = [];
  list.push(
    node('car', 'Spatial', root.id, { position: { x: at[0], y: at[1], z: at[2] }, physics: { enabled: true, bodyMode: 'dynamic', shape: 'box', size: { ...BOX.size }, mass: form.drive.mass } }, [
      behavior('vehicle_controller', 'car', controllerProperties(form.drive)),
    ])
  );
  for (const slot of wheelSlots(form.type, form.customAxles)) {
    const w = buildWheel(slot, form, BOX);
    const id = `wheel_${slot.role}`;
    wheelIds.push(id);
    list.push(node(id, 'MeshInstance', 'car', w.properties, opts.withBehaviorOnWheels === false ? [] : [behavior('vehicle_wheel', id, w.behavior)]));
  }
  if (opts.camera) {
    list.push(node('cam', 'Camera', root.id, { active: true, position: { x: 0, y: 3, z: 8 } }, [behavior('camera_third_person', 'cam', { targetNodeId: 'car' })]));
  }
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: list.filter((n) => n.parentId === root.id).map((n) => n.id) } as GameNode };
  for (const n of list) nodes[n.id] = n.id === 'car' ? ({ ...n, childrenIds: wheelIds } as GameNode) : n;
  return { ...scene, nodes } as unknown as SceneData;
}

function play(scene: SceneData) {
  const diagnostics = new DiagnosticService();
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input, diagnostics });
  session.start();
  return { session, diagnostics, messages: () => diagnostics.list({ ephemeral: true }).map((d) => `${d.code}:${d.message}`) };
}
const run = (s: RuntimeSession, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) s.step(1 / 60);
};
const tf = (s: RuntimeSession, id = 'car') => s.getSimulatedTransform(id)!;
const speedOf = (s: RuntimeSession) => s.physics!.forwardSpeed('car') ?? 0;
const settle = (s: RuntimeSession) => {
  held.clear();
  run(s, 2.5);
};

describe('veículo no Play (AIS-73-C01/C03)', () => {
  it('assenta sobre as molas e não atravessa o chão', () => {
    const { session, messages } = play(vehicleScene());
    settle(session);
    expect(tf(session).position[1]).toBeGreaterThan(0.2);
    expect(tf(session).position[1]).toBeLessThan(1.5);
    expect(messages().filter((m) => m.startsWith('physics.') || m.startsWith('behavior.'))).toEqual([]);
    session.dispose();
  });

  it('Accelerate acelera para a FRENTE (-Z) até perto de maxSpeed; soltar desacelera sozinho', () => {
    const { session } = play(vehicleScene());
    settle(session);
    held.add('Accelerate');
    run(session, 8);
    const top = speedOf(session);
    expect(top).toBeGreaterThan(8);
    expect(top).toBeLessThan(31); // maxSpeed do Arcade = 30 m/s
    expect(tf(session).position[2]).toBeLessThan(-20);
    expect(tf(session).position[1]).toBeGreaterThan(0.2); // segue sobre o chão
    held.clear();
    run(session, 6);
    expect(speedOf(session)).toBeLessThan(top * 0.85); // resistência de rolamento
    session.dispose();
  });

  it('Brake freia em movimento e, parado, engata a ré', () => {
    const { session } = play(vehicleScene());
    settle(session);
    held.add('Accelerate');
    run(session, 5);
    const fast = speedOf(session);
    held.clear();
    held.add('Brake');
    run(session, 3);
    expect(speedOf(session)).toBeLessThan(fast * 0.35);
    run(session, 6);
    expect(speedOf(session)).toBeLessThan(-0.5); // de ré
    held.clear();
    session.dispose();
  });

  it('SteerLeft vira para a esquerda (-X) e SteerRight para a direita (+X)', () => {
    const left = play(vehicleScene());
    settle(left.session);
    held.add('Accelerate');
    held.add('SteerLeft');
    run(left.session, 5);
    const lx = tf(left.session).position[0];
    held.clear();
    left.session.dispose();
    const right = play(vehicleScene());
    settle(right.session);
    held.add('Accelerate');
    held.add('SteerRight');
    run(right.session, 5);
    const rx = tf(right.session).position[0];
    held.clear();
    right.session.dispose();
    expect(lx).toBeLessThan(-1);
    expect(rx).toBeGreaterThan(1);
  });

  it('Handbrake para o carro mesmo com Accelerate', () => {
    const { session } = play(vehicleScene());
    settle(session);
    held.add('Accelerate');
    run(session, 4);
    held.add('Handbrake');
    run(session, 4);
    expect(speedOf(session)).toBeLessThan(2);
    held.clear();
    session.dispose();
  });
});

describe('o controlador não possui câmera (AIS-73-C10, decisão 28)', () => {
  const drive = (camera: boolean) => {
    const { session } = play(vehicleScene({ camera }));
    settle(session);
    held.add('Accelerate');
    held.add('SteerLeft');
    run(session, 4);
    held.delete('SteerLeft');
    run(session, 3);
    const t = tf(session);
    const out = { position: [...t.position], rotation: [...t.rotation] };
    held.clear();
    session.dispose();
    return out;
  };

  it('com e sem a câmera de perseguição, a dinâmica do veículo é IDÊNTICA', () => {
    const without = drive(false);
    const withCamera = drive(true);
    expect(withCamera.position[0]).toBeCloseTo(without.position[0], 6);
    expect(withCamera.position[1]).toBeCloseTo(without.position[1], 6);
    expect(withCamera.position[2]).toBeCloseTo(without.position[2], 6);
  });

  it('o código-fonte do controlador não importa cameraRig nem chama setGameCamera', async () => {
    const fs = await import('node:fs');
    for (const file of ['index.ts', 'runtime.ts']) {
      const text = fs.readFileSync(`src/logic/behaviors/vehicle_controller/${file}`, 'utf8');
      expect(text).not.toMatch(/from\s+['"][^'"]*cameraRig/); // nenhum import de cameraRig
      expect(text).not.toMatch(/\.setGameCamera\s*\(/); // nenhuma chamada que publique pose de câmera
    }
  });
});

describe('rodas: só visual em runtime (AIS-73-C12)', () => {
  it('as rodas giram e a dianteira esterça NA INSTÂNCIA VIVA; o authoring (snapshot) não muda', () => {
    const scene = vehicleScene();
    const authoring = JSON.stringify(scene.nodes.wheel_front_left.properties);
    const { session } = play(scene);
    settle(session);
    const before = [...session.scene.getInstance('wheel_front_left')!.transform.rotation];
    held.add('Accelerate');
    held.add('SteerLeft');
    run(session, 2);
    const live = session.scene.getInstance('wheel_front_left')!;
    expect(live.transform.rotation.map((n) => Math.round(n))).not.toEqual(before.map((n) => Math.round(n)));
    expect(JSON.stringify(scene.nodes.wheel_front_left.properties)).toBe(authoring);
    held.clear();
    session.dispose();
  });

  it('a roda sobe e desce com a suspensão (posição Y viva muda ao frear forte)', () => {
    const { session } = play(vehicleScene());
    settle(session);
    const rest = session.scene.getInstance('wheel_front_left')!.transform.position[1];
    held.add('Accelerate');
    run(session, 4);
    held.clear();
    held.add('Brake');
    let moved = 0;
    for (let i = 0; i < 120; i++) {
      session.step(1 / 60);
      moved = Math.max(moved, Math.abs(session.scene.getInstance('wheel_front_left')!.transform.position[1] - rest));
    }
    expect(moved).toBeGreaterThan(0.005);
    held.clear();
    session.dispose();
  });
});

describe('configuração incompleta avisa, nunca quebra (AIS-73)', () => {
  it('sem rodas: avisa uma vez e a sessão segue', () => {
    const scene = vehicleScene({ withBehaviorOnWheels: false });
    const { session, messages } = play(scene);
    settle(session);
    held.add('Accelerate');
    run(session, 1);
    held.clear();
    expect(session.status).toBe('running');
    expect(messages().join('\n')).toMatch(/Vehicle Controller: o nó não tem rodas/);
    session.dispose();
  });
});

/** O "para cima" do veículo (+Y local) no mundo: 1 = em pé, ≤ 0 = de lado/de cabeça para baixo. */
const upDot = (s: RuntimeSession, id = 'car') => {
  const q = s.physics!.getPose(id)!.rotation;
  return 1 - 2 * (q.x * q.x + q.z * q.z);
};

describe('estabilidade: o carro não capota em curva rápida (AIS-73-C01)', () => {
  it('Arcade: acelerar a fundo e esterçar totalmente a ~25 m/s mantém o carro de pé e sobre as rodas', () => {
    const { session } = play(vehicleScene());
    settle(session);
    held.add('Accelerate');
    run(session, 6);
    held.add('SteerLeft');
    let worst = 1;
    for (let i = 0; i < 6 * 60; i++) {
      session.step(1 / 60);
      worst = Math.min(worst, upDot(session));
    }
    expect(worst).toBeGreaterThan(0.85); // nunca passa de ~30° de inclinação
    expect(tf(session).position[1]).toBeGreaterThan(0.2);
    expect(tf(session).position[0]).toBeLessThan(-3); // e de fato virou à esquerda
    held.clear();
    session.dispose();
  });

  for (const type of ['truck', 'sport'] as const) {
    it(`${type}: curva em velocidade sem capotar`, () => {
      const form = type === 'truck' ? defaultVehicleForm('truck') : { ...defaultVehicleForm('car'), preset: 'sport' as const, drive: { ...drivePreset('sport').values } };
      const { session } = play(vehicleScene({ form }));
      settle(session);
      held.add('Accelerate');
      run(session, 4);
      held.add('SteerRight');
      let worst = 1;
      for (let i = 0; i < 6 * 60; i++) {
        session.step(1 / 60);
        worst = Math.min(worst, upDot(session));
      }
      expect(worst).toBeGreaterThan(0.85);
      held.clear();
      session.dispose();
    });
  }
});


describe('moto: uma linha de rodas fica em pé, anda e vira (AIS-73)', () => {
  const bikeScene = () => {
    const form = defaultVehicleForm('motorbike');
    const scene = vehicleScene({ form });
    (scene.nodes.car.properties as any).physics = { ...(scene.nodes.car.properties as any).physics, size: { x: 0.5, y: 0.7, z: 2 } };
    return scene;
  };
  const yawOf = (s: RuntimeSession) => {
    const q = s.physics!.getPose('car')!.rotation;
    return (Math.atan2(2 * (q.w * q.y + q.x * q.z), 1 - 2 * (q.y * q.y + q.x * q.x)) * 180) / Math.PI;
  };

  it('com os estabilizadores a moto não deita e NÃO empina a pleno acelerador (a roda dianteira segue no chão)', () => {
    const { session } = play(bikeScene());
    settle(session);
    expect(upDot(session)).toBeGreaterThan(0.95);
    held.add('Accelerate');
    let worst = 1;
    for (let i = 0; i < 4 * 60; i++) {
      session.step(1 / 60);
      worst = Math.min(worst, upDot(session));
    }
    expect(speedOf(session)).toBeGreaterThan(5);
    expect(worst).toBeGreaterThan(0.95); // antes: empinava (up 0,79) e o esterço deixava de ter efeito
    held.clear();
    session.dispose();
  });

  it('esterçar à esquerda indo para a frente vira de verdade para a ESQUERDA (yaw +, x −); à direita, o oposto; sem tombar', () => {
    for (const [key, sign] of [['SteerLeft', 1], ['SteerRight', -1]] as const) {
      const { session } = play(bikeScene());
      settle(session);
      held.add('Accelerate');
      run(session, 2);
      const y0 = yawOf(session);
      const x0 = tf(session).position[0];
      held.add(key);
      let worst = 1;
      for (let i = 0; i < 2 * 60; i++) {
        session.step(1 / 60);
        worst = Math.min(worst, upDot(session));
      }
      expect(sign * (yawOf(session) - y0)).toBeGreaterThan(10);
      expect(sign * (x0 - tf(session).position[0])).toBeGreaterThan(1);
      expect(worst).toBeGreaterThan(0.8); // a moto se inclina de propósito para dentro da curva (até ~32°); aqui só importa não tombar
      held.clear();
      session.dispose();
    }
  });
});

describe('moto: inclina para DENTRO da curva e mais quanto mais rápida (AIS-73)', () => {
  const bikeScene = () => {
    const scene = vehicleScene({ form: defaultVehicleForm('motorbike') });
    (scene.nodes.car.properties as any).physics = { ...(scene.nodes.car.properties as any).physics, size: { x: 0.5, y: 0.7, z: 2 } };
    return scene;
  };
  /** Inclinação lateral (graus, + = esquerda): a vertical do mundo no referencial do corpo. */
  const leanDeg = (s: RuntimeSession) => {
    const q = s.physics!.getPose('car')!.rotation;
    return (Math.atan2(2 * (q.x * q.y + q.w * q.z), 1 - 2 * (q.x * q.x + q.z * q.z)) * 180) / Math.PI;
  };
  const leanAt = (accelSeconds: number, key: 'SteerLeft' | 'SteerRight') => {
    const { session } = play(bikeScene());
    settle(session);
    held.add('Accelerate');
    run(session, accelSeconds);
    const speed = speedOf(session);
    held.add(key);
    let peak = 0;
    let minContacts = 4;
    let minUp = 1;
    for (let i = 0; i < 90; i++) {
      session.step(1 / 60);
      if (Math.abs(leanDeg(session)) > Math.abs(peak)) peak = leanDeg(session);
      minUp = Math.min(minUp, upDot(session));
      minContacts = Math.min(minContacts, session.physics!.vehicleWheels('car').filter((w) => session.physics!.vehicleWheelState('car', w.id)!.inContact).length);
    }
    held.clear();
    session.dispose();
    return { speed, peak, minContacts, minUp };
  };

  it('esterçar à esquerda inclina PARA A ESQUERDA (+), à direita PARA A DIREITA (−): para dentro da curva, nunca para fora', () => {
    const left = leanAt(2, 'SteerLeft');
    const right = leanAt(2, 'SteerRight');
    expect(left.peak).toBeGreaterThan(8); // inclina de verdade
    expect(right.peak).toBeLessThan(-8);
    expect(Math.abs(left.peak + right.peak)).toBeLessThan(6); // simétrica
  });

  it('a inclinação cresce com a velocidade e fica dentro do limite, sem tombar nem sair do chão', () => {
    const slow = leanAt(0.25, 'SteerLeft');
    const fast = leanAt(3, 'SteerLeft');
    expect(fast.speed).toBeGreaterThan(slow.speed + 4);
    expect(fast.peak).toBeGreaterThan(slow.peak + 6);
    expect(fast.peak).toBeLessThan(36); // BIKE_MAX_LEAN + folga do controle
    expect(fast.minContacts).toBeGreaterThanOrEqual(2); // inclinada, apoia nas duas rodas (as de equilíbrio levantam, como numa moto real); nunca no ar
    expect(fast.minUp).toBeGreaterThan(0.8);
  });

  it('parada ou em linha reta a moto fica em pé (inclinação ~0)', () => {
    const { session } = play(bikeScene());
    settle(session);
    expect(Math.abs(leanDeg(session))).toBeLessThan(2);
    held.add('Accelerate');
    run(session, 3);
    expect(Math.abs(leanDeg(session))).toBeLessThan(3);
    held.clear();
    session.dispose();
  });
});
