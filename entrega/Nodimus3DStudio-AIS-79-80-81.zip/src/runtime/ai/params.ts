import { parseTagList } from '../weapons/tags';
import { PATROL_SOURCES, type PatrolSource } from './types';

/** AIS-71 — parâmetros dos Behaviors de IA (um só lugar: definição, executor e testes leem daqui). Leitura tolerante: nunca lança. */

export interface AiParams {
  perceptionRadius: number;
  loseRadius: number;
  perceptionIntervalMs: number;
  targetTags: string[];
  attackRange: number;
  attackCooldownMs: number;
  idleTimeMs: number;
  fleeBelowHealth: number;
  fleeDurationMs: number;
  healthVariable: string;
  movementSpeed: number;
  canFly: boolean;
  patrolSource: PatrolSource;
  patrolRadius: number;
  patrolWaitMs: number;
  patrolRoute: string;
  patrolLoop: 'loop' | 'pingpong';
  patrolPath: string;
  idleAnimation: string;
  walkAnimation: string;
  attackAnimation: string;
}

export const AI_DEFAULTS = {
  perceptionRadius: 10,
  loseRadius: 14,
  perceptionIntervalMs: 200,
  targetTags: '',
  attackRange: 2,
  attackCooldownMs: 1000,
  idleTimeMs: 1000,
  fleeBelowHealth: 0,
  fleeDurationMs: 3000,
  healthVariable: 'health',
  movementSpeed: 3,
  canFly: false,
  patrolSource: 'none',
  patrolRadius: 8,
  patrolWaitMs: 1000,
  patrolRoute: '',
  patrolLoop: 'loop',
  patrolPath: '',
  idleAnimation: '',
  walkAnimation: '',
  attackAnimation: '',
} as const;

/** Intervalo mínimo de percepção: nunca por quadro (AIS-71 §4-8). */
export const MIN_PERCEPTION_INTERVAL_MS = 50;

const num = (v: unknown, fallback: number, min = 0): number => (typeof v === 'number' && Number.isFinite(v) ? Math.max(min, v) : fallback);
const str = (v: unknown, fallback: string): string => (typeof v === 'string' ? v.trim() : fallback);

export function readAiParams(raw: Record<string, any> | undefined): AiParams {
  const D = AI_DEFAULTS;
  const perceptionRadius = num(raw?.perceptionRadius, D.perceptionRadius);
  return {
    perceptionRadius,
    // histerese: perder o alvo exige ir além de onde ele foi detectado
    loseRadius: Math.max(perceptionRadius, num(raw?.loseRadius, D.loseRadius)),
    perceptionIntervalMs: num(raw?.perceptionIntervalMs, D.perceptionIntervalMs, MIN_PERCEPTION_INTERVAL_MS),
    targetTags: parseTagList(raw?.targetTags),
    attackRange: num(raw?.attackRange, D.attackRange),
    attackCooldownMs: num(raw?.attackCooldownMs, D.attackCooldownMs),
    idleTimeMs: num(raw?.idleTimeMs, D.idleTimeMs),
    fleeBelowHealth: num(raw?.fleeBelowHealth, D.fleeBelowHealth),
    fleeDurationMs: num(raw?.fleeDurationMs, D.fleeDurationMs),
    healthVariable: str(raw?.healthVariable, D.healthVariable) || D.healthVariable,
    movementSpeed: num(raw?.movementSpeed, D.movementSpeed),
    canFly: raw?.canFly === true,
    patrolSource: PATROL_SOURCES.includes(raw?.patrolSource) ? (raw!.patrolSource as PatrolSource) : D.patrolSource,
    patrolRadius: num(raw?.patrolRadius, D.patrolRadius),
    patrolWaitMs: num(raw?.patrolWaitMs, D.patrolWaitMs),
    patrolRoute: str(raw?.patrolRoute, ''),
    patrolLoop: raw?.patrolLoop === 'pingpong' ? 'pingpong' : 'loop',
    patrolPath: str(raw?.patrolPath, ''),
    idleAnimation: str(raw?.idleAnimation, ''),
    walkAnimation: str(raw?.walkAnimation, ''),
    attackAnimation: str(raw?.attackAnimation, ''),
  };
}

export interface ActorParams {
  health: number;
  healthVariable: string;
  dieAnimation: string;
}

export const ACTOR_DEFAULTS = { health: 100, healthVariable: 'health', dieAnimation: '' } as const;

export function readActorParams(raw: Record<string, any> | undefined): ActorParams {
  return {
    health: num(raw?.health, ACTOR_DEFAULTS.health),
    healthVariable: str(raw?.healthVariable, ACTOR_DEFAULTS.healthVariable) || ACTOR_DEFAULTS.healthVariable,
    dieAnimation: str(raw?.dieAnimation, ''),
  };
}
