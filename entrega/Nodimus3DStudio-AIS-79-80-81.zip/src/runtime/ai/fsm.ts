import type { AiState } from './types';

/**
 * AIS-71 §A — a lógica de decisão da IA, PURA (sem relógio, sem física, sem cena): o runtime só a alimenta com o que mediu.
 * Estados fixos Idle/Patrol/Chase/Attack/Flee; transições avaliadas a cada tick, a PRIMEIRA que valer vence:
 *   1. Flee    — `fleeBelowHealth > 0`, vida <= limite e há alvo (de qualquer estado, exceto o próprio Flee em curso)
 *   2. Attack  — há alvo e distância <= attackRange
 *   3. Chase   — há alvo
 *   4. Patrol  — há patrulha configurada e o tempo em Idle >= idleTimeMs
 *   5. Idle    — caso contrário
 * Sem alvo, Chase/Attack/Flee decaem para Idle (e só então vale a regra 4). Flee termina por tempo → Idle.
 */

export interface NextStateInputs {
  /** Há alvo detectado (a histerese `loseRadius` já foi aplicada pela percepção). */
  hasTarget: boolean;
  /** Distância (m) até o alvo; `Infinity` sem alvo. */
  targetDistance: number;
  attackRange: number;
  /** Vida atual; `null` = o nó não tem a variável (ou não há vitais) — `fleeBelowHealth` fica inativo. */
  health: number | null;
  fleeBelowHealth: number;
  /** Segundos desde que entrou no estado atual. */
  timeInState: number;
  idleTimeMs: number;
  fleeDurationMs: number;
  patrolEnabled: boolean;
}

export function nextState(state: AiState, i: NextStateInputs): AiState {
  if (state === 'Flee') {
    // o Flee em curso não é reavaliado pela regra 1: dura `fleeDurationMs` (ou até perder o alvo) e volta a Idle
    return i.hasTarget && i.timeInState * 1000 < i.fleeDurationMs ? 'Flee' : 'Idle';
  }
  if (i.hasTarget && i.fleeBelowHealth > 0 && i.health !== null && i.health <= i.fleeBelowHealth) return 'Flee';
  if (i.hasTarget && i.targetDistance <= i.attackRange) return 'Attack';
  if (i.hasTarget) return 'Chase';
  if (state === 'Chase' || state === 'Attack') return 'Idle';
  if (!i.patrolEnabled) return 'Idle';
  if (state === 'Patrol') return 'Patrol';
  return i.timeInState * 1000 >= i.idleTimeMs ? 'Patrol' : 'Idle';
}

export interface TargetCandidate {
  id: string;
  /** Distância centro-a-centro (m). */
  distance: number;
}

/**
 * Alvo = o MAIS PRÓXIMO dentro de `perceptionRadius` (empate: id estável). Sem ninguém no raio de percepção, o alvo atual é mantido
 * enquanto estiver dentro de `loseRadius` (histerese); fora dele, perde o alvo. Os candidatos já vêm filtrados (Tags, próprio nó).
 */
export function selectTarget(candidates: readonly TargetCandidate[], opts: { currentId: string | null; perceptionRadius: number; loseRadius: number }): string | null {
  const byDistance = (a: TargetCandidate, b: TargetCandidate) => a.distance - b.distance || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  const inside = candidates.filter((c) => c.distance <= opts.perceptionRadius).sort(byDistance);
  if (inside.length > 0) return inside[0].id;
  if (opts.currentId) {
    const current = candidates.find((c) => c.id === opts.currentId);
    if (current && current.distance <= opts.loseRadius) return current.id;
  }
  return null;
}
