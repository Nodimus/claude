import type { RuntimeInstance } from '../RuntimeScene';
import { isSelfOrDescendantOf, subtreeIds, worldPoseOf } from '../weapons/fireWeapon';
import { passesTagFilter } from '../weapons/tags';
import type { TargetCandidate } from './fsm';
import type { PerceptionWorld } from './types';

/**
 * AIS-71 §A — percepção: candidatos a alvo pela ÚNICA consulta espacial permitida (`PhysicsBridge.overlapSphere`). Nunca Rapier direto nem
 * `THREE.Raycaster`. O próprio nó e seus descendentes são ignorados; as Tags filtram pelos MESMOS `passesTagFilter`/`parseTagList` do AIS-69
 * (`targetTags` vazio = qualquer GameNode, exceto ele). Projéteis vivos e atores mortos nunca são alvo. Distância = centro a centro.
 */

export interface PerceptionOptions {
  /** Raio da consulta (m): `max(perceptionRadius, loseRadius)`. */
  radius: number;
  targetTags: readonly string[];
  isProjectile: (id: string) => boolean;
  isDead: (id: string) => boolean;
}

export function gatherCandidates(host: PerceptionWorld, self: RuntimeInstance, options: PerceptionOptions): TargetCandidate[] {
  const bridge = host.physics();
  const here = worldPoseOf(self)?.position;
  if (!bridge || bridge.isDisposed || !here || !(options.radius > 0)) return [];
  const hits = bridge.overlapSphere(here, options.radius, { ignoreNodeIds: subtreeIds(self) });
  const out: TargetCandidate[] = [];
  for (const hit of hits) {
    const other = host.instance(hit.nodeId);
    if (!other || other.disposed) continue;
    if (isSelfOrDescendantOf(other, self.persistentNodeId)) continue;
    if (options.isProjectile(other.persistentNodeId) || options.isDead(other.persistentNodeId)) continue;
    if (!passesTagFilter(other.tags, [], options.targetTags)) continue;
    const there = worldPoseOf(other)?.position;
    if (!there) continue;
    out.push({ id: other.persistentNodeId, distance: Math.hypot(there.x - here.x, there.y - here.y, there.z - here.z) });
  }
  return out;
}

/** Distância centro-a-centro até uma instância viva (`Infinity` se sumiu). */
export function distanceBetween(a: RuntimeInstance, b: RuntimeInstance | undefined): number {
  const pa = worldPoseOf(a)?.position;
  const pb = b && !b.disposed ? worldPoseOf(b)?.position : undefined;
  return pa && pb ? Math.hypot(pb.x - pa.x, pb.y - pa.y, pb.z - pa.z) : Infinity;
}
