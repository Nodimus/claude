import type { PhysicsBridge } from '../../core/physics/PhysicsBridge';
import type { RuntimeInstance } from '../RuntimeScene';

/**
 * AIS-71 — contratos da IA de atores (`src/runtime/ai/`). A IA decide e se move (`ai_state_machine`) e tem vitais (`game_actor_with_health`);
 * dano e disparo são do núcleo de armas (AIS-69), movimento é `moveNodeToward` (AIS-72), rota é `resolveRoute` (AIS-72b). Nada aqui toca
 * Rapier, `THREE.Raycaster` ou o authoring: consulta espacial só pela `PhysicsBridge.overlapSphere`.
 */

export type AiState = 'Idle' | 'Patrol' | 'Chase' | 'Attack' | 'Flee';

/** Os 5 estados são FIXOS (sem editor de estados). */
export const AI_STATES: readonly AiState[] = ['Idle', 'Patrol', 'Chase', 'Attack', 'Flee'];

/** Gatilhos de HOOK da IA/ator: Triggers das regras do PRÓPRIO Behavior (nascem vazias). */
export type AiHookTrigger = 'on_ai_state_changed' | 'on_ai_attack' | 'on_actor_hit' | 'on_actor_die';

export const AI_HOOK_TRIGGERS: readonly AiHookTrigger[] = ['on_ai_state_changed', 'on_ai_attack', 'on_actor_hit', 'on_actor_die'];

export type PatrolSource = 'none' | 'random_area' | 'waypoints' | 'path';

export const PATROL_SOURCES: readonly PatrolSource[] = ['none', 'random_area', 'waypoints', 'path'];

/** O que a percepção precisa do mundo (vem da EngineApi: `engine.physics()` e `ctx.getNode`). */
export interface PerceptionWorld {
  physics(): PhysicsBridge | null;
  /** Instância viva por ID estável (`persistentNodeId`). */
  instance(id: string): RuntimeInstance | undefined;
}

/** Estado transitório de um `ai_state_machine` em execução (vive em `state.memory` do Behavior, AIS-78d; nunca vai ao authoring). */
export interface AiBrain {
  state: AiState;
  /** Quando entrou no estado atual (tempo de jogo, s). */
  enteredAt: number;
  targetId: string | null;
  /** Próxima consulta de percepção (s). */
  nextPerceptionAt: number;
  /** Próximo `on_ai_attack` permitido (s). */
  nextAttackAt: number;
  /** Fim do `Flee` em curso (s); `null` fora dele. */
  fleeUntil: number | null;
  /** Patrulha: índice do próximo waypoint, direção (pingpong) e fim da espera (s) quando parado num ponto. */
  waypointIndex: number;
  waypointDir: 1 | -1;
  waitUntil: number | null;
  /** Patrulha aleatória: centro (posição inicial no Play) e destino atual. */
  patrolCenter: { x: number; y: number; z: number } | null;
  patrolPoint: { x: number; y: number; z: number } | null;
  /** Último clipe pedido (só troca quando muda). */
  lastClip: string | null;
}

export const newBrain = (): AiBrain => ({
  state: 'Idle',
  enteredAt: -1, // `-1` = ainda não definido: o primeiro quadro grava o relógio da sessão
  targetId: null,
  nextPerceptionAt: 0,
  nextAttackAt: 0,
  fleeUntil: null,
  waypointIndex: 0,
  waypointDir: 1,
  waitUntil: null,
  patrolCenter: null,
  patrolPoint: null,
  lastClip: null,
});
