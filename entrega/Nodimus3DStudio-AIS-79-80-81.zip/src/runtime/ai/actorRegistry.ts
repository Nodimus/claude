import type { RuntimeInstance } from '../RuntimeScene';

/**
 * AIS-78d — registro de atores da `RuntimeSession` (o que sobrou do antigo `AiService`): só o conhecimento COMPARTILHADO entre nós — quem está
 * morto e qual é o alvo atual de cada ator. O estado privado de cada cérebro (estado, timers, patrulha) vive em `state.memory` do Behavior
 * `ai_state_machine` (como o estado de um script mora no próprio nó, em Godot); a inscrição em `damage_taken` e os ganchos são do Behavior
 * `game_actor_with_health`, pela EngineApi. Descartável com a cena (Stop, restart, troca de cena); nada daqui vai ao authoring.
 */
export class ActorRegistry {
  private readonly targets = new Map<string, string | null>();
  private readonly dead = new Set<string>();
  private disposed = false;

  constructor(
    /** Instância viva por ID estável (para validar o alvo publicado). */
    private readonly instance: (id: string) => RuntimeInstance | undefined
  ) {}

  /** O ator entra (ou volta a entrar, no attach/"Restart Behavior") como VIVO. */
  revive(nodeId: string): void {
    if (!this.disposed) this.dead.delete(nodeId);
  }

  markDead(nodeId: string): void {
    if (!this.disposed) this.dead.add(nodeId);
  }

  isDead(nodeId: string): boolean {
    return this.dead.has(nodeId);
  }

  /** O `ai_state_machine` publica o alvo atual (a Action `shoot` o lê quando não recebe alvo explícito). */
  setTarget(nodeId: string, targetId: string | null): void {
    if (this.disposed) return;
    if (targetId === null) this.targets.delete(nodeId);
    else this.targets.set(nodeId, targetId);
  }

  /** Alvo atual da IA do nó (ID estável) ou `null` (sem alvo, excluído ou morto). */
  currentTarget(nodeId: string): string | null {
    const id = this.targets.get(nodeId) ?? null;
    if (!id) return null;
    const instance = this.instance(id);
    return instance && !instance.disposed && !this.dead.has(id) ? id : null;
  }

  get deadCount(): number {
    return this.dead.size;
  }

  /** Solta tudo (Stop, restart, troca de cena). Idempotente. */
  dispose(): void {
    this.disposed = true;
    this.targets.clear();
    this.dead.clear();
  }
}
