import type { EngineApi } from '../engineApi';
import type { RuntimeInstance } from '../RuntimeScene';
import { tNow } from '../../core/i18n';

/** O próprio nó se for animado, senão o primeiro descendente animado (decisão 30). Pura. */
export function findAnimatedObject(node: RuntimeInstance): RuntimeInstance | undefined {
  if (!node.disposed && node.type === 'MeshInstance' && node.properties.animated === true) return node;
  for (const child of node.children) {
    const hit = findAnimatedObject(child);
    if (hit) return hit;
  }
  return undefined;
}

/**
 * Pede o clipe pela `EngineApi.animation` (decisão 30). Nó sem objeto animado e clipe inexistente viram aviso de referência não resolvida
 * (uma vez por chave, `engine.diagnostics.warnOnce`); sessão sem host de animação = nada (como antes).
 */
export function playActorClip(engine: EngineApi, nodeId: string, start: RuntimeInstance, clip: string): void {
  if (!clip) return;
  const target = findAnimatedObject(start);
  if (!target) {
    engine.diagnostics.warnOnce(`obj:${nodeId}`, 'warning', 'ai.animation_no_object', tNow('clipsMsgCore.animationIsNotAnAnimated', { clip, name: start.name }), nodeId);
    return;
  }
  const result = engine.animation.play(target.persistentNodeId, clip);
  if (!result.ok && result.code !== 'animation.unavailable') engine.diagnostics.warnOnce(`${nodeId}:${clip}`, 'warning', 'ai.animation_unresolved', tNow('clipsMsgCore.animationOfWasNotPlayed', { clip, name: start.name, message: result.message }), nodeId);
}
