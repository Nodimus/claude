/**
 * AIS-71 §A — patrulha (puro). `random_area`: ponto aleatório num círculo horizontal em torno do centro (posição inicial no Play).
 * `waypoints`: índice do próximo ponto da rota (`resolveRoute`) em `loop` ou `pingpong`. O movimento é de `moveNodeToward`; a rota,
 * de `resolveRoute`; o caminho (`path`) é o Behavior `follow_a_path` — nada disto interpola nem move.
 */

export interface Point3 {
  x: number;
  y: number;
  z: number;
}

/** Ponto dentro do círculo de `radius` no plano horizontal, uniforme em área; `random` em [0, 1). Mesma altura do centro. */
export function randomPatrolPoint(center: Point3, radius: number, random: () => number): Point3 {
  const r = Math.max(0, radius) * Math.sqrt(Math.min(0.999999, Math.max(0, random())));
  const angle = 2 * Math.PI * Math.min(0.999999, Math.max(0, random()));
  return { x: center.x + r * Math.cos(angle), y: center.y, z: center.z + r * Math.sin(angle) };
}

/** Próximo índice da rota. `loop` volta ao início; `pingpong` inverte nas pontas. Rota de 0/1 ponto fica em 0. */
export function nextWaypoint(index: number, dir: 1 | -1, count: number, mode: 'loop' | 'pingpong'): { index: number; dir: 1 | -1 } {
  if (count <= 1) return { index: 0, dir: 1 };
  if (mode === 'loop') return { index: (index + 1) % count, dir: 1 };
  const next = index + dir;
  if (next >= count) return { index: count - 2, dir: -1 };
  if (next < 0) return { index: 1, dir: 1 };
  return { index: next, dir };
}
