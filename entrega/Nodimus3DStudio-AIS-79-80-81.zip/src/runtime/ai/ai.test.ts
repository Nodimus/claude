import { describe, expect, it } from 'vitest';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { LogicRegistry, EXPECTED_NATIVE_LOGIC } from '../../logic/registry';
import { ActionRuntime } from '../../logic/actionRuntime';
import { BehaviorRuntimeCatalog } from '../../logic/behaviorRuntime';
import { declareMissingLocals } from '../../core/variableManager';
import { createSetLocalVariablesCommand } from '../../core/commands/VariableCommands';
import { collectWeaponPrefabPaths } from '../weapons/prefabPaths';
import { aiHelperSpec } from '../../components/viewports/viewportAiHelpers';
import { nextState, selectTarget, type NextStateInputs } from './fsm';
import { nextWaypoint, randomPatrolPoint } from './patrol';
import { AI_DEFAULTS, MIN_PERCEPTION_INTERVAL_MS, readActorParams, readAiParams } from './params';

/** AIS-71 — partes PURAS da IA (prioridade de transições, timers, alvo, patrulha, parâmetros), catálogo e o contrato "um só caminho". */

const base: NextStateInputs = { hasTarget: false, targetDistance: Infinity, attackRange: 2, health: null, fleeBelowHealth: 0, timeInState: 0, idleTimeMs: 1000, fleeDurationMs: 3000, patrolEnabled: true };
const at = (over: Partial<NextStateInputs>): NextStateInputs => ({ ...base, ...over });

describe('nextState — prioridade das transições (AIS-71-C06)', () => {
  it('sem alvo: Idle espera idleTimeMs e então vai a Patrol; sem patrulha configurada fica em Idle', () => {
    expect(nextState('Idle', at({ timeInState: 0.5 }))).toBe('Idle');
    expect(nextState('Idle', at({ timeInState: 1 }))).toBe('Patrol');
    expect(nextState('Idle', at({ timeInState: 99, patrolEnabled: false }))).toBe('Idle');
    expect(nextState('Idle', at({ timeInState: 0, idleTimeMs: 0 }))).toBe('Patrol'); // 0 = vai direto
    expect(nextState('Patrol', at({ timeInState: 0 }))).toBe('Patrol');
    expect(nextState('Patrol', at({ patrolEnabled: false }))).toBe('Idle');
  });

  it('com alvo: Chase fora do alcance, Attack dentro dele', () => {
    expect(nextState('Idle', at({ hasTarget: true, targetDistance: 5 }))).toBe('Chase');
    expect(nextState('Chase', at({ hasTarget: true, targetDistance: 2 }))).toBe('Attack'); // <= attackRange
    expect(nextState('Attack', at({ hasTarget: true, targetDistance: 2.1 }))).toBe('Chase');
    expect(nextState('Patrol', at({ hasTarget: true, targetDistance: 1 }))).toBe('Attack');
  });

  it('Flee vence Attack/Chase quando vida <= fleeBelowHealth e há alvo (de qualquer estado); sem o limite, alvo no alcance é Attack', () => {
    const near = at({ hasTarget: true, targetDistance: 1, health: 20, fleeBelowHealth: 30 });
    for (const s of ['Idle', 'Patrol', 'Chase', 'Attack'] as const) expect(nextState(s, near), s).toBe('Flee');
    expect(nextState('Idle', at({ hasTarget: true, targetDistance: 1, health: 20, fleeBelowHealth: 0 }))).toBe('Attack');
    expect(nextState('Idle', at({ hasTarget: true, targetDistance: 1, health: 31, fleeBelowHealth: 30 }))).toBe('Attack');
    expect(nextState('Idle', at({ hasTarget: true, targetDistance: 1, health: 30, fleeBelowHealth: 30 }))).toBe('Flee'); // vida <= limite
    expect(nextState('Idle', at({ hasTarget: true, targetDistance: 1, health: null, fleeBelowHealth: 30 }))).toBe('Attack'); // sem vitais: inativo
    expect(nextState('Idle', at({ hasTarget: false, health: 1, fleeBelowHealth: 30 }))).not.toBe('Flee'); // precisa de alvo
  });

  it('Flee termina por tempo (→ Idle) e decai sem alvo; o Flee em curso não é reavaliado pela regra 1', () => {
    const low = at({ hasTarget: true, targetDistance: 1, health: 1, fleeBelowHealth: 30, fleeDurationMs: 3000 });
    expect(nextState('Flee', { ...low, timeInState: 2.9 })).toBe('Flee');
    expect(nextState('Flee', { ...low, timeInState: 3 })).toBe('Idle');
    expect(nextState('Flee', { ...low, timeInState: 0.1, hasTarget: false })).toBe('Idle');
  });

  it('sem alvo, Chase/Attack decaem para Idle (e só então vale Patrol)', () => {
    expect(nextState('Chase', at({ timeInState: 10 }))).toBe('Idle');
    expect(nextState('Attack', at({ timeInState: 10 }))).toBe('Idle');
  });
});

describe('selectTarget (AIS-71-C08)', () => {
  const c = (id: string, distance: number) => ({ id, distance });
  const opts = { currentId: null, perceptionRadius: 10, loseRadius: 14 };

  it('o mais próximo dentro do raio; empate resolve por id estável', () => {
    expect(selectTarget([c('b', 5), c('a', 3), c('z', 9)], opts)).toBe('a');
    expect(selectTarget([c('b', 4), c('a', 4)], opts)).toBe('a');
    expect(selectTarget([c('a', 10.5)], opts)).toBeNull();
    expect(selectTarget([], opts)).toBeNull();
  });

  it('histerese: mantém o alvo atual até loseRadius; além dele, perde', () => {
    expect(selectTarget([c('a', 12)], { ...opts, currentId: 'a' })).toBe('a');
    expect(selectTarget([c('a', 14.1)], { ...opts, currentId: 'a' })).toBeNull();
    expect(selectTarget([c('a', 12)], { ...opts, currentId: 'outro' })).toBeNull();
    expect(selectTarget([c('a', 12), c('n', 3)], { ...opts, currentId: 'a' })).toBe('n'); // alguém mais próximo dentro do raio de percepção
  });
});

describe('patrulha', () => {
  it('random_area fica dentro do círculo (mesma altura) e é determinística com o sorteio injetado', () => {
    const center = { x: 4, y: 1, z: -2 };
    let seed = 7;
    const rand = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    for (let i = 0; i < 200; i++) {
      const p = randomPatrolPoint(center, 5, rand);
      expect(Math.hypot(p.x - center.x, p.z - center.z)).toBeLessThanOrEqual(5 + 1e-9);
      expect(p.y).toBe(1);
    }
    expect(randomPatrolPoint(center, 5, () => 0)).toEqual({ x: 4, y: 1, z: -2 });
    expect(randomPatrolPoint(center, 0, () => 0.9)).toEqual({ x: 4, y: 1, z: -2 });
  });

  it('waypoints: loop volta ao início; pingpong inverte nas pontas; 1 ponto fica parado', () => {
    let i = 0;
    const loop = Array.from({ length: 5 }, () => (i = nextWaypoint(i, 1, 3, 'loop').index));
    expect(loop).toEqual([1, 2, 0, 1, 2]);
    let s = { index: 0, dir: 1 as 1 | -1 };
    const seq = Array.from({ length: 6 }, () => (s = nextWaypoint(s.index, s.dir, 3, 'pingpong')).index);
    expect(seq).toEqual([1, 2, 1, 0, 1, 2]);
    expect(nextWaypoint(0, 1, 1, 'loop')).toEqual({ index: 0, dir: 1 });
    expect(nextWaypoint(0, 1, 0, 'pingpong')).toEqual({ index: 0, dir: 1 });
  });
});

describe('parâmetros', () => {
  it('leitura tolerante com os padrões; loseRadius nunca fica abaixo de perceptionRadius; percepção nunca por quadro', () => {
    const d = readAiParams(undefined);
    expect(d.perceptionRadius).toBe(AI_DEFAULTS.perceptionRadius);
    expect(d.patrolSource).toBe('none');
    const p = readAiParams({ perceptionRadius: 20, loseRadius: 5, perceptionIntervalMs: 1, targetTags: 'a, b', patrolSource: 'xyz', movementSpeed: -3, canFly: 'sim', healthVariable: '  ' });
    expect(p.loseRadius).toBe(20);
    expect(p.perceptionIntervalMs).toBe(MIN_PERCEPTION_INTERVAL_MS);
    expect(p.targetTags).toEqual(['a', 'b']);
    expect(p.patrolSource).toBe('none');
    expect(p.movementSpeed).toBe(0);
    expect(p.canFly).toBe(false);
    expect(p.healthVariable).toBe('health');
    expect(readActorParams({ health: 'x', dieAnimation: ' morrer ' })).toEqual({ health: 100, healthVariable: 'health', dieAnimation: 'morrer' });
  });
});

describe('catálogo e cobertura (AIS-71-C14, C15)', () => {
  const ids = {
    triggers: ['on_ai_state_changed', 'on_ai_attack', 'on_actor_hit', 'on_actor_die'],
    behaviors: ['ai_state_machine', 'game_actor_with_health'],
    actions: ['shoot'],
  };

  it('os 7 itens estão em EXPECTED_NATIVE_LOGIC e no LogicRegistry, na categoria IA, com executor', () => {
    for (const id of ids.triggers) {
      expect(EXPECTED_NATIVE_LOGIC.trigger, id).toContain(id);
      expect(LogicRegistry.isKnownTrigger(id), id).toBe(true);
      expect(LogicRegistry.getTrigger(id)!.category, id).toBe('AI');
    }
    for (const id of ids.behaviors) {
      expect(EXPECTED_NATIVE_LOGIC.behavior, id).toContain(id);
      expect(LogicRegistry.getBehavior(id)!.category, id).toBe('AI');
      expect(BehaviorRuntimeCatalog.get(id), `runtime de ${id}`).toBeDefined();
      expect(LogicRegistry.getBehavior(id)!.status, id).not.toBe('disabled');
    }
    expect(EXPECTED_NATIVE_LOGIC.action).toContain('shoot');
    expect(LogicRegistry.getAction('shoot')!.category).toBe('AI');
    expect(ActionRuntime.get('shoot'), 'executor de shoot').toBeDefined();
  });

  it('os Behaviors nascem com as regras de gancho VAZIAS (uma por estado + ataque; hit + die)', () => {
    const ai = (LogicRegistry.getBehavior('ai_state_machine') as any).create({ targetNodeId: 'x' });
    expect(ai.rules.map((r: { eventType: string; parameters: { state?: string } }) => `${r.eventType}:${r.parameters.state ?? ''}`)).toEqual([
      'on_ai_state_changed:Idle', 'on_ai_state_changed:Patrol', 'on_ai_state_changed:Chase', 'on_ai_state_changed:Attack', 'on_ai_state_changed:Flee', 'on_ai_attack:',
    ]);
    const actor = (LogicRegistry.getBehavior('game_actor_with_health') as any).create({ targetNodeId: 'x' });
    expect(actor.rules.map((r: { eventType: string }) => r.eventType)).toEqual(['on_actor_hit', 'on_actor_die']);
    for (const r of [...ai.rules, ...actor.rules]) expect(r.actions).toEqual([]);
  });

  it('o seletor de variável de vida é Local do nó dono; fontes de patrulha só mostram os campos do modo; animações vêm do objeto', () => {
    const health = LogicRegistry.getBehavior('ai_state_machine')!.params.find((p) => p.key === 'healthVariable')!;
    expect(health).toMatchObject({ variable: true, variableScope: 'local' });
    const params = LogicRegistry.getBehavior('ai_state_machine')!.params;
    expect(params.find((p) => p.key === 'patrolPath')).toMatchObject({ nodeTypes: ['Path'], visibleWhen: { key: 'patrolSource', equals: 'path' } });
    for (const key of ['idleAnimation', 'walkAnimation', 'attackAnimation']) expect(params.find((p) => p.key === key)!.optionsFrom).toBe('animations');
    expect(LogicRegistry.getBehavior('game_actor_with_health')!.params.find((p) => p.key === 'dieAnimation')!.optionsFrom).toBe('animations');
    expect(params.some((p) => /lista|list/i.test(p.type))).toBe(false); // sem tipo de parâmetro novo
  });

  it('o Trigger on_ai_state_changed tem o parâmetro state com os 5 estados (decisão 30: animação só por clipe do objeto, o guarda noLegacyAnimation cobre o legado)', () => {
    expect(LogicRegistry.getTrigger('on_ai_state_changed')!.params[0]).toMatchObject({ key: 'state', options: ['Idle', 'Patrol', 'Chase', 'Attack', 'Flee'] });
  });

  it('o prefab da Action shoot entra no pré-carregamento do núcleo de armas', () => {
    const snapshot = { nodes: { a: { id: 'a', behaviors: [{ behaviorType: 'ai_state_machine', properties: {}, rules: [{ actions: [{ type: 'shoot', parameters: { bullet: 'res://prefabs/tiro.prefab.json' } }] }] }] } } } as never;
    expect(collectWeaponPrefabPaths(snapshot)).toEqual(['res://prefabs/tiro.prefab.json']);
  });
});

describe('vida declarada por Command (AIS-71-C12)', () => {
  it('declareMissingLocals só acrescenta o que falta (nunca sobrescreve o valor editado) e devolve null sem mudança', () => {
    expect(declareMissingLocals({}, { health: 100 })).toEqual({ health: 100 });
    expect(declareMissingLocals({ health: 42, ouro: 1 }, { health: 100 })).toBeNull();
    expect(declareMissingLocals(undefined, { vida: 50, nome: 'x', vivo: true })).toEqual({ vida: 50, nome: 'x', vivo: true });
    expect(declareMissingLocals({}, { 'nome inválido': 1 })).toBeNull();
    const preset = (LogicRegistry.getBehavior('game_actor_with_health') as any).presetVariables;
    expect(preset({ healthVariable: 'hp', health: 80 })).toEqual({ hp: 80 });
    expect(preset({})).toEqual({ health: 100 });
  });

  it('o Command de declaração tem Undo que remove a variável', () => {
    let vars: Record<string, any> | undefined = { ouro: 3 };
    const store = { get: () => vars, set: (_: string, next: Record<string, any>) => void (vars = next) };
    const next = declareMissingLocals(vars, { health: 100 })!;
    const command = createSetLocalVariablesCommand({ label: 'Preset: variável Local "health"', store, nodeId: 'n', next })!;
    command.execute();
    expect(vars).toEqual({ ouro: 3, health: 100 });
    command.undo();
    expect(vars).toEqual({ ouro: 3 });
  });
});

describe('helpers de editor (AIS-71-C17)', () => {
  it('raios a desenhar: só com ai_state_machine ligado; patrulha só em random_area', () => {
    const node = (props: Record<string, unknown>, enabled = true) => ({ behaviors: [{ behaviorType: 'ai_state_machine', enabled, properties: props }] }) as never;
    expect(aiHelperSpec(undefined)).toBeNull();
    expect(aiHelperSpec({ behaviors: [] } as never)).toBeNull();
    expect(aiHelperSpec(node({}, false))).toBeNull();
    expect(aiHelperSpec(node({ perceptionRadius: 6, loseRadius: 9 }))).toEqual({ perception: 6, lose: 9, patrol: null });
    expect(aiHelperSpec(node({ perceptionRadius: 6, loseRadius: 9, patrolSource: 'random_area', patrolRadius: 4 }))).toEqual({ perception: 6, lose: 9, patrol: 4 });
    expect(aiHelperSpec(node({ patrolSource: 'waypoints', patrolRadius: 4 }))!.patrol).toBeNull();
  });
});

describe('um só caminho (AIS-71-C11, C04b)', () => {
  const read = (p: string) => readFileSync(p, 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
  const walk = (dir: string): string[] => readdirSync(dir).flatMap((n) => (statSync(join(dir, n)).isDirectory() ? walk(join(dir, n)) : n.endsWith('.ts') && !n.endsWith('.test.ts') ? [join(dir, n)] : []));
  const aiFiles = [
    ...walk('src/runtime/ai'),
    'src/logic/behaviors/ai_state_machine/runtime.ts',
    'src/logic/behaviors/game_actor_with_health/runtime.ts',
    'src/logic/actions/shoot/runtime.ts',
  ];

  it('nenhum arquivo da IA usa Rapier, THREE.Raycaster ou physicsRegistry', () => {
    for (const file of aiFiles) expect(read(file), file).not.toMatch(/Raycaster|@dimforge|rapier|physicsRegistry/i);
  });

  it('o movimento é só `moveNodeToward`: nenhum setLinearVelocity/teleport/setPose; a patrulha por Path compõe follow_a_path', () => {
    const code = read('src/logic/behaviors/ai_state_machine/runtime.ts');
    expect(code).toMatch(/moveNodeToward\(/);
    expect(code).not.toMatch(/setLinearVelocity|teleport\(|setPose|addImpulse|addForce|getPointAt|CatmullRom/);
    expect(code).toMatch(/follow_a_path\/runtime/);
    expect(code).toMatch(/overlapSphere|gatherCandidates/);
  });

  it('o tempo vem do relógio da sessão: nenhum Date.now/performance.now nos arquivos da IA', () => {
    for (const file of aiFiles) expect(read(file), file).not.toMatch(/Date\.now|performance\.now/);
  });

  it('a percepção usa a única consulta espacial (overlapSphere) e nada de raycast', () => {
    expect(read('src/runtime/ai/perception.ts')).toMatch(/overlapSphere\(/);
    for (const file of aiFiles) expect(read(file), file).not.toMatch(/\.raycast\(/);
  });
});
