import { describe, expect, it } from 'vitest';
import { SubscriptionRegistry } from './subscriptions';

/** AIS-48b — registry de disposers por owner (puro). */
describe('SubscriptionRegistry', () => {
  const scene = { kind: 'scene', id: 's' } as const;
  const bA = { kind: 'behavior', id: 'n::a' } as const;
  const bB = { kind: 'behavior', id: 'n::b' } as const;

  it('add devolve um unsubscribe idempotente que roda o disposer uma única vez', () => {
    const reg = new SubscriptionRegistry();
    let n = 0;
    const off = reg.add(scene, () => n++);
    expect(reg.count()).toBe(1);
    off();
    off();
    expect(n).toBe(1);
    expect(reg.count()).toBe(0);
    expect(reg.owners()).toEqual([]);
  });

  it('disposeOwner cancela só as inscrições do dono; as dos outros seguem', () => {
    const reg = new SubscriptionRegistry();
    const hits: string[] = [];
    reg.add(bA, () => hits.push('a1'));
    reg.add(bA, () => hits.push('a2'));
    reg.add(bB, () => hits.push('b1'));
    expect(reg.disposeOwner(bA)).toBe(2);
    expect(hits).toEqual(['a1', 'a2']);
    expect(reg.count({ owner: bA })).toBe(0);
    expect(reg.count({ owner: bB })).toBe(1);
    expect(reg.disposeOwner(bA)).toBe(0); // idempotente
  });

  it('unsubscribe depois do disposeOwner não roda de novo', () => {
    const reg = new SubscriptionRegistry();
    let n = 0;
    const off = reg.add(bA, () => n++);
    reg.disposeOwner(bA);
    off();
    expect(n).toBe(1);
  });

  it('disposeKind e disposeAll(keep) respeitam o tipo do dono', () => {
    const reg = new SubscriptionRegistry();
    reg.add(scene, () => undefined);
    reg.add(bA, () => undefined);
    reg.add({ kind: 'session', id: 'x' }, () => undefined);
    reg.add({ kind: 'script-worker', id: 'w' }, () => undefined);
    expect(reg.count({ kind: 'behavior' })).toBe(1);
    expect(reg.disposeKind('behavior')).toBe(1);
    expect(reg.disposeAll(['session'])).toBe(2);
    expect(reg.count()).toBe(1);
    expect(reg.disposeAll()).toBe(1);
    expect(reg.count()).toBe(0);
  });

  it('um disposer que lança não impede os demais', () => {
    const reg = new SubscriptionRegistry();
    let ok = 0;
    reg.add(bA, () => {
      throw new Error('boom');
    });
    reg.add(bA, () => ok++);
    expect(() => reg.disposeOwner(bA)).not.toThrow();
    expect(ok).toBe(1);
  });
});
