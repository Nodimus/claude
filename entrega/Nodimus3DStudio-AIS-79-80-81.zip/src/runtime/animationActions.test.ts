import { describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { RuntimeSession } from './RuntimeSession';
import type { LogicLogEntry } from './logicRunner';

/**
 * AIS-60/60b — as Actions `play_animation`, `pause_animation` e `stop_animation` EXECUTAM no Play: falam com o `AnimationHost` da sessão (estado
 * de reprodução; o apresentador da viewport aplica os clipes) e publicam `animation_*` no `SignalBus`.
 */

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[]): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters: {}, conditions: [], actions });
const rules = (...r: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'Regras', behaviorType: 'custom_rules', enabled: true, properties: {}, rules: r });

const CLIPS = [
  { name: 'Idle', duration: 2 },
  { name: 'Walk', duration: 1 },
  { name: 'Run', duration: 0.8 },
];

const node = (id: string, type: string, parentId: string, extra: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type, parentId, childrenIds: [], visible: true, locked: false, properties: type === 'MeshInstance' ? { meshType: 'CubeMesh' } : {}, ...extra }) as unknown as GameNode;

/** `hero` = MeshInstance animado (decisão 30: o próprio objeto guarda a animação); a regra roda no `hero` ou num nó à parte (`trigger`). */
function play(actions: LogicAction[], opts: { registerFirst?: boolean; event?: string; onOther?: boolean } = {}) {
  const { registerFirst = true, event = 'on_start', onOther = false } = opts;
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const behaviors = [rules(rule(event, actions))];
  const nodes: Record<string, GameNode> = {
    [root.id]: { ...root, childrenIds: ['hero', 'trigger'] } as GameNode,
    hero: node('hero', 'MeshInstance', root.id, { properties: { meshType: 'CubeMesh', animated: true, animation: { default: '', autoplay: false, loop: true, speed: 1, crossfade: 0.2 } }, ...(onOther ? {} : { behaviors }) } as Partial<GameNode>),
    trigger: node('trigger', 'MeshInstance', root.id, onOther ? ({ behaviors } as Partial<GameNode>) : {}),
  };
  const logs: LogicLogEntry[] = [];
  const diagnostics = new DiagnosticService();
  const session = new RuntimeSession({
    snapshot: createRuntimeSnapshot({ ...scene, nodes } as unknown as SceneData),
    diagnostics,
    input: { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never,
    onLog: (e) => logs.push(e),
  });
  session.start();
  if (registerFirst) session.animation.register('hero', { clips: CLIPS, crossfade: 0.2 });
  return { session, logs, diagnostics, errors: () => logs.filter((l) => l.level === 'error').map((l) => l.message) };
}

describe('play_animation', () => {
  it('toca a animação do objeto animado (alvo = o próprio objeto)', () => {
    const { session, errors } = play([act('play_animation', { target: 'hero', animation: 'Walk', crossfade: 0.2, loop: true, speed: 1 })]);
    session.step(1 / 60);
    session.step(1 / 60);
    expect(session.animation.stateOf('hero')).toMatchObject({ clip: 'Walk', playing: true });
    expect(errors()).toEqual([]);
    session.dispose();
  });

  it('alvo vazio = o dono da regra; alvo = outro nó animado também funciona', () => {
    const a = play([act('play_animation', { animation: 'Run' })]);
    a.session.step(1 / 60);
    expect(a.session.animation.stateOf('hero')).toMatchObject({ clip: 'Run', playing: true });
    const b = play([act('play_animation', { target: 'hero', animation: 'Idle' })], { onOther: true });
    b.session.step(1 / 60);
    expect(b.session.animation.stateOf('hero')).toMatchObject({ clip: 'Idle', playing: true });
    a.session.dispose();
    b.session.dispose();
  });

  it('crossfade: Idle → Walk faz duas camadas e migra os pesos em segundos', () => {
    const { session } = play([act('play_animation', { animation: 'Idle' })]);
    session.step(1 / 60);
    session.animation.play('hero', 'Walk', { crossfade: 0.2 });
    expect(session.animation.layersOf('hero').map((l) => l.clip)).toEqual(['Idle', 'Walk']);
    for (let i = 0; i < 14; i++) session.step(1 / 60); // > 0,2 s
    expect(session.animation.layersOf('hero')).toHaveLength(1);
    session.dispose();
  });

  it('animação inexistente e nó não animado: erro explícito no log (nada em silêncio)', () => {
    const a = play([act('play_animation', { animation: 'Dance' })]);
    a.session.step(1 / 60);
    expect(a.errors().join('\n')).toMatch(/"Dance" não existe/);
    const b = play([act('play_animation', { target: 'trigger', animation: 'Walk' })], { onOther: true });
    b.session.step(1 / 60);
    expect(b.errors().join('\n')).toMatch(/não é um objeto animado/);
    a.session.dispose();
    b.session.dispose();
  });

  it('pedido feito antes de os clipes carregarem espera e roda no registro', () => {
    const { session } = play([act('play_animation', { animation: 'Walk' })], { registerFirst: false });
    session.step(1 / 60); // a regra roda; ainda não há clipes
    expect(session.animation.isRegistered('hero')).toBe(false);
    session.animation.register('hero', { clips: CLIPS });
    expect(session.animation.stateOf('hero')).toMatchObject({ clip: 'Walk', playing: true });
    session.dispose();
  });
});

describe('pause_animation e stop_animation', () => {
  it('pause_animation pausa e retoma', () => {
    const { session } = play([act('play_animation', { animation: 'Walk' }), act('pause_animation', { paused: true })]);
    session.step(1 / 60);
    expect(session.animation.stateOf('hero')!.playing).toBe(false);
    session.animation.pause('hero', false);
    expect(session.animation.stateOf('hero')!.playing).toBe(true);
    session.dispose();
  });

  it('stop_animation para e volta ao quadro 0', () => {
    const { session, errors } = play([act('play_animation', { animation: 'Walk' }), act('stop_animation', {})]);
    session.step(1 / 60);
    expect(session.animation.stateOf('hero')).toMatchObject({ clip: 'Walk', playing: false, time: 0 });
    expect(errors()).toEqual([]);
    session.dispose();
  });

  it('stop_animation num nó não animado: erro explícito no log', () => {
    const { session, errors } = play([act('stop_animation', { target: 'trigger' })], { onOther: true });
    session.step(1 / 60);
    expect(errors().join(' | ')).toMatch(/não é um objeto animado/);
    session.dispose();
  });
});

describe('sinais e ciclo de vida', () => {
  it('animation_finished e animation_started chegam ao SignalBus com origem no objeto animado', () => {
    const { session } = play([act('play_animation', { animation: 'Walk', loop: false })]);
    session.step(1 / 60);
    for (let i = 0; i < 90; i++) session.step(1 / 60); // Walk dura 1 s e não repete
    const history = session.signalBus.getHistory();
    expect(history.some((e) => e.signal === 'animation_started' && e.source === 'hero')).toBe(true);
    expect(history.some((e) => e.signal === 'animation_finished' && e.source === 'hero' && e.args[0] === 'Walk')).toBe(true);
    session.dispose();
  });

  it('a pausa do Play congela a animação (a sessão não passa o tempo)', () => {
    const { session } = play([act('play_animation', { animation: 'Walk' })]);
    session.step(1 / 60);
    session.pause();
    const t = session.animation.stateOf('hero')!.time;
    for (let i = 0; i < 60; i++) session.step(1 / 60);
    expect(session.animation.stateOf('hero')!.time).toBe(t);
    session.dispose();
  });

  it('restart esvazia o estado de animação', () => {
    const { session } = play([act('play_animation', { animation: 'Walk' })]);
    session.step(1 / 60);
    session.restartScene();
    expect(session.animation.isRegistered('hero')).toBe(false);
    session.dispose();
  });
});
