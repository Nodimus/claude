import { describe, expect, it } from 'vitest';
import { SpriteHost, type SpriteClipInfo } from './spriteHost';

/** AIS-76-C06/C07 — reprodução do Billboard no Play: troca de clipe, `once` congela e os 3 sinais. 10 fps = 100 ms por frame. */
const clips: SpriteClipInfo[] = [
  { name: 'idle', frameIndices: [0, 1, 2], fps: 10, loopMode: 'loop' },
  { name: 'hit', frameIndices: [7, 8], fps: 10, loopMode: 'once' },
  { name: 'bounce', frameIndices: [3, 4, 5], fps: 10, loopMode: 'ping-pong' },
];
const run = (host: SpriteHost, seconds: number, dt = 1 / 60) => {
  for (let t = 0; t < seconds - 1e-9; t += dt) host.step(dt);
};

describe('SpriteHost', () => {
  it('toca a animação do nó (ou a padrão) com o índice GLOBAL do frame', () => {
    const h = new SpriteHost();
    h.register('n', { clips, animation: '', defaultAnimation: 'idle' });
    expect(h.animationOf('n')).toBe('idle');
    expect(h.frameOf('n')).toBe(0);
    run(h, 0.15);
    expect(h.frameOf('n')).toBe(1);
    h.register('m', { clips, animation: 'hit' });
    expect(h.frameOf('m')).toBe(7);
  });

  it('trocar `animation` troca o clipe e recomeça; o mesmo clipe não reinicia; nome desconhecido cai na padrão', () => {
    const h = new SpriteHost();
    h.register('n', { clips, defaultAnimation: 'idle' });
    run(h, 0.25);
    expect(h.frameOf('n')).toBe(2);
    expect(h.setAnimation('n', 'idle')).toBe(true);
    expect(h.frameOf('n')).toBe(2); // sem reiniciar
    expect(h.setAnimation('n', 'bounce')).toBe(true);
    expect(h.animationOf('n')).toBe('bounce');
    expect(h.frameOf('n')).toBe(3);
    expect(h.setAnimation('n', 'nao_existe')).toBe(false);
    expect(h.animationOf('n')).toBe('idle');
    h.setAnimation('n', 'hit');
    h.setAnimation('n', ''); // vazio = padrão
    expect(h.animationOf('n')).toBe('idle');
  });

  it('`once` toca uma vez e CONGELA no último frame (C06)', () => {
    const h = new SpriteHost();
    h.register('n', { clips, animation: 'hit' });
    run(h, 0.15);
    expect(h.frameOf('n')).toBe(8);
    run(h, 5);
    expect(h.frameOf('n')).toBe(8);
    expect(h.isPlaying('n')).toBe(false);
  });

  it('emite frame_changed a cada mudança, animation_looped nos cíclicos e animation_finished SÓ em once (C07)', () => {
    const h = new SpriteHost();
    h.register('l', { clips, animation: 'idle' });
    h.register('o', { clips, animation: 'hit' });
    run(h, 0.65);
    const events = h.drainEvents();
    const of = (node: string, name: string) => events.filter((e) => e.nodeId === node && e.name === name);
    expect(of('l', 'frame_changed').map((e) => e.frame)).toEqual([1, 2, 0, 1, 2, 0].slice(0, of('l', 'frame_changed').length));
    expect(of('l', 'frame_changed').length).toBeGreaterThanOrEqual(5);
    expect(of('l', 'animation_looped').length).toBe(2); // 300 ms por volta, 650 ms
    expect(of('l', 'animation_finished')).toHaveLength(0);
    expect(of('o', 'animation_finished')).toHaveLength(1);
    expect(of('o', 'animation_finished')[0]).toMatchObject({ clip: 'hit', frame: 8 });
    expect(of('o', 'animation_looped')).toHaveLength(0);
    expect(h.drainEvents()).toEqual([]); // drenado
  });

  it('parado (autoplay falso) mostra a posição `frame` e não emite nada; play() retoma', () => {
    const h = new SpriteHost();
    h.register('n', { clips, animation: 'idle', autoplay: false, frame: 2 });
    run(h, 1);
    expect(h.frameOf('n')).toBe(2);
    expect(h.drainEvents()).toEqual([]);
    h.setFrame('n', 99); // clamp ao último
    expect(h.frameOf('n')).toBe(2);
    h.setFrame('n', 1);
    expect(h.frameOf('n')).toBe(1);
    h.play('n');
    run(h, 0.1);
    expect(h.isPlaying('n')).toBe(true);
  });

  it('speedScale acelera/atrasa; 0 congela', () => {
    const h = new SpriteHost();
    h.register('fast', { clips, animation: 'idle', speedScale: 2 });
    h.register('slow', { clips, animation: 'idle', speedScale: 0.5 });
    h.register('stop', { clips, animation: 'idle', speedScale: 0 });
    run(h, 0.13);
    expect(h.frameOf('fast')).toBe(2);
    expect(h.frameOf('slow')).toBe(0);
    expect(h.frameOf('stop')).toBe(0);
    h.setSpeedScale('stop', 1);
    run(h, 0.15);
    expect(h.frameOf('stop')).toBe(1);
  });

  it('play() depois de terminar um once recomeça; sem clipes tudo é seguro', () => {
    const h = new SpriteHost();
    h.register('n', { clips, animation: 'hit' });
    run(h, 1);
    h.play('n');
    expect(h.frameOf('n')).toBe(7);
    h.register('v', { clips: [] });
    run(h, 1);
    expect(h.frameOf('v')).toBe(-1);
    expect(h.animationOf('v')).toBe('');
    expect(h.frameOf('desconhecido')).toBe(-1);
    expect(h.setAnimation('desconhecido', 'idle')).toBe(false);
  });

  it('clear() esquece tudo (restart, troca de cena e Stop)', () => {
    const h = new SpriteHost();
    h.register('n', { clips, animation: 'idle' });
    run(h, 0.5);
    h.clear();
    expect(h.has('n')).toBe(false);
    expect(h.drainEvents()).toEqual([]);
  });
});
