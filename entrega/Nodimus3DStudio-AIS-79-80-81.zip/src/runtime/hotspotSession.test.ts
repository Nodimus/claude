import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { ensureRapier } from '../core/physics/rapierInit';
import { LogicRegistry } from '../logic/registry';
import { RuntimeSession } from './RuntimeSession';
import type { LogicLogEntry } from './logicRunner';

/** AIS-70 — Hotspot no Play: On Hotspot Enter/Exit (física de gatilho, Rapier real) e On Hotspot Click (raycast do Play → runner). */

beforeAll(async () => {
  await ensureRapier();
});

const node = (id: string, type: string, at: [number, number, number], props: Record<string, unknown> = {}, over: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type, parentId: null, childrenIds: [], visible: true, locked: false, properties: { position: { x: at[0], y: at[1], z: at[2] }, ...props }, ...over }) as unknown as GameNode;

const input = { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never;

const hotspotBehavior = (tag = ''): BehaviorInstance => {
  const b = (LogicRegistry.getBehavior('hotspot_events') as any).create({ targetNodeId: 'zona' }) as BehaviorInstance;
  b.rules = b.rules.map((r) => ({ ...r, parameters: tag && r.eventType !== 'on_hotspot_click' ? { tag } : r.parameters, actions: [{ id: `a_${r.eventType}`, type: 'print_log', parameters: { text: r.eventType.toUpperCase() } }] }));
  return b;
};

function open(...extra: GameNode[]) {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  const logs: LogicLogEntry[] = [];
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot({ ...scene, nodes } as unknown as SceneData), input, onLog: (e) => logs.push(e) });
  session.start();
  return { session, logs };
}
const run = (s: RuntimeSession, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) s.step(1 / 60);
};
const count = (logs: LogicLogEntry[], text: string) => logs.filter((l) => l.message.includes(text)).length;

const HOTSPOT = (behavior = hotspotBehavior()) =>
  node('zona', 'Hotspot', [0, 1, 0], { physics: { enabled: true, bodyMode: 'trigger', shape: 'sphere', size: { x: 4, y: 4, z: 4 } } }, { behaviors: [behavior] } as never);
const FLOOR = node('floor', 'MeshInstance', [0, -0.5, 0], { meshType: 'CubeMesh', scale: { x: 40, y: 1, z: 40 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } });
const BODY = (at: [number, number, number], tags: string[] = []) => node('corpo', 'MeshInstance', at, { meshType: 'CubeMesh', physics: { enabled: true, bodyMode: 'dynamic', shape: 'auto' } }, { tags } as never);

describe('Hotspot (AIS-70-C02)', () => {
  it('catálogo: 3 Triggers e o Behavior hotspot_events só para Hotspot', () => {
    for (const id of ['on_hotspot_enter', 'on_hotspot_exit', 'on_hotspot_click']) expect(LogicRegistry.isKnownTrigger(id), id).toBe(true);
    expect(LogicRegistry.behaviorAllowsNodeType('hotspot_events', 'Hotspot')).toBe(true);
    expect(LogicRegistry.behaviorAllowsNodeType('hotspot_events', 'MeshInstance')).toBe(false);
  });

  it('On Hotspot Enter ao entrar e On Hotspot Exit ao sair do volume', () => {
    const { session, logs } = open(FLOOR, HOTSPOT(), BODY([0, 6, 0]));
    run(session, 2); // o corpo cai dentro da esfera (centro y=1, raio 2) e repousa no chão (y≈0,5)
    expect(count(logs, 'ON_HOTSPOT_ENTER')).toBe(1);
    expect(count(logs, 'ON_HOTSPOT_EXIT')).toBe(0);
    session.physics!.teleport('corpo', { x: 10, y: 1, z: 0 });
    run(session, 0.3);
    expect(count(logs, 'ON_HOTSPOT_EXIT')).toBe(1);
    expect(count(logs, 'ON_HOTSPOT_ENTER')).toBe(1);
    session.dispose();
  });

  it('filtro por Tag: só o corpo com a Tag dispara Enter/Exit', () => {
    const wrong = open(FLOOR, HOTSPOT(hotspotBehavior('jogador')), BODY([0, 6, 0], ['outro']));
    run(wrong.session, 2);
    expect(count(wrong.logs, 'ON_HOTSPOT_ENTER')).toBe(0);
    wrong.session.dispose();
    const right = open(FLOOR, HOTSPOT(hotspotBehavior('jogador')), BODY([0, 6, 0], ['jogador']));
    run(right.session, 2);
    expect(count(right.logs, 'ON_HOTSPOT_ENTER')).toBe(1);
    right.session.dispose();
  });

  it('On Hotspot Click: o clique no volume (notifyClick do raycast do Play) dispara; clique em outro nó não', () => {
    const { session, logs } = open(FLOOR, HOTSPOT());
    run(session, 0.2);
    session.runner!.notifyClick('zona', 'left');
    session.runner!.notifyClick('floor', 'left');
    run(session, 0.1);
    expect(count(logs, 'ON_HOTSPOT_CLICK')).toBe(1);
    session.runner!.notifyClick('zona', 'right'); // a regra é do botão esquerdo
    run(session, 0.1);
    expect(count(logs, 'ON_HOTSPOT_CLICK')).toBe(1);
    session.dispose();
  });

  it('o Hotspot não tem corpo sólido: o corpo que entra não é barrado por ele', () => {
    const { session } = open(FLOOR, HOTSPOT(), BODY([0, 3, 0]));
    run(session, 3);
    const y = session.getSimulatedTransform('corpo')!.position[1];
    expect(y).toBeLessThan(0.7); // atravessou o volume e pousou no chão
    session.dispose();
  });
});
