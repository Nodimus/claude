/**
 * AIS-61 §4 — attachment a osso feito em jogo (`attach_to_bone` / `detach_from_bone`). Estado DESCARTÁVEL da `RuntimeSession` (Stop,
 * restart e troca de cena o esvaziam; nunca vai ao authoring nem gera Undo) e PURO — sem Three. O apresentador da viewport
 * (`viewportAttachments.ts`) lê `entries()` e faz o reparent no osso. Um registro `null` = "solto em jogo" (anula o vínculo autoral).
 */

export interface AttachmentRecord {
  /** Nó dono do modelo (esqueleto); `null` = o pai autoral do nó. */
  holder: string | null;
  bone: string;
}

export interface AttachmentControl {
  attach(nodeId: string, record: AttachmentRecord): void;
  detach(nodeId: string): void;
}

export class AttachmentHost implements AttachmentControl {
  private readonly map = new Map<string, AttachmentRecord | null>();
  /** Incrementa a cada mudança (o apresentador compara este número em vez de varrer tudo). */
  revision = 0;

  attach(nodeId: string, record: AttachmentRecord): void {
    this.map.set(nodeId, { holder: record.holder, bone: record.bone });
    this.revision++;
  }

  detach(nodeId: string): void {
    this.map.set(nodeId, null);
    this.revision++;
  }

  /** `undefined` = a sessão não mexeu no nó (vale o vínculo autoral); `null` = solto; senão, o vínculo vivo. */
  get(nodeId: string): AttachmentRecord | null | undefined {
    return this.map.get(nodeId);
  }

  entries(): [string, AttachmentRecord | null][] {
    return [...this.map.entries()];
  }

  clear(): void {
    if (this.map.size === 0) return;
    this.map.clear();
    this.revision++;
  }
}
