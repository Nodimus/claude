import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { ViewportParticles } from '../components/viewports/viewportParticles';
import { RuntimeSession } from './RuntimeSession';
import type { LogicLogEntry } from './logicRunner';
import { ParticleBurstQueue } from './particleRuntime';

/**
 * AIS-59c — a Action `emit_particles` EXECUTA: a regra pede a rajada, a sessão enfileira, o apresentador da viewport a entrega ao motor
 * único (`emitBurst`). Antes não havia executor (a Action ficava habilitada e muda).
 */

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[]): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters: {}, conditions: [], actions });
const behavior = (...rules: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'Regras', behaviorType: 'custom_rules', enabled: true, properties: {}, rules });

const node = (id: string, type: string, over: Partial<GameNode> = {}, props: Record<string, any> = {}): GameNode =>
  ({ id, name: id, type, parentId: null, childrenIds: [], visible: true, locked: false, properties: { position: { x: 0, y: 1, z: 0 }, ...props }, ...over }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: [] } as GameNode };
  for (const n of extra) {
    nodes[n.id] = { ...n, parentId: n.parentId ?? root.id } as GameNode;
    nodes[root.id].childrenIds.push(n.id);
  }
  return { ...scene, nodes };
}

const fakeInput = () => ({
  isActionPressed: () => false,
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: () => 0,
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
});

function play(scene: SceneData) {
  const logs: LogicLogEntry[] = [];
  const diagnostics = new DiagnosticService();
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input: fakeInput(), diagnostics, onLog: (e) => logs.push(e) });
  session.start();
  return { session, logs, diagnostics };
}

const FX = node('fx', 'ParticleSystem', {}, { presetId: 'fire', emitting: false });
const trigger = (target: string, count = 25) => node('btn', 'MeshInstance', { behaviors: [behavior(rule('on_start', [act('emit_particles', { targetNodeId: target, count })]))] } as any, { meshType: 'CubeMesh' });

describe('Action emit_particles (AIS-59c)', () => {
  it('a regra pede a rajada e a sessão a entrega UMA vez ao apresentador', () => {
    const { session, logs } = play(sceneWith(FX, trigger('fx', 25)));
    session.step(1 / 60);
    const bursts = session.takeParticleBursts();
    expect(bursts).toEqual([{ nodeId: 'fx', count: 25 }]);
    expect(session.takeParticleBursts()).toEqual([]); // esvaziou
    expect(logs.filter((l) => l.level === 'error')).toEqual([]);
    session.dispose();
  });

  it('alvo inexistente ou de outro tipo: erro explícito no log, nada é enfileirado', () => {
    const missing = play(sceneWith(FX, trigger('nao-existe')));
    missing.session.step(1 / 60);
    expect(missing.session.takeParticleBursts()).toEqual([]);
    expect(missing.logs.some((l) => l.level === 'error' && /Emit Particles/.test(l.message))).toBe(true);

    const wrong = play(sceneWith(FX, trigger('btn')));
    wrong.session.step(1 / 60);
    expect(wrong.session.takeParticleBursts()).toEqual([]);
    expect(wrong.logs.some((l) => l.level === 'error')).toBe(true);
    missing.session.dispose();
    wrong.session.dispose();
  });

  it('restart e Stop esvaziam a fila (nada vaza para a cena seguinte)', () => {
    const { session } = play(sceneWith(FX, trigger('fx')));
    session.step(1 / 60);
    session.restartScene();
    expect(session.takeParticleBursts()).toEqual([]);
    session.dispose();
  });
});

describe('fila de rajadas', () => {
  it('soma pedidos do mesmo nó, limita e ignora contagem inválida', () => {
    const q = new ParticleBurstQueue();
    q.request('a', 10);
    q.request('a', 5);
    q.request('b', 0);
    q.request('c', -3);
    q.request('d', 1e9);
    expect(q.take()).toEqual([{ nodeId: 'a', count: 15 }, { nodeId: 'd', count: 10_000 }]);
  });
});

describe('apresentador entrega a rajada ao motor único (ViewportParticles.burst)', () => {
  it('as partículas nascem no sistema do nó; nó sem sistema ou oculto devolve 0', () => {
    (globalThis as any).document ??= { createElement: () => ({ width: 0, height: 0, getContext: () => null }) };
    const scene = sceneWith(FX);
    const host = new THREE.Group();
    const particles = new ViewportParticles();
    particles.sync(scene, new Map([['fx', host]]));
    expect(particles.burst('fx', 12)).toBe(12);
    expect(particles.burst('fx', 3)).toBe(3);
    expect(particles.burst('nao-existe', 5)).toBe(0);
    host.visible = false;
    expect(particles.burst('fx', 5)).toBe(0);
    particles.dispose();
  });
});
