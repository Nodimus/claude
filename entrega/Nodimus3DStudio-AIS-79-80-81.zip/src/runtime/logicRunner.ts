import type { GameNode } from '../types/node';
import * as THREE from 'three';
import type { AuthoringSceneSnapshot } from '../types/runtime';
import type { BehaviorInstance, LogicEventRule } from '../types/visualLogic';
import type { ActionRuntimeContext, ConditionNode } from '../logic/types';
import { ActionRuntime } from '../logic/actionRuntime';
import { evaluateConditionOrNull, type ConditionWorld } from '../logic/evaluateCondition';
import { validateAction } from '../logic/validateAction';
import { LogicRegistry } from '../logic/registry';
import { evaluateInputTrigger, type RawInputReader } from './input/inputTriggers';
import { BehaviorRuntimeStates } from './behaviorRuntimeState';
import type { RuntimeInstance, RuntimeScene } from './RuntimeScene';
import type { VariableChange, VariableManager } from '../core/variableManager';
import type { PhysicsBridge } from '../core/physics/PhysicsBridge';
import type { SoundHost } from './audioRuntime';
import type { ParticleHost } from './particleRuntime';
import type { AnimationControl } from './animationRuntime';
import type { SpriteHost } from './spriteHost';
import { nodeOps } from './nodeOps';
import { createEngineCore, deriveActionContext, type EngineCore } from './engineScope';
import type { WeaponService } from './weapons/weaponService';
import type { ActorRegistry } from './ai/actorRegistry';
import type { ScriptHost } from './scripting/ScriptHost';
import type { AttachmentControl } from './attachmentRuntime';
import { spinDynamicBody, stopSpinningBody } from './spinBody';
import { createTweenControl, type TweenControl } from './propertyTweens';
import type { Tweener } from '../animation/tweener';
import { tNow } from '../core/i18n';

/**
 * AIS-44 — LogicRunner: interpretador determinístico de Visual Logic (Behaviors → regras Trigger → Condition → Action).
 *
 * Opera sobre a cena VIVA (`RuntimeScene`, construída de um snapshot): lê as regras do snapshot e escreve só em
 * `RuntimeInstance`/variáveis da sessão — nunca no authoring nem no CommandManager (invariantes 4 e 5 de `types/runtime.ts`).
 * É independente de React/DOM/relógio: o tempo vem de `step(dt)` (pausar = não chamar `step`), o input vem de um
 * `RawInputReader` e os eventos de ponteiro/colisão/sinal chegam por `notify*`/`dispatch*`. O `RuntimeSession` (AIS-44b)
 * passa a ser quem o cria e chama `step`; até lá, `logicRunnerSession.ts` faz essa ponte.
 *
 * Política de execução (skill nodimus-play-mode / emenda 3.1):
 *  - Actions rodam em ORDEM, de forma síncrona; efeito assíncrono (Promise) é fire-and-continue e nunca bloqueia o quadro.
 *  - Operação estrutural destrutiva (`'stop'`: destruir o próprio nó, reiniciar, sair) aborta o resto da cadeia.
 *  - Action inválida/desabilitada/sem executor NUNCA é ignorada em silêncio: vira entrada de log (`error`/`warn`/`info`).
 *  - `run_script` fica desabilitada até o AIS-79 (sandbox): é ignorada sem erro, com uma linha informativa.
 */

export type LogicLogLevel = 'info' | 'warn' | 'error';

/** AIS-48b — contexto de um log/diagnóstico: o MESMO registro do `globalDiagnosticService` o carrega (nunca um tipo paralelo). */
export interface LogicLogMeta {
  code?: string;
  behaviorId?: string;
  logicId?: string;
}

export interface LogicLogEntry extends LogicLogMeta {
  /** ID da instância viva (`RuntimeInstance.id`) dona do log. */
  instanceId?: string;
  /** Segundos de jogo (`sceneTime`) em que a entrada foi emitida. */
  time: number;
  level: LogicLogLevel;
  message: string;
  nodeName?: string;
  /** ID autoral do nó dono (diagnósticos contextuais da sessão). */
  nodeId?: string;
  /** Escreve também no painel Output (Actions de log do usuário, avisos e erros). */
  toOutput: boolean;
}

export interface LogicRunnerHost {
  onLog?(entry: LogicLogEntry): void;
  /** AIS-48b: um sinal foi processado (`emit_signal`/`dispatchSignal`): a sessão repassa aos assinantes (`onSignal`). */
  onSignalEmitted?(name: string): void;
  /** AIS-57: um nó emitiu um sinal de interação (`on_click`/`on_hover`): a sessão o leva ao barramento, com a origem. */
  onNodeSignal?(nodeId: string, signal: 'on_click' | 'on_hover', args: readonly unknown[]): void;
  /** Pedidos de ciclo de vida: chamados DEPOIS da cadeia atual, no fim do `step`. */
  onRestartScene?(): void;
  onQuitGame?(): void;
  /** AIS-44b: pedido de troca de cena (caminho `res://…`); a sessão aborta as cadeias, descarta e carrega a nova. */
  onChangeScene?(scenePath: string): void;
  /** Propriedades de UI mudaram (HUD precisa redesenhar; a cena 3D não). */
  onUiChanged?(): void;
}

export interface LogicRunnerOptions {
  scene: RuntimeScene;
  snapshot: AuthoringSceneSnapshot;
  variables: VariableManager | null;
  input: RawInputReader;
  host?: LogicRunnerHost;
  /** Injetado nos testes; padrão `Math.random`. */
  random?: () => number;
  /** `true` loga também cada disparo de `on_update`/inputs contínuos (padrão: só erros nesses). */
  verbose?: boolean;
  /** AIS-44b: Behaviors cujo executor por propriedades (`behaviors/<id>/runtime.ts`) substitui as `rules` de preset. */
  skipRules?: (behavior: BehaviorInstance) => boolean;
  /** AIS-44b: estados por (nó × Behavior) compartilhados com o lifecycle dos Behaviors (da sessão). */
  behaviorStates?: BehaviorRuntimeStates;
  /** AIS-45: ponte física atual da sessão (pode surgir depois da criação do runner, quando o Rapier termina de carregar). */
  physics?: () => PhysicsBridge | null;
  /** AIS-52: gerenciador de vozes do Play (muda por sessão; `null` = sem áudio). */
  audio?: () => SoundHost | null;
  /** AIS-59b (D6): a lógica escreveu a pose de uma instância (Actions, tweens); a sessão a empurra para o corpo DINÂMICO (a física é a dona da pose). */
  onPoseWritten?: (instance: RuntimeInstance) => void;
  /** AIS-59c: host de partículas da sessão (fila consumida pelo apresentador da viewport; `null` = sem apresentador). */
  particles?: () => ParticleHost | null;
  /** AIS-60: controle de animação da sessão (`AnimationHost`; `null` = sem host). */
  animation?: () => AnimationControl | null;
  /** AIS-76b: host dos Billboards animados (as Actions de sprite). */
  sprites?: () => SpriteHost | null;
  /** AIS-69: núcleo de armas da sessão. */
  weapons?: () => WeaponService | null;
  /** AIS-71: serviço de IA da sessão. */
  ai?: () => ActorRegistry | null;
  /** AIS-79: sandbox de scripts da sessão (a Action `run_script`). */
  scripts?: () => ScriptHost | null;
  /** AIS-61 §4: attachment de nós a ossos da sessão (`AttachmentHost`). */
  attachments?: () => AttachmentControl | null;
  /** AIS-59: `Tweener` da cena viva (a sessão o atualiza a cada quadro e o descarta com a cena). */
  tweener?: () => Tweener | null;
}

interface CompiledRule {
  nodeId: string;
  behavior: BehaviorInstance;
  rule: LogicEventRule;
  /** Acumuladores próprios da regra (temporizador). */
  elapsed: number;
  done: boolean;
}

type RunnerEvent =
  | { kind: 'signal'; name: string }
  | { kind: 'click'; nodeId: string; button: string }
  | { kind: 'hover'; nodeId: string; phase: 'enter' | 'exit' }
  | { kind: 'collision'; type: ContactTrigger; nodeId: string; otherId: string; force?: number }
  | { kind: 'variable'; change: VariableChange }
  | { kind: 'spriteFinished'; nodeId: string; clip: string }
  | { kind: 'hook'; nodeId: string; behaviorId: string; trigger: string; detail: string; params?: Record<string, string> };

/**
 * Triggers de HOOK — disparados só nas regras do PRÓPRIO Behavior que os emite (não existe `on_projectile_hit`).
 * AIS-69: arma (`on_weapon_*`). AIS-71: IA e vitais (`on_ai_state_changed`, `on_ai_attack`, `on_actor_hit`, `on_actor_die`).
 */
const HOOK_TRIGGERS: readonly string[] = ['on_weapon_shoot', 'on_weapon_impact', 'on_weapon_empty', 'on_weapon_reload', 'on_ai_state_changed', 'on_ai_attack', 'on_actor_hit', 'on_actor_die'];

interface Scheduled {
  at: number;
  fn: () => void;
}

const BUTTONS = ['left', 'middle', 'right'];
/** AIS-48: os quatro Triggers físicos (Enter/Exit; nunca Stay). */
export type ContactTrigger = 'on_collision_enter' | 'on_collision_exit' | 'on_trigger_enter' | 'on_trigger_exit';
/** Teto de lotes de eventos por quadro: um laço de sinais/variáveis não trava o quadro (o resto segue no próximo). */
const MAX_EVENT_PASSES = 32;
/**
 * Triggers que podem disparar todo quadro: só aparecem no log em modo verbose (senão o Debugger vira ruído). `on_key_*` e
 * `on_mouse_down` NÃO entram: disparam uma vez por aperto/soltura, então cada disparo é um evento que vale registrar.
 */
const CONTINUOUS_TRIGGERS: ReadonlySet<string> = new Set(['on_update', 'on_input_action']);

export class LogicRunner {
  private readonly scene: RuntimeScene;
  private readonly input: RawInputReader;
  private readonly variables: VariableManager | null;
  private readonly host: LogicRunnerHost;
  private readonly random: () => number;
  private readonly verbose: boolean;
  private readonly rules: CompiledRule[] = [];
  /** Estado mutável por (nó × Behavior): nunca no authoring. */
  public readonly behaviorStates: BehaviorRuntimeStates;

  private time = 0;
  /** AIS-78c: a EngineApi deste runner (o mundo injetado por funções; nada daqui sai para scripts). Actions não assinam sinais nem eventos físicos. */
  private readonly engine: EngineCore = createEngineCore({
    instanceById: (ref) => this.scene.getInstance(ref),
    instanceByName: (name) => this.findByName(name),
    variables: () => this.variables,
    input: () => this.input,
    physics: () => this.physicsOf(),
    sceneTime: () => this.time,
    emitSignal: (name) => this.dispatchSignal(name),
    connectSignal: () => {
      throw new Error('Actions não assinam sinais: use um Behavior (o dono das inscrições).');
    },
    onPhysicsEvent: () => {
      throw new Error('Actions não assinam eventos físicos: use um Behavior (o dono das inscrições).');
    },
    log: (level, message, node, o) => this.log(level, message, node, o?.toOutput ?? level !== 'info', o?.code ? { code: o.code } : undefined),
    commitTransform: (instance) => this.commitTransform(instance),
    audio: () => this.audioOf(),
    particles: () => this.particlesOf(),
    animation: () => this.animationOf(),
    sprites: () => this.spritesOf(),
    tweens: () => this.tweensFor(),
    after: (seconds, fn) => this.schedule(seconds, fn),
    destroy: (instance) => this.destroyInstance(instance),
    setWorldPosition: (instance, position) => this.setWorldPosition(instance, position),
    sceneRequest: (request) => this.requestScene(request),
    weapons: () => this.weaponsOf(),
    actors: () => this.aiOf(),
    fireHook: (ownerId, behaviorId, trigger, detail, params) => this.dispatchHook(ownerId, behaviorId, trigger, detail, params),
    random: () => this.random(),
    scripts: () => this.scriptsOf(),
    attachments: () => this.attachmentsOf(),
    nodeOps: () => nodeOps,
    interpolate: (text, selfNodeId) => this.interpolateText(text, selfNodeId),
    markUiDirty: () => this.markUiDirty(),
    setContinuousRotation: (instance, axis, dps) => this.setContinuousRotation(instance, axis, dps),
    setContinuousVelocity: (instance, velocity, space) => this.setContinuousVelocity(instance, velocity, space),
  });
  private started = false;
  private disposed = false;
  private queue: RunnerEvent[] = [];
  private scheduled: Scheduled[] = [];
  private rotations = new Map<string, { instance: RuntimeInstance; axis: 'x' | 'y' | 'z'; dps: number }>();
  private velocities = new Map<string, { instance: RuntimeInstance; v: { x: number; y: number; z: number }; space: 'world' | 'local' }>();
  private readonly physicsOf: () => PhysicsBridge | null;
  private readonly audioOf: () => SoundHost | null;
  private readonly particlesOf: () => ParticleHost | null;
  private readonly animationOf: () => AnimationControl | null;
  private readonly spritesOf: () => SpriteHost | null;
  private readonly weaponsOf: () => WeaponService | null;
  private readonly aiOf: () => ActorRegistry | null;
  private readonly scriptsOf: () => ScriptHost | null;
  private readonly attachmentsOf: () => AttachmentControl | null;
  private readonly onPoseWritten: (instance: RuntimeInstance) => void;
  private readonly tweenerOf: () => Tweener | null;
  private tweenControl: { tweener: Tweener; control: TweenControl } | null = null;
  private pointerHit: string | null = null;
  private pendingRestart = false;
  private pendingQuit = false;
  private pendingChange: string | null = null;
  /** AIS-44b: troca/restart/abort invalida cadeias em andamento (nunca continuam sobre cena destruída). */
  private generation = 0;
  private readonly skipRules: (behavior: BehaviorInstance) => boolean;
  private readonly reported = new Set<string>();
  private readonly disposers: (() => void)[] = [];
  private _uiRevision = 0;
  private _executions = 0;

  constructor(options: LogicRunnerOptions) {
    this.scene = options.scene;
    this.input = options.input;
    this.variables = options.variables;
    this.host = options.host ?? {};
    this.random = options.random ?? Math.random;
    this.verbose = options.verbose ?? false;
    this.skipRules = options.skipRules ?? (() => false);
    this.physicsOf = options.physics ?? (() => null);
    this.audioOf = options.audio ?? (() => null);
    this.particlesOf = options.particles ?? (() => null);
    this.animationOf = options.animation ?? (() => null);
    this.spritesOf = options.sprites ?? (() => null);
    this.weaponsOf = options.weapons ?? (() => null);
    this.aiOf = options.ai ?? (() => null);
    this.scriptsOf = options.scripts ?? (() => null);
    this.attachmentsOf = options.attachments ?? (() => null);
    this.onPoseWritten = options.onPoseWritten ?? (() => {});
    this.tweenerOf = options.tweener ?? (() => null);
    this.behaviorStates = options.behaviorStates ?? new BehaviorRuntimeStates();
    this.compile(options.snapshot);
    if (this.variables) this.disposers.push(this.variables.onVariableChanged((change) => this.queue.push({ kind: 'variable', change })));
  }

  /** Incrementa a cada mudança de propriedade de UI feita por Actions (o host redesenha o HUD quando muda). */
  public get uiRevision(): number {
    return this._uiRevision;
  }
  public get sceneTime(): number {
    return this.time;
  }
  /** Quantas regras já executaram (todas as Actions de uma regra contam uma vez). */
  public get executions(): number {
    return this._executions;
  }
  public get ruleCount(): number {
    return this.rules.length;
  }
  public get isDisposed(): boolean {
    return this.disposed;
  }

  private compile(snapshot: AuthoringSceneSnapshot): void {
    this.compileNodes(Object.values(snapshot.nodes));
  }

  /**
   * AIS-29g — registra as regras de nós criados DEPOIS do início (`spawnPrefab`). `on_start` dispara agora para as regras novas
   * (o nó nasceu agora); as demais seguem o ciclo normal. Devolve quantas regras entraram.
   */
  public addNodes(nodes: Iterable<GameNode>): number {
    if (this.disposed) return 0;
    const before = this.rules.length;
    this.compileNodes(nodes);
    const added = this.rules.slice(before);
    if (this.started) for (const c of added) if (c.rule.eventType === 'on_start') this.fire(c, 'on_start');
    return added.length;
  }

  private compileNodes(nodes: Iterable<GameNode>): void {
    for (const node of nodes) {
      if (!this.scene.getInstance(node.id)) continue;
      for (const behavior of node.behaviors ?? []) {
        if (this.skipRules(behavior)) continue;
        for (const rule of behavior.rules ?? []) {
          this.rules.push({ nodeId: node.id, behavior, rule, elapsed: 0, done: false });
          if (!LogicRegistry.isKnownTrigger(rule.eventType)) {
            this.report(`unknown-trigger:${rule.id}`, 'warn', tNow('logicRunnerMsgCore.unknownTriggerInThisEditor', { eventType: rule.eventType, name: node.name }), undefined, { code: 'trigger.unknown', behaviorId: behavior.id, logicId: rule.eventType });
          }
        }
      }
    }
  }

  // ── entrada de eventos (host) ─────────────────────────────────────────────────────────────────

  /** Clique do mouse sobre um objeto 3D (raycast) ou controle de UI, já resolvido para o ID do nó. */
  public notifyClick(nodeId: string, button: 'left' | 'middle' | 'right' = 'left'): void {
    if (!this.disposed) this.queue.push({ kind: 'click', nodeId, button });
  }

  /** Nó sob o ponteiro neste quadro (`null` = nenhum): rastreia entrada/saída e alimenta `on_mouse_down` com alvo. */
  public setPointerTarget(nodeId: string | null): void {
    if (this.disposed || nodeId === this.pointerHit) return;
    const previous = this.pointerHit;
    this.pointerHit = nodeId;
    if (previous) this.queue.push({ kind: 'hover', nodeId: previous, phase: 'exit' });
    if (nodeId) this.queue.push({ kind: 'hover', nodeId, phase: 'enter' });
  }

  /**
   * Hook de Behavior (`on_weapon_*`, `on_ai_*`, `on_actor_*`) — dispara as regras do Behavior `behaviorId` do nó `nodeId`; processado no quadro.
   * `params` (ex.: `{ state: 'Chase' }`) restringe às regras que declaram o mesmo valor (regra sem o parâmetro dispara sempre).
   */
  public dispatchHook(nodeId: string, behaviorId: string, trigger: string, detail: string, params?: Record<string, string>): void {
    if (!this.disposed && HOOK_TRIGGERS.includes(trigger)) this.queue.push({ kind: 'hook', nodeId, behaviorId, trigger, detail, params });
  }

  /** AIS-76b: um clipe `once` do Billboard terminou → regras `on_sprite_animation_finished` do PRÓPRIO nó (filtro opcional por nome da animação). */
  public dispatchSpriteFinished(nodeId: string, clip: string): void {
    if (!this.disposed) this.queue.push({ kind: 'spriteFinished', nodeId, clip });
  }

  public dispatchSignal(name: string): void {
    if (!this.disposed) this.queue.push({ kind: 'signal', name });
  }

  /** Contato físico (a ponte física do AIS-45 chama): dispara a regra dos DOIS corpos. */
  /** Contato físico de UM lado (a ponte física entrega um evento por participante): dispara só as regras do `selfId`. */
  public dispatchContact(type: ContactTrigger, selfId: string, otherId: string, force?: number): void {
    if (!this.disposed) this.queue.push({ kind: 'collision', type, nodeId: selfId, otherId, force });
  }

  public dispatchCollision(type: ContactTrigger, aId: string, bId: string): void {
    if (this.disposed) return;
    this.queue.push({ kind: 'collision', type, nodeId: aId, otherId: bId }, { kind: 'collision', type, nodeId: bId, otherId: aId });
  }

  /** AIS-78c: o controle de tweens da cena viva (a EngineApi o alcança por aqui; `null` fora de uma cena viva). */
  public getTweenControl(): TweenControl | null {
    return this.tweensFor();
  }

  /** Posiciona a instância numa pose MUNDIAL (converte para local pela hierarquia; só estado de runtime). */
  public setWorldPosition(instance: RuntimeInstance, position: { x: number; y: number; z: number }): void {
    const object = instance.object;
    if (!object) return;
    object.parent?.updateWorldMatrix(true, false);
    const local = object.parent ? object.parent.worldToLocal(new THREE.Vector3(position.x, position.y, position.z)) : new THREE.Vector3(position.x, position.y, position.z);
    instance.transform.position = [local.x, local.y, local.z];
    this.commitTransform(instance);
  }

  /** Pedido de ciclo de vida do jogo (restart/quit/trocar de cena): executado depois da cadeia e do quadro atuais. */
  public requestScene(request: { kind: 'restart' | 'quit' } | { kind: 'change'; path: string }): void {
    if (request.kind === 'restart') this.pendingRestart = true;
    else if (request.kind === 'quit') this.pendingQuit = true;
    else if (request.kind === 'change') this.pendingChange = request.path;
  }

  /** Destrói a instância (e a subárvore) da cena viva; regras dela deixam de disparar. */
  public destroyInstance(instance: RuntimeInstance): void {
    this.scene.destroyInstance(instance.id);
  }

  /** Agenda `fn` daqui a `seconds` segundos de jogo (não bloqueia; só avança com `step`). */
  public schedule(seconds: number, fn: () => void): void {
    if (this.disposed) return;
    this.scheduled.push({ at: this.time + Math.max(0, seconds), fn });
  }

  // ── quadro ────────────────────────────────────────────────────────────────────────────────────

  public step(dt: number): void {
    if (this.disposed) return;
    const delta = Number.isFinite(dt) && dt > 0 ? dt : 0;
    this.time += delta;

    this.runDueTimers();
    if (!this.started) {
      this.started = true;
      for (const c of this.rules) if (c.rule.eventType === 'on_start') this.fire(c, 'on_start');
    }
    this.applyRotations(delta);
    this.applyVelocities(delta);

    for (const c of this.rules) {
      if (this.disposed) return;
      this.evaluatePolling(c, delta);
    }
    this.drainEvents();
    this.finishFrame();
  }

  private runDueTimers(): void {
    if (this.scheduled.length === 0) return;
    const due = this.scheduled.filter((s) => s.at <= this.time).sort((a, b) => a.at - b.at);
    this.scheduled = this.scheduled.filter((s) => s.at > this.time);
    for (const s of due) {
      try {
        s.fn();
      } catch (error) {
        this.report(`timer:${String(error)}`, 'error', tNow('logicRunnerMsgCore.errorInScheduledAction', { value: error instanceof Error ? error.message : String(error) }));
      }
    }
  }

  /** Movimento contínuo de nós sem corpo dinâmico (kinematic/trigger seguem esta pose pela ponte física). */
  private applyVelocities(dt: number): void {
    for (const [id, m] of this.velocities) {
      if (m.instance.disposed) {
        this.velocities.delete(id);
        continue;
      }
      let { x, y, z } = m.v;
      if (m.space === 'local') {
        const [rx, ry, rz] = m.instance.transform.rotation.map((d) => (d * Math.PI) / 180);
        const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz, 'XYZ'));
        const r = new THREE.Vector3(x, y, z).applyQuaternion(q);
        ({ x, y, z } = r);
      }
      const p = m.instance.transform.position;
      m.instance.transform.position = [p[0] + x * dt, p[1] + y * dt, p[2] + z * dt];
      this.scene.applyInstanceTransform(m.instance);
    }
  }

  private applyRotations(dt: number): void {
    for (const [id, r] of this.rotations) {
      if (r.instance.disposed) {
        this.rotations.delete(id);
        continue;
      }
      // corpo DINÂMICO: a física é a dona da pose (escrever no `transform` seria desfeito no mesmo quadro) → velocidade angular pela ponte
      if (spinDynamicBody(this.physicsOf(), r.instance.persistentNodeId, r.axis, r.dps)) continue;
      const index = r.axis === 'x' ? 0 : r.axis === 'y' ? 1 : 2;
      const next: [number, number, number] = [...r.instance.transform.rotation];
      next[index] += r.dps * dt;
      r.instance.transform.rotation = next;
      this.scene.applyInstanceTransform(r.instance);
    }
  }

  /** Triggers avaliados por quadro (tempo e input). Os demais chegam pela fila de eventos. */
  private evaluatePolling(c: CompiledRule, dt: number): void {
    const type = c.rule.eventType;
    if (type === 'on_update') return void this.fire(c, type);
    if (type === 'on_timeout') {
      if (c.done) return;
      const interval = Math.max(0.01, Number(c.rule.parameters.interval) || 1);
      const repeat = c.rule.parameters.repeat !== false;
      c.elapsed += dt;
      while (c.elapsed >= interval && !c.done && !this.disposed) {
        c.elapsed -= interval;
        if (!repeat) c.done = true;
        this.fire(c, type);
      }
      return;
    }
    const result = evaluateInputTrigger(this.input, type, c.rule.parameters);
    if (!result.handled || !result.fired) return;
    if (result.needsPick && !(this.pointerHit && this.isSelfOrDescendant(this.pointerHit, c.nodeId))) return;
    this.fire(c, type);
  }

  private drainEvents(): void {
    for (let pass = 0; pass < MAX_EVENT_PASSES && this.queue.length > 0 && !this.disposed; pass++) {
      const batch = this.queue;
      this.queue = [];
      for (const event of batch) this.dispatch(event);
    }
    if (this.queue.length > 0) {
      this.report('event-loop', 'warn', tNow('logicRunnerMsgCore.moreThanEventBatchesIn', { MAX_EVENT_PASSES }));
    }
  }

  private dispatch(event: RunnerEvent): void {
    switch (event.kind) {
      case 'signal':
        try {
          this.host.onSignalEmitted?.(event.name);
        } catch (error) {
          this.report(`signal-listener:${event.name}`, 'error', tNow('logicRunnerMsgCore.subscriberOfSignalFailed', { name: event.name, value: error instanceof Error ? error.message : String(error) }), undefined, { code: 'runtime.listener_failed' });
        }
        for (const c of this.rules) if (c.rule.eventType === 'on_signal' && c.rule.parameters.signal === event.name) this.fire(c, 'on_signal', tNow('sharedMsgCore.signal', { name: event.name }));
        return;
      case 'click': {
        // AIS-70: clique no volume de um Hotspot (raycast do Play) → On Hotspot Click (botão da regra; padrão esquerdo)
        if (this.scene.getInstance(event.nodeId)?.type === 'Hotspot') {
          for (const c of this.rulesOf(event.nodeId, 'on_hotspot_click')) {
            const wanted = BUTTONS.includes(c.rule.parameters.button) ? c.rule.parameters.button : 'left';
            if (wanted === event.button) this.fire(c, 'on_hotspot_click', tNow('logicRunnerMsgCore.click', { button: event.button }));
          }
        }
        this.host.onNodeSignal?.(event.nodeId, 'on_click', [event.button]);
        const owner = this.bubbleTo(event.nodeId, 'on_click');
        if (!owner) return;
        for (const c of this.rulesOf(owner, 'on_click')) {
          const wanted = BUTTONS.includes(c.rule.parameters.button) ? c.rule.parameters.button : 'left';
          if (wanted === event.button) this.fire(c, 'on_click', tNow('logicRunnerMsgCore.click', { button: event.button }));
        }
        return;
      }
      case 'hover': {
        this.host.onNodeSignal?.(event.nodeId, 'on_hover', [event.phase]);
        const owner = this.bubbleTo(event.nodeId, 'on_hover');
        if (!owner) return;
        for (const c of this.rulesOf(owner, 'on_hover')) {
          if ((c.rule.parameters.phase === 'exit' ? 'exit' : 'enter') === event.phase) this.fire(c, 'on_hover', tNow('logicRunnerMsgCore.pointer', { value: event.phase === 'enter' ? 'entrou' : 'saiu' }));
        }
        return;
      }
      case 'collision':
        // AIS-70: o gatilho de um Hotspot também dispara On Hotspot Enter/Exit (filtro opcional por Tag do corpo que entrou/saiu)
        if ((event.type === 'on_trigger_enter' || event.type === 'on_trigger_exit') && this.scene.getInstance(event.nodeId)?.type === 'Hotspot') {
          const hotspotTrigger = event.type === 'on_trigger_enter' ? 'on_hotspot_enter' : 'on_hotspot_exit';
          const other = this.scene.getInstance(event.otherId);
          for (const c of this.rulesOf(event.nodeId, hotspotTrigger)) {
            const tag = typeof c.rule.parameters.tag === 'string' ? c.rule.parameters.tag.trim() : '';
            if (tag && !(other?.tags ?? []).includes(tag)) continue;
            this.fire(c, hotspotTrigger, tNow('logicRunnerMsgCore.body', { value: other?.name ?? event.otherId }));
          }
        }
        for (const c of this.rulesOf(event.nodeId, event.type)) {
          if (event.type === 'on_collision_enter' && !this.impactAllowed(c, event.force ?? 0)) continue; // força mínima + debounce (legado do Behavior de impacto)
          const other = this.scene.getInstance(event.otherId)?.name ?? event.otherId;
          this.fire(c, event.type, tNow('logicRunnerMsgCore.with', { value: event.type.startsWith('on_trigger') ? 'gatilho' : 'contato', other, value2: event.force !== undefined && event.type === 'on_collision_enter' ? tNow('logicRunnerMsgLast.forceN', { force: event.force.toFixed(1) }) : '' }));
        }
        return;
      case 'spriteFinished':
        for (const c of this.rulesOf(event.nodeId, 'on_sprite_animation_finished')) {
          const wanted = typeof c.rule.parameters.animation === 'string' ? c.rule.parameters.animation.trim() : '';
          if (!wanted || wanted === event.clip) this.fire(c, 'on_sprite_animation_finished', tNow('logicRunnerMsgCore.animationFinished', { clip: event.clip }));
        }
        return;
      case 'hook':
        for (const c of this.rules) {
          if (c.nodeId !== event.nodeId || c.behavior.id !== event.behaviorId || c.rule.eventType !== event.trigger) continue;
          const wanted = event.params ? Object.entries(event.params) : [];
          if (wanted.some(([key, value]) => typeof c.rule.parameters?.[key] === 'string' && c.rule.parameters[key] !== value)) continue;
          this.fire(c, event.trigger, event.detail);
        }
        return;
      case 'variable': {
        const { change } = event;
        for (const c of this.rules) {
          if (c.rule.eventType !== 'on_variable_changed') continue;
          const p = c.rule.parameters;
          if ((p.scope === 'local' ? 'local' : 'global') !== change.scope || p.variable !== change.name) continue;
          if (change.scope === 'local') {
            const owner = this.scene.getInstance(typeof p.target === 'string' && p.target.trim() ? p.target.trim() : c.nodeId) ?? this.findByName(String(p.target));
            if (owner?.persistentNodeId !== change.nodeId) continue;
          }
          this.fire(c, 'on_variable_changed', `${change.name}: ${String(change.oldValue)} → ${String(change.newValue)}`);
        }
        return;
      }
    }
  }

  // ── execução de uma regra ─────────────────────────────────────────────────────────────────────

  /** Contexto da regra/Action em execução (vira `behaviorId`/`logicId` do diagnóstico). */
  private current: { behaviorId?: string; logicId?: string } = {};

  private fire(c: CompiledRule, trigger: string, detail?: string): void {
    const previous = this.current;
    this.current = { behaviorId: c.behavior.id };
    try {
      this.fireRule(c, trigger, detail);
    } finally {
      this.current = previous;
    }
  }

  private fireRule(c: CompiledRule, trigger: string, detail?: string): void {
    if (this.disposed || this.structuralPending()) return;
    const self = this.scene.getInstance(c.nodeId);
    if (!self || self.disposed || !c.behavior.enabled) return;
    const ruleLabel = `${self.name} › ${c.behavior.name}`;

    const world = this.conditionWorld(self);
    for (const condition of c.rule.conditions) {
      const verdict = evaluateConditionOrNull({ type: condition.type, parameters: condition.parameters }, world);
      if (verdict === null) {
        this.report(`cond:${c.rule.id}:${condition.id}`, 'warn', tNow('logicRunnerMsgCore.theConditionCouldNotBe', { ruleLabel, type: condition.type }), self, { code: 'condition.unresolved', logicId: condition.type });
        return;
      }
      if (!verdict) return;
    }

    this._executions++;
    const noisy = CONTINUOUS_TRIGGERS.has(trigger) && !this.verbose;
    if (!noisy) this.log('info', tNow('logicRunnerMsgCore.actionS', { ruleLabel, trigger, value: detail ? ` (${detail})` : '', count: c.rule.actions.length }), self);

    const ctx = this.actionContext(self);
    const generation = this.generation;
    for (let i = 0; i < c.rule.actions.length; i++) {
      if (this.disposed || self.disposed || generation !== this.generation || this.structuralPending()) {
        if (!noisy && i < c.rule.actions.length) this.log('info', tNow('logicRunnerMsgCore.chainOfAbortedNodeOr', { ruleLabel }), self);
        return;
      }
      const action = c.rule.actions[i];
      const stop = this.runAction(action, ctx, self, `${ruleLabel} #${i + 1}`, noisy);
      if (stop) {
        if (!noisy) this.log('info', tNow('logicRunnerMsgCore.chainOfEndedAfter', { ruleLabel, type: action.type }), self);
        return;
      }
    }
  }

  /** `true` = a cadeia deve parar. */
  private runAction(action: { id: string; type: string; parameters: Record<string, any> }, ctx: ActionRuntimeContext, self: RuntimeInstance, where: string, noisy: boolean): boolean {
    // o alvo da Action: `target` (convenção do catálogo) ou `targetNodeId` (AIS-41 v5.1.3, `emit_particles`) — a validação de tipo precisa olhar o ALVO, não o dono da regra
    const rawTarget = action.parameters?.target ?? action.parameters?.targetNodeId;
    const refParam = typeof rawTarget === 'string' ? rawTarget.trim() : '';
    const target = this.scene.getInstance(refParam) ?? (refParam ? this.findByName(refParam) : self);
    const validated = validateAction({ type: action.type, parameters: action.parameters }, { target: target ? this.toConditionNode(target) : undefined });
    if (!validated.ok) {
      const key = `act:${action.id}:${validated.code}`;
      const meta = { code: validated.code, logicId: action.type };
      if (validated.code === 'action.disabled') this.report(key, 'info', `${where}: ${validated.message}`, self, meta);
      else this.report(key, 'error', `${where}: ${validated.message}`, self, meta);
      return false;
    }
    const executor = ActionRuntime.get(action.type);
    if (!executor) {
      this.report(`noexec:${action.type}`, 'warn', tNow('logicRunnerMsgCore.theActionHasNoRuntime', { where, type: action.type }), self, { code: 'action.no_executor', logicId: action.type });
      return false;
    }
    const previousCurrent = this.current;
    this.current = { ...previousCurrent, logicId: action.type };
    const meta = { code: 'action.failed', logicId: action.type, behaviorId: previousCurrent.behaviorId };
    try {
      const outcome = executor(validated.params, ctx);
      if (outcome && typeof (outcome as Promise<unknown>).then === 'function') {
        // fire-and-continue: a próxima Action não espera; falha tardia vira log, nunca derruba o Play
        (outcome as Promise<unknown>).catch((error) => this.log('error', `${where}: ${error instanceof Error ? error.message : String(error)}`, self, true, meta));
        return false;
      }
      if (outcome === 'stop') return true;
      if (!noisy && this.verbose) this.log('info', `  ✓ ${action.type}`, self);
    } catch (error) {
      // erro de Action é logado e não derruba o Play Mode nem as outras regras
      this.log('error', tNow('logicRunnerMsgCore.errorIn', { where, type: action.type, value: error instanceof Error ? error.message : String(error) }), self, true, meta);
    } finally {
      this.current = previousCurrent;
    }
    return false;
  }

  /**
   * AIS-57: executa o executor de uma Action nativa com `self` = a instância dada (métodos nativos de sinal: `show`, `hide`,
   * `queue_free`…). Mesma política das regras: erro explícito no log, nunca silêncio.
   */
  public invokeAction(actionId: string, params: Record<string, unknown>, self: RuntimeInstance): void {
    if (this.disposed) return;
    const executor = ActionRuntime.get(actionId);
    if (!executor) throw new Error(`a Action "${actionId}" não tem executor.`);
    executor(params, this.actionContext(self));
  }

  /** Escrita de pose feita pela LÓGICA: grava no objeto vivo e, num corpo dinâmico, empurra a pose para a física. (Rotação/velocidade contínuas têm caminho próprio.) */
  private commitTransform(instance: RuntimeInstance): void {
    this.scene.applyInstanceTransform(instance);
    this.onPoseWritten(instance);
  }

  /** AIS-78c: a EngineApi.ui — o HUD é redesenhado, a cena 3D não. */
  markUiDirty(): void {
    this._uiRevision++;
    this.host.onUiChanged?.();
  }

  /** AIS-78c: a EngineApi.text — `$variavel$`/`$no.atributo$` pelos valores vivos (o nó dono resolve `self`). */
  interpolateText(text: string, selfNodeId: string | null): string {
    return this.variables ? this.variables.interpolate(text, { selfNodeId: selfNodeId ?? undefined, resolveNodeId: (n) => this.scene.getInstance(n)?.persistentNodeId ?? this.findByName(n)?.persistentNodeId }) : text;
  }

  /** AIS-78c: a EngineApi.motion.spin — rotação contínua; `0` a para (e, em corpo dinâmico, zera a velocidade angular). */
  setContinuousRotation(instance: RuntimeInstance, axis: 'x' | 'y' | 'z', dps: number): void {
    if (dps === 0) {
      this.rotations.delete(instance.id);
      stopSpinningBody(this.physicsOf(), instance.persistentNodeId); // corpo dinâmico: a rotação só para se a velocidade angular for zerada
    } else this.rotations.set(instance.id, { instance, axis, dps });
  }

  /** AIS-78c: a EngineApi.motion.velocity — velocidade contínua de um nó sem corpo dinâmico; vetor zero a para. */
  setContinuousVelocity(instance: RuntimeInstance, velocity: { x: number; y: number; z: number }, space: 'world' | 'local'): void {
    if (velocity.x === 0 && velocity.y === 0 && velocity.z === 0) this.velocities.delete(instance.id);
    else this.velocities.set(instance.id, { instance, v: velocity, space });
  }

  /** Um `TweenControl` por `Tweener` (o da cena viva); troca de cena/restart cria um novo `Tweener` e, com ele, um novo controle. */
  private tweensFor(): TweenControl | null {
    const tweener = this.tweenerOf();
    if (!tweener) return null;
    if (this.tweenControl?.tweener !== tweener) {
      this.tweenControl = {
        tweener,
        control: createTweenControl(tweener, {
          applyTransform: (instance) => this.commitTransform(instance),
          markUiDirty: () => this.markUiDirty(),
        }),
      };
    }
    return this.tweenControl.control;
  }

  /**
   * AIS-78c (decisão 32): a interseção com o Behavior (nó, variáveis, `sceneTime`, transform, sinal, física, log) sai da `EngineApi` pelo
   * `deriveActionContext`; desde a 1.3 não há mais extras na Action (UI, texto e movimento contínuo também saem da EngineApi).
   */
  private actionContext(self: RuntimeInstance): ActionRuntimeContext {
    return deriveActionContext(this.engine, { self, owner: null }, {});
  }

  private finishFrame(): void {
    if (this.disposed) return;
    // pedidos estruturais só depois de a cadeia e o quadro terminarem (a cena nunca é destruída no meio de uma cadeia)
    if (this.pendingQuit) {
      this.pendingQuit = false;
      this.pendingRestart = false;
      this.pendingChange = null;
      this.log('info', tNow('logicRunnerMsgCore.quitGameRequestedEndingPlay'));
      this.host.onQuitGame?.();
    } else if (this.pendingChange !== null) {
      const path = this.pendingChange;
      this.pendingChange = null;
      this.pendingRestart = false;
      this.log('info', tNow('logicRunnerMsgCore.changeSceneRequested', { path }));
      this.host.onChangeScene?.(path);
    } else if (this.pendingRestart) {
      this.pendingRestart = false;
      this.log('info', tNow('logicRunnerMsgCore.restartSceneRequestedRestartingThe'));
      this.host.onRestartScene?.();
    }
  }

  // ── consulta ──────────────────────────────────────────────────────────────────────────────────

  private conditionWorld(self: RuntimeInstance): ConditionWorld {
    const lookup = (ref: string) => this.scene.getInstance(ref) ?? this.findByName(ref);
    return {
      selfNodeId: self.persistentNodeId,
      getNode: (ref) => {
        const found = lookup(ref);
        return found ? this.toConditionNode(found) : undefined;
      },
      getWorldPosition: (ref) => {
        const found = lookup(ref);
        if (!found?.object) return undefined;
        found.object.updateWorldMatrix(true, false);
        const v = found.object.getWorldPosition(new THREE.Vector3());
        return { x: v.x, y: v.y, z: v.z };
      },
      input: this.input,
      sceneTime: this.time,
      random: this.random,
      getVariable: this.variables ? (scope, name, nodeId) => this.variables!.getVariable(scope, name, nodeId) : undefined,
    };
  }

  private toConditionNode(i: RuntimeInstance): ConditionNode {
    return { id: i.persistentNodeId, name: i.name, type: i.type, visible: i.visible, properties: i.properties };
  }

  private findByName(name: string): RuntimeInstance | undefined {
    return this.scene.getAllInstances().find((i) => i.name === name);
  }

  private rulesOf(nodeId: string, type: string): CompiledRule[] {
    return this.rules.filter((c) => c.nodeId === nodeId && c.rule.eventType === type);
  }

  /** Sobe pela hierarquia viva até o primeiro nó (ele mesmo incluso) que tem regra do tipo. */
  private bubbleTo(nodeId: string, type: string): string | null {
    for (let cursor = this.scene.getInstance(nodeId); cursor; cursor = cursor.parent ?? undefined) {
      if (this.rulesOf(cursor.persistentNodeId, type).length > 0) return cursor.persistentNodeId;
    }
    return null;
  }

  private isSelfOrDescendant(nodeId: string, ownerId: string): boolean {
    for (let cursor = this.scene.getInstance(nodeId); cursor; cursor = cursor.parent ?? undefined) if (cursor.persistentNodeId === ownerId) return true;
    return false;
  }

  // ── log ───────────────────────────────────────────────────────────────────────────────────────

  private log(level: LogicLogLevel, message: string, node?: RuntimeInstance | string, toOutput = level !== 'info', meta?: LogicLogMeta): void {
    const nodeName = typeof node === 'string' ? node : node?.name;
    const nodeId = typeof node === 'string' ? undefined : node?.persistentNodeId;
    const instanceId = typeof node === 'string' ? undefined : node?.id;
    this.host.onLog?.({ time: this.time, level, message, nodeName, nodeId, instanceId, toOutput, ...this.current, ...meta });
  }

  /** Aviso de configuração: uma vez por chave (não inunda o log a cada quadro). */
  private report(key: string, level: LogicLogLevel, message: string, node?: RuntimeInstance | string, meta?: LogicLogMeta): void {
    if (this.reported.has(key)) return;
    this.reported.add(key);
    this.log(level, message, node, level !== 'info', meta);
  }

  private readonly lastImpact = new Map<string, number>();
  /** `minimalForce` (N) e `maxEveryMs` (debounce, tempo de JOGO) de um On Collision Enter; sem parâmetros dispara sempre. */
  private impactAllowed(c: CompiledRule, force: number): boolean {
    const min = Number(c.rule.parameters.minimalForce) || 0;
    if (force < min) return false;
    const every = (Number(c.rule.parameters.maxEveryMs) || 0) / 1000;
    if (every > 0) {
      const last = this.lastImpact.get(c.rule.id);
      if (last !== undefined && this.time - last < every) return false;
      this.lastImpact.set(c.rule.id, this.time);
    }
    return true;
  }

  private structuralPending(): boolean {
    return this.pendingQuit || this.pendingRestart || this.pendingChange !== null;
  }

  /**
   * AIS-44b — aborta TODAS as cadeias e timers desta cena (primeiro passo da troca/restart de cena): o que estiver em andamento
   * para na próxima Action, e callbacks agendados deixam de existir. O runner segue utilizável até o `dispose`.
   */
  public abortChains(): void {
    this.generation++;
    this.scheduled = [];
    this.queue = [];
    this.rotations.clear();
    this.velocities.clear();
  }

  /** Este (nó × Behavior) tem regras neste runner? */
  public hasBehavior(nodeId: string, behaviorId: string): boolean {
    return this.rules.some((c) => c.nodeId === nodeId && c.behavior.id === behaviorId);
  }

  /** "Restart Behavior": zera só os acumuladores das regras deste Behavior (a cena e os demais Behaviors não mudam). */
  public resetBehavior(nodeId: string, behaviorId: string): void {
    for (const c of this.rules) {
      if (c.nodeId === nodeId && c.behavior.id === behaviorId) {
        c.elapsed = 0;
        c.done = false;
      }
    }
    this.behaviorStates.reset(nodeId, behaviorId);
  }

  /** Fim da sessão: nada de timer, assinatura ou fila sobrevive (idempotente). */
  public dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    for (const d of this.disposers.splice(0)) d();
    this.queue = [];
    this.scheduled = [];
    this.rotations.clear();
    this.velocities.clear();
    this.lastImpact.clear();
    this.rules.length = 0;
    this.behaviorStates.dispose();
  }
}
