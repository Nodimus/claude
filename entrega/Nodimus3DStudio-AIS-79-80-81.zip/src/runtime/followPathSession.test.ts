import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { ensureRapier } from '../core/physics/rapierInit';
import { LogicRegistry } from '../logic/registry';
import { moveNodeToward, type MotionContext } from './motion/moveToward';
import { RuntimeSession } from './RuntimeSession';

/** AIS-72 — `moveNodeToward` por tipo de corpo e o Behavior `follow_a_path` no Play (Rapier real, diagnósticos reais). */

beforeAll(async () => {
  await ensureRapier();
});

const P = (x: number, y = 0, z = 0) => ({ x, y, z });
const node = (id: string, type: string, at: [number, number, number], props: Record<string, unknown> = {}, over: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type, parentId: null, childrenIds: [], visible: true, locked: false, properties: { position: { x: at[0], y: at[1], z: at[2] }, ...props }, ...over }) as unknown as GameNode;

const input = { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never;

const follow = (props: Record<string, unknown>): BehaviorInstance => {
  const b = (LogicRegistry.getBehavior('follow_a_path') as any).create({ targetNodeId: 'mover' }) as BehaviorInstance;
  b.properties = { ...b.properties, ...props };
  return b;
};
const PATH = (nodes = [P(0), P(10)], extra: Record<string, unknown> = {}) => node('rota', 'Path', [0, 0, 0], { nodes, closed: false, tightness: 0.5, ...extra });
const MOVER = (props: Record<string, unknown> = {}, behavior?: BehaviorInstance, at: [number, number, number] = [0, 0, 0]) =>
  node('mover', 'MeshInstance', at, { meshType: 'CubeMesh', ...props }, behavior ? ({ behaviors: [behavior] } as never) : {});
const FLOOR = node('floor', 'MeshInstance', [0, -0.5, 0], { meshType: 'CubeMesh', scale: { x: 60, y: 1, z: 60 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } });

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  return { ...scene, nodes } as unknown as SceneData;
}

function play(scene: SceneData) {
  const diagnostics = new DiagnosticService();
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input, diagnostics });
  session.start();
  return { session, diagnostics, codes: () => diagnostics.list({ ephemeral: true }).map((d) => d.code) };
}
const run = (s: RuntimeSession, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) s.step(1 / 60);
};
const xOf = (s: RuntimeSession, id = 'mover') => s.getSimulatedTransform(id)!.position[0];
const posOf = (s: RuntimeSession, id = 'mover') => s.getSimulatedTransform(id)!.position;

describe('moveNodeToward por tipo de corpo (AIS-72-C14)', () => {
  const motion = (s: RuntimeSession): MotionContext => ({ physics: s.physics, getNode: (id) => s.scene.getInstance(id), applyTransform: (i) => s.scene.applyInstanceTransform(i) });

  it('sem corpo: anda speed·dt por chamada e chega exatamente ao alvo', () => {
    const { session } = play(sceneWith(MOVER()));
    const ctx = motion(session);
    const first = moveNodeToward(ctx, 'mover', P(10), 6, 0.5); // passo de 3
    expect(first).toMatchObject({ status: 'moving', moved: 3, remaining: 7 });
    expect(session.scene.getInstance('mover')!.transform.position[0]).toBeCloseTo(3);
    const last = moveNodeToward(ctx, 'mover', P(10), 100, 1); // passo maior que o resto: não ultrapassa
    expect(last.status).toBe('arrived');
    expect(session.scene.getInstance('mover')!.transform.position[0]).toBeCloseTo(10);
    expect(moveNodeToward(ctx, 'mover', P(10), 5, 1).status).toBe('arrived');
    session.dispose();
  });

  it('kinematic: a pose do runtime é a autoridade e a ponte física segue', () => {
    const { session } = play(sceneWith(MOVER({ physics: { enabled: true, bodyMode: 'kinematic', shape: 'auto' } })));
    const ctx = motion(session);
    for (let i = 0; i < 60; i++) {
      moveNodeToward(ctx, 'mover', P(6), 6, 1 / 60);
      session.step(1 / 60);
    }
    expect(xOf(session)).toBeCloseTo(6, 1);
    expect(session.physics!.getPose('mover')!.position.x).toBeCloseTo(6, 1);
    session.dispose();
  });

  it('character: o deslocamento passa pelo controlador da PhysicsBridge (não atravessa o piso)', () => {
    const { session } = play(sceneWith(FLOOR, MOVER({ physics: { enabled: true, bodyMode: 'character', shape: 'capsule' } }, undefined, [0, 1, 0])));
    const ctx = motion(session);
    for (let i = 0; i < 90; i++) {
      moveNodeToward(ctx, 'mover', P(6, 1, 0), 4, 1 / 60);
      session.step(1 / 60);
    }
    expect(xOf(session)).toBeGreaterThan(4);
    expect(posOf(session)[1]).toBeGreaterThan(0.2); // apoiado no piso, não caiu através dele
    session.dispose();
  });

  it('dynamic e static: incompatíveis, nada é movido e o resultado traz o diagnóstico', () => {
    const dyn = play(sceneWith(FLOOR, MOVER({ physics: { enabled: true, bodyMode: 'dynamic', shape: 'auto' } }, undefined, [0, 2, 0])));
    const result = moveNodeToward(motion(dyn.session), 'mover', P(10, 2, 0), 5, 1);
    expect(result).toMatchObject({ status: 'incompatible', moved: 0, code: 'motion.dynamic_body' });
    expect(result.message).toMatch(/dinâmico/);
    expect(dyn.session.scene.getInstance('mover')!.transform.position[0]).toBe(0);
    dyn.session.dispose();
    const stat = play(sceneWith(MOVER({ physics: { enabled: true, bodyMode: 'static', shape: 'auto' } })));
    expect(moveNodeToward(motion(stat.session), 'mover', P(10), 5, 1)).toMatchObject({ status: 'incompatible', code: 'motion.static_body' });
    stat.session.dispose();
  });

  it('corpo desligado (enabled: false) conta como sem corpo; nó inexistente é incompatível', () => {
    const { session } = play(sceneWith(MOVER({ physics: { enabled: false, bodyMode: 'dynamic', shape: 'auto' } })));
    const ctx = motion(session);
    expect(moveNodeToward(ctx, 'mover', P(2), 10, 1).status).toBe('arrived');
    expect(moveNodeToward(ctx, 'nao-existe', P(2), 10, 1)).toMatchObject({ status: 'incompatible', code: 'motion.no_object' });
    session.dispose();
  });
});

describe('Behavior follow_a_path no Play (AIS-72-C07)', () => {
  it('once: percorre a spline na velocidade configurada e para no último ponto', () => {
    const { session } = play(sceneWith(PATH(), MOVER({}, follow({ pathId: 'rota', speed: 5, loopMode: 'once' }))));
    run(session, 1);
    expect(xOf(session)).toBeGreaterThan(4.5);
    expect(xOf(session)).toBeLessThan(5.6);
    run(session, 3);
    expect(xOf(session)).toBeCloseTo(10, 1);
    run(session, 1);
    expect(xOf(session)).toBeCloseTo(10, 1); // parou
    session.dispose();
  });

  it('o nó começa longe do caminho: aproxima do ponto inicial e só então percorre', () => {
    const { session } = play(sceneWith(PATH(), MOVER({}, follow({ pathId: 'rota', speed: 5, loopMode: 'once' }), [0, 0, -10])));
    run(session, 1);
    expect(posOf(session)[2]).toBeGreaterThan(-6); // vindo do z = -10
    expect(xOf(session)).toBeLessThan(0.5); // ainda não saiu do início
    run(session, 5);
    expect(xOf(session)).toBeCloseTo(10, 1);
    expect(posOf(session)[2]).toBeCloseTo(0, 1);
    session.dispose();
  });

  it('loop: ao chegar no fim volta ao início e recomeça', () => {
    const { session } = play(sceneWith(PATH(), MOVER({}, follow({ pathId: 'rota', speed: 10, loopMode: 'loop' }))));
    let max = 0;
    let minAfterMax = Infinity;
    let secondRise = 0;
    for (let i = 0; i < 60 * 6; i++) {
      session.step(1 / 60);
      const x = xOf(session);
      if (x > max) max = x;
      if (max > 9.5) {
        minAfterMax = Math.min(minAfterMax, x);
        if (minAfterMax < 1) secondRise = Math.max(secondRise, x);
      }
    }
    expect(max).toBeGreaterThan(9.5);
    expect(minAfterMax).toBeLessThan(1); // voltou ao início
    expect(secondRise).toBeGreaterThan(5); // e recomeçou a percorrer
    session.dispose();
  });

  it('pingpong: inverte a direção nas extremidades', () => {
    const { session } = play(sceneWith(PATH(), MOVER({}, follow({ pathId: 'rota', speed: 5, loopMode: 'pingpong' }))));
    run(session, 1.5);
    const going = xOf(session);
    expect(going).toBeCloseTo(7.5, 0); // t = 1,5 subindo
    run(session, 1.5); // t = 3: passou do fim (t = 2) e já voltou
    expect(xOf(session)).toBeLessThan(going);
    expect(xOf(session)).toBeCloseTo(5, 0);
    run(session, 1); // t = 4: de volta ao início
    expect(xOf(session)).toBeCloseTo(0, 0);
    run(session, 0.5); // e sobe de novo
    expect(xOf(session)).toBeGreaterThan(1);
    session.dispose();
  });

  it('closed + loop percorre a spline fechada sem salto (nunca se afasta mais que a volta)', () => {
    const square = [P(0), P(6), P(6, 0, 6), P(0, 0, 6)];
    const { session } = play(sceneWith(PATH(square, { closed: true }), MOVER({}, follow({ pathId: 'rota', speed: 6, loopMode: 'loop' }))));
    let last = posOf(session);
    let maxJump = 0;
    for (let i = 0; i < 60 * 8; i++) {
      session.step(1 / 60);
      const p = posOf(session);
      maxJump = Math.max(maxJump, Math.hypot(p[0] - last[0], p[1] - last[1], p[2] - last[2]));
      last = p;
    }
    expect(maxJump).toBeLessThan(6 / 60 + 0.05);
    session.dispose();
  });

  it('o transform do Path (posição) vale: waypoints são locais ao nó Path', () => {
    const shifted = node('rota', 'Path', [0, 0, 20], { nodes: [P(0), P(10)], closed: false, tightness: 0.5 });
    const { session } = play(sceneWith(shifted, MOVER({}, follow({ pathId: 'rota', speed: 10, loopMode: 'once' }), [0, 0, 20])));
    run(session, 2);
    expect(xOf(session)).toBeCloseTo(10, 1);
    expect(posOf(session)[2]).toBeCloseTo(20, 1);
    session.dispose();
  });

  it('character: segue o caminho sobre o piso pelo controlador', () => {
    const { session } = play(sceneWith(FLOOR, PATH([P(0, 1), P(8, 1)]), MOVER({ physics: { enabled: true, bodyMode: 'character', shape: 'capsule' } }, follow({ pathId: 'rota', speed: 4, loopMode: 'once' }), [0, 1, 0])));
    run(session, 3);
    expect(xOf(session)).toBeGreaterThan(7);
    session.dispose();
  });

  it('corpo dynamic: diagnóstico explícito e o corpo não é conduzido', () => {
    const { session, codes } = play(sceneWith(FLOOR, PATH(), MOVER({ physics: { enabled: true, bodyMode: 'dynamic', shape: 'auto' } }, follow({ pathId: 'rota', speed: 5, loopMode: 'once' }), [0, 1, 0])));
    run(session, 1);
    expect(codes()).toContain('motion.dynamic_body');
    expect(Math.abs(xOf(session))).toBeLessThan(0.5);
    session.dispose();
  });
});

describe('referência inválida (AIS-72-C09)', () => {
  const cases: [string, GameNode[], Record<string, unknown>, string][] = [
    ['pathId vazio', [PATH()], { pathId: '' }, 'follow_a_path.path_missing'],
    ['nó ausente', [PATH()], { pathId: 'fantasma' }, 'follow_a_path.path_missing'],
    ['tipo errado', [PATH(), node('caixa', 'MeshInstance', [0, 0, 0], { meshType: 'CubeMesh' })], { pathId: 'caixa' }, 'follow_a_path.not_a_path'],
    ['Path com 1 waypoint', [PATH([P(0)])], { pathId: 'rota' }, 'follow_a_path.path_too_short'],
    ['Path sem waypoints', [PATH([])], { pathId: 'rota' }, 'follow_a_path.path_too_short'],
    ['Path com todos os waypoints no mesmo ponto', [PATH([P(3), P(3), P(3)])], { pathId: 'rota' }, 'follow_a_path.path_too_short'],
    ['velocidade zero', [PATH()], { pathId: 'rota', speed: 0 }, 'follow_a_path.invalid_speed'],
  ];

  for (const [label, nodes, props, code] of cases) {
    it(`${label}: emite ${code} uma vez e o nó não se move`, () => {
      const { session, diagnostics, codes } = play(sceneWith(...nodes, MOVER({}, follow({ speed: 5, loopMode: 'loop', ...props }))));
      run(session, 1);
      expect(codes()).toContain(code);
      expect(diagnostics.list({ ephemeral: true }).filter((d) => d.code === code)).toHaveLength(1); // sem inundar a cada quadro
      expect(diagnostics.list({ ephemeral: true }).find((d) => d.code === code)!.severity).toBe('error');
      expect(xOf(session)).toBe(0);
      session.dispose();
    });
  }
});

describe('Stop e Restart (AIS-72-C08)', () => {
  it('o Play nunca altera os waypoints autorais; uma nova sessão recomeça do início', () => {
    const scene = sceneWith(PATH([P(0), P(4, 0, 4), P(10)]), MOVER({}, follow({ pathId: 'rota', speed: 5, loopMode: 'loop' })));
    const before = JSON.stringify(scene.nodes.rota.properties);
    const first = play(scene);
    run(first.session, 2);
    expect(xOf(first.session)).toBeGreaterThan(1);
    expect(JSON.stringify(first.session.scene.getInstance('rota')!.properties)).toBe(before); // nem a instância viva muda
    first.session.dispose();
    expect(JSON.stringify(scene.nodes.rota.properties)).toBe(before);
    const second = play(scene);
    expect(xOf(second.session)).toBeCloseTo(0, 1); // progresso é da sessão, não do authoring
    second.session.dispose();
  });
});
