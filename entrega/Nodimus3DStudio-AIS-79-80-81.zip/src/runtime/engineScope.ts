import type { BehaviorInstance } from '../types/visualLogic';
import type { ActionRuntimeContext, BehaviorRuntimeContext } from '../logic/types';
import { buildEngineApi, type EngineApi, type EngineHost } from './engineApi';
import type { RuntimeInstance } from './RuntimeScene';
import type { SubscriptionOwner } from './subscriptions';

/**
 * AIS-78c (decisão 32) — Scoped Runtime Contexts. `ActionRuntimeContext` e `BehaviorRuntimeContext` são PERMANENTES (a ergonomia dos executores
 * não muda), mas SEMPRE derivam de `EngineApi` + `InvocationScope`: a interseção dos dois contextos (nó, variáveis, sinais, input, física, log,
 * `sceneTime`, transform) sai da mesma fonte; o resto são EXTRAS declarados (`*_CONTEXT_SOURCE`). Eliminar caminhos paralelos e imports indevidos
 * é o objetivo; eliminar os contextos não é.
 *
 * Os manifestos `ACTION_CONTEXT_SOURCE` e `BEHAVIOR_CONTEXT_SOURCE` são `Record<keyof Contexto, …>`: membro NOVO num contexto é erro de tipo até
 * ser classificado, e `src/logic/engineBoundary.test.ts` congela a lista dos `extra` (membro novo fora da EngineApi precisa de decisão explícita).
 */

/** Quem está invocando: o nó dono e, num Behavior, a instância e o estado de trabalho. `owner` é o dono das assinaturas. */
export interface InvocationScope {
  /** Nó dono (a instância viva): `self` da Action / `node` do Behavior. */
  self: RuntimeInstance;
  behavior?: BehaviorInstance;
  state?: { properties: Record<string, any>; memory: Record<string, unknown> };
  initialTransform?: { position: [number, number, number]; rotation: [number, number, number]; scale: [number, number, number] };
  /** Dono das assinaturas feitas nesta invocação (Behavior: `behavior`; Action: nenhuma). */
  owner: SubscriptionOwner | null;
}

/** O par confiável (só dentro do runtime): o mundo injetado + a fábrica de `EngineApi` por dono. Nunca é exportado a scripts. */
export interface EngineCore {
  readonly host: EngineHost;
  apiFor(owner: SubscriptionOwner | null, selfNodeId?: string | null, behaviorId?: string | null): EngineApi;
}

export function createEngineCore(host: EngineHost): EngineCore {
  return { host, apiFor: (owner, selfNodeId = null, behaviorId = null) => buildEngineApi(host, owner, selfNodeId, behaviorId) };
}

export type ContextSource = 'engine' | 'scope' | 'extra';

/** De onde sai cada membro do `ActionRuntimeContext`. */
export const ACTION_CONTEXT_SOURCE = {
  engine: 'engine',
  self: 'scope',
  resolve: 'engine',
  variables: 'engine',
  sceneTime: 'engine',
  applyTransform: 'engine',
  log: 'engine',
  emitSignal: 'engine',
  physics: 'engine',
  markUiDirty: 'engine',
  interpolate: 'engine',
  setContinuousRotation: 'engine',
  setContinuousVelocity: 'engine',
} as const satisfies Record<keyof ActionRuntimeContext, ContextSource>;

/** De onde sai cada membro do `BehaviorRuntimeContext`. */
export const BEHAVIOR_CONTEXT_SOURCE = {
  engine: 'engine',
  node: 'scope',
  behavior: 'scope',
  state: 'scope',
  initialTransform: 'scope',
  input: 'engine',
  variables: 'engine',
  sceneTime: 'engine',
  applyTransform: 'engine',
  log: 'engine',
  physics: 'engine',
  onPhysicsEvent: 'engine',
  onSignal: 'engine',
  getNode: 'engine',
  onFrame: 'engine',
  onInput: 'engine',
  setGameCamera: 'engine',
  setLocomotion: 'engine',
} as const satisfies Record<keyof BehaviorRuntimeContext, ContextSource>;

/**
 * LACUNAS conhecidas (decisão 32, §7) — registradas, NÃO corrigidas neste prompt. São capacidades que existem num contexto e faltam no outro; fechá-las
 * é migração futura, por dono, sem prazo:
 */
export const KNOWN_CONTEXT_GAPS = {
  /** FECHADA (AIS-78c, decisão 32): Behavior e Action têm `ctx.engine` — áudio, partículas, animação, sprites, tweens, `destroy` e agenda são os mesmos. */
  behaviorLacks: [] as string[],
  /**
   * A Action não tem `onFrame` — POR DESIGN, não é lacuna a fechar: no Godot, `_process` é do NÓ (o Behavior), e um passo pontual agenda por
   * `Timer`/`await` (aqui, `engine.after`). `view` e `input` não faltam mais: são `engine.camera.view()` (como `Viewport.get_camera_3d()`) e
   * `engine.input` (o singleton `Input`, global em Godot).
   */
  actionLacks: ['onFrame'],
} as const;

type ActionKeys = { [K in keyof ActionRuntimeContext]-?: (typeof ACTION_CONTEXT_SOURCE)[K] extends 'extra' ? K : never }[keyof ActionRuntimeContext];
type BehaviorKeys = { [K in keyof BehaviorRuntimeContext]-?: (typeof BEHAVIOR_CONTEXT_SOURCE)[K] extends 'extra' ? K : never }[keyof BehaviorRuntimeContext];

/** Os membros que NÃO vêm da EngineApi (o chamador — runner/lifecycle — os fornece). */
export type ActionExtras = Pick<ActionRuntimeContext, ActionKeys>;
export type BehaviorExtras = Pick<BehaviorRuntimeContext, BehaviorKeys>;

/**
 * Contexto de uma Action: a interseção vem da `EngineApi`/host; `extras` completa o resto. Mesma assinatura e mesmo comportamento de antes
 * (`variables` continua o `VariableManager`, `physics` a `PhysicsBridge` lida na criação).
 */
export function deriveActionContext(core: EngineCore, scope: InvocationScope, extras: ActionExtras = {} as ActionExtras): ActionRuntimeContext {
  const api = core.apiFor(scope.owner, scope.self.persistentNodeId);
  const host = core.host;
  const self = scope.self;
  const derived: Omit<ActionRuntimeContext, ActionKeys> = {
    engine: api,
    self,
    resolve: (ref) => (ref ? (host.instanceById(ref) ?? host.instanceByName(ref)) : self),
    variables: host.variables(),
    sceneTime: api.time(),
    applyTransform: (instance) => host.commitTransform(instance),
    log: (level, message, options) => host.log(level, message, self, { toOutput: options?.toOutput, code: options?.code }),
    emitSignal: (name) => api.signals.emit(name),
    physics: api.physics(),
    markUiDirty: () => api.ui.markDirty(),
    interpolate: (text) => api.text.interpolate(text),
    setContinuousRotation: (instance, axis, dps) => void api.motion.spin(instance.persistentNodeId, axis, dps),
    setContinuousVelocity: (instance, velocity, space) => void api.motion.velocity(instance.persistentNodeId, velocity, space),
  };
  // os extras entram por DESCRITOR (getters tardios preservados), nunca por espalhamento que os avaliaria agora
  return Object.defineProperties(derived, Object.getOwnPropertyDescriptors(extras)) as ActionRuntimeContext;
}

/** Contexto de um Behavior: a interseção vem da `EngineApi`/host; `extras` completa o resto. */
export function deriveBehaviorContext(core: EngineCore, scope: InvocationScope, extras: BehaviorExtras = {} as BehaviorExtras): BehaviorRuntimeContext {
  const api = core.apiFor(scope.owner, scope.self.persistentNodeId, scope.behavior?.id ?? null);
  const host = core.host;
  const node = scope.self;
  const behavior = scope.behavior!;
  const derived: Omit<BehaviorRuntimeContext, BehaviorKeys> = {
    engine: api,
    node,
    behavior,
    state: scope.state!,
    initialTransform: scope.initialTransform!,
    input: host.input(),
    variables: host.variables(),
    sceneTime: api.time(),
    applyTransform: (instance) => host.commitTransform(instance),
    physics: api.physics(),
    onPhysicsEvent: (name, cb) => api.onPhysicsEvent(name, cb),
    onSignal: (name, cb) => api.signals.connect(name, (signal) => cb(signal)),
    onFrame: (cb) => api.frame.onUpdate(cb),
    onInput: (cb) => api.frame.onInput(cb),
    setGameCamera: (pose) => void api.camera.publish(pose),
    setLocomotion: (state) => void api.locomotion.set(state),
    getNode: (id) => host.instanceById(id),
    log: (level, message, options) => host.log(level, `${behavior.name}: ${message}`, node, { code: options?.code, behaviorId: behavior.id, logicId: behavior.behaviorType }),
  };
  // os extras entram por DESCRITOR: getters tardios (`view`, `animation`, `weapons`, `ai`) continuam lidos só quando o Behavior os usa
  return Object.defineProperties(derived, Object.getOwnPropertyDescriptors(extras)) as unknown as BehaviorRuntimeContext;
}
