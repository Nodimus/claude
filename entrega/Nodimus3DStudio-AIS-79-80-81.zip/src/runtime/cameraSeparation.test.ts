import { beforeAll, describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { ensureRapier } from '../core/physics/rapierInit';
import { InputManager } from './input/InputManager';
import { RuntimeSession } from './RuntimeSession';
import type { LogicLogEntry } from './logicRunner';
import { rotateByQuat } from './controllers/controllerMath';

/**
 * AIS-47c (decisão 28) — movimento e câmera SEPARADOS, dentro da `RuntimeSession` com a física real e o `InputManager` real:
 * Behaviors de movimento no ator, Behaviors de câmera no nó `Camera`, `ctx.view` como única leitura da câmera.
 */

beforeAll(async () => {
  await ensureRapier();
});

let seq = 0;
const beh = (behaviorType: string, properties: Record<string, any> = {}): BehaviorInstance => ({ id: `b${++seq}`, name: behaviorType, behaviorType, enabled: true, properties, rules: [] });

const meshNode = (id: string, at: [number, number, number], extra: Record<string, any> = {}, nodeExtra: Record<string, any> = {}): GameNode =>
  ({ id, name: id, type: 'MeshInstance', parentId: null, childrenIds: [], visible: true, locked: false, properties: { meshType: 'CubeMesh', position: { x: at[0], y: at[1], z: at[2] }, ...extra }, ...nodeExtra }) as unknown as GameNode;

const cameraNode = (id: string, at: [number, number, number], behaviors: BehaviorInstance[] = [], props: Record<string, any> = {}): GameNode =>
  ({ id, name: id, type: 'Camera', parentId: null, childrenIds: [], visible: true, locked: false, properties: { position: { x: at[0], y: at[1], z: at[2] }, rotation: { x: 0, y: 0, z: 0 }, active: true, ...props }, behaviors }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  return { ...scene, nodes };
}

const FLOOR = meshNode('floor', [0, -0.5, 0], { scale: { x: 80, y: 1, z: 80 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } });
const CHARACTER = { enabled: true, bodyMode: 'character', shape: 'capsule' };
const hero = (...behaviors: BehaviorInstance[]) => meshNode('hero', [0, 2, 0], { scale: { x: 1, y: 1.8, z: 1 }, physics: CHARACTER }, { behaviors });

function open(scene: SceneData) {
  const input = new InputManager();
  input.setEnabled(true);
  const logs: LogicLogEntry[] = [];
  const reports: { code: string; severity: string; nodeId?: string }[] = [];
  const diagnostics = { report: (d: any) => void reports.push({ code: d.code, severity: d.severity, nodeId: d.nodeId }), clearSession: () => 0 };
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input, onLog: (e) => logs.push(e), diagnostics });
  session.start();
  const frame = (n = 1) => {
    for (let i = 0; i < n; i++) {
      session.step(1 / 60);
      input.endFrame();
    }
  };
  const pos = (id = 'hero') => session.getSimulatedTransform(id)!.position;
  const inst = (id: string) => session.currentScene!.getInstance(id)!;
  return { session, input, logs, reports, frame, pos, inst };
}

const walk = (input: InputManager, frame: (n?: number) => void, key = 'KeyW', n = 60) => {
  input.handleKey(key, true);
  frame(n);
  input.handleKey(key, false);
};

describe('First Person: Movement (ator) + Camera (nó Camera)', () => {
  const build = () => {
    const cam = beh('camera_first_person', { targetNodeId: 'hero', eyeHeight: 1.6, mouseSensitivity: 0.15 });
    const h = hero(beh('first_person_movement', { moveSpeed: 5 }));
    return { ...open(sceneWith(FLOOR, h, cameraNode('cam', [0, 5, 5], [cam]))), camBehaviorId: cam.id };
  };

  it('a câmera fica nos olhos do alvo e é a câmera de jogo (kind camera); viewBasis vem dela', () => {
    const { session, frame, pos } = build();
    frame(120);
    const g = session.gameCamera!;
    expect(g.kind).toBe('camera');
    expect(g.nodeId).toBe('cam');
    expect(g.pointerLock).toBe(true);
    expect(g.position.y).toBeCloseTo(pos()[1] + 1.6, 1);
    expect(g.position.x).toBeCloseTo(pos()[0], 1);
    expect(session.viewBasis).toEqual({ nodeId: 'cam', yaw: 0, pitch: 0 });
  });

  it('WASD anda relativo ao olhar da câmera: depois de virar 90° à esquerda vai para -X, e o corpo acompanha o olhar', () => {
    const { session, input, frame, pos, inst } = build();
    frame(120);
    const z0 = pos()[2];
    walk(input, frame);
    expect(z0 - pos()[2]).toBeGreaterThan(4);
    input.handlePointerDelta(-600, 0); // 90° à esquerda (0.15°/px)
    frame(3); // a câmera publica no quadro N; o movimento lê no N+1 (atraso de 1 quadro)
    expect(session.viewBasis!.yaw).toBeCloseTo(90, 4);
    const x0 = pos()[0];
    walk(input, frame);
    expect(x0 - pos()[0]).toBeGreaterThan(4);
    expect(inst('hero').transform.rotation[1]).toBeCloseTo(90, 3); // bodyFollowsView
  });

  it('esconde o corpo do alvo só no Play e o restaura ao remover a câmera', () => {
    const { session, frame, inst, camBehaviorId } = build();
    frame(5);
    expect(inst('hero').visible).toBe(false);
    expect(session.removeBehavior('cam', camBehaviorId)).toBe(true);
    expect(inst('hero').visible).toBe(true);
    expect(session.gameCamera).toBeNull();
    expect(session.viewBasis).toBeNull();
  });

  it('o movimento NÃO publica pose, não captura o ponteiro e não esconde o corpo (contrato; só o Behavior de câmera faz isso)', () => {
    const { session, frame, inst } = open(sceneWith(FLOOR, hero(beh('first_person_movement'))));
    frame(120);
    expect(session.gameCamera).toBeNull();
    expect(inst('hero').visible).toBe(true);
    for (const id of ['first_person_movement', 'third_person_movement']) {
      const src = readFileSync(new URL(`../logic/behaviors/${id}/runtime.ts`, import.meta.url), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
      expect(src).not.toMatch(/setGameCamera|pointerLock|\.visible\s*=/);
    }
  });
});

describe('Third Person: Movement (ator) + Camera (nó Camera)', () => {
  const build = (camProps: Record<string, any> = {}) => open(sceneWith(FLOOR, hero(beh('third_person_movement', { moveSpeed: 5 })), cameraNode('cam', [0, 5, 5], [beh('camera_third_person', { targetNodeId: 'hero', ...camProps })])));

  it('a câmera de perseguição segue o alvo e o corpo continua visível', () => {
    const { session, frame, pos, inst } = build();
    frame(120);
    const g = session.gameCamera!;
    expect(g.kind).toBe('camera');
    expect(g.pointerLock).toBe(false);
    expect(g.position.z - pos()[2]).toBeGreaterThan(4); // atrás do personagem (+Z), a ~6 m
    expect(inst('hero').visible).toBe(true);
    expect(session.viewBasis!.nodeId).toBe('cam');
  });

  it('ViewBasis.pitch segue o contrato (> 0 olha para CIMA): câmera acima do alvo olha para BAIXO (pitch < 0); a arma mira por ele (AIS-69)', () => {
    const { session, frame } = build();
    frame(120);
    expect(session.viewBasis!.pitch).toBeLessThan(0);
  });

  it('o movimento é relativo à câmera: orbitar 90° (botão direito) muda para onde "frente" vai', () => {
    const { session, input, frame, pos, inst } = build();
    frame(120);
    const z0 = pos()[2];
    walk(input, frame);
    expect(z0 - pos()[2]).toBeGreaterThan(4);
    input.handleMouseButton(2, true);
    input.handlePointerDelta(-300, 0); // 90° (0.3°/px)
    frame(3);
    input.handleMouseButton(2, false);
    expect(Math.abs(session.viewBasis!.yaw)).toBeCloseTo(90, 3);
    const x0 = pos()[0];
    walk(input, frame);
    expect(Math.abs(pos()[0] - x0)).toBeGreaterThan(4); // agora "frente" é para o lado
    expect(Math.abs(inst('hero').transform.rotation[1])).toBeGreaterThan(30); // o corpo virou para onde anda
  });

  it('followTargetRotation: yaw faz a câmera acompanhar a rotação do alvo (veículos/aeronaves)', () => {
    const turned = open(sceneWith(FLOOR, meshNode('car', [0, 1, 0], { rotation: { x: 0, y: 90, z: 0 } }), cameraNode('cam', [0, 5, 5], [beh('camera_third_person', { targetNodeId: 'car', followTargetRotation: 'yaw' })])));
    turned.frame(30);
    expect(turned.session.viewBasis!.yaw).toBeCloseTo(90, 3);
    const none = open(sceneWith(FLOOR, meshNode('car', [0, 1, 0], { rotation: { x: 0, y: 90, z: 0 } }), cameraNode('cam', [0, 5, 5], [beh('camera_third_person', { targetNodeId: 'car' })])));
    none.frame(30);
    expect(none.session.viewBasis!.yaw).toBeCloseTo(0, 3);
  });
});

describe('câmera com e sem alvo; alvo inválido', () => {
  it('sem alvo (1ª pessoa): só olha no lugar onde o nó Camera está', () => {
    const { session, input, frame } = open(sceneWith(FLOOR, cameraNode('cam', [3, 4, 5], [beh('camera_first_person', { mouseSensitivity: 0.15 })])));
    frame(10);
    expect(session.gameCamera!.position).toEqual({ x: 3, y: 4, z: 5 });
    input.handlePointerDelta(-600, 0);
    frame(1);
    expect(session.viewBasis!.yaw).toBeCloseTo(90, 4);
    expect(session.gameCamera!.position).toEqual({ x: 3, y: 4, z: 5 });
  });

  it('sem alvo (3ª pessoa): orbita em torno da própria posição autoral', () => {
    const { session, frame } = open(sceneWith(FLOOR, cameraNode('cam', [3, 4, 5], [beh('camera_third_person', { distance: 6, targetHeight: 0 })])));
    frame(10);
    const p = session.gameCamera!.position;
    expect(Math.hypot(p.x - 3, p.y - 4, p.z - 5)).toBeCloseTo(6, 3);
  });

  it('alvo que não existe: diagnóstico camera.target_unresolved uma vez, câmera na pose autoral, nenhum outro nó escolhido', () => {
    const { session, frame, logs } = open(sceneWith(FLOOR, hero(), cameraNode('cam', [3, 4, 5], [beh('camera_first_person', { targetNodeId: 'nao_existe' })])));
    frame(30);
    expect(session.gameCamera!.position).toEqual({ x: 3, y: 4, z: 5 });
    expect(logs.filter((l) => l.code === 'camera.target_unresolved')).toHaveLength(1);
  });
});

describe('seleção da câmera ativa', () => {
  it('nó Camera ativo SEM Behavior de câmera continua ignorado (o projeto padrão tem uma MainCamera ativa)', () => {
    const { session, frame } = open(sceneWith(FLOOR, hero(beh('first_person_movement')), cameraNode('MainCamera', [0, 3, 8])));
    frame(60);
    expect(session.gameCamera).toBeNull();
    expect(session.viewBasis).toBeNull();
  });

  it('câmera com active: false não publica', () => {
    const { session, frame } = open(sceneWith(FLOOR, cameraNode('cam', [0, 3, 8], [beh('camera_first_person')], { active: false })));
    frame(30);
    expect(session.gameCamera).toBeNull();
  });

  it('mais de uma ativa: vale a primeira e camera.multiple_active é avisado (uma vez)', () => {
    const { session, frame, reports } = open(sceneWith(FLOOR, cameraNode('camA', [1, 3, 8], [beh('camera_first_person')]), cameraNode('camB', [2, 3, 8], [beh('camera_first_person')])));
    frame(30);
    expect(session.gameCamera!.nodeId).toBe('camA');
    expect(reports.filter((r) => r.code === 'camera.multiple_active')).toHaveLength(1);
  });
});

describe('movimento sem câmera ativa (fallback determinístico)', () => {
  it('1ª pessoa anda relativo ao yaw do próprio nó (W = -Z) sem erro', () => {
    const { session, input, frame, pos, logs } = open(sceneWith(FLOOR, hero(beh('first_person_movement'))));
    frame(120);
    const z0 = pos()[2];
    walk(input, frame);
    expect(z0 - pos()[2]).toBeGreaterThan(4);
    expect(session.gameCamera).toBeNull();
    expect(logs.filter((l) => l.level === 'error')).toHaveLength(0);
  });

  it('3ª pessoa usa os eixos do mundo (W = -Z, D = +X) e o corpo vira para onde anda', () => {
    const { input, frame, pos, inst } = open(sceneWith(FLOOR, hero(beh('third_person_movement'))));
    frame(120);
    const x0 = pos()[0];
    walk(input, frame, 'KeyD');
    expect(pos()[0] - x0).toBeGreaterThan(4);
    expect(inst('hero').transform.rotation[1]).toBeLessThan(-30); // virou para +X (yaw negativo)
  });
});

describe('estado de locomoção (leitura da sessão)', () => {
  it('idle → walk → idle; Sprint vira run só com sprintMultiplier > 1; Jump sai do chão (jump/fall) e volta', () => {
    const { session, input, frame } = open(sceneWith(FLOOR, hero(beh('first_person_movement', { sprintMultiplier: 2, jumpSpeed: 6 }))));
    frame(120);
    expect(session.getLocomotion('hero')).toMatchObject({ state: 'idle', grounded: true });
    input.handleKey('KeyW', true);
    frame(10);
    expect(session.getLocomotion('hero')!.state).toBe('walk');
    input.handleKey('ShiftLeft', true);
    frame(10);
    expect(session.getLocomotion('hero')!.state).toBe('run');
    input.handleKey('ShiftLeft', false);
    input.handleKey('KeyW', false);
    frame(60);
    input.handleKey('Space', true);
    frame(1);
    input.handleKey('Space', false);
    frame(3);
    expect(['jump', 'fall']).toContain(session.getLocomotion('hero')!.state);
    expect(session.getLocomotion('hero')!.grounded).toBe(false);
    frame(180);
    expect(session.getLocomotion('hero')!.state).toBe('idle');
  });

  it('some com o Stop e com a remoção do Behavior', () => {
    const mv = beh('third_person_movement');
    const { session, frame } = open(sceneWith(FLOOR, hero(mv)));
    frame(30);
    expect(session.getLocomotion('hero')).toBeDefined();
    session.removeBehavior('hero', mv.id);
    expect(session.getLocomotion('hero')).toBeUndefined();
    const again = open(sceneWith(FLOOR, hero(beh('third_person_movement'))));
    again.frame(30);
    again.session.dispose();
    expect(again.session.getLocomotion('hero')).toBeUndefined();
    expect(again.session.viewBasis).toBeNull();
  });
});

describe('espaço do alvo: world × local (alvo dentro de um grupo movido e girado)', () => {
  /** grupo em (10,0,0) girado 90° em Y; o alvo é filho dele em (0,0,2): mundo = (12,0,0); local = (0,0,2). */
  const grouped = (camBehavior: BehaviorInstance): SceneData => {
    const scene = sceneWith(FLOOR, cameraNode('cam', [0, 5, 5], [camBehavior]));
    const root = scene.nodes[scene.rootNodeId];
    const grp = { ...meshNode('grp', [10, 0, 0], { rotation: { x: 0, y: 90, z: 0 } }), parentId: root.id, childrenIds: ['tgt'] } as GameNode;
    const tgt = { ...meshNode('tgt', [0, 0, 2]), parentId: 'grp' } as GameNode;
    return { ...scene, nodes: { ...scene.nodes, [root.id]: { ...root, childrenIds: [...root.childrenIds, 'grp'] } as GameNode, grp, tgt } };
  };

  it('1ª pessoa: world (padrão) segue a posição MUNDIAL do alvo; local lê o transform local', () => {
    const world = open(grouped(beh('camera_first_person', { targetNodeId: 'tgt', hideTarget: false })));
    world.frame(5);
    expect(world.session.gameCamera!.position.x).toBeCloseTo(12, 3);
    expect(world.session.gameCamera!.position.z).toBeCloseTo(0, 3);
    const local = open(grouped(beh('camera_first_person', { targetNodeId: 'tgt', hideTarget: false, targetSpace: 'local' })));
    local.frame(5);
    expect(local.session.gameCamera!.position.x).toBeCloseTo(0, 3);
    expect(local.session.gameCamera!.position.z).toBeCloseTo(2, 3);
  });

  it('3ª pessoa: o ponto seguido e o yaw acompanhado (followTargetRotation) vêm do espaço escolhido', () => {
    const world = open(grouped(beh('camera_third_person', { targetNodeId: 'tgt', targetHeight: 0, followTargetRotation: 'yaw', distance: 6 })));
    world.frame(5);
    const wp = world.session.gameCamera!.position;
    expect(Math.hypot(wp.x - 12, wp.y, wp.z)).toBeCloseTo(6, 2); // a 6 m do alvo MUNDIAL
    expect(world.session.viewBasis!.yaw).toBeCloseTo(90, 2); // yaw mundial do grupo
    const local = open(grouped(beh('camera_third_person', { targetNodeId: 'tgt', targetHeight: 0, followTargetRotation: 'yaw', distance: 6, targetSpace: 'local' })));
    local.frame(5);
    const lp = local.session.gameCamera!.position;
    expect(Math.hypot(lp.x, lp.y, lp.z - 2)).toBeCloseTo(6, 2); // a 6 m do ponto LOCAL (0,0,2)
    expect(local.session.viewBasis!.yaw).toBeCloseTo(0, 2); // o nó filho não tem rotação própria
  });

  it('alvo na raiz da cena: world e local são idênticos', () => {
    const w = open(sceneWith(FLOOR, meshNode('car', [3, 1, 4], { rotation: { x: 0, y: 30, z: 0 } }), cameraNode('cam', [0, 5, 5], [beh('camera_third_person', { targetNodeId: 'car', followTargetRotation: 'yaw' })])));
    const l = open(sceneWith(FLOOR, meshNode('car', [3, 1, 4], { rotation: { x: 0, y: 30, z: 0 } }), cameraNode('cam', [0, 5, 5], [beh('camera_third_person', { targetNodeId: 'car', followTargetRotation: 'yaw', targetSpace: 'local' })])));
    w.frame(20);
    l.frame(20);
    expect(w.session.gameCamera!.position).toEqual(l.session.gameCamera!.position);
  });
});
