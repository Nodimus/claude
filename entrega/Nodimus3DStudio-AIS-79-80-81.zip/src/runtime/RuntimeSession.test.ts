import { describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import type { BehaviorRuntime, BehaviorRuntimeModule } from '../logic/types';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { AuthoringModel } from '../core/authoring/AuthoringModel';
import { CommandManager } from '../core/commandManager';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { InputManager } from './input/InputManager';
import { RuntimeSession, activateRuntimeSession, getActiveRuntimeSession, getSimulatedTransform, type RuntimeSessionOptions } from './RuntimeSession';
import type { LogicLogEntry } from './logicRunner';

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[], parameters: Record<string, any> = {}): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters, conditions: [], actions });
const behavior = (type: string, rules: LogicEventRule[] = [], properties: Record<string, any> = {}, id = `b${++seq}`): BehaviorInstance => ({
  id,
  name: `B_${id}`,
  behaviorType: type,
  enabled: true,
  properties,
  rules,
});
const node = (id: string, type: string, extra: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type, parentId: null, childrenIds: [], visible: true, locked: false, properties: {}, ...extra }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes = { ...scene.nodes };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  nodes[root.id] = { ...root, childrenIds: [...root.childrenIds, ...extra.map((n) => n.id)] };
  return { ...scene, nodes };
}

const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v));

/** Entrada falsa: só o que Triggers/Behaviors consultam. */
const fakeInput = () => ({
  isActionPressed: () => false,
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: () => 0,
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
});

function open(scene: SceneData, extra: Partial<RuntimeSessionOptions> = {}) {
  const logs: LogicLogEntry[] = [];
  const diagnostics = new DiagnosticService();
  const session = new RuntimeSession({
    snapshot: createRuntimeSnapshot(scene),
    mode: 'scene',
    input: fakeInput(),
    diagnostics,
    onLog: (e) => logs.push(e),
    ...extra,
  });
  session.start();
  return { session, logs, diagnostics };
}

describe('Play altera o runtime e Stop restaura o autoral sem Undo (AIS-44b-C01)', () => {
  it('posição/variável mudam só no runtime; autoral, projeto e histórico ficam idênticos', () => {
    const scene = sceneWith(node('hero', 'Spatial', { behaviors: [behavior('custom_rules', [rule('on_update', [act('move_by', { dx: 2 }), act('add_to_variable', { variable: 'score', amount: 1 })])])] }));
    const model = new AuthoringModel({ files: {}, settings: { general: {} }, globalVariables: [{ id: 'g', name: 'score', type: 'number', value: 0 }] } as any, scene);
    const commands = new CommandManager();
    const before = clone(model.getScene());
    const globalsBefore = clone(model.getProject().globalVariables);
    const historyBefore = commands.getHistory().length;

    const session = new RuntimeSession({ snapshot: model.createSceneSnapshot(), globals: model.getProject().globalVariables, input: fakeInput() });
    session.start();
    session.step(0.1);
    session.step(0.1);
    expect(session.getSimulatedTransform('hero')!.position[0]).toBe(4);
    expect(session.variables!.getVariable('global', 'score')).toBe(2);
    session.dispose();

    expect(model.getScene()).toEqual(before);
    expect(model.getProject().globalVariables).toEqual(globalsBefore);
    expect(commands.getHistory().length).toBe(historyBefore);
    expect(session.status).toBe('stopped');
    expect(session.currentScene).toBeNull();
  });

  it('pose simulada: a sessão ativa responde por getSimulatedTransform; sem sessão, undefined', () => {
    const { session } = open(sceneWith(node('hero', 'Spatial', { behaviors: [behavior('custom_rules', [rule('on_start', [act('set_position', { x: 1, y: 2, z: 3 })])])] })));
    activateRuntimeSession(session);
    session.step(0.016);
    expect(getSimulatedTransform('hero')!.position).toEqual([1, 2, 3]);
    activateRuntimeSession(null);
    expect(getSimulatedTransform('hero')).toBeUndefined();
    expect(session.isDisposed).toBe(true);
  });

  it('pausar congela (step ignorado) e retomar volta a avançar', () => {
    const { session } = open(sceneWith(node('hero', 'Spatial', { behaviors: [behavior('custom_rules', [rule('on_update', [act('move_by', { dx: 1 })])])] })));
    session.step(0.1);
    session.pause();
    session.step(0.1);
    expect(session.status).toBe('paused');
    expect(session.getSimulatedTransform('hero')!.position[0]).toBe(1);
    expect(session.elapsedTime).toBeCloseTo(0.1);
    session.resume();
    session.step(0.1);
    expect(session.getSimulatedTransform('hero')!.position[0]).toBe(2);
  });
});

describe('lifecycle de Behavior e estado por instância (AIS-44b-C03)', () => {
  const calls: string[] = [];
  const counter = (): BehaviorRuntimeModule => ({
    create(): BehaviorRuntime {
      return {
        attach: (c) => calls.push(`attach:${c.node.persistentNodeId}`),
        onPlayStart: (c) => calls.push(`start:${c.node.persistentNodeId}`),
        onUpdate: (c) => {
          c.state.memory.n = ((c.state.memory.n as number) ?? 0) + 1;
        },
        onPlayStop: (c) => calls.push(`stop:${c.node.persistentNodeId}`),
        detach: (c) => calls.push(`detach:${c.node.persistentNodeId}`),
        dispose: () => calls.push('dispose'),
      };
    },
  });
  const catalog = { get: (t: string) => (t === 'counter' ? counter() : undefined) };
  const memoryOf = (s: RuntimeSession, node: string, behaviorId: string) => s.runner!.behaviorStates.get(node, behaviorId)?.memory.n;

  it('ordem attach → onPlayStart → onUpdate → onPlayStop → detach → dispose, uma vez cada', () => {
    calls.length = 0;
    const scene = sceneWith(node('a', 'Spatial', { behaviors: [behavior('counter', [], {}, 'ba')] }));
    const { session } = open(scene, { behaviorCatalog: catalog });
    session.step(0.1);
    session.dispose();
    session.dispose(); // idempotente
    expect(calls).toEqual(['attach:a', 'start:a', 'stop:a', 'detach:a', 'dispose']);
  });

  it('duas GameNodes (e duas instâncias no mesmo nó) com o mesmo Behavior têm estado independente', () => {
    const scene = sceneWith(
      node('a', 'Spatial', { behaviors: [behavior('counter', [], {}, 'a1'), behavior('counter', [], {}, 'a2')] }),
      node('b', 'Spatial', { behaviors: [behavior('counter', [], {}, 'b1')] })
    );
    const { session } = open(scene, { behaviorCatalog: catalog });
    session.step(0.1);
    session.step(0.1);
    session.step(0.1);
    expect([memoryOf(session, 'a', 'a1'), memoryOf(session, 'a', 'a2'), memoryOf(session, 'b', 'b1')]).toEqual([3, 3, 3]);
    session.restartBehavior('a', 'a1');
    session.step(0.1);
    expect([memoryOf(session, 'a', 'a1'), memoryOf(session, 'a', 'a2'), memoryOf(session, 'b', 'b1')]).toEqual([1, 4, 4]);
  });

  it('erro num callback é logado e não derruba a sessão nem os outros Behaviors', () => {
    const boom: BehaviorRuntimeModule = { create: () => ({ onUpdate: () => { throw new Error('quebrou'); } }) };
    const scene = sceneWith(node('a', 'Spatial', { behaviors: [behavior('boom', [], {}, 'x'), behavior('counter', [], {}, 'y')] }));
    const { session, logs } = open(scene, { behaviorCatalog: { get: (t) => (t === 'boom' ? boom : t === 'counter' ? counter() : undefined) } });
    expect(() => session.step(0.1)).not.toThrow();
    expect(memoryOf(session, 'a', 'y')).toBe(1);
    expect(logs.some((l) => l.level === 'error' && l.message.includes('quebrou'))).toBe(true);
  });

  it('continuous_rotation (executor por propriedades) gira por segundo e substitui as regras de preset (sem rotação dupla)', () => {
    const presetRule = rule('on_update', [act('rotate_by', { degrees: 1 })]);
    const scene = sceneWith(
      node('fan1', 'Spatial', { behaviors: [behavior('continuous_rotation', [presetRule], { rotationSpeed: 90, axis: 'y' })] }),
      node('fan2', 'Spatial', { behaviors: [behavior('continuous_rotation', [presetRule], { rotationSpeed: 30, axis: 'y' })] })
    );
    const { session } = open(scene);
    session.step(1);
    expect(session.getSimulatedTransform('fan1')!.rotation[1]).toBeCloseTo(90);
    expect(session.getSimulatedTransform('fan2')!.rotation[1]).toBeCloseTo(30);
  });
});

describe('Restart Scene e Restart Behavior (AIS-44b-C05/C06)', () => {
  it('Restart Scene preserva globais e restaura locais e a pose', () => {
    const scene = sceneWith(
      node('hero', 'Spatial', {
        variables: { hp: 10 },
        behaviors: [behavior('custom_rules', [rule('on_update', [act('move_by', { dx: 1 }), act('subtract_from_variable', { scope: 'local', target: 'hero', variable: 'hp', amount: 1 }), act('add_to_variable', { variable: 'score', amount: 1 })])])],
      })
    );
    const { session } = open(scene, { globals: [{ name: 'score', type: 'number', value: 0 }] });
    session.step(0.1);
    session.step(0.1);
    const sceneBefore = session.currentScene;
    expect(session.variables!.getVariable('local', 'hp', 'hero')).toBe(8);
    expect(session.getSimulatedTransform('hero')!.position[0]).toBe(2);
    expect(session.variables!.getVariable('global', 'score')).toBe(2);

    expect(session.restartScene()).toBe(true);
    expect(session.currentScene).not.toBe(sceneBefore);
    expect(sceneBefore!.disposed).toBe(true);
    expect(session.variables!.getVariable('global', 'score')).toBe(2); // preservada
    expect(session.variables!.getVariable('local', 'hp', 'hero')).toBe(10); // restaurada
    expect(session.getSimulatedTransform('hero')!.position[0]).toBe(0);
  });

  it('Restart Behavior zera só aquele Behavior: a cena e a pose do nó não são recriadas', () => {
    const scene = sceneWith(node('t', 'Spatial', { behaviors: [behavior('custom_rules', [rule('on_timeout', [act('add_to_variable', { variable: 'n', amount: 1 })], { interval: 1, repeat: true })], {}, 'timer')] }), node('m', 'Spatial'));
    const { session } = open(scene, { globals: [{ name: 'n', type: 'number', value: 0 }] });
    const live = session.currentScene;
    session.step(0.7);
    session.restartBehavior('t', 'timer');
    session.step(0.7); // sem o restart: 1.4 s (já teria disparado); com o restart: 0.7 s
    expect(session.variables!.getVariable('global', 'n')).toBe(0);
    session.step(0.4);
    expect(session.variables!.getVariable('global', 'n')).toBe(1);
    expect(session.currentScene).toBe(live);
  });
});

describe('troca de cena (AIS-44b-C04)', () => {
  const other = () => createRuntimeSnapshot({ ...sceneWith(node('boss', 'Spatial', { variables: { rage: 3 } })), id: 'scene_b', name: 'B', path: 'res://scenes/b.scene.json' });

  it('as Actions restantes da cena antiga não rodam; globais preservadas, locais limpas, nova cena viva', async () => {
    const scene = sceneWith(
      node('hero', 'Spatial', {
        variables: { hp: 7 },
        behaviors: [
          behavior('custom_rules', [
            rule('on_start', [act('set_variable', { variable: 'g', value: 'kept' }), act('change_scene', { scenePath: 'res://scenes/b.scene.json' }), act('set_variable', { variable: 'after', value: true })]),
            rule('on_start', [act('set_variable', { variable: 'sameFrame', value: true })]), // outra regra, mesmo quadro, depois do pedido
          ]),
        ],
      })
    );
    const { session } = open(scene, {
      globals: [
        { name: 'g', type: 'string', value: '' },
        { name: 'after', type: 'boolean', value: false },
        { name: 'sameFrame', type: 'boolean', value: false },
      ],
      resolveScene: async () => other(),
    });
    const oldScene = session.currentScene!;
    session.step(0.1);
    await new Promise((r) => setTimeout(r, 0));
    await new Promise((r) => setTimeout(r, 0));
    expect(session.variables!.getVariable('global', 'after')).toBe(false);
    expect(session.variables!.getVariable('global', 'sameFrame')).toBe(false);
    expect(session.variables!.getVariable('global', 'g')).toBe('kept'); // global preservada
    expect(oldScene.disposed).toBe(true);
    expect(session.currentScene!.getInstance('boss')).toBeDefined();
    expect(session.currentScene!.getInstance('hero')).toBeUndefined();
    expect(session.variables!.getVariable('local', 'hp', 'hero')).toBeUndefined(); // local da cena antiga limpa
    expect(session.variables!.getVariable('local', 'rage', 'boss')).toBe(3);
    session.step(0.1);
    expect(session.status).toBe('running');
  });

  it('timers e fila da cena antiga não disparam depois da troca; teardowns de sistemas rodam uma vez', async () => {
    const { session } = open(sceneWith());
    let late = 0;
    let torn = 0;
    session.runner!.schedule(0.5, () => late++);
    session.registerTeardown(() => torn++);
    const result = await session.changeScene(other());
    expect(result.committed).toBe(true);
    session.step(5);
    expect(late).toBe(0);
    expect(torn).toBe(1);
    session.dispose();
    expect(torn).toBe(1);
  });

  it('destino que não resolve: erro explícito (diagnóstico efêmero), a cena atual continua intacta', async () => {
    const scene = sceneWith(node('hero', 'Spatial', { behaviors: [behavior('custom_rules', [rule('on_update', [act('add_to_variable', { variable: 'n', amount: 1 })])])] }));
    const { session, diagnostics } = open(scene, { globals: [{ name: 'n', type: 'number', value: 0 }], resolveScene: () => { throw new Error('arquivo ausente'); } });
    const before = session.currentScene;
    const result = await session.changeScene('res://nao-existe.scene.json');
    expect(result.committed).toBe(false);
    expect(session.currentScene).toBe(before);
    session.step(0.1);
    expect(session.variables!.getVariable('global', 'n')).toBe(1); // regras da cena atual seguem funcionando
    expect(diagnostics.list({ ephemeral: true }).some((d) => d.code === 'logic.change_scene_failed')).toBe(true);
  });
});

describe('diagnósticos efêmeros (AIS-44b-C08/C09)', () => {
  const failing = () => sceneWith(node('n', 'Spatial', { behaviors: [behavior('custom_rules', [rule('on_start', [act('add_force', { x: 1, y: 0, z: 0 })])])] }));

  it('o diagnóstico do Play usa o sessionId e some no Stop; os autorais permanecem', () => {
    const diagnostics = new DiagnosticService();
    diagnostics.report({ source: 'scene', sourceId: 'res://scenes/Main.scene.json', severity: 'warning', phase: 'serialization', code: 'scene.missing_nodes', message: 'nós ausentes' });
    const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(failing()), input: fakeInput(), diagnostics });
    session.start();
    session.step(0.1);
    const ephemeral = diagnostics.list({ sessionId: session.id });
    expect(ephemeral.length).toBeGreaterThan(0);
    expect(ephemeral.every((d) => d.sessionId === session.id && d.source === 'runtime')).toBe(true);
    session.dispose();
    expect(diagnostics.list({ ephemeral: true })).toHaveLength(0);
    expect(diagnostics.list({ code: 'scene.missing_nodes' })).toHaveLength(1);
  });

  it('cinco ciclos Play/Stop deixam a contagem do DiagnosticService idêntica à de antes do primeiro Play', () => {
    const diagnostics = new DiagnosticService();
    diagnostics.report({ source: 'scene', sourceId: 's', severity: 'warning', phase: 'serialization', code: 'scene.missing_nodes', message: 'x' });
    const baseline = diagnostics.list().length;
    for (let i = 0; i < 5; i++) {
      const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(failing()), input: fakeInput(), diagnostics });
      session.start();
      session.step(0.1);
      expect(diagnostics.list().length).toBeGreaterThan(baseline);
      session.dispose();
      expect(diagnostics.list().length).toBe(baseline);
    }
  });
});

describe('Play/Stop repetido não multiplica callbacks (AIS-44b-C02)', () => {
  it('5 ciclos: listeners do input, sessões ativas, runtime vivo e lifecycle contam igual ao início', () => {
    const input = new InputManager();
    const base = input.listenerCount;
    const lifecycle = { attach: 0, dispose: 0 };
    const catalog = { get: (t: string): BehaviorRuntimeModule | undefined => (t === 'probe' ? { create: () => ({ attach: () => void lifecycle.attach++, dispose: () => void lifecycle.dispose++ }) } : undefined) };
    const scene = sceneWith(node('n', 'Spatial', { behaviors: [behavior('probe'), behavior('custom_rules', [rule('on_update', [act('add_to_variable', { variable: 'n', amount: 1 })])])] }));
    let runs = 0;
    for (let cycle = 0; cycle < 5; cycle++) {
      const logs: LogicLogEntry[] = [];
      const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), globals: [{ name: 'n', type: 'number', value: 0 }], input, behaviorCatalog: catalog, onLog: (e) => logs.push(e), verbose: true });
      activateRuntimeSession(session);
      session.start();
      const detach = input.attach({ keyTarget: { addEventListener() {}, removeEventListener() {} } });
      session.step(0.1);
      const variables = session.variables!;
      const runner = session.runner!;
      expect(variables.getVariable('global', 'n')).toBe(1); // exatamente uma execução por quadro, nunca N
      detach();
      activateRuntimeSession(null); // descarta
      // nada reage depois do Stop: nem assinatura de variável, nem step
      const executions = runner.executions;
      variables.setVariable('global', 'n', 99);
      runner.step(1);
      expect(runner.executions).toBe(executions);
      expect(session.isDisposed).toBe(true);
      expect(getActiveRuntimeSession()).toBeNull();
      expect(input.listenerCount).toBe(base);
      runs++;
    }
    expect(runs).toBe(5);
    expect(lifecycle.attach).toBe(5);
    expect(lifecycle.dispose).toBe(5);
  });
});
