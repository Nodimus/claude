import { beforeAll, describe, expect, it } from 'vitest';
import { AuthoringModel } from '../core/authoring/AuthoringModel';
import { applyBehaviorList, collectBehaviors } from '../core/authoring/behaviors';
import { CommandManager } from '../core/commandManager';
import { createBehaviorOps, type BehaviorStore } from '../core/commands/BehaviorCommands';
import { createChangePropertyCommand } from '../core/commands/ChangePropertyCommand';
import { createAddNodeCommand, createDeleteNodeCommand } from '../core/commands/SceneTreeCommands';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createSetGeneratorSourceCommand } from '../core/generators/generatorCommands';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { ensureRapier } from '../core/physics/rapierInit';
import { createDefaultNode } from '../nodes/registry';
import { createAircraft, type VehicleDeps } from '../core/vehicles/vehicleCommands';
import { defaultAircraftForm, type AircraftFormValues } from '../core/vehicles/vehiclePresets';
import { bodyAxes } from './aircraft/aircraftFlight';
import { RuntimeSession } from './RuntimeSession';

/**
 * AIS-73b — sessão com Rapier REAL: a aeronave criada pelo MESMO `createAircraft` do `VehicleDialog` acelera, ganha sustentação a partir de
 * `minSpeedToFly`, cai abaixo dele, responde a Throttle/Pitch/Yaw/Roll, e com ou sem a câmera de perseguição o resultado é IDÊNTICO (decisão 28).
 */

beforeAll(async () => {
  await ensureRapier();
});

const held = new Set<string>();
const input = {
  isActionPressed: (a: string) => held.has(a),
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: (neg: string, pos: string) => (held.has(pos) ? 1 : 0) - (held.has(neg) ? 1 : 0),
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
} as never;

function build(opts: { camera?: boolean; form?: AircraftFormValues; at?: { x: number; y: number; z: number } } = {}) {
  const model = new AuthoringModel();
  const manager = new CommandManager();
  model.loadScene(createDefault3DStarterScene());
  const store: BehaviorStore = { get: () => collectBehaviors(model.getScene()), set: (next) => void applyBehaviorList(model, next) };
  const deps: VehicleDeps = {
    nodes: () => model.getScene().nodes,
    addNode: (type, parentId, name, properties) => {
      const scene = model.getScene();
      const node = createDefaultNode(type, name, parentId ?? scene.rootNodeId, properties, scene.nodes);
      manager.execute(createAddNodeCommand({ target: model, node, parentId: parentId ?? scene.rootNodeId }));
      return node;
    },
    ops: createBehaviorOps(store, (c) => manager.execute(c)),
    changeNodeProperties: (nodeId, changes, label) => {
      const c = createChangePropertyCommand({ target: model, nodeId, changes, label });
      if (c) manager.execute(c);
    },
    deleteNodes: (ids) => {
      const c = createDeleteNodeCommand({ target: model, nodeIds: ids });
      if (c) manager.execute(c);
    },
    setGeneratorSource: (nodeId, source) => {
      const c = createSetGeneratorSourceCommand({ target: model, nodeId, source });
      if (c) manager.execute(c);
    },
    transaction: (label, fn) => manager.transaction(label, fn),
  };
  // piso de pista: grande e de atrito baixo
  const scene = model.getScene();
  const root = scene.nodes[scene.rootNodeId];
  const floor = createDefaultNode('MeshInstance', 'Pista', root.id, { meshType: 'CubeMesh', position: { x: 0, y: -0.5, z: -400 }, scale: { x: 400, y: 1, z: 2000 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto', friction: 0.05 } }, scene.nodes);
  manager.execute(createAddNodeCommand({ target: model, node: floor, parentId: root.id }));
  const form = opts.form ?? defaultAircraftForm('light');
  const result = createAircraft(deps, { form, parentId: null, name: 'Aviao', fuselage: { mode: 'prototype', size: { x: 1.2, y: 1.1, z: 7 } }, position: opts.at ?? { x: 0, y: 0.9, z: 0 }, camera: opts.camera ? { active: true } : null });
  return { model, manager, deps, result };
}

function play(scene: ReturnType<AuthoringModel['getScene']>) {
  const diagnostics = new DiagnosticService();
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input, diagnostics });
  session.start();
  return { session, diagnostics, messages: () => diagnostics.list({ ephemeral: true }).map((d) => `${d.severity} ${d.code}: ${d.message}`) };
}
const run = (s: RuntimeSession, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) s.step(1 / 60);
};
const pos = (s: RuntimeSession, id: string) => s.getSimulatedTransform(id)!.position;
const forwardSpeed = (s: RuntimeSession, id: string) => s.physics!.forwardSpeed(id) ?? 0;
const noseUp = (s: RuntimeSession, id: string) => bodyAxes(s.physics!.getPose(id)!.rotation).forward.y;

describe('aeronave no Play (AIS-73b-C01)', () => {
  it('Throttle acelera na pista até passar de minSpeedToFly; PitchUp então decola e sobe (sustentação)', () => {
    const { model, result } = build();
    const { session, messages } = play(model.getScene());
    held.clear();
    run(session, 1);
    held.add('Throttle');
    run(session, 9);
    expect(forwardSpeed(session, result.aircraftId)).toBeGreaterThan(18); // minSpeedToFly do Leve
    expect(pos(session, result.aircraftId)[1]).toBeLessThan(1.5); // ainda na pista
    held.add('PitchUp');
    run(session, 4);
    expect(pos(session, result.aircraftId)[1]).toBeGreaterThan(4); // decolou
    expect(messages().filter((m) => m.startsWith('error') || /Aircraft/.test(m))).toEqual([]);
    held.clear();
    session.dispose();
  });

  it('abaixo de minSpeedToFly perde a sustentação e CAI (quase queda livre); acima dele voa nivelada', () => {
    const slow = build({ at: { x: 0, y: 300, z: 0 } });
    const a = play(slow.model.getScene());
    held.clear();
    a.session.physics!.setLinearVelocity(slow.result.aircraftId, { x: 0, y: 0, z: -5 }); // 5 m/s < 18
    run(a.session, 3);
    expect(300 - pos(a.session, slow.result.aircraftId)[1]).toBeGreaterThan(30); // caiu (queda livre em 3 s ≈ 44 m)
    a.session.dispose();

    const fast = build({ at: { x: 0, y: 300, z: 0 } });
    const b = play(fast.model.getScene());
    b.session.physics!.setLinearVelocity(fast.result.aircraftId, { x: 0, y: 0, z: -40 });
    held.add('Throttle');
    run(b.session, 3);
    expect(Math.abs(300 - pos(b.session, fast.result.aircraftId)[1])).toBeLessThan(6); // nivelada: a sustentação sustenta o peso
    held.clear();
    b.session.dispose();
  });

  it('PitchUp levanta o nariz, PitchDown o abaixa; YawLeft vira para a esquerda; RollLeft inclina a asa esquerda para baixo', () => {
    const fly = () => {
      const s = build({ at: { x: 0, y: 300, z: 0 } });
      const p = play(s.model.getScene());
      p.session.physics!.setLinearVelocity(s.result.aircraftId, { x: 0, y: 0, z: -35 });
      held.clear();
      held.add('Throttle');
      run(p.session, 1);
      return { id: s.result.aircraftId, session: p.session };
    };
    const up = fly();
    held.add('PitchUp');
    run(up.session, 1);
    expect(noseUp(up.session, up.id)).toBeGreaterThan(0.25);
    up.session.dispose();

    const down = fly();
    held.add('PitchDown');
    run(down.session, 1);
    expect(noseUp(down.session, down.id)).toBeLessThan(-0.25);
    down.session.dispose();

    const yaw = fly();
    held.add('YawLeft');
    run(yaw.session, 2);
    expect(pos(yaw.session, yaw.id)[0]).toBeLessThan(-2); // esquerda = -X ao voar para -Z
    yaw.session.dispose();

    const roll = fly();
    held.add('RollLeft');
    run(roll.session, 1);
    const right = bodyAxes(roll.session.physics!.getPose(roll.id)!.rotation).right;
    expect(right.y).toBeGreaterThan(0.25); // a asa DIREITA sobe = a esquerda desce
    roll.session.dispose();
    held.clear();
  });
});

describe('o controlador não possui câmera (AIS-73b-C09, decisão 28)', () => {
  const flight = (camera: boolean) => {
    const s = build({ camera, at: { x: 0, y: 300, z: 0 } });
    const p = play(s.model.getScene());
    p.session.physics!.setLinearVelocity(s.result.aircraftId, { x: 0, y: 0, z: -35 });
    held.clear();
    held.add('Throttle');
    run(p.session, 1);
    held.add('PitchUp');
    held.add('RollLeft');
    run(p.session, 2);
    held.delete('PitchUp');
    run(p.session, 2);
    const t = p.session.getSimulatedTransform(s.result.aircraftId)!;
    const out = { position: [...t.position], rotation: [...t.rotation] };
    held.clear();
    p.session.dispose();
    return out;
  };

  it('com e sem a câmera de perseguição a dinâmica da aeronave é IDÊNTICA', () => {
    const a = flight(false);
    const b = flight(true);
    for (let i = 0; i < 3; i++) expect(b.position[i]).toBeCloseTo(a.position[i], 6);
  });

  it('o código-fonte do controlador não importa cameraRig nem chama setGameCamera', async () => {
    const fs = await import('node:fs');
    for (const file of ['index.ts', 'runtime.ts']) {
      const text = fs.readFileSync(`src/logic/behaviors/aircraft_controller/${file}`, 'utf8');
      expect(text).not.toMatch(/from\s+['"][^'"]*cameraRig/);
      expect(text).not.toMatch(/\.setGameCamera\s*\(/);
    }
  });
});

describe('configuração incompleta avisa, nunca quebra (AIS-73b)', () => {
  it('corpo que não é dynamic: avisa uma vez e a sessão segue', () => {
    const s = build();
    s.deps.changeNodeProperties(s.result.aircraftId, { 'physics.bodyMode': 'static' }, 'teste');
    const p = play(s.model.getScene());
    held.add('Throttle');
    run(p.session, 2);
    expect(p.session.status).toBe('running');
    expect(p.messages().join('\n')).toMatch(/Aircraft Controller: o corpo deste nó é "static"/);
    held.clear();
    p.session.dispose();
  });
});

describe('os três presets decolam e voam (AIS-73b-C01)', () => {
  for (const [type, seconds] of [['fighter', 8], ['glider', 18]] as const) {
    it(`${type}: acelera na pista acima de minSpeedToFly e decola com PitchUp`, () => {
      const form = defaultAircraftForm(type);
      const { model, result } = build({ form });
      const { session, messages } = play(model.getScene());
      held.clear();
      run(session, 1);
      held.add('Throttle');
      run(session, seconds);
      expect(forwardSpeed(session, result.aircraftId)).toBeGreaterThan(form.flight.minSpeedToFly);
      held.add('PitchUp');
      run(session, 5);
      expect(pos(session, result.aircraftId)[1]).toBeGreaterThan(3);
      expect(messages().filter((m) => m.startsWith('error'))).toEqual([]);
      held.clear();
      session.dispose();
    });
  }
});

describe('auto-nivelamento: soltar o comando volta ao voo nivelado (AIS-73b)', () => {
  const fly = (at = { x: 0, y: 300, z: 0 }, speed = 35) => {
    const b = build({ at });
    const p = play(b.model.getScene());
    p.session.physics!.setLinearVelocity(b.result.aircraftId, { x: 0, y: 0, z: -speed });
    held.clear();
    held.add('Throttle');
    run(p.session, 1);
    return { id: b.result.aircraftId, session: p.session };
  };
  const pitchDeg = (s: RuntimeSession, id: string) => (Math.asin(bodyAxes(s.physics!.getPose(id)!.rotation).forward.y) * 180) / Math.PI;
  const bankDeg = (s: RuntimeSession, id: string) => {
    const a = bodyAxes(s.physics!.getPose(id)!.rotation);
    return (Math.atan2(a.right.y, a.up.y) * 180) / Math.PI;
  };

  it('PitchUp e PitchDown: enquanto seguram inclinam o nariz; soltos, o nariz volta ao horizonte em poucos segundos (sem mergulhar para sempre)', () => {
    for (const [key, sign] of [['PitchUp', 1], ['PitchDown', -1]] as const) {
      const a = fly();
      held.add(key);
      run(a.session, 1);
      expect(sign * pitchDeg(a.session, a.id)).toBeGreaterThan(12); // enquanto segura, inclina
      held.delete(key);
      run(a.session, 3);
      expect(Math.abs(pitchDeg(a.session, a.id))).toBeLessThan(5); // soltou: volta ao horizonte
      run(a.session, 3);
      expect(Math.abs(a.session.physics!.getPose(a.id)!.linearVelocity.y)).toBeLessThan(5); // e não segue subindo/caindo
      held.clear();
      a.session.dispose();
    }
  });

  it('RollLeft/RollRight: soltos, as asas voltam niveladas (antes ficavam travadas a ~80°)', () => {
    for (const [key, sign] of [['RollLeft', 1], ['RollRight', -1]] as const) {
      const a = fly();
      held.add(key);
      run(a.session, 1);
      expect(Math.abs(bankDeg(a.session, a.id))).toBeGreaterThan(25);
      expect(sign * bankDeg(a.session, a.id)).toBeGreaterThan(0); // + = asa direita para cima = inclinada à esquerda
      held.delete(key);
      run(a.session, 3);
      expect(Math.abs(bankDeg(a.session, a.id))).toBeLessThan(5);
      held.clear();
      a.session.dispose();
    }
  });

  it('mergulho em alta: ao soltar o comando a aeronave se recupera sozinha e a velocidade não dispara', () => {
    const a = fly();
    held.add('PitchDown');
    run(a.session, 2.5); // nariz bem para baixo
    held.delete('PitchDown');
    held.delete('Throttle');
    const before = a.session.physics!.getPose(a.id)!.position.y;
    run(a.session, 8);
    expect(Math.abs(pitchDeg(a.session, a.id))).toBeLessThan(8);
    expect(before - a.session.physics!.getPose(a.id)!.position.y).toBeLessThan(160); // perdeu altura na recuperação, mas não despencou
    expect(forwardSpeed(a.session, a.id)).toBeLessThan(80);
    held.clear();
    a.session.dispose();
  });

  it('de cabeça para baixo (180° de rolagem) e sem comando: desvira pelo caminho mais curto e volta ao voo normal', () => {
    const a = fly();
    const q = bodyAxes(a.session.physics!.getPose(a.id)!.rotation);
    void q;
    a.session.physics!.setPose(a.id, { rotation: { x: 0, y: 0, z: 1, w: 0 } }); // 180° em torno de Z (frente -Z): invertida
    run(a.session, 6);
    expect(Math.abs(bankDeg(a.session, a.id))).toBeLessThan(10);
    held.clear();
    a.session.dispose();
  });

  it('estol: devagar e caindo, com Throttle a aeronave ganha velocidade, recupera a sustentação e volta a voar nivelada', () => {
    const a = fly({ x: 0, y: 400, z: 0 }, 5);
    run(a.session, 12);
    expect(forwardSpeed(a.session, a.id)).toBeGreaterThan(18); // passou de minSpeedToFly
    expect(Math.abs(pitchDeg(a.session, a.id))).toBeLessThan(15);
    expect(a.session.physics!.getPose(a.id)!.position.y).toBeGreaterThan(150); // recuperou antes do solo
    held.clear();
    a.session.dispose();
  });
});
