import { beforeAll, describe, expect, it } from 'vitest';
import * as THREE from 'three';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { AuthoringModel } from '../core/authoring/AuthoringModel';
import { CommandManager } from '../core/commandManager';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { legacyPhysicsDiagnostic } from '../core/diagnostics/adapters';
import { legacyPhysicsWarning, convertLegacyPhysics } from '../schemas/legacyPhysics';
import { normalizeUnknownNodes } from '../schemas/missingNodes';
import { ensureRapier } from '../core/physics/rapierInit';
import { RuntimeSession, type RuntimeSessionOptions } from './RuntimeSession';
import type { LogicLogEntry } from './logicRunner';

/**
 * AIS-45 — a ponte física DENTRO da `RuntimeSession`: o mundo nasce com a cena viva, o corpo é o dono da pose (só na instância de
 * runtime), Actions passam pela ponte, contatos viram Triggers, diagnósticos são efêmeros e o Stop/restart libera tudo.
 */

beforeAll(async () => {
  await ensureRapier();
});

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[], parameters: Record<string, any> = {}): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters, conditions: [], actions });
const behavior = (...rules: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'Regras', behaviorType: 'custom_rules', enabled: true, properties: {}, rules });

/** Nó 3D com pose/escala/física nas `properties` (o snapshot lê a pose daí). */
const body = (id: string, at: [number, number, number], physics: Record<string, any> | undefined, extra: Record<string, any> = {}, node: Partial<GameNode> = {}): GameNode =>
  ({
    id,
    name: id,
    type: 'MeshInstance',
    parentId: null,
    childrenIds: [],
    visible: true,
    locked: false,
    properties: { meshType: 'CubeMesh', position: { x: at[0], y: at[1], z: at[2] }, ...(physics ? { physics } : {}), ...extra },
    ...node,
  }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  // isola o teste: sem os nós do starter (nem os Behaviors dele)
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: [] } as GameNode };
  for (const n of extra) {
    const parentId = n.parentId ?? root.id;
    nodes[n.id] = { ...n, parentId } as GameNode;
    if (parentId === root.id) nodes[root.id].childrenIds.push(n.id);
    else nodes[parentId] = { ...nodes[parentId], childrenIds: [...(nodes[parentId].childrenIds ?? []), n.id] } as GameNode;
  }
  return { ...scene, nodes };
}

const fakeInput = () => ({
  isActionPressed: () => false,
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: () => 0,
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
});

const FLOOR = body('floor', [0, -0.5, 0], { enabled: true, bodyMode: 'static', shape: 'auto' }, { scale: { x: 40, y: 1, z: 40 } });

function open(scene: SceneData, extra: Partial<RuntimeSessionOptions> = {}) {
  const logs: LogicLogEntry[] = [];
  const diagnostics = new DiagnosticService();
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input: fakeInput(), diagnostics, onLog: (e) => logs.push(e), ...extra });
  session.start();
  return { session, logs, diagnostics };
}
const run = (session: RuntimeSession, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) session.step(1 / 60);
};

describe('o corpo é o dono da pose; o authoring nunca a recebe (AIS-45 · skill §5)', () => {
  it('dynamic cai e repousa; a pose simulada é lida da instância e o authoring/histórico ficam intactos', () => {
    const scene = sceneWith(FLOOR, body('box', [0, 5, 0], { enabled: true, bodyMode: 'dynamic', shape: 'auto' }));
    const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene);
    const commands = new CommandManager();
    const before = JSON.parse(JSON.stringify(model.getScene()));
    const session = new RuntimeSession({ snapshot: model.createSceneSnapshot(), input: fakeInput() });
    session.start();
    expect(session.physics).not.toBeNull();
    run(session, 4);
    const y = session.getSimulatedTransform('box')!.position[1];
    expect(y).toBeGreaterThan(0.45);
    expect(y).toBeLessThan(0.56);
    session.dispose();
    expect(model.getScene()).toEqual(before);
    expect(commands.getHistory().length).toBe(0);
  });

  it('cena sem bloco de física não carrega mundo; nó sem bloco ou com enabled:false não cria corpo (C02)', () => {
    const none = open(sceneWith(body('a', [0, 0, 0], undefined)));
    expect(none.session.physics).toBeNull();
    const mixed = open(sceneWith(body('on', [0, 5, 0], { enabled: true, bodyMode: 'dynamic', shape: 'auto' }), body('off', [0, 5, 0], { enabled: false, bodyMode: 'dynamic', shape: 'auto' }), body('plain', [0, 5, 0], undefined)));
    expect(mixed.session.physics!.has('on')).toBe(true);
    expect(mixed.session.physics!.has('off')).toBe(false);
    expect(mixed.session.physics!.has('plain')).toBe(false);
    expect(mixed.session.physics!.bodyCount).toBe(1);
  });

  it('a gravidade é da Scene (environmentSettings), não do projeto', () => {
    const scene = { ...sceneWith(body('b', [0, 0, 0], { enabled: true, bodyMode: 'dynamic', shape: 'auto' })), environmentSettings: { gravity: { x: 0, y: 0, z: 0 } } } as unknown as SceneData;
    const { session } = open(scene);
    run(session, 1);
    expect(session.getSimulatedTransform('b')!.position[1]).toBeCloseTo(0, 3); // gravidade zero: não cai
  });

  it('filho de pai rotacionado: a pose mundial do Rapier vira pose LOCAL correta (mundo → local pela cadeia de pais)', () => {
    const parent = body('parent', [10, 0, 0], undefined, { rotation: { x: 0, y: 90, z: 0 } }, { type: 'Spatial', childrenIds: ['kid'] } as any);
    const kid = body('kid', [0, 6, 0], { enabled: true, bodyMode: 'dynamic', shape: 'auto' }, {}, { parentId: 'parent' });
    const floor = body('floor', [10, -0.5, 0], { enabled: true, bodyMode: 'static', shape: 'auto' }, { scale: { x: 40, y: 1, z: 40 } });
    const { session } = open(sceneWith(floor, parent, kid));
    run(session, 4);
    const instance = session.scene.getInstance('kid')!;
    instance.object!.updateWorldMatrix(true, false);
    const world = instance.object!.getWorldPosition(new THREE.Vector3());
    const pose = session.physics!.getPose('kid')!.position;
    expect(world.x).toBeCloseTo(pose.x, 2);
    expect(world.y).toBeCloseTo(pose.y, 2);
    expect(world.z).toBeCloseTo(pose.z, 2);
    expect(pose.y).toBeGreaterThan(0.4); // repousou sobre o chão
    expect(pose.y).toBeLessThan(0.6);
  });
});

describe('Actions e contatos passam pela PhysicsBridge (AIS-45 · skill de Actions)', () => {
  it('Add Force num corpo static falha com mensagem clara, sem derrubar o Play; no dynamic funciona', () => {
    const scene = sceneWith(
      body('wall', [0, 0, 0], { enabled: true, bodyMode: 'static', shape: 'auto' }, {}, { behaviors: [behavior(rule('on_start', [act('add_force', { force: { x: 1, y: 0, z: 0 } }), act('set_variable', { variable: 'after', value: true })]))] } as any),
      body('ball', [5, 0, 0], { enabled: true, bodyMode: 'dynamic', shape: 'auto' }, {}, { behaviors: [behavior(rule('on_start', [act('add_impulse', { impulse: { x: 5, y: 0, z: 0 } })]))] } as any)
    );
    const { session, logs } = open(scene, { globals: [{ name: 'after', type: 'boolean', value: false }] });
    run(session, 1);
    expect(logs.some((l) => l.level === 'error' && /Add Force/.test(l.message) && /static|Sólido/.test(l.message))).toBe(true);
    expect(session.variables!.getVariable('global', 'after')).toBe(true); // a cadeia seguiu
    expect(session.getSimulatedTransform('ball')!.position[0]).toBeGreaterThan(5.1);
    expect(session.status).toBe('running');
  });

  it('teleporte reposiciona o corpo e a instância; Set Physics Enabled liga/desliga sem remover o nó', () => {
    const scene = sceneWith(
      body('b', [0, 20, 0], { enabled: true, bodyMode: 'dynamic', shape: 'auto' }, {}, {
        behaviors: [behavior(rule('on_start', [act('teleport_physics_body', { position: { x: 7, y: 9, z: 2 } }), act('set_physics_enabled', { enabled: false })]))],
      } as any)
    );
    const { session } = open(scene);
    run(session, 1);
    expect(session.getSimulatedTransform('b')!.position).toEqual([7, 9, 2]); // não cai: desligado
    expect(session.physics!.has('b')).toBe(true);
    expect(session.physics!.isEnabled('b')).toBe(false);
  });

  it('colisão dispara on_collision_enter na regra do corpo; o gatilho (trigger) dispara on_trigger_enter (AIS-48)', () => {
    const scene = sceneWith(
      FLOOR,
      body('crate', [0, 2, 0], { enabled: true, bodyMode: 'dynamic', shape: 'auto' }, {}, { behaviors: [behavior(rule('on_collision_enter', [act('add_to_variable', { variable: 'hits', amount: 1 })]))] } as any),
      body('zone', [8, 0, 0], { enabled: true, bodyMode: 'trigger', shape: 'auto' }, { scale: { x: 3, y: 3, z: 3 } }, { behaviors: [behavior(rule('on_trigger_enter', [act('set_variable', { variable: 'zoned', value: true })]))] } as any),
      body('ball', [8, 6, 0], { enabled: true, bodyMode: 'dynamic', shape: 'sphere' })
    );
    const { session } = open(scene, { globals: [{ name: 'hits', type: 'number', value: 0 }, { name: 'zoned', type: 'boolean', value: false }] });
    run(session, 3);
    expect(session.variables!.getVariable('global', 'hits')).toBeGreaterThanOrEqual(1);
    expect(session.variables!.getVariable('global', 'zoned')).toBe(true);
  });

  it('kinematic segue a pose da lógica (move_velocity) e empurra um dynamic; character cai e pousa', () => {
    const scene = sceneWith(
      FLOOR,
      body('plat', [-2, 0.5, 0], { enabled: true, bodyMode: 'kinematic', shape: 'auto' }, { scale: { x: 1, y: 1, z: 3 } }, { behaviors: [behavior(rule('on_start', [act('move_velocity', { velocity: { x: 2, y: 0, z: 0 } })]))] } as any),
      body('crate', [0.5, 0.5, 0], { enabled: true, bodyMode: 'dynamic', shape: 'auto' }),
      body('hero', [10, 5, 0], { enabled: true, bodyMode: 'character', shape: 'capsule' }, { scale: { x: 1, y: 2, z: 1 } })
    );
    const { session } = open(scene);
    run(session, 3);
    expect(session.getSimulatedTransform('plat')!.position[0]).toBeGreaterThan(2);
    expect(session.getSimulatedTransform('crate')!.position[0]).toBeGreaterThan(1.5); // foi empurrada
    expect(session.physics!.isGrounded('hero')).toBe(true);
    expect((session.physics as any).entries.get('hero').body.isDynamic()).toBe(false); // character NUNCA é dynamic
    expect(session.getSimulatedTransform('hero')!.position[1]).toBeLessThan(2);
  });
});

describe('diagnósticos de física são EFÊMEROS (AIS-45-C12 · emenda v5.8)', () => {
  const scene = () =>
    sceneWith(
      body('stretched', [0, 1, 0], { enabled: true, bodyMode: 'static', shape: 'sphere' }, { scale: { x: 1, y: 3, z: 1 } }),
      body('empty', [0, 0, 0], { enabled: true, bodyMode: 'static', shape: 'mesh' }, {}, { type: 'Spatial' } as any),
      body('ok', [0, 5, 0], { enabled: true, bodyMode: 'dynamic', shape: 'auto' })
    );

  it('nonuniform_scale e mesh_missing_geometry aparecem no Play, o nó afetado fica sem corpo e somem no Stop', () => {
    const diagnostics = new DiagnosticService();
    diagnostics.report({ source: 'scene', sourceId: 'x', severity: 'warning', phase: 'serialization', code: 'scene.missing_nodes', message: 'autoral' });
    const logs: LogicLogEntry[] = [];
    const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene()), input: fakeInput(), diagnostics, onLog: (e) => logs.push(e) });
    session.start();
    run(session, 0.5);
    const codes = diagnostics.list({ ephemeral: true }).map((d) => d.code);
    expect(codes).toContain('physics.nonuniform_scale');
    expect(codes).toContain('physics.mesh_missing_geometry');
    expect(diagnostics.list({ ephemeral: true }).every((d) => d.source === 'physics' && d.sessionId === session.id)).toBe(true);
    expect(session.physics!.has('empty')).toBe(false); // sem corpo, sem quebrar
    expect(session.physics!.has('ok')).toBe(true);
    expect(session.status).toBe('running');
    expect(logs.some((l) => l.message.startsWith('[physics.mesh_missing_geometry]'))).toBe(true);
    session.dispose();
    expect(diagnostics.list({ ephemeral: true })).toHaveLength(0);
    expect(diagnostics.list({ code: 'scene.missing_nodes' })).toHaveLength(1);
  });

  it('o escala não uniforme é avisada UMA vez, não a cada quadro', () => {
    const { session, diagnostics } = open(scene());
    run(session, 2);
    expect(diagnostics.list({ code: 'physics.nonuniform_scale' })).toHaveLength(1);
    expect(diagnostics.list({ code: 'physics.nonuniform_scale' })[0].occurrences).toBe(1);
  });
});

describe('Stop, restart e carga assíncrona do Rapier', () => {
  const dyn = () => sceneWith(FLOOR, body('b', [0, 3, 0], { enabled: true, bodyMode: 'dynamic', shape: 'auto' }));

  it('Stop libera o mundo (world.free) e a ponte fica inutilizável', () => {
    const { session } = open(dyn());
    const bridge = session.physics!;
    run(session, 1);
    session.dispose();
    expect(bridge.isDisposed).toBe(true);
    expect(session.physics).toBeNull();
    expect(() => bridge.addImpulse('b', { x: 1, y: 0, z: 0 })).toThrow(/encerrada/);
  });

  it('Restart Scene cria um mundo NOVO do snapshot (sem velocidade nem posição residual) e libera o anterior', () => {
    const { session } = open(dyn());
    run(session, 3); // repousa sobre o chão
    const first = session.physics!;
    expect(session.restartScene()).toBe(true);
    expect(first.isDisposed).toBe(true);
    const second = session.physics!;
    expect(second).not.toBe(first);
    expect(second.getPose('b')!.position.y).toBeCloseTo(3, 3);
    expect(second.getPose('b')!.linearVelocity.y).toBe(0);
    expect(session.getSimulatedTransform('b')!.position[1]).toBeCloseTo(3, 3);
  });

  it('5 ciclos Play/Stop não acumulam mundos', () => {
    const bridges = [];
    for (let i = 0; i < 5; i++) {
      const { session } = open(dyn());
      run(session, 0.5);
      bridges.push(session.physics!);
      session.dispose();
    }
    expect(bridges.every((b) => b.isDisposed)).toBe(true);
    expect(new Set(bridges).size).toBe(5);
  });

  it('Rapier ainda não carregado: o Play começa e o mundo entra quando a carga termina (sem esperar nem quebrar)', async () => {
    const R = await ensureRapier();
    let consultas = 0;
    // 1ª consulta (início do Play): ainda carregando; 2ª (depois da carga): disponível
    const { session } = open(dyn(), { getRapier: () => (++consultas >= 2 ? R : null) });
    expect(session.physics).toBeNull(); // o Play já começou, sem mundo
    expect(session.status).toBe('running');
    expect(() => run(session, 0.2)).not.toThrow();
    await new Promise((r) => setTimeout(r, 0));
    await new Promise((r) => setTimeout(r, 0));
    expect(session.physics).not.toBeNull(); // entrou quando o Rapier ficou pronto
    run(session, 0.5);
    expect(session.getSimulatedTransform('b')!.position[1]).toBeLessThan(3);
  });

  it('Rapier que nunca fica disponível: diagnóstico efêmero explícito e a cena segue sem corpos', async () => {
    const { session, diagnostics } = open(dyn(), { getRapier: () => null });
    await new Promise((r) => setTimeout(r, 0));
    await new Promise((r) => setTimeout(r, 0));
    expect(diagnostics.list({ code: 'physics.engine_unavailable' })).toHaveLength(1);
    expect(session.physics).toBeNull();
    expect(session.status).toBe('running');
  });

  it('troca de cena destrói o mundo antigo e cria o da nova cena', async () => {
    const { session } = open(dyn());
    const old = session.physics!;
    const next = createRuntimeSnapshot({ ...sceneWith(FLOOR, body('other', [0, 2, 0], { enabled: true, bodyMode: 'dynamic', shape: 'auto' })), id: 'b', path: 'res://scenes/b.scene.json' });
    await session.changeScene(next);
    expect(old.isDisposed).toBe(true);
    expect(session.physics).not.toBe(old);
    expect(session.physics!.has('other')).toBe(true);
    expect(session.physics!.has('b')).toBe(false);
  });
});

describe('física legada não convertida vira diagnóstico (AIS-45-C11 · emenda v5.8)', () => {
  const legacyScene = () => ({
    nodes: {
      root: { id: 'root', name: 'Root', type: 'Spatial', parentId: null, childrenIds: ['rb'] },
      // corpo legado com DOIS CollisionShape: não é o caso simples, fica sem conversão
      rb: { id: 'rb', name: 'Antigo', type: 'RigidBody', parentId: 'root', childrenIds: ['s1', 's2'], properties: {} },
      s1: { id: 's1', name: 'S1', type: 'CollisionShape', parentId: 'rb', childrenIds: [], properties: {} },
      s2: { id: 's2', name: 'S2', type: 'CollisionShape', parentId: 'rb', childrenIds: [], properties: {} },
    },
  });

  it('conta o legado também depois de lido (Missing Node com originalType legado)', () => {
    const loaded = normalizeUnknownNodes(convertLegacyPhysics(legacyScene())).nodes as any;
    expect(Object.values(loaded).some((n: any) => n.type === 'Missing')).toBe(true);
    expect(legacyPhysicsWarning(loaded)).toMatch(/physics\.legacy_unconverted: 3/);
  });

  it('um item por cena; reabrir NÃO duplica e `occurrences` sobe', () => {
    const d = new DiagnosticService();
    const loaded = normalizeUnknownNodes(convertLegacyPhysics(legacyScene())).nodes as any;
    const publish = () => d.replaceForOwner({ source: 'physics', sourceId: 'res://scenes/Old.scene.json' }, legacyPhysicsDiagnostic('res://scenes/Old.scene.json', legacyPhysicsWarning(loaded)), { announce: 'all' });
    publish();
    publish();
    const items = d.list({ code: 'physics.legacy_unconverted' });
    expect(items).toHaveLength(1);
    expect(items[0].severity).toBe('warning');
    expect(items[0].occurrences).toBe(2);
    expect(items[0].message).toContain('sem conversão simples');
    expect(legacyPhysicsDiagnostic('x', null)).toEqual([]);
  });
});
