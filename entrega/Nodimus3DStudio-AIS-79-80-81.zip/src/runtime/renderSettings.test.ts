import { describe, expect, it } from 'vitest';
import { effectiveShadowMapSize, fitFrame, normalizeHexColor, resolveRenderSettings } from './renderSettings';
import { schemaDefaults } from '../core/projectSettingsForm';
import type { ProjectSettings } from '../types/project';

const settings = (patch: { rendering?: Partial<ProjectSettings['rendering']>; display?: Partial<ProjectSettings['display']> } = {}): ProjectSettings => {
  const base = schemaDefaults();
  return { ...base, rendering: { ...base.rendering, ...patch.rendering }, display: { ...base.display, ...patch.display } };
};

describe('resolveRenderSettings (AIS-44d-C01)', () => {
  it('os padrões do schema reproduzem a aparência atual do Play (decisão 4a)', () => {
    const r = resolveRenderSettings(settings());
    expect(r.shadows).toEqual({ enabled: true, mapSize: 2048 });
    expect(r.clearColor).toBe('#141822');
    expect(r.hdr).toBe(false);
    expect(r.msaa).toEqual({ setting: '2x', samples: 2, antialias: true });
    expect(r.frame).toEqual({ width: 1280, height: 720, aspect: 1280 / 720 });
  });

  it('aceita o ProjectData inteiro ou só settings', () => {
    const s = settings({ rendering: { shadowQuality: 'high' } });
    expect(resolveRenderSettings({ settings: s }).shadows.mapSize).toBe(4096);
    expect(resolveRenderSettings(s).shadows.mapSize).toBe(4096);
  });

  it('shadowsEnabled: o projeto desliga tudo; a regra é AND com o realtimeShadows do Environment', () => {
    expect(resolveRenderSettings(settings({ rendering: { shadowsEnabled: false } }), { realtimeShadows: true }).shadows.enabled).toBe(false);
    expect(resolveRenderSettings(settings({ rendering: { shadowsEnabled: true } }), { realtimeShadows: false }).shadows.enabled).toBe(false);
    expect(resolveRenderSettings(settings({ rendering: { shadowsEnabled: true } }), { realtimeShadows: true }).shadows.enabled).toBe(true);
    expect(resolveRenderSettings(settings({ rendering: { shadowsEnabled: true } })).shadows.enabled).toBe(true); // sem Environment: só o projeto
    expect(resolveRenderSettings(settings({ rendering: { shadowsEnabled: false } })).shadows.enabled).toBe(false);
  });

  it.each([
    ['low', 1024],
    ['medium', 2048],
    ['high', 4096],
  ] as const)('shadowQuality %s → mapa %i', (quality, size) => {
    expect(resolveRenderSettings(settings({ rendering: { shadowQuality: quality } })).shadows.mapSize).toBe(size);
  });

  it('clearColor: normaliza #rgb e maiúsculas; hex inválido cai no padrão', () => {
    expect(resolveRenderSettings(settings({ rendering: { clearColor: '#ABC' } })).clearColor).toBe('#aabbcc');
    expect(resolveRenderSettings(settings({ rendering: { clearColor: '#FF8800' } })).clearColor).toBe('#ff8800');
    expect(resolveRenderSettings(settings({ rendering: { clearColor: 'vermelho' } })).clearColor).toBe('#141822');
    expect(resolveRenderSettings(settings({ rendering: { clearColor: '#12345' } })).clearColor).toBe('#141822');
    expect(normalizeHexColor(42)).toBeUndefined();
  });

  it('hdr e msaa', () => {
    expect(resolveRenderSettings(settings({ rendering: { hdr: true } })).hdr).toBe(true);
    const cases = [
      ['disabled', 0, false],
      ['2x', 2, true],
      ['4x', 4, true],
      ['8x', 8, true],
    ] as const;
    for (const [setting, samples, antialias] of cases) {
      expect(resolveRenderSettings(settings({ rendering: { msaa: setting } })).msaa).toEqual({ setting, samples, antialias });
    }
  });

  it('display.width × height → proporção da moldura', () => {
    expect(resolveRenderSettings(settings({ display: { width: 1000, height: 1000 } })).frame).toEqual({ width: 1000, height: 1000, aspect: 1 });
    expect(resolveRenderSettings(settings({ display: { width: 800, height: 1600 } })).frame.aspect).toBeCloseTo(0.5);
    expect(resolveRenderSettings(settings({ display: { width: 1920, height: 1080 } })).frame.aspect).toBeCloseTo(16 / 9);
  });

  it('projeto antigo sem os campos novos usa os padrões, campo a campo', () => {
    const old = { general: { projectName: 'X' }, display: { width: 640, height: 480, resizable: true, fullscreen: false }, rendering: { renderer: 'Three.js (WebGL)', clearColor: '#101010', vsync: true, msaa: '4x', shadowsEnabled: false } };
    const r = resolveRenderSettings({ settings: old });
    expect(r.shadows).toEqual({ enabled: false, mapSize: 2048 }); // shadowQuality ausente → medium
    expect(r.hdr).toBe(false);
    expect(r.msaa.samples).toBe(4);
    expect(r.clearColor).toBe('#101010');
    expect(r.frame.aspect).toBeCloseTo(640 / 480);
  });

  it('valores inválidos e entradas vazias nunca lançam: viram os padrões', () => {
    for (const bad of [undefined, null, {}, 'x', 42, { rendering: null, display: [] }]) {
      const r = resolveRenderSettings(bad);
      expect(r.shadows.mapSize).toBe(2048);
      expect(r.clearColor).toBe('#141822');
      expect(r.frame.aspect).toBeCloseTo(1280 / 720);
    }
    const garbage = resolveRenderSettings({ settings: { rendering: { shadowQuality: 'ultra', msaa: '16x', hdr: 'sim', shadowsEnabled: 'não', clearColor: 7 }, display: { width: -5, height: 'a' } } });
    expect(garbage.shadows).toEqual({ enabled: true, mapSize: 2048 });
    expect(garbage.msaa.setting).toBe('2x');
    expect(garbage.hdr).toBe(false);
    expect(garbage.frame).toEqual({ width: 1280, height: 720, aspect: 1280 / 720 });
  });
});

describe('moldura e shadowMapSize (AIS-44d-C04/C06)', () => {
  it('fitFrame: letterbox (mais largo que a moldura) e pillarbox (mais alto), centrado', () => {
    expect(fitFrame({ width: 1000, height: 400 }, 16 / 9)).toEqual({ width: 711, height: 400, left: 144, top: 0 });
    expect(fitFrame({ width: 400, height: 1000 }, 16 / 9)).toEqual({ width: 400, height: 225, left: 0, top: 387 });
    expect(fitFrame({ width: 500, height: 500 }, 1)).toEqual({ width: 500, height: 500, left: 0, top: 0 });
  });

  it('fitFrame com entrada degenerada devolve o próprio contêiner (nunca NaN)', () => {
    expect(fitFrame({ width: 0, height: 0 }, 1.7)).toEqual({ width: 0, height: 0, left: 0, top: 0 });
    expect(fitFrame({ width: 300, height: 200 }, 0)).toEqual({ width: 300, height: 200, left: 0, top: 0 });
  });

  it('o shadowMapSize do nó de luz vence; sem ele vale o do projeto; sem projeto (Edit) o histórico 2048', () => {
    expect(effectiveShadowMapSize(512, 4096)).toBe(512);
    expect(effectiveShadowMapSize(undefined, 4096)).toBe(4096);
    expect(effectiveShadowMapSize(undefined, undefined)).toBe(2048);
    expect(effectiveShadowMapSize('x', 1024)).toBe(1024);
    expect(effectiveShadowMapSize(0, 1024)).toBe(1024);
  });
});
