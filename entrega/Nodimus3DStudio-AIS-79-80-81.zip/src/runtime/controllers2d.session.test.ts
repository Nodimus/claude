import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { ensureRapier } from '../core/physics/rapierInit';
import { InputManager } from './input/InputManager';
import { RuntimeSession } from './RuntimeSession';

/**
 * AIS-75 — Platformer2D e TopDown2D na `RuntimeSession` com a física REAL (Rapier) e o `InputManager` real: pulo, queda, chão, colisão
 * e permanência no plano escolhido (AIS-74).
 */

beforeAll(async () => {
  await ensureRapier();
});

let seq = 0;
const beh = (behaviorType: string, properties: Record<string, any> = {}): BehaviorInstance => ({ id: `b${++seq}`, name: behaviorType, behaviorType, enabled: true, properties, rules: [] });
const meshNode = (id: string, at: [number, number, number], extra: Record<string, any> = {}, nodeExtra: Record<string, any> = {}): GameNode =>
  ({ id, name: id, type: 'MeshInstance', parentId: null, childrenIds: [], visible: true, locked: false, properties: { meshType: 'CubeMesh', position: { x: at[0], y: at[1], z: at[2] }, ...extra }, ...nodeExtra }) as unknown as GameNode;
function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  return { ...scene, nodes };
}
const FLOOR = meshNode('floor', [0, -0.5, 0], { scale: { x: 80, y: 1, z: 80 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } });
const WALL = meshNode('wall', [5, 1, 0], { scale: { x: 1, y: 4, z: 6 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } });
const character = (plane: string) => ({ enabled: true, bodyMode: 'character', shape: 'capsule', constrainToPlane: plane });

function open(scene: SceneData) {
  const input = new InputManager();
  input.setEnabled(true);
  const logs: { level: string; message: string }[] = [];
  const diagnostics = { report: () => undefined, clearSession: () => 0 };
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input, onLog: (e: any) => logs.push(e), diagnostics } as any);
  session.start();
  const frame = (n = 1) => {
    for (let i = 0; i < n; i++) {
      session.step(1 / 60);
      input.endFrame();
    }
  };
  const pos = (id = 'hero') => session.getSimulatedTransform(id)!.position;
  return { session, input, logs, frame, pos };
}

describe('Platformer 2D na sessão (AIS-75-C01)', () => {
  const build = (props: Record<string, any> = {}, plane = 'xy', startZ = 0) =>
    open(sceneWith(FLOOR, WALL, meshNode('hero', [0, 1.5, startZ], { scale: { x: 1, y: 1.8, z: 1 }, physics: character(plane) }, { behaviors: [beh('platformer_2d_movement', props)] })));

  it('cai, pousa no chão e fica parado', () => {
    const { frame, pos } = build();
    frame(120);
    expect(pos()[1]).toBeGreaterThan(0.3);
    expect(pos()[1]).toBeLessThan(1.2);
    const y = pos()[1];
    frame(30);
    expect(Math.abs(pos()[1] - y)).toBeLessThan(0.01);
  });

  it('anda para os lados e fica ESTRITAMENTE no plano XY (z não muda)', () => {
    const { input, frame, pos } = build({}, 'xy', 3);
    frame(90);
    input.handleKey('KeyD', true);
    frame(40);
    input.handleKey('KeyD', false);
    expect(pos()[0]).toBeGreaterThan(2);
    input.handleKey('KeyA', true);
    frame(80);
    expect(pos()[0]).toBeLessThan(1);
    expect(pos()[2]).toBeCloseTo(3, 5);
  });

  it('pula: sobe e volta ao chão; Jump no ar não pula de novo', () => {
    const { input, frame, pos } = build();
    frame(90);
    const ground = pos()[1];
    input.handleKey('Space', true);
    frame(1);
    let top = ground;
    for (let i = 0; i < 90; i++) {
      frame(1);
      top = Math.max(top, pos()[1]);
      if (i === 3) input.handleKey('Space', false);
    }
    expect(top - ground).toBeGreaterThan(0.5); // pulou
    expect(pos()[1]).toBeCloseTo(ground, 1); // voltou ao chão
  });

  it('o pulo respeita a gravidade configurável: mais gravidade = pulo mais baixo', () => {
    const apex = (gravityScale: number) => {
      const { input, frame, pos } = build({ gravityScale, variableJump: false });
      frame(90);
      const ground = pos()[1];
      input.handleKey('Space', true);
      let top = ground;
      for (let i = 0; i < 90; i++) {
        frame(1);
        top = Math.max(top, pos()[1]);
      }
      return top - ground;
    };
    expect(apex(1)).toBeGreaterThan(apex(3) + 0.5);
  });

  it('colide com a parede: não atravessa', () => {
    const { input, frame, pos } = build({ moveSpeed: 8 });
    frame(90);
    input.handleKey('KeyD', true);
    frame(150);
    expect(pos()[0]).toBeLessThan(4.6); // a parede ocupa x ∈ [4.5, 5.5]
  });
});

describe('Top-Down 2D na sessão', () => {
  const build = (props: Record<string, any> = {}, plane = 'xz') =>
    open(sceneWith(FLOOR, meshNode('hero', [0, 1, 0], { scale: { x: 1, y: 1.8, z: 1 }, physics: character(plane) }, { behaviors: [beh('top_down_2d_movement', props)] })));

  it('anda nos 2 eixos do plano XZ, sem cair, com o eixo Y congelado', () => {
    const { input, frame, pos } = build();
    frame(30);
    const y = pos()[1];
    input.handleKey('KeyW', true);
    input.handleKey('KeyD', true);
    frame(60);
    expect(pos()[2]).toBeLessThan(-2); // ↑/W = -Z
    expect(pos()[0]).toBeGreaterThan(2);
    expect(Math.abs(pos()[1] - y)).toBeLessThan(0.05);
  });

  it('parado não deriva (sem gravidade acumulada)', () => {
    const { frame, pos } = build();
    frame(60);
    const y = pos()[1];
    frame(240);
    expect(Math.abs(pos()[1] - y)).toBeLessThan(0.05);
  });

  it('facing = movimento: gira em torno do eixo normal (Y) para a direção andada', () => {
    const { session, input, frame } = build({ turnSpeed: 100 });
    frame(10);
    input.handleKey('KeyD', true);
    frame(30);
    const rot = session.getSimulatedTransform('hero')!.rotation;
    const yaw = Math.abs(rot[1]) > 1 ? rot[1] : 0;
    expect(Math.abs(yaw)).toBeGreaterThan(60); // virou ~-90°
    expect(Math.abs(rot[0]) + Math.abs(rot[2])).toBeLessThan(1); // sem inclinar
  });

  it('no plano XY (visto de lado) o eixo Z fica congelado', () => {
    const { input, frame, pos } = build({}, 'xy');
    frame(30);
    input.handleKey('KeyW', true);
    frame(30);
    expect(pos()[2]).toBeCloseTo(0, 5);
    expect(pos()[1]).toBeGreaterThan(1.5);
  });
});
