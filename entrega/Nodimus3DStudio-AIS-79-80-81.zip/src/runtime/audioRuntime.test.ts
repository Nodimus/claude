import { describe, expect, it, vi } from 'vitest';
import * as THREE from 'three';
import type { GameNode } from '../types/node';
import type { Voice, VoiceOptions } from '../core/sound/audioEngine';
import { createSoundHost, type SoundEngine } from './audioRuntime';
import playSound from '../logic/actions/play_sound/runtime';
import stopSound from '../logic/actions/stop_sound/runtime';
import setSoundProperties from '../logic/actions/set_sound_properties/runtime';
import type { ActionRuntimeContext } from '../logic/types';
import type { SoundHost } from './audioRuntime';
import { buildEngineApi } from './engineApi';

const flush = () => new Promise((r) => setTimeout(r, 0));

function fakeEngine() {
  const played: Array<{ options: VoiceOptions; voice: Voice & { gain: number; pitch: number; stopped: boolean } }> = [];
  const engine: SoundEngine = {
    decodeAudio: async () => ({}) as AudioBuffer,
    resumeAudio: async () => undefined,
    setListener: vi.fn(),
    playVoice: (options) => {
      const voice = {
        gain: options.gain, pitch: options.pitch, stopped: false, currentTime: 0,
        setGain(v: number) { this.gain = v; },
        setPitch(v: number) { this.pitch = v; },
        setPosition: vi.fn(),
        stop() { this.stopped = true; },
      };
      played.push({ options, voice });
      return voice as unknown as Voice;
    },
  };
  return { engine, played };
}

const node = (id: string, type: string, properties: Record<string, unknown>) => ({ id, type, name: id, properties } as unknown as GameNode);

function makeHost(nodes: GameNode[], audio = { masterVolume: 0.5, musicVolume: 1, sfxVolume: 1 }) {
  const { engine, played } = fakeEngine();
  const host = createSoundHost({
    nodes: Object.fromEntries(nodes.map((n) => [n.id, n])),
    objectOf: () => undefined,
    sourceOf: (path) => (path.startsWith('res://audio/') ? `data:audio/ogg;base64,${path}` : undefined),
    getSettings: () => audio,
    getListener: () => undefined,
    engine,
  });
  return { host, played };
}

describe('SoundHost (AIS-52)', () => {
  it('autoplay: toca com o mixer do projeto, atenuação, Doppler e efeito do nó', async () => {
    const { played } = makeHost([
      node('s1', 'AudioPlayer3D', { autoplay: true, stream: 'res://audio/a.ogg', channel: 'SFX', volumeDb: 0, attenuation: 'linear', unitSize: 3, maxDistance: 30, dopplerEffect: true, soundFX: 'echo', fxGain: 50, fxRoomSize: 50 }),
    ]);
    await flush();
    expect(played).toHaveLength(1);
    const o = played[0].options;
    expect(o.gain).toBeCloseTo(0.5, 5); // master 0.5 × sfx 1
    expect(o.spatial?.params).toMatchObject({ distanceModel: 'linear', refDistance: 3, maxDistance: 30 });
    expect(o.fx?.kind).toBe('echo');
  });

  it('sem autoplay ou sem arquivo não toca', async () => {
    const { played } = makeHost([
      node('a', 'AudioPlayer', { autoplay: false, stream: 'res://audio/a.ogg' }),
      node('b', 'AudioPlayer', { autoplay: true, stream: 'res://outro/ausente.wav' }),
    ]);
    await flush();
    expect(played).toHaveLength(0);
  });

  it('play → setProperties → stop por emissor e arquivo', async () => {
    const { host, played } = makeHost([node('e1', 'MeshInstance', {}), node('e2', 'MeshInstance', {})]);
    expect(host.play({ emitterId: 'e1', path: 'res://audio/a.ogg', volume: 0.5, pitch: 2 })).toBeNull();
    expect(host.play({ emitterId: 'e1', path: 'res://audio/b.ogg' })).toBeNull();
    expect(host.play({ emitterId: 'e2', path: 'res://audio/a.ogg' })).toBeNull();
    await flush();
    expect(played).toHaveLength(3);
    expect(played[0].options.pitch).toBe(2);
    expect(played[0].options.gain).toBeCloseTo(0.25, 5); // master 0.5 × multiplicador 0.5

    expect(host.setProperties('e1', { volume: 2, pitch: 0.5 })).toBe(2);
    expect(played[0].voice.pitch).toBe(0.5);

    expect(host.stop('e1', 'res://audio/a.ogg')).toBe(1);
    expect(played[0].voice.stopped).toBe(true);
    expect(played[1].voice.stopped).toBe(false);
    expect(host.stop('e1')).toBe(1);
    expect(host.stop('e1')).toBe(0);
    expect(played[2].voice.stopped).toBe(false);
  });

  it('erros explícitos: arquivo ausente e caminho vazio; dispose para tudo', async () => {
    const { host, played } = makeHost([node('e1', 'MeshInstance', {})]);
    expect(host.play({ emitterId: 'e1', path: '' })).toMatch(/nenhum arquivo/);
    expect(host.play({ emitterId: 'e1', path: 'res://outro/x.wav' })).toMatch(/não foi encontrado/);
    host.play({ emitterId: 'e1', path: 'res://audio/a.ogg' });
    await flush();
    host.dispose();
    expect(played[0].voice.stopped).toBe(true);
    expect(host.play({ emitterId: 'e1', path: 'res://audio/a.ogg' })).toMatch(/encerrado/);
  });

  it('o mixer vale durante o Play: mudar o master no quadro seguinte muda o ganho', async () => {
    const settings = { masterVolume: 1, musicVolume: 1, sfxVolume: 1 };
    const { engine, played } = fakeEngine();
    const host = createSoundHost({
      nodes: { m: node('m', 'AudioPlayer', { autoplay: true, stream: 'res://audio/a.ogg', channel: 'Music' }) },
      objectOf: () => undefined,
      sourceOf: () => 'data:audio/ogg;base64,AAAA',
      getSettings: () => settings,
      getListener: () => new THREE.PerspectiveCamera(),
      engine,
    });
    await flush();
    settings.masterVolume = 0.25;
    host.update(1 / 60);
    expect(played[0].voice.gain).toBeCloseTo(0.25, 5);
  });
});

describe('SoundHost: sinal finished (AIS-57)', () => {
  it('o fim natural do som chama onFinished do emissor; stop() e dispose não', async () => {
    const finished: Array<[string, string]> = [];
    const { engine, played } = fakeEngine();
    const host = createSoundHost({
      nodes: { e: node('e', 'MeshInstance', {}) },
      objectOf: () => undefined,
      sourceOf: () => 'data:audio/ogg;base64,AAAA',
      getSettings: () => undefined,
      getListener: () => undefined,
      onFinished: (id, path) => finished.push([id, path]),
      engine,
    });
    host.play({ emitterId: 'e', path: 'res://audio/a.ogg' });
    host.play({ emitterId: 'e', path: 'res://audio/b.ogg' });
    await flush();
    played[0].options.onEnded?.(); // terminou sozinho
    expect(finished).toEqual([['e', 'res://audio/a.ogg']]);
    expect(host.stop('e')).toBe(1); // só restou a b; a a já saiu da lista
    host.dispose();
    played[1].options.onEnded?.();
    expect(finished).toHaveLength(1);
  });
});

describe('Actions de som (AIS-52)', () => {
  // AIS-78c: as Actions de som falam com a `EngineApi.audio` (decisão 32); o host de áudio é injetado no EngineHost, como no runtime
  const makeCtx = (audio: SoundHost | null) => {
    const logs: Array<[string, string]> = [];
    const self = { persistentNodeId: 'self', name: 'Self', type: 'Spatial', disposed: false };
    const noop = () => undefined;
    const engine = buildEngineApi({
      instanceById: (ref: string) => (ref === 'self' ? (self as never) : undefined),
      instanceByName: () => undefined,
      variables: () => null,
      input: () => ({}) as never,
      physics: () => null,
      sceneTime: () => 0,
      emitSignal: noop,
      connectSignal: () => noop,
      onPhysicsEvent: () => noop,
      log: noop,
      commitTransform: noop,
      audio: () => audio,
    });
    const ctx = {
      engine,
      self,
      resolve: (ref: string) => (ref === '' || ref === 'self' ? self : undefined),
      log: (level: string, message: string) => logs.push([level, message]),
    } as unknown as ActionRuntimeContext;
    return { ctx, logs };
  };

  it('play_sound chama o host com o emissor resolvido; erro do host vira log', () => {
    const host = { play: vi.fn().mockReturnValueOnce(null).mockReturnValueOnce('falhou') };
    const { ctx, logs } = makeCtx(host as never);
    playSound({ sound: 'res://audio/a.ogg', target: '', volume: 0.5, pitch: 1.5, spatial: false }, ctx);
    expect(host.play).toHaveBeenCalledWith({ emitterId: 'self', path: 'res://audio/a.ogg', volume: 0.5, pitch: 1.5, spatial: false });
    playSound({ sound: 'res://audio/a.ogg', target: '', volume: 1, pitch: 1, spatial: true }, ctx);
    expect(logs).toEqual([['error', 'Play Sound: falhou']]);
  });

  it('sem host (sem Web Audio) as 3 Actions avisam em vez de ignorar', () => {
    const { ctx, logs } = makeCtx(null);
    playSound({ sound: 'x', target: '', volume: 1, pitch: 1, spatial: true }, ctx);
    stopSound({ target: '', sound: '' }, ctx);
    setSoundProperties({ target: '', volume: 1, pitch: 1 }, ctx);
    expect(logs.map((l) => l[0])).toEqual(['error', 'error', 'error']);
  });

  it('stop_sound e set_sound_properties avisam quando nada toca; alvo inexistente é erro', () => {
    const host = { stop: vi.fn().mockReturnValue(0), setProperties: vi.fn().mockReturnValue(0) };
    const { ctx, logs } = makeCtx(host as never);
    stopSound({ target: '', sound: 'res://audio/a.ogg' }, ctx);
    expect(host.stop).toHaveBeenCalledWith('self', 'res://audio/a.ogg');
    setSoundProperties({ target: '', volume: 2, pitch: 1 }, ctx);
    expect(host.setProperties).toHaveBeenCalledWith('self', { volume: 2, pitch: 1 });
    stopSound({ target: 'nao-existe', sound: '' }, ctx);
    expect(logs.map((l) => l[0])).toEqual(['warn', 'warn', 'error']);
  });
});
