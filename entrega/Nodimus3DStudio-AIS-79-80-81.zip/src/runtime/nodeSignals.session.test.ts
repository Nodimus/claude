import { describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { NodeSignalConnection } from '../types/signal';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { RuntimeSession, type RuntimeSessionOptions } from './RuntimeSession';

/** AIS-57 — conexões de sinal de nó executadas pela sessão (semântica do Godot sobre o SignalBus). */

let seq = 0;
const act = (type: string, parameters: Record<string, unknown> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[], parameters: Record<string, unknown> = {}): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters, conditions: [], actions });
const behavior = (rules: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'B', behaviorType: 'custom_rules', enabled: true, properties: {}, rules });
const conn = (signalName: string, targetNodeId: string, targetMethod: string, extra: Partial<NodeSignalConnection> = {}): NodeSignalConnection => ({ id: `c${++seq}`, signalName, targetNodeId, targetMethod, ...extra });
const node = (id: string, type: string, extra: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type, parentId: null, childrenIds: [], visible: true, locked: false, properties: {}, ...extra }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes = { ...scene.nodes };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  nodes[root.id] = { ...root, childrenIds: [...root.childrenIds, ...extra.map((n) => n.id)] };
  return { ...scene, nodes };
}

const fakeInput = () => ({
  isActionPressed: () => false,
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: () => 0,
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
});

function open(scene: SceneData, extra: Partial<RuntimeSessionOptions> = {}) {
  const diagnostics = new DiagnosticService();
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), mode: 'scene', input: fakeInput(), diagnostics, ...extra });
  session.start();
  return { session, diagnostics };
}

const codes = (d: DiagnosticService) => d.list().map((x) => x.code);

describe('conexões de sinal de nó executam sobre o SignalBus (AIS-57)', () => {
  it('o snapshot leva as conexões ao runtime', () => {
    const scene = sceneWith(node('a', 'Spatial', { signals: [conn('ready', 'b', 'show')] }), node('b', 'Spatial'));
    expect(createRuntimeSnapshot(scene).nodes.a.signals).toHaveLength(1);
  });

  it('ready chama o método nativo no alvo (hide) e aparece no histórico com origem lifecycle', () => {
    const scene = sceneWith(node('a', 'Spatial', { signals: [conn('ready', 'b', 'hide')] }), node('b', 'Spatial'));
    const { session } = open(scene);
    expect(session.scene.getInstance('b')!.visible).toBe(false);
    const h = session.signalBus.getHistory().filter((e) => e.signal === 'ready');
    expect(h).toHaveLength(1);
    expect(h[0]).toMatchObject({ source: 'a', origin: 'lifecycle', delivered: 1 });
  });

  it('o sinal emitido por um método (emit_signal do Godot) segue para as conexões do nó que o emitiu', () => {
    const scene = sceneWith(
      node('a', 'Spatial', { signals: [conn('ready', 'a', 'emit_signal', { arguments: [{ type: 'string', value: 'door_opened' }] })] }),
      node('listener', 'Spatial'),
    );
    scene.nodes.a = { ...scene.nodes.a, signals: [...(scene.nodes.a.signals ?? []), conn('door_opened', 'listener', 'hide')] };
    const { session } = open(scene);
    expect(session.scene.getInstance('listener')!.visible).toBe(false);
    expect(session.signalBus.getHistory().map((e) => e.signal)).toEqual(['ready', 'door_opened']);
  });

  it('argumentos: o sinal passa os seus e a conexão acrescenta os vinculados (binds); faltar argumento obrigatório é erro explícito', () => {
    const scene = sceneWith(
      node('a', 'Spatial', { signals: [conn('ready', 'b', 'set_visible', { arguments: [{ type: 'boolean', value: false }] }), conn('ready', 'c', 'set_visible')] }),
      node('b', 'Spatial'),
      node('c', 'Spatial'),
    );
    const { session, diagnostics } = open(scene);
    expect(session.scene.getInstance('b')!.visible).toBe(false); // set_visible(false) executou
    expect(session.scene.getInstance('c')!.visible).toBe(true); // set_visible() sem argumento: não executou
    expect(codes(diagnostics)).toEqual(['signal.bad_arguments']);
  });

  it('método inexistente: diagnóstico signal.method_not_found; o jogo segue e as outras conexões rodam', () => {
    const scene = sceneWith(node('a', 'Spatial', { signals: [conn('ready', 'b', '_on_nope'), conn('ready', 'b', 'hide')] }), node('b', 'Spatial'));
    const { session, diagnostics } = open(scene);
    expect(codes(diagnostics)).toEqual(['signal.method_not_found']);
    expect(session.scene.getInstance('b')!.visible).toBe(false);
  });

  it('alvo que não existe na cena: aviso signal.target_missing no início', () => {
    const { diagnostics } = open(sceneWith(node('a', 'Spatial', { signals: [conn('ready', 'fantasma', 'hide')] })));
    expect(codes(diagnostics)).toEqual(['signal.target_missing']);
  });

  it('método de script (registerMethod) sobrescreve o nativo e é chamado com os argumentos', () => {
    const scene = sceneWith(node('a', 'Spatial', { signals: [conn('tree_entered', 'b', 'hide', { arguments: [{ type: 'string', value: 'x' }] })] }), node('b', 'Spatial'));
    const got: unknown[][] = [];
    const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), mode: 'scene', input: fakeInput() });
    // registrado ANTES do início: o runtime da cena ainda não existe; os scripts do AIS-79 registram em `onPlayStart` (aqui, via owner de sessão)
    session.registerMethod('b', 'hide', (_t, args) => got.push([...args]), undefined, { kind: 'session', id: 'test' });
    session.start();
    expect(got).toEqual([['x']]);
    expect(session.scene.getInstance('b')!.visible).toBe(true); // o nativo não rodou
  });

  it('on_click de um nó chega ao barramento com a origem e o botão', () => {
    const scene = sceneWith(node('btn', 'Spatial', { signals: [conn('on_click', 'x', 'hide')] }), node('x', 'Spatial'));
    const { session } = open(scene);
    session.runner!.notifyClick('btn', 'left');
    session.step(0.016);
    const e = session.signalBus.getHistory().find((h) => h.signal === 'on_click');
    expect(e).toMatchObject({ source: 'btn', args: ['left'] });
    expect(session.scene.getInstance('x')!.visible).toBe(false);
  });

  it('o alvo destruído desfaz a conexão sozinho, sem erro (como um nó liberado do Godot)', () => {
    const scene = sceneWith(
      node('a', 'Spatial', { signals: [conn('ping', 'b', 'hide')] }),
      node('b', 'Spatial'),
    );
    const { session, diagnostics } = open(scene);
    session.scene.destroyInstance('b');
    session.emitSignal('ping', { source: 'a' });
    expect(codes(diagnostics)).toEqual([]);
    expect(session.signalBus.listenerCount('ping')).toBe(0);
  });

  it('oneShot dispara uma vez; deferred só no fim do quadro', () => {
    const scene = sceneWith(
      node('a', 'Spatial', { signals: [conn('ping', 'b', 'hide', { oneShot: true }), conn('ping', 'c', 'hide', { deferred: true })] }),
      node('b', 'Spatial'),
      node('c', 'Spatial'),
    );
    const { session } = open(scene);
    session.emitSignal('ping', { source: 'a' });
    expect(session.scene.getInstance('b')!.visible).toBe(false);
    expect(session.scene.getInstance('c')!.visible).toBe(true); // adiado
    session.step(0.016);
    expect(session.scene.getInstance('c')!.visible).toBe(false);
    session.scene.getInstance('b')!.visible = true;
    session.emitSignal('ping', { source: 'a' });
    expect(session.scene.getInstance('b')!.visible).toBe(true); // oneShot já se desconectou
  });

  it('emit_signal da lógica entra no barramento (global) e sinal global emitido por código dispara on_signal, sem eco', () => {
    const hideSelf = () => act('set_visible', { visible: false });
    const scene = sceneWith(
      node('a', 'Spatial', { behaviors: [behavior([rule('on_start', [act('emit_signal', { signal: 'boom' })])])] }),
      node('l1', 'Spatial', { behaviors: [behavior([rule('on_signal', [hideSelf()], { signal: 'boom' })])] }),
      node('l2', 'Spatial', { behaviors: [behavior([rule('on_signal', [hideSelf()], { signal: 'from_code' })])] }),
    );
    const { session } = open(scene);
    session.step(0.016);
    const boom = session.signalBus.getHistory().filter((e) => e.signal === 'boom');
    expect(boom).toHaveLength(1); // sem eco: a lógica não reemite o que ela mesma emitiu
    expect(boom[0]).toMatchObject({ source: undefined, origin: 'logic' });
    expect(session.scene.getInstance('l1')!.visible).toBe(false);
    expect(session.scene.getInstance('l2')!.visible).toBe(true);
    session.emitSignal('from_code');
    session.step(0.016);
    expect(session.scene.getInstance('l2')!.visible).toBe(false);
  });

  it('Stop descarta conexões e fila; o histórico segue legível', () => {
    const scene = sceneWith(node('a', 'Spatial', { signals: [conn('ready', 'b', 'hide')] }), node('b', 'Spatial'));
    const { session } = open(scene);
    const bus = session.signalBus;
    session.stop();
    expect(bus.listenerCount()).toBe(0);
    expect(bus.isDisposed).toBe(true);
    expect(bus.getHistory().length).toBeGreaterThan(0);
  });
});

describe('emissores por tempo/estado e destruição (AIS-57)', () => {
  const timer = (id: string, props: Record<string, unknown>, signals: NodeSignalConnection[]) => node(id, 'Timer', { properties: props, signals });

  it('Timer: autostart repete a cada waitTime e emite timeout com a origem', () => {
    const scene = sceneWith(timer('t', { waitTime: 0.5, oneShot: false, autostart: true }, [conn('timeout', 'b', 'hide')]), node('b', 'Spatial'));
    const { session } = open(scene);
    session.step(0.25);
    expect(session.signalBus.getHistory().filter((e) => e.signal === 'timeout')).toHaveLength(0);
    session.step(0.25);
    expect(session.scene.getInstance('b')!.visible).toBe(false);
    session.step(0.5);
    session.step(0.5);
    const fired = session.signalBus.getHistory().filter((e) => e.signal === 'timeout');
    expect(fired).toHaveLength(3);
    expect(fired[0]).toMatchObject({ source: 't', origin: 'timer' });
  });

  it('Timer: oneShot dispara uma vez; sem autostart só começa com o método start(); stop() cancela', () => {
    const scene = sceneWith(
      timer('once', { waitTime: 0.1, oneShot: true, autostart: true }, []),
      timer('manual', { waitTime: 1, oneShot: false, autostart: false }, []),
      node('ctl', 'Spatial', { signals: [conn('ready', 'manual', 'start', { arguments: [{ type: 'number', value: 0.2 }] })] }),
    );
    const { session } = open(scene);
    const count = (id: string) => session.signalBus.getHistory().filter((e) => e.signal === 'timeout' && e.source === id).length;
    for (let i = 0; i < 10; i++) session.step(0.1);
    expect(count('once')).toBe(1);
    expect(count('manual')).toBe(1); // start(0.2) trocou só a 1ª contagem (em 0,2 s); a 2ª viria em 1,2 s com o waitTime de 1 s
  });

  it('Timer: stop() para a contagem sem emitir timeout', () => {
    const scene = sceneWith(timer('t', { waitTime: 0.2, autostart: true }, []), node('ctl', 'Spatial', { signals: [conn('on_click', 't', 'stop')] }));
    const { session } = open(scene);
    session.runner!.notifyClick('ctl', 'left');
    session.step(0.016);
    for (let i = 0; i < 20; i++) session.step(0.1);
    expect(session.signalBus.getHistory().filter((e) => e.signal === 'timeout')).toHaveLength(0);
  });

  it('visibility_changed: emitido quando visible muda, por qualquer escritor, uma vez por mudança', () => {
    const scene = sceneWith(node('a', 'Spatial', { signals: [conn('visibility_changed', 'b', 'hide')] }), node('b', 'Spatial'));
    const { session } = open(scene);
    session.step(0.016);
    expect(session.signalBus.getHistory().filter((e) => e.signal === 'visibility_changed')).toHaveLength(0);
    session.scene.getInstance('a')!.visible = false; // ex.: Action/Behavior/script
    session.step(0.016);
    session.step(0.016);
    const ev = session.signalBus.getHistory().filter((e) => e.signal === 'visibility_changed' && e.source === 'a'); // 'b' também emite o dele ao ser escondido pela conexão
    expect(ev).toHaveLength(1);
    expect(ev[0]).toMatchObject({ source: 'a', args: [false] });
    expect(session.scene.getInstance('b')!.visible).toBe(false);
  });

  it('environment_changed: emitido quando as propriedades do Environment mudam no jogo', () => {
    const scene = sceneWith(node('b', 'Spatial'));
    const envId = Object.values(scene.nodes).find((n) => n.type === 'Environment')!.id;
    scene.nodes[envId] = { ...scene.nodes[envId], signals: [conn('environment_changed', 'b', 'hide')] };
    const { session } = open(scene);
    session.step(0.016);
    expect(session.signalBus.getHistory().filter((e) => e.signal === 'environment_changed')).toHaveLength(0);
    session.scene.getInstance(envId)!.properties.fogEnabled = true;
    session.step(0.016);
    expect(session.signalBus.getHistory().filter((e) => e.signal === 'environment_changed')).toHaveLength(1);
    expect(session.scene.getInstance('b')!.visible).toBe(false);
    session.step(0.016);
    expect(session.signalBus.getHistory().filter((e) => e.signal === 'environment_changed')).toHaveLength(1);
  });

  it('tree_exited: destruir um nó emite o sinal dele (filhos antes do pai); sem ouvintes não emite', () => {
    const scene = sceneWith(node('p', 'Spatial', { childrenIds: ['c'], signals: [conn('tree_exited', 'obs', 'hide')] }), node('obs', 'Spatial'));
    scene.nodes.c = node('c', 'Spatial', { parentId: 'p', signals: [conn('tree_exited', 'obs', 'hide')] });
    const { session } = open(scene);
    session.scene.destroyInstance('p');
    const exited = session.signalBus.getHistory().filter((e) => e.signal === 'tree_exited').map((e) => e.source);
    expect(exited).toEqual(['c', 'p']);
    expect(session.scene.getInstance('obs')!.visible).toBe(false);
  });

  it('tree_exited no Stop: os nós vivos saem da árvore (filhos primeiro) antes de o barramento ser descartado', () => {
    const scene = sceneWith(node('x', 'Spatial', { signals: [conn('tree_exited', 'x', 'hide')] }));
    const { session } = open(scene);
    const bus = session.signalBus;
    session.stop();
    expect(bus.getHistory().some((e) => e.signal === 'tree_exited' && e.source === 'x')).toBe(true);
  });
});
