import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { ensureRapier } from '../core/physics/rapierInit';
import { RuntimeSession } from './RuntimeSession';

/** AIS-61 §4 — nó preso a osso anda com a animação: não tem corpo físico (um corpo ficaria parado na pose de autoria), com motivo. */

beforeAll(async () => {
  await ensureRapier();
});

const PHYSICS = { enabled: true, bodyMode: 'static', shape: 'auto' };
const node = (id: string, props: Record<string, unknown>, extra: Record<string, unknown> = {}): GameNode =>
  ({ ...extra, id, name: id, type: 'MeshInstance', parentId: null, childrenIds: [], visible: true, locked: false, properties: { meshType: 'CubeMesh', position: { x: 0, y: 1, z: 0 }, ...props } }) as unknown as GameNode;

function play(...extra: GameNode[]) {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: [] } as GameNode };
  for (const n of extra) {
    nodes[n.id] = { ...n, parentId: root.id } as GameNode;
    nodes[root.id].childrenIds.push(n.id);
  }
  const diagnostics = new DiagnosticService();
  const logs: { level: string; code?: string; message: string }[] = [];
  const session = new RuntimeSession({
    snapshot: createRuntimeSnapshot({ ...scene, nodes } as unknown as SceneData),
    diagnostics,
    input: { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never,
    onLog: (e) => logs.push(e as never),
  });
  session.start();
  return { session, diagnostics, logs };
}

describe('colisão de nó preso a osso', () => {
  it('com `attachment` autoral e física ligada: sem corpo e com o diagnóstico physics.attached_to_bone', () => {
    const { session, diagnostics } = play(node('sword', { physics: PHYSICS, attachment: { bone: 'mixamorigRightHand' } }), node('floor', { physics: PHYSICS }));
    expect(session.physics!.has('sword')).toBe(false);
    expect(session.physics!.has('floor')).toBe(true);
    expect(diagnostics.list({ ephemeral: true }).find((d) => d.code === 'physics.attached_to_bone')?.nodeId).toBe('sword');
    session.dispose();
  });

  it('sem attachment, o corpo existe como sempre', () => {
    const { session, diagnostics } = play(node('box', { physics: PHYSICS }));
    expect(session.physics!.has('box')).toBe(true);
    expect(diagnostics.list({ ephemeral: true }).map((d) => d.code)).not.toContain('physics.attached_to_bone');
    session.dispose();
  });

  it('attach_to_bone em jogo (Action) avisa e desliga o corpo que o nó já tinha', () => {
    const rules = [{ id: 'b1', name: 'Regras', behaviorType: 'custom_rules', enabled: true, properties: {}, rules: [{ id: 'r1', eventType: 'on_start', parameters: {}, conditions: [], actions: [{ id: 'a1', type: 'attach_to_bone', parameters: { holder: '', bone: 'Hand' } }] }] }];
    const { session, logs } = play(node('sword', { physics: PHYSICS }, { behaviors: rules }));
    session.step(1 / 60);
    expect(session.attachments.get('sword')).toEqual({ holder: null, bone: 'Hand' });
    expect(logs.find((l) => l.code === 'physics.attached_to_bone')?.level).toBe('warn');
    expect(session.physics!.isEnabled('sword')).toBe(false);
    session.dispose();
  });
});
