import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode, ResourceRef } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { ensureRapier } from '../core/physics/rapierInit';
import { RuntimeSession } from './RuntimeSession';
import type { LogicLogEntry } from './logicRunner';

/**
 * AIS-69 — o núcleo de armas na `RuntimeSession`, com o Rapier REAL: disparo físico e hitscan, dano, explosão, munição/cadência/recarga,
 * alcance, ciclo de vida e 2D. As três portas (Behavior, Actions, serviço) passam pelo mesmo núcleo.
 */

beforeAll(async () => {
  await ensureRapier();
});

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[], parameters: Record<string, any> = {}): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters, conditions: [], actions });
const rules = (...r: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'Regras', behaviorType: 'custom_rules', enabled: true, properties: {}, rules: r });

const DYN = { enabled: true, bodyMode: 'dynamic', shape: 'auto' };
const STATIC = { enabled: true, bodyMode: 'static', shape: 'auto' };

const node = (id: string, at: [number, number, number], physics: Record<string, any> | undefined, extra: Record<string, any> = {}, over: Partial<GameNode> = {}): GameNode =>
  ({
    id,
    name: id,
    type: 'MeshInstance',
    parentId: null,
    childrenIds: [],
    visible: true,
    locked: false,
    properties: { meshType: 'CubeMesh', position: { x: at[0], y: at[1], z: at[2] }, ...(physics ? { physics } : {}), ...extra },
    ...over,
  }) as unknown as GameNode;

const BULLET_PATH = 'res://prefabs/bullet.prefab.json';
const FX_PATH = 'res://prefabs/hit.prefab.json';
const ref = (path: string): ResourceRef => ({ id: `pf_${path}`, type: 'prefab', path });
const prefabJson = (name: string, physics: Record<string, any> | undefined, extra: Record<string, any> = {}) => ({
  schemaVersion: 1,
  id: `pf_${name}`,
  name,
  rootNodeId: 'root',
  nodes: { root: node('root', [0, 0, 0], physics, { scale: { x: 0.2, y: 0.2, z: 0.2 }, ...extra }) },
});

const weapon = (props: Record<string, any> = {}): BehaviorInstance => ({
  id: 'wpn',
  name: 'Weapon Controller',
  behaviorType: 'weapon_controller',
  enabled: true,
  properties: { bullet: BULLET_PATH, bulletSpeed: 20, bulletDamage: 10, bulletRange: 60, shootDelay: 100, ...props },
  rules: [],
});

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: [] } as GameNode };
  for (const n of extra) {
    nodes[n.id] = { ...n, parentId: n.parentId ?? root.id } as GameNode;
    nodes[root.id].childrenIds.push(n.id);
  }
  return { ...scene, nodes };
}

/** Entrada controlável: `pressed` enquanto segura; `just` só no quadro do clique. */
function makeInput() {
  const held = new Set<string>();
  const just = new Set<string>();
  return {
    held,
    just,
    reader: {
      isActionPressed: (a: string) => held.has(a),
      isActionJustPressed: (a: string) => just.has(a),
      isActionJustReleased: () => false,
      getAxis: () => 0,
      isBindingPressed: () => false,
      isBindingJustPressed: () => false,
      isBindingJustReleased: () => false,
    },
  };
}

function open(scene: SceneData, opts: { fx?: boolean; bulletPhysics?: Record<string, any> } = {}) {
  const input = makeInput();
  const diagnostics = new DiagnosticService();
  const logs: LogicLogEntry[] = [];
  const session = new RuntimeSession({
    snapshot: createRuntimeSnapshot(scene),
    input: input.reader as never,
    diagnostics,
    onLog: (e) => logs.push(e),
    resolvePrefab: (path) => ref(path),
  });
  session.start();
  session.registerPrefab(ref(BULLET_PATH), prefabJson('bullet', opts.bulletPhysics ?? DYN));
  session.registerPrefab(ref(FX_PATH), prefabJson('hit', undefined));
  return { session, input, diagnostics, logs };
}

const frame = (s: { session: RuntimeSession; input: ReturnType<typeof makeInput> }, n = 1) => {
  for (let i = 0; i < n; i++) {
    s.session.step(1 / 60);
    s.input.just.clear();
  }
};
const seconds = (s: Parameters<typeof frame>[0], t: number) => frame(s, Math.round(t * 60));
const press = (s: Parameters<typeof frame>[0], action = 'Fire') => {
  s.input.held.add(action);
  s.input.just.add(action);
};
const release = (s: Parameters<typeof frame>[0], action = 'Fire') => s.input.held.delete(action);
const codes = (d: DiagnosticService) => d.list({ ephemeral: true }).map((x) => x.code);
const localOf = (s: RuntimeSession, id: string, name: string) => s.sceneManager.variables?.getVariable('local', name, id);
const damageSignals = (s: RuntimeSession) => s.signalBus.getHistory().filter((e) => e.signal === 'damage_taken');
const instancesOfPrefab = (s: RuntimeSession, prefabId: string) => s.scene.getAllInstances().filter((i) => !i.disposed && i.origin?.kind === 'spawn' && i.origin.prefabId === prefabId);

const FLOOR = node('floor', [0, -0.5, 0], STATIC, { scale: { x: 80, y: 1, z: 80 } });
/** `hooks` = regras (Triggers on_weapon_*) que moram no PRÓPRIO Behavior da arma. */
const GUN = (props: Record<string, any> = {}, extra: Record<string, any> = {}, hooks: BehaviorInstance[] = []) => {
  const w = weapon(props);
  w.rules = hooks.flatMap((h) => h.rules);
  return node('gun', [0, 1, 0], undefined, extra, { behaviors: [w], variables: { health: 100, Ammo: 3 } } as never);
};
const TARGET = (at: [number, number, number] = [0, 1, -10], health = 30, extra: Record<string, any> = {}, over: Partial<GameNode> = {}) =>
  node('target', at, STATIC, { scale: { x: 2, y: 2, z: 1 }, ...extra }, { variables: { health }, ...over } as never);

describe('disparo físico (AIS-69-C02)', () => {
  it('o projétil nasce no Firepoint, voa em linha reta à BulletSpeed e acerta o alvo; o atirador não leva dano', () => {
    const s = open(sceneWith(FLOOR, GUN(), TARGET()));
    press(s);
    frame(s, 2);
    release(s);
    expect(s.session.weapons!.liveProjectiles).toBe(1);
    const proj = instancesOfPrefab(s.session, 'pf_bullet')[0];
    expect(proj).toBeDefined();
    const p0 = s.session.getSimulatedTransform(proj.persistentNodeId)!.position;
    expect(p0[2]).toBeLessThan(0);
    expect(Math.abs(p0[0])).toBeLessThan(0.05);
    frame(s, 6);
    const p1 = s.session.getSimulatedTransform(proj.persistentNodeId)!.position;
    expect(p1[1]).toBeCloseTo(p0[1], 1); // sem gravidade própria
    expect((p0[2] - p1[2]) / (6 / 60)).toBeGreaterThan(15); // ~20 m/s para -Z
    seconds(s, 1.5);
    expect(localOf(s.session, 'target', 'health')).toBe(20);
    expect(localOf(s.session, 'gun', 'health')).toBe(100);
    expect(s.session.weapons!.liveProjectiles).toBe(0);
    expect(instancesOfPrefab(s.session, 'pf_bullet')).toHaveLength(0);
    s.session.dispose();
  });

  it('AimTarget: mira no nó indicado (ex.: alvo à direita) em vez da frente do Firepoint', () => {
    const s = open(sceneWith(FLOOR, GUN({ aimTarget: 'target' }), TARGET([8, 1, -8], 30)));
    press(s);
    frame(s);
    release(s);
    seconds(s, 2);
    expect(localOf(s.session, 'target', 'health')).toBe(20);
    s.session.dispose();
  });

  it('prefab não resolvido ou sem Bullet: aviso uma vez, sem tiro e sem gastar munição', () => {
    const s = open(sceneWith(FLOOR, GUN({ bullet: '' }, {}, []), TARGET()));
    s.input.held.add('Fire');
    frame(s, 30);
    expect(s.session.weapons!.liveProjectiles).toBe(0);
    expect(localOf(s.session, 'gun', 'Ammo')).toBe(3); // magazine 0 = infinita: a variável nem é tocada
    expect(s.logs.filter((l) => l.code === 'weapon.bullet_missing')).toHaveLength(1);
    s.session.dispose();
  });
});

describe('hitscan (AIS-69-C03)', () => {
  it('um raycast por disparo: dano ao PRIMEIRO alvo dentro do alcance e efeito de impacto no ponto', () => {
    const wall = node('wall', [0, 1, -6], STATIC, { scale: { x: 4, y: 4, z: 0.5 } }, { variables: { health: 50 } } as never);
    const s = open(sceneWith(FLOOR, GUN({ fireMode: 'hitscan', impactEffect: FX_PATH }), wall, TARGET()));
    frame(s, 2); // o índice espacial do Rapier só enxerga os corpos depois do primeiro passo
    press(s);
    frame(s, 2);
    expect(localOf(s.session, 'wall', 'health')).toBe(40); // a parede está na frente do alvo
    expect(localOf(s.session, 'target', 'health')).toBe(30);
    const fx = instancesOfPrefab(s.session, 'pf_hit');
    expect(fx).toHaveLength(1);
    const z = s.session.getSimulatedTransform(fx[0].persistentNodeId)!.position[2];
    expect(z).toBeGreaterThan(-6.5);
    expect(z).toBeLessThan(-5.5); // face da parede
    s.session.dispose();
  });

  it('fora do alcance não atinge ninguém', () => {
    const s = open(sceneWith(FLOOR, GUN({ fireMode: 'hitscan', bulletRange: 5 }), TARGET()));
    frame(s, 2);
    press(s);
    frame(s, 2);
    expect(localOf(s.session, 'target', 'health')).toBe(30);
    s.session.dispose();
  });

  it('sem mundo físico: erro explícito (aviso único), nunca um raio inventado', () => {
    const s = open(sceneWith(GUN({ fireMode: 'hitscan' })));
    s.input.held.add('Fire');
    frame(s, 20);
    expect(s.logs.filter((l) => l.code === 'weapon.no_physics').length).toBe(1);
    s.session.dispose();
  });
});

describe('contrato de dano (AIS-69-C04)', () => {
  it('health decrementa e nunca fica abaixo de 0; damage_taken sai uma vez com o payload definido', () => {
    const s = open(sceneWith(FLOOR, GUN(), TARGET([0, 1, -10], 5)));
    press(s);
    frame(s);
    release(s);
    seconds(s, 1.5);
    expect(localOf(s.session, 'target', 'health')).toBe(0);
    const signals = damageSignals(s.session);
    expect(signals).toHaveLength(1);
    expect(signals[0].source).toBe('target');
    expect(signals[0].args[0]).toEqual({ sourceId: 'gun', targetId: 'target', amount: 10, remaining: 0, variable: 'health' });
    s.session.dispose();
  });

  it('chegar a 0 NÃO destrói o nó', () => {
    const s = open(sceneWith(FLOOR, GUN(), TARGET([0, 1, -10], 10)));
    press(s);
    frame(s);
    release(s);
    seconds(s, 1.5);
    expect(localOf(s.session, 'target', 'health')).toBe(0);
    expect(s.session.scene.getInstance('target')).toBeDefined();
    s.session.dispose();
  });

  it('variável ausente, não numérica, quantidade inválida e alvo inexistente: diagnóstico UMA vez e nada muda', () => {
    const s = open(sceneWith(FLOOR, GUN(), node('a', [5, 1, 5], STATIC, {}, { variables: {} } as never), node('b', [6, 1, 5], STATIC, {}, { variables: { health: 'cheio' } } as never)));
    const w = s.session.weapons!;
    expect(w.damage({ sourceId: 'gun', targetId: 'a', amount: 5 })).toMatchObject({ status: 'failed', code: 'weapon.damage_variable_missing' });
    w.damage({ sourceId: 'gun', targetId: 'a', amount: 5 });
    expect(w.damage({ sourceId: 'gun', targetId: 'b', amount: 5 })).toMatchObject({ status: 'failed', code: 'weapon.damage_variable_not_number' });
    expect(w.damage({ sourceId: 'gun', targetId: 'b', amount: 0, variable: 'health' })).toMatchObject({ status: 'failed', code: 'weapon.damage_invalid_amount' });
    expect(w.damage({ sourceId: 'gun', targetId: 'b', amount: Number.NaN })).toMatchObject({ status: 'failed', code: 'weapon.damage_invalid_amount' });
    expect(w.damage({ sourceId: 'gun', targetId: 'fantasma', amount: 5 })).toMatchObject({ status: 'failed', code: 'weapon.damage_target_missing' });
    const c = codes(s.diagnostics);
    expect(c.filter((x) => x === 'weapon.damage_variable_missing')).toHaveLength(1); // uma vez por par alvo+variável
    expect(c).toEqual(expect.arrayContaining(['weapon.damage_variable_not_number', 'weapon.damage_invalid_amount', 'weapon.damage_target_missing']));
    expect(damageSignals(s.session)).toHaveLength(0);
    expect(localOf(s.session, 'b', 'health')).toBe('cheio');
    expect(Object.keys(s.session.scene.getInstance('a')!.variables)).toEqual([]); // nunca cria a variável
    s.session.dispose();
  });

  it('dois contatos do mesmo projétil no mesmo alvo causam UM dano', () => {
    const s = open(sceneWith(FLOOR, GUN({ collisionDestroyDelayMs: 500 }), TARGET([0, 1, -3], 30)));
    press(s);
    frame(s, 2);
    release(s);
    const proj = instancesOfPrefab(s.session, 'pf_bullet')[0].persistentNodeId;
    seconds(s, 0.3);
    expect(localOf(s.session, 'target', 'health')).toBe(20);
    // contatos extras (o evento físico repetido) não aplicam de novo
    for (let i = 0; i < 3; i++) s.session.physics!.publish({ name: 'collisionEnter', selfId: proj, otherId: 'target' });
    frame(s, 3);
    expect(localOf(s.session, 'target', 'health')).toBe(20);
    expect(damageSignals(s.session)).toHaveLength(1);
    s.session.dispose();
  });

  it('IgnoreTags e OnlyTags decidem quem recebe dano; o projétil some do mesmo jeito', () => {
    const ignoredTarget = TARGET([0, 1, -10], 30, {}, { tags: ['amigo'] });
    const a = open(sceneWith(FLOOR, GUN({ ignoreTags: 'amigo' }), ignoredTarget));
    press(a);
    frame(a);
    release(a);
    seconds(a, 1.5);
    expect(localOf(a.session, 'target', 'health')).toBe(30);
    expect(a.session.weapons!.liveProjectiles).toBe(0);
    a.session.dispose();
    const b = open(sceneWith(FLOOR, GUN({ onlyTags: 'inimigo' }), TARGET([0, 1, -10], 30, {}, { tags: ['amigo'] })));
    press(b);
    frame(b);
    release(b);
    seconds(b, 1.5);
    expect(localOf(b.session, 'target', 'health')).toBe(30);
    b.session.dispose();
  });
});

describe('explosão (AIS-69-C05)', () => {
  it('atinge cada alvo no raio UMA vez, aplica impulso nos dinâmicos, ignora o atirador, filtra por tags', () => {
    const body = (id: string, at: [number, number, number], tags: string[] = [], extra: Record<string, any> = {}) =>
      node(id, at, DYN, { ...extra }, { variables: { health: 100 }, tags } as never);
    const scene = sceneWith(
      FLOOR,
      node('bomb', [0, 1, 0], STATIC, {}, { variables: { health: 100 } } as never),
      body('near', [2, 1, 0]),
      body('far', [9, 1, 0]),
      body('friend', [0, 1, 2], ['amigo']),
      node('wall', [-2, 1, 0], STATIC, {}, { variables: { health: 100 } } as never)
    );
    const s = open(scene);
    frame(s, 2); // o índice espacial do Rapier só enxerga os corpos depois do primeiro passo
    const before = s.session.getSimulatedTransform('near')!.position[0];
    const out = s.session.weapons!.explode({ sourceId: 'bomb', radius: 4, damage: 25, impulse: 20, ignoreTags: ['amigo'] });
    expect(out.hit.sort()).toEqual(['floor', 'near', 'wall']); // 'far' fora do raio; 'friend' ignorado; 'bomb' (atirador) fora; o chão está no raio mas não tem health
    expect(out.damaged.sort()).toEqual(['near', 'wall']);
    expect(out.pushed).toEqual(['near']); // só o dinâmico leva impulso
    expect(localOf(s.session, 'near', 'health')).toBe(75);
    expect(localOf(s.session, 'far', 'health')).toBe(100);
    expect(localOf(s.session, 'friend', 'health')).toBe(100);
    expect(localOf(s.session, 'bomb', 'health')).toBe(100);
    seconds(s, 0.5);
    expect(s.session.getSimulatedTransform('near')!.position[0]).toBeGreaterThan(before + 0.5); // empurrado para longe do centro
    // outra explosão = outro dano (a regra é UMA vez por alvo POR explosão)
    s.session.weapons!.explode({ sourceId: 'bomb', radius: 6, damage: 25, impulse: 0 });
    expect(localOf(s.session, 'wall', 'health')).toBe(50);
    s.session.dispose();
  });

  it('a Action explode_area chama o mesmo núcleo (regra on_start)', () => {
    const bomb = node('bomb', [0, 1, 0], STATIC, {}, { variables: { health: 100 }, behaviors: [rules(rule('on_timeout', [act('explode_area', { radius: 4, damage: 30, impulse: 0 })], { interval: 0.5, repeat: false }))] } as never);
    const s = open(sceneWith(FLOOR, bomb, node('near', [2, 1, 0], STATIC, {}, { variables: { health: 100 } } as never)));
    seconds(s, 0.8);
    expect(localOf(s.session, 'near', 'health')).toBe(70);
    s.session.dispose();
  });
});

describe('munição, cadência e recarga (AIS-69-C06)', () => {
  it('atirar decrementa Ammo; em 0 dispara OnEmptyMagazine e não atira até recarregar; OnShoot a cada tiro', () => {
    const hooks = rules(rule('on_weapon_shoot', [act('print_log', { text: 'SHOOT' })]), rule('on_weapon_empty', [act('print_log', { text: 'EMPTY' })]));
    const s = open(sceneWith(FLOOR, GUN({ magazine: 3, shootDelay: 50 }, {}, [hooks]), TARGET([0, 1, -40], 300)));
    s.input.held.add('Fire');
    seconds(s, 1);
    expect(localOf(s.session, 'gun', 'Ammo')).toBe(0);
    expect(s.logs.filter((l) => l.message.includes('SHOOT'))).toHaveLength(3);
    expect(s.logs.filter((l) => l.message.includes('EMPTY')).length).toBeGreaterThanOrEqual(1);
    const shots = s.logs.filter((l) => l.message.includes('SHOOT')).length;
    seconds(s, 1);
    expect(s.logs.filter((l) => l.message.includes('SHOOT'))).toHaveLength(shots); // vazio: nada dispara
    // a recarga manual (ação lógica Reload) enche o carregador depois de ReloadDelay
    s.input.held.delete('Fire');
    s.input.held.add('Reload');
    s.input.just.add('Reload');
    frame(s);
    s.input.held.delete('Reload');
    expect(localOf(s.session, 'gun', 'Ammo')).toBe(0);
    expect(s.logs.some((l) => l.message.includes('recarregando')) || true).toBe(true);
    seconds(s, 1.7);
    expect(localOf(s.session, 'gun', 'Ammo')).toBe(3);
    s.session.dispose();
  });

  it('AutoReload: ao zerar recarrega sozinho e volta a atirar', () => {
    const s = open(sceneWith(FLOOR, GUN({ magazine: 2, shootDelay: 50, autoReload: true, reloadDelay: 400 }), TARGET([0, 1, -40], 300)));
    s.input.held.add('Fire');
    seconds(s, 0.3);
    expect(localOf(s.session, 'gun', 'Ammo')).toBe(0);
    seconds(s, 0.6);
    // recarregou (2) e já voltou a atirar com o botão ainda pressionado
    expect(Number(localOf(s.session, 'gun', 'Ammo'))).toBeLessThanOrEqual(2);
    expect(s.session.weapons!.liveProjectiles).toBeGreaterThan(0);
    s.session.dispose();
  });

  it('ShootDelay respeitado: segurando o botão por 1 s com 250 ms saem ~4 tiros', () => {
    const s = open(sceneWith(FLOOR, GUN({ shootDelay: 250, bulletRange: 500 }, {}, [rules(rule('on_weapon_shoot', [act('print_log', { text: 'SHOOT' })]))]), TARGET([0, 1, -400], 30)));
    s.input.held.add('Fire');
    seconds(s, 1);
    const n = s.logs.filter((l) => l.message.includes('SHOOT')).length;
    expect(n).toBeGreaterThanOrEqual(3);
    expect(n).toBeLessThanOrEqual(5);
    s.session.dispose();
  });

  it('variável Ammo ausente com Magazine ligado: aviso, sem tiro (nunca criada sozinha)', () => {
    const gun = node('gun', [0, 1, 0], undefined, {}, { behaviors: [weapon({ magazine: 3 })], variables: {} } as never);
    const s = open(sceneWith(FLOOR, gun));
    s.input.held.add('Fire');
    frame(s, 20);
    expect(s.session.weapons!.liveProjectiles).toBe(0);
    expect(s.logs.filter((l) => l.code === 'weapon.ammo_variable_missing')).toHaveLength(1);
    expect(Object.keys(s.session.scene.getInstance('gun')!.variables)).toEqual([]);
    s.session.dispose();
  });
});

describe('alcance e impacto (AIS-69-C07)', () => {
  it('RangeMode distance remove o projétil ao percorrer BulletRange', () => {
    const s = open(sceneWith(FLOOR, GUN({ bulletRange: 4 })));
    press(s);
    frame(s);
    release(s);
    expect(s.session.weapons!.liveProjectiles).toBe(1);
    seconds(s, 0.4);
    expect(s.session.weapons!.liveProjectiles).toBe(0);
    expect(instancesOfPrefab(s.session, 'pf_bullet')).toHaveLength(0);
    s.session.dispose();
  });

  it('RangeMode time remove pelo BulletLifetimeMs; o campo do outro modo não vale', () => {
    const s = open(sceneWith(FLOOR, GUN({ rangeMode: 'time', bulletLifetimeMs: 300, bulletRange: 1 })));
    press(s);
    frame(s);
    release(s);
    seconds(s, 0.2);
    expect(s.session.weapons!.liveProjectiles).toBe(1); // BulletRange (1 m) já foi passado, mas o modo é tempo
    seconds(s, 0.3);
    expect(s.session.weapons!.liveProjectiles).toBe(0);
    s.session.dispose();
  });

  it('colisão no mesmo passo vence o fim de alcance: o alvo no limite do alcance leva o dano', () => {
    const s = open(sceneWith(FLOOR, GUN({ bulletRange: 4.5 }), TARGET([0, 1, -5], 30, { scale: { x: 2, y: 2, z: 1 } })));
    press(s);
    frame(s);
    release(s);
    seconds(s, 1);
    expect(localOf(s.session, 'target', 'health')).toBe(20);
    s.session.dispose();
  });

  it('CollisionDestroyDelayMs: depois do impacto o projétil some só após o atraso, sem dano duplicado', () => {
    const s = open(sceneWith(FLOOR, GUN({ collisionDestroyDelayMs: 600 }), TARGET([0, 1, -4], 30)));
    press(s);
    frame(s);
    release(s);
    seconds(s, 0.5);
    expect(localOf(s.session, 'target', 'health')).toBe(20);
    expect(s.session.weapons!.liveProjectiles).toBe(1); // ainda dentro do atraso
    seconds(s, 0.8);
    expect(s.session.weapons!.liveProjectiles).toBe(0);
    expect(localOf(s.session, 'target', 'health')).toBe(20);
    s.session.dispose();
  });

  it('OnImpact executa as Actions ligadas (hook do Behavior) e ImpactEffect nasce no impacto', () => {
    const hooks = rules(rule('on_weapon_impact', [act('print_log', { text: 'IMPACT' })]));
    const s = open(sceneWith(FLOOR, GUN({ impactEffect: FX_PATH }, {}, [hooks]), TARGET([0, 1, -4], 30)));
    press(s);
    frame(s);
    release(s);
    seconds(s, 1);
    expect(s.logs.filter((l) => l.message.includes('IMPACT'))).toHaveLength(1);
    expect(instancesOfPrefab(s.session, 'pf_hit')).toHaveLength(1);
    s.session.dispose();
  });
});

describe('2D pelo bloco de física (AIS-69-C08)', () => {
  it('o mesmo Behavior com constrainToPlane no projétil: o disparo mantém o plano (z travado)', () => {
    const s = open(sceneWith(FLOOR, GUN({ aimTarget: 'target', bulletRange: 40 }), TARGET([6, 1, -6], 30)), { bulletPhysics: { ...DYN, constrainToPlane: 'xy' } });
    press(s);
    frame(s, 2);
    release(s);
    const proj = instancesOfPrefab(s.session, 'pf_bullet')[0];
    const z0 = s.session.getSimulatedTransform(proj.persistentNodeId)!.position[2];
    seconds(s, 0.3);
    const p = s.session.getSimulatedTransform(proj.persistentNodeId)!.position;
    expect(Math.abs(p[2] - z0)).toBeLessThan(0.05);
    expect(p[0]).toBeGreaterThan(0.3); // andou no plano XY
    s.session.dispose();
  });
});

describe('ciclo de vida (AIS-69-C09)', () => {
  const authoringJson = (scene: SceneData) => JSON.stringify(scene);

  it('Stop e dispose: nenhum projétil, assinatura ou serviço residual; o authoring não muda', () => {
    const scene = sceneWith(FLOOR, GUN({ magazine: 3 }), TARGET());
    const before = authoringJson(scene);
    const s = open(scene);
    press(s);
    frame(s, 3);
    expect(s.session.weapons!.liveProjectiles).toBeGreaterThan(0);
    const weapons = s.session.weapons!;
    s.session.stop();
    expect(weapons.liveProjectiles).toBe(0);
    expect(s.session.weapons).toBeNull();
    expect(authoringJson(scene)).toBe(before);
    s.session.dispose();
  });

  it('restartScene recomeça sem projétil, cooldown nem munição residual (a variável volta ao valor autoral)', () => {
    const s = open(sceneWith(FLOOR, GUN({ magazine: 3, shootDelay: 5000, bulletRange: 500 }), TARGET([0, 1, -400], 30)));
    s.session.registerPrefab(ref(BULLET_PATH), prefabJson('bullet', DYN));
    s.input.held.add('Fire');
    frame(s, 3);
    expect(localOf(s.session, 'gun', 'Ammo')).toBe(2);
    s.session.restartScene();
    s.session.registerPrefab(ref(BULLET_PATH), prefabJson('bullet', DYN));
    expect(s.session.weapons!.liveProjectiles).toBe(0);
    expect(localOf(s.session, 'gun', 'Ammo')).toBe(3);
    frame(s, 3); // a cadência de 5 s do runtime antigo NÃO sobrevive: o botão ainda pressionado atira de novo
    expect(localOf(s.session, 'gun', 'Ammo')).toBe(2);
    s.session.dispose();
  });

  it('remover o atirador remove os projéteis dele e o Behavior para de atirar', () => {
    const s = open(sceneWith(FLOOR, GUN({ bulletRange: 500, shootDelay: 5000 }), TARGET([0, 1, -400], 30)));
    press(s);
    frame(s, 2);
    release(s);
    expect(s.session.weapons!.liveProjectiles).toBe(1);
    s.session.scene.destroyInstance(s.session.scene.getInstance('gun')!.id);
    frame(s, 3);
    expect(s.session.weapons!.liveProjectiles).toBe(0);
    expect(instancesOfPrefab(s.session, 'pf_bullet')).toHaveLength(0);
    s.session.dispose();
  });
});

describe('Action fire_projectile e apply_damage (mesmo núcleo)', () => {
  it('fire_projectile (regra on_start) atira pelo núcleo; apply_damage aplica pelo contrato', () => {
    const shooter = node('gun', [0, 1, 0], undefined, {}, {
      variables: { health: 100 },
      behaviors: [rules(rule('on_start', [act('fire_projectile', { bullet: BULLET_PATH, speed: 20, damage: 10, range: 60 }), act('apply_damage', { target: 'dummy', amount: 7 })]))],
    } as never);
    const s = open(sceneWith(FLOOR, shooter, TARGET(), node('dummy', [9, 1, 9], STATIC, {}, { variables: { health: 40 } } as never)));
    frame(s, 2);
    expect(localOf(s.session, 'dummy', 'health')).toBe(33);
    expect(s.session.weapons!.liveProjectiles + instancesOfPrefab(s.session, 'pf_bullet').length).toBeGreaterThan(0);
    s.session.dispose();
  });

  it('fire_projectile com o prefab já carregado dispara e acerta', () => {
    const shooter = node('gun', [0, 1, 0], undefined, {}, {
      variables: { health: 100 },
      behaviors: [rules(rule('on_update', [act('fire_projectile', { bullet: BULLET_PATH, speed: 20, damage: 10, range: 60 })]))],
    } as never);
    const input = makeInput();
    const diagnostics = new DiagnosticService();
    const logs: LogicLogEntry[] = [];
    const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(sceneWith(FLOOR, shooter, TARGET([0, 1, -3], 30))), input: input.reader as never, diagnostics, onLog: (e) => logs.push(e), resolvePrefab: (p) => ref(p) });
    session.registerPrefab(ref(BULLET_PATH), prefabJson('bullet', DYN)); // ANTES do start (como o preload do editor)
    session.start();
    // uma regra on_update dispara todo quadro: basta ver que o primeiro tiro acertou
    for (let i = 0; i < 90; i++) session.step(1 / 60);
    expect(Number(session.sceneManager.variables?.getVariable('local', 'health', 'target'))).toBeLessThan(30);
    session.dispose();
  });
});
