import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { OVERLAY_FONT_CHARSET } from './overlayHud';

/** AIS-79: o atlas do HUD é pré-gerado (a CSP sem `unsafe-eval` impede o gerador MSDF em runtime). Este teste pega charset e atlas dessincronizados. */
describe('atlas MSDF pré-gerado do HUD', () => {
  const families = JSON.parse(readFileSync('public/fonts/overlay-ui.msdf.json', 'utf8')) as Record<string, Record<string, { chars: { char: string }[]; pages: string[] }>>;

  it('cobre todo o charset pt-BR em cada peso e embute a textura', () => {
    const weights = Object.values(families).flatMap((f) => Object.values(f));
    expect(weights.length).toBeGreaterThanOrEqual(2);
    for (const font of weights) {
      const have = new Set(font.chars.map((c) => c.char));
      const missing = [...OVERLAY_FONT_CHARSET].filter((ch) => !have.has(ch));
      expect(missing).toEqual([]);
      expect(font.pages[0]).toMatch(/^data:image\/png;base64,/);
    }
  });
});
