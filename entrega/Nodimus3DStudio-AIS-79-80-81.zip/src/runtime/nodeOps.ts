import * as THREE from 'three';
import type { RuntimeInstance } from './RuntimeScene';

/**
 * AIS-78c (execução 3, decisão 32) — operações de nó que precisam do objeto vivo (Three). Ficam AQUI, no runtime, e entram na `EngineApi` por
 * `EngineHost.nodeOps`: o `engineApi.ts` continua puro e `src/logic/**` nunca importa `three`. Equivalem, em Godot, aos métodos do próprio
 * `Node3D` (`look_at`, `global_position`) e à API de `Material` (`emission`): o script pede ao motor, não toca no objeto de renderização.
 */
export interface NodeOps {
  /** Vira o nó para um ponto MUNDIAL (como `Node3D.look_at`); grava a rotação (graus, XYZ) na instância. `false` = nó sem objeto vivo. */
  lookAt(instance: RuntimeInstance, point: { x: number; y: number; z: number }): boolean;
  /** Posição MUNDIAL do nó (como `Node3D.global_position`); `null` = nó sem objeto vivo. */
  worldPosition(instance: RuntimeInstance): { x: number; y: number; z: number } | null;
  /** Cor/intensidade emissiva dos materiais do nó (só no objeto vivo). Devolve quantos materiais foram alterados. */
  setEmissive(instance: RuntimeInstance, color: string, intensity: number): number;
}

export const nodeOps: NodeOps = {
  lookAt(instance, point) {
    const object = instance.object;
    if (!object) return false;
    object.updateWorldMatrix(true, false);
    object.lookAt(new THREE.Vector3(point.x, point.y, point.z));
    const e = object.rotation;
    instance.transform.rotation = [THREE.MathUtils.radToDeg(e.x), THREE.MathUtils.radToDeg(e.y), THREE.MathUtils.radToDeg(e.z)];
    return true;
  },
  worldPosition(instance) {
    const object = instance.object;
    if (!object) return null;
    object.updateWorldMatrix(true, false);
    const p = object.getWorldPosition(new THREE.Vector3());
    return { x: p.x, y: p.y, z: p.z };
  },
  setEmissive(instance, color, intensity) {
    let applied = 0;
    instance.object?.traverse((child) => {
      const materials = (child as THREE.Mesh).material;
      for (const m of Array.isArray(materials) ? materials : materials ? [materials] : []) {
        const std = m as THREE.MeshStandardMaterial;
        if (std.emissive) {
          std.emissive.set(color);
          std.emissiveIntensity = intensity;
          applied++;
        }
      }
    });
    return applied;
  },
};
