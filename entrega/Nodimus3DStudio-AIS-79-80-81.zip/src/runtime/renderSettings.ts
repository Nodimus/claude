import type { ProjectData, ProjectSettings } from '../types/project';
import { normalizeSettings, schemaDefaults } from '../core/projectSettingsForm';

/**
 * AIS-44d — `resolveRenderSettings`: a ÚNICA leitora das settings de renderização/moldura do Play
 * (`project.settings.rendering.*` e `display.width/height`). Pura (sem React nem Three): o Viewport/RuntimeViewportHost só
 * consome o objeto devolvido. Os padrões do schema reproduzem exatamente a aparência de antes do prompt (decisão 4a):
 * sombras ligadas, mapa 2048, fundo #141822, tone mapping do `Environment`, 2x MSAA, 1280×720.
 *
 * O `Environment` da Scene continua dono do ambiente (decisão 17): `realtimeShadows` entra por AND, `shadowMapSize` do nó de
 * luz continua vencendo e `clearColor` só vale quando o `Environment` não define fundo próprio.
 */

export type MsaaSetting = ProjectSettings['rendering']['msaa'];

export interface ResolvedRenderSettings {
  shadows: {
    /** `rendering.shadowsEnabled` E `realtimeShadows` do Environment (o projeto desliga tudo; a Scene desliga as suas). */
    enabled: boolean;
    /** Lado do shadow map quando o nó de luz NÃO define `shadowMapSize`: low 1024 · medium 2048 · high 4096. */
    mapSize: number;
  };
  /** `#rrggbb` minúsculo (hex inválido cai no padrão do schema). Fundo do Play sem fundo próprio no Environment e barras da moldura. */
  clearColor: string;
  /** `false` = tone mapping como hoje (o do Environment); `true` = caminho HDR do Play (AgX; o render target HDR é do AIS-55). */
  hdr: boolean;
  msaa: { setting: MsaaSetting; samples: 0 | 2 | 4 | 8; antialias: boolean };
  /** Proporção da moldura do Play (`display.width × display.height`). */
  frame: { width: number; height: number; aspect: number };
}

/** Parte do `Environment` da Scene que influencia a resolução (tudo opcional: sem Environment = padrões atuais). */
export interface RenderEnvironmentInput {
  realtimeShadows?: boolean;
}

const SHADOW_MAP_SIZE: Record<ProjectSettings['rendering']['shadowQuality'], number> = { low: 1024, medium: 2048, high: 4096 };
const MSAA_SAMPLES: Record<MsaaSetting, 0 | 2 | 4 | 8> = { disabled: 0, '2x': 2, '4x': 4, '8x': 8 };
/** Lado do mapa quando nada define (valor histórico do Viewport). */
export const DEFAULT_SHADOW_MAP_SIZE = 2048;

/** `#rgb`/`#rrggbb` → `#rrggbb` minúsculo; qualquer outra coisa → `undefined`. */
export function normalizeHexColor(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  const m = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.exec(value.trim());
  if (!m) return undefined;
  const hex = m[1].length === 3 ? m[1].split('').map((c) => c + c).join('') : m[1];
  return `#${hex.toLowerCase()}`;
}

const dimension = (value: unknown, fallback: number): number =>
  typeof value === 'number' && Number.isFinite(value) && value >= 1 && value <= 16384 ? Math.round(value) : fallback;

/**
 * Resolve as settings de renderização do Play. Aceita o `ProjectData` inteiro ou só `project.settings` (projeto antigo, campos
 * ausentes e valores inválidos viram os padrões do schema, campo a campo).
 */
export function resolveRenderSettings(source: ProjectData | ProjectSettings | unknown, environment: RenderEnvironmentInput = {}): ResolvedRenderSettings {
  const raw = source && typeof source === 'object' && 'settings' in (source as object) ? (source as ProjectData).settings : source;
  const settings = normalizeSettings(raw);
  const defaults = schemaDefaults();
  const r = settings.rendering as Partial<ProjectSettings['rendering']>;
  const d = settings.display as Partial<ProjectSettings['display']>;

  const shadowQuality = r.shadowQuality && r.shadowQuality in SHADOW_MAP_SIZE ? r.shadowQuality : defaults.rendering.shadowQuality;
  const msaaSetting: MsaaSetting = r.msaa && r.msaa in MSAA_SAMPLES ? r.msaa : defaults.rendering.msaa;
  const width = dimension(d.width, defaults.display.width);
  const height = dimension(d.height, defaults.display.height);

  return {
    shadows: {
      enabled: (typeof r.shadowsEnabled === 'boolean' ? r.shadowsEnabled : defaults.rendering.shadowsEnabled) && environment.realtimeShadows !== false,
      mapSize: SHADOW_MAP_SIZE[shadowQuality],
    },
    clearColor: normalizeHexColor(r.clearColor) ?? (normalizeHexColor(defaults.rendering.clearColor) as string),
    hdr: typeof r.hdr === 'boolean' ? r.hdr : defaults.rendering.hdr,
    msaa: { setting: msaaSetting, samples: MSAA_SAMPLES[msaaSetting], antialias: MSAA_SAMPLES[msaaSetting] > 0 },
    frame: { width, height, aspect: width / height },
  };
}

/** Maior retângulo com a proporção `aspect` que cabe em `width × height`, centrado (letterbox/pillarbox). Arredondado para baixo. */
export function fitFrame(container: { width: number; height: number }, aspect: number): { width: number; height: number; left: number; top: number } {
  if (!(container.width > 0) || !(container.height > 0) || !Number.isFinite(aspect) || aspect <= 0) {
    return { width: Math.max(0, container.width), height: Math.max(0, container.height), left: 0, top: 0 };
  }
  let width = container.width;
  let height = width / aspect;
  if (height > container.height) {
    height = container.height;
    width = height * aspect;
  }
  width = Math.floor(width);
  height = Math.floor(height);
  return { width, height, left: Math.floor((container.width - width) / 2), top: Math.floor((container.height - height) / 2) };
}

/** Lado do shadow map efetivo de uma luz: o valor do nó, quando existe, vence; senão o do projeto (Play) ou o histórico (Edit). */
export function effectiveShadowMapSize(nodeValue: unknown, projectMapSize: number | undefined): number {
  return typeof nodeValue === 'number' && Number.isFinite(nodeValue) && nodeValue > 0 ? nodeValue : (projectMapSize ?? DEFAULT_SHADOW_MAP_SIZE);
}
