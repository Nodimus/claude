import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import type { BehaviorRuntime, BehaviorRuntimeModule } from '../logic/types';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { ensureRapier } from '../core/physics/rapierInit';
import { RuntimeSession, type RuntimeSessionOptions } from './RuntimeSession';

/**
 * AIS-48b — assinaturas de runtime por owner: Stop zera, 5 ciclos Play/Stop estáveis, Behavior removido cancela só o dele, instância
 * destruída cancela as suas, frame/input/sinal/física com `unsubscribe` idempotente, diagnóstico unificado com contexto e Stay inexistente.
 */

beforeAll(async () => {
  await ensureRapier();
});

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[], parameters: Record<string, any> = {}): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters, conditions: [], actions });
const behavior = (type: string, rules: LogicEventRule[] = [], id = `b${++seq}`): BehaviorInstance => ({ id, name: `B_${id}`, behaviorType: type, enabled: true, properties: {}, rules });
const node = (id: string, physics: Record<string, any> | undefined, nodeExtra: Record<string, any> = {}): GameNode =>
  ({
    id,
    name: id,
    type: 'MeshInstance',
    parentId: null,
    childrenIds: [],
    visible: true,
    locked: false,
    properties: { meshType: 'CubeMesh', position: { x: 0, y: 0.5, z: 0 }, ...(physics ? { physics } : {}) },
    ...nodeExtra,
  }) as unknown as GameNode;
function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  return { ...scene, nodes };
}
const fakeInput = () => ({
  isActionPressed: () => false,
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: () => 0,
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
});
const STATIC = { enabled: true, bodyMode: 'static', shape: 'auto' };

/** Behavior de teste: assina frame, input, sinal e física e conta o que recebe. */
function probe(counts: { frame: number; input: number; signal: number }): BehaviorRuntimeModule {
  return {
    create(): BehaviorRuntime {
      return {
        onPlayStart(ctx) {
          ctx.onFrame(() => counts.frame++);
          ctx.onInput(() => counts.input++);
          ctx.onSignal('ping', () => counts.signal++);
          ctx.onPhysicsEvent('*', () => undefined);
        },
      };
    },
  };
}

function open(scene: SceneData, extra: Partial<RuntimeSessionOptions> = {}) {
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input: fakeInput(), ...extra });
  session.start();
  return session;
}
const run = (session: RuntimeSession, frames: number) => {
  for (let i = 0; i < frames; i++) session.step(1 / 60);
};
const catalogOf = (m: BehaviorRuntimeModule) => ({ get: (t: string) => (t === 'probe' ? m : undefined) });

describe('inscrições por owner (AIS-48b-C01..C03)', () => {
  it('C01: Stop zera as inscrições da sessão (frame, input, sinal, física, nó)', () => {
    const counts = { frame: 0, input: 0, signal: 0 };
    const session = open(sceneWith(node('a', STATIC, { behaviors: [behavior('probe', [], 'p1')] })), { behaviorCatalog: catalogOf(probe(counts)) });
    session.onFrame(() => undefined);
    session.onNodeSignal(() => undefined);
    session.onSignal('x', () => undefined, { kind: 'session', id: 'ed' });
    expect(session.subscriptionCount()).toBeGreaterThan(5);
    session.stop();
    expect(session.subscriptionCount()).toBe(0);
  });

  it('C02: 5 ciclos Play/Stop mantêm as contagens estáveis (nada se acumula)', () => {
    const counts = { frame: 0, input: 0, signal: 0 };
    const scene = sceneWith(node('a', STATIC, { behaviors: [behavior('probe', [], 'p1')] }));
    const perCycle: number[] = [];
    for (let i = 0; i < 5; i++) {
      const session = open(scene, { behaviorCatalog: catalogOf(probe(counts)) });
      perCycle.push(session.subscriptionCount());
      const before = { ...counts };
      run(session, 3);
      expect(counts.frame - before.frame).toBe(3); // um único assinante por ciclo
      expect(counts.input - before.input).toBe(3);
      session.stop();
      expect(session.subscriptionCount()).toBe(0);
      session.dispose();
    }
    expect(new Set(perCycle).size).toBe(1);
    expect(perCycle[0]).toBe(4);
  });

  it('frame/input/sinal chegam e o unsubscribe é idempotente', () => {
    const session = open(sceneWith(node('a', undefined, { behaviors: [behavior('custom_rules', [rule('on_start', [act('emit_signal', { signal: 'ping' })])])] })));
    let frames = 0;
    let inputs = 0;
    const pings: string[] = [];
    const offF = session.onFrame(() => frames++);
    const offI = session.onInput(() => inputs++);
    const offS = session.onSignal('ping', (n) => pings.push(n));
    run(session, 2);
    expect(frames).toBe(2);
    expect(inputs).toBe(2);
    offF();
    offF();
    offI();
    offS();
    run(session, 2);
    expect(frames).toBe(2);
    expect(inputs).toBe(2);
    session.dispose();
  });

  it('o sinal emitido por uma Action chega ao assinante', () => {
    const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(sceneWith(node('a', undefined, { behaviors: [behavior('custom_rules', [rule('on_start', [act('emit_signal', { signal: 'ping' })])])] }))), input: fakeInput() });
    const pings: string[] = [];
    session.onSignal('ping', (n) => pings.push(n));
    session.start();
    run(session, 2);
    expect(pings).toEqual(['ping']);
    session.dispose();
  });

  it('C03: remover um Behavior cancela só as inscrições dele', () => {
    const counts = { frame: 0, input: 0, signal: 0 };
    const session = open(sceneWith(node('a', STATIC, { behaviors: [behavior('probe', [], 'p1'), behavior('probe', [], 'p2')] })), { behaviorCatalog: catalogOf(probe(counts)) });
    expect(session.subscriptionCount({ kind: 'behavior' })).toBe(8);
    expect(session.subscriptionCount({ owner: { kind: 'behavior', id: 'a::p1' } })).toBe(4);
    expect(session.removeBehavior('a', 'p1')).toBe(true);
    expect(session.removeBehavior('a', 'p1')).toBe(false);
    expect(session.subscriptionCount({ owner: { kind: 'behavior', id: 'a::p1' } })).toBe(0);
    expect(session.subscriptionCount({ owner: { kind: 'behavior', id: 'a::p2' } })).toBe(4);
    run(session, 3);
    expect(counts.frame).toBe(3); // só o p2 segue assinando
    session.dispose();
  });

  it('instância destruída no jogo cancela as inscrições dos Behaviors dela (sem callback sobre nó morto)', () => {
    const counts = { frame: 0, input: 0, signal: 0 };
    const session = open(sceneWith(node('a', STATIC, { behaviors: [behavior('probe', [], 'p1')] }), node('b', STATIC, { behaviors: [behavior('probe', [], 'p2')] })), { behaviorCatalog: catalogOf(probe(counts)) });
    run(session, 1);
    expect(session.subscriptionCount({ kind: 'behavior' })).toBe(8);
    session.scene.destroyInstance(session.scene.getInstance('a')!.id);
    run(session, 1); // o reaper roda no começo do quadro
    expect(session.subscriptionCount({ owner: { kind: 'behavior', id: 'a::p1' } })).toBe(0);
    expect(session.subscriptionCount({ owner: { kind: 'behavior', id: 'b::p2' } })).toBe(4);
    const before = counts.frame;
    run(session, 2);
    expect(counts.frame - before).toBe(2); // só o nó vivo
    session.dispose();
  });

  it('restartBehavior troca as inscrições do dono sem acumular', () => {
    const counts = { frame: 0, input: 0, signal: 0 };
    const session = open(sceneWith(node('a', STATIC, { behaviors: [behavior('probe', [], 'p1')] })), { behaviorCatalog: catalogOf(probe(counts)) });
    for (let i = 0; i < 4; i++) session.restartBehavior('a', 'p1');
    expect(session.subscriptionCount({ owner: { kind: 'behavior', id: 'a::p1' } })).toBe(4);
    session.dispose();
  });

  it('Restart Scene descarta as inscrições da cena e mantém as de dono session', () => {
    const session = open(sceneWith(node('a', STATIC)));
    session.onFrame(() => undefined);
    session.onFrame(() => undefined, { kind: 'session', id: 'ed' });
    session.restartScene();
    expect(session.subscriptionCount({ kind: 'scene' })).toBe(0);
    expect(session.subscriptionCount({ kind: 'session' })).toBe(1);
    session.dispose();
    expect(session.subscriptionCount()).toBe(0);
  });

  it('um assinante que lança vira diagnóstico e não derruba o quadro', () => {
    const diagnostics = new DiagnosticService();
    const session = open(sceneWith(node('a', STATIC)), { diagnostics });
    let ok = 0;
    session.onFrame(() => {
      throw new Error('boom');
    });
    session.onFrame(() => ok++);
    expect(() => run(session, 2)).not.toThrow();
    expect(ok).toBe(2);
    expect(diagnostics.list({ sessionId: session.id }).some((d) => d.code === 'runtime.listener_failed')).toBe(true);
    session.dispose();
  });
});

describe('diagnóstico unificado (AIS-48b-C04/C07)', () => {
  it('C04: Add Force em corpo incompatível → diagnóstico com sessionId e contexto, sem derrubar; some ao descartar', () => {
    const diagnostics = new DiagnosticService();
    const wall = node('wall', STATIC, { behaviors: [behavior('custom_rules', [rule('on_start', [act('add_force', { force: { x: 1, y: 0, z: 0 } }), act('set_variable', { variable: 'after', value: true })])], 'bh1')] });
    const session = open(sceneWith(wall), { diagnostics, globals: [{ name: 'after', type: 'boolean', value: false }] });
    expect(() => run(session, 3)).not.toThrow();
    expect(session.variables!.getVariable('global', 'after')).toBe(true); // a cadeia seguiu
    const d = diagnostics.list({ sessionId: session.id }).find((x) => x.code === 'physics.incompatible_body_mode');
    expect(d).toBeDefined();
    expect(d).toMatchObject({ severity: 'error', phase: 'physics', sessionId: session.id, nodeId: 'wall', behaviorId: 'bh1', logicId: 'add_force' });
    expect(d!.instanceId).toBeTruthy();
    session.dispose();
    expect(diagnostics.list({ sessionId: session.id })).toHaveLength(0);
  });

  it('Action em nó sem corpo usa o mesmo formato (physics.no_body, com behaviorId)', () => {
    const diagnostics = new DiagnosticService();
    const n = node('a', undefined, { behaviors: [behavior('custom_rules', [rule('on_start', [act('add_force', { force: { x: 1, y: 0, z: 0 } })])], 'bh2')] });
    const session = open(sceneWith(n), { diagnostics });
    run(session, 2);
    expect(diagnostics.list({ sessionId: session.id }).some((d) => d.code === 'physics.no_body' && d.behaviorId === 'bh2')).toBe(true);
    session.dispose();
  });

  it('erro de Behavior (callback lança) vira diagnóstico com behaviorId e logicId', () => {
    const diagnostics = new DiagnosticService();
    const bad: BehaviorRuntimeModule = {
      create: () => ({
        onUpdate() {
          throw new Error('quebrou');
        },
      }),
    };
    const session = open(sceneWith(node('a', undefined, { behaviors: [behavior('probe', [], 'p1')] })), { diagnostics, behaviorCatalog: catalogOf(bad) });
    expect(() => run(session, 2)).not.toThrow();
    expect(diagnostics.list({ sessionId: session.id }).find((d) => d.code === 'behavior.failed')).toMatchObject({ behaviorId: 'p1', logicId: 'probe', nodeId: 'a' });
    session.dispose();
  });

  it('C07: existe um único tipo RuntimeDiagnostic no código (nada paralelo)', () => {
    const files: string[] = [];
    const walk = (dir: string) => {
      for (const name of readdirSync(dir)) {
        const p = join(dir, name);
        if (statSync(p).isDirectory()) walk(p);
        else if (/\.(ts|tsx)$/.test(name) && !/\.test\./.test(name)) files.push(p);
      }
    };
    walk(join(process.cwd(), 'src'));
    const hits = files.filter((f) => /^(export )?(interface|type)\s+RuntimeDiagnostic\b/m.test(readFileSync(f, 'utf8')));
    expect(hits).toHaveLength(1);
    expect(hits[0].replace(/\\/g, '/')).toContain('core/diagnostics/DiagnosticService.ts');
  });
});

describe('sem Stay (AIS-48b-C05)', () => {
  it('sem assinante de física nem regra de contato, o passo não consulta contatos (nenhum evento por passo)', () => {
    const session = open(sceneWith(node('floor', STATIC, { properties: { meshType: 'CubeMesh', position: { x: 0, y: -0.5, z: 0 }, scale: { x: 40, y: 1, z: 40 }, physics: STATIC } }), node('crate', { enabled: true, bodyMode: 'dynamic', shape: 'auto' })));
    run(session, 60);
    let events = 0;
    session.onPhysicsEvent('*', () => events++);
    run(session, 300); // 5 s em repouso
    expect(events).toBe(0);
    expect(session.subscriptionCount({ kind: 'scene' })).toBe(1);
    session.dispose();
  });
});
