import * as THREE from 'three';
import { buildPathCurve, type PathConfig } from '../../core/path/pathData';
import type { RuntimeInstance } from '../RuntimeScene';

/**
 * AIS-78c (execução 3) — a spline de um nó `Path` em coordenadas MUNDIAIS, como DADO: o Behavior `follow_a_path` só pede `pointAt(s)` e o
 * comprimento (sem `THREE.*` em `src/logic/**`). Em Godot: `Path3D.curve` + `global_transform` → `Curve3D.sample_baked`.
 */
export interface WorldPathCurve {
  /** Chave de cache: muda quando o caminho (pontos, fechamento, tensão) ou a transformação do nó muda. */
  key: string;
  length: number;
  closed: boolean;
  /** Ponto da curva à distância `s` (metros, limitada a 0..comprimento). */
  pointAt(s: number): { x: number; y: number; z: number };
}

/** `null` se a curva não pode ser construída (poucos pontos). Comprimento zero é decidido por quem chama (diagnóstico próprio). */
export function buildWorldPathCurve(path: RuntimeInstance, config: PathConfig): WorldPathCurve | null {
  const matrix = path.object ? (path.object.updateWorldMatrix(true, false), path.object.matrixWorld) : new THREE.Matrix4();
  const key = `${config.nodes.map((n) => `${n.x},${n.y},${n.z}`).join(';')}|${config.closed}|${config.tightness}|${matrix.elements.join(',')}`; // inclui as coordenadas: editar um waypoint invalida a curva
  const world = config.nodes.map((p) => {
    const v = new THREE.Vector3(p.x, p.y, p.z).applyMatrix4(matrix); // a Catmull-Rom é invariante por transformação afim: transformar os pontos basta
    return { x: v.x, y: v.y, z: v.z };
  });
  const curve = buildPathCurve({ ...config, nodes: world });
  if (!curve) return null;
  const length = curve.getLength();
  return {
    key,
    length,
    closed: config.closed,
    pointAt: (s) => {
      const p = curve.getPointAt(length > 0 ? Math.min(1, Math.max(0, s / length)) : 0);
      return { x: p.x, y: p.y, z: p.z };
    },
  };
}
