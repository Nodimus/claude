/**
 * AIS-25b — Layout de Controls estilo Godot (função ÚNICA de retângulo de tela, decisão 25).
 *
 * Cada overlay é um `Control`: **âncoras** (L/T/R/B, 0..1 do retângulo do pai) + **offsets** em px.
 *
 *   left  = pai.x + aL·pai.w + offsetL      right  = pai.x + aR·pai.w + offsetR
 *   top   = pai.y + aT·pai.h + offsetT      bottom = pai.y + aB·pai.h + offsetB
 *
 * O campo `alignment` do nó guarda o **Layout Preset** (nomes do Godot); `posX/posY/width/height`
 * guardam os offsets nas chaves de sempre (sem migração de cena):
 *  - preset de PONTO (âncora colapsada): `pos` = deslocamento do ponto de âncora do pai ao MESMO ponto
 *    do controle; `size` = tamanho — idêntico ao desenho antigo `pos − anchorOffset(anchor, w, h)`;
 *  - eixo ESTICADO (presets "wide"/Full-Rect): `pos` = margem do início, `size` = margem do fim.
 *
 * Usada por editor, Inspector, handles e render UIKit/Play: nunca duplicar (bug histórico do projeto
 * anterior: o publish reimplementou o cálculo sem `anchorOffset`).
 * Puro: sem React, DOM nem Three.
 */

export interface Rect {
  left: number;
  top: number;
  width: number;
  height: number;
}

export type LayoutPreset =
  | 'Top-Left'
  | 'Top-Center'
  | 'Top-Right'
  | 'Center-Left'
  | 'Center'
  | 'Center-Right'
  | 'Bottom-Left'
  | 'Bottom-Center'
  | 'Bottom-Right'
  | 'Top-Wide'
  | 'VCenter-Wide'
  | 'Bottom-Wide'
  | 'Left-Wide'
  | 'HCenter-Wide'
  | 'Right-Wide'
  | 'Full-Rect';

/** Âncoras de cada preset (L, T, R, B em 0..1). Ponto: L==R e T==B. */
export const LAYOUT_PRESETS: Readonly<Record<LayoutPreset, { aL: number; aT: number; aR: number; aB: number }>> = {
  'Top-Left': { aL: 0, aT: 0, aR: 0, aB: 0 },
  'Top-Center': { aL: 0.5, aT: 0, aR: 0.5, aB: 0 },
  'Top-Right': { aL: 1, aT: 0, aR: 1, aB: 0 },
  'Center-Left': { aL: 0, aT: 0.5, aR: 0, aB: 0.5 },
  Center: { aL: 0.5, aT: 0.5, aR: 0.5, aB: 0.5 },
  'Center-Right': { aL: 1, aT: 0.5, aR: 1, aB: 0.5 },
  'Bottom-Left': { aL: 0, aT: 1, aR: 0, aB: 1 },
  'Bottom-Center': { aL: 0.5, aT: 1, aR: 0.5, aB: 1 },
  'Bottom-Right': { aL: 1, aT: 1, aR: 1, aB: 1 },
  'Top-Wide': { aL: 0, aT: 0, aR: 1, aB: 0 },
  'VCenter-Wide': { aL: 0, aT: 0.5, aR: 1, aB: 0.5 },
  'Bottom-Wide': { aL: 0, aT: 1, aR: 1, aB: 1 },
  'Left-Wide': { aL: 0, aT: 0, aR: 0, aB: 1 },
  'HCenter-Wide': { aL: 0.5, aT: 0, aR: 0.5, aB: 1 },
  'Right-Wide': { aL: 1, aT: 0, aR: 1, aB: 1 },
  'Full-Rect': { aL: 0, aT: 0, aR: 1, aB: 1 },
};

/** Presets na ordem do dropdown do Inspector (9 de ponto, 6 esticados, Full-Rect). */
export const LAYOUT_PRESET_ORDER: readonly LayoutPreset[] = [
  'Top-Left',
  'Top-Center',
  'Top-Right',
  'Center-Left',
  'Center',
  'Center-Right',
  'Bottom-Left',
  'Bottom-Center',
  'Bottom-Right',
  'Top-Wide',
  'VCenter-Wide',
  'Bottom-Wide',
  'Left-Wide',
  'HCenter-Wide',
  'Right-Wide',
  'Full-Rect',
];

/** `alignment` desconhecido ou ausente = `Top-Left` (nunca lança). */
export function normalizeLayoutPreset(value: unknown): LayoutPreset {
  return typeof value === 'string' && Object.prototype.hasOwnProperty.call(LAYOUT_PRESETS, value)
    ? (value as LayoutPreset)
    : 'Top-Left';
}

export const isHorizontallyStretched = (preset: LayoutPreset): boolean => LAYOUT_PRESETS[preset].aL !== LAYOUT_PRESETS[preset].aR;
export const isVerticallyStretched = (preset: LayoutPreset): boolean => LAYOUT_PRESETS[preset].aT !== LAYOUT_PRESETS[preset].aB;

/** Os quatro números do controle, nas chaves de dados atuais. */
export interface OverlayControl {
  alignment?: unknown;
  posX: number;
  posY: number;
  width: number;
  height: number;
}

const num = (v: unknown, fallback: number): number => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);

/**
 * Lê o controle das `properties` do nó. Padrões = os do registry (posX/posY 20, 140×48; texto: altura
 * pelo tamanho da fonte). `??` (não `||`): zero é um valor válido.
 */
export function readOverlayControl(type: string, properties: Record<string, any> | undefined): OverlayControl {
  const p = properties ?? {};
  const isText = type === 'TextOverlay2D';
  const fontSize = num(p.fontSize, 15);
  return {
    alignment: p.alignment,
    posX: num(p.posX, 20),
    posY: num(p.posY, 20),
    width: Math.max(0, num(p.width, 140)),
    height: Math.max(0, num(p.height, isText ? Math.round(fontSize * 1.6) : type === 'ButtonOverlay2D' ? 38 : 48)),
  };
}

/** Retângulo de tela do controle dentro do retângulo do pai (viewport para overlays de topo). */
export function computeOverlayScreenRect(control: OverlayControl, parent: Rect): Rect {
  const preset = normalizeLayoutPreset(control.alignment);
  const a = LAYOUT_PRESETS[preset];
  const axis = (start: number, size: number, aStart: number, aEnd: number, pos: number, extent: number) => {
    if (aStart === aEnd) {
      // âncora de ponto: pos desloca o ponto de âncora do pai ao mesmo ponto do controle
      return { start: start + aStart * size + pos - aStart * extent, extent };
    }
    // esticado: pos = margem do início, extent(width/height) = margem do fim
    const s = start + aStart * size + pos;
    const e = start + aEnd * size - extent;
    return { start: s, extent: Math.max(0, e - s) };
  };
  const x = axis(parent.left, parent.width, a.aL, a.aR, control.posX, control.width);
  const y = axis(parent.top, parent.height, a.aT, a.aB, control.posY, control.height);
  return { left: x.start, top: y.start, width: x.extent, height: y.extent };
}

/**
 * Inverso de `computeOverlayScreenRect`: dado o retângulo de tela desejado (arrastar/redimensionar no
 * editor 2D), devolve os offsets (`posX/posY/width/height`) que o produzem para o preset.
 */
export function rectToOverlayOffsets(preset: LayoutPreset, parent: Rect, rect: Rect): Pick<OverlayControl, 'posX' | 'posY' | 'width' | 'height'> {
  const a = LAYOUT_PRESETS[preset];
  const axis = (pStart: number, pSize: number, aStart: number, aEnd: number, start: number, extent: number) => {
    if (aStart === aEnd) {
      return { pos: start - pStart - aStart * pSize + aStart * extent, size: extent };
    }
    return { pos: start - pStart - aStart * pSize, size: pStart + aEnd * pSize - (start + extent) };
  };
  const x = axis(parent.left, parent.width, a.aL, a.aR, rect.left, rect.width);
  const y = axis(parent.top, parent.height, a.aT, a.aB, rect.top, rect.height);
  return { posX: x.pos, posY: y.pos, width: x.size, height: y.size };
}

/** Rótulos dos quatro campos de layout conforme o preset (Inspector). */
export function layoutFieldLabels(preset: LayoutPreset): { posX: string; posY: string; width: string; height: string } {
  const h = isHorizontallyStretched(preset);
  const v = isVerticallyStretched(preset);
  return {
    posX: h ? 'Margin Left (px)' : 'Position X (px)',
    posY: v ? 'Margin Top (px)' : 'Position Y (px)',
    width: h ? 'Margin Right (px)' : 'Width (px)',
    height: v ? 'Margin Bottom (px)' : 'Height (px)',
  };
}

// ── Cena: retângulos de todos os overlays ─────────────────────────────────────────────────────

/**
 * Nós de UI de tela: overlays (AIS-25b) e Containers/controles (AIS-25c). A lista de TIPOS vem do registry
 * (`isUI`); aqui ficam só os nomes para o runtime puro não importar o registry.
 */
export const OVERLAY_NODE_TYPES = [
  'Overlay2D',
  'TextOverlay2D',
  'ButtonOverlay2D',
  'Panel',
  'Container',
  'HBox',
  'VBox',
  'Grid',
  'MarginContainer',
  'CenterContainer',
  'ScrollContainer',
  'CheckBox',
  'Slider',
  'ProgressBar',
  'TextInput',
] as const;
export type OverlayNodeType = (typeof OVERLAY_NODE_TYPES)[number];
export const isOverlayNodeType = (type: string): type is OverlayNodeType => (OVERLAY_NODE_TYPES as readonly string[]).includes(type);

/** Um nó de UI na ordem de desenho: pai de UI (ou `null` = viewport) e profundidade. */
export interface UiTreeEntry {
  id: string;
  parentId: string | null;
  depth: number;
}

interface UiTreeNodeLike extends OverlayNodeLike {
  childrenIds?: string[];
}

/**
 * Árvore de UI visível em ordem de desenho (pai antes dos filhos; filhos na ordem de `childrenIds`).
 * Raízes = nós de UI cujo pai NÃO é de UI, na ordem de `nodes`. Nó/pai invisível remove a subárvore.
 */
export function collectUiTree(nodes: Record<string, UiTreeNodeLike>): UiTreeEntry[] {
  const out: UiTreeEntry[] = [];
  const seen = new Set<string>();
  const visit = (id: string, parentId: string | null, depth: number) => {
    const node = nodes[id];
    if (!node || seen.has(id) || !isOverlayNodeType(node.type)) return;
    seen.add(id);
    if (node.visible === false || node.properties?.visible === false) return;
    out.push({ id, parentId, depth });
    for (const childId of node.childrenIds ?? []) visit(childId, id, depth + 1);
  };
  for (const [id, node] of Object.entries(nodes)) {
    if (!isOverlayNodeType(node.type)) continue;
    const parent = node.parentId ? nodes[node.parentId] : undefined;
    if (parent && isOverlayNodeType(parent.type)) continue; // entra pela raiz da sua árvore
    visit(id, null, 0);
  }
  return out;
}

interface OverlayNodeLike {
  id: string;
  type: string;
  parentId: string | null;
  visible?: boolean;
  properties?: Record<string, any>;
}

/**
 * Retângulos de tela dos overlays visíveis (ordem de `nodes`). O pai de um overlay de topo é a viewport;
 * um overlay filho de outro overlay usa o retângulo calculado do pai. Pai oculto oculta o filho.
 */
export function resolveOverlayRects(nodes: Record<string, OverlayNodeLike>, viewport: { width: number; height: number }): Map<string, Rect> {
  const result = new Map<string, Rect>();
  const visited = new Set<string>();
  const root: Rect = { left: 0, top: 0, width: viewport.width, height: viewport.height };

  const rectOf = (id: string): Rect | null => {
    if (result.has(id)) return result.get(id)!;
    const node = nodes[id];
    if (!node || !isOverlayNodeType(node.type)) return null;
    if (visited.has(id)) return null; // ciclo
    visited.add(id);
    const visible = node.visible !== false && node.properties?.visible !== false;
    if (!visible) return null;
    const parentNode = node.parentId ? nodes[node.parentId] : undefined;
    let parentRect = root;
    if (parentNode && isOverlayNodeType(parentNode.type)) {
      const pr = rectOf(parentNode.id);
      if (!pr) return null;
      parentRect = pr;
    }
    const rect = computeOverlayScreenRect(readOverlayControl(node.type, node.properties), parentRect);
    result.set(id, rect);
    return rect;
  };

  for (const id of Object.keys(nodes)) rectOf(id);
  return result;
}

/** Hit-test: id do overlay mais ao topo (último da ordem) sob o ponto (x, y) em px de tela. */
export function hitTestOverlays(rects: ReadonlyMap<string, Rect>, x: number, y: number, accept?: (id: string) => boolean): string | null {
  let hit: string | null = null;
  for (const [id, r] of rects) {
    if (accept && !accept(id)) continue;
    if (x >= r.left && x <= r.left + r.width && y >= r.top && y <= r.top + r.height) hit = id;
  }
  return hit;
}
