import { describe, expect, it } from 'vitest';
import {
  axisFlags,
  childFlex,
  childMinSize,
  containerFlexProps,
  containerKindOf,
  gridRows,
  isLayoutContainerType,
  parseSizeFlag,
  SIZE_FLAG_VALUES,
} from './containerLayout';
import { collectUiTree, isOverlayNodeType, OVERLAY_NODE_TYPES } from './overlay';
import { NODE_REGISTRY } from '../nodes/registry';

describe('size flags (Godot)', () => {
  it('valores válidos; qualquer outro cai em fill', () => {
    for (const v of SIZE_FLAG_VALUES) expect(parseSizeFlag(v)).toBe(v);
    expect(parseSizeFlag('xx')).toBe('fill');
    expect(parseSizeFlag(undefined)).toBe('fill');
  });

  it('expand e fill por flag; alinhamento dos shrink', () => {
    expect(axisFlags('fill')).toEqual({ expand: false, fill: true, align: 'begin' });
    expect(axisFlags('expand')).toEqual({ expand: true, fill: false, align: 'begin' });
    expect(axisFlags('expand-fill')).toEqual({ expand: true, fill: true, align: 'begin' });
    expect(axisFlags('shrink-center').align).toBe('center');
    expect(axisFlags('shrink-end').align).toBe('end');
    expect(axisFlags('shrink-begin')).toEqual({ expand: false, fill: false, align: 'begin' });
  });
});

describe('quais tipos organizam filhos', () => {
  it('HBox/VBox/Grid/Margin/Center/Scroll/Container organizam; Panel e controles não', () => {
    for (const t of ['HBox', 'VBox', 'Grid', 'MarginContainer', 'CenterContainer', 'ScrollContainer', 'Container']) {
      expect(isLayoutContainerType(t)).toBe(true);
    }
    for (const t of ['Panel', 'Overlay2D', 'TextOverlay2D', 'ButtonOverlay2D', 'CheckBox', 'Slider', 'MeshInstance']) {
      expect(isLayoutContainerType(t)).toBe(false);
      expect(containerKindOf(t)).toBeNull();
    }
  });
});

describe('containerFlexProps', () => {
  it('HBox: linha com separação e alinhamento do conteúdo', () => {
    expect(containerFlexProps('HBox', { separation: 12, contentAlignment: 'center' })).toMatchObject({ flexDirection: 'row', gap: 12, justifyContent: 'center' });
    expect(containerFlexProps('HBox', {})).toMatchObject({ flexDirection: 'row', gap: 8, justifyContent: 'flex-start' });
  });
  it('VBox: coluna', () => {
    expect(containerFlexProps('VBox', { separation: 0, contentAlignment: 'end' })).toMatchObject({ flexDirection: 'column', gap: 0, justifyContent: 'flex-end' });
  });
  it('Margin: padding por lado; Center: centra; Scroll: overflow por eixo', () => {
    expect(containerFlexProps('MarginContainer', { marginLeft: 1, marginTop: 2, marginRight: 3, marginBottom: 4 })).toMatchObject({
      paddingLeft: 1,
      paddingTop: 2,
      paddingRight: 3,
      paddingBottom: 4,
    });
    expect(containerFlexProps('CenterContainer', {})).toMatchObject({ alignItems: 'center', justifyContent: 'center' });
    expect(containerFlexProps('ScrollContainer', { scrollH: 'never', scrollV: 'always' })).toMatchObject({ overflow: 'scroll' });
    expect(containerFlexProps('ScrollContainer', { scrollH: 'never', scrollV: 'never' })).toMatchObject({ overflow: 'hidden' });
  });
  it('valores negativos/inválidos não quebram', () => {
    expect(containerFlexProps('HBox', { separation: -5 })).toMatchObject({ gap: 0 });
    expect(containerFlexProps('MarginContainer', { marginLeft: 'x' })).toMatchObject({ paddingLeft: 8 });
    expect(containerFlexProps('Panel', {})).toEqual({});
  });
});

describe('childMinSize', () => {
  it('é o maior entre minSize e o tamanho próprio do nó', () => {
    expect(childMinSize({ width: 100, height: 40, minSize: { x: 150, y: 10 } })).toEqual({ width: 150, height: 40 });
    expect(childMinSize({})).toEqual({ width: 0, height: 0 });
    expect(childMinSize({ width: -5, minSize: 'x' })).toEqual({ width: 0, height: 0 });
  });
});

describe('childFlex — como o filho entra no fluxo', () => {
  it('HBox: expand dispara flexGrow = stretchRatio; sem expand não cresce', () => {
    const grow = childFlex('row', { width: 50, height: 30, sizeFlagsH: 'expand-fill', stretchRatio: 2 });
    expect(grow.slot.flexGrow).toBe(2);
    expect(grow.inner.width).toBe('100%');
    const fixed = childFlex('row', { width: 50, height: 30, sizeFlagsH: 'fill' });
    expect(fixed.slot.flexGrow).toBe(0);
    expect(fixed.inner.width).toBe(50); // fill sem expand = tamanho mínimo
  });

  it('HBox: eixo transversal — fill estica; shrink-* alinha o mínimo', () => {
    expect(childFlex('row', { width: 50, height: 30, sizeFlagsV: 'fill' }).slot.alignSelf).toBe('stretch');
    expect(childFlex('row', { width: 50, height: 30, sizeFlagsV: 'fill' }).inner.height).toBe('100%');
    const centered = childFlex('row', { width: 50, height: 30, sizeFlagsV: 'shrink-center' });
    expect(centered.slot.alignSelf).toBe('center');
    expect(centered.inner.height).toBe(30);
    expect(childFlex('row', { width: 50, height: 30, sizeFlagsV: 'shrink-end' }).slot.alignSelf).toBe('flex-end');
  });

  it('VBox: o eixo principal é a altura', () => {
    const c = childFlex('column', { width: 50, height: 30, sizeFlagsV: 'expand', stretchRatio: 3 });
    expect(c.slot.flexDirection).toBe('column');
    expect(c.slot.flexGrow).toBe(3);
    expect(c.inner.height).toBe(30); // expand sem fill: mantém o mínimo, alinhado no slot
    expect(childFlex('column', { width: 50, height: 30, sizeFlagsH: 'shrink-center' }).slot.alignSelf).toBe('center');
  });

  it('expand sem fill alinha o filho dentro do slot pelo flag (begin/center/end)', () => {
    expect(childFlex('row', { width: 50, height: 30, sizeFlagsH: 'expand' }).slot.justifyContent).toBe('flex-start');
    expect(childFlex('row', { width: 50, height: 30, sizeFlagsH: 'shrink-center' }).slot.justifyContent).toBe('center');
  });

  it('MarginContainer: o filho ocupa todo o retângulo (menos as margens), ignorando os flags', () => {
    const c = childFlex('margin', { width: 10, height: 10, sizeFlagsH: 'shrink-end', sizeFlagsV: 'shrink-end' });
    expect(c.inner).toMatchObject({ width: '100%', height: '100%' });
    expect(c.slot.flexGrow).toBe(1);
  });

  it('CenterContainer: o filho fica no tamanho mínimo, centrado', () => {
    const c = childFlex('center', { width: 80, height: 20 });
    expect(c.slot.alignSelf).toBe('center');
    expect(c.slot.flexGrow).toBe(0);
  });

  it('stretchRatio inválido vira um valor positivo', () => {
    expect(childFlex('row', { sizeFlagsH: 'expand', stretchRatio: -3, width: 1, height: 1 }).slot.flexGrow).toBeGreaterThan(0);
    expect(childFlex('row', { sizeFlagsH: 'expand', stretchRatio: 'x', width: 1, height: 1 }).slot.flexGrow).toBe(1);
  });
});

describe('gridRows', () => {
  it('divide em linhas de N colunas e completa a última com null', () => {
    expect(gridRows(['a', 'b', 'c', 'd', 'e'], 2)).toEqual([['a', 'b'], ['c', 'd'], ['e', null]]);
    expect(gridRows([], 3)).toEqual([]);
    expect(gridRows(['a', 'b'], 0)).toEqual([['a'], ['b']]);
    expect(gridRows(['a', 'b'], 5)).toEqual([['a', 'b', null, null, null]]);
  });
});

describe('collectUiTree', () => {
  const n = (id: string, type: string, parentId: string | null, childrenIds: string[] = [], properties: Record<string, any> = {}, visible = true) => ({
    id,
    type,
    parentId,
    childrenIds,
    properties,
    visible,
  });

  it('raízes = UI cujo pai não é UI; pai antes dos filhos; filhos na ordem de childrenIds', () => {
    const nodes = {
      world: n('world', 'Spatial', null, ['v', 'img']),
      v: n('v', 'VBox', 'world', ['b', 'a']),
      a: n('a', 'TextOverlay2D', 'v'),
      b: n('b', 'ButtonOverlay2D', 'v'),
      img: n('img', 'Overlay2D', 'world'),
      mesh: n('mesh', 'MeshInstance', 'world'),
    };
    expect(collectUiTree(nodes)).toEqual([
      { id: 'v', parentId: null, depth: 0 },
      { id: 'b', parentId: 'v', depth: 1 },
      { id: 'a', parentId: 'v', depth: 1 },
      { id: 'img', parentId: null, depth: 0 },
    ]);
  });

  it('nó ou pai invisível remove a subárvore; ciclo não trava', () => {
    const hidden = {
      p: n('p', 'Panel', null, ['c'], {}, false),
      c: n('c', 'Overlay2D', 'p'),
      ok: n('ok', 'Overlay2D', null),
      x: n('x', 'Overlay2D', 'y', ['y']),
      y: n('y', 'Overlay2D', 'x', ['x']),
    };
    expect(collectUiTree(hidden).map((e) => e.id)).toEqual(['ok']);
  });
});

describe('registry × runtime: os mesmos tipos de UI', () => {
  it('todo tipo `isUI` do registry está em OVERLAY_NODE_TYPES e vice-versa', () => {
    const registryUi = Object.values(NODE_REGISTRY)
      .filter((m) => m.isUI)
      .map((m) => m.type)
      .sort();
    expect([...OVERLAY_NODE_TYPES].sort()).toEqual(registryUi);
    for (const t of registryUi) expect(isOverlayNodeType(t)).toBe(true);
  });

  it('os 12 tipos novos existem e têm o layout de Container no Inspector', () => {
    for (const t of ['Panel', 'Container', 'HBox', 'VBox', 'Grid', 'MarginContainer', 'CenterContainer', 'ScrollContainer', 'CheckBox', 'Slider', 'ProgressBar', 'TextInput']) {
      const meta = NODE_REGISTRY[t as keyof typeof NODE_REGISTRY];
      expect(meta, t).toBeDefined();
      const keys = meta.propertyDescriptors.map((d) => d.key);
      for (const k of ['sizeFlagsH', 'sizeFlagsV', 'minSize', 'stretchRatio', 'alignment', 'posX']) expect(keys, `${t}:${k}`).toContain(k);
    }
  });

  it('Overlay2D/TextOverlay2D/ButtonOverlay2D também ganham os campos de Container', () => {
    for (const t of ['Overlay2D', 'TextOverlay2D', 'ButtonOverlay2D'] as const) {
      expect(NODE_REGISTRY[t].propertyDescriptors.map((d) => d.key)).toEqual(
        expect.arrayContaining(['sizeFlagsH', 'sizeFlagsV', 'minSize', 'stretchRatio'])
      );
    }
  });
});
