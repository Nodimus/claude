import { InputManager } from './InputManager';

/**
 * Instância única do input do JOGO (AIS-40b). Nasce desligada: só o Play a liga (`attach`) e o Stop a desliga (disposer).
 * Behaviors, Triggers e a simulação leem dela; ninguém cria outro InputManager nem escuta o teclado por conta própria.
 */
export const globalInputManager = new InputManager();
