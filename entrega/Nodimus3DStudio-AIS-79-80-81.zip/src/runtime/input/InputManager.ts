/**
 * AIS-40b — InputManager (runtime): UMA camada de input do JOGO, separada dos atalhos do editor (`useDesktopShortcuts`).
 *
 *   dispositivo físico (teclado/mouse) → InputManager → ação lógica ("MoveForward", "Jump", "Interact"…)
 *
 * Behaviors e Triggers leem AÇÕES (`isActionPressed`, `getAxis`…), nunca `KeyboardEvent.code`. O mapa ação → bindings é
 * dado (`InputMap`); trocar a tecla de uma ação muda todos os consumidores sem editar nenhum deles. O AIS-58 amplia e
 * remapeia ESTE contrato (gamepad, toque, mapa no projeto); não cria outro InputManager.
 *
 * Núcleo puro (sem DOM): recebe eventos por `handleKey`/`handleMouseButton`/`handlePointerMove`. Só `attach` toca o DOM, e
 * devolve SEMPRE um disposer (AIS-48b): Play/Stop repetido não acumula listeners, e fora de Play o manager fica desligado e
 * ignora qualquer evento (atalhos do editor nunca viram gameplay).
 */

import {
  DEFAULT_DEADZONE,
  DEFAULT_INPUT_ACTIONS,
  DEFAULT_INPUT_MAP,
  mouseBinding,
  padAxisBinding,
  padButtonBinding,
  parsePadBinding,
  resolveDeadzone,
  type GamepadLike,
  type InputBinding,
  type InputMap,
} from '../../core/inputMap';

// AIS-58: o mapa padrão, o formato dos bindings e as regras do mapa moram em `src/core/inputMap.ts`; reexportados aqui para os consumidores do AIS-40b.
export { DEFAULT_INPUT_ACTIONS, DEFAULT_INPUT_MAP, mouseBinding };
export type { InputBinding, InputMap };

export const MOUSE_BINDINGS: Record<'left' | 'middle' | 'right', InputBinding> = { left: 'Mouse0', middle: 'Mouse1', right: 'Mouse2' };

/** Leitura de ações: o que Behaviors, Triggers e a simulação enxergam (nunca o dispositivo). */
export interface InputReader {
  isActionPressed(action: string): boolean;
  isActionJustPressed(action: string): boolean;
  isActionJustReleased(action: string): boolean;
  /** Força da ação em [0, 1]: 1 para tecla/botão pressionado; 0–1 num eixo analógico (já sem a zona morta). */
  getActionStrength?(action: string): number;
  /** `pos` menos `neg` (força): `-1`, `0` ou `+1` no teclado; fracionário num analógico. */
  getAxis(negative: string, positive: string): number;
}

/** Força da ação (0–1) de qualquer leitor: usa `getActionStrength` quando o leitor o tem, senão 1/0 por `isActionPressed`. */
export const readActionStrength = (reader: InputReader, action: string): number => reader.getActionStrength?.(action) ?? (reader.isActionPressed(action) ? 1 : 0);

export type InputPhase = 'pressed' | 'released';
export interface InputActionEvent {
  action: string;
  phase: InputPhase;
}

export interface PointerState {
  x: number;
  y: number;
  /** Deslocamento acumulado desde o último `endFrame`. */
  dx: number;
  dy: number;
  /** AIS-47d: roda do mouse acumulada desde o último `endFrame` (`deltaY` normalizado em linhas: > 0 = para baixo/longe). */
  wheel: number;
  /** AIS-47d: retângulo da viewport na página (px, o mesmo espaço de `x`/`y`); `null` = desconhecido (testes/sem DOM). */
  bounds: { left: number; top: number; width: number; height: number } | null;
}

/** Alvo de eventos mínimo (Window/HTMLElement; nos testes, um espião que conta add/remove). */
export interface InputEventTarget {
  addEventListener(type: string, listener: (event: any) => void, options?: unknown): void;
  removeEventListener(type: string, listener: (event: any) => void, options?: unknown): void;
}

export interface AttachTargets {
  /** Recebe teclado e `blur` (normalmente `window`). */
  keyTarget: InputEventTarget;
  /** Recebe mouse (normalmente o canvas/contêiner da viewport). */
  pointerTarget?: InputEventTarget;
  /** Foco em campo de texto: o jogo não rouba a digitação. Padrão: `input`/`textarea`/`select`/`contenteditable`. */
  isTextEntry?: (target: EventTarget | null) => boolean;
  /** Fonte dos gamepads lidos por `poll()` (padrão: `navigator.getGamepads`). */
  getGamepads?: () => ReadonlyArray<GamepadLike | null | undefined>;
}

const defaultIsTextEntry = (target: EventTarget | null): boolean => {
  const t = target as { tagName?: string; isContentEditable?: boolean } | null;
  const tag = t?.tagName?.toUpperCase();
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || !!t?.isContentEditable;
};

export class InputManager implements InputReader {
  private map: Record<string, readonly InputBinding[]>;
  private down = new Set<InputBinding>();
  private justDown = new Set<InputBinding>();
  private justUp = new Set<InputBinding>();
  private actionJustPressed = new Set<string>();
  private actionJustReleased = new Set<string>();
  private listeners = new Set<(event: InputActionEvent) => void>();
  private detach: (() => void) | null = null;
  private active = false;
  /** AIS-58: força analógica por binding de eixo (já sem zona morta) e bindings de gamepad atualmente pressionados. */
  private analog = new Map<InputBinding, number>();
  private padDown = new Set<InputBinding>();
  private deadzone = DEFAULT_DEADZONE;
  private gamepadSource: (() => ReadonlyArray<GamepadLike | null | undefined>) | null = null;
  private readonly pointerState: PointerState = { x: 0, y: 0, dx: 0, dy: 0, wheel: 0, bounds: null };

  constructor(map: InputMap = DEFAULT_INPUT_MAP) {
    this.map = this.copyMap(map);
  }

  // ── Mapa ────────────────────────────────────────────────────────────────────
  private copyMap(map: InputMap): Record<string, readonly InputBinding[]> {
    return Object.fromEntries(Object.entries(map).map(([action, bindings]) => [action, [...bindings]]));
  }

  getMap(): InputMap {
    return this.copyMap(this.map);
  }

  /** Troca o mapa inteiro (estado de entrada zerado: um binding antigo não fica "preso"). */
  setMap(map: InputMap): void {
    this.map = this.copyMap(map);
    this.releaseAll();
  }

  /** Remapeia UMA ação (ex.: `rebind('Jump', ['KeyJ'])`). */
  rebind(action: string, bindings: readonly InputBinding[]): void {
    this.map = { ...this.map, [action]: [...bindings] };
    this.releaseAll();
  }

  bindingsOf(action: string): readonly InputBinding[] {
    return this.map[action] ?? [];
  }

  /** Alguma ação usa este binding? (o DOM só impede o comportamento padrão — rolagem — de teclas do jogo). */
  isBound(binding: InputBinding): boolean {
    return Object.values(this.map).some((bindings) => bindings.includes(binding));
  }

  actions(): string[] {
    return Object.keys(this.map);
  }

  // ── Estado de ligado/desligado ──────────────────────────────────────────────
  /** Desligado = todo evento é ignorado e o estado fica zerado (fora de Play o jogo não "vê" teclas do editor). */
  get enabled(): boolean {
    return this.active;
  }

  setEnabled(enabled: boolean): void {
    this.active = enabled;
    if (!enabled) this.releaseAll();
  }

  // ── Gamepad (AIS-58) ────────────────────────────────────────────────────────
  /** Zona morta dos eixos analógicos, em [0, 0,95]; valor inválido volta ao padrão. */
  setDeadzone(value: number): void {
    this.deadzone = resolveDeadzone(value);
  }

  getDeadzone(): number {
    return this.deadzone;
  }

  /** Define de onde `poll()` lê os gamepads (testes injetam; `attach` usa `navigator.getGamepads`). */
  setGamepadSource(source: (() => ReadonlyArray<GamepadLike | null | undefined>) | null): void {
    this.gamepadSource = source;
  }

  /**
   * Lê os gamepads e atualiza os bindings `Pad:…` (botões e eixos de QUALQUER pad conectado, em conjunto). Chamar uma vez por
   * quadro, ANTES da simulação (o `endFrame` vem depois). Sem fonte ou desligado, não faz nada.
   */
  poll(): void {
    if (!this.active || !this.gamepadSource) return;
    const pads = this.gamepadSource();
    const pressed = new Set<InputBinding>();
    const analog = new Map<InputBinding, number>();
    for (const pad of pads) {
      if (!pad?.connected) continue;
      pad.buttons.forEach((button, i) => {
        if (button.pressed || button.value > 0.5) pressed.add(padButtonBinding(i));
      });
      pad.axes.forEach((raw, i) => {
        const magnitude = Math.abs(raw);
        if (!Number.isFinite(raw) || magnitude <= this.deadzone) return;
        const strength = Math.min(1, (magnitude - this.deadzone) / (1 - this.deadzone));
        const binding = padAxisBinding(i, raw > 0 ? '+' : '-');
        pressed.add(binding);
        analog.set(binding, Math.max(analog.get(binding) ?? 0, strength));
      });
    }
    this.analog = analog;
    for (const binding of pressed) {
      if (!this.padDown.has(binding)) {
        this.padDown.add(binding);
        this.handleBinding(binding, true);
      }
    }
    for (const binding of [...this.padDown]) {
      if (!pressed.has(binding)) {
        this.padDown.delete(binding);
        this.handleBinding(binding, false);
      }
    }
  }

  // ── Entrada (alimentada por `attach` ou pelos testes) ───────────────────────
  private actionsUsing(binding: InputBinding): string[] {
    return Object.entries(this.map)
      .filter(([, bindings]) => bindings.includes(binding))
      .map(([action]) => action);
  }

  handleBinding(binding: InputBinding, isDown: boolean): void {
    if (!this.active) return;
    const wasDown = this.down.has(binding);
    if (isDown === wasDown) return; // repetição automática do teclado: nada muda
    const affected = this.actionsUsing(binding);
    const before = new Map(affected.map((action) => [action, this.isActionPressed(action)]));
    if (isDown) {
      this.down.add(binding);
      this.justDown.add(binding);
    } else {
      this.down.delete(binding);
      this.justUp.add(binding);
    }
    for (const action of affected) {
      const was = before.get(action) ?? false;
      const now = this.isActionPressed(action);
      if (was === now) continue; // outro binding da mesma ação continua pressionado
      (now ? this.actionJustPressed : this.actionJustReleased).add(action);
      this.emit({ action, phase: now ? 'pressed' : 'released' });
    }
  }

  handleKey(code: string, isDown: boolean): void {
    this.handleBinding(code, isDown);
  }

  handleMouseButton(button: number, isDown: boolean): void {
    this.handleBinding(mouseBinding(button), isDown);
  }

  handlePointerMove(x: number, y: number): void {
    if (!this.active) return;
    this.pointerState.dx += x - this.pointerState.x;
    this.pointerState.dy += y - this.pointerState.y;
    this.pointerState.x = x;
    this.pointerState.y = y;
  }

  /** AIS-47: deslocamento RELATIVO do ponteiro (PointerLock: `movementX/Y`; a posição fica parada). Soma ao deslocamento do quadro. */
  handlePointerDelta(dx: number, dy: number): void {
    if (!this.active) return;
    this.pointerState.dx += dx;
    this.pointerState.dy += dy;
  }

  /** AIS-47d: roda do mouse (deslocamento vertical já em linhas). Soma ao acumulado do quadro; só vale com o input ativo. */
  handleWheel(deltaLines: number): void {
    if (!this.active) return;
    this.pointerState.wheel += deltaLines;
  }

  /** AIS-47d: retângulo da viewport na página (px); `null` o esquece. O DOM o atualiza a cada mouse/roda; testes o injetam. */
  setPointerBounds(bounds: PointerState['bounds']): void {
    this.pointerState.bounds = bounds ? { ...bounds } : null;
  }

  /** Perda de foco da janela: solta tudo (senão a tecla soltada fora ficaria presa). */
  releaseAll(): void {
    if (this.active) {
      for (const binding of [...this.down]) this.handleBinding(binding, false);
    }
    this.down.clear();
    this.padDown.clear();
    this.analog.clear();
    this.justDown.clear();
    this.justUp.clear();
    this.actionJustPressed.clear();
    this.actionJustReleased.clear();
    this.pointerState.dx = 0;
    this.pointerState.dy = 0;
    this.pointerState.wheel = 0;
  }

  /** Fim do quadro: `justPressed`/`justReleased` valem por UM quadro. Chamar uma vez por frame de simulação. */
  endFrame(): void {
    this.justDown.clear();
    this.justUp.clear();
    this.actionJustPressed.clear();
    this.actionJustReleased.clear();
    this.pointerState.dx = 0;
    this.pointerState.dy = 0;
    this.pointerState.wheel = 0;
  }

  // ── Leitura por ação ────────────────────────────────────────────────────────
  isActionPressed(action: string): boolean {
    return this.bindingsOf(action).some((binding) => this.down.has(binding));
  }

  isActionJustPressed(action: string): boolean {
    return this.actionJustPressed.has(action);
  }

  isActionJustReleased(action: string): boolean {
    return this.actionJustReleased.has(action);
  }

  getActionStrength(action: string): number {
    let strength = 0;
    for (const binding of this.bindingsOf(action)) {
      if (!this.down.has(binding)) continue;
      // eixo analógico: a força vem do eixo; tecla, botão e mouse valem 1
      strength = Math.max(strength, parsePadBinding(binding)?.kind === 'axis' ? (this.analog.get(binding) ?? 1) : 1);
    }
    return strength;
  }

  getAxis(negative: string, positive: string): number {
    return Math.max(-1, Math.min(1, this.getActionStrength(positive) - this.getActionStrength(negative)));
  }

  // ── Leitura bruta (só Triggers de tecla/mouse; Behaviors usam ações) ────────
  isBindingPressed(binding: InputBinding): boolean {
    return this.down.has(binding);
  }
  isBindingJustPressed(binding: InputBinding): boolean {
    return this.justDown.has(binding);
  }
  isBindingJustReleased(binding: InputBinding): boolean {
    return this.justUp.has(binding);
  }

  get pointer(): Readonly<PointerState> {
    return this.pointerState;
  }

  // ── Assinaturas (sempre com disposer) ───────────────────────────────────────
  subscribe(listener: (event: InputActionEvent) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private emit(event: InputActionEvent): void {
    for (const listener of [...this.listeners]) listener(event);
  }

  get listenerCount(): number {
    return this.listeners.size;
  }

  // ── DOM ─────────────────────────────────────────────────────────────────────
  /**
   * Liga o manager aos eventos do DOM e o ATIVA. Devolve o disposer (remove TODOS os listeners e desliga). Chamar `attach` de
   * novo sem dispor antes descarta a ligação anterior: nunca há dois conjuntos de listeners (Play/Stop repetido, StrictMode).
   */
  attach(targets: AttachTargets): () => void {
    this.detach?.();
    const isTextEntry = targets.isTextEntry ?? defaultIsTextEntry;
    const cleanups: (() => void)[] = [];
    const on = (target: InputEventTarget | undefined, type: string, listener: (event: any) => void, options?: unknown) => {
      if (!target) return;
      target.addEventListener(type, listener, options);
      cleanups.push(() => target.removeEventListener(type, listener, options));
    };
    /** AIS-47d: retângulo atual da viewport (o contêiner do `pointerTarget`), no espaço de `clientX/Y`. */
    const trackBounds = (e: { currentTarget?: unknown }) => {
      const el = e.currentTarget as { getBoundingClientRect?: () => { left: number; top: number; width: number; height: number } } | null | undefined;
      if (el && typeof el.getBoundingClientRect === 'function') {
        const r = el.getBoundingClientRect();
        this.setPointerBounds({ left: r.left, top: r.top, width: r.width, height: r.height });
      }
    };

    on(targets.keyTarget, 'keydown', (e: KeyboardEvent) => {
      if (e.repeat || isTextEntry(e.target)) return;
      this.handleKey(e.code, true);
      if (this.isBound(e.code)) e.preventDefault(); // espaço/setas não rolam a página durante o jogo
    });
    on(targets.keyTarget, 'keyup', (e: KeyboardEvent) => this.handleKey(e.code, false));
    on(targets.keyTarget, 'blur', () => this.releaseAll());
    on(targets.pointerTarget, 'mousedown', (e: MouseEvent) => this.handleMouseButton(e.button, true));
    on(targets.pointerTarget, 'mouseup', (e: MouseEvent) => this.handleMouseButton(e.button, false));
    // com o ponteiro CAPTURADO (PointerLock) `clientX/Y` não muda: o olhar usa o deslocamento relativo (`movementX/Y`)
    on(targets.pointerTarget, 'mousemove', (e: MouseEvent) => {
      trackBounds(e);
      if (typeof document !== 'undefined' && document.pointerLockElement) this.handlePointerDelta(e.movementX ?? 0, e.movementY ?? 0);
      else this.handlePointerMove(e.clientX, e.clientY);
    });
    // AIS-47d: roda do mouse (zoom da câmera RTS). `deltaMode` 1 = linhas; 0 = pixels (≈ 100 por "clique"). Não rola a página durante o jogo.
    on(
      targets.pointerTarget,
      'wheel',
      (e: WheelEvent) => {
        trackBounds(e);
        this.handleWheel(e.deltaMode === 1 ? e.deltaY : e.deltaY / 100);
        if (this.active) e.preventDefault();
      },
      { passive: false }
    );
    // soltar o botão fora do canvas também solta a ação
    on(targets.keyTarget, 'mouseup', (e: MouseEvent) => this.handleMouseButton(e.button, false));

    // AIS-58: gamepads por polling (`navigator.getGamepads`), sem lib; `poll()` roda uma vez por quadro de simulação
    this.gamepadSource = targets.getGamepads ?? (typeof navigator !== 'undefined' && typeof navigator.getGamepads === 'function' ? () => Array.from(navigator.getGamepads()) : null);

    this.setEnabled(true);
    const dispose = () => {
      if (this.detach !== dispose) return; // já descartado (idempotente)
      this.detach = null;
      for (const cleanup of cleanups.splice(0)) cleanup();
      this.setEnabled(false);
      this.gamepadSource = null;
    };
    this.detach = dispose;
    return dispose;
  }

  get attached(): boolean {
    return this.detach !== null;
  }
}
