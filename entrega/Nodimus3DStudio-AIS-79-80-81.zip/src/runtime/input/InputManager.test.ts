import { describe, expect, it, vi } from 'vitest';
import { defaultInputMap as defaultInputMapForTest } from '../../core/inputMap';
import { DEFAULT_INPUT_ACTIONS, DEFAULT_INPUT_MAP, InputManager, type InputEventTarget } from './InputManager';
import { evaluateInputTrigger, keyCodesOf } from './inputTriggers';
import { globalInputManager } from './global';
import { LogicRegistry } from '../../logic/registry';
import { dispatchDesktopShortcut, type ShortcutActionHandlers } from '../../hooks/useDesktopShortcuts';

const on = () => {
  const m = new InputManager();
  m.setEnabled(true);
  return m;
};

/** Alvo de eventos falso que conta listeners vivos por tipo e deixa disparar eventos. */
class FakeTarget implements InputEventTarget {
  listeners = new Map<string, Set<(e: any) => void>>();
  addEventListener(type: string, l: (e: any) => void) {
    this.listeners.set(type, (this.listeners.get(type) ?? new Set()).add(l));
  }
  removeEventListener(type: string, l: (e: any) => void) {
    this.listeners.get(type)?.delete(l);
  }
  get count() {
    return [...this.listeners.values()].reduce((n, s) => n + s.size, 0);
  }
  fire(type: string, event: Record<string, unknown> = {}) {
    const e = { preventDefault: vi.fn(), target: null, repeat: false, ...event };
    for (const l of [...(this.listeners.get(type) ?? [])]) l(e);
    return e;
  }
}

describe('AIS-40b — ações semânticas (C01)', () => {
  it('W mapeia para MoveForward (e as setas também); a ação some ao soltar', () => {
    const m = on();
    m.handleKey('KeyW', true);
    expect(m.isActionPressed('MoveForward')).toBe(true);
    expect(m.isActionPressed('MoveBackward')).toBe(false);
    m.handleKey('KeyW', false);
    expect(m.isActionPressed('MoveForward')).toBe(false);
    m.handleKey('ArrowUp', true);
    expect(m.isActionPressed('MoveForward')).toBe(true);
  });

  it('o mapa padrão traz as ações semânticas pedidas', () => {
    for (const a of ['MoveForward', 'MoveBackward', 'MoveLeft', 'MoveRight', 'Jump', 'Interact']) expect(DEFAULT_INPUT_ACTIONS).toContain(a);
    expect(DEFAULT_INPUT_MAP.Jump).toEqual(['Space']);
  });

  it('remapear uma ação muda quem a consulta, sem editar o consumidor', () => {
    const m = on();
    m.rebind('Jump', ['KeyJ']);
    m.handleKey('Space', true);
    expect(m.isActionPressed('Jump')).toBe(false);
    m.handleKey('KeyJ', true);
    expect(m.isActionPressed('Jump')).toBe(true);
  });

  it('o mapa devolvido é cópia (mexer nele não muda o manager)', () => {
    const m = on();
    (m.getMap().Jump as string[]).push('KeyX');
    expect(m.bindingsOf('Jump')).toEqual(['Space']);
  });

  it('mouse: botão esquerdo é a ação Fire; o direito é AltFire', () => {
    const m = on();
    m.handleMouseButton(0, true);
    expect(m.isActionPressed('Fire')).toBe(true);
    expect(m.isActionPressed('AltFire')).toBe(false);
    m.handleMouseButton(2, true);
    expect(m.isActionPressed('AltFire')).toBe(true);
  });
});

describe('AIS-40b — pressed / justPressed / justReleased / eixos', () => {
  it('justPressed e justReleased valem por UM quadro (endFrame)', () => {
    const m = on();
    m.handleKey('Space', true);
    expect(m.isActionJustPressed('Jump')).toBe(true);
    expect(m.isActionPressed('Jump')).toBe(true);
    m.endFrame();
    expect(m.isActionJustPressed('Jump')).toBe(false);
    expect(m.isActionPressed('Jump')).toBe(true);
    m.handleKey('Space', false);
    expect(m.isActionJustReleased('Jump')).toBe(true);
    m.endFrame();
    expect(m.isActionJustReleased('Jump')).toBe(false);
  });

  it('repetição automática do teclado não gera novo justPressed', () => {
    const m = on();
    m.handleKey('Space', true);
    m.endFrame();
    m.handleKey('Space', true);
    expect(m.isActionJustPressed('Jump')).toBe(false);
  });

  it('dois bindings da mesma ação: só a primeira pressão e a última soltura contam', () => {
    const m = on();
    const events: string[] = [];
    // `ui_up` compartilha W/↑ com MoveForward (AIS-58): conta só os eventos da ação testada
    m.subscribe((e) => e.action === 'MoveForward' && events.push(`${e.action}:${e.phase}`));
    m.handleKey('KeyW', true);
    m.handleKey('ArrowUp', true);
    m.handleKey('KeyW', false);
    expect(m.isActionPressed('MoveForward')).toBe(true); // a seta ainda segura
    m.handleKey('ArrowUp', false);
    expect(events).toEqual(['MoveForward:pressed', 'MoveForward:released']);
  });

  it('eixos: -1, 0, +1; opostos juntos se anulam', () => {
    const m = on();
    expect(m.getAxis('MoveLeft', 'MoveRight')).toBe(0);
    m.handleKey('KeyD', true);
    expect(m.getAxis('MoveLeft', 'MoveRight')).toBe(1);
    m.handleKey('KeyA', true);
    expect(m.getAxis('MoveLeft', 'MoveRight')).toBe(0);
    m.handleKey('KeyD', false);
    expect(m.getAxis('MoveLeft', 'MoveRight')).toBe(-1);
  });

  it('releaseAll (perda de foco) solta tudo e emite released', () => {
    const m = on();
    const events: string[] = [];
    m.subscribe((e) => e.action === 'MoveForward' && events.push(e.phase));
    m.handleKey('KeyW', true);
    m.releaseAll();
    expect(m.isActionPressed('MoveForward')).toBe(false);
    expect(events).toEqual(['pressed', 'released']);
  });

  it('ponteiro acumula o deslocamento até o fim do quadro', () => {
    const m = on();
    m.handlePointerMove(10, 10);
    m.handlePointerMove(14, 7);
    expect(m.pointer).toMatchObject({ x: 14, y: 7, dx: 14, dy: 7 });
    m.endFrame();
    expect(m.pointer).toMatchObject({ x: 14, y: 7, dx: 0, dy: 0 });
  });
});

describe('AIS-40b — ligado só em Play; atalhos do editor não viram gameplay (C04)', () => {
  it('desligado ignora qualquer evento e mantém o estado zerado', () => {
    const m = new InputManager();
    m.handleKey('KeyW', true);
    m.handleMouseButton(0, true);
    expect(m.isActionPressed('MoveForward')).toBe(false);
    expect(m.isActionPressed('Fire')).toBe(false);
    expect(m.isActionJustPressed('MoveForward')).toBe(false);
  });

  it('desligar zera o que estava pressionado', () => {
    const m = on();
    m.handleKey('KeyW', true);
    m.setEnabled(false);
    m.setEnabled(true);
    expect(m.isActionPressed('MoveForward')).toBe(false);
  });

  it('o manager global nasce desligado (nada escuta fora de Play)', () => {
    expect(globalInputManager.enabled).toBe(false);
    expect(globalInputManager.attached).toBe(false);
  });

  const keyEvent = (k: string): KeyboardEvent =>
    ({ key: k, ctrlKey: false, metaKey: false, shiftKey: false, altKey: false, target: null, preventDefault: () => {} }) as unknown as KeyboardEvent;
  const handlers = (extra: Partial<ShortcutActionHandlers> = {}) => ({
    onTranslateGizmo: vi.fn(),
    onRotateGizmo: vi.fn(),
    onScaleGizmo: vi.fn(),
    onFrameSelected: vi.fn(),
    onDeleteSelected: vi.fn(),
    onStopSimulation: vi.fn(),
    onEscape: vi.fn(),
    selectedNodeId: 'n1',
    ...extra,
  });

  it('em Play, W/E/R/F e Delete do editor não disparam (as teclas são do jogo)', () => {
    const h = handlers({ isPlaying: true });
    for (const k of ['w', 'e', 'r', 'f', 'Delete', 'Backspace']) expect(dispatchDesktopShortcut(keyEvent(k), h)).toBeNull();
    expect(h.onTranslateGizmo).not.toHaveBeenCalled();
    expect(h.onDeleteSelected).not.toHaveBeenCalled();
  });

  it('em Play, Esc e F8 (parar) continuam sendo do editor; fora de Play W volta a ser o gizmo', () => {
    const h = handlers({ isPlaying: true });
    expect(dispatchDesktopShortcut(keyEvent('F8'), h)).toBe('stop_simulation');
    expect(dispatchDesktopShortcut(keyEvent('Escape'), h)).toBe('escape');
    expect(dispatchDesktopShortcut(keyEvent('w'), handlers({ isPlaying: false }))).toBe('gizmo_translate');
  });
});

describe('AIS-40b — disposer: Play/Stop repetido não duplica listeners (C03)', () => {
  const targets = () => ({ keyTarget: new FakeTarget(), pointerTarget: new FakeTarget() });

  it('attach liga e ativa; o disposer remove TODOS os listeners e desliga', () => {
    const m = new InputManager();
    const t = targets();
    const dispose = m.attach(t);
    expect(m.enabled).toBe(true);
    expect(t.keyTarget.count).toBeGreaterThan(0);
    expect(t.pointerTarget.count).toBeGreaterThan(0);
    dispose();
    expect(t.keyTarget.count).toBe(0);
    expect(t.pointerTarget.count).toBe(0);
    expect(m.enabled).toBe(false);
    dispose(); // idempotente
    expect(m.enabled).toBe(false);
  });

  it('dez ciclos Play/Stop deixam zero listeners e um único conjunto durante o Play', () => {
    const m = new InputManager();
    const t = targets();
    let perAttach = 0;
    for (let i = 0; i < 10; i++) {
      const dispose = m.attach(t);
      if (i === 0) perAttach = t.keyTarget.count + t.pointerTarget.count;
      expect(t.keyTarget.count + t.pointerTarget.count).toBe(perAttach);
      dispose();
      expect(t.keyTarget.count + t.pointerTarget.count).toBe(0);
    }
  });

  it('attach sem dispor antes (StrictMode) não acumula: a ligação anterior é descartada', () => {
    const m = new InputManager();
    const t = targets();
    m.attach(t);
    const first = t.keyTarget.count;
    m.attach(t);
    expect(t.keyTarget.count).toBe(first);
    // e o disposer antigo, tardio, não derruba a ligação nova
    const stale = m.attach(t);
    const live = m.attach(t);
    stale();
    expect(m.enabled).toBe(true);
    live();
    expect(m.enabled).toBe(false);
  });

  it('eventos do DOM chegam como ações; campo de texto e repetição não alimentam o jogo', () => {
    const m = new InputManager();
    const t = targets();
    const dispose = m.attach(t);
    const e = t.keyTarget.fire('keydown', { code: 'KeyW' });
    expect(m.isActionPressed('MoveForward')).toBe(true);
    expect(e.preventDefault).toHaveBeenCalled(); // tecla do jogo não rola a página
    t.keyTarget.fire('keyup', { code: 'KeyW' });
    expect(m.isActionPressed('MoveForward')).toBe(false);
    t.keyTarget.fire('keydown', { code: 'KeyA', target: { tagName: 'INPUT' } });
    expect(m.isActionPressed('MoveLeft')).toBe(false);
    const fn = vi.fn();
    m.subscribe((e) => e.action === 'MoveRight' && fn(e)); // ui_right compartilha o D
    t.keyTarget.fire('keydown', { code: 'KeyD' });
    t.keyTarget.fire('keydown', { code: 'KeyD', repeat: true });
    expect(fn).toHaveBeenCalledTimes(1);
    t.pointerTarget.fire('mousedown', { button: 0 });
    expect(m.isActionPressed('Fire')).toBe(true);
    t.keyTarget.fire('blur');
    expect(m.isActionPressed('Fire')).toBe(false);
    dispose();
  });

  it('a assinatura devolve disposer', () => {
    const m = on();
    const off = m.subscribe(() => undefined);
    expect(m.listenerCount).toBe(1);
    off();
    expect(m.listenerCount).toBe(0);
  });
});

describe('AIS-40b — Triggers consultam ações, não o dispositivo (C02)', () => {
  it('on_input_action: pressed / released / held', () => {
    const m = on();
    const fires = (phase: string) => evaluateInputTrigger(m, 'on_input_action', { action: 'Jump', phase });
    m.handleKey('Space', true);
    expect([fires('pressed').fired, fires('held').fired, fires('released').fired]).toEqual([true, true, false]);
    m.endFrame();
    expect([fires('pressed').fired, fires('held').fired]).toEqual([false, true]);
    m.handleKey('Space', false);
    expect(fires('released').fired).toBe(true);
  });

  it('on_input_action segue o remapeamento: o Trigger não muda', () => {
    const m = on();
    m.rebind('Jump', ['KeyJ']);
    m.handleKey('KeyJ', true);
    expect(evaluateInputTrigger(m, 'on_input_action', { action: 'Jump' }).fired).toBe(true);
  });

  it('on_key_down / on_key_up aceitam nomes amigáveis do parâmetro key', () => {
    expect(keyCodesOf('w')).toEqual(['KeyW']);
    expect(keyCodesOf('5')).toEqual(['Digit5']);
    expect(keyCodesOf('Shift')).toEqual(['ShiftLeft', 'ShiftRight']);
    expect(keyCodesOf('Esc')).toEqual(['Escape']);
    expect(keyCodesOf('ArrowUp')).toEqual(['ArrowUp']);
    expect(keyCodesOf('')).toEqual([]);
    const m = on();
    m.handleKey('ShiftRight', true);
    expect(evaluateInputTrigger(m, 'on_key_down', { key: 'Shift' }).fired).toBe(true);
    m.endFrame();
    m.handleKey('ShiftRight', false);
    expect(evaluateInputTrigger(m, 'on_key_up', { key: 'Shift' }).fired).toBe(true);
    expect(evaluateInputTrigger(m, 'on_key_down', { key: '' }).fired).toBe(false);
  });

  it('on_mouse_down: botão certo dispara; alvo "object" pede o raycast ao runtime', () => {
    const m = on();
    m.handleMouseButton(2, true);
    expect(evaluateInputTrigger(m, 'on_mouse_down', { button: 'left' }).fired).toBe(false);
    expect(evaluateInputTrigger(m, 'on_mouse_down', { button: 'right', target: 'anywhere' })).toEqual({ handled: true, fired: true, needsPick: false });
    expect(evaluateInputTrigger(m, 'on_mouse_down', { button: 'right', target: 'object' }).needsPick).toBe(true);
  });

  it('Triggers que não são de input não são tratados aqui', () => {
    expect(evaluateInputTrigger(on(), 'on_update')).toEqual({ handled: false, fired: false });
  });

  it('o Trigger on_input_action existe no registro com as ações do InputManager no picker', () => {
    const def = LogicRegistry.getTrigger('on_input_action')!;
    expect(def).toBeDefined();
    expect(def.params.find((p) => p.key === 'action')!.options).toEqual([...DEFAULT_INPUT_ACTIONS]);
    expect(def.params.find((p) => p.key === 'phase')!.options).toEqual(['pressed', 'released', 'held']);
  });
});

describe('AIS-58 — gamepad por polling, zona morta e força da ação', () => {
  const pad = (buttons: number[] = [], axes: number[] = [0, 0, 0, 0]) => ({
    connected: true,
    buttons: Array.from({ length: 16 }, (_, i) => ({ pressed: buttons.includes(i), value: buttons.includes(i) ? 1 : 0 })),
    axes,
  });
  const setup = () => {
    const m = new InputManager();
    m.setEnabled(true);
    let pads: ReturnType<typeof pad>[] = [pad()];
    m.setMap(defaultInputMapForTest());
    m.setGamepadSource(() => pads);
    return { m, set: (p: ReturnType<typeof pad>) => { pads = [p]; } };
  };

  it('botão do gamepad aciona a MESMA ação do teclado (Jump) com justPressed/justReleased por quadro', () => {
    const { m, set } = setup();
    set(pad([0]));
    m.poll();
    expect(m.isActionPressed('Jump')).toBe(true);
    expect(m.isActionJustPressed('Jump')).toBe(true);
    m.endFrame();
    m.poll();
    expect(m.isActionJustPressed('Jump')).toBe(false); // segurado: sem novo justPressed
    set(pad());
    m.poll();
    expect(m.isActionPressed('Jump')).toBe(false);
    expect(m.isActionJustReleased('Jump')).toBe(true);
  });

  it('analógico esquerdo move: força analógica, zona morta e getAxis fracionário', () => {
    const { m, set } = setup();
    m.setDeadzone(0.2);
    set(pad([], [0.1, 0, 0, 0]));
    m.poll();
    expect(m.isActionPressed('MoveRight')).toBe(false); // dentro da zona morta
    set(pad([], [0.6, 0, 0, 0]));
    m.poll();
    expect(m.isActionPressed('MoveRight')).toBe(true);
    expect(m.getActionStrength('MoveRight')).toBeCloseTo(0.5, 5); // (0,6 − 0,2) / (1 − 0,2)
    expect(m.getAxis('MoveLeft', 'MoveRight')).toBeCloseTo(0.5, 5);
    set(pad([], [-1, 0, 0, 0]));
    m.poll();
    expect(m.getAxis('MoveLeft', 'MoveRight')).toBe(-1);
    expect(m.isActionPressed('MoveRight')).toBe(false);
  });

  it('tecla vale força 1; teclado e gamepad na mesma ação não se atrapalham', () => {
    const { m, set } = setup();
    m.handleKey('KeyD', true);
    expect(m.getActionStrength('MoveRight')).toBe(1);
    set(pad([], [0.6, 0, 0, 0]));
    m.poll();
    m.handleKey('KeyD', false);
    expect(m.isActionPressed('MoveRight')).toBe(true); // o analógico segue
    expect(m.getActionStrength('MoveRight')).toBeCloseTo(0.5, 5);
  });

  it('desligado ou sem fonte, poll() não faz nada; desconectado solta o que estava preso; deadzone inválida volta ao padrão', () => {
    const m = new InputManager();
    m.setGamepadSource(() => [pad([0])]);
    m.poll();
    expect(m.isActionPressed('Jump')).toBe(false); // desligado
    const { m: on, set } = setup();
    set(pad([0]));
    on.poll();
    expect(on.isActionPressed('Jump')).toBe(true);
    on.setGamepadSource(() => [{ ...pad([0]), connected: false }]);
    on.poll();
    expect(on.isActionPressed('Jump')).toBe(false);
    on.setDeadzone(9);
    expect(on.getDeadzone()).toBe(0.2);
  });

  it('remapear Jump no mapa muda o gamepad também, sem tocar nos consumidores', () => {
    const { m, set } = setup();
    m.rebind('Jump', ['Pad:B3']);
    set(pad([0]));
    m.poll();
    expect(m.isActionPressed('Jump')).toBe(false);
    set(pad([3]));
    m.poll();
    expect(m.isActionPressed('Jump')).toBe(true);
  });
});
