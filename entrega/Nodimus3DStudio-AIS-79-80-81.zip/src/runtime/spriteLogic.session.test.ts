import { describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { RuntimeSession } from './RuntimeSession';
import type { SpriteClipInfo } from './spriteHost';
import { LogicRegistry } from '../logic/registry';

/** AIS-76b — play_sprite_animation, set_sprite_frame e On Sprite Animation Finished na `RuntimeSession` (o registro dos clipes imita o apresentador da viewport). */

let seq = 0;
const act = (type: string, parameters: Record<string, unknown> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[], parameters: Record<string, unknown> = {}): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters, conditions: [], actions });
const behavior = (rules: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'B', behaviorType: 'custom_rules', enabled: true, properties: {}, rules });
const node = (id: string, type: string, extra: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type, parentId: null, childrenIds: [], visible: true, locked: false, properties: {}, ...extra }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes = { ...scene.nodes };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  nodes[root.id] = { ...root, childrenIds: [...root.childrenIds, ...extra.map((n) => n.id)] };
  return { ...scene, nodes };
}

const fakeInput = () => ({
  isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0,
  isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false,
});

const CLIPS: SpriteClipInfo[] = [
  { name: 'idle', frameIndices: [0, 1, 2], fps: 10, loopMode: 'loop' },
  { name: 'hit', frameIndices: [4, 5], fps: 10, loopMode: 'once' },
];
const REF = { id: 'res_sprite', type: 'sprite', path: 'res://sprites/Hero.sprite.json' };

const billboard = (behaviors: BehaviorInstance[], props: Record<string, unknown> = {}) => node('spr', 'Billboard', { properties: { spriteProject: REF, animation: '', speedScale: 1, autoplay: true, frame: 0, ...props }, behaviors });

function open(scene: SceneData) {
  const logs: { level: string; message: string; code?: string }[] = [];
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), mode: 'scene', input: fakeInput(), onLog: (e: any) => logs.push(e) } as any);
  session.start();
  const registerSprite = (nodeId = 'spr', animation = '') => session.sprites.register(nodeId, { clips: CLIPS, defaultAnimation: 'idle', animation, frameCount: 8 });
  return { session, logs, registerSprite };
}
const run = (s: RuntimeSession, seconds: number) => {
  for (let t = 0; t < seconds - 1e-9; t += 1 / 60) s.step(1 / 60);
};
const sig = (name: string, ...actions: LogicAction[]) => rule('on_signal', actions, { signal: name });

describe('catálogo', () => {
  it('as 2 Actions e o Trigger existem no LogicRegistry', () => {
    expect(LogicRegistry.isKnownAction('play_sprite_animation')).toBe(true);
    expect(LogicRegistry.isKnownAction('set_sprite_frame')).toBe(true);
    expect(LogicRegistry.isKnownTrigger('on_sprite_animation_finished')).toBe(true);
  });
});

describe('play_sprite_animation', () => {
  it('pedido feito ANTES de o sprite carregar fica adiado e roda no registro', () => {
    const { session, registerSprite } = open(sceneWith(billboard([behavior([rule('on_start', [act('play_sprite_animation', { target: 'spr', animation: 'hit' })])])])));
    session.step(1 / 60); // on_start dispara; o apresentador ainda não registrou
    registerSprite();
    expect(session.sprites.animationOf('spr')).toBe('hit');
    expect(session.sprites.frameOf('spr')).toBe(4);
    expect(session.scene.getInstance('spr')!.properties.animation).toBe('hit');
  });

  it('troca o clipe por sinal, sem novo Behavior; restart:false mantém; speedScale muda o frame no mesmo tempo', () => {
    const { session, registerSprite } = open(
      sceneWith(
        billboard([behavior([sig('go_hit', act('play_sprite_animation', { target: 'spr', animation: 'hit', speedScale: 2 })), sig('go_idle', act('play_sprite_animation', { target: 'spr', animation: 'idle', restart: false }))])])
      )
    );
    session.step(1 / 60);
    registerSprite();
    session.emitSignal('go_hit');
    session.step(1 / 60);
    expect(session.sprites.animationOf('spr')).toBe('hit');
    run(session, 0.06); // 2x: 120 ms de relógio → já no 2º quadro do clipe
    expect(session.sprites.frameOf('spr')).toBe(5);
    session.emitSignal('go_idle');
    session.step(1 / 60);
    expect(session.sprites.animationOf('spr')).toBe('idle');
    const frameBefore = session.sprites.frameOf('spr');
    session.emitSignal('go_idle'); // restart:false na MESMA animação: não reinicia
    run(session, 0.05);
    expect(session.sprites.frameOf('spr')).not.toBe(frameBefore === 0 ? -1 : 0 /* continuou avançando */);
    expect(session.sprites.animationOf('spr')).toBe('idle');
  });

  it('once congela no último frame', () => {
    const { session, registerSprite } = open(sceneWith(billboard([behavior([sig('go', act('play_sprite_animation', { target: 'spr', animation: 'hit' }))])])));
    session.step(1 / 60);
    registerSprite();
    session.emitSignal('go');
    run(session, 3);
    expect(session.sprites.frameOf('spr')).toBe(5);
    expect(session.sprites.isPlaying('spr')).toBe(false);
  });

  it('animação inexistente gera diagnóstico e a atual continua; alvo que não é Billboard também (sem exceção)', () => {
    const { session, logs, registerSprite } = open(
      sceneWith(
        billboard([behavior([sig('bad', act('play_sprite_animation', { target: 'spr', animation: 'nao_existe' })), sig('bad2', act('play_sprite_animation', { target: 'cubo' }))])]),
        node('cubo', 'MeshInstance', { properties: {} })
      )
    );
    session.step(1 / 60);
    registerSprite('spr', 'idle');
    session.emitSignal('bad');
    session.emitSignal('bad2');
    expect(() => run(session, 0.1)).not.toThrow();
    expect(session.sprites.animationOf('spr')).toBe('idle');
    expect(logs.some((l) => l.code === 'sprite.unknown_animation')).toBe(true);
    expect(logs.some((l) => l.code === 'sprite.invalid_target' || l.code === 'action.incompatible_node_type'), JSON.stringify(logs)).toBe(true); // a validação do catálogo barra antes do executor
  });
});

describe('set_sprite_frame', () => {
  it('mostra o frame (clampado ao atlas) e pausa', () => {
    const { session, logs, registerSprite } = open(sceneWith(billboard([behavior([sig('f', act('set_sprite_frame', { target: 'spr', frame: 99 })), sig('g', act('set_sprite_frame', { target: 'spr', frame: 2.4 }))])])));
    session.step(1 / 60);
    registerSprite();
    session.emitSignal('f');
    run(session, 0.3);
    expect(session.sprites.frameOf('spr')).toBe(7); // clamp: atlas de 8 quadros
    expect(session.sprites.isPlaying('spr')).toBe(false);
    expect(logs.some((l) => l.code === 'sprite.frame_clamped')).toBe(true);
    session.emitSignal('g');
    run(session, 0.3);
    expect(session.sprites.frameOf('spr')).toBe(2); // arredondado
  });

  it('pause:false segue tocando a partir do quadro (se ele está na animação)', () => {
    const { session, registerSprite } = open(sceneWith(billboard([behavior([sig('f', act('set_sprite_frame', { target: 'spr', frame: 1, pause: false }))])])));
    session.step(1 / 60);
    registerSprite('spr', 'idle');
    session.emitSignal('f');
    session.step(1 / 60);
    expect(session.sprites.isPlaying('spr')).toBe(true);
    expect(session.sprites.frameOf('spr')).toBe(1);
  });
});

describe('On Sprite Animation Finished', () => {
  it('dispara só ao fim de um clipe once e encadeia outra Action (filtro por nome)', () => {
    const { session, registerSprite } = open(
      sceneWith(
        billboard([
          behavior([
            sig('go', act('play_sprite_animation', { target: 'spr', animation: 'hit' })),
            rule('on_sprite_animation_finished', [act('play_sprite_animation', { target: 'spr', animation: 'idle' })], { animation: 'hit' }),
            rule('on_sprite_animation_finished', [act('play_sprite_animation', { target: 'spr', animation: 'hit' })], { animation: 'outra' }),
          ]),
        ])
      )
    );
    session.step(1 / 60);
    registerSprite('spr', 'idle');
    run(session, 1); // loop não dispara
    expect(session.sprites.animationOf('spr')).toBe('idle');
    session.emitSignal('go');
    run(session, 0.1);
    expect(session.sprites.animationOf('spr')).toBe('hit');
    run(session, 0.3); // hit termina → regra encadeia idle
    expect(session.sprites.animationOf('spr')).toBe('idle');
  });
});

describe('estado descartável', () => {
  it('o authoring não muda (propriedades do nó e Undo) e o Stop limpa o host', () => {
    const scene = sceneWith(billboard([behavior([sig('go', act('play_sprite_animation', { target: 'spr', animation: 'hit', speedScale: 3 }))])]));
    const before = JSON.stringify(scene.nodes.spr);
    const { session, registerSprite } = open(scene);
    session.step(1 / 60);
    registerSprite();
    session.emitSignal('go');
    run(session, 0.5);
    expect(session.scene.getInstance('spr')!.properties.speedScale).toBe(3); // estado VIVO
    expect(JSON.stringify(scene.nodes.spr)).toBe(before); // authoring intacto
    session.stop();
    expect(session.sprites.has('spr')).toBe(false);
  });
});
