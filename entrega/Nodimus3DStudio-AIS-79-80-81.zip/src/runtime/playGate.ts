import type { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { formatDiagnosticLine } from '../core/diagnostics/adapters';

/**
 * AIS-44c — "este Play pode começar?". Pura: consulta SÓ o `DiagnosticService` (AIS-32c) — nenhuma verificação própria de
 * erros no host. Diagnóstico `blocking` das fases `scene`/`validation` DA cena a rodar (ou do projeto todo, quando não
 * aponta uma cena) impede o Play; `warning`/`error` não bloqueiam. Devolve as linhas `[código] mensagem` para o Output
 * (formato do console do AIS-32c); lista vazia = pode jogar.
 */
export const PLAY_GATE_PHASES = ['scene', 'validation'] as const;

export function playBlockLines(diagnostics: Pick<DiagnosticService, 'hasBlocking'>, scenePath: string): string[] {
  const verdict = diagnostics.hasBlocking({ phase: PLAY_GATE_PHASES });
  if (!verdict.blocked) return [];
  return verdict.reasons
    .filter((d) => (d.sourceId === undefined && d.uri === undefined) || d.sourceId === scenePath || d.uri === scenePath)
    .map(formatDiagnosticLine);
}
