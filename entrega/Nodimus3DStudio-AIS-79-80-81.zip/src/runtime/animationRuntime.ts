import { tNow } from '../core/i18n';
import { createClipMixer, type ClipMixer, type ClipMixerState, type MixerClipInfo, type MixerLayer } from './skeletalAnimation';

/**
 * AIS-60/60b — estado de reprodução da animação do objeto animado (MeshInstance com `properties.animated`) no Play. Mora na `RuntimeSession` (descartável: restart, troca de cena e Stop o
 * limpam; nunca vai ao authoring) e é PURO — sem Three, sem DOM. Reutiliza o `createClipMixer` do AIS-37 (tempo, velocidade, loop,
 * crossfade em segundos): proibido um segundo mixer. Quem conhece os clipes de verdade e os aplica ao esqueleto é o apresentador da
 * viewport (`components/viewports/viewportAnimation.ts`), que registra aqui os nomes/durações e lê `layersOf()` a cada quadro.
 *
 * Fluxo: as Actions (`play_animation`, `pause_animation`, `stop_animation`) e os Behaviors de movimento falam com este host pelo contexto; pedidos feitos ANTES de o
 * apresentador terminar de carregar os clipes ficam numa fila curta e rodam no `register`.
 */

export interface AnimationClipInfo extends MixerClipInfo {
  /** `loop` do clipe na biblioteca (`RigClip.loop`); ausente = o do nó. */
  loop?: boolean;
}

export interface AnimationRegistration {
  clips: readonly AnimationClipInfo[];
  /** `animation.speed` / `loop` / `crossfade` do objeto animado. */
  speed?: number;
  loop?: boolean;
  crossfade?: number;
  /** `animation.default` + `autoplay` do objeto: começa tocando já no registro. */
  initial?: string;
  autoplay?: boolean;
}

export interface PlayOptions {
  /** Segundos; ausente = o `crossfadeDuration` do nó. */
  crossfade?: number;
  loop?: boolean;
  speed?: number;
}

export type AnimationEventName = 'animation_started' | 'animation_finished' | 'animation_changed';

export interface AnimationEvent {
  playerId: string;
  name: AnimationEventName;
  clip: string;
}

export type AnimationProblemCode = 'animation.unknown_clip' | 'animation.not_ready' | 'animation.queue_overflow';

/** O que as Actions enxergam. Devolvem uma mensagem de erro (explícita) ou `null` quando o pedido foi aceito (ou enfileirado). */
export interface AnimationControl {
  play(player: string, clip: string, options?: PlayOptions): string | null;
  pause(player: string, paused: boolean): string | null;
  stop(player: string): string | null;
  setSpeed(player: string, speed: number): string | null;
}

type Command =
  | { kind: 'play'; clip: string; options?: PlayOptions }
  | { kind: 'pause'; paused: boolean }
  | { kind: 'stop' }
  | { kind: 'speed'; speed: number };

interface Entry {
  mixer: ClipMixer;
  clips: AnimationClipInfo[];
  loop: boolean;
  crossfade: number;
  wasPlaying: boolean;
  lastClip: string | null;
  /** Velocidade pedida pelo nó/Action (sem a do clipe). */
  baseSpeed: number;
}

const MAX_PENDING = 16;

export class AnimationHost implements AnimationControl {
  private readonly entries = new Map<string, Entry>();
  private readonly pending = new Map<string, Command[]>();
  private events: AnimationEvent[] = [];
  /** Incrementa quando um player entra ou sai (o apresentador compara este número em vez de varrer a cena). */
  revision = 0;

  constructor(private readonly onProblem?: (code: AnimationProblemCode, message: string, playerId: string) => void) {}

  // ── registro ────────────────────────────────────────────────────────────────────────────────────────────────────────

  register(playerId: string, registration: AnimationRegistration): void {
    const clips = registration.clips.filter((c) => c.name && c.duration >= 0);
    const mixer = createClipMixer(clips.map((c) => ({ name: c.name, duration: c.duration })));
    const loop = registration.loop !== false;
    mixer.setLoop(loop);
    if (registration.speed !== undefined) mixer.setSpeed(registration.speed);
    const entry: Entry = { mixer, clips, loop, crossfade: Math.max(0, registration.crossfade ?? 0.2), wasPlaying: false, lastClip: null, baseSpeed: registration.speed ?? 1 };
    this.entries.set(playerId, entry);
    this.revision++;
    if (registration.initial && clips.some((c) => c.name === registration.initial)) {
      mixer.select(registration.initial);
      entry.lastClip = registration.initial;
      if (registration.autoplay) {
        mixer.play();
        this.emit(playerId, 'animation_started', registration.initial);
      }
    }
    entry.wasPlaying = mixer.state().playing;
    const queued = this.pending.get(playerId) ?? [];
    this.pending.delete(playerId);
    for (const command of queued) this.run(playerId, entry, command, true);
  }

  unregister(playerId: string): void {
    if (this.entries.delete(playerId)) this.revision++;
    this.pending.delete(playerId);
  }

  isRegistered(playerId: string): boolean {
    return this.entries.has(playerId);
  }

  clipsOf(playerId: string): readonly AnimationClipInfo[] {
    return this.entries.get(playerId)?.clips ?? [];
  }

  playerIds(): string[] {
    return [...this.entries.keys()];
  }

  /** Esvazia tudo (restart, troca de cena, Stop). */
  clear(): void {
    this.entries.clear();
    this.pending.clear();
    this.events = [];
    this.revision++;
  }

  // ── comandos (as Actions e os Behaviors) ──────────────────────────────────────────────────────────────────────────────

  play(player: string, clip: string, options?: PlayOptions): string | null {
    return this.dispatch(player, { kind: 'play', clip, options });
  }

  pause(player: string, paused: boolean): string | null {
    return this.dispatch(player, { kind: 'pause', paused });
  }

  stop(player: string): string | null {
    return this.dispatch(player, { kind: 'stop' });
  }

  setSpeed(player: string, speed: number): string | null {
    return this.dispatch(player, { kind: 'speed', speed });
  }

  private dispatch(playerId: string, command: Command): string | null {
    const entry = this.entries.get(playerId);
    if (entry) return this.run(playerId, entry, command, false);
    // clipes ainda carregando: guarda o pedido (curto) e executa no registro
    const queue = this.pending.get(playerId) ?? [];
    if (queue.length >= MAX_PENDING) return tNow('animationRuntimeMsgCore.thereAreTooManyRequests');
    queue.push(command);
    this.pending.set(playerId, queue);
    return null;
  }

  private run(playerId: string, entry: Entry, command: Command, deferred: boolean): string | null {
    const result = this.exec(playerId, entry, command, deferred);
    // um comando muda `playing` por conta própria (pause/stop/play): sem isto o próximo `step` leria a mudança como "o clipe terminou"
    entry.wasPlaying = entry.mixer.state().playing;
    return result;
  }

  private exec(playerId: string, entry: Entry, command: Command, deferred: boolean): string | null {
    const fail = (code: AnimationProblemCode, message: string): string | null => {
      // pedido adiado não tem mais quem receba o retorno: vira diagnóstico; o imediato volta para a Action logar
      if (deferred) this.onProblem?.(code, message, playerId);
      return message;
    };
    const s = entry.mixer.state();
    switch (command.kind) {
      case 'play': {
        const info = entry.clips.find((c) => c.name === command.clip);
        if (!info) return fail('animation.unknown_clip', tNow('animationRuntimeMsgCore.theClipDoesNotExist', { clip: command.clip, value: entry.clips.map((c) => c.name).join(', ') || tNow('animationRuntimeMsgLast.noClipLoaded') }));
        const loop = command.options?.loop ?? info.loop ?? entry.loop;
        const fade = command.options?.crossfade ?? entry.crossfade;
        if (command.options?.speed !== undefined) entry.baseSpeed = command.options.speed;
        entry.mixer.setSpeed(entry.baseSpeed); // limitada pelo mixer
        if (s.clip === info.name && s.playing) {
          entry.mixer.setLoop(loop);
          return null; // já está tocando este clipe: só atualiza loop/velocidade
        }
        if (s.clip && s.clip !== info.name && s.playing) {
          entry.mixer.crossFadeTo(info.name, fade);
        } else {
          if (s.clip !== info.name) entry.mixer.select(info.name);
          else entry.mixer.seek(0);
          entry.mixer.play();
        }
        entry.mixer.setLoop(loop);
        if (entry.lastClip !== info.name) this.emit(playerId, 'animation_changed', info.name); // o mixer já nasce com o 1º clipe selecionado: a troca é pelo último clipe TOCADO
        this.emit(playerId, 'animation_started', info.name);
        entry.lastClip = info.name;
        return null;
      }
      case 'pause':
        if (command.paused) entry.mixer.pause();
        else entry.mixer.play();
        return null;
      case 'stop':
        if (s.clip) entry.mixer.select(s.clip); // volta ao quadro 0 e cancela o crossfade
        entry.mixer.pause();
        return null;
      case 'speed':
        entry.baseSpeed = command.speed;
        entry.mixer.setSpeed(command.speed);
        return null;
    }
  }

  // ── passo e leitura ─────────────────────────────────────────────────────────────────────────────────────────────────────

  /** Avança `dt` segundos de JOGO (pausa e Stop respeitados pela sessão). */
  step(dt: number): void {
    if (!(dt > 0)) return;
    for (const [playerId, entry] of this.entries) {
      entry.mixer.step(dt);
      const s = entry.mixer.state();
      // clipe sem loop que chegou ao fim: `animation_finished` (clipe em loop nunca "termina")
      if (entry.wasPlaying && !s.playing && s.clip && !s.loop) this.emit(playerId, 'animation_finished', s.clip);
      entry.wasPlaying = s.playing;
    }
  }

  layersOf(playerId: string): MixerLayer[] {
    return this.entries.get(playerId)?.mixer.layers() ?? [];
  }

  stateOf(playerId: string): Readonly<ClipMixerState> | null {
    return this.entries.get(playerId)?.mixer.state() ?? null;
  }

  /** Eventos desde a última chamada (a sessão os publica no `SignalBus`). */
  drainEvents(): AnimationEvent[] {
    if (this.events.length === 0) return [];
    const out = this.events;
    this.events = [];
    return out;
  }

  private emit(playerId: string, name: AnimationEventName, clip: string): void {
    this.events.push({ playerId, name, clip });
  }
}
