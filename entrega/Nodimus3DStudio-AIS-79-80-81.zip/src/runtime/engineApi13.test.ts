import { describe, expect, it, vi } from 'vitest';
import { ENGINE_OPERATIONS, buildEngineApi, type EngineHost } from './engineApi';

/** AIS-78c (EngineApi 1.3) — frame (onUpdate/onInput), camera.publish, locomotion, text, ui e motion: o dono da invocação vem do escopo. */

const inst = (id: string) =>
  ({ persistentNodeId: id, name: id, type: 'Spatial', disposed: false, tags: [], visible: true, parent: null, properties: {}, transform: { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] } }) as never;

function hostWith(extra: Partial<EngineHost> = {}): EngineHost {
  const noop = () => undefined;
  const nodes: Record<string, unknown> = { a: inst('a') };
  return {
    instanceById: (ref: string) => nodes[ref] as never,
    instanceByName: () => undefined,
    variables: () => null,
    input: () => ({}) as never,
    physics: () => null,
    sceneTime: () => 0,
    emitSignal: noop,
    connectSignal: () => noop,
    onPhysicsEvent: () => noop,
    log: noop,
    commitTransform: noop,
    ...extra,
  } as EngineHost;
}

const OWNER = { kind: 'behavior', id: 'a::b1' } as never;

describe('frame', () => {
  it('assina com o DONO da invocação e devolve o disposer do host', () => {
    const off = vi.fn();
    const onFrame = vi.fn(() => off);
    const onInput = vi.fn(() => off);
    const api = buildEngineApi(hostWith({ onFrame, onInput }), OWNER, 'a');
    const cb = () => undefined;
    expect(api.frame.onUpdate(cb)).toBe(off);
    expect(api.frame.onInput(cb)).toBe(off);
    expect(onFrame).toHaveBeenCalledWith(cb, OWNER);
    expect(onInput).toHaveBeenCalledWith(cb, OWNER);
  });

  it('sem suporte do host (Action): falha EXPLÍCITA, nunca assinatura silenciosa', () => {
    const api = buildEngineApi(hostWith(), null, 'a');
    expect(() => api.frame.onUpdate(() => undefined)).toThrow(/Actions não assinam/);
    expect(() => api.frame.onInput(() => undefined)).toThrow(/Actions não assinam/);
  });
});

describe('camera.publish e locomotion.set (escrita só do nó dono)', () => {
  it('publicam para o nó da invocação, e null retira', () => {
    const setGameCamera = vi.fn();
    const setLocomotion = vi.fn();
    const api = buildEngineApi(hostWith({ setGameCamera, setLocomotion }), OWNER, 'a');
    const pose = { position: [0, 1, 2], quaternion: [0, 0, 0, 1], pointerLock: false } as never;
    expect(api.camera.publish(pose)).toEqual({ ok: true });
    expect(api.camera.publish(null)).toEqual({ ok: true });
    expect(setGameCamera).toHaveBeenNthCalledWith(1, 'a', pose);
    expect(setGameCamera).toHaveBeenNthCalledWith(2, 'a', null);
    expect(api.locomotion.set({ state: 'walk', speed: 2, grounded: true })).toEqual({ ok: true });
    expect(setLocomotion).toHaveBeenCalledWith('a', { state: 'walk', speed: 2, grounded: true });
  });

  it('sem nó dono (script de sessão): falha com código estável', () => {
    const api = buildEngineApi(hostWith({ setGameCamera: vi.fn(), setLocomotion: vi.fn() }), null, null);
    expect(api.camera.publish(null)).toMatchObject({ ok: false, code: 'camera.no_owner' });
    expect(api.locomotion.set(null)).toMatchObject({ ok: false, code: 'locomotion.no_owner' });
  });

  it('host sem o serviço: unavailable', () => {
    const api = buildEngineApi(hostWith(), OWNER, 'a');
    expect(api.camera.publish(null)).toMatchObject({ ok: false, code: 'camera.unavailable' });
    expect(api.locomotion.set(null)).toMatchObject({ ok: false, code: 'locomotion.unavailable' });
  });
});

describe('text, ui e motion', () => {
  it('interpolate passa o nó dono (resolve self) e, sem host, devolve o texto como veio', () => {
    const interpolate = vi.fn((t: string, self: string | null) => `${t}@${self}`);
    expect(buildEngineApi(hostWith({ interpolate }), null, 'a').text.interpolate('oi')).toBe('oi@a');
    expect(buildEngineApi(hostWith(), null, 'a').text.interpolate('oi')).toBe('oi');
  });

  it('ui.markDirty chama o host; sem host não faz nada', () => {
    const markUiDirty = vi.fn();
    buildEngineApi(hostWith({ markUiDirty }), null, 'a').ui.markDirty();
    expect(markUiDirty).toHaveBeenCalledTimes(1);
    expect(() => buildEngineApi(hostWith(), null, 'a').ui.markDirty()).not.toThrow();
  });

  it('spin/velocity endereçam o nó por ID; nó inexistente e host ausente viram falha', () => {
    const spin = vi.fn();
    const velocity = vi.fn();
    const api = buildEngineApi(hostWith({ setContinuousRotation: spin, setContinuousVelocity: velocity }), null, null);
    expect(api.motion.spin('a', 'y', 90)).toEqual({ ok: true });
    expect(api.motion.velocity('a', { x: 0, y: 0, z: -1 }, 'world')).toEqual({ ok: true });
    expect(spin).toHaveBeenCalledWith(expect.objectContaining({ persistentNodeId: 'a' }), 'y', 90);
    expect(velocity).toHaveBeenCalledWith(expect.objectContaining({ persistentNodeId: 'a' }), { x: 0, y: 0, z: -1 }, 'world');
    expect(api.motion.spin('nada', 'y', 1)).toMatchObject({ ok: false, code: 'node.not_found' });
    expect(buildEngineApi(hostWith(), null, null).motion.spin('a', 'y', 1)).toMatchObject({ ok: false, code: 'motion.unavailable' });
  });
});

describe('catálogo 1.3', () => {
  it('as operações novas declaram 1.3; camera.view segue 1.2', () => {
    const since = (id: string) => ENGINE_OPERATIONS.find((o) => o.id === id)?.since;
    for (const id of ['frame.onUpdate', 'frame.onInput', 'camera.publish', 'locomotion.set', 'text.interpolate', 'ui.markDirty', 'motion.spin', 'motion.velocity']) expect(since(id), id).toBe('1.3');
    expect(since('camera.view')).toBe('1.2');
    expect(since('weapons.fire')).toBe('1.2');
  });
});
