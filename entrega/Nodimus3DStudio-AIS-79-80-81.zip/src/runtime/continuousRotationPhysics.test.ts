import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { ensureRapier } from '../core/physics/rapierInit';
import { RuntimeSession } from './RuntimeSession';

/**
 * Rotação contínua com física. O Behavior `continuous_rotation` e a Action `rotate_continuous` escreviam em `instance.transform.rotation`;
 * num corpo DINÂMICO a física é a dona da pose e o `PhysicsHost` copia a rotação do Rapier por cima a cada quadro, apagando a escrita
 * (a rotação funcionava sem física e com "sólido parado", e parava com física ativa). Agora o corpo dinâmico gira por velocidade angular
 * pela `PhysicsBridge`.
 */

beforeAll(async () => {
  await ensureRapier();
});

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[]): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters: {}, conditions: [], actions });
const rulesBehavior = (...rules: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'Regras', behaviorType: 'custom_rules', enabled: true, properties: {}, rules });
const spinBehavior = (speed: number, axis = 'y'): BehaviorInstance => ({ id: `b${++seq}`, name: 'Spin', behaviorType: 'continuous_rotation', enabled: true, properties: { rotationSpeed: speed, axis }, rules: [] });

type Body = Record<string, any> | undefined;
const box = (id: string, physics: Body, behaviors: BehaviorInstance[]): GameNode =>
  ({
    id,
    name: id,
    type: 'MeshInstance',
    parentId: null,
    childrenIds: [],
    visible: true,
    locked: false,
    behaviors,
    properties: { meshType: 'CubeMesh', position: { x: 0, y: 5, z: 0 }, ...(physics ? { physics } : {}) },
  }) as unknown as GameNode;

function open(node: GameNode, gravityOff = true) {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: [node.id] } as GameNode, [node.id]: { ...node, parentId: root.id } as GameNode };
  const data = { ...scene, nodes, ...(gravityOff ? { environmentSettings: { gravity: { x: 0, y: 0, z: 0 } } } : {}) } as unknown as SceneData;
  const session = new RuntimeSession({
    snapshot: createRuntimeSnapshot(data),
    input: { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never,
  });
  session.start();
  return session;
}
const run = (s: RuntimeSession, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) s.step(1 / 60);
};
const yaw = (s: RuntimeSession, id: string) => s.getSimulatedTransform(id)!.rotation[1];

const DYNAMIC = { enabled: true, bodyMode: 'dynamic', shape: 'auto' };

describe('Behavior continuous_rotation', () => {
  it('sem física: gira (regressão)', () => {
    const s = open(box('b', undefined, [spinBehavior(45)]));
    run(s, 1);
    expect(yaw(s, 'b')).toBeGreaterThan(40);
    s.dispose();
  });

  it('com sólido parado (static): gira (regressão)', () => {
    const s = open(box('b', { enabled: true, bodyMode: 'static', shape: 'auto' }, [spinBehavior(45)]));
    run(s, 1);
    expect(yaw(s, 'b')).toBeGreaterThan(40);
    s.dispose();
  });

  it('com física ativa (dynamic): GIRA — velocidade angular pela ponte', () => {
    const s = open(box('b', DYNAMIC, [spinBehavior(45)]));
    expect(s.physics?.modeOf('b')).toBe('dynamic');
    run(s, 1);
    expect(yaw(s, 'b')).toBeGreaterThan(40);
    expect(yaw(s, 'b')).toBeLessThan(50); // ~45°/s, sem aceleração
    s.dispose();
  });

  it('com física ativa, no eixo X e no sentido contrário', () => {
    const s = open(box('b', DYNAMIC, [spinBehavior(-45, 'x')]));
    run(s, 1);
    expect(s.getSimulatedTransform('b')!.rotation[0]).toBeLessThan(-40);
    s.dispose();
  });

  it('com física ativa, continua girando a velocidade constante ao longo do tempo', () => {
    const s = open(box('b', DYNAMIC, [spinBehavior(30)]));
    run(s, 1);
    const a = yaw(s, 'b');
    run(s, 1);
    expect(yaw(s, 'b') - a).toBeGreaterThan(25);
    s.dispose();
  });

  it('kinematic: gira (a pose pedida é a autoridade)', () => {
    const s = open(box('b', { enabled: true, bodyMode: 'kinematic', shape: 'auto' }, [spinBehavior(45)]));
    run(s, 1);
    expect(yaw(s, 'b')).toBeGreaterThan(40);
    s.dispose();
  });
});

describe('Action rotate_continuous', () => {
  const withRule = (physics: Body, dps: number) => box('b', physics, [rulesBehavior(rule('on_start', [act('rotate_continuous', { target: 'b', axis: 'y', degreesPerSecond: dps })]))]);

  it('sem física: gira (regressão)', () => {
    const s = open(withRule(undefined, 45));
    run(s, 1);
    expect(yaw(s, 'b')).toBeGreaterThan(40);
    s.dispose();
  });

  it('com física ativa (dynamic): GIRA', () => {
    const s = open(withRule(DYNAMIC, 45));
    run(s, 1);
    expect(yaw(s, 'b')).toBeGreaterThan(40);
    expect(yaw(s, 'b')).toBeLessThan(50);
    s.dispose();
  });

  it('0°/s desliga a rotação também no corpo dinâmico (a velocidade angular é zerada)', () => {
    const node = box('b', DYNAMIC, [
      rulesBehavior(rule('on_start', [act('rotate_continuous', { target: 'b', axis: 'y', degreesPerSecond: 45 })]), rule('on_timeout', [act('rotate_continuous', { target: 'b', axis: 'y', degreesPerSecond: 0 })])),
    ]);
    // `on_timeout` repete a cada 1 s por padrão: a regra de parada roda uma vez em t≈1 s e a rotação precisa estacionar
    const s = open(node);
    run(s, 1.2);
    const stopped = yaw(s, 'b');
    run(s, 1);
    expect(Math.abs(yaw(s, 'b') - stopped)).toBeLessThan(1);
    s.dispose();
  });
});
