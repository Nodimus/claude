import { describe, expect, it, vi } from 'vitest';
import { ENGINE_OPERATIONS, buildEngineApi, negotiateEngineApi, type EngineHost } from './engineApi';

/** AIS-79 (EngineApi 1.5) — `scripts.run`: a Action run_script pelo sandbox; só em Play, host-only. */

const noop = () => undefined;
const hostWith = (extra: Partial<EngineHost> = {}): EngineHost =>
  ({ instanceById: () => undefined, instanceByName: () => undefined, variables: () => null, input: () => ({}) as never, physics: () => null, sceneTime: () => 0, emitSignal: noop, connectSignal: () => noop, onPhysicsEvent: () => noop, log: noop, commitTransform: noop, ...extra }) as EngineHost;

describe('engine.scripts.run', () => {
  it('delega ao ScriptHost com o nó DONO da invocação e devolve o resultado dele', () => {
    const run = vi.fn(() => ({ ok: true as const }));
    const api = buildEngineApi(hostWith({ scripts: () => ({ run }) as never }), null, 'dono');
    expect(api.scripts.run('res://scripts/a.js', { x: 1 })).toEqual({ ok: true });
    expect(run).toHaveBeenCalledWith('dono', 'res://scripts/a.js', { x: 1 });
  });

  it('sem sandbox na sessão: falha com código estável (scripts.unavailable)', () => {
    expect(buildEngineApi(hostWith(), null, 'dono').scripts.run('res://scripts/a.js')).toMatchObject({ ok: false, code: 'scripts.unavailable' });
  });

  it('a operação é da 1.5, só em Play (publish ainda não empacota scripts) e não é marshalável (um script não chama script)', () => {
    const op = ENGINE_OPERATIONS.find((o) => o.id === 'scripts.run')!;
    expect(op).toMatchObject({ since: '1.5', marshalable: false, safeIn: { play: true, publish: false } });
    expect(negotiateEngineApi({ major: 1, minMinor: 5, features: ['scripts'] }).ok).toBe(true);
    expect(negotiateEngineApi({ major: 1, minMinor: 6 }).ok).toBe(false);
  });
});
