import { describe, expect, it, vi } from 'vitest';
import { ENGINE_OPERATIONS, buildEngineApi, negotiateEngineApi, type EngineHost } from './engineApi';
import { ActorRegistry } from './ai/actorRegistry';
import { findAnimatedObject, playActorClip } from './ai/clips';

/** AIS-78d (EngineApi 1.4) — ai (vivo/morto/alvo), hooks, routes, diagnostics e random; o `ActorRegistry` e o clipe de animação do ator. */

const inst = (id: string, extra: Record<string, unknown> = {}) =>
  ({ persistentNodeId: id, name: id, type: 'Spatial', disposed: false, tags: [], visible: true, parent: null, children: [], properties: {}, transform: { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] }, ...extra }) as never;

const nodes: Record<string, any> = { a: inst('a'), b: inst('b') };

function hostWith(extra: Partial<EngineHost> = {}): EngineHost {
  const noop = () => undefined;
  return {
    instanceById: (ref: string) => nodes[ref],
    instanceByName: () => undefined,
    variables: () => null,
    input: () => ({}) as never,
    physics: () => null,
    sceneTime: () => 0,
    emitSignal: noop,
    connectSignal: () => noop,
    onPhysicsEvent: () => noop,
    log: noop,
    commitTransform: noop,
    ...extra,
  } as EngineHost;
}

describe('ActorRegistry', () => {
  it('morto, alvo e revive; alvo só vale se o nó existe e não morreu', () => {
    const reg = new ActorRegistry((id) => nodes[id]);
    reg.setTarget('a', 'b');
    expect(reg.currentTarget('a')).toBe('b');
    reg.markDead('b');
    expect(reg.isDead('b')).toBe(true);
    expect(reg.currentTarget('a')).toBeNull(); // alvo morto
    reg.revive('b');
    expect(reg.currentTarget('a')).toBe('b');
    reg.setTarget('a', null);
    expect(reg.currentTarget('a')).toBeNull();
  });

  it('dispose esvazia tudo e ignora escritas depois', () => {
    const reg = new ActorRegistry((id) => nodes[id]);
    reg.markDead('a');
    reg.dispose();
    expect(reg.isDead('a')).toBe(false);
    reg.markDead('a');
    expect(reg.deadCount).toBe(0);
  });
});

describe('engine.ai (escrita só pelo dono)', () => {
  it('com dono: registra, marca morto, publica alvo; leitura vale para qualquer nó', () => {
    const reg = new ActorRegistry((id) => nodes[id]);
    const api = buildEngineApi(hostWith({ actors: () => reg }), null, 'a', 'beh');
    expect(api.ai.registerActor()).toEqual({ ok: true });
    expect(api.ai.setTarget('b')).toEqual({ ok: true });
    expect(api.ai.currentTarget('a')).toBe('b');
    expect(api.ai.markDead()).toEqual({ ok: true });
    expect(api.ai.isDead('a')).toBe(true);
    expect(api.ai.isDead('b')).toBe(false);
  });

  it('sem nó dono: falha com ai.no_owner; sem registro: unavailable', () => {
    const reg = new ActorRegistry((id) => nodes[id]);
    const none = buildEngineApi(hostWith({ actors: () => reg }), null, null, null);
    for (const r of [none.ai.registerActor(), none.ai.markDead(), none.ai.setTarget(null)]) expect(r).toMatchObject({ ok: false, code: 'ai.no_owner' });
    const bare = buildEngineApi(hostWith(), null, 'a', 'beh');
    expect(bare.ai.markDead()).toMatchObject({ ok: false, code: 'ai.unavailable' });
    expect(bare.ai.isDead('a')).toBe(false);
    expect(bare.ai.currentTarget('a')).toBeNull();
  });
});

describe('engine.hooks / routes / diagnostics / random', () => {
  it('hooks.fire dispara no Behavior DONO (nó + behaviorId do escopo); Action falha com hooks.no_owner', () => {
    const fireHook = vi.fn();
    const api = buildEngineApi(hostWith({ fireHook }), null, 'a', 'beh1');
    expect(api.hooks.fire('on_ai_attack', 'x', { state: 'Chase' })).toEqual({ ok: true });
    expect(fireHook).toHaveBeenCalledWith('a', 'beh1', 'on_ai_attack', 'x', { state: 'Chase' });
    const action = buildEngineApi(hostWith({ fireHook }), null, 'a', null);
    expect(action.hooks.fire('on_ai_attack', 'x')).toMatchObject({ ok: false, code: 'hooks.no_owner' });
    expect(fireHook).toHaveBeenCalledTimes(1);
    expect(buildEngineApi(hostWith(), null, 'a', 'beh1').hooks.fire('t', 'd')).toMatchObject({ ok: false, code: 'hooks.unavailable' });
  });

  it('weapons.hook (alias depreciado) usa o mesmo caminho do host', () => {
    const fireHook = vi.fn();
    buildEngineApi(hostWith({ fireHook }), null, 'a', 'beh1').weapons.hook('a', 'beh1', 'on_weapon_shoot', 'd');
    expect(fireHook).toHaveBeenCalledWith('a', 'beh1', 'on_weapon_shoot', 'd');
  });

  it('routes.resolve devolve o resultado de resolveRoute; sem host, falha com código de rota', () => {
    const route = { ok: true, points: [{ id: 'w1', position: { x: 1, y: 0, z: 0 }, waitMs: 0 }] };
    expect(buildEngineApi(hostWith({ resolveRoute: () => route as never }), null).routes.resolve('c')).toBe(route);
    expect(buildEngineApi(hostWith(), null).routes.resolve('c')).toMatchObject({ ok: false, code: 'route.container_missing' });
  });

  it('diagnostics.warnOnce delega ao host (a deduplicação é da sessão); random.next usa o sorteio injetado', () => {
    const reportOnce = vi.fn();
    const api = buildEngineApi(hostWith({ reportOnce, random: () => 0.25 }), null, 'a', 'beh1');
    api.diagnostics.warnOnce('k', 'warning', 'ai.x', 'msg', 'a');
    expect(reportOnce).toHaveBeenCalledWith('k', 'warning', 'ai.x', 'msg', 'a');
    expect(api.random.next()).toBe(0.25);
  });
});

describe('playActorClip', () => {
  const animated = (id: string, children: any[] = []) => inst(id, { type: 'MeshInstance', properties: { animated: true }, children });

  it('acha o objeto animado (o próprio ou o primeiro descendente)', () => {
    const child = animated('model');
    expect(findAnimatedObject(inst('actor', { children: [child] }))?.persistentNodeId).toBe('model');
    expect(findAnimatedObject(animated('self'))?.persistentNodeId).toBe('self');
    expect(findAnimatedObject(inst('x'))).toBeUndefined();
  });

  it('toca pelo engine.animation; sem objeto animado e clipe inexistente viram aviso único; sem host de animação = nada', () => {
    const warn = vi.fn();
    const play = vi.fn(() => null);
    const withHost = buildEngineApi(hostWith({ animation: () => ({ play }) as never, reportOnce: warn, instanceById: (id: string) => ({ model: animated('model') } as any)[id] }), null, 'actor', 'b');
    const actor = inst('actor', { children: [animated('model')] });
    playActorClip(withHost, 'actor', actor, 'Walk');
    expect(play.mock.calls[0].slice(0, 2)).toEqual(['model', 'Walk']);
    playActorClip(withHost, 'actor', inst('semAnim'), 'Walk');
    expect(warn).toHaveBeenCalledWith('obj:actor', 'warning', 'ai.animation_no_object', expect.any(String), 'actor');

    const missing = buildEngineApi(hostWith({ animation: () => ({ play: () => 'o clipe "Voar" não existe' }) as never, reportOnce: warn, instanceById: (id: string) => ({ model: animated('model') } as any)[id] }), null, 'actor', 'b');
    playActorClip(missing, 'actor', actor, 'Voar');
    expect(warn).toHaveBeenCalledWith('actor:Voar', 'warning', 'ai.animation_unresolved', expect.stringContaining('Voar'), 'actor');

    warn.mockClear();
    playActorClip(buildEngineApi(hostWith({ reportOnce: warn, instanceById: (id: string) => ({ model: animated('model') } as any)[id] }), null, 'actor', 'b'), 'actor', actor, 'Walk');
    expect(warn).not.toHaveBeenCalled();
  });
});

describe('catálogo 1.4', () => {
  it('as operações novas declaram 1.4; ai.currentTarget segue 1.2; negociação aceita minMinor 4 e recusa 5', () => {
    const since = (id: string) => ENGINE_OPERATIONS.find((o) => o.id === id)?.since;
    for (const id of ['ai.registerActor', 'ai.markDead', 'ai.isDead', 'ai.setTarget', 'hooks.fire', 'routes.resolve', 'diagnostics.warnOnce', 'random.next']) expect(since(id), id).toBe('1.4');
    expect(since('ai.currentTarget')).toBe('1.2');
    expect(since('frame.onUpdate')).toBe('1.3');
    expect(negotiateEngineApi({ major: 1, minMinor: 4 }).ok).toBe(true);
    expect(negotiateEngineApi({ major: 1, minMinor: 6 }).ok).toBe(false); // a 1.5 (AIS-79) já existe
  });
});
