import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { ensureRapier } from '../core/physics/rapierInit';
import { LogicRegistry } from '../logic/registry';
import { RuntimeSession } from './RuntimeSession';
import { wrapDeg, yawKeepingAuthoredTilt, yawOfEulerXYZ } from './controllers/controllerMath';

/**
 * Regressão do tremor ao andar de costas / encostar em algo: a pose simulada volta do Rapier como Euler XYZ (um yaw > 90° vira
 * `180, 180 - yaw, 180`). Os Behaviors de movimento e a IA relidos `rotation[0]`/`[2]` e reescreviam só o Y, o que alternava a frente
 * entre dois espelhos a cada quadro. Agora mantêm a inclinação AUTORAL e o yaw só depende do próprio estado.
 */

beforeAll(async () => {
  await ensureRapier();
});

const node = (id: string, type: string, at: [number, number, number], props: Record<string, unknown> = {}, over: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type, parentId: null, childrenIds: [], visible: true, locked: false, properties: { position: { x: at[0], y: at[1], z: at[2] }, ...props }, ...over }) as unknown as GameNode;

const held = new Set<string>();
const input = {
  isActionPressed: (a: string) => held.has(a),
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: (neg: string, pos: string) => (held.has(pos) ? 1 : 0) - (held.has(neg) ? 1 : 0),
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
} as never;

const solid = { enabled: true, bodyMode: 'static', shape: 'auto' };
const FLOOR = node('floor', 'MeshInstance', [0, -0.5, 0], { meshType: 'CubeMesh', scale: { x: 60, y: 1, z: 60 }, physics: solid });
const WALL = node('wall', 'MeshInstance', [0, 1, 4], { meshType: 'CubeMesh', scale: { x: 10, y: 2, z: 1 }, physics: solid });

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  return { ...scene, nodes } as unknown as SceneData;
}

const player = (type: 'third_person_movement' | 'first_person_movement') => {
  const b = (LogicRegistry.getBehavior(type) as any).create({ targetNodeId: 'p' });
  return node('p', 'MeshInstance', [0, 1, 0], { meshType: 'CubeMesh', physics: { enabled: true, bodyMode: 'character', shape: 'capsule' } }, { behaviors: [b] } as never);
}

function play(...extra: GameNode[]) {
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(sceneWith(...extra)), input, diagnostics: new DiagnosticService() });
  session.start();
  return session;
}

describe('yawOfEulerXYZ / yawKeepingAuthoredTilt', () => {
  it('lê o yaw real mesmo na forma (180, 180 - yaw, 180) que o Rapier devolve', () => {
    expect(yawOfEulerXYZ([0, 40, 0])).toBeCloseTo(40);
    expect(yawOfEulerXYZ([0, -70, 0])).toBeCloseTo(-70);
    expect(yawOfEulerXYZ([180, 30, 180])).toBeCloseTo(150); // yaw 150° como a decomposição XYZ o entrega
    expect(wrapDeg(yawOfEulerXYZ([-180, 0, -180]))).toBeCloseTo(180);
  });
  it('mantém X/Z autorais e troca só o yaw', () => {
    expect(yawKeepingAuthoredTilt([3, 99, -2], 150)).toEqual([3, 150, -2]);
  });
});

describe('o corpo não treme ao andar de costas e encostar na parede', () => {
  for (const type of ['third_person_movement'] as const) {
    it(`${type}: S contra a parede mantém a frente estável (yaw 180°) por 100 quadros`, () => {
      held.clear();
      const s = play(FLOOR, WALL, player(type));
      held.add('MoveBackward');
      const yaws: number[] = [];
      for (let i = 0; i < 260; i++) {
        s.step(1 / 60);
        if (i >= 160) yaws.push(yawOfEulerXYZ(s.getSimulatedTransform('p')!.rotation));
      }
      expect(s.getSimulatedTransform('p')!.position[2]).toBeGreaterThan(2.5); // chegou à parede e ficou
      for (const yaw of yaws) expect(Math.abs(wrapDeg(yaw - 180))).toBeLessThan(1);
      held.clear();
      s.dispose();
    });
  }

  it('o yaw nunca pula mais que a suavização permite entre quadros consecutivos (sem espelho)', () => {
    held.clear();
    const s = play(FLOOR, player('third_person_movement'));
    held.add('MoveBackward');
    let prev = 0;
    let worst = 0;
    for (let i = 0; i < 120; i++) {
      s.step(1 / 60);
      const yaw = yawOfEulerXYZ(s.getSimulatedTransform('p')!.rotation);
      if (i > 0) worst = Math.max(worst, Math.abs(wrapDeg(yaw - prev)));
      prev = yaw;
    }
    expect(worst).toBeLessThan(40); // antes: saltos de 180° a cada quadro
    held.clear();
    s.dispose();
  });
});
