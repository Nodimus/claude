import type { ResourceRef } from '../../types/node';
import type { Vec3 } from '../../core/physics/bounds';
import type { PhysicsBridge } from '../../core/physics/PhysicsBridge';
import type { VariableManager } from '../../core/variableManager';
import type { SpawnedHandle, SpawnOptions } from '../spawnHost';
import type { RuntimeInstance } from '../RuntimeScene';

/**
 * AIS-69 — contratos do núcleo de armas (`src/runtime/weapons/`). UM núcleo serve ao Behavior `weapon_controller`, às Actions
 * `fire_projectile`/`apply_damage`/`explode_area` e (AIS-71) à Action `Shoot` da IA: nenhuma porta de entrada implementa disparo,
 * impacto ou dano por conta própria. Nada aqui toca Rapier, `THREE.Raycaster` ou o authoring: consulta e força passam pela
 * `PhysicsBridge`; criação e destruição de nós, pela `SpawnHost` da `RuntimeSession` (AIS-29g).
 */

/** Gatilhos de HOOK da arma (Triggers das regras do próprio Behavior; ARM-03: não existe `on_projectile_hit`). */
export type WeaponHookTrigger = 'on_weapon_shoot' | 'on_weapon_impact' | 'on_weapon_empty' | 'on_weapon_reload';

export const WEAPON_HOOK_TRIGGERS: readonly WeaponHookTrigger[] = ['on_weapon_shoot', 'on_weapon_impact', 'on_weapon_empty', 'on_weapon_reload'];

/** Dependências que o núcleo pede à sessão (a `RuntimeSession` implementa; os testes injetam dublês). */
export interface WeaponHost {
  /** Tempo de JOGO (s). */
  now(): number;
  physics(): PhysicsBridge | null;
  variables(): VariableManager | null;
  /** Instância viva por ID estável (`persistentNodeId`). */
  instance(id: string): RuntimeInstance | undefined;
  /** `ref` vazio = `selfId`; aceita ID ou nome. */
  resolve(ref: string, selfId: string): RuntimeInstance | undefined;
  /** Caminho `res://…prefab.json` → referência de recurso carregável (`undefined` = não é um prefab do projeto). */
  resolvePrefab(path: string): ResourceRef | undefined;
  /** Lança `SpawnError` em qualquer falha (nunca spawn parcial). */
  spawn(ref: ResourceRef, options: SpawnOptions): SpawnedHandle;
  despawn(rootId: string): void;
  /** Carrega prefabs antes do primeiro disparo (assíncrono; o spawn exige prefab já carregado). */
  preload(refs: readonly ResourceRef[]): Promise<unknown>;
  emitSignal(signal: string, options: { source?: string; args?: unknown[] }): void;
  report(severity: 'error' | 'warning', code: string, message: string, nodeId?: string): void;
  /** Dispara as regras do Behavior `behaviorId` do nó `ownerId` cujo Trigger é `trigger`. */
  fireHook(ownerId: string, behaviorId: string, trigger: WeaponHookTrigger, detail: string): void;
}

/** Estado/serviços compartilhados pelas funções do núcleo. */
export interface WeaponCoreContext {
  host: WeaponHost;
  /** Diagnóstico UMA vez por chave e sessão (`código:alvo:variável`…). */
  warnOnce(key: string, code: string, message: string, nodeId?: string): void;
  /** Projéteis vivos criados por este núcleo. */
  isProjectile(nodeId: string): boolean;
  projectileIds(): string[];
  track(projectile: ProjectileState): void;
}

export interface DamageParams {
  /** Quem causou o dano (atirador); só vai no payload do sinal e nas regras de alvo. */
  sourceId: string;
  targetId: string;
  amount: number;
  /** Variável LOCAL do alvo (padrão `health`). Nunca é criada automaticamente. */
  variable?: string;
  ignoreTags?: readonly string[];
  onlyTags?: readonly string[];
}

export type DamageOutcome =
  | { status: 'applied'; remaining: number }
  | { status: 'ignored'; reason: 'self' | 'projectile' | 'tag' | 'owner' }
  | { status: 'failed'; code: DamageFailure };

export type DamageFailure = 'weapon.damage_invalid_amount' | 'weapon.damage_target_missing' | 'weapon.damage_variable_missing' | 'weapon.damage_variable_not_number';

export interface FireParams {
  /** Nó que atira (dono do disparo e do `ownerId` do projétil). */
  sourceId: string;
  /** Behavior que recebe os hooks `on_weapon_*` (ausente = sem hooks; ex.: Action avulsa). */
  behaviorId?: string;
  mode: 'physical' | 'hitscan';
  /** Origem do disparo (ID/nome); vazio = o próprio atirador. */
  firepoint?: string;
  /** Alvo da mira (ID/nome); vazio = direção do Firepoint. */
  aimTarget?: string;
  /** AIS-71: deslocamento da origem do disparo no espaço LOCAL do Firepoint (ex.: `shootPositionDisplacement` da Action `shoot`). */
  originOffset?: Vec3;
  /** Prefab do projétil (`res://prefabs/*.prefab.json`); obrigatório no modo `physical`. */
  bullet?: string;
  /** Prefab do efeito de impacto (opcional). */
  impactEffect?: string;
  impactEffectLifetimeMs?: number;
  speed: number;
  damage: number;
  damageVariable?: string;
  range: number;
  rangeMode: 'distance' | 'time';
  lifetimeMs: number;
  facesMotion: boolean;
  collisionDestroyDelayMs: number;
  ignoreTags?: readonly string[];
  onlyTags?: readonly string[];
  /** Orientação da câmera ativa (`ViewBasis`), em graus: se presente, a mira segue a câmera (decisão 28; só leitura). */
  aimView?: { yaw: number; pitch: number };
  /** Recuo da mira (graus) somado ao disparo. */
  kick?: { yaw: number; pitch: number };
}

export type FireOutcome =
  | { ok: true; mode: 'physical'; projectileId: string }
  | { ok: true; mode: 'hitscan'; hit: { nodeId: string; point: Vec3; normal: Vec3; distance: number } | null }
  | { ok: false; code: FireFailure; message: string };

export type FireFailure = 'weapon.source_missing' | 'weapon.firepoint_missing' | 'weapon.aim_target_missing' | 'weapon.bullet_missing' | 'weapon.prefab_unresolved' | 'weapon.spawn_failed' | 'weapon.no_physics' | 'weapon.bad_params';

export interface ProjectileState {
  id: string;
  ownerId: string;
  behaviorId?: string;
  damage: number;
  damageVariable: string;
  ignoreTags: readonly string[];
  onlyTags: readonly string[];
  impactEffect?: string;
  impactEffectLifetimeMs: number;
  /** Direção unitária de voo e velocidade (m/s): mantidas a cada quadro (sem gravidade própria). */
  direction: Vec3;
  speed: number;
  start: Vec3;
  spawnedAt: number;
  rangeMode: 'distance' | 'time';
  range: number;
  lifetimeMs: number;
  collisionDestroyDelayMs: number;
  /** Cada projétil atinge cada alvo no máximo uma vez. */
  hitIds: Set<string>;
  /** Depois do primeiro impacto: não aplica dano de novo; some em `destroyAt`. */
  impacted: boolean;
  destroyAt?: number;
}

export interface ExplosionParams {
  sourceId: string;
  /** Centro (ID/nome); vazio = o próprio nó que explode. */
  center?: string;
  radius: number;
  damage: number;
  damageVariable?: string;
  /** Impulso máximo (N·s) no centro; cai linearmente até 0 na borda. 0 = sem impulso. */
  impulse: number;
  ignoreTags?: readonly string[];
  onlyTags?: readonly string[];
  /** O atirador (e descendentes) também recebe? Padrão: não. */
  hitSource?: boolean;
}

export interface ExplosionOutcome {
  hit: string[];
  damaged: string[];
  pushed: string[];
}
