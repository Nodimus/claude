import * as THREE from 'three';
import type { Vec3 } from '../../core/physics/bounds';

/**
 * AIS-69 — mira (puro). Direções MUNDIAIS unitárias; graus nos ângulos (como o authoring). Convenção do `cameraRig`: yaw 0 olha para -Z
 * e yaw 90 para -X; pitch positivo olha para cima.
 */

const norm = (v: Vec3): Vec3 | null => {
  const len = Math.hypot(v.x, v.y, v.z);
  return len > 1e-9 ? { x: v.x / len, y: v.y / len, z: v.z / len } : null;
};

/** Direção de `from` para `to`; `null` se coincidem. */
export function directionBetween(from: Vec3, to: Vec3): Vec3 | null {
  return norm({ x: to.x - from.x, y: to.y - from.y, z: to.z - from.z });
}

/** Frente (-Z local) de uma rotação em quaternion. */
export function forwardOf(q: { x: number; y: number; z: number; w: number }): Vec3 {
  const v = new THREE.Vector3(0, 0, -1).applyQuaternion(new THREE.Quaternion(q.x, q.y, q.z, q.w));
  return { x: v.x, y: v.y, z: v.z };
}

/** Direção do olhar da câmera ativa (`ViewBasis`: yaw/pitch em graus). */
export function forwardFromView(view: { yaw: number; pitch: number }): Vec3 {
  const yaw = THREE.MathUtils.degToRad(view.yaw);
  const pitch = THREE.MathUtils.degToRad(view.pitch);
  return { x: -Math.sin(yaw) * Math.cos(pitch), y: Math.sin(pitch), z: -Math.cos(yaw) * Math.cos(pitch) };
}

/** Gira `dir` por `kick` (yaw em torno de Y do mundo, pitch em torno do eixo lateral). Sem recuo devolve a mesma direção. */
export function applyKick(dir: Vec3, kick?: { yaw: number; pitch: number }): Vec3 {
  if (!kick || (kick.yaw === 0 && kick.pitch === 0)) return dir;
  const d = new THREE.Vector3(dir.x, dir.y, dir.z);
  d.applyAxisAngle(new THREE.Vector3(0, 1, 0), THREE.MathUtils.degToRad(kick.yaw));
  const side = new THREE.Vector3().crossVectors(d, new THREE.Vector3(0, 1, 0));
  if (side.lengthSq() > 1e-9) d.applyAxisAngle(side.normalize(), THREE.MathUtils.degToRad(kick.pitch));
  d.normalize();
  return { x: d.x, y: d.y, z: d.z };
}

/**
 * Projeta `dir` no plano de `constrainToPlane` (decisões 6 e 26: o plano 2D vem do bloco de física do atirador e do projétil) e
 * renormaliza. `xy` trava Z, `xz` trava Y, `yz` trava X. Sem plano (ou direção que sobraria nula) devolve a mesma.
 */
export function constrainDirection(dir: Vec3, plane: 'none' | 'xy' | 'xz' | 'yz' | undefined): Vec3 {
  if (!plane || plane === 'none') return dir;
  const d = { ...dir };
  if (plane === 'xy') d.z = 0;
  else if (plane === 'xz') d.y = 0;
  else d.x = 0;
  return norm(d) ?? dir;
}

/** Rotação (graus, XYZ) que aponta o -Z do objeto para `dir`. */
export function eulerDegreesFacing(dir: Vec3): [number, number, number] {
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, -1), new THREE.Vector3(dir.x, dir.y, dir.z).normalize());
  const e = new THREE.Euler().setFromQuaternion(q, 'XYZ');
  return [THREE.MathUtils.radToDeg(e.x), THREE.MathUtils.radToDeg(e.y), THREE.MathUtils.radToDeg(e.z)];
}
