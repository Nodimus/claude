/**
 * AIS-69 — filtros por Tags (puro). `IgnoreTags` e `OnlyTags` são listas de Tags genéricas (as mesmas do AIS-71): vêm como lista ou como
 * texto separado por vírgula (campo de texto do modal de parâmetros).
 */

/** `"inimigo, boss"` → `['inimigo','boss']`; lista é limpa e deduplicada; qualquer outra coisa → `[]`. */
export function parseTagList(value: unknown): string[] {
  const raw = Array.isArray(value) ? value : typeof value === 'string' ? value.split(',') : [];
  return [...new Set(raw.map((t) => (typeof t === 'string' ? t.trim() : '')).filter((t) => t.length > 0))];
}

/**
 * O alvo com estas tags pode receber dano? `ignore` vence `only`; `only` vazio = qualquer um. Comparação exata (sem caixa).
 */
export function passesTagFilter(tags: readonly string[], ignore: readonly string[] = [], only: readonly string[] = []): boolean {
  if (ignore.length > 0 && tags.some((t) => ignore.includes(t))) return false;
  if (only.length > 0) return tags.some((t) => only.includes(t));
  return true;
}
