import { describe, expect, it } from 'vitest';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { LogicRegistry } from '../../logic/registry';
import { ActionRuntime } from '../../logic/actionRuntime';
import { BehaviorRuntimeCatalog } from '../../logic/behaviorRuntime';
import { parseTagList, passesTagFilter } from './tags';
import { applyKick, directionBetween, eulerDegreesFacing, forwardFromView, forwardOf } from './aim';
import { afterShot, canReload, evaluateShot, finishReloadIfDue, newClock, reloadTarget, shotRequested, startReload, type AmmoConfig } from './ammo';
import { readWeaponParams, WEAPON_DEFAULTS } from './params';
import { collectWeaponPrefabPaths } from './prefabPaths';

/** AIS-69 — partes PURAS do núcleo de armas + o contrato "um só caminho" (C01, C03, C10). */

describe('catálogo (AIS-69-C01)', () => {
  it('weapon_controller, fire_projectile, apply_damage e explode_area estão no LogicRegistry, com categoria Física e executor', () => {
    for (const id of ['fire_projectile', 'apply_damage', 'explode_area']) {
      const a = LogicRegistry.getAction(id);
      expect(a, id).toBeDefined();
      expect(a!.category).toBe('Physics');
      expect(ActionRuntime.get(id), `executor de ${id}`).toBeDefined();
    }
    const b = LogicRegistry.getBehavior('weapon_controller');
    expect(b).toBeDefined();
    expect(b!.category).toBe('Physics');
    expect(BehaviorRuntimeCatalog.get('weapon_controller'), 'runtime de weapon_controller').toBeDefined();
  });

  it('os 4 hooks são Triggers da arma; NÃO existe on_projectile_hit (ARM-03)', () => {
    for (const id of ['on_weapon_shoot', 'on_weapon_impact', 'on_weapon_empty', 'on_weapon_reload']) expect(LogicRegistry.isKnownTrigger(id), id).toBe(true);
    expect(LogicRegistry.isKnownTrigger('on_projectile_hit')).toBe(false);
  });

  it('o Behavior nasce com os 4 hooks como regras vazias (o editor liga as Actions a cada uma)', () => {
    const created = (LogicRegistry.getBehavior('weapon_controller') as any).create({ targetNodeId: 'x' });
    expect(created.rules.map((r: { eventType: string }) => r.eventType)).toEqual(['on_weapon_shoot', 'on_weapon_impact', 'on_weapon_empty', 'on_weapon_reload']);
    for (const r of created.rules) expect(r.actions).toEqual([]);
  });

  it('o Behavior não tem ConstrainToPlane/ForwardAxis (ARM-10: vêm de properties.physics)', () => {
    const keys = LogicRegistry.getBehavior('weapon_controller')!.params.map((p) => p.key.toLowerCase());
    expect(keys.some((k) => k.includes('constrain') || k.includes('forwardaxis'))).toBe(false);
  });
});

describe('tags', () => {
  it('lista por vírgula, ignore vence only, only vazio libera todos', () => {
    expect(parseTagList(' inimigo, boss ,, inimigo')).toEqual(['inimigo', 'boss']);
    expect(parseTagList(['a', 7, ' b '])).toEqual(['a', 'b']);
    expect(parseTagList(undefined)).toEqual([]);
    expect(passesTagFilter(['x'], [], [])).toBe(true);
    expect(passesTagFilter(['inimigo'], ['inimigo'], ['inimigo'])).toBe(false);
    expect(passesTagFilter(['amigo'], [], ['inimigo'])).toBe(false);
    expect(passesTagFilter(['inimigo', 'boss'], ['x'], ['boss'])).toBe(true);
  });
});

describe('mira', () => {
  it('direção entre pontos, frente do quaternion e olhar da câmera (yaw 0 = -Z; yaw 90 = -X)', () => {
    expect(directionBetween({ x: 0, y: 0, z: 0 }, { x: 0, y: 0, z: -4 })).toEqual({ x: 0, y: 0, z: -1 });
    expect(directionBetween({ x: 1, y: 1, z: 1 }, { x: 1, y: 1, z: 1 })).toBeNull();
    const f = forwardOf({ x: 0, y: 0, z: 0, w: 1 });
    expect(f.z).toBeCloseTo(-1);
    const right = forwardFromView({ yaw: 90, pitch: 0 });
    expect(right.x).toBeCloseTo(-1);
    expect(forwardFromView({ yaw: 0, pitch: 90 }).y).toBeCloseTo(1);
  });
  it('recuo gira a direção; sem recuo devolve a mesma; euler aponta o -Z para a direção', () => {
    const dir = { x: 0, y: 0, z: -1 };
    expect(applyKick(dir)).toBe(dir);
    expect(applyKick(dir, { yaw: 0, pitch: 0 })).toBe(dir);
    const up = applyKick(dir, { yaw: 0, pitch: 10 });
    expect(up.y).toBeGreaterThan(0.15);
    const side = applyKick(dir, { yaw: 10, pitch: 0 });
    expect(side.x).toBeLessThan(-0.15);
    const [, yaw] = eulerDegreesFacing({ x: -1, y: 0, z: 0 });
    expect(yaw).toBeCloseTo(90, 3);
  });
});

describe('cadência, munição e recarga (AIS-69-C06, máquina pura)', () => {
  const cfg: AmmoConfig = { magazine: 3, maxAmmo: 0, shootDelayMs: 200, reloadDelayMs: 1000, autoReload: false, shootOnce: false };
  it('ShootDelay: depois de um tiro só atira de novo passado o intervalo', () => {
    const c = newClock();
    expect(evaluateShot(c, cfg, 0, 3)).toBe('shoot');
    expect(afterShot(c, cfg, 0, 3)).toBe(2);
    expect(evaluateShot(c, cfg, 0.1, 2)).toBe('cooldown');
    expect(evaluateShot(c, cfg, 0.2, 2)).toBe('shoot');
  });
  it('munição zerada = empty; nunca negativa; infinita (null) nunca esvazia', () => {
    const c = newClock();
    expect(evaluateShot(c, cfg, 0, 0)).toBe('empty');
    expect(afterShot(c, cfg, 0, 0)).toBe(0);
    expect(afterShot(newClock(), cfg, 0, null)).toBeNull();
    expect(evaluateShot(newClock(), cfg, 0, null)).toBe('shoot');
  });
  it('recarga: bloqueia o tiro até o fim; enche até o carregador (respeitando maxAmmo); não recarrega cheio', () => {
    const c = newClock();
    expect(canReload(c, cfg, 3)).toBe(false);
    expect(canReload(c, cfg, 1)).toBe(true);
    startReload(c, cfg, 10);
    expect(canReload(c, cfg, 1)).toBe(false);
    expect(evaluateShot(c, cfg, 10.5, 1)).toBe('reloading');
    expect(finishReloadIfDue(c, 10.5)).toBe(false);
    expect(finishReloadIfDue(c, 11)).toBe(true);
    expect(evaluateShot(c, cfg, 11, 3)).toBe('shoot');
    expect(reloadTarget({ ...cfg, maxAmmo: 2 })).toBe(2);
    expect(canReload(newClock(), { ...cfg, magazine: 0 }, 0)).toBe(false); // sem sistema de munição
  });
  it('ShootOnce só no clique; senão enquanto segura', () => {
    expect(shotRequested(cfg, { pressed: true, justPressed: false })).toBe(true);
    expect(shotRequested({ ...cfg, shootOnce: true }, { pressed: true, justPressed: false })).toBe(false);
    expect(shotRequested({ ...cfg, shootOnce: true }, { pressed: true, justPressed: true })).toBe(true);
  });
});

describe('parâmetros e prefabs', () => {
  it('leitura tolerante com os padrões', () => {
    expect(readWeaponParams(undefined).bulletSpeed).toBe(WEAPON_DEFAULTS.bulletSpeed);
    const p = readWeaponParams({ fireMode: 'hitscan', bulletSpeed: -5, ignoreTags: 'a, b', rangeMode: 'x', shootDelay: 'lento' });
    expect(p.fireMode).toBe('hitscan');
    expect(p.bulletSpeed).toBe(0);
    expect(p.ignoreTags).toEqual(['a', 'b']);
    expect(p.rangeMode).toBe('distance');
    expect(p.shootDelay).toBe(WEAPON_DEFAULTS.shootDelay);
  });
  it('coleta os prefabs do Behavior e das Actions fire_projectile para carregar na abertura', () => {
    const snapshot = {
      nodes: {
        a: { id: 'a', behaviors: [{ behaviorType: 'weapon_controller', properties: { bullet: 'res://prefabs/b.prefab.json', impactEffect: ' res://prefabs/fx.prefab.json ' }, rules: [] }] },
        b: { id: 'b', behaviors: [{ behaviorType: 'custom_rules', properties: {}, rules: [{ actions: [{ type: 'fire_projectile', parameters: { bullet: 'res://prefabs/c.prefab.json' } }, { type: 'print_log', parameters: {} }] }] }] },
      },
    } as never;
    expect(collectWeaponPrefabPaths(snapshot).sort()).toEqual(['res://prefabs/b.prefab.json', 'res://prefabs/c.prefab.json', 'res://prefabs/fx.prefab.json']);
  });
});

describe('um só caminho (AIS-69-C03, C10)', () => {
  const read = (p: string) => readFileSync(p, 'utf8');
  const walk = (dir: string): string[] => readdirSync(dir).flatMap((n) => (statSync(join(dir, n)).isDirectory() ? walk(join(dir, n)) : n.endsWith('.ts') && !n.endsWith('.test.ts') ? [join(dir, n)] : []));

  it('o núcleo de armas não usa THREE.Raycaster, Rapier nem physicsRegistry', () => {
    for (const file of walk('src/runtime/weapons')) {
      const code = read(file).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
      expect(code, file).not.toMatch(/Raycaster|@dimforge|rapier|physicsRegistry/i);
    }
  });

  it('Action, Behavior e (AIS-71) Shoot chamam o MESMO núcleo: sem spawnPrefab/raycast/overlap próprios', () => {
    for (const file of ['src/logic/actions/fire_projectile/runtime.ts', 'src/logic/actions/apply_damage/runtime.ts', 'src/logic/actions/explode_area/runtime.ts', 'src/logic/actions/shoot/runtime.ts', 'src/logic/behaviors/weapon_controller/runtime.ts']) {
      const code = read(file).replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, '');
      expect(code, file).not.toMatch(/spawnPrefab|despawn|raycast|overlapSphere|Raycaster|addImpulse/);
      expect(code, file).toMatch(/weapons\.(fire|damage|explode)\(/);
    }
  });
});
