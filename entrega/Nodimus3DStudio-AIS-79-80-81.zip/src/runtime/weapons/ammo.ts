/**
 * AIS-69 — cadência, munição e recarga do Weapon Controller (máquina de estados PURA). Tempo em segundos de JOGO. A munição em curso
 * é uma variável LOCAL do atirador (`Ammo`, AIS-43) lida/escrita pelo Behavior; aqui só se decide o que fazer.
 *
 *  - `magazine` = tiros por carregador (0 = munição infinita, o sistema de munição fica desligado);
 *  - `maxAmmo` = teto da variável (0 = sem teto extra); a recarga enche até `min(magazine, maxAmmo)`.
 */

export interface AmmoConfig {
  magazine: number;
  maxAmmo: number;
  shootDelayMs: number;
  reloadDelayMs: number;
  autoReload: boolean;
  shootOnce: boolean;
}

export interface WeaponClock {
  /** Instante (s) a partir do qual o próximo tiro é permitido. */
  nextShotAt: number;
  /** Fim da recarga em curso; `null` = não está recarregando. */
  reloadingUntil: number | null;
}

export const newClock = (): WeaponClock => ({ nextShotAt: 0, reloadingUntil: null });

export const hasAmmoSystem = (cfg: AmmoConfig): boolean => cfg.magazine > 0;

export const reloadTarget = (cfg: AmmoConfig): number => (cfg.maxAmmo > 0 ? Math.min(cfg.magazine, cfg.maxAmmo) : cfg.magazine);

/** O jogador pediu um tiro neste quadro? (`ShootOnce` = só no clique; senão enquanto segura) */
export const shotRequested = (cfg: AmmoConfig, input: { pressed: boolean; justPressed: boolean }): boolean => (cfg.shootOnce ? input.justPressed : input.pressed);

export type ShotDecision = 'shoot' | 'empty' | 'cooldown' | 'reloading';

/** `ammo === null` = sistema de munição desligado ou variável indisponível tratada pelo chamador. */
export function evaluateShot(clock: WeaponClock, cfg: AmmoConfig, now: number, ammo: number | null): ShotDecision {
  if (clock.reloadingUntil !== null) return 'reloading';
  if (now < clock.nextShotAt) return 'cooldown';
  if (ammo !== null && ammo <= 0) return 'empty';
  return 'shoot';
}

/** Registra o tiro: inicia a cadência e devolve a munição restante (`null` se infinita). */
export function afterShot(clock: WeaponClock, cfg: AmmoConfig, now: number, ammo: number | null): number | null {
  clock.nextShotAt = now + Math.max(0, cfg.shootDelayMs) / 1000;
  return ammo === null ? null : Math.max(0, ammo - 1);
}

/** Pode começar a recarregar agora? (sistema ligado, não recarregando e carregador não cheio) */
export function canReload(clock: WeaponClock, cfg: AmmoConfig, ammo: number | null): boolean {
  return hasAmmoSystem(cfg) && ammo !== null && clock.reloadingUntil === null && ammo < reloadTarget(cfg);
}

export function startReload(clock: WeaponClock, cfg: AmmoConfig, now: number): void {
  clock.reloadingUntil = now + Math.max(0, cfg.reloadDelayMs) / 1000;
}

/** A recarga terminou neste instante? Se sim, limpa o estado e devolve `true`. */
export function finishReloadIfDue(clock: WeaponClock, now: number): boolean {
  if (clock.reloadingUntil === null || now < clock.reloadingUntil) return false;
  clock.reloadingUntil = null;
  return true;
}
