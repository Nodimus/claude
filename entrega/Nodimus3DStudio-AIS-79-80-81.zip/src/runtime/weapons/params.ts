import { parseTagList } from './tags';

/**
 * AIS-69 — propriedades do Behavior `weapon_controller` (leitura PURA e tolerante: valor ausente/inválido cai no padrão; nunca lança).
 * Plano 2D: NÃO há campo aqui (ARM-10): vale `properties.physics.constrainToPlane/forwardAxis` do atirador e do projétil (decisões 6 e 26).
 */

export interface WeaponParams {
  gunName: string;
  /** Prefab do projétil e do efeito de impacto (`res://prefabs/*.prefab.json`). */
  bullet: string;
  impactEffect: string;
  /** Referências por ID/nome de nó (vazio: Firepoint = o atirador; AimTarget = frente do Firepoint). */
  firepoint: string;
  aimTarget: string;
  fireMode: 'physical' | 'hitscan';
  fireAction: string;
  shootDelay: number;
  shootOnce: boolean;
  recoil: boolean;
  recoilHorizontal: number;
  recoilVertical: number;
  /** Tiros por carregador (0 = munição infinita) e teto da variável. */
  magazine: number;
  /** NOME da variável Local do atirador com a munição em curso (padrão `Ammo`). */
  ammo: string;
  maxAmmo: number;
  reloadAction: string;
  reloadDelay: number;
  autoReload: boolean;
  bulletSpeed: number;
  bulletDamage: number;
  damageVariable: string;
  bulletRange: number;
  rangeMode: 'distance' | 'time';
  bulletLifetimeMs: number;
  bulletFacesMotion: boolean;
  collisionDestroyDelayMs: number;
  ignoreTags: string[];
  onlyTags: string[];
  /** A mira segue a câmera ativa (`ViewBasis`, só leitura; decisão 28). */
  aimFromCamera: boolean;
  /** Com `aimFromCamera`: inclui também a inclinação (1ª pessoa). Desligado, o tiro segue só o yaw da câmera (horizontal; 3ª pessoa, onde a câmera olha de cima). */
  aimWithPitch: boolean;
}

export const WEAPON_DEFAULTS = {
  gunName: 'Weapon',
  bullet: '',
  impactEffect: '',
  firepoint: '',
  aimTarget: '',
  fireMode: 'physical',
  fireAction: 'Fire',
  shootDelay: 250,
  shootOnce: false,
  recoil: false,
  recoilHorizontal: 0.5,
  recoilVertical: 1,
  magazine: 0,
  ammo: 'Ammo',
  maxAmmo: 0,
  reloadAction: 'Reload',
  reloadDelay: 1500,
  autoReload: false,
  bulletSpeed: 30,
  bulletDamage: 10,
  damageVariable: 'health',
  bulletRange: 100,
  rangeMode: 'distance',
  bulletLifetimeMs: 3000,
  bulletFacesMotion: true,
  collisionDestroyDelayMs: 0,
  ignoreTags: '',
  onlyTags: '',
  aimFromCamera: false,
  aimWithPitch: false,
} as const;

const num = (v: unknown, fallback: number, min = 0): number => (typeof v === 'number' && Number.isFinite(v) ? Math.max(min, v) : fallback);
const str = (v: unknown, fallback: string): string => (typeof v === 'string' ? v.trim() : fallback);
const bool = (v: unknown, fallback: boolean): boolean => (typeof v === 'boolean' ? v : fallback);

export function readWeaponParams(p: Record<string, any> | undefined): WeaponParams {
  const d = WEAPON_DEFAULTS;
  const props = p ?? {};
  return {
    gunName: str(props.gunName, d.gunName) || d.gunName,
    bullet: str(props.bullet, d.bullet),
    impactEffect: str(props.impactEffect, d.impactEffect),
    firepoint: str(props.firepoint, d.firepoint),
    aimTarget: str(props.aimTarget, d.aimTarget),
    fireMode: props.fireMode === 'hitscan' ? 'hitscan' : 'physical',
    fireAction: str(props.fireAction, d.fireAction) || d.fireAction,
    shootDelay: num(props.shootDelay, d.shootDelay),
    shootOnce: bool(props.shootOnce, d.shootOnce),
    recoil: bool(props.recoil, d.recoil),
    recoilHorizontal: num(props.recoilHorizontal, d.recoilHorizontal),
    recoilVertical: num(props.recoilVertical, d.recoilVertical),
    magazine: Math.floor(num(props.magazine, d.magazine)),
    ammo: str(props.ammo, d.ammo) || d.ammo,
    maxAmmo: Math.floor(num(props.maxAmmo, d.maxAmmo)),
    reloadAction: str(props.reloadAction, d.reloadAction) || d.reloadAction,
    reloadDelay: num(props.reloadDelay, d.reloadDelay),
    autoReload: bool(props.autoReload, d.autoReload),
    bulletSpeed: num(props.bulletSpeed, d.bulletSpeed),
    bulletDamage: num(props.bulletDamage, d.bulletDamage),
    damageVariable: str(props.damageVariable, d.damageVariable) || d.damageVariable,
    bulletRange: num(props.bulletRange, d.bulletRange),
    rangeMode: props.rangeMode === 'time' ? 'time' : 'distance',
    bulletLifetimeMs: num(props.bulletLifetimeMs, d.bulletLifetimeMs),
    bulletFacesMotion: bool(props.bulletFacesMotion, d.bulletFacesMotion),
    collisionDestroyDelayMs: num(props.collisionDestroyDelayMs, d.collisionDestroyDelayMs),
    ignoreTags: parseTagList(props.ignoreTags),
    onlyTags: parseTagList(props.onlyTags),
    aimFromCamera: bool(props.aimFromCamera, d.aimFromCamera),
    aimWithPitch: bool(props.aimWithPitch, d.aimWithPitch),
  };
}
