import type { AuthoringSceneSnapshot } from '../../types/runtime';

/**
 * AIS-69 — caminhos de prefab que as armas da cena vão usar (puro): `Bullet`/`ImpactEffect` dos Behaviors `weapon_controller` e
 * `bullet`/`impactEffect` das Actions `fire_projectile` e `shoot` (nas regras de qualquer Behavior). A sessão os carrega na abertura: o spawn é
 * síncrono e exige prefab já carregado (AIS-29g).
 */

const isPrefabPath = (v: unknown): v is string => typeof v === 'string' && v.trim().endsWith('.prefab.json');

export function collectWeaponPrefabPaths(snapshot: Pick<AuthoringSceneSnapshot, 'nodes'>): string[] {
  const found = new Set<string>();
  for (const node of Object.values(snapshot.nodes)) {
    for (const behavior of node.behaviors ?? []) {
      if (behavior.behaviorType === 'weapon_controller') {
        for (const key of ['bullet', 'impactEffect']) if (isPrefabPath(behavior.properties?.[key])) found.add((behavior.properties[key] as string).trim());
      }
      for (const rule of behavior.rules ?? []) {
        for (const action of rule.actions ?? []) {
          if (action.type !== 'fire_projectile' && action.type !== 'shoot') continue; // `shoot` (AIS-71) usa o mesmo núcleo: o projétil também é pré-carregado
          for (const key of ['bullet', 'impactEffect']) if (isPrefabPath(action.parameters?.[key])) found.add((action.parameters[key] as string).trim());
        }
      }
    }
  }
  return [...found];
}
