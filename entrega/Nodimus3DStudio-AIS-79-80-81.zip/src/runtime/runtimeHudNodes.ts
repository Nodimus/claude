import type { HudNode } from './overlayHud';
import type { RuntimeScene } from './RuntimeScene';

/**
 * AIS-44 — nós do HUD durante o Play: os nós de UI da cena autoral com as propriedades/visibilidade da instância VIVA por cima
 * (texto trocado por `change_text`, offsets de `move_by`, `visible`…). Função pura; devolve novos objetos e nunca muda o
 * autoral. Só o HUD (UIKit) é redesenhado com isto — a cena 3D não é tocada. O Runtime Host (AIS-44c) substitui esta ponte.
 */
export function mergeRuntimeHudNodes(authoring: Readonly<Record<string, HudNode>>, scene: RuntimeScene | null): Record<string, HudNode> {
  if (!scene) return authoring as Record<string, HudNode>;
  const out: Record<string, HudNode> = {};
  for (const [id, node] of Object.entries(authoring)) {
    const live = scene.getInstance(id);
    if (live) out[id] = { ...node, properties: { ...(node.properties ?? {}), ...live.properties }, visible: live.visible };
    else out[id] = scene.wasDestroyed(id) ? { ...node, visible: false } : node; // destruído no jogo: some do HUD
  }
  return out;
}
