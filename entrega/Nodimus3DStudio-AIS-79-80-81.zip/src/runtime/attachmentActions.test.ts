import { describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { RuntimeSession } from './RuntimeSession';
import type { LogicLogEntry } from './logicRunner';
import { AttachmentHost } from './attachmentRuntime';
import { canAttachToBone, attachmentValue, isModelHolder, readAttachment } from '../core/attachment/boneAttachment';

/** AIS-61 §4 — `attach_to_bone` / `detach_from_bone` executam no Play (estado da sessão) e a regra autoral é única. */

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[]): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters: {}, conditions: [], actions });
const rules = (...r: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'Regras', behaviorType: 'custom_rules', enabled: true, properties: {}, rules: r });
const node = (id: string, type: string, parentId: string, props: Record<string, any> = {}, extra: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type, parentId, childrenIds: [], visible: true, locked: false, properties: props, ...extra }) as unknown as GameNode;

function play(actions: LogicAction[]) {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = {
    [root.id]: { ...root, childrenIds: ['hero', 'sword'] } as GameNode,
    hero: node('hero', 'MeshInstance', root.id, { meshType: 'CubeMesh' }),
    sword: node('sword', 'MeshInstance', root.id, { meshType: 'CubeMesh' }, { behaviors: [rules(rule('on_start', actions))] } as Partial<GameNode>),
  };
  const logs: LogicLogEntry[] = [];
  const session = new RuntimeSession({
    snapshot: createRuntimeSnapshot({ ...scene, nodes } as unknown as SceneData),
    input: { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never,
    onLog: (e) => logs.push(e),
  });
  session.start();
  return { session, errors: () => logs.filter((l) => l.level === 'error').map((l) => l.message) };
}

describe('attach_to_bone / detach_from_bone', () => {
  it('attach registra o vínculo na sessão (holder, osso) e posiciona o nó no offset local', () => {
    const { session, errors } = play([act('attach_to_bone', { target: '', holder: 'hero', bone: 'mixamorigRightHand', offset: { x: 1, y: 2, z: 3 } })]);
    session.step(1 / 60);
    expect(errors()).toEqual([]);
    expect(session.attachments.get('sword')).toEqual({ holder: 'hero', bone: 'mixamorigRightHand' });
    expect(session.currentScene!.getInstance('sword')!.transform.position).toEqual([1, 2, 3]);
  });

  it('sem holder vale o pai autoral (holder = null)', () => {
    const { session } = play([act('attach_to_bone', { bone: 'Hand' })]);
    session.step(1 / 60);
    expect(session.attachments.get('sword')).toEqual({ holder: null, bone: 'Hand' });
  });

  it('detach marca "solto" (anula também o vínculo autoral) e Stop/clear esvazia tudo', () => {
    const { session } = play([act('attach_to_bone', { holder: 'hero', bone: 'Hand' }), act('detach_from_bone', {})]);
    session.step(1 / 60);
    expect(session.attachments.get('sword')).toBeNull();
    session.dispose();
    expect(session.attachments.entries()).toEqual([]);
  });

  it('erros explícitos: holder inexistente, osso vazio, preso a si mesmo', () => {
    const missing = play([act('attach_to_bone', { holder: 'nada', bone: 'Hand' })]);
    missing.session.step(1 / 60);
    expect(missing.errors().join('\n')).toMatch(/nada/);
    const self = play([act('attach_to_bone', { holder: 'sword', bone: 'Hand' })]);
    self.session.step(1 / 60);
    expect(self.errors().join('\n')).toMatch(/próprio esqueleto/);
    expect(self.session.attachments.get('sword')).toBeUndefined();
  });
});

describe('AttachmentHost', () => {
  it('get: undefined = intocado, null = solto, objeto = preso; revision muda a cada alteração', () => {
    const h = new AttachmentHost();
    expect(h.get('a')).toBeUndefined();
    const r0 = h.revision;
    h.attach('a', { holder: null, bone: 'Hand' });
    expect(h.get('a')).toEqual({ holder: null, bone: 'Hand' });
    h.detach('a');
    expect(h.get('a')).toBeNull();
    expect(h.revision).toBe(r0 + 2);
    h.clear();
    expect(h.get('a')).toBeUndefined();
  });
});

describe('regra autoral do attachment', () => {
  const holder = { type: 'MeshInstance', properties: { model: { id: 'm1', type: 'model', path: 'res://models/a.glb' } } } as unknown as GameNode;
  it('só filho de MeshInstance com modelo pode ser preso', () => {
    expect(isModelHolder(holder)).toBe(true);
    expect(isModelHolder({ type: 'MeshInstance', properties: { meshType: 'CubeMesh' } } as unknown as GameNode)).toBe(false);
    expect(canAttachToBone({ type: 'MeshInstance', parentId: 'h' }, holder)).toBe(true);
    expect(canAttachToBone({ type: 'MeshInstance', parentId: 'h' }, undefined)).toBe(false);
  });
  it('leitura tolerante e valor gravado (null remove)', () => {
    expect(readAttachment({ attachment: { bone: 'Hand' } })).toEqual({ bone: 'Hand' });
    expect(readAttachment({ attachment: { bone: '' } })).toBeUndefined();
    expect(readAttachment({ attachment: 'x' })).toBeUndefined();
    expect(readAttachment(undefined)).toBeUndefined();
    expect(attachmentValue(' Hand ')).toEqual({ bone: 'Hand' });
    expect(attachmentValue('')).toBeNull();
    expect(attachmentValue(null)).toBeNull();
  });
});
