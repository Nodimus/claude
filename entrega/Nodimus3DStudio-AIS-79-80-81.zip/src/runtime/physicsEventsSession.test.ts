import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import type { BehaviorRuntime, BehaviorRuntimeModule } from '../logic/types';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { ensureRapier } from '../core/physics/rapierInit';
import { applyPhysicsPatch, defaultPhysicsConfig, diffPhysics, readPhysics } from '../core/physics/physicsConfig';
import { PHYSICS_SIGNALS, signalsEmittedBy } from '../core/signals/emittedSignals';
import { LogicRegistry } from '../logic/registry';
import { getNodeMetadata } from '../nodes/registry';
import objectMoved from '../logic/behaviors/object_moved_by_physics';
import { RuntimeSession, type NodeSignalEvent, type RuntimeSessionOptions } from './RuntimeSession';
import type { LogicLogEntry } from './logicRunner';
import { createEngineApi } from './engineApi';
import type { PhysicsEvent } from '../core/physics/PhysicsBridge';

/**
 * AIS-48 — despacho dos eventos físicos DENTRO da `RuntimeSession`: os 4 Triggers (Collision/Trigger × Enter/Exit), força mínima +
 * debounce do impacto, sinais `body_entered`/`body_exited` com `otherId`, `onPhysicsEvent → unsubscribe` (cancelado em Stop, Restart e
 * detach de Behavior) e o Behavior `Object Moved By Physics Engine`.
 */

beforeAll(async () => {
  await ensureRapier();
});

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[], parameters: Record<string, any> = {}): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters, conditions: [], actions });
const behavior = (type: string, rules: LogicEventRule[] = [], id = `b${++seq}`): BehaviorInstance => ({ id, name: `B_${id}`, behaviorType: type, enabled: true, properties: {}, rules });
const custom = (...rules: LogicEventRule[]) => behavior('custom_rules', rules);

const node = (id: string, at: [number, number, number], physics: Record<string, any> | undefined, extra: Record<string, any> = {}, nodeExtra: Record<string, any> = {}): GameNode =>
  ({
    id,
    name: id,
    type: 'MeshInstance',
    parentId: null,
    childrenIds: [],
    visible: true,
    locked: false,
    properties: { meshType: 'CubeMesh', position: { x: at[0], y: at[1], z: at[2] }, ...(physics ? { physics } : {}), ...extra },
    ...nodeExtra,
  }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  return { ...scene, nodes };
}

const fakeInput = () => ({
  isActionPressed: () => false,
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: () => 0,
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
});

const STATIC = { enabled: true, bodyMode: 'static', shape: 'auto' };
const DYNAMIC = { enabled: true, bodyMode: 'dynamic', shape: 'auto' };
const FLOOR = node('floor', [0, -0.5, 0], STATIC, { scale: { x: 80, y: 1, z: 80 } });

function open(scene: SceneData, extra: Partial<RuntimeSessionOptions> = {}) {
  const logs: LogicLogEntry[] = [];
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input: fakeInput(), onLog: (e) => logs.push(e), ...extra });
  session.start();
  return { session, logs };
}
const run = (session: RuntimeSession, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) session.step(1 / 60);
};
const counter = (name: string) => act('add_to_variable', { variable: name, amount: 1 });
const G = (...names: string[]) => names.map((name) => ({ name, type: 'number', value: 0 }));

describe('catálogo: os 4 Triggers físicos (AIS-48-C01)', () => {
  it('existem as pastas on_collision_enter/exit e on_trigger_enter/exit', () => {
    const ids = LogicRegistry.listTriggers().map((t) => t.id);
    for (const id of ['on_collision_enter', 'on_collision_exit', 'on_trigger_enter', 'on_trigger_exit']) expect(ids).toContain(id);
    expect(ids.some((id) => /stay/i.test(id))).toBe(false); // sem Stay (C04)
  });

  it('Collision e Trigger são DISTINTOS: cada evento dispara só o seu Trigger', () => {
    const scene = sceneWith(
      FLOOR,
      node('crate', [0, 2, 0], DYNAMIC, {}, { behaviors: [custom(rule('on_collision_enter', [counter('colEnter')]), rule('on_collision_exit', [counter('colExit')]), rule('on_trigger_enter', [counter('crateTrigEnter')]))] }),
      node('zone', [8, 3, 0], { enabled: true, bodyMode: 'trigger', shape: 'auto' }, { scale: { x: 3, y: 3, z: 3 } }, { behaviors: [custom(rule('on_trigger_enter', [counter('zoneEnter')]), rule('on_trigger_exit', [counter('zoneExit')]), rule('on_collision_enter', [counter('zoneColEnter')]))] }),
      node('ball', [8, 9, 0], DYNAMIC)
    );
    const { session } = open(scene, { globals: G('colEnter', 'colExit', 'crateTrigEnter', 'zoneEnter', 'zoneExit', 'zoneColEnter') });
    run(session, 3);
    const v = (n: string) => session.variables!.getVariable('global', n);
    expect(v('colEnter')).toBeGreaterThanOrEqual(1); // a caixa bateu no chão
    expect(v('zoneEnter')).toBeGreaterThanOrEqual(1); // a bola entrou na Área
    expect(v('zoneExit')).toBeGreaterThanOrEqual(1); // e saiu
    expect(v('crateTrigEnter')).toBe(0); // contato sólido NÃO é gatilho
    expect(v('zoneColEnter')).toBe(0); // gatilho NÃO é colisão
  });
});

describe('força mínima e debounce do impacto (legado do Behavior de impacto, AIS-48)', () => {
  const bouncy = (params: Record<string, any>) =>
    sceneWith(FLOOR, node('ball', [0, 3, 0], { enabled: true, bodyMode: 'dynamic', shape: 'sphere', bounce: 0.95 }, {}, { behaviors: [custom(rule('on_collision_enter', [counter('impacts')], params))] }));

  it('sem parâmetros dispara em todo impacto (a bola quica várias vezes)', () => {
    const { session } = open(bouncy({}), { globals: G('impacts') });
    run(session, 6);
    expect(session.variables!.getVariable('global', 'impacts')).toBeGreaterThanOrEqual(3);
  });

  it('Minimal Force: abaixo do limiar NÃO dispara; acima dispara', () => {
    const { session } = open(bouncy({ minimalForce: 1e9 }), { globals: G('impacts') });
    run(session, 6);
    expect(session.variables!.getVariable('global', 'impacts')).toBe(0);
    const { session: ok } = open(bouncy({ minimalForce: 0.0001 }), { globals: G('impacts') });
    run(ok, 6);
    expect(ok.variables!.getVariable('global', 'impacts')).toBeGreaterThanOrEqual(1);
  });

  it('Max Every (ms): respeita o debounce em tempo de JOGO', () => {
    const { session } = open(bouncy({ maxEveryMs: 60000 }), { globals: G('impacts') });
    run(session, 6);
    expect(session.variables!.getVariable('global', 'impacts')).toBe(1); // os demais quiques caem dentro da janela
    const loose = open(bouncy({ maxEveryMs: 1 }), { globals: G('impacts') });
    run(loose.session, 6);
    expect(loose.session.variables!.getVariable('global', 'impacts')).toBeGreaterThanOrEqual(3);
  });
});

describe('Behavior Object Moved By Physics Engine (preset dynamic)', () => {
  it('o preset traz a regra de impacto (legado → On Collision Enter com força/debounce) e liga a Colisão como dynamic', () => {
    expect(LogicRegistry.listBehaviorPresets().map((b) => b.id)).toContain('object_moved_by_physics');
    expect(objectMoved.presetPhysics).toEqual({ bodyMode: 'dynamic' });
    const created = objectMoved.create({ targetNodeId: 'crate' });
    expect(created.rules).toHaveLength(1);
    expect(created.rules[0].eventType).toBe('on_collision_enter');
    expect(created.rules[0].parameters).toEqual({ minimalForce: 0, maxEveryMs: 0 });
    // o patch do preset é UM diff do bloco (Command com Undo no editor): sem bloco cria dynamic automático; com bloco só troca o modo
    const fresh = applyPhysicsPatch(defaultPhysicsConfig(), objectMoved.presetPhysics!);
    expect(fresh.bodyMode).toBe('dynamic');
    expect(Object.keys(diffPhysics(null, fresh)).sort()).toEqual(['physics.bodyMode', 'physics.enabled', 'physics.shape']);
    const existing = applyPhysicsPatch({ enabled: true, bodyMode: 'static', shape: 'mesh' } as any, { bodyMode: 'dynamic' });
    expect(existing.shape).toBe('auto'); // "Malha exata" só em static: o patch mantém o estado coerente
    expect(readPhysics({ physics: existing })?.bodyMode).toBe('dynamic');
  });

  it('em execução: a regra do preset roda no impacto; corpo que não é dynamic avisa UMA vez', () => {
    const ruleWithAction = { ...objectMoved.create({ targetNodeId: 'crate' }), rules: [{ ...objectMoved.create({ targetNodeId: 'crate' }).rules[0], actions: [counter('hit')] }] };
    const { session, logs } = open(sceneWith(FLOOR, node('crate', [0, 2, 0], DYNAMIC, {}, { behaviors: [ruleWithAction] })), { globals: G('hit') });
    run(session, 3);
    expect(session.variables!.getVariable('global', 'hit')).toBeGreaterThanOrEqual(1);
    expect(logs.filter((l) => l.level === 'warn' && /Object Moved By Physics/.test(l.message))).toHaveLength(0);

    const wrong = open(sceneWith(FLOOR, node('crate', [0, 2, 0], STATIC, {}, { behaviors: [objectMoved.create({ targetNodeId: 'crate' })] })));
    run(wrong.session, 1);
    expect(wrong.logs.filter((l) => l.level === 'warn' && /"static"/.test(l.message))).toHaveLength(1);
  });
});

describe('sinais body_entered / body_exited (AIS-48-C02)', () => {
  it('pertencem ao nó com `properties.physics` (qualquer tipo) e vêm com o otherId; nó sem bloco não emite', () => {
    // tipo qualquer: um Spatial com o bloco emite; uma malha SEM bloco não
    const spatial = node('area', [8, 3, 0], { enabled: true, bodyMode: 'trigger', shape: 'auto' }, { scale: { x: 3, y: 3, z: 3 } }, { type: 'Spatial' });
    const { session } = open(sceneWith(FLOOR, spatial, node('ball', [8, 9, 0], DYNAMIC), node('decor', [20, 1, 0], undefined)));
    const signals: NodeSignalEvent[] = [];
    session.onNodeSignal((s) => signals.push(s));
    run(session, 3);
    const fromArea = signals.filter((s) => s.sourceNodeId === 'area');
    expect(fromArea.find((s) => s.signal === 'body_entered')?.args).toEqual(['ball']);
    expect(fromArea.find((s) => s.signal === 'body_exited')?.args).toEqual(['ball']);
    expect(signals.filter((s) => s.sourceNodeId === 'ball').some((s) => s.args[0] === 'area')).toBe(true); // a bola também "vê" a Área
    expect(signals.some((s) => s.sourceNodeId === 'decor')).toBe(false); // sem bloco de física: nenhum sinal
  });

  it('o Inspector oferece body_entered/body_exited só quando o nó tem o bloco de Colisão (qualquer tipo)', () => {
    expect(signalsEmittedBy('Spatial', { physics: STATIC })).toEqual(expect.arrayContaining([...PHYSICS_SIGNALS]));
    expect(signalsEmittedBy('MeshInstance', { physics: { ...DYNAMIC, enabled: false } })).toEqual(expect.arrayContaining([...PHYSICS_SIGNALS])); // bloco guardado, mesmo desligado
    expect(signalsEmittedBy('MeshInstance', {})).not.toContain('body_entered');
    expect(signalsEmittedBy('Spatial')).toEqual(getNodeMetadata('Spatial').availableSignals); // sem bloco: só o que o tipo declara
    expect(new Set(signalsEmittedBy('Spatial', { physics: STATIC })).size).toBe(signalsEmittedBy('Spatial', { physics: STATIC }).length); // sem duplicata
  });
});

describe('assinaturas descartáveis (AIS-48 · emenda 3.1)', () => {
  const scene = () => sceneWith(FLOOR, node('crate', [0, 2, 0], DYNAMIC));

  it('session.onPhysicsEvent → unsubscribe; o EngineApi repassa a mesma porta', () => {
    const { session } = open(scene());
    const api = createEngineApi(session);
    const got: PhysicsEvent[] = [];
    const off = api.onPhysicsEvent('collisionEnter', (e) => got.push(e));
    expect(typeof off).toBe('function');
    run(session, 2);
    expect(got.length).toBeGreaterThan(0);
    expect(got.every((e) => e.name === 'collisionEnter' && typeof e.selfId === 'string' && typeof e.otherId === 'string')).toBe(true);
    off();
    off();
    const n = got.length;
    session.physics!.teleport('crate', { x: 0, y: 3, z: 0 });
    run(session, 2);
    expect(got.length).toBe(n);
  });

  it('Restart Scene, troca de cena e Stop cancelam TODAS as inscrições (nenhuma sobrevive à cena)', async () => {
    const { session } = open(scene());
    let n = 0;
    session.onPhysicsEvent('*', () => n++);
    run(session, 1);
    expect(n).toBeGreaterThan(0);
    expect(session.restartScene()).toBe(true);
    const afterRestart = n;
    run(session, 2); // o mundo novo bate no chão de novo: a inscrição antiga NÃO recebe
    expect(n).toBe(afterRestart);

    let m = 0;
    session.onPhysicsEvent('*', () => m++);
    await session.changeScene(createRuntimeSnapshot(scene()));
    run(session, 2);
    expect(m).toBe(0);

    let z = 0;
    session.onPhysicsEvent('*', () => z++);
    session.dispose();
    expect(z).toBe(0);
  });

  it('inscrição feita por um Behavior é cancelada no detach e no Restart Behavior', () => {
    const received: string[] = [];
    let offs = 0;
    const probe: BehaviorRuntimeModule = {
      create(): BehaviorRuntime {
        return {
          attach(ctx) {
            const off = ctx.onPhysicsEvent('collisionEnter', (e) => received.push(e.selfId));
            const wrapped = () => {
              offs++;
              off();
            };
            void wrapped;
          },
        };
      },
    };
    const { session } = open(sceneWith(FLOOR, node('crate', [0, 2, 0], DYNAMIC, {}, { behaviors: [behavior('probe', [], 'probe1')] })), { behaviorCatalog: { get: (t) => (t === 'probe' ? probe : undefined) } });
    run(session, 2);
    expect(received).toContain('crate');
    const before = received.length;
    session.restartBehavior('crate', 'probe1'); // recria o Behavior: a inscrição ANTIGA é cancelada e uma nova é feita
    session.physics!.teleport('crate', { x: 0, y: 3, z: 0 });
    run(session, 2);
    // uma só inscrição ativa: cada colisão chega UMA vez (se a antiga sobrevivesse, chegaria duplicada)
    const newOnes = received.slice(before);
    expect(newOnes.length).toBeGreaterThan(0);
    expect(newOnes.length).toBeLessThanOrEqual(2);
    session.dispose();
    expect(offs).toBe(0); // (o probe não guarda o disposer: o cancelamento é do host)
  });

  it('assinante com defeito vira diagnóstico efêmero e não derruba a sessão', () => {
    const { session } = open(scene());
    session.onPhysicsEvent('*', () => {
      throw new Error('quebrou');
    });
    expect(() => run(session, 2)).not.toThrow();
    expect(session.status).toBe('running');
  });
});
