import * as THREE from 'three';
import type { RuntimeInstance, RuntimeScene } from './RuntimeScene';

/**
 * AIS-44e — SpawnPresenter: faz os objetos criados DURANTE o jogo (`spawnPrefab`, AIS-29g) aparecerem no Play.
 *
 * O Play desenha os objetos de EDIÇÃO da viewport (AIS-44c, "opção A") e `mirrorSessionToObjects` só alcança ids autorais; um spawn tem
 * ids novos, então simulava e colidia, mas ficava invisível. Aqui a `rootObject` da `RuntimeScene` entra na cena Three da viewport e
 * os objetos que NÃO são de spawn (a cópia viva da cena inicial, já desenhada pelo espelho) saem da câmera pela CAMADA do Three.js:
 *
 *   - `layers` NÃO é herdada (ao contrário de `visible`): um spawn pendurado num pai escondido continua desenhado;
 *   - a hierarquia do runtime fica intacta (nada é reparentado), então o spawn acompanha o pai pela matriz mundial e a física continua
 *     convertendo mundo → local pela cadeia de pais;
 *   - luzes, câmeras e terreno do runtime não duplicam a iluminação nem o desenho (a camada vale para tudo, inclusive sombras).
 *
 * Sem React, sem escrita no authoring. `unmount()` devolve a cena Three ao estado anterior ao Play.
 */

/** Camada onde ficam os objetos de runtime que o espelho da viewport já desenha. A câmera da viewport só enxerga a camada 0. */
export const HIDDEN_RUNTIME_LAYER = 31;

/** Tipos que a `RuntimeObjectFactory` não sabe desenhar: o nó simula, mas não aparece (aviso `spawn.node_not_presentable`). */
export const NON_PRESENTABLE_SPAWN_TYPES: ReadonlySet<string> = new Set(['Billboard']);

export class SpawnPresenter {
  private scene: RuntimeScene | null = null;
  private parent: THREE.Object3D | null = null;
  private lastRevision = -1;

  /** Cena de runtime atualmente montada (`null` = nada montado). */
  get mounted(): RuntimeScene | null {
    return this.scene;
  }

  /**
   * Monta a cena de runtime na cena Three. Idempotente para a mesma cena; trocar de cena (restart, `change_scene`) desmonta a anterior.
   * `showAll`: desenha a cena viva inteira (usado quando ela difere da cena aberta no editor).
   * Devolve `true` se montou agora.
   */
  mount(scene: RuntimeScene, parent: THREE.Object3D, showAll = false): boolean {
    if (this.scene === scene && this.parent === parent && scene.rootObject.parent === parent) return false;
    this.unmount();
    // `showAll` (AIS-73, Change Scene em jogo): a cena viva NÃO é a desenhada pelo espelho do editor, então tudo dela é desenhado
    if (!showAll) this.hideNonSpawned(scene);
    this.scene = scene;
    this.parent = parent;
    this.lastRevision = -1;
    parent.add(scene.rootObject);
    return true;
  }

  /** Tira a cena de runtime da cena Three (idempotente). Os objetos em si são liberados pela `RuntimeScene`/fábrica no Stop. */
  unmount(): void {
    if (this.scene && this.scene.rootObject.parent === this.parent) this.parent?.remove(this.scene.rootObject);
    this.scene = null;
    this.parent = null;
    this.lastRevision = -1;
  }

  /** Há spawns novos ou destruídos desde a última chamada? (barato: um contador, nunca a cena inteira por quadro) */
  takeChanged(): boolean {
    const revision = this.scene?.spawnRevision ?? -1;
    if (revision === this.lastRevision) return false;
    this.lastRevision = revision;
    return true;
  }

  /** Instâncias de spawn vivas que têm objeto (para quem precisa montar algo por cima, ex.: partículas). */
  spawnedInstances(): RuntimeInstance[] {
    return this.scene?.getAllInstances().filter((i) => i.origin?.kind === 'spawn' && i.object) ?? [];
  }

  /** Manda para a camada escondida tudo que NÃO é de spawn (percorre a rootObject uma vez e pula as subárvores de spawn). */
  private hideNonSpawned(scene: RuntimeScene): void {
    const spawned = new Set<THREE.Object3D>();
    for (const instance of scene.getAllInstances()) if (instance.origin && instance.object) spawned.add(instance.object);
    const mark = (o: THREE.Object3D) => {
      if (spawned.has(o)) return;
      o.layers.set(HIDDEN_RUNTIME_LAYER);
      for (const child of o.children) mark(child);
    };
    mark(scene.rootObject);
  }
}
