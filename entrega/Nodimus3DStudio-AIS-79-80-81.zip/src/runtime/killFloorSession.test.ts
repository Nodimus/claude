import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance } from '../types/visualLogic';
import type { BehaviorRuntimeModule } from '../logic/types';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import type { PhysicsBridge } from '../core/physics/PhysicsBridge';
import { ensureRapier } from '../core/physics/rapierInit';
import { signalsEmittedBy } from '../core/signals/emittedSignals';
import { RuntimeSession, type NodeSignalEvent } from './RuntimeSession';

/**
 * AIS-49 — Kill Floor DENTRO da sessão: o sinal `fell_out_of_world` (barramento de sinais do AIS-48) e o evento `killFloor` chegam antes do
 * descarte; depois a instância é destruída; a lógica de contato não confunde o aviso com Enter/Exit; sono visível pela ponte.
 */

beforeAll(async () => {
  await ensureRapier();
});

const node = (id: string, y: number, physics: Record<string, any> | undefined, nodeExtra: Record<string, any> = {}): GameNode =>
  ({ id, name: id, type: 'MeshInstance', parentId: null, childrenIds: [], visible: true, locked: false, properties: { meshType: 'CubeMesh', position: { x: 0, y, z: 0 }, ...(physics ? { physics } : {}) }, ...nodeExtra }) as unknown as GameNode;
function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  return { ...scene, nodes };
}
const fakeInput = () => ({
  isActionPressed: () => false,
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: () => 0,
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
});
const DYNAMIC = { enabled: true, bodyMode: 'dynamic', shape: 'auto' };
const STATIC = { enabled: true, bodyMode: 'static', shape: 'auto' };
const run = (s: RuntimeSession, frames: number) => {
  for (let i = 0; i < frames; i++) s.step(1 / 60);
};
const behavior = (id: string, type = 'probe'): BehaviorInstance => ({ id, name: `B_${id}`, behaviorType: type, enabled: true, properties: {}, rules: [] });

describe('Kill Floor na sessão (AIS-49-C03)', () => {
  it('sinal fell_out_of_world e evento killFloor chegam com o corpo ainda vivo; depois a instância é destruída', () => {
    const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(sceneWith(node('rock', 0, DYNAMIC))), input: fakeInput() });
    const signals: NodeSignalEvent[] = [];
    const alive: boolean[] = [];
    session.onNodeSignal((s) => {
      signals.push(s);
      alive.push(!!session.currentScene?.getInstance('rock') && !!session.physics?.has('rock'));
    });
    session.start();
    for (let i = 0; i < 60 * 8 && session.currentScene?.getInstance('rock'); i++) session.step(1 / 60);
    const fell = signals.filter((s) => s.signal === 'fell_out_of_world');
    expect(fell).toHaveLength(1);
    expect(fell[0].sourceNodeId).toBe('rock');
    expect(fell[0].args[0] as number).toBeLessThan(-50);
    expect(alive).toEqual([true]); // reação possível: instância e corpo ainda existiam
    expect(session.currentScene?.getInstance('rock')).toBeUndefined();
    expect(session.physics?.has('rock')).toBe(false);
    session.dispose();
  });

  it('um Behavior reage ao aviso via ctx.onPhysicsEvent (resgate por teleporte: nada é destruído)', () => {
    // ctx.physics é null em attach/onPlayStart (o mundo entra depois): o Behavior guarda a ponte no primeiro onUpdate
    let bridge: PhysicsBridge | null = null;
    const rescue: BehaviorRuntimeModule = {
      create: () => ({
        onPlayStart(ctx) {
          ctx.onPhysicsEvent('killFloor', (e) => bridge?.teleport(e.selfId, { x: 0, y: 4, z: 0 }));
        },
        onUpdate(ctx) {
          bridge = ctx.physics;
        },
      }),
    };
    const session = new RuntimeSession({
      snapshot: createRuntimeSnapshot(sceneWith(node('hero', 0, DYNAMIC, { behaviors: [behavior('r1')] }))),
      input: fakeInput(),
      behaviorCatalog: { get: (t) => (t === 'probe' ? rescue : undefined) },
    });
    session.start();
    run(session, 60 * 6);
    expect(session.currentScene?.getInstance('hero')).toBeDefined();
    expect(session.physics?.has('hero')).toBe(true);
    session.dispose();
  });

  it('o aviso NÃO vira Trigger de contato (on_collision/on_trigger exit) na lógica', () => {
    const rules = { id: 'r1', eventType: 'on_trigger_exit', parameters: {}, conditions: [], actions: [{ id: 'a1', type: 'add_to_variable', parameters: { variable: 'exits', amount: 1 } }] };
    const b: BehaviorInstance = { id: 'b1', name: 'B', behaviorType: 'custom_rules', enabled: true, properties: {}, rules: [rules] as any };
    const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(sceneWith(node('rock', 0, DYNAMIC, { behaviors: [b] }))), input: fakeInput(), globals: [{ name: 'exits', type: 'number', value: 0 }] });
    session.start();
    run(session, 60 * 8);
    expect(session.variables!.getVariable('global', 'exits')).toBe(0);
    session.dispose();
  });

  it('o Inspector lista fell_out_of_world só em nós com Colisão', () => {
    expect(signalsEmittedBy('Spatial', { physics: DYNAMIC })).toContain('fell_out_of_world');
    expect(signalsEmittedBy('Spatial', {})).not.toContain('fell_out_of_world');
  });
});

describe('sono dentro da sessão (AIS-49-C01)', () => {
  it('a caixa pousada dorme pela ponte e a contagem de ativos cai', () => {
    const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(sceneWith(node('floor', -0.5, STATIC), node('crate', 0.5, DYNAMIC))), input: fakeInput() });
    session.start();
    run(session, 60 * 8);
    expect(session.physics!.isSleeping('crate')).toBe(true);
    expect(session.physics!.activeBodyCount).toBe(0);
    expect(session.physics!.sleepingBodyCount).toBe(1);
    session.dispose();
  });
});
