import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { RuntimeSession } from './RuntimeSession';

/** AIS-59 — Action `tween_to` sobre o `Tweener` da sessão: nós vivos, UI, substituição, encadeamento por sinal, pausa e Stop. */

let seq = 0;
const act = (type: string, parameters: Record<string, unknown> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[], parameters: Record<string, unknown> = {}): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters, conditions: [], actions });
const behavior = (rules: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'B', behaviorType: 'custom_rules', enabled: true, properties: {}, rules });
const node = (id: string, type: string, extra: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type, parentId: null, childrenIds: [], visible: true, locked: false, properties: {}, ...extra }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes = { ...scene.nodes };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  nodes[root.id] = { ...root, childrenIds: [...root.childrenIds, ...extra.map((n) => n.id)] };
  return { ...scene, nodes };
}

const fakeInput = () => ({
  isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0,
  isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false,
});

const tweenOnStart = (id: string, params: Record<string, unknown>, extraActions: LogicAction[] = []): GameNode =>
  node(id, 'Spatial', { behaviors: [behavior([rule('on_start', [act('tween_to', params), ...extraActions])])] });

function open(scene: SceneData) {
  const diagnostics = new DiagnosticService();
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), mode: 'scene', input: fakeInput(), diagnostics });
  session.start();
  return { session, diagnostics };
}

const pos = (s: RuntimeSession, id: string) => s.scene.getInstance(id)!.transform.position;

describe('tween_to: posição, rotação, escala (AIS-59)', () => {
  it('posição absoluta com curva: avança com o tempo de jogo, atualiza o objeto vivo e termina exato', () => {
    const { session } = open(sceneWith(tweenOnStart('a', { property: 'position', x: 10, y: 0, z: 0, duration: 2, easing: 'EaseInQuad' })));
    session.step(0.016); // on_start dispara e o tween nasce
    session.step(1);
    const mid = pos(session, 'a')[0];
    expect(mid).toBeGreaterThan(0);
    expect(mid).toBeLessThan(5); // EaseInQuad: menos que o linear (5)
    expect(session.scene.getInstance('a')!.object!.position.x).toBeCloseTo(mid, 6);
    session.step(2);
    expect(pos(session, 'a')[0]).toBe(10);
    expect(session.scene.getInstance('a')!.object!.position.x).toBe(10);
  });

  it('relativo soma ao valor atual; rotação em graus e escala', () => {
    const scene = sceneWith(
      node('p', 'Spatial', { transform: { position: [1, 2, 3], rotation: [0, 0, 0], scale: [1, 1, 1] } as never, behaviors: [behavior([rule('on_start', [
        act('tween_to', { property: 'position', x: 4, y: 0, z: 0, relative: true, duration: 1 }),
        act('tween_to', { property: 'rotation', x: 0, y: 90, z: 0, duration: 1 }),
        act('tween_to', { property: 'scale', x: 2, y: 2, z: 2, duration: 1 }),
      ])])] }),
    );
    const { session } = open(scene);
    session.step(0.016);
    session.step(5);
    const inst = session.scene.getInstance('p')!;
    expect(inst.transform.position).toEqual([5, 2, 3]);
    expect(inst.transform.rotation).toEqual([0, 90, 0]);
    expect(inst.transform.scale).toEqual([2, 2, 2]);
    expect(inst.object!.rotation.y).toBeCloseTo(Math.PI / 2, 6);
  });

  it('um novo tween da mesma propriedade substitui o anterior', () => {
    const { session } = open(sceneWith(tweenOnStart('a', { property: 'position', x: 100, duration: 10 }, [])));
    session.step(0.016);
    session.step(1);
    const runner = session.runner!;
    runner.invokeAction('tween_to', { target: '', property: 'position', x: 0, y: 0, z: 0, duration: 0.5, easing: 'Linear', loop: 'once', relative: false, delay: 0, color: '', opacity: 1, onCompleteSignal: '' }, session.scene.getInstance('a')!);
    session.step(1); // o tween novo (0,5 s) terminou; o antigo (10 s) não pode mais puxar para 100
    expect(pos(session, 'a')[0]).toBe(0);
    session.step(5);
    expect(pos(session, 'a')[0]).toBe(0);
  });

  it('pausa não avança; Stop descarta os tweens', () => {
    const { session } = open(sceneWith(tweenOnStart('a', { property: 'position', x: 10, duration: 1 })));
    session.step(0.016);
    session.step(0.5);
    const at = pos(session, 'a')[0];
    session.pause();
    session.step(3);
    expect(pos(session, 'a')[0]).toBe(at);
    session.resume();
    session.stop();
    expect(() => session.step(1)).not.toThrow();
  });
});

describe('tween_to: cor, opacidade e UI (AIS-59)', () => {
  const mesh = (id: string, params: Record<string, unknown>) =>
    node(id, 'MeshInstance', { behaviors: [behavior([rule('on_start', [act('tween_to', params)])])] });

  it('cor do material e opacidade do objeto vivo (translúcido durante o tween)', () => {
    const { session } = open(sceneWith(mesh('m', { property: 'color', color: '#0000ff', duration: 1 }), mesh('o', { property: 'opacity', opacity: 0.2, duration: 1 })));
    session.step(0.016);
    session.step(0.5);
    const find = (id: string): THREE.MeshStandardMaterial => {
      let found: THREE.MeshStandardMaterial | null = null;
      session.scene.getInstance(id)!.object!.traverse((c) => { const m = (c as THREE.Mesh).material; if (!found && m) found = (Array.isArray(m) ? m[0] : m) as THREE.MeshStandardMaterial; });
      return found!;
    };
    expect(find('m').color.b).toBeGreaterThan(0.5); // indo para o azul
    expect(find('o').transparent).toBe(true);
    expect(find('o').opacity).toBeLessThan(1);
    session.step(2);
    expect(find('m').color.getHexString()).toBe('0000ff');
    expect(find('o').opacity).toBeCloseTo(0.2, 6);
  });

  it('nó de UI: posição pelos offsets, opacidade em alpha e cor em color, com o HUD marcado como alterado', () => {
    const ui = node('hud', 'Overlay2D', {
      properties: { posX: 0, posY: 0, alpha: 1, color: { r: 1, g: 0, b: 0, a: 1 } },
      behaviors: [behavior([rule('on_start', [
        act('tween_to', { property: 'position', x: 100, y: 40, duration: 1 }),
        act('tween_to', { property: 'opacity', opacity: 0, duration: 1 }),
        act('tween_to', { property: 'color', color: '#00ff00', duration: 1 }),
      ])])],
    });
    const { session } = open(sceneWith(ui));
    session.step(0.016);
    const revision = session.runner!.uiRevision;
    session.step(0.5);
    expect(session.runner!.uiRevision).toBeGreaterThan(revision);
    session.step(2);
    const p = session.scene.getInstance('hud')!.properties;
    expect([p.posX, p.posY, p.alpha]).toEqual([100, 40, 0]);
    expect(p.color).toEqual({ r: 0, g: 1, b: 0, a: 1 }); // alfa da cor preservado
  });

  it('erros explícitos no diagnóstico: UI não tem rotação, nó sem material, cor inválida', () => {
    const { diagnostics, session } = open(sceneWith(
      node('u', 'Overlay2D', { behaviors: [behavior([rule('on_start', [act('tween_to', { property: 'rotation', y: 90, duration: 1 })])])] }),
      node('s', 'Spatial', { behaviors: [behavior([rule('on_start', [act('tween_to', { property: 'color', color: '#ff0000', duration: 1 })])])] }),
    ));
    session.step(0.016);
    const msgs = diagnostics.list().map((d) => d.message).join('\n');
    expect(msgs).toMatch(/nó de UI/);
    expect(msgs).toMatch(/não tem cor para animar/);
  });

  it('corpo físico character recusa tween de posição (a pose sai do controlador)', () => {
    const body = node('b', 'MeshInstance', { properties: { physics: { enabled: true, bodyMode: 'character', shape: 'auto' } }, behaviors: [behavior([rule('on_start', [act('tween_to', { property: 'position', x: 5, duration: 1 })])])] });
    const { diagnostics, session } = open(sceneWith(body));
    session.step(0.016);
    expect(diagnostics.list().map((d) => d.message).join('\n')).toMatch(/corpo físico/);
  });
});

describe('tween_to: encadeamento e sinal ao terminar (AIS-59)', () => {
  it('onCompleteSignal emite o sinal global ao terminar e o on_signal inicia o passo seguinte (corrente na lógica visual)', () => {
    const a = node('a', 'Spatial', { behaviors: [behavior([
      rule('on_start', [act('tween_to', { property: 'position', x: 10, duration: 1, onCompleteSignal: 'step1_done' })]),
      rule('on_signal', [act('tween_to', { property: 'position', x: 10, y: 5, duration: 1 })], { signal: 'step1_done' }),
    ])] });
    const { session } = open(sceneWith(a));
    session.step(0.016);
    session.step(1.2); // o 1º passo termina no fim deste quadro e enfileira o sinal
    expect(pos(session, 'a')[0]).toBe(10);
    session.step(0.016); // o runner entrega o sinal no quadro seguinte e o on_signal inicia o 2º passo
    expect(session.signalBus.getHistory().filter((e) => e.signal === 'step1_done')).toHaveLength(1);
    session.step(2);
    expect(pos(session, 'a')).toEqual([10, 5, 0]);
  });

  it('delay e loop pingpong no nó: oscila e nunca termina; o sinal de término só vale para tweens finitos', () => {
    const { session } = open(sceneWith(tweenOnStart('a', { property: 'position', x: 4, duration: 1, delay: 0.5, loop: 'pingpong', onCompleteSignal: 'nunca' })));
    session.step(0.016);
    session.step(0.4);
    expect(pos(session, 'a')[0]).toBe(0); // ainda no delay
    session.step(1.1); // 1,516 s − 0,5 s de delay = 1,016 s: já voltando (~0 de novo)
    session.step(10);
    expect(session.signalBus.getHistory().some((e) => e.signal === 'nunca')).toBe(false);
  });
});
