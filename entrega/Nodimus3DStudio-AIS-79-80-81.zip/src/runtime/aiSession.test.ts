import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { ensureRapier } from '../core/physics/rapierInit';
import { LogicRegistry } from '../logic/registry';
import { RuntimeSession } from './RuntimeSession';
import type { LogicLogEntry } from './logicRunner';

/** AIS-71 — IA no Play (Rapier real): percepção → Chase → Attack → `shoot` → `damage_taken` → `on_actor_die`, Flee, patrulha, diagnósticos. */

beforeAll(async () => {
  await ensureRapier();
});

const P = (x: number, y = 0, z = 0) => ({ x, y, z });
const node = (id: string, type: string, at: [number, number, number], props: Record<string, unknown> = {}, over: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type, parentId: null, childrenIds: [], visible: true, locked: false, properties: { position: { x: at[0], y: at[1], z: at[2] }, ...props }, ...over }) as unknown as GameNode;
const input = { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never;

const log = (text: string) => ({ id: `a_${text}`, type: 'print_log', parameters: { text } });

/** AI State Machine com os ganchos ligados a um `print_log` (`ST:<estado>`, `ATTACK`) e, no ataque, às Actions pedidas. */
function aiBehavior(props: Record<string, unknown>, attackActions: unknown[] = [log('ATTACK')]): BehaviorInstance {
  const b = (LogicRegistry.getBehavior('ai_state_machine') as any).create({ targetNodeId: 'npc' }) as BehaviorInstance;
  b.properties = { ...b.properties, ...props };
  b.rules = b.rules.map((r) => ({ ...r, actions: r.eventType === 'on_ai_state_changed' ? [log(`ST:${r.parameters.state}`)] : (attackActions as never[]) }));
  return b;
}
function actorBehavior(nodeId: string, props: Record<string, unknown> = {}): BehaviorInstance {
  const b = (LogicRegistry.getBehavior('game_actor_with_health') as any).create({ targetNodeId: nodeId }) as BehaviorInstance;
  b.properties = { ...b.properties, ...props };
  b.rules = b.rules.map((r) => ({ ...r, actions: [log(r.eventType === 'on_actor_hit' ? `HIT:${nodeId}` : `DIE:${nodeId}`)] }));
  return b;
}

const FLOOR = node('floor', 'MeshInstance', [0, -0.5, 0], { meshType: 'CubeMesh', scale: { x: 80, y: 1, z: 80 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } });
const KIN = { enabled: true, bodyMode: 'kinematic', shape: 'auto' };
const npc = (props: Record<string, unknown>, at: [number, number, number] = [0, 1, 0], physics: unknown = KIN, extra: BehaviorInstance[] = [], attackActions?: unknown[], variables?: Record<string, unknown>) =>
  node('npc', 'MeshInstance', at, { meshType: 'CubeMesh', physics }, { behaviors: [aiBehavior(props, attackActions), ...extra], ...(variables ? { variables } : {}) } as never);
/** Move um corpo cinemático: a pose do runtime é a autoridade (um `teleport` na ponte seria desfeito no quadro seguinte). */
const moveNode = (s: RuntimeSession, id: string, at: [number, number, number]) => {
  const instance = s.scene.getInstance(id)!;
  instance.transform.position = at;
  s.scene.applyInstanceTransform(instance);
};
const player = (at: [number, number, number], vars: Record<string, unknown> = { health: 100 }, tags = ['jogador']) =>
  node('jogador', 'MeshInstance', at, { meshType: 'CubeMesh', physics: KIN }, { tags, variables: vars, behaviors: [actorBehavior('jogador')] } as never);

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  return { ...scene, nodes } as unknown as SceneData;
}
function play(scene: SceneData, options: { random?: () => number } = {}) {
  const diagnostics = new DiagnosticService();
  const logs: LogicLogEntry[] = [];
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input, diagnostics, onLog: (e) => logs.push(e), random: options.random });
  session.start();
  const count = (text: string) => logs.filter((l) => l.message.includes(text)).length;
  const states = () => logs.filter((l) => l.message.includes('ST:')).map((l) => l.message.match(/ST:(\w+)/)![1]);
  return { session, diagnostics, logs, count, states, codes: () => diagnostics.list({ ephemeral: true }).map((d) => d.code) };
}
const run = (s: RuntimeSession, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) s.step(1 / 60);
};
const pos = (s: RuntimeSession, id = 'npc') => s.getSimulatedTransform(id)!.position;
const health = (s: RuntimeSession, id = 'jogador') => s.variables?.getVariable('local', 'health', id);

// targetTags 'jogador': com a lista vazia QUALQUER GameNode (até o piso) é alvo — comportamento especificado, testado à parte
const FAST = { perceptionIntervalMs: 50, idleTimeMs: 0, movementSpeed: 6, attackRange: 2, attackCooldownMs: 500, targetTags: 'jogador' };

describe('Idle → Chase → Attack → shoot → morte (AIS-71-C01, C03, C13)', () => {
  it('percebe o alvo em raio, persegue, ataca em alcance, o dano chega pelo núcleo de armas e on_actor_die dispara UMA vez', () => {
    const shoot = { id: 'a_shoot', type: 'shoot', parameters: { bullet: '', damage: 40, damageVariable: 'health', fireMode: 'physical', target: '' } };
    const t = play(sceneWith(FLOOR, npc({ ...FAST, perceptionRadius: 12, loseRadius: 16, targetTags: 'jogador' }, [0, 1, 0], KIN, [], [shoot]), player([8, 1, 0])));
    run(t.session, 0.4);
    expect(t.states()).toContain('Chase');
    run(t.session, 2);
    expect(t.states().slice(0, 2)).toEqual(['Chase', 'Attack']); // Idle → Chase (percebeu) → Attack (alcance)
    expect(Math.abs(pos(t.session)[0] - 8)).toBeLessThan(2.6); // chegou ao alcance de ataque
    // 100 → 60 → 20 → 0: três ataques; o terceiro mata
    run(t.session, 2.2);
    expect(health(t.session)).toBe(0);
    expect(t.count('HIT:jogador')).toBe(3);
    expect(t.count('DIE:jogador')).toBe(1);
    // morto: o alvo some da percepção, a IA volta a Idle e nenhum dano posterior repete on_actor_die
    run(t.session, 3);
    expect(t.count('DIE:jogador')).toBe(1);
    expect(t.session.ai!.isDead('jogador')).toBe(true);
    expect(t.session.scene.getInstance('jogador')).toBeDefined(); // nada é destruído automaticamente
    expect(t.states().at(-1)).toBe('Idle');
    t.session.dispose();
  });

  it('sinal ai_state_changed {from,to} sai pelo SignalBus', () => {
    const t = play(sceneWith(FLOOR, npc({ ...FAST, perceptionRadius: 12, targetTags: 'jogador' }), player([8, 1, 0])));
    run(t.session, 1);
    const emissions = t.session.signalBus.getHistory().filter((e) => e.signal === 'ai_state_changed');
    expect(emissions.length).toBeGreaterThanOrEqual(1);
    expect(emissions[0]).toMatchObject({ source: 'npc', args: [{ from: 'Idle', to: expect.stringMatching(/Chase|Attack/) }] });
    t.session.dispose();
  });

  it('shoot com Bullet vazio = dano direto; sem alvo = falha EXPLÍCITA (nunca silêncio)', () => {
    const noTarget = { id: 'a_shoot', type: 'shoot', parameters: { bullet: '', damage: 5, target: '' } };
    const t = play(sceneWith(FLOOR, npc({ ...FAST, perceptionRadius: 3, idleTimeMs: 9999999 }, [0, 1, 0], KIN, [], [noTarget])));
    const behaviorId = (t.session.snapshot.nodes.npc.behaviors as BehaviorInstance[])[0].id;
    t.session.runner!.dispatchHook('npc', behaviorId, 'on_ai_attack', 'manual');
    run(t.session, 0.2);
    expect(t.logs.some((l) => l.level === 'error' && l.code === 'shoot.no_target')).toBe(true);
    expect(t.codes()).toContain('shoot.no_target');
    t.session.dispose();
  });

  it('shoot com alvo explícito aplica o dano mesmo sem percepção', () => {
    const explicit = { id: 'a_shoot', type: 'shoot', parameters: { bullet: '', damage: 7, target: 'jogador' } };
    const t = play(sceneWith(FLOOR, npc({ ...FAST, perceptionRadius: 3, idleTimeMs: 9999999 }, [0, 1, 0], KIN, [], [explicit]), player([30, 1, 0])));
    const behaviorId = (t.session.snapshot.nodes.npc.behaviors as BehaviorInstance[])[0].id;
    t.session.runner!.dispatchHook('npc', behaviorId, 'on_ai_attack', 'manual');
    run(t.session, 0.2);
    expect(health(t.session)).toBe(93);
    expect(t.count('HIT:jogador')).toBe(1);
    t.session.dispose();
  });
});

describe('percepção e alvo (AIS-71-C08, C09)', () => {
  it('Tags filtram; fora do raio não percebe; sem alvo nenhum erro; alvo excluído em Play não gera exceção', () => {
    const decoy = node('isca', 'MeshInstance', [3, 1, 0], { meshType: 'CubeMesh', physics: KIN }, { tags: ['outro'] } as never);
    const t = play(sceneWith(FLOOR, npc({ ...FAST, perceptionRadius: 12, targetTags: 'jogador', attackRange: 0.5 }), decoy, player([8, 1, 0])));
    run(t.session, 0.6);
    expect(t.session.ai!.currentTarget('npc')).toBe('jogador'); // a isca mais perto não tem a Tag
    // exclui o alvo no meio do jogo
    t.session.scene.destroyInstance(t.session.scene.getInstance('jogador')!.id);
    expect(() => run(t.session, 0.6)).not.toThrow();
    expect(t.session.ai!.currentTarget('npc')).toBeNull();
    expect(t.codes().filter((c) => c.startsWith('ai.')).length).toBe(0);
    t.session.dispose();
    const far = play(sceneWith(FLOOR, npc({ ...FAST, perceptionRadius: 5, targetTags: 'jogador' }), player([20, 1, 0])));
    run(far.session, 1);
    expect(far.states()).not.toContain('Chase');
    expect(far.codes()).toEqual([]);
    far.session.dispose();
  });

  it('targetTags vazio = qualquer GameNode exceto ele (e seus descendentes)', () => {
    const child = node('capacete', 'MeshInstance', [0.3, 1.3, 0], { meshType: 'CubeMesh', physics: KIN });
    const scene = sceneWith(FLOOR, npc({ ...FAST, targetTags: '', perceptionRadius: 6, attackRange: 0.2 }), child);
    scene.nodes.capacete = { ...scene.nodes.capacete, parentId: 'npc' } as GameNode;
    scene.nodes.npc = { ...scene.nodes.npc, childrenIds: ['capacete'] } as GameNode;
    scene.nodes[scene.rootNodeId] = { ...scene.nodes[scene.rootNodeId], childrenIds: ['floor', 'npc'] } as GameNode;
    const t = play(scene);
    run(t.session, 0.8);
    expect(t.session.ai!.currentTarget('npc')).not.toBe('capacete');
    expect(t.session.ai!.currentTarget('npc')).not.toBe('npc');
    t.session.dispose();
  });

  it('histerese: perde o alvo só além de loseRadius', () => {
    const t = play(sceneWith(FLOOR, npc({ ...FAST, movementSpeed: 0, perceptionRadius: 6, loseRadius: 12, targetTags: 'jogador' }), player([5, 1, 0])));
    run(t.session, 0.5);
    expect(t.session.ai!.currentTarget('npc')).toBe('jogador');
    moveNode(t.session, 'jogador', [9, 1, 0]); // entre perception e lose: mantém
    run(t.session, 0.5);
    expect(t.session.ai!.currentTarget('npc')).toBe('jogador');
    moveNode(t.session, 'jogador', [14, 1, 0]); // além de loseRadius: perde
    run(t.session, 0.5);
    expect(t.session.ai!.currentTarget('npc')).toBeNull();
    t.session.dispose();
  });
});

describe('Flee e vitais (AIS-71-C06 em sessão, C12)', () => {
  it('com vida <= fleeBelowHealth e alvo no alcance de ataque, entra em Flee (não Attack) e se afasta', () => {
    // a vida é variável Local DECLARADA no authoring (aqui: no próprio nó); o runtime nunca a cria
    const t = play(sceneWith(FLOOR, npc({ ...FAST, perceptionRadius: 12, fleeBelowHealth: 30, fleeDurationMs: 2000, healthVariable: 'health' }, [0, 1, 0], KIN, [actorBehavior('npc')], undefined, { health: 20 }), player([1.5, 1, 0])));
    run(t.session, 0.6);
    expect(t.states()).toContain('Flee');
    expect(t.states()).not.toContain('Attack');
    expect(Math.abs(pos(t.session)[0] - 1.5)).toBeGreaterThan(1.6); // afastou do alvo
    t.session.dispose();
  });

  it('o runtime nunca cria a variável de vida: sem declaração, aviso/diagnóstico e nada é criado', () => {
    const t = play(sceneWith(FLOOR, npc({ ...FAST, targetTags: 'jogador', fleeBelowHealth: 30 }, [0, 1, 0], KIN, [actorBehavior('npc')]), player([5, 1, 0])));
    run(t.session, 0.6);
    expect(t.session.variables!.getVariable('local', 'health', 'npc')).toBeUndefined();
    expect(t.codes()).toEqual(expect.arrayContaining(['ai.no_health', 'ai.actor_no_health']));
    // dano num alvo sem a variável: falha do núcleo de armas e NENHUMA criação
    const r = t.session.weapons!.damage({ sourceId: 'jogador', targetId: 'npc', amount: 5, variable: 'health' });
    expect(r).toMatchObject({ status: 'failed' });
    expect(t.session.variables!.getVariable('local', 'health', 'npc')).toBeUndefined();
    t.session.dispose();
  });

  it('dano em outra variável não é a vida do ator (sem hit/die)', () => {
    const t = play(sceneWith(FLOOR, node('alvo', 'MeshInstance', [0, 1, 0], { meshType: 'CubeMesh', physics: KIN }, { variables: { health: 10, escudo: 10 }, behaviors: [actorBehavior('alvo')] } as never)));
    t.session.weapons!.damage({ sourceId: 'x', targetId: 'alvo', amount: 10, variable: 'escudo' });
    run(t.session, 0.2);
    expect(t.count('HIT:alvo')).toBe(0);
    t.session.weapons!.damage({ sourceId: 'x', targetId: 'alvo', amount: 3, variable: 'health' });
    run(t.session, 0.2);
    expect(t.count('HIT:alvo')).toBe(1);
    expect(t.count('DIE:alvo')).toBe(0);
    t.session.dispose();
  });
});

describe('patrulha (AIS-71-C10)', () => {
  const route = (...pts: [number, number, number, number][]) => [
    node('rota', 'Spatial', [0, 0, 0]),
    ...pts.map(([x, y, z, wait], i) => node(`wp${i}`, 'Waypoint', [x, y, z], { waitMs: wait }, { parentId: 'rota' } as never)),
  ];
  const withRoute = (nodes: GameNode[]): SceneData => {
    const scene = sceneWith(FLOOR, ...nodes);
    const ids = nodes.filter((n) => n.id.startsWith('wp')).map((n) => n.id);
    for (const id of ids) scene.nodes[id] = { ...scene.nodes[id], parentId: 'rota' } as GameNode;
    scene.nodes.rota = { ...scene.nodes.rota, childrenIds: ids } as GameNode;
    scene.nodes[scene.rootNodeId] = { ...scene.nodes[scene.rootNodeId], childrenIds: scene.nodes[scene.rootNodeId].childrenIds.filter((id) => !id.startsWith('wp')) } as GameNode;
    return scene;
  };

  it('waypoints: percorre a rota de resolveRoute em ordem, esperando o waitMs de cada ponto, em loop', () => {
    const scene = withRoute([npc({ ...FAST, movementSpeed: 8, patrolSource: 'waypoints', patrolRoute: 'rota', patrolLoop: 'loop' }, [0, 1, 0]), ...route([6, 1, 0, 500], [6, 1, 6, 0], [0, 1, 6, 0])]);
    const t = play(scene);
    const visits: string[] = [];
    let waitedAtFirst = 0;
    for (let i = 0; i < 60 * 9; i++) {
      t.session.step(1 / 60);
      const [x, , z] = pos(t.session);
      const near = (px: number, pz: number) => Math.hypot(x - px, z - pz) < 0.2;
      const here = near(6, 0) ? 'wp0' : near(6, 6) ? 'wp1' : near(0, 6) ? 'wp2' : '';
      if (here && visits.at(-1) !== here) visits.push(here);
      if (here === 'wp0' && waitedAtFirst < 1000) waitedAtFirst++;
    }
    expect(visits.slice(0, 4)).toEqual(['wp0', 'wp1', 'wp2', 'wp0']); // ordem da rota e volta ao início (loop)
    expect(waitedAtFirst).toBeGreaterThanOrEqual(25); // ~0,5 s parado no primeiro ponto
    t.session.dispose();
  });

  it('waypoints em pingpong inverte nas pontas', () => {
    const scene = withRoute([npc({ ...FAST, movementSpeed: 10, patrolSource: 'waypoints', patrolRoute: 'rota', patrolLoop: 'pingpong' }, [0, 1, 0]), ...route([5, 1, 0, 0], [5, 1, 5, 0], [0, 1, 5, 0])]);
    const t = play(scene);
    const visits: string[] = [];
    for (let i = 0; i < 60 * 10; i++) {
      t.session.step(1 / 60);
      const [x, , z] = pos(t.session);
      const here = Math.hypot(x - 5, z) < 0.2 ? 'wp0' : Math.hypot(x - 5, z - 5) < 0.2 ? 'wp1' : Math.hypot(x, z - 5) < 0.2 ? 'wp2' : '';
      if (here && visits.at(-1) !== here) visits.push(here);
    }
    expect(visits.slice(0, 5)).toEqual(['wp0', 'wp1', 'wp2', 'wp1', 'wp0']);
    t.session.dispose();
  });

  it('rota inválida (contêiner vazio ou ausente) gera diagnóstico e o ator não patrulha em silêncio', () => {
    const empty = play(sceneWith(FLOOR, node('vazia', 'Spatial', [0, 0, 0]), npc({ ...FAST, patrolSource: 'waypoints', patrolRoute: 'vazia' })));
    run(empty.session, 0.5);
    expect(empty.codes()).toContain('route.empty');
    expect(empty.diagnostics.list({ ephemeral: true }).find((d) => d.code === 'route.empty')!.severity).toBe('error');
    expect(pos(empty.session)[0]).toBeCloseTo(0, 1);
    empty.session.dispose();
    const missing = play(sceneWith(FLOOR, npc({ ...FAST, patrolSource: 'waypoints', patrolRoute: 'fantasma' })));
    run(missing.session, 0.5);
    expect(missing.codes()).toContain('route.container_missing');
    const unset = play(sceneWith(FLOOR, npc({ ...FAST, patrolSource: 'waypoints', patrolRoute: '' })));
    run(unset.session, 0.5);
    expect(unset.codes()).toContain('ai.route_missing');
    missing.session.dispose();
    unset.session.dispose();
  });

  it('random_area: fica dentro do raio em torno da posição inicial e usa o sorteio da sessão', () => {
    let seed = 11;
    const random = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    const t = play(sceneWith(FLOOR, npc({ ...FAST, movementSpeed: 6, patrolSource: 'random_area', patrolRadius: 4, patrolWaitMs: 100 }, [10, 1, -5])), { random });
    let maxDist = 0;
    let moved = 0;
    for (let i = 0; i < 60 * 12; i++) {
      t.session.step(1 / 60);
      const [x, , z] = pos(t.session);
      maxDist = Math.max(maxDist, Math.hypot(x - 10, z + 5));
      moved = Math.max(moved, Math.hypot(x - 10, z + 5));
    }
    expect(maxDist).toBeLessThanOrEqual(4 + 0.3);
    expect(moved).toBeGreaterThan(0.5); // andou de verdade
    expect(t.codes()).toEqual([]);
    t.session.dispose();
  });

  it('path: compõe follow_a_path (sem movimento próprio); Path ausente/curto gera diagnóstico', () => {
    const path = node('caminho', 'Path', [0, 0, 0], { nodes: [P(0, 1, 0), P(10, 1, 0)], closed: false, tightness: 0.5 });
    const t = play(sceneWith(FLOOR, path, npc({ ...FAST, movementSpeed: 5, patrolSource: 'path', patrolPath: 'caminho' }, [0, 1, 0])));
    run(t.session, 1);
    expect(pos(t.session)[0]).toBeGreaterThan(3);
    let max = 0;
    for (let i = 0; i < 60 * 2; i++) {
      t.session.step(1 / 60);
      max = Math.max(max, pos(t.session)[0]);
    }
    expect(max).toBeGreaterThan(9.5); // chegou ao fim do caminho (depois, em `loop`, volta ao início como o follow_a_path)
    t.session.dispose();
    const bad = play(sceneWith(FLOOR, npc({ ...FAST, patrolSource: 'path', patrolPath: 'fantasma' })));
    run(bad.session, 0.5);
    expect(bad.codes()).toContain('follow_a_path.path_missing');
    const empty = play(sceneWith(FLOOR, npc({ ...FAST, patrolSource: 'path', patrolPath: '' })));
    run(empty.session, 0.5);
    expect(empty.codes()).toContain('ai.path_missing');
    bad.session.dispose();
    empty.session.dispose();
  });
});

describe('movimento e corpo (AIS-71-C11)', () => {
  it('character persegue pelo controlador; kinematic move; dynamic gera diagnóstico e não é conduzido', () => {
    const ch = play(sceneWith(FLOOR, npc({ ...FAST, targetTags: 'jogador', perceptionRadius: 14 }, [0, 1, 0], { enabled: true, bodyMode: 'character', shape: 'capsule' }), player([9, 1, 0])));
    run(ch.session, 1.2);
    expect(pos(ch.session)[0]).toBeGreaterThan(3);
    ch.session.dispose();

    const dyn = play(sceneWith(FLOOR, npc({ ...FAST, targetTags: 'jogador', perceptionRadius: 14 }, [0, 1, 0], { enabled: true, bodyMode: 'dynamic', shape: 'auto' }), player([9, 1, 0])));
    run(dyn.session, 1);
    expect(dyn.codes()).toContain('motion.dynamic_body');
    expect(Math.abs(pos(dyn.session)[0])).toBeLessThan(0.5);
    dyn.session.dispose();
  });

  it('sem Colisão no nó: diagnóstico explícito e a IA não age', () => {
    const t = play(sceneWith(FLOOR, node('npc', 'MeshInstance', [0, 1, 0], { meshType: 'CubeMesh' }, { behaviors: [aiBehavior({ ...FAST })] } as never), player([4, 1, 0])));
    run(t.session, 0.6);
    expect(t.codes()).toContain('ai.no_collider');
    expect(t.states()).toEqual([]);
    t.session.dispose();
  });

  it('canFly=false mantém a altura do nó (movimento no plano horizontal)', () => {
    const t = play(sceneWith(FLOOR, npc({ ...FAST, targetTags: 'jogador', perceptionRadius: 20, canFly: false }, [0, 1, 0]), player([8, 4, 0])));
    run(t.session, 1);
    expect(pos(t.session)[1]).toBeCloseTo(1, 1);
    expect(pos(t.session)[0]).toBeGreaterThan(2);
    t.session.dispose();
    const fly = play(sceneWith(FLOOR, npc({ ...FAST, targetTags: 'jogador', perceptionRadius: 20, canFly: true, attackRange: 0.2 }, [0, 1, 0]), player([8, 4, 0])));
    run(fly.session, 1.6);
    expect(pos(fly.session)[1]).toBeGreaterThan(2);
    fly.session.dispose();
  });
});

describe('timers e ciclo de vida (AIS-71-C07)', () => {
  it('Idle→Patrol só depois de idleTimeMs; Stop descarta o serviço (nenhuma inscrição sobra)', () => {
    const path = node('caminho', 'Path', [0, 0, 0], { nodes: [P(0, 1, 0), P(10, 1, 0)], closed: false, tightness: 0.5 });
    const t = play(sceneWith(FLOOR, path, npc({ ...FAST, idleTimeMs: 1000, patrolSource: 'path', patrolPath: 'caminho' }, [0, 1, 0]), player([40, 1, 0])));
    run(t.session, 0.8);
    expect(t.states()).toEqual([]); // ainda em Idle
    run(t.session, 0.4);
    expect(t.states()).toEqual(['Patrol']);
    expect(t.session.ai).not.toBeNull(); // AIS-78d: o cérebro vive em state.memory do Behavior; o registro de atores existe enquanto a cena vive
    t.session.dispose();
    expect(t.session.ai).toBeNull();
    expect(t.session.subscriptionCount()).toBe(0);
  });

  it('remover o Behavior do ator em Play cancela só a inscrição dele', () => {
    const t = play(sceneWith(FLOOR, player([0, 1, 0]), node('outro', 'MeshInstance', [3, 1, 0], { meshType: 'CubeMesh', physics: KIN }, { variables: { health: 5 }, behaviors: [actorBehavior('outro')] } as never)));
    const before = t.session.subscriptionCount({ kind: 'behavior' });
    expect(before).toBeGreaterThanOrEqual(2);
    const behaviorId = (t.session.snapshot.nodes.outro.behaviors as BehaviorInstance[])[0].id;
    expect(t.session.removeBehavior('outro', behaviorId)).toBe(true);
    expect(t.session.subscriptionCount({ kind: 'behavior' })).toBe(before - 1);
    t.session.weapons!.damage({ sourceId: 'x', targetId: 'outro', amount: 5, variable: 'health' });
    run(t.session, 0.2);
    expect(t.count('HIT:outro')).toBe(0); // sem inscrição, sem gancho
    t.session.dispose();
  });
});
