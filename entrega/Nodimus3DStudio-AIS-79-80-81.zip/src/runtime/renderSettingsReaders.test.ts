import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { SETTINGS_WITHOUT_READER, pendingReaderTooltip, readerOwnerOf } from '../core/projectSettingsReaders';
import { schemaDefaults } from '../core/projectSettingsForm';

const SRC = path.resolve(import.meta.dirname, '..');

function sourceFiles(dir: string): string[] {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) return sourceFiles(full);
    return /\.(ts|tsx)$/.test(e.name) && !/\.test\.(ts|tsx)$/.test(e.name) ? [full] : [];
  });
}

describe('única leitora das settings de renderização/janela (AIS-44d-C01)', () => {
  // quem EDITA/valida/grava as settings (formulário, modal, schema, padrões) não é "consumidor" do runtime
  const ALLOWED = [
    'runtime/renderSettings.ts',
    'core/projectSettingsForm.ts',
    'components/modals/ProjectSettingsModal.tsx',
    'core/defaultProject.ts',
    'core/projectStorage.ts',
    'core/projectStore/DiskProjectStore.ts', // AIS-30c: persistência em disco (lê o renderizador do project.json para a lista; não é consumidor de runtime)
  ];
  const READ = /(?:settings|\bs)\??\.(?:rendering|display)\??\.|\.rendering\.(?:shadowsEnabled|shadowQuality|clearColor|msaa|hdr|vsync)\b|\.display\.(?:width|height)\b/;

  it('nenhum consumidor lê project.settings.rendering/display fora de resolveRenderSettings', () => {
    const offenders: string[] = [];
    for (const file of sourceFiles(SRC)) {
      const rel = path.relative(SRC, file).replace(/\\/g, '/');
      if (rel.startsWith('schemas/') || ALLOWED.includes(rel)) continue;
      const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
      lines.forEach((line, i) => {
        if (READ.test(line) && !/^\s*(\/\/|\*|\/\*)/.test(line)) offenders.push(`${rel}:${i + 1}: ${line.trim()}`);
      });
    }
    expect(offenders).toEqual([]);
  });
});

describe('campos sem leitor aparecem desabilitados com o AIS dono (AIS-44d-C08, decisão 14)', () => {
  it('a lista cobre exatamente os campos do prompt, com o dono certo', () => {
    expect(SETTINGS_WITHOUT_READER).toEqual({
      'display.windowMode': 'AIS-85c / AIS-85',
      'display.resizable': 'AIS-85c',
      'display.orientation': 'AIS-85c',
      'rendering.vsync': 'AIS-85c',
      // AIS-52: audio.masterVolume / musicVolume / sfxVolume agora têm leitor (audioMixer.getChannelGain) — removidos
    });
  });

  it('o tooltip diz "em breve — <AIS dono>"; campos com leitor ficam editáveis (sem tooltip)', () => {
    expect(pendingReaderTooltip('display.orientation')).toBe('em breve — AIS-85c');
    // AIS-52: campos de áudio agora têm leitor — devem ser undefined (editáveis)
    for (const editable of [
      'physics.defaultLinearDamp', 'rendering.shadowsEnabled', 'rendering.shadowQuality',
      'rendering.clearColor', 'rendering.hdr', 'rendering.msaa', 'display.width', 'display.height',
      'audio.masterVolume', 'audio.musicVolume', 'audio.sfxVolume',
    ]) {
      expect(pendingReaderTooltip(editable), editable).toBeUndefined();
      expect(readerOwnerOf(editable)).toBeUndefined();
    }
  });

  it('cada campo listado existe de verdade nas settings (os valores gravados permanecem)', () => {
    const defaults = schemaDefaults() as unknown as Record<string, Record<string, unknown>>;
    for (const field of Object.keys(SETTINGS_WITHOUT_READER)) {
      const [group, key] = field.split('.');
      expect(defaults[group], field).toBeDefined();
      expect(key in defaults[group], field).toBe(true);
    }
  });
});
