import type { SpriteAnimation } from '../types/sprite';

/**
 * AIS-76 (decisão 24) — função CANÔNICA de frame de sprite. Usada pelo editor, pelo Play e pelo publish: nunca lógica de frame inline
 * (o bug histórico era aplicar `elapsedMs % total` antes de checar `loopMode`, o que fazia o clipe `once` repetir no publish).
 * Pura: sem DOM, sem Three.
 */

export type ClipInput = Pick<SpriteAnimation, 'frameIndices' | 'fps' | 'loopMode'> & { frameDurations?: number[] };

/** Sequência de posições percorridas (offsets em `frameIndices`): `ping-pong` vai e volta sem repetir as pontas. */
function playOrder(n: number, loopMode: ClipInput['loopMode']): number[] {
  const order: number[] = [];
  for (let i = 0; i < n; i++) order.push(i);
  if (loopMode === 'ping-pong') for (let i = n - 2; i >= 1; i--) order.push(i);
  return order;
}

function weightOf(animation: ClipInput, pos: number): number {
  const baseMs = 1000 / Math.max(0.1, Number.isFinite(animation.fps) ? animation.fps : 0.1);
  const mult = animation.frameDurations?.[pos];
  return Math.max(0.01, typeof mult === 'number' && Number.isFinite(mult) ? mult : 1) * baseMs;
}

/** Duração (ms) de UMA passada do clipe (ping-pong inclui a volta). `0` = sem frames. */
export function clipDurationMs(animation: ClipInput): number {
  const n = animation.frameIndices.length;
  if (n === 0) return 0;
  return playOrder(n, animation.loopMode).reduce((sum, pos) => sum + weightOf(animation, pos), 0);
}

/**
 * Posição (offset em `frameIndices`) ativa em `elapsedMs`. `-1` se não há frames.
 * `loop` cicla; `once` congela no último frame; `ping-pong` vai e volta sem repetir as pontas.
 */
export function clipPositionAtTime(animation: ClipInput, elapsedMs: number): number {
  const n = animation.frameIndices.length;
  if (n === 0) return -1;
  if (n === 1) return 0;
  const order = playOrder(n, animation.loopMode);
  const total = order.reduce((sum, pos) => sum + weightOf(animation, pos), 0);
  const t = Number.isFinite(elapsedMs) ? Math.max(0, elapsedMs) : 0;
  if (animation.loopMode === 'once' && t >= total) return n - 1;
  let rest = animation.loopMode === 'once' ? t : t % total;
  for (const pos of order) {
    const d = weightOf(animation, pos);
    if (rest < d) return pos;
    rest -= d;
  }
  return order[order.length - 1];
}

/**
 * Índice GLOBAL do frame (no atlas) ativo em `elapsedMs`. Retorna -1 se não há frames.
 * `loop` cicla; `once` congela no último frame; `ping-pong` vai e volta sem repetir as pontas.
 */
export function clipFrameIndexAtTime(animation: ClipInput, elapsedMs: number): number {
  const pos = clipPositionAtTime(animation, elapsedMs);
  return pos < 0 ? -1 : animation.frameIndices[pos];
}

/** `once` já terminou em `elapsedMs`? (base do sinal `animation_finished`; `loop`/`ping-pong` nunca terminam). */
export function clipFinishedAt(animation: ClipInput, elapsedMs: number): boolean {
  if (animation.loopMode !== 'once' || animation.frameIndices.length === 0) return false;
  return elapsedMs >= clipDurationMs(animation);
}

/** Quantas voltas completas o clipe cíclico (`loop`/`ping-pong`) já deu em `elapsedMs` (base do sinal `animation_looped`). */
export function clipLoopsAt(animation: ClipInput, elapsedMs: number): number {
  if (animation.loopMode === 'once' || animation.frameIndices.length < 2) return 0;
  const total = clipDurationMs(animation);
  return total > 0 ? Math.floor(Math.max(0, elapsedMs) / total) : 0;
}

/** Instante (ms) em que a POSIÇÃO `position` de `frameIndices` começa na primeira passada do clipe (base do "ir para este frame" do editor). */
export function clipStartMsOfPosition(animation: ClipInput, position: number): number {
  const n = animation.frameIndices.length;
  if (n === 0) return 0;
  const target = Math.max(0, Math.min(n - 1, Math.floor(position)));
  let t = 0;
  for (let i = 0; i < target; i++) t += weightOf(animation, i);
  return t;
}
