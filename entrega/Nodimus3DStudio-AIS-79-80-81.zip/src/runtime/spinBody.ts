import type { PhysicsBridge } from '../core/physics/PhysicsBridge';

/**
 * Rotação contínua de um corpo DINÂMICO. Num corpo dinâmico a física é a dona da pose: o `PhysicsHost` copia posição e rotação do Rapier
 * para a instância a cada quadro, então escrever em `instance.transform.rotation` é desfeito no mesmo quadro (a rotação contínua
 * funcionava sem física e com "sólido parado" e parava com física ativa). O caminho certo é a velocidade angular, pela `PhysicsBridge`
 * (nunca `RigidBody` do Rapier). Nós sem corpo, `static`, `kinematic` e `trigger` seguem pelo `transform` (a pose pedida é a autoridade).
 *
 * A velocidade é reafirmada a cada quadro (como um motor de velocidade constante): contatos e amortecimento não a roubam. O eixo é o do
 * MUNDO; um eixo travado por `constrainToPlane` não gira (o corpo não pode rodar nele).
 */

const DEG = Math.PI / 180;

export type SpinAxis = 'x' | 'y' | 'z';

/** `true` se o nó tem corpo dinâmico ligado (a rotação deve ir pela ponte, não pelo `transform`). */
export function drivesWithPhysics(bridge: PhysicsBridge | null, nodeId: string): bridge is PhysicsBridge {
  return !!bridge && !bridge.isDisposed && bridge.modeOf(nodeId) === 'dynamic' && bridge.isEnabled(nodeId);
}

/** Gira o corpo dinâmico a `degreesPerSecond` no eixo do mundo. Devolve `false` se o nó não é um corpo dinâmico (o chamador usa o `transform`). */
export function spinDynamicBody(bridge: PhysicsBridge | null, nodeId: string, axis: SpinAxis, degreesPerSecond: number): boolean {
  if (!drivesWithPhysics(bridge, nodeId)) return false;
  const w = degreesPerSecond * DEG;
  bridge.setAngularVelocity(nodeId, { x: axis === 'x' ? w : 0, y: axis === 'y' ? w : 0, z: axis === 'z' ? w : 0 });
  return true;
}

/** Para a rotação (zera a velocidade angular) de um corpo dinâmico; sem efeito em outros nós. */
export function stopSpinningBody(bridge: PhysicsBridge | null, nodeId: string): void {
  if (drivesWithPhysics(bridge, nodeId)) bridge.setAngularVelocity(nodeId, { x: 0, y: 0, z: 0 });
}
