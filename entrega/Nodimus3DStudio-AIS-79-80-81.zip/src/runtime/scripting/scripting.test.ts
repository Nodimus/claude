import { describe, expect, it } from 'vitest';
import { ENGINE_OPERATIONS } from '../engineApi';
import { DEFAULT_SCRIPT_LIMITS } from './limits';
import { SCRIPT_API_OPERATIONS, scriptOperations, validateCommands } from './protocol';
import { buildScriptSnapshot } from './snapshot';
import { createScriptEngine, createScriptWorkerCore } from './workerCore';
import type { ScriptCommand, ScriptSnapshot, WorkerToHost } from './protocol';

/** AIS-79 — superfície da API do script, validação do Command Buffer (entrada NÃO CONFIÁVEL), snapshot somente-leitura e o núcleo do Worker. */

const L = DEFAULT_SCRIPT_LIMITS;

describe('superfície da API do script (perfil restrito, diretriz 4.1)', () => {
  it('é um SUBCONJUNTO de ENGINE_OPERATIONS: toda operação existe, é marshalável e segura em Play', () => {
    expect(scriptOperations()).toHaveLength(SCRIPT_API_OPERATIONS.length);
    for (const op of scriptOperations()) {
      expect(op.marshalable, op.id).toBe(true);
      expect(op.safeIn.play, op.id).toBe(true);
    }
  });

  it('não inclui física, áudio, tweens, animação, cena, armas, IA, anexos, câmera nem `scripts` (um script não chama script)', () => {
    const forbidden = ['physics', 'audio', 'particles', 'animation', 'sprites', 'tweens', 'scene', 'weapons', 'ai', 'attachments', 'camera', 'materials', 'scripts', 'frame', 'locomotion', 'motion', 'hooks', 'routes'];
    for (const id of SCRIPT_API_OPERATIONS) expect(forbidden.includes(id.split('.')[0]), id).toBe(false);
    expect(SCRIPT_API_OPERATIONS.every((id) => ENGINE_OPERATIONS.some((o) => o.id === id))).toBe(true);
  });
});

describe('validateCommands (o host trata o que vem do Worker como não confiável)', () => {
  it('aceita os quatro comandos válidos e normaliza', () => {
    const r = validateCommands(
      [
        { op: 'transform.set', id: 'a', patch: { position: [1, 2, 3] } },
        { op: 'variables.set', scope: 'global', name: 'pontos', value: 10 },
        { op: 'variables.set', scope: 'local', name: 'hp', value: 5, nodeId: 'n1' },
        { op: 'signals.emit', name: 'boom', args: [1, 'x'] },
        { op: 'log', level: 'warn', message: 'oi' },
      ],
      L
    );
    expect(r.rejected).toEqual([]);
    expect(r.commands).toHaveLength(5);
  });

  it('recusa operação fora da superfície (física, arquivo, eval…) e formatos inválidos, COM motivo', () => {
    const r = validateCommands(
      [
        { op: 'physics.raycast', origin: [0, 0, 0] },
        { op: 'fs.write', path: 'C:/x' },
        { op: 'eval', code: '1' },
        { op: 'transform.set', id: 'a', patch: { position: [1, 2] } },
        { op: 'transform.set', id: 'a', patch: { position: [1, Number.NaN, 3] } },
        { op: 'transform.set', id: '', patch: { position: [1, 2, 3] } },
        { op: 'transform.set', id: 'a', patch: {} },
        { op: 'variables.set', scope: 'sessao', name: 'x', value: 1 },
        { op: 'variables.set', scope: 'global', name: 'x', value: { a: 1 } },
        { op: 'signals.emit', name: 'x', args: 'nao-lista' },
        { op: 'log', level: 'fatal', message: 'x' },
        42,
        null,
      ],
      L
    );
    expect(r.commands).toEqual([]);
    expect(r.rejected).toHaveLength(13);
    expect(r.rejected[0].reason).toMatch(/fora da superfície/);
  });

  it('o buffer que não é lista é recusado por inteiro', () => {
    expect(validateCommands({ op: 'log' }, L).rejected[0].reason).toMatch(/não é uma lista/);
  });

  it('teto de comandos por quadro: o excesso é descartado e contado', () => {
    const many = Array.from({ length: 300 }, () => ({ op: 'log', level: 'info', message: 'x' }));
    const r = validateCommands(many, L);
    expect(r.commands).toHaveLength(L.maxCommandsPerFrame);
    expect(r.overflow).toBe(300 - L.maxCommandsPerFrame);
  });

  it('limites de tamanho: log truncado, nome e args longos recusados', () => {
    const r = validateCommands(
      [
        { op: 'log', level: 'info', message: 'x'.repeat(5000) },
        { op: 'signals.emit', name: 'n'.repeat(200) },
        { op: 'signals.emit', name: 'ok', args: ['y'.repeat(5000)] },
      ],
      L
    );
    expect((r.commands[0] as Extract<ScriptCommand, { op: 'log' }>).message).toHaveLength(L.maxTextChars);
    expect(r.rejected).toHaveLength(2);
  });

  it('args cíclicos ou com funções não passam (só JSON puro)', () => {
    const cyclic: unknown[] = [];
    cyclic.push(cyclic);
    expect(validateCommands([{ op: 'signals.emit', name: 'x', args: cyclic }], L).rejected).toHaveLength(1);
  });
});

const instance = (id: string, name: string, extra: Record<string, unknown> = {}) =>
  ({ persistentNodeId: id, name, type: 'Spatial', disposed: false, tags: ['t'], visible: true, parent: null, transform: { position: [1, 2, 3], rotation: [0, 0, 0], scale: [1, 1, 1] }, ...extra }) as never;

describe('buildScriptSnapshot', () => {
  const input = { isActionPressed: (a: string) => a === 'Jump', isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false, actions: () => ['Jump', 'Fire'] };

  it('só dados serializáveis: nós, variáveis (globais e locais) e estado das ações', () => {
    const variables = { listGlobals: () => [{ name: 'pontos', type: 'number', value: 3 }], listLocals: (id: string) => (id === 'a' ? [{ name: 'hp', type: 'number', value: 9 }, { name: 'obj', type: 'string', value: { x: 1 } }] : []) };
    const { snapshot, truncated } = buildScriptSnapshot({ time: 1.5, frame: 4, instances: [instance('a', 'Heroi'), instance('b', 'Inimigo', { disposed: true })], variables: variables as never, input: input as never, actionNames: [] }, L);
    expect(truncated).toBe(false);
    expect(JSON.parse(JSON.stringify(snapshot))).toEqual(snapshot);
    expect(Object.keys(snapshot.nodes)).toEqual(['a']); // descartado não entra
    expect(snapshot.variables).toEqual({ global: { pontos: 3 }, local: { a: { hp: 9 } } }); // valor não primitivo fica de fora
    expect(snapshot.input).toEqual({ Jump: { pressed: true, justPressed: false, justReleased: false, strength: 1 }, Fire: { pressed: false, justPressed: false, justReleased: false, strength: 0 } });
  });

  it('teto de nós: corta e avisa', () => {
    const many = Array.from({ length: 5 }, (_, i) => instance(`n${i}`, `N${i}`));
    const r = buildScriptSnapshot({ time: 0, frame: 1, instances: many, variables: null, input: input as never, actionNames: [] }, { maxSnapshotNodes: 3 });
    expect(Object.keys(r.snapshot.nodes)).toHaveLength(3);
    expect(r.truncated).toBe(true);
  });
});

const SNAP: ScriptSnapshot = {
  time: 2,
  frame: 7,
  nodes: { a: { id: 'a', name: 'Heroi', type: 'Spatial', tags: [], visible: true, parentId: null, transform: { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] } } },
  variables: { global: { pontos: 1 }, local: { a: { hp: 4 } } },
  input: { Jump: { pressed: true, justPressed: true, justReleased: false, strength: 1 }, MoveLeft: { pressed: false, justPressed: false, justReleased: false, strength: 0 }, MoveRight: { pressed: true, justPressed: false, justReleased: false, strength: 1 } },
};

describe('engine do script (createScriptEngine)', () => {
  const make = () => {
    const buffer: ScriptCommand[] = [];
    return { buffer, engine: createScriptEngine(structuredClone(SNAP), 'a', buffer) };
  };

  it('lê o snapshot; ações lógicas e eixo; resolve por id ou nome', () => {
    const { engine } = make();
    expect(engine.self).toBe('a');
    expect(engine.time()).toBe(2);
    expect(engine.nodes.get('a')?.name).toBe('Heroi');
    expect(engine.nodes.resolve('Heroi')).toEqual({ id: 'a' });
    expect(engine.nodes.resolve('nada')).toBeUndefined();
    expect(engine.variables.get('global', 'pontos')).toBe(1);
    expect(engine.variables.get('local', 'hp')).toBe(4); // local = do dono
    expect(engine.input.isPressed('Jump')).toBe(true);
    expect(engine.input.axis('MoveLeft', 'MoveRight')).toBe(1);
  });

  it('escrever = enfileirar comando (nunca altera o snapshot, que é congelado)', () => {
    const { engine, buffer } = make();
    engine.transform.set('a', { position: [5, 0, 0] });
    engine.variables.set('local', 'hp', 3);
    engine.signals.emit('x', [1]);
    engine.log('info', 'oi');
    expect(buffer.map((c) => c.op)).toEqual(['transform.set', 'variables.set', 'signals.emit', 'log']);
    expect((buffer[1] as Extract<ScriptCommand, { op: 'variables.set' }>).nodeId).toBe('a');
    const node = engine.nodes.get('a')!;
    expect(() => {
      (node.transform.position as number[])[0] = 999;
    }).toThrow(); // congelado (módulo ESM é estrito)
    expect(engine.transform.get('a')!.position[0]).toBe(0);
  });

  it('o objeto engine não tem window, document, fetch, filesystem nem TauriBridge', () => {
    const { engine } = make();
    const keys = Object.keys(engine).sort();
    expect(keys).toEqual(['input', 'log', 'nodes', 'self', 'signals', 'time', 'transform', 'variables', 'version']);
    for (const bad of ['window', 'document', 'fetch', 'fs', 'tauri', 'physics', 'audio']) expect(bad in engine).toBe(false);
    expect(Object.isFrozen(engine)).toBe(true);
  });
});

describe('núcleo do Worker (createScriptWorkerCore)', () => {
  const setup = (mod: Record<string, unknown> | Error) => {
    const out: WorkerToHost[] = [];
    const handle = createScriptWorkerCore({
      post: (m) => void out.push(m),
      importModule: async () => {
        if (mod instanceof Error) throw mod;
        return mod;
      },
      now: (() => {
        let t = 0;
        return () => (t += 2);
      })(),
    });
    return { out, handle };
  };

  it('load → ready com as funções exportadas; call devolve os comandos e o tempo medido', async () => {
    const { out, handle } = setup({ onUpdate: (e: any, dt: number) => e.log('info', `dt=${dt}`), run: (e: any, args: any) => e.variables.set('global', 'x', args.v), naoEntrada: () => {} });
    await handle({ t: 'load', url: 'u', ownerId: 'a', limits: { frameBudgetMs: 8, maxTextChars: 2000 } });
    expect(out[0]).toEqual({ t: 'ready', exports: ['onUpdate', 'run'] });
    await handle({ t: 'call', id: 1, fn: 'onUpdate', dt: 0.016, snapshot: SNAP });
    await handle({ t: 'call', id: 2, fn: 'run', args: { v: 7 }, snapshot: SNAP });
    expect(out[1]).toMatchObject({ t: 'done', id: 1, commands: [{ op: 'log', level: 'info', message: 'dt=0.016' }], ms: 2 });
    expect(out[2]).toMatchObject({ t: 'done', id: 2, commands: [{ op: 'variables.set', scope: 'global', name: 'x', value: 7 }] });
  });

  it('exceção do script vira erro com código estável (nunca derruba o Worker); chamada sem a função também', async () => {
    const { out, handle } = setup({ onUpdate: () => { throw new Error('quebrou'); }, run: () => {} });
    await handle({ t: 'load', url: 'u', ownerId: null, limits: { frameBudgetMs: 8, maxTextChars: 2000 } });
    await handle({ t: 'call', id: 1, fn: 'onUpdate', dt: 0, snapshot: SNAP });
    await handle({ t: 'call', id: 2, fn: 'onReady', snapshot: SNAP });
    expect(out[1]).toMatchObject({ t: 'error', id: 1, code: 'script.exception' });
    expect((out[1] as { message: string }).message).toContain('quebrou');
    expect(out[2]).toMatchObject({ t: 'error', id: 2, code: 'script.no_entry' });
  });

  it('módulo que falha ao carregar ou sem função de entrada vira erro de carga', async () => {
    const a = setup(new SyntaxError('token inesperado'));
    await a.handle({ t: 'load', url: 'u', ownerId: null, limits: { frameBudgetMs: 8, maxTextChars: 2000 } });
    expect(a.out[0]).toMatchObject({ t: 'error', code: 'script.load_failed' });
    const b = setup({ x: 1 });
    await b.handle({ t: 'load', url: 'u', ownerId: null, limits: { frameBudgetMs: 8, maxTextChars: 2000 } });
    expect(b.out[0]).toMatchObject({ t: 'error', code: 'script.no_entry' });
  });
});
