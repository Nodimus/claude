/// <reference lib="webworker" />
import { createScriptWorkerCore } from './workerCore';
import type { HostToWorker } from './protocol';

/**
 * AIS-79 — ENTRADA do Web Worker de scripts. Só aqui existem os globais do Worker. Endurece o escopo ANTES de carregar código do usuário:
 *  - sem rede/armazenamento/outros workers (`fetch`, `XMLHttpRequest`, `WebSocket`, `importScripts`, `indexedDB`, `caches`, `Worker`…);
 *  - sem `eval`/`new Function` (e os construtores de funções assíncronas/geradoras): complementa a CSP do documento (sem `unsafe-eval`).
 * É CONVENÇÃO + CSP, não a barreira principal: a barreira é o Worker não ter `window`, `document` nem `TauriBridge`, e o host validar tudo que volta
 * (Command Buffer). O código do usuário entra por `import(blobUrl)` — nunca por `eval`.
 */

const scope = self as unknown as Record<string, unknown>;

function blockGlobals(names: readonly string[]): void {
  for (const name of names) {
    try {
      Object.defineProperty(self, name, { value: undefined, writable: false, configurable: false });
    } catch {
      /* já não-configurável: segue */
    }
  }
}

function blockCodeGeneration(): void {
  const blocked = function blockedFunction() {
    throw new Error('Geração dinâmica de código é bloqueada no sandbox de scripts.');
  };
  try {
    Object.defineProperty(self, 'eval', { value: blocked, writable: false, configurable: false });
  } catch {
    /* segue */
  }
  const protos = [Function.prototype, Object.getPrototypeOf(async function () {}), Object.getPrototypeOf(function* () {}), Object.getPrototypeOf(async function* () {})];
  for (const proto of protos) {
    try {
      Object.defineProperty(proto, 'constructor', { value: blocked, writable: false, configurable: false });
    } catch {
      /* segue */
    }
  }
}

blockGlobals(['fetch', 'XMLHttpRequest', 'WebSocket', 'EventSource', 'importScripts', 'indexedDB', 'caches', 'BroadcastChannel', 'Worker', 'SharedWorker', 'WebTransport', 'FileReaderSync']);
blockCodeGeneration();

const postToHost = self.postMessage.bind(self);
const handle = createScriptWorkerCore({
  post: (message) => postToHost(message),
  importModule: (url) => import(/* @vite-ignore */ url) as Promise<Record<string, unknown>>,
});

self.onmessage = (event: MessageEvent<HostToWorker>) => {
  void handle(event.data);
};

void scope;
