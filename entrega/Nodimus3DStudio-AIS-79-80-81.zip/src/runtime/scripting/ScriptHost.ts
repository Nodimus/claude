import type { ServiceResult } from '../engineApi';
import { DEFAULT_SCRIPT_LIMITS, type ScriptLimits } from './limits';
import { validateCommands, type HostToWorker, type ScriptCommand, type ScriptSnapshot, type WorkerToHost } from './protocol';
import { tNow } from '../../core/i18n';

/**
 * AIS-79 — host do sandbox de scripts (decisão canônica: **Web Worker isolado + mensagem estruturada + EngineApi restrita + Command Buffer validado
 * pelo host**). UM `ScriptHost` por `RuntimeSession`; cada script (arquivo × nó dono) roda no SEU Worker, para que o timeout de um só o encerre.
 * Scripts anexados a nós (`GameNode.script`) e a Action `run_script` usam este MESMO mecanismo (decisão 32: um caminho, o `InvocationScope` do dono).
 *
 * Fluxo por quadro (`tick`): 1) aplica os comandos que os Workers devolveram desde o quadro anterior (validados); 2) monta UM snapshot somente-leitura
 * e chama `onUpdate(engine, dt)` em cada Worker livre. O efeito das escritas de um script chega, portanto, com 1 quadro de latência (aceito).
 * Estourar `callTimeoutMs` (parede) ou `frameBudgetMs` por `overBudgetStrikes` quadros seguidos ENCERRA o Worker: o script fica marcado com erro
 * (diagnóstico efêmero `script.timeout`/`script.over_budget` no nó dono) e o Play segue. Tudo é descartado no Stop/restart/troca de cena.
 */

export interface WorkerLike {
  postMessage(message: HostToWorker): void;
  terminate(): void;
  onmessage: ((event: { data: unknown }) => void) | null;
  onerror: ((event: { message?: string }) => void) | null;
}

/** Como o host aplica um comando JÁ VALIDADO (a sessão liga isto à `EngineApi` do nó dono). Devolve `false` se o alvo recusou. */
export interface ScriptCommandSink {
  transformSet(ownerId: string | null, id: string, patch: Extract<ScriptCommand, { op: 'transform.set' }>['patch']): boolean;
  variablesSet(ownerId: string | null, scope: 'global' | 'local', name: string, value: number | string | boolean, nodeId?: string): boolean;
  emit(ownerId: string | null, name: string, args?: unknown[]): void;
  log(ownerId: string | null, level: 'info' | 'warn' | 'error', message: string): void;
}

export interface ScriptHostOptions {
  createWorker(): WorkerLike;
  /** Código-fonte de um script de `res://scripts/` (`null` = não existe). */
  readSource(path: string): string | null;
  /** Transforma código em URL carregável pelo Worker (`URL.createObjectURL(new Blob(...))`). */
  createUrl(source: string): string;
  revokeUrl(url: string): void;
  report(severity: 'error' | 'warning', code: string, message: string, nodeId?: string): void;
  sink: ScriptCommandSink;
  buildSnapshot(frame: number): ScriptSnapshot;
  limits?: Partial<ScriptLimits>;
  setTimer?: (fn: () => void, ms: number) => unknown;
  clearTimer?: (handle: unknown) => void;
}

type InstanceState = 'loading' | 'ready' | 'failed' | 'disposed';

interface Call {
  fn: 'onReady' | 'onUpdate' | 'run';
  args?: unknown;
}

interface Instance {
  key: string;
  path: string;
  ownerId: string | null;
  worker: WorkerLike;
  url: string;
  state: InstanceState;
  exports: Set<string>;
  inflight: { id: number; fn: Call['fn']; timer: unknown } | null;
  queue: Call[];
  strikes: number;
  loadTimer: unknown;
  /** Comandos devolvidos pelo Worker, aguardando o próximo quadro. */
  pending: unknown[];
  warned: Set<string>;
}

const SCRIPT_PATH = /^res:\/\/scripts\/[^\\]+\.js$/i;

export const isRunnableScriptPath = (path: unknown): path is string => typeof path === 'string' && SCRIPT_PATH.test(path) && !path.includes('..');

export class ScriptHost {
  private readonly instances = new Map<string, Instance>();
  private readonly limits: ScriptLimits;
  private readonly setTimer: (fn: () => void, ms: number) => unknown;
  private readonly clearTimer: (handle: unknown) => void;
  private frame = 0;
  private callId = 0;
  private disposed = false;

  constructor(private readonly options: ScriptHostOptions) {
    this.limits = { ...DEFAULT_SCRIPT_LIMITS, ...options.limits };
    this.setTimer = options.setTimer ?? ((fn, ms) => setTimeout(fn, ms));
    this.clearTimer = (h) => {
      if (h !== null && h !== undefined) (options.clearTimer ?? ((x) => clearTimeout(x as ReturnType<typeof setTimeout>)))(h);
    };
  }

  /** Quantos scripts estão vivos (carregando ou prontos). */
  get activeCount(): number {
    return [...this.instances.values()].filter((i) => i.state === 'loading' || i.state === 'ready').length;
  }

  stateOf(ownerId: string | null, path: string): InstanceState | undefined {
    return this.instances.get(this.keyOf(ownerId, path))?.state;
  }

  private keyOf = (ownerId: string | null, path: string) => `${ownerId ?? ''}::${path}`;

  /** Script anexado a um nó: carrega e passa a receber `onReady` (uma vez) e `onUpdate` a cada quadro. */
  attach(ownerId: string, path: string): ServiceResult {
    const created = this.ensure(ownerId, path);
    if (!created.ok) return created;
    return { ok: true };
  }

  /** Action `run_script`: roda `run(engine, args)` UMA vez, com `ownerId` = o dono da regra. O efeito chega no quadro seguinte. */
  run(ownerId: string | null, path: string, args?: unknown): ServiceResult {
    if (path.toLowerCase().endsWith('.ts')) return fail('script.ts_not_supported', tNow('scriptHostMsgCore.tsScriptsDoNotRun'));
    const found = this.ensure(ownerId, path);
    if (!found.ok) return found;
    const inst = found.instance;
    if (inst.state === 'failed') return fail('script.failed', tNow('scriptHostMsgCore.theScriptIsMarkedWith', { path }));
    inst.queue.push({ fn: 'run', args });
    return { ok: true };
  }

  /** Um quadro: aplica o que os Workers devolveram e dispara a próxima rodada. */
  tick(dt: number): void {
    if (this.disposed) return;
    this.frame++;
    for (const inst of this.instances.values()) this.applyPending(inst);
    let snapshot: ScriptSnapshot | null = null;
    for (const inst of [...this.instances.values()]) {
      if (inst.state !== 'ready' || inst.inflight) continue;
      const call = inst.queue.shift() ?? (inst.exports.has('onUpdate') ? ({ fn: 'onUpdate' } as Call) : null);
      if (!call) continue;
      snapshot ??= this.options.buildSnapshot(this.frame);
      this.send(inst, call, dt, snapshot);
    }
  }

  dispose(): void {
    this.disposed = true;
    for (const inst of this.instances.values()) this.kill(inst, 'disposed');
    this.instances.clear();
  }

  // ── interno ────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

  private ensure(ownerId: string | null, path: string): { ok: true; instance: Instance } | { ok: false; code: string; message: string } {
    if (this.disposed) return fail('script.session_ended', tNow('scriptHostMsgCore.theSessionHasAlreadyEnded'));
    if (!isRunnableScriptPath(path)) return fail('script.invalid_path', tNow('scriptHostMsgResB.isNotAJsFrom', { value: String(path).slice(0, 80) }));
    const key = this.keyOf(ownerId, path);
    const existing = this.instances.get(key);
    if (existing) return { ok: true, instance: existing };
    const source = this.options.readSource(path);
    if (source === null) return fail('script.not_found', tNow('scriptHostMsgCore.theScriptDoesNotExist', { path }));
    if (source.length > this.limits.maxSourceChars) return fail('script.too_large', tNow('scriptHostMsgCore.theScriptExceedsCharacters', { path, maxSourceChars: this.limits.maxSourceChars }));
    let url: string;
    let worker: WorkerLike;
    try {
      url = this.options.createUrl(source);
      worker = this.options.createWorker();
    } catch (error) {
      return fail('script.worker_unavailable', tNow('scriptHostMsgCore.couldNotCreateTheScript', { value: error instanceof Error ? error.message : String(error) }));
    }
    const inst: Instance = { key, path, ownerId, worker, url, state: 'loading', exports: new Set(), inflight: null, queue: [], strikes: 0, loadTimer: null, pending: [], warned: new Set() };
    this.instances.set(key, inst);
    worker.onmessage = (event) => this.onMessage(inst, event.data);
    worker.onerror = (event) => this.failInstance(inst, 'script.crashed', tNow('scriptHostMsgCore.theWorkerOfTheScript', { path, value: event.message ?? tNow('scriptHostMsgLast.unhandledError') }));
    inst.loadTimer = this.setTimer(() => this.failInstance(inst, 'script.timeout', tNow('scriptHostMsgCore.theScriptDidNotLoad', { path, value: Math.max(this.limits.callTimeoutMs, 1000) })), Math.max(this.limits.callTimeoutMs, 1000));
    worker.postMessage({ t: 'load', url, ownerId, limits: { frameBudgetMs: this.limits.frameBudgetMs, maxTextChars: this.limits.maxTextChars } });
    return { ok: true, instance: inst };
  }

  private send(inst: Instance, call: Call, dt: number, snapshot: ScriptSnapshot): void {
    const id = ++this.callId;
    const timer = this.setTimer(() => this.failInstance(inst, 'script.timeout', tNow('scriptHostMsgCore.theScriptDidNotRespond', { path: inst.path, callTimeoutMs: this.limits.callTimeoutMs, fn: call.fn })), this.limits.callTimeoutMs);
    inst.inflight = { id, fn: call.fn, timer };
    inst.worker.postMessage({ t: 'call', id, fn: call.fn, dt, args: call.args, snapshot });
  }

  private onMessage(inst: Instance, data: unknown): void {
    if (inst.state === 'failed' || inst.state === 'disposed') return;
    if (!data || typeof data !== 'object' || typeof (data as { t?: unknown }).t !== 'string') return; // mensagem forjada ou ruído: ignorada
    const m = data as WorkerToHost;
    if (m.t === 'ready') {
      this.clearTimer(inst.loadTimer);
      inst.loadTimer = null;
      inst.exports = new Set(Array.isArray(m.exports) ? m.exports.filter((e): e is string => typeof e === 'string') : []);
      inst.state = 'ready';
      if (inst.exports.has('onReady')) inst.queue.unshift({ fn: 'onReady' }); // `onReady` uma vez, antes de qualquer `run` já enfileirado
      return;
    }
    if (m.t === 'error') {
      if (m.id !== undefined && inst.inflight && m.id !== inst.inflight.id) return; // resposta de uma chamada que não é a atual
      this.failInstance(inst, typeof m.code === 'string' ? m.code : 'script.exception', typeof m.message === 'string' ? m.message.slice(0, this.limits.maxTextChars) : tNow('scriptHostMsgCore.scriptError'));
      return;
    }
    if (m.t === 'done') {
      const flight = inst.inflight;
      if (!flight || flight.id !== m.id) return; // resposta forjada/atrasada: sem chamada correspondente
      this.clearTimer(flight.timer);
      inst.inflight = null;
      inst.pending.push(m.commands);
      if (flight.fn === 'onUpdate') this.checkBudget(inst, typeof m.ms === 'number' ? m.ms : 0);
    }
  }

  private checkBudget(inst: Instance, ms: number): void {
    if (ms <= this.limits.frameBudgetMs) {
      inst.strikes = 0;
      return;
    }
    inst.strikes++;
    if (inst.strikes >= this.limits.overBudgetStrikes) {
      this.failInstance(inst, 'script.over_budget', tNow('scriptHostMsgCore.theScriptSpentMoreThan', { path: inst.path, frameBudgetMs: this.limits.frameBudgetMs, strikes: inst.strikes }));
      return;
    }
    this.warnOnce(inst, 'budget', tNow('scriptHostMsgCore.theScriptSpentMsIn', { path: inst.path, ms: ms.toFixed(1), frameBudgetMs: this.limits.frameBudgetMs }), 'script.slow');
  }

  private applyPending(inst: Instance): void {
    const batches = inst.pending;
    inst.pending = [];
    for (const raw of batches) {
      const { commands, rejected, overflow } = validateCommands(raw, this.limits);
      for (const r of rejected) this.warnOnce(inst, `rej:${r.reason}`, tNow('scriptHostMsgCore.commandRejectedByTheHost', { path: inst.path, reason: r.reason }), 'script.command_rejected');
      if (overflow > 0) this.warnOnce(inst, 'overflow', tNow('scriptHostMsgCore.theScriptExceededTheCeiling', { path: inst.path, maxCommandsPerFrame: this.limits.maxCommandsPerFrame, overflow }), 'script.command_overflow');
      for (const c of commands) this.execute(inst, c);
    }
  }

  private execute(inst: Instance, c: ScriptCommand): void {
    const sink = this.options.sink;
    let ok = true;
    switch (c.op) {
      case 'transform.set':
        ok = sink.transformSet(inst.ownerId, c.id, c.patch);
        break;
      case 'variables.set':
        ok = sink.variablesSet(inst.ownerId, c.scope, c.name, c.value, c.nodeId);
        break;
      case 'signals.emit':
        sink.emit(inst.ownerId, c.name, c.args);
        break;
      case 'log':
        sink.log(inst.ownerId, c.level, `[${inst.path.split('/').pop()}] ${c.message}`);
        break;
    }
    if (!ok) this.warnOnce(inst, `fail:${c.op}`, tNow('scriptHostMsgCore.aCommandFromWasNot', { op: c.op, path: inst.path }), 'script.command_failed');
  }

  private warnOnce(inst: Instance, key: string, message: string, code: string): void {
    if (inst.warned.has(`${code}:${key}`)) return;
    inst.warned.add(`${code}:${key}`);
    this.options.report('warning', code, message, inst.ownerId ?? undefined);
  }

  /** Erro do script: marca como falho, encerra o Worker e publica o diagnóstico no nó dono. O Play NÃO para. */
  private failInstance(inst: Instance, code: string, message: string): void {
    if (inst.state === 'failed' || inst.state === 'disposed') return;
    this.kill(inst, 'failed');
    this.options.report('error', code, message, inst.ownerId ?? undefined);
  }

  private kill(inst: Instance, state: 'failed' | 'disposed'): void {
    inst.state = state;
    this.clearTimer(inst.loadTimer);
    if (inst.inflight) this.clearTimer(inst.inflight.timer);
    inst.inflight = null;
    inst.queue = [];
    inst.pending = [];
    inst.worker.onmessage = null;
    inst.worker.onerror = null;
    try {
      inst.worker.terminate();
    } finally {
      this.options.revokeUrl(inst.url);
    }
  }
}

const fail = (code: string, message: string): { ok: false; code: string; message: string } => ({ ok: false, code, message });
