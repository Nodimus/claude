/**
 * AIS-79 — limites do sandbox de scripts (Web Worker). Valores PADRÃO (testes e o editor podem sobrescrever por `ScriptHost`):
 *  - `callTimeoutMs`: relógio de parede entre enviar uma chamada ao Worker e receber a resposta; estourar = o Worker é ENCERRADO (`terminate`),
 *    o script/nó fica marcado com erro e o Play segue. É o único limite que impede um laço infinito de travar algo: o Worker é outro thread.
 *  - `frameBudgetMs`: tempo medido DENTRO do Worker por chamada de quadro (`onUpdate`); estourar `overBudgetStrikes` quadros seguidos também
 *    encerra o Worker (um pico isolado de GC só gera aviso).
 *  - `maxCommandsPerFrame`: teto do Command Buffer por chamada; o excesso é descartado com diagnóstico.
 */
export interface ScriptLimits {
  callTimeoutMs: number;
  frameBudgetMs: number;
  overBudgetStrikes: number;
  maxCommandsPerFrame: number;
  /** Tamanho máximo do texto de um `log`/nome de sinal (caracteres). */
  maxTextChars: number;
  /** Tamanho máximo (JSON) dos argumentos de um sinal emitido por script. */
  maxSignalArgsChars: number;
  /** Tamanho máximo do código-fonte de um script (bytes ~ caracteres). */
  maxSourceChars: number;
  /** Teto de nós no snapshot enviado ao Worker (o excesso é cortado com diagnóstico). */
  maxSnapshotNodes: number;
}

export const DEFAULT_SCRIPT_LIMITS: Readonly<ScriptLimits> = Object.freeze({
  callTimeoutMs: 100,
  frameBudgetMs: 8,
  overBudgetStrikes: 3,
  maxCommandsPerFrame: 256,
  maxTextChars: 2000,
  maxSignalArgsChars: 4000,
  maxSourceChars: 512 * 1024,
  maxSnapshotNodes: 2000,
});
