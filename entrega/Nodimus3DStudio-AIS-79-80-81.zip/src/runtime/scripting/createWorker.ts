import type { WorkerLike } from './ScriptHost';

/**
 * AIS-79 — cria o Web Worker real do sandbox de scripts (módulo: o Vite empacota `scriptWorker.ts` como chunk próprio). Separado para que o resto do
 * runtime (e os testes em Node) só o chame quando precisarem de um Worker de verdade; testes injetam um dublê por `createScriptWorker`.
 */
export function createScriptWorker(): WorkerLike {
  if (typeof Worker === 'undefined') throw new Error('Web Workers não estão disponíveis neste ambiente.');
  return new Worker(new URL('./scriptWorker.ts', import.meta.url), { type: 'module' }) as unknown as WorkerLike;
}
