import { describe, expect, it } from 'vitest';
import { ScriptHost, isRunnableScriptPath, type ScriptCommandSink, type ScriptHostOptions } from './ScriptHost';
import { FakeWorker, fakeWorkerFactory, settle } from './testWorker';
import type { ScriptSnapshot } from './protocol';

/** AIS-79 — o host do sandbox: ciclo de vida, Command Buffer validado, timeout (Worker encerrado, Play segue), orçamento por quadro e mensagens forjadas. */

const SNAP: ScriptSnapshot = { time: 0, frame: 0, nodes: {}, variables: { global: {}, local: {} }, input: {} };

const SOURCES: Record<string, string> = {
  'res://scripts/mover.js': `export function onUpdate(engine, dt) { engine.transform.set(engine.self, { position: [1, 2, 3] }); }
export function run(engine, args) { engine.log('info', 'rodou ' + (args ?? 'sem args')); }
export function onReady(engine) { engine.log('info', 'pronto'); }`,
  'res://scripts/solo.js': `export function run(engine) { engine.variables.set('global', 'pontos', 5); }`,
  'res://scripts/quebra.js': `export function onUpdate() { throw new Error('boom'); }`,
  'res://scripts/ma-fe.js': `export function onUpdate(engine) { engine.transform.set('a', { position: [1, 2] }); engine.nodes.get('x').y.z; }`,
  'res://scripts/spam.js': `export function onUpdate(engine) { for (let i = 0; i < 400; i++) engine.log('info', 'x' + i); }`,
  'res://scripts/vazio.js': `export const x = 1;`,
  'res://scripts/sintaxe.js': `export function onUpdate( { `,
  'res://scripts/lento.js': `export function onUpdate() {}`,
};

function setup(extra: Partial<ScriptHostOptions> = {}) {
  const factory = fakeWorkerFactory();
  const reports: { severity: string; code: string; message: string; nodeId?: string }[] = [];
  const applied: string[] = [];
  const revoked: string[] = [];
  let urlCounter = 0;
  const timers: { fn: () => void; ms: number; cleared: boolean }[] = [];
  const sink: ScriptCommandSink = {
    transformSet: (owner, id, patch) => (applied.push(`transform:${owner}:${id}:${JSON.stringify(patch.position)}`), id !== 'sumiu'),
    variablesSet: (owner, scope, name, value) => (applied.push(`var:${owner}:${scope}:${name}=${value}`), true),
    emit: (owner, name) => void applied.push(`emit:${owner}:${name}`),
    log: (owner, level, message) => void applied.push(`log:${owner}:${level}:${message}`),
  };
  const host = new ScriptHost({
    createWorker: factory.create,
    readSource: (path) => SOURCES[path] ?? null,
    createUrl: (source) => {
      const url = URL.createObjectURL(new Blob([source], { type: 'text/javascript' }));
      urlCounter++;
      return url;
    },
    revokeUrl: (url) => {
      revoked.push(url);
      URL.revokeObjectURL(url);
    },
    report: (severity, code, message, nodeId) => void reports.push({ severity, code, message, nodeId }),
    sink,
    buildSnapshot: () => SNAP,
    setTimer: (fn, ms) => {
      const t = { fn, ms, cleared: false };
      timers.push(t);
      return t;
    },
    clearTimer: (h) => void ((h as { cleared: boolean }).cleared = true),
    ...extra,
  });
  return { host, factory, reports, applied, revoked, timers, urls: () => urlCounter };
}

describe('caminho do script', () => {
  it('só .js de res://scripts/ (sem .., sem outra pasta, sem .ts)', () => {
    expect(isRunnableScriptPath('res://scripts/a.js')).toBe(true);
    expect(isRunnableScriptPath('res://scripts/sub/a.JS')).toBe(true);
    for (const bad of ['res://scripts/a.ts', 'res://other/a.js', 'res://scripts/../x.js', 'https://x/a.js', 'scripts/a.js', '', 42, null]) expect(isRunnableScriptPath(bad as never), String(bad)).toBe(false);
  });
});

describe('script anexado a um nó (attach): onReady uma vez e onUpdate por quadro', () => {
  it('carrega, roda onReady e depois onUpdate; as escritas chegam com UM quadro de latência, validadas', async () => {
    const t = setup();
    expect(t.host.attach('a', 'res://scripts/mover.js')).toEqual({ ok: true });
    expect(t.host.stateOf('a', 'res://scripts/mover.js')).toBe('loading');
    await settle();
    expect(t.host.stateOf('a', 'res://scripts/mover.js')).toBe('ready');

    t.host.tick(0.016); // dispara onReady
    await settle();
    expect(t.applied).toEqual([]); // nada aplicado ainda: o resultado volta no quadro seguinte
    t.host.tick(0.016); // aplica o onReady e dispara onUpdate
    expect(t.applied).toEqual(['log:a:info:[mover.js] pronto']);
    await settle();
    t.host.tick(0.016);
    expect(t.applied).toContain('transform:a:a:[1,2,3]');
    expect(t.reports).toEqual([]);
    t.host.dispose();
  });

  it('um Worker por (nó × arquivo): dois nós com o mesmo script têm Workers e donos distintos', async () => {
    const t = setup();
    t.host.attach('a', 'res://scripts/mover.js');
    t.host.attach('b', 'res://scripts/mover.js');
    expect(t.factory.workers).toHaveLength(2);
    await settle();
    for (let i = 0; i < 4; i++) {
      t.host.tick(0.016);
      await settle();
    }
    expect(t.applied.some((x) => x.startsWith('transform:a:'))).toBe(true);
    expect(t.applied.some((x) => x.startsWith('transform:b:'))).toBe(true);
    t.host.dispose();
  });
});

describe('run_script (uma vez, com o dono da regra)', () => {
  it('executa run(engine, args) uma vez; chamar de novo reaproveita o Worker', async () => {
    const t = setup();
    expect(t.host.run('a', 'res://scripts/solo.js')).toEqual({ ok: true });
    await settle();
    t.host.tick(0.016);
    await settle();
    t.host.tick(0.016);
    expect(t.applied).toEqual(['var:a:global:pontos=5']);
    t.host.run('a', 'res://scripts/solo.js');
    expect(t.factory.workers).toHaveLength(1);
    // sem onUpdate: nada roda sozinho a cada quadro
    await settle();
    t.host.tick(0.016);
    await settle();
    t.host.tick(0.016);
    expect(t.applied.filter((x) => x.startsWith('var:'))).toHaveLength(2);
    t.host.dispose();
  });

  it('recusas explícitas com código estável: .ts, caminho inválido, inexistente, grande demais', () => {
    const t = setup({ limits: { maxSourceChars: 200 } });
    expect(t.host.run('a', 'res://scripts/boss.ts')).toMatchObject({ ok: false, code: 'script.ts_not_supported' });
    expect(t.host.run('a', 'res://x/boss.js')).toMatchObject({ ok: false, code: 'script.invalid_path' });
    expect(t.host.run('a', 'res://scripts/nao-existe.js')).toMatchObject({ ok: false, code: 'script.not_found' });
    expect(t.host.run('a', 'res://scripts/mover.js')).toMatchObject({ ok: false, code: 'script.too_large' });
    expect(t.factory.workers).toHaveLength(0); // nada foi criado
  });

  it('sem Worker no ambiente: erro com código, nunca exceção', () => {
    const t = setup({
      createWorker: () => {
        throw new Error('sem Worker');
      },
    });
    expect(t.host.run('a', 'res://scripts/solo.js')).toMatchObject({ ok: false, code: 'script.worker_unavailable' });
  });
});

describe('isolamento de falha: o script quebra, o Play segue', () => {
  it('exceção no script marca o script como erro no nó dono, encerra o Worker e revoga a URL; os outros seguem', async () => {
    const t = setup();
    t.host.attach('a', 'res://scripts/quebra.js');
    t.host.attach('b', 'res://scripts/mover.js');
    await settle();
    for (let i = 0; i < 4; i++) {
      t.host.tick(0.016);
      await settle();
    }
    expect(t.reports).toEqual([expect.objectContaining({ severity: 'error', code: 'script.exception', nodeId: 'a' })]);
    expect(t.host.stateOf('a', 'res://scripts/quebra.js')).toBe('failed');
    expect(t.factory.workers[0].terminated).toBe(true);
    expect(t.revoked.length).toBe(1);
    expect(t.host.stateOf('b', 'res://scripts/mover.js')).toBe('ready');
    expect(t.applied.some((x) => x.startsWith('transform:b:'))).toBe(true);
    // run_script em script falho: recusa clara, sem reviver
    expect(t.host.run('a', 'res://scripts/quebra.js')).toMatchObject({ ok: false, code: 'script.failed' });
    t.host.dispose();
  });

  it('módulo com erro de sintaxe ou sem função de entrada vira erro de carga (nunca exceção no host)', async () => {
    const t = setup();
    t.host.attach('a', 'res://scripts/sintaxe.js');
    t.host.attach('b', 'res://scripts/vazio.js');
    await settle();
    expect(t.reports.map((r) => [r.nodeId, r.code]).sort()).toEqual([['a', 'script.load_failed'], ['b', 'script.no_entry']]);
    t.host.dispose();
  });
});

describe('Command Buffer: o host valida o que volta do Worker', () => {
  it('comando inválido é recusado com aviso (uma vez), o válido do mesmo buffer é aplicado; alvo recusado também avisa', async () => {
    const t = setup();
    t.host.attach('a', 'res://scripts/ma-fe.js');
    await settle();
    for (let i = 0; i < 4; i++) {
      t.host.tick(0.016);
      await settle();
    }
    expect(t.reports.some((r) => r.code === 'script.exception')).toBe(true); // engine.nodes.get('x').y.z lançou: o buffer dessa chamada se perde
    t.host.dispose();

    const forged = setup();
    forged.host.attach('a', 'res://scripts/mover.js');
    await settle();
    // o Worker "responde" com um comando malicioso e um válido
    const w = forged.factory.workers[0];
    forged.host.tick(0.016); // a chamada sai; a resposta REAL ainda não chegou — o Worker (malicioso) responde antes, com um buffer forjado
    const call = w.received.find((m) => m.t === 'call')!;
    w.forge({ t: 'done', id: (call as { id: number }).id, ms: 1, commands: [{ op: 'fs.write', path: 'C:/x' }, { op: 'log', level: 'info', message: 'ok' }] });
    forged.host.tick(0.016);
    expect(forged.applied).toContain('log:a:info:[mover.js] ok');
    expect(forged.applied.some((x) => x.includes('fs.write'))).toBe(false);
    expect(forged.reports.filter((r) => r.code === 'script.command_rejected')).toHaveLength(1);
    forged.host.dispose();
  });

  it('teto de comandos por quadro: avisa e descarta o excesso', async () => {
    const t = setup();
    t.host.attach('a', 'res://scripts/spam.js');
    await settle();
    for (let i = 0; i < 5; i++) {
      t.host.tick(0.016);
      await settle();
    }
    expect(t.reports.filter((r) => r.code === 'script.command_overflow')).toHaveLength(1);
    expect(t.applied.filter((x) => x.startsWith('log:')).length % 256).toBe(0);
    t.host.dispose();
  });

  it('alvo que recusa o comando (nó inexistente) gera aviso único', async () => {
    const t = setup({
      readSource: (p) => (p === 'res://scripts/alvo.js' ? `export function onUpdate(e) { e.transform.set('sumiu', { position: [1, 1, 1] }); }` : null),
    });
    t.host.attach('a', 'res://scripts/alvo.js');
    await settle();
    for (let i = 0; i < 5; i++) {
      t.host.tick(0.016);
      await settle();
    }
    expect(t.reports.filter((r) => r.code === 'script.command_failed')).toHaveLength(1);
    t.host.dispose();
  });
});

describe('limites: timeout e orçamento por quadro', () => {
  it('chamada que não responde em callTimeoutMs: o Worker é ENCERRADO, o script marcado com erro e o host segue', async () => {
    const t = setup();
    t.host.attach('a', 'res://scripts/lento.js');
    await settle();
    // o Worker "trava": ignora as chamadas
    t.factory.workers[0].postMessage = () => {};
    t.host.tick(0.016);
    const watchdog = t.timers.filter((x) => !x.cleared).pop()!;
    expect(watchdog.ms).toBe(100);
    watchdog.fn(); // o relógio de parede estourou
    expect(t.reports).toEqual([expect.objectContaining({ severity: 'error', code: 'script.timeout', nodeId: 'a' })]);
    expect(t.factory.workers[0].terminated).toBe(true);
    expect(t.host.stateOf('a', 'res://scripts/lento.js')).toBe('failed');
    expect(() => t.host.tick(0.016)).not.toThrow(); // o Play segue
    t.host.dispose();
  });

  it('script que não carrega a tempo também é encerrado (script.timeout)', () => {
    const t = setup();
    t.host.attach('a', 'res://scripts/lento.js');
    const loadTimer = t.timers[0];
    expect(loadTimer.ms).toBeGreaterThanOrEqual(1000);
    loadTimer.fn();
    expect(t.reports[0]).toMatchObject({ code: 'script.timeout', nodeId: 'a' });
    t.host.dispose();
  });

  it('estourar o orçamento de quadro por N quadros seguidos encerra o Worker; um pico isolado só avisa', async () => {
    const t = setup({ limits: { frameBudgetMs: 8, overBudgetStrikes: 3 } });
    t.host.attach('a', 'res://scripts/lento.js');
    await settle();
    t.host.tick(0.016); // onReady
    await settle();
    const w = t.factory.workers[0];
    const answer = (ms: number) => {
      const last = [...w.received].reverse().find((m) => m.t === 'call') as { id: number } | undefined;
      w.forge({ t: 'done', id: last!.id, ms, commands: [] });
    };
    // onReady já respondeu por si; agora três quadros caros seguidos
    t.host.tick(0.016);
    await settle();
    answer(20); // 1º estouro: aviso
    t.host.tick(0.016);
    answer(20); // 2º
    expect(t.reports.map((r) => r.code)).toEqual(['script.slow']);
    answer(1); // volta ao normal: zera a contagem
    t.host.tick(0.016);
    answer(20);
    t.host.tick(0.016);
    answer(20);
    t.host.tick(0.016);
    answer(20); // 3 seguidos
    expect(t.reports.map((r) => r.code)).toContain('script.over_budget');
    expect(t.factory.workers[0].terminated).toBe(true);
    t.host.dispose();
  });
});

describe('mensagens do Worker são não confiáveis', () => {
  it('ruído e respostas sem chamada correspondente são ignorados (nada é aplicado)', async () => {
    const t = setup();
    t.host.attach('a', 'res://scripts/mover.js');
    await settle();
    const w = t.factory.workers[0];
    w.forge(null);
    w.forge('texto');
    w.forge({ t: 'done', id: 9999, ms: 0, commands: [{ op: 'log', level: 'info', message: 'forjado' }] });
    w.forge({ t: 'qualquer' });
    t.host.tick(0.016);
    expect(t.applied).toEqual([]);
    expect(t.reports).toEqual([]);
    t.host.dispose();
  });

  it('erro não tratado do Worker (onerror) marca o script como falho', async () => {
    const t = setup();
    t.host.attach('a', 'res://scripts/mover.js');
    await settle();
    t.factory.workers[0].onerror?.({ message: 'crash' });
    expect(t.reports[0]).toMatchObject({ code: 'script.crashed', nodeId: 'a' });
    t.host.dispose();
  });
});

describe('descarte (Stop, restart, troca de cena)', () => {
  it('dispose encerra TODOS os Workers, revoga as URLs e ignora o que vier depois', async () => {
    const t = setup();
    t.host.attach('a', 'res://scripts/mover.js');
    t.host.run('b', 'res://scripts/solo.js');
    await settle();
    t.host.dispose();
    expect(t.factory.workers.every((w: FakeWorker) => w.terminated)).toBe(true);
    expect(t.revoked).toHaveLength(2);
    expect(t.host.activeCount).toBe(0);
    expect(() => t.host.tick(0.016)).not.toThrow();
    expect(t.host.run('a', 'res://scripts/solo.js')).toMatchObject({ ok: false, code: 'script.session_ended' });
  });
});
