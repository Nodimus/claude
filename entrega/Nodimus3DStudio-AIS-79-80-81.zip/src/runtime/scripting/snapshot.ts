import type { VariableManager } from '../../core/variableManager';
import type { RuntimeInstance } from '../RuntimeScene';
import type { RawInputReader } from '../input/inputTriggers';
import type { ScriptLimits } from './limits';
import type { ScriptInputState, ScriptNodeSnapshot, ScriptSnapshot, ScriptValue } from './protocol';

/**
 * AIS-79 — snapshot SOMENTE-LEITURA do mundo, enviado ao Worker a cada chamada. Só dados serializáveis (nunca instância viva, `Object3D`, Rapier ou
 * store). Construído no host a partir da cena viva; o Worker o lê sem poder alterá-lo (escrever = enfileirar comando, validado pelo host).
 */

export interface SnapshotSources {
  time: number;
  frame: number;
  instances: Iterable<RuntimeInstance>;
  variables: VariableManager | null;
  input: RawInputReader & { actions?: () => string[]; getActionStrength?: (action: string) => number };
  /** Nomes de ação lidos do mapa de entrada do projeto (o leitor sem `actions()` usa esta lista). */
  actionNames: readonly string[];
}

const isScriptValue = (v: unknown): v is ScriptValue => typeof v === 'boolean' || typeof v === 'string' || (typeof v === 'number' && Number.isFinite(v));

export function buildScriptSnapshot(src: SnapshotSources, limits: Pick<ScriptLimits, 'maxSnapshotNodes'>): { snapshot: ScriptSnapshot; truncated: boolean } {
  const nodes: Record<string, ScriptNodeSnapshot> = {};
  const local: Record<string, Record<string, ScriptValue>> = {};
  let count = 0;
  let truncated = false;
  for (const i of src.instances) {
    if (i.disposed) continue;
    if (count >= limits.maxSnapshotNodes) {
      truncated = true;
      break;
    }
    count++;
    nodes[i.persistentNodeId] = {
      id: i.persistentNodeId,
      name: i.name,
      type: String(i.type),
      tags: [...i.tags],
      visible: i.visible,
      parentId: i.parent?.persistentNodeId ?? null,
      transform: { position: [...i.transform.position] as [number, number, number], rotation: [...i.transform.rotation] as [number, number, number], scale: [...i.transform.scale] as [number, number, number] },
    };
    const vars = src.variables?.listLocals(i.persistentNodeId) ?? [];
    if (vars.length) {
      const record: Record<string, ScriptValue> = {};
      for (const v of vars) if (isScriptValue(v.value)) record[v.name] = v.value;
      if (Object.keys(record).length) local[i.persistentNodeId] = record;
    }
  }
  const global: Record<string, ScriptValue> = {};
  for (const v of src.variables?.listGlobals() ?? []) if (isScriptValue(v.value)) global[v.name] = v.value;

  const names = new Set<string>(typeof src.input.actions === 'function' ? src.input.actions() : src.actionNames);
  const input: Record<string, ScriptInputState> = {};
  for (const name of names) {
    const pressed = src.input.isActionPressed(name);
    input[name] = {
      pressed,
      justPressed: src.input.isActionJustPressed(name),
      justReleased: src.input.isActionJustReleased(name),
      strength: typeof src.input.getActionStrength === 'function' ? src.input.getActionStrength(name) : pressed ? 1 : 0,
    };
  }
  return { snapshot: { time: src.time, frame: src.frame, nodes, variables: { global, local }, input }, truncated };
}
