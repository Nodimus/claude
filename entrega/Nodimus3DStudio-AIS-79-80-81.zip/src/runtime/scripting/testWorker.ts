import { resolveObjectURL } from 'node:buffer';
import { createScriptWorkerCore } from './workerCore';
import type { HostToWorker, WorkerToHost } from './protocol';
import type { WorkerLike } from './ScriptHost';

/**
 * AIS-79 — dublê de Worker para os testes (Node): roda o MESMO `createScriptWorkerCore` do Worker real, no mesmo processo, com clone estruturado nas
 * duas direções (como `postMessage`). O módulo do usuário vem do texto da URL `blob:` criada pelo host (`createObjectURL`), importado como
 * `data:` URL — ou seja, o código-fonte do script roda DE VERDADE (ESM), só que sem o isolamento do thread. Não é importado pelo app.
 */

export class FakeWorker implements WorkerLike {
  onmessage: ((event: { data: unknown }) => void) | null = null;
  onerror: ((event: { message?: string }) => void) | null = null;
  terminated = false;
  readonly received: HostToWorker[] = [];
  private readonly handle: (message: HostToWorker) => Promise<void>;

  constructor(importer: (url: string) => Promise<Record<string, unknown>> = importFromBlobUrl) {
    this.handle = createScriptWorkerCore({
      post: (message: WorkerToHost) => {
        if (this.terminated) return;
        const copy = structuredClone(message);
        queueMicrotask(() => this.onmessage?.({ data: copy }));
      },
      importModule: importer,
    });
  }

  postMessage(message: HostToWorker): void {
    if (this.terminated) return;
    this.received.push(message);
    void this.handle(structuredClone(message));
  }

  terminate(): void {
    this.terminated = true;
  }

  /** Simula uma mensagem arbitrária (forjada) do Worker para o host. */
  forge(data: unknown): void {
    this.onmessage?.({ data });
  }
}

/** Importa o módulo do usuário a partir da URL `blob:` do host (o texto do script vira uma URL `data:`). */
export async function importFromBlobUrl(url: string): Promise<Record<string, unknown>> {
  const blob = resolveObjectURL(url);
  if (!blob) throw new Error('URL de módulo desconhecida');
  const text = await blob.text();
  return (await import(/* @vite-ignore */ `data:text/javascript;base64,${Buffer.from(text, 'utf8').toString('base64')}`)) as Record<string, unknown>;
}

/** Fábrica que guarda os Workers criados (para os testes inspecionarem/forjarem). */
export function fakeWorkerFactory(importer?: (url: string) => Promise<Record<string, unknown>>): { create: () => FakeWorker; workers: FakeWorker[] } {
  const workers: FakeWorker[] = [];
  return {
    workers,
    create: () => {
      const worker = new FakeWorker(importer);
      workers.push(worker);
      return worker;
    },
  };
}

/** Deixa as microtarefas e o `import()` assíncrono terminarem. */
export async function settle(rounds = 8): Promise<void> {
  for (let i = 0; i < rounds; i++) await new Promise<void>((resolve) => setTimeout(resolve, 0));
}
