import { describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { RuntimeSession } from './RuntimeSession';
import type { LogicLogEntry } from './logicRunner';
import { fakeWorkerFactory, settle } from './scripting/testWorker';

/** AIS-79 — o sandbox na sessão de Play: script anexado a nó e Action `run_script` pelo MESMO mecanismo, efeitos com 1 quadro de latência, falha isolada, Stop. */

let seq = 0;
const act = (type: string, parameters: Record<string, unknown> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[]): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters: {}, conditions: [], actions });
const behavior = (...rules: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'Regras', behaviorType: 'custom_rules', enabled: true, properties: {}, rules });
const node = (id: string, extra: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type: 'Spatial', parentId: null, childrenIds: [], visible: true, locked: false, properties: {}, ...extra }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes = { ...scene.nodes };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  nodes[root.id] = { ...root, childrenIds: [...root.childrenIds, ...extra.map((n) => n.id)] };
  return { ...scene, nodes } as unknown as SceneData;
}

const input = { isActionPressed: (a: string) => a === 'Jump', isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false, actions: () => ['Jump'] } as never;

const SCRIPTS: Record<string, string> = {
  'res://scripts/pular.js': `export function onUpdate(engine, dt) {
  if (engine.input.isPressed('Jump')) {
    const p = engine.transform.get(engine.self).position;
    engine.transform.set(engine.self, { position: [p[0], p[1] + 1, p[2]] });
  }
}`,
  'res://scripts/pontuar.js': `export function run(engine) { engine.variables.set('global', 'pontos', engine.variables.get('global', 'pontos') + 10); engine.signals.emit('pontuou'); }`,
  'res://scripts/quebra.js': `export function onUpdate() { throw new Error('boom'); }`,
  'res://scripts/hostil.js': `export function onUpdate(engine) {
  engine.transform.set(engine.self, { position: [Number.NaN, 0, 0] });
  engine.variables.set('global', 'pontos', { a: 1 });
  engine.log('info', 'vivo');
}`,
  'res://scripts/nao-clona.js': `export function onUpdate(engine) { engine.signals.emit('x', [() => 1]); }`,
  'res://scripts/trava.js': `export function onUpdate() { return new Promise(() => {}); }`,
};

function play(scene: SceneData, options: { limits?: Record<string, number> } = {}) {
  const diagnostics = new DiagnosticService();
  const logs: LogicLogEntry[] = [];
  const factory = fakeWorkerFactory();
  const session = new RuntimeSession({
    snapshot: createRuntimeSnapshot(scene),
    input,
    diagnostics,
    globals: [{ name: 'pontos', type: 'number', value: 0 }],
    onLog: (e) => logs.push(e),
    readScript: (path) => SCRIPTS[path] ?? null,
    createScriptWorker: factory.create,
    scriptLimits: options.limits,
  });
  session.start();
  const signals: string[] = [];
  session.signalBus.connect({ signal: 'pontuou', listener: (e) => void signals.push(e.signal) });
  return { session, diagnostics, logs, factory, signals, codes: () => diagnostics.list({ ephemeral: true }).map((d) => d.code) };
}

/** Passos de 1/60 s; entre eles o Worker (assíncrono) responde. */
async function run(session: RuntimeSession, frames: number): Promise<void> {
  for (let i = 0; i < frames; i++) {
    session.step(1 / 60);
    await settle(3);
  }
}
const posY = (s: RuntimeSession, id: string) => s.getSimulatedTransform(id)!.position[1];

describe('script anexado a um nó (GameNode.script)', () => {
  it('roda no Worker com o nó dono: lê a ação lógica e move o nó (só o runtime; o authoring não muda)', async () => {
    const hero = node('hero', { script: 'res://scripts/pular.js', transform: { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] } as never });
    const t = play(sceneWith(hero));
    await settle();
    await run(t.session, 12);
    expect(posY(t.session, 'hero')).toBeGreaterThan(3); // vários quadros com "Jump" pressionado
    expect((t.session.snapshot.nodes.hero as { transform?: { position: number[] } }).transform?.position[1] ?? 0).toBe(0); // authoring intocado
    expect(t.codes()).toEqual([]);
    t.session.dispose();
  });

  it('o Stop descarta tudo: Workers encerrados e diagnósticos efêmeros limpos', async () => {
    const t = play(sceneWith(node('hero', { script: 'res://scripts/quebra.js' })));
    await settle();
    await run(t.session, 4);
    expect(t.codes()).toContain('script.exception');
    t.session.dispose();
    expect(t.factory.workers.every((w) => w.terminated)).toBe(true);
    expect(t.diagnostics.list({ ephemeral: true })).toEqual([]);
  });

  it('script que lança exceção é marcado com erro NO NÓ; o Play e os outros scripts seguem', async () => {
    const t = play(sceneWith(node('a', { script: 'res://scripts/quebra.js' }), node('b', { script: 'res://scripts/pular.js', transform: { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] } as never })));
    await settle();
    await run(t.session, 10);
    const d = t.diagnostics.list({ ephemeral: true }).find((x) => x.code === 'script.exception')!;
    expect(d).toMatchObject({ severity: 'error', phase: 'script', nodeId: 'a' });
    expect(posY(t.session, 'b')).toBeGreaterThan(2);
    t.session.dispose();
  });

  it('comandos hostis (NaN, objeto como valor de variável) são recusados pelo host; o comando válido do mesmo buffer segue', async () => {
    const t = play(sceneWith(node('a', { script: 'res://scripts/hostil.js', transform: { position: [1, 2, 3], rotation: [0, 0, 0], scale: [1, 1, 1] } as never })));
    await settle();
    await run(t.session, 6);
    expect(t.session.getSimulatedTransform('a')!.position).toEqual([1, 2, 3]);
    expect(t.codes()).toContain('script.command_rejected');
    expect(t.logs.some((l) => l.message.includes('vivo'))).toBe(true);
    t.session.dispose();
  });

  it('resultado que não é serializável (função em args) vira erro do script, nunca exceção solta', async () => {
    const t = play(sceneWith(node('a', { script: 'res://scripts/nao-clona.js' })));
    await settle();
    await run(t.session, 4);
    expect(t.codes()).toContain('script.invalid_result');
    t.session.dispose();
  });

  it('script anexado que não é .js de res://scripts/ (.ts, inline) vira aviso, não executa', async () => {
    const t = play(sceneWith(node('a', { script: 'res://scripts/boss.ts' }), node('b', { script: 'console.log(1)' })));
    await settle();
    expect(t.codes().filter((c) => c === 'script.invalid_path')).toHaveLength(2);
    expect(t.factory.workers).toHaveLength(0);
    t.session.dispose();
  });
});

describe('Action run_script (mesmo mecanismo, dono = o nó da regra)', () => {
  it('executa o script UMA vez pelo Worker; o efeito (variável + sinal) chega no quadro seguinte', async () => {
    const t = play(sceneWith(node('n', { behaviors: [behavior(rule('on_start', [act('run_script', { scriptRef: 'res://scripts/pontuar.js' })]))] })));
    await settle();
    await run(t.session, 6);
    expect(t.session.variables?.getVariable('global', 'pontos')).toBe(10); // uma única execução
    expect(t.signals).toEqual(['pontuou']);
    expect(t.factory.workers).toHaveLength(1);
    t.session.dispose();
  });

  it('script inexistente: erro explícito com código estável no log, o Play segue', async () => {
    const t = play(sceneWith(node('n', { behaviors: [behavior(rule('on_start', [act('run_script', { scriptRef: 'res://scripts/nada.js' }), act('print_log', { text: 'seguiu' })]))] })));
    await settle();
    await run(t.session, 3);
    expect(t.logs.some((l) => l.level === 'error' && l.message.includes('script.not_found'.replace('script.not_found', 'não existe')))).toBe(true);
    expect(t.logs.some((l) => l.message.includes('seguiu'))).toBe(true);
    t.session.dispose();
  });

  it('.ts: erro explícito "em breve" (sem Worker criado)', async () => {
    const t = play(sceneWith(node('n', { behaviors: [behavior(rule('on_start', [act('run_script', { scriptRef: 'res://scripts/boss.ts' })]))] })));
    await run(t.session, 3);
    expect(t.logs.some((l) => l.level === 'error' && /\.ts/.test(l.message))).toBe(true);
    expect(t.factory.workers).toHaveLength(0);
    t.session.dispose();
  });
});

describe('limites na sessão', () => {
  it('callTimeoutMs ínfimo: script que não responde a tempo é encerrado e marcado com erro; o Play segue', async () => {
    const t = play(sceneWith(node('a', { script: 'res://scripts/trava.js' })), { limits: { callTimeoutMs: 20 } });
    await settle();
    t.session.step(1 / 60); // onReady (não exportado: nada) e onUpdate: o script devolve uma Promise que nunca resolve
    await settle(2);
    t.session.step(1 / 60);
    await new Promise((r) => setTimeout(r, 60)); // o relógio de parede estoura
    expect(t.diagnostics.list({ ephemeral: true }).find((d) => d.code === 'script.timeout')).toMatchObject({ severity: 'error', nodeId: 'a' });
    expect(t.factory.workers[0].terminated).toBe(true);
    expect(() => t.session.step(1 / 60)).not.toThrow(); // o Play segue
    t.session.dispose();
  });
});
