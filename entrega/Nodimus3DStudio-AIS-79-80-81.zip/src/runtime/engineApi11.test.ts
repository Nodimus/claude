import { describe, expect, it, vi } from 'vitest';
import { ENGINE_OPERATIONS, buildEngineApi, type EngineHost } from './engineApi';

/** AIS-78c (EngineApi 1.1) — sistemas endereçados por nó (audio, partículas, animação, sprites, tweens, cena) e consultas espaciais, com host injetado. */

const inst = (id: string, extra: Record<string, unknown> = {}) =>
  ({ persistentNodeId: id, name: id, type: 'Spatial', disposed: false, tags: [], visible: true, parent: null, properties: {}, transform: { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] }, ...extra }) as never;

function hostWith(extra: Partial<EngineHost> = {}, nodes: Record<string, unknown> = { a: inst('a') }): EngineHost {
  const noop = () => undefined;
  return {
    instanceById: (ref: string) => nodes[ref] as never,
    instanceByName: () => undefined,
    variables: () => null,
    input: () => ({}) as never,
    physics: () => null,
    sceneTime: () => 0,
    emitSignal: noop,
    connectSignal: () => noop,
    onPhysicsEvent: () => noop,
    log: noop,
    commitTransform: noop,
    ...extra,
  } as EngineHost;
}

describe('serviço ausente = falha com código estável, nunca silêncio', () => {
  const api = buildEngineApi(hostWith(), null);
  it('audio / particles / animation / tweens', () => {
    expect(api.audio.play('a', { path: 'x.ogg' })).toMatchObject({ ok: false, code: 'audio.unavailable' });
    expect(api.audio.stop('a')).toMatchObject({ ok: false, code: 'audio.unavailable' });
    expect(buildEngineApi(hostWith({}, { p: inst('p', { type: 'ParticleSystem' }) }), null).particles.burst('p', 3)).toMatchObject({ ok: false, code: 'particles.unavailable' });
    expect(api.animation.play('a', 'Walk')).toMatchObject({ ok: false, code: 'animation.unavailable' });
    expect(api.tweens.stop('a')).toMatchObject({ ok: false, code: 'tweens.unavailable' });
  });
  it('nó inexistente: falha própria, não indisponibilidade', () => {
    const r = api.audio.play('nada', { path: 'x.ogg' });
    expect(r.ok).toBe(false);
    expect((r as { code: string }).code).not.toBe('audio.unavailable');
  });
  it('sprites sem host mantém o código estável do AIS-76b', () => {
    const b = buildEngineApi(hostWith({}, { s: inst('s', { type: 'Billboard', properties: { spriteProject: { id: 'r' } } }) }), null);
    expect(b.sprites.play('s', { animation: 'idle' })).toMatchObject({ ok: false, code: 'sprite.unavailable' });
    expect(b.sprites.clipNames('s')).toEqual([]);
  });
});

describe('serviços presentes', () => {
  it('audio.play entrega o emissor e os parâmetros ao SoundHost; stop/setProperties devolvem a contagem', () => {
    const played: unknown[] = [];
    const audio = { play: (spec: unknown) => (played.push(spec), null), stop: vi.fn(() => 2), setProperties: vi.fn(() => 1) };
    const api = buildEngineApi(hostWith({ audio: () => audio as never }), null);
    expect(api.audio.play('a', { path: 'x.ogg', volume: 0.5 })).toEqual({ ok: true });
    expect(played[0]).toMatchObject({ emitterId: 'a', path: 'x.ogg', volume: 0.5, pitch: 1, spatial: true });
    expect(api.audio.stop('a')).toEqual({ ok: true, count: 2 });
    expect(api.audio.setProperties('a', { volume: 0.2 })).toEqual({ ok: true, count: 1 });
  });

  it('erro textual do host vira falha com o código do sistema', () => {
    const audio = { play: () => 'arquivo não encontrado', stop: () => 0, setProperties: () => 0 };
    const api = buildEngineApi(hostWith({ audio: () => audio as never }), null);
    expect(api.audio.play('a', { path: 'x' })).toMatchObject({ ok: false, code: 'audio.play_failed', message: 'arquivo não encontrado' });
  });

  it('tweens.start converte onCompleteSignal em callback que emite o sinal', () => {
    const emitted: string[] = [];
    let captured: { onComplete?: () => void } = {};
    const tweens = { start: (_n: unknown, req: { onComplete?: () => void }) => ((captured = req), null), stop: () => 0 };
    const api = buildEngineApi(hostWith({ tweens: () => tweens as never, emitSignal: (n: string) => void emitted.push(n) }), null);
    expect(api.tweens.start('a', { property: 'position.x', to: 1, duration: 1, onCompleteSignal: 'fim' } as never)).toEqual({ ok: true });
    captured.onComplete?.();
    expect(emitted).toEqual(['fim']);
  });

  it('scene.* pede à sessão; destroy só devolve true para nó vivo', () => {
    const requests: unknown[] = [];
    const destroyed: string[] = [];
    const api = buildEngineApi(hostWith({ sceneRequest: (r) => void requests.push(r), destroy: (i) => void destroyed.push(i.persistentNodeId) }), null);
    api.scene.restart();
    api.scene.quit();
    api.scene.change('res://scenes/b.scene.json');
    expect(requests).toEqual([{ kind: 'restart' }, { kind: 'quit' }, { kind: 'change', path: 'res://scenes/b.scene.json' }]);
    expect(api.scene.destroy('a')).toBe(true);
    expect(api.scene.destroy('nada')).toBe(false);
    expect(destroyed).toEqual(['a']);
  });

  it('transform.setWorldPosition valida números finitos antes de chamar o host', () => {
    const set = vi.fn();
    const api = buildEngineApi(hostWith({ setWorldPosition: set }), null);
    expect(api.transform.setWorldPosition('a', { x: 1, y: 2, z: 3 })).toBe(true);
    expect(api.transform.setWorldPosition('a', { x: Number.NaN, y: 0, z: 0 })).toBe(false);
    expect(api.transform.setWorldPosition('nada', { x: 0, y: 0, z: 0 })).toBe(false);
    expect(set).toHaveBeenCalledTimes(1);
  });

  it('after delega a agenda de tempo de jogo do host', () => {
    const after = vi.fn();
    const fn = () => undefined;
    buildEngineApi(hostWith({ after }), null).after(1.5, fn);
    expect(after).toHaveBeenCalledWith(1.5, fn);
  });
});

describe('consultas espaciais (raycast / overlapSphere)', () => {
  it('sem mundo físico: falha com código, nunca null silencioso', () => {
    const api = buildEngineApi(hostWith(), null);
    expect(api.raycast({ x: 0, y: 0, z: 0 }, { x: 0, y: -1, z: 0 })).toMatchObject({ ok: false, code: 'physics.no_world' });
    expect(api.overlapSphere({ x: 0, y: 0, z: 0 }, 2)).toMatchObject({ ok: false, code: 'physics.no_world' });
  });

  it('com a ponte: devolve o acerto; erro da ponte vira falha com o código dela', () => {
    const bridge = {
      raycast: vi.fn(() => ({ nodeId: 'a', distance: 3 })),
      overlapSphere: vi.fn(() => {
        throw Object.assign(new Error('raio inválido'), { code: 'physics.bad_radius' });
      }),
    };
    const api = buildEngineApi(hostWith({ physics: () => bridge as never }), null);
    expect(api.raycast({ x: 0, y: 5, z: 0 }, { x: 0, y: -1, z: 0 })).toEqual({ ok: true, hit: { nodeId: 'a', distance: 3 } });
    expect(api.overlapSphere({ x: 0, y: 0, z: 0 }, -1)).toMatchObject({ ok: false, code: 'physics.bad_radius' });
  });
});

describe('catálogo 1.1', () => {
  it('as operações novas declaram versão 1.1 e as de 1.0 continuam 1.0', () => {
    const since = (id: string) => ENGINE_OPERATIONS.find((o) => o.id === id)?.since;
    for (const id of ['audio.play', 'particles.burst', 'animation.play', 'sprites.play', 'tweens.start', 'scene.destroy', 'physics.raycast', 'time.after']) expect(since(id), id).toBe('1.1');
    for (const id of ['nodes.get', 'transform.set', 'signals.emit']) expect(since(id), id).toBe('1.0');
  });
});
