import { clipFinishedAt, clipLoopsAt, clipPositionAtTime, clipStartMsOfPosition, type ClipInput } from './sprite';

/**
 * AIS-76 — estado de reprodução dos `Billboard` animados no Play (o `AnimatedSprite3D` do Godot). Mora na `RuntimeSession` (descartável:
 * restart, troca de cena e Stop o limpam; nunca vai ao authoring) e é PURO — sem Three, sem DOM. O tempo de cada clipe vem SEMPRE de
 * `clipFrameIndexAtTime`/`clipPositionAtTime` (`runtime/sprite.ts`, decisão 24): nenhuma lógica de frame inline.
 *
 * Quem sabe quais clipes existem (carrega o `.sprite.json`) e desenha o quadro é o apresentador da viewport
 * (`components/viewports/viewportSprites.ts`): ele registra aqui os clipes do nó, sincroniza `animation`/`speedScale`/`frame`/`autoplay`
 * das propriedades vivas e lê `frameOf()` a cada quadro. Os eventos viram sinais no `SignalBus` da sessão
 * (`frame_changed`, `animation_looped`, `animation_finished` — este só em clipes `once`).
 */

export interface SpriteClipInfo extends ClipInput {
  name: string;
}

export interface SpriteRegistration {
  clips: readonly SpriteClipInfo[];
  /** Nome da animação do nó; vazio/ausente/desconhecido = a animação padrão do recurso. */
  animation?: string;
  /** Animação padrão do recurso (`activeAnimationId` resolvido para nome). */
  defaultAnimation?: string;
  /** `speedScale` do nó (1 = normal). */
  speedScale?: number;
  /** `autoplay`: toca já no registro. Falso = parado no `frame` do nó. */
  autoplay?: boolean;
  /** `frame` do nó: POSIÇÃO dentro da animação (como o `frame` do Godot), usada quando parado. */
  frame?: number;
  /** Quantos quadros o atlas tem (limite do `set_sprite_frame`); ausente = sem clamp superior. */
  frameCount?: number;
}

export type SpriteEventName = 'frame_changed' | 'animation_looped' | 'animation_finished';

export interface SpriteEvent {
  nodeId: string;
  name: SpriteEventName;
  clip: string;
  /** Índice GLOBAL do frame no atlas ativo no momento do evento. */
  frame: number;
}

interface Entry {
  clips: readonly SpriteClipInfo[];
  defaultAnimation: string;
  clip: SpriteClipInfo | null;
  elapsedMs: number;
  speedScale: number;
  playing: boolean;
  /** Posição manual (parado). */
  manualPosition: number;
  /** Último valor da propriedade `frame` do nó aplicado (só reaplica quando ela muda). */
  propFrame: number;
  /** Frame GLOBAL mostrado por `set_sprite_frame` enquanto parado (`null` = vale a posição manual/o relógio). */
  manualGlobal: number | null;
  frameCount: number;
  lastPosition: number;
  loopsSeen: number;
  finished: boolean;
}

const finiteOr = (v: unknown, fallback: number): number => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);

export class SpriteHost {
  private readonly entries = new Map<string, Entry>();
  /** Pedidos das Actions feitos ANTES de o sprite carregar: rodam no `register` do nó. */
  private readonly pending = new Map<string, (() => void)[]>();
  private events: SpriteEvent[] = [];

  /** Regista (ou re-regista) o sprite de um nó. Re-registrar recomeça a reprodução. */
  register(nodeId: string, registration: SpriteRegistration): void {
    const entry: Entry = {
      clips: registration.clips,
      defaultAnimation: registration.defaultAnimation ?? registration.clips[0]?.name ?? '',
      clip: null,
      elapsedMs: 0,
      speedScale: Math.max(0, finiteOr(registration.speedScale, 1)),
      playing: registration.autoplay !== false,
      manualPosition: Math.max(0, Math.floor(finiteOr(registration.frame, 0))),
      propFrame: Math.max(0, Math.floor(finiteOr(registration.frame, 0))),
      manualGlobal: null,
      frameCount: Math.max(0, Math.floor(finiteOr(registration.frameCount, 0))),
      lastPosition: -1,
      loopsSeen: 0,
      finished: false,
    };
    this.entries.set(nodeId, entry);
    this.select(entry, registration.animation);
    entry.lastPosition = this.positionOf(entry);
    const queued = this.pending.get(nodeId);
    if (queued) {
      this.pending.delete(nodeId);
      for (const fn of queued) fn();
    }
  }

  /** Adia `fn` até o sprite do nó ser registrado (Actions em `on_start`, antes da primeira apresentação). */
  defer(nodeId: string, fn: () => void): void {
    const list = this.pending.get(nodeId) ?? [];
    if (list.length < 16) list.push(fn);
    this.pending.set(nodeId, list);
  }

  unregister(nodeId: string): void {
    this.entries.delete(nodeId);
  }

  clear(): void {
    this.entries.clear();
    this.pending.clear();
    this.events = [];
  }

  has(nodeId: string): boolean {
    return this.entries.has(nodeId);
  }

  /** Nome da animação ativa do nó (`''` se não há clipes). */
  animationOf(nodeId: string): string {
    return this.entries.get(nodeId)?.clip?.name ?? '';
  }

  isPlaying(nodeId: string): boolean {
    return this.entries.get(nodeId)?.playing ?? false;
  }

  private select(entry: Entry, name: string | undefined): boolean {
    const wanted = (name ?? '').trim();
    const found = (wanted ? entry.clips.find((c) => c.name === wanted) : undefined) ?? entry.clips.find((c) => c.name === entry.defaultAnimation) ?? entry.clips[0] ?? null;
    entry.clip = found;
    entry.elapsedMs = 0;
    entry.loopsSeen = 0;
    entry.finished = false;
    entry.manualGlobal = null;
    return !wanted || found?.name === wanted;
  }

  /**
   * Troca o clipe (recomeça do zero). `''` volta à animação padrão. Nome desconhecido: devolve `false` e cai na padrão (o apresentador avisa).
   * Trocar para o MESMO clipe não reinicia (as propriedades vivas são sincronizadas a cada quadro).
   */
  setAnimation(nodeId: string, name: string): boolean {
    const entry = this.entries.get(nodeId);
    if (!entry) return false;
    const wanted = name.trim();
    if (wanted && entry.clip?.name === wanted) return true;
    if (!wanted && entry.clip?.name === entry.defaultAnimation) return true;
    const ok = this.select(entry, name);
    entry.lastPosition = this.positionOf(entry);
    if (ok) entry.playing = true;
    return ok;
  }

  setSpeedScale(nodeId: string, speedScale: number): void {
    const entry = this.entries.get(nodeId);
    if (entry) entry.speedScale = Math.max(0, finiteOr(speedScale, 1));
  }

  play(nodeId: string): void {
    const entry = this.entries.get(nodeId);
    if (!entry || !entry.clip) return;
    entry.manualGlobal = null;
    if (entry.finished) {
      entry.elapsedMs = 0;
      entry.loopsSeen = 0;
      entry.finished = false;
    }
    entry.playing = true;
  }

  pause(nodeId: string): void {
    const entry = this.entries.get(nodeId);
    if (entry) entry.playing = false;
  }

  /** Parado: mostra a POSIÇÃO `frame` da animação (clamp ao tamanho). Só reaplica quando o valor da propriedade MUDA (não apaga o `set_sprite_frame`). */
  setFrame(nodeId: string, position: number): void {
    const entry = this.entries.get(nodeId);
    if (!entry) return;
    const next = Math.max(0, Math.floor(finiteOr(position, 0)));
    if (next === entry.propFrame) return;
    entry.propFrame = next;
    entry.manualPosition = next;
    entry.manualGlobal = null;
  }

  /** Nomes das animações do sprite do nó (vazio se o nó não está registrado). */
  clipNames(nodeId: string): string[] {
    return (this.entries.get(nodeId)?.clips ?? []).map((c) => c.name);
  }

  /**
   * AIS-76b — `play_sprite_animation` (o `AnimatedSprite3D.play` do Godot). Devolve `ok`, `unregistered` (nó sem sprite resolvido) ou
   * `unknown_animation` (nome que o recurso não tem; a animação atual continua). `restart: false` na MESMA animação não a reinicia (e um `once`
   * já terminado continua terminado); `fromEnd` começa pelo último quadro.
   */
  playClip(nodeId: string, opts: { animation?: string; restart?: boolean; speedScale?: number; fromEnd?: boolean }): 'ok' | 'unregistered' | 'unknown_animation' {
    const entry = this.entries.get(nodeId);
    if (!entry) return 'unregistered';
    const wanted = (opts.animation ?? '').trim();
    if (wanted && !entry.clips.some((c) => c.name === wanted)) return 'unknown_animation';
    const target = wanted || entry.defaultAnimation;
    const same = entry.clip?.name === target;
    const restart = opts.restart !== false;
    if (typeof opts.speedScale === 'number' && Number.isFinite(opts.speedScale)) entry.speedScale = Math.max(0, opts.speedScale);
    if (!same || restart) {
      this.select(entry, target);
      entry.manualGlobal = null;
      if (opts.fromEnd && entry.clip && entry.clip.frameIndices.length > 0) entry.elapsedMs = clipStartMsOfPosition(entry.clip, entry.clip.frameIndices.length - 1) + 1;
      entry.lastPosition = this.positionOf(entry);
      entry.playing = true;
    } else if (!entry.finished) {
      entry.manualGlobal = null;
      entry.playing = true;
    }
    return 'ok';
  }

  /**
   * AIS-76b — `set_sprite_frame`: mostra o frame GLOBAL `frame` (arredondado e clampado ao atlas). Com `pause` (padrão) para a reprodução;
   * sem `pause`, se o quadro está na animação ativa o relógio salta para ele e segue tocando.
   */
  showFrame(nodeId: string, frame: number, pause = true): { ok: boolean; frame: number } {
    const entry = this.entries.get(nodeId);
    if (!entry) return { ok: false, frame: -1 };
    const max = entry.frameCount > 0 ? entry.frameCount - 1 : Number.MAX_SAFE_INTEGER;
    const clamped = Math.min(max, Math.max(0, Math.round(finiteOr(frame, 0))));
    const pos = entry.clip ? entry.clip.frameIndices.indexOf(clamped) : -1;
    if (!pause && pos >= 0 && entry.clip) {
      entry.elapsedMs = clipStartMsOfPosition(entry.clip, pos) + 1;
      entry.manualGlobal = null;
      entry.finished = false;
      entry.playing = true;
    } else {
      entry.manualGlobal = clamped;
      entry.playing = false;
    }
    return { ok: true, frame: clamped };
  }

  private positionOf(entry: Entry): number {
    const clip = entry.clip;
    if (!clip || clip.frameIndices.length === 0) return -1;
    if (!entry.playing && !entry.finished) return Math.min(entry.manualPosition, clip.frameIndices.length - 1);
    return clipPositionAtTime(clip, entry.elapsedMs);
  }

  /** Índice GLOBAL do frame no atlas (`-1` = sem frame). */
  frameOf(nodeId: string): number {
    const entry = this.entries.get(nodeId);
    if (!entry) return -1;
    if (entry.manualGlobal !== null && !entry.playing) return entry.manualGlobal;
    if (!entry.clip) return -1;
    const pos = this.positionOf(entry);
    return pos < 0 ? -1 : entry.clip.frameIndices[pos];
  }

  /** Avança o tempo de JOGO (segundos). Pausar a sessão = não chamar. */
  step(dt: number): void {
    if (!(dt > 0)) return;
    for (const [nodeId, entry] of this.entries) {
      const clip = entry.clip;
      if (!clip || clip.frameIndices.length === 0) continue;
      if (entry.playing) {
        entry.elapsedMs += dt * 1000 * entry.speedScale;
        if (clip.loopMode === 'once') {
          if (!entry.finished && clipFinishedAt(clip, entry.elapsedMs)) {
            entry.finished = true;
            entry.playing = false;
            this.events.push({ nodeId, name: 'animation_finished', clip: clip.name, frame: clip.frameIndices[clip.frameIndices.length - 1] });
          }
        } else {
          const loops = clipLoopsAt(clip, entry.elapsedMs);
          if (loops > entry.loopsSeen) {
            entry.loopsSeen = loops;
            this.events.push({ nodeId, name: 'animation_looped', clip: clip.name, frame: clip.frameIndices[clipPositionAtTime(clip, entry.elapsedMs)] });
          }
        }
      }
      const pos = this.positionOf(entry);
      if (pos !== entry.lastPosition && pos >= 0) {
        entry.lastPosition = pos;
        this.events.push({ nodeId, name: 'frame_changed', clip: clip.name, frame: clip.frameIndices[pos] });
      }
    }
  }

  /** Eventos acumulados desde a última chamada (a sessão os publica no `SignalBus`). */
  drainEvents(): SpriteEvent[] {
    const out = this.events;
    this.events = [];
    return out;
  }
}
