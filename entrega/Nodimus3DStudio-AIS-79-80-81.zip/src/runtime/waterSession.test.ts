import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { ensureRapier } from '../core/physics/rapierInit';
import type { PhysicsEvent } from '../core/physics/PhysicsBridge';
import { RuntimeSession } from './RuntimeSession';

/** AIS-68 (Emenda v5.5) — flutuação e eventos de área do `WaterPlane` na `RuntimeSession`, com o Rapier real. */

beforeAll(async () => {
  await ensureRapier();
});

const node = (id: string, type: string, at: [number, number, number], props: Record<string, unknown> = {}): GameNode =>
  ({ id, name: id, type, parentId: null, childrenIds: [], visible: true, locked: false, properties: { position: { x: at[0], y: at[1], z: at[2] }, ...props } }) as unknown as GameNode;

const input = { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never;

function open(...extra: GameNode[]) {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot({ ...scene, nodes } as unknown as SceneData), input });
  session.start();
  return session;
}

const run = (s: RuntimeSession, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) s.step(1 / 60);
};
const y = (s: RuntimeSession, id: string) => s.getSimulatedTransform(id)!.position[1];

const FLOOR = node('floor', 'MeshInstance', [0, -5.5, 0], { meshType: 'CubeMesh', scale: { x: 60, y: 1, z: 60 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } });
const WATER = node('lake', 'WaterPlane', [0, 0, 0], { width: 40, depth: 40 });
const box = (id: string, floats: boolean, at: [number, number, number] = [0, 3, 0]) =>
  node(id, 'MeshInstance', at, { meshType: 'CubeMesh', physics: { enabled: true, bodyMode: 'dynamic', shape: 'auto', floats } });

describe('WaterPlane: flutuação simples', () => {
  it('com "Flutua na água" o corpo cai, para na superfície (meio submerso) e fica; sem ela afunda até o fundo', () => {
    const s = open(FLOOR, WATER, box('boia', true), box('pedra', false, [4, 3, 0]));
    run(s, 8);
    expect(Math.abs(y(s, 'boia'))).toBeLessThan(0.35); // centro perto da superfície (y = 0)
    expect(y(s, 'pedra')).toBeLessThan(-4); // chegou ao fundo (piso em y = -5)
    s.dispose();
  });

  it('fora do retângulo da água não há empuxo', () => {
    const s = open(FLOOR, WATER, box('longe', true, [25, 3, 0]));
    run(s, 8);
    expect(y(s, 'longe')).toBeLessThan(-4);
    s.dispose();
  });

  it('o nível é o Y do nó: subir a água muda onde o corpo flutua', () => {
    const s = open(FLOOR, node('lake', 'WaterPlane', [0, 2, 0], { width: 40, depth: 40 }), box('boia', true, [0, 6, 0]));
    run(s, 8);
    expect(y(s, 'boia')).toBeGreaterThan(1.6);
    expect(y(s, 'boia')).toBeLessThan(2.4);
    s.dispose();
  });

  it('Enter/Exit: um evento por participante ao entrar e ao sair da água', () => {
    const s = open(FLOOR, WATER, box('boia', true, [0, 1.5, 0]));
    const events: PhysicsEvent[] = [];
    s.physics!.onPhysicsEvent('*', (e) => events.push(e));
    run(s, 4);
    const enter = events.filter((e) => e.name === 'triggerEnter');
    expect(enter.map((e) => `${e.selfId}>${e.otherId}`).sort()).toEqual(['boia>lake', 'lake>boia']);
    s.physics!.teleport('boia', { x: 0, y: 5, z: 0 });
    run(s, 0.2);
    expect(events.filter((e) => e.name === 'triggerExit')).toHaveLength(2);
    s.dispose();
  });

  it('a água não tem corpo físico', () => {
    const s = open(FLOOR, WATER, box('boia', true));
    run(s, 1);
    expect(s.physics!.has('lake')).toBe(false);
    s.dispose();
  });
});
