import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode, ResourceRef } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { ensureRapier } from '../core/physics/rapierInit';
import { RuntimeSession, type RuntimeSessionOptions } from './RuntimeSession';
import { SpawnError } from './spawnHost';

/**
 * AIS-29g — spawn/despawn de prefab em runtime: IDs novos, corpo físico, regras e Behaviors dos nós novos, limites, lifetime,
 * teardown e o conserto do corpo "fantasma" de nó destruído (`destroy_node`).
 */

beforeAll(async () => {
  await ensureRapier();
});

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[]): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters: {}, conditions: [], actions });
const behavior = (...rules: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'Regras', behaviorType: 'custom_rules', enabled: true, properties: {}, rules });

const node = (id: string, at: [number, number, number], physics: Record<string, any> | undefined, extra: Record<string, any> = {}, over: Partial<GameNode> = {}): GameNode =>
  ({
    id,
    name: id,
    type: 'MeshInstance',
    parentId: null,
    childrenIds: [],
    visible: true,
    locked: false,
    properties: { meshType: 'CubeMesh', position: { x: at[0], y: at[1], z: at[2] }, ...(physics ? { physics } : {}), ...extra },
    ...over,
  }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: [] } as GameNode };
  for (const n of extra) {
    nodes[n.id] = { ...n, parentId: n.parentId ?? root.id } as GameNode;
    nodes[root.id].childrenIds.push(n.id);
  }
  return { ...scene, nodes };
}

const fakeInput = () => ({
  isActionPressed: () => false,
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: () => 0,
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
});

const FLOOR = node('floor', [0, -0.5, 0], { enabled: true, bodyMode: 'static', shape: 'auto' }, { scale: { x: 40, y: 1, z: 40 } });
const PLAIN = node('plain', [3, 1, 3], undefined);

const DYN = { enabled: true, bodyMode: 'dynamic', shape: 'auto' };
const ref = (id = 'bullet'): ResourceRef => ({ id: `pf_${id}`, type: 'prefab', path: `res://prefabs/${id}.prefab.json` });

/** Prefab de um nó (`bullet`) ou de uma raiz com um filho. */
function prefab(id = 'bullet', over: Record<string, any> = {}, withChild = false) {
  const root = node('bullet', [0, 0, 0], DYN, { scale: { x: 0.2, y: 0.2, z: 0.2 } }, withChild ? { childrenIds: ['muzzle'] } : {});
  const nodes: Record<string, any> = { bullet: root };
  if (withChild) nodes.muzzle = node('muzzle', [0, 0, 0.5], undefined, {}, { parentId: 'bullet' });
  return { schemaVersion: 1, id: `pf_${id}`, name: id, rootNodeId: 'bullet', nodes, ...over };
}

function open(scene: SceneData, extra: Partial<RuntimeSessionOptions> = {}) {
  const diagnostics = new DiagnosticService();
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input: fakeInput(), diagnostics, ...extra });
  session.start();
  return { session, diagnostics };
}
const run = (session: RuntimeSession, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) session.step(1 / 60);
};
const codes = (d: DiagnosticService) => d.list({ ephemeral: true }).map((x) => x.code);

describe('spawnPrefab (AIS-29g-C01/C02)', () => {
  it('cria a subárvore com IDs novos e corpo físico; o authoring e o prefab ficam intactos', () => {
    const scene = sceneWith(FLOOR);
    const authoringBefore = JSON.stringify(scene);
    const raw = prefab('bullet', {}, true);
    const rawBefore = JSON.stringify(raw);
    const { session } = open(scene);
    expect(session.registerPrefab(ref(), raw)).toBe(true);

    const h = session.spawnPrefab(ref(), { position: [2, 4, 0], ownerId: 'floor' });
    expect(h.rootId).not.toBe('bullet');
    expect(h.rootId.startsWith('bullet')).toBe(true);
    expect(h.nodeIds).toHaveLength(2);
    expect(h.nodeIds.every((id) => id !== 'bullet' && id !== 'muzzle')).toBe(true);
    expect(session.physics!.has(h.rootId)).toBe(true);
    const inst = session.sceneManager.current!.getInstance(h.rootId)!;
    expect(inst.origin).toEqual({ kind: 'spawn', prefabId: 'pf_bullet', ownerId: 'floor' });
    expect(inst.children[0].persistentNodeId).toBe(h.nodeIds[1]);

    expect(JSON.stringify(scene)).toBe(authoringBefore);
    expect(JSON.stringify(raw)).toBe(rawBefore);
    expect(session.sceneManager.current!.getInstance('bullet')).toBeUndefined(); // o id do prefab nunca entra na cena
    session.dispose();
  });

  it('position/rotation mundiais e initialVelocity: o corpo se move no passo seguinte', () => {
    const { session } = open(sceneWith(FLOOR));
    session.registerPrefab(ref(), prefab());
    const h = session.spawnPrefab(ref(), { position: [1, 10, 2], rotation: [0, 90, 0], initialVelocity: { x: 10, y: 0, z: 0 } });
    expect(session.getSimulatedTransform(h.rootId)!.position).toEqual([1, 10, 2]);
    expect(session.getSimulatedTransform(h.rootId)!.rotation[1]).toBeCloseTo(90, 3);
    run(session, 0.5);
    expect(session.getSimulatedTransform(h.rootId)!.position[0]).toBeGreaterThan(5);
    session.dispose();
  });

  it('dois spawns do mesmo prefab não compartilham estado mutável (AIS-29d-C04)', () => {
    const { session } = open(sceneWith(FLOOR));
    session.registerPrefab(ref(), prefab());
    const a = session.spawnPrefab(ref(), { position: [0, 3, 0] });
    const b = session.spawnPrefab(ref(), { position: [4, 3, 0] });
    expect(a.rootId).not.toBe(b.rootId);
    const ia = session.sceneManager.current!.getInstance(a.rootId)!;
    const ib = session.sceneManager.current!.getInstance(b.rootId)!;
    expect(ia.properties).not.toBe(ib.properties);
    ia.properties.meshType = 'SphereMesh';
    ia.tags.push('x');
    expect(ib.properties.meshType).toBe('CubeMesh');
    expect(ib.tags).toEqual([]);
    session.dispose();
  });
});

describe('spawnPrefab — regras e Behaviors dos nós novos', () => {
  it('as regras do prefab rodam no spawn e as referências internas são remapeadas para os ids novos', () => {
    const { session } = open(sceneWith(FLOOR));
    const raw = prefab();
    raw.nodes.bullet.behaviors = [behavior(rule('on_start', [act('destroy_node', { target: 'bullet' })]))];
    session.registerPrefab(ref(), raw);
    const h = session.spawnPrefab(ref(), { position: [0, 3, 0] });
    expect(session.sceneManager.current!.getInstance(h.rootId)).toBeDefined();
    run(session, 0.1); // on_start do nó novo → destroy_node no id REMAPEADO
    expect(session.sceneManager.current!.getInstance(h.rootId)).toBeUndefined();
    expect(session.physics!.has(h.rootId)).toBe(false);
    session.dispose();
  });
});

describe('spawnPrefab — falhas explícitas, sem spawn parcial (AIS-29g-C03)', () => {
  it('prefab não carregado, inválido, pai inexistente e lifetime inválido lançam SpawnError com diagnóstico', () => {
    const { session, diagnostics } = open(sceneWith(FLOOR));
    const instancesBefore = session.sceneManager.current!.getAllInstances().length;
    const bodiesBefore = session.physics!.bodyCount;
    const code = (fn: () => unknown) => {
      try {
        fn();
      } catch (e) {
        return e instanceof SpawnError ? e.code : 'outro';
      }
      return 'sem-erro';
    };
    expect(code(() => session.spawnPrefab(ref('ausente')))).toBe('spawn.prefab_not_loaded');
    expect(session.registerPrefab(ref('ruim'), { id: 'x' })).toBe(false); // sem nodes/rootNodeId
    expect(code(() => session.spawnPrefab(ref('ruim')))).toBe('spawn.prefab_not_loaded');
    session.registerPrefab(ref(), prefab());
    expect(code(() => session.spawnPrefab(ref(), { parentId: 'nao-existe' }))).toBe('spawn.failed');
    expect(code(() => session.spawnPrefab(ref(), { lifetimeMs: 0 }))).toBe('spawn.failed');
    expect(codes(diagnostics)).toEqual(expect.arrayContaining(['spawn.prefab_not_loaded', 'spawn.prefab_invalid', 'spawn.failed']));
    // nada ficou criado
    expect(session.sceneManager.current!.getAllInstances().length).toBe(instancesBefore);
    expect(session.physics!.bodyCount).toBe(bodiesBefore);
    expect(session.spawns.liveCount).toBe(0);
    session.dispose();
  });

  it('o teto de objetos criados em jogo falha com diagnóstico, sem descartar os antigos', () => {
    const { session, diagnostics } = open(sceneWith(FLOOR), { maxSpawns: 2 });
    session.registerPrefab(ref(), prefab());
    const a = session.spawnPrefab(ref(), { position: [0, 3, 0] });
    session.spawnPrefab(ref(), { position: [2, 3, 0] });
    expect(() => session.spawnPrefab(ref(), { position: [4, 3, 0] })).toThrow(SpawnError);
    expect(codes(diagnostics)).toContain('spawn.limit_exceeded');
    expect(session.spawns.liveCount).toBe(2);
    expect(session.sceneManager.current!.getInstance(a.rootId)).toBeDefined();
    session.dispose();
  });

  it('sessão encerrada: SpawnError em vez de criar', () => {
    const { session } = open(sceneWith(FLOOR));
    session.registerPrefab(ref(), prefab());
    session.stop();
    expect(() => session.spawnPrefab(ref())).toThrow(SpawnError);
    session.dispose();
  });
});

describe('despawn (AIS-29g-C04/C05)', () => {
  it('remove nós, corpos e variáveis; é idempotente; acontece no fim do quadro', () => {
    const { session } = open(sceneWith(FLOOR));
    session.registerPrefab(ref(), prefab('bullet', {}, true));
    const h = session.spawnPrefab(ref(), { position: [0, 3, 0] });
    const bodies = session.physics!.bodyCount;
    session.despawn(h.rootId);
    expect(session.sceneManager.current!.getInstance(h.rootId)).toBeDefined(); // adiado: ainda vivo até o fim do quadro
    session.step(1 / 60);
    expect(h.nodeIds.every((id) => !session.sceneManager.current!.getInstance(id))).toBe(true);
    expect(session.physics!.has(h.rootId)).toBe(false);
    expect(session.physics!.bodyCount).toBe(bodies - 1);
    expect(() => {
      session.despawn(h.rootId);
      session.despawn('id-que-nunca-existiu');
      session.step(1 / 60);
    }).not.toThrow();
    session.dispose();
  });

  it('despawn pedido DENTRO de um callback físico não corrompe o mundo', () => {
    const { session } = open(sceneWith(FLOOR));
    session.registerPrefab(ref(), prefab());
    const h = session.spawnPrefab(ref(), { position: [0, 1, 0] });
    let hits = 0;
    session.onPhysicsEvent('collisionEnter', (e) => {
      if (e.selfId === h.rootId) {
        hits++;
        session.despawn(h.rootId);
      }
    });
    expect(() => run(session, 2)).not.toThrow();
    expect(hits).toBeGreaterThanOrEqual(1);
    expect(session.sceneManager.current!.getInstance(h.rootId)).toBeUndefined();
    expect(session.physics!.has(h.rootId)).toBe(false);
    session.dispose();
  });

  it('lifetimeMs destrói sozinho, no tempo de JOGO (pausa não conta)', () => {
    const { session } = open(sceneWith(FLOOR));
    session.registerPrefab(ref(), prefab());
    const h = session.spawnPrefab(ref(), { position: [0, 30, 0], lifetimeMs: 500 });
    run(session, 0.3);
    expect(session.sceneManager.current!.getInstance(h.rootId)).toBeDefined();
    session.pause();
    run(session, 5); // pausada: nada avança
    expect(session.sceneManager.current!.getInstance(h.rootId)).toBeDefined();
    session.resume();
    run(session, 0.4);
    expect(session.sceneManager.current!.getInstance(h.rootId)).toBeUndefined();
    expect(session.physics!.has(h.rootId)).toBe(false);
    session.dispose();
  });
});

describe('conserto do corpo fantasma (AIS-29g-C04a)', () => {
  it('destroy_node remove o corpo do mundo (antes o collider seguia vivo)', () => {
    const victim = node('victim', [0, 5, 0], DYN, {}, { behaviors: [behavior(rule('on_start', [act('destroy_node', { target: 'victim' })]))] } as any);
    const { session } = open(sceneWith(FLOOR, victim));
    expect(session.physics!.has('victim')).toBe(true);
    run(session, 0.2);
    expect(session.sceneManager.current!.getInstance('victim')).toBeUndefined();
    expect(session.physics!.has('victim')).toBe(false);
  });

  it('destruir um pai também remove o corpo dos filhos', () => {
    const parent = node('parent', [0, 5, 0], undefined, {}, { childrenIds: ['kid'] } as any);
    const kid = node('kid', [0, 0, 0], DYN, {}, { parentId: 'parent' });
    const scene = sceneWith(FLOOR, parent);
    scene.nodes.kid = kid as GameNode;
    const { session } = open(scene);
    expect(session.physics!.has('kid')).toBe(true);
    session.sceneManager.current!.destroyInstance('parent');
    expect(session.physics!.has('kid')).toBe(false);
    session.dispose();
  });
});

describe('mundo físico sob demanda (AIS-29g-C04b)', () => {
  it('cena sem nenhum corpo no início: o spawn com física cria o mundo e o corpo funciona', () => {
    const { session } = open(sceneWith(PLAIN));
    expect(session.physics).toBeNull();
    session.registerPrefab(ref(), prefab());
    const h = session.spawnPrefab(ref(), { position: [0, 10, 0] });
    expect(session.physics).not.toBeNull();
    expect(session.physics!.has(h.rootId)).toBe(true);
    run(session, 0.5);
    expect(session.getSimulatedTransform(h.rootId)!.position[1]).toBeLessThan(10); // a gravidade da cena atua
    session.dispose();
  });

  it('prefab SEM física numa cena sem corpos não cria mundo', () => {
    const { session } = open(sceneWith(PLAIN));
    session.registerPrefab(ref('fx'), prefab('fx', { nodes: { bullet: node('bullet', [0, 0, 0], undefined) } }));
    session.spawnPrefab(ref('fx'));
    expect(session.physics).toBeNull();
    session.dispose();
  });

  it('motor de física indisponível: diagnóstico explícito, sem corpo e sem quebrar o Play', async () => {
    const { session, diagnostics } = open(sceneWith(PLAIN), { getRapier: () => null });
    session.registerPrefab(ref(), prefab());
    const h = session.spawnPrefab(ref(), { position: [0, 10, 0], initialVelocity: { x: 1, y: 0, z: 0 } });
    await new Promise((r) => setTimeout(r, 30));
    expect(codes(diagnostics)).toContain('physics.engine_unavailable');
    expect(session.physics).toBeNull();
    expect(() => run(session, 0.2)).not.toThrow();
    expect(session.sceneManager.current!.getInstance(h.rootId)).toBeDefined();
    session.dispose();
  });
});

describe('teardown (AIS-29g-C06)', () => {
  it('restartScene descarta todos os spawns, corpos e lifetimes; nada vaza para a sessão seguinte', () => {
    const { session } = open(sceneWith(FLOOR));
    session.registerPrefab(ref(), prefab());
    const baseline = session.physics!.bodyCount;
    session.spawnPrefab(ref(), { position: [0, 5, 0], lifetimeMs: 100000 });
    session.spawnPrefab(ref(), { position: [2, 5, 0] });
    expect(session.spawns.liveCount).toBe(2);
    session.restartScene();
    expect(session.spawns.liveCount).toBe(0);
    expect(session.physics!.bodyCount).toBe(baseline);
    expect(session.sceneManager.current!.getAllInstances().some((i) => i.origin)).toBe(false);
    run(session, 0.5);
    expect(session.spawns.liveCount).toBe(0);
    // o cache de prefabs é da sessão: segue disponível depois do restart
    expect(() => session.spawnPrefab(ref(), { position: [0, 5, 0] })).not.toThrow();
    session.dispose();
  });

  it('Stop libera tudo: o mundo físico é descartado e o spawn passa a falhar', () => {
    const { session } = open(sceneWith(FLOOR));
    session.registerPrefab(ref(), prefab());
    session.spawnPrefab(ref(), { position: [0, 5, 0] });
    const bridge = session.physics!;
    session.stop();
    expect(bridge.isDisposed).toBe(true);
    expect(session.physics).toBeNull();
    expect(() => session.spawnPrefab(ref())).toThrow(SpawnError);
    session.dispose();
  });

  it('preloadPrefabs lê pelo readPrefab, valida e informa o que não carregou', async () => {
    const files: Record<string, unknown> = { pf_ok: prefab('ok'), pf_bad: { id: 'x' } };
    const { session, diagnostics } = open(sceneWith(FLOOR), {
      readPrefab: async (r) => {
        if (!(r.id in files)) throw new Error('arquivo não existe');
        return files[r.id];
      },
    });
    const loaded = await session.preloadPrefabs([ref('ok'), ref('bad'), ref('missing')]);
    expect(loaded.map((r) => r.id)).toEqual(['pf_ok']);
    expect(codes(diagnostics)).toEqual(expect.arrayContaining(['spawn.prefab_invalid', 'spawn.prefab_not_loaded']));
    expect(() => session.spawnPrefab(ref('ok'), { position: [0, 3, 0] })).not.toThrow();
    session.dispose();
  });
});
