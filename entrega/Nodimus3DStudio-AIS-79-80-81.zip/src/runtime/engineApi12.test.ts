import { describe, expect, it, vi } from 'vitest';
import { ENGINE_OPERATIONS, buildEngineApi, type EngineHost } from './engineApi';

/** AIS-78c (EngineApi 1.2) — armas, alvo da IA, attachments, câmera (leitura), materiais e operações de nó (lookAt/worldPosition/behaviorProperties). */

const inst = (id: string, extra: Record<string, unknown> = {}) =>
  ({ persistentNodeId: id, name: id, type: 'Spatial', disposed: false, tags: [], visible: true, parent: null, properties: {}, transform: { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] }, ...extra }) as never;

function hostWith(extra: Partial<EngineHost> = {}): EngineHost {
  const noop = () => undefined;
  const nodes: Record<string, unknown> = { a: inst('a'), b: inst('b') };
  return {
    instanceById: (ref: string) => nodes[ref] as never,
    instanceByName: () => undefined,
    variables: () => null,
    input: () => ({}) as never,
    physics: () => null,
    sceneTime: () => 0,
    emitSignal: noop,
    connectSignal: () => noop,
    onPhysicsEvent: () => noop,
    log: noop,
    commitTransform: noop,
    ...extra,
  } as EngineHost;
}

describe('sem serviço: falha com código estável, nunca silêncio', () => {
  const api = buildEngineApi(hostWith(), null);
  it('weapons', () => {
    expect(api.weapons.available()).toBe(false);
    expect(api.weapons.fire({ sourceId: 'a' } as never)).toMatchObject({ ok: false, code: 'weapon.unavailable' });
    expect(api.weapons.damage({ sourceId: 'a', targetId: 'b', amount: 1 } as never)).toMatchObject({ ok: false, code: 'weapon.unavailable' });
    expect(api.weapons.explode({} as never)).toMatchObject({ ok: false, code: 'weapon.unavailable' });
    expect(api.weapons.isProjectile('a')).toBe(false);
  });
  it('attachments, materiais, câmera, IA e nó sem objeto vivo', () => {
    expect(api.attachments.attach('a', { holder: null, bone: 'Hand' })).toMatchObject({ ok: false, code: 'attachment.unavailable' });
    expect(api.attachments.detach('nada')).toMatchObject({ ok: false, code: 'node.not_found' });
    expect(api.materials.setEmissive('a', '#fff', 1)).toMatchObject({ ok: false, code: 'materials.unavailable' });
    expect(api.camera.view()).toBeNull();
    expect(api.ai.currentTarget('a')).toBeNull();
    expect(api.transform.lookAt('a', { x: 0, y: 0, z: 1 })).toBe(false);
    expect(api.transform.worldPosition('a')).toBeUndefined();
    expect(api.nodes.behaviorProperties('a', 'x')).toBeUndefined();
  });
});

describe('com serviço', () => {
  it('weapons delega ao núcleo único e hook/isProjectile chegam a ele', () => {
    const core = { fire: vi.fn(() => ({ ok: true, mode: 'hitscan', hit: null })), damage: vi.fn(() => ({ status: 'applied', remaining: 3 })), explode: vi.fn(() => ({ hit: [], damaged: [], pushed: [] })), isProjectile: vi.fn(() => true) };
    const fireHook = vi.fn();
    const api = buildEngineApi(hostWith({ weapons: () => core as never, fireHook }), null);
    expect(api.weapons.available()).toBe(true);
    expect(api.weapons.fire({ sourceId: 'a' } as never)).toMatchObject({ ok: true });
    expect(api.weapons.damage({ sourceId: 'a', targetId: 'b', amount: 2 } as never)).toEqual({ status: 'applied', remaining: 3 });
    api.weapons.explode({} as never);
    api.weapons.hook('a', 'beh', 'on_weapon_shoot', 'x');
    expect(fireHook).toHaveBeenCalledWith('a', 'beh', 'on_weapon_shoot', 'x'); // alias depreciado de hooks.fire (1.4)
    expect(api.weapons.isProjectile('a')).toBe(true);
  });

  it('ai.currentTarget, attachments e câmera (cópia, não a referência viva)', () => {
    const control = { attach: vi.fn(), detach: vi.fn() };
    const live = { nodeId: 'cam', yaw: 10, pitch: -5 };
    const api = buildEngineApi(hostWith({ actors: () => ({ currentTarget: () => 'b' }) as never, attachments: () => control as never, view: () => live }), null);
    expect(api.ai.currentTarget('a')).toBe('b');
    expect(api.attachments.attach('a', { holder: 'b', bone: 'Hand' })).toEqual({ ok: true });
    expect(control.attach).toHaveBeenCalledWith('a', { holder: 'b', bone: 'Hand' });
    expect(api.attachments.detach('a')).toEqual({ ok: true });
    const view = api.camera.view()!;
    expect(view).toEqual(live);
    view.yaw = 999;
    expect(live.yaw).toBe(10);
  });

  it('lookAt valida o ponto, delega ao motor e grava a pose; worldPosition vem do motor', () => {
    const commit = vi.fn();
    const ops = { lookAt: vi.fn(() => true), worldPosition: vi.fn(() => ({ x: 1, y: 2, z: 3 })), setEmissive: vi.fn(() => 2) };
    const api = buildEngineApi(hostWith({ nodeOps: () => ops, commitTransform: commit }), null);
    expect(api.transform.lookAt('a', { x: 0, y: 0, z: 5 })).toBe(true);
    expect(commit).toHaveBeenCalledTimes(1);
    expect(api.transform.lookAt('a', { x: Number.NaN, y: 0, z: 0 })).toBe(false);
    expect(api.transform.lookAt('nada', { x: 0, y: 0, z: 0 })).toBe(false);
    expect(api.transform.worldPosition('a')).toEqual({ x: 1, y: 2, z: 3 });
    expect(api.materials.setEmissive('a', '#ff0000', 2)).toEqual({ ok: true, count: 2 });
  });

  it('behaviorProperties devolve CÓPIA somente leitura das properties de trabalho', () => {
    const props = { speed: 3, nested: { a: 1 } };
    const api = buildEngineApi(hostWith({ behaviorProperties: (_n, t) => (t === 'vehicle_wheel' ? props : undefined) }), null);
    const copy = api.nodes.behaviorProperties('a', 'vehicle_wheel') as typeof props;
    expect(copy).toEqual(props);
    copy.nested.a = 99;
    expect(props.nested.a).toBe(1);
    expect(api.nodes.behaviorProperties('a', 'outro')).toBeUndefined();
  });
});

describe('catálogo 1.2', () => {
  it('as operações novas declaram versão 1.2; as da 1.1 e 1.0 não mudam', () => {
    const since = (id: string) => ENGINE_OPERATIONS.find((o) => o.id === id)?.since;
    for (const id of ['weapons.fire', 'weapons.available', 'ai.currentTarget', 'attachments.attach', 'camera.view', 'materials.setEmissive', 'transform.lookAt', 'transform.worldPosition', 'nodes.behaviorProperties']) expect(since(id), id).toBe('1.2');
    expect(since('audio.play')).toBe('1.1');
    expect(since('physics.raycast')).toBe('1.1');
    expect(since('nodes.get')).toBe('1.0');
  });
});
