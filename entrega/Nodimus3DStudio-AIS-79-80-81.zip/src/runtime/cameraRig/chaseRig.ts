import { clamp, DEG, lookAngles, quatFromYawPitch, smoothingFactor, type Quat, type V3 } from '../controllers/controllerMath';

/**
 * AIS-47b — rig de câmera de perseguição/órbita (puro): órbita com o mouse e câmera elástica que olha para o alvo. Extraído do
 * `thirdPerson.ts` do AIS-47 sem mudar nenhum resultado numérico (testes de caracterização).
 */

export interface ChaseOrbitState {
  /** Órbita (graus): yaw em torno do alvo e elevação da câmera. */
  orbitYaw: number;
  orbitPitch: number;
}

export interface ChaseOrbitParams {
  /** graus por pixel do mouse */
  rotateSpeed: number;
  minPitch: number;
  maxPitch: number;
}

export interface ChasePoseParams {
  distance: number;
  /** altura do ponto olhado acima da origem do alvo */
  targetHeight: number;
  /** velocidade do seguimento elástico (1/s); 0 = a câmera não segue */
  followSmoothingSpeed: number;
}

/** Um quadro de órbita: só orbita com `orbiting` (ex.: botão direito segurado). */
export function stepChaseOrbit(orbit: ChaseOrbitState, params: ChaseOrbitParams, lookDx: number, lookDy: number, orbiting: boolean): ChaseOrbitState {
  if (!orbiting) return { orbitYaw: orbit.orbitYaw, orbitPitch: orbit.orbitPitch };
  return {
    orbitYaw: orbit.orbitYaw - lookDx * params.rotateSpeed,
    orbitPitch: clamp(orbit.orbitPitch + lookDy * params.rotateSpeed, params.minPitch, params.maxPitch),
  };
}

/**
 * Câmera orbital: ponto ideal atrás do alvo, aproximação elástica (independente da taxa de quadros) e olhar para o alvo.
 * `previous` é a posição suavizada do quadro anterior (`null` = a câmera nasce no ponto ideal, sem "voar" até ele).
 */
export function chaseRigPose(anchor: V3, orbit: ChaseOrbitState, previous: V3 | null, params: ChasePoseParams, dt: number): { camera: V3; position: V3; quaternion: Quat } {
  const target: V3 = { x: anchor.x, y: anchor.y + params.targetHeight, z: anchor.z };
  const yaw = orbit.orbitYaw * DEG;
  const pitch = orbit.orbitPitch * DEG;
  const ideal: V3 = {
    x: target.x + params.distance * Math.sin(yaw) * Math.cos(pitch),
    y: target.y + params.distance * Math.sin(pitch),
    z: target.z + params.distance * Math.cos(yaw) * Math.cos(pitch),
  };
  const k = smoothingFactor(params.followSmoothingSpeed, dt);
  const cam: V3 = previous ? { x: previous.x + (ideal.x - previous.x) * k, y: previous.y + (ideal.y - previous.y) * k, z: previous.z + (ideal.z - previous.z) * k } : ideal;
  const look = lookAngles(cam, target);
  return { camera: cam, position: cam, quaternion: quatFromYawPitch(look.yaw, look.pitch) };
}
