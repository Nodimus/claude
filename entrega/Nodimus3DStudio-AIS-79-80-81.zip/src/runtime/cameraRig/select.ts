import type { GameCameraPose } from '../controllers/gameCamera';
import type { ViewBasis } from './types';

/**
 * Escolha da câmera de jogo ativa entre as poses publicadas (puro).
 *
 * REGRA (AIS-47c, decisão 28):
 *  1. poses de Behaviors de CÂMERA (`kind: 'camera'`, só publicam com o nó `Camera` `active`): vale a PRIMEIRA na ordem de inserção
 *     (= ordem de `attach` = ordem dos nós do snapshot); mais de uma é avisada pela sessão (`camera.multiple_active`);
 *  2. senão, poses dos controladores COMPOSTOS legados (AIS-47/47b; `kind` ausente ou `'legacy'`): vale a ÚLTIMA publicada;
 *  3. senão `null`: a viewport segue a câmera orbital do editor (e o follow implícito do jogador).
 * Nó `Camera` ativo SEM Behavior de câmera não publica pose e nunca participa.
 */
export function selectGameCamera(poses: readonly GameCameraPose[]): GameCameraPose | null {
  const cameras = poses.filter((p) => p.kind === 'camera');
  if (cameras.length) return cameras[0];
  return poses.length ? poses[poses.length - 1] : null;
}

/** Quantas poses de Behavior de câmera estão ativas ao mesmo tempo (mais de uma = aviso `camera.multiple_active`). */
export const countCameraPoses = (poses: readonly GameCameraPose[]): number => poses.filter((p) => p.kind === 'camera').length;

/** `ViewBasis` da pose escolhida; `null` quando não há pose ou ela não traz `view`. */
export function viewBasisOf(pose: GameCameraPose | null): ViewBasis | null {
  if (!pose?.view) return null;
  return { nodeId: pose.nodeId, yaw: pose.view.yaw, pitch: pose.view.pitch };
}
