import * as THREE from 'three';
import type { RuntimeInstance } from '../RuntimeScene';
import type { TargetSpace } from './params';

/**
 * AIS-47c / AIS-78c — pose de um nó-alvo para os Behaviors de câmera, no espaço pedido. Mora em `runtime/cameraRig` (o único lugar que calcula
 * olhar e pose de câmera, decisão 28), para que `src/logic/**` nunca importe `three`.
 */
const EULER_DEG = Math.PI / 180;

export const nodePosition = (n: RuntimeInstance): { x: number; y: number; z: number } => ({ x: n.transform.position[0], y: n.transform.position[1], z: n.transform.position[2] });

/** Matriz local (T·R·S) de uma instância viva; rotação em graus, ordem XYZ (a mesma do nó). */
function localMatrix(n: RuntimeInstance): THREE.Matrix4 {
  const [px, py, pz] = n.transform.position;
  const [rx, ry, rz] = n.transform.rotation;
  const [sx, sy, sz] = n.transform.scale;
  return new THREE.Matrix4().compose(new THREE.Vector3(px, py, pz), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx * EULER_DEG, ry * EULER_DEG, rz * EULER_DEG, 'XYZ')), new THREE.Vector3(sx, sy, sz));
}

export interface TargetPose {
  position: { x: number; y: number; z: number };
  /** graus; `local` = o transform do nó; `world` = yaw (Y) e pitch (X) mundiais (ordem YXZ), roll ignorado. */
  rotation: [number, number, number];
}

/**
 * `local` = transform local do nó (o comportamento do AIS-47: certo só para alvo na raiz da cena); `world` (padrão) = compõe a hierarquia de
 * pais, então alvo dentro de um grupo movido/girado é seguido de verdade. Para alvo na raiz os dois espaços são idênticos.
 */
export function targetPoseOf(target: RuntimeInstance, space: TargetSpace): TargetPose {
  if (space === 'local' || !target.parent) return { position: nodePosition(target), rotation: [...target.transform.rotation] as [number, number, number] };
  let m = localMatrix(target);
  for (let p: RuntimeInstance | null = target.parent; p; p = p.parent) m = localMatrix(p).multiply(m);
  const pos = new THREE.Vector3();
  const quat = new THREE.Quaternion();
  m.decompose(pos, quat, new THREE.Vector3());
  const e = new THREE.Euler().setFromQuaternion(quat, 'YXZ');
  return { position: { x: pos.x, y: pos.y, z: pos.z }, rotation: [e.x / EULER_DEG, e.y / EULER_DEG, 0] };
}
