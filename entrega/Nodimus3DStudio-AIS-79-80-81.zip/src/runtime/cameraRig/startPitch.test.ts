import { describe, expect, it } from 'vitest';
import { CAMERA_THIRD_PERSON_DEFAULTS, readCameraThirdPersonParams } from './params';

/** AIS-75 — "Start Pitch" da câmera de 3ª pessoa: 0 = vista lateral (jogo 2D), 85 = de cima (top-down). O padrão (20°) não muda nada. */
describe('Third Person Camera: Start Pitch', () => {
  it('o padrão continua sendo 20° (cenas existentes iguais)', () => {
    expect(CAMERA_THIRD_PERSON_DEFAULTS.startPitch).toBe(20);
    expect(readCameraThirdPersonParams({}).startPitch).toBe(20);
  });
  it('lê o valor e ignora lixo', () => {
    expect(readCameraThirdPersonParams({ startPitch: 85 }).startPitch).toBe(85);
    expect(readCameraThirdPersonParams({ startPitch: 'x' }).startPitch).toBe(20);
  });
});
