import { clamp, lerpAngleDeg, normalizeAxes, planarBasis, smoothingFactor, RAD, type V3 } from '../controllers/controllerMath';

/**
 * AIS-47c (decisão 28) — passo de LOCOMOÇÃO puro, independente de câmera: recebe o yaw de referência (o `viewBasis` da câmera ativa
 * ou o fallback) e devolve a INTENÇÃO de deslocamento horizontal. Gravidade, colisão e chão são do `PhysicsBridge`, nunca daqui.
 * Mesma matemática dos controladores compostos do AIS-47 (equivalência testada).
 */

export interface PlanarMoveParams {
  /** m/s */
  moveSpeed: number;
  /** 0 = resposta imediata; maior = aceleração mais suave (1/s) */
  smoothing: number;
  /** multiplicador de velocidade (corrida); 1 = normal */
  speedMultiplier: number;
}

export interface PlanarMoveState {
  vx: number;
  vz: number;
}

export interface PlanarMoveInput {
  /** +1 = para frente (MoveForward), -1 = para trás. */
  forward: number;
  /** +1 = para a direita (MoveRight), -1 = esquerda. */
  strafe: number;
}

export const initialPlanarMoveState = (): PlanarMoveState => ({ vx: 0, vz: 0 });

/** Um quadro: devolve o novo estado, o deslocamento MUNDIAL horizontal e a direção desejada (unitária ou nula). */
export function stepPlanarMove(
  state: PlanarMoveState,
  params: PlanarMoveParams,
  input: PlanarMoveInput,
  yawDeg: number,
  dt: number
): { state: PlanarMoveState; delta: V3; dirX: number; dirZ: number; moving: boolean; speed: number } {
  const axes = normalizeAxes(clamp(input.forward, -1, 1), clamp(input.strafe, -1, 1));
  const { forward, right } = planarBasis(yawDeg);
  const dirX = forward.x * axes.forward + right.x * axes.strafe;
  const dirZ = forward.z * axes.forward + right.z * axes.strafe;
  const top = params.moveSpeed * params.speedMultiplier;
  const k = params.smoothing > 0 ? smoothingFactor(params.smoothing, dt) : 1;
  const vx = state.vx + (dirX * top - state.vx) * k;
  const vz = state.vz + (dirZ * top - state.vz) * k;
  return { state: { vx, vz }, delta: { x: vx * dt, y: 0, z: vz * dt }, dirX, dirZ, moving: Math.hypot(dirX, dirZ) > 1e-6, speed: Math.hypot(vx, vz) };
}

/** O corpo vira para a direção do movimento (suavização independente da taxa de quadros). */
export function turnTowardMovement(faceYaw: number, dirX: number, dirZ: number, turnSpeed: number, dt: number): number {
  if (Math.hypot(dirX, dirZ) <= 1e-6) return faceYaw;
  const target = Math.atan2(-dirX, -dirZ) * RAD;
  return lerpAngleDeg(faceYaw, target, smoothingFactor(turnSpeed, dt));
}

export type LocomotionKind = 'idle' | 'walk' | 'run' | 'jump' | 'fall';

/** Estado de locomoção de um ator (leitura da `RuntimeSession`; consumido pelos Behaviors de movimento no AIS-60b). Nunca vai ao authoring. */
export interface LocomotionState {
  state: LocomotionKind;
  /** velocidade horizontal (m/s) */
  speed: number;
  grounded: boolean;
}

export interface LocomotionInput {
  moving: boolean;
  /** `Sprint` pressionado E corrida habilitada (`sprintMultiplier > 1`). */
  sprinting: boolean;
  grounded: boolean;
  /** velocidade vertical da física, se disponível (sem ela: no ar = `fall`). */
  verticalVelocity?: number;
  speed: number;
}

/** Função pura: estado discreto de locomoção. No chão: idle/walk/run; no ar: `jump` (subindo) ou `fall`. */
export function locomotionState(i: LocomotionInput): LocomotionState {
  if (!i.grounded) return { state: i.verticalVelocity !== undefined && i.verticalVelocity > 0.5 ? 'jump' : 'fall', speed: i.speed, grounded: false };
  if (!i.moving) return { state: 'idle', speed: i.speed, grounded: true };
  return { state: i.sprinting ? 'run' : 'walk', speed: i.speed, grounded: true };
}
