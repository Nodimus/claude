import { clamp, finite } from '../controllers/controllerMath';

/**
 * AIS-47c — leitura TOLERANTE dos parâmetros dos Behaviors de movimento e de câmera (valores vindos de arquivo nunca produzem
 * NaN no jogo; booleano gravado como texto continua válido). Funções puras.
 */

export const readBool = (v: unknown, fallback: boolean): boolean => {
  if (typeof v === 'boolean') return v;
  if (v === 'true') return true;
  if (v === 'false') return false;
  return fallback;
};

export const readString = (v: unknown, fallback = ''): string => (typeof v === 'string' ? v : fallback);

export const readVec3 = (v: unknown, fallback = { x: 0, y: 0, z: 0 }): { x: number; y: number; z: number } => {
  const o = (v && typeof v === 'object' ? v : {}) as Record<string, unknown>;
  return { x: finite(o.x, fallback.x), y: finite(o.y, fallback.y), z: finite(o.z, fallback.z) };
};

export interface FirstPersonMovementParams {
  moveSpeed: number;
  jumpSpeed: number;
  sprintMultiplier: number;
  smoothing: number;
  bodyFollowsView: boolean;
}
export const FIRST_PERSON_MOVEMENT_DEFAULTS: FirstPersonMovementParams = { moveSpeed: 5, jumpSpeed: 6, sprintMultiplier: 1, smoothing: 0, bodyFollowsView: true };

export function readFirstPersonMovementParams(raw: Record<string, any> | undefined): FirstPersonMovementParams {
  const d = FIRST_PERSON_MOVEMENT_DEFAULTS;
  return {
    moveSpeed: Math.max(0, finite(raw?.moveSpeed, d.moveSpeed)),
    jumpSpeed: Math.max(0, finite(raw?.jumpSpeed, d.jumpSpeed)),
    sprintMultiplier: Math.max(1, finite(raw?.sprintMultiplier, d.sprintMultiplier)),
    smoothing: Math.max(0, finite(raw?.smoothing, d.smoothing)),
    bodyFollowsView: readBool(raw?.bodyFollowsView, d.bodyFollowsView),
  };
}

export interface ThirdPersonMovementParams {
  moveSpeed: number;
  jumpSpeed: number;
  sprintMultiplier: number;
  turnSpeed: number;
}
export const THIRD_PERSON_MOVEMENT_DEFAULTS: ThirdPersonMovementParams = { moveSpeed: 5, jumpSpeed: 6, sprintMultiplier: 1, turnSpeed: 12 };

export function readThirdPersonMovementParams(raw: Record<string, any> | undefined): ThirdPersonMovementParams {
  const d = THIRD_PERSON_MOVEMENT_DEFAULTS;
  return {
    moveSpeed: Math.max(0, finite(raw?.moveSpeed, d.moveSpeed)),
    jumpSpeed: Math.max(0, finite(raw?.jumpSpeed, d.jumpSpeed)),
    sprintMultiplier: Math.max(1, finite(raw?.sprintMultiplier, d.sprintMultiplier)),
    turnSpeed: Math.max(0, finite(raw?.turnSpeed, d.turnSpeed)),
  };
}

/** Espaço em que a pose do alvo é lida: `world` (padrão; compensa a hierarquia) ou `local` (transform local do nó, como no AIS-47). */
export type TargetSpace = 'world' | 'local';
export const readTargetSpace = (v: unknown): TargetSpace => (v === 'local' ? 'local' : 'world');

export interface CameraFirstPersonParams {
  targetNodeId: string;
  targetSpace: TargetSpace;
  eyeHeight: number;
  offset: { x: number; y: number; z: number };
  mouseSensitivity: number;
  maxVerticalAngle: number;
  fov: number;
  smoothing: number;
  hideTarget: boolean;
  pointerLock: boolean;
}
export const CAMERA_FIRST_PERSON_DEFAULTS: CameraFirstPersonParams = {
  targetNodeId: '',
  targetSpace: 'world',
  eyeHeight: 1.6,
  offset: { x: 0, y: 0, z: 0 },
  mouseSensitivity: 0.15,
  maxVerticalAngle: 85,
  fov: 70,
  smoothing: 0,
  hideTarget: true,
  pointerLock: true,
};

export function readCameraFirstPersonParams(raw: Record<string, any> | undefined): CameraFirstPersonParams {
  const d = CAMERA_FIRST_PERSON_DEFAULTS;
  return {
    targetNodeId: readString(raw?.targetNodeId, d.targetNodeId),
    targetSpace: readTargetSpace(raw?.targetSpace),
    eyeHeight: finite(raw?.eyeHeight, d.eyeHeight),
    offset: readVec3(raw?.offset, d.offset),
    mouseSensitivity: Math.max(0, finite(raw?.mouseSensitivity, d.mouseSensitivity)),
    maxVerticalAngle: clamp(finite(raw?.maxVerticalAngle, d.maxVerticalAngle), 1, 89.9),
    fov: clamp(finite(raw?.fov, d.fov), 10, 150),
    smoothing: Math.max(0, finite(raw?.smoothing, d.smoothing)),
    hideTarget: readBool(raw?.hideTarget, d.hideTarget),
    pointerLock: readBool(raw?.pointerLock, d.pointerLock),
  };
}

export type FollowTargetRotation = 'none' | 'yaw' | 'full';

export interface CameraThirdPersonParams {
  targetNodeId: string;
  targetSpace: TargetSpace;
  distance: number;
  targetHeight: number;
  followSmoothingSpeed: number;
  mouseSensitivity: number;
  /** Inclinação inicial (°) da órbita (limitada a Min/Max Pitch): 0 = de lado (jogo 2D lateral), 85 = de cima (top-down). */
  startPitch: number;
  minPitch: number;
  maxPitch: number;
  fov: number;
  orbitAction: string;
  followTargetRotation: FollowTargetRotation;
}
export const CAMERA_THIRD_PERSON_DEFAULTS: CameraThirdPersonParams = {
  targetNodeId: '',
  targetSpace: 'world',
  distance: 6,
  targetHeight: 1.4,
  followSmoothingSpeed: 6,
  mouseSensitivity: 0.3,
  startPitch: 20,
  minPitch: -10,
  maxPitch: 80,
  fov: 60,
  orbitAction: 'AltFire',
  followTargetRotation: 'none',
};

export function readCameraThirdPersonParams(raw: Record<string, any> | undefined): CameraThirdPersonParams {
  const d = CAMERA_THIRD_PERSON_DEFAULTS;
  const minPitch = clamp(finite(raw?.minPitch, d.minPitch), -89, 89);
  const follow = raw?.followTargetRotation;
  return {
    targetNodeId: readString(raw?.targetNodeId, d.targetNodeId),
    targetSpace: readTargetSpace(raw?.targetSpace),
    distance: Math.max(0.5, finite(raw?.distance, d.distance)),
    targetHeight: finite(raw?.targetHeight, d.targetHeight),
    followSmoothingSpeed: Math.max(0, finite(raw?.followSmoothingSpeed, d.followSmoothingSpeed)),
    mouseSensitivity: Math.max(0, finite(raw?.mouseSensitivity, d.mouseSensitivity)),
    startPitch: finite(raw?.startPitch, d.startPitch),
    minPitch,
    maxPitch: clamp(finite(raw?.maxPitch, d.maxPitch), minPitch, 89),
    fov: clamp(finite(raw?.fov, d.fov), 10, 150),
    orbitAction: readString(raw?.orbitAction, d.orbitAction) || d.orbitAction,
    followTargetRotation: follow === 'yaw' || follow === 'full' ? follow : 'none',
  };
}

/** Órbita efetiva da câmera 3ª pessoa quando acompanha a rotação do alvo (graus; `full` = yaw + pitch, sem roll). */
export function effectiveOrbit(orbitYaw: number, orbitPitch: number, mode: FollowTargetRotation, targetRotationDeg: readonly [number, number, number]): { orbitYaw: number; orbitPitch: number } {
  if (mode === 'none') return { orbitYaw, orbitPitch };
  if (mode === 'yaw') return { orbitYaw: orbitYaw + targetRotationDeg[1], orbitPitch };
  return { orbitYaw: orbitYaw + targetRotationDeg[1], orbitPitch: orbitPitch - targetRotationDeg[0] };
}

// ── AIS-47d: Free Flying, Model Viewer, Panorama, RTS ──────────────────────────────────────────────

export interface CameraFreeFlyingParams {
  moveSpeed: number;
  rotateSpeed: number;
  smoothMoving: number;
  fov: number;
  pointerLock: boolean;
}
export const CAMERA_FREE_FLYING_DEFAULTS: CameraFreeFlyingParams = { moveSpeed: 6, rotateSpeed: 0.15, smoothMoving: 0, fov: 70, pointerLock: true };

export function readCameraFreeFlyingParams(raw: Record<string, any> | undefined): CameraFreeFlyingParams {
  const d = CAMERA_FREE_FLYING_DEFAULTS;
  return {
    moveSpeed: Math.max(0, finite(raw?.moveSpeed, d.moveSpeed)),
    rotateSpeed: Math.max(0, finite(raw?.rotateSpeed, d.rotateSpeed)),
    smoothMoving: Math.max(0, finite(raw?.smoothMoving, d.smoothMoving)),
    fov: clamp(finite(raw?.fov, d.fov), 10, 150),
    pointerLock: readBool(raw?.pointerLock, d.pointerLock),
  };
}

export interface CameraModelViewerParams {
  targetNodeId: string;
  targetSpace: TargetSpace;
  rotateSpeed: number;
  radius: number;
  verticalMovementAllowed: boolean;
  fov: number;
  orbitAction: string;
}
export const CAMERA_MODEL_VIEWER_DEFAULTS: CameraModelViewerParams = { targetNodeId: '', targetSpace: 'world', rotateSpeed: 0.4, radius: 5, verticalMovementAllowed: true, fov: 50, orbitAction: 'Fire' };

export function readCameraModelViewerParams(raw: Record<string, any> | undefined): CameraModelViewerParams {
  const d = CAMERA_MODEL_VIEWER_DEFAULTS;
  return {
    targetNodeId: readString(raw?.targetNodeId, d.targetNodeId),
    targetSpace: readTargetSpace(raw?.targetSpace),
    rotateSpeed: Math.max(0, finite(raw?.rotateSpeed, d.rotateSpeed)),
    radius: Math.max(0.1, finite(raw?.radius, d.radius)),
    verticalMovementAllowed: readBool(raw?.verticalMovementAllowed, d.verticalMovementAllowed),
    fov: clamp(finite(raw?.fov, d.fov), 10, 150),
    orbitAction: readString(raw?.orbitAction, d.orbitAction) || d.orbitAction,
  };
}

export interface CameraPanoramaParams {
  rotateSpeed: number;
  fov: number;
  orbitAction: string;
}
export const CAMERA_PANORAMA_DEFAULTS: CameraPanoramaParams = { rotateSpeed: 0.2, fov: 75, orbitAction: 'Fire' };

export function readCameraPanoramaParams(raw: Record<string, any> | undefined): CameraPanoramaParams {
  const d = CAMERA_PANORAMA_DEFAULTS;
  return {
    rotateSpeed: Math.max(0, finite(raw?.rotateSpeed, d.rotateSpeed)),
    fov: clamp(finite(raw?.fov, d.fov), 10, 150),
    orbitAction: readString(raw?.orbitAction, d.orbitAction) || d.orbitAction,
  };
}

export interface CameraRtsParams {
  distanceFromBoundary: number;
  panSpeed: number;
  enableZoomScroll: boolean;
  zoomScrollDistance: number;
  minZoomDistance: number;
  maxZoomDistance: number;
  tilt: number;
  fov: number;
  /** Limites da área jogável (`boundsMin`/`boundsMax` no XZ); eixo com min ≥ max = sem limite. */
  boundsMin: { x: number; y: number; z: number };
  boundsMax: { x: number; y: number; z: number };
}
export const CAMERA_RTS_DEFAULTS: CameraRtsParams = {
  distanceFromBoundary: 20,
  panSpeed: 12,
  enableZoomScroll: true,
  zoomScrollDistance: 2,
  minZoomDistance: 5,
  maxZoomDistance: 40,
  tilt: 55,
  fov: 55,
  boundsMin: { x: 0, y: 0, z: 0 },
  boundsMax: { x: 0, y: 0, z: 0 },
};

export function readCameraRtsParams(raw: Record<string, any> | undefined): CameraRtsParams {
  const d = CAMERA_RTS_DEFAULTS;
  const min = Math.max(0.5, finite(raw?.minZoomDistance, d.minZoomDistance));
  return {
    distanceFromBoundary: Math.max(0, finite(raw?.distanceFromBoundary, d.distanceFromBoundary)),
    panSpeed: Math.max(0, finite(raw?.panSpeed, d.panSpeed)),
    enableZoomScroll: readBool(raw?.enableZoomScroll, d.enableZoomScroll),
    zoomScrollDistance: Math.max(0, finite(raw?.zoomScrollDistance, d.zoomScrollDistance)),
    minZoomDistance: min,
    maxZoomDistance: Math.max(min, finite(raw?.maxZoomDistance, d.maxZoomDistance)),
    tilt: clamp(finite(raw?.tilt, d.tilt), 5, 90),
    fov: clamp(finite(raw?.fov, d.fov), 10, 150),
    boundsMin: readVec3(raw?.boundsMin, d.boundsMin),
    boundsMax: readVec3(raw?.boundsMax, d.boundsMax),
  };
}

/** Limites no plano XZ a partir de `boundsMin`/`boundsMax`: eixo com min ≥ max (o padrão 0/0) fica SEM limite. */
export function rtsLimits(p: Pick<CameraRtsParams, 'boundsMin' | 'boundsMax'>): { minX: number | null; maxX: number | null; minZ: number | null; maxZ: number | null } {
  const x = p.boundsMax.x > p.boundsMin.x;
  const z = p.boundsMax.z > p.boundsMin.z;
  return { minX: x ? p.boundsMin.x : null, maxX: x ? p.boundsMax.x : null, minZ: z ? p.boundsMin.z : null, maxZ: z ? p.boundsMax.z : null };
}
