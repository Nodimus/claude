import { describe, expect, it } from 'vitest';
import { rotateByQuat } from '../controllers/controllerMath';
import {
  CAMERA_RTS_DEFAULTS,
  edgePanAxes,
  freeFlyPose,
  initialFreeFlyState,
  initialRtsDistance,
  initialRtsState,
  lookForward,
  readCameraFreeFlyingParams,
  readCameraModelViewerParams,
  readCameraPanoramaParams,
  readCameraRtsParams,
  rtsLimits,
  rtsPose,
  stepFreeFly,
  stepRts,
  type RtsParams,
} from './index';

/** AIS-47d — estilos de câmera sem ator: Free Flying e RTS (funções puras). */

describe('Free Flying', () => {
  const p = { moveSpeed: 6, rotateSpeed: 0.15, smoothMoving: 0 };
  const idle = { forward: 0, strafe: 0, up: 0, lookDx: 0, lookDy: 0 };

  it('lookForward: yaw 0 olha para -Z; yaw 90 para -X; pitch 90° para cima', () => {
    expect(lookForward(0, 0).z).toBeCloseTo(-1);
    expect(lookForward(90, 0).x).toBeCloseTo(-1);
    expect(lookForward(0, 90).y).toBeCloseTo(1);
  });

  it('W voa NO olhar (inclusive o pitch): olhando 45° para cima, subir e avançar juntos', () => {
    const s0 = initialFreeFlyState({ x: 0, y: 0, z: 0 }, 0, 45);
    const s1 = stepFreeFly(s0, p, { ...idle, forward: 1 }, 1);
    expect(s1.position.y).toBeCloseTo(6 * Math.SQRT1_2);
    expect(s1.position.z).toBeCloseTo(-6 * Math.SQRT1_2);
  });

  it('strafe é horizontal; Jump/Crouch sobem e descem no eixo Y do mundo; sem gravidade', () => {
    const right = stepFreeFly(initialFreeFlyState({ x: 0, y: 5, z: 0 }), p, { ...idle, strafe: 1 }, 1);
    expect(right.position.x).toBeCloseTo(6);
    expect(right.position.y).toBe(5);
    expect(stepFreeFly(initialFreeFlyState({ x: 0, y: 5, z: 0 }), p, { ...idle, up: 1 }, 1).position.y).toBeCloseTo(11);
    expect(stepFreeFly(initialFreeFlyState({ x: 0, y: 5, z: 0 }), p, { ...idle, up: -1 }, 1).position.y).toBeCloseTo(-1);
    expect(stepFreeFly(initialFreeFlyState({ x: 0, y: 5, z: 0 }), p, idle, 5).position).toEqual({ x: 0, y: 5, z: 0 }); // parado no ar
  });

  it('a diagonal não é mais rápida; o olhar gira com o mouse e o pitch é limitado', () => {
    const d = stepFreeFly(initialFreeFlyState({ x: 0, y: 0, z: 0 }), p, { ...idle, forward: 1, strafe: 1 }, 1);
    expect(Math.hypot(d.position.x, d.position.z)).toBeCloseTo(6);
    const look = stepFreeFly(initialFreeFlyState({ x: 0, y: 0, z: 0 }), p, { ...idle, lookDx: 100, lookDy: -100000 }, 0);
    expect(look.yaw).toBeCloseTo(-15);
    expect(look.pitch).toBe(89);
  });

  it('smoothMoving acelera aos poucos e continua deslizando ao soltar', () => {
    const soft = { ...p, smoothMoving: 4 };
    const a = stepFreeFly(initialFreeFlyState({ x: 0, y: 0, z: 0 }), soft, { ...idle, forward: 1 }, 1 / 60);
    expect(Math.abs(a.velocity.z)).toBeGreaterThan(0);
    expect(Math.abs(a.velocity.z)).toBeLessThan(6);
    const b = stepFreeFly(a, soft, idle, 1 / 60);
    expect(Math.abs(b.velocity.z)).toBeGreaterThan(0);
    expect(Math.abs(b.velocity.z)).toBeLessThan(Math.abs(a.velocity.z));
  });

  it('a pose olha para onde o yaw/pitch dizem', () => {
    const pose = freeFlyPose(initialFreeFlyState({ x: 1, y: 2, z: 3 }, 90, 0));
    expect(pose.position).toEqual({ x: 1, y: 2, z: 3 });
    expect(rotateByQuat({ x: 0, y: 0, z: -1 }, pose.quaternion).x).toBeCloseTo(-1);
  });
});

describe('RTS', () => {
  const params: RtsParams = { distanceFromBoundary: 20, panSpeed: 10, enableZoomScroll: true, zoomScrollDistance: 2, minZoomDistance: 5, maxZoomDistance: 20, tilt: 45, limits: { minX: null, maxX: null, minZ: null, maxZ: null } };
  const none = { forward: 0, strafe: 0, wheel: 0 };

  it('edgePanAxes: ponteiro a menos de `margin` px de uma borda empurra para o lado; fora da viewport ou sem bounds = 0', () => {
    const b = { left: 100, top: 50, width: 800, height: 600 };
    expect(edgePanAxes({ x: 105, y: 300 }, b, 20)).toEqual({ forward: 0, strafe: -1 });
    expect(edgePanAxes({ x: 895, y: 300 }, b, 20)).toEqual({ forward: 0, strafe: 1 });
    expect(edgePanAxes({ x: 500, y: 55 }, b, 20)).toEqual({ forward: 1, strafe: 0 }); // borda de cima = para dentro da cena
    expect(edgePanAxes({ x: 500, y: 645 }, b, 20)).toEqual({ forward: -1, strafe: 0 });
    expect(edgePanAxes({ x: 105, y: 55 }, b, 20)).toEqual({ forward: 1, strafe: -1 }); // canto
    expect(edgePanAxes({ x: 500, y: 300 }, b, 20)).toEqual({ forward: 0, strafe: 0 }); // meio
    expect(edgePanAxes({ x: 50, y: 300 }, b, 20)).toEqual({ forward: 0, strafe: 0 }); // fora da viewport
    expect(edgePanAxes({ x: 105, y: 300 }, null, 20)).toEqual({ forward: 0, strafe: 0 });
    expect(edgePanAxes({ x: 105, y: 300 }, b, 0)).toEqual({ forward: 0, strafe: 0 }); // margem 0 = sem pan por borda
  });

  it('o pan é relativo ao yaw e respeita a velocidade; a diagonal não é mais rápida', () => {
    const s0 = { fx: 0, fz: 0, distance: 10 };
    const fwd = stepRts(s0, params, { ...none, forward: 1 }, 0, 1);
    expect(fwd.fz).toBeCloseTo(-10);
    const turned = stepRts(s0, params, { ...none, forward: 1 }, 90, 1);
    expect(turned.fx).toBeCloseTo(-10);
    const diag = stepRts(s0, params, { ...none, forward: 1, strafe: 1 }, 0, 1);
    expect(Math.hypot(diag.fx, diag.fz)).toBeCloseTo(10);
  });

  it('o foco fica dentro da área jogável (por eixo; eixo sem limite anda livre)', () => {
    const bounded = { ...params, limits: { minX: -5, maxX: 5, minZ: null, maxZ: null } };
    const s = stepRts({ fx: 0, fz: 0, distance: 10 }, bounded, { ...none, strafe: 1 }, 0, 10);
    expect(s.fx).toBe(5);
    const free = stepRts({ fx: 0, fz: 0, distance: 10 }, bounded, { ...none, forward: 1 }, 0, 10);
    expect(free.fz).toBeCloseTo(-100);
  });

  it('a roda afasta (> 0) e aproxima (< 0) dentro de [min, max]; zoom desligado ignora a roda', () => {
    const s0 = { fx: 0, fz: 0, distance: 10 };
    expect(stepRts(s0, params, { ...none, wheel: 3 }, 0, 1 / 60).distance).toBeCloseTo(16);
    expect(stepRts(s0, params, { ...none, wheel: 100 }, 0, 1 / 60).distance).toBe(20);
    expect(stepRts(s0, params, { ...none, wheel: -100 }, 0, 1 / 60).distance).toBe(5);
    expect(stepRts(s0, { ...params, enableZoomScroll: false }, { ...none, wheel: 3 }, 0, 1 / 60).distance).toBe(10);
  });

  it('pose: atrás e acima do foco, na inclinação pedida, olhando para ele', () => {
    const pose = rtsPose({ fx: 0, fz: 0, distance: 10 }, { tilt: 45 }, 0);
    expect(pose.position.y).toBeCloseTo(10 * Math.SQRT1_2);
    expect(pose.position.z).toBeCloseTo(10 * Math.SQRT1_2); // atrás de quem olha para -Z
    const dir = rotateByQuat({ x: 0, y: 0, z: -1 }, pose.quaternion);
    // a câmera olha para o foco (a origem)
    const toFocus = { x: -pose.position.x, y: -pose.position.y, z: -pose.position.z };
    const len = Math.hypot(toFocus.x, toFocus.y, toFocus.z);
    expect(dir.x).toBeCloseTo(toFocus.x / len, 5);
    expect(dir.y).toBeCloseTo(toFocus.y / len, 5);
    expect(dir.z).toBeCloseTo(toFocus.z / len, 5);
  });

  it('o estado inicial põe a câmera acima do XZ autoral, com a distância coerente com a altura autoral', () => {
    const s = initialRtsState({ x: 3, y: 10 * Math.SQRT1_2, z: 8 }, 0, params);
    expect(s.distance).toBeCloseTo(10);
    const pose = rtsPose(s, params, 0);
    expect(pose.position.x).toBeCloseTo(3);
    expect(pose.position.z).toBeCloseTo(8);
    expect(initialRtsDistance(0, params)).toBeCloseTo(12.5); // sem altura autoral: meio do intervalo
    expect(initialRtsDistance(1000, params)).toBe(20); // sempre dentro de [min, max]
  });
});

describe('leitura tolerante dos novos estilos', () => {
  it('padrões e limites', () => {
    expect(readCameraFreeFlyingParams({ moveSpeed: -3, fov: 999, pointerLock: 'false' })).toMatchObject({ moveSpeed: 0, fov: 150, pointerLock: false });
    expect(readCameraModelViewerParams({ radius: 0, verticalMovementAllowed: 'false', targetSpace: 'local' })).toMatchObject({ radius: 0.1, verticalMovementAllowed: false, targetSpace: 'local', orbitAction: 'Fire' });
    expect(readCameraPanoramaParams({ orbitAction: '' }).orbitAction).toBe('Fire');
    expect(readCameraRtsParams(undefined)).toEqual(CAMERA_RTS_DEFAULTS);
    expect(readCameraRtsParams({ minZoomDistance: 30, maxZoomDistance: 10 })).toMatchObject({ minZoomDistance: 30, maxZoomDistance: 30 });
  });

  it('rtsLimits: o padrão 0/0 não limita; min < max limita aquele eixo', () => {
    expect(rtsLimits(CAMERA_RTS_DEFAULTS)).toEqual({ minX: null, maxX: null, minZ: null, maxZ: null });
    expect(rtsLimits({ boundsMin: { x: -10, y: 0, z: 0 }, boundsMax: { x: 10, y: 0, z: 0 } })).toEqual({ minX: -10, maxX: 10, minZ: null, maxZ: null });
  });
});
