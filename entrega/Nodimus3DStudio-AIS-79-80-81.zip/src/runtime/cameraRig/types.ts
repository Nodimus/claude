/**
 * AIS-47b (decisão 28) — tipos do rig de câmera de jogo. PURO: sem THREE, React, RuntimeSession nem PhysicsBridge.
 * O rig só calcula olhar, órbita e pose; quem publica a pose é um Behavior (via `ctx.setGameCamera`) e quem a escolhe é a
 * `RuntimeSession`. Tudo é estado de runtime descartável (AIS-03c): nunca vai ao authoring.
 */

/**
 * Orientação de visão da câmera de jogo ativa, em graus (yaw em torno de +Y, 0 olha para -Z; pitch > 0 olha para cima). É a
 * ÚNICA leitura que um Behavior de movimento faz da câmera (somente leitura; defasagem de até 1 quadro é aceita, decisão 28).
 */
export interface ViewBasis {
  /** Nó dono da pose (a câmera, ou o personagem nos controladores compostos legados). */
  nodeId: string;
  yaw: number;
  pitch: number;
}

/** Estado de olhar (yaw/pitch em graus). */
export interface LookAngles {
  yaw: number;
  pitch: number;
}
