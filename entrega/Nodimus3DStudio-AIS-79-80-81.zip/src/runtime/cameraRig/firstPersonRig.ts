import { clamp, quatFromYawPitch, type Quat, type V3 } from '../controllers/controllerMath';
import type { LookAngles } from './types';

/**
 * AIS-47b — rig de 1ª pessoa (puro): olhar com mouse e pose dos olhos. Extraído do `firstPerson.ts` do AIS-47 sem mudar nenhum
 * resultado numérico (testes de caracterização em `characterization.test.ts`).
 */

export interface FirstPersonLookParams {
  /** graus por pixel do mouse */
  rotateSpeed: number;
  /** limite do olhar para cima/baixo, em graus */
  maxVerticalAngle: number;
}

export interface FirstPersonPoseParams {
  /** altura dos olhos acima da origem do alvo */
  eyeHeight: number;
}

/** Um quadro de olhar: mouse para a direita = virar para a direita; mouse para baixo = olhar para baixo. */
export function stepFirstPersonLook(look: LookAngles, params: FirstPersonLookParams, lookDx: number, lookDy: number): LookAngles {
  return {
    yaw: look.yaw - lookDx * params.rotateSpeed,
    pitch: clamp(look.pitch - lookDy * params.rotateSpeed, -params.maxVerticalAngle, params.maxVerticalAngle),
  };
}

/** Pose da câmera: olhos na altura `eyeHeight` acima de `anchor`, orientação yaw/pitch. */
export function firstPersonRigPose(anchor: V3, look: LookAngles, params: FirstPersonPoseParams): { position: V3; quaternion: Quat } {
  return { position: { x: anchor.x, y: anchor.y + params.eyeHeight, z: anchor.z }, quaternion: quatFromYawPitch(look.yaw, look.pitch) };
}
