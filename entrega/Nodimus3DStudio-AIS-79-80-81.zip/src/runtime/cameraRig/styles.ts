import { clamp, normalizeAxes, planarBasis, quatFromYawPitch, smoothingFactor, DEG, type Quat, type V3 } from '../controllers/controllerMath';

/**
 * AIS-47d (decisão 28) — passos PUROS dos estilos de câmera que não têm ator: Free Flying (voo livre) e RTS (pan por borda/teclas +
 * zoom pela roda). Model Viewer e Panorama reaproveitam `chaseRig`/`firstPersonRig` (nada de segundo cálculo de órbita/olhar).
 * Sem THREE, React, `RuntimeSession` nem `PhysicsBridge`.
 */

// ── Free Flying ────────────────────────────────────────────────────────────────────────────────────

export interface FreeFlyParams {
  /** m/s */
  moveSpeed: number;
  /** graus por pixel do mouse */
  rotateSpeed: number;
  /** 0 = resposta imediata; maior = aceleração mais suave (1/s) */
  smoothMoving: number;
}

export interface FreeFlyState {
  yaw: number;
  pitch: number;
  position: V3;
  velocity: V3;
}

export interface FreeFlyInput {
  /** +1 = para frente (no olhar, inclusive o pitch). */
  forward: number;
  /** +1 = para a direita. */
  strafe: number;
  /** +1 = sobe (eixo Y do mundo), -1 = desce. */
  up: number;
  lookDx: number;
  lookDy: number;
}

export const initialFreeFlyState = (position: V3, yawDeg = 0, pitchDeg = 0): FreeFlyState => ({ yaw: yawDeg, pitch: clamp(pitchDeg, -89, 89), position: { ...position }, velocity: { x: 0, y: 0, z: 0 } });

/** Direção "frente" de quem olha com yaw/pitch (graus): -Z em yaw 0, sobe com pitch > 0. */
export function lookForward(yawDeg: number, pitchDeg: number): V3 {
  const y = yawDeg * DEG;
  const p = pitchDeg * DEG;
  return { x: -Math.sin(y) * Math.cos(p), y: Math.sin(p), z: -Math.cos(y) * Math.cos(p) };
}

/** Um quadro de voo: olhar com o mouse, movimento relativo ao olhar (sem gravidade, sem colisão), com suavização opcional. */
export function stepFreeFly(state: FreeFlyState, params: FreeFlyParams, input: FreeFlyInput, dt: number): FreeFlyState {
  const yaw = state.yaw - input.lookDx * params.rotateSpeed;
  const pitch = clamp(state.pitch - input.lookDy * params.rotateSpeed, -89, 89);
  const axes = normalizeAxes(clamp(input.forward, -1, 1), clamp(input.strafe, -1, 1));
  const fwd = lookForward(yaw, pitch);
  const { right } = planarBasis(yaw);
  const up = clamp(input.up, -1, 1);
  const want: V3 = {
    x: (fwd.x * axes.forward + right.x * axes.strafe) * params.moveSpeed,
    y: (fwd.y * axes.forward + up) * params.moveSpeed,
    z: (fwd.z * axes.forward + right.z * axes.strafe) * params.moveSpeed,
  };
  const k = params.smoothMoving > 0 ? smoothingFactor(params.smoothMoving, dt) : 1;
  const velocity: V3 = { x: state.velocity.x + (want.x - state.velocity.x) * k, y: state.velocity.y + (want.y - state.velocity.y) * k, z: state.velocity.z + (want.z - state.velocity.z) * k };
  return { yaw, pitch, velocity, position: { x: state.position.x + velocity.x * dt, y: state.position.y + velocity.y * dt, z: state.position.z + velocity.z * dt } };
}

export function freeFlyPose(state: FreeFlyState): { position: V3; quaternion: Quat } {
  return { position: { ...state.position }, quaternion: quatFromYawPitch(state.yaw, state.pitch) };
}

// ── RTS ────────────────────────────────────────────────────────────────────────────────────────────

export interface RtsParams {
  /** px do limite da viewport que ativam o pan do mouse (0 = sem pan por borda) */
  distanceFromBoundary: number;
  /** m/s */
  panSpeed: number;
  enableZoomScroll: boolean;
  /** metros de distância por "clique" da roda */
  zoomScrollDistance: number;
  minZoomDistance: number;
  maxZoomDistance: number;
  /** inclinação da câmera, graus (90 = de cima) */
  tilt: number;
  /** limites da área jogável no plano XZ; `null` = sem limite naquele eixo */
  limits: { minX: number | null; maxX: number | null; minZ: number | null; maxZ: number | null };
}

export interface RtsState {
  /** ponto do chão que a câmera olha */
  fx: number;
  fz: number;
  /** distância da câmera a esse ponto */
  distance: number;
}

export interface RtsInput {
  /** +1 = para frente (para dentro da cena), -1 = para trás */
  forward: number;
  /** +1 = direita */
  strafe: number;
  /** roda do mouse do quadro, em cliques (> 0 = afasta) */
  wheel: number;
}

/** Eixos de pan pelas BORDAS da viewport: ponteiro a menos de `margin` px de uma borda empurra para aquele lado. Fora da viewport = 0. */
export function edgePanAxes(pointer: { x: number; y: number } | undefined, bounds: { left: number; top: number; width: number; height: number } | null | undefined, margin: number): { forward: number; strafe: number } {
  if (!pointer || !bounds || margin <= 0 || bounds.width <= 0 || bounds.height <= 0) return { forward: 0, strafe: 0 };
  const x = pointer.x - bounds.left;
  const y = pointer.y - bounds.top;
  if (x < 0 || y < 0 || x > bounds.width || y > bounds.height) return { forward: 0, strafe: 0 };
  const strafe = x <= margin ? -1 : x >= bounds.width - margin ? 1 : 0;
  const forward = y <= margin ? 1 : y >= bounds.height - margin ? -1 : 0; // borda de cima = para dentro da cena
  return { forward, strafe };
}

/** Distância inicial coerente com a altura autoral da câmera (ou o meio do intervalo), sempre dentro de [min, max]. */
export function initialRtsDistance(authoredHeight: number, params: Pick<RtsParams, 'minZoomDistance' | 'maxZoomDistance' | 'tilt'>): number {
  const raw = authoredHeight > 0.5 ? authoredHeight / Math.sin(clamp(params.tilt, 5, 90) * DEG) : (params.minZoomDistance + params.maxZoomDistance) / 2;
  return clamp(raw, params.minZoomDistance, params.maxZoomDistance);
}

/** Foco inicial: a câmera nasce acima do XZ autoral, olhando para frente (yaw do nó) a `distance·cos(tilt)`. */
export function initialRtsState(position: V3, yawDeg: number, params: RtsParams): RtsState {
  const distance = initialRtsDistance(position.y, params);
  const { forward } = planarBasis(yawDeg);
  const reach = distance * Math.cos(clamp(params.tilt, 5, 90) * DEG);
  return { fx: position.x + forward.x * reach, fz: position.z + forward.z * reach, distance };
}

/** Um quadro: pan relativo ao yaw da câmera (limitado à área jogável) e zoom pela roda (limitado a [min, max]). */
export function stepRts(state: RtsState, params: RtsParams, input: RtsInput, yawDeg: number, dt: number): RtsState {
  const axes = normalizeAxes(clamp(input.forward, -1, 1), clamp(input.strafe, -1, 1));
  const { forward, right } = planarBasis(yawDeg);
  let fx = state.fx + (forward.x * axes.forward + right.x * axes.strafe) * params.panSpeed * dt;
  let fz = state.fz + (forward.z * axes.forward + right.z * axes.strafe) * params.panSpeed * dt;
  const l = params.limits;
  if (l.minX !== null) fx = Math.max(l.minX, fx);
  if (l.maxX !== null) fx = Math.min(l.maxX, fx);
  if (l.minZ !== null) fz = Math.max(l.minZ, fz);
  if (l.maxZ !== null) fz = Math.min(l.maxZ, fz);
  const distance = params.enableZoomScroll ? clamp(state.distance + input.wheel * params.zoomScrollDistance, params.minZoomDistance, params.maxZoomDistance) : state.distance;
  return { fx, fz, distance };
}

/** Pose: atrás e acima do foco (yaw do nó, inclinação `tilt`), olhando para ele. */
export function rtsPose(state: RtsState, params: Pick<RtsParams, 'tilt'>, yawDeg: number): { position: V3; quaternion: Quat } {
  const tilt = clamp(params.tilt, 5, 90) * DEG;
  const { forward } = planarBasis(yawDeg);
  const back = state.distance * Math.cos(tilt);
  return { position: { x: state.fx - forward.x * back, y: state.distance * Math.sin(tilt), z: state.fz - forward.z * back }, quaternion: quatFromYawPitch(yawDeg, -(tilt / DEG)) };
}
