import { describe, expect, it } from 'vitest';
import {
  CAMERA_FIRST_PERSON_DEFAULTS,
  CAMERA_THIRD_PERSON_DEFAULTS,
  effectiveOrbit,
  initialPlanarMoveState,
  locomotionState,
  readBool,
  readCameraFirstPersonParams,
  readCameraThirdPersonParams,
  readFirstPersonMovementParams,
  readThirdPersonMovementParams,
  stepPlanarMove,
  turnTowardMovement,
} from './index';

/** AIS-47c — locomoção pura (sem câmera) e leitura tolerante de parâmetros. */

describe('stepPlanarMove (movimento relativo a um yaw)', () => {
  const p = { moveSpeed: 5, smoothing: 0, speedMultiplier: 1 };
  it('yaw 0: W vai para -Z; yaw 90 vira o "frente" para -X; a diagonal não é mais rápida', () => {
    expect(stepPlanarMove(initialPlanarMoveState(), p, { forward: 1, strafe: 0 }, 0, 1).delta.z).toBeCloseTo(-5);
    expect(stepPlanarMove(initialPlanarMoveState(), p, { forward: 1, strafe: 0 }, 90, 1).delta.x).toBeCloseTo(-5);
    const d = stepPlanarMove(initialPlanarMoveState(), p, { forward: 1, strafe: 1 }, 0, 1);
    expect(Math.hypot(d.delta.x, d.delta.z)).toBeCloseTo(5);
  });
  it('corrida multiplica a velocidade; sem entrada não se move; suavização acelera aos poucos', () => {
    expect(stepPlanarMove(initialPlanarMoveState(), { ...p, speedMultiplier: 2 }, { forward: 1, strafe: 0 }, 0, 1).speed).toBeCloseTo(10);
    const idle = stepPlanarMove(initialPlanarMoveState(), p, { forward: 0, strafe: 0 }, 0, 1);
    expect(idle.moving).toBe(false);
    expect(idle.delta).toEqual({ x: 0, y: 0, z: 0 });
    const soft = stepPlanarMove(initialPlanarMoveState(), { ...p, smoothing: 4 }, { forward: 1, strafe: 0 }, 0, 1 / 60);
    expect(soft.speed).toBeGreaterThan(0);
    expect(soft.speed).toBeLessThan(5);
  });
});

describe('turnTowardMovement', () => {
  it('vira para a direção do movimento pelo caminho mais curto e não mexe sem movimento', () => {
    expect(turnTowardMovement(10, 0, 0, 12, 1 / 60)).toBe(10);
    expect(turnTowardMovement(0, 1, 0, 1000, 1)).toBeCloseTo(-90, 3); // direção +X → yaw -90
  });
});

describe('locomotionState', () => {
  const base = { moving: false, sprinting: false, grounded: true, speed: 0 };
  it('no chão: idle / walk / run', () => {
    expect(locomotionState(base).state).toBe('idle');
    expect(locomotionState({ ...base, moving: true, speed: 5 }).state).toBe('walk');
    expect(locomotionState({ ...base, moving: true, sprinting: true, speed: 8 }).state).toBe('run');
  });
  it('no ar: subindo = jump; descendo ou sem velocidade vertical = fall', () => {
    expect(locomotionState({ ...base, grounded: false, verticalVelocity: 3 }).state).toBe('jump');
    expect(locomotionState({ ...base, grounded: false, verticalVelocity: -3 }).state).toBe('fall');
    expect(locomotionState({ ...base, grounded: false }).state).toBe('fall');
    expect(locomotionState({ ...base, grounded: false }).grounded).toBe(false);
  });
});

describe('leitura tolerante de parâmetros', () => {
  it('booleano gravado como texto continua válido; lixo cai no padrão', () => {
    expect(readBool('false', true)).toBe(false);
    expect(readBool('true', false)).toBe(true);
    expect(readBool(undefined, true)).toBe(true);
    expect(readBool(7, false)).toBe(false);
    expect(readCameraFirstPersonParams({ hideTarget: 'false', pointerLock: 'false' })).toMatchObject({ hideTarget: false, pointerLock: false });
  });
  it('padrões e limites', () => {
    expect(readCameraFirstPersonParams(undefined)).toEqual(CAMERA_FIRST_PERSON_DEFAULTS);
    expect(readCameraThirdPersonParams(undefined)).toEqual(CAMERA_THIRD_PERSON_DEFAULTS);
    expect(readCameraFirstPersonParams({ fov: 999, maxVerticalAngle: 200 })).toMatchObject({ fov: 150, maxVerticalAngle: 89.9 });
    expect(readCameraThirdPersonParams({ distance: 0, maxPitch: 200, minPitch: NaN })).toMatchObject({ distance: 0.5, maxPitch: 89 });
    expect(readCameraThirdPersonParams({ followTargetRotation: 'lixo', orbitAction: '' })).toMatchObject({ followTargetRotation: 'none', orbitAction: 'AltFire' });
    expect(readCameraFirstPersonParams({ offset: { x: 1, y: 'a', z: 3 } }).offset).toEqual({ x: 1, y: 0, z: 3 });
    expect(readFirstPersonMovementParams({ sprintMultiplier: 0.2 }).sprintMultiplier).toBe(1);
    expect(readThirdPersonMovementParams({ moveSpeed: -5 }).moveSpeed).toBe(0);
  });
});

describe('effectiveOrbit (followTargetRotation)', () => {
  it('none ignora o alvo; yaw soma o yaw; full soma o yaw e subtrai o pitch (sem roll)', () => {
    expect(effectiveOrbit(10, 20, 'none', [30, 40, 50])).toEqual({ orbitYaw: 10, orbitPitch: 20 });
    expect(effectiveOrbit(10, 20, 'yaw', [30, 40, 50])).toEqual({ orbitYaw: 50, orbitPitch: 20 });
    expect(effectiveOrbit(10, 20, 'full', [30, 40, 50])).toEqual({ orbitYaw: 50, orbitPitch: -10 });
  });
});
