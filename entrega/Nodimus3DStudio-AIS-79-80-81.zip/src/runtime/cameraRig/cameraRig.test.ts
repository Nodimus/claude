import { describe, expect, it } from 'vitest';
import type { GameCameraPose } from '../controllers/gameCamera';
import { rotateByQuat } from '../controllers/controllerMath';
import { chaseRigPose, countCameraPoses, firstPersonRigPose, selectGameCamera, stepChaseOrbit, stepFirstPersonLook, viewBasisOf } from './index';

/** AIS-47b — funções puras do rig de câmera (sem THREE/React/RuntimeSession). */

const pose = (nodeId: string, view?: { yaw: number; pitch: number }): GameCameraPose => ({ nodeId, position: { x: 0, y: 0, z: 0 }, quaternion: { x: 0, y: 0, z: 0, w: 1 }, pointerLock: false, ...(view ? { view } : {}) });

describe('firstPersonRig', () => {
  const look = { rotateSpeed: 0.15, maxVerticalAngle: 85 };
  it('mouse para a direita vira para a direita; para baixo olha para baixo', () => {
    const a = stepFirstPersonLook({ yaw: 0, pitch: 0 }, look, 100, 0);
    expect(a.yaw).toBeCloseTo(-15);
    const b = stepFirstPersonLook({ yaw: 0, pitch: 0 }, look, 0, 100);
    expect(b.pitch).toBeCloseTo(-15);
  });
  it('o pitch respeita o limite vertical nos dois sentidos', () => {
    expect(stepFirstPersonLook({ yaw: 0, pitch: 80 }, look, 0, -1000).pitch).toBe(85);
    expect(stepFirstPersonLook({ yaw: 0, pitch: -80 }, look, 0, 1000).pitch).toBe(-85);
  });
  it('a pose põe os olhos eyeHeight acima da âncora e olha para onde o yaw diz', () => {
    const p = firstPersonRigPose({ x: 1, y: 2, z: 3 }, { yaw: 90, pitch: 0 }, { eyeHeight: 1.6 });
    expect(p.position).toEqual({ x: 1, y: 3.6, z: 3 });
    expect(rotateByQuat({ x: 0, y: 0, z: -1 }, p.quaternion).x).toBeCloseTo(-1);
  });
});

describe('chaseRig', () => {
  const orbit = { rotateSpeed: 0.3, minPitch: -10, maxPitch: 80 };
  const posePar = { distance: 6, targetHeight: 1.4, followSmoothingSpeed: 6 };
  it('só orbita com `orbiting`; o pitch respeita os limites', () => {
    expect(stepChaseOrbit({ orbitYaw: 10, orbitPitch: 20 }, orbit, 50, 50, false)).toEqual({ orbitYaw: 10, orbitPitch: 20 });
    const o = stepChaseOrbit({ orbitYaw: 10, orbitPitch: 20 }, orbit, 10, 1000, true);
    expect(o.orbitYaw).toBeCloseTo(7);
    expect(o.orbitPitch).toBe(80);
  });
  it('sem posição anterior a câmera nasce no ponto ideal, à distância certa do alvo, olhando para ele', () => {
    const r = chaseRigPose({ x: 0, y: 0, z: 0 }, { orbitYaw: 0, orbitPitch: 0 }, null, posePar, 1 / 60);
    expect(r.camera).toEqual(r.position);
    expect(r.position.z).toBeCloseTo(6);
    expect(r.position.y).toBeCloseTo(1.4);
    expect(rotateByQuat({ x: 0, y: 0, z: -1 }, r.quaternion).z).toBeCloseTo(-1);
  });
  it('com posição anterior aproxima elasticamente, sem chegar de uma vez; velocidade 0 não segue', () => {
    const prev = { x: 0, y: 1.4, z: 0 };
    const r = chaseRigPose({ x: 0, y: 0, z: 0 }, { orbitYaw: 0, orbitPitch: 0 }, prev, posePar, 1 / 60);
    expect(r.position.z).toBeGreaterThan(0);
    expect(r.position.z).toBeLessThan(6);
    const still = chaseRigPose({ x: 0, y: 0, z: 0 }, { orbitYaw: 0, orbitPitch: 0 }, prev, { ...posePar, followSmoothingSpeed: 0 }, 1 / 60);
    expect(still.position).toEqual(prev);
  });
});

describe('selectGameCamera / viewBasisOf', () => {
  it('sem poses → null (a viewport segue a câmera do editor)', () => {
    expect(selectGameCamera([])).toBeNull();
    expect(viewBasisOf(null)).toBeNull();
  });
  it('com duas poses vale a ÚLTIMA (ordem de inserção = ordem de attach)', () => {
    const a = pose('a');
    const b = pose('b');
    expect(selectGameCamera([a, b])).toBe(b);
    expect(selectGameCamera([b, a])).toBe(a);
  });
  it('viewBasis vem do `view` da pose; sem `view` é null', () => {
    expect(viewBasisOf(pose('hero', { yaw: 30, pitch: -5 }))).toEqual({ nodeId: 'hero', yaw: 30, pitch: -5 });
    expect(viewBasisOf(pose('hero'))).toBeNull();
  });
});

describe('selectGameCamera (AIS-47c): câmera com Behavior vence o composto legado', () => {
  const legacy = (id: string): GameCameraPose => ({ ...pose(id), kind: 'legacy' });
  const cam = (id: string): GameCameraPose => ({ ...pose(id), kind: 'camera' });
  it('Behavior de câmera tem prioridade; entre câmeras vale a PRIMEIRA; entre legados, a última', () => {
    expect(selectGameCamera([legacy('hero'), cam('camA'), cam('camB')])?.nodeId).toBe('camA');
    expect(selectGameCamera([cam('camA'), legacy('hero')])?.nodeId).toBe('camA');
    expect(selectGameCamera([legacy('a'), legacy('b')])?.nodeId).toBe('b');
    expect(selectGameCamera([pose('a'), pose('b')])?.nodeId).toBe('b'); // `kind` ausente = legado (AIS-47b)
  });
  it('countCameraPoses conta só as de Behavior de câmera', () => {
    expect(countCameraPoses([legacy('a'), cam('b'), cam('c')])).toBe(2);
    expect(countCameraPoses([])).toBe(0);
  });
});
