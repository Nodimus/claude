import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { ensureRapier } from '../core/physics/rapierInit';
import { RuntimeSession } from './RuntimeSession';
import { sceneHasPhysics } from './physicsHost';

/**
 * AIS-59b (D2) — bloco de física inválido SOZINHO na cena nunca fica em silêncio. Antes, `sceneHasPhysics` usava `readPhysics` (null no
 * bloco inválido), o mundo nem era criado e o diagnóstico do `resolvePhysicsDescriptor` nunca rodava.
 */

beforeAll(async () => {
  await ensureRapier();
});

const node = (id: string, physics: unknown): GameNode =>
  ({
    id,
    name: id,
    type: 'MeshInstance',
    parentId: null,
    childrenIds: [],
    visible: true,
    locked: false,
    properties: { meshType: 'CubeMesh', position: { x: 0, y: 1, z: 0 }, ...(physics === undefined ? {} : { physics }) },
  }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: [] } as GameNode };
  for (const n of extra) {
    nodes[n.id] = { ...n, parentId: root.id } as GameNode;
    nodes[root.id].childrenIds.push(n.id);
  }
  return { ...scene, nodes };
}

const fakeInput = () => ({
  isActionPressed: () => false,
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: () => 0,
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
});

const INVALID_MESH = { enabled: true, bodyMode: 'dynamic', shape: 'mesh' }; // "Malha exata" só em static
const GARBAGE = { enabled: true, bodyMode: 'voando', shape: 42 };

function play(scene: SceneData) {
  const diagnostics = new DiagnosticService();
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input: fakeInput(), diagnostics });
  session.start();
  return { session, diagnostics, codes: () => diagnostics.list({ ephemeral: true }).map((d) => d.code) };
}

describe('bloco de física inválido nunca em silêncio (AIS-59b-C02)', () => {
  it('"Malha exata" em corpo dinâmico, SOZINHO na cena: publica physics.mesh_not_static e o Play segue', () => {
    const { session, codes } = play(sceneWith(node('floor', INVALID_MESH)));
    expect(codes()).toContain('physics.mesh_not_static');
    expect(session.status).toBe('running');
    expect(() => session.step(1 / 60)).not.toThrow();
    session.dispose();
  });

  it('bloco ilegível (dado adulterado), SOZINHO: publica physics.invalid_config', () => {
    const { session, codes } = play(sceneWith(node('lixo', GARBAGE)));
    expect(codes()).toContain('physics.invalid_config');
    session.dispose();
  });

  it('o nó com bloco inválido continua sem corpo (sem colisão), com o motivo registrado', () => {
    const { session, diagnostics } = play(sceneWith(node('floor', INVALID_MESH)));
    expect(session.physics?.has('floor') ?? false).toBe(false);
    expect(diagnostics.list({ ephemeral: true }).find((d) => d.code === 'physics.mesh_not_static')?.nodeId).toBe('floor');
    session.dispose();
  });

  it('bloco desligado (enabled:false) ou ausente continua sem diagnóstico e sem mundo', () => {
    const off = play(sceneWith(node('a', { enabled: false, bodyMode: 'static', shape: 'auto' }), node('b', undefined)));
    expect(off.codes().filter((c) => c.startsWith('physics.'))).toEqual([]);
    expect(off.session.physics).toBeNull();
    off.session.dispose();
  });

  it('com um bloco válido ao lado, o comportamento anterior se mantém (um diagnóstico, o válido tem corpo)', () => {
    const { session, codes } = play(sceneWith(node('floor', INVALID_MESH), node('ok', { enabled: true, bodyMode: 'static', shape: 'auto' })));
    expect(codes().filter((c) => c === 'physics.mesh_not_static')).toHaveLength(1);
    expect(session.physics!.has('ok')).toBe(true);
    session.dispose();
  });

  it('sceneHasPhysics: bloco inválido ligado conta como "quer física" (para o resolvedor reportar)', () => {
    const { session } = play(sceneWith(node('floor', INVALID_MESH)));
    expect(sceneHasPhysics(session.sceneManager.current!)).toBe(true);
    session.dispose();
  });
});
