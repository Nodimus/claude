import { describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { ENGINE_API_VERSION, ENGINE_FEATURES, ENGINE_OPERATIONS, createEngineApi, negotiateEngineApi, type EngineApi } from './engineApi';
import { RuntimeSession } from './RuntimeSession';

/** AIS-78c-C02/C04 — a EngineApi só expõe dados serializáveis e a PhysicsBridge; tem versão e negociação explícita. */

const node = (id: string, type: string, extra: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type, parentId: null, childrenIds: [], visible: true, locked: false, properties: {}, ...extra }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes = { ...scene.nodes };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  nodes[root.id] = { ...root, childrenIds: [...root.childrenIds, ...extra.map((n) => n.id)] };
  return { ...scene, nodes };
}

const held = new Set<string>();
const input = {
  isActionPressed: (a: string) => held.has(a),
  isActionJustPressed: (a: string) => held.has(`+${a}`),
  isActionJustReleased: () => false,
  getAxis: (n: string, p: string) => (held.has(p) ? 1 : 0) - (held.has(n) ? 1 : 0),
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
};

function open() {
  const logs: { level: string; message: string; code?: string }[] = [];
  const scene = sceneWith(
    node('hero', 'Spatial', { name: 'Heroi', transform: { position: [1, 2, 3], rotation: [0, 90, 0], scale: [1, 1, 1] } as never, properties: { hp: 7, nested: { a: [1, 2] }, fn: undefined } })
  );
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), mode: 'scene', input: input as never, onLog: (e: any) => logs.push(e) } as any);
  session.start();
  return { session, api: createEngineApi(session), logs };
}

/** Todo valor alcançável pela API é função, dado puro ou a PhysicsBridge (a única porta física). */
function surface(api: EngineApi): string[] {
  const out: string[] = [];
  const walk = (value: unknown, path: string) => {
    if (typeof value === 'function') return void out.push(path);
    if (value && typeof value === 'object') for (const [k, v] of Object.entries(value)) walk(v, `${path}.${k}`);
  };
  walk(api, 'api');
  return out;
}

describe('versão e negociação (C04)', () => {
  it('a API declara versão e features; a negociação aceita o compatível e falha de forma EXPLÍCITA no resto', () => {
    expect(ENGINE_API_VERSION).toEqual({ major: 1, minor: 5 });
    expect(negotiateEngineApi({ major: 1 })).toMatchObject({ ok: true, version: { major: 1, minor: 5 } });
    expect(negotiateEngineApi({ major: 1, features: ['nodes', 'signals', 'physics'] }).ok).toBe(true);
    expect(negotiateEngineApi({ major: 2 })).toMatchObject({ ok: false, code: 'engine.major_mismatch' });
    expect(negotiateEngineApi({ major: 1, minMinor: 4 }).ok).toBe(true); // AIS-78d-C01
    expect(negotiateEngineApi({ major: 1, minMinor: 6 })).toMatchObject({ ok: false, code: 'engine.minor_too_old' });
    const missing = negotiateEngineApi({ major: 1, features: ['nodes', 'teleport'] });
    expect(missing).toMatchObject({ ok: false, code: 'engine.missing_feature', missing: ['teleport'] });
  });

  it('hasFeature e negotiate vêm da própria API', () => {
    const { api } = open();
    expect(api.version).toEqual(ENGINE_API_VERSION);
    expect(api.hasFeature('signals')).toBe(true);
    expect(api.hasFeature('rede')).toBe(false);
    expect(api.negotiate({ major: 9 }).ok).toBe(false);
    expect(ENGINE_FEATURES).toContain('physics');
  });
});

describe('catálogo de operações', () => {
  it('cada operação declara modo e segurança em Play e publish; ids únicos e estáveis', () => {
    const ids = ENGINE_OPERATIONS.map((o) => o.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const o of ENGINE_OPERATIONS) {
      expect(['sync', 'async']).toContain(o.mode);
      expect(typeof o.safeIn.play).toBe('boolean');
      expect(typeof o.safeIn.publish).toBe('boolean');
      expect(o.id.startsWith(`${o.feature}.`)).toBe(true);
      expect(o.since).toMatch(/^\d+\.\d+$/);
    }
  });

  it('só a PhysicsBridge (objeto vivo) e as operações com callback não são marshaláveis; a física exige requiresPhysics', () => {
    expect(ENGINE_OPERATIONS.filter((o) => !o.marshalable).map((o) => o.id).sort()).toEqual(['frame.onInput', 'frame.onUpdate', 'physics.bridge', 'scripts.run', 'time.after']);
    expect(ENGINE_OPERATIONS.find((o) => o.id === 'physics.bridge')?.requires).toEqual(['requiresPhysics']);
  });

  it('toda função pública da API tem uma operação declarada (nada sem contrato)', () => {
    const { api } = open();
    const declared = new Set(ENGINE_OPERATIONS.map((o) => o.id));
    const META = new Set(['api.hasFeature', 'api.negotiate', 'api.operations']);
    const camel = (p: string) => p.replace(/^api\./, '');
    const map: Record<string, string> = { 'physics': 'physics.bridge', 'onPhysicsEvent': 'physics.onEvent', 'log': 'log.write', 'time': 'time.sceneTime', 'raycast': 'physics.raycast', 'overlapSphere': 'physics.overlapSphere', 'after': 'time.after', 'input.axis': 'input.axis' };
    for (const path of surface(api)) {
      if (META.has(path)) continue;
      const key = camel(path);
      expect(declared.has(map[key] ?? key), `sem operação para ${path}`).toBe(true);
    }
  });
});

describe('superfície (C02): sem objetos internos vivos', () => {
  it('só funções e dados: nenhuma chave de DOM, Three, Rapier, store ou Tauri', () => {
    const { api } = open();
    for (const forbidden of ['renderer', 'document', 'window', 'store', 'tauri', 'filesystem', 'rapier', 'world', 'object3d']) {
      expect(Object.keys(api).map((k) => k.toLowerCase())).not.toContain(forbidden);
    }
    // os valores não-função da raiz são dados (versão) ou namespaces de funções
    for (const [k, v] of Object.entries(api)) {
      if (typeof v === 'function') continue;
      expect(['version', 'nodes', 'transform', 'variables', 'signals', 'input', 'audio', 'particles', 'animation', 'sprites', 'tweens', 'scene', 'weapons', 'ai', 'attachments', 'camera', 'materials', 'frame', 'locomotion', 'text', 'ui', 'motion', 'hooks', 'routes', 'diagnostics', 'random', 'scripts']).toContain(k);
    }
  });

  it('nodes.get / transform.get devolvem CÓPIAS serializáveis (nunca a instância viva nem o objeto Three)', () => {
    const { api, session } = open();
    const snap = api.nodes.get('hero')!;
    expect(JSON.parse(JSON.stringify(snap))).toEqual(snap);
    expect(Object.keys(snap).sort()).toEqual(['id', 'name', 'parentId', 'tags', 'transform', 'type', 'visible']);
    expect(snap.transform.position).toEqual([1, 2, 3]);
    snap.transform.position[0] = 999; // mexer na cópia não mexe no jogo
    expect(session.scene.getInstance('hero')!.transform.position[0]).toBe(1);
    expect(api.transform.get('hero')!.rotation[1]).toBe(90);
    expect(api.nodes.getProperty('hero', 'nested')).toEqual({ a: [1, 2] });
    expect(api.nodes.getProperty('hero', 'hp')).toBe(7);
    expect(api.nodes.getProperty('hero', 'inexistente')).toBeUndefined();
  });

  it('handles por ID estável: resolve por ID ou nome; desconhecido vira undefined', () => {
    const { api } = open();
    expect(api.nodes.resolve('hero')).toEqual({ id: 'hero' });
    expect(api.nodes.resolve('Heroi')).toEqual({ id: 'hero' });
    expect(api.nodes.resolve('ninguem')).toBeUndefined();
    expect(api.nodes.get('ninguem')).toBeUndefined();
  });
});

describe('operações', () => {
  it('transform.set valida e aplica só no estado de runtime; entrada inválida não aplica nada (sem parcial)', () => {
    const { api, session } = open();
    expect(api.transform.set('hero', { position: [5, 6, 7] })).toBe(true);
    expect(session.scene.getInstance('hero')!.transform.position).toEqual([5, 6, 7]);
    expect(api.transform.set('hero', { position: [9, 9, 9], rotation: [Number.NaN, 0, 0] })).toBe(false);
    expect(session.scene.getInstance('hero')!.transform.position).toEqual([5, 6, 7]); // nada parcial
    expect(api.transform.set('ninguem', { position: [0, 0, 0] })).toBe(false);
    expect(session.snapshot.nodes['hero']).toBeDefined();
  });

  it('signals: connect devolve disposer idempotente; emit entrega (nome e args); depois do disposer, nada', () => {
    const { api } = open();
    const got: [string, readonly unknown[]][] = [];
    const off = api.signals.connect('boom', (name, args) => got.push([name, args]));
    api.signals.emit('boom', [1, 'a']);
    expect(got).toEqual([['boom', [1, 'a']]]);
    off();
    off();
    api.signals.emit('boom');
    expect(got).toHaveLength(1);
  });

  it('as assinaturas pertencem à cena: Stop as solta (nenhuma sobrevive)', () => {
    const { api, session } = open();
    let n = 0;
    api.signals.connect('boom', () => n++);
    session.stop();
    api.signals.emit('boom');
    expect(n).toBe(0);
  });

  it('input por ação lógica (nunca KeyboardEvent.code) e eixo', () => {
    const { api } = open();
    held.clear();
    expect(api.input.isPressed('Jump')).toBe(false);
    held.add('Jump');
    held.add('+Jump');
    held.add('MoveRight');
    expect(api.input.isPressed('Jump')).toBe(true);
    expect(api.input.justPressed('Jump')).toBe(true);
    expect(api.input.axis('MoveLeft', 'MoveRight')).toBe(1);
    held.clear();
  });

  it('variáveis: lê e escreve só o que já existe (o runtime nunca cria variável); time e log', () => {
    const { api, logs } = open();
    expect(api.variables.get('global', 'naoExiste')).toBeUndefined();
    expect(api.variables.set('global', 'naoExiste', 1)).toBe(false);
    expect(api.time()).toBeGreaterThanOrEqual(0);
    api.log('warn', 'cuidado', { code: 'x.y' });
    expect(logs.some((l) => l.level === 'warn' && l.message === 'cuidado' && l.code === 'x.y')).toBe(true);
  });

  it('physics() é a PhysicsBridge da sessão (ou null enquanto o motor carrega) e onPhysicsEvent devolve disposer', () => {
    const { api, session } = open();
    expect(api.physics()).toBe(session.physics);
    const off = api.onPhysicsEvent('*', () => undefined);
    expect(typeof off).toBe('function');
    off();
  });
});
