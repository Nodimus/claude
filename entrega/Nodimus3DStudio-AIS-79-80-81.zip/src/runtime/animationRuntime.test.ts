import { describe, expect, it } from 'vitest';
import { AnimationHost, type AnimationProblemCode } from './animationRuntime';

/** AIS-60 — estado de reprodução do objeto animado (puro): play/stop/pause/setSpeed, crossfade em segundos e eventos. */

const CLIPS = [
  { name: 'Idle', duration: 2 },
  { name: 'Walk', duration: 1 },
  { name: 'Run', duration: 0.8 },
  { name: 'Jump', duration: 1, loop: false },
];

function host(registration: Partial<Parameters<AnimationHost['register']>[1]> = {}) {
  const problems: { code: AnimationProblemCode; message: string }[] = [];
  const h = new AnimationHost((code, message) => problems.push({ code, message }));
  h.register('p', { clips: CLIPS, crossfade: 0.2, ...registration });
  return { h, problems };
}
const run = (h: AnimationHost, seconds: number, dt = 1 / 60) => {
  for (let t = 0; t < seconds - 1e-9; t += dt) h.step(dt);
};

describe('play / pause / stop / setSpeed', () => {
  it('play toca o clipe do começo e avança com o tempo de jogo', () => {
    const { h } = host();
    expect(h.play('p', 'Walk')).toBeNull();
    run(h, 0.5);
    const s = h.stateOf('p')!;
    expect(s.clip).toBe('Walk');
    expect(s.playing).toBe(true);
    expect(s.time).toBeCloseTo(0.5, 2);
  });

  it('pause congela e retomar continua de onde parou', () => {
    const { h } = host();
    h.play('p', 'Walk');
    run(h, 0.3);
    h.pause('p', true);
    const frozen = h.stateOf('p')!.time;
    run(h, 1);
    expect(h.stateOf('p')!.time).toBeCloseTo(frozen, 6);
    h.pause('p', false);
    run(h, 0.2);
    expect(h.stateOf('p')!.time).toBeCloseTo(frozen + 0.2, 2);
  });

  it('stop volta ao quadro 0 e para', () => {
    const { h } = host();
    h.play('p', 'Walk');
    run(h, 0.6);
    h.stop('p');
    expect(h.stateOf('p')).toMatchObject({ playing: false, time: 0 });
    run(h, 1);
    expect(h.stateOf('p')!.time).toBe(0);
  });

  it('setSpeed escala a reprodução (limitada a 0,25×–2×)', () => {
    const { h } = host();
    h.play('p', 'Idle');
    h.setSpeed('p', 2);
    run(h, 0.5);
    expect(h.stateOf('p')!.time).toBeCloseTo(1, 2);
    h.setSpeed('p', 99);
    expect(h.stateOf('p')!.speed).toBe(2);
    h.setSpeed('p', 0.01);
    expect(h.stateOf('p')!.speed).toBe(0.25);
  });

  it('o clipe em loop volta ao início; o sem loop para no fim', () => {
    const { h } = host();
    h.play('p', 'Walk'); // 1 s, loop do nó
    run(h, 1.25);
    expect(h.stateOf('p')!.time).toBeCloseTo(0.25, 1);
    h.play('p', 'Jump'); // clipe com loop:false na biblioteca
    run(h, 1.5);
    expect(h.stateOf('p')).toMatchObject({ playing: false, time: 1 });
  });
});

describe('crossfade em segundos', () => {
  it('Idle → Walk em 0,2 s: pesos somam 1 e migram do antigo para o novo', () => {
    const { h } = host();
    h.play('p', 'Idle');
    run(h, 0.5);
    h.play('p', 'Walk', { crossfade: 0.2 });
    let layers = h.layersOf('p');
    expect(layers.map((l) => l.clip)).toEqual(['Idle', 'Walk']);
    expect(layers[0].weight).toBeCloseTo(1, 6);
    run(h, 0.1);
    layers = h.layersOf('p');
    expect(layers[0].weight + layers[1].weight).toBeCloseTo(1, 6);
    expect(layers[1].weight).toBeCloseTo(0.5, 1);
    run(h, 0.15);
    layers = h.layersOf('p');
    expect(layers).toHaveLength(1);
    expect(layers[0]).toMatchObject({ clip: 'Walk', weight: 1 });
  });

  it('sem crossfade informado vale o crossfadeDuration do nó; 0 = troca seca', () => {
    const a = host({ crossfade: 0.4 });
    a.h.play('p', 'Idle');
    a.h.play('p', 'Walk');
    expect(a.h.stateOf('p')!.fade?.seconds).toBeCloseTo(0.4, 6);
    const b = host();
    b.h.play('p', 'Idle');
    b.h.play('p', 'Walk', { crossfade: 0 });
    expect(b.h.stateOf('p')!.fade).toBeNull();
    expect(b.h.layersOf('p')).toHaveLength(1);
  });

  it('tocar o clipe que já toca não reinicia nem faz crossfade', () => {
    const { h } = host();
    h.play('p', 'Walk');
    run(h, 0.4);
    h.play('p', 'Walk');
    expect(h.stateOf('p')!.time).toBeCloseTo(0.4, 2);
    expect(h.stateOf('p')!.fade).toBeNull();
  });
});

describe('autoplay e eventos', () => {
  it('autoplay + currentAnimation começam tocando no registro', () => {
    const { h } = host({ initial: 'Walk', autoplay: true });
    expect(h.stateOf('p')).toMatchObject({ clip: 'Walk', playing: true });
    expect(h.drainEvents().map((e) => e.name)).toContain('animation_started');
  });

  it('sem autoplay o clipe inicial fica selecionado e parado', () => {
    const { h } = host({ initial: 'Walk', autoplay: false });
    expect(h.stateOf('p')).toMatchObject({ clip: 'Walk', playing: false });
  });

  it('animation_started / animation_changed ao trocar; animation_finished só ao fim de um clipe SEM loop', () => {
    const { h } = host();
    h.play('p', 'Idle');
    expect(h.drainEvents().map((e) => e.name)).toEqual(['animation_changed', 'animation_started']);
    h.play('p', 'Jump');
    h.drainEvents();
    run(h, 1.5);
    expect(h.drainEvents().filter((e) => e.name === 'animation_finished')).toEqual([{ playerId: 'p', name: 'animation_finished', clip: 'Jump' }]);
    run(h, 1);
    expect(h.drainEvents()).toEqual([]); // não repete
  });

  it('clipe em loop nunca emite animation_finished; pause também não', () => {
    const { h } = host();
    h.play('p', 'Walk');
    h.drainEvents();
    run(h, 3);
    h.pause('p', true);
    run(h, 0.5);
    expect(h.drainEvents().filter((e) => e.name === 'animation_finished')).toEqual([]);
  });
});

describe('erros explícitos e fila antes do registro', () => {
  it('clipe inexistente devolve erro com a lista dos clipes', () => {
    const { h } = host();
    expect(h.play('p', 'Dance')).toMatch(/"Dance" não existe.*Idle, Walk, Run, Jump/);
  });

  it('pedidos feitos antes do registro rodam quando os clipes chegam', () => {
    const h = new AnimationHost();
    expect(h.play('p', 'Walk')).toBeNull(); // clipes ainda carregando
    expect(h.setSpeed('p', 2)).toBeNull();
    expect(h.isRegistered('p')).toBe(false);
    h.register('p', { clips: CLIPS });
    expect(h.stateOf('p')).toMatchObject({ clip: 'Walk', playing: true, speed: 2 });
  });

  it('pedido adiado com clipe inválido vira problema (ninguém mais recebe o retorno)', () => {
    const problems: string[] = [];
    const h = new AnimationHost((code) => problems.push(code));
    h.play('p', 'Dance');
    h.register('p', { clips: CLIPS });
    expect(problems).toEqual(['animation.unknown_clip']);
  });

  it('a fila é limitada', () => {
    const h = new AnimationHost();
    let overflow: string | null = null;
    for (let i = 0; i < 40; i++) overflow = h.setSpeed('p', 1) ?? overflow;
    expect(overflow).toMatch(/pedidos demais/);
  });

  it('clear/unregister descartam o estado e a fila', () => {
    const { h } = host();
    h.play('p', 'Walk');
    h.clear();
    expect(h.isRegistered('p')).toBe(false);
    expect(h.drainEvents()).toEqual([]);
    expect(h.layersOf('p')).toEqual([]);
  });
});

describe('faixa de velocidade', () => {
  it('setSpeed limita a 0,25–2 (a mesma faixa do Inspector e da Action)', () => {
    const { h } = host();
    h.setSpeed('p', 5);
    expect(h.stateOf('p')!.speed).toBe(2);
    h.setSpeed('p', -3);
    expect(h.stateOf('p')!.speed).toBe(0.25);
  });
});
