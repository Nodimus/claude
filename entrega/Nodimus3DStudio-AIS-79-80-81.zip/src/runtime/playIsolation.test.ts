import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance, LogicAction, LogicEventRule } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { AuthoringModel } from '../core/authoring/AuthoringModel';
import { CommandManager } from '../core/commandManager';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { serializeSceneToJson } from '../core/serialization/sceneSerializer';
import { ensureRapier } from '../core/physics/rapierInit';
import { InputManager } from './input/InputManager';
import { RuntimeSession, activateRuntimeSession, getActiveRuntimeSession } from './RuntimeSession';
import { requestStepFrame, startPlaySession, stopPlaySession, takeStepFrameRequest } from './logicRunnerSession';

/**
 * AIS-46 — Sandbox isolado do Play: o Play roda sobre um CLONE profundo da cena e o editor fica 100% inalterado. Estes testes provam
 * C01 (clone do SceneData inteiro), C02–C04 (física/lógica no clone, teardown com `world.free()`), C05 (comparação serializada
 * antes/depois), C06 (Pausar congela e "Avançar 1 Quadro" roda exatamente um passo) e C07 (5 ciclos com contagens estáveis).
 */

beforeAll(async () => {
  await ensureRapier();
});

let seq = 0;
const act = (type: string, parameters: Record<string, any> = {}): LogicAction => ({ id: `a${++seq}`, type, parameters });
const rule = (eventType: string, actions: LogicAction[], parameters: Record<string, any> = {}): LogicEventRule => ({ id: `r${++seq}`, eventType, parameters, conditions: [], actions });
const behavior = (...rules: LogicEventRule[]): BehaviorInstance => ({ id: `b${++seq}`, name: 'Regras', behaviorType: 'custom_rules', enabled: true, properties: {}, rules });

const node = (id: string, at: [number, number, number], extra: Record<string, any> = {}, nodeExtra: Partial<GameNode> = {}): GameNode =>
  ({
    id,
    name: id,
    type: 'MeshInstance',
    parentId: null,
    childrenIds: [],
    visible: true,
    locked: false,
    properties: { meshType: 'CubeMesh', position: { x: at[0], y: at[1], z: at[2] }, ...extra },
    ...nodeExtra,
  }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  return { ...scene, nodes };
}

const fakeInput = () => ({
  isActionPressed: () => false,
  isActionJustPressed: () => false,
  isActionJustReleased: () => false,
  getAxis: () => 0,
  isBindingPressed: () => false,
  isBindingJustPressed: () => false,
  isBindingJustReleased: () => false,
});

const gameplayScene = () =>
  sceneWith(
    node('floor', [0, -0.5, 0], { scale: { x: 40, y: 1, z: 40 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } }),
    // corpo físico: o Rapier é o dono da pose (a lógica só mexe em variáveis dele)
    node('crate', [0, 6, 0], { physics: { enabled: true, bodyMode: 'dynamic', shape: 'auto' } }, {
      variables: { hp: 10 },
      behaviors: [behavior(rule('on_update', [act('subtract_from_variable', { scope: 'local', target: 'crate', variable: 'hp', amount: 1 }), act('add_to_variable', { variable: 'score', amount: 1 })]))],
    } as any),
    // nó SEM física: a lógica é a dona da pose
    node('mover', [-4, 1, 0], {}, { behaviors: [behavior(rule('on_update', [act('move_by', { dx: 0.5 })]))] } as any),
    node('victim', [4, 0.5, 0], {}, { behaviors: [behavior(rule('on_start', [act('destroy_node', { target: 'victim' })]))] } as any)
  );

const run = (session: RuntimeSession, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) session.step(1 / 60);
};

/** Todas as referências de objeto alcançáveis de `root` (para provar que o clone não compartilha nada com o original). */
function collectObjects(root: unknown, into = new Set<object>()): Set<object> {
  if (root && typeof root === 'object' && !into.has(root as object)) {
    into.add(root as object);
    for (const value of Object.values(root as Record<string, unknown>)) collectObjects(value, into);
  }
  return into;
}

describe('C01 — o SceneData inteiro é clonado profundamente ao iniciar o Play', () => {
  it('o snapshot cobre TODOS os nós e não compartilha nenhuma referência de objeto com a cena do editor', () => {
    const scene = gameplayScene();
    const snapshot = createRuntimeSnapshot(scene);
    expect(Object.keys(snapshot.nodes).sort()).toEqual(Object.keys(scene.nodes).sort());
    const original = collectObjects(scene);
    const shared = [...collectObjects(snapshot)].filter((o) => original.has(o));
    expect(shared).toEqual([]); // nada alcançável do clone é objeto da cena autoral
  });

  it('mudar a cena do editor DEPOIS do clone não altera o clone (e vice-versa o Play não vaza para o editor)', () => {
    const scene = gameplayScene();
    const snapshot = createRuntimeSnapshot(scene);
    const before = JSON.stringify(snapshot);
    (scene.nodes.crate.properties as any).position.y = 123;
    (scene.nodes.crate.behaviors as any)[0].rules[0].eventType = 'on_start';
    expect(JSON.stringify(snapshot)).toBe(before);
  });
});

describe('C02–C05 — física e lógica rodam no clone; o editor fica byte-a-byte igual', () => {
  it('Play → Stop com física, Behaviors, variáveis e nó destruído: cena, projeto, serialização e histórico idênticos', () => {
    const scene = gameplayScene();
    const model = new AuthoringModel({ files: {}, settings: { general: {} }, globalVariables: [{ id: 'g', name: 'score', type: 'number', value: 0 }] } as any, scene);
    const commands = new CommandManager();
    const sceneBefore = JSON.stringify(model.getScene());
    const fileBefore = serializeSceneToJson(model.getScene());
    const projectBefore = JSON.stringify(model.getProject());
    const historyBefore = commands.getHistory().length;

    const session = new RuntimeSession({ snapshot: model.createSceneSnapshot(), globals: model.getProject().globalVariables, input: fakeInput() });
    session.start();
    run(session, 3);

    // o jogo de fato aconteceu NO CLONE: física (C02), lógica (C03), variável, destruição
    expect(session.physics).not.toBeNull();
    expect(session.getSimulatedTransform('crate')!.position[1]).toBeLessThan(2); // caiu
    expect(session.getSimulatedTransform('mover')!.position[0]).toBeGreaterThan(1); // a lógica o moveu (pose do clone)
    expect(session.variables!.getVariable('local', 'hp', 'crate')).toBeLessThan(10);
    expect(session.variables!.getVariable('global', 'score')).toBeGreaterThan(0);
    expect(session.currentScene!.getInstance('victim')).toBeUndefined();
    const bridge = session.physics!;
    const live = session.currentScene!;

    session.dispose();

    // C04 — descartado: mundo liberado, cena viva descartada, sem corpos nem objetos residuais
    expect(bridge.isDisposed).toBe(true);
    expect(bridge.bodyCount).toBe(0);
    expect(live.disposed).toBe(true);
    expect(session.sceneManager.liveObjectCount).toBe(0);
    expect(session.physics).toBeNull();

    // C05 — comparação serializada: ZERO alteração
    expect(JSON.stringify(model.getScene())).toBe(sceneBefore);
    expect(serializeSceneToJson(model.getScene())).toBe(fileBefore);
    expect(JSON.stringify(model.getProject())).toBe(projectBefore);
    expect(commands.getHistory().length).toBe(historyBefore);
  });
});

describe('C06 — Pausar congela de fato; Avançar 1 Quadro roda exatamente um passo', () => {
  const crateY = (s: RuntimeSession) => s.getSimulatedTransform('crate')!.position[1];

  it('em pausa nenhum corpo se move e o tempo da sessão não anda', () => {
    const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(gameplayScene()), input: fakeInput() });
    session.start();
    run(session, 0.5);
    session.pause();
    const y = crateY(session);
    const t = session.elapsedTime;
    run(session, 2);
    expect(crateY(session)).toBe(y);
    expect(session.elapsedTime).toBe(t);
    expect(session.status).toBe('paused');
    session.resume();
    run(session, 0.2);
    expect(crateY(session)).toBeLessThan(y); // retomar volta a simular
  });

  it('stepFrame avança UM passo fixo (v = g·dt) e segue pausada; fora de pausa não faz nada', () => {
    const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(gameplayScene()), input: fakeInput() });
    session.start();
    expect(session.stepFrame()).toBe(false); // rodando: o botão não se aplica
    session.pause();
    const y0 = crateY(session);
    const t0 = session.elapsedTime;
    const bridge = session.physics!;
    expect(session.stepFrame()).toBe(true);
    expect(session.status).toBe('paused');
    expect(session.elapsedTime).toBeCloseTo(t0 + 1 / 60, 6);
    expect(bridge.getPose('crate')!.linearVelocity.y).toBeCloseTo(-9.8 / 60, 2); // exatamente um passo de gravidade
    expect(crateY(session)).toBeLessThan(y0);
    const y1 = crateY(session);
    session.stepFrame();
    session.stepFrame();
    expect(bridge.getPose('crate')!.linearVelocity.y).toBeCloseTo((-9.8 * 3) / 60, 2); // três quadros = três passos
    expect(crateY(session)).toBeLessThan(y1);
    run(session, 1); // pausa continua valendo
    expect(bridge.getPose('crate')!.linearVelocity.y).toBeCloseTo((-9.8 * 3) / 60, 2);
  });

  it('pedidos de "Avançar 1 Quadro": só valem em pausa, cada um vira UM quadro, e não sobrevivem ao Stop', () => {
    const snapshot = createRuntimeSnapshot(gameplayScene());
    const session = startPlaySession({ snapshot, mode: 'scene', globals: [] });
    requestStepFrame(); // rodando: ignorado
    expect(takeStepFrameRequest()).toBe(false);
    session.pause();
    requestStepFrame();
    requestStepFrame();
    expect(takeStepFrameRequest()).toBe(true);
    expect(takeStepFrameRequest()).toBe(true);
    expect(takeStepFrameRequest()).toBe(false);
    requestStepFrame();
    stopPlaySession();
    expect(takeStepFrameRequest()).toBe(false); // limpo no Stop
    expect(getActiveRuntimeSession()).toBeNull();
  });
});

describe('C07 — 5 ciclos Play/Stop: contagens estáveis (auditoria F1–F5)', () => {
  it('objetos vivos, corpos, listeners, sessões e diagnósticos voltam ao mesmo valor em todos os ciclos', () => {
    const input = new InputManager();
    const listenersBase = input.listenerCount;
    const diagnostics = new DiagnosticService();
    const diagBase = diagnostics.list().length;
    const during: number[][] = [];
    const after: number[][] = [];

    for (let cycle = 0; cycle < 5; cycle++) {
      const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(gameplayScene()), globals: [{ name: 'score', type: 'number', value: 0 }], input, diagnostics });
      activateRuntimeSession(session);
      session.start();
      const detach = input.attach({ keyTarget: { addEventListener() {}, removeEventListener() {} } });
      run(session, 1);
      during.push([session.sceneManager.liveObjectCount, session.physics!.bodyCount, input.listenerCount]);
      const manager = session.sceneManager;
      const bridge = session.physics!;
      detach();
      activateRuntimeSession(null);
      after.push([manager.liveObjectCount, bridge.bodyCount, input.listenerCount, diagnostics.list().length, getActiveRuntimeSession() === null ? 1 : 0]);
      expect(bridge.isDisposed).toBe(true);
    }
    // durante o Play: o mesmo número de objetos/corpos/listeners em TODOS os ciclos
    expect(new Set(during.map((d) => d.join(','))).size).toBe(1);
    // depois do Stop: tudo zerado/igual ao início
    for (const a of after) expect(a).toEqual([0, 0, listenersBase, diagBase, 1]);
  });

  it('dois Plays seguidos não geram duas sessões vivas (o segundo descarta o primeiro)', () => {
    const first = startPlaySession({ snapshot: createRuntimeSnapshot(gameplayScene()), mode: 'scene', globals: [] });
    const bridge = first.physics;
    const second = startPlaySession({ snapshot: createRuntimeSnapshot(gameplayScene()), mode: 'scene', globals: [] });
    expect(first.isDisposed).toBe(true);
    expect(bridge?.isDisposed ?? true).toBe(true);
    expect(getActiveRuntimeSession()).toBe(second);
    stopPlaySession();
    expect(second.isDisposed).toBe(true);
  });
});
