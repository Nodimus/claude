import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import {
  CANONICAL_BONES,
  REQUIRED_BONES,
  autoMapBones,
  detectConvention,
  emptyBoneMap,
  normalizeBoneName,
  parseBoneName,
  overlaySegments,
  quaternionAngleDeg,
  restPoseMismatches,
  retargetClip,
  rigDiagnostics,
  validateBoneMap,
  type BoneMap,
  type ClipLike,
} from './skeletalAnimation';
import { RigConfigSchema, parseRigConfig } from '../schemas/v1/rig.schema';

const mixamo = (n: string) => `mixamorig:${n}`;
const MIXAMO = [
  'Hips', 'Spine', 'Spine1', 'Spine2', 'Neck', 'Head', 'HeadTop_End',
  'LeftShoulder', 'LeftArm', 'LeftForeArm', 'LeftHand', 'LeftHandThumb1', 'LeftHandIndex1',
  'RightShoulder', 'RightArm', 'RightForeArm', 'RightHand', 'RightHandThumb1',
  'LeftUpLeg', 'LeftLeg', 'LeftFoot', 'LeftToeBase', 'LeftToe_End',
  'RightUpLeg', 'RightLeg', 'RightFoot', 'RightToeBase',
].map(mixamo);

const RIGIFY = [
  'DEF-spine', 'DEF-spine.001', 'DEF-spine.002', 'DEF-spine.003', 'DEF-spine.004', 'DEF-spine.005', 'DEF-spine.006',
  'DEF-shoulder.L', 'DEF-upper_arm.L', 'DEF-upper_arm.L.001', 'DEF-forearm.L', 'DEF-hand.L', 'DEF-f_index.01.L',
  'DEF-shoulder.R', 'DEF-upper_arm.R', 'DEF-forearm.R', 'DEF-hand.R',
  'DEF-thigh.L', 'DEF-shin.L', 'DEF-foot.L', 'DEF-toe.L', 'DEF-thigh.R', 'DEF-shin.R', 'DEF-foot.R', 'DEF-toe.R',
];

const UNITY = [
  'Hips', 'Spine', 'Chest', 'UpperChest', 'Neck', 'Head',
  'LeftShoulder', 'LeftUpperArm', 'LeftLowerArm', 'LeftHand', 'LeftThumbProximal',
  'RightShoulder', 'RightUpperArm', 'RightLowerArm', 'RightHand',
  'LeftUpperLeg', 'LeftLowerLeg', 'LeftFoot', 'LeftToes',
  'RightUpperLeg', 'RightLowerLeg', 'RightFoot', 'RightToes',
];

// Godot Humanoid (SkeletonProfileHumanoid): mesmos nomes do Unity, com `Root` acima do `Hips`
const GODOT = ['Root', ...UNITY];

const expectFull = (names: string[], expected: Record<string, string>) => {
  const r = autoMapBones(names);
  expect(r.missing).toEqual([]);
  expect(r.confidence).toBe(1);
  for (const [bone, name] of Object.entries(expected)) expect(r.map[bone as keyof BoneMap]).toBe(name);
  return r;
};

describe('normalizeBoneName / parseBoneName', () => {
  it('remove prefixos, separadores e caixa; lateralidade .L/_L/Left', () => {
    expect(normalizeBoneName('mixamorig:LeftHand')).toBe('lefthand');
    expect(normalizeBoneName('mixamorig_RightUpLeg')).toBe('rightupleg');
    expect(normalizeBoneName('Armature|Hips')).toBe('hips');
    expect(normalizeBoneName('DEF-upper_arm.L')).toBe('leftupperarm');
    expect(normalizeBoneName('DEF-forearm.R')).toBe('rightforearm');
    expect(normalizeBoneName('upperarm_l')).toBe('leftupperarm');
    expect(normalizeBoneName('thigh.R')).toBe('rightthigh');
    expect(normalizeBoneName('HandLeft')).toBe('lefthand');
    expect(normalizeBoneName('L_Foot')).toBe('leftfoot');
    expect(normalizeBoneName('DEF-spine.001')).toBe('spine001');
  });
  it('não confunde osso sem lateralidade que apenas começa/termina com l/r', () => {
    expect(parseBoneName('Leg')).toEqual({ side: null, base: 'leg' });
    expect(parseBoneName('LowerArm')).toEqual({ side: null, base: 'lowerarm' });
    expect(parseBoneName('Spine1')).toEqual({ side: null, base: 'spine1' });
    expect(parseBoneName('upper_leg').side).toBeNull();
  });
});

describe('autoMapBones — as quatro nomenclaturas (AIS-36-C01)', () => {
  it('Mixamo: 19 ossos; dedos e dedos do pé ignorados', () => {
    const r = expectFull(MIXAMO, {
      Hips: 'mixamorig:Hips', Spine: 'mixamorig:Spine', Chest: 'mixamorig:Spine1', Neck: 'mixamorig:Neck', Head: 'mixamorig:Head',
      LeftShoulder: 'mixamorig:LeftShoulder', LeftArm: 'mixamorig:LeftArm', LeftForeArm: 'mixamorig:LeftForeArm', LeftHand: 'mixamorig:LeftHand',
      RightHand: 'mixamorig:RightHand', LeftUpLeg: 'mixamorig:LeftUpLeg', LeftLeg: 'mixamorig:LeftLeg', LeftFoot: 'mixamorig:LeftFoot', RightFoot: 'mixamorig:RightFoot',
    });
    expect(r.convention).toBe('generic');
    expect(Object.values(r.map)).not.toContain('mixamorig:LeftHandThumb1');
    expect(Object.values(r.map)).not.toContain('mixamorig:LeftToeBase');
  });
  it('Blender Rigify (DEF-*)', () => {
    const r = expectFull(RIGIFY, {
      Hips: 'DEF-spine', Spine: 'DEF-spine.001', Chest: 'DEF-spine.002', Neck: 'DEF-spine.004', Head: 'DEF-spine.006',
      LeftShoulder: 'DEF-shoulder.L', LeftArm: 'DEF-upper_arm.L', LeftForeArm: 'DEF-forearm.L', LeftHand: 'DEF-hand.L',
      RightArm: 'DEF-upper_arm.R', LeftUpLeg: 'DEF-thigh.L', LeftLeg: 'DEF-shin.L', LeftFoot: 'DEF-foot.L', RightUpLeg: 'DEF-thigh.R', RightFoot: 'DEF-foot.R',
    });
    expect(r.convention).toBe('rigify');
    expect(Object.values(r.map)).not.toContain('DEF-upper_arm.L.001');
  });
  it('Unity Humanoid', () => {
    const r = expectFull(UNITY, {
      Hips: 'Hips', Spine: 'Spine', Chest: 'Chest', Neck: 'Neck', Head: 'Head', LeftArm: 'LeftUpperArm', LeftForeArm: 'LeftLowerArm',
      LeftUpLeg: 'LeftUpperLeg', LeftLeg: 'LeftLowerLeg', RightFoot: 'RightFoot',
    });
    expect(Object.values(r.map)).not.toContain('UpperChest');
  });
  it('Godot Humanoid: `Root/Hips` é UM osso (o Hips de verdade; Root não entra)', () => {
    const r = expectFull(GODOT, { Hips: 'Hips', Spine: 'Spine', LeftHand: 'LeftHand', RightLeg: 'RightLowerLeg' });
    expect(Object.values(r.map)).not.toContain('Root');
  });
  it('Root só vale como Hips quando não existe um osso de quadril', () => {
    const r = autoMapBones(['Root', 'Spine', 'Head']);
    expect(r.map.Hips).toBe('Root');
  });
  it('nomes vindos de `Armature|…` (export Blender/FBX) também são reconhecidos', () => {
    const r = autoMapBones(UNITY.map((n) => `Armature|${n}`));
    expect(r.missing).toEqual([]);
    expect(r.map.Hips).toBe('Armature|Hips');
  });
});

// O `GLTFLoader`/`THREE.Skeleton` entregam o nome JÁ sanitizado (`PropertyBinding.sanitizeNodeName`: tira `:`, `.`, `[`, `]`, `/`).
// Estes testes espelham o que o loader realmente entrega ao mapeador (o Rigify quebrava: `DEF-hand.L` → `DEF-handL`).
const sanitized = (names: string[]) => names.map((n) => THREE.PropertyBinding.sanitizeNodeName(n));

describe('nomes sanitizados pelo three (AIS-36 pendência: nome de origem = nome do THREE.Skeleton)', () => {
  it('o three realmente tira ":" e "." (premissa do teste)', () => {
    expect(THREE.PropertyBinding.sanitizeNodeName('DEF-hand.L')).toBe('DEF-handL');
    expect(THREE.PropertyBinding.sanitizeNodeName('mixamorig:Hips')).toBe('mixamorigHips');
  });
  it('lado colado no fim: handL, shinR, upper_armL001; sem confundir Hips/Chest/Head/Spine1', () => {
    expect(normalizeBoneName('DEF-handL')).toBe('lefthand');
    expect(normalizeBoneName('DEF-shinR')).toBe('rightshin');
    expect(normalizeBoneName('DEF-upper_armL')).toBe('leftupperarm');
    expect(normalizeBoneName('DEF-upper_armL001')).toBe('leftupperarm001');
    expect(parseBoneName('Hips').side).toBeNull();
    expect(parseBoneName('Chest').side).toBeNull();
    expect(parseBoneName('Head').side).toBeNull();
    expect(parseBoneName('mixamorigSpine1').side).toBeNull();
    expect(parseBoneName('DEF-spine001')).toEqual({ side: null, base: 'spine001' });
  });
  it('Rigify sanitizado: 19/19, confiança 1.0, mesmos ossos (agora com o nome do loader)', () => {
    const names = sanitized(RIGIFY);
    const r = autoMapBones(names);
    expect(r.convention).toBe('rigify');
    expect(r.missing).toEqual([]);
    expect(r.confidence).toBe(1);
    expect(r.map.Hips).toBe('DEF-spine');
    expect(r.map.Spine).toBe('DEF-spine001');
    expect(r.map.Head).toBe('DEF-spine006');
    expect(r.map.LeftArm).toBe('DEF-upper_armL');
    expect(r.map.RightForeArm).toBe('DEF-forearmR');
    expect(r.map.LeftUpLeg).toBe('DEF-thighL');
    expect(r.map.RightLeg).toBe('DEF-shinR');
    expect(r.map.LeftFoot).toBe('DEF-footL');
    expect(Object.values(r.map)).not.toContain('DEF-upper_armL001'); // osso de torção fica de fora
  });
  it('Mixamo, Unity e Godot sanitizados continuam 19/19', () => {
    for (const set of [MIXAMO, UNITY, GODOT]) {
      const r = autoMapBones(sanitized(set));
      expect(r.missing).toEqual([]);
      expect(r.confidence).toBe(1);
    }
    expect(autoMapBones(sanitized(MIXAMO)).map.Chest).toBe('mixamorigSpine1');
  });
  it('o retarget entre rigs sanitizados renomeia as trilhas com o nome do loader', () => {
    const src = autoMapBones(sanitized(MIXAMO)).map;
    const dst = autoMapBones(sanitized(RIGIFY)).map;
    const out = retargetClip({ name: 'A', duration: 1, tracks: [{ name: 'mixamorigLeftArm.quaternion', times: [0], values: [0, 0, 0, 1] }] }, src, dst);
    expect(out.clip.tracks[0].name).toBe('DEF-upper_armL.quaternion');
  });
});

describe('validação e diagnósticos (AIS-36-C02, C04)', () => {
  it('lista os obrigatórios faltantes; opcionais ausentes não reprovam', () => {
    const noChest = autoMapBones(MIXAMO.filter((n) => !/Spine1|Neck|Shoulder/.test(n)));
    const v = validateBoneMap(noChest.map);
    expect(v.humanoid).toBe(true);
    expect(v.missingOptional).toEqual(expect.arrayContaining(['Chest', 'Neck', 'LeftShoulder']));
    const broken = autoMapBones(MIXAMO.filter((n) => !/RightLeg|LeftArm$/.test(n)));
    const bv = validateBoneMap(broken.map);
    expect(bv.humanoid).toBe(false);
    expect(bv.missingRequired).toEqual(expect.arrayContaining(['RightLeg', 'LeftArm']));
    expect(REQUIRED_BONES.every((b) => (CANONICAL_BONES as readonly string[]).includes(b))).toBe(true);
  });
  it('correção manual: trocar o osso de um canônico remove a falta; osso repetido é acusado', () => {
    const base = autoMapBones(MIXAMO.filter((n) => !/RightLeg/.test(n)));
    expect(validateBoneMap(base.map).missingRequired).toEqual(['RightLeg']);
    const fixed = { ...base.map, RightLeg: 'mixamorig:RightLeg' };
    expect(validateBoneMap(fixed).humanoid).toBe(true);
    const dup = { ...fixed, RightLeg: 'mixamorig:LeftLeg' };
    expect(validateBoneMap(dup).duplicates).toEqual(['mixamorig:LeftLeg']);
  });
  it('rig.not_humanoid (info) sem esqueleto ou com poucos ossos; rig.missing_bones (warning) com faltantes', () => {
    expect(rigDiagnostics([], emptyBoneMap())).toEqual([expect.objectContaining({ code: 'rig.not_humanoid', severity: 'info' })]);
    const tail = ['Wing_01', 'Wing_02', 'Tail_01'];
    expect(rigDiagnostics(tail, autoMapBones(tail).map)[0]).toMatchObject({ code: 'rig.not_humanoid', severity: 'info' });
    const partial = MIXAMO.filter((n) => !/RightLeg/.test(n));
    expect(rigDiagnostics(partial, autoMapBones(partial).map)[0]).toMatchObject({ code: 'rig.missing_bones', severity: 'warning' });
    expect(rigDiagnostics(MIXAMO, autoMapBones(MIXAMO).map)).toEqual([]);
  });
  it('detectConvention distingue Rigify (DEF-) do resto', () => {
    expect(detectConvention(RIGIFY)).toBe('rigify');
    expect(detectConvention(MIXAMO)).toBe('generic');
  });
});

describe('retargetClip (AIS-36-C06)', () => {
  const source = autoMapBones(MIXAMO).map;
  const target = autoMapBones(UNITY).map;
  const clip = (): ClipLike => ({
    name: 'Walk',
    duration: 1,
    tracks: [
      { name: 'mixamorig:Hips.position', times: [0, 1], values: [0, 1, 0, 0, 1, 2] },
      { name: 'mixamorig:Hips.quaternion', times: [0, 1], values: [0, 0, 0, 1, 0, 0, 0, 1] },
      { name: 'mixamorig:LeftArm.quaternion', times: [0, 1], values: [0, 0, 0, 1, 0, 0, 0.1, 0.99] },
      { name: 'mixamorig:LeftHandThumb1.quaternion', times: [0], values: [0, 0, 0, 1] },
    ],
  });

  it('renomeia as trilhas passando pelos nomes canônicos e não muta a entrada', () => {
    const input = clip();
    const snapshot = JSON.stringify(input);
    const r = retargetClip(input, source, target);
    expect(JSON.stringify(input)).toBe(snapshot);
    expect(r.clip.tracks.map((t) => t.name)).toEqual(['Hips.position', 'Hips.quaternion', 'LeftUpperArm.quaternion', 'mixamorig:LeftHandThumb1.quaternion']);
    expect(r.passthrough).toEqual(['mixamorig:LeftHandThumb1.quaternion']);
    expect(r.warnings).toEqual([]);
    expect(r.clip.duration).toBe(1);
    expect(Array.from(r.clip.tracks[2].times)).toEqual([0, 1]);
  });
  it('escala a translação do Hips pela razão de altura do quadril; só o Hips', () => {
    const r = retargetClip(clip(), source, target, { sourceHipHeight: 1, targetHipHeight: 0.5 });
    expect(Array.from(r.clip.tracks[0].values)).toEqual([0, 0.5, 0, 0, 0.5, 1]);
    expect(Array.from(r.clip.tracks[1].values)).toEqual([0, 0, 0, 1, 0, 0, 0, 1]);
  });
  it('osso mapeado na origem mas ausente no alvo: trilha descartada e aviso', () => {
    const noArm = { ...target, LeftArm: null };
    const r = retargetClip(clip(), source, noArm);
    expect(r.dropped).toEqual(['mixamorig:LeftArm.quaternion']);
    expect(r.warnings).toEqual([expect.objectContaining({ code: 'anim.target_bone_missing', bones: ['LeftArm'] })]);
  });
  it('sinaliza anim.rest_pose_mismatch quando as poses de repouso divergem (T-pose × A-pose) e não finge corrigir', () => {
    const identity = [0, 0, 0, 1] as const;
    const tilt45 = [0, 0, Math.sin(Math.PI / 8), Math.cos(Math.PI / 8)] as const; // 45° em Z
    const r = retargetClip(clip(), source, target, {
      sourceRestPose: { LeftArm: identity, Hips: identity },
      targetRestPose: { LeftArm: tilt45, Hips: identity },
    });
    const warn = r.warnings.find((w) => w.code === 'anim.rest_pose_mismatch');
    expect(warn?.bones).toEqual(['LeftArm']);
    // as trilhas continuam só renomeadas (valores intocados)
    expect(Array.from(r.clip.tracks[2].values)).toEqual([0, 0, 0, 1, 0, 0, 0.1, 0.99]);
    // mesma pose: sem aviso; pose desconhecida: sem aviso (não inventa)
    expect(retargetClip(clip(), source, target, { sourceRestPose: { LeftArm: identity }, targetRestPose: { LeftArm: identity } }).warnings).toEqual([]);
    expect(retargetClip(clip(), source, target).warnings).toEqual([]);
  });
  it('ângulo entre quaternions e tolerância', () => {
    expect(quaternionAngleDeg([0, 0, 0, 1], [0, 0, 0, -1])).toBeCloseTo(0, 5);
    expect(quaternionAngleDeg([0, 0, 0, 1], [0, 0, Math.sin(Math.PI / 4), Math.cos(Math.PI / 4)])).toBeCloseTo(90, 4);
    const small = [0, 0, Math.sin(0.05), Math.cos(0.05)] as const; // ~5.7°
    expect(restPoseMismatches({ Hips: [0, 0, 0, 1] }, { Hips: small })).toEqual([]);
    expect(restPoseMismatches({ Hips: [0, 0, 0, 1] }, { Hips: small }, 2)).toEqual(['Hips']);
  });
});

describe('RigConfig (Zod v1) (AIS-36-C03)', () => {
  const asset = { id: 'res_model', type: 'mesh', path: 'res://models/Hero.glb' };
  it('round-trip sem perder ossos nem clipes; nenhum keyframe', () => {
    const bones = autoMapBones(MIXAMO).map;
    const rig = RigConfigSchema.parse({ asset, standard: 'humanoid19', bones, clips: [{ name: 'Walk', source: { id: 'res_clip' } }] });
    const back = parseRigConfig(JSON.stringify(rig));
    expect(back.ok && back.legacy).toBe(false);
    expect(back.ok && back.rig).toEqual(rig);
    expect(JSON.stringify(rig)).not.toMatch(/times|values|keyframe/);
  });
  it('legado/tolerante: sem schemaVersion lê; osso inválido vira null; chave desconhecida é ignorada; sem asset falha tipado', () => {
    const r = parseRigConfig({ asset, bones: { Hips: 'Hips', Head: 42, Cauda: 'Tail' }, clips: [{ name: 'A' }, 7] });
    expect(r.ok && r.legacy).toBe(true);
    if (!r.ok) return;
    expect(r.rig.bones.Hips).toBe('Hips');
    expect(r.rig.bones.Head).toBeNull();
    expect('Cauda' in r.rig.bones).toBe(false);
    expect(r.rig.clips).toEqual([{ name: 'A' }]);
    expect(Object.keys(r.rig.bones)).toEqual([...CANONICAL_BONES]);
    expect(parseRigConfig({ bones: {} }).ok).toBe(false);
    expect(parseRigConfig('{ quebrado').ok).toBe(false);
    expect(parseRigConfig(null).ok).toBe(false);
  });
});

describe('overlaySegments (overlay do esqueleto só com os ossos mapeados)', () => {
  it('liga cada osso mapeado ao ancestral mapeado mais próximo; dedos e torção ficam de fora', () => {
    const parentOf = new Map<string, string | null>([
      ['Hips', null], ['Spine', 'Hips'], ['Arm', 'Spine'], ['Fore', 'Arm'], ['Hand', 'Fore'],
      ['Thumb1', 'Hand'], ['Thumb2', 'Thumb1'], ['ArmTwist', 'Arm'], ['Head', 'Spine'],
    ]);
    const mapped = new Set(['Hips', 'Spine', 'Arm', 'Fore', 'Hand', 'Head']);
    expect(overlaySegments(parentOf, mapped).map(([a, b]) => `${a}>${b}`).sort()).toEqual(['Arm>Fore', 'Fore>Hand', 'Hips>Spine', 'Spine>Arm', 'Spine>Head']);
  });
  it('pula ossos intermediários não mapeados; osso sem ancestral mapeado fica solto; ciclo não trava', () => {
    const parentOf = new Map<string, string | null>([['A', null], ['x', 'A'], ['B', 'x'], ['C', null], ['p', 'q'], ['q', 'p']]);
    expect(overlaySegments(parentOf, new Set(['A', 'B', 'C']))).toEqual([['A', 'B']]);
    expect(overlaySegments(parentOf, new Set(['p']))).toEqual([]);
    expect(overlaySegments(parentOf, new Set(['fantasma']))).toEqual([]);
  });
});
