import { tNow } from '../core/i18n';
import { PrefabV1Schema, type PrefabV1 } from '../schemas/v1/prefab.schema';
import type { GameNode, ResourceRef } from '../types/node';
import type { Vec3 } from '../core/physics/bounds';
import { readPhysics } from '../core/physics/physicsConfig';
import type { VariableManager } from '../core/variableManager';
import type { BehaviorLifecycleHost } from './behaviorLifecycle';
import type { LogicRunner } from './logicRunner';
import type { PhysicsHost } from './physicsHost';
import type { RuntimeInstance, RuntimeScene, SpawnPlacement } from './RuntimeScene';
import { NON_PRESENTABLE_SPAWN_TYPES } from './spawnPresenter';

/**
 * AIS-29g — SpawnHost: o ÚNICO caminho de criação e destruição DINÂMICA de GameNodes durante o Play (projéteis, efeitos, inimigos
 * gerados). Pertence à `RuntimeSession` (um por sessão) e nunca toca o authoring: o prefab é lido (`.prefab.json`, `PrefabV1` validado
 * por Zod) e a subárvore nasce na `RuntimeScene` ativa com ids novos. Registra o que a cena inicial registra — corpo físico
 * (`PhysicsHost.addInstance`), variáveis locais, regras (`LogicRunner.addNodes`) e Behaviors (`BehaviorLifecycleHost.addNodes`) — e
 * desfaz tudo na destruição (`RuntimeScene.destroyInstance` → ouvintes: corpo e variáveis saem junto).
 *
 * Não há spawn parcial: erro de prefab, de pai, de limite ou de criação lança `SpawnError` (e publica o diagnóstico); nada fica
 * criado. Destruições pedidas por `despawn()` são ADIADAS para o fim do quadro (`flush`), seguras dentro de callbacks físicos.
 * Limitação conhecida: conexões de sinal (`node.signals`) de nós do prefab não são ligadas no spawn (o `SignalBus` liga as da cena
 * inicial); um aviso é publicado uma vez por prefab.
 */

export type SpawnErrorCode = 'spawn.prefab_not_loaded' | 'spawn.prefab_invalid' | 'spawn.limit_exceeded' | 'spawn.failed' | 'spawn.session_inactive';

export class SpawnError extends Error {
  constructor(public readonly code: SpawnErrorCode, message: string) {
    super(message);
    this.name = 'SpawnError';
  }
}

export interface SpawnOptions extends SpawnPlacement {
  /** Velocidade linear MUNDIAL aplicada ao corpo da raiz (precisa ser `dynamic`; senão aviso `spawn.velocity_ignored`). */
  initialVelocity?: Vec3;
  /** Nó que originou o spawn (ex.: o atirador). Fica só na instância de runtime. */
  ownerId?: string;
  /** Destruição automática depois de N ms de tempo de JOGO (pausa não conta). */
  lifetimeMs?: number;
}

export interface SpawnedHandle {
  /** Id (runtime, único) do nó raiz do spawn; aceito por `despawn`, `getInstance` e pela `PhysicsBridge`. */
  rootId: string;
  nodeIds: string[];
  prefab: ResourceRef;
  ownerId?: string;
}

export const DEFAULT_MAX_SPAWNS = 512;

export interface SpawnHostDeps {
  scene(): RuntimeScene | null;
  physics(): PhysicsHost | null;
  /** Garante o mundo físico da cena (síncrono se o Rapier já carregou; senão entra quando terminar e chama `onPhysicsReady`). */
  attachPhysics(): void;
  behaviors(): BehaviorLifecycleHost | null;
  runner(): LogicRunner | null;
  variables(): VariableManager | null;
  /** Tempo de jogo da sessão, em segundos. */
  now(): number;
  publish(severity: 'error' | 'warning', code: string, message: string, nodeId?: string): void;
  /** Lê o JSON bruto de um prefab (`ResourceRegistry`). Sem isso só `registerPrefab` alimenta o cache. */
  readPrefab?: (ref: ResourceRef) => Promise<unknown>;
  /** Teto de instâncias vivas criadas por spawn (padrão 512). */
  maxSpawns?: number;
}

export class SpawnHost {
  private readonly prefabs = new Map<string, { ref: ResourceRef; prefab: PrefabV1 }>();
  private readonly deadlines = new Map<string, number>();
  private readonly despawnQueue = new Set<string>();
  private readonly pendingVelocity = new Map<string, Vec3>();
  private readonly warnedSignals = new Set<string>();
  private readonly warnedTypes = new Set<string>();
  private readonly maxSpawns: number;

  constructor(private readonly deps: SpawnHostDeps) {
    this.maxSpawns = deps.maxSpawns ?? DEFAULT_MAX_SPAWNS;
  }

  // ── prefabs (cache da sessão; a leitura do arquivo é assíncrona e acontece ANTES do jogo precisar dela) ──────────────────────

  /** Valida e guarda um prefab já lido. Inválido = diagnóstico e `false` (nada é guardado). */
  registerPrefab(ref: ResourceRef, raw: unknown): boolean {
    const parsed = PrefabV1Schema.safeParse(raw);
    if (!parsed.success) {
      this.deps.publish('error', 'spawn.prefab_invalid', tNow('spawnHostMsgCore.invalidPrefab', { value: ref.path ?? ref.id, value2: parsed.error.issues[0]?.message ?? tNow('spawnHostMsgLast.unknownFormat') }));
      return false;
    }
    this.prefabs.set(ref.id, { ref, prefab: parsed.data });
    return true;
  }

  hasPrefab(ref: ResourceRef): boolean {
    return this.prefabs.has(ref.id);
  }

  /** Lê (`readPrefab`) e registra os prefabs que o jogo vai criar. Devolve os que ficaram carregados. */
  async preloadPrefabs(refs: readonly ResourceRef[]): Promise<ResourceRef[]> {
    const loaded: ResourceRef[] = [];
    for (const ref of refs) {
      if (this.prefabs.has(ref.id)) {
        loaded.push(ref);
        continue;
      }
      if (!this.deps.readPrefab) {
        this.deps.publish('error', 'spawn.prefab_not_loaded', tNow('spawnHostMsgCore.thereIsNoWayTo', { value: ref.path ?? ref.id }));
        continue;
      }
      try {
        if (this.registerPrefab(ref, await this.deps.readPrefab(ref))) loaded.push(ref);
      } catch (error) {
        this.deps.publish('error', 'spawn.prefab_not_loaded', tNow('spawnHostMsgCore.failedToReadThePrefab', { value: ref.path ?? ref.id, value2: error instanceof Error ? error.message : String(error) }));
      }
    }
    return loaded;
  }

  // ── spawn / despawn ─────────────────────────────────────────────────────────────────────────────────────────────────────────

  get liveCount(): number {
    return this.deps.scene()?.getAllInstances().filter((i) => i.origin?.kind === 'spawn').length ?? 0;
  }

  spawn(ref: ResourceRef, options: SpawnOptions = {}): SpawnedHandle {
    const fail = (code: SpawnErrorCode, message: string): never => {
      this.deps.publish('error', code, message, options.ownerId);
      throw new SpawnError(code, message);
    };
    const scene = this.deps.scene();
    if (!scene || scene.disposed) return fail('spawn.session_inactive', tNow('spawnHostMsgCore.thereIsNoRunningScene'));
    const entry = this.prefabs.get(ref.id);
    if (!entry) return fail('spawn.prefab_not_loaded', tNow('spawnHostMsgCore.thePrefabWasNotLoaded', { value: ref.path ?? ref.id }));
    if (options.lifetimeMs !== undefined && !(Number.isFinite(options.lifetimeMs) && options.lifetimeMs > 0)) return fail('spawn.failed', tNow('spawnHostMsgCore.lifetimemsMustBeANumber'));
    const incoming = Object.keys(entry.prefab.nodes).length;
    if (this.liveCount + incoming > this.maxSpawns) return fail('spawn.limit_exceeded', tNow('spawnHostMsgCore.limitOfObjectsCreatedIn', { maxSpawns: this.maxSpawns, name: entry.prefab.name }));

    let result;
    try {
      result = scene.spawnSubtree({ id: entry.prefab.id, rootNodeId: entry.prefab.rootNodeId, nodes: entry.prefab.nodes as unknown as Record<string, GameNode> }, options, { ownerId: options.ownerId });
    } catch (error) {
      return fail('spawn.failed', tNow('spawnHostMsgCore.failedToCreate', { name: entry.prefab.name, value: error instanceof Error ? error.message : String(error) }));
    }
    const { root, instances, nodes } = result;

    // variáveis locais (como a cena inicial) — antes das regras, que podem lê-las
    const variables = this.deps.variables();
    for (const i of instances) variables?.registerLocals(i.persistentNodeId, i.variables);

    // corpo físico: o mundo é criado sob demanda se a cena começou sem nenhum corpo
    const wantsPhysics = instances.some((i) => readPhysics(i.properties)?.enabled === true);
    if (wantsPhysics) {
      if (!this.deps.physics()) this.deps.attachPhysics(); // já cria o corpo dos novos (estão na cena); assíncrono se o Rapier ainda carrega
      else for (const i of instances) this.deps.physics()!.addInstance(i);
    }
    if (options.initialVelocity) this.pendingVelocity.set(root.persistentNodeId, { ...options.initialVelocity });
    if (this.deps.physics()) this.applyPendingVelocity();

    // lógica: Behaviors por propriedade e regras de Visual Logic dos nós novos
    const created = Object.values(nodes);
    this.deps.behaviors()?.addNodes(created);
    this.deps.runner()?.addNodes(created);

    if (options.lifetimeMs !== undefined) this.deadlines.set(root.persistentNodeId, this.deps.now() + options.lifetimeMs / 1000);
    // AIS-44e: tipo que a fábrica não sabe desenhar — o nó simula, mas não aparece (aviso único por tipo e sessão; nunca em silêncio)
    for (const n of created) {
      if (!NON_PRESENTABLE_SPAWN_TYPES.has(n.type) || this.warnedTypes.has(n.type)) continue;
      this.warnedTypes.add(n.type);
      this.deps.publish('warning', 'spawn.node_not_presentable', tNow('spawnHostMsgCore.anObjectCreatedInPlay', { type: n.type, name: entry.prefab.name }), n.id);
    }
    if (created.some((n) => (n.signals?.length ?? 0) > 0) && !this.warnedSignals.has(entry.prefab.id)) {
      this.warnedSignals.add(entry.prefab.id);
      this.deps.publish('warning', 'spawn.signals_not_wired', tNow('spawnHostMsgCore.thePrefabHasSignalConnections', { name: entry.prefab.name }), root.persistentNodeId);
    }
    return { rootId: root.persistentNodeId, nodeIds: instances.map((i) => i.persistentNodeId), prefab: entry.ref, ownerId: options.ownerId };
  }

  /** Pede a destruição da subárvore criada; acontece no fim do quadro (`flush`). Idempotente: id desconhecido/destruído não falha. */
  despawn(rootId: string): void {
    this.despawnQueue.add(rootId);
  }

  /** Fim do quadro: expira `lifetimeMs` e executa os `despawn` pedidos. Devolve quantas raízes foram destruídas. */
  flush(): number {
    const now = this.deps.now();
    for (const [id, deadline] of [...this.deadlines]) if (now >= deadline) this.despawnQueue.add(id);
    if (this.despawnQueue.size === 0) return 0;
    const scene = this.deps.scene();
    let n = 0;
    for (const id of [...this.despawnQueue]) {
      this.despawnQueue.delete(id);
      this.deadlines.delete(id);
      const live = scene?.getInstance(id);
      if (!scene || !live) continue;
      scene.destroyInstance(live.id);
      n++;
    }
    return n;
  }

  // ── ganchos da sessão ─────────────────────────────────────────────────────────────────────────────────────────────────────

  /** Ouvinte de destruição da cena viva: o corpo físico e as variáveis locais de TODO nó destruído saem do mundo (conserto do corpo fantasma). */
  onInstanceDestroyed = (instance: RuntimeInstance): void => {
    this.deps.physics()?.removeInstance(instance.persistentNodeId);
    this.deps.variables()?.unregisterLocals(instance.persistentNodeId);
    this.deadlines.delete(instance.persistentNodeId);
    this.pendingVelocity.delete(instance.persistentNodeId);
  };

  /** O mundo físico terminou de ser criado (Rapier carregado depois do spawn): aplica as velocidades iniciais que esperavam. */
  onPhysicsReady(): void {
    this.applyPendingVelocity();
  }

  private applyPendingVelocity(): void {
    const physics = this.deps.physics();
    if (!physics) return;
    for (const [nodeId, v] of [...this.pendingVelocity]) {
      this.pendingVelocity.delete(nodeId);
      try {
        physics.bridge.setLinearVelocity(nodeId, v);
      } catch (error) {
        this.deps.publish('warning', 'spawn.velocity_ignored', tNow('spawnHostMsgCore.initialVelocityIgnoredOn', { nodeId, value: error instanceof Error ? error.message : String(error) }), nodeId);
      }
    }
  }

  /** Teardown de cena (Stop, restart, troca): nada de spawn atravessa para a próxima cena. O cache de prefabs é da sessão e fica. */
  resetScene(): void {
    this.deadlines.clear();
    this.despawnQueue.clear();
    this.pendingVelocity.clear();
  }

  /** Fim da sessão. */
  dispose(): void {
    this.resetScene();
    this.prefabs.clear();
    this.warnedSignals.clear();
    this.warnedTypes.clear();
  }
}
