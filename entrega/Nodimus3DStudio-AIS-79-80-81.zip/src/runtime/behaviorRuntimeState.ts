/**
 * AIS-41b — estado MUTÁVEL de um Behavior durante o Play: pertence ao par (nó em execução × `BehaviorInstance`), nunca à
 * Definition (a pasta em `src/logic/behaviors/<id>/`) nem ao authoring (`GameNode.behaviors`). Duas instâncias da mesma
 * Definition, em nós distintos (ou no mesmo nó), têm estado independente; o authoring nunca é alterado por ele.
 *
 * É um contêiner puro e descartável: a `RuntimeSession` (AIS-44b) cria um por sessão e o descarta no Stop/troca de cena.
 */
import type { BehaviorInstance } from '../types/visualLogic';

const clone = <T>(v: T): T => (v === undefined ? v : JSON.parse(JSON.stringify(v)));

export interface BehaviorRuntimeState {
  nodeId: string;
  behaviorId: string;
  /** Cópia de trabalho de `properties`: scripts/Actions podem mudá-la sem tocar no authoring. */
  properties: Record<string, any>;
  /** Variáveis internas do executor (temporizadores, índice de caminho, contadores…). */
  memory: Record<string, unknown>;
}

const keyOf = (nodeId: string, behaviorId: string) => `${nodeId}::${behaviorId}`;

export class BehaviorRuntimeStates {
  private states = new Map<string, BehaviorRuntimeState>();

  /** Estado do par (nó, Behavior); criado na primeira consulta a partir da instância (cópia profunda). */
  ensure(nodeId: string, instance: BehaviorInstance): BehaviorRuntimeState {
    const key = keyOf(nodeId, instance.id);
    let state = this.states.get(key);
    if (!state) {
      state = { nodeId, behaviorId: instance.id, properties: clone(instance.properties), memory: {} };
      this.states.set(key, state);
    }
    return state;
  }

  get(nodeId: string, behaviorId: string): BehaviorRuntimeState | undefined {
    return this.states.get(keyOf(nodeId, behaviorId));
  }

  /** "Restart Behaviors" de um nó: volta ao que o authoring tem. */
  reset(nodeId: string, behaviorId: string): void {
    this.states.delete(keyOf(nodeId, behaviorId));
  }

  get size(): number {
    return this.states.size;
  }

  /** Stop / troca de cena: nada sobrevive à sessão. */
  dispose(): void {
    this.states.clear();
  }
}
