/**
 * AIS-48b — registry de DISPOSERS por owner da `RuntimeSession`. Toda API que registra callback em runtime (frame, input, física,
 * sinais, cena) devolve um `unsubscribe` e registra o disposer AQUI, com o dono da inscrição. Descartar um owner cancela, de forma
 * idempotente, só as inscrições dele; Stop/Restart/troca de cena descartam tudo o que é da cena. Assim `Play → Stop` repetido nunca
 * multiplica callbacks, e remover um Behavior (ou destruir uma instância) cancela apenas o que era dele.
 *
 * Puro (sem React/DOM/Three): é a única contabilidade de inscrições; nenhum consumidor mantém `Set` próprio de listeners ativos sem
 * passar por aqui.
 */

export type SubscriptionOwnerKind = 'session' | 'scene' | 'instance' | 'behavior' | 'script-worker';

export interface SubscriptionOwner {
  kind: SubscriptionOwnerKind;
  /** Identidade estável do dono (id da cena, do nó, `nodeId::behaviorId`, id do Worker…). */
  id: string;
}

const keyOf = (owner: SubscriptionOwner): string => `${owner.kind}:${owner.id}`;

export class SubscriptionRegistry {
  private readonly byOwner = new Map<string, { owner: SubscriptionOwner; disposers: Set<() => void> }>();

  /**
   * Registra o disposer de uma inscrição de `owner`. Devolve o `unsubscribe` IDEMPOTENTE da inscrição (chamá-lo de novo, ou depois de
   * o owner ser descartado, não faz nada). Se o owner já estava descartado nada impede nova inscrição: o dono decide.
   */
  add(owner: SubscriptionOwner, dispose: () => void): () => void {
    const key = keyOf(owner);
    let slot = this.byOwner.get(key);
    if (!slot) {
      slot = { owner: { ...owner }, disposers: new Set() };
      this.byOwner.set(key, slot);
    }
    const disposers = slot.disposers;
    let active = true;
    const unsubscribe = () => {
      if (!active) return;
      active = false;
      disposers.delete(unsubscribe);
      if (disposers.size === 0 && this.byOwner.get(key)?.disposers === disposers) this.byOwner.delete(key);
      dispose();
    };
    disposers.add(unsubscribe);
    return unsubscribe;
  }

  /** Cancela TODAS as inscrições de um owner (e só dele). Devolve quantas cancelou. Um disposer que lança não impede os demais. */
  disposeOwner(owner: SubscriptionOwner): number {
    const slot = this.byOwner.get(keyOf(owner));
    if (!slot) return 0;
    return this.runAll([...slot.disposers]);
  }

  /** Cancela as inscrições de todos os owners de um tipo (ex.: `behavior`). */
  disposeKind(kind: SubscriptionOwnerKind): number {
    const all: Array<() => void> = [];
    for (const slot of this.byOwner.values()) if (slot.owner.kind === kind) all.push(...slot.disposers);
    return this.runAll(all);
  }

  /** Cancela tudo, exceto os tipos em `keep` (a sessão mantém as suas ao trocar de cena). */
  disposeAll(keep: readonly SubscriptionOwnerKind[] = []): number {
    const all: Array<() => void> = [];
    for (const slot of this.byOwner.values()) if (!keep.includes(slot.owner.kind)) all.push(...slot.disposers);
    return this.runAll(all);
  }

  /** Inscrições ativas (de um owner, de um tipo, ou todas). */
  count(filter: { owner?: SubscriptionOwner; kind?: SubscriptionOwnerKind } = {}): number {
    if (filter.owner) return this.byOwner.get(keyOf(filter.owner))?.disposers.size ?? 0;
    let n = 0;
    for (const slot of this.byOwner.values()) if (!filter.kind || slot.owner.kind === filter.kind) n += slot.disposers.size;
    return n;
  }

  /** Owners com inscrição ativa (depuração/testes). */
  owners(): SubscriptionOwner[] {
    return [...this.byOwner.values()].map((s) => ({ ...s.owner }));
  }

  private runAll(disposers: Array<() => void>): number {
    let n = 0;
    for (const dispose of disposers) {
      try {
        dispose();
        n++;
      } catch {
        // um disposer com defeito não pode impedir o cancelamento das demais inscrições
        n++;
      }
    }
    return n;
  }
}
