import { describe, expect, it } from 'vitest';
import type { VehicleWheelSpec } from '../../core/physics/PhysicsBridge';
import {
  BALANCE_TRACK_LIMIT,
  BIKE_MAX_LEAN,
  LEAN_SAFETY,
  forwardOf,
  leanOf,
  leanTarget,
  leanTorque,
  REVERSE_SPEED_FRACTION,
  balanceWheelSpecs,
  buildWheelSpec,
  driveWheels,
  groundAlignmentTorque,
  initialDriveState,
  limitsOf,
  readDriveParams,
  stabilityOf,
  trackOf,
  upOf,
  wheelSpinFromBridge,
  wheelVisualQuaternion,
  type VehicleDriveInput,
  type VehicleDriveWheel,
} from './vehicleDrive';

/** AIS-73 — condução arcade em funções puras (sem Rapier, sem Three). */

const P = { enginePower: 9000, brakeForce: 9000, steerAngle: 30, maxSpeed: 30 };
const WHEELS: VehicleDriveWheel[] = [
  { id: 'fl', steering: true, motorized: false },
  { id: 'fr', steering: true, motorized: false },
  { id: 'rl', steering: false, motorized: true },
  { id: 'rr', steering: false, motorized: true },
];
const IDLE: VehicleDriveInput = { throttle: 0, brake: 0, handbrake: false, steer: 0 };
const drive = (input: Partial<VehicleDriveInput>, speed = 0, params = P, state = initialDriveState(), dt = 1 / 60) => driveWheels(state, params, { ...IDLE, ...input }, speed, WHEELS, dt);
const sum = (r: ReturnType<typeof drive>, key: 'engineForce' | 'brake') => Object.values(r.controls).reduce((s, c) => s + c[key], 0);

describe('motor, freio e ré (AIS-73)', () => {
  it('Accelerate divide o motor entre as rodas MOTRIZES (a força total é enginePower)', () => {
    const r = drive({ throttle: 1 });
    expect(r.controls.rl.engineForce).toBeCloseTo(4500);
    expect(r.controls.fl.engineForce).toBe(0);
    expect(sum(r, 'engineForce')).toBeCloseTo(9000);
  });

  it('o motor some linearmente até maxSpeed e nunca vira freio (limitador arcade)', () => {
    expect(sum(drive({ throttle: 1 }, 15), 'engineForce')).toBeCloseTo(4500);
    expect(sum(drive({ throttle: 1 }, 30), 'engineForce')).toBe(0);
    expect(sum(drive({ throttle: 1 }, 45), 'engineForce')).toBe(0);
  });

  it('Brake em movimento freia todas as rodas; sem acelerador, parado ou de ré, engata a ré (limitada)', () => {
    const braking = drive({ brake: 1 }, 10);
    expect(sum(braking, 'brake')).toBeCloseTo(9000);
    expect(sum(braking, 'engineForce')).toBe(0);
    const reversing = drive({ brake: 1 }, 0);
    expect(sum(reversing, 'engineForce')).toBeLessThan(0);
    expect(sum(reversing, 'brake')).toBe(0);
    expect(sum(drive({ brake: 1 }, -30 * REVERSE_SPEED_FRACTION), 'engineForce')).toBeCloseTo(0); // limite da ré
  });

  it('Accelerate + Brake em movimento: acelera e freia juntos (o motor não cancela o freio)', () => {
    const r = drive({ throttle: 1, brake: 1 }, 10);
    expect(sum(r, 'brake')).toBeGreaterThan(0);
  });

  it('sem entrada: só a resistência de rolamento; Handbrake trava as rodas traseiras e corta o motor', () => {
    const coast = drive({}, 10);
    expect(sum(coast, 'engineForce')).toBe(0);
    expect(sum(coast, 'brake')).toBeGreaterThan(0);
    expect(sum(coast, 'brake')).toBeLessThan(2000);
    const hb = drive({ throttle: 1, handbrake: true }, 10);
    expect(sum(hb, 'engineForce')).toBe(0);
    expect(hb.controls.rl.brake).toBeGreaterThan(hb.controls.fl.brake);
  });

  it('entrada fora de faixa e velocidade inválida nunca produzem NaN', () => {
    const r = drive({ throttle: 7, brake: -3, steer: 99 }, Number.NaN);
    for (const c of Object.values(r.controls)) for (const v of Object.values(c)) expect(Number.isFinite(v)).toBe(true);
  });
});

describe('esterçamento (AIS-73)', () => {
  it('só as rodas dianteiras esterçam; + = esquerda; é suavizado (não salta)', () => {
    const first = drive({ steer: 1 });
    expect(first.controls.fl.steering).toBeGreaterThan(0);
    expect(first.controls.fl.steering).toBe(first.controls.fr.steering);
    expect(first.controls.rl.steering).toBe(0);
    expect(first.controls.fl.steering).toBeLessThan((30 * Math.PI) / 180); // não chega ao máximo no 1º quadro
    let state = first.state;
    for (let i = 0; i < 60; i++) state = drive({ steer: 1 }, 0, P, state).state;
    expect(state.steer).toBeCloseTo((30 * Math.PI) / 180, 3);
    expect(drive({ steer: -1 }).controls.fl.steering).toBeLessThan(0);
  });

  it('o ângulo diminui com a velocidade e respeita o limite de aceleração lateral', () => {
    const settle = (speed: number, params = P) => {
      let state = initialDriveState();
      for (let i = 0; i < 120; i++) state = drive({ steer: 1 }, speed, params, state).state;
      return state.steer;
    };
    expect(settle(25)).toBeLessThan(settle(0));
    const lateral = { ...P, lateral: { wheelbase: 2.6, maxLateralAccel: 6 } };
    expect(settle(25, lateral)).toBeLessThan(settle(25));
    expect(settle(25, lateral)).toBeCloseTo(Math.atan((6 * 2.6) / 625), 4); // v²·tan(δ)/L = a
    expect(settle(0, lateral)).toBeCloseTo((30 * Math.PI) / 180, 3); // parado: ângulo cheio
  });
});

describe('estabilidade e rodas de equilíbrio (AIS-73)', () => {
  const spec = (id: string, x: number, z: number, steering = false): VehicleWheelSpec => ({ id, connection: { x, y: 0.1, z }, radius: 0.35, suspensionRestLength: 0.4, maxSuspensionTravel: 0.4, stiffness: 30, compressionDamping: 2.4, relaxationDamping: 4.5, frictionSlip: 10.5, steering, motorized: !steering });
  const car = [spec('fl', -0.8, -1.3, true), spec('fr', 0.8, -1.3, true), spec('rl', -0.8, 1.3), spec('rr', 0.8, 1.3)];

  it('entre-eixos e aceleração lateral de tombamento vêm da geometria das rodas', () => {
    const s = stabilityOf(car);
    expect(s.wheelbase).toBeCloseTo(2.6);
    expect(s.maxLateralAccel).toBeGreaterThan(3);
    expect(s.maxLateralAccel).toBeLessThan(12); // abaixo da aceleração que tomba um carro de bitola 1,6 m
    expect(stabilityOf(car.map((w) => ({ ...w, connection: { ...w.connection, x: w.connection.x * 2 } }))).maxLateralAccel).toBeGreaterThan(s.maxLateralAccel); // bitola maior = mais estável
    expect(stabilityOf([]).maxLateralAccel).toBeGreaterThan(0);
  });

  it('carro de bitola normal não ganha rodas de equilíbrio; moto (uma linha de rodas) ganha duas, atrás, sem tração', () => {
    expect(trackOf(car)).toBeCloseTo(1.6);
    expect(balanceWheelSpecs('car', car)).toEqual([]);
    const bike = [spec('f', 0, -0.8, true), spec('r', 0, 0.8)];
    expect(trackOf(bike)).toBe(0);
    expect(trackOf(bike)).toBeLessThan(BALANCE_TRACK_LIMIT);
    const [l, r] = balanceWheelSpecs('moto', bike);
    expect(l.id).toBe('moto#balance_l');
    expect(r.id).toBe('moto#balance_r');
    expect(l.connection.x).toBeLessThan(0);
    expect(r.connection.x).toBeGreaterThan(0);
    expect(l.connection.z).toBe(0.8);
    expect(l.motorized || l.steering).toBe(false);
    // toca o chão junto com as rodas reais: fundo da roda virtual = fundo da roda real
    const bottom = (w: VehicleWheelSpec) => w.connection.y - w.suspensionRestLength - w.radius;
    expect(bottom(l)).toBeCloseTo(bottom(bike[1]));
    expect(balanceWheelSpecs('x', [])).toEqual([]);
  });
});

describe('roda: especificação, visual e alinhamento (AIS-73)', () => {
  const vehicle = { suspensionStiffness: 30, suspensionDamping: 2.4, suspensionTravel: 0.4 };

  it('a conexão fica no espaço do corpo SEM escala, acima do centro da roda pelo curso; herda a suspensão do veículo', () => {
    const w = buildWheelSpec('w1', { radius: 0.4, isSteering: true, isMotorized: false }, vehicle, [0.5, -0.3, -1], [2, 2, 2]);
    expect(w.connection).toEqual({ x: 1, y: -0.6 + 0.4, z: -2 });
    expect(w).toMatchObject({ radius: 0.4, suspensionRestLength: 0.4, stiffness: 30, compressionDamping: 2.4, steering: true, motorized: false });
    expect(w.relaxationDamping).toBeGreaterThan(w.compressionDamping);
  });

  it('com Suspension Override a roda usa os PRÓPRIOS valores; valor inválido cai no do veículo', () => {
    const own = buildWheelSpec('w', { suspensionOverride: true, suspensionStiffness: 55, suspensionDamping: 3, suspensionTravel: 0.7 }, vehicle, [0, 0, 0], [1, 1, 1]);
    expect(own).toMatchObject({ stiffness: 55, compressionDamping: 3, suspensionRestLength: 0.7 });
    const bad = buildWheelSpec('w', { suspensionOverride: true, suspensionStiffness: 'x', radius: 'y' }, vehicle, [0, 0, 0], [1, 1, 1]);
    expect(bad.stiffness).toBe(30);
    expect(bad.radius).toBeCloseTo(0.35);
  });

  it('parâmetros do arquivo nunca produzem NaN nem valores perigosos', () => {
    const p = readDriveParams({ enginePower: 'x', maxSpeed: -5, steerAngle: 500, mass: 0 });
    expect(p.enginePower).toBe(9000);
    expect(p.maxSpeed).toBeGreaterThan(0);
    expect(p.steerAngle).toBeLessThanOrEqual(80);
    expect(p.mass).toBeGreaterThanOrEqual(1);
  });

  it('visual: esterço em Y e giro em X compõem sobre a rotação autoral; sem esterço nem giro = a própria autoral', () => {
    const authored = { x: 0, y: 0, z: Math.SQRT1_2, w: Math.SQRT1_2 }; // 90° em Z (cilindro com eixo em X)
    const same = wheelVisualQuaternion(authored, 0, 0);
    expect(same.z).toBeCloseTo(authored.z);
    expect(same.w).toBeCloseTo(authored.w);
    const steered = wheelVisualQuaternion(authored, Math.PI / 2, 0);
    expect(Math.hypot(steered.x, steered.y, steered.z, steered.w)).toBeCloseTo(1); // continua unitário
    expect(steered.y).not.toBeCloseTo(0);
    expect(wheelSpinFromBridge(2)).toBe(-2);
  });

  it('alinhamento ao chão: gira o "para cima" rumo à normal; zero sem normal, sem velocidade ou sem massa', () => {
    const up = { x: 0, y: 1, z: 0 };
    const tilted = groundAlignmentTorque(up, { x: 0.2, y: 0.98, z: 0 }, 2, 1000);
    expect(tilted.z).toBeLessThan(0); // up × normal aponta em -Z: gira o "para cima" (+Y) rumo a +X, onde está a normal
    expect(Math.hypot(tilted.x, tilted.y, tilted.z)).toBeGreaterThan(0);
    expect(groundAlignmentTorque(up, up, 2, 1000)).toEqual({ x: 0, y: 0, z: 0 }); // já alinhado
    expect(groundAlignmentTorque(up, null, 2, 1000)).toEqual({ x: 0, y: 0, z: 0 });
    expect(groundAlignmentTorque(up, { x: 1, y: 0, z: 0 }, 0, 1000)).toEqual({ x: 0, y: 0, z: 0 });
    expect(groundAlignmentTorque(up, { x: 1, y: 0, z: 0 }, 2, 0)).toEqual({ x: 0, y: 0, z: 0 });
    expect(upOf({ x: 0, y: 0, z: 0, w: 1 })).toEqual({ x: 0, y: 1, z: 0 });
  });
});

describe('antiempino e anti-stoppie (AIS-73)', () => {
  const spec = (id: string, z: number, steering = false): VehicleWheelSpec => ({ id, connection: { x: 0, y: 0.05, z }, radius: 0.33, suspensionRestLength: 0.4, maxSuspensionTravel: 0.4, stiffness: 30, compressionDamping: 2.4, relaxationDamping: 4.5, frictionSlip: 10.5, steering, motorized: !steering });

  it('entre-eixos curta e centro de massa alto limitam a aceleração (moto) muito mais que um carro', () => {
    const bike = stabilityOf([spec('f', -0.68, true), spec('r', 0.6)]);
    const car = stabilityOf([spec('fl', -1.3, true), spec('fr', -1.3, true), spec('rl', 1.3), spec('rr', 1.3)]);
    expect(bike.maxAccel).toBeLessThan(car.maxAccel);
    expect(bike.maxAccel).toBeGreaterThan(2);
    expect(bike.maxAccel).toBeLessThan(8); // a 9000 N / 1000 kg (9 m/s²) a moto empinaria
    expect(bike.maxDecel).toBeGreaterThan(0);
    expect(limitsOf(bike, 250).maxEngineForce).toBeCloseTo(bike.maxAccel * 250);
  });

  it('driveWheels respeita os tetos de motor e de freio (nunca passa do que empina)', () => {
    const capped = { ...P, maxEngineForce: 1000, maxBrakeForce: 800 };
    expect(sum(drive({ throttle: 1 }, 0, capped), 'engineForce')).toBeCloseTo(1000);
    expect(sum(drive({ brake: 1 }, 10, capped), 'brake')).toBeCloseTo(800);
    expect(sum(drive({ brake: 1 }, 0, capped), 'engineForce')).toBeGreaterThan(-1000 * REVERSE_SPEED_FRACTION - 1);
    expect(sum(drive({ handbrake: true }, 10, capped), 'brake')).toBeCloseTo(800 * (1 + 0.15)); // freio de mão (teto) + resistência de rolamento
    expect(sum(drive({ throttle: 1 }, 0, P), 'engineForce')).toBeCloseTo(9000); // sem teto: igual a antes
  });
});

describe('inclinação da moto (AIS-73)', () => {
  const quatZ = (deg: number) => ({ x: 0, y: 0, z: Math.sin((deg * Math.PI) / 360), w: Math.cos((deg * Math.PI) / 360) });

  it('leanOf: 0 em pé; + quando inclinado para a ESQUERDA (topo para -X), − para a direita', () => {
    expect(leanOf({ x: 0, y: 0, z: 0, w: 1 })).toBeCloseTo(0);
    // girar +30° em torno de +Z leva o topo (+Y) para -X (esquerda do corpo)
    expect(leanOf(quatZ(30))).toBeCloseTo((30 * Math.PI) / 180, 4);
    expect(leanOf(quatZ(-30))).toBeCloseTo((-30 * Math.PI) / 180, 4);
    expect(forwardOf({ x: 0, y: 0, z: 0, w: 1 })).toEqual({ x: -0, y: -0, z: -1 });
  });

  it('o alvo cresce com a velocidade (e com o quadrado dela), vai para o lado da curva e respeita o limite', () => {
    const steer = (10 * Math.PI) / 180;
    const slow = leanTarget(4, steer, 1.3);
    const fast = leanTarget(14, steer, 1.3);
    expect(fast).toBeGreaterThan(slow);
    expect(slow).toBeGreaterThan(0); // esquerda
    expect(leanTarget(14, -steer, 1.3)).toBeCloseTo(-fast);
    expect(fast).toBeLessThanOrEqual((BIKE_MAX_LEAN * Math.PI) / 180 + 1e-9);
    expect(leanTarget(30, 0.6, 1.3)).toBeCloseTo((BIKE_MAX_LEAN * Math.PI) / 180);
    expect(leanTarget(0, steer, 1.3)).toBe(0); // parada: em pé
    expect(leanTarget(-6, steer, 1.3)).toBe(0); // de ré: em pé
    expect(leanTarget(10, Number.NaN, 1.3)).toBe(0);
  });

  it('o torque empurra a inclinação rumo ao alvo e amortece a rotação (sinal: torque em torno da frente > 0 inclina para a DIREITA)', () => {
    expect(leanTorque(0, 0, 0.3, 250)).toBeLessThan(0); // quer inclinar mais para a esquerda → torque negativo em torno da frente
    expect(leanTorque(0, 0, -0.3, 250)).toBeGreaterThan(0);
    expect(leanTorque(0.3, 0, 0.3, 250)).toBeCloseTo(0); // no alvo e parado: nada
    // girando rápido para a esquerda (ω em torno da frente negativo) passando do alvo: o amortecimento freia
    expect(leanTorque(0.3, -2, 0.3, 250)).toBeGreaterThan(0);
  });

  it('o teto lateral da moto vem da inclinação máxima (maior que o de um veículo de quatro rodas estreito)', () => {
    const spec = (id: string, x: number, z: number, steering = false): VehicleWheelSpec => ({ id, connection: { x, y: 0.05, z }, radius: 0.33, suspensionRestLength: 0.4, maxSuspensionTravel: 0.4, stiffness: 30, compressionDamping: 2.4, relaxationDamping: 4.5, frictionSlip: 10.5, steering, motorized: !steering });
    const bike = stabilityOf([spec('f', 0, -0.68, true), spec('r', 0, 0.6)]);
    expect(bike.maxLateralAccel).toBeCloseTo(LEAN_SAFETY * 9.81 * Math.tan((BIKE_MAX_LEAN * Math.PI) / 180), 3);
  });
});
