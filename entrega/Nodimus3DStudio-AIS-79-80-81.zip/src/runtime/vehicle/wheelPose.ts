import * as THREE from 'three';
import { wheelVisualQuaternion } from './vehicleDrive';

const _q = new THREE.Quaternion();
const _e = new THREE.Euler();
const DEG2RAD = Math.PI / 180;
const RAD2DEG = 180 / Math.PI;

/**
 * AIS-78c (execução 3) — rotação de APRESENTAÇÃO da roda (graus, XYZ) a partir da rotação autoral, do esterço e do giro: a conversão
 * Euler↔quaternion fica no runtime (sem `THREE.*` em `src/logic/**`). Pura sobre números.
 */
export function wheelRotationDegrees(initialRotationDeg: readonly number[], steering: number, spin: number): [number, number, number] {
  _e.set(initialRotationDeg[0] * DEG2RAD, initialRotationDeg[1] * DEG2RAD, initialRotationDeg[2] * DEG2RAD, 'XYZ');
  _q.setFromEuler(_e);
  const q = wheelVisualQuaternion({ x: _q.x, y: _q.y, z: _q.z, w: _q.w }, steering, spin);
  _e.setFromQuaternion(_q.set(q.x, q.y, q.z, q.w), 'XYZ');
  return [_e.x * RAD2DEG, _e.y * RAD2DEG, _e.z * RAD2DEG];
}
