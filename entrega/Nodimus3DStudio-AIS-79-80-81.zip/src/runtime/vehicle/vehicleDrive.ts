import type { VehicleWheelSpec } from '../../core/physics/PhysicsBridge';
import type { VehicleWheelControl } from '../../core/physics/PhysicsBridge';
import { clamp, DEG, finite, quatFromAxisAngle } from '../controllers/controllerMath';
import type { Quat, V3 } from '../controllers/controllerMath';

/**
 * AIS-73 — condução ARCADE de um veículo, em funções PURAS (sem Rapier, sem Three, sem DOM). O `vehicle_controller` lê a entrada, chama
 * `driveWheels` e entrega os comandos por roda à `PhysicsBridge`; a física (suspensão, atrito do pneu) é do controlador nativo do Rapier.
 * Não é simulação de veículo real: o motor é uma força por roda motriz com um limitador linear até `maxSpeed`, o freio é uma força por
 * roda, e o esterçamento é suavizado e reduzido com a velocidade para o carro não "capotar" em curva rápida.
 */

/** Parâmetros gerais do `vehicle_controller` (N, graus e m/s). */
export interface VehicleDriveParams {
  enginePower: number;
  brakeForce: number;
  steerAngle: number;
  maxSpeed: number;
  /** Limite arcade de aceleração lateral (ver `stabilityOf`): o esterçamento nunca pede mais curva do que a carroceria aguenta sem tombar. */
  lateral?: { wheelbase: number; maxLateralAccel: number };
  /** Força máxima (N) de motor e de freio que não empina nem faz stoppie (aceleração máx. × massa; ver `stabilityOf`). */
  maxEngineForce?: number;
  maxBrakeForce?: number;
}

/** Entrada lógica de um quadro (ações `Accelerate`/`Brake`/`SteerLeft`/`SteerRight`/`Handbrake` já lidas). */
export interface VehicleDriveInput {
  /** 0..1 */
  throttle: number;
  /** 0..1 */
  brake: number;
  handbrake: boolean;
  /** -1 (direita) .. +1 (esquerda), como o yaw do motor. */
  steer: number;
}

export interface VehicleDriveWheel {
  id: string;
  steering: boolean;
  motorized: boolean;
}

/** Estado entre quadros: esterçamento suavizado (rad). */
export interface VehicleDriveState {
  steer: number;
}

export const initialDriveState = (): VehicleDriveState => ({ steer: 0 });

/** Velocidade (m/s) abaixo da qual "freio" vira marcha à ré. */
export const REVERSE_THRESHOLD = 0.6;
/** Marcha à ré até esta fração de `maxSpeed`. */
export const REVERSE_SPEED_FRACTION = 0.35;
/** Resistência de rolamento (fração de `brakeForce`) sem acelerador nem freio: o carro desacelera sozinho. */
export const ROLLING_RESISTANCE = 0.15;
/** Esterçamento: velocidade de resposta (rad/s) e perda de ângulo na velocidade máxima. */
export const STEER_RATE = 5;
export const STEER_SPEED_LOSS = 0.55;
/** Aderência padrão do pneu (Bullet `frictionSlip`) usada ao registrar rodas. */
export const WHEEL_FRICTION_SLIP = 10.5;

/** Lê um parâmetro numérico vindo de arquivo (nunca NaN no jogo). */
export function readDriveParams(properties: Record<string, unknown>): VehicleDriveParams & { mass: number; suspensionStiffness: number; suspensionDamping: number; suspensionTravel: number; groundAlignmentSpeed: number } {
  return {
    enginePower: Math.max(0, finite(properties.enginePower, 9000)),
    brakeForce: Math.max(0, finite(properties.brakeForce, 9000)),
    steerAngle: clamp(finite(properties.steerAngle, 32), 0, 80),
    maxSpeed: Math.max(0.1, finite(properties.maxSpeed, 30)),
    mass: Math.max(1, finite(properties.mass, 1000)),
    suspensionStiffness: Math.max(0.1, finite(properties.suspensionStiffness, 30)),
    suspensionDamping: Math.max(0, finite(properties.suspensionDamping, 2.4)),
    suspensionTravel: Math.max(0.02, finite(properties.suspensionTravel, 0.4)),
    groundAlignmentSpeed: Math.max(0, finite(properties.groundAlignmentSpeed, 2)),
  };
}

/**
 * Um quadro de condução: comandos por roda (motor em N, freio em N, esterçamento em rad). `forwardSpeed` é a velocidade ao longo da
 * frente do veículo (m/s; negativa em marcha à ré).
 */
export function driveWheels(
  state: VehicleDriveState,
  params: VehicleDriveParams,
  input: VehicleDriveInput,
  forwardSpeed: number,
  wheels: readonly VehicleDriveWheel[],
  dt: number
): { state: VehicleDriveState; controls: Record<string, Required<VehicleWheelControl>> } {
  const engineCap = params.maxEngineForce ?? Number.POSITIVE_INFINITY;
  const brakeCap = params.maxBrakeForce ?? Number.POSITIVE_INFINITY;
  const throttle = clamp(input.throttle, 0, 1);
  const brake = clamp(input.brake, 0, 1);
  const speed = Number.isFinite(forwardSpeed) ? forwardSpeed : 0;
  const motorized = wheels.filter((w) => w.motorized);
  const rear = wheels.filter((w) => !w.steering);

  // motor: acelerador empurra para a frente até `maxSpeed`; freio com o carro parado (ou de ré) vira marcha à ré
  let engine = 0;
  let braking = 0;
  const reversing = brake > 0 && throttle === 0 && speed <= REVERSE_THRESHOLD;
  if (throttle > 0) {
    const limiter = speed > 0 ? clamp(1 - speed / params.maxSpeed, 0, 1) : 1;
    engine = Math.min(params.enginePower, engineCap) * throttle * limiter;
    if (brake > 0 && speed > REVERSE_THRESHOLD) braking = Math.min(params.brakeForce, brakeCap) * brake;
  } else if (reversing) {
    const limiter = speed < 0 ? clamp(1 - -speed / (params.maxSpeed * REVERSE_SPEED_FRACTION), 0, 1) : 1;
    engine = -Math.min(params.enginePower, engineCap) * brake * limiter * REVERSE_SPEED_FRACTION;
  } else if (brake > 0) {
    braking = Math.min(params.brakeForce, brakeCap) * brake;
  } else {
    braking = Math.min(params.brakeForce, brakeCap) * ROLLING_RESISTANCE;
  }

  // esterçamento: suavizado e menor em velocidade alta
  const speedFactor = 1 - STEER_SPEED_LOSS * clamp(Math.abs(speed) / params.maxSpeed, 0, 1);
  // aceleração lateral ≈ v² · tan(δ) / L: limita δ para que ela fique abaixo do que tomba a carroceria
  const lateralCap = params.lateral ? Math.atan((params.lateral.maxLateralAccel * params.lateral.wheelbase) / Math.max(speed * speed, 1)) : Math.PI / 2;
  const target = clamp(input.steer, -1, 1) * Math.min(params.steerAngle * DEG * speedFactor, lateralCap);
  const maxStep = STEER_RATE * Math.max(0, dt);
  const steer = state.steer + clamp(target - state.steer, -maxStep, maxStep);

  const controls: Record<string, Required<VehicleWheelControl>> = {};
  const perMotor = motorized.length ? engine / motorized.length : 0;
  const perBrake = wheels.length ? braking / wheels.length : 0;
  const handbrakePerWheel = input.handbrake ? Math.min(params.brakeForce, brakeCap) / Math.max(1, rear.length || wheels.length) : 0;
  for (const w of wheels) {
    controls[w.id] = {
      engineForce: w.motorized && !input.handbrake ? perMotor : 0,
      brake: perBrake + (input.handbrake && (rear.length === 0 || !w.steering) ? handbrakePerWheel : 0),
      steering: w.steering ? steer : 0,
    };
  }
  return { state: { steer }, controls };
}

/** Giro visual da roda (rad, em torno do eixo X do veículo): para a frente (-Z) o topo da roda anda para -Z, ou seja, ângulo NEGATIVO. */
export const wheelSpinFromBridge = (bridgeRotation: number): number => -bridgeRotation;

/**
 * Orientação visual da roda: `Qy(esterço) · Qx(giro) · Q0` (Q0 = rotação autoral da roda, ex.: cilindro girado 90° em Z para o eixo ficar
 * em X). O giro acontece em torno do EIXO DO VEÍCULO (X), depois do esterçamento — a roda esterçada gira em torno do próprio eixo.
 */
export function wheelVisualQuaternion(authored: Quat, steer: number, spin: number): Quat {
  return multiplyQuat(multiplyQuat(quatFromAxisAngle({ x: 0, y: 1, z: 0 }, steer), quatFromAxisAngle({ x: 1, y: 0, z: 0 }, spin)), authored);
}

export function multiplyQuat(a: Quat, b: Quat): Quat {
  return {
    x: a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
    y: a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
    z: a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
    w: a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
  };
}

/**
 * Alinhamento arcade ao chão: torque que gira o "para cima" do veículo (`up`) rumo à normal média do chão. `alignmentSpeed` (1/s) × massa
 * dá a intensidade; ângulos pequenos (o sinal do produto vetorial cresce com o ângulo até 90°). Zero sem normal ou com velocidade 0.
 */
export function groundAlignmentTorque(up: V3, normal: V3 | null, alignmentSpeed: number, mass: number): V3 {
  if (!normal || !(alignmentSpeed > 0) || !(mass > 0)) return { x: 0, y: 0, z: 0 };
  const axis = { x: up.y * normal.z - up.z * normal.y, y: up.z * normal.x - up.x * normal.z, z: up.x * normal.y - up.y * normal.x };
  const k = alignmentSpeed * mass * ALIGNMENT_GAIN;
  return { x: axis.x * k, y: axis.y * k, z: axis.z * k };
}
/** Ganho do alinhamento (m²/s² por unidade de seno do desvio, por kg e por 1/s). */
export const ALIGNMENT_GAIN = 1.2;

/** Inclinação máxima da moto (graus) e fração dela usada como teto de aceleração lateral. */
export const BIKE_MAX_LEAN = 32;
export const LEAN_SAFETY = 0.85;
/** Fração da aceleração lateral de tombamento permitida ao esterçar (margem de segurança). */
export const LATERAL_SAFETY = 0.55;
const GRAVITY = 9.81;

/**
 * Geometria de estabilidade a partir das rodas registradas (espaço do corpo; o centro de massa fica na origem do corpo): entre-eixos
 * (`wheelbase`), bitola e altura do centro de massa dão a aceleração lateral que TOMBA o veículo (`g · (bitola/2) / h`); a permitida é uma
 * fração dela. Veículo de uma linha de rodas (moto) usa uma bitola mínima: quem o mantém em pé são as rodas de equilíbrio.
 */
export function stabilityOf(wheels: readonly Pick<VehicleWheelSpec, 'connection' | 'radius' | 'suspensionRestLength' | 'steering'>[]): { wheelbase: number; maxLateralAccel: number; maxAccel: number; maxDecel: number } {
  if (wheels.length === 0) return { wheelbase: 2.5, maxLateralAccel: 8, maxAccel: 8, maxDecel: 8 };
  const zs = wheels.map((w) => w.connection.z);
  const xs = wheels.map((w) => w.connection.x);
  const front = wheels.filter((w) => w.steering).map((w) => w.connection.z);
  const rear = wheels.filter((w) => !w.steering).map((w) => w.connection.z);
  const mean = (a: number[]) => a.reduce((s, v) => s + v, 0) / a.length;
  const wheelbase = Math.max(1, front.length && rear.length ? Math.abs(mean(front) - mean(rear)) : Math.max(...zs) - Math.min(...zs));
  const track = Math.max(0.9, Math.max(...xs) - Math.min(...xs));
  const h = Math.max(0.25, mean(wheels.map((w) => w.radius - (w.connection.y - w.suspensionRestLength))));
  // empinar (wheelie): a roda traseira vira o pivô quando m·a·h = m·g·b (b = COM → eixo mais traseiro); frear forte faz o mesmo para a frente (stoppie)
  const back = Math.max(0.2, Math.max(...zs));
  const frontDist = Math.max(0.2, -Math.min(...zs));
  // moto (uma linha de rodas): ela se INCLINA para dentro da curva, então a aceleração lateral é a da inclinação máxima (tan φ · g), não a de tombamento lateral
  const leans = Math.max(...xs) - Math.min(...xs) < BALANCE_TRACK_LIMIT;
  const maxLateralAccel = leans ? LEAN_SAFETY * GRAVITY * Math.tan(BIKE_MAX_LEAN * DEG) : LATERAL_SAFETY * GRAVITY * (track / 2) / h;
  return { wheelbase, maxLateralAccel, maxAccel: LONGITUDINAL_SAFETY * GRAVITY * back / h, maxDecel: LONGITUDINAL_SAFETY * GRAVITY * frontDist / h };
}

/** Fração da aceleração/frenagem que empina ou capota para frente permitida (margem de segurança). */
export const LONGITUDINAL_SAFETY = 0.6;

/** O "para cima" (+Y local) de um quaternion, no mundo. */
export function upOf(q: Quat): V3 {
  return { x: 2 * (q.x * q.y - q.w * q.z), y: 1 - 2 * (q.x * q.x + q.z * q.z), z: 2 * (q.y * q.z + q.w * q.x) };
}

/**
 * `VehicleWheelSpec` de uma roda filha. `initialPosition` é a posição LOCAL autoral da roda e `parentScale` a escala do veículo: a
 * conexão fica no espaço do corpo SEM escala (`local × escala do pai`), `suspensionTravel` acima do centro da roda em repouso. Sem
 * "Suspension Override" a roda herda rigidez, amortecimento e curso do veículo.
 */
export function buildWheelSpec(
  id: string,
  wheel: Readonly<Record<string, unknown>>,
  vehicle: { suspensionStiffness: number; suspensionDamping: number; suspensionTravel: number },
  initialPosition: readonly [number, number, number],
  parentScale: readonly [number, number, number]
): VehicleWheelSpec {
  const override = wheel.suspensionOverride === true;
  const travel = override ? Math.max(0.02, finite(wheel.suspensionTravel, vehicle.suspensionTravel)) : vehicle.suspensionTravel;
  const stiffness = override ? Math.max(0.1, finite(wheel.suspensionStiffness, vehicle.suspensionStiffness)) : vehicle.suspensionStiffness;
  const damping = override ? Math.max(0, finite(wheel.suspensionDamping, vehicle.suspensionDamping)) : vehicle.suspensionDamping;
  return {
    id,
    connection: { x: initialPosition[0] * parentScale[0], y: initialPosition[1] * parentScale[1] + travel, z: initialPosition[2] * parentScale[2] },
    radius: Math.max(0.05, finite(wheel.radius, 0.35)),
    suspensionRestLength: travel,
    maxSuspensionTravel: travel,
    stiffness,
    compressionDamping: damping,
    relaxationDamping: damping * 1.9,
    frictionSlip: WHEEL_FRICTION_SLIP,
    steering: wheel.isSteering === true,
    motorized: wheel.isMotorized === true,
  };
}

/** Bitola (m) abaixo da qual o veículo é de "uma linha de rodas" (moto): sem estabilizadores ele deitaria na hora. */
export const BALANCE_TRACK_LIMIT = 0.6;
/** Meia-distância lateral (m) das rodas de equilíbrio. */
export const BALANCE_HALF_TRACK = 0.3;

/** Bitola das rodas reais (m): distância lateral entre a mais à esquerda e a mais à direita. */
export const trackOf = (wheels: readonly Pick<VehicleWheelSpec, 'connection'>[]): number => (wheels.length ? Math.max(...wheels.map((w) => w.connection.x)) - Math.min(...wheels.map((w) => w.connection.x)) : 0);

/**
 * Rodas de EQUILÍBRIO de um veículo de uma linha de rodas (moto, AIS-73): duas rodas virtuais (sem nó, sem motor, sem freio, atrito baixo) nas
 * laterais da roda traseira, que tocam o chão ao mesmo tempo que as reais. É um estabilizador ARCADE (a moto não inclina nem cai); sem eles
 * um corpo apoiado numa linha de rodas deita. Vazio se o veículo já tem bitola suficiente.
 */
export function balanceWheelSpecs(vehicleId: string, wheels: readonly VehicleWheelSpec[]): VehicleWheelSpec[] {
  if (wheels.length === 0 || trackOf(wheels) >= BALANCE_TRACK_LIMIT) return [];
  const anchor = wheels.reduce((best, w) => (w.connection.z > best.connection.z ? w : best), wheels[0]); // a mais traseira
  const radius = Math.max(0.05, anchor.radius * 0.5);
  const make = (side: 'l' | 'r', x: number): VehicleWheelSpec => ({
    ...anchor,
    id: `${vehicleId}#balance_${side}`,
    connection: { x: anchor.connection.x + x, y: anchor.connection.y - anchor.radius + radius, z: anchor.connection.z },
    radius,
    frictionSlip: 0.8,
    steering: false,
    motorized: false,
  });
  return [make('l', -BALANCE_HALF_TRACK), make('r', BALANCE_HALF_TRACK)];
}

/** Limites de estabilidade → parâmetros do `driveWheels` (esterçamento lateral e forças máximas de motor/freio para a massa real do corpo). */
export function limitsOf(stability: ReturnType<typeof stabilityOf>, mass: number): Pick<VehicleDriveParams, 'lateral' | 'maxEngineForce' | 'maxBrakeForce'> {
  return { lateral: { wheelbase: stability.wheelbase, maxLateralAccel: stability.maxLateralAccel }, maxEngineForce: stability.maxAccel * mass, maxBrakeForce: stability.maxDecel * mass };
}

// ── inclinação da moto (arcade) ───────────────────────────────────────────────────────────────

/** Ganho sobre a inclinação "física" atan(a/g): exagera um pouco, como nos jogos de moto. */
export const LEAN_GAIN = 1;
/** Velocidade (m/s) a partir da qual a inclinação chega ao valor cheio (abaixo, cresce linear: parada ela fica em pé). */
export const LEAN_FULL_SPEED = 16;
/** Controle PD do torque de inclinação (inércia equivalente por kg, rigidez e amortecimento). */
export const LEAN_INERTIA = 0.3;
export const LEAN_KP = 70;
export const LEAN_KD = 11;

/** Inclinação lateral λ (rad, POSITIVA = inclinado para a ESQUERDA) de um corpo: a vertical do mundo vista no referencial do corpo. */
export function leanOf(q: Quat): number {
  const wx = 2 * (q.x * q.y + q.w * q.z);
  const wy = 1 - 2 * (q.x * q.x + q.z * q.z);
  return Math.atan2(wx, wy);
}

/** A frente (-Z local) do corpo, no mundo. */
export function forwardOf(q: Quat): V3 {
  return { x: -2 * (q.x * q.z + q.w * q.y), y: -2 * (q.y * q.z - q.w * q.x), z: -(1 - 2 * (q.x * q.x + q.y * q.y)) };
}

/**
 * Inclinação-alvo (rad, + = esquerda) da moto: atan(a_lat / g) com a_lat = v² · tan(δ) / L, para o lado da curva. Cresce com o QUADRADO da
 * velocidade (mais rápido, mais deitada), é limitada por \`BIKE_MAX_LEAN\` e some parada ou de ré. \`steer\` em rad (+ = esquerda).
 */
export function leanTarget(forwardSpeed: number, steer: number, wheelbase: number): number {
  if (!(forwardSpeed > 0.3) || !Number.isFinite(steer) || !(wheelbase > 0)) return 0;
  const lateral = (forwardSpeed * forwardSpeed * Math.tan(steer)) / wheelbase;
  const ramp = clamp(forwardSpeed / LEAN_FULL_SPEED, 0, 1);
  const max = BIKE_MAX_LEAN * DEG;
  return clamp(Math.atan(lateral / GRAVITY) * LEAN_GAIN * ramp, -max, max);
}

/**
 * Torque (N·m) em torno da FRENTE do corpo que leva a inclinação \`lean\` ao alvo (PD sobre λ). \`forwardAngularVelocity\` = ω · frente (rad/s).
 * Torque positivo em torno da frente inclina para a DIREITA (λ diminui), por isso o sinal negativo.
 */
export function leanTorque(lean: number, forwardAngularVelocity: number, target: number, mass: number): number {
  const leanRate = -forwardAngularVelocity;
  const accel = LEAN_KP * (target - lean) - LEAN_KD * leanRate; // aceleração desejada de λ
  return -LEAN_INERTIA * Math.max(1, mass) * accel;
}
