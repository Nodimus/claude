/**
 * AIS-25c — Containers estilo Godot sobre o UIKit (Yoga/Flexbox): tradução PURA do modelo
 * `Control`/`Container` para propriedades de flex. Não calcula geometria (quem calcula é o Yoga do UIKit,
 * o mesmo motor que desenha); só decide COMO cada filho entra no fluxo. Sem React/Three/UIKit.
 *
 * Modelo (Godot):
 *  - Container: organiza os filhos; as âncoras/offsets do filho são IGNORADOS.
 *  - Size flags por eixo: `fill` (ocupa o espaço do seu slot), `expand` (disputa o espaço extra, proporcional
 *    a `stretchRatio`, mantendo o tamanho mínimo alinhado ao início), `expand-fill` (disputa e preenche),
 *    `shrink-begin|center|end` (tamanho mínimo alinhado).
 *  - Tamanho mínimo do filho = máx(`minSize`, `width`/`height` do próprio nó): Overlay2D/Panel/Slider… não
 *    têm conteúdo intrínseco, então o tamanho dado ao nó é o mínimo dele dentro do Container.
 */

export const SIZE_FLAG_VALUES = ['fill', 'expand', 'expand-fill', 'shrink-begin', 'shrink-center', 'shrink-end'] as const;
export type SizeFlag = (typeof SIZE_FLAG_VALUES)[number];

export function parseSizeFlag(value: unknown): SizeFlag {
  return typeof value === 'string' && (SIZE_FLAG_VALUES as readonly string[]).includes(value) ? (value as SizeFlag) : 'fill';
}

export interface AxisFlags {
  /** Disputa o espaço extra do eixo principal. */
  expand: boolean;
  /** Ocupa todo o slot (senão fica no tamanho mínimo). */
  fill: boolean;
  /** Alinhamento do tamanho mínimo dentro do slot quando não preenche. */
  align: 'begin' | 'center' | 'end';
}

export function axisFlags(flag: SizeFlag): AxisFlags {
  switch (flag) {
    case 'fill':
      return { expand: false, fill: true, align: 'begin' };
    case 'expand':
      return { expand: true, fill: false, align: 'begin' };
    case 'expand-fill':
      return { expand: true, fill: true, align: 'begin' };
    case 'shrink-center':
      return { expand: false, fill: false, align: 'center' };
    case 'shrink-end':
      return { expand: false, fill: false, align: 'end' };
    case 'shrink-begin':
    default:
      return { expand: false, fill: false, align: 'begin' };
  }
}

// ── Quais tipos organizam filhos ──────────────────────────────────────────────────────────────

export type ContainerKind = 'row' | 'column' | 'grid' | 'margin' | 'center' | 'scroll' | 'stack';

const CONTAINER_KIND: Readonly<Record<string, ContainerKind>> = {
  HBox: 'row',
  VBox: 'column',
  Grid: 'grid',
  MarginContainer: 'margin',
  CenterContainer: 'center',
  ScrollContainer: 'scroll',
  Container: 'stack',
};

/** `null` para tipos que NÃO organizam filhos (Panel, Overlay2D, controles): filhos deles são livres (âncoras/offsets). */
export function containerKindOf(type: string): ContainerKind | null {
  return CONTAINER_KIND[type] ?? null;
}
export const isLayoutContainerType = (type: string): boolean => containerKindOf(type) !== null;

// ── Propriedades de flex ──────────────────────────────────────────────────────────────────────

type Props = Record<string, any> | undefined;
const num = (v: unknown, fallback: number): number => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);
const flexAlign = (a: 'begin' | 'center' | 'end') => (a === 'center' ? 'center' : a === 'end' ? 'flex-end' : 'flex-start');

export interface FlexProps {
  [key: string]: string | number | undefined;
}

/** Propriedades de flex do PRÓPRIO container (como organiza os filhos). Posição/tamanho do container vêm do layout livre ou do pai. */
export function containerFlexProps(type: string, props: Props): FlexProps {
  const p = props ?? {};
  switch (containerKindOf(type)) {
    case 'row':
      return {
        flexDirection: 'row',
        gap: Math.max(0, num(p.separation, 8)),
        justifyContent: flexAlign(p.contentAlignment === 'center' || p.contentAlignment === 'end' ? p.contentAlignment : 'begin'),
        alignItems: 'stretch',
      };
    case 'column':
      return {
        flexDirection: 'column',
        gap: Math.max(0, num(p.separation, 8)),
        justifyContent: flexAlign(p.contentAlignment === 'center' || p.contentAlignment === 'end' ? p.contentAlignment : 'begin'),
        alignItems: 'stretch',
      };
    case 'grid':
      return { flexDirection: 'column', gap: Math.max(0, num(p.vSeparation, 8)), alignItems: 'stretch' };
    case 'margin':
      return {
        flexDirection: 'column',
        paddingLeft: Math.max(0, num(p.marginLeft, 8)),
        paddingTop: Math.max(0, num(p.marginTop, 8)),
        paddingRight: Math.max(0, num(p.marginRight, 8)),
        paddingBottom: Math.max(0, num(p.marginBottom, 8)),
        alignItems: 'stretch',
      };
    case 'center':
      return { flexDirection: 'column', alignItems: 'center', justifyContent: 'center' };
    case 'scroll': {
      // o UIKit tem um só `overflow` (os dois eixos): rola se algum eixo permitir; os dois `never` = corta
      const both = p.scrollH === 'never' && p.scrollV === 'never';
      return { flexDirection: 'column', alignItems: 'stretch', overflow: both ? 'hidden' : 'scroll' };
    }
    case 'stack':
      return { flexDirection: 'column', alignItems: 'stretch' };
    default:
      return {};
  }
}

/** Direção do eixo principal do fluxo dos filhos (para ler os flags certos). */
export function mainAxisOf(kind: ContainerKind): 'row' | 'column' {
  return kind === 'row' ? 'row' : 'column';
}

/** Tamanho mínimo base de um filho: máx(minSize, width/height próprios); 0 num eixo esticado por preset. */
export function childMinSize(props: Props): { width: number; height: number } {
  const p = props ?? {};
  const minSize = p.minSize && typeof p.minSize === 'object' ? p.minSize : {};
  return {
    width: Math.max(0, num(minSize.x, 0), num(p.width, 0)),
    height: Math.max(0, num(minSize.y, 0), num(p.height, 0)),
  };
}

export interface ChildFlex {
  /** Wrapper (o "slot" do Godot) que recebe o espaço do eixo principal. */
  slot: FlexProps;
  /** O controle em si dentro do slot. */
  inner: FlexProps;
}

/**
 * Como um filho entra no fluxo de um container (linha/coluna/grade/margem/centro/scroll).
 * `slot` é o espaço reservado; `inner` o controle dentro dele.
 */
export function childFlex(kind: ContainerKind, childProps: Props): ChildFlex {
  const p = childProps ?? {};
  const h = axisFlags(parseSizeFlag(p.sizeFlagsH));
  const v = axisFlags(parseSizeFlag(p.sizeFlagsV));
  const min = childMinSize(p);
  const ratio = Math.max(0.01, num(p.stretchRatio, 1));

  if (kind === 'margin') {
    // Godot MarginContainer: o filho ocupa todo o retângulo menos as margens
    return {
      slot: { flexDirection: 'row', flexGrow: 1, flexShrink: 1, flexBasis: 0, alignSelf: 'stretch' },
      inner: { width: '100%', height: '100%', minWidth: min.width, minHeight: min.height },
    };
  }

  const main = kind === 'row' ? h : v; // eixo principal do container
  const cross = kind === 'row' ? v : h; // eixo transversal
  const minMain = kind === 'row' ? min.width : min.height;
  const minCross = kind === 'row' ? min.height : min.width;
  const direction = kind === 'row' ? 'row' : 'column';

  const slot: FlexProps = {
    flexDirection: direction,
    flexShrink: 0,
    // espaço extra só vai para quem tem `expand`, na proporção de `stretchRatio`
    flexGrow: kind === 'center' || kind === 'scroll' || kind === 'stack' ? 0 : main.expand ? ratio : 0,
    flexBasis: minMain, // base = tamanho mínimo; o resto é repartido por `flexGrow` (Godot: expand divide o espaço extra)
    // transversal: fill estica; senão alinha o tamanho mínimo
    alignSelf: kind === 'center' ? 'center' : cross.fill ? 'stretch' : flexAlign(cross.align),
    // principal: quando o slot cresce e o filho não preenche, o filho se alinha dentro do slot
    justifyContent: flexAlign(main.align),
    alignItems: cross.fill ? 'stretch' : flexAlign(cross.align),
  };

  const inner: FlexProps = {};
  if (kind === 'row') {
    inner.width = main.fill ? '100%' : min.width;
    inner.height = cross.fill ? '100%' : min.height;
  } else {
    inner.height = main.fill ? '100%' : min.height;
    inner.width = cross.fill ? '100%' : min.width;
  }
  inner.minWidth = min.width;
  inner.minHeight = min.height;
  // `fill` no eixo principal só faz sentido se o slot tiver espaço: slot sem expand mantém o tamanho mínimo
  if (!main.expand && main.fill) {
    if (kind === 'row') inner.width = min.width;
    else inner.height = min.height;
  }
  void minCross;
  return { slot, inner };
}

/** Divide os filhos de um Grid em linhas de `columns` células (a última completada com `null`). */
export function gridRows<T>(items: readonly T[], columns: number): (T | null)[][] {
  const cols = Math.max(1, Math.floor(columns) || 1);
  const rows: (T | null)[][] = [];
  for (let i = 0; i < items.length; i += cols) {
    const row: (T | null)[] = items.slice(i, i + cols);
    while (row.length < cols) row.push(null);
    rows.push(row);
  }
  return rows;
}
