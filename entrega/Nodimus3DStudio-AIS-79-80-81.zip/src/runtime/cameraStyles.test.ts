import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { ensureRapier } from '../core/physics/rapierInit';
import { InputManager } from './input/InputManager';
import { RuntimeSession } from './RuntimeSession';
import { rotateByQuat } from './controllers/controllerMath';

/**
 * AIS-47d (decisão 28) — Free Flying, Model Viewer, Panorama e RTS dentro da `RuntimeSession`, com o `InputManager` real
 * (teclado, botão do mouse, roda e limites da viewport injetados como o DOM faz).
 */

beforeAll(async () => {
  await ensureRapier();
});

let seq = 0;
const beh = (behaviorType: string, properties: Record<string, any> = {}): BehaviorInstance => ({ id: `b${++seq}`, name: behaviorType, behaviorType, enabled: true, properties, rules: [] });

const meshNode = (id: string, at: [number, number, number], extra: Record<string, any> = {}): GameNode =>
  ({ id, name: id, type: 'MeshInstance', parentId: null, childrenIds: [], visible: true, locked: false, properties: { meshType: 'CubeMesh', position: { x: at[0], y: at[1], z: at[2] }, ...extra } }) as unknown as GameNode;

const cameraNode = (id: string, at: [number, number, number], behaviors: BehaviorInstance[] = [], props: Record<string, any> = {}): GameNode =>
  ({ id, name: id, type: 'Camera', parentId: null, childrenIds: [], visible: true, locked: false, properties: { position: { x: at[0], y: at[1], z: at[2] }, rotation: { x: 0, y: 0, z: 0 }, active: true, ...props }, behaviors }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  return { ...scene, nodes };
}

function open(scene: SceneData) {
  const input = new InputManager();
  input.setEnabled(true);
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input });
  session.start();
  const frame = (n = 1) => {
    for (let i = 0; i < n; i++) {
      session.step(1 / 60);
      input.endFrame();
    }
  };
  const cam = () => session.gameCamera!;
  const dir = () => rotateByQuat({ x: 0, y: 0, z: -1 }, cam().quaternion);
  return { session, input, frame, cam, dir, inst: (id: string) => session.currentScene!.getInstance(id)! };
}

const hold = (input: InputManager, frame: (n?: number) => void, key: string, n = 60) => {
  input.handleKey(key, true);
  frame(n);
  input.handleKey(key, false);
};

describe('Free Flying Camera', () => {
  const build = (props: Record<string, any> = {}) => open(sceneWith(cameraNode('cam', [0, 5, 10], [beh('camera_free_flying', props)])));

  it('voa sem ator: WASD relativo ao olhar, Jump sobe, Crouch desce; sem gravidade (fica parada no ar)', () => {
    const { input, frame, cam } = build({ moveSpeed: 6 });
    frame(10);
    expect(cam().kind).toBe('camera');
    expect(cam().position).toEqual({ x: 0, y: 5, z: 10 }); // sem gravidade: nada o derruba
    frame(120);
    expect(cam().position.y).toBe(5);
    hold(input, frame, 'KeyW');
    expect(cam().position.z).toBeCloseTo(10 - 6, 0); // ~6 m para -Z em 1 s
    hold(input, frame, 'Space');
    expect(cam().position.y).toBeCloseTo(11, 0);
    hold(input, frame, 'KeyC');
    expect(cam().position.y).toBeCloseTo(5, 0);
  });

  it('olha com o mouse (ponteiro capturado) e passa a avançar para onde olha; viewBasis vem dela', () => {
    const { session, input, frame, cam } = build({ rotateSpeed: 0.15 });
    frame(2);
    input.handlePointerDelta(-600, 0); // 90° à esquerda
    frame(2);
    expect(session.viewBasis!.yaw).toBeCloseTo(90, 4);
    const x0 = cam().position.x;
    hold(input, frame, 'KeyW');
    expect(x0 - cam().position.x).toBeGreaterThan(5); // agora "frente" é -X
  });

  it('não depende de ator, não move o nó Camera autoral nem escreve no authoring', () => {
    const scene = sceneWith(cameraNode('cam', [0, 5, 10], [beh('camera_free_flying')]));
    const before = JSON.stringify(scene);
    const { input, frame, inst } = open(scene);
    hold(input, frame, 'KeyW', 30);
    expect(inst('cam').transform.position).toEqual([0, 5, 10]);
    expect(JSON.stringify(scene)).toBe(before);
  });

  it('com o nó inativo não publica', () => {
    const { session, frame } = open(sceneWith(cameraNode('cam', [0, 5, 10], [beh('camera_free_flying')], { active: false })));
    frame(10);
    expect(session.gameCamera).toBeNull();
  });
});

describe('Model Viewer Camera', () => {
  const build = (props: Record<string, any> = {}, at: [number, number, number] = [0, 5, 10]) => open(sceneWith(meshNode('model', [4, 1, 0]), cameraNode('cam', at, [beh('camera_model_viewer', { targetNodeId: 'model', radius: 5, rotateSpeed: 0.5, ...props })])));
  const distTo = (p: { x: number; y: number; z: number }, t: [number, number, number]) => Math.hypot(p.x - t[0], p.y - t[1], p.z - t[2]);

  it('orbita o alvo à distância `radius` e SÓ gira arrastando com a ação de órbita (botão esquerdo)', () => {
    const { input, frame, cam, session } = build();
    frame(5);
    expect(distTo(cam().position, [4, 1, 0])).toBeCloseTo(5, 3);
    const p0 = { ...cam().position };
    input.handlePointerDelta(120, 0); // sem arrastar: não gira
    frame(2);
    expect(cam().position).toEqual(p0);
    input.handleMouseButton(0, true);
    input.handlePointerDelta(120, 0); // 60°
    frame(2);
    input.handleMouseButton(0, false);
    expect(Math.abs(session.viewBasis!.yaw)).toBeCloseTo(60, 3);
    expect(distTo(cam().position, [4, 1, 0])).toBeCloseTo(5, 3); // a distância não muda
    expect(cam().position.x).not.toBeCloseTo(p0.x, 1);
  });

  it('verticalMovementAllowed: false trava a elevação; true deixa subir', () => {
    const locked = build({ verticalMovementAllowed: false });
    locked.frame(3);
    const y0 = locked.cam().position.y;
    locked.input.handleMouseButton(0, true);
    locked.input.handlePointerDelta(0, 200);
    locked.frame(2);
    expect(locked.cam().position.y).toBeCloseTo(y0, 6);
    const free = build({ verticalMovementAllowed: true });
    free.frame(3);
    const f0 = free.cam().position.y;
    free.input.handleMouseButton(0, true);
    free.input.handlePointerDelta(0, 60);
    free.frame(2);
    expect(Math.abs(free.cam().position.y - f0)).toBeGreaterThan(0.3);
  });

  it('nunca altera o modelo; sem alvo orbita a posição autoral; alvo inexistente cai no pivô autoral', () => {
    const scene = sceneWith(meshNode('model', [4, 1, 0]), cameraNode('cam', [2, 3, 4], [beh('camera_model_viewer', { radius: 5 })]));
    const s = open(scene);
    s.input.handleMouseButton(0, true);
    s.input.handlePointerDelta(100, 40);
    s.frame(5);
    expect(distTo(s.cam().position, [2, 3, 4])).toBeCloseTo(5, 3);
    expect(s.inst('model').transform.position).toEqual([4, 1, 0]);
    expect(s.inst('model').transform.rotation).toEqual([0, 0, 0]);
    const ghost = build({ targetNodeId: 'nao_existe' }, [2, 3, 4]);
    ghost.frame(3);
    expect(distTo(ghost.cam().position, [2, 3, 4])).toBeCloseTo(5, 3);
  });
});

describe('Panorama Camera', () => {
  const build = () => open(sceneWith(cameraNode('cam', [1, 2, 3], [beh('camera_panorama', { rotateSpeed: 0.2 })])));

  it('posição fixa e só rotaciona arrastando com a ação (botão esquerdo)', () => {
    const { session, input, frame, cam } = build();
    frame(3);
    expect(cam().position).toEqual({ x: 1, y: 2, z: 3 });
    input.handlePointerDelta(450, 0);
    frame(2);
    expect(session.viewBasis!.yaw).toBeCloseTo(0, 6); // sem arrastar, nada gira
    input.handleMouseButton(0, true);
    input.handlePointerDelta(-450, 0); // 90° à esquerda (0,2°/px)
    frame(2);
    input.handleMouseButton(0, false);
    expect(session.viewBasis!.yaw).toBeCloseTo(90, 3);
    expect(cam().position).toEqual({ x: 1, y: 2, z: 3 }); // a posição nunca muda
  });

  it('não captura o ponteiro e o pitch é limitado', () => {
    const { input, frame, cam, session } = build();
    frame(2);
    input.handleMouseButton(0, true);
    input.handlePointerDelta(0, -100000);
    frame(2);
    expect(cam().pointerLock).toBe(false);
    expect(session.viewBasis!.pitch).toBe(85);
  });
});

describe('RTS Camera', () => {
  const build = (props: Record<string, any> = {}) => {
    const s = open(sceneWith(cameraNode('cam', [0, 10, 10], [beh('camera_rts', { panSpeed: 10, tilt: 45, minZoomDistance: 5, maxZoomDistance: 30, zoomScrollDistance: 2, ...props })])));
    s.input.setPointerBounds({ left: 0, top: 0, width: 800, height: 600 });
    s.input.handlePointerMove(400, 300); // meio da viewport: sem pan de borda
    s.input.endFrame();
    return s;
  };

  it('sem alvo e sem player: a câmera nasce acima do XZ autoral, inclinada, olhando para o chão', () => {
    const { session, frame, cam } = build();
    frame(3);
    expect(cam().kind).toBe('camera');
    expect(cam().position.x).toBeCloseTo(0, 3);
    expect(cam().position.z).toBeCloseTo(10, 3);
    expect(cam().position.y).toBeCloseTo(10, 3);
    expect(session.viewBasis!.pitch).toBe(-45);
  });

  it('WASD faz pan relativo ao yaw da câmera', () => {
    const { input, frame, cam } = build();
    frame(3);
    const z0 = cam().position.z;
    hold(input, frame, 'KeyW');
    expect(z0 - cam().position.z).toBeCloseTo(10, 0);
    const x0 = cam().position.x;
    hold(input, frame, 'KeyD');
    expect(cam().position.x - x0).toBeCloseTo(10, 0);
  });

  it('pan pela BORDA da viewport (ponteiro perto do limite) e nada fora dela', () => {
    const { input, frame, cam } = build({ distanceFromBoundary: 20 });
    frame(3);
    const x0 = cam().position.x;
    input.handlePointerMove(5, 300); // colado na borda esquerda
    frame(60);
    expect(x0 - cam().position.x).toBeGreaterThan(8); // ~10 m para -X
    const x1 = cam().position.x;
    input.handlePointerMove(-50, 300); // fora da viewport
    frame(60);
    expect(cam().position.x).toBeCloseTo(x1, 6);
    input.handlePointerMove(400, 300);
    frame(60);
    expect(cam().position.x).toBeCloseTo(x1, 6); // meio: parado
  });

  it('distanceFromBoundary 0 desliga o pan por borda', () => {
    const { input, frame, cam } = build({ distanceFromBoundary: 0 });
    frame(3);
    const x0 = cam().position.x;
    input.handlePointerMove(5, 300);
    frame(60);
    expect(cam().position.x).toBeCloseTo(x0, 6);
  });

  it('zoom pela roda dentro de [min, max]; Zoom Scroll desligado ignora a roda', () => {
    const { input, frame, cam } = build();
    frame(3);
    const d = (p: { x: number; y: number; z: number }) => p.y / Math.sin(Math.PI / 4); // distância ao foco pela altura (tilt 45°)
    const d0 = d(cam().position);
    input.handleWheel(3); // 3 cliques para longe: +6 m
    frame(2);
    expect(d(cam().position)).toBeCloseTo(d0 + 6, 3);
    input.handleWheel(1000);
    frame(2);
    expect(d(cam().position)).toBeCloseTo(30, 3);
    input.handleWheel(-1000);
    frame(2);
    expect(d(cam().position)).toBeCloseTo(5, 3);
    const off = build({ enableZoomScroll: false });
    off.frame(3);
    const o0 = off.cam().position.y;
    off.input.handleWheel(5);
    off.frame(2);
    expect(off.cam().position.y).toBeCloseTo(o0, 6);
  });

  it('o foco respeita a área jogável (boundsMin/boundsMax)', () => {
    const { input, frame, cam } = build({ boundsMin: { x: -5, y: 0, z: -100 }, boundsMax: { x: 5, y: 0, z: 100 } });
    frame(3);
    hold(input, frame, 'KeyD', 300); // 50 m para a direita: para em x = 5
    expect(cam().position.x).toBeCloseTo(5, 3);
    hold(input, frame, 'KeyA', 600);
    expect(cam().position.x).toBeCloseTo(-5, 3);
  });
});

describe('InputManager: roda e limites da viewport (AIS-47d)', () => {
  it('a roda acumula no quadro e zera no endFrame; só vale com o input ativo', () => {
    const input = new InputManager();
    input.setEnabled(true);
    input.handleWheel(2);
    input.handleWheel(-0.5);
    expect(input.pointer.wheel).toBeCloseTo(1.5);
    input.endFrame();
    expect(input.pointer.wheel).toBe(0);
    input.setEnabled(false);
    input.handleWheel(3);
    expect(input.pointer.wheel).toBe(0);
  });

  it('bounds é injetável e copiado; null o esquece', () => {
    const input = new InputManager();
    expect(input.pointer.bounds).toBeNull();
    const rect = { left: 1, top: 2, width: 3, height: 4 };
    input.setPointerBounds(rect);
    rect.left = 99;
    expect(input.pointer.bounds).toEqual({ left: 1, top: 2, width: 3, height: 4 });
    input.setPointerBounds(null);
    expect(input.pointer.bounds).toBeNull();
  });

  it('pelo DOM: o evento wheel acumula (linhas e pixels) e atualiza os limites da viewport', () => {
    const listeners = new Map<string, (e: any) => void>();
    const target = { addEventListener: (t: string, l: (e: any) => void) => void listeners.set(t, l), removeEventListener: () => undefined };
    const input = new InputManager();
    const detach = input.attach({ keyTarget: { addEventListener: () => undefined, removeEventListener: () => undefined }, pointerTarget: target, getGamepads: () => [] });
    const el = { getBoundingClientRect: () => ({ left: 10, top: 20, width: 300, height: 200 }) };
    let prevented = 0;
    listeners.get('wheel')!({ deltaMode: 1, deltaY: 3, currentTarget: el, preventDefault: () => prevented++ });
    listeners.get('wheel')!({ deltaMode: 0, deltaY: 100, currentTarget: el, preventDefault: () => prevented++ });
    expect(input.pointer.wheel).toBeCloseTo(4);
    expect(input.pointer.bounds).toEqual({ left: 10, top: 20, width: 300, height: 200 });
    expect(prevented).toBe(2); // não rola a página durante o jogo
    detach();
  });
});

describe('seleção com os novos estilos', () => {
  it('qualquer estilo de câmera tem prioridade sobre o composto legado e o nó Camera sem Behavior segue ignorado', () => {
    const withRts = open(sceneWith(cameraNode('ignored', [0, 3, 8]), cameraNode('cam', [0, 10, 10], [beh('camera_rts')])));
    withRts.frame(3);
    expect(withRts.session.gameCamera!.nodeId).toBe('cam');
    const onlyPlain = open(sceneWith(cameraNode('MainCamera', [0, 3, 8])));
    onlyPlain.frame(3);
    expect(onlyPlain.session.gameCamera).toBeNull();
  });
});
