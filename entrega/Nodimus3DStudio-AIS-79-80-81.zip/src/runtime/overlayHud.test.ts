import { describe, expect, it } from 'vitest';
import { OverlayHud, type HudNode } from './overlayHud';
import type { Rect } from './overlay';

/**
 * AIS-25c — geometria REAL dos Containers: roda o layout (Yoga) do próprio UIKit, headless (sem WebGL/DOM).
 * É o mesmo motor que desenha no editor e no Play, então estes números são a paridade Editor × Play.
 */

const VIEW = { width: 800, height: 600 };

type NodeMap = Record<string, HudNode>;
const node = (id: string, type: string, parentId: string | null, childrenIds: string[], properties: Record<string, any> = {}): HudNode => ({
  id,
  name: id,
  type,
  parentId,
  childrenIds,
  visible: true,
  properties,
});
/** Filho "elástico": tamanho próprio 0 (só flags/ratio decidem). */
const flexChild = (id: string, parentId: string, properties: Record<string, any> = {}) =>
  node(id, 'Overlay2D', parentId, [], { width: 0, height: 0, ...properties });
const fixed = (id: string, parentId: string, width: number, height: number, properties: Record<string, any> = {}) =>
  node(id, 'Overlay2D', parentId, [], { width, height, ...properties });

async function layout(nodes: NodeMap): Promise<ReadonlyMap<string, Rect>> {
  const hud = new OverlayHud({ loadFonts: false });
  await hud.ready();
  hud.setNodes(nodes);
  const rects = hud.layoutNow(VIEW.width, VIEW.height);
  return rects;
}

const near = (a: number, b: number, tol = 0.6) => Math.abs(a - b) <= tol;
const expectRect = (r: Rect | undefined, left: number, top: number, width: number, height: number) => {
  expect(r, 'rect ausente').toBeDefined();
  expect(near(r!.left, left), `left ${r!.left} ≠ ${left}`).toBe(true);
  expect(near(r!.top, top), `top ${r!.top} ≠ ${top}`).toBe(true);
  expect(near(r!.width, width), `width ${r!.width} ≠ ${width}`).toBe(true);
  expect(near(r!.height, height), `height ${r!.height} ≠ ${height}`).toBe(true);
};

describe('OverlayHud — layout livre (AIS-25b) pelo mesmo motor', () => {
  it('Overlay2D Center 100×100 fica no centro; Top-Left usa posX/posY', async () => {
    const rects = await layout({
      c: node('c', 'Overlay2D', null, [], { alignment: 'Center', posX: 0, posY: 0, width: 100, height: 100 }),
      t: node('t', 'Overlay2D', null, [], { alignment: 'Top-Left', posX: 20, posY: 30, width: 140, height: 40 }),
      br: node('br', 'Overlay2D', null, [], { alignment: 'Bottom-Right', posX: 0, posY: 0, width: 100, height: 50 }),
    });
    expectRect(rects.get('c'), 350, 250, 100, 100);
    expectRect(rects.get('t'), 20, 30, 140, 40);
    expectRect(rects.get('br'), 700, 550, 100, 50);
  });

  it('presets esticados: Top-Wide e Full-Rect', async () => {
    const rects = await layout({
      top: node('top', 'Panel', null, [], { alignment: 'Top-Wide', posX: 10, posY: 5, width: 30, height: 40 }),
      full: node('full', 'Panel', null, [], { alignment: 'Full-Rect', posX: 10, posY: 20, width: 30, height: 40 }),
    });
    expectRect(rects.get('top'), 10, 5, 760, 40);
    expectRect(rects.get('full'), 10, 20, 760, 540);
  });

  it('filho livre dentro de um Panel usa o retângulo do pai (preset Center)', async () => {
    const rects = await layout({
      p: node('p', 'Panel', null, ['c'], { alignment: 'Top-Left', posX: 100, posY: 100, width: 200, height: 200 }),
      c: node('c', 'Overlay2D', 'p', [], { alignment: 'Center', posX: 0, posY: 0, width: 60, height: 20 }),
    });
    expectRect(rects.get('p'), 100, 100, 200, 200);
    expectRect(rects.get('c'), 170, 190, 60, 20);
  });
});

describe('HBox / VBox — distribuição (size flags, stretchRatio, separação)', () => {
  it('HBox: fixo + expand-fill 1:2 dividem o espaço extra na proporção, com separação', async () => {
    const rects = await layout({
      row: node('row', 'HBox', null, ['a', 'b', 'c'], { alignment: 'Top-Left', posX: 0, posY: 0, width: 300, height: 50, separation: 10 }),
      a: fixed('a', 'row', 50, 30, { sizeFlagsH: 'fill' }),
      b: flexChild('b', 'row', { sizeFlagsH: 'expand-fill', stretchRatio: 1 }),
      c: flexChild('c', 'row', { sizeFlagsH: 'expand-fill', stretchRatio: 2 }),
    });
    expectRect(rects.get('row'), 0, 0, 300, 50);
    // livre = 300 − 50 − 2×10 = 230 → b = 230/3, c = 460/3
    const w = 230 / 3;
    expectRect(rects.get('a'), 0, 0, 50, 50); // fill na vertical: estica até 50
    expectRect(rects.get('b'), 60, 0, w, 50);
    expectRect(rects.get('c'), 60 + w + 10, 0, 2 * w, 50);
  });

  it('HBox: eixo transversal — shrink-center centra, shrink-end encosta embaixo', async () => {
    const rects = await layout({
      row: node('row', 'HBox', null, ['a', 'b', 'c'], { alignment: 'Top-Left', posX: 0, posY: 0, width: 300, height: 100, separation: 0 }),
      a: fixed('a', 'row', 40, 20, { sizeFlagsV: 'shrink-begin' }),
      b: fixed('b', 'row', 40, 20, { sizeFlagsV: 'shrink-center' }),
      c: fixed('c', 'row', 40, 20, { sizeFlagsV: 'shrink-end' }),
    });
    expectRect(rects.get('a'), 0, 0, 40, 20);
    expectRect(rects.get('b'), 40, 40, 40, 20);
    expectRect(rects.get('c'), 80, 80, 40, 20);
  });

  it('HBox: expand sem fill mantém o tamanho mínimo e alinha dentro do slot', async () => {
    const rects = await layout({
      row: node('row', 'HBox', null, ['a', 'b'], { alignment: 'Top-Left', posX: 0, posY: 0, width: 300, height: 40, separation: 0 }),
      a: fixed('a', 'row', 50, 20, { sizeFlagsH: 'expand', sizeFlagsV: 'shrink-begin' }), // slot de 150, filho de 50 no início
      b: fixed('b', 'row', 50, 20, { sizeFlagsH: 'expand', sizeFlagsV: 'shrink-begin' }),
    });
    expectRect(rects.get('a'), 0, 0, 50, 20);
    expectRect(rects.get('b'), 150, 0, 50, 20);
  });

  it('VBox: eixo principal é a altura; expand-fill 1:3 e separação', async () => {
    const rects = await layout({
      col: node('col', 'VBox', null, ['a', 'b', 'c'], { alignment: 'Top-Left', posX: 0, posY: 0, width: 100, height: 340, separation: 20 }),
      a: fixed('a', 'col', 100, 100, { sizeFlagsV: 'fill' }),
      b: flexChild('b', 'col', { sizeFlagsV: 'expand-fill', stretchRatio: 1 }),
      c: flexChild('c', 'col', { sizeFlagsV: 'expand-fill', stretchRatio: 3 }),
    });
    // livre = 340 − 100 − 2×20 = 200 → b = 50, c = 150
    expectRect(rects.get('a'), 0, 0, 100, 100);
    expectRect(rects.get('b'), 0, 120, 100, 50);
    expectRect(rects.get('c'), 0, 190, 100, 150);
  });

  it('contentAlignment center/end alinha o conjunto no eixo principal', async () => {
    const mk = (contentAlignment: string) =>
      layout({
        row: node('row', 'HBox', null, ['a'], { alignment: 'Top-Left', posX: 0, posY: 0, width: 300, height: 40, separation: 0, contentAlignment }),
        a: fixed('a', 'row', 100, 40),
      });
    expectRect((await mk('begin')).get('a'), 0, 0, 100, 40);
    expectRect((await mk('center')).get('a'), 100, 0, 100, 40);
    expectRect((await mk('end')).get('a'), 200, 0, 100, 40);
  });

  it('a ordem dos filhos (childrenIds) define a ordem do fluxo; reordenar muda as posições', async () => {
    const make = (order: string[]) => ({
      row: node('row', 'HBox', null, order, { alignment: 'Top-Left', posX: 0, posY: 0, width: 300, height: 40, separation: 0 }),
      a: fixed('a', 'row', 50, 40),
      b: fixed('b', 'row', 70, 40),
    });
    const ab = await layout(make(['a', 'b']));
    expect(ab.get('a')!.left).toBeLessThan(ab.get('b')!.left);
    const ba = await layout(make(['b', 'a']));
    expect(ba.get('b')!.left).toBeLessThan(ba.get('a')!.left);
    expectRect(ba.get('b'), 0, 0, 70, 40);
    expectRect(ba.get('a'), 70, 0, 50, 40);
  });
});

describe('Grid, Margin, Center, aninhamento', () => {
  it('Grid de 2 colunas: colunas de largura igual, separações H/V', async () => {
    const rects = await layout({
      g: node('g', 'Grid', null, ['a', 'b', 'c'], { alignment: 'Top-Left', posX: 0, posY: 0, width: 210, height: 200, columns: 2, hSeparation: 10, vSeparation: 20 }),
      a: fixed('a', 'g', 0, 40),
      b: fixed('b', 'g', 0, 40),
      c: fixed('c', 'g', 0, 40),
    });
    // colunas: (210 − 10) / 2 = 100
    expectRect(rects.get('a'), 0, 0, 100, 40);
    expectRect(rects.get('b'), 110, 0, 100, 40);
    expectRect(rects.get('c'), 0, 60, 100, 40); // 2ª linha: topo = 40 + 20
  });

  it('MarginContainer: o filho ocupa o retângulo menos as margens', async () => {
    const rects = await layout({
      m: node('m', 'MarginContainer', null, ['c'], { alignment: 'Top-Left', posX: 50, posY: 50, width: 200, height: 120, marginLeft: 10, marginTop: 20, marginRight: 30, marginBottom: 40 }),
      c: fixed('c', 'm', 10, 10),
    });
    expectRect(rects.get('m'), 50, 50, 200, 120);
    expectRect(rects.get('c'), 60, 70, 160, 60);
  });

  it('CenterContainer: o filho fica no tamanho mínimo, centrado', async () => {
    const rects = await layout({
      cc: node('cc', 'CenterContainer', null, ['c'], { alignment: 'Top-Left', posX: 0, posY: 0, width: 200, height: 100 }),
      c: fixed('c', 'cc', 40, 20),
    });
    expectRect(rects.get('c'), 80, 40, 40, 20);
  });

  it('VBox dentro de VBox/HBox: a geometria compõe (HBox aninhado numa coluna)', async () => {
    const rects = await layout({
      col: node('col', 'VBox', null, ['title', 'row'], { alignment: 'Top-Left', posX: 0, posY: 0, width: 200, height: 120, separation: 10 }),
      title: fixed('title', 'col', 100, 30, { sizeFlagsV: 'fill' }),
      row: node('row', 'HBox', 'col', ['x', 'y'], { width: 0, height: 40, separation: 0, sizeFlagsV: 'fill' }),
      x: fixed('x', 'row', 60, 40),
      y: fixed('y', 'row', 80, 40),
    });
    expectRect(rects.get('title'), 0, 0, 200, 30); // fill transversal estica até a largura da coluna
    expectRect(rects.get('row'), 0, 40, 200, 40);
    expectRect(rects.get('x'), 0, 40, 60, 40);
    expectRect(rects.get('y'), 60, 40, 80, 40);
  });

  it('nó invisível some do layout e libera o espaço; filho de pai invisível some junto', async () => {
    const rects = await layout({
      row: node('row', 'HBox', null, ['a', 'b', 'c'], { alignment: 'Top-Left', posX: 0, posY: 0, width: 300, height: 40, separation: 0 }),
      a: fixed('a', 'row', 50, 40),
      b: fixed('b', 'row', 70, 40, { visible: false }),
      c: fixed('c', 'row', 60, 40),
    });
    expect(rects.has('b')).toBe(false);
    expectRect(rects.get('c'), 50, 0, 60, 40);
  });

  it('o container interno ao Panel (livre) e o pai de Container: filhos de Container ignoram posX/alignment', async () => {
    const rects = await layout({
      row: node('row', 'HBox', null, ['a'], { alignment: 'Top-Left', posX: 0, posY: 0, width: 300, height: 40, separation: 0 }),
      a: fixed('a', 'row', 50, 40, { alignment: 'Bottom-Right', posX: 999, posY: 999 }),
    });
    expectRect(rects.get('a'), 0, 0, 50, 40);
  });

  it('controles: CheckBox, Slider, ProgressBar e TextInput ocupam o retângulo pedido', async () => {
    const rects = await layout({
      v: node('v', 'VBox', null, ['cb', 'sl', 'pb', 'ti'], { alignment: 'Top-Left', posX: 0, posY: 0, width: 200, height: 200, separation: 10 }),
      cb: node('cb', 'CheckBox', 'v', [], { width: 140, height: 24 }),
      sl: node('sl', 'Slider', 'v', [], { width: 160, height: 20 }),
      pb: node('pb', 'ProgressBar', 'v', [], { width: 160, height: 20 }),
      ti: node('ti', 'TextInput', 'v', [], { width: 160, height: 30 }),
    });
    expect(rects.get('cb')!.height).toBeCloseTo(24, 0);
    expect(rects.get('sl')!.height).toBeCloseTo(20, 0);
    expect(rects.get('pb')!.height).toBeCloseTo(20, 0);
    expect(rects.get('ti')!.height).toBeCloseTo(30, 0);
    // empilhados em coluna com separação 10
    expect(near(rects.get('sl')!.top, rects.get('cb')!.top + 24 + 10, 1)).toBe(true);
    expect(near(rects.get('pb')!.top, rects.get('sl')!.top + 20 + 10, 1)).toBe(true);
  });
});
