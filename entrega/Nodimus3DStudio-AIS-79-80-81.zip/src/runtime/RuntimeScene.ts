import * as THREE from 'three';
import type { AuthoringSceneSnapshot, RuntimeInstanceHandle, RuntimeSceneContract } from '../types/runtime';
import type { GameNode, NodeType } from '../types/node';
import { extractNodeTransform } from '../core/authoring/snapshot';
import { remapNodeIds } from '../core/authoring/remapNodeIds';
import { RuntimeObjectFactory } from './RuntimeObjectFactory';

/**
 * AIS-29d — RuntimeScene e RuntimeInstance.
 *
 * `RuntimeScene` é a cena VIVA, descartável, construída de um `AuthoringSceneSnapshot` (nunca da cena autoral): uma
 * árvore de `RuntimeInstance` com os seus `THREE.Object3D`, separada da árvore do editor. Uma `RuntimeInstance` liga o
 * id autoral (`persistentNodeId`) a um handle de runtime (`id`) e tem estado PRÓPRIO — transform, propriedades, tags e
 * variáveis são cópias profundas do snapshot: nenhuma mutação de runtime volta para o autoral nem para o snapshot, e
 * duas instâncias nunca compartilham referência mutável.
 *
 * Esta camada não conhece EditorContext, AuthoringModel nem CommandManager: só lê o snapshot.
 */

type Transform = RuntimeInstanceHandle['transform'];

const clone = <T>(value: T): T => (value === undefined ? value : JSON.parse(JSON.stringify(value)));

let instanceCounter = 0;
const newHandleId = (nodeId: string): string => `inst_${nodeId}_${(++instanceCounter).toString(36)}`;

let spawnCounter = 0;

/** AIS-29g — de onde veio uma instância criada DURANTE o jogo. Vive só na instância (runtime), nunca no authoring. */
export interface InstanceOrigin {
  kind: 'spawn';
  /** Id do prefab de origem (`PrefabV1.id`). */
  prefabId: string;
  /** Nó que originou o spawn (ex.: o atirador). */
  ownerId?: string;
}

export interface SpawnPlacement {
  /** Pose MUNDIAL desejada para a RAIZ do spawn (rotação em graus, XYZ). Ausente = a pose autoral do prefab sob o pai. */
  position?: readonly [number, number, number];
  rotation?: readonly [number, number, number];
  /** Pai do spawn (id de instância ou de nó). Ausente = a raiz da cena. */
  parentId?: string;
}

export interface SpawnResult {
  root: RuntimeInstance;
  instances: RuntimeInstance[];
  /** Os nós do prefab com ids NOVOS (mesma forma de `GameNode`): o host usa-os para registrar regras e Behaviors. */
  nodes: Record<string, GameNode>;
}

/** Tipos sem representação executável: dado autoral preservado, mas sem instância viva. */
const NON_EXECUTABLE_TYPES: ReadonlySet<string> = new Set(['Missing']);

export class RuntimeInstance implements RuntimeInstanceHandle {
  public readonly id: string;
  public readonly persistentNodeId: string;
  public readonly name: string;
  public readonly type: NodeType;
  public transform: Transform;
  public properties: Record<string, any>;
  public tags: string[];
  public variables: Record<string, any>;
  public visible: boolean;
  public disposed = false;
  /** AIS-29g: presente só em instâncias criadas durante o jogo. */
  public origin: InstanceOrigin | null = null;
  /** Objeto vivo do jogo (criado e destruído SÓ pela `RuntimeObjectFactory`). */
  public object: THREE.Object3D | null = null;
  public parent: RuntimeInstance | null = null;
  public readonly children: RuntimeInstance[] = [];

  constructor(snapshotNode: AuthoringSceneSnapshot['nodes'][string]) {
    const t = extractNodeTransform(snapshotNode as never);
    this.id = newHandleId(snapshotNode.id);
    this.persistentNodeId = snapshotNode.id;
    this.name = snapshotNode.name;
    this.type = snapshotNode.type;
    this.transform = { position: [...t.position], rotation: [...t.rotation], scale: [...t.scale] };
    this.properties = clone(snapshotNode.properties ?? {});
    this.tags = [...(snapshotNode.tags ?? [])];
    this.variables = clone(snapshotNode.variables ?? {});
    this.visible = snapshotNode.visible !== false;
  }
}

export class RuntimeScene implements RuntimeSceneContract {
  public readonly sceneId: string;
  public readonly name: string;
  public readonly rootNodeId: string;
  /** Raiz da árvore de objetos de runtime (nunca é filha da cena do editor). */
  public readonly rootObject = new THREE.Group();
  public readonly snapshotId: string;

  private readonly byHandle = new Map<string, RuntimeInstance>();
  private readonly byNode = new Map<string, RuntimeInstance>();
  private readonly list: RuntimeInstance[] = [];
  private _disposed = false;
  /** AIS-57: chamado para cada instância destruída DURANTE o jogo (filhos antes do pai, antes de ela ser liberada): `tree_exited`. */
  public onInstanceDestroyed: ((instance: RuntimeInstance) => void) | null = null;
  /** AIS-29g: ouvintes de destruição (física, variáveis, spawns) — vários, ao contrário do slot acima; vivem e morrem com a cena. */
  public readonly destroyListeners = new Set<(instance: RuntimeInstance) => void>();
  /** AIS-44e: incrementa a cada spawn e a cada destruição de instância de spawn (quem apresenta os spawns compara este número, nunca varre a cena). */
  public spawnRevision = 0;

  constructor(snapshot: AuthoringSceneSnapshot, private readonly factory: RuntimeObjectFactory) {
    this.sceneId = snapshot.sceneId;
    this.name = snapshot.name;
    this.rootNodeId = snapshot.rootNodeId;
    this.snapshotId = snapshot.snapshotId;
    this.rootObject.name = `runtime:${snapshot.name}`;

    // 1) uma instância por nó executável
    for (const node of Object.values(snapshot.nodes)) {
      if (NON_EXECUTABLE_TYPES.has(node.type)) continue;
      const instance = new RuntimeInstance(node);
      this.byHandle.set(instance.id, instance);
      this.byNode.set(instance.persistentNodeId, instance);
      this.list.push(instance);
    }
    // 2) hierarquia (ordem dos irmãos = childrenIds) e objetos vivos
    this.attachTree(snapshot.nodes, snapshot.rootNodeId, this.rootObject, null);
  }

  private attachTree(nodes: Readonly<Record<string, Readonly<GameNode>>>, nodeId: string, parentObject: THREE.Object3D, parent: RuntimeInstance | null): void {
    const instance = this.byNode.get(nodeId);
    const node = nodes[nodeId];
    if (!node) return;
    if (!instance) {
      // nó não executável (ex.: Missing): seus filhos sobem para o pai mais próximo
      for (const child of node.childrenIds ?? []) this.attachTree(nodes, child, parentObject, parent);
      return;
    }
    instance.object = this.factory.create(instance, parent);
    this.factory.applyTransform(instance.object, instance.transform);
    instance.object.visible = instance.visible;
    parentObject.add(instance.object);
    instance.parent = parent;
    parent?.children.push(instance);
    for (const child of node.childrenIds ?? []) this.attachTree(nodes, child, instance.object, instance);
  }

  public get disposed(): boolean {
    return this._disposed;
  }

  public getInstance(idOrNodeId: string): RuntimeInstance | undefined {
    const found = this.byHandle.get(idOrNodeId) ?? this.byNode.get(idOrNodeId);
    return found && !found.disposed ? found : undefined;
  }

  /** `true` se o nó teve instância e ela foi destruída durante o jogo. */
  public wasDestroyed(nodeId: string): boolean {
    return this.byNode.get(nodeId)?.disposed === true;
  }

  public getAllInstances(): RuntimeInstance[] {
    return this.list.filter((i) => !i.disposed);
  }

  public findInstancesByTag(tag: string): RuntimeInstance[] {
    return this.list.filter((i) => !i.disposed && i.tags.includes(tag));
  }

  public findInstancesByType(type: NodeType): RuntimeInstance[] {
    return this.list.filter((i) => !i.disposed && i.type === type);
  }

  /** Escreve o `transform` da instância no objeto vivo (executores de Action nunca falam com a fábrica). */
  public applyInstanceTransform(instance: RuntimeInstance): void {
    if (instance.object) this.factory.applyTransform(instance.object, instance.transform);
  }

  /**
   * AIS-29g — cria DURANTE o jogo uma subárvore a partir de nós de prefab (única criação dinâmica de GameNode em Play). Os nós ganham
   * ids NOVOS e únicos (`<id>__sN`; referências internas ao prefab são remapeadas) e cópias profundas do estado: dois spawns do mesmo
   * prefab nunca compartilham referência mutável, e o prefab de origem não é tocado. Devolve os nós novos para o host registrar
   * regras/Behaviors/física/variáveis. `parentId` inexistente ou destruído lança — nenhum spawn parcial.
   */
  public spawnSubtree(prefab: { id: string; rootNodeId: string; nodes: Readonly<Record<string, Readonly<GameNode>>> }, placement: SpawnPlacement = {}, origin?: { ownerId?: string }): SpawnResult {
    if (this._disposed) throw new Error('A cena de runtime já foi descartada.');
    if (!prefab.nodes[prefab.rootNodeId]) throw new Error(`O prefab "${prefab.id}" não tem o nó raiz "${prefab.rootNodeId}".`);
    const parent = (placement.parentId ? this.getInstance(placement.parentId) : this.getInstance(this.rootNodeId)) ?? null;
    if (placement.parentId && !parent) throw new Error(`O pai do spawn "${placement.parentId}" não existe (ou já foi destruído).`);
    if (parent && !parent.object) throw new Error(`O pai do spawn "${parent.persistentNodeId}" não tem objeto vivo.`);
    const parentObject = parent?.object ?? this.rootObject;

    const n = ++spawnCounter;
    const ids = new Map<string, string>();
    for (const id of Object.keys(prefab.nodes)) ids.set(id, `${id}__s${n.toString(36)}`);
    const nodes: Record<string, GameNode> = {};
    for (const [oldId, node] of Object.entries(prefab.nodes)) {
      const copy = remapNodeIds(clone(node) as GameNode, ids);
      copy.id = ids.get(oldId)!;
      copy.parentId = oldId === prefab.rootNodeId ? (parent?.persistentNodeId ?? null) : (node.parentId ? (ids.get(node.parentId) ?? null) : null);
      copy.childrenIds = (node.childrenIds ?? []).map((c) => ids.get(c)).filter((c): c is string => !!c);
      nodes[copy.id] = copy;
    }
    const rootId = ids.get(prefab.rootNodeId)!;
    const created: RuntimeInstance[] = [];
    for (const node of Object.values(nodes)) {
      if (NON_EXECUTABLE_TYPES.has(node.type)) continue;
      const instance = new RuntimeInstance(node as never);
      instance.origin = { kind: 'spawn', prefabId: prefab.id, ownerId: origin?.ownerId };
      this.byHandle.set(instance.id, instance);
      this.byNode.set(instance.persistentNodeId, instance);
      this.list.push(instance);
      created.push(instance);
    }
    const root = this.byNode.get(rootId);
    if (!root) {
      for (const i of created) this.forget(i);
      throw new Error(`O nó raiz do prefab "${prefab.id}" não é executável.`);
    }
    try {
      this.attachTree(nodes, rootId, parentObject, parent);
      this.placeInWorld(root, parentObject, placement);
    } catch (error) {
      for (const i of created) this.forget(i);
      throw error;
    }
    this.spawnRevision++;
    return { root, instances: created, nodes };
  }

  /** Pose MUNDIAL pedida para a raiz do spawn → transform local sob o pai (sem tocar a escala). */
  private placeInWorld(root: RuntimeInstance, parentObject: THREE.Object3D, placement: SpawnPlacement): void {
    if (!root.object || (!placement.position && !placement.rotation)) return;
    parentObject.updateWorldMatrix(true, false);
    const parentWorld = parentObject.matrixWorld;
    const toRad = (r: readonly number[]) => new THREE.Euler(THREE.MathUtils.degToRad(r[0]), THREE.MathUtils.degToRad(r[1]), THREE.MathUtils.degToRad(r[2]), 'XYZ');
    const local = new THREE.Matrix4().compose(new THREE.Vector3(...root.transform.position), new THREE.Quaternion().setFromEuler(toRad(root.transform.rotation)), new THREE.Vector3(...root.transform.scale));
    const p = new THREE.Vector3();
    const q = new THREE.Quaternion();
    const s = new THREE.Vector3();
    parentWorld.clone().multiply(local).decompose(p, q, s);
    if (placement.position) p.set(placement.position[0], placement.position[1], placement.position[2]);
    if (placement.rotation) q.setFromEuler(toRad(placement.rotation));
    const lp = new THREE.Vector3();
    const lq = new THREE.Quaternion();
    const ls = new THREE.Vector3();
    parentWorld.clone().invert().multiply(new THREE.Matrix4().compose(p, q, s)).decompose(lp, lq, ls);
    const e = new THREE.Euler().setFromQuaternion(lq, 'XYZ');
    root.transform.position = [lp.x, lp.y, lp.z];
    root.transform.rotation = [THREE.MathUtils.radToDeg(e.x), THREE.MathUtils.radToDeg(e.y), THREE.MathUtils.radToDeg(e.z)];
    this.applyInstanceTransform(root);
  }

  /** Desfaz o registro de uma instância criada por um spawn que falhou no meio (nenhum spawn parcial). */
  private forget(instance: RuntimeInstance): void {
    if (instance.object) this.factory.destroy(instance.object);
    instance.object = null;
    instance.disposed = true;
    if (instance.parent) instance.parent.children.splice(instance.parent.children.indexOf(instance), 1);
    this.byHandle.delete(instance.id);
    this.byNode.delete(instance.persistentNodeId);
    const i = this.list.indexOf(instance);
    if (i >= 0) this.list.splice(i, 1);
  }

  /** Destrói uma instância (e a subárvore dela) durante o jogo: objetos liberados, handles marcados `disposed`. */
  public destroyInstance(idOrNodeId: string): void {
    const instance = this.getInstance(idOrNodeId);
    if (!instance) return;
    for (const child of [...instance.children]) this.destroyInstance(child.id);
    if (instance.origin) this.spawnRevision++;
    for (const listener of [...this.destroyListeners]) listener(instance);
    this.onInstanceDestroyed?.(instance);
    if (instance.object) this.factory.destroy(instance.object);
    instance.object = null;
    instance.disposed = true;
    if (instance.parent) instance.parent.children.splice(instance.parent.children.indexOf(instance), 1);
  }

  /** Descarta a cena inteira (idempotente). Não toca em nada autoral. */
  public dispose(): void {
    if (this._disposed) return;
    this._disposed = true;
    this.destroyListeners.clear();
    for (const instance of this.list) {
      if (instance.object) this.factory.destroy(instance.object);
      instance.object = null;
      instance.disposed = true;
      instance.children.length = 0;
      instance.parent = null;
    }
    this.factory.destroy(this.rootObject);
  }
}
