import { describe, expect, it } from 'vitest';
import {
  computeOverlayScreenRect,
  hitTestOverlays,
  LAYOUT_PRESET_ORDER,
  LAYOUT_PRESETS,
  layoutFieldLabels,
  normalizeLayoutPreset,
  readOverlayControl,
  rectToOverlayOffsets,
  resolveOverlayRects,
  type LayoutPreset,
  type Rect,
} from './overlay';

const VIEW: Rect = { left: 0, top: 0, width: 800, height: 600 };

/** Fórmula do desenho antigo (9 âncoras): rect = pos − anchorOffset(anchor, w, h) a partir do ponto do pai. */
const POINT_PRESETS: { preset: LayoutPreset; fx: number; fy: number }[] = [
  { preset: 'Top-Left', fx: 0, fy: 0 },
  { preset: 'Top-Center', fx: 0.5, fy: 0 },
  { preset: 'Top-Right', fx: 1, fy: 0 },
  { preset: 'Center-Left', fx: 0, fy: 0.5 },
  { preset: 'Center', fx: 0.5, fy: 0.5 },
  { preset: 'Center-Right', fx: 1, fy: 0.5 },
  { preset: 'Bottom-Left', fx: 0, fy: 1 },
  { preset: 'Bottom-Center', fx: 0.5, fy: 1 },
  { preset: 'Bottom-Right', fx: 1, fy: 1 },
];

describe('computeOverlayScreenRect — 9 presets de ponto (paridade com o desenho antigo)', () => {
  for (const { preset, fx, fy } of POINT_PRESETS) {
    it(`${preset}: um 100×100 com pos (0,0) fica no ponto de âncora, com o MESMO ponto do controle`, () => {
      const r = computeOverlayScreenRect({ alignment: preset, posX: 0, posY: 0, width: 100, height: 100 }, VIEW);
      expect(r).toEqual({ left: fx * 800 - fx * 100, top: fy * 600 - fy * 100, width: 100, height: 100 });
    });

    it(`${preset}: offsets deslocam o ponto (pos 20,10) e o tamanho não muda`, () => {
      const r = computeOverlayScreenRect({ alignment: preset, posX: 20, posY: 10, width: 140, height: 40 }, VIEW);
      expect(r.left).toBeCloseTo(fx * 800 + 20 - fx * 140, 9);
      expect(r.top).toBeCloseTo(fy * 600 + 10 - fy * 40, 9);
      expect(r.width).toBe(140);
      expect(r.height).toBe(40);
    });
  }

  it('Center 100×100 no meio da tela de 800×600 → (350, 250)', () => {
    expect(computeOverlayScreenRect({ alignment: 'Center', posX: 0, posY: 0, width: 100, height: 100 }, VIEW)).toEqual({
      left: 350,
      top: 250,
      width: 100,
      height: 100,
    });
  });

  it('Bottom-Right 100×100 com pos (0,0) encosta no canto inferior direito', () => {
    expect(computeOverlayScreenRect({ alignment: 'Bottom-Right', posX: 0, posY: 0, width: 100, height: 100 }, VIEW)).toEqual({
      left: 700,
      top: 500,
      width: 100,
      height: 100,
    });
  });

  it('cenas atuais: alignment ausente ou desconhecido = Top-Left (left/top = posX/posY)', () => {
    for (const alignment of [undefined, null, '', 'Whatever', 42]) {
      expect(computeOverlayScreenRect({ alignment, posX: 20, posY: 80, width: 140, height: 38 }, VIEW)).toEqual({
        left: 20,
        top: 80,
        width: 140,
        height: 38,
      });
    }
  });

  it('o retângulo do pai desloca tudo (overlay filho de overlay)', () => {
    const parent: Rect = { left: 100, top: 50, width: 400, height: 200 };
    expect(computeOverlayScreenRect({ alignment: 'Center', posX: 0, posY: 0, width: 100, height: 40 }, parent)).toEqual({
      left: 250,
      top: 130,
      width: 100,
      height: 40,
    });
  });
});

describe('presets esticados (wide) e Full-Rect', () => {
  it('Top-Wide: margens esquerda/direita; Y é ponto (pos Y, altura)', () => {
    const r = computeOverlayScreenRect({ alignment: 'Top-Wide', posX: 10, posY: 5, width: 30, height: 40 }, VIEW);
    expect(r).toEqual({ left: 10, top: 5, width: 800 - 10 - 30, height: 40 });
  });

  it('Bottom-Wide: barra encostada na base', () => {
    const r = computeOverlayScreenRect({ alignment: 'Bottom-Wide', posX: 0, posY: 0, width: 0, height: 60 }, VIEW);
    expect(r).toEqual({ left: 0, top: 540, width: 800, height: 60 });
  });

  it('VCenter-Wide: esticado em X e centralizado em Y', () => {
    const r = computeOverlayScreenRect({ alignment: 'VCenter-Wide', posX: 20, posY: 0, width: 20, height: 100 }, VIEW);
    expect(r).toEqual({ left: 20, top: 250, width: 760, height: 100 });
  });

  it('Left-Wide / Right-Wide / HCenter-Wide: esticados em Y', () => {
    expect(computeOverlayScreenRect({ alignment: 'Left-Wide', posX: 0, posY: 10, width: 120, height: 20 }, VIEW)).toEqual({ left: 0, top: 10, width: 120, height: 570 });
    expect(computeOverlayScreenRect({ alignment: 'Right-Wide', posX: 0, posY: 0, width: 120, height: 0 }, VIEW)).toEqual({ left: 680, top: 0, width: 120, height: 600 });
    expect(computeOverlayScreenRect({ alignment: 'HCenter-Wide', posX: 0, posY: 0, width: 100, height: 0 }, VIEW)).toEqual({ left: 350, top: 0, width: 100, height: 600 });
  });

  it('Full-Rect: posX/posY/width/height são as margens esquerda/topo/direita/base', () => {
    expect(computeOverlayScreenRect({ alignment: 'Full-Rect', posX: 10, posY: 20, width: 30, height: 40 }, VIEW)).toEqual({
      left: 10,
      top: 20,
      width: 760,
      height: 540,
    });
    expect(computeOverlayScreenRect({ alignment: 'Full-Rect', posX: 0, posY: 0, width: 0, height: 0 }, VIEW)).toEqual(VIEW);
  });

  it('margens maiores que o pai nunca geram tamanho negativo', () => {
    const r = computeOverlayScreenRect({ alignment: 'Full-Rect', posX: 500, posY: 400, width: 500, height: 400 }, VIEW);
    expect(r.width).toBe(0);
    expect(r.height).toBe(0);
  });
});

describe('presets: tabela e ordem', () => {
  it('são 16, sem repetição, na ordem do Inspector (9 pontos + 6 esticados + Full-Rect)', () => {
    expect(LAYOUT_PRESET_ORDER.length).toBe(16);
    expect(new Set(LAYOUT_PRESET_ORDER).size).toBe(16);
    expect(Object.keys(LAYOUT_PRESETS).sort()).toEqual([...LAYOUT_PRESET_ORDER].sort());
    expect(LAYOUT_PRESET_ORDER.slice(0, 9)).toEqual(POINT_PRESETS.map((p) => p.preset));
    expect(LAYOUT_PRESET_ORDER[15]).toBe('Full-Rect');
  });

  it('normalizeLayoutPreset aceita os existentes e cai em Top-Left no resto', () => {
    for (const p of LAYOUT_PRESET_ORDER) expect(normalizeLayoutPreset(p)).toBe(p);
    expect(normalizeLayoutPreset('top-left')).toBe('Top-Left');
    expect(normalizeLayoutPreset(undefined)).toBe('Top-Left');
  });

  it('rótulos acompanham o preset', () => {
    expect(layoutFieldLabels('Top-Left')).toEqual({ posX: 'Position X (px)', posY: 'Position Y (px)', width: 'Width (px)', height: 'Height (px)' });
    expect(layoutFieldLabels('Top-Wide').posX).toBe('Margin Left (px)');
    expect(layoutFieldLabels('Top-Wide').width).toBe('Margin Right (px)');
    expect(layoutFieldLabels('Top-Wide').posY).toBe('Position Y (px)');
    expect(layoutFieldLabels('Full-Rect').height).toBe('Margin Bottom (px)');
  });
});

describe('rectToOverlayOffsets — inverso (arrastar/redimensionar no editor 2D)', () => {
  it('ida e volta para todos os presets', () => {
    const control = { posX: 13, posY: 27, width: 120, height: 44 };
    for (const preset of LAYOUT_PRESET_ORDER) {
      const rect = computeOverlayScreenRect({ ...control, alignment: preset }, VIEW);
      const back = rectToOverlayOffsets(preset, VIEW, rect);
      expect(back.posX).toBeCloseTo(control.posX, 9);
      expect(back.posY).toBeCloseTo(control.posY, 9);
      expect(back.width).toBeCloseTo(control.width, 9);
      expect(back.height).toBeCloseTo(control.height, 9);
    }
  });

  it('mover 30px à direita muda só o necessário: ponto → posX; esticado → margem esquerda cresce e a direita encolhe', () => {
    const moved = (preset: LayoutPreset, control: { posX: number; posY: number; width: number; height: number }) => {
      const r = computeOverlayScreenRect({ ...control, alignment: preset }, VIEW);
      return rectToOverlayOffsets(preset, VIEW, { ...r, left: r.left + 30 });
    };
    const point = moved('Center', { posX: 0, posY: 0, width: 100, height: 50 });
    expect(point).toMatchObject({ posX: 30, width: 100 });
    const wide = moved('Top-Wide', { posX: 10, posY: 0, width: 10, height: 40 });
    expect(wide).toMatchObject({ posX: 40, width: -20 }); // margem do fim negativa = passou da borda direita
  });

  it('redimensionar a borda esquerda em preset de ponto mantém a borda direita no lugar', () => {
    const preset: LayoutPreset = 'Center';
    const r = computeOverlayScreenRect({ alignment: preset, posX: 0, posY: 0, width: 100, height: 50 }, VIEW);
    const resized = { ...r, left: r.left - 20, width: r.width + 20 };
    const off = rectToOverlayOffsets(preset, VIEW, resized);
    const after = computeOverlayScreenRect({ alignment: preset, ...off }, VIEW);
    expect(after.left + after.width).toBeCloseTo(r.left + r.width, 9);
    expect(after.width).toBe(120);
  });
});

describe('readOverlayControl — leitura das chaves atuais', () => {
  it('padrões do registry; zero é valor válido (não vira o padrão)', () => {
    expect(readOverlayControl('Overlay2D', {})).toMatchObject({ posX: 20, posY: 20, width: 140, height: 48 });
    expect(readOverlayControl('ButtonOverlay2D', {}).height).toBe(38);
    expect(readOverlayControl('Overlay2D', { posX: 0, posY: 0 })).toMatchObject({ posX: 0, posY: 0 });
  });

  it('texto: largura 140 e altura pelo tamanho da fonte', () => {
    expect(readOverlayControl('TextOverlay2D', { fontSize: 20 })).toMatchObject({ width: 140, height: 32 });
  });

  it('valores inválidos caem nos padrões, sem exceção', () => {
    expect(readOverlayControl('Overlay2D', { posX: 'a', width: NaN, height: -5 })).toMatchObject({ posX: 20, width: 140, height: 0 });
    expect(readOverlayControl('Overlay2D', undefined).width).toBe(140);
  });
});

describe('resolveOverlayRects', () => {
  const node = (id: string, type: string, parentId: string | null, properties: Record<string, any> = {}, visible = true) => ({ id, type, parentId, properties, visible });

  it('overlays de topo usam a viewport; não-overlays são ignorados', () => {
    const rects = resolveOverlayRects(
      {
        root: node('root', 'Spatial', null),
        a: node('a', 'Overlay2D', 'root', { alignment: 'Center', posX: 0, posY: 0, width: 100, height: 100 }),
        mesh: node('mesh', 'MeshInstance', 'root'),
      },
      { width: 800, height: 600 }
    );
    expect([...rects.keys()]).toEqual(['a']);
    expect(rects.get('a')).toEqual({ left: 350, top: 250, width: 100, height: 100 });
  });

  it('overlay filho de overlay usa o retângulo calculado do pai', () => {
    const rects = resolveOverlayRects(
      {
        p: node('p', 'Overlay2D', null, { alignment: 'Top-Left', posX: 100, posY: 100, width: 200, height: 200 }),
        c: node('c', 'TextOverlay2D', 'p', { alignment: 'Center', posX: 0, posY: 0, width: 60, height: 20 }),
      },
      { width: 800, height: 600 }
    );
    expect(rects.get('c')).toEqual({ left: 170, top: 190, width: 60, height: 20 });
  });

  it('invisível (nó ou propriedade) e filhos de pai invisível ficam de fora', () => {
    const rects = resolveOverlayRects(
      {
        hidden: node('hidden', 'Overlay2D', null, {}, false),
        hiddenProp: node('hiddenProp', 'Overlay2D', null, { visible: false }),
        p: node('p', 'Overlay2D', null, { visible: false }),
        c: node('c', 'Overlay2D', 'p'),
        ok: node('ok', 'Overlay2D', null),
      },
      { width: 800, height: 600 }
    );
    expect([...rects.keys()]).toEqual(['ok']);
  });

  it('ciclo de pais não trava', () => {
    const rects = resolveOverlayRects(
      { a: node('a', 'Overlay2D', 'b'), b: node('b', 'Overlay2D', 'a') },
      { width: 800, height: 600 }
    );
    expect(rects.size).toBe(0);
  });
});

describe('hitTestOverlays', () => {
  const rects = new Map<string, Rect>([
    ['back', { left: 0, top: 0, width: 200, height: 200 }],
    ['front', { left: 100, top: 100, width: 200, height: 200 }],
  ]);

  it('devolve o mais ao topo (último da ordem); nulo fora de todos', () => {
    expect(hitTestOverlays(rects, 150, 150)).toBe('front');
    expect(hitTestOverlays(rects, 50, 50)).toBe('back');
    expect(hitTestOverlays(rects, 500, 500)).toBeNull();
  });

  it('o filtro permite ignorar tipos (ex.: só botões)', () => {
    expect(hitTestOverlays(rects, 150, 150, (id) => id === 'back')).toBe('back');
  });

  it('as bordas contam como dentro', () => {
    expect(hitTestOverlays(rects, 300, 300)).toBe('front');
  });
});
