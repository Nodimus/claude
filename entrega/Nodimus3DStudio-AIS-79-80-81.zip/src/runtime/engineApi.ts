import type { OverlapHit, OverlapOptions, PhysicsBridge, PhysicsEvent, PhysicsEventName, RaycastHit, RaycastOptions } from '../core/physics/PhysicsBridge';
import type { SoundHost } from './audioRuntime';
import type { ParticleHost } from './particleRuntime';
import type { AnimationControl } from './animationRuntime';
import type { SpriteHost } from './spriteHost';
import type { TweenControl, TweenProperty, PropertyTweenRequest } from './propertyTweens';
import type { Capability } from '../core/capabilities';
import type { VariableManager, VariableScope, VariableValue } from '../core/variableManager';
import type { RawInputReader } from './input/inputTriggers';
import type { RuntimeInstance } from './RuntimeScene';
import type { SubscriptionOwner } from './subscriptions';
import type { NodeOps } from './nodeOps';
import type { ScriptHost } from './scripting/ScriptHost';
import type { WeaponService } from './weapons/weaponService';
import type { ActorRegistry } from './ai/actorRegistry';
import type { RouteResult } from '../core/waypoints/resolveRoute';
import type { AttachmentControl, AttachmentRecord } from './attachmentRuntime';
import type { ViewBasis } from './cameraRig/types';
import type { LocomotionState } from './cameraRig/movement';
import type { GameCameraPose } from './controllers/gameCamera';
import type { DamageOutcome, DamageParams, ExplosionOutcome, ExplosionParams, FireOutcome, FireParams, WeaponHookTrigger } from './weapons/types';
import { tNow } from '../core/i18n';

/**
 * AIS-78c (decisão 32) — `EngineApi` v1: a superfície ESTÁVEL do runtime para scripts (`res://scripts/`, AIS-79) e a base de que os contextos
 * dos executores de `src/logic/` derivam (`engineScope.ts`). Cobre só a INTERSEÇÃO dos dois contextos (Action e Behavior): consulta de nó por
 * handle, variáveis, sinais (emitir e assinar), input por ação, física via `PhysicsBridge`, log, `sceneTime` e transform.
 *
 * Regras do contrato:
 *  - **Handles por ID estável** (`persistentNodeId`): `NodeHandle`/`NodeSnapshot` são dados SERIALIZÁVEIS (cópias; nunca a instância viva).
 *  - **Nada interno vivo**: sem DOM, sem `THREE.*`, sem objetos Rapier, sem stores React, sem `TauriBridge` nem filesystem. A única porta para a
 *    física é a `PhysicsBridge` (decisão 9/AIS-45), e só em Play.
 *  - **Cada operação declara** `sync`/`async` e se é segura em Play e em publish (`ENGINE_OPERATIONS`): é o que o AIS-79 usa para marshalar a chamada
 *    pela fronteira do Worker.
 *  - **Assinaturas devolvem disposer** (AIS-48b) e pertencem a um dono (`SubscriptionOwner`): quando o dono morre, nada fica vivo.
 *  - **Versão e feature negotiation** (`negotiateEngineApi`): remover uma feature ou mudar contrato = subir `major` e falhar de forma EXPLÍCITA.
 *
 * Este módulo é puro (sem React, sem Three): o runtime injeta o mundo por `EngineHost`.
 */

export const ENGINE_API_VERSION = { major: 1, minor: 5 } as const;

/**
 * Features. 1.0: nodes, variables, signals, input, physics, log, time, transform. 1.1 (decisão 32, estilo PlayCanvas: UM objeto "app" com sistemas
 * endereçados por entidade): audio, particles, animation, sprites, tweens, scene e consultas espaciais (raycast/overlapSphere). 1.2 (a mesma
 * regra, vista contra o Godot: singletons de jogo e métodos do Node3D): weapons, ai (alvo atual), attachments, camera (ViewBasis somente
 * leitura), materials (emissão), nodes.behaviorProperties, transform.lookAt/worldPosition. 1.3 (Godot: _process/_input e Camera3D.make_current são
 * API pública do nó; texto, UI e movimento contínuo são do motor): frame (onUpdate/onInput), camera.publish, locomotion, text, ui, motion. 1.4 (AIS-78d; o estado de uma IA mora no nó, o
 * conhecimento compartilhado é do motor): ai (vivo/morto/alvo), hooks, routes, diagnostics e random. 1.5 (AIS-79): scripts.run — a Action run_script
 * pelo sandbox (Web Worker); só em Play, host-only (o script NÃO chama script).
 */
export const ENGINE_FEATURES = ['nodes', 'variables', 'signals', 'input', 'physics', 'log', 'time', 'transform', 'audio', 'particles', 'animation', 'sprites', 'tweens', 'scene', 'weapons', 'ai', 'attachments', 'camera', 'materials', 'frame', 'locomotion', 'text', 'ui', 'motion', 'hooks', 'routes', 'diagnostics', 'random', 'scripts'] as const;
export type EngineFeature = (typeof ENGINE_FEATURES)[number];

export type Disposer = () => void;

/** Referência estável a um nó (o ID autoral). Serializável. */
export interface NodeHandle {
  readonly id: string;
}

export type Vec3Tuple = [number, number, number];

export interface TransformData {
  position: Vec3Tuple;
  rotation: Vec3Tuple;
  scale: Vec3Tuple;
}

/** Cópia serializável do estado de um nó vivo (nunca a instância). */
export interface NodeSnapshot {
  id: string;
  name: string;
  type: string;
  tags: string[];
  visible: boolean;
  parentId: string | null;
  transform: TransformData;
}

export interface EngineOperation {
  /** `<feature>.<operação>`: estável; nunca renomear. */
  id: string;
  feature: EngineFeature;
  /** Primeira versão da API que a oferece (`major.minor`). */
  since: string;
  mode: 'sync' | 'async';
  safeIn: { play: boolean; publish: boolean };
  /** Entrada e saída são dados serializáveis (cruzam a fronteira do Worker do AIS-79 sem objetos vivos). */
  marshalable: boolean;
  description: string;
  requires?: Capability[];
}

const op = (id: string, feature: EngineFeature, description: string, extra: Partial<Pick<EngineOperation, 'marshalable' | 'requires' | 'safeIn'>> = {}): EngineOperation => ({
  id,
  feature,
  since: '1.0',
  mode: 'sync',
  safeIn: extra.safeIn ?? { play: true, publish: true },
  marshalable: extra.marshalable ?? true,
  description,
  ...(extra.requires ? { requires: extra.requires } : {}),
});

/** Operações acrescentadas na 1.1 além dos sistemas novos (a 1.0 já tinha nós, transform, variáveis, sinais, input, physics.bridge/onEvent, log e time). */
const SINCE_1_1 = new Set(['physics.raycast', 'physics.overlapSphere', 'transform.setWorldPosition', 'time.after']);
/** Acrescentadas na 1.2 (sistemas de jogo e operações de nó). */
const SINCE_1_2 = new Set(['nodes.behaviorProperties', 'transform.lookAt', 'transform.worldPosition']);
const SINCE_1_2_FEATURES = ['weapons', 'ai', 'attachments', 'materials'];
/** Acrescentadas na 1.3 (camera.view é da 1.2; camera.publish é da 1.3). */
const SINCE_1_3 = new Set(['camera.publish']);
const SINCE_1_3_FEATURES = ['frame', 'locomotion', 'text', 'ui', 'motion'];
/** Acrescentadas na 1.4 (ai.currentTarget é da 1.2; as demais operações de ai são da 1.4). */
const SINCE_1_4_FEATURES = ['hooks', 'routes', 'diagnostics', 'random'];
/** Acrescentada na 1.5 (AIS-79). */
const SINCE_1_5_FEATURES = ['scripts'];
const SINCE_1_4 = new Set(['ai.registerActor', 'ai.markDead', 'ai.isDead', 'ai.setTarget']);

/** Catálogo das operações da v1 (a fonte do que a negociação e o AIS-79 enxergam). */
export const ENGINE_OPERATIONS: readonly EngineOperation[] = ([
  op('nodes.resolve', 'nodes', 'Resolve uma referência (ID ou nome) em um NodeHandle estável.'),
  op('nodes.get', 'nodes', 'Cópia serializável do estado de um nó vivo.'),
  op('nodes.getProperty', 'nodes', 'Valor (cópia) de uma propriedade viva do nó; só dados serializáveis.'),
  op('transform.get', 'transform', 'Pose do nó (posição, rotação em graus, escala).'),
  op('transform.set', 'transform', 'Altera a pose de runtime do nó (validada; nunca o authoring).'),
  op('variables.get', 'variables', 'Lê uma variável Global ou Local.'),
  op('variables.set', 'variables', 'Escreve uma variável Global ou Local já declarada (o runtime nunca cria variável).'),
  op('signals.emit', 'signals', 'Emite um sinal na cena (dispara on_signal e as conexões).'),
  op('signals.connect', 'signals', 'Assina um sinal; devolve o disposer.'),
  op('input.isPressed', 'input', 'Ação lógica pressionada.'),
  op('input.justPressed', 'input', 'Ação lógica pressionada neste quadro.'),
  op('input.justReleased', 'input', 'Ação lógica solta neste quadro.'),
  op('input.axis', 'input', 'Eixo -1..1 a partir de um par de ações.'),
  op('physics.raycast', 'physics', 'Primeiro corpo atingido por um raio (consulta espacial pela PhysicsBridge; dados planos).', { requires: ['requiresPhysics'] }),
  op('physics.overlapSphere', 'physics', 'Corpos que tocam uma esfera, ordenados por distância.', { requires: ['requiresPhysics'] }),
  op('physics.onEvent', 'physics', 'Assina eventos físicos (Enter/Exit; sem Stay); devolve o disposer.', { requires: ['requiresPhysics'] }),
  op('physics.bridge', 'physics', 'A PhysicsBridge da sessão (única porta para o mundo físico). Objeto vivo: só em processo, NÃO cruza a fronteira do Worker.', { marshalable: false, requires: ['requiresPhysics'] }),
  op('transform.setWorldPosition', 'transform', 'Posiciona o nó numa pose MUNDIAL (converte pela hierarquia; só estado de runtime).'),
  op('audio.play', 'audio', 'Toca um som a partir de um emissor (nó).', { requires: ['requiresDOM'] }),
  op('audio.stop', 'audio', 'Para os sons de um emissor.', { requires: ['requiresDOM'] }),
  op('audio.setProperties', 'audio', 'Ajusta volume/pitch das vozes de um emissor.', { requires: ['requiresDOM'] }),
  op('particles.burst', 'particles', 'Rajada de partículas num ParticleSystem.'),
  op('animation.play', 'animation', 'Toca uma animação do objeto animado (crossfade em segundos).'),
  op('animation.pause', 'animation', 'Pausa/retoma a animação do objeto animado.'),
  op('animation.stop', 'animation', 'Para a animação do objeto animado.'),
  op('animation.setSpeed', 'animation', 'Velocidade da animação do objeto animado.'),
  op('sprites.play', 'sprites', 'Toca uma animação de sprite de um Billboard (como AnimatedSprite3D.play).'),
  op('sprites.show', 'sprites', 'Mostra um quadro do atlas de um Billboard (com pausa opcional).'),
  op('sprites.clipNames', 'sprites', 'Nomes das animações do Sprite Project de um Billboard registrado.'),
  op('tweens.start', 'tweens', 'Interpola uma propriedade do nó (posição, rotação, escala, cor, opacidade); fim por sinal.'),
  op('tweens.stop', 'tweens', 'Para os tweens de um nó.'),
  op('scene.destroy', 'scene', 'Destrói o nó (e a subárvore) na cena viva.'),
  op('scene.restart', 'scene', 'Pede o reinício da cena (processado depois da cadeia/quadro atual).'),
  op('scene.quit', 'scene', 'Pede o fim do jogo.'),
  op('scene.change', 'scene', 'Pede a troca de cena por caminho res://.'),
  op('nodes.behaviorProperties', 'nodes', 'Propriedades de trabalho (cópia, somente leitura) do Behavior de um tipo ligado ao nó; undefined se o nó não o tem em execução.'),
  op('transform.lookAt', 'transform', 'Vira o nó para um ponto MUNDIAL (como Node3D.look_at); só estado de runtime.'),
  op('transform.worldPosition', 'transform', 'Posição MUNDIAL do nó (como Node3D.global_position).'),
  op('weapons.fire', 'weapons', 'Disparo pelo núcleo único de armas (físico ou hitscan).'),
  op('weapons.damage', 'weapons', 'Dano pelo contrato único (variável de vida do alvo).'),
  op('weapons.explode', 'weapons', 'Explosão: overlap + dano + impulso, uma vez por alvo.'),
  op('weapons.hook', 'weapons', 'Dispara o gancho on_weapon_* das regras do Behavior de arma.'),
  op('weapons.available', 'weapons', 'O núcleo de armas existe nesta sessão (cena viva)?'),
  op('weapons.isProjectile', 'weapons', 'O nó é um projétil vivo do núcleo de armas?'),
  op('ai.currentTarget', 'ai', 'Alvo atual (ID) do AI State Machine do nó, ou null.'),
  op('attachments.attach', 'attachments', 'Prende o nó a um osso em jogo (só estado de sessão; o apresentador faz o reparent).'),
  op('attachments.detach', 'attachments', 'Solta o nó do osso em jogo.'),
  op('camera.view', 'camera', 'Orientação (yaw/pitch, graus) da câmera de jogo ativa; somente leitura, publicada no quadro anterior.'),
  op('materials.setEmissive', 'materials', 'Cor e intensidade emissivas dos materiais do nó (só no objeto vivo do Play).'),
  op('frame.onUpdate', 'frame', 'Callback por quadro (depois da física); devolve o disposer. Só com dono (Behavior ou sessão): Actions não assinam.', { marshalable: false }),
  op('frame.onInput', 'frame', 'Callback por quadro com o leitor de entrada (antes dos Behaviors); devolve o disposer.', { marshalable: false }),
  op('camera.publish', 'camera', 'O nó dono publica (ou retira, com null) a câmera de jogo; some no Stop, restart, troca de cena e remoção do nó.'),
  op('locomotion.set', 'locomotion', 'O nó dono publica (ou retira) o estado de locomoção (idle/walk/run/jump/fall); estado de sessão.'),
  op('text.interpolate', 'text', 'Substitui $variavel$ e $no.atributo$ pelos valores vivos.'),
  op('ui.markDirty', 'ui', 'Avisa que propriedades de UI mudaram: o HUD é redesenhado, a cena 3D não.'),
  op('motion.spin', 'motion', 'Rotação contínua do nó em graus/s por eixo (0 para).'),
  op('motion.velocity', 'motion', 'Velocidade contínua (m/s) de um nó sem corpo dinâmico (vetor zero para).'),
  op('ai.registerActor', 'ai', 'O nó dono entra como ator VIVO (attach/Restart Behavior); só num Behavior.'),
  op('ai.markDead', 'ai', 'O nó dono marca a si mesmo como morto (a IA dele para); só num Behavior.'),
  op('ai.isDead', 'ai', 'O ator está morto? (nó sem registro = não morto)'),
  op('ai.setTarget', 'ai', 'O nó dono publica (ou retira, com null) o alvo atual da IA; só num Behavior.'),
  op('hooks.fire', 'hooks', 'Dispara as regras do PRÓPRIO Behavior (nó dono + Behavior da invocação) cujo Trigger é o informado; só num Behavior.'),
  op('routes.resolve', 'routes', 'Rota de patrulha de um contêiner de Waypoints (resolveRoute do AIS-72b), em dados planos.'),
  op('diagnostics.warnOnce', 'diagnostics', 'Diagnóstico UMA vez por chave e sessão, pelo DiagnosticService.'),
  op('random.next', 'random', 'Número em [0, 1) do sorteio injetado da sessão (determinístico nos testes).'),
  op('scripts.run', 'scripts', 'Roda um script .js de res://scripts/ no sandbox (Web Worker) uma vez, com o nó dono da invocação; o efeito chega no quadro seguinte. Só em Play (a publicação ainda não empacota scripts).', { marshalable: false, safeIn: { play: true, publish: false } }),
  op('time.after', 'time', 'Agenda uma chamada daqui a N segundos de JOGO (pausa e Stop respeitados). O callback é local ao processo: não cruza o Worker.', { marshalable: false }),
  op('log.write', 'log', 'Escreve no log de execução (warn/error vão ao Output).'),
  op('time.sceneTime', 'time', 'Segundos de jogo desde o início da cena.'),
] as EngineOperation[]).map((o) => (SINCE_1_5_FEATURES.includes(o.feature) ? { ...o, since: '1.5' } : SINCE_1_4.has(o.id) || SINCE_1_4_FEATURES.includes(o.feature) ? { ...o, since: '1.4' } : SINCE_1_3.has(o.id) || SINCE_1_3_FEATURES.includes(o.feature) ? { ...o, since: '1.3' } : SINCE_1_2.has(o.id) || o.id === 'camera.view' || SINCE_1_2_FEATURES.includes(o.feature) ? { ...o, since: '1.2' } : SINCE_1_1.has(o.id) || ['audio', 'particles', 'animation', 'sprites', 'tweens', 'scene'].includes(o.feature) ? { ...o, since: '1.1' } : o));

// ── Negociação de versão/features ───────────────────────────────────────────────────────────────────────────────────────────────────────

export interface NegotiationRequest {
  /** Versão maior que o consumidor foi escrito para. */
  major: number;
  /** Menor versão mínima exigida (padrão 0). */
  minMinor?: number;
  /** Features sem as quais o consumidor não funciona. */
  features?: readonly string[];
}

export type NegotiationResult =
  | { ok: true; version: { major: number; minor: number }; features: readonly EngineFeature[] }
  | { ok: false; code: 'engine.major_mismatch' | 'engine.minor_too_old' | 'engine.missing_feature'; message: string; missing?: string[] };

/** Pura: o consumidor declara o que precisa e recebe aceite ou um erro EXPLÍCITO (nunca degradação silenciosa). */
export function negotiateEngineApi(request: NegotiationRequest): NegotiationResult {
  const { major, minor } = ENGINE_API_VERSION;
  if (request.major !== major) {
    return { ok: false, code: 'engine.major_mismatch', message: tNow('engineApiMsgCore.theEngineapiIsVersionThe', { major, minor, major2: request.major }) };
  }
  if ((request.minMinor ?? 0) > minor) {
    return { ok: false, code: 'engine.minor_too_old', message: tNow('engineApiMsgCore.theConsumerRequiresEngineapiThis', { major, minMinor: request.minMinor, major2: major, minor }) };
  }
  const missing = (request.features ?? []).filter((f) => !(ENGINE_FEATURES as readonly string[]).includes(f));
  if (missing.length > 0) return { ok: false, code: 'engine.missing_feature', message: tNow('engineApiMsgCore.featuresNotOfferedByEngineapi', { major, minor, missing: missing.join(', ') }), missing };
  return { ok: true, version: { major, minor }, features: ENGINE_FEATURES };
}

// ── A API ─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

export type LogLevel = 'info' | 'warn' | 'error';

/** Falha de serviço: dado serializável com código estável (nunca exceção para erro esperado). */
export interface ServiceFailure {
  ok: false;
  code: string;
  message: string;
}
export type ServiceResult = { ok: true } | ServiceFailure;
export type CountResult = { ok: true; count: number } | ServiceFailure;

export interface PlaySpriteOptions {
  /** Animação do Sprite Project; vazio = a padrão do recurso. */
  animation?: string;
  restart?: boolean;
  speedScale?: number;
  fromEnd?: boolean;
}
/** `deferred`: o sprite do nó ainda não carregou; o pedido roda quando ele for registrado. */
export type SpritePlayResult = { ok: true; deferred?: boolean } | ServiceFailure;
export type SpriteShowResult = { ok: true; frame: number; deferred?: boolean } | ServiceFailure;

/** Pedido de tween como DADO (o fim do tween é um SINAL, não um callback). */
export interface TweenRequestData {
  property: TweenProperty;
  to: { x?: number; y?: number; z?: number } | string | number;
  relative?: boolean;
  duration: number;
  delay?: number;
  easing?: string;
  loop?: PropertyTweenRequest['loop'];
  repeat?: number;
  /** Sinal global emitido ao terminar. */
  onCompleteSignal?: string;
}

export type RaycastResult = { ok: true; hit: RaycastHit | null } | ServiceFailure;
export type OverlapResult = { ok: true; hits: OverlapHit[] } | ServiceFailure;
export type SignalListener = (name: string, args: readonly unknown[]) => void;

export interface EngineApi {
  readonly version: { readonly major: number; readonly minor: number };
  hasFeature(feature: string): boolean;
  negotiate(request: NegotiationRequest): NegotiationResult;
  operations(): readonly EngineOperation[];

  readonly nodes: {
    resolve(ref: string): NodeHandle | undefined;
    get(id: string): NodeSnapshot | undefined;
    getProperty(id: string, key: string): unknown;
    /** 1.2: properties de trabalho (cópia, somente leitura) do Behavior behaviorType ligado ao nó; undefined se o nó não o tem em execução. */
    behaviorProperties(id: string, behaviorType: string): Readonly<Record<string, unknown>> | undefined;
  };
  readonly transform: {
    get(id: string): TransformData | undefined;
    set(id: string, patch: Partial<TransformData>): boolean;
    /** Posição MUNDIAL (converte pela hierarquia; só estado de runtime). */
    setWorldPosition(id: string, position: { x: number; y: number; z: number }): boolean;
    /** 1.2: vira o nó para um ponto MUNDIAL (como Node3D.look_at). false = nó inexistente, sem objeto vivo ou ponto inválido. */
    lookAt(id: string, point: { x: number; y: number; z: number }): boolean;
    /** 1.2: posição MUNDIAL (como Node3D.global_position); undefined = nó inexistente ou sem objeto vivo. */
    worldPosition(id: string): { x: number; y: number; z: number } | undefined;
  };
  readonly variables: {
    get(scope: VariableScope, name: string, nodeId?: string): VariableValue | undefined;
    set(scope: VariableScope, name: string, value: VariableValue, nodeId?: string): boolean;
  };
  readonly signals: {
    emit(name: string, args?: readonly unknown[], source?: string): void;
    connect(name: string, listener: SignalListener, options?: { source?: string }): Disposer;
  };
  readonly input: {
    isPressed(action: string): boolean;
    justPressed(action: string): boolean;
    justReleased(action: string): boolean;
    axis(negative: string, positive: string): number;
  };
  /** A única porta para a física (`PhysicsBridge`); `null` = a cena não tem corpos ou o motor ainda carrega. */
  physics(): PhysicsBridge | null;
  /** Consulta espacial (AIS-45b) em dados planos: o mais próximo atingido pelo raio. Entrada inválida/sem física vira falha com código, nunca `null` silencioso. */
  raycast(origin: { x: number; y: number; z: number }, direction: { x: number; y: number; z: number }, options?: RaycastOptions): RaycastResult;
  overlapSphere(center: { x: number; y: number; z: number }, radius: number, options?: OverlapOptions): OverlapResult;
  /** Agenda `fn` daqui a `seconds` segundos de JOGO (pausa e Stop respeitados). */
  after(seconds: number, fn: () => void): void;

  // ── 1.1: sistemas endereçados por nó (o "app" do PlayCanvas) ─────────────────────────────────────────────────────────────────────────
  readonly audio: {
    play(nodeId: string, spec: { path: string; volume?: number; pitch?: number; spatial?: boolean }): ServiceResult;
    stop(nodeId: string, path?: string): CountResult;
    setProperties(nodeId: string, props: { volume?: number; pitch?: number }): CountResult;
  };
  readonly particles: { burst(nodeId: string, count: number): ServiceResult };
  readonly animation: {
    play(nodeId: string, clip: string, options?: { crossfade?: number; loop?: boolean; speed?: number }): ServiceResult;
    pause(nodeId: string, paused: boolean): ServiceResult;
    stop(nodeId: string): ServiceResult;
    setSpeed(nodeId: string, speed: number): ServiceResult;
  };
  readonly sprites: {
    play(nodeId: string, options?: PlaySpriteOptions): SpritePlayResult;
    show(nodeId: string, frame: number, pause?: boolean): SpriteShowResult;
    clipNames(nodeId: string): string[];
  };
  readonly tweens: {
    start(nodeId: string, request: TweenRequestData): ServiceResult;
    stop(nodeId: string, property?: TweenProperty): CountResult;
  };
  /** 1.2: núcleo de armas da sessão (o MESMO para Behavior, Actions e IA). Sem núcleo: falha weapon.unavailable, nunca silêncio. */
  readonly weapons: {
    fire(params: FireParams): FireOutcome | ServiceFailure;
    damage(params: DamageParams): DamageOutcome | ServiceFailure;
    explode(params: ExplosionParams): ExplosionOutcome | ServiceFailure;
    /** @deprecated 1.4: use `hooks.fire` (um só caminho de gancho). Mantido como alias até a 2.0. */
    hook(ownerId: string, behaviorId: string, trigger: WeaponHookTrigger, detail: string): void;
    isProjectile(nodeId: string): boolean;
    /** O núcleo de armas existe nesta sessão? (cena viva) */
    available(): boolean;
  };
  /** 1.4: conhecimento compartilhado das IAs. As escritas são só do nó DONO da invocação (como `camera.publish`); sem dono → falha `ai.no_owner`. */
  readonly ai: {
    registerActor(): ServiceResult;
    markDead(): ServiceResult;
    isDead(nodeId: string): boolean;
    setTarget(targetId: string | null): ServiceResult;
    currentTarget(nodeId: string): string | null;
  };
  /** 1.4: gancho unificado — dispara as regras do PRÓPRIO Behavior da invocação (substitui `weapons.hook` e o antigo `AiService.hook`). */
  readonly hooks: { fire(trigger: string, detail: string, params?: Record<string, string>): ServiceResult };
  readonly routes: { resolve(containerId: string): RouteResult };
  readonly diagnostics: { warnOnce(key: string, severity: 'error' | 'warning', code: string, message: string, nodeId?: string): void };
  readonly random: { next(): number };
  /** 1.5: sandbox de scripts (Web Worker). `run` roda `run(engine, args)` de um `.js` de res://scripts/ com o nó dono da invocação; não espera o resultado. */
  readonly scripts: { run(path: string, args?: unknown): ServiceResult };
  readonly attachments: {
    attach(nodeId: string, record: AttachmentRecord): ServiceResult;
    detach(nodeId: string): ServiceResult;
  };
  /** 1.2: leitura da câmera de jogo ativa (como Viewport.get_camera_3d()); a escrita é do Behavior de câmera (decisão 28). */
  readonly camera: {
    view(): ViewBasis | null;
    /** 1.3: o nó DONO da invocação publica (ou retira, com `null`) a câmera de jogo (como Camera3D.make_current). Só num Behavior. */
    publish(pose: Omit<GameCameraPose, 'nodeId'> | null): ServiceResult;
  };
  /** 1.3: ciclo de vida por quadro (o _process/_input do nó). Devolve o disposer; só com dono (Behavior ou sessão). */
  readonly frame: {
    onUpdate(cb: (dt: number) => void): Disposer;
    onInput(cb: (input: RawInputReader) => void): Disposer;
  };
  readonly locomotion: { set(state: LocomotionState | null): ServiceResult };
  readonly text: { interpolate(text: string): string };
  readonly ui: { markDirty(): void };
  readonly motion: {
    spin(nodeId: string, axis: 'x' | 'y' | 'z', degreesPerSecond: number): ServiceResult;
    velocity(nodeId: string, velocity: { x: number; y: number; z: number }, space: 'world' | 'local'): ServiceResult;
  };
  readonly materials: { setEmissive(nodeId: string, color: string, intensity: number): CountResult };
  readonly scene: {
    destroy(nodeId: string): boolean;
    restart(): void;
    quit(): void;
    change(scenePath: string): void;
  };
  /**
   * `onPhysicsEvent(name, cb) → unsubscribe` (`'*'` = todos): a mesma porta de `RuntimeSession.onPhysicsEvent` (AIS-48). É o que o adaptador mínimo
   * original de `createEngineApi(session)` já expunha; nunca configuração de Inspector. Cancelada com o dono (Stop, Restart, troca de cena).
   */
  onPhysicsEvent(name: PhysicsEventName | '*', cb: (event: PhysicsEvent) => void): Disposer;
  log(level: LogLevel, message: string, options?: { code?: string; toOutput?: boolean }): void;
  /** Segundos de jogo desde o início da cena. */
  time(): number;
}

/**
 * O mundo que a API enxerga. Quem a monta (`RuntimeSession`, `LogicRunner`, `BehaviorLifecycleHost`) injeta funções; nada daqui é exportado
 * pela `EngineApi`. Cada consumidor tem o seu `commitTransform` (o runner também sincroniza o corpo físico; o Behavior aplica no objeto).
 */
export interface EngineHost {
  instanceById(ref: string): RuntimeInstance | undefined;
  instanceByName(name: string): RuntimeInstance | undefined;
  variables(): VariableManager | null;
  input(): RawInputReader;
  physics(): PhysicsBridge | null;
  sceneTime(): number;
  emitSignal(name: string, args?: readonly unknown[], source?: string): void;
  connectSignal(name: string, listener: SignalListener, owner: SubscriptionOwner | null, source?: string): Disposer;
  onPhysicsEvent(name: PhysicsEventName | '*', cb: (event: PhysicsEvent) => void, owner: SubscriptionOwner | null): Disposer;
  log(level: LogLevel, message: string, node: RuntimeInstance | undefined, options?: { code?: string; toOutput?: boolean; behaviorId?: string; logicId?: string }): void;
  commitTransform(instance: RuntimeInstance): void;
  // Serviços de sessão (todos opcionais: ausente = o sistema não existe neste contexto e a API devolve `*.unavailable`).
  audio?(): SoundHost | null;
  particles?(): ParticleHost | null;
  animation?(): AnimationControl | null;
  sprites?(): SpriteHost | null;
  tweens?(): TweenControl | null;
  after?(seconds: number, fn: () => void): void;
  destroy?(instance: RuntimeInstance): void;
  setWorldPosition?(instance: RuntimeInstance, position: { x: number; y: number; z: number }): void;
  sceneRequest?(request: { kind: 'restart' | 'quit' } | { kind: 'change'; path: string }): void;
  // 1.2
  weapons?(): WeaponService | null;
  actors?(): ActorRegistry | null;
  // 1.4
  fireHook?(ownerId: string, behaviorId: string, trigger: string, detail: string, params?: Record<string, string>): void;
  reportOnce?(key: string, severity: 'error' | 'warning', code: string, message: string, nodeId?: string): void;
  resolveRoute?(containerId: string): RouteResult;
  random?(): number;
  // 1.5
  scripts?(): ScriptHost | null;
  attachments?(): AttachmentControl | null;
  view?(): ViewBasis | null;
  behaviorProperties?(nodeId: string, behaviorType: string): Readonly<Record<string, unknown>> | undefined;
  // 1.3
  onFrame?(cb: (dt: number) => void, owner: SubscriptionOwner | null): Disposer;
  onInput?(cb: (input: RawInputReader) => void, owner: SubscriptionOwner | null): Disposer;
  setGameCamera?(nodeId: string, pose: Omit<GameCameraPose, 'nodeId'> | null): void;
  setLocomotion?(nodeId: string, state: LocomotionState | null): void;
  interpolate?(text: string, selfNodeId: string | null): string;
  markUiDirty?(): void;
  setContinuousRotation?(instance: RuntimeInstance, axis: 'x' | 'y' | 'z', degreesPerSecond: number): void;
  setContinuousVelocity?(instance: RuntimeInstance, velocity: { x: number; y: number; z: number }, space: 'world' | 'local'): void;
  /** Operações que precisam do objeto vivo (Three); implementadas em nodeOps.ts, nunca neste módulo. */
  nodeOps?(): NodeOps | null;
}

const isTuple3 = (v: unknown): v is Vec3Tuple => Array.isArray(v) && v.length === 3 && v.every((n) => typeof n === 'number' && Number.isFinite(n));

/** Cópia por JSON (só dados serializáveis); `undefined` se não houver representação (função, ciclo…). */
export function cloneData(value: unknown): unknown {
  if (value === undefined) return undefined;
  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return undefined;
  }
}

const copyTransform = (t: { position: readonly number[]; rotation: readonly number[]; scale: readonly number[] }): TransformData => ({
  position: [t.position[0], t.position[1], t.position[2]],
  rotation: [t.rotation[0], t.rotation[1], t.rotation[2]],
  scale: [t.scale[0], t.scale[1], t.scale[2]],
});

/**
 * Compatibilidade (AIS-48): `createEngineApi(session)` — o adaptador mínimo que o AIS-78c amplia. Agora devolve a `EngineApi` completa da sessão
 * (as assinaturas pertencem à cena, como antes).
 */
export function createEngineApi(session: { engineApi(owner?: SubscriptionOwner): EngineApi }, owner?: SubscriptionOwner): EngineApi {
  return session.engineApi(owner);
}

/** Monta a `EngineApi` sobre o `EngineHost`. `owner` é o dono das assinaturas feitas por este objeto (`null` = da sessão). */
const failure = (code: string, message: string): ServiceFailure => ({ ok: false, code, message });
const fromError = (error: string | null, code: string): ServiceResult => (error ? failure(code, error) : { ok: true });

export function buildEngineApi(host: EngineHost, owner: SubscriptionOwner | null = null, selfNodeId: string | null = null, behaviorId: string | null = null): EngineApi {
  const noNode = (id: string): ServiceFailure => failure('node.not_found', tNow('engineApiMsgCore.theNodeDoesNotExist', { id }));
  const unavailable = (system: string): ServiceFailure => failure(`${system}.unavailable`, tNow('engineApiMsgCore.theSystemIsNotAvailable', { system }));
  const live = (id: string): RuntimeInstance | undefined => {
    const i = host.instanceById(id);
    return i && !i.disposed ? i : undefined;
  };
  return {
    version: ENGINE_API_VERSION,
    hasFeature: (feature) => (ENGINE_FEATURES as readonly string[]).includes(feature),
    negotiate: negotiateEngineApi,
    operations: () => ENGINE_OPERATIONS,
    nodes: {
      resolve: (ref) => {
        const found = ref ? (host.instanceById(ref) ?? host.instanceByName(ref)) : undefined;
        return found && !found.disposed ? { id: found.persistentNodeId } : undefined;
      },
      get: (id) => {
        const i = live(id);
        return i
          ? { id: i.persistentNodeId, name: i.name, type: String(i.type), tags: [...i.tags], visible: i.visible, parentId: i.parent?.persistentNodeId ?? null, transform: copyTransform(i.transform) }
          : undefined;
      },
      getProperty: (id, key) => cloneData(live(id)?.properties?.[key]),
      behaviorProperties: (id, behaviorType) => {
        if (!live(id)) return undefined;
        const props = host.behaviorProperties?.(id, behaviorType);
        return props ? (cloneData(props) as Record<string, unknown> | undefined) : undefined;
      },
    },
    transform: {
      get: (id) => {
        const i = live(id);
        return i ? copyTransform(i.transform) : undefined;
      },
      set: (id, patch) => {
        const i = live(id);
        if (!i) return false;
        for (const key of ['position', 'rotation', 'scale'] as const) if (patch[key] !== undefined && !isTuple3(patch[key])) return false; // validado: nada parcial
        if (patch.position) i.transform.position = [...patch.position];
        if (patch.rotation) i.transform.rotation = [...patch.rotation];
        if (patch.scale) i.transform.scale = [...patch.scale];
        host.commitTransform(i);
        return true;
      },
      setWorldPosition: (id, position) => {
        const i = live(id);
        if (!i || !host.setWorldPosition || ![position?.x, position?.y, position?.z].every((n) => typeof n === 'number' && Number.isFinite(n))) return false;
        host.setWorldPosition(i, { x: position.x, y: position.y, z: position.z });
        return true;
      },
      lookAt: (id, point) => {
        const i = live(id);
        const ops = host.nodeOps?.();
        if (!i || !ops || ![point?.x, point?.y, point?.z].every((n) => typeof n === 'number' && Number.isFinite(n))) return false;
        if (!ops.lookAt(i, point)) return false;
        host.commitTransform(i); // grava no objeto vivo e, num corpo dinâmico, empurra a pose para a física
        return true;
      },
      worldPosition: (id) => {
        const i = live(id);
        return (i && host.nodeOps?.()?.worldPosition(i)) || undefined;
      },
    },
    variables: {
      get: (scope, name, nodeId) => host.variables()?.getVariable(scope, name, nodeId),
      set: (scope, name, value, nodeId) => host.variables()?.setVariable(scope, name, value, nodeId) ?? false,
    },
    signals: {
      emit: (name, args, source) => host.emitSignal(name, args, source),
      connect: (name, listener, options) => host.connectSignal(name, listener, owner, options?.source),
    },
    input: {
      isPressed: (a) => host.input().isActionPressed(a),
      justPressed: (a) => host.input().isActionJustPressed(a),
      justReleased: (a) => host.input().isActionJustReleased(a),
      axis: (n, p) => host.input().getAxis(n, p),
    },
    physics: () => host.physics(),
    onPhysicsEvent: (name, cb) => host.onPhysicsEvent(name, cb, owner),
    raycast: (origin, direction, options) => {
      const bridge = host.physics();
      if (!bridge) return failure('physics.no_world', tNow('engineApiMsgCore.theSceneHasNoPhysics'));
      try {
        return { ok: true, hit: bridge.raycast(origin, direction, options) };
      } catch (error) {
        return failure((error as { code?: string }).code ?? 'physics.query_failed', error instanceof Error ? error.message : String(error));
      }
    },
    overlapSphere: (center, radius, options) => {
      const bridge = host.physics();
      if (!bridge) return failure('physics.no_world', tNow('engineApiMsgCore.theSceneHasNoPhysics'));
      try {
        return { ok: true, hits: bridge.overlapSphere(center, radius, options) };
      } catch (error) {
        return failure((error as { code?: string }).code ?? 'physics.query_failed', error instanceof Error ? error.message : String(error));
      }
    },
    after: (seconds, fn) => host.after?.(seconds, fn),
    audio: {
      play: (nodeId, spec) => {
        if (!live(nodeId)) return noNode(nodeId);
        const audio = host.audio?.();
        if (!audio) return unavailable('audio');
        return fromError(audio.play({ emitterId: nodeId, path: spec.path, volume: spec.volume ?? 1, pitch: spec.pitch ?? 1, spatial: spec.spatial !== false }), 'audio.play_failed');
      },
      stop: (nodeId, path) => {
        if (!live(nodeId)) return noNode(nodeId);
        const audio = host.audio?.();
        return audio ? { ok: true, count: audio.stop(nodeId, path || undefined) } : unavailable('audio');
      },
      setProperties: (nodeId, props) => {
        if (!live(nodeId)) return noNode(nodeId);
        const audio = host.audio?.();
        return audio ? { ok: true, count: audio.setProperties(nodeId, props) } : unavailable('audio');
      },
    },
    particles: {
      burst: (nodeId, count) => {
        const i = live(nodeId);
        if (!i) return noNode(nodeId);
        if (i.type !== 'ParticleSystem') return failure('particles.wrong_type', tNow('engineApiMsgCore.isNotAParticlesystem', { name: i.name, type: i.type }));
        const particles = host.particles?.();
        return particles ? fromError(particles.burst(nodeId, count), 'particles.burst_failed') : unavailable('particles');
      },
    },
    animation: {
      play: (nodeId, clip, options) => {
        if (!live(nodeId)) return noNode(nodeId);
        const a = host.animation?.();
        return a ? fromError(a.play(nodeId, clip, options), 'animation.play_failed') : unavailable('animation');
      },
      pause: (nodeId, paused) => {
        if (!live(nodeId)) return noNode(nodeId);
        const a = host.animation?.();
        return a ? fromError(a.pause(nodeId, paused), 'animation.pause_failed') : unavailable('animation');
      },
      stop: (nodeId) => {
        if (!live(nodeId)) return noNode(nodeId);
        const a = host.animation?.();
        return a ? fromError(a.stop(nodeId), 'animation.stop_failed') : unavailable('animation');
      },
      setSpeed: (nodeId, speed) => {
        if (!live(nodeId)) return noNode(nodeId);
        const a = host.animation?.();
        return a ? fromError(a.setSpeed(nodeId, speed), 'animation.speed_failed') : unavailable('animation');
      },
    },
    sprites: {
      play: (nodeId, options = {}) => {
        const i = live(nodeId);
        if (!i) return noNode(nodeId);
        if (i.type !== 'Billboard' || !i.properties.spriteProject) return failure('sprite.invalid_target', tNow('engineApiMsgCore.mustBeABillboardWith', { name: i.name }));
        const sp = host.sprites?.();
        if (!sp) return failure('sprite.unavailable', tNow('engineApiMsgCore.theSpriteSystemIsNot'));
        const speed = typeof options.speedScale === 'number' && Number.isFinite(options.speedScale) ? options.speedScale : 1;
        // as propriedades VIVAS (estado de sessão, nunca o authoring) acompanham a troca para o apresentador da viewport não desfazê-la
        const apply = () => {
          const result = sp.playClip(nodeId, { ...options, speedScale: speed });
          if (result === 'unknown_animation') {
            host.log('error', tNow('engineApiMsgCore.doesNotHaveTheAnimation', { name: i.name, animation: options.animation, value: sp.clipNames(nodeId).join(', ') || 'nenhuma' }), i, { code: 'sprite.unknown_animation' });
            return result;
          }
          if (result === 'ok') {
            i.properties.animation = (options.animation ?? '').trim();
            i.properties.speedScale = speed;
            i.properties.autoplay = true;
          }
          return result;
        };
        if (!sp.has(nodeId)) {
          sp.defer(nodeId, () => void apply());
          return { ok: true, deferred: true };
        }
        const result = apply();
        return result === 'unknown_animation' ? failure('sprite.unknown_animation', tNow('engineApiMsgCore.doesNotHaveTheAnimation2', { name: i.name, animation: options.animation })) : { ok: true };
      },
      show: (nodeId, frame, pause = true) => {
        const i = live(nodeId);
        if (!i) return noNode(nodeId);
        if (i.type !== 'Billboard' || !i.properties.spriteProject) return failure('sprite.invalid_target', tNow('engineApiMsgCore.mustBeABillboardWith', { name: i.name }));
        const sp = host.sprites?.();
        if (!sp) return failure('sprite.unavailable', tNow('engineApiMsgCore.theSpriteSystemIsNot'));
        const apply = () => {
          const shown = sp.showFrame(nodeId, frame, pause);
          if (shown.ok && shown.frame !== Math.round(frame)) host.log('warn', tNow('engineApiMsgCore.frameIsOutsideTheAtlas', { frame, name: i.name, frame2: shown.frame }), i, { code: 'sprite.frame_clamped' });
          return shown;
        };
        if (!sp.has(nodeId)) {
          sp.defer(nodeId, () => void apply());
          return { ok: true, frame: Math.max(0, Math.round(frame)), deferred: true };
        }
        const shown = apply();
        return shown.ok ? { ok: true, frame: shown.frame } : failure('sprite.unavailable', tNow('engineApiMsgCore.thisNodeSSpriteIs'));
      },
      clipNames: (nodeId) => host.sprites?.()?.clipNames(nodeId) ?? [],
    },
    tweens: {
      start: (nodeId, request) => {
        const i = live(nodeId);
        if (!i) return noNode(nodeId);
        const tweens = host.tweens?.();
        if (!tweens) return unavailable('tweens');
        const { onCompleteSignal, ...rest } = request;
        const signal = onCompleteSignal?.trim();
        return fromError(tweens.start(i, { ...rest, onComplete: signal ? () => host.emitSignal(signal) : undefined }), 'tween.failed');
      },
      stop: (nodeId, property) => {
        const i = live(nodeId);
        if (!i) return noNode(nodeId);
        const tweens = host.tweens?.();
        return tweens ? { ok: true, count: tweens.stop(i, property) } : unavailable('tweens');
      },
    },
    weapons: {
      fire: (params) => host.weapons?.()?.fire(params) ?? failure('weapon.unavailable', tNow('engineApiMsgCore.theWeaponCoreIsNot')),
      damage: (params) => host.weapons?.()?.damage(params) ?? failure('weapon.unavailable', tNow('engineApiMsgCore.theWeaponCoreIsNot')),
      explode: (params) => host.weapons?.()?.explode(params) ?? failure('weapon.unavailable', tNow('engineApiMsgCore.theWeaponCoreIsNot')),
      hook: (ownerId, hookBehaviorId, trigger, detail) => host.fireHook?.(ownerId, hookBehaviorId, trigger, detail),
      isProjectile: (nodeId) => host.weapons?.()?.isProjectile(nodeId) ?? false,
      available: () => !!host.weapons?.(),
    },
    ai: {
      registerActor: () => {
        if (!selfNodeId) return failure('ai.no_owner', tNow('engineApiMsgCore.onlyABehaviorRegistersThe'));
        const actors = host.actors?.();
        if (!actors) return unavailable('ai');
        actors.revive(selfNodeId);
        return { ok: true };
      },
      markDead: () => {
        if (!selfNodeId) return failure('ai.no_owner', tNow('engineApiMsgCore.onlyABehaviorMarksIts'));
        const actors = host.actors?.();
        if (!actors) return unavailable('ai');
        actors.markDead(selfNodeId);
        return { ok: true };
      },
      isDead: (nodeId) => host.actors?.()?.isDead(nodeId) ?? false,
      setTarget: (targetId) => {
        if (!selfNodeId) return failure('ai.no_owner', tNow('engineApiMsgCore.onlyABehaviorPublishesThe2'));
        const actors = host.actors?.();
        if (!actors) return unavailable('ai');
        actors.setTarget(selfNodeId, targetId);
        return { ok: true };
      },
      currentTarget: (nodeId) => host.actors?.()?.currentTarget(nodeId) ?? null,
    },
    hooks: {
      fire: (trigger, detail, params) => {
        if (!selfNodeId || !behaviorId) return failure('hooks.no_owner', tNow('engineApiMsgCore.onlyABehaviorFiresHooks'));
        if (!host.fireHook) return unavailable('hooks');
        host.fireHook(selfNodeId, behaviorId, trigger, detail, params);
        return { ok: true };
      },
    },
    routes: {
      resolve: (containerId) => host.resolveRoute?.(containerId) ?? ({ ok: false, code: 'route.container_missing', message: tNow('sharedMsgCore.routesAreNotAvailableIn') } as RouteResult),
    },
    diagnostics: { warnOnce: (key, severity, code, message, nodeId) => host.reportOnce?.(key, severity, code, message, nodeId) },
    random: { next: () => host.random?.() ?? Math.random() },
    scripts: {
      run: (path, args) => {
        const scripts = host.scripts?.();
        return scripts ? scripts.run(selfNodeId, path, args) : unavailable('scripts');
      },
    },
    attachments: {
      attach: (nodeId, record) => {
        if (!live(nodeId)) return noNode(nodeId);
        const control = host.attachments?.();
        if (!control) return failure('attachment.unavailable', tNow('engineApiMsgCore.boneAttachmentIsNotAvailable'));
        control.attach(nodeId, { holder: record.holder, bone: record.bone });
        return { ok: true };
      },
      detach: (nodeId) => {
        if (!live(nodeId)) return noNode(nodeId);
        const control = host.attachments?.();
        if (!control) return failure('attachment.unavailable', tNow('engineApiMsgCore.boneAttachmentIsNotAvailable'));
        control.detach(nodeId);
        return { ok: true };
      },
    },
    camera: {
      view: () => {
        const v = host.view?.();
        return v ? { nodeId: v.nodeId, yaw: v.yaw, pitch: v.pitch } : null;
      },
      publish: (pose) => {
        if (!selfNodeId) return failure('camera.no_owner', tNow('engineApiMsgCore.onlyABehaviorPublishesThe'));
        if (!host.setGameCamera) return unavailable('camera');
        host.setGameCamera(selfNodeId, pose);
        return { ok: true };
      },
    },
    frame: {
      onUpdate: (cb) => {
        if (!host.onFrame) throw new Error('Actions não assinam o quadro: use um Behavior (o dono das inscrições).');
        return host.onFrame(cb, owner);
      },
      onInput: (cb) => {
        if (!host.onInput) throw new Error('Actions não assinam a entrada por quadro: use um Behavior (o dono das inscrições).');
        return host.onInput(cb, owner);
      },
    },
    locomotion: {
      set: (state) => {
        if (!selfNodeId) return failure('locomotion.no_owner', tNow('engineApiMsgCore.onlyABehaviorPublishesThe3'));
        if (!host.setLocomotion) return unavailable('locomotion');
        host.setLocomotion(selfNodeId, state);
        return { ok: true };
      },
    },
    text: { interpolate: (text) => host.interpolate?.(text, selfNodeId) ?? text },
    ui: { markDirty: () => host.markUiDirty?.() },
    motion: {
      spin: (nodeId, axis, degreesPerSecond) => {
        const i = live(nodeId);
        if (!i) return noNode(nodeId);
        if (!host.setContinuousRotation) return unavailable('motion');
        host.setContinuousRotation(i, axis, degreesPerSecond);
        return { ok: true };
      },
      velocity: (nodeId, velocity, space) => {
        const i = live(nodeId);
        if (!i) return noNode(nodeId);
        if (!host.setContinuousVelocity) return unavailable('motion');
        host.setContinuousVelocity(i, velocity, space);
        return { ok: true };
      },
    },
    materials: {
      setEmissive: (nodeId, color, intensity) => {
        const i = live(nodeId);
        if (!i) return noNode(nodeId);
        const ops = host.nodeOps?.();
        return ops ? { ok: true, count: ops.setEmissive(i, color, intensity) } : unavailable('materials');
      },
    },
    scene: {
      destroy: (nodeId) => {
        const i = live(nodeId);
        if (!i || !host.destroy) return false;
        host.destroy(i);
        return true;
      },
      restart: () => host.sceneRequest?.({ kind: 'restart' }),
      quit: () => host.sceneRequest?.({ kind: 'quit' }),
      change: (scenePath) => host.sceneRequest?.({ kind: 'change', path: scenePath }),
    },
    log: (level, message, options) => host.log(level, message, undefined, options),
    time: () => host.sceneTime(),
  };
}
