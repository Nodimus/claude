/**
 * AIS-59c — ponte entre a Action `emit_particles` (lógica, sem Three/DOM) e o apresentador de partículas da viewport (dono do estado
 * de simulação, motor único `src/core/particles/`). Mesmo desenho do `SoundHost`: a Action fala com um `ParticleHost` do contexto; quem
 * implementa decide como entregar.
 *
 * Na `RuntimeSession` o host é uma FILA: a Action só pede ("emita N partículas no nó X") e o apresentador consome a fila a cada quadro e
 * chama `emitBurst`. Assim a lógica não conhece o apresentador e o Publish (AIS-85) poderá consumir a mesma fila com o seu renderer.
 */

/** O que a Action enxerga. Devolve uma mensagem de erro (explícita), ou `null` quando o pedido foi aceito. */
export interface ParticleHost {
  burst(nodeId: string, count: number): string | null;
}

export interface ParticleBurst {
  nodeId: string;
  count: number;
}

/** Teto de uma rajada por pedido (o motor ainda limita pelo `maxParticles` do sistema). */
export const MAX_BURST_COUNT = 10_000;

/** Fila de rajadas pedidas e ainda não entregues ao apresentador. Pedidos do mesmo nó no mesmo quadro se somam. */
export class ParticleBurstQueue {
  private readonly pending = new Map<string, number>();

  request(nodeId: string, count: number): void {
    const n = Math.min(MAX_BURST_COUNT, Math.max(0, Math.floor(count)));
    if (n === 0) return;
    this.pending.set(nodeId, Math.min(MAX_BURST_COUNT, (this.pending.get(nodeId) ?? 0) + n));
  }

  /** Entrega e esvazia a fila. */
  take(): ParticleBurst[] {
    if (this.pending.size === 0) return [];
    const out = [...this.pending].map(([nodeId, count]) => ({ nodeId, count }));
    this.pending.clear();
    return out;
  }

  clear(): void {
    this.pending.clear();
  }

  get size(): number {
    return this.pending.size;
  }
}
