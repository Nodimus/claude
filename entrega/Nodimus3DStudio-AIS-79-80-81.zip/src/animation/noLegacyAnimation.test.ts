import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

/**
 * AIS-60b-C (decisão 30) — guarda: o produto não tem nó `AnimationPlayer`, Timeline, edição de clipes (`ClipEdit`) nem a Action
 * `switch_pose`. Se algum nome voltar ao código, este teste acusa. Nomes legados só podem aparecer em dados de cena antigos (que abrem
 * como Missing Node) e nos testes que o provam.
 */

const SRC = path.resolve(import.meta.dirname, '..');
const FORBIDDEN = /AnimationPlayer|switch_pose|switchPose|ClipEdit|clipEditor|clipEditing|clipConsumers|viewportTimeline|ViewportTimeline|TimelinePanel|autoLocomotion/;
const SELF = 'animation/noLegacyAnimation.test.ts';
/** Prova do Missing Node: o dado legado entra como texto de cena antiga. */
const ALLOWED_LEGACY_DATA = new Set(['core/serialization/sceneSerializer.test.ts']);

function sourceFiles(dir: string): string[] {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) return sourceFiles(full);
    return /\.(ts|tsx)$/.test(e.name) ? [full] : [];
  });
}

describe('sem animação legada (AIS-60b-C)', () => {
  it('nenhum arquivo de src/ cita AnimationPlayer, Timeline de clipes, ClipEdit ou switch_pose', () => {
    const offenders: string[] = [];
    for (const file of sourceFiles(SRC)) {
      const rel = path.relative(SRC, file).replace(/\\/g, '/');
      if (rel === SELF || ALLOWED_LEGACY_DATA.has(rel)) continue;
      fs.readFileSync(file, 'utf8')
        .split(/\r?\n/)
        .forEach((line, i) => {
          if (FORBIDDEN.test(line)) offenders.push(`${rel}:${i + 1}: ${line.trim()}`);
        });
    }
    expect(offenders).toEqual([]);
  });

  it('AnimationPlayer não é NodeType e switch_pose não é Action do registry', async () => {
    const { NODE_DEFINITIONS } = await import('../nodes/registry');
    expect(Object.keys(NODE_DEFINITIONS)).not.toContain('AnimationPlayer');
    const { LogicRegistry } = await import('../logic/registry');
    expect(LogicRegistry.getAction('switch_pose')).toBeUndefined();
    expect(LogicRegistry.getAction('stop_animation')).toBeDefined();
  });
});
