/**
 * @file tweener.ts
 * @module animation
 *
 * AIS-59 — motor de interpolação leve (Tween). PURO: sem Three, sem React, sem relógio global; o tempo vem de `update(dt)`
 * (pausar = não chamar `update`). Interpola números e vetores numéricos (posição, rotação, escala, cor RGB(A), opacidade) por
 * um par `get/set` — quem sabe aplicar o valor ao nó é o adaptador do runtime (`src/runtime/propertyTweens.ts`).
 *
 * Recursos: curvas (`easing.ts`), `delay`, `loop`/`pingpong` (com `repeat`), callbacks `onStart`/`onUpdate`/`onComplete` e
 * ENCADEAMENTO (`tween.then(spec)` / `tweener.sequence([...])`): o passo seguinte começa quando o anterior termina, já com o
 * tempo que sobrou do quadro (um `dt` grande não perde tempo entre passos). A origem (`from`) é lida do `get()` no momento em que o
 * passo COMEÇA (depois do delay), então um passo encadeado parte de onde o anterior parou.
 *
 * Estado de runtime descartável: `clear()`/descarte do `Tweener` na saída do Play; nada aqui escreve em dado autoral.
 */

import { ease, type EasingName } from './easing';

export type TweenValue = number | readonly number[];
export type LoopMode = 'once' | 'loop' | 'pingpong';
export type TweenState = 'pending' | 'running' | 'done' | 'killed';

export interface TweenSpec<V extends TweenValue = TweenValue> {
  /** Valor atual (origem quando `from` não vem; lido ao COMEÇAR o passo). */
  get(): V;
  set(value: V): void;
  from?: V;
  to: V;
  /** Segundos (≥ 0). 0 = aplica `to` no primeiro `update`. */
  duration: number;
  /** Espera antes de começar (segundos). */
  delay?: number;
  easing?: EasingName | string;
  /** `once` (padrão), `loop` (volta ao início) ou `pingpong` (vai e volta). */
  loop?: LoopMode;
  /** Repetições ADICIONAIS além da primeira passada. Em `loop`/`pingpong` o padrão é infinito; em `once` é 0. */
  repeat?: number;
  /** Dono do tween (nó, sessão…): `kill(owner)` mata todos os dele. */
  owner?: unknown;
  /** Rótulo para depuração/monitores. */
  label?: string;
  onStart?(): void;
  onUpdate?(value: V, progress: number): void;
  onComplete?(): void;
}

const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;

/** Interpola número ou vetor (mesmo tamanho; o excesso de um lado é ignorado). */
export function lerpValue(from: TweenValue, to: TweenValue, t: number): TweenValue {
  if (typeof from === 'number' && typeof to === 'number') return lerp(from, to, t);
  const a = Array.isArray(from) ? (from as readonly number[]) : [from as number];
  const b = Array.isArray(to) ? (to as readonly number[]) : [to as number];
  const n = Math.min(a.length, b.length);
  return Array.from({ length: n }, (_, i) => lerp(a[i], b[i], t));
}

export class Tween {
  readonly id: number;
  state: TweenState = 'pending';
  private readonly spec: TweenSpec;
  private readonly children: Tween[] = [];
  private elapsed = 0;
  private started = false;
  private origin: TweenValue = 0;

  constructor(id: number, spec: TweenSpec, private readonly manager: Tweener) {
    this.id = id;
    this.spec = spec;
  }

  get owner(): unknown {
    return this.spec.owner;
  }

  get label(): string | undefined {
    return this.spec.label;
  }

  /** Progresso da passada atual em [0,1] (`done` = 1). */
  get progress(): number {
    return this.state === 'done' ? 1 : this.progressAt(this.elapsed - this.delay);
  }

  /** Encadeia o próximo passo: começa quando este terminar. Devolve o NOVO passo (para encadear mais). */
  then(spec: TweenSpec): Tween {
    const next = this.manager.create(spec);
    this.children.push(next);
    return next;
  }

  kill(): void {
    this.manager.kill(this);
  }

  // ── interno (chamado pelo Tweener) ───────────────────────────────────────────

  private get delay(): number {
    return Math.max(0, this.spec.delay ?? 0);
  }

  private get duration(): number {
    return Number.isFinite(this.spec.duration) ? Math.max(0, this.spec.duration) : 0;
  }

  private get loops(): number {
    const mode = this.spec.loop ?? 'once';
    if (mode === 'once') return 1 + Math.max(0, this.spec.repeat ?? 0);
    return this.spec.repeat === undefined ? Infinity : 1 + Math.max(0, this.spec.repeat);
  }

  private progressAt(active: number): number {
    const d = this.duration;
    if (d === 0) return 1;
    const iteration = Math.min(Math.floor(active / d), this.loops - 1);
    const within = iteration === this.loops - 1 && active >= this.loops * d ? 1 : (active - iteration * d) / d;
    const p = Math.min(1, Math.max(0, within));
    return this.spec.loop === 'pingpong' && iteration % 2 === 1 ? 1 - p : p;
  }

  /**
   * Avança `dt` segundos. Devolve o tempo que SOBROU (> 0 só ao terminar), para o passo encadeado seguir no mesmo quadro.
   * `undefined` = continua em andamento.
   */
  advance(dt: number): number | undefined {
    if (this.state === 'killed' || this.state === 'done') return undefined;
    this.state = 'running';
    this.elapsed += dt;
    const active = this.elapsed - this.delay;
    if (active < 0) return undefined;

    if (!this.started) {
      this.started = true;
      this.origin = this.spec.from ?? this.spec.get();
      this.manager.safe(() => this.spec.onStart?.(), 'onStart', this);
      if (this.state !== 'running') return undefined; // onStart pode ter matado o tween
    }

    const total = this.duration * this.loops;
    const finished = Number.isFinite(total) && active >= total;
    const p = this.progressAt(finished ? total : active);
    const value = lerpValue(this.origin, this.spec.to, ease(this.spec.easing ?? 'Linear', p));
    this.manager.safe(() => {
      (this.spec as TweenSpec<TweenValue>).set(value);
      (this.spec as TweenSpec<TweenValue>).onUpdate?.(value, p);
    }, 'set/onUpdate', this);
    if (this.state !== 'running') return undefined;

    if (!finished) return undefined;
    this.state = 'done';
    this.manager.safe(() => this.spec.onComplete?.(), 'onComplete', this);
    return Math.max(0, active - total);
  }

  takeChildren(): Tween[] {
    return this.children.splice(0);
  }

  markKilled(): void {
    this.state = 'killed';
    for (const child of this.children.splice(0)) child.markKilled();
  }
}

export interface TweenerOptions {
  /** Erro num callback/`set`: a sessão leva ao DiagnosticService; o tween é morto, os outros seguem. */
  onError?(error: unknown, where: string, tween: Tween): void;
}

export class Tweener {
  private active: Tween[] = [];
  private nextId = 1;
  private paused = false;

  constructor(private readonly options: TweenerOptions = {}) {}

  /** Cria o tween SEM iniciá-lo (usado por `then`); o público é `add`. */
  create(spec: TweenSpec): Tween {
    return new Tween(this.nextId++, spec, this);
  }

  /** Inicia um tween (começa a contar no próximo `update`). */
  add<V extends TweenValue>(spec: TweenSpec<V>): Tween {
    const tween = this.create(spec as TweenSpec);
    this.active.push(tween);
    return tween;
  }

  /** Passos em sequência: cada um começa quando o anterior termina. Devolve o ÚLTIMO (para anexar callbacks/`then`). */
  sequence(specs: ReadonlyArray<TweenSpec>): Tween | undefined {
    let last: Tween | undefined;
    for (const spec of specs) last = last ? last.then(spec) : this.add(spec);
    return last;
  }

  get count(): number {
    return this.active.length;
  }

  has(owner: unknown): boolean {
    return this.active.some((t) => t.owner === owner);
  }

  setPaused(paused: boolean): void {
    this.paused = paused;
  }

  /** Mata um tween (e o que estava encadeado depois dele) ou todos os de um dono. Devolve quantos matou. */
  kill(target: Tween | unknown): number {
    const victims = target instanceof Tween ? [target] : this.active.filter((t) => t.owner === target);
    for (const v of victims) v.markKilled();
    this.active = this.active.filter((t) => t.state !== 'killed');
    return victims.length;
  }

  clear(): void {
    for (const t of this.active) t.markKilled();
    this.active = [];
  }

  /** Avança todos os tweens `dt` segundos; os que terminam disparam `onComplete` e iniciam o passo encadeado. */
  update(dt: number): void {
    if (this.paused || !(dt > 0)) return;
    const queue: Array<{ tween: Tween; dt: number }> = this.active.map((tween) => ({ tween, dt }));
    while (queue.length > 0) {
      const { tween, dt: step } = queue.shift()!;
      if (tween.state === 'killed') continue;
      const leftover = tween.advance(step);
      if (leftover === undefined || tween.state !== 'done') continue;
      for (const child of tween.takeChildren()) {
        this.active.push(child);
        queue.push({ tween: child, dt: leftover });
      }
    }
    this.active = this.active.filter((t) => t.state !== 'done' && t.state !== 'killed');
  }

  /** @internal executa um callback isolando o erro: o tween falho morre, o resto segue. */
  safe(fn: () => void, where: string, tween: Tween): void {
    try {
      fn();
    } catch (error) {
      tween.markKilled();
      this.options.onError?.(error, where, tween);
    }
  }
}
