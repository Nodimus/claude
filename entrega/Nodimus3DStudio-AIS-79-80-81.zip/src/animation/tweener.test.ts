import { describe, expect, it, vi } from 'vitest';
import { EASING_NAMES, EASINGS, ease, normalizeEasing } from './easing';
import { Tweener, lerpValue, type TweenSpec } from './tweener';

/** Alvo de teste: um valor mutável com get/set. */
type Cell<V> = { ref: { value: V }; get(): V; set(v: V): void };
function cell(initial: number): Cell<number>;
function cell(initial: number[]): Cell<number[]>;
function cell(initial: number | number[]): Cell<number | number[]> {
  const ref = { value: initial };
  return { ref, get: () => ref.value, set: (v) => { ref.value = v; } };
}

const spec = <V extends number | number[]>(c: Cell<V>, to: V, over: Partial<TweenSpec<V>> = {}): TweenSpec<V> => ({
  get: c.get, set: c.set, to, duration: 1, ...over,
});

describe('curvas de transição (AIS-59)', () => {
  it.each(EASING_NAMES)('%s vale 0 em t=0 e 1 em t=1', (name) => {
    expect(EASINGS[name](0)).toBeCloseTo(0, 10);
    expect(EASINGS[name](1)).toBeCloseTo(1, 10);
  });

  it('Linear é a identidade; Quad: In começa devagar, Out termina devagar, InOut é simétrica', () => {
    expect(ease('Linear', 0.3)).toBeCloseTo(0.3, 10);
    expect(ease('EaseInQuad', 0.5)).toBeCloseTo(0.25, 10);
    expect(ease('EaseOutQuad', 0.5)).toBeCloseTo(0.75, 10);
    expect(ease('EaseInOutQuad', 0.5)).toBeCloseTo(0.5, 10);
    expect(ease('EaseInOutQuad', 0.25) + ease('EaseInOutQuad', 0.75)).toBeCloseTo(1, 10);
  });

  it('Bounce quica (nunca passa de 1, volta a descer) e Elastic ultrapassa o alvo e oscila', () => {
    const bounce = Array.from({ length: 101 }, (_, i) => EASINGS.Bounce(i / 100));
    expect(Math.max(...bounce)).toBeLessThanOrEqual(1 + 1e-9);
    expect(bounce.some((v, i) => i > 0 && v < bounce[i - 1])).toBe(true); // quicou
    const elastic = Array.from({ length: 101 }, (_, i) => EASINGS.Elastic(i / 100));
    expect(Math.max(...elastic)).toBeGreaterThan(1); // ultrapassa
  });

  it('nomes legados dos keyframes e caixa diferente são aceitos; desconhecido cai em Linear; t fora de [0,1] é preso', () => {
    expect(normalizeEasing('ease-in')).toBe('EaseInQuad');
    expect(normalizeEasing('ease-out')).toBe('EaseOutQuad');
    expect(normalizeEasing('ease-in-out')).toBe('EaseInOutQuad');
    expect(normalizeEasing('bounce')).toBe('Bounce');
    expect(normalizeEasing('xyz')).toBe('Linear');
    expect(normalizeEasing(undefined)).toBe('Linear');
    expect(ease('Linear', 2)).toBe(1);
    expect(ease('Linear', -1)).toBe(0);
    expect(ease('Linear', Number.NaN)).toBe(0);
  });
});

describe('Tweener: interpolação (AIS-59)', () => {
  it('número, vetor (posição/rotação/escala) e cor RGB chegam ao valor final', () => {
    const t = new Tweener();
    const n = cell(0);
    const v = cell([0, 0, 0]);
    const c = cell([1, 0, 0]); // vermelho → azul
    t.add(spec(n, 10, { duration: 2 }));
    t.add(spec(v, [4, 8, -2], { duration: 2 }));
    t.add(spec(c, [0, 0, 1], { duration: 2 }));
    t.update(1);
    expect(n.ref.value).toBeCloseTo(5, 10);
    expect(v.ref.value).toEqual([2, 4, -1]);
    expect(c.ref.value).toEqual([0.5, 0, 0.5]);
    t.update(1);
    expect([n.ref.value, v.ref.value, c.ref.value]).toEqual([10, [4, 8, -2], [0, 0, 1]]);
    expect(t.count).toBe(0);
  });

  it('a curva é aplicada ao progresso (EaseInQuad no meio = 25%)', () => {
    const t = new Tweener();
    const n = cell(0);
    t.add(spec(n, 100, { duration: 2, easing: 'EaseInQuad' }));
    t.update(1);
    expect(n.ref.value).toBeCloseTo(25, 10);
  });

  it('from explícito vale; sem from, a origem é lida ao COMEÇAR (depois do delay)', () => {
    const t = new Tweener();
    const a = cell(5);
    const b = cell(0);
    t.add(spec(a, 15, { from: 10, duration: 1 }));
    t.add(spec(b, 10, { delay: 1, duration: 1 }));
    b.ref.value = 20; // muda antes de o delay acabar: a origem é a de quando o tween começa
    t.update(0.5);
    expect(a.ref.value).toBeCloseTo(12.5, 10);
    expect(b.ref.value).toBe(20); // ainda esperando
    t.update(1.5);
    expect(b.ref.value).toBe(10);
  });

  it('duração 0 aplica o valor final no primeiro update; dt gigante não passa do alvo', () => {
    const t = new Tweener();
    const a = cell(0);
    const b = cell(0);
    t.add(spec(a, 7, { duration: 0 }));
    t.add(spec(b, 9, { duration: 1 }));
    t.update(1000);
    expect([a.ref.value, b.ref.value]).toEqual([7, 9]);
  });

  it('lerpValue: tamanhos diferentes usam o menor', () => {
    expect(lerpValue([0, 0, 0], [2, 4], 0.5)).toEqual([1, 2]);
    expect(lerpValue(0, 10, 0.1)).toBeCloseTo(1, 10);
  });
});

describe('Tweener: callbacks, loop, encadeamento e controle (AIS-59)', () => {
  it('onStart uma vez ao começar (depois do delay), onUpdate a cada passo e onComplete uma única vez', () => {
    const t = new Tweener();
    const n = cell(0);
    const onStart = vi.fn();
    const onUpdate = vi.fn();
    const onComplete = vi.fn();
    t.add(spec(n, 1, { delay: 0.5, duration: 1, onStart, onUpdate, onComplete }));
    t.update(0.25);
    expect(onStart).not.toHaveBeenCalled();
    t.update(0.5);
    expect(onStart).toHaveBeenCalledTimes(1);
    t.update(1);
    expect(onComplete).toHaveBeenCalledTimes(1);
    t.update(1);
    expect(onComplete).toHaveBeenCalledTimes(1);
    expect(onUpdate).toHaveBeenLastCalledWith(1, 1);
  });

  it('encadeamento: then() começa quando o anterior termina, parte de onde ele parou e aproveita a sobra do quadro', () => {
    const t = new Tweener();
    const n = cell(0);
    const order: string[] = [];
    t.add(spec(n, 10, { duration: 1, onComplete: () => order.push('a') }))
      .then(spec(n, 30, { duration: 2, onComplete: () => order.push('b') }))
      .then(spec(n, 0, { duration: 1, onComplete: () => order.push('c') }));
    t.update(1.5); // termina A e já anda 0,5 s em B
    expect(order).toEqual(['a']);
    expect(n.ref.value).toBeCloseTo(15, 10); // 10 + (30−10) × 0,25
    t.update(1.5); // B termina exatamente aqui (0,5 + 1,5 = 2 s) e C começa
    expect(order).toEqual(['a', 'b']);
    expect(n.ref.value).toBeCloseTo(30, 10);
    t.update(0.5);
    expect(n.ref.value).toBeCloseTo(15, 10); // C: 30 → 0, metade
    t.update(0.5);
    expect(order).toEqual(['a', 'b', 'c']);
    expect(n.ref.value).toBe(0);
    expect(t.count).toBe(0);
  });

  it('sequence() monta os passos em ordem e devolve o último', () => {
    const t = new Tweener();
    const n = cell(0);
    const done = vi.fn();
    const last = t.sequence([spec(n, 1, { duration: 1 }), spec(n, 2, { duration: 1 }), spec(n, 3, { duration: 1, onComplete: done })]);
    expect(last).toBeDefined();
    t.update(2.5);
    expect(n.ref.value).toBeCloseTo(2.5, 10);
    t.update(1);
    expect(n.ref.value).toBe(3);
    expect(done).toHaveBeenCalledTimes(1);
  });

  it('loop recomeça do início; pingpong vai e volta; repeat finito termina e chama onComplete', () => {
    const t = new Tweener();
    const loop = cell(0);
    const pp = cell(0);
    const finite = cell(0);
    const done = vi.fn();
    t.add(spec(loop, 10, { duration: 1, loop: 'loop' }));
    t.add(spec(pp, 10, { duration: 1, loop: 'pingpong' }));
    t.add(spec(finite, 10, { duration: 1, loop: 'pingpong', repeat: 1, onComplete: done })); // ida e volta = 2 passadas
    t.update(1.5);
    expect(loop.ref.value).toBeCloseTo(5, 10); // 2ª passada, metade
    expect(pp.ref.value).toBeCloseTo(5, 10); // voltando
    t.update(0.25);
    expect(pp.ref.value).toBeCloseTo(2.5, 10);
    expect(finite.ref.value).toBeCloseTo(2.5, 10);
    t.update(1);
    expect(done).toHaveBeenCalledTimes(1);
    expect(finite.ref.value).toBe(0); // terminou no ponto de partida (2 passadas de pingpong)
    expect(t.count).toBe(2); // os dois infinitos seguem
  });

  it('kill por tween, por dono e clear; matar um passo cancela o que estava encadeado depois', () => {
    const t = new Tweener();
    const owner = {};
    const a = cell(0);
    const b = cell(0);
    const c = cell(0);
    const chained = vi.fn();
    const first = t.add(spec(a, 1, { owner }));
    first.then(spec(a, 2, { onStart: chained }));
    t.add(spec(b, 1, { owner }));
    t.add(spec(c, 1));
    expect(t.has(owner)).toBe(true);
    expect(t.kill(owner)).toBe(2);
    t.update(5);
    expect([a.ref.value, b.ref.value, c.ref.value]).toEqual([0, 0, 1]);
    expect(chained).not.toHaveBeenCalled();
    const d = t.add(spec(cell(0), 1, { duration: 10 }));
    d.kill();
    expect(t.count).toBe(0);
    t.add(spec(cell(0), 1));
    t.clear();
    expect(t.count).toBe(0);
  });

  it('pausar não avança; dt ≤ 0 ou NaN é ignorado', () => {
    const t = new Tweener();
    const n = cell(0);
    t.add(spec(n, 10));
    t.setPaused(true);
    t.update(1);
    expect(n.ref.value).toBe(0);
    t.setPaused(false);
    t.update(0);
    t.update(Number.NaN);
    expect(n.ref.value).toBe(0);
    t.update(0.5);
    expect(n.ref.value).toBeCloseTo(5, 10);
  });

  it('erro num callback mata só aquele tween e vai ao onError; os outros seguem', () => {
    const errors: string[] = [];
    const t = new Tweener({ onError: (e, where) => errors.push(`${where}:${(e as Error).message}`) });
    const bad = cell(0);
    const good = cell(0);
    t.add(spec(bad, 1, { onUpdate: () => { throw new Error('boom'); } }));
    t.add(spec(good, 1));
    t.update(0.5);
    expect(errors).toEqual(['set/onUpdate:boom']);
    expect(good.ref.value).toBeCloseTo(0.5, 10);
    expect(t.count).toBe(1);
  });

  it('um callback pode criar outro tween no mesmo quadro (sem laço nem perda)', () => {
    const t = new Tweener();
    const a = cell(0);
    const b = cell(0);
    t.add(spec(a, 1, { duration: 1, onComplete: () => t.add(spec(b, 5, { duration: 1 })) }));
    t.update(1);
    expect(t.count).toBe(1);
    t.update(1);
    expect(b.ref.value).toBe(5);
  });
});
