/**
 * @file easing.ts
 * @module animation
 *
 * AIS-59 — curvas de transição do Tweener. Funções puras `t ∈ [0,1] → [0,1]` (Bounce/Elastic passam do intervalo no meio do
 * caminho, como se espera, mas valem 0 em t=0 e 1 em t=1). Os nomes são os do prompt; `normalizeEasing` aceita também os
 * nomes legados dos keyframes (`ease-in`, `ease-out`, `ease-in-out`, `linear`) de `src/types/animation.ts`.
 */

export const EASING_NAMES = ['Linear', 'EaseInQuad', 'EaseOutQuad', 'EaseInOutQuad', 'Bounce', 'Elastic'] as const;
export type EasingName = (typeof EASING_NAMES)[number];

export type EasingFn = (t: number) => number;

const easeOutBounce: EasingFn = (t) => {
  const n1 = 7.5625;
  const d1 = 2.75;
  if (t < 1 / d1) return n1 * t * t;
  if (t < 2 / d1) return n1 * (t -= 1.5 / d1) * t + 0.75;
  if (t < 2.5 / d1) return n1 * (t -= 2.25 / d1) * t + 0.9375;
  return n1 * (t -= 2.625 / d1) * t + 0.984375;
};

const easeOutElastic: EasingFn = (t) => {
  if (t === 0 || t === 1) return t;
  const c4 = (2 * Math.PI) / 3;
  return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1;
};

export const EASINGS: Record<EasingName, EasingFn> = {
  Linear: (t) => t,
  EaseInQuad: (t) => t * t,
  EaseOutQuad: (t) => 1 - (1 - t) * (1 - t),
  EaseInOutQuad: (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2),
  Bounce: easeOutBounce,
  Elastic: easeOutElastic,
};

const LEGACY: Record<string, EasingName> = {
  linear: 'Linear',
  'ease-in': 'EaseInQuad',
  'ease-out': 'EaseOutQuad',
  'ease-in-out': 'EaseInOutQuad',
};

/** Nome (canônico, legado de keyframe ou com outra caixa) → `EasingName`; desconhecido cai em `Linear`. */
export function normalizeEasing(value: unknown): EasingName {
  if (typeof value !== 'string') return 'Linear';
  if ((EASING_NAMES as readonly string[]).includes(value)) return value as EasingName;
  const legacy = LEGACY[value];
  if (legacy) return legacy;
  const ci = EASING_NAMES.find((n) => n.toLowerCase() === value.toLowerCase());
  return ci ?? 'Linear';
}

/** Aplica a curva com `t` preso a [0,1]. */
export function ease(name: EasingName | string, t: number): number {
  const clamped = Number.isFinite(t) ? Math.min(1, Math.max(0, t)) : 0;
  return EASINGS[normalizeEasing(name)](clamped);
}
