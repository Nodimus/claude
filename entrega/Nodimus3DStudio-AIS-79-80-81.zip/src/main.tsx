import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import './index.css';
import { themeService } from './core/theme/themeService';
import { readStoredLanguage, setCurrentLanguage, tNow } from './core/i18n';

// Inicialização síncrona do tema antes da montagem para evitar flash
themeService.initTheme();
setCurrentLanguage(readStoredLanguage()); // mensagens de bootstrap (antes do I18nProvider) já saem no idioma salvo

const rootElement = document.getElementById('root')!;

/** Falha ao preparar o workspace em disco: mensagem explícita (nunca cai em silêncio no localStorage — decisão 14). */
function renderStorageError(error: unknown): void {
  const message = (error as { message?: string } | null)?.message ?? String(error);
  rootElement.innerHTML = '';
  const box = document.createElement('div');
  box.style.cssText = 'padding:24px;font:13px/1.5 system-ui,sans-serif;color:#dfe4ec;background:#12151d;height:100vh';
  const title = document.createElement('h2');
  title.textContent = tNow('mainMsgCore.couldNotOpenTheProjects');
  const text = document.createElement('p');
  text.textContent = message;
  const hint = document.createElement('p');
  hint.textContent = tNow('mainMsgCore.checkThatTheFolderExists');
  const retry = document.createElement('button');
  retry.textContent = tNow('mainMsgCore.tryAgain');
  retry.onclick = () => location.reload();
  const reset = document.createElement('button');
  reset.textContent = tNow('mainMsgCore.useTheDefaultFolder');
  reset.style.marginLeft = '8px';
  reset.onclick = () => {
    try {
      localStorage.removeItem('nodimus_workspace_root');
    } catch {
      /* sem localStorage */
    }
    location.reload();
  };
  box.append(title, text, hint, retry, reset);
  rootElement.append(box);
}

// AIS-30c: o armazenamento (workspace em disco no desktop) precisa estar pronto ANTES de qualquer módulo que leia o projeto
// (o `AuthoringModel` global lê o projeto na criação), por isso App e ganchos de teste entram por import dinâmico.
async function bootstrap(): Promise<void> {
  try {
    const { ProjectStorage } = await import('./core/projectStorage');
    await ProjectStorage.initialize();
  } catch (error) {
    console.error('[bootstrap] falha ao preparar o armazenamento', error);
    renderStorageError(error);
    return;
  }
  const [{ default: App }, { installDevHooks }] = await Promise.all([import('./App.tsx'), import('./devHooks')]);
  installDevHooks(); // só em `vite dev`: gancho de teste e2e (window.__nodimus)
  createRoot(rootElement).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}

void bootstrap();
