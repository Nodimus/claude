import { describe, expect, it, vi } from 'vitest';
import { dispatchDesktopShortcut, isAnyEditorModalOpen, isTextEntryElement, MODAL_OPEN_FLAGS, type ShortcutActionHandlers } from './useDesktopShortcuts';

const key = (k: string, mods: { ctrl?: boolean; shift?: boolean } = {}) =>
  ({
    key: k,
    ctrlKey: Boolean(mods.ctrl),
    metaKey: false,
    shiftKey: Boolean(mods.shift),
    altKey: false,
    target: null,
    preventDefault: () => {},
  }) as unknown as KeyboardEvent;

const handlers = (extra: Partial<ShortcutActionHandlers> = {}) => ({
  onUndo: vi.fn(),
  onRedo: vi.fn(),
  onDeleteSelected: vi.fn(),
  onDuplicateSelected: vi.fn(),
  onTranslateGizmo: vi.fn(),
  onRotateGizmo: vi.fn(),
  onScaleGizmo: vi.fn(),
  onFrameSelected: vi.fn(),
  onSaveScene: vi.fn(),
  onEscape: vi.fn(),
  selectedNodeId: 'n1',
  ...extra,
});

describe('atalhos globais × modais abertos (AIS-22)', () => {
  it('sem modal: Undo/Redo/Delete/Duplicar/gizmo disparam', () => {
    const h = handlers();
    expect(dispatchDesktopShortcut(key('z', { ctrl: true }), h)).toBe('undo');
    expect(dispatchDesktopShortcut(key('y', { ctrl: true }), h)).toBe('redo');
    expect(dispatchDesktopShortcut(key('Delete'), h)).toBe('delete_node');
    expect(dispatchDesktopShortcut(key('d', { ctrl: true }), h)).toBe('duplicate_node');
    expect(dispatchDesktopShortcut(key('w'), h)).toBe('gizmo_translate');
    expect(h.onUndo).toHaveBeenCalledTimes(1);
    expect(h.onDeleteSelected).toHaveBeenCalledTimes(1);
  });

  it('com modal aberto: nada que mute a cena por trás do modal dispara', () => {
    const h = handlers({ modalOpen: true });
    for (const e of [
      key('z', { ctrl: true }),
      key('y', { ctrl: true }),
      key('z', { ctrl: true, shift: true }),
      key('Delete'),
      key('Backspace'),
      key('d', { ctrl: true }),
      key('w'),
      key('e'),
      key('r'),
      key('f'),
    ]) {
      expect(dispatchDesktopShortcut(e, h)).toBeNull();
    }
    expect(h.onUndo).not.toHaveBeenCalled();
    expect(h.onRedo).not.toHaveBeenCalled();
    expect(h.onDeleteSelected).not.toHaveBeenCalled();
    expect(h.onDuplicateSelected).not.toHaveBeenCalled();
    expect(h.onTranslateGizmo).not.toHaveBeenCalled();
    expect(h.onFrameSelected).not.toHaveBeenCalled();
  });

  it('com modal aberto, Escape e Ctrl+S continuam funcionando', () => {
    const h = handlers({ modalOpen: true });
    expect(dispatchDesktopShortcut(key('Escape'), h)).toBe('escape');
    expect(dispatchDesktopShortcut(key('s', { ctrl: true }), h)).toBe('save_scene');
  });

  it('isAnyEditorModalOpen: falso sem flags; verdadeiro com qualquer uma das flags de modal', () => {
    expect(isAnyEditorModalOpen({})).toBe(false);
    expect(isAnyEditorModalOpen({ isSoundModalOpen: false })).toBe(false);
    for (const flag of MODAL_OPEN_FLAGS) expect(isAnyEditorModalOpen({ [flag]: true })).toBe(true);
  });

  it('as flags listadas existem no EditorStore (nenhuma lista de modal inventada)', async () => {
    const { useEditorStore } = await import('../core/editorStore');
    const state = useEditorStore.getState() as unknown as Record<string, unknown>;
    for (const flag of MODAL_OPEN_FLAGS) expect(typeof state[flag]).toBe('boolean');
  });
});

describe('Undo/Redo com foco em controles que não digitam (AIS-25)', () => {
  // `isEditableElement` exige HTMLElement; em Node simulamos com uma classe mínima
  class FakeEl {
    tagName: string;
    type?: string;
    isContentEditable = false;
    constructor(tagName: string, type?: string) {
      this.tagName = tagName;
      this.type = type;
    }
    closest() {
      return null;
    }
  }
  const withTarget = (target: unknown, k: string, ctrl = true, shift = false) =>
    ({ key: k, ctrlKey: ctrl, metaKey: false, shiftKey: shift, altKey: false, target, preventDefault: () => {} }) as unknown as KeyboardEvent;

  const g = globalThis as unknown as { HTMLElement?: unknown };
  const original = g.HTMLElement;
  const install = () => void (g.HTMLElement = FakeEl);
  const restore = () => void (g.HTMLElement = original);

  it('select, checkbox, range e cor não são campos de texto; texto/número/textarea são', () => {
    install();
    try {
      expect(isTextEntryElement(new FakeEl('SELECT') as unknown as EventTarget)).toBe(false);
      for (const type of ['checkbox', 'radio', 'range', 'color']) expect(isTextEntryElement(new FakeEl('INPUT', type) as unknown as EventTarget)).toBe(false);
      for (const type of ['text', 'number', 'search']) expect(isTextEntryElement(new FakeEl('INPUT', type) as unknown as EventTarget)).toBe(true);
      expect(isTextEntryElement(new FakeEl('TEXTAREA') as unknown as EventTarget)).toBe(true);
    } finally {
      restore();
    }
  });

  it('Ctrl+Z/Ctrl+Y valem com foco num select; Delete e W continuam bloqueados', () => {
    install();
    try {
      const h = handlers();
      const select = new FakeEl('SELECT');
      expect(dispatchDesktopShortcut(withTarget(select, 'z'), h)).toBe('undo');
      expect(dispatchDesktopShortcut(withTarget(select, 'y'), h)).toBe('redo');
      expect(dispatchDesktopShortcut(withTarget(select, 'Delete', false), h)).toBeNull();
      expect(dispatchDesktopShortcut(withTarget(select, 'w', false), h)).toBeNull();
      expect(h.onDeleteSelected).not.toHaveBeenCalled();
    } finally {
      restore();
    }
  });

  it('em campo de texto o Ctrl+Z continua do próprio campo (não desfaz a cena)', () => {
    install();
    try {
      const h = handlers();
      expect(dispatchDesktopShortcut(withTarget(new FakeEl('INPUT', 'text'), 'z'), h)).toBeNull();
      expect(h.onUndo).not.toHaveBeenCalled();
    } finally {
      restore();
    }
  });

  it('com modal aberto, Undo continua bloqueado mesmo com foco num select', () => {
    install();
    try {
      const h = handlers({ modalOpen: true });
      expect(dispatchDesktopShortcut(withTarget(new FakeEl('SELECT'), 'z'), h)).toBeNull();
    } finally {
      restore();
    }
  });
});
