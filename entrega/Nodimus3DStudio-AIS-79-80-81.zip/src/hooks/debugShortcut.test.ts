import { describe, expect, it, vi } from 'vitest';
import { DESKTOP_SHORTCUTS, dispatchDesktopShortcut } from './useDesktopShortcuts';

/** AIS-77-C01 — F3 alterna o overlay só em Play; fora dele a tecla segue com o navegador. */
const key = (k: string) => ({ key: k, target: null, preventDefault: vi.fn(), ctrlKey: false, metaKey: false, shiftKey: false, altKey: false }) as unknown as KeyboardEvent;

describe('atalho F3 (overlay de debug)', () => {
  it('em Play: alterna, impede o padrão do navegador e devolve o id', () => {
    const toggle = vi.fn();
    const e = key('F3');
    expect(dispatchDesktopShortcut(e, { isPlaying: true, onToggleDebugOverlay: toggle })).toBe('toggle_debug_overlay');
    expect(toggle).toHaveBeenCalledTimes(1);
    expect(e.preventDefault).toHaveBeenCalled();
  });
  it('fora do Play: não faz nada e NÃO captura a tecla', () => {
    const toggle = vi.fn();
    const e = key('F3');
    expect(dispatchDesktopShortcut(e, { isPlaying: false, onToggleDebugOverlay: toggle })).toBeNull();
    expect(toggle).not.toHaveBeenCalled();
    expect(e.preventDefault).not.toHaveBeenCalled();
  });
  it('consta na lista canônica de atalhos', () => {
    expect(DESKTOP_SHORTCUTS.some((s) => s.keyCombo === 'F3')).toBe(true);
  });
});
