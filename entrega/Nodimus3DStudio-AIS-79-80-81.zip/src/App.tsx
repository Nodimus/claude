import React, { useState, useEffect } from 'react';
import { EditorProvider, useEditor } from './core/EditorContext';
import { I18nProvider } from './core/i18n/I18nContext';
import { TopBar } from './components/layout/TopBar';
import { SceneTreePanel } from './components/sceneTree/SceneTreePanel';
import { FileSystemPanel } from './components/fileSystem/FileSystemPanel';
import { InspectorPanel } from './components/inspector/InspectorPanel';
import { Viewport3D } from './components/viewports/Viewport3D';
import { VisualLogicEditor } from './components/viewports/VisualLogicEditor';
import { CodeEditorWorkspace } from './components/viewports/CodeEditorWorkspace';
import { BottomPanel } from './components/bottomPanel/BottomPanel';
import { CreateNodeModal } from './components/modals/CreateNodeModal';
import { ProjectManagerModal } from './components/modals/ProjectManagerModal';
import { ProjectSettingsModal } from './components/modals/ProjectSettingsModal';
import { PostProcessingModal } from './components/modals/PostProcessingModal';
import { TerrainEditorModal } from './components/modals/TerrainEditorModal';
import { CameraPresetDialog } from './components/modals/CameraPresetDialog';
import { VehicleDialog } from './components/modals/VehicleDialog';
import { DocumentConflictDialog } from './components/modals/DocumentConflictDialog';
import { DecisionDialog } from './components/modals/DecisionDialog';
import { TreeEditorModal } from './components/modals/TreeEditorModal';
import { FogModal } from './components/modals/FogModal';
import { SoundModal } from './components/modals/SoundModal';
import { ParticleModal } from './components/modals/ParticleModal';
import { AssetImportModal } from './components/modals/AssetImportModal';
import { ScriptEditorModal } from './components/modals/ScriptEditorModal';
import { TexturePreviewModal } from './components/modals/TexturePreviewModal';
import { ExtensionsPanel } from './components/modals/ExtensionsPanel';
import { VideoEditorModal } from './components/modals/VideoEditorModal';
import { SpriteEditorModal } from './components/modals/SpriteEditorModal';
import { useDesktopShortcuts } from './hooks/useDesktopShortcuts';
import { useEditorStore } from './core/editorStore';

const EditorLayout: React.FC = () => {
  const { workspaceMode } = useEditor();
  // AIS-44c: durante o Play a edição autoral (Scene Tree/Inspector) fica bloqueada; os painéis seguem visíveis, só leitura
  const isPlaying = useEditorStore((s) => s.isPlaying);

  // AIS-04: Global Desktop Keyboard Shortcuts listener (F5, F6, F8, Ctrl+S, Ctrl+Z, Ctrl+Y, W, E, R, F, Del, Ctrl+D)
  useDesktopShortcuts();

  // Left dock split ratio (SceneTree vs FileSystem)
  const [leftSplitRatio, setLeftSplitRatio] = useState(0.55);

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[var(--gl-bg)] text-[var(--gl-text)] font-sans antialiased select-none">
      {/* Top Godot 3.x Style Command & Workspace Bar */}
      <TopBar />

      {/* Main Docking Workspace */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Dock: Scene Tree (top) + FileSystem (bottom) */}
        <aside className="w-64 flex flex-col shrink-0 border-r border-[var(--gl-border)] bg-[var(--gl-panel)] overflow-hidden">
          {/* Scene Tree Panel */}
          <div
            style={{ height: `${leftSplitRatio * 100}%` }}
            className="overflow-hidden flex flex-col"
            inert={isPlaying}
          >
            <SceneTreePanel />
          </div>

          {/* Horizontal Splitter */}
          <div
            onMouseDown={(e) => {
              const startY = e.clientY;
              const startRatio = leftSplitRatio;
              const onMouseMove = (moveEv: MouseEvent) => {
                const totalHeight = window.innerHeight - 80;
                const delta = (moveEv.clientY - startY) / totalHeight;
                setLeftSplitRatio(Math.max(0.2, Math.min(0.8, startRatio + delta)));
              };
              const onMouseUp = () => {
                window.removeEventListener('mousemove', onMouseMove);
                window.removeEventListener('mouseup', onMouseUp);
              };
              window.addEventListener('mousemove', onMouseMove);
              window.addEventListener('mouseup', onMouseUp);
            }}
            className="h-1 bg-[var(--gl-border)] hover:bg-[var(--gl-accent)] cursor-row-resize transition-colors shrink-0"
          />

          {/* FileSystem Panel */}
          <div
            style={{ height: `${(1 - leftSplitRatio) * 100}%` }}
            className="overflow-hidden flex flex-col"
          >
            <FileSystemPanel />
          </div>
        </aside>

        {/* Center Area: Active Viewport + Bottom Panel */}
        <main className="flex-1 flex flex-col overflow-hidden relative bg-[var(--gl-bg)]">
          {/* Viewport switcher */}
          <div className="flex-1 relative overflow-hidden">
            {workspaceMode === '3D' && <Viewport3D />}
            {workspaceMode === 'VisualLogic' && <VisualLogicEditor />}
            {workspaceMode === 'Script' && <CodeEditorWorkspace />}
          </div>

          {/* Bottom Dock: Output, Debugger */}
          <BottomPanel />
        </main>

        {/* Right Dock: Inspector & Node Signals */}
        <aside className="w-72 shrink-0 border-l border-[var(--gl-border)] bg-[var(--gl-panel)] flex flex-col overflow-hidden" inert={isPlaying}>
          <InspectorPanel />
        </aside>
      </div>

      {/* Global Modals */}
      <CreateNodeModal />
      <ProjectManagerModal />
      <ProjectSettingsModal />
      <PostProcessingModal />
      <TerrainEditorModal />
      <CameraPresetDialog />
      <VehicleDialog />
      <DocumentConflictDialog />
      <DecisionDialog />
      <TreeEditorModal />
      <FogModal />
      <SoundModal />
      <ParticleModal />
      <AssetImportModal />
      <ScriptEditorModal />
      <TexturePreviewModal />
      <ExtensionsPanel />
      <VideoEditorModal />
      <SpriteEditorModal />
    </div>
  );
};

export default function App() {
  return (
    <I18nProvider>
      <EditorProvider>
        <EditorLayout />
      </EditorProvider>
    </I18nProvider>
  );
}
