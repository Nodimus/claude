import { setCurrentLanguage } from './core/i18n';

/**
 * AIS-80 — idioma das mensagens nos testes. As mensagens de diagnóstico/log nasceram em pt-BR e os testes históricos afirmam esse texto;
 * fixar o idioma evita que o padrão do produto (`en`) mude o resultado. Teste que quiser outro idioma chama `setCurrentLanguage`.
 */
setCurrentLanguage('pt-BR');
