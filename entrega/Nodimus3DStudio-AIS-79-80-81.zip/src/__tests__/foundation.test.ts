/**
 * Testes da fundação (AIS-02b … AIS-05r).
 * Convertem os verificadores determinísticos existentes (funções puras que
 * antes eram verificados por checklist) em asserções Vitest. Cada verificador
 * continua sendo a fonte da verdade; aqui só falhamos com a lista de itens
 * reprovados para facilitar o diagnóstico.
 */
import { describe, expect, it } from 'vitest';
import {
  verifyZodSchemas,
  verifyEditorStoreSelectors,
  verifyEditorContextFacade,
  verifyDesktopShortcuts,
  verifyDefaultProjectAndStorage,
} from '../schemas/fixtures';
import { verifyStateMutationPolicy } from '../core/stateMutationPolicy';

type AnyResult = { allPassed: boolean; results?: unknown[] } & Record<string, unknown>;

const failures = (r: AnyResult) =>
  (Array.isArray(r.results) ? r.results : []).filter((x: any) => {
    if ('passed' in x) return !x.passed;
    if ('validPasses' in x) return !x.validPasses || !x.invalidCatchesErrors;
    return false;
  });

const expectAllPassed = (r: AnyResult) => {
  expect(failures(r), JSON.stringify(failures(r), null, 2)).toEqual([]);
  expect(r.allPassed).toBe(true);
};

describe('fundação', () => {
  it('AIS-02b/03b — schemas Zod e preservação de dados', () => expectAllPassed(verifyZodSchemas() as AnyResult));
  it('AIS-03d — selectors do EditorStore', () => expectAllPassed(verifyEditorStoreSelectors() as AnyResult));
  it('AIS-03e — State Mutation Policy', () => expectAllPassed(verifyStateMutationPolicy() as AnyResult));
  it('AIS-03f — fachada do EditorContext', () => expectAllPassed(verifyEditorContextFacade() as AnyResult));
  it('AIS-04 — atalhos de desktop', () => expectAllPassed(verifyDesktopShortcuts() as AnyResult));
  it('AIS-05/05r — projeto default e persistência', () => expectAllPassed(verifyDefaultProjectAndStorage() as AnyResult));
});
