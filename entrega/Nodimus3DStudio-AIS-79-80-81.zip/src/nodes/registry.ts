import type { NodeType, NodeTypeMetadata, GameNode, PropertyDescriptor } from '../types/node';
import { PARTICLE_DEFAULTS, PARTICLE_LIMITS } from '../core/particles/particleTypes';
import { LAYOUT_PRESET_ORDER, layoutFieldLabels, normalizeLayoutPreset } from '../runtime/overlay';
import { SIZE_FLAG_VALUES } from '../runtime/containerLayout';
import { DEFAULT_HDRI_ID, hdriOptions } from '../core/environment/skyTypes';

/** Layout Presets do Godot (AIS-25b): 9 de ponto + 6 esticados + Full-Rect. */
const LAYOUT_PRESET_OPTIONS = LAYOUT_PRESET_ORDER.map((preset) => ({ label: preset, value: preset }));
const layoutLabel = (field: 'posX' | 'posY' | 'width' | 'height') => (properties: Record<string, any>) =>
  layoutFieldLabels(normalizeLayoutPreset(properties.alignment))[field];

// ── AIS-25c: Containers e controles de UI (modelo Control/Container da Godot sobre o UIKit) ─────────
// Um filho de Container tem o posicionamento assumido pelo Container: valem os size flags, `minSize` e
// `stretchRatio` (categoria 'Container Layout'); fora de Container valem o preset + offsets ('2D Coordinates').
// O Inspector mostra uma ou outra conforme o pai (ver `uiLayoutCategories`).

/** Size flags do Godot (por eixo; definição em `runtime/containerLayout.ts`). */
const SIZE_FLAG_OPTIONS = SIZE_FLAG_VALUES.map((value) => ({ label: value, value }));

/** Categorias de descriptor de layout de UI (o Inspector escolhe uma conforme o pai ser Container). */
export const UI_FREE_LAYOUT_CATEGORY = '2D Coordinates';
export const UI_CONTAINER_LAYOUT_CATEGORY = 'Container Layout';

/** Campos de layout "em Container", comuns a TODO nó de UI (inclusive Overlay2D/TextOverlay2D/ButtonOverlay2D). */
const UI_CHILD_DESCRIPTORS: PropertyDescriptor[] = [
  { key: 'sizeFlagsH', label: 'Size Flags H', type: 'enum', category: UI_CONTAINER_LAYOUT_CATEGORY, defaultValue: 'fill', options: SIZE_FLAG_OPTIONS },
  { key: 'sizeFlagsV', label: 'Size Flags V', type: 'enum', category: UI_CONTAINER_LAYOUT_CATEGORY, defaultValue: 'fill', options: SIZE_FLAG_OPTIONS },
  { key: 'minSize', label: 'Min Size (px)', type: 'vector2', category: UI_CONTAINER_LAYOUT_CATEGORY, defaultValue: { x: 0, y: 0 } },
  { key: 'stretchRatio', label: 'Stretch Ratio', type: 'float', category: UI_CONTAINER_LAYOUT_CATEGORY, defaultValue: 1, min: 0.1, step: 0.1 },
];

const UI_LAYOUT_DESCRIPTORS = (width: number, height: number): PropertyDescriptor[] => {
  return [
  { key: 'posX', label: 'Position X (px)', type: 'integer', category: UI_FREE_LAYOUT_CATEGORY, defaultValue: 20, dynamicLabel: layoutLabel('posX') },
  { key: 'posY', label: 'Position Y (px)', type: 'integer', category: UI_FREE_LAYOUT_CATEGORY, defaultValue: 20, dynamicLabel: layoutLabel('posY') },
  { key: 'width', label: 'Width (px)', type: 'integer', category: UI_FREE_LAYOUT_CATEGORY, defaultValue: width, dynamicLabel: layoutLabel('width') },
  { key: 'height', label: 'Height (px)', type: 'integer', category: UI_FREE_LAYOUT_CATEGORY, defaultValue: height, dynamicLabel: layoutLabel('height') },
  {
    key: 'alignment',
    label: 'Layout Preset',
    type: 'enum',
    category: UI_FREE_LAYOUT_CATEGORY,
    defaultValue: 'Top-Left',
    options: LAYOUT_PRESET_OPTIONS,
  },
];
};

const UI_BOX_APPEARANCE: PropertyDescriptor[] = [
  { key: 'color', label: 'Background Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.1, g: 0.13, b: 0.19, a: 0.9 } },
  { key: 'borderColor', label: 'Border Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.29, g: 0.51, b: 0.92, a: 1 } },
  { key: 'borderWidth', label: 'Border Width', type: 'integer', category: 'Appearance', defaultValue: 1, min: 0, max: 10 },
  { key: 'cornerRadius', label: 'Corner Radius', type: 'integer', category: 'Appearance', defaultValue: 6, min: 0, max: 64 },
];

const UI_VISIBLE: PropertyDescriptor = { key: 'visible', label: 'Visible', type: 'boolean', category: 'General', defaultValue: true };

/** Entrada de nó de UI: layout livre + layout de Container + o que for específico do tipo. */
function defineUiNode<T extends string>(def: {
  type: T;
  description: string;
  icon: string;
  size: { width: number; height: number };
  defaults: Record<string, any>;
  descriptors?: PropertyDescriptor[];
  signals?: string[];
}): NodeTypeMetadata<T> {
  return {
    type: def.type,
    name: def.type,
    category: '2D Overlay',
    createCategory: 'UI',
    is2D: true,
    is3D: false,
    isUI: true,
    description: def.description,
    icon: def.icon,
    defaultProperties: {
      posX: 20,
      posY: 20,
      width: def.size.width,
      height: def.size.height,
      alignment: 'Top-Left',
      visible: true,
      ...def.defaults,
    },
    propertyDescriptors: [
      ...UI_LAYOUT_DESCRIPTORS(def.size.width, def.size.height),
      ...UI_CHILD_DESCRIPTORS,
      ...(def.descriptors ?? []),
      UI_VISIBLE,
    ],
    availableSignals: def.signals ?? [],
  };
}

const CONTAINER_ALIGNMENT_OPTIONS = ['begin', 'center', 'end'].map((value) => ({ label: value, value }));
const SCROLL_MODE_OPTIONS = ['auto', 'always', 'never'].map((value) => ({ label: value, value }));
const UI_TEXT_COLOR: PropertyDescriptor = { key: 'textColor', label: 'Text Color', type: 'color', category: 'Typography', defaultValue: { r: 1, g: 1, b: 1, a: 1 } };
const UI_FONT_SIZE: PropertyDescriptor = { key: 'fontSize', label: 'Font Size (px)', type: 'integer', category: 'Typography', defaultValue: 13, min: 8, max: 64 };

/** Infere as chaves e exige, em compilação, que `type` de cada entrada seja igual à sua chave. */
function defineNodeTypes<K extends string>(defs: { [P in K]: NodeTypeMetadata<P> }): { [P in K]: NodeTypeMetadata<P> } {
  return defs;
}


export const NODE_DEFINITIONS = defineNodeTypes({
  // CORE
  Node: {
    type: 'Node',
    name: 'Node',
    category: 'Core',
    createCategory: 'Special',
    is2D: false,
    is3D: false,
    isUI: false,
    description: 'Base node for all scene objects. Has no spatial transform.',
    icon: 'Circle',
    defaultProperties: {
      pauseMode: 'inherit',
    },
    propertyDescriptors: [
      {
        key: 'pauseMode',
        label: 'Pause Mode',
        type: 'enum',
        category: 'General',
        defaultValue: 'inherit',
        options: [
          { label: 'Inherit', value: 'inherit' },
          { label: 'Stop', value: 'stop' },
          { label: 'Process', value: 'process' },
        ],
      },
    ],
    availableSignals: ['tree_entered', 'tree_exited', 'ready'],
  },

  Spatial: {
    type: 'Spatial',
    name: 'Spatial',
    category: 'Core',
    createCategory: '3D Nodes',
    is2D: false,
    is3D: true,
    isUI: false,
    description: '3D root node with position, rotation, and scale in Three.js world space.',
    icon: 'Box',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      visible: true,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'rotation', label: 'Rotation (deg)', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'scale', label: 'Scale', type: 'vector3', category: 'Transform', defaultValue: { x: 1, y: 1, z: 1 } },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'Rendering', defaultValue: true },
    ],
    availableSignals: ['visibility_changed'],
  },

  // 3D NODES
  MeshInstance: {
    type: 'MeshInstance',
    name: 'MeshInstance',
    category: '3D',
    createCategory: '3D Nodes',
    is2D: false,
    is3D: true,
    isUI: false,
    description: '3D Mesh geometry (Cube, Sphere, Cylinder, Plane, Torus) or an imported 3D model (res://models/) with PBR material.',
    icon: 'Box',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      visible: true,
      meshType: 'CubeMesh',
      // AIS-25: material único do nó (parcial; o que falta vem dos padrões de `MaterialProperties`)
      materialOverride: { color: { r: 0.28, g: 0.52, b: 0.92, a: 1 }, roughness: 0.4, metalness: 0.1 },
      castShadow: true,
      receiveShadow: true,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'scale', label: 'Scale', type: 'vector3', category: 'Transform', defaultValue: { x: 1, y: 1, z: 1 } },
      {
        key: 'meshType',
        label: 'Mesh Shape',
        type: 'enum',
        category: 'Mesh',
        defaultValue: 'CubeMesh',
        // com `model` o nó desenha o modelo importado; `meshType` fica guardado (fallback e Undo), sem efeito (AIS-33a)
        visibleWhen: (p) => !p.model,
        options: [
          { label: 'Cube Mesh', value: 'CubeMesh' },
          { label: 'Sphere Mesh', value: 'SphereMesh' },
          { label: 'Cylinder Mesh', value: 'CylinderMesh' },
          { label: 'Plane Mesh', value: 'PlaneMesh' },
          { label: 'Torus Mesh', value: 'TorusMesh' },
        ],
      },
      // AIS-33a (decisão 27): modelo 3D real. `model` é um `ResourceRef` para `res://models/`; só aparece quando existe.
      { key: 'model', label: 'Model', type: 'resource', category: 'Mesh', defaultValue: null, visibleWhen: (p) => !!p.model, description: 'Modelo 3D importado (res://models/). A troca de modelo é feita pela reedição da importação.' },
      { key: 'modelYawDeg', label: 'Model Facing (°)', type: 'float', category: 'Mesh', defaultValue: 0, visibleWhen: (p) => !!p.model, description: 'Frente do modelo: rotação em Y aplicada ao modelo dentro do nó (180° para glTF/Mixamo, cuja frente é +Z; o motor usa -Z). Não muda o yaw do nó.' },
      { key: 'modelOffset', label: 'Model Offset', type: 'vector3', category: 'Mesh', defaultValue: { x: 0, y: 0, z: 0 }, visibleWhen: (p) => !!p.model, description: 'Compensação de pivô aplicada ao modelo dentro do nó.' },
      // O material (shader, albedo, rugosidade, metal, emissivo, textura, tiling, wireframe) é editado só pela
      // seção "Material & Textura" (MeshMaterialSection) sobre `materialOverride`: sem descriptors duplicados.
      { key: 'castShadow', label: 'Cast Shadow', type: 'boolean', category: 'Rendering', defaultValue: true },
      { key: 'receiveShadow', label: 'Receive Shadow', type: 'boolean', category: 'Rendering', defaultValue: true },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'Rendering', defaultValue: true },
    ],
    availableSignals: [],
  },

  Camera: {
    type: 'Camera',
    name: 'Camera',
    category: '3D',
    createCategory: '3D Nodes',
    is2D: false,
    is3D: true,
    isUI: false,
    description: '3D perspective or orthographic game camera. Exactly one active camera is used at game start.',
    icon: 'Video',
    defaultProperties: {
      position: { x: 0, y: 3, z: 8 },
      rotation: { x: -15, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      fov: 65,
      near: 0.1,
      far: 1000,
      active: true,
      /** @deprecated use 'active' — kept for backwards compat with existing scenes */
      current: true,
      projection: 'perspective',
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 3, z: 8 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: -15, y: 0, z: 0 } },
      {
        key: 'projection',
        label: 'Projection',
        type: 'enum',
        category: 'Camera',
        defaultValue: 'perspective',
        options: [
          { label: 'Perspective', value: 'perspective' },
          { label: 'Orthographic', value: 'orthographic' },
        ],
      },
      {
        key: 'fov',
        label: 'Field of View',
        type: 'float',
        category: 'Camera',
        defaultValue: 65,
        min: 20,
        max: 120,
        visibleWhen: (p) => (p.projection ?? 'perspective') === 'perspective',
      },
      { key: 'near', label: 'Near Clip', type: 'float', category: 'Camera', defaultValue: 0.1, min: 0.01 },
      { key: 'far', label: 'Far Clip', type: 'float', category: 'Camera', defaultValue: 1000, min: 10 },
      { key: 'active', label: 'Active Camera', type: 'boolean', category: 'Camera', defaultValue: true, description: 'The game will use exactly one active camera. Switching at runtime via Actions.' },
    ],
    availableSignals: [],
  },

  DirectionalLight: {
    type: 'DirectionalLight',
    name: 'DirectionalLight',
    category: '3D',
    createCategory: 'Lights',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Simulates parallel sunlight across the entire 3D scene. Direction only — position does not affect the light calculation.',
    icon: 'Sun',
    defaultProperties: {
      position: { x: 4, y: 8, z: 4 },
      rotation: { x: -45, y: 30, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      lightColor: { r: 1, g: 0.98, b: 0.9, a: 1 },
      energy: 1.2,
      castShadow: true,
      shadowFrustum: 15,
      shadowBias: -0.0005,
      shadowNormalBias: 0.02,
      shadowNear: 0.5,
      shadowFar: 100,
      shadowMapSize: 2048,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 4, y: 8, z: 4 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: -45, y: 30, z: 0 } },
      { key: 'lightColor', label: 'Color', type: 'color', category: 'Light', defaultValue: { r: 1, g: 0.98, b: 0.9, a: 1 } },
      { key: 'energy', label: 'Intensity', type: 'float', category: 'Light', defaultValue: 1.2, min: 0, max: 10, step: 0.1 },
      { key: 'castShadow', label: 'Cast Shadows', type: 'boolean', category: 'Shadows', defaultValue: true },
      { key: 'shadowFrustum', label: 'Shadow Frustum', type: 'float', category: 'Shadows', defaultValue: 15, min: 2, max: 100, step: 1, visibleWhen: (p) => Boolean(p.castShadow) },
      { key: 'shadowBias', label: 'Shadow Bias', type: 'float', category: 'Shadows', defaultValue: -0.0005, min: -0.01, max: 0.01, step: 0.0001, visibleWhen: (p) => Boolean(p.castShadow) },
      { key: 'shadowNormalBias', label: 'Normal Bias', type: 'float', category: 'Shadows', defaultValue: 0.02, min: 0, max: 0.1, step: 0.005, visibleWhen: (p) => Boolean(p.castShadow) },
      { key: 'shadowNear', label: 'Shadow Near', type: 'float', category: 'Shadows', defaultValue: 0.5, min: 0.1, max: 50, step: 0.5, visibleWhen: (p) => Boolean(p.castShadow) },
      { key: 'shadowFar', label: 'Shadow Far', type: 'float', category: 'Shadows', defaultValue: 100, min: 5, max: 1000, step: 5, visibleWhen: (p) => Boolean(p.castShadow) },
    ],
    availableSignals: [],
  },

  OmniLight: {
    type: 'OmniLight',
    name: 'OmniLight',
    category: '3D',
    createCategory: 'Lights',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Point light (OmniLight) emitting in all directions from a 3D origin. Maps to THREE.PointLight at runtime.',
    icon: 'Zap',
    defaultProperties: {
      position: { x: 0, y: 2, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      lightColor: { r: 1, g: 0.8, b: 0.4, a: 1 },
      energy: 2.0,
      range: 12,
      decay: 2.0,
      castShadow: false,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 2, z: 0 } },
      { key: 'lightColor', label: 'Color', type: 'color', category: 'Light', defaultValue: { r: 1, g: 0.8, b: 0.4, a: 1 } },
      { key: 'energy', label: 'Intensity', type: 'float', category: 'Light', defaultValue: 2.0, min: 0, max: 10 },
      { key: 'range', label: 'Distance', type: 'float', category: 'Light', defaultValue: 12, min: 0.1, max: 200, description: 'Maximum range. 0 = infinite.' },
      { key: 'decay', label: 'Decay', type: 'float', category: 'Light', defaultValue: 2.0, min: 0, max: 4, step: 0.1 },
      { key: 'castShadow', label: 'Cast Shadows', type: 'boolean', category: 'Shadows', defaultValue: false },
    ],
    availableSignals: [],
  },

  SpotLight: {
    type: 'SpotLight',
    name: 'SpotLight',
    category: '3D',
    createCategory: 'Lights',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Conical spotlight with angle and penumbra controls. Deliberate product addition — three.js supports natively.',
    icon: 'Flashlight',
    defaultProperties: {
      position: { x: 0, y: 4, z: 0 },
      rotation: { x: -90, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      lightColor: { r: 1, g: 1, b: 1, a: 1 },
      energy: 3.0,
      distance: 20,
      decay: 2.0,
      angle: 45,
      penumbra: 0.1,
      castShadow: false,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 4, z: 0 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: -90, y: 0, z: 0 } },
      { key: 'lightColor', label: 'Color', type: 'color', category: 'Light', defaultValue: { r: 1, g: 1, b: 1, a: 1 } },
      { key: 'energy', label: 'Intensity', type: 'float', category: 'Light', defaultValue: 3.0, min: 0, max: 10, step: 0.1 },
      { key: 'distance', label: 'Distance', type: 'float', category: 'Light', defaultValue: 20, min: 0.1, max: 200, description: 'Maximum cone reach. 0 = infinite.' },
      { key: 'decay', label: 'Decay', type: 'float', category: 'Light', defaultValue: 2.0, min: 0, max: 4, step: 0.1 },
      { key: 'angle', label: 'Cone Angle (deg)', type: 'float', category: 'Light', defaultValue: 45, min: 1, max: 90 },
      { key: 'penumbra', label: 'Penumbra', type: 'float', category: 'Light', defaultValue: 0.1, min: 0, max: 1, step: 0.05, description: 'Softness of the cone edge (0 = hard, 1 = fully soft).' },
      { key: 'castShadow', label: 'Cast Shadows', type: 'boolean', category: 'Shadows', defaultValue: false },
    ],
    availableSignals: [],
  },

  Environment: {
    type: 'Environment',
    name: 'Environment',
    category: '3D',
    createCategory: 'Special',
    singleton: true,
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Defines 3D world environment settings (ambient lighting, background clear color, realtime shadows, atmospheric fog). A scene permits exactly 0..1 Environment node.',
    icon: 'Sun',
    defaultProperties: {
      ambientColor: { r: 0.5, g: 0.6, b: 0.75, a: 1 },
      ambientIntensity: 0.45,
      backgroundMode: 'Color',
      backgroundColor: { r: 0.08, g: 0.1, b: 0.14, a: 1 },
      realtimeShadows: true,
      fogEnabled: false,
      fogMode: 'exponential2',
      fogColor: { r: 0.56, g: 0.64, b: 0.72, a: 1 },
      fogDensity: 0.008,
      fogNear: 15,
      fogFar: 180,
      fogHeight: 12,
      fogHeightFalloff: 0.6,
      tonemapping: 'ACESFilmic',
      tonemappingExposure: 1.0,
      ssao: 'Disabled',
      ssr: 'Disabled',
    },
    propertyDescriptors: [
      { key: 'ambientColor', label: 'Ambient Color', type: 'color', category: 'Ambient Light', defaultValue: { r: 0.5, g: 0.6, b: 0.75, a: 1 } },
      { key: 'ambientIntensity', label: 'Ambient Intensity', type: 'float', category: 'Ambient Light', defaultValue: 0.45, min: 0, max: 3, step: 0.05 },
      {
        key: 'backgroundMode',
        label: 'Background Mode',
        type: 'enum',
        category: 'Background',
        defaultValue: 'Color',
        options: [
          { label: 'Solid Color', value: 'Color' },
          { label: 'Gradient Sky', value: 'Gradient' },
          { label: 'Procedural Sky (Preetham)', value: 'Procedural' },
          { label: 'HDRI Sky (biblioteca)', value: 'HDRI' },
          // Cubemap de 6 faces continua indisponível (decisão 14).
          { label: 'Skybox Cubemap (em breve)', value: 'Skybox_Pending', disabled: true },
        ],
      },
      { key: 'skyIntensity', label: 'Sky Intensity', type: 'float', category: 'Background', defaultValue: 1, min: 0, max: 8, step: 0.05, visibleWhen: (p) => (p.backgroundMode ?? 'Color') !== 'Color' },
      // Gradient
      { key: 'skyTopColor', label: 'Top Color', type: 'color', category: 'Sky Gradient', defaultValue: { r: 0.12, g: 0.3, b: 0.65, a: 1 }, visibleWhen: (p) => p.backgroundMode === 'Gradient' },
      { key: 'skyHorizonColor', label: 'Horizon Color', type: 'color', category: 'Sky Gradient', defaultValue: { r: 0.7, g: 0.82, b: 0.92, a: 1 }, visibleWhen: (p) => p.backgroundMode === 'Gradient' },
      { key: 'skyBottomColor', label: 'Ground Color', type: 'color', category: 'Sky Gradient', defaultValue: { r: 0.18, g: 0.17, b: 0.16, a: 1 }, visibleWhen: (p) => p.backgroundMode === 'Gradient' },
      { key: 'skyGradientExponent', label: 'Gradient Curve', type: 'float', category: 'Sky Gradient', defaultValue: 1, min: 0.2, max: 6, step: 0.05, visibleWhen: (p) => p.backgroundMode === 'Gradient' },
      // Procedural (three/addons Sky)
      { key: 'sunElevation', label: 'Sun Elevation (°)', type: 'float', category: 'Procedural Sky', defaultValue: 35, min: -10, max: 90, step: 0.5, visibleWhen: (p) => p.backgroundMode === 'Procedural' },
      { key: 'sunAzimuth', label: 'Sun Azimuth (°)', type: 'float', category: 'Procedural Sky', defaultValue: 180, min: 0, max: 360, step: 1, visibleWhen: (p) => p.backgroundMode === 'Procedural' },
      { key: 'skyTurbidity', label: 'Turbidity', type: 'float', category: 'Procedural Sky', defaultValue: 8, min: 0, max: 20, step: 0.1, visibleWhen: (p) => p.backgroundMode === 'Procedural' },
      { key: 'skyRayleigh', label: 'Rayleigh', type: 'float', category: 'Procedural Sky', defaultValue: 2, min: 0, max: 4, step: 0.05, visibleWhen: (p) => p.backgroundMode === 'Procedural' },
      { key: 'skyMieCoefficient', label: 'Mie Coefficient', type: 'float', category: 'Procedural Sky', defaultValue: 0.005, min: 0, max: 0.1, step: 0.001, visibleWhen: (p) => p.backgroundMode === 'Procedural' },
      { key: 'skyMieDirectionalG', label: 'Mie Directional G', type: 'float', category: 'Procedural Sky', defaultValue: 0.8, min: 0, max: 0.999, step: 0.01, visibleWhen: (p) => p.backgroundMode === 'Procedural' },
      { key: 'skyLighting', label: 'Sky Lighting (IBL)', type: 'boolean', category: 'Procedural Sky', defaultValue: true, visibleWhen: (p) => p.backgroundMode === 'Procedural' },
      // HDRI (biblioteca)
      { key: 'hdriId', label: 'HDRI', type: 'enum', category: 'HDRI Sky', defaultValue: DEFAULT_HDRI_ID, options: hdriOptions(), visibleWhen: (p) => p.backgroundMode === 'HDRI' },
      { key: 'hdriRotation', label: 'HDRI Rotation (°)', type: 'float', category: 'HDRI Sky', defaultValue: 0, min: -360, max: 360, step: 1, visibleWhen: (p) => p.backgroundMode === 'HDRI' },
      { key: 'hdriLighting', label: 'HDRI Lighting (IBL)', type: 'boolean', category: 'HDRI Sky', defaultValue: true, visibleWhen: (p) => p.backgroundMode === 'HDRI' },
      {
        key: 'backgroundColor',
        label: 'Clear Color',
        type: 'color',
        category: 'Background',
        defaultValue: { r: 0.08, g: 0.1, b: 0.14, a: 1 },
        visibleWhen: (p) => (p.backgroundMode ?? 'Color') === 'Color',
      },
      { key: 'realtimeShadows', label: 'Realtime Shadows', type: 'boolean', category: 'Shadows', defaultValue: true },
      { key: 'fogEnabled', label: 'Enable Fog', type: 'boolean', category: 'Atmosphere / Fog', defaultValue: false },
      {
        key: 'fogMode',
        label: 'Fog Mode',
        type: 'enum',
        category: 'Atmosphere / Fog',
        defaultValue: 'exponential2',
        options: [
          { label: 'Exponential Squared (Exp2)', value: 'exponential2' },
          { label: 'Linear', value: 'linear' },
          { label: 'Height (Ground Fog)', value: 'height' },
        ],
        visibleWhen: (p) => Boolean(p.fogEnabled),
      },
      {
        key: 'fogColor',
        label: 'Fog Color',
        type: 'color',
        category: 'Atmosphere / Fog',
        defaultValue: { r: 0.56, g: 0.64, b: 0.72, a: 1 },
        visibleWhen: (p) => Boolean(p.fogEnabled),
      },
      {
        key: 'fogDensity',
        label: 'Density',
        type: 'float',
        category: 'Atmosphere / Fog',
        defaultValue: 0.008,
        min: 0.0001,
        max: 0.1,
        step: 0.001,
        visibleWhen: (p) => Boolean(p.fogEnabled) && (p.fogMode ?? 'exponential2') !== 'linear',
      },
      {
        key: 'fogNear',
        label: 'Near Distance',
        type: 'float',
        category: 'Atmosphere / Fog',
        defaultValue: 15,
        min: 0.1,
        max: 500,
        visibleWhen: (p) => Boolean(p.fogEnabled) && p.fogMode === 'linear',
      },
      {
        key: 'fogFar',
        label: 'Far Distance',
        type: 'float',
        category: 'Atmosphere / Fog',
        defaultValue: 180,
        min: 1,
        max: 2000,
        visibleWhen: (p) => Boolean(p.fogEnabled) && p.fogMode === 'linear',
      },
      {
        key: 'fogHeight',
        label: 'Ground Fog Height',
        type: 'float',
        category: 'Atmosphere / Fog',
        defaultValue: 12,
        min: 0.1,
        max: 500,
        visibleWhen: (p) => Boolean(p.fogEnabled) && p.fogMode === 'height',
      },
      {
        key: 'fogHeightFalloff',
        label: 'Ground Fog Falloff',
        type: 'float',
        category: 'Atmosphere / Fog',
        defaultValue: 0.6,
        min: 0.1,
        max: 2,
        step: 0.05,
        visibleWhen: (p) => Boolean(p.fogEnabled) && p.fogMode === 'height',
      },
      {
        key: 'tonemapping',
        label: 'Tone Mapping',
        type: 'enum',
        category: 'Rendering Pipeline',
        defaultValue: 'ACESFilmic',
        options: [
          { label: 'ACES Filmic', value: 'ACESFilmic' },
          { label: 'None', value: 'None' },
        ],
        description: 'High dynamic range tone mapping curve applied to WebGL output.',
      },
      {
        key: 'tonemappingExposure',
        label: 'Exposure',
        type: 'float',
        category: 'Rendering Pipeline',
        defaultValue: 1.0,
        min: 0.1,
        max: 3.0,
        step: 0.05,
        description: 'Exposure level for ACESFilmic tone mapping.',
      },
      {
        key: 'ssao',
        label: 'SSAO',
        type: 'enum',
        category: 'Post Pipeline (Pending)',
        defaultValue: 'Disabled',
        options: [
          { label: 'Disabled (Pending Stage B)', value: 'Disabled' },
        ],
        description: 'Screen Space Ambient Occlusion is pending Stage B pass integration.',
      },
      {
        key: 'ssr',
        label: 'SSR',
        type: 'enum',
        category: 'Post Pipeline (Pending)',
        defaultValue: 'Disabled',
        options: [
          { label: 'Disabled (Pending Stage B)', value: 'Disabled' },
        ],
        description: 'Screen Space Reflections are pending Stage B pass integration.',
      },
    ],
    availableSignals: ['environment_changed'],
  },

  // 2D OVERLAY NODES:
  // 1. Overlay2D (2D Screen Image / HUD Rect)
  // 2. TextOverlay2D (2D Screen Text / Label HUD)
  // 3. ButtonOverlay2D (2D Screen Button / Clickable HUD)
  // 4. Billboard (3D Sprite facing active camera)
  Overlay2D: {
    type: 'Overlay2D',
    name: 'Overlay2D',
    category: '2D Overlay',
    createCategory: 'UI',
    is2D: true,
    is3D: false,
    isUI: true,
    description: '2D Screen Overlay. Draws a 2D image, HUD panel, healthbar or texture over the 3D viewport.',
    icon: 'Image',
    defaultProperties: {
      posX: 20,
      posY: 20,
      width: 140,
      height: 48,
      alignment: 'Top-Left',
      color: { r: 0.15, g: 0.2, b: 0.28, a: 0.85 },
      borderColor: { r: 0.29, g: 0.51, b: 0.92, a: 1 },
      borderWidth: 2,
      texture: '',
      alpha: 0.9,
      visible: true,
      onClickAction: 'none',
    },
    propertyDescriptors: [
      { key: 'posX', label: 'Position X (px)', type: 'integer', category: '2D Coordinates', defaultValue: 20, dynamicLabel: layoutLabel('posX') },
      { key: 'posY', label: 'Position Y (px)', type: 'integer', category: '2D Coordinates', defaultValue: 20, dynamicLabel: layoutLabel('posY') },
      { key: 'width', label: 'Width (px)', type: 'integer', category: '2D Coordinates', defaultValue: 140, dynamicLabel: layoutLabel('width') },
      { key: 'height', label: 'Height (px)', type: 'integer', category: '2D Coordinates', defaultValue: 48, dynamicLabel: layoutLabel('height') },
      {
        key: 'alignment',
        label: 'Layout Preset',
        type: 'enum',
        category: '2D Coordinates',
        defaultValue: 'Top-Left',
        options: LAYOUT_PRESET_OPTIONS,
      },
      { key: 'color', label: 'Background Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.15, g: 0.2, b: 0.28, a: 0.85 } },
      { key: 'borderColor', label: 'Border Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.29, g: 0.51, b: 0.92, a: 1 } },
      { key: 'borderWidth', label: 'Border Width', type: 'integer', category: 'Appearance', defaultValue: 2, min: 0, max: 10 },
      { key: 'texture', label: 'Texture Path', type: 'string', category: 'Appearance', defaultValue: '' },
      { key: 'alpha', label: 'Opacity', type: 'float', category: 'Appearance', defaultValue: 0.9, min: 0, max: 1, step: 0.05 },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'Appearance', defaultValue: true },
      ...UI_CHILD_DESCRIPTORS,
    ],
    availableSignals: ['on_click', 'on_hover'],
  },

  TextOverlay2D: {
    type: 'TextOverlay2D',
    name: 'TextOverlay2D',
    category: '2D Overlay',
    createCategory: 'UI',
    is2D: true,
    is3D: false,
    isUI: true,
    description: '2D Screen Text Overlay. Displays HUD scores, dialogue subtitles, messages and health counter text.',
    icon: 'Type',
    defaultProperties: {
      text: 'HP: 100 / 100',
      posX: 28,
      posY: 28,
      fontSize: 15,
      textColor: { r: 1, g: 1, b: 1, a: 1 },
      alignment: 'Top-Left',
      fontFamily: 'sans-serif',
      shadow: true,
      visible: true,
    },
    propertyDescriptors: [
      { key: 'text', label: 'Text Message', type: 'string', category: 'Content', defaultValue: 'HP: 100 / 100' },
      { key: 'posX', label: 'Position X', type: 'integer', category: '2D Coordinates', defaultValue: 28, dynamicLabel: layoutLabel('posX') },
      { key: 'posY', label: 'Position Y', type: 'integer', category: '2D Coordinates', defaultValue: 28, dynamicLabel: layoutLabel('posY') },
      { key: 'width', label: 'Width (px)', type: 'integer', category: '2D Coordinates', defaultValue: 140, dynamicLabel: layoutLabel('width') },
      { key: 'height', label: 'Height (px)', type: 'integer', category: '2D Coordinates', defaultValue: 24, dynamicLabel: layoutLabel('height') },
      {
        key: 'alignment',
        label: 'Layout Preset',
        type: 'enum',
        category: '2D Coordinates',
        defaultValue: 'Top-Left',
        options: LAYOUT_PRESET_OPTIONS,
      },
      { key: 'fontSize', label: 'Font Size (px)', type: 'integer', category: 'Typography', defaultValue: 15, min: 8, max: 64 },
      { key: 'textColor', label: 'Font Color', type: 'color', category: 'Typography', defaultValue: { r: 1, g: 1, b: 1, a: 1 } },
      { key: 'shadow', label: 'Text Shadow', type: 'boolean', category: 'Typography', defaultValue: true },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'General', defaultValue: true },
      ...UI_CHILD_DESCRIPTORS,
    ],
    availableSignals: ['on_click'],
  },

  ButtonOverlay2D: {
    type: 'ButtonOverlay2D',
    name: 'ButtonOverlay2D',
    category: '2D Overlay',
    createCategory: 'UI',
    is2D: true,
    is3D: false,
    isUI: true,
    description: '2D Screen Button Overlay. Interactive clickable UI button that triggers actions on click or hover.',
    icon: 'MousePointerClick',
    defaultProperties: {
      text: 'Inventory',
      posX: 20,
      posY: 80,
      width: 140,
      height: 38,
      alignment: 'Top-Left',
      buttonColor: { r: 0.16, g: 0.42, b: 0.85, a: 1 },
      hoverColor: { r: 0.22, g: 0.52, b: 0.95, a: 1 },
      textColor: { r: 1, g: 1, b: 1, a: 1 },
      fontSize: 13,
      visible: true,
    },
    propertyDescriptors: [
      { key: 'text', label: 'Button Label', type: 'string', category: 'Content', defaultValue: 'Inventory' },
      { key: 'posX', label: 'Position X', type: 'integer', category: '2D Coordinates', defaultValue: 20, dynamicLabel: layoutLabel('posX') },
      { key: 'posY', label: 'Position Y', type: 'integer', category: '2D Coordinates', defaultValue: 80, dynamicLabel: layoutLabel('posY') },
      { key: 'width', label: 'Width (px)', type: 'integer', category: '2D Coordinates', defaultValue: 140, dynamicLabel: layoutLabel('width') },
      { key: 'height', label: 'Height (px)', type: 'integer', category: '2D Coordinates', defaultValue: 38, dynamicLabel: layoutLabel('height') },
      {
        key: 'alignment',
        label: 'Layout Preset',
        type: 'enum',
        category: '2D Coordinates',
        defaultValue: 'Top-Left',
        options: LAYOUT_PRESET_OPTIONS,
      },
      { key: 'buttonColor', label: 'Normal Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.16, g: 0.42, b: 0.85, a: 1 } },
      { key: 'hoverColor', label: 'Hover Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.22, g: 0.52, b: 0.95, a: 1 } },
      { key: 'textColor', label: 'Text Color', type: 'color', category: 'Typography', defaultValue: { r: 1, g: 1, b: 1, a: 1 } },
      { key: 'fontSize', label: 'Font Size', type: 'integer', category: 'Typography', defaultValue: 13 },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'General', defaultValue: true },
      ...UI_CHILD_DESCRIPTORS,
    ],
    availableSignals: ['on_click', 'on_hover'],
  },

  // ── AIS-25c: Containers (organizam os filhos; Yoga/Flexbox do UIKit) ────────────────────────────
  Panel: defineUiNode({
    type: 'Panel',
    description: 'UI Panel: fundo/borda e área de conteúdo. Posiciona como um Control.',
    icon: 'PanelTop',
    size: { width: 200, height: 120 },
    defaults: { color: { r: 0.1, g: 0.13, b: 0.19, a: 0.9 }, borderColor: { r: 0.29, g: 0.51, b: 0.92, a: 1 }, borderWidth: 1, cornerRadius: 6 },
    descriptors: UI_BOX_APPEARANCE,
  }),

  Container: defineUiNode({
    type: 'Container',
    description: 'UI Container base: empilha os filhos em coluna, sem fundo.',
    icon: 'LayoutPanelTop',
    size: { width: 200, height: 120 },
    defaults: {},
  }),

  HBox: defineUiNode({
    type: 'HBox',
    description: 'UI HBox: organiza os filhos em linha (esquerda → direita).',
    icon: 'Columns3',
    size: { width: 240, height: 48 },
    defaults: { separation: 8, contentAlignment: 'begin' },
    descriptors: [
      { key: 'separation', label: 'Separation (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0, max: 256 },
      { key: 'contentAlignment', label: 'Content Alignment', type: 'enum', category: 'Container', defaultValue: 'begin', options: CONTAINER_ALIGNMENT_OPTIONS },
    ],
  }),

  VBox: defineUiNode({
    type: 'VBox',
    description: 'UI VBox: organiza os filhos em coluna (cima → baixo).',
    icon: 'Rows3',
    size: { width: 160, height: 160 },
    defaults: { separation: 8, contentAlignment: 'begin' },
    descriptors: [
      { key: 'separation', label: 'Separation (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0, max: 256 },
      { key: 'contentAlignment', label: 'Content Alignment', type: 'enum', category: 'Container', defaultValue: 'begin', options: CONTAINER_ALIGNMENT_OPTIONS },
    ],
  }),

  Grid: defineUiNode({
    type: 'Grid',
    description: 'UI Grid: organiza os filhos em grade de N colunas (colunas de largura igual).',
    icon: 'Grid3x3',
    size: { width: 240, height: 160 },
    defaults: { columns: 2, hSeparation: 8, vSeparation: 8 },
    descriptors: [
      { key: 'columns', label: 'Columns', type: 'integer', category: 'Container', defaultValue: 2, min: 1, max: 32 },
      { key: 'hSeparation', label: 'H Separation (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0, max: 256 },
      { key: 'vSeparation', label: 'V Separation (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0, max: 256 },
    ],
  }),

  MarginContainer: defineUiNode({
    type: 'MarginContainer',
    description: 'UI MarginContainer: afasta os filhos das bordas por margens em px.',
    icon: 'Frame',
    size: { width: 200, height: 120 },
    defaults: { marginLeft: 8, marginTop: 8, marginRight: 8, marginBottom: 8 },
    descriptors: [
      { key: 'marginLeft', label: 'Margin Left (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0 },
      { key: 'marginTop', label: 'Margin Top (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0 },
      { key: 'marginRight', label: 'Margin Right (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0 },
      { key: 'marginBottom', label: 'Margin Bottom (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0 },
    ],
  }),

  CenterContainer: defineUiNode({
    type: 'CenterContainer',
    description: 'UI CenterContainer: centraliza o conteúdo nos dois eixos.',
    icon: 'Focus',
    size: { width: 200, height: 120 },
    defaults: {},
  }),

  ScrollContainer: defineUiNode({
    type: 'ScrollContainer',
    description: 'UI ScrollContainer: o conteúdo maior que a caixa rola.',
    icon: 'ScrollText',
    size: { width: 200, height: 120 },
    defaults: { scrollH: 'auto', scrollV: 'auto' },
    descriptors: [
      { key: 'scrollH', label: 'Scroll H', type: 'enum', category: 'Container', defaultValue: 'auto', options: SCROLL_MODE_OPTIONS },
      { key: 'scrollV', label: 'Scroll V', type: 'enum', category: 'Container', defaultValue: 'auto', options: SCROLL_MODE_OPTIONS },
    ],
  }),

  // ── AIS-25c: controles de uso geral (Image/Label/Button = Overlay2D/TextOverlay2D/ButtonOverlay2D) ──
  CheckBox: defineUiNode({
    type: 'CheckBox',
    description: 'UI CheckBox: caixa de marcação com rótulo.',
    icon: 'SquareCheck',
    size: { width: 140, height: 24 },
    defaults: { text: 'CheckBox', checked: false, fontSize: 13, textColor: { r: 1, g: 1, b: 1, a: 1 } },
    descriptors: [
      { key: 'text', label: 'Text', type: 'string', category: 'Content', defaultValue: 'CheckBox' },
      { key: 'checked', label: 'Checked', type: 'boolean', category: 'Content', defaultValue: false },
      UI_FONT_SIZE,
      UI_TEXT_COLOR,
    ],
    signals: ['toggled'],
  }),

  Slider: defineUiNode({
    type: 'Slider',
    description: 'UI Slider: valor numérico entre mínimo e máximo.',
    icon: 'SlidersHorizontal',
    size: { width: 160, height: 20 },
    defaults: { min: 0, max: 100, step: 1, value: 50 },
    descriptors: [
      { key: 'min', label: 'Min', type: 'float', category: 'Value', defaultValue: 0 },
      { key: 'max', label: 'Max', type: 'float', category: 'Value', defaultValue: 100 },
      { key: 'step', label: 'Step', type: 'float', category: 'Value', defaultValue: 1, min: 0 },
      { key: 'value', label: 'Value', type: 'float', category: 'Value', defaultValue: 50 },
    ],
    signals: ['value_changed'],
  }),

  ProgressBar: defineUiNode({
    type: 'ProgressBar',
    description: 'UI ProgressBar: barra de progresso (vida, carregamento).',
    icon: 'Loader',
    size: { width: 160, height: 20 },
    defaults: { min: 0, max: 100, value: 50, showPercent: true },
    descriptors: [
      { key: 'min', label: 'Min', type: 'float', category: 'Value', defaultValue: 0 },
      { key: 'max', label: 'Max', type: 'float', category: 'Value', defaultValue: 100 },
      { key: 'value', label: 'Value', type: 'float', category: 'Value', defaultValue: 50 },
      { key: 'showPercent', label: 'Show Percent', type: 'boolean', category: 'Value', defaultValue: true },
    ],
    signals: ['value_changed'],
  }),

  TextInput: defineUiNode({
    type: 'TextInput',
    description: 'UI TextInput: campo de texto de uma linha.',
    icon: 'TextCursorInput',
    size: { width: 160, height: 30 },
    defaults: { text: '', placeholder: 'Text...', maxLength: 0, fontSize: 13, textColor: { r: 1, g: 1, b: 1, a: 1 } },
    descriptors: [
      { key: 'text', label: 'Text', type: 'string', category: 'Content', defaultValue: '' },
      { key: 'placeholder', label: 'Placeholder', type: 'string', category: 'Content', defaultValue: 'Text...' },
      { key: 'maxLength', label: 'Max Length (0 = ilimitado)', type: 'integer', category: 'Content', defaultValue: 0, min: 0 },
      UI_FONT_SIZE,
      UI_TEXT_COLOR,
    ],
    signals: ['text_changed', 'text_submitted'],
  }),

  Billboard: {
    type: 'Billboard',
    name: 'Billboard',
    category: '3D', // AIS-25b: ancorado no mundo 3D; fora da unificação de overlays de tela
    createCategory: 'Special',
    is2D: true,
    is3D: true,
    isUI: false,
    description: '3D Billboard Sprite. A 2D plane in 3D space that automatically faces the active camera (trees, projectiles, particles, items).',
    icon: 'Radio',
    defaultProperties: {
      position: { x: 0, y: 1.5, z: 0 },
      width: 1.5,
      height: 2.0,
      color: { r: 0.2, g: 0.85, b: 0.4, a: 1 },
      texture: '',
      faceMode: 'camera',
      visible: true,
      // AIS-76 (decisão 24): o Billboard é o `AnimatedSprite3D` — referencia o `SpriteProject` (nunca o copia)
      spriteProject: null,
      animation: '',
      frame: 0,
      speedScale: 1,
      autoplay: true,
      flipH: false,
      flipV: false,
      centered: true,
      offset: { x: 0, y: 0 },
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation (3D)', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 1.5, z: 0 } },
      { key: 'width', label: 'Width (m)', type: 'float', category: 'Dimensions', defaultValue: 1.5, min: 0.1, max: 20 },
      { key: 'height', label: 'Height (m)', type: 'float', category: 'Dimensions', defaultValue: 2.0, min: 0.1, max: 20 },
      { key: 'color', label: 'Tint Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.2, g: 0.85, b: 0.4, a: 1 } },
      { key: 'texture', label: 'Texture Path', type: 'string', category: 'Appearance', defaultValue: '' },
      {
        key: 'faceMode',
        label: 'Face Mode',
        type: 'enum',
        category: 'Billboard',
        defaultValue: 'camera',
        description: 'Câmera = encara a câmera ativa nos 3 eixos; Só eixo Y = fica em pé (árvores/vegetação); Não girar = usa a rotação do nó. Cenas antigas com "alwaysFaceCamera" continuam valendo.',
        options: [
          { label: 'Face camera (3 eixos)', value: 'camera' },
          { label: 'Face camera (só eixo Y)', value: 'y-axis' },
          { label: 'Não girar', value: 'none' },
        ],
      },
      { key: 'spriteProject', label: 'Sprite Project', type: 'resource', category: 'Sprite', defaultValue: null, description: 'Recurso res://sprites/*.sprite.json (SpriteFrames): o nó referencia, não copia. Arraste um .sprite.json para a cena ou use o Sprite Studio.' },
      { key: 'animation', label: 'Animation', type: 'string', category: 'Sprite', defaultValue: '', description: 'Nome da animação do Sprite Project. Vazio = a animação padrão do recurso. Trocar o valor troca o clipe.' },
      { key: 'frame', label: 'Frame', type: 'integer', category: 'Sprite', defaultValue: 0, min: 0, description: 'Posição do frame dentro da animação (Godot "frame"): vale quando o sprite está parado (Autoplay desligado).' },
      { key: 'speedScale', label: 'Speed Scale', type: 'float', category: 'Sprite', defaultValue: 1, min: 0, max: 10, step: 0.1 },
      { key: 'autoplay', label: 'Autoplay', type: 'boolean', category: 'Sprite', defaultValue: true },
      { key: 'flipH', label: 'Flip H', type: 'boolean', category: 'Sprite', defaultValue: false },
      { key: 'flipV', label: 'Flip V', type: 'boolean', category: 'Sprite', defaultValue: false },
      { key: 'centered', label: 'Centered', type: 'boolean', category: 'Sprite', defaultValue: true, description: 'Desligado: o canto superior esquerdo do sprite fica na origem do nó.' },
      { key: 'offset', label: 'Offset (m)', type: 'vector2', category: 'Sprite', defaultValue: { x: 0, y: 0 } },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'General', defaultValue: true },
    ],
    availableSignals: ['animation_finished', 'animation_looped', 'frame_changed'],
  },

  // AIS-70: volume de detecção invisível no jogo (esfera/caixa). Forma e tamanho = bloco `properties.physics` (corpo `trigger`, decisão 26);
  // Enter/Exit vêm dos eventos físicos de gatilho e o Click, do raycast do Play. Helper (wireframe + marcador) só no editor.
  Hotspot: {
    type: 'Hotspot',
    name: 'Hotspot',
    category: '3D',
    createCategory: 'Special',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Volume de detecção (esfera/caixa) invisível no jogo: dispara On Hotspot Enter/Exit quando um corpo entra/sai e On Hotspot Click ao clicar. Ajuste forma e tamanho em Colisão.',
    icon: 'Target',
    defaultProperties: {
      position: { x: 0, y: 1, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      visible: true,
      physics: { enabled: true, bodyMode: 'trigger', shape: 'sphere', size: { x: 2, y: 2, z: 2 } },
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 1, z: 0 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'scale', label: 'Scale', type: 'vector3', category: 'Transform', defaultValue: { x: 1, y: 1, z: 1 } },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'General', defaultValue: true },
    ],
    availableSignals: [],
  },

  // AIS-72: dado autoral puro (sem corpo, colisão nem malha de colisão): lista ordenada de waypoints editável na viewport com handles 3D.
  // `nodes` (espaço local do nó) é editado só na viewport (um Command por gesto); `closed`/`tightness`/`showInPlay` pelo Inspector.
  // O Behavior `follow_a_path` o percorre; a spline é a mesma `CatmullRomCurve3` do preview (`src/core/path/pathData.ts`).
  Path: {
    type: 'Path',
    name: 'Path',
    category: '3D',
    createCategory: 'Special',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Caminho de waypoints (spline Catmull-Rom) editável na viewport. Objetos com o Behavior Follow a Path o percorrem. Selecione e use "Editar pontos" para criar, mover, inserir e remover waypoints.',
    icon: 'Route',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      visible: true,
      nodes: [
        { x: -3, y: 0, z: 0 },
        { x: 3, y: 0, z: 0 },
      ],
      closed: false,
      tightness: 0.5,
      showInPlay: false,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'scale', label: 'Scale', type: 'vector3', category: 'Transform', defaultValue: { x: 1, y: 1, z: 1 } },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'General', defaultValue: true },
      { key: 'closed', label: 'Closed', type: 'boolean', category: 'Path', defaultValue: false, description: 'Liga o último waypoint ao primeiro.' },
      { key: 'tightness', label: 'Tightness', type: 'float', category: 'Path', defaultValue: 0.5, min: 0, max: 1, step: 0.05, description: 'Tensão da spline Catmull-Rom (0,5 = padrão; 0 = mais solta, 1 = mais justa nos waypoints).' },
      { key: 'showInPlay', label: 'Show Spline in Play', type: 'boolean', category: 'Path', defaultValue: false, description: 'Mantém a linha da spline visível durante o Play (referência visual). Handles e linhas de edição nunca aparecem no Play.' },
    ],
    availableSignals: [],
  },

  // AIS-72b: marcador de ponto no mundo (sem malha, física nem colisão). A posição do nó é o ponto; uma rota é um contêiner qualquer cujos
  // filhos `Waypoint`, na ordem da SceneTree, formam a sequência (`resolveRoute`, `src/core/waypoints/`). Helper (sprite + rótulo) só no editor.
  Waypoint: {
    type: 'Waypoint',
    name: 'Waypoint',
    category: '3D',
    createCategory: 'Special',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Ponto no mundo (marcador sem malha nem colisão). Filhos Waypoint de um contêiner, na ordem da SceneTree, formam uma rota (ex.: patrulha). Visível só no editor.',
    icon: 'MapPin',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      visible: true,
      label: '',
      waitMs: 0,
      color: { r: 0.133, g: 0.827, b: 0.933, a: 1 }, // #22d3ee
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'scale', label: 'Scale', type: 'vector3', category: 'Transform', defaultValue: { x: 1, y: 1, z: 1 } },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'General', defaultValue: true },
      { key: 'label', label: 'Label', type: 'string', category: 'Waypoint', defaultValue: '', description: 'Rótulo opcional exibido no marcador (só no editor).' },
      { key: 'waitMs', label: 'Wait (ms)', type: 'float', category: 'Waypoint', defaultValue: 0, min: 0, step: 100, description: 'Permanência sugerida ao chegar (>= 0). Quem consome a rota decide se usa.' },
      { key: 'color', label: 'Helper Color', type: 'color', category: 'Waypoint', defaultValue: { r: 0.133, g: 0.827, b: 0.933, a: 1 }, description: 'Cor do marcador e das linhas da rota no editor.' },
    ],
    availableSignals: [],
  },

  // AUDIO & MISC
  AudioPlayer: {
    type: 'AudioPlayer',
    name: 'AudioPlayer',
    category: 'Audio',
    createCategory: 'Animation & Audio',
    is2D: false,
    is3D: false,
    isUI: false,
    description: 'Plays global non-positional background music or ambient tracks.',
    icon: 'Volume2',
    defaultProperties: {
      stream: 'res://audio/bgm.ogg',
      volumeDb: 0,
      pitchScale: 1.0,
      autoplay: false,
      loop: true,
      channel: 'Music',
      soundFX: 'none',
      fxGain: 40,
      fxRoomSize: 65,
    },
    propertyDescriptors: [
      { key: 'stream', label: 'Audio Stream', type: 'file', category: 'Stream', defaultValue: 'res://audio/bgm.ogg' },
      { key: 'channel', label: 'Mixer Channel', type: 'enum', category: 'Audio', defaultValue: 'Music', options: [{ label: 'Master', value: 'Master' }, { label: 'Music', value: 'Music' }, { label: 'SFX', value: 'SFX' }, { label: 'Ambience', value: 'Ambience' }] },

      { key: 'volumeDb', label: 'Volume (dB)', type: 'float', category: 'Audio', defaultValue: 0, min: -40, max: 6 },
      { key: 'pitchScale', label: 'Pitch Scale', type: 'float', category: 'Audio', defaultValue: 1.0, min: 0.1, max: 4.0 },
      { key: 'autoplay', label: 'Autoplay', type: 'boolean', category: 'Playback', defaultValue: false },
      { key: 'soundFX', label: 'Sound Effect', type: 'enum', category: 'Effects', defaultValue: 'none', options: [{ label: 'None', value: 'none' }, { label: 'Reverb', value: 'reverb' }, { label: 'Echo', value: 'echo' }, { label: 'Low-pass', value: 'lowpass' }, { label: 'Distortion', value: 'distortion' }] },
      { key: 'fxGain', label: 'Effect Amount (%)', type: 'float', category: 'Effects', defaultValue: 40, min: 0, max: 100, step: 1, visibleWhen: (p) => (p.soundFX ?? 'none') !== 'none' },
      { key: 'fxRoomSize', label: 'Room / Delay Size (%)', type: 'float', category: 'Effects', defaultValue: 65, min: 0, max: 100, step: 1, visibleWhen: (p) => p.soundFX === 'reverb' || p.soundFX === 'echo' },
      { key: 'loop', label: 'Loop', type: 'boolean', category: 'Playback', defaultValue: true },
    ],
    availableSignals: ['finished'],
  },

  AudioPlayer3D: {
    type: 'AudioPlayer3D',
    name: 'AudioPlayer3D',
    category: 'Audio',
    createCategory: 'Animation & Audio',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Plays spatial 3D audio with positional distance attenuation.',
    icon: 'Headphones',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      stream: 'res://audio/sfx_spatial.wav',
      unitSize: 10.0,
      maxDistance: 40.0,
      volumeDb: 0,
      pitchScale: 1.0,
      autoplay: false,
      loop: false,
      channel: 'SFX',
      attenuation: 'inverse',
      dopplerEffect: false,
      soundFX: 'none',
      fxGain: 40,
      fxRoomSize: 65,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'stream', label: 'Audio Stream', type: 'file', category: 'Stream', defaultValue: 'res://audio/sfx_spatial.wav' },
      { key: 'unitSize', label: 'Unit Size', type: 'float', category: '3D Attenuation', defaultValue: 10.0 },
      { key: 'maxDistance', label: 'Max Distance', type: 'float', category: '3D Attenuation', defaultValue: 40.0 },
      {
        key: 'attenuation',
        label: 'Attenuation Curve',
        type: 'enum',
        category: '3D Attenuation',
        defaultValue: 'inverse',
        options: [{ label: 'Inverse', value: 'inverse' }, { label: 'Linear', value: 'linear' }, { label: 'Exponential', value: 'exponential' }],
      },
      { key: 'dopplerEffect', label: 'Doppler Effect', type: 'boolean', category: '3D Attenuation', defaultValue: false },
      { key: 'volumeDb', label: 'Volume (dB)', type: 'float', category: 'Audio', defaultValue: 0, min: -40, max: 6 },
      { key: 'pitchScale', label: 'Pitch Scale', type: 'float', category: 'Audio', defaultValue: 1.0, min: 0.1, max: 4.0 },
      { key: 'channel', label: 'Mixer Channel', type: 'enum', category: 'Audio', defaultValue: 'SFX', options: [{ label: 'Master', value: 'Master' }, { label: 'Music', value: 'Music' }, { label: 'SFX', value: 'SFX' }, { label: 'Ambience', value: 'Ambience' }] },
      { key: 'autoplay', label: 'Autoplay', type: 'boolean', category: 'Playback', defaultValue: false },
      { key: 'soundFX', label: 'Sound Effect', type: 'enum', category: 'Effects', defaultValue: 'none', options: [{ label: 'None', value: 'none' }, { label: 'Reverb', value: 'reverb' }, { label: 'Echo', value: 'echo' }, { label: 'Low-pass', value: 'lowpass' }, { label: 'Distortion', value: 'distortion' }] },
      { key: 'fxGain', label: 'Effect Amount (%)', type: 'float', category: 'Effects', defaultValue: 40, min: 0, max: 100, step: 1, visibleWhen: (p) => (p.soundFX ?? 'none') !== 'none' },
      { key: 'fxRoomSize', label: 'Room / Delay Size (%)', type: 'float', category: 'Effects', defaultValue: 65, min: 0, max: 100, step: 1, visibleWhen: (p) => p.soundFX === 'reverb' || p.soundFX === 'echo' },
      { key: 'loop', label: 'Loop', type: 'boolean', category: 'Playback', defaultValue: false },
    ],
    availableSignals: ['finished'],
  },

  ParticleSystem: {
    type: 'ParticleSystem',
    name: 'ParticleSystem',
    category: '3D',
    createCategory: 'Special',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Generates 3D animated particle effects like fire, smoke, rain, snow, sparks, and magic.',
    icon: 'Sparkles',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      ...PARTICLE_DEFAULTS,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'scale', label: 'Scale', type: 'vector3', category: 'Transform', defaultValue: { x: 1, y: 1, z: 1 } },
      { key: 'emitting', label: 'Emitting', type: 'boolean', category: 'Emission', defaultValue: PARTICLE_DEFAULTS.emitting },
      { key: 'emitterType', label: 'Emitter Shape', type: 'enum', category: 'Emitter', defaultValue: PARTICLE_DEFAULTS.emitterType, options: [
        { label: 'Point Emitter', value: 'point' },
        { label: 'Box / Area Emitter', value: 'box' },
        { label: 'Ring / Cylinder Emitter', value: 'ring' },
        { label: 'Sphere Emitter', value: 'sphere' },
      ]},
      { key: 'emitterRadius', label: 'Emitter Radius (m)', type: 'float', category: 'Emitter', defaultValue: PARTICLE_DEFAULTS.emitterRadius, ...PARTICLE_LIMITS.emitterRadius, step: 0.1 },
      { key: 'emitterBoxSize', label: 'Emitter Box Size (m)', type: 'vector3', category: 'Emitter', defaultValue: PARTICLE_DEFAULTS.emitterBoxSize, ...PARTICLE_LIMITS.emitterBoxSize },
      { key: 'particlesPerSecond', label: 'Emission Rate (pts/s)', type: 'integer', category: 'Emission', defaultValue: PARTICLE_DEFAULTS.particlesPerSecond, ...PARTICLE_LIMITS.particlesPerSecond },
      { key: 'maxParticles', label: 'Max Particles', type: 'integer', category: 'Emission', defaultValue: PARTICLE_DEFAULTS.maxParticles, ...PARTICLE_LIMITS.maxParticles },
      { key: 'lifetimeMin', label: 'Min Lifetime (s)', type: 'float', category: 'Lifetime', defaultValue: PARTICLE_DEFAULTS.lifetimeMin, ...PARTICLE_LIMITS.lifetimeMin },
      { key: 'lifetimeMax', label: 'Max Lifetime (s)', type: 'float', category: 'Lifetime', defaultValue: PARTICLE_DEFAULTS.lifetimeMax, ...PARTICLE_LIMITS.lifetimeMax },
      { key: 'direction', label: 'Direction Vector', type: 'vector3', category: 'Physics', defaultValue: PARTICLE_DEFAULTS.direction },
      { key: 'maxAngleDeviation', label: 'Cone Angle Spread (°)', type: 'float', category: 'Physics', defaultValue: PARTICLE_DEFAULTS.maxAngleDeviation, ...PARTICLE_LIMITS.maxAngleDeviation },
      { key: 'speedMin', label: 'Min Speed', type: 'float', category: 'Physics', defaultValue: PARTICLE_DEFAULTS.speedMin, ...PARTICLE_LIMITS.speedMin },
      { key: 'speedMax', label: 'Max Speed', type: 'float', category: 'Physics', defaultValue: PARTICLE_DEFAULTS.speedMax, ...PARTICLE_LIMITS.speedMax },
      { key: 'gravity', label: 'Gravity Vector', type: 'vector3', category: 'Physics', defaultValue: PARTICLE_DEFAULTS.gravity, ...PARTICLE_LIMITS.gravity },
      { key: 'startColor', label: 'Start Color', type: 'color', category: 'Appearance', defaultValue: PARTICLE_DEFAULTS.startColor },
      { key: 'endColor', label: 'End / Fade Color', type: 'color', category: 'Appearance', defaultValue: PARTICLE_DEFAULTS.endColor },
      { key: 'startSize', label: 'Start Size (m)', type: 'float', category: 'Appearance', defaultValue: PARTICLE_DEFAULTS.startSize, ...PARTICLE_LIMITS.startSize },
      { key: 'endSize', label: 'End Size (m)', type: 'float', category: 'Appearance', defaultValue: PARTICLE_DEFAULTS.endSize, ...PARTICLE_LIMITS.endSize },
      { key: 'fadeOut', label: 'Fade Out Over Life', type: 'boolean', category: 'Appearance', defaultValue: PARTICLE_DEFAULTS.fadeOut },
      { key: 'blending', label: 'Blend Mode', type: 'enum', category: 'Rendering', defaultValue: PARTICLE_DEFAULTS.blending, options: [
        { label: 'Additive (Glow/Fire/Sparks)', value: 'additive' },
        { label: 'Alpha Blend (Translucent/Smoke)', value: 'alpha' },
        { label: 'Multiply / Modulate', value: 'modulate' },
      ]},
      { key: 'texture', label: 'Texture', type: 'enum', category: 'Rendering', defaultValue: PARTICLE_DEFAULTS.texture, options: [
        { label: 'Glow', value: 'glow' },
        { label: 'Flame', value: 'flame' },
        { label: 'Smoke', value: 'smoke' },
        { label: 'Spark', value: 'spark' },
        { label: 'Drop', value: 'drop' },
        { label: 'Snow', value: 'snow' },
        { label: 'Star', value: 'star' },
      ]},
      { key: 'presetId', label: 'Preset', type: 'string', category: 'Origin', defaultValue: PARTICLE_DEFAULTS.presetId, description: 'Preset de origem (marca informativa; os valores vivem no nó).', visibleWhen: () => false /* o Inspector escolhe o preset pelo dropdown (AIS-23) */ },
      { key: 'seed', label: 'Seed', type: 'integer', category: 'Origin', defaultValue: PARTICLE_DEFAULTS.seed, ...PARTICLE_LIMITS.seed },
    ],
    availableSignals: ['started', 'finished'],
  },

  Timer: {
    type: 'Timer',
    name: 'Timer',
    category: 'Misc',
    createCategory: 'Special',
    is2D: false,
    is3D: false,
    isUI: false,
    description: 'Counts down a specified interval and fires timeout event.',
    icon: 'Timer',
    defaultProperties: {
      waitTime: 1.0,
      oneShot: false,
      autostart: true,
    },
    propertyDescriptors: [
      { key: 'waitTime', label: 'Wait Time (sec)', type: 'float', category: 'Timer', defaultValue: 1.0, min: 0.01 },
      { key: 'oneShot', label: 'One Shot', type: 'boolean', category: 'Timer', defaultValue: false },
      { key: 'autostart', label: 'Autostart', type: 'boolean', category: 'Timer', defaultValue: true },
    ],
    availableSignals: ['timeout'],
  },

  // AIS-50 (decisão 23): terreno de primeira classe; geometria no CPU (`src/core/terrainGeometry.ts`), colisão = heightfield do mesmo buffer.
  Terrain: {
    type: 'Terrain',
    name: 'Terrain',
    category: '3D',
    createCategory: 'Environment',
    singleton: true,
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Terreno procedural ou por heightmap (geometria calculada no CPU, splatmap de 3 camadas por altitude, colisão heightfield).',
    icon: 'Mountain',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      visible: true,
      // Dimensões
      width: 120,
      depth: 120,
      segmentsW: 128,
      segmentsH: 128,
      maxHeight: 24,
      // Heightmap (`ResourceRef` de imagem em res://textures/) e escultura (`.height`, escrito pelo AIS-50b; aqui só é lido)
      heightmapRef: null,
      invertHeightmap: false,
      smoothHeightmap: true,
      heightBufferRef: null,
      // Preset procedural (quando não há heightmap)
      terrainPreset: 'flat',
      presetSeed: 0,
      // Splatmap: 3 camadas por altitude relativa
      groundTexture: 'Grass_Green',
      midTexture: 'Rock_Cliff',
      highTexture: 'Snow_Mountain',
      textureTiling: 16,
      blendSharpness: 0.5,
      // Colisão é do objeto (decisão 26): `auto` = heightfield do MESMO buffer
      physics: { enabled: true, bodyMode: 'static', shape: 'auto' },
    },
    // Marca de origem (AIS-49b): `params` mínimo, as propriedades do nó são a fonte de verdade (como o Particle, emenda v5.1.3)
    defaultGeneratorSource: { generatorId: 'terrain', version: 1, params: { preset: 'flat' }, seed: 0 },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'scale', label: 'Scale', type: 'vector3', category: 'Transform', defaultValue: { x: 1, y: 1, z: 1 } },
      { key: 'width', label: 'Width (m)', type: 'float', category: 'Terrain Dimensions', defaultValue: 120, min: 1, max: 4000, step: 1 },
      { key: 'depth', label: 'Depth (m)', type: 'float', category: 'Terrain Dimensions', defaultValue: 120, min: 1, max: 4000, step: 1 },
      { key: 'segmentsW', label: 'Segments W', type: 'enum', category: 'Terrain Dimensions', defaultValue: 128, options: [32, 64, 128, 256].map((v) => ({ label: String(v), value: v })) },
      { key: 'segmentsH', label: 'Segments H', type: 'enum', category: 'Terrain Dimensions', defaultValue: 128, options: [32, 64, 128, 256].map((v) => ({ label: String(v), value: v })) },
      { key: 'maxHeight', label: 'Max Height (m)', type: 'float', category: 'Terrain Dimensions', defaultValue: 24, min: 0.1, max: 1000, step: 1 },
      // O picker, "Limpar", "Regerar" e "Abrir Editor de Terreno" ficam na seção "Terrain" do Inspector (TerrainSection)
      { key: 'heightmapRef', label: 'Heightmap', type: 'resource', category: 'Heightmap', defaultValue: null, visibleWhen: () => false, description: 'PNG/JPG grayscale de res://textures/ (canal R = altura).' },
      { key: 'invertHeightmap', label: 'Invert Heightmap', type: 'boolean', category: 'Heightmap', defaultValue: false, visibleWhen: (p) => !!p.heightmapRef },
      { key: 'smoothHeightmap', label: 'Smooth Heightmap', type: 'boolean', category: 'Heightmap', defaultValue: true, visibleWhen: (p) => !!p.heightmapRef },
      { key: 'heightBufferRef', label: 'Sculpted Heights (.height)', type: 'resource', category: 'Heightmap', defaultValue: null, visibleWhen: () => false, description: 'Buffer de alturas esculpido (res://terrain/<nome>.height), escrito pelo AIS-50b.' },
      {
        key: 'terrainPreset',
        label: 'Terrain Preset',
        type: 'enum',
        category: 'Terrain Preset',
        defaultValue: 'flat',
        visibleWhen: (p) => !p.heightmapRef && !p.heightBufferRef,
        options: [
          { label: 'Plano', value: 'flat' },
          { label: 'Colinas', value: 'hills' },
          { label: 'Montanhas', value: 'mountains' },
          { label: 'Deserto', value: 'desert' },
          { label: 'Canyon', value: 'canyon' },
        ],
      },
      { key: 'presetSeed', label: 'Preset Seed', type: 'integer', category: 'Terrain Preset', defaultValue: 0, step: 1, visibleWhen: (p) => !p.heightmapRef && !p.heightBufferRef },
      { key: 'groundTexture', label: 'Ground Texture', type: 'enum', category: 'Terrain Materials', defaultValue: 'Grass_Green', options: ['Grass_Green', 'Sand_Desert', 'Dirt_Soil', 'Pebbles_Gravel'].map((v) => ({ label: v.replace('_', ' '), value: v })) },
      { key: 'midTexture', label: 'Mid Texture', type: 'enum', category: 'Terrain Materials', defaultValue: 'Rock_Cliff', options: ['Rock_Cliff', 'Granite_Rough', 'Dry_Dirt'].map((v) => ({ label: v.replace('_', ' '), value: v })) },
      { key: 'highTexture', label: 'High Texture', type: 'enum', category: 'Terrain Materials', defaultValue: 'Snow_Mountain', options: ['Snow_Mountain', 'Bare_Rock', 'Ice_Glacier'].map((v) => ({ label: v.replace('_', ' '), value: v })) },
      { key: 'textureTiling', label: 'Texture Tiling', type: 'float', category: 'Terrain Materials', defaultValue: 16, min: 1, max: 256, step: 1 },
      { key: 'blendSharpness', label: 'Blend Sharpness', type: 'float', category: 'Terrain Materials', defaultValue: 0.5, min: 0, max: 1, step: 0.05 },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'Rendering', defaultValue: true },
    ],
    availableSignals: [],
  },

  // AIS-68: superfície de água (plano XZ; o nível é a posição Y). `properties` é a fonte da verdade; presets só preenchem os campos.
  // Desenho/ondulação/reflexo: `src/core/water/` (fábrica única do Viewport e do Play). Flutuação: `PhysicsHost` + `buoyancy.ts`.
  WaterPlane: {
    type: 'WaterPlane',
    name: 'WaterPlane',
    category: '3D',
    createCategory: 'Environment',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Superfície de água com ondulação procedural, reflexo planar em tempo real (ou barato, só do ambiente), transparência e flutuação simples de corpos dinâmicos.',
    icon: 'Waves',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      visible: true,
      width: 100,
      depth: 100,
      color: { r: 0.04, g: 0.22, b: 0.3, a: 1 },
      transparency: 0.15,
      waveScale: 1,
      waveSpeed: 0.3,
      waveStrength: 0.5,
      flowDirection: 0,
      reflectionMode: 'planar',
      reflectionIntensity: 0.9,
      reflectionResolution: 512,
      buoyancy: 1,
      drag: 2.5,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation (Y = nível da água)', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'scale', label: 'Scale', type: 'vector3', category: 'Transform', defaultValue: { x: 1, y: 1, z: 1 } },
      { key: 'width', label: 'Width (m)', type: 'float', category: 'Water Size', defaultValue: 100, min: 0.1, max: 10000, step: 1 },
      { key: 'depth', label: 'Depth (m)', type: 'float', category: 'Water Size', defaultValue: 100, min: 0.1, max: 10000, step: 1 },
      { key: 'color', label: 'Base Color', type: 'color', category: 'Water Surface', defaultValue: { r: 0.04, g: 0.22, b: 0.3, a: 1 } },
      { key: 'transparency', label: 'Transparency', type: 'float', category: 'Water Surface', defaultValue: 0.15, min: 0, max: 1, step: 0.01 },
      { key: 'waveScale', label: 'Wave Scale', type: 'float', category: 'Waves', defaultValue: 1, min: 0.05, max: 20, step: 0.05 },
      { key: 'waveSpeed', label: 'Wave Speed', type: 'float', category: 'Waves', defaultValue: 0.3, min: 0, max: 10, step: 0.05 },
      { key: 'waveStrength', label: 'Wave Strength', type: 'float', category: 'Waves', defaultValue: 0.5, min: 0, max: 10, step: 0.05 },
      { key: 'flowDirection', label: 'Flow Direction (°)', type: 'float', category: 'Waves', defaultValue: 0, min: -360, max: 360, step: 1 },
      {
        key: 'reflectionMode',
        label: 'Reflection',
        type: 'enum',
        category: 'Reflection',
        defaultValue: 'planar',
        description: 'Planar renderiza a cena de novo por quadro (caro); Ambiente reflete só o HDRI/Skybox ativo (barato).',
        options: [
          { label: 'Planar (tempo real, caro)', value: 'planar' },
          { label: 'Ambiente (barato)', value: 'environment' },
          { label: 'Sem reflexo', value: 'off' },
        ],
      },
      { key: 'reflectionIntensity', label: 'Reflection Intensity', type: 'float', category: 'Reflection', defaultValue: 0.9, min: 0, max: 1, step: 0.01, visibleWhen: (p) => p.reflectionMode !== 'off' },
      {
        key: 'reflectionResolution',
        label: 'Reflection Resolution',
        type: 'enum',
        category: 'Reflection',
        defaultValue: 512,
        visibleWhen: (p) => (p.reflectionMode ?? 'planar') === 'planar',
        options: [256, 512, 1024].map((v) => ({ label: `${v} px`, value: v })),
      },
      { key: 'buoyancy', label: 'Buoyancy', type: 'float', category: 'Floating Bodies', defaultValue: 1, min: 0, max: 10, step: 0.1, description: 'Corpos dynamic com "Flutua na água" (Colisão). 1 = metade submerso.' },
      { key: 'drag', label: 'Water Drag', type: 'float', category: 'Floating Bodies', defaultValue: 2.5, min: 0, max: 20, step: 0.1 },
      // o seletor de preset (Lago/Rio/Oceano + arquivos do projeto) fica na seção "Água" do Inspector (WaterSection); o preset atual é derivado dos campos
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'Rendering', defaultValue: true },
    ],
    availableSignals: [],
  },

  // AIS-51d: floresta sobre o terreno. Filho de um `Terrain`; guarda a ÁRVORE-FONTE + seed + parâmetros (nunca a lista de matrizes).
  // As posições saem de `scatterVegetation` (src/core/vegetation) sobre o buffer CPU de alturas do pai; desenho = `InstancedMesh` por tile.
  // Criado pela distribuição (TreeEditorModal / aba Vegetação / arrastar Prefab), não pelo diálogo de criação.
  Vegetation: {
    type: 'Vegetation',
    name: 'Vegetation',
    category: '3D',
    createCategory: 'Environment',
    creatable: false,
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Árvores distribuídas sobre o terreno pai (InstancedMesh por tile, seed determinística, colisão: um cilindro por tronco).',
    icon: 'TreePine',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      visible: true,
      treeSource: null,
      count: 60,
      seed: 1,
      variants: 3,
      scaleMin: 0.8,
      scaleMax: 1.3,
      maxSlope: 35,
      altitudeMin: 0,
      altitudeMax: 0.7,
      margin: 3,
      minSpacing: 3,
      castShadow: true,
      receiveShadow: true,
      // um corpo estático com N cilindros (decisão 26, emenda v5.5); desligar a colisão = o jogador atravessa a floresta
      physics: { enabled: true, bodyMode: 'static', shape: 'auto' },
    },
    propertyDescriptors: [
      { key: 'count', label: 'Quantidade', type: 'integer', category: 'Vegetação', defaultValue: 60, min: 1, max: 2000, step: 1 },
      { key: 'seed', label: 'Seed', type: 'integer', category: 'Vegetação', defaultValue: 1, step: 1 },
      { key: 'variants', label: 'Variações de árvore', type: 'integer', category: 'Vegetação', defaultValue: 3, min: 1, max: 6, step: 1 },
      { key: 'scaleMin', label: 'Escala mínima', type: 'float', category: 'Vegetação', defaultValue: 0.8, min: 0.05, max: 20, step: 0.05 },
      { key: 'scaleMax', label: 'Escala máxima', type: 'float', category: 'Vegetação', defaultValue: 1.3, min: 0.05, max: 20, step: 0.05 },
      { key: 'maxSlope', label: 'Inclinação máxima (°)', type: 'float', category: 'Vegetação', defaultValue: 35, min: 0, max: 90, step: 1 },
      { key: 'altitudeMin', label: 'Altitude mínima (0–1)', type: 'float', category: 'Vegetação', defaultValue: 0, min: 0, max: 1, step: 0.05 },
      { key: 'altitudeMax', label: 'Altitude máxima (0–1)', type: 'float', category: 'Vegetação', defaultValue: 0.7, min: 0, max: 1, step: 0.05 },
      { key: 'margin', label: 'Margem da borda (m)', type: 'float', category: 'Vegetação', defaultValue: 3, min: 0, max: 1000, step: 0.5 },
      { key: 'minSpacing', label: 'Espaçamento mínimo (m)', type: 'float', category: 'Vegetação', defaultValue: 3, min: 0, max: 1000, step: 0.5 },
      { key: 'castShadow', label: 'Cast Shadow', type: 'boolean', category: 'Rendering', defaultValue: true },
      { key: 'receiveShadow', label: 'Receive Shadow', type: 'boolean', category: 'Rendering', defaultValue: true },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'Rendering', defaultValue: true },
    ],
    availableSignals: [],
  },

  // Nó de tipo ausente nesta versão do editor (AIS-18d): preservado e regravado intacto.
  Missing: {
    type: 'Missing',
    name: 'Missing Node',
    category: 'Misc',
    createCategory: 'Special',
    creatable: false,
    is2D: false,
    is3D: false,
    isUI: false,
    description: 'Tipo ausente nesta versão do editor; dados preservados.',
    icon: 'AlertTriangle',
    defaultProperties: {},
    propertyDescriptors: [], // o Inspector mostra o tipo original (somente leitura)
    availableSignals: [],
  },
});

/**
 * Registro único dos tipos de nó. `NodeType` é derivado das chaves; o schema Zod e o diálogo de
 * criação leem daqui. Tipo novo = uma entrada nova neste objeto (decisão 19).
 */
export const NODE_REGISTRY: Record<NodeType, NodeTypeMetadata> = NODE_DEFINITIONS;

/** AIS-56: o nó já existente de um tipo `singleton` (no máximo um por cena), ou `undefined` (tipo comum ou ainda não há). */
export function findSingletonNode(nodes: Readonly<Record<string, GameNode>>, type: NodeType): GameNode | undefined {
  if (!NODE_DEFINITIONS[type]?.singleton) return undefined;
  return Object.values(nodes).find((n) => n.type === type);
}

export function getNodeMetadata(type: NodeType): NodeTypeMetadata {
  return (
    NODE_REGISTRY[type] || {
      type,
      name: type,
      category: 'Core',
      is2D: false,
      is3D: true,
      isUI: false,
      description: 'Node of type ' + type,
      icon: 'Circle',
      defaultProperties: {},
      propertyDescriptors: [],
      availableSignals: [],
    }
  );
}

/**
 * `initialProperties` é mesclado sobre os defaults do tipo (cópia profunda) antes de o nó existir:
 * quem grava o nó (Command de criação) já o recebe completo, sem mutação posterior (AIS-18c).
 */
export function createDefaultNode(
  type: NodeType,
  customName?: string,
  parentId: string | null = null,
  initialProperties?: Record<string, any>,
  /** AIS-56: nós existentes da cena; o id gerado nunca colide com eles (nunca sobrescreve um nó). */
  existingNodes?: Readonly<Record<string, unknown>>
): GameNode {
  const meta = getNodeMetadata(type);
  const makeId = () => `${type.toLowerCase()}_${Math.random().toString(36).substring(2, 9)}`;
  let id = makeId();
  while (existingNodes && id in existingNodes) id = makeId();
  const name = customName || `${type}`;

  return {
    id,
    name,
    type,
    parentId,
    childrenIds: [],
    visible: true,
    locked: false,
    properties: {
      ...JSON.parse(JSON.stringify(meta.defaultProperties)),
      ...(initialProperties ? JSON.parse(JSON.stringify(initialProperties)) : {}),
    },
    signals: [],
    behaviors: [],
    ...(meta.defaultGeneratorSource ? { generatorSource: JSON.parse(JSON.stringify(meta.defaultGeneratorSource)) } : {}),
  };
}
