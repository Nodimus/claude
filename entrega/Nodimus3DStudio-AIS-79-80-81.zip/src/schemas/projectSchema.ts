import { z } from 'zod';
import { ProjectSettingsV1Schema } from './v1/project.schema';
import { CURRENT_PROJECT_SCHEMA_VERSION } from '../core/persistenceVersions';

/**
 * Checks whether a given path is an absolute OS path.
 * Matches:
 * - Windows drives: "C:\...", "D:/..."
 * - UNC paths: "\\server\...", "//server/..."
 * - Unix absolute paths: "/Users/...", "/home/..."
 */
export function isAbsoluteSystemPath(path: string): boolean {
  if (!path || typeof path !== 'string') return false;
  const trimmed = path.trim();
  // Windows drive letter
  if (/^[a-zA-Z]:[/\\]/.test(trimmed)) return true;
  // UNC path
  if (/^\\\\[^\\]/.test(trimmed) || /^\/\/[^/]/.test(trimmed)) return true;
  // Unix root path (excluding res:// and other virtual protocols)
  if (trimmed.startsWith('/') && !trimmed.startsWith('//') && !trimmed.includes('://')) return true;
  return false;
}

/**
 * Normalizes any path to a valid project-relative path.
 * If given an absolute system path, strips parent directories or transforms to res://
 */
export function normalizeToProjectPath(path: string, defaultFolder = 'res'): string {
  if (!path) return '';
  const trimmed = path.trim().replace(/\\/g, '/');

  if (trimmed.startsWith('res://')) {
    return trimmed;
  }

  if (isAbsoluteSystemPath(trimmed)) {
    // Extract asset subfolder if found, e.g. /path/to/res/scenes/Main.scene.json -> res://scenes/Main.scene.json
    const resIdx = trimmed.indexOf('/res/');
    if (resIdx !== -1) {
      return 'res://' + trimmed.slice(resIdx + 5);
    }
    const filename = trimmed.split('/').pop() || 'asset';
    return `res://${defaultFolder}/${filename}`;
  }

  // Relative path: e.g. "scenes/Main.scene.json" -> "res://scenes/Main.scene.json"
  if (trimmed.startsWith('./')) {
    return `res://${trimmed.slice(2)}`;
  }
  if (!trimmed.startsWith('res://')) {
    return `res://${trimmed}`;
  }

  return trimmed;
}

/**
 * Zod validator ensuring path is NOT an absolute system path
 */
export const ProjectPathSchema = z
  .string()
  .min(1, 'Path cannot be empty')
  .refine((val) => !isAbsoluteSystemPath(val), {
    message: 'Absolute system paths are prohibited. Path must be project-relative or use "res://"',
  });

export const ProjectSceneEntrySchema = z
  .object({
    id: z.string().min(1, 'Scene ID is required and must be a stable UUID'),
    name: z.string().min(1, 'Scene name is required'),
    path: ProjectPathSchema,
    isStartScene: z.boolean().optional(),
  })
  .passthrough();

export const ProjectGlobalVariableSchema = z
  .object({
    id: z.string().min(1, 'Variable ID is required'),
    name: z.string().min(1, 'Variable name is required'),
    type: z.enum(['string', 'number', 'boolean', 'vector2', 'vector3', 'color', 'any']).default('string'),
    value: z.any(),
    description: z.string().optional(),
  })
  .passthrough();

/**
 * Schema for project.json
 * v4.7.0: there is no `addons` field anymore. A legacy `addons` array from an
 * older project.json is preserved as an unknown field by `.passthrough()`.
 */
export const ProjectFileSchema = z
  .object({
    schemaVersion: z.number().int().min(1, 'schemaVersion must be an integer >= 1').default(CURRENT_PROJECT_SCHEMA_VERSION),
    projectId: z.string().min(1, 'projectId must be a stable, non-empty identifier'),
    name: z.string().min(1, 'Project name is required'),
    appId: z.string().min(1, 'appId is required'),
    engineVersion: z.string().default('1.0.0'),
    startSceneId: z.string().min(1, 'startSceneId is required'),
    scenes: z.array(ProjectSceneEntrySchema).min(1, 'Project must contain at least one scene'),
    globalVariables: z.array(ProjectGlobalVariableSchema).default([]),
    inputMap: z.union([z.record(z.string(), z.any()), z.array(z.any())]).default([]),
    settings: ProjectSettingsV1Schema,
    metadata: z.record(z.string(), z.unknown()).optional().default({}),
    createdAt: z.string().optional().default(() => new Date().toISOString()),
    updatedAt: z.string().optional().default(() => new Date().toISOString()),
  })
  .passthrough();

export type ProjectFileValidated = z.infer<typeof ProjectFileSchema>;
