import { describe, expect, it } from 'vitest';
import { createEmptySpriteProject, createBlankSpriteProject } from '../utils/spritePresets';
import { validateSprite } from './index';
import { gridFrames, normalizeSprite, parseSpriteJson, serializeSprite, toPersistedSprite } from './spriteNormalize';
import { clipFrameIndexAtTime } from '../runtime/sprite';

/** AIS-76-C03/C04 — formatos legados normalizados sem perda; v1 sem base64; arquivo inválido devolve erro (e o chamador não grava). */

const PNG = 'data:image/png;base64,iVBORw0KGgo=';

describe('SpriteProject v1', () => {
  it('createEmptySpriteProject é canônico: valida, 1 animação de 1 frame, sem atlas e sem base64', () => {
    const p = createEmptySpriteProject('Hero');
    expect(p.frames).toHaveLength(1);
    expect(p.animations[0]).toMatchObject({ frameIndices: [0], loopMode: 'loop' });
    expect(p.sheetConfig.texture).toBeUndefined();
    expect(validateSprite(JSON.parse(serializeSprite(p))).success).toBe(true);
  });

  it('serializa SEM imageUrl nem customDataUrl (nunca base64 em JSON) e reabre igual', () => {
    const p = createEmptySpriteProject('Hero');
    p.sheetConfig.imageUrl = PNG;
    p.frames[0].customDataUrl = PNG;
    const text = serializeSprite(p);
    expect(text).not.toContain('data:');
    expect(text).not.toContain('imageUrl');
    expect(text).not.toContain('customDataUrl');
    const back = parseSpriteJson(text);
    expect(back.ok && back.format).toBe('v1');
    if (back.ok) {
      expect(back.readOnly).toBe(false);
      expect(back.project.name).toBe('Hero');
      expect(back.project.frames[0]).not.toHaveProperty('customDataUrl');
    }
  });

  it('frameDurations e a referência do atlas sobrevivem ao ida-e-volta', () => {
    const p = createEmptySpriteProject('Hero');
    p.sheetConfig.texture = { id: 'res_1', type: 'texture', path: 'res://textures/Hero.png' };
    p.animations[0] = { ...p.animations[0], frameIndices: [0, 0, 0], frameDurations: [1, 2, 3] };
    const back = parseSpriteJson(serializeSprite(p));
    expect(back.ok).toBe(true);
    if (back.ok) {
      expect(back.project.sheetConfig.texture).toMatchObject({ id: 'res_1', path: 'res://textures/Hero.png' });
      expect(back.project.animations[0].frameDurations).toEqual([1, 2, 3]);
    }
  });

  it('o JSON v1 não usa durationMs em frames novos', () => {
    expect(serializeSprite(createEmptySpriteProject('Hero'))).not.toContain('durationMs');
  });

  it('chaves desconhecidas da raiz são preservadas (versões futuras/ferramentas externas)', () => {
    const raw = { ...JSON.parse(serializeSprite(createEmptySpriteProject('Hero'))), custom: { a: 1 } };
    const r = normalizeSprite(raw);
    expect(r.ok).toBe(true);
    if (r.ok) expect((r.project as any).custom).toEqual({ a: 1 });
  });
});

describe('formatos legados (§3.3)', () => {
  it('1) SpriteProject completo da casca: base64 vira estado de sessão e some do JSON', () => {
    const legacy = {
      id: 'sprite_1',
      name: 'Knight',
      sheetConfig: { name: 'Knight', imageUrl: PNG, imageWidth: 64, imageHeight: 32, frameWidth: 32, frameHeight: 32, columns: 2, rows: 1, spacing: 0, margin: 0, totalFrames: 2 },
      frames: [
        { id: 'f0', index: 0, x: 0, y: 0, width: 32, height: 32, durationMs: 100 },
        { id: 'f1', index: 1, x: 32, y: 0, width: 32, height: 32, durationMs: 100, customDataUrl: PNG },
      ],
      animations: [{ id: 'a', name: 'idle', frameIndices: [1, 0], fps: 6, loopMode: 'ping-pong' }],
      activeAnimationId: 'a',
      currentFrameIndex: 1,
      settings3D: { billboardMode: 'cylindrical_y', renderScale: { x: 2, y: 3 }, pixelPerfectFilter: false, tintColor: { r: 1, g: 0, b: 0, a: 1 }, emissiveColor: '#112233', emissiveIntensity: 0.5, alphaTest: 0.3, doubleSided: false, castShadow: false, receiveShadow: true, turntableSpeed: 2, environmentLighting: 'night', showGroundGrid: false, showPixelWireframe: true },
      palette: ['#000000'],
    };
    const r = normalizeSprite(legacy);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.format).toBe('full');
    expect(r.session.atlas).toBe(PNG);
    expect(r.session.frames).toEqual({ f1: PNG });
    // sem perda de dados
    expect(r.project.animations[0]).toMatchObject({ frameIndices: [1, 0], fps: 6, loopMode: 'ping-pong' });
    expect(r.project.settings3D).toMatchObject({ billboardMode: 'cylindrical_y', renderScale: { x: 2, y: 3 }, environmentLighting: 'night', showPixelWireframe: true });
    expect(r.project.frames[0].durationMs).toBe(100); // legado lido
    expect(r.project.currentFrameIndex).toBe(1);
    expect(r.project.palette).toEqual(['#000000']);
    expect(serializeSprite(r.project)).not.toContain('data:');
  });

  it('2) amostra do defaultProject: texturePath → texture, mapa → animations com frameIndices expandidos, loop → loopMode', () => {
    const r = normalizeSprite({
      name: 'Character_Idle',
      texturePath: 'res://textures/player_spritesheet.png',
      frameWidth: 32,
      frameHeight: 32,
      frameCount: 6,
      fps: 10,
      loop: true,
      animations: { idle: { startFrame: 0, endFrame: 5, fps: 10, loop: true }, hit: { startFrame: 2, endFrame: 3, fps: 4, loop: false } },
    });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.format).toBe('sample');
    expect(r.project.sheetConfig.texture).toMatchObject({ type: 'texture', path: 'res://textures/player_spritesheet.png' });
    expect(r.project.frames).toHaveLength(6);
    expect(r.project.animations.map((a) => [a.name, a.frameIndices, a.fps, a.loopMode])).toEqual([
      ['idle', [0, 1, 2, 3, 4, 5], 10, 'loop'],
      ['hit', [2, 3], 4, 'once'],
    ]);
    expect(r.project.activeAnimationId).toBe(r.project.animations[0].id);
    expect(validateSprite(JSON.parse(serializeSprite(r.project))).success).toBe(true);
  });

  it('2b) amostra sem mapa de animações: uma animação com todos os frames, loop false → once', () => {
    const r = normalizeSprite({ texturePath: 'res://textures/a.png', frameWidth: 16, frameHeight: 16, frameCount: 3, fps: 12, loop: false });
    expect(r.ok && r.project.animations).toMatchObject([{ frameIndices: [0, 1, 2], fps: 12, loopMode: 'once' }]);
  });

  it('3) stub do "Novo Sprite" antigo: completado com id, frames da grade e settings3D', () => {
    const r = normalizeSprite({ name: 'Slime', sheetConfig: { frameWidth: 32, frameHeight: 32, columns: 4, rows: 1 }, animations: [{ id: 'anim_idle', name: 'idle', fps: 8, loopMode: 'loop', frameIndices: [0, 1, 2, 3] }] });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.format).toBe('stub');
    expect(r.project.id).toBeTruthy();
    expect(r.project.frames.map((f) => f.x)).toEqual([0, 32, 64, 96]);
    expect(r.project.animations[0]).toMatchObject({ id: 'anim_idle', frameIndices: [0, 1, 2, 3] });
    expect(r.project.settings3D.billboardMode).toBe('spherical');
    expect(validateSprite(JSON.parse(serializeSprite(r.project))).success).toBe(true);
  });

  it('versão FUTURA: aberta somente para leitura e nunca rebaixada', () => {
    const future = { ...JSON.parse(serializeSprite(createEmptySpriteProject('F'))), schemaVersion: 7, novidade: true };
    const r = normalizeSprite(future);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.readOnly).toBe(true);
      expect(r.project.schemaVersion).toBe(7);
      expect((r.project as any).novidade).toBe(true);
    }
  });
});

describe('arquivo inválido', () => {
  it('JSON ilegível, tipo errado e formato desconhecido devolvem erro legível', () => {
    expect(parseSpriteJson('{ quebrado')).toMatchObject({ ok: false });
    expect(normalizeSprite([])).toMatchObject({ ok: false });
    expect(normalizeSprite(null)).toMatchObject({ ok: false });
    expect(normalizeSprite({ foo: 1 })).toMatchObject({ ok: false });
    const bad = normalizeSprite({ ...JSON.parse(serializeSprite(createEmptySpriteProject('X'))), frames: 'nope' });
    expect(bad.ok).toBe(false);
    if (!bad.ok) expect(bad.error).toMatch(/frames/);
  });
  it('toPersistedSprite lança em projeto de sessão inconsistente (nunca grava lixo)', () => {
    const p = createEmptySpriteProject('X');
    p.sheetConfig.frameWidth = 0;
    expect(() => toPersistedSprite(p)).toThrow(/Sprite inválido/);
  });
});

describe('gridFrames (Convert to Frames)', () => {
  it('grade 4×4 gera 16 regiões em ordem de linha; spacing e margin deslocam', () => {
    const f = gridFrames(4, 4, 16, 16);
    expect(f).toHaveLength(16);
    expect(f[5]).toMatchObject({ index: 5, x: 16, y: 16, width: 16, height: 16 });
    const g = gridFrames(2, 2, 10, 10, 2, 3);
    expect(g.map((r) => [r.x, r.y])).toEqual([[3, 3], [15, 3], [3, 15], [15, 15]]);
  });
  it('quantidade menor que a grade corta no fim', () => {
    expect(gridFrames(4, 4, 8, 8, 0, 0, 10)).toHaveLength(10);
  });
  it('animação com frameIndices fora de ordem usa índices globais no player canônico', () => {
    const f = gridFrames(4, 4, 8, 8);
    const anim = { frameIndices: [15, 3, 3, 0], fps: 10, loopMode: 'loop' as const };
    expect([0, 100, 200, 300].map((t) => f[clipFrameIndexAtTime(anim, t)].index)).toEqual([15, 3, 3, 0]);
  });
});

// createBlankSpriteProject usa canvas: só garantimos que o módulo carrega em Node (sem executar a função)
describe('módulo', () => {
  it('spritePresets carrega em Node', () => {
    expect(typeof createBlankSpriteProject).toBe('function');
  });
});
