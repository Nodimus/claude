import { z } from 'zod';
import { tNow } from '../core/i18n';

export interface ValidationErrorIssue {
  path: string;
  message: string;
  code: string;
  expected?: string;
  received?: string;
}

export interface ValidationResult<T> {
  success: boolean;
  data?: T;
  errors?: ValidationErrorIssue[];
  formattedError?: string;
  context?: string;
}

/**
 * Converts a ZodError into structured, diagnostic validation issues.
 */
export function formatZodError(error: z.ZodError): ValidationErrorIssue[] {
  return error.issues.map((issue) => {
    const path = issue.path.length > 0 ? issue.path.join('.') : '(root)';
    const item: ValidationErrorIssue = {
      path,
      message: issue.message,
      code: issue.code,
    };

    if ('expected' in issue) {
      item.expected = String((issue as any).expected);
    }
    if ('received' in issue) {
      item.received = String((issue as any).received);
    }

    return item;
  });
}

/**
 * Formats structured validation issues into a human-readable diagnostic log.
 */
export function formatIssuesToString(context: string, issues: ValidationErrorIssue[]): string {
  const lines = [tNow('diagnosticsMsgCore.zodvalidationValidationFailedFor', { context })];
  issues.forEach((iss, index) => {
    const detail = iss.expected && iss.received ? tNow('diagnosticsMsgCore.expectedReceived', { expected: iss.expected, received: iss.received }) : '';
    lines.push(`  ${index + 1}. [${iss.path}] ${iss.message}${detail}`);
  });
  return lines.join('\n');
}

/**
 * Validates data against a Zod schema and returns a structured ValidationResult.
 */
export function validateWithDiagnostics<T>(
  schema: z.ZodSchema<T>,
  data: unknown,
  contextName = 'Entity'
): ValidationResult<T> {
  const result = schema.safeParse(data);
  if (result.success) {
    return {
      success: true,
      data: result.data,
      context: contextName,
    };
  }

  const errors = formatZodError(result.error);
  const formattedError = formatIssuesToString(contextName, errors);

  return {
    success: false,
    errors,
    formattedError,
    context: contextName,
  };
}
