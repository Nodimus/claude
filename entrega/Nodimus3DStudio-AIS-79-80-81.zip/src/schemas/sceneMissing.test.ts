import { describe, expect, it } from 'vitest';
import { validateScene, validateSceneFile, validatePrefab, missingNodesWarning } from './index';
import { withRestoredMissingNodes } from './missingNodes';
import { INVALID_SCENE_FIXTURE } from './fixtures';
import { NODE_DEFINITIONS } from '../nodes/registry';

const foo = {
  schemaVersion: 1,
  id: 'foo1',
  name: 'Foo',
  type: 'Terrain2000',
  parentId: 'root',
  childrenIds: ['child1'],
  visible: true,
  locked: false,
  properties: { size: 12, nested: { a: [1, 2] } },
  script: 'res://scripts/x.js',
  behaviors: ['b1'],
  extraField: { keep: 'me' },
};
const makeScene = () => ({
  schemaVersion: 1,
  id: 's1',
  name: 'S',
  path: 'res://scenes/S.scene.json',
  rootNodeId: 'root',
  nodes: {
    root: { id: 'root', name: 'Root', type: 'Spatial', parentId: null, childrenIds: ['foo1'], properties: {} },
    foo1: JSON.parse(JSON.stringify(foo)),
    child1: { id: 'child1', name: 'Child', type: 'Node', parentId: 'foo1', childrenIds: [], properties: {} },
  },
});

describe('Missing Node (AIS-18d)', () => {
  it('cena com tipo desconhecido carrega; filhos e hierarquia preservados', () => {
    const res = validateScene(makeScene());
    expect(res.success).toBe(true);
    const nodes = res.data!.nodes;
    expect(nodes.foo1.type).toBe('Missing');
    expect(nodes.foo1.childrenIds).toEqual(['child1']);
    expect(nodes.child1.parentId).toBe('foo1');
    expect(nodes.foo1.properties.__missing.originalType).toBe('Terrain2000');
  });

  it('tipo conhecido não vira Missing', () => {
    const res = validateScene(makeScene());
    expect(res.data!.nodes.root.type).toBe('Spatial');
    expect(res.data!.nodes.child1.type).toBe('Node');
  });

  it('round-trip: carregar → serializar mantém tipo, propriedades e campos extras', () => {
    const res = validateScene(makeScene());
    const out = withRestoredMissingNodes(res.data!);
    expect(out.nodes.foo1).toEqual(foo);
  });

  it('alterações estruturais valem sobre o original; dados continuam intactos', () => {
    const res = validateScene(makeScene());
    const scene = res.data!;
    scene.nodes.foo1 = { ...scene.nodes.foo1, name: 'Renomeado', visible: false };
    const out = withRestoredMissingNodes(scene).nodes.foo1 as any;
    expect(out.type).toBe('Terrain2000');
    expect(out.name).toBe('Renomeado');
    expect(out.visible).toBe(false);
    expect(out.properties).toEqual(foo.properties);
    expect(out.extraField).toEqual(foo.extraField);
  });

  it('SceneFile e Prefab também leem tipo desconhecido', () => {
    const s = makeScene();
    const file = validateSceneFile({ schemaVersion: 1, sceneId: 's1', name: 'S', rootNodeId: 'root', nodes: s.nodes });
    expect(file.success).toBe(true);
    expect(file.data!.nodes.foo1.type).toBe('Missing');
    const prefab = validatePrefab({ schemaVersion: 1, id: 'p', name: 'P', rootNodeId: 'root', nodes: s.nodes });
    expect(prefab.success).toBe(true);
  });

  it('aviso único com contagem e tipos; nenhum aviso sem Missing', () => {
    const res = validateScene(makeScene());
    expect(missingNodesWarning(res.data!.nodes)).toBe('1 nó(s) de tipo desconhecido preservado(s): Terrain2000');
    const clean = makeScene();
    delete (clean.nodes as any).foo1;
    clean.nodes.root.childrenIds = [];
    expect(missingNodesWarning(validateScene(clean).data!.nodes)).toBeNull();
  });

  it('fixture inválida continua inválida por motivo real (id vazio)', () => {
    expect(validateScene(INVALID_SCENE_FIXTURE).success).toBe(false);
    expect(validateScene({ ...makeScene(), nodes: { root: { ...makeScene().nodes.root, id: '' } } }).success).toBe(false);
  });

  it('Missing existe no registry', () => {
    expect(NODE_DEFINITIONS.Missing.creatable).toBe(false);
  });
});

describe('transform do nó sobrevive à validação (AIS-18d, pendência)', () => {
  it('validateScene mantém transform em objeto, tupla e quaternion', () => {
    const scene = makeScene() as any;
    scene.nodes.root.transform = { position: { x: 1, y: 2, z: 3 }, rotation: [0, 90, 0], scale: { x: 1, y: 1, z: 1 } };
    scene.nodes.child1.transform = { position: [4, 5, 6], rotation: { x: 0, y: 0, z: 0, w: 1 }, scale: [2, 2, 2] };
    const res = validateScene(scene);
    expect(res.success).toBe(true);
    expect(res.data!.nodes.root.transform).toEqual(scene.nodes.root.transform);
    expect(res.data!.nodes.child1.transform).toEqual(scene.nodes.child1.transform);
  });

  it('transform malformado é rejeitado', () => {
    const scene = makeScene() as any;
    scene.nodes.root.transform = { position: 'x' };
    expect(validateScene(scene).success).toBe(false);
  });

  it('Missing mantém transform alterado no editor ao regravar', () => {
    const scene = validateScene(makeScene()).data!;
    scene.nodes.foo1 = { ...scene.nodes.foo1, transform: { position: { x: 9, y: 0, z: 0 }, rotation: { x: 0, y: 0, z: 0 }, scale: { x: 1, y: 1, z: 1 } } };
    expect((withRestoredMissingNodes(scene).nodes.foo1 as any).transform.position.x).toBe(9);
  });
});
