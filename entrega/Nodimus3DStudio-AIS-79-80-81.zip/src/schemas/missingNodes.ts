import { NODE_DEFINITIONS } from '../nodes/registry';
import { convertLegacyPhysics } from './legacyPhysics';
import { tNow } from '../core/i18n';

/**
 * Missing Node (AIS-18d, decisão 19): nó cujo `type` não existe em `NODE_DEFINITIONS` é lido como
 * `type: 'Missing'` guardando a cópia integral em `properties.__missing` e é regravado intacto.
 */

export const MISSING_NODE_TYPE = 'Missing';
export const MISSING_KEY = '__missing';

type AnyRecord = Record<string, any>;

const isRecord = (v: unknown): v is AnyRecord => typeof v === 'object' && v !== null && !Array.isArray(v);

export function isKnownNodeType(type: unknown): boolean {
  return typeof type === 'string' && Object.prototype.hasOwnProperty.call(NODE_DEFINITIONS, type);
}

/** Campos estruturais que o editor pode alterar num Missing e que valem sobre `originalNode`. */
const STRUCTURAL_KEYS = ['id', 'name', 'parentId', 'childrenIds', 'visible', 'locked', 'collapsed', 'transform'] as const;

function toMissingNode(raw: AnyRecord): AnyRecord {
  const missing: AnyRecord = {
    type: MISSING_NODE_TYPE,
    properties: {
      [MISSING_KEY]: { originalType: raw.type, originalNode: JSON.parse(JSON.stringify(raw)) },
    },
  };
  if (raw.schemaVersion !== undefined) missing.schemaVersion = raw.schemaVersion;
  for (const key of STRUCTURAL_KEYS) if (raw[key] !== undefined) missing[key] = raw[key];
  return missing;
}

/**
 * Passo anterior à validação: reescreve em memória os nós de tipo desconhecido como Missing.
 * Não altera a entrada; devolve a mesma referência se nada mudou.
 */
export function normalizeUnknownNodes<T>(input: T): T {
  // AIS-26b: física legada é migrada antes de o tipo ser tratado como desconhecido
  const data = convertLegacyPhysics(input);
  if (!isRecord(data) || !isRecord(data.nodes)) return data;
  let nodes: AnyRecord | null = null;
  for (const [id, raw] of Object.entries(data.nodes)) {
    if (!isRecord(raw) || typeof raw.type !== 'string' || isKnownNodeType(raw.type)) continue;
    nodes ??= { ...data.nodes };
    nodes[id] = toMissingNode(raw);
  }
  return nodes ? ({ ...data, nodes } as T) : data;
}

/** Tipos originais (únicos, ordem de aparição) dos Missing Nodes de um mapa de nós. */
export function collectMissingTypes(nodes: Record<string, { type: string; properties?: AnyRecord }> | undefined): {
  count: number;
  types: string[];
} {
  const types: string[] = [];
  let count = 0;
  for (const node of Object.values(nodes ?? {})) {
    const info = node?.type === MISSING_NODE_TYPE ? node.properties?.[MISSING_KEY] : undefined;
    if (!info) continue;
    count++;
    const t = String(info.originalType);
    if (!types.includes(t)) types.push(t);
  }
  return { count, types };
}

/** Mensagem única por cena para o console do editor; `null` se não há Missing. */
export function missingNodesWarning(nodes: Record<string, { type: string; properties?: AnyRecord }> | undefined): string | null {
  const { count, types } = collectMissingTypes(nodes);
  return count ? tNow('missingNodesMsgCore.nodeSOfUnknownType', { count, types: types.join(', ') }) : null;
}

/** Gravação: Missing volta a ser emitido com o tipo e os dados originais + alterações estruturais. */
export function restoreMissingNode<N extends AnyRecord>(node: N): N | AnyRecord {
  const info = node?.type === MISSING_NODE_TYPE ? node.properties?.[MISSING_KEY] : undefined;
  if (!isRecord(info) || !isRecord(info.originalNode)) return node;
  const restored: AnyRecord = JSON.parse(JSON.stringify(info.originalNode));
  restored.type = info.originalType;
  for (const key of STRUCTURAL_KEYS) if (node[key] !== undefined) restored[key] = node[key];
  return restored;
}

/** Aplica `restoreMissingNode` a um mapa de nós; mesma referência se não há Missing. */
export function restoreMissingNodes<M extends Record<string, any>>(nodes: M): M {
  let out: AnyRecord | null = null;
  for (const [id, node] of Object.entries(nodes)) {
    const restored = restoreMissingNode(node);
    if (restored === node) continue;
    out ??= { ...nodes };
    out[id] = restored;
  }
  return (out ?? nodes) as M;
}

/** Cena/prefab pronto para JSON.stringify: Missing Nodes restaurados. */
export function withRestoredMissingNodes<T extends { nodes: Record<string, any> }>(doc: T): T {
  const nodes = restoreMissingNodes(doc.nodes);
  return nodes === doc.nodes ? doc : { ...doc, nodes };
}
