import { z } from 'zod';
import { GameNodeV1Schema } from './node.schema';

export const PrefabV1Schema = z.object({
  schemaVersion: z.literal(1).optional().default(1),
  id: z.string().min(1, 'Prefab ID is required'),
  name: z.string().min(1, 'Prefab name is required'),
  rootNodeId: z.string().min(1, 'Prefab rootNodeId is required'),
  nodes: z.record(z.string(), GameNodeV1Schema).refine(
    (nodes) => Object.keys(nodes).length > 0,
    { message: 'Prefab must contain at least one node' }
  ),
  sourcePath: z.string().optional(), // e.g. "res://prefabs/Coin.prefab.json"
  createdAt: z.string().optional().default(() => new Date().toISOString()),
  updatedAt: z.string().optional().default(() => new Date().toISOString()),
});

export type PrefabV1 = z.infer<typeof PrefabV1Schema>;
