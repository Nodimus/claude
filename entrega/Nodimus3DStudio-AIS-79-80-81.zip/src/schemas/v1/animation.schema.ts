import { z } from 'zod';
import { ResourceRefSchema } from '../sceneSchema';

/**
 * AIS-60b (decisão 30): bloco `GameNode.properties.animation` do MeshInstance animado (`properties.animated: true`). Aditivo — sem nova
 * `schemaVersion`. `rig` aponta o `RigConfig` (`res://materials/<asset>_rig.json`) por ResourceRef; o caminho em texto é o formato que o
 * importador ainda grava e é lido com a mesma regra.
 */
export const ANIMATION_SPEED_MIN = 0.25;
export const ANIMATION_SPEED_MAX = 2;

export const AnimationConfigSchema = z.object({
  rig: z.union([ResourceRefSchema, z.string()]).optional(),
  default: z.string().default(''),
  autoplay: z.boolean().default(true),
  loop: z.boolean().default(true),
  speed: z.number().min(ANIMATION_SPEED_MIN).max(ANIMATION_SPEED_MAX).default(1),
  crossfade: z.number().min(0).max(5).default(0.2),
});

export type AnimationConfigV1 = z.infer<typeof AnimationConfigSchema>;
