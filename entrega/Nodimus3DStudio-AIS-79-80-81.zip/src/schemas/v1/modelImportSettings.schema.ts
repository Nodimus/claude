import { z } from 'zod';
import { ResourceRefSchema } from '../sceneSchema';
import { Vector3V1Schema } from './node.schema';

/**
 * AIS-33a — `ModelImportSettings` (`importSettings` do `VirtualFile` de um modelo 3D, Zod v1). Criado aqui e ESTENDIDO de
 * forma aditiva pelos prompts seguintes (34 calibração, 35 materiais, 36/37 rig/clipes, 38c reedição): campos novos entram
 * com `.default()`/`.optional()`, sem nova `schemaVersion` do projeto. Padrões neutros. Leitura tolerante: nunca lança.
 */
export const ModelImportSettingsSchema = z.object({
  schemaVersion: z.literal(1).default(1),
  /** Eixo "para cima" do arquivo (AIS-34). */
  upAxis: z.enum(['y', 'z']).default('y'),
  rotationDeg: Vector3V1Schema.default({ x: 0, y: 0, z: 0 }),
  scale: z.number().positive().default(1),
  pivot: z.enum(['bottom', 'center', 'top', 'custom']).default('bottom'),
  /** Compensação final (`modelOffset` do nó, no espaço do modelo) calculada da calibração (AIS-34). */
  pivotOffset: Vector3V1Schema.default({ x: 0, y: 0, z: 0 }),
  /**
   * Frente do modelo: rotação (graus, eixo Y) aplicada ao modelo DENTRO do nó, não ao nó. glTF/Mixamo têm a frente em +Z e o motor usa -Z;
   * como Behaviors de movimento e IA sobrescrevem o yaw do NÓ, a correção tem de viver no modelo. Ausente = 0 (arquivos antigos).
   */
  modelYawDeg: z.number().default(0),
  /** AIS-34: multiplicadores por eixo sobre `scale` (≠ 1,1,1 = escala não uniforme, aviso `physics.nonuniform_scale`). */
  scaleAxes: Vector3V1Schema.default({ x: 1, y: 1, z: 1 }),
  /** AIS-34: "Auto Centralizar" ligado (centro da caixa em X=0, Z=0). */
  centerXZ: z.boolean().default(false),
  /** AIS-35 → `res://textures/<asset>_material.json`. */
  materials: ResourceRefSchema.optional(),
  /** AIS-36/37 → `res://materials/<asset>_rig.json`. */
  rig: ResourceRefSchema.optional(),
  /** Arquivos gerados pelo import (exclusão em pacote, AIS-38c). */
  outputs: z.array(ResourceRefSchema).default([]),
});

export type ModelImportSettings = z.infer<typeof ModelImportSettingsSchema>;

export const DEFAULT_MODEL_IMPORT_SETTINGS: ModelImportSettings = ModelImportSettingsSchema.parse({});

/**
 * Lê as settings persistidas com tolerância: campo inválido volta ao padrão e o resto é mantido; chaves de outros
 * prompts (desconhecidas) são preservadas em `extra` pelo chamador, nunca descartadas daqui.
 */
export function parseModelImportSettings(raw: unknown): ModelImportSettings {
  const whole = ModelImportSettingsSchema.safeParse(raw);
  if (whole.success) return whole.data;
  const source = raw && typeof raw === 'object' && !Array.isArray(raw) ? (raw as Record<string, unknown>) : {};
  const out: Record<string, unknown> = { schemaVersion: 1 };
  for (const key of Object.keys(ModelImportSettingsSchema.shape) as (keyof ModelImportSettings)[]) {
    if (source[key] === undefined) continue;
    const field = ModelImportSettingsSchema.shape[key].safeParse(source[key]);
    if (field.success) out[key] = field.data;
  }
  return ModelImportSettingsSchema.parse(out);
}
