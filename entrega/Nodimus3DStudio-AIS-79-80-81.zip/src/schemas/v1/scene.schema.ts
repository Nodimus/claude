import { z } from 'zod';
import { GameNodeV1Schema } from './node.schema';

export const BloomSettingsV1Schema = z.object({
  enabled: z.boolean().default(false),
  blurIterations: z.number().min(1).max(10).default(3),
  threshold: z.number().min(0).max(1).default(0.8),
});

export const BlurSettingsV1Schema = z.object({
  enabled: z.boolean().default(false),
  iterations: z.number().min(1).max(10).default(2),
});

export const ColorizeSettingsV1Schema = z.object({
  enabled: z.boolean().default(false),
  color: z.string().default('#ff6600'),
});

export const VignetteSettingsV1Schema = z.object({
  enabled: z.boolean().default(false),
  intensity: z.number().min(0).max(1).default(0.6),
  radiusA: z.number().min(0).max(1).default(0.4),
  radiusB: z.number().min(0).max(1).default(0.8),
});

export const PostProcessingSettingsV1Schema = z.object({
  bloom: BloomSettingsV1Schema.default({ enabled: false, blurIterations: 3, threshold: 0.8 }),
  blackAndWhite: z.object({ enabled: z.boolean().default(false) }).default({ enabled: false }),
  invert: z.object({ enabled: z.boolean().default(false) }).default({ enabled: false }),
  blur: BlurSettingsV1Schema.default({ enabled: false, iterations: 2 }),
  colorize: ColorizeSettingsV1Schema.default({ enabled: false, color: '#ff6600' }),
  vignette: VignetteSettingsV1Schema.default({ enabled: false, intensity: 0.6, radiusA: 0.4, radiusB: 0.8 }),
});

export const FogModeV1Schema = z.enum(['exponential2', 'exponential', 'linear', 'height']);

export const SceneFogSettingsV1Schema = z.object({
  enabled: z.boolean().default(false),
  mode: FogModeV1Schema.default('exponential2'),
  color: z.string().default('#8fa4b8'),
  density: z.number().default(0.008),
  near: z.number().default(15),
  far: z.number().default(180),
  height: z.number().default(12),
  heightFalloff: z.number().default(0.6),
  affectSkybox: z.boolean().default(false),
  windDrift: z.boolean().default(true),
  windSpeed: z.number().default(0.5),
});

export const SceneV1Schema = z.object({
  schemaVersion: z.literal(1).optional().default(1),
  id: z.string().min(1, 'Scene ID is required'),
  name: z.string().min(1, 'Scene name is required'),
  path: z.string().min(1, 'Scene path is required'),
  rootNodeId: z.string().min(1, 'Scene rootNodeId is required'),
  nodes: z.record(z.string(), GameNodeV1Schema).refine(
    (nodes) => Object.keys(nodes).length > 0,
    { message: 'Scene must contain at least one node (root node)' }
  ),
  postProcessing: PostProcessingSettingsV1Schema.optional(),
  fog: SceneFogSettingsV1Schema.optional(),
  createdAt: z.string().optional().default(() => new Date().toISOString()),
  updatedAt: z.string().optional().default(() => new Date().toISOString()),
});

export type SceneV1 = z.infer<typeof SceneV1Schema>;
export type PostProcessingSettingsV1 = z.infer<typeof PostProcessingSettingsV1Schema>;
export type SceneFogSettingsV1 = z.infer<typeof SceneFogSettingsV1Schema>;
