import { z } from 'zod';
import { ResourceRefSchema } from '../sceneSchema';
import { CURRENT_SPRITE_SCHEMA_VERSION } from '../../core/persistenceVersions';
import { DEFAULT_SPRITE_3D_SETTINGS } from '../../types/sprite';

/**
 * AIS-76 (decisão 24) — `SpriteProject` v1: o recurso `res://sprites/<nome>.sprite.json`, análogo do `SpriteFrames` do Godot.
 *
 * - O atlas é um PNG em `res://textures/`, referenciado por `sheetConfig.texture: ResourceRef`.
 * - `imageUrl` e `customDataUrl` são ESTADO DE SESSÃO do editor: não existem neste schema (nunca base64 em JSON). Chaves desconhecidas
 *   da raiz são preservadas (`passthrough`), para versões futuras e ferramentas externas não perderem dados.
 * - `SpriteFrame.durationMs` é campo LEGADO: lido (opcional), mas não é autoridade de tempo. Valem `fps` e `frameDurations`.
 */

const positiveInt = z.number().int().min(1);
const nonNegativeInt = z.number().int().min(0);

export const SpriteFrameV1Schema = z
  .object({
    id: z.string().min(1),
    index: nonNegativeInt,
    x: z.number().min(0),
    y: z.number().min(0),
    width: z.number().min(1),
    height: z.number().min(1),
    durationMs: z.number().optional(),
  })
  .strip();

export const SpriteAnimationV1Schema = z
  .object({
    id: z.string().min(1),
    name: z.string().min(1),
    frameIndices: z.array(nonNegativeInt),
    fps: z.number().positive(),
    loopMode: z.enum(['loop', 'once', 'ping-pong']).default('loop'),
    frameDurations: z.array(z.number().positive()).optional(),
  })
  .strip();

const D = DEFAULT_SPRITE_3D_SETTINGS;
export const Sprite3DSettingsV1Schema = z
  .object({
    billboardMode: z.enum(['spherical', 'cylindrical_y', 'flat_quad', 'isometric']).default(D.billboardMode),
    renderScale: z.object({ x: z.number().positive(), y: z.number().positive() }).default({ ...D.renderScale }),
    pixelPerfectFilter: z.boolean().default(D.pixelPerfectFilter),
    tintColor: z.object({ r: z.number(), g: z.number(), b: z.number(), a: z.number() }).default({ ...D.tintColor }),
    emissiveColor: z.string().default(D.emissiveColor),
    emissiveIntensity: z.number().min(0).default(D.emissiveIntensity),
    alphaTest: z.number().min(0).max(1).default(D.alphaTest),
    doubleSided: z.boolean().default(D.doubleSided),
    castShadow: z.boolean().default(D.castShadow),
    receiveShadow: z.boolean().default(D.receiveShadow),
    turntableSpeed: z.number().default(D.turntableSpeed),
    environmentLighting: z.enum(['studio', 'night', 'sunset', 'retro_arcade', 'cyberpunk']).default(D.environmentLighting),
    showGroundGrid: z.boolean().default(D.showGroundGrid),
    showPixelWireframe: z.boolean().default(D.showPixelWireframe),
    tileH: z.boolean().default(D.tileH),
    tileV: z.boolean().default(D.tileV),
    premultiplyAlpha: z.boolean().default(D.premultiplyAlpha),
  })
  .strip();

export const SpriteSheetConfigV1Schema = z
  .object({
    name: z.string().default(''),
    texture: ResourceRefSchema.optional(),
    imageWidth: nonNegativeInt.default(0),
    imageHeight: nonNegativeInt.default(0),
    frameWidth: positiveInt,
    frameHeight: positiveInt,
    columns: positiveInt,
    rows: positiveInt,
    spacing: nonNegativeInt.default(0),
    margin: nonNegativeInt.default(0),
    totalFrames: nonNegativeInt.default(0),
  })
  .strip();

export const SpriteProjectV1Schema = z
  .object({
    schemaVersion: z.literal(CURRENT_SPRITE_SCHEMA_VERSION),
    id: z.string().min(1),
    name: z.string().min(1),
    sheetConfig: SpriteSheetConfigV1Schema,
    frames: z.array(SpriteFrameV1Schema),
    animations: z.array(SpriteAnimationV1Schema),
    activeAnimationId: z.string().default(''),
    currentFrameIndex: nonNegativeInt.default(0),
    settings3D: Sprite3DSettingsV1Schema.default({ ...D }),
    palette: z.array(z.string()).default([]),
  })
  .passthrough();

export type SpriteProjectV1 = z.infer<typeof SpriteProjectV1Schema>;
