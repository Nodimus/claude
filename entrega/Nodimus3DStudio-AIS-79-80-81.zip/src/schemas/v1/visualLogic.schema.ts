import { z } from 'zod';

/**
 * v4.7.0 — Visual Logic IDs are no longer closed enums in a single document.
 * Each trigger/condition/action/behavior lives in its own folder under
 * `src/logic/<kind>/<id>/` and the ID is the folder name. The schema only
 * validates the ID *shape*; whether the ID is known is a registry question
 * (`src/logic/registry.ts`). Unknown IDs are preserved, never discarded.
 */
export const LogicIdV1Schema = z
  .string()
  .regex(/^[a-z][a-z0-9_]*$/, 'Logic ID must be snake_case (folder name in src/logic/<kind>/<id>/)');

export const LogicEventTypeV1Schema = LogicIdV1Schema;

export const LogicConditionTypeV1Schema = LogicIdV1Schema;

export const LogicActionTypeV1Schema = LogicIdV1Schema;

export const LogicConditionV1Schema = z.object({
  id: z.string().min(1),
  type: LogicConditionTypeV1Schema,
  parameters: z.record(z.string(), z.any()).default({}),
});

export const LogicActionV1Schema = z.object({
  id: z.string().min(1, 'Action ID is required'),
  type: LogicActionTypeV1Schema,
  parameters: z.record(z.string(), z.any()).default({}),
});

export const LogicEventRuleV1Schema = z.object({
  id: z.string().min(1),
  eventType: LogicEventTypeV1Schema,
  parameters: z.record(z.string(), z.any()).default({}),
  conditions: z.array(LogicConditionV1Schema).default([]),
  actions: z.array(LogicActionV1Schema).default([]),
});

export const BehaviorTypeV1Schema = LogicIdV1Schema;

export const BehaviorV1Schema = z.object({
  schemaVersion: z.literal(1).optional().default(1),
  id: z.string().min(1, 'Behavior ID is required'),
  name: z.string().min(1, 'Behavior name is required'),
  targetNodeId: z.string(),
  behaviorType: BehaviorTypeV1Schema,
  enabled: z.boolean().default(true),
  properties: z.record(z.string(), z.any()).default({}),
  rules: z.array(LogicEventRuleV1Schema).default([]),
});

export type LogicActionV1 = z.infer<typeof LogicActionV1Schema>;
export type BehaviorV1 = z.infer<typeof BehaviorV1Schema>;
export type LogicEventRuleV1 = z.infer<typeof LogicEventRuleV1Schema>;
