import React from 'react';
import { Wand2 } from 'lucide-react';
import type { GameNode } from '../../types/node';
import { useEditorStore } from '../../core/editorStore';
import { generatorButtonState, openGeneratorEditor } from '../../core/generators/generatorEditor';
import { useTranslation } from '../../core/i18n/I18nContext';

/**
 * AIS-49b — "Editar no gerador": só aparece em nó com `generatorSource` (os demais nós não mudam). Reabre o modal do gerador com os
 * parâmetros salvos; se o gerador ainda não existe neste editor, o botão fica desabilitado com "em breve" (decisão 14).
 */
export const GeneratorSection: React.FC<{ node: GameNode }> = ({ node }) => {
  const { t } = useTranslation();
  const startGeneratorEdit = useEditorStore((s) => s.startGeneratorEdit);
  const endGeneratorEdit = useEditorStore((s) => s.endGeneratorEdit);
  const state = generatorButtonState(node);
  if (!state.visible) return null;
  return (
    <div className="px-3 py-2 flex items-center justify-between gap-2" data-testid="generator-section">
      <span className="text-[11px] text-[#8b97a8] truncate">
        {t('generatorSection.generator')} <span className="font-mono text-[#dfe4ec]">{state.label}</span>
      </span>
      <button
        type="button"
        disabled={!state.enabled}
        title={state.tooltip}
        onClick={() => openGeneratorEditor(node, { startGeneratorEdit, endGeneratorEdit })}
        className="px-2 py-1 rounded text-[10px] font-medium border bg-[#222a3b] hover:bg-[#2b354a] border-[#2e3b52] text-[#93a1b8] hover:text-white flex items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <Wand2 className="w-3 h-3" />
        {t('generatorSection.editInGenerator')}
      </button>
    </div>
  );
};
