import React, { useEffect, useState } from 'react';
import * as THREE from 'three';
import { Box } from 'lucide-react';
import type { ResourceRef } from '../../types/node';
import { createModelObject } from '../../core/models/createModelObject';
import { projectModelSource } from '../../core/models/global';
import { modelKeyOf } from '../../core/models/modelNodeSync';
import { useTranslation } from '../../core/i18n/I18nContext';

const SIZE = 96;
/** Miniaturas já renderizadas (chave = recurso + conteúdo: o reimport muda o hash e refaz a miniatura). */
const thumbnails = new Map<string, string | null>();

/** Renderiza UMA vez o modelo (mesma `createModelObject` do Viewport) num canvas fora da tela e devolve um data URL. */
async function renderThumbnail(ref: ResourceRef): Promise<string | null> {
  const handle = createModelObject(ref, { source: projectModelSource });
  try {
    if ((await handle.ready) !== 'ready') return null;
    const box = new THREE.Box3().setFromObject(handle.object);
    if (box.isEmpty()) return null;
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    const radius = Math.max(size.x, size.y, size.z) * 0.5 || 1;
    const scene = new THREE.Scene();
    const sun = new THREE.DirectionalLight(0xffffff, 2.2);
    sun.position.set(2, 3, 2);
    scene.add(handle.object, new THREE.AmbientLight(0xffffff, 1.4), sun);
    const camera = new THREE.PerspectiveCamera(35, 1, radius * 0.05, radius * 50);
    camera.position.copy(center).add(new THREE.Vector3(1, 0.7, 1.2).normalize().multiplyScalar(radius * 3.2));
    camera.lookAt(center);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer.setSize(SIZE, SIZE);
    renderer.render(scene, camera);
    const url = renderer.domElement.toDataURL('image/png');
    renderer.dispose();
    renderer.forceContextLoss();
    return url;
  } catch {
    return null;
  } finally {
    handle.release();
  }
}

/** Miniatura do modelo no Inspector (AIS-38c). Sem WebGL ou com falha, mostra o ícone — nunca quebra a seção. */
export const ModelThumbnail: React.FC<{ model: ResourceRef | null }> = ({ model }) => {
  const { t } = useTranslation();
  const key = model ? modelKeyOf(model) : '';
  const [src, setSrc] = useState<string | null>(() => (key ? thumbnails.get(key) ?? null : null));

  useEffect(() => {
    if (!model || !key.endsWith('|ok')) {
      setSrc(null);
      return;
    }
    if (thumbnails.has(key)) {
      setSrc(thumbnails.get(key) ?? null);
      return;
    }
    let cancelled = false;
    void renderThumbnail(model).then((url) => {
      thumbnails.set(key, url);
      if (!cancelled) setSrc(url);
    });
    return () => {
      cancelled = true;
    };
  }, [model, key]);

  return (
    <div className="w-12 h-12 rounded border border-[#2c3345] bg-[#12151c] flex items-center justify-center shrink-0 overflow-hidden" data-testid="model-thumbnail">
      {src ? <img src={src} alt={t('modelThumbnail.modelThumbnail')} className="w-full h-full object-contain" /> : <Box className="w-5 h-5 text-[#4a5568]" />}
    </div>
  );
};
