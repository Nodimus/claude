import React, { useMemo, useState } from 'react';
import { Mountain, Dices, ImageOff, Image as ImageIcon, SquarePen, Search, X } from 'lucide-react';
import type { GameNode, ResourceRef } from '../../types/node';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { globalResourceRegistry } from '../../core/resources/global';
import { useResourceRegistryVersion } from '../../core/resources/useResources';
import { applyTerrainChanges } from '../../core/generators/terrainGenerator';
import { canChangeGeometry, hasSculptedHeights, heightmapChanges, reseedChanges } from '../../core/terrainOps';
import { useTranslation } from '../../core/i18n/I18nContext';

const isRef = (v: unknown): v is ResourceRef => !!v && typeof v === 'object' && typeof (v as ResourceRef).id === 'string' && (v as ResourceRef).id.length > 0;
const nameOf = (uri: string) => uri.split('/').pop() ?? uri;
const BTN = 'px-2 py-1 rounded text-[10px] font-medium border bg-[#222a3b] hover:bg-[#2b354a] border-[#2e3b52] text-[#93a1b8] hover:text-white flex items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed';
const HEIGHTMAP_ROOT = 'res://textures/';
const HEIGHTMAP_EXT = /\.(png|jpe?g)$/i;

/** Seletor de imagem de `res://textures/` para o heightmap. */
export const HeightmapPicker: React.FC<{ currentId?: string; onPick: (ref: ResourceRef) => void; onClose: () => void }> = ({ currentId, onPick, onClose }) => {
  const { t } = useTranslation();
  useResourceRegistryVersion();
  const [filter, setFilter] = useState('');
  const entries = globalResourceRegistry
    .list('texture')
    .filter((e) => e.uri.startsWith(HEIGHTMAP_ROOT) && HEIGHTMAP_EXT.test(e.uri) && e.uri.toLowerCase().includes(filter.trim().toLowerCase()))
    .sort((a, b) => a.uri.localeCompare(b.uri));
  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/60" role="dialog" aria-label={t('terrainSection.chooseHeightmap')} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="w-[420px] max-h-[70vh] flex flex-col rounded-lg border border-[#2c3345] bg-[#1a1e27] shadow-2xl text-[11px] text-[#dfe4ec]">
        <div className="flex items-center justify-between px-3 py-2 border-b border-[#2c3345]">
          <span className="font-semibold text-white">{t('terrainSection.chooseHeightmapPngJpgGrayscale')}</span>
          <button onClick={onClose} aria-label={t('shared.close')} className="text-[#8b97a8] hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-2 border-b border-[#2c3345] flex items-center gap-1.5">
          <Search className="w-3.5 h-3.5 text-[#718096]" />
          <input autoFocus value={filter} onChange={(e) => setFilter(e.target.value)} placeholder={t('terrainSectionResA.filterImagesFromResTextures')} className="flex-1 bg-[#12151c] rounded border border-[#2c3345] px-2 py-1 outline-none focus:border-blue-500" />
        </div>
        <div role="listbox" aria-label={t('terrainSection.projectImages')} className="flex-1 overflow-y-auto">
          {entries.length === 0 ? (
            <p className="p-3 text-[#8b97a8]">{t('terrainSectionResA.noPngJpgImageIn')}</p>
          ) : (
            entries.map((e) => (
              <button
                key={e.resourceId}
                role="option"
                aria-selected={e.resourceId === currentId}
                onClick={() => {
                  const ref = globalResourceRegistry.makeRef(e.resourceId);
                  if (ref) onPick(ref);
                }}
                className={`w-full text-left px-3 py-1.5 font-mono break-all ${e.resourceId === currentId ? 'bg-[#4982ea]/30 text-white' : 'hover:bg-[#272e3d]'}`}
              >
                {e.uri}
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

/**
 * AIS-50 — seção **Terrain** do Inspector (nó `Terrain`): heightmap (escolher/limpar), "Regerar" a semente do preset e "Abrir
 * Editor de Terreno". As demais propriedades (dimensões, preset, texturas) vêm do Inspector genérico pelos `PropertyDescriptor`s.
 * Toda edição é UM `MacroCommand` (propriedades + marca de origem `generatorSource`); terreno esculpido trava a geometria.
 */
export const TerrainSection: React.FC<{ node: GameNode }> = ({ node }) => {
  const { t } = useTranslation();
  const setIsTerrainEditorOpen = useEditorStore((s) => s.setIsTerrainEditorOpen);
  const { addLog } = useEditor();
  const version = useResourceRegistryVersion();
  const [picker, setPicker] = useState(false);

  const ref = isRef(node.properties.heightmapRef) ? node.properties.heightmapRef : null;
  const resolved = useMemo(() => (ref ? globalResourceRegistry.resolve(ref) : null), [ref, version]); // eslint-disable-line react-hooks/exhaustive-deps
  const entry = resolved?.status === 'resolved' ? resolved.entry : null;
  const sculpted = hasSculptedHeights(node.properties);
  const geometry = canChangeGeometry(node.properties);
  const lock = geometry.ok ? undefined : geometry.reason;

  return (
    <div className="px-2 pt-2" data-testid="terrain-section">
      <div className="rounded border border-[#252c3c] bg-[#171b23]/60 p-2 space-y-2">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-green-500 uppercase tracking-wider">
          <Mountain className="w-3.5 h-3.5" /> {t('terrainSection.terrain')}
        </div>
        {sculpted && (
          <div className="text-[10px] text-amber-400" data-testid="terrain-sculpted-badge">
            {t('terrainSection.manuallyEditedTerrainTheGeometry')}
          </div>
        )}
        <div className="text-[11px]">
          <div className="text-[#8b97a8]">{t('terrainSection.heightmap')}</div>
          <div className="truncate font-mono text-[10px] text-[#dfe4ec]" title={entry?.uri ?? ref?.path} data-testid="terrain-heightmap-name">
            {ref ? (entry ? nameOf(entry.uri) : <span className="text-rose-400">{t('terrainSection.unresolved', { value: ref.label || nameOf(ref.path ?? ref.id) })}</span>) : t('sharedMsg.noneUsesThePreset')}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          <button onClick={() => setPicker(true)} disabled={!geometry.ok} title={lock ?? t('terrainSectionMsgResB.chooseAGrayscaleImageFrom')} className={BTN}>
            <ImageIcon className="w-3 h-3" /> {t('terrainSection.chooseHeightmap2')}
          </button>
          <button
            onClick={() => applyTerrainChanges(node.id, heightmapChanges(null), t('leftovers.clearHeightmap'))}
            disabled={!ref || !geometry.ok}
            title={lock ?? t('terrainSectionMsg.backToTheProceduralPreset')}
            className={BTN}
          >
            <ImageOff className="w-3 h-3" /> {t('shared.clear')}
          </button>
          <button
            onClick={() => applyTerrainChanges(node.id, reseedChanges(node.properties), t('leftovers.regenTerrain'))}
            disabled={!!ref || !geometry.ok}
            title={lock ?? (ref ? t('terrainSectionMsg.withAHeightmapThePreset') : t('terrainSectionMsg.newPresetSeedCtrlZ'))}
            className={BTN}
          >
            <Dices className="w-3 h-3" /> {t('terrainSection.regenerate')}
          </button>
          <button onClick={() => setIsTerrainEditorOpen(true)} title={t('terrainSection.opensTheTerrainEditorOver')} className={BTN}>
            <SquarePen className="w-3 h-3" /> {t('terrainSection.openTerrainEditor')}
          </button>
        </div>
      </div>
      {picker && (
        <HeightmapPicker
          currentId={entry?.resourceId}
          onClose={() => setPicker(false)}
          onPick={(next) => {
            setPicker(false);
            if (applyTerrainChanges(node.id, heightmapChanges(next), t('leftovers.setHeightmap'))) addLog('log', t('terrainSectionMsg.heightmapAppliedTo', { name: node.name }));
          }}
        />
      )}
    </div>
  );
};
