import { useTranslation } from '../../core/i18n/I18nContext';
import React, { useEffect, useState } from 'react';
import { Link2 } from 'lucide-react';
import type { GameNode } from '../../types/node';
import { useEditor } from '../../core/EditorContext';
import { attachmentValue, canAttachToBone, readAttachment } from '../../core/attachment/boneAttachment';
import { readPhysics } from '../../core/physics/physicsConfig';
import { projectModelSource } from '../../core/models/global';
import { loadModelBoneNames } from '../../core/models/modelBones';

const FIELD = 'flex-1 min-w-0 bg-[#12151c] rounded border border-[#2c3345] px-2 py-1 text-[11px] text-[#dfe4ec] outline-none focus:border-blue-500';

/** AIS-61 §4: prende o nó a um osso do modelo do pai (Command com Undo; a transformação do nó passa a ser local ao osso). */
export const AttachmentSection: React.FC<{ node: GameNode; parent: GameNode | undefined }> = ({ node, parent }) => {
  const { t } = useTranslation();
  const { changeNodeProperties } = useEditor();
  const [bones, setBones] = useState<string[]>([]);
  const modelId = parent?.properties?.model?.id as string | undefined;
  const current = readAttachment(node.properties)?.bone ?? '';
  useEffect(() => {
    let alive = true;
    setBones([]);
    void loadModelBoneNames(parent?.properties?.model, projectModelSource).then((names) => alive && setBones(names));
    return () => {
      alive = false;
    };
  }, [modelId]);
  if (!parent || !canAttachToBone(node, parent)) return null;
  const physics = readPhysics(node.properties);
  // um nó preso anda com a animação; o corpo físico ficaria parado: prender desliga a colisão NO MESMO Command (um Undo desfaz os dois)
  const set = (bone: string) => {
    const value = attachmentValue(bone);
    const changes: Record<string, any> = { attachment: value };
    if (value && physics?.enabled) changes.physics = { ...physics, enabled: false };
    changeNodeProperties(node.id, changes, value ? t('attachmentSectionMsg.attachToBone') : t('attachmentSectionMsg.detachFromBone'));
  };
  const known = bones.includes(current);
  return (
    <div className="px-3 py-1.5 text-[11px] space-y-1" aria-label={t('attachmentSection.attachmentToBone')}>
      <div className="flex items-center gap-1.5 text-[#93a1b8] font-semibold uppercase tracking-wider text-[10px]">
        <Link2 className="w-3 h-3" /> {t('attachmentSection.attachment')}
      </div>
      <div className="flex items-center gap-2">
        <label htmlFor={`bone-${node.id}`} className="w-24 shrink-0 text-[#93a1b8]">{t('attachmentSection.bone')}</label>
        {bones.length > 0 ? (
          <select id={`bone-${node.id}`} aria-label={t('attachmentSection.bone')} className={FIELD} value={current} onChange={(e) => set(e.target.value)}>
            <option value="">{t('attachmentSection.noneChildOfTheModel')}</option>
            {!known && current && <option value={current}>{t('attachmentSection.outsideTheModel', { current })}</option>}
            {bones.map((b) => (
              <option key={b} value={b}>{b}</option>
            ))}
          </select>
        ) : (
          <input id={`bone-${node.id}`} aria-label={t('attachmentSection.bone')} className={FIELD} value={current} placeholder={t('attachmentSection.boneNameModelWithoutA')} onChange={(e) => set(e.target.value)} />
        )}
      </div>
      {current && <p className="text-[10px] text-[#6c7a91]">{t('attachmentSection.thisNodeSPositionRotation')}</p>}
      {current && physics?.enabled && (
        <p role="alert" className="text-[10px] text-amber-300">{t('attachmentSection.thisNodeIsAttachedTo')}</p>
      )}
    </div>
  );
};
