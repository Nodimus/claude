import React, { useEffect, useId, useRef, useState } from 'react';
import { globalCommandManager } from '../../core/commandManager';
import { applyNumberDrag, formatNumberForInput, parseNumberInput, stepNumber } from './numberInput';

interface DraftNumberInputProps {
  value: number;
  /** Chamado só com valor finito válido (Enter/blur/setas), e só se mudou. */
  onCommit: (value: number) => void;
  integer?: boolean;
  min?: number;
  max?: number;
  /** Passo das setas ↑/↓ (Shift = ×10). */
  step?: number;
  className?: string;
  'aria-label'?: string;
  title?: string;
}

/**
 * AIS-23 — campo numérico com rascunho textual: digitar não grava; Enter/blur gravam um valor
 * finito (vírgula ou ponto decimal); Escape descarta; entrada inválida permanece no campo com
 * erro acessível (`aria-invalid` + mensagem) e não grava nada.
 */
export const DraftNumberInput: React.FC<DraftNumberInputProps> = ({
  value,
  onCommit,
  integer,
  min,
  max,
  step = 0.1,
  className = '',
  title,
  ...rest
}) => {
  // `null` = mostra o valor formatado; texto = rascunho em edição
  const [draft, setDraft] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const dragState = useRef<{ startX: number; startValue: number } | null>(null);
  const didDrag = useRef(false);
  const errorId = useId();

  // AIS-24: arrasto e ↑/↓ mantida = UM gesto no CommandManager (uma entrada de Undo: início → fim),
  // mantendo a prévia ao vivo na viewport. Enter/blur/digitação seguem como Command único.
  const gestureOpen = useRef(false);
  const openGesture = () => {
    if (gestureOpen.current) return;
    gestureOpen.current = true;
    globalCommandManager.beginGesture();
  };
  const closeGesture = () => {
    if (!gestureOpen.current) return;
    gestureOpen.current = false;
    globalCommandManager.endGesture();
  };
  const commitLive = (next: number) => {
    openGesture();
    onCommit(next);
  };
  useEffect(() => closeGesture, []); // desmontar no meio do gesto fecha o gesto

  const commit = (text: string) => {
    const result = parseNumberInput(text, { integer, min, max });
    if (!result.ok) {
      setError(result.error);
      return false;
    }
    setError(null);
    setDraft(null);
    if (result.value !== value) onCommit(result.value);
    return true;
  };

  const shown = draft ?? formatNumberForInput(value);

  return (
    <>
      <input
        type="text"
        inputMode="decimal"
        value={shown}
        aria-label={rest['aria-label']}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        title={error ?? title}
        onDoubleClick={(e) => {
          setDraft(formatNumberForInput(value));
          e.currentTarget.focus();
          e.currentTarget.select();
        }}
        onPointerDown={(e) => {
          if (e.button !== 0) return;
          if (e.detail === 2) return;
          didDrag.current = false;
          dragState.current = { startX: e.clientX, startValue: value };
          e.currentTarget.setPointerCapture?.(e.pointerId);
        }}
        onPointerMove={(e) => {
          if (!dragState.current) return;
          const deltaX = e.clientX - dragState.current.startX;
          if (deltaX === 0) return;
          didDrag.current = true;
          const next = applyNumberDrag(dragState.current.startValue, deltaX, step, { integer, min, max });
          setDraft(formatNumberForInput(next));
          if (next !== value) commitLive(next);
        }}
        onPointerUp={(e) => {
          closeGesture();
          if (!dragState.current) return;
          dragState.current = null;
          setDraft(null);
          setError(null);
          // depois de arrastar o foco sai do campo: Ctrl+Z/Delete globais voltam a valer (clique simples mantém o foco para digitar)
          if (didDrag.current) {
            didDrag.current = false;
            e.currentTarget.blur();
          }
        }}
        onPointerCancel={() => {
          closeGesture();
          dragState.current = null;
          setDraft(null);
        }}
        onLostPointerCapture={() => {
          closeGesture();
          dragState.current = null;
        }}
        onPointerLeave={() => {
          if (!dragState.current) return;
          closeGesture();
          dragState.current = null;
          setDraft(null);
          setError(null);
        }}
        onFocus={(e) => {
          setDraft(formatNumberForInput(value));
          e.currentTarget.select();
        }}
        onChange={(e) => {
          setDraft(e.target.value);
          setError(null);
        }}
        onBlur={() => {
          closeGesture();
          if (draft === null) return;
          if (draft === formatNumberForInput(value)) {
            setDraft(null);
            setError(null);
            return;
          }
          commit(draft);
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            if (commit(draft ?? formatNumberForInput(value))) e.currentTarget.blur();
          } else if (e.key === 'Escape') {
            e.stopPropagation();
            setDraft(null);
            setError(null);
            e.currentTarget.blur();
          } else if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
            e.preventDefault();
            const parsed = parseNumberInput(draft ?? formatNumberForInput(value), { integer, min, max });
            const base = parsed.ok ? parsed.value : value;
            const next = stepNumber(base, e.key === 'ArrowUp' ? 1 : -1, integer ? Math.max(1, Math.round(step)) : step, e.shiftKey, { min, max });
            setError(null);
            setDraft(formatNumberForInput(next));
            if (next !== value) commitLive(next);
          }
        }}
        onKeyUp={(e) => {
          if (e.key === 'ArrowUp' || e.key === 'ArrowDown') closeGesture();
        }}
        className={`${className}${error ? ' !border-red-500 !text-red-300 !bg-red-500/10' : ''} cursor-ew-resize`}
      />
      {error && (
        <span id={errorId} role="alert" className="sr-only">
          {error}
        </span>
      )}
    </>
  );
};
