import { tNow } from '../../core/i18n';
/**
 * AIS-23 — Lógica pura do campo numérico do Inspector (rascunho textual).
 *
 * O campo mantém o texto digitado como rascunho e só grava em Enter/blur com valor finito.
 * Aceita vírgula ou ponto decimal (pt-BR); entrada inválida devolve uma mensagem de erro
 * (acessível no campo) e nunca lança exceção.
 */

export interface NumberParseOptions {
  /** Campo inteiro: rejeita valores com parte fracionária. */
  integer?: boolean;
  min?: number;
  max?: number;
}

export type NumberParseResult = { ok: true; value: number } | { ok: false; error: string };

const NUMBER_SHAPE = /^[+-]?(\d+([.,]\d*)?|[.,]\d+)([eE][+-]?\d+)?$/;

export function parseNumberInput(text: string, options: NumberParseOptions = {}): NumberParseResult {
  const raw = text.trim();
  if (raw === '') return { ok: false, error: tNow('numberInputMsgNow.enterANumber') };
  if (!NUMBER_SHAPE.test(raw)) return { ok: false, error: tNow('numberInputMsgNow.invalidNumber') };

  const value = Number(raw.replace(',', '.'));
  if (!Number.isFinite(value)) return { ok: false, error: tNow('numberInputMsgNow.numberOutOfRange') };
  if (options.integer && !Number.isInteger(value)) return { ok: false, error: tNow('numberInputMsgNow.useAWholeNumber') };

  let clamped = value;
  if (typeof options.min === 'number' && clamped < options.min) clamped = options.min;
  if (typeof options.max === 'number' && clamped > options.max) clamped = options.max;
  return { ok: true, value: clamped };
}

/** Ajusta um valor ao arrastar horizontalmente o cursor, respeitando `step`, min/max e inteiro. */
export function applyNumberDrag(value: number, deltaX: number, step: number, options: NumberParseOptions = {}): number {
  const safeStep = Number.isFinite(step) && step > 0 ? step : 1;
  const delta = deltaX * safeStep * 0.02;

  let next = options.integer ? Math.round(value + delta) : Number((value + delta).toFixed(6));
  if (typeof options.min === 'number' && next < options.min) next = options.min;
  if (typeof options.max === 'number' && next > options.max) next = options.max;
  return next;
}

/** Texto exibido para um valor (separador decimal do idioma; sem agrupamento de milhar). */
export function formatNumberForInput(value: unknown, locale?: string): string {
  const n = typeof value === 'number' && Number.isFinite(value) ? value : 0;
  return new Intl.NumberFormat(locale, { maximumFractionDigits: 6, useGrouping: false }).format(Object.is(n, -0) ? 0 : n);
}

/** Valor depois de ArrowUp/ArrowDown (passo; Shift = ×10), sem erro de ponto flutuante visível. */
export function stepNumber(value: number, direction: 1 | -1, step: number, shift: boolean, options: NumberParseOptions = {}): number {
  const delta = step * (shift ? 10 : 1) * direction;
  let next = Number((value + delta).toFixed(6));
  if (typeof options.min === 'number' && next < options.min) next = options.min;
  if (typeof options.max === 'number' && next > options.max) next = options.max;
  return next;
}
