import { describe, expect, it } from 'vitest';
import { applyNumberDrag, formatNumberForInput, parseNumberInput, stepNumber } from './numberInput';

describe('parseNumberInput (AIS-23)', () => {
  it('aceita ponto e vírgula decimal (pt-BR), sinais e notação científica', () => {
    expect(parseNumberInput('1.5')).toEqual({ ok: true, value: 1.5 });
    expect(parseNumberInput('1,5')).toEqual({ ok: true, value: 1.5 });
    expect(parseNumberInput('  -0,25 ')).toEqual({ ok: true, value: -0.25 });
    expect(parseNumberInput('+3')).toEqual({ ok: true, value: 3 });
    expect(parseNumberInput(',5')).toEqual({ ok: true, value: 0.5 });
    expect(parseNumberInput('2e3')).toEqual({ ok: true, value: 2000 });
  });

  it('rejeita vazio, texto, vários separadores e lixo — sem exceção', () => {
    for (const bad of ['', '   ', 'abc', '1,2,3', '1.2.3', '--1', '1e', '0x10', '1 2', '∞', 'NaN', 'Infinity']) {
      const r = parseNumberInput(bad);
      expect(r.ok).toBe(false);
      if (!r.ok) expect(r.error.length).toBeGreaterThan(0);
    }
  });

  it('valor não finito (estouro) é inválido', () => {
    expect(parseNumberInput('1e999').ok).toBe(false);
  });

  it('campo inteiro rejeita fração', () => {
    expect(parseNumberInput('3', { integer: true })).toEqual({ ok: true, value: 3 });
    expect(parseNumberInput('3,5', { integer: true }).ok).toBe(false);
    expect(parseNumberInput('3.0', { integer: true })).toEqual({ ok: true, value: 3 });
  });

  it('respeita min e max do descriptor (limita o valor)', () => {
    expect(parseNumberInput('-5', { min: 0 })).toEqual({ ok: true, value: 0 });
    expect(parseNumberInput('99', { max: 10 })).toEqual({ ok: true, value: 10 });
    expect(parseNumberInput('5', { min: 0, max: 10 })).toEqual({ ok: true, value: 5 });
  });
});

describe('formatNumberForInput / stepNumber', () => {
  it('usa o separador do idioma, sem milhar e sem -0', () => {
    expect(formatNumberForInput(1.5, 'pt-BR')).toBe('1,5');
    expect(formatNumberForInput(1.5, 'en-US')).toBe('1.5');
    expect(formatNumberForInput(1234567.25, 'pt-BR')).toBe('1234567,25');
    expect(formatNumberForInput(-0, 'en-US')).toBe('0');
    expect(formatNumberForInput(undefined, 'en-US')).toBe('0');
    expect(formatNumberForInput(NaN, 'en-US')).toBe('0');
  });

  it('o texto formatado volta ao mesmo valor (ida e volta)', () => {
    for (const v of [0, 1.5, -3.25, 0.000123, 1000.5]) {
      for (const loc of ['pt-BR', 'en-US']) {
        const r = parseNumberInput(formatNumberForInput(v, loc));
        expect(r).toEqual({ ok: true, value: v });
      }
    }
  });

  it('stepNumber: passo, Shift ×10, limites e sem ruído de ponto flutuante', () => {
    expect(stepNumber(0.1, 1, 0.1, false)).toBe(0.2);
    expect(stepNumber(0.7, 1, 0.1, false)).toBe(0.8);
    expect(stepNumber(1, -1, 0.5, true)).toBe(-4);
    expect(stepNumber(9.9, 1, 0.5, false, { max: 10 })).toBe(10);
    expect(stepNumber(0.2, -1, 0.5, false, { min: 0 })).toBe(0);
  });

  it('applyNumberDrag: arrastar no eixo X ajusta o valor usando o passo e respeita limites', () => {
    expect(applyNumberDrag(1, 20, 0.1)).toBeCloseTo(1.04, 6);
    expect(applyNumberDrag(1, -30, 0.5)).toBeCloseTo(0.7, 6);
    expect(applyNumberDrag(2, 150, 1, { min: 0, max: 5 })).toBe(5);
    expect(applyNumberDrag(2, -150, 1, { min: 0, max: 5 })).toBe(0);
    expect(applyNumberDrag(2, 40, 1, { integer: true })).toBe(3);
  });
});
