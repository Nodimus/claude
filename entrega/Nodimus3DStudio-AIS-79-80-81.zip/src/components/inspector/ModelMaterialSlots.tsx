import React, { useMemo, useState } from 'react';
import type { GameNode } from '../../types/node';
import type { MaterialOverride } from '../../types/material';
import { useEditor } from '../../core/EditorContext';
import { globalAuthoringModel } from '../../core/authoring';
import { globalResourceRegistry } from '../../core/resources/global';
import { useResourceRegistryVersion } from '../../core/resources/useResources';
import { parseModelMaterialManifest, type ManifestMaterial } from '../../schemas/v1/modelMaterialManifest.schema';
import { colorToHex, hexToColor, patchMaterialSlot, resolveSlotMaterial, slotRows, type SlotRow } from '../../core/modelImport/materials';
import { DraftNumberInput } from './DraftNumberInput';
import { useTranslation } from '../../core/i18n/I18nContext';
import { tk, type TextRef } from '../../core/i18n/index';

const toRef = (v: unknown) => (v && typeof v === 'object' && typeof (v as { id?: unknown }).id === 'string' ? (v as { id: string }) : null);
const NUM = 'w-14 bg-[#12151c] text-[11px] text-right font-mono text-white px-1 py-0.5 rounded border border-[#2c3345] focus:border-blue-500 outline-none';
const KIND_LABEL: Record<SlotRow['kind'], TextRef> = { slot: tk('moduleUi.kindSlot'), override: tk('moduleUi.kindOverride'), original: tk('moduleUi.kindOriginal') };

/** Materiais do manifesto do modelo (`importSettings.materials` → `res://textures/<asset>_material.json`). Vazio sem manifesto. */
function useManifestMaterials(node: GameNode): ManifestMaterial[] {
  const version = useResourceRegistryVersion();
  const { project } = useEditor();
  return useMemo(() => {
    const modelRef = toRef(node.properties.model);
    if (!modelRef) return [];
    const resolved = globalResourceRegistry.resolve(modelRef as never);
    if (resolved.status !== 'resolved') return [];
    const manifestRef = toRef((resolved.entry.importSettings as Record<string, unknown> | undefined)?.materials);
    if (!manifestRef) return [];
    const target = globalResourceRegistry.resolve(manifestRef as never);
    if (target.status !== 'resolved') return [];
    const content = (project.files ?? globalAuthoringModel.getProject().files)[target.entry.uri]?.content;
    const parsed = content ? parseModelMaterialManifest(content) : null;
    return parsed?.ok ? parsed.manifest.materials : [];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [node.properties.model, project.files, version]);
}

/**
 * AIS-35 (decisão 3.2) — lista os slots de material de um nó com `model`: um por material do arquivo. Slot sem entrada = material
 * original (ou o `materialOverride` do nó, que vale como padrão); editar grava só `materialSlots[<nome>]` num Command.
 */
export const ModelMaterialSlots: React.FC<{ node: GameNode }> = ({ node }) => {
  const { t } = useTranslation();
  const { changeNodeProperty } = useEditor();
  const base = useManifestMaterials(node);
  const rows = useMemo(() => slotRows(node.properties, base), [node.properties, base]);
  const [open, setOpen] = useState<string | null>(null);

  const write = (name: string, patch: MaterialOverride | null) => {
    const current = resolveSlotMaterial(node.properties, name);
    const own = current.kind === 'slot' ? current.override : {};
    const next = patch === null ? null : { ...own, ...patch };
    changeNodeProperty(node.id, 'materialSlots', patchMaterialSlot(node.properties, name, next));
  };

  return (
    <div className="space-y-1.5 pt-1 border-t border-[#252c3c]" data-testid="model-material-slots">
      <div className="flex items-center justify-between text-[11px]">
        <span className="font-semibold text-white">{t('modelMaterialSlots.modelMaterialSlots', { length: rows.length })}</span>
        <span className="text-[10px] text-[#718096]">{t('modelMaterialSlots.missingSlotOriginal')}</span>
      </div>
      {rows.length === 0 && <div className="text-[10px] text-[#8695ad]">{t('modelMaterialSlots.thisModelWasImportedWithout')}</div>}
      {rows.map((row) => {
        const expanded = open === row.name;
        return (
          <div key={row.name} className="rounded border border-[#252c3c] bg-[#12151c]">
            <button onClick={() => setOpen(expanded ? null : row.name)} aria-expanded={expanded} className="w-full flex items-center gap-2 px-2 py-1 text-left">
              <span className="w-3 h-3 rounded-full border border-white/20 shrink-0" style={{ backgroundColor: colorToHex(row.values.color) }} />
              <span className="flex-1 truncate text-[11px] text-white">{row.name}</span>
              <span className={`text-[9px] ${row.kind === 'slot' ? 'text-amber-400' : 'text-[#718096]'}`}>{t(KIND_LABEL[row.kind].key)}</span>
            </button>
            {expanded && (
              <div className="px-2 pb-2 space-y-1.5 text-[10px] text-[#8b97a8]">
                <label className="flex items-center justify-between gap-2">
                  <span>Cor</span>
                  <input type="color" aria-label={t('modelMaterialSlotsMsg.colorOfSlot', { name: row.name })} value={colorToHex(row.values.color)} onChange={(e) => write(row.name, { color: hexToColor(e.target.value, row.values.color) })} className="w-6 h-5 p-0 bg-transparent border border-[#2c3345] rounded cursor-pointer" />
                </label>
                <label className="flex items-center justify-between gap-2">
                  <span>{t('shared.roughness')}</span>
                  <DraftNumberInput value={row.values.roughness} min={0} max={1} step={0.05} className={NUM} aria-label={t('modelMaterialSlotsMsg.roughnessOfSlot', { name: row.name })} onCommit={(roughness) => write(row.name, { roughness })} />
                </label>
                <label className="flex items-center justify-between gap-2">
                  <span>{t('shared.metalness')}</span>
                  <DraftNumberInput value={row.values.metalness} min={0} max={1} step={0.05} className={NUM} aria-label={t('modelMaterialSlotsMsg.metalnessOfSlot', { name: row.name })} onCommit={(metalness) => write(row.name, { metalness })} />
                </label>
                <label className="flex items-center justify-between gap-2">
                  <span>{t('shared.emissive')}</span>
                  <input type="color" aria-label={t('modelMaterialSlotsMsg.emissiveOfSlot', { name: row.name })} value={colorToHex(row.values.emissiveColor)} onChange={(e) => write(row.name, { emissiveColor: hexToColor(e.target.value, row.values.emissiveColor) })} className="w-6 h-5 p-0 bg-transparent border border-[#2c3345] rounded cursor-pointer" />
                </label>
                <label className="flex items-center justify-between gap-2">
                  <span>{t('shared.emissiveIntensity')}</span>
                  <DraftNumberInput value={row.values.emissiveIntensity} min={0} max={10} step={0.1} className={NUM} aria-label={t('modelMaterialSlotsMsg.emissiveIntensityOfSlot', { name: row.name })} onCommit={(emissiveIntensity) => write(row.name, { emissiveIntensity })} />
                </label>
                <div className="flex items-center justify-between gap-2">
                  <span>{t('shared.tilingUv')}</span>
                  <span className="flex gap-1">
                    <DraftNumberInput value={row.values.uvTiling.x} min={0.01} max={64} step={0.5} className={NUM} aria-label={t('modelMaterialSlotsMsg.tilingUvXOfSlot', { name: row.name })} onCommit={(x) => write(row.name, { uvTiling: { ...row.values.uvTiling, x } })} />
                    <DraftNumberInput value={row.values.uvTiling.y} min={0.01} max={64} step={0.5} className={NUM} aria-label={t('modelMaterialSlotsMsg.tilingUvYOfSlot', { name: row.name })} onCommit={(y) => write(row.name, { uvTiling: { ...row.values.uvTiling, y } })} />
                  </span>
                </div>
                {row.kind === 'slot' && (
                  <button onClick={() => write(row.name, null)} className="w-full mt-1 px-2 py-1 rounded bg-[#1b2230] hover:bg-[#2b354a] border border-[#2e3b52] text-[#93a1b8]">
                    {t('modelMaterialSlots.revertToOriginal')}
                  </button>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
