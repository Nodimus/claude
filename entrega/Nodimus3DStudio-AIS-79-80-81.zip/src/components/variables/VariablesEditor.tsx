import React, { useState } from 'react';
import { Plus, Trash2, AlertTriangle } from 'lucide-react';
import { VARIABLE_TYPES, describeConsumer, isEditableType, type VariableConsumer, type VariableType } from '../../core/variableManager';
import { useTranslation } from '../../core/i18n/I18nContext';

/**
 * AIS-43 — lista editável de variáveis, a MESMA para as globais (aba Variables do Project Settings) e as locais (seção
 * Variables do Inspector). Não conhece Commands nem stores: quem usa decide o que cada callback faz e devolve a mensagem de
 * erro (`string`) ou `null` quando aceitou. Erro de nome duplicado aparece inline na própria linha, sem fechar nada.
 */
export interface VariableRow {
  /** Identidade da linha (ID da global; nome da local). */
  key: string;
  name: string;
  /** Tipos além de number/string/boolean (ex.: vector3, de dados antigos) ficam visíveis, só leitura. */
  type: string;
  value: unknown;
}

interface Props {
  rows: VariableRow[];
  onAdd(input: { name: string; type: VariableType; value: string }): string | null;
  onRename(key: string, name: string): string | null;
  onUpdate(key: string, patch: { type?: VariableType; value?: string | boolean }): string | null;
  onRemove(key: string): void;
  consumersOf(row: VariableRow): VariableConsumer[];
  testId: string;
  emptyHint: string;
}

const INPUT = 'bg-[#141820] text-white px-2 py-1 rounded border border-[#2c3345] outline-none focus:border-[#4982ea] min-w-0';

const display = (v: unknown): string => (typeof v === 'string' ? v : v === undefined ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v));

/** Campo de texto que só confirma em Enter/blur (Esc volta); mantém o rascunho enquanto o pai recusa. */
const CommitInput: React.FC<{ value: string; onCommit: (text: string) => string | null; className?: string; label: string; testId?: string; onError: (e: string | null) => void }> = ({ value, onCommit, className, label, testId, onError }) => {
  const [text, setText] = useState<string | null>(null);
  const shown = text ?? value;
  const commit = () => {
    if (text === null) return;
    if (text === value) {
      setText(null);
      onError(null);
      return;
    }
    const error = onCommit(text);
    onError(error);
    if (!error) setText(null);
  };
  return (
    <input
      aria-label={label}
      data-testid={testId}
      className={`${INPUT} ${className ?? ''}`}
      value={shown}
      onChange={(e) => setText(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === 'Enter') (e.currentTarget as HTMLInputElement).blur();
        else if (e.key === 'Escape') {
          setText(null);
          onError(null);
          e.stopPropagation();
        }
      }}
    />
  );
};

export const VariablesEditor: React.FC<Props> = ({ rows, onAdd, onRename, onUpdate, onRemove, consumersOf, testId, emptyHint }) => {
  const { t: tr } = useTranslation();
  const [errors, setErrors] = useState<Record<string, string | null>>({});
  const setError = (key: string, e: string | null) => setErrors((prev) => (prev[key] === e ? prev : { ...prev, [key]: e }));
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const [draft, setDraft] = useState<{ name: string; type: VariableType; value: string }>({ name: '', type: 'number', value: '' });
  const [addError, setAddError] = useState<string | null>(null);

  const add = () => {
    const error = onAdd(draft);
    setAddError(error);
    if (!error) setDraft((d) => ({ ...d, name: '', value: '' }));
  };

  const askDelete = (row: VariableRow) => {
    if (consumersOf(row).length === 0) onRemove(row.key);
    else setPendingDelete(row.key);
  };

  return (
    <div className="space-y-2" data-testid={testId}>
      {rows.length === 0 && <p className="text-[11px] text-[#8b97a8]">{emptyHint}</p>}

      {rows.map((row) => {
        const editable = isEditableType(row.type);
        const consumers = pendingDelete === row.key ? consumersOf(row) : [];
        return (
          <div key={row.key} data-testid={`${testId}-row-${row.name}`}>
            <div className="flex items-center gap-1.5">
              <CommitInput label={tr('variablesEditorMsg.variableName', { name: row.name })} value={row.name} className="w-[34%]" testId={`${testId}-name-${row.name}`} onCommit={(t) => onRename(row.key, t)} onError={(e) => setError(row.key, e)} />
              {editable ? (
                <select
                  aria-label={tr('variablesEditorMsg.typeOf', { name: row.name })}
                  className={`${INPUT} w-[22%]`}
                  value={row.type}
                  onChange={(e) => setError(row.key, onUpdate(row.key, { type: e.target.value as VariableType }))}
                >
                  {VARIABLE_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              ) : (
                <span className="w-[22%] text-[11px] text-[#8b97a8] truncate" title={tr('variablesEditor.typePreservedEditInThe')}>
                  {row.type}
                </span>
              )}
              {!editable ? (
                <span className="flex-1 text-[11px] text-[#8b97a8] truncate font-mono">{display(row.value)}</span>
              ) : row.type === 'boolean' ? (
                <select aria-label={tr('sharedMsg.valueOf', { name: row.name })} className={`${INPUT} flex-1`} value={String(row.value === true)} onChange={(e) => setError(row.key, onUpdate(row.key, { value: e.target.value === 'true' }))}>
                  <option value="true">{tr('shared.true')}</option>
                  <option value="false">{tr('shared.false')}</option>
                </select>
              ) : (
                <CommitInput label={tr('sharedMsg.valueOf', { name: row.name })} value={display(row.value)} className="flex-1" testId={`${testId}-value-${row.name}`} onCommit={(t) => onUpdate(row.key, { value: t })} onError={(e) => setError(row.key, e)} />
              )}
              <button type="button" onClick={() => askDelete(row)} className="p-1 text-[#8b97a8] hover:text-rose-400" aria-label={tr('variablesEditorMsg.deleteVariable', { name: row.name })} title={tr('variablesEditor.deleteVariable')}>
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
            {errors[row.key] && (
              <span role="alert" className="text-[10px] text-rose-400 block mt-0.5" data-testid={`${testId}-error-${row.name}`}>
                {errors[row.key]}
              </span>
            )}
            {pendingDelete === row.key && consumers.length > 0 && (
              <div role="alertdialog" aria-label={tr('sharedMsg.delete', { name: row.name })} className="mt-1 rounded border border-amber-500/40 bg-amber-500/10 p-2 text-[11px]" data-testid={`${testId}-delete-warning`}>
                <div className="flex items-center gap-1.5 text-amber-300 font-medium">
                  <AlertTriangle className="w-3.5 h-3.5" /> {tr('manualUi.variableUsedBy', { name: row.name, count: consumers.length })}
                </div>
                <ul className="list-disc pl-5 my-1 text-[#dfe4ec] max-h-24 overflow-y-auto">
                  {consumers.map((c, i) => (
                    <li key={`${c.behaviorId}-${c.ruleId}-${i}`}>{describeConsumer(c)}</li>
                  ))}
                </ul>
                <div className="flex gap-2 justify-end">
                  <button type="button" onClick={() => setPendingDelete(null)} className="px-2 py-0.5 rounded bg-[#202736] hover:bg-[#2b3548] text-[#a0afc4]">
                    {tr('shared.cancel')}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setPendingDelete(null);
                      onRemove(row.key);
                    }}
                    className="px-2 py-0.5 rounded bg-rose-600 hover:bg-rose-500 text-white"
                    data-testid={`${testId}-delete-confirm`}
                  >
                    {tr('variablesEditor.deleteAnyway')}
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })}

      <div className="pt-1 border-t border-[#2c3345]/60">
        <div className="flex items-center gap-1.5">
          <input
            aria-label={tr('variablesEditor.newVariableName')}
            data-testid={`${testId}-new-name`}
            placeholder={tr('variablesEditor.name')}
            className={`${INPUT} w-[34%]`}
            value={draft.name}
            onChange={(e) => {
              setDraft((d) => ({ ...d, name: e.target.value }));
              setAddError(null);
            }}
            onKeyDown={(e) => e.key === 'Enter' && add()}
          />
          <select aria-label={tr('variablesEditor.newVariableType')} data-testid={`${testId}-new-type`} className={`${INPUT} w-[22%]`} value={draft.type} onChange={(e) => setDraft((d) => ({ ...d, type: e.target.value as VariableType, value: '' }))}>
            {VARIABLE_TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
          {draft.type === 'boolean' ? (
            <select aria-label={tr('variablesEditor.initialValue')} className={`${INPUT} flex-1`} value={draft.value || 'false'} onChange={(e) => setDraft((d) => ({ ...d, value: e.target.value }))}>
              <option value="false">{tr('shared.false')}</option>
              <option value="true">{tr('shared.true')}</option>
            </select>
          ) : (
            <input
              aria-label={tr('variablesEditor.initialValue')}
              data-testid={`${testId}-new-value`}
              placeholder={draft.type === 'number' ? '0' : 'texto'}
              className={`${INPUT} flex-1`}
              value={draft.value}
              onChange={(e) => {
                setDraft((d) => ({ ...d, value: e.target.value }));
                setAddError(null);
              }}
              onKeyDown={(e) => e.key === 'Enter' && add()}
            />
          )}
          <button type="button" onClick={add} className="p-1 rounded bg-[#4982ea] hover:bg-[#3d72d6] text-white" aria-label={tr('variablesEditor.addVariable')} title={tr('variablesEditor.addVariable')} data-testid={`${testId}-add`}>
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>
        {addError && (
          <span role="alert" className="text-[10px] text-rose-400 block mt-0.5" data-testid={`${testId}-add-error`}>
            {addError}
          </span>
        )}
      </div>
    </div>
  );
};
