import React, { useEffect, useMemo, useState } from 'react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { globalCommandManager } from '../../core/commandManager';
import { globalResourceRegistry } from '../../core/resources/global';
import { useResourceRegistryVersion } from '../../core/resources/useResources';
import { ensureLibraryEntriesById } from '../../core/library/libraryUse';
import { libraryEntryById } from '../../core/library/assetLibrary';
import { useGeneratorEdit } from '../../core/generators/useGeneratorEdit';
import { createSetGeneratorSourceCommand } from '../../core/generators/generatorCommands';
import { globalAuthoringModel } from '../../core/authoring';
import { applyTerrainChanges, regenerateTerrainGeometry, registerTerrainGenerator, TERRAIN_GENERATOR_ID } from '../../core/generators/terrainGenerator';
import {
  TERRAIN_HIGH_TEXTURES,
  TERRAIN_GROUND_TEXTURES,
  TERRAIN_MID_TEXTURES,
  TERRAIN_PRESETS,
  TERRAIN_SEGMENT_OPTIONS,
  TERRAIN_TEXTURE_COLORS,
  type TerrainPreset,
} from '../../core/terrainGeometry';
import {
  draftChanges,
  draftFromProps,
  geometryDirty,
  hasSculptedHeights,
  normalizeDraft,
  regenerateChanges,
  terrainGeneratorSource,
  visualOnlyChanges,
  type TerrainDraft,
} from '../../core/terrainOps';
import { HeightmapPicker } from '../inspector/TerrainSection';
import { TerrainVegetationTab } from './TerrainVegetationTab';
import { Mountain, Trees, X, Upload, RotateCcw, Check, Palette, Info, Lock, TriangleAlert } from 'lucide-react';
import { useTranslation } from '../../core/i18n/I18nContext';
import { tk, type TextRef } from '../../core/i18n/index';

/** Mantido por compatibilidade com quem importava o tipo (preset de topologia = `terrainPreset`). */
export type TerrainTopology = TerrainPreset;

const LOCKED_TIP: TextRef = tk('moduleUi.lockedTip');
const nameOf = (uri: string) => uri.split('/').pop() ?? uri;

/**
 * AIS-50 — editor do nó `Terrain` (decisão 23). É só uma VIEW de edição: lê as `properties` do nó (o selecionado, ou o alvo de
 * "Editar no gerador"), guarda um rascunho de UI e grava por Command (um Undo). Não tem geometria nem estado de terreno próprios
 * e nunca cria `MeshInstance` com `isTerrain`; o preview é a viewport 3D real (o resultado aparece ao aplicar).
 * Abas: Gerar e Texturas. Escultura é do AIS-50b; Vegetação (AIS-51d) distribui árvores do editor sobre o terreno (nó `Vegetation`).
 */
export const TerrainEditorModal: React.FC = () => {
  const { t } = useTranslation();
  const { isTerrainEditorOpen, setIsTerrainEditorOpen, activeScene, addNode, selectNode, addLog } = useEditor();
  const selectedNodeId = useEditorStore((s) => s.selectedNodeId);
  const endGeneratorEdit = useEditorStore((s) => s.endGeneratorEdit);
  const addWithCollision = useEditorStore((s) => s.addWithCollision); // preferência do editor (decisão 26, emenda v5.5)
  const setAddWithCollision = useEditorStore((s) => s.setAddWithCollision);
  const gen = useGeneratorEdit(TERRAIN_GENERATOR_ID);
  useResourceRegistryVersion();

  // "Editar no gerador" registra o gerador (disposer devolvido no unmount, AIS-48b)
  useEffect(() => registerTerrainGenerator(), []);

  // alvo: o nó de "Editar no gerador" ou o Terrain selecionado; sem nenhum, o modal cria um novo
  const selected = selectedNodeId ? activeScene.nodes[selectedNodeId] : undefined;
  // AIS-56: um Terrain por cena — sem seleção própria, o modal edita o único Terrain existente em vez de criar outro
  const onlyTerrain = Object.values(activeScene.nodes).find((n) => n.type === 'Terrain');
  const node = gen.editing && gen.nodeId ? activeScene.nodes[gen.nodeId] : selected?.type === 'Terrain' ? selected : onlyTerrain;
  const sculpted = hasSculptedHeights(node?.properties);

  const [activeTab, setActiveTab] = useState<'generate' | 'textures' | 'vegetation'>('generate');
  const [draft, setDraft] = useState<TerrainDraft>(() => draftFromProps(undefined));
  const [pickerOpen, setPickerOpen] = useState(false);
  const [confirmRegenerate, setConfirmRegenerate] = useState(false);

  // o rascunho recomeça a cada abertura/troca de nó (nunca fica estado de terreno entre aberturas)
  useEffect(() => {
    if (!isTerrainEditorOpen) return;
    setDraft(draftFromProps(node?.properties));
    setActiveTab('generate');
    setConfirmRegenerate(false);
    setPickerOpen(false);
  }, [isTerrainEditorOpen, node?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const set = <K extends keyof TerrainDraft>(key: K, value: TerrainDraft[K]) => setDraft((d) => ({ ...d, [key]: value }));

  const heightmapEntry = useMemo(() => {
    if (!draft.heightmapRef) return null;
    const r = globalResourceRegistry.resolve(draft.heightmapRef);
    return r.status === 'resolved' ? r.entry : null;
  }, [draft.heightmapRef, globalResourceRegistry.version]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!isTerrainEditorOpen) return null;

  const normalized = normalizeDraft(draft);
  const allChanges = node ? draftChanges(node.properties, normalized) : {};
  const visualChanges = node ? visualOnlyChanges(node.properties, normalized) : {};
  const dirtyGeometry = node ? geometryDirty(node.properties, normalized) : false;

  const close = () => {
    endGeneratorEdit(); // fechar sem aplicar não altera o nó
    setIsTerrainEditorOpen(false);
  };

  /** Aplica por Command: via `useGeneratorEdit` quando veio de "Editar no gerador", senão direto (os dois = um `MacroCommand`). */
  const applyToNode = (changes: Record<string, any>, label: string): boolean => {
    if (!node) return false;
    if (gen.editing) {
      const source = terrainGeneratorSource({ ...node.properties, ...changes });
      return gen.apply(changes, source);
    }
    return applyTerrainChanges(node.id, changes, label);
  };

  /** Texturas das camadas: as da biblioteca (padrão) entram no projeto junto com a ação (o Undo da ação as remove). */
  const withLayerImports = async <T,>(layers: { groundTexture: string; midTexture: string; highTexture: string }, run: () => T): Promise<T> => {
    const { commands, failed } = await ensureLibraryEntriesById([layers.groundTexture, layers.midTexture, layers.highTexture]);
    for (const f of failed) addLog('warn', t('sharedMsg.textureNotImportedTheLayer', { id: f.id, error: f.error }));
    return globalCommandManager.transaction(t('leftovers.terrainTextures'), () => {
      for (const c of commands) globalCommandManager.pushCommand(c);
      return run();
    });
  };

  const handleApply = async () => {
    if (!node) return;
    await withLayerImports(normalized, () => applyToNode(allChanges, t('leftovers.applyToNode')));
    addLog('log', t('terrainEditorModalMsg.terrainUpdated', { name: node.name }));
    close();
  };

  const handleApplyVisual = async () => {
    if (!node) return;
    await withLayerImports(normalized, () => applyToNode(visualChanges, t('terrainEditorModalMsg.updateVisualParameters')));
    addLog('log', t('terrainEditorModalMsg.visualParametersOfUpdated', { name: node.name }));
    close();
  };

  const handleRegenerate = async () => {
    if (!node) return;
    if (sculpted && !confirmRegenerate) {
      setConfirmRegenerate(true); // nunca regenera em silêncio: a escultura será descartada
      return;
    }
    const changes = sculpted ? regenerateChanges(node.properties, normalized) : draftChanges(node.properties, normalized, ['width', 'depth', 'segmentsW', 'segmentsH', 'maxHeight', 'terrainPreset', 'presetSeed', 'heightmapRef', 'invertHeightmap', 'smoothHeightmap']);
    const result = await regenerateTerrainGeometry(node.id, changes);
    if (result.deletedFile) addLog('log', t('terrainEditorModalMsg.sculptDiscardedRemoved', { deletedFile: result.deletedFile }));
    addLog('log', t('terrainEditorModalMsg.geometryOfRegenerated', { name: node.name }));
    close();
  };

  /** Cria o Terrain da cena (só quando ainda não há um): nó + marca de origem = UMA transação (um Undo). */
  const handleCreateNew = async () => {
    if (Object.values(globalAuthoringModel.getScene().nodes).some((n) => n.type === 'Terrain')) {
      addLog('warn', t('terrainEditorModalMsg.theSceneAlreadyHasA'));
      return;
    }
    // decisão 26: o Terrain novo nasce com o bloco de colisão (estático, auto = heightfield) ligado ou desligado pela preferência
    const initial = { ...draftChanges(undefined, normalized), heightBufferRef: null, physics: { enabled: addWithCollision, bodyMode: 'static', shape: 'auto' } };
    const { commands, failed } = await ensureLibraryEntriesById([normalized.groundTexture, normalized.midTexture, normalized.highTexture]);
    for (const f of failed) addLog('warn', t('sharedMsg.textureNotImportedTheLayer', { id: f.id, error: f.error }));
    const created = globalCommandManager.transaction(t('leftovers.createTerrain'), () => {
      for (const c of commands) globalCommandManager.pushCommand(c); // as texturas importadas por esta criação saem no mesmo Undo
      const n = addNode('Terrain', activeScene.rootNodeId, 'Terrain', initial);
      const command = createSetGeneratorSourceCommand({ target: globalAuthoringModel, nodeId: n.id, source: terrainGeneratorSource({ ...n.properties, ...initial }) });
      if (command) globalCommandManager.execute(command);
      return n;
    });
    selectNode(created.id);
    addLog('log', t('terrainEditorModalMsg.terrainCreatedX', { name: created.name, segmentsW: normalized.segmentsW, segmentsH: normalized.segmentsH }));
    close();
  };

  /** Miniatura: a textura real da biblioteca (padrão); sem ela, a cor sólida da camada. */
  const swatch = (name: string): React.CSSProperties => {
    const url = libraryEntryById(name)?.urls.color;
    return url ? { backgroundImage: `url(${url})`, backgroundSize: 'cover', backgroundPosition: 'center' } : { background: TERRAIN_TEXTURE_COLORS[name]?.color ?? '#808080' };
  };
  const textureSelect = (value: string, names: readonly string[], onChange: (v: string) => void) => (
    <select value={value} onChange={(e) => onChange(e.target.value)} className="w-full px-2 py-1 bg-[#202636] border border-[#2c3345] rounded text-white">
      {names.map((n) => (
        <option key={n} value={n}>
          {TERRAIN_TEXTURE_COLORS[n]?.label ?? n}
        </option>
      ))}
    </select>
  );
  const lockedProps = (locked: boolean) => (locked ? { disabled: true, title: t(LOCKED_TIP.key) } : {});

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none" data-testid="terrain-editor-modal">
      <div className="w-[840px] h-[610px] bg-[#1e232f] border border-[#3b475f] rounded-lg shadow-2xl flex flex-col overflow-hidden text-xs text-[#dfe4ec]">
        {/* Header */}
        <div className="h-11 bg-[#171b24] border-b border-[#2c3345] px-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5 font-semibold text-white">
            <div className="p-1 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Mountain className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[13px]">{t('terrainEditorModal.terrainEditorGenerator')}</span>
                <span className="px-1.5 py-0.2 bg-[#2a3244] text-[#8b97a8] rounded text-[10px] font-normal">{node ? t('terrainEditorModalMsg.editing', { name: node.name }) : t('terrainEditorModalMsg.newTerrain')}</span>
                {sculpted && (
                  <span data-testid="terrain-sculpted-seal" className="px-1.5 py-0.2 bg-amber-500/15 text-amber-300 border border-amber-500/30 rounded text-[10px] font-normal">
                    {t('terrainEditorModal.manuallyEditedTerrain')}
                  </span>
                )}
              </div>
              <div className="text-[10px] text-[#8b97a8] font-normal">
                {t('shared.scene')} <span className="text-white">{activeScene?.name}</span>
              </div>
            </div>
          </div>
          <button onClick={close} aria-label={t('common.close')} className="p-1 text-[#8b97a8] hover:text-white rounded hover:bg-[#2c3345] transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar Tabs */}
          <div className="w-48 border-r border-[#2c3345] bg-[#171b24] p-2 space-y-1">
            <button
              onClick={() => setActiveTab('generate')}
              className={`w-full text-left px-3 py-2 rounded flex items-center gap-2 transition-colors ${activeTab === 'generate' ? 'bg-[#4982ea] text-white font-medium shadow-sm' : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'}`}
            >
              <Mountain className="w-3.5 h-3.5 text-amber-400" />
              <span>{t('terrainEditorModal.generationSize')}</span>
            </button>
            <button
              onClick={() => setActiveTab('textures')}
              className={`w-full text-left px-3 py-2 rounded flex items-center gap-2 transition-colors ${activeTab === 'textures' ? 'bg-[#4982ea] text-white font-medium shadow-sm' : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'}`}
            >
              <Palette className="w-3.5 h-3.5 text-sky-400" />
              <span>{t('terrainEditorModal.texturesSplatting')}</span>
            </button>
            <button
              onClick={() => setActiveTab('vegetation')}
              data-testid="terrain-tab-vegetation"
              className={`w-full text-left px-3 py-2 rounded flex items-center gap-2 transition-colors ${activeTab === 'vegetation' ? 'bg-[#4982ea] text-white font-medium shadow-sm' : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'}`}
            >
              <Trees className="w-3.5 h-3.5 text-emerald-400" />
              <span>{t('shared.vegetation')}</span>
            </button>

            <div className="pt-3">
              <div className="px-2 pb-1 text-[10px] font-semibold text-[#68768e] uppercase tracking-wider">{t('terrainEditorModal.preview')}</div>
              <div className="p-2 rounded bg-[#13161f] border border-[#2c3345] text-[10px] text-[#8b97a8] space-y-1" data-testid="terrain-preview-note">
                <div className="flex items-start gap-1.5">
                  <Info className="w-3 h-3 mt-0.5 shrink-0 text-sky-400" />
                  <span>{t('terrainEditorModal.thePreviewIsThe3d')}</span>
                </div>
                <div className="font-mono text-[#dfe4ec]">
                  {normalized.width}×{normalized.depth} m · {normalized.segmentsW}×{normalized.segmentsH}
                </div>
              </div>
            </div>
          </div>

          {/* Configuration Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#1b202c]">
            {confirmRegenerate && (
              <div className="rounded border border-amber-500/40 bg-amber-500/10 p-3 flex items-start gap-2 text-amber-200" role="alert" data-testid="terrain-regenerate-confirm">
                <TriangleAlert className="w-4 h-4 mt-0.5 shrink-0" />
                <div className="flex-1">
                  <div className="font-semibold">{t('terrainEditorModal.regeneratingTheGeometryDiscardsThe')}</div>
                  <div className="text-[11px]">{t('terrainEditorModal.theHeightFileLinkIs')}</div>
                  <div className="flex gap-2 pt-2">
                    <button onClick={() => void handleRegenerate()} className="px-2.5 py-1 rounded bg-amber-500 text-black font-medium hover:bg-amber-400">
                      {t('terrainEditorModal.discardSculptAndRegenerate')}
                    </button>
                    <button onClick={() => setConfirmRegenerate(false)} className="px-2.5 py-1 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec]">
                      {t('shared.cancel')}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'vegetation' && <TerrainVegetationTab terrain={node} onDone={close} />}

            {/* 1. Generate & Dimensions Tab */}
            {activeTab === 'generate' && (
              <div className="space-y-4">
                <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-[#2c3345]">
                    <Mountain className="w-4 h-4 text-amber-400" />
                    <div>
                      <div className="font-semibold text-white">{t('terrainEditorModal.terrainDimensionsGeometry')}</div>
                      <div className="text-[10px] text-[#8b97a8]">{t('terrainEditorModal.dimensionsInMetersMeshResolution')}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-[#8b97a8]">
                        <span>{t('terrainEditorModal.widthX')}</span>
                        <span className="text-white font-mono">{draft.width}m</span>
                      </div>
                      <input type="range" min={10} max={1000} step={10} value={draft.width} onChange={(e) => set('width', parseInt(e.target.value) || 120)} className="w-full accent-[#4982ea]" {...lockedProps(sculpted)} aria-label={t('terrainEditorModal.width')} />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-[#8b97a8]">
                        <span>{t('terrainEditorModal.depthZ')}</span>
                        <span className="text-white font-mono">{draft.depth}m</span>
                      </div>
                      <input type="range" min={10} max={1000} step={10} value={draft.depth} onChange={(e) => set('depth', parseInt(e.target.value) || 120)} className="w-full accent-[#4982ea]" {...lockedProps(sculpted)} aria-label={t('terrainEditorModal.depth')} />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-[#8b97a8]">
                        <span>{t('terrainEditorModal.maxHeightElevation', { value: sculpted ? t('terrainEditorModalMsg.visualScale') : '' })}</span>
                        <span className="text-white font-mono">{draft.maxHeight}m</span>
                      </div>
                      <input type="range" min={1} max={200} step={1} value={draft.maxHeight} onChange={(e) => set('maxHeight', parseInt(e.target.value) || 24)} className="w-full accent-[#4982ea]" aria-label={t('terrainEditorModal.maxHeight')} />
                    </div>
                    <div>
                      <label className="text-[#8b97a8] block mb-1">{t('terrainEditorModal.resolutionSegmentsWH')}</label>
                      <div className="flex gap-1.5">
                        <select
                          value={draft.segmentsW}
                          onChange={(e) => set('segmentsW', parseInt(e.target.value))}
                          className="flex-1 px-2.5 py-1.5 bg-[#171b24] border border-[#2c3345] rounded text-white disabled:opacity-50"
                          aria-label={t('terrainEditorModal.segmentsW')}
                          {...lockedProps(sculpted)}
                        >
                          {TERRAIN_SEGMENT_OPTIONS.map((v) => (
                            <option key={v} value={v}>
                              {v}
                            </option>
                          ))}
                        </select>
                        <select
                          value={draft.segmentsH}
                          onChange={(e) => set('segmentsH', parseInt(e.target.value))}
                          className="flex-1 px-2.5 py-1.5 bg-[#171b24] border border-[#2c3345] rounded text-white disabled:opacity-50"
                          aria-label={t('terrainEditorModal.segmentsH')}
                          {...lockedProps(sculpted)}
                        >
                          {TERRAIN_SEGMENT_OPTIONS.map((v) => (
                            <option key={v} value={v}>
                              {v}
                            </option>
                          ))}
                        </select>
                      </div>
                      <span className="text-[10px] text-[#718096] mt-0.5 block">{t('terrainEditorModal.n128128IsRecommendedFor')}</span>
                    </div>
                  </div>

                  <div className="pt-1">
                    <label className="text-[#8b97a8] block mb-1">{t('terrainEditorModal.terrainPresetUsedWhenThere')}</label>
                    <div className="grid grid-cols-5 gap-1.5">
                      {TERRAIN_PRESETS.map((p) => (
                        <button
                          key={p.id}
                          onClick={() => set('terrainPreset', p.id)}
                          disabled={sculpted}
                          title={sculpted ? t(LOCKED_TIP.key) : p.label}
                          className={`px-2 py-1.5 rounded text-center transition-colors border disabled:opacity-50 disabled:cursor-not-allowed ${draft.terrainPreset === p.id ? 'bg-[#4982ea] text-white border-blue-400 font-medium' : 'bg-[#171b24] text-[#8b97a8] border-[#2c3345] hover:text-white'}`}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                    <div className="flex items-center gap-2 pt-2 text-[#8b97a8]">
                      <span>{t('terrainEditorModal.seed')}</span>
                      <input
                        type="number"
                        value={draft.presetSeed}
                        onChange={(e) => set('presetSeed', Math.trunc(Number(e.target.value)) || 0)}
                        className="w-28 px-2 py-1 bg-[#171b24] border border-[#2c3345] rounded text-white font-mono disabled:opacity-50"
                        aria-label={t('terrainEditorModal.seed')}
                        {...lockedProps(sculpted)}
                      />
                      <button
                        onClick={() => set('presetSeed', Math.floor(Math.random() * 1_000_000))}
                        disabled={sculpted}
                        title={sculpted ? t(LOCKED_TIP.key) : t('terrainEditorModalMsg.rollsANewSeedApply')}
                        className="px-2 py-1 rounded bg-[#2a3244] hover:bg-[#343e54] text-white border border-[#3b475f] disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {t('terrainEditorModal.randomize')}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Heightmap Card */}
                <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-[#2c3345]">
                    <Upload className="w-4 h-4 text-sky-400" />
                    <div>
                      <div className="font-semibold text-white">{t('terrainEditorModal.heightmapOptional')}</div>
                      <div className="text-[10px] text-[#8b97a8]">{t('terrainEditorModalResA.grayscalePngJpgImageFrom')}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setPickerOpen(true)}
                      disabled={sculpted}
                      title={sculpted ? t(LOCKED_TIP.key) : t('terrainEditorModalMsg.chooseAProjectImage')}
                      className="px-3 py-1.5 rounded bg-[#2a3244] hover:bg-[#343e54] text-white font-medium border border-[#3b475f] flex items-center gap-1.5 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{t('terrainEditorModal.chooseHeightmap')}</span>
                    </button>
                    <button onClick={() => set('heightmapRef', null)} disabled={sculpted || !draft.heightmapRef} className="px-2.5 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] disabled:opacity-50 disabled:cursor-not-allowed" title={sculpted ? t(LOCKED_TIP.key) : t('terrainEditorModalMsg.backToPreset')}>
                      {t('shared.clear')}
                    </button>
                    <span className="text-[#8b97a8] truncate max-w-xs font-mono" data-testid="terrain-modal-heightmap">
                      {draft.heightmapRef ? (heightmapEntry ? nameOf(heightmapEntry.uri) : 'unresolved') : t('sharedMsg.noneUsesThePreset')}
                    </span>
                  </div>
                  <div className="flex items-center gap-6 pt-1 text-[#8b97a8]">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={draft.invertHeightmap} onChange={(e) => set('invertHeightmap', e.target.checked)} disabled={sculpted} className="rounded bg-[#171b24] border-[#2c3345] text-[#4982ea]" />
                      <span>{t('terrainEditorModal.invertHeightmap')}</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={draft.smoothHeightmap} onChange={(e) => set('smoothHeightmap', e.target.checked)} disabled={sculpted} className="rounded bg-[#171b24] border-[#2c3345] text-[#4982ea]" />
                      <span>{t('terrainEditorModal.smoothHeightmapFiltering')}</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* 2. Textures & Splatting Tab */}
            {activeTab === 'textures' && (
              <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-[#2c3345]">
                  <Palette className="w-4 h-4 text-sky-400" />
                  <div>
                    <div className="font-semibold text-white">{t('terrainEditorModal.multiTextureElevationSplatting')}</div>
                    <div className="text-[10px] text-[#8b97a8]">{t('terrainEditorModal.layersByRelativeAltitudeGround')}</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="p-3 rounded bg-[#171b24] border border-[#2c3345] space-y-2">
                    <div className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                      <span>{t('terrainEditorModal.groundValleyBase')}</span>
                    </div>
                    {textureSelect(draft.groundTexture, TERRAIN_GROUND_TEXTURES, (v) => set('groundTexture', v))}
                    <div className="h-14 rounded border border-[#2c3345] flex items-center justify-center text-[10px] text-white/90 [text-shadow:0_1px_2px_#000]" style={swatch(draft.groundTexture)}>
                      {draft.groundTexture}
                    </div>
                  </div>
                  <div className="p-3 rounded bg-[#171b24] border border-[#2c3345] space-y-2">
                    <div className="text-[11px] font-semibold text-amber-400 flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                      <span>{t('terrainEditorModal.midLevelSlopeCliff')}</span>
                    </div>
                    {textureSelect(draft.midTexture, TERRAIN_MID_TEXTURES, (v) => set('midTexture', v))}
                    <div className="h-14 rounded border border-[#2c3345] flex items-center justify-center text-[10px] text-white/90 [text-shadow:0_1px_2px_#000]" style={swatch(draft.midTexture)}>
                      {draft.midTexture}
                    </div>
                  </div>
                  <div className="p-3 rounded bg-[#171b24] border border-[#2c3345] space-y-2">
                    <div className="text-[11px] font-semibold text-cyan-300 flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                      <span>{t('terrainEditorModal.highPointMountainPeak')}</span>
                    </div>
                    {textureSelect(draft.highTexture, TERRAIN_HIGH_TEXTURES, (v) => set('highTexture', v))}
                    <div className="h-14 rounded border border-[#2c3345] flex items-center justify-center text-[10px] text-slate-800" style={swatch(draft.highTexture)}>
                      {draft.highTexture}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div className="space-y-1">
                    <div className="flex justify-between text-[#8b97a8]">
                      <span>{t('terrainEditorModal.textureUvTilingRepeat')}</span>
                      <span className="text-white font-mono">{draft.textureTiling}x</span>
                    </div>
                    <input type="range" min={4} max={64} step={4} value={draft.textureTiling} onChange={(e) => set('textureTiling', parseInt(e.target.value) || 16)} className="w-full accent-[#4982ea]" aria-label={t('terrainEditorModal.textureTiling')} />
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[#8b97a8]">
                      <span>{t('terrainEditorModal.layerBlendSharpness')}</span>
                      <span className="text-white font-mono">{draft.blendSharpness.toFixed(2)}</span>
                    </div>
                    <input type="range" min={0} max={1} step={0.05} value={draft.blendSharpness} onChange={(e) => set('blendSharpness', parseFloat(e.target.value) || 0)} className="w-full accent-[#4982ea]" aria-label={t('terrainEditorModal.blendSharpness')} />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="h-12 bg-[#171b24] border-t border-[#2c3345] px-4 flex items-center justify-between">
          <button
            onClick={() => setDraft(draftFromProps(sculpted ? { ...node?.properties } : undefined))}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#8b97a8] hover:text-white transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t('terrainEditorModal.resetDefaults')}</span>
          </button>

          <div className="flex items-center gap-2">
            <label className="flex items-center gap-1.5 text-[#8b97a8] mr-2 cursor-pointer" title={t('terrainEditorModal.appliesToTheTerrainCreated')}>
              <input
                type="checkbox"
                checked={addWithCollision}
                onChange={(e) => setAddWithCollision(e.target.checked)}
                className="w-3.5 h-3.5 rounded bg-[#181c24] border border-[#2c3345] text-[#4982ea] focus:ring-0 focus:ring-offset-0 cursor-pointer"
              />
              {t('shared.addWithCollision')}
            </label>
            <button onClick={close} className="px-3.5 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] transition-colors">
              {t('common.cancel')}
            </button>
            {!node && (
              <button onClick={handleCreateNew} className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-[#4982ea] hover:bg-[#3b6ecc] text-white font-medium shadow-md transition-colors">
                <Check className="w-3.5 h-3.5" />
                <span>{t('dialogs.terrain.create')}</span>
              </button>
            )}
            {node && (
              <>
                <button
                  onClick={() => void handleRegenerate()}
                  disabled={!sculpted && !dirtyGeometry}
                  title={sculpted ? t('terrainEditorModalMsg.discardsTheSculptAsksFor') : dirtyGeometry ? t('terrainEditorModalMsg.rebuildsOnlyTheChangedGeometry') : t('terrainEditorModalMsg.enabledWhenHeightmapPresetSeed')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  data-testid="terrain-regenerate"
                >
                  {sculpted && <Lock className="w-3 h-3" />}
                  <span>{t('terrainEditorModal.regenerateGeometry', { value: sculpted ? ' ⚠' : '' })}</span>
                </button>
                {sculpted ? (
                  <button onClick={handleApplyVisual} disabled={Object.keys(visualChanges).length === 0} className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-[#4982ea] hover:bg-[#3b6ecc] text-white font-medium shadow-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed" data-testid="terrain-apply-visual">
                    <Check className="w-3.5 h-3.5" />
                    <span>{t('terrainEditorModal.updateVisualParameters')}</span>
                  </button>
                ) : (
                  <button onClick={handleApply} disabled={Object.keys(allChanges).length === 0} className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-[#4982ea] hover:bg-[#3b6ecc] text-white font-medium shadow-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed" data-testid="terrain-apply">
                    <Check className="w-3.5 h-3.5" />
                    <span>{t('dialogs.terrain.applyToNode')}</span>
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      </div>
      {pickerOpen && (
        <HeightmapPicker
          currentId={heightmapEntry?.resourceId}
          onClose={() => setPickerOpen(false)}
          onPick={(ref) => {
            setPickerOpen(false);
            set('heightmapRef', ref);
          }}
        />
      )}
    </div>
  );
};
