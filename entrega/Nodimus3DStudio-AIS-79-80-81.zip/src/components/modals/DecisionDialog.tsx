import React, { useEffect, useSyncExternalStore } from 'react';
import { AlertTriangle } from 'lucide-react';
import { answerDecision, getPendingDecision, subscribeDecisions } from '../../core/documents/decisions';

/**
 * AIS-18b — decisão explícita do usuário (salvar / descartar / cancelar), no lugar de
 * `window.confirm`. Escape cancela. Nada é descartado sem uma escolha.
 */
export const DecisionDialog: React.FC = () => {
  const pending = useSyncExternalStore(subscribeDecisions, getPendingDecision);

  useEffect(() => {
    if (!pending) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        answerDecision(null);
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [pending]);

  if (!pending) return null;

  const variantClass = (variant?: string) =>
    variant === 'primary'
      ? 'bg-[#4982ea] hover:bg-[#3b71d4] text-white'
      : variant === 'danger'
      ? 'bg-rose-900/40 hover:bg-rose-800/60 text-rose-200'
      : 'bg-[#272e3d] hover:bg-[#323b4e] text-[#c2cbdb]';

  return (
    <div
      role="alertdialog"
      aria-labelledby="decision-title"
      data-decision-dialog
      className="fixed inset-0 z-[70] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 select-none"
    >
      <div className="bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-sm text-sm text-[#d4dbe8]">
        <div className="px-5 py-3.5 bg-[#141720] border-b border-[#242b3b] flex items-center gap-3 rounded-t-xl">
          <AlertTriangle className="w-5 h-5 text-amber-400" />
          <h2 id="decision-title" className="font-semibold text-white text-base">
            {pending.title}
          </h2>
        </div>
        <div className="px-5 py-4 text-xs text-[#b3bed0] whitespace-pre-line">{pending.message}</div>
        <div className="px-5 pb-4 flex justify-end gap-2">
          {pending.options.map((option) => (
            <button
              key={option.id}
              onClick={() => answerDecision(option.id)}
              className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${variantClass(option.variant)}`}
            >
              {option.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
