import React, { useEffect, useState } from 'react';
import { Video } from 'lucide-react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { globalCommandManager } from '../../core/commandManager';
import { CAMERA_PRESETS, applyCameraPreset, createCameraWithPreset, detectCameraPreset, isPresetAvailable, type CameraPresetDeps, type CameraPresetId } from '../../core/cameraPresets';
import { useTranslation } from '../../core/i18n/I18nContext';

/**
 * AIS-47c — diálogo "Create a new Camera" (decisão 28). Não cria direto: o usuário escolhe o preset (qual Behavior de câmera o nó
 * leva) e se ela é a primeira câmera ativa. Presets sem execução ficam desabilitados com o AIS dono (decisão 14). Duplo clique
 * numa `Camera` reabre o diálogo com os valores atuais; criar e trocar de preset são UM Command (um Undo). Esc cancela.
 */
export const CameraPresetDialog: React.FC = () => {
  const { t } = useTranslation();
  const dialog = useEditorStore((s) => s.cameraDialog);
  const setCameraDialog = useEditorStore((s) => s.setCameraDialog);
  const { activeScene, addNode, changeNodeProperties, behaviorOps: ops, addLog } = useEditor();
  const [preset, setPreset] = useState<CameraPresetId>('simple');
  const [active, setActive] = useState(true);

  const editing = dialog?.mode === 'edit' ? activeScene.nodes[dialog.nodeId] : undefined;

  // abre com os valores atuais (editar) ou com os padrões (criar: câmera simples, ativa ao iniciar)
  useEffect(() => {
    if (!dialog) return;
    if (dialog.mode === 'edit' && editing) {
      setPreset(detectCameraPreset(editing));
      setActive(editing.properties?.active !== false);
    } else {
      setPreset('simple');
      setActive(true);
    }
  }, [dialog]); // eslint-disable-line react-hooks/exhaustive-deps

  const close = () => setCameraDialog(null);

  useEffect(() => {
    if (!dialog) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        setCameraDialog(null);
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [dialog, setCameraDialog]);

  if (!dialog) return null;

  const deps: CameraPresetDeps = {
    nodes: () => activeScene.nodes,
    addNode: (type, parentId, name, props) => addNode(type, parentId ?? undefined, name, props), // sem pai = o selecionado ou a raiz (nunca órfão)
    ops,
    changeNodeProperties,
    transaction: (label, fn) => globalCommandManager.transaction(label, fn),
  };

  const confirm = () => {
    try {
      if (dialog.mode === 'create') {
        const node = createCameraWithPreset(deps, dialog.parentId, preset, active);
        addLog('log', t('cameraPresetDialogMsg.cameraCreated', { name: node.name }));
      } else {
        const changed = applyCameraPreset(deps, dialog.nodeId, preset, active);
        if (changed) addLog('log', t('cameraPresetDialogMsg.cameraUpdated'));
      }
    } catch (error) {
      addLog('warn', error instanceof Error ? error.message : String(error));
    }
    close();
  };

  const groups: { title: string; items: typeof CAMERA_PRESETS }[] = [
    { title: '3D', items: CAMERA_PRESETS.filter((p) => p.group === '3D') },
    { title: '2D', items: CAMERA_PRESETS.filter((p) => p.group === '2D') },
  ];

  return (
    <div role="dialog" aria-labelledby="camera-dialog-title" data-testid="camera-preset-dialog" className="fixed inset-0 z-[70] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 select-none">
      <div className="bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-md text-sm text-[#d4dbe8]">
        <div className="px-5 py-3.5 bg-[#141720] border-b border-[#242b3b] flex items-center gap-3 rounded-t-xl">
          <Video className="w-5 h-5 text-sky-400" />
          <h2 id="camera-dialog-title" className="font-semibold text-white text-base">
            {dialog.mode === 'create' ? t('cameraPresetDialogMsg.createANewCamera') : t('cameraPresetDialogMsg.camera', { value: editing?.name ?? '' })}
          </h2>
        </div>
        <div className="px-5 py-4 space-y-3">
          {groups.map((group) => (
            <div key={group.title}>
              <div className="text-[10px] uppercase tracking-wider text-[#68768e] mb-1.5">{group.title}</div>
              <div className="grid grid-cols-2 gap-2">
                {group.items.map((p) => {
                  const available = isPresetAvailable(p);
                  const selected = preset === p.id;
                  return (
                    <label
                      key={p.id}
                      title={available ? p.description : t('cameraPresetDialogMsg.comingSoon', { value: p.soon ?? '' })}
                      className={`flex flex-col gap-0.5 px-3 py-2 rounded border text-left ${
                        available ? 'cursor-pointer' : 'opacity-40 cursor-not-allowed'
                      } ${selected ? 'border-sky-500 bg-[#1c2536]' : 'border-[#2c3345] bg-[#141822] hover:border-[#3a4560]'}`}
                    >
                      <span className="flex items-center gap-2">
                        <input type="radio" name="camera-preset" value={p.id} checked={selected} disabled={!available} onChange={() => setPreset(p.id)} />
                        <span className="font-medium text-[#dfe4ec] text-xs">{p.label}</span>
                      </span>
                      <span className="text-[10px] text-[#8b97a8]">{available ? p.description : t('cameraPresetDialogMsg.comingSoon', { value: p.soon ?? '' })}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          ))}
          <div className="pt-2 border-t border-[#242b3b] space-y-1.5">
            <label className="flex items-center gap-2 text-xs">
              <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} data-testid="camera-active" />
              {t('cameraPresetDialog.whenStartingTheSceneThis')}
            </label>
            <label className="flex items-center gap-2 text-xs opacity-40 cursor-not-allowed" title={t('cameraPresetDialog.comingSoonCollisionBelongsTo')}>
              <input type="checkbox" disabled />
              {t('cameraPresetDialog.collidesAgainstGeometryWhenMoved')}
            </label>
          </div>
        </div>
        <div className="px-5 pb-4 flex justify-end gap-2">
          <button type="button" onClick={close} className="px-3 py-1.5 rounded text-xs bg-[#272e3d] hover:bg-[#323b4e] text-[#c2cbdb]">
            {t('shared.cancel')}
          </button>
          <button type="button" onClick={confirm} data-testid="camera-dialog-ok" className="px-3 py-1.5 rounded text-xs bg-[#4982ea] hover:bg-[#3b71d4] text-white">
            {dialog.mode === 'create' ? t('cameraPresetDialogMsgTwo.create') : t('cameraPresetDialogMsgTwo.apply')}
          </button>
        </div>
      </div>
    </div>
  );
};
