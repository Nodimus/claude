import React, { useRef, useEffect, useState, useCallback } from 'react';
import { SpriteProject, SpriteTool } from '../../../types/sprite';
import { useTranslation } from '../../../core/i18n/I18nContext';
import {
  PenTool,
  Eraser,
  Pipette,
  PaintBucket,
  ZoomIn,
  ZoomOut,
  Maximize,
  Grid,
  Undo2,
  Redo2,
  FlipHorizontal,
  FlipVertical,
  RotateCw,
  Trash2,
  Eye,
  Sliders,
} from 'lucide-react';

interface SpriteCanvasEditorProps {
  project: SpriteProject;
  activeFrameIndex: number;
  /** `initial` = o canvas só foi (re)carregado do atlas/frame ao navegar (não é uma edição de pixels). */
  onUpdateFrameCanvas: (frameIndex: number, canvas: HTMLCanvasElement, initial?: boolean) => void;
  onionSkinEnabled: boolean;
  onToggleOnionSkin: () => void;
  previousFrameCanvas: HTMLCanvasElement | null;
  nextFrameCanvas: HTMLCanvasElement | null;
}

export const SpriteCanvasEditor: React.FC<SpriteCanvasEditorProps> = ({
  project,
  activeFrameIndex,
  onUpdateFrameCanvas,
  onionSkinEnabled,
  onToggleOnionSkin,
  previousFrameCanvas,
  nextFrameCanvas,
}) => {
  const { t } = useTranslation();
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isDrawingRef = useRef(false);

  // Tools & Settings
  const [activeTool, setActiveTool] = useState<SpriteTool>('pencil');
  const [activeColor, setActiveColor] = useState<string>('#ffffff');
  const [brushSize, setBrushSize] = useState<number>(1);
  const [zoom, setZoom] = useState<number>(16);
  const [showGrid, setShowGrid] = useState<boolean>(true);

  // Undo / Redo history stack for the current frame
  const historyRef = useRef<ImageData[]>([]);
  const historyStepRef = useRef<number>(-1);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  const frameWidth = project.sheetConfig.frameWidth || 32;
  const frameHeight = project.sheetConfig.frameHeight || 32;

  // Save current frame state to undo history
  const pushHistory = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    // Trim any future steps
    historyRef.current = historyRef.current.slice(0, historyStepRef.current + 1);
    historyRef.current.push(imgData);
    historyStepRef.current = historyRef.current.length - 1;

    setCanUndo(historyStepRef.current > 0);
    setCanRedo(false);
  }, []);

  // Initialize or load frame onto canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = frameWidth;
    canvas.height = frameHeight;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;

    // Load from project frame customDataUrl or spritesheet image
    const frame = project.frames[activeFrameIndex];
    if (frame && frame.customDataUrl) {
      const img = new Image();
      img.onload = () => {
        ctx.clearRect(0, 0, frameWidth, frameHeight);
        ctx.drawImage(img, 0, 0);
        // Clear history for this frame
        historyRef.current = [ctx.getImageData(0, 0, frameWidth, frameHeight)];
        historyStepRef.current = 0;
        setCanUndo(false);
        setCanRedo(false);
        onUpdateFrameCanvas(activeFrameIndex, canvas, true);
      };
      img.src = frame.customDataUrl;
    } else if (project.sheetConfig.imageUrl) {
      const sheetImg = new Image();
      sheetImg.onload = () => {
        ctx.clearRect(0, 0, frameWidth, frameHeight);
        if (frame) {
          ctx.drawImage(
            sheetImg,
            frame.x,
            frame.y,
            frame.width,
            frame.height,
            0,
            0,
            frameWidth,
            frameHeight
          );
        }
        historyRef.current = [ctx.getImageData(0, 0, frameWidth, frameHeight)];
        historyStepRef.current = 0;
        setCanUndo(false);
        setCanRedo(false);
        onUpdateFrameCanvas(activeFrameIndex, canvas, true);
      };
      sheetImg.src = project.sheetConfig.imageUrl;
    } else {
      ctx.clearRect(0, 0, frameWidth, frameHeight);
      historyRef.current = [ctx.getImageData(0, 0, frameWidth, frameHeight)];
      historyStepRef.current = 0;
      setCanUndo(false);
      setCanRedo(false);
      onUpdateFrameCanvas(activeFrameIndex, canvas, true);
    }
  }, [activeFrameIndex, frameWidth, frameHeight, project.sheetConfig.imageUrl]);

  const undo = () => {
    if (historyStepRef.current <= 0) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    historyStepRef.current--;
    ctx.putImageData(historyRef.current[historyStepRef.current], 0, 0);
    setCanUndo(historyStepRef.current > 0);
    setCanRedo(true);
    onUpdateFrameCanvas(activeFrameIndex, canvas);
  };

  const redo = () => {
    if (historyStepRef.current >= historyRef.current.length - 1) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    historyStepRef.current++;
    ctx.putImageData(historyRef.current[historyStepRef.current], 0, 0);
    setCanUndo(true);
    setCanRedo(historyStepRef.current < historyRef.current.length - 1);
    onUpdateFrameCanvas(activeFrameIndex, canvas);
  };

  // Convert client mouse position to canvas pixel coordinates
  const getCanvasCoords = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const x = Math.floor(((e.clientX - rect.left) / rect.width) * canvas.width);
    const y = Math.floor(((e.clientY - rect.top) / rect.height) * canvas.height);
    return {
      x: Math.max(0, Math.min(canvas.width - 1, x)),
      y: Math.max(0, Math.min(canvas.height - 1, y)),
    };
  };

  // Flood fill algorithm
  const floodFill = (startX: number, startY: number, fillColor: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imgData.data;
    const width = canvas.width;
    const height = canvas.height;

    // Parse fill color
    const tempDiv = document.createElement('div');
    tempDiv.style.color = fillColor;
    document.body.appendChild(tempDiv);
    const computed = window.getComputedStyle(tempDiv).color;
    document.body.removeChild(tempDiv);
    const match = computed.match(/\d+/g);
    if (!match) return;
    const targetR = parseInt(match[0], 10);
    const targetG = parseInt(match[1], 10);
    const targetB = parseInt(match[2], 10);
    const targetA = match[3] ? Math.round(parseFloat(match[3]) * 255) : 255;

    const startPos = (startY * width + startX) * 4;
    const startR = data[startPos];
    const startG = data[startPos + 1];
    const startB = data[startPos + 2];
    const startA = data[startPos + 3];

    // If already the same color, no-op
    if (
      startR === targetR &&
      startG === targetG &&
      startB === targetB &&
      startA === targetA
    ) {
      return;
    }

    const queue: [number, number][] = [[startX, startY]];
    const visited = new Uint8Array(width * height);

    while (queue.length > 0) {
      const [x, y] = queue.pop()!;
      const idx = y * width + x;
      if (visited[idx]) continue;
      visited[idx] = 1;

      const pos = idx * 4;
      if (
        data[pos] === startR &&
        data[pos + 1] === startG &&
        data[pos + 2] === startB &&
        data[pos + 3] === startA
      ) {
        data[pos] = targetR;
        data[pos + 1] = targetG;
        data[pos + 2] = targetB;
        data[pos + 3] = targetA;

        if (x > 0) queue.push([x - 1, y]);
        if (x < width - 1) queue.push([x + 1, y]);
        if (y > 0) queue.push([x, y - 1]);
        if (y < height - 1) queue.push([x, y + 1]);
      }
    }

    ctx.putImageData(imgData, 0, 0);
    pushHistory();
    onUpdateFrameCanvas(activeFrameIndex, canvas);
  };

  // Draw pixel helper
  const drawAt = (x: number, y: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    if (activeTool === 'pencil') {
      ctx.fillStyle = activeColor;
      ctx.fillRect(
        Math.floor(x - (brushSize - 1) / 2),
        Math.floor(y - (brushSize - 1) / 2),
        brushSize,
        brushSize
      );
    } else if (activeTool === 'eraser') {
      ctx.clearRect(
        Math.floor(x - (brushSize - 1) / 2),
        Math.floor(y - (brushSize - 1) / 2),
        brushSize,
        brushSize
      );
    }
  };

  // Mouse drawing events
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (e.button !== 0) return;
    const { x, y } = getCanvasCoords(e);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    if (activeTool === 'picker') {
      const pixel = ctx.getImageData(x, y, 1, 1).data;
      if (pixel[3] > 0) {
        const hex =
          '#' +
          [pixel[0], pixel[1], pixel[2]]
            .map((val) => val.toString(16).padStart(2, '0'))
            .join('');
        setActiveColor(hex);
        setActiveTool('pencil');
      }
      return;
    }

    if (activeTool === 'bucket') {
      floodFill(x, y, activeColor);
      return;
    }

    isDrawingRef.current = true;
    drawAt(x, y);
    onUpdateFrameCanvas(activeFrameIndex, canvas);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    const { x, y } = getCanvasCoords(e);
    drawAt(x, y);
    if (canvasRef.current) {
      onUpdateFrameCanvas(activeFrameIndex, canvasRef.current);
    }
  };

  const handleMouseUp = () => {
    if (isDrawingRef.current) {
      isDrawingRef.current = false;
      pushHistory();
    }
  };

  // Transformation actions
  const applyTransform = (transformFn: (ctx: CanvasRenderingContext2D) => void) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvas.width;
    tempCanvas.height = canvas.height;
    const tempCtx = tempCanvas.getContext('2d')!;
    tempCtx.drawImage(canvas, 0, 0);

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    transformFn(ctx);
    ctx.drawImage(tempCanvas, 0, 0);
    ctx.restore();

    pushHistory();
    onUpdateFrameCanvas(activeFrameIndex, canvas);
  };

  const flipHorizontal = () => {
    applyTransform((ctx) => {
      ctx.translate(frameWidth, 0);
      ctx.scale(-1, 1);
    });
  };

  const flipVertical = () => {
    applyTransform((ctx) => {
      ctx.translate(0, frameHeight);
      ctx.scale(1, -1);
    });
  };

  const rotate90 = () => {
    applyTransform((ctx) => {
      ctx.translate(frameWidth / 2, frameHeight / 2);
      ctx.rotate(Math.PI / 2);
      ctx.translate(-frameWidth / 2, -frameHeight / 2);
    });
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    pushHistory();
    onUpdateFrameCanvas(activeFrameIndex, canvas);
  };

  return (
    <div className="flex flex-col h-full bg-[#181c24] border-r border-[#2c3345] select-none">
      {/* Top Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-[#2c3345] bg-[#202531]">
        {/* Left: Tools Selection */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setActiveTool('pencil')}
            className={`p-1.5 rounded transition-colors ${
              activeTool === 'pencil'
                ? 'bg-[#4982ea] text-white shadow-sm'
                : 'text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]'
            }`}
            title={t('spriteCanvasEditor.pixelPencil')}
          >
            <PenTool className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActiveTool('eraser')}
            className={`p-1.5 rounded transition-colors ${
              activeTool === 'eraser'
                ? 'bg-[#4982ea] text-white shadow-sm'
                : 'text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]'
            }`}
            title={t('spriteCanvasEditor.eraser')}
          >
            <Eraser className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActiveTool('picker')}
            className={`p-1.5 rounded transition-colors ${
              activeTool === 'picker'
                ? 'bg-[#4982ea] text-white shadow-sm'
                : 'text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]'
            }`}
            title={t('spriteCanvasEditor.eyedropper')}
          >
            <Pipette className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActiveTool('bucket')}
            className={`p-1.5 rounded transition-colors ${
              activeTool === 'bucket'
                ? 'bg-[#4982ea] text-white shadow-sm'
                : 'text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]'
            }`}
            title={t('spriteCanvasEditor.paintBucketContiguousFill')}
          >
            <PaintBucket className="w-4 h-4" />
          </button>

          <div className="h-4 w-[1px] bg-[#374158] mx-1" />

          {/* Brush Sizes */}
          <div className="flex items-center gap-1 bg-[#181c24] px-1 py-0.5 rounded border border-[#2c3345]">
            {[1, 2, 3, 4].map((size) => (
              <button
                key={size}
                onClick={() => setBrushSize(size)}
                className={`w-5 h-5 rounded text-[10px] font-mono font-bold transition-colors ${
                  brushSize === size
                    ? 'bg-[#4982ea] text-white'
                    : 'text-[#8b97a8] hover:text-white'
                }`}
                title={t('spriteCanvasEditorMsg.brushSizePx', { size })}
              >
                {size}
              </button>
            ))}
          </div>

          <div className="h-4 w-[1px] bg-[#374158] mx-1" />

          {/* Undo / Redo */}
          <button
            onClick={undo}
            disabled={!canUndo}
            className={`p-1.5 rounded transition-colors ${
              canUndo
                ? 'text-[#dfe4ec] hover:bg-[#2c3345]'
                : 'text-[#4e586c] cursor-not-allowed'
            }`}
            title={t('spriteCanvasEditor.undo')}
          >
            <Undo2 className="w-4 h-4" />
          </button>

          <button
            onClick={redo}
            disabled={!canRedo}
            className={`p-1.5 rounded transition-colors ${
              canRedo
                ? 'text-[#dfe4ec] hover:bg-[#2c3345]'
                : 'text-[#4e586c] cursor-not-allowed'
            }`}
            title={t('spriteCanvasEditor.redo')}
          >
            <Redo2 className="w-4 h-4" />
          </button>
        </div>

        {/* Right: Grid, Onion Skin, Zoom & Transforms */}
        <div className="flex items-center gap-1">
          <button
            onClick={onToggleOnionSkin}
            className={`flex items-center gap-1 px-2 py-1 rounded text-xs transition-colors ${
              onionSkinEnabled
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]'
            }`}
            title={t('spriteCanvasEditor.onionSkinningViewPreviousNext')}
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="text-[11px] hidden sm:inline">{t('spriteCanvasEditor.onionSkin')}</span>
          </button>

          <button
            onClick={() => setShowGrid(!showGrid)}
            className={`p-1.5 rounded transition-colors ${
              showGrid ? 'bg-[#323b4e] text-sky-400' : 'text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]'
            }`}
            title={t('spriteCanvasEditor.pixelGrid')}
          >
            <Grid className="w-4 h-4" />
          </button>

          <div className="h-4 w-[1px] bg-[#374158] mx-1" />

          <button
            onClick={flipHorizontal}
            className="p-1.5 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title={t('spriteCanvasEditor.flipHorizontally')}
          >
            <FlipHorizontal className="w-4 h-4" />
          </button>

          <button
            onClick={flipVertical}
            className="p-1.5 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title={t('spriteCanvasEditor.flipVertically')}
          >
            <FlipVertical className="w-4 h-4" />
          </button>

          <button
            onClick={rotate90}
            className="p-1.5 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title={t('spriteCanvasEditor.rotate90Clockwise')}
          >
            <RotateCw className="w-4 h-4" />
          </button>

          <button
            onClick={clearCanvas}
            className="p-1.5 rounded text-[#9ca7b7] hover:text-rose-400 hover:bg-rose-950/30"
            title={t('spriteCanvasEditor.clearCurrentFrame')}
          >
            <Trash2 className="w-4 h-4" />
          </button>

          <div className="h-4 w-[1px] bg-[#374158] mx-1" />

          {/* Zoom controls */}
          <button
            onClick={() => setZoom(Math.max(2, zoom - 2))}
            className="p-1.5 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title={t('spriteCanvasEditor.zoomOut')}
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-[11px] font-mono text-[#cbd5e1] min-w-[32px] text-center">
            {zoom}x
          </span>
          <button
            onClick={() => setZoom(Math.min(48, zoom + 2))}
            className="p-1.5 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title={t('spriteCanvasEditor.zoomIn')}
          >
            <ZoomIn className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Pixel Canvas Drawing Viewport */}
      <div
        ref={containerRef}
        className="flex-1 overflow-auto flex items-center justify-center p-6 bg-[#12151d] relative"
        onMouseUp={handleMouseUp}
        // estilo GameMaker: Ctrl + roda do mouse dá zoom na imagem
        onWheel={(e) => {
          if (!e.ctrlKey) return;
          e.preventDefault();
          setZoom((z) => Math.max(2, Math.min(48, z + (e.deltaY < 0 ? 2 : -2))));
        }}
      >
        <div
          className="relative shadow-2xl border border-[#3b475e] bg-[radial-gradient(#1f293d_1px,transparent_1px)] [background-size:16px_16px]"
          style={{
            width: frameWidth * zoom,
            height: frameHeight * zoom,
          }}
        >
          {/* Transparency checkerboard background */}
          <div
            className="absolute inset-0 pointer-events-none opacity-40"
            style={{
              backgroundImage:
                'linear-gradient(45deg, #181d28 25%, transparent 25%), linear-gradient(-45deg, #181d28 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #181d28 75%), linear-gradient(-45deg, transparent 75%, #181d28 75%)',
              backgroundSize: '16px 16px',
              backgroundPosition: '0 0, 0 8px, 8px -8px, -8px 0px',
            }}
          />

          {/* Onion Skin: Previous Frame (Ghosted Blue) */}
          {onionSkinEnabled && previousFrameCanvas && (
            <img
              src={previousFrameCanvas.toDataURL()}
              alt={t('spriteCanvasEditor.previousFrameGhost')}
              className="absolute inset-0 w-full h-full pointer-events-none opacity-30 mix-blend-screen filter hue-rotate-180"
              style={{ imageRendering: 'pixelated' }}
            />
          )}

          {/* Onion Skin: Next Frame (Ghosted Red) */}
          {onionSkinEnabled && nextFrameCanvas && (
            <img
              src={nextFrameCanvas.toDataURL()}
              alt={t('spriteCanvasEditor.nextFrameGhost')}
              className="absolute inset-0 w-full h-full pointer-events-none opacity-25 mix-blend-screen filter hue-rotate-90"
              style={{ imageRendering: 'pixelated' }}
            />
          )}

          {/* Interactive Editable 2D Canvas */}
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full cursor-crosshair"
            style={{ imageRendering: 'pixelated' }}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onContextMenu={(e) => e.preventDefault()}
          />

          {/* Pixel Grid Overlay */}
          {showGrid && zoom >= 8 && (
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                backgroundImage:
                  'linear-gradient(to right, rgba(255, 255, 255, 0.08) 1px, transparent 1px), linear-gradient(to bottom, rgba(255, 255, 255, 0.08) 1px, transparent 1px)',
                backgroundSize: t('spriteCanvasEditorMsg.pxPx', { zoom, zoom2: zoom }),
              }}
            />
          )}
        </div>
      </div>

      {/* Bottom Color Palette Bar */}
      <div className="px-3 py-2 border-t border-[#2c3345] bg-[#202531] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          {/* Active color swatch with picker */}
          <label className="flex items-center gap-1.5 cursor-pointer bg-[#181c24] px-2 py-1 rounded border border-[#3b475e]">
            <input
              type="color"
              value={activeColor}
              onChange={(e) => setActiveColor(e.target.value)}
              className="w-5 h-5 rounded cursor-pointer border-0 p-0 bg-transparent"
            />
            <span className="font-mono text-xs text-[#cbd5e1] uppercase">
              {activeColor}
            </span>
          </label>

          <span className="text-xs text-[#64748b]">{t('spriteCanvasEditor.palette')}</span>

          {/* Palette Swatches */}
          <div className="flex items-center gap-1 flex-wrap">
            {project.palette.map((color, index) => (
              <button
                key={index}
                onClick={() => setActiveColor(color)}
                style={{ backgroundColor: color }}
                className={`w-5 h-5 rounded-sm border transition-transform ${
                  activeColor.toLowerCase() === color.toLowerCase()
                    ? 'border-white scale-110 shadow-md ring-1 ring-sky-400'
                    : 'border-black/30 hover:scale-105'
                }`}
                title={t('spriteCanvasEditorMsg.color', { color })}
              />
            ))}
          </div>
        </div>

        <div className="text-[11px] text-[#8b97a8]">
          {t('spriteCanvasEditor.frameOfXPx', { value: activeFrameIndex + 1, length: project.frames.length, frameWidth, frameHeight })}
        </div>
      </div>
    </div>
  );
};
