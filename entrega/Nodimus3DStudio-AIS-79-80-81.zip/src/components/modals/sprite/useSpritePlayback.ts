import { useCallback, useEffect, useRef } from 'react';
import type { SpriteAnimation } from '../../../types/sprite';
import { clipDurationMs, clipFinishedAt, clipFrameIndexAtTime, clipPositionAtTime, clipStartMsOfPosition } from '../../../runtime/sprite';

/**
 * AIS-76 — player do Sprite Editor. `requestAnimationFrame` + TEMPO DECORRIDO ABSOLUTO: o quadro atual é sempre
 * `clipFrameIndexAtTime(animação, elapsedMs)` (a função canônica do editor, do Play e do publish) — sem `setInterval`, sem estado
 * acumulado de "próximo quadro" e sem `setState` dentro de updater de `setState`. `once` termina e congela no último frame.
 */

export interface PlaybackAnimation {
  frameIndices: number[];
  fps: number;
  loopMode: SpriteAnimation['loopMode'];
  frameDurations?: number[];
}

interface Options {
  animation: PlaybackAnimation | undefined;
  playing: boolean;
  /** Chamado quando o frame GLOBAL muda (só nas mudanças). */
  onFrame: (globalIndex: number) => void;
  /** `once` chegou ao fim: o dono pausa. */
  onFinished: () => void;
  /** Muda ao trocar de animação/estrutura do clipe (reinicia o relógio). */
  clipKey: string;
}

export function useSpritePlayback({ animation, playing, onFrame, onFinished, clipKey }: Options) {
  const animationRef = useRef(animation);
  animationRef.current = animation;
  const onFrameRef = useRef(onFrame);
  onFrameRef.current = onFrame;
  const onFinishedRef = useRef(onFinished);
  onFinishedRef.current = onFinished;

  /** Tempo decorrido (ms) do clipe, preservado entre pausa e retomada. */
  const elapsedRef = useRef(0);
  const lastFrameRef = useRef(-2);

  // trocar de clipe recomeça do zero
  useEffect(() => {
    elapsedRef.current = 0;
    lastFrameRef.current = -2;
  }, [clipKey]);

  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    let start = performance.now() - elapsedRef.current;
    const tick = (now: number) => {
      const anim = animationRef.current;
      if (!anim || anim.frameIndices.length === 0) return;
      elapsedRef.current = now - start;
      const frame = clipFrameIndexAtTime(anim, elapsedRef.current);
      if (frame !== lastFrameRef.current) {
        lastFrameRef.current = frame;
        onFrameRef.current(frame);
      }
      if (clipFinishedAt(anim, elapsedRef.current)) {
        elapsedRef.current = clipDurationMs(anim);
        onFinishedRef.current();
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, clipKey]);

  /** Vai para a POSIÇÃO `position` do clipe (timeline/passo) e devolve o frame global. */
  const seekPosition = useCallback((position: number): number => {
    const anim = animationRef.current;
    if (!anim || anim.frameIndices.length === 0) return -1;
    const pos = Math.max(0, Math.min(anim.frameIndices.length - 1, Math.floor(position)));
    elapsedRef.current = clipStartMsOfPosition(anim, pos) + 1;
    lastFrameRef.current = anim.frameIndices[pos];
    return anim.frameIndices[pos];
  }, []);

  /** Posição atual no clipe (para os botões de passo). */
  const currentPosition = useCallback((): number => {
    const anim = animationRef.current;
    return anim ? clipPositionAtTime(anim, elapsedRef.current) : -1;
  }, []);

  /** Leva o relógio ao início da primeira ocorrência do frame global `index` (clicou num quadro). */
  const seekFrame = useCallback((index: number): void => {
    const anim = animationRef.current;
    if (!anim) return;
    const pos = anim.frameIndices.indexOf(index);
    if (pos >= 0) {
      elapsedRef.current = clipStartMsOfPosition(anim, pos) + 1;
      lastFrameRef.current = index;
    }
  }, []);

  return { seekPosition, seekFrame, currentPosition };
}
