import type { SpriteFrame, SpriteSheetConfig } from '../../../types/sprite';

/**
 * AIS-76 (§3.2) — atlas PNG do Sprite Editor. Dois modos de gravação:
 *  - `pixels`: o layout NÃO mudou; os pixels editados são escritos de volta NA REGIÃO de cada frame do atlas já carregado (espaçamento e margem do
 *    arquivo original preservados).
 *  - `repack`: frames foram criados/duplicados/removidos/movidos; o atlas é reempacotado numa grade uniforme (`planRepack`) e as regiões dos frames
 *    são atualizadas para a nova grade.
 * A parte de layout é PURA (testável em Node); `composeAtlas` usa canvas (DOM) e fica na borda.
 */

export type AtlasWriteMode = 'none' | 'pixels' | 'repack';

/** Sobe o modo (nunca desce): none < pixels < repack. */
export const raiseAtlasMode = (current: AtlasWriteMode, next: AtlasWriteMode): AtlasWriteMode => {
  const rank: Record<AtlasWriteMode, number> = { none: 0, pixels: 1, repack: 2 };
  return rank[next] > rank[current] ? next : current;
};

export interface RepackPlan {
  frames: Pick<SpriteFrame, 'x' | 'y' | 'width' | 'height'>[];
  columns: number;
  rows: number;
  imageWidth: number;
  imageHeight: number;
}

/** Grade uniforme `columns` de largura (≥ 1) para `count` frames `fw × fh`, com `spacing` e `margin`. */
export function planRepack(count: number, fw: number, fh: number, columns: number, spacing = 0, margin = 0): RepackPlan {
  const cols = Math.max(1, Math.min(Math.floor(columns) || 1, Math.max(1, count)));
  const rows = Math.max(1, Math.ceil(Math.max(0, count) / cols));
  const frames = Array.from({ length: Math.max(0, count) }, (_, i) => ({ x: margin + (i % cols) * (fw + spacing), y: margin + Math.floor(i / cols) * (fh + spacing), width: fw, height: fh }));
  return { frames, columns: cols, rows, imageWidth: margin * 2 + cols * fw + (cols - 1) * spacing, imageHeight: margin * 2 + rows * fh + (rows - 1) * spacing };
}

/** Aplica um `RepackPlan` ao projeto (regiões, índices sequenciais, dimensões do atlas). */
export function applyRepack(frames: SpriteFrame[], config: SpriteSheetConfig, plan: RepackPlan): { frames: SpriteFrame[]; config: SpriteSheetConfig } {
  return {
    frames: frames.map((f, i) => ({ ...f, index: i, ...plan.frames[i] })),
    config: { ...config, columns: plan.columns, rows: plan.rows, imageWidth: plan.imageWidth, imageHeight: plan.imageHeight, totalFrames: frames.length },
  };
}

export interface ComposeInput {
  mode: Exclude<AtlasWriteMode, 'none'>;
  /** Atlas carregado (data URL de sessão); `''` = nenhum (nasce do zero). */
  baseImageUrl: string;
  frames: SpriteFrame[];
  config: SpriteSheetConfig;
  /** Pixels de cada frame (um canvas `frameWidth × frameHeight` por frame; `null` = sem edição/sem pixels). */
  canvases: (HTMLCanvasElement | null)[];
}

export interface ComposedAtlas {
  dataUrl: string;
  frames: SpriteFrame[];
  config: SpriteSheetConfig;
}

function loadImage(url: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    if (!url) return resolve(null);
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = url;
  });
}

/** Gera o PNG do atlas (data URL) e as regiões/dimensões finais. Só roda no navegador (canvas). */
export async function composeAtlas(input: ComposeInput): Promise<ComposedAtlas> {
  const { mode, frames, config, canvases } = input;
  const fw = config.frameWidth || 32;
  const fh = config.frameHeight || 32;
  const base = await loadImage(input.baseImageUrl);

  let outFrames = frames;
  let outConfig = config;
  let width: number;
  let height: number;
  if (mode === 'repack' || !base) {
    const plan = planRepack(frames.length, fw, fh, config.columns, config.spacing, config.margin);
    const applied = applyRepack(frames, config, plan);
    outFrames = applied.frames;
    outConfig = applied.config;
    width = plan.imageWidth;
    height = plan.imageHeight;
  } else {
    width = base.naturalWidth;
    height = base.naturalHeight;
  }

  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, width);
  canvas.height = Math.max(1, height);
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  if (mode === 'pixels' && base) ctx.drawImage(base, 0, 0);

  outFrames.forEach((f, i) => {
    const px = canvases[i];
    if (px) {
      ctx.clearRect(f.x, f.y, f.width, f.height);
      ctx.drawImage(px, 0, 0, px.width, px.height, f.x, f.y, f.width, f.height);
    } else if (mode === 'repack' && base) {
      // frame sem canvas ainda: copia a região de ORIGEM (frames originais) para a nova posição
      const src = frames[i];
      ctx.drawImage(base, src.x, src.y, src.width, src.height, f.x, f.y, f.width, f.height);
    }
  });

  return { dataUrl: canvas.toDataURL('image/png'), frames: outFrames, config: { ...outConfig, imageUrl: '' } };
}
