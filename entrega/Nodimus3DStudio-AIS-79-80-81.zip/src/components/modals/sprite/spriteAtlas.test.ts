import { describe, expect, it } from 'vitest';
import { gridFrames } from '../../../schemas/spriteNormalize';
import { createEmptySpriteProject } from '../../../utils/spritePresets';
import { applyRepack, planRepack, raiseAtlasMode } from './spriteAtlas';

/** AIS-76-C04 — layout do atlas gravado de volta no PNG (parte pura). */
describe('planRepack', () => {
  it('grade uniforme com colunas limitadas ao número de frames', () => {
    const p = planRepack(6, 32, 32, 4);
    expect(p).toMatchObject({ columns: 4, rows: 2, imageWidth: 128, imageHeight: 64 });
    expect(p.frames[5]).toEqual({ x: 32, y: 32, width: 32, height: 32 });
    expect(planRepack(2, 16, 16, 8)).toMatchObject({ columns: 2, rows: 1, imageWidth: 32, imageHeight: 16 });
  });
  it('spacing e margin entram nas posições e no tamanho', () => {
    const p = planRepack(4, 10, 10, 2, 2, 3);
    expect(p.frames.map((f) => [f.x, f.y])).toEqual([[3, 3], [15, 3], [3, 15], [15, 15]]);
    expect(p).toMatchObject({ imageWidth: 3 * 2 + 20 + 2, imageHeight: 3 * 2 + 20 + 2 });
  });
  it('zero frames e colunas inválidas não quebram', () => {
    expect(planRepack(0, 8, 8, 4).frames).toEqual([]);
    expect(planRepack(3, 8, 8, 0).columns).toBe(1);
    expect(planRepack(3, 8, 8, Number.NaN).columns).toBe(1);
  });
  it('coincide com gridFrames (mesma convenção do Convert to Frames)', () => {
    const p = planRepack(6, 16, 24, 3, 1, 2);
    const g = gridFrames(3, 2, 16, 24, 1, 2);
    expect(p.frames).toEqual(g.map(({ x, y, width, height }) => ({ x, y, width, height })));
  });
});

describe('applyRepack', () => {
  it('atualiza regiões, índices e dimensões; preserva ids e dados dos frames', () => {
    const proj = createEmptySpriteProject('X');
    const frames = [...gridFrames(1, 3, 32, 32)].reverse().map((f, i) => ({ ...f, id: `f${i}`, index: 99 }));
    const plan = planRepack(3, 32, 32, 2);
    const out = applyRepack(frames, proj.sheetConfig, plan);
    expect(out.frames.map((f) => f.id)).toEqual(['f0', 'f1', 'f2']);
    expect(out.frames.map((f) => f.index)).toEqual([0, 1, 2]);
    expect(out.frames[2]).toMatchObject({ x: 0, y: 32 });
    expect(out.config).toMatchObject({ columns: 2, rows: 2, imageWidth: 64, imageHeight: 64, totalFrames: 3 });
  });
});

describe('raiseAtlasMode', () => {
  it('só sobe: none < pixels < repack', () => {
    expect(raiseAtlasMode('none', 'pixels')).toBe('pixels');
    expect(raiseAtlasMode('pixels', 'repack')).toBe('repack');
    expect(raiseAtlasMode('repack', 'pixels')).toBe('repack');
    expect(raiseAtlasMode('pixels', 'none')).toBe('pixels');
  });
});
