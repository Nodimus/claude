import React, { useState } from 'react';
import { SpriteProject, SpriteAnimation, LoopMode } from '../../../types/sprite';
import { useTranslation } from '../../../core/i18n/I18nContext';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Plus,
  Copy,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Repeat,
  RotateCcw,
  Sparkles,
  Layers,
  Clock,
  X,
} from 'lucide-react';

interface SpriteTimelineProps {
  project: SpriteProject;
  currentFrameIndex: number;
  onSelectFrame: (index: number) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onStepFrame: (direction: number) => void;
  onAddFrame: () => void;
  onDuplicateFrame: (index: number) => void;
  onDeleteFrame: (index: number) => void;
  onMoveFrame: (fromIndex: number, toIndex: number) => void;
  onSelectAnimation: (animId: string) => void;
  onAddAnimation: (name: string) => void;
  onUpdateAnimation: (anim: SpriteAnimation) => void;
  onDeleteAnimation: (animId: string) => void;
  frameCanvases: (HTMLCanvasElement | null)[];
}

export const SpriteTimeline: React.FC<SpriteTimelineProps> = ({
  project,
  currentFrameIndex,
  onSelectFrame,
  isPlaying,
  onTogglePlay,
  onStepFrame,
  onAddFrame,
  onDuplicateFrame,
  onDeleteFrame,
  onMoveFrame,
  onSelectAnimation,
  onAddAnimation,
  onUpdateAnimation,
  onDeleteAnimation,
  frameCanvases,
}) => {
  const { t } = useTranslation();
  const [isAddingAnim, setIsAddingAnim] = useState(false);
  const [newAnimName, setNewAnimName] = useState('');
  /** AIS-76: posição selecionada na SEQUÊNCIA da animação (frameIndices pode repetir e ficar fora de ordem). */
  const [selPos, setSelPos] = useState(0);
  /** Arrastar quadro na faixa para reordenar (estilo GameMaker). */
  const [dragFrom, setDragFrom] = useState<number | null>(null);
  const [dropAt, setDropAt] = useState<number | null>(null);

  const activeAnim =
    project.animations.find((a) => a.id === project.activeAnimationId) ||
    project.animations[0];

  const handleCreateAnim = () => {
    if (!newAnimName.trim()) return;
    onAddAnimation(newAnimName.trim().toLowerCase());
    setNewAnimName('');
    setIsAddingAnim(false);
  };

  const handleFpsChange = (newFps: number) => {
    if (!activeAnim) return;
    onUpdateAnimation({ ...activeAnim, fps: Math.max(1, Math.min(60, newFps)) });
  };

  const handleLoopModeChange = (loopMode: LoopMode) => {
    if (!activeAnim) return;
    onUpdateAnimation({ ...activeAnim, loopMode });
  };

  const activeFrames = activeAnim ? activeAnim.frameIndices : [];

  // ── Quadros DA ANIMAÇÃO ativa (frameIndices + frameDurations): a faixa mostra só os quadros dela, na ordem dela ──
  const seq = activeAnim?.frameIndices ?? [];
  const sel = Math.min(Math.max(0, selPos), Math.max(0, seq.length - 1));
  const multOf = (pos: number): number => activeAnim?.frameDurations?.[pos] ?? 1;
  const durationsNow = (): number[] => seq.map((_, i) => multOf(i));
  const writeSequence = (indices: number[], durations: number[]) => {
    if (!activeAnim) return;
    const custom = durations.some((d) => d !== 1);
    onUpdateAnimation({ ...activeAnim, frameIndices: indices, frameDurations: custom ? durations : undefined });
  };
  /** Tira a POSIÇÃO da animação (o quadro continua existindo no atlas; ele só deixa de tocar nesta animação). */
  const seqRemove = () => {
    if (seq.length <= 1) return;
    writeSequence(seq.filter((_, i) => i !== sel), durationsNow().filter((_, i) => i !== sel));
    setSelPos(Math.max(0, sel - 1));
  };
  /** Move a posição `from` para `to` (botões ◀ ▶ e arrastar). */
  const seqReorder = (from: number, to: number) => {
    if (from === to || from < 0 || to < 0 || from >= seq.length || to >= seq.length) return;
    const idx = [...seq];
    const d = durationsNow();
    const [i1] = idx.splice(from, 1);
    const [d1] = d.splice(from, 1);
    idx.splice(to, 0, i1);
    d.splice(to, 0, d1);
    writeSequence(idx, d);
    setSelPos(to);
  };
  const seqSetMult = (value: number) => {
    const d = durationsNow();
    d[sel] = Math.max(0.1, Math.min(20, Number.isFinite(value) ? value : 1));
    writeSequence(seq, d);
  };
  const activePos = seq[sel] === currentFrameIndex ? sel : seq.indexOf(currentFrameIndex);

  return (
    <div className="flex flex-col bg-[#1c222e] border-t border-[#2c3345] select-none h-[15.5rem] shrink-0">
      {/* Animation Header & Tabs */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-[#2c3345] bg-[#181c24] text-xs">
        {/* Left: Animation Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
          <span className="text-[#64748b] text-[11px] font-semibold flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-sky-400" />
            {t('spriteTimeline.animation')}
          </span>

          {project.animations.map((anim) => (
            <div
              key={anim.id}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium cursor-pointer transition-colors ${
                anim.id === project.activeAnimationId
                  ? 'bg-[#4982ea] text-white shadow-sm'
                  : 'bg-[#202531] text-[#9ca7b7] hover:bg-[#2c3345] hover:text-[#dfe4ec]'
              }`}
              onClick={() => onSelectAnimation(anim.id)}
            >
              <span>{anim.name}</span>
              <span className="text-[10px] opacity-75">
                ({anim.frameIndices.length}q)
              </span>

              {project.animations.length > 1 && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteAnimation(anim.id);
                  }}
                  className="hover:text-rose-300 ml-0.5"
                  title={t('spriteTimeline.deleteAnimation')}
                >
                  ×
                </button>
              )}
            </div>
          ))}

          {/* Add Animation Button */}
          {isAddingAnim ? (
            <div className="flex items-center gap-1 bg-[#202531] p-0.5 rounded border border-[#3b475e]">
              <input
                type="text"
                autoFocus
                placeholder={t('spriteTimeline.name')}
                value={newAnimName}
                onChange={(e) => setNewAnimName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleCreateAnim();
                  if (e.key === 'Escape') setIsAddingAnim(false);
                }}
                className="w-20 px-1 py-0.5 text-xs bg-[#141822] text-white border border-[#2c3345] rounded"
              />
              <button
                onClick={handleCreateAnim}
                className="px-1.5 py-0.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px]"
              >
                OK
              </button>
              <button
                onClick={() => setIsAddingAnim(false)}
                className="px-1 text-[#8b97a8] hover:text-white text-[10px]"
              >
                ×
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsAddingAnim(true)}
              className="flex items-center gap-1 px-2 py-1 rounded bg-[#202531] hover:bg-[#2c3345] text-[#9ca7b7] hover:text-white border border-dashed border-[#374158] transition-colors"
              title={t('spriteTimeline.createNewAnimationTrack')}
            >
              <Plus className="w-3 h-3 text-sky-400" />
              <span className="text-[11px]">{t('spriteTimeline.new')}</span>
            </button>
          )}
        </div>

        {/* Velocidade e modo agora ficam no painel de propriedades (como no GameMaker); aqui só o resumo */}
        {activeAnim && (
          <div className="flex items-center gap-2 text-[11px] text-[#8b97a8] font-mono" data-testid="sprite-anim-summary">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>{activeAnim.fps} FPS</span>
            <span>·</span>
            <span>{activeAnim.loopMode === 'loop' ? t('spriteTimelineMsgTwo.loop') : activeAnim.loopMode === 'once' ? '1x' : 'Ping-pong'}</span>
          </div>
        )}
      </div>

      {/* Main Playback Bar & Controls */}
      <div className="flex items-center justify-between px-3 py-1 bg-[#181c24] border-b border-[#2c3345]">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onStepFrame(-1000)}
            className="p-1 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title={t('spriteTimeline.firstFrame')}
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => onStepFrame(-1)}
            className="p-1 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title={t('spriteTimeline.previousFrame')}
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            onClick={onTogglePlay}
            className={`px-3 py-1 rounded flex items-center gap-1.5 font-medium text-xs shadow-sm transition-colors ${
              isPlaying
                ? 'bg-amber-600 hover:bg-amber-500 text-white'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5" /> {t('spriteTimeline.pause')}
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" /> {t('spriteTimeline.play')}
              </>
            )}
          </button>

          <button
            onClick={() => onStepFrame(1)}
            className="p-1 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title={t('spriteTimeline.nextFrame')}
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => onStepFrame(1000)}
            className="p-1 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title={t('spriteTimeline.lastFrame')}
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>

          <div className="h-4 w-[1px] bg-[#374158] mx-1" />

          {/* Posição na animação */}
          <span className="text-xs text-[#cbd5e1] font-mono" data-testid="sprite-timeline-readout">
            {t('manualUi.frameColon')} <strong className="text-sky-400">{activePos >= 0 ? activePos + 1 : '–'}</strong> / {seq.length}
          </span>
        </div>

        {/* Ações sobre os quadros DESTA animação */}
        <div className="flex items-center gap-1">
          <label className="flex items-center gap-1 text-[11px] text-[#9ca7b7] mr-1" title={t('spriteTimeline.selectedFrameSTimeMultiplier')}>
            {t('spriteTimeline.duration')}
            <input
              type="number"
              min="0.1"
              max="20"
              step="0.25"
              value={seq.length ? multOf(sel) : 1}
              disabled={seq.length === 0}
              onChange={(e) => seqSetMult(parseFloat(e.target.value))}
              className="w-14 px-1 py-0.5 bg-[#141822] text-center font-mono rounded border border-[#3b475e] text-white disabled:opacity-40"
            />
          </label>
          <button onClick={onAddFrame} className="flex items-center gap-1 px-2 py-1 rounded bg-[#202531] hover:bg-[#2c3345] text-sky-400 hover:text-sky-300 text-xs transition-colors" title={t('spriteTimeline.addABlankFrameAt')}>
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t('spriteTimeline.addFrame')}</span>
          </button>
          <button
            onClick={() => seq.length > 0 && onDuplicateFrame(seq[sel])}
            disabled={seq.length === 0}
            className="flex items-center gap-1 px-2 py-1 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] text-xs transition-colors disabled:opacity-40"
            title={t('spriteTimeline.duplicateTheSelectedFrameEditable')}
          >
            <Copy className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t('shared.duplicate')}</span>
          </button>
          <button onClick={() => seqReorder(sel, sel - 1)} disabled={sel <= 0} className="p-1 rounded text-[#dfe4ec] hover:bg-[#2c3345] disabled:text-[#4e586c] disabled:cursor-not-allowed" title={t('spriteTimeline.moveFrameLeft')}>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => seqReorder(sel, sel + 1)} disabled={sel >= seq.length - 1} className="p-1 rounded text-[#dfe4ec] hover:bg-[#2c3345] disabled:text-[#4e586c] disabled:cursor-not-allowed" title={t('spriteTimeline.moveFrameRight')}>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button onClick={seqRemove} disabled={seq.length <= 1} className="p-1 rounded text-[#b3bed0] hover:text-rose-400 hover:bg-rose-950/30 disabled:text-[#4e586c] disabled:cursor-not-allowed" title={t('spriteTimeline.removeTheFrameFromThis')}>
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Faixa de quadros: SOMENTE os da animação ativa, na ordem dela (arraste para reordenar) */}
      <div className="flex-1 overflow-x-auto flex items-center gap-2 p-2.5 bg-[#141822]" data-testid="sprite-strip">
        {seq.length === 0 && <span className="text-xs text-[#64748b]">{t('spriteTimeline.thisAnimationHasNoFrames')}</span>}
        {seq.map((frameIdx, pos) => {
          const frame = project.frames[frameIdx];
          const isActive = pos === activePos;
          const isSelected = pos === sel;
          const frameCanvas = frameCanvases[frameIdx];
          const mult = multOf(pos);
          return (
            <div
              key={`${pos}-${frameIdx}`}
              onClick={() => {
                setSelPos(pos);
                onSelectFrame(frameIdx);
              }}
              draggable
              data-testid={`sprite-strip-frame-${pos}`}
              onDragStart={(e) => {
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/x-sprite-frame', String(pos));
                setDragFrom(pos);
              }}
              onDragOver={(e) => {
                if (dragFrom !== null) {
                  e.preventDefault();
                  setDropAt(pos);
                }
              }}
              onDragLeave={() => setDropAt((d) => (d === pos ? null : d))}
              onDrop={(e) => {
                e.preventDefault();
                const from = dragFrom ?? parseInt(e.dataTransfer.getData('text/x-sprite-frame'));
                setDragFrom(null);
                setDropAt(null);
                if (Number.isInteger(from)) seqReorder(from, pos);
              }}
              onDragEnd={() => {
                setDragFrom(null);
                setDropAt(null);
              }}
              title={t('spriteTimeline.clickToSelectDragTo')}
              className={`flex flex-col items-center justify-between p-1 rounded-lg cursor-pointer transition-all shrink-0 w-20 h-24 border ${dropAt === pos && dragFrom !== null && dragFrom !== pos ? 'ring-2 ring-emerald-400 ' : ''}${dragFrom === pos ? 'opacity-40 ' : ''}${
                isActive ? 'bg-[#242f44] border-sky-400 ring-2 ring-sky-500/30 shadow-md' : isSelected ? 'bg-[#1f2736] border-[#4f5d79]' : 'bg-[#1b212d] border-[#374158] hover:border-[#4f5d79]'
              }`}
            >
              <div className="flex items-center justify-between w-full px-1 text-[10px]">
                <span className={`font-mono font-bold ${isActive ? 'text-sky-400' : 'text-[#8b97a8]'}`}>{pos + 1}</span>
                {mult !== 1 && <span className="font-mono text-amber-300" title={t('spriteTimeline.timeMultiplier')}>×{mult}</span>}
              </div>

              <div className="w-14 h-14 bg-[#0e1118] rounded flex items-center justify-center overflow-hidden border border-[#2c3345] shadow-inner relative">
                {frameCanvas ? (
                  <img src={frameCanvas.toDataURL()} alt={t('spriteTimelineMsg.frame', { value: pos + 1 })} className="max-w-full max-h-full object-contain" style={{ imageRendering: 'pixelated' }} />
                ) : frame?.customDataUrl ? (
                  <img src={frame.customDataUrl} alt={t('spriteTimelineMsg.frame', { value: pos + 1 })} className="max-w-full max-h-full object-contain" style={{ imageRendering: 'pixelated' }} />
                ) : (
                  <div className="text-[9px] text-[#4b5563]">{t('spriteTimeline.empty')}</div>
                )}
              </div>

              <span className="text-[9px] text-[#64748b] font-mono" title={t('manualUi.atlasFrameNumber')}>
                {t('spriteTimeline.atlas', { value: frameIdx + 1 })}</span>
            </div>
          );
        })}

        <button
          onClick={onAddFrame}
          className="flex flex-col items-center justify-center w-16 h-24 rounded-lg border-2 border-dashed border-[#2e3748] hover:border-sky-400 hover:bg-[#1b2230] text-[#64748b] hover:text-sky-300 transition-colors shrink-0 gap-1"
          title={t('spriteTimeline.newFrameInThisAnimation')}
        >
          <Plus className="w-4 h-4" />
          <span className="text-[10px]">{t('spriteTimeline.frame')}</span>
        </button>
      </div>
    </div>
  );
};
