import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { buildTree, disposeTree, type TreeStats } from '../../core/tree/treeBuild';
import type { TreeParams } from '../../core/tree/treeParams';
import type { BarkMapUrls } from '../../core/tree/treeBark';
import { loadBarkTextures, loadLeafTexture } from '../../core/tree/treeBarkTextures';
import type { LeafAtlas } from '../../core/tree/treeLeaf';

interface TreePreview3DProps {
  active: boolean;
  params: TreeParams;
  /** Mapas da casca já resolvidos (projeto ou biblioteca); `key` muda quando o conteúdo muda. */
  barkMaps?: (BarkMapUrls & { key: string }) | undefined;
  /** Atlas de folhagem resolvido (projeto ou biblioteca). */
  leafAtlas?: LeafAtlas | undefined;
  wireframeMode: boolean;
  animateWindPreview: boolean;
  previewRotation: number;
  onStats: (stats: TreeStats) => void;
}

/**
 * Preview real do editor de árvores (AIS-51a): cena Three.js em miniatura com a MESMA `buildTree` da Viewport e do Play,
 * OrbitControls e o fundo escuro da casca. Recalcula a cada mudança de campo; as estatísticas vêm da geometria real.
 */
export const TreePreview3D: React.FC<TreePreview3DProps> = ({ active, params, barkMaps, leafAtlas, wireframeMode, animateWindPreview, previewRotation, onStats }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    pivot: THREE.Group;
    renderer: THREE.WebGLRenderer;
    tree: THREE.Object3D | null;
    fitted: boolean;
  } | null>(null);
  const onStatsRef = useRef(onStats);
  onStatsRef.current = onStats;

  // cena, câmera, luzes, controles e laço de render (uma vez por abertura do modal)
  useEffect(() => {
    if (!active) return;
    const container = containerRef.current;
    if (!container) return;
    const w = Math.max(1, container.clientWidth);
    const h = Math.max(1, container.clientHeight);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x10141c);
    const camera = new THREE.PerspectiveCamera(40, w / h, 0.1, 500);
    camera.position.set(9, 6, 12);

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(w, h, false);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    container.replaceChildren(renderer.domElement);
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.target.set(0, 4, 0);

    scene.add(new THREE.HemisphereLight(0xbfd4ff, 0x2a2118, 0.9));
    const sun = new THREE.DirectionalLight(0xffffff, 2.2);
    sun.position.set(8, 14, 6);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.camera.left = -14; sun.shadow.camera.right = 14; sun.shadow.camera.top = 18; sun.shadow.camera.bottom = -6;
    sun.shadow.camera.far = 50;
    scene.add(sun);

    const ground = new THREE.Mesh(
      new THREE.CircleGeometry(9, 48),
      new THREE.MeshStandardMaterial({ color: 0x0c0f16, roughness: 0.9 }),
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground, new THREE.GridHelper(18, 18, 0x3d4a66, 0x1a2130));

    const pivot = new THREE.Group();
    scene.add(pivot);
    stateRef.current = { scene, camera, controls, pivot, renderer, tree: null, fitted: false };

    const ro = new ResizeObserver(() => {
      const cw = container.clientWidth;
      const ch = container.clientHeight;
      if (cw > 0 && ch > 0) {
        camera.aspect = cw / ch;
        camera.updateProjectionMatrix();
        renderer.setSize(cw, ch, false);
      }
    });
    ro.observe(container);

    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      controls.update();
      renderer.render(scene, camera);
    };
    loop();

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      controls.dispose();
      if (stateRef.current?.tree) disposeTree(stateRef.current.tree);
      ground.geometry.dispose();
      (ground.material as THREE.Material).dispose();
      renderer.dispose();
      container.replaceChildren();
      stateRef.current = null;
    };
  }, [active]);

  // recalcula a árvore a cada mudança de parâmetro (a seed e todos os campos entram em `params`)
  useEffect(() => {
    const st = stateRef.current;
    if (!active || !st) return;
    if (st.tree) {
      st.pivot.remove(st.tree);
      disposeTree(st.tree);
    }
    const { object, stats, height } = buildTree(params, { bark: loadBarkTextures(barkMaps), leaf: leafAtlas && loadLeafTexture(leafAtlas.url) ? { map: loadLeafTexture(leafAtlas.url)!, cells: leafAtlas.cells } : undefined });
    st.tree = object;
    st.pivot.add(object);
    if (!st.fitted || height > 0) {
      // enquadra pela altura real; só reposiciona a câmera na primeira árvore (depois o usuário manda)
      st.controls.target.set(0, height * 0.5, 0);
      if (!st.fitted) {
        st.camera.position.set(height * 0.9, height * 0.7, height * 1.3);
        st.fitted = true;
      }
    }
    onStatsRef.current(stats);
    if (containerRef.current) {
      containerRef.current.dataset.triangles = String(Math.round(stats.triangles));
      containerRef.current.dataset.leaves = String(stats.foliageInstances);
      containerRef.current.dataset.height = height.toFixed(2);
    }
  }, [active, params, barkMaps?.key, leafAtlas?.key]); // eslint-disable-line react-hooks/exhaustive-deps

  // wireframe, vento e rotação não reconstroem a malha
  useEffect(() => {
    const st = stateRef.current;
    if (!st?.tree) return;
    st.tree.traverse((o) => {
      const mat = (o as THREE.Mesh).material as THREE.Material | undefined;
      if (mat && 'wireframe' in mat) (mat as THREE.MeshStandardMaterial).wireframe = wireframeMode;
    });
    const wind = st.tree.userData.treeWind as { uStrength: { value: number } } | undefined;
    if (wind) wind.uStrength.value = animateWindPreview && params.material.wind.enabled ? params.material.wind.strength : 0;
    st.pivot.rotation.y = (previewRotation * Math.PI) / 180;
  }, [params, wireframeMode, animateWindPreview, previewRotation]);

  return <div ref={containerRef} data-testid="tree-preview-3d" className="w-full h-full min-h-[300px] rounded-md overflow-hidden" />;
};
