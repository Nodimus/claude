import React, { useEffect, useRef } from 'react';
import { createState, resetState, sampleParticle, step, type ParticleState } from '../../core/particles/particleEngine';
import { getTintedParticleCanvas } from '../../core/particles/particleTextures';
import type { ParticleProps } from '../../core/particles/particleTypes';
import { useTranslation } from '../../core/i18n/I18nContext';

interface ParticlePreviewCanvasProps {
  /** Propriedades no formato do nó; o preview apenas as lê. */
  draft: ParticleProps;
  paused: boolean;
  /** Incrementar para limpar as partículas e reiniciar a sequência da seed. */
  resetKey: number;
  width?: number;
  height?: number;
  className?: string;
}

const COMPOSITE: Record<ParticleProps['blending'], GlobalCompositeOperation> = {
  additive: 'lighter',
  alpha: 'source-over',
  modulate: 'multiply',
};

/**
 * Preview 2D do `ParticleModal`: roda o MESMO `step()` do motor único e as mesmas texturas
 * procedurais da viewport. Não guarda parâmetros — só o estado de simulação do motor.
 */
export const ParticlePreviewCanvas: React.FC<ParticlePreviewCanvasProps> = ({
  draft,
  paused,
  resetKey,
  width = 380,
  height = 460,
  className,
}) => {
  const { t } = useTranslation();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const draftRef = useRef(draft);
  draftRef.current = draft;
  const pausedRef = useRef(paused);
  pausedRef.current = paused;
  const stateRef = useRef<ParticleState | null>(null);

  useEffect(() => {
    if (stateRef.current) resetState(stateRef.current);
  }, [resetKey, draft.seed]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const state = createState(draftRef.current);
    stateRef.current = state;
    let last = performance.now();
    let frame = 0;

    const render = () => {
      const now = performance.now();
      const dt = Math.min(0.06, (now - last) * 0.001);
      last = now;
      const props = { ...draftRef.current, emitting: true };
      state.seed = props.seed >>> 0;

      const w = canvas.width;
      const h = canvas.height;
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#0a0d14';
      ctx.fillRect(0, 0, w, h);

      const cx = w * 0.5;
      const cy = h * 0.72;

      ctx.strokeStyle = 'rgba(35, 45, 65, 0.4)';
      ctx.lineWidth = 1;
      for (let r = 20; r <= 140; r += 30) {
        ctx.beginPath();
        ctx.ellipse(cx, cy, r, r * 0.35, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      if (props.emitterType === 'ring' || props.emitterType === 'sphere') {
        ctx.beginPath();
        ctx.ellipse(cx, cy, props.emitterRadius * 40, props.emitterRadius * 15, 0, 0, Math.PI * 2);
        ctx.stroke();
      } else if (props.emitterType === 'box') {
        const bw = props.emitterBoxSize.x * 35;
        const bh = props.emitterBoxSize.z * 18;
        ctx.strokeRect(cx - bw * 0.5, cy - bh * 0.5, bw, bh);
      } else {
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(cx, cy, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      if (!pausedRef.current) step(state, props, dt);

      ctx.globalCompositeOperation = COMPOSITE[props.blending];
      for (let i = 0; i < state.count; i++) {
        const s = sampleParticle(state, props, i);
        const px = Math.max(2, s.size * 45);
        const sx = cx + state.x[i] * 45;
        const sy = cy - state.y[i] * 45 + state.z[i] * 15;
        ctx.globalAlpha = Math.min(1, Math.max(0, s.a));
        ctx.drawImage(getTintedParticleCanvas(props.texture, s.r, s.g, s.b), sx - px / 2, sy - px / 2, px, px);
      }
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 1;

      ctx.fillStyle = 'rgba(10, 14, 22, 0.75)';
      ctx.fillRect(8, 8, w - 16, 22);
      ctx.strokeStyle = 'rgba(38, 48, 68, 0.8)';
      ctx.strokeRect(8, 8, w - 16, 22);
      ctx.fillStyle = '#38bdf8';
      ctx.font = t('sharedMsg.n10pxMonospace');
      ctx.fillText(
        t('particlePreviewCanvasMsg.activeRatePSBlend', { count: state.count, maxParticles: props.maxParticles, particlesPerSecond: props.particlesPerSecond, blending: props.blending.toUpperCase() }),
        14,
        22
      );

      frame = requestAnimationFrame(render);
    };

    frame = requestAnimationFrame(render);
    return () => {
      cancelAnimationFrame(frame);
      stateRef.current = null;
    };
  }, [t]);

  return <canvas ref={canvasRef} width={width} height={height} className={className} />;
};
