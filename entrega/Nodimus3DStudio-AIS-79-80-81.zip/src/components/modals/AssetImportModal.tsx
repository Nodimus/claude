/**
 * AIS-33 — o monólito de 2375 linhas foi dividido em `src/components/modals/assetImport/` (casca, abas, preview e hook de
 * sessão) e `src/core/modelImport/` (lógica pura). Este arquivo só mantém o caminho de importação dos chamadores.
 */
export { AssetImportModal } from './assetImport/AssetImportModal';
