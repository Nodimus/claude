import { useTranslation } from '../../../core/i18n/I18nContext';
import React, { useRef, useState } from 'react';
import { AlertTriangle, ChevronLeft, ChevronRight, FilePlus2, Pause, Play, Sparkles, X } from 'lucide-react';
import { COVERAGE_THRESHOLD, type LibraryClip } from '../../../core/modelImport/animationLibrary';
import { MAX_SPEED, MIN_SPEED, PREVIEW_FPS, frameCount, timeToFrame } from '../../../runtime/skeletalAnimation';
import type { ModelImportSession } from './useModelImportSession';
import { HEADER, NOTE, NoModel } from './tabParts';

const CARD = 'space-y-2 bg-[#1b2230] p-3 rounded-lg border border-[#273347]';
const LABEL = 'text-[11px] font-bold text-white uppercase tracking-wider block';
const BTN = 'bg-[#222a3b] hover:bg-[#2b354a] border border-[#2e3b52] text-[#93a1b8] disabled:opacity-50 disabled:cursor-not-allowed';
const SPEEDS = [0.25, 0.5, 1, 1.5, 2];

/** Aba 4 — Animation Player (AIS-37): biblioteca de clipes (embutidos + arquivos só de animação) e player com scrub, velocidade, loop e crossfade. */
export const AnimationTab: React.FC<{ session: ModelImportSession }> = ({ session: s }) => {
  const { t } = useTranslation();
  const a = s.animation;
  const model = s.loaded;
  const picker = useRef<HTMLInputElement>(null);
  const [fadeTo, setFadeTo] = useState('');
  const [fadeSeconds, setFadeSeconds] = useState(0.3);

  const snap = a.snapshot;
  const frames = frameCount(snap.duration);
  const frame = timeToFrame(snap.time);
  const targets = a.accepted.filter((c) => c.name !== snap.clip);
  const fadeTarget = targets.some((c) => c.name === fadeTo) ? fadeTo : targets[0]?.name ?? '';

  return (
    <div className="p-4 space-y-4">
      <div className={HEADER}>
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <h3 className="font-bold text-sm text-white">{t('animationTab.animationPlayer')}</h3>
        </div>
        <span className="text-[10px] text-[#8695ad]" data-testid="anim-counts">
          {t('animationTab.clipSInTheLibrary', { length: a.accepted.length, length2: a.library.length })}
        </span>
      </div>

      {s.isReedit && (
        <div className={NOTE} role="status" data-testid="anim-reedit-note">
          <b className="text-white">{t('animationTab.editImport')}</b> {t('animationTab.theClipLibraryIsNot')}
        </div>
      )}

      {!model ? (
        <NoModel />
      ) : (
        <>
          <div className={CARD}>
            <div className="flex items-center justify-between">
              <label className={LABEL}>{t('animationTab.clipLibrary2')}</label>
              <button onClick={() => picker.current?.click()} className={`px-2 py-1 rounded text-[11px] border flex items-center gap-1 ${BTN}`} title={t('animationTab.animationOnlyFbxGlbGltf')}>
                <FilePlus2 className="w-3 h-3 text-emerald-400" /> {t('animationTab.addAnimations')}
              </button>
              <input
                ref={picker}
                type="file"
                multiple
                accept=".fbx,.glb,.gltf,.dae"
                className="hidden"
                data-testid="anim-file-input"
                onChange={(e) => {
                  const files = Array.from(e.target.files ?? []);
                  e.target.value = '';
                  if (files.length > 0) void a.addFiles(files);
                }}
              />
            </div>
            {a.library.length === 0 ? (
              <div className={NOTE} data-testid="anim-empty">
                {t('animationTab.thisModelHasNoAnimations')}
              </div>
            ) : (
              <div className="space-y-1" role="list" aria-label={t('animationTab.clipLibrary')}>
                {a.library.map((c) => (
                  <ClipRow key={c.id} clip={c} onPatch={(p) => a.patchClip(c.id, p)} />
                ))}
              </div>
            )}
            {a.extraFiles.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {a.extraFiles.map((f) => (
                  <span key={f.name} className="inline-flex items-center gap-1 bg-[#222a3b] border border-[#2e3b52] rounded px-1.5 py-0.5 text-[10px] text-[#b8c4d6]">
                    <span className="font-mono">{f.name}</span>
                    <button onClick={() => a.removeFile(f.name)} aria-label={t('sharedMsg.remove', { name: f.name })} className="text-[#8695ad] hover:text-white">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
            {a.notice && (
              <div role="status" className="flex items-start gap-1.5 text-[10px] text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded px-2 py-1.5">
                <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
                <span>{a.notice}</span>
              </div>
            )}
            <p className="text-[10px] text-[#8695ad]">
              {t('manualUi.libraryKeeps1')} <b className="text-white">{t('animationTab.references')}</b> {t('manualUi.libraryKeeps2')} <span className="font-mono">res://materials/&lt;asset&gt;_rig.json</span> {t('manualUi.libraryKeeps3', { percent: Math.round(COVERAGE_THRESHOLD * 100) })}
            </p>
          </div>

          {a.hasPlayer && (
            <div className={CARD} data-testid="anim-player">
              <label className={LABEL}>{t('animationTab.player')}</label>
              <select
                aria-label={t('animationTab.playerClip')}
                value={snap.clip ?? ''}
                onChange={(e) => a.select(e.target.value)}
                className="w-full bg-[#141820] text-[11px] text-[#dfe4ec] px-1.5 py-1 rounded border border-[#2c3345] outline-none focus:border-blue-500"
              >
                {a.accepted.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>

              <div className="flex items-center gap-1.5">
                <button onClick={() => a.stepFrame(-1)} aria-label={t('animationTab.previousFrame')} className={`p-1.5 rounded border ${BTN}`}>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <button onClick={a.toggle} aria-label={snap.playing ? t('sharedMsgTwo.pause') : t('animationTabMsgTwo.play')} className={`px-3 py-1.5 rounded border flex items-center gap-1 text-[11px] ${snap.playing ? 'bg-blue-600/30 border-blue-500 text-blue-300' : BTN}`}>
                  {snap.playing ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{snap.playing ? t('sharedMsgTwo.pause') : t('animationTabMsgTwo.play')}</span>
                </button>
                <button onClick={() => a.stepFrame(1)} aria-label={t('animationTab.nextFrame')} className={`p-1.5 rounded border ${BTN}`}>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
                <span className="ml-auto font-mono text-[10px] text-[#b8c4d6]" data-testid="anim-frame">
                  {t('animationTab.frameSS', { frame, value: frames - 1, value2: snap.time.toFixed(2), value3: snap.duration.toFixed(2) })}
                </span>
              </div>

              <input
                type="range"
                aria-label={t('animationTab.timeline')}
                min={0}
                max={Math.max(0, frames - 1)}
                step={1}
                value={Math.min(frame, frames - 1)}
                onChange={(e) => a.seek(parseInt(e.target.value, 10) / PREVIEW_FPS)}
                className="w-full accent-emerald-500 h-1.5 bg-[#253042] rounded"
              />

              <div className="flex items-center justify-between gap-2 text-[11px]">
                <label className="flex items-center gap-1.5 text-[#8695ad]">
                  {t('shared.speed')}
                  <select
                    aria-label={t('shared.speed')}
                    value={snap.speed}
                    onChange={(e) => a.setSpeed(parseFloat(e.target.value))}
                    className="bg-[#141820] text-[11px] text-[#dfe4ec] px-1 py-0.5 rounded border border-[#2c3345] outline-none"
                  >
                    {SPEEDS.filter((v) => v >= MIN_SPEED && v <= MAX_SPEED).map((v) => (
                      <option key={v} value={v}>
                        {v}×
                      </option>
                    ))}
                  </select>
                </label>
                <label className="flex items-center gap-1.5 text-white cursor-pointer">
                  <input type="checkbox" aria-label={t('shared.loop')} checked={snap.loop} onChange={(e) => a.setLoop(e.target.checked)} className="rounded bg-[#232c3d] border-[#384661] text-emerald-500 focus:ring-0" />
                  {t('shared.loop')}
                </label>
              </div>

              {targets.length > 0 && (
                <div className="flex items-center gap-1.5 pt-1 border-t border-[#273347] text-[11px]">
                  <span className="text-[#8695ad]">{t('animationTab.crossfade')}</span>
                  <select aria-label={t('animationTab.crossfadeTargetClip')} value={fadeTarget} onChange={(e) => setFadeTo(e.target.value)} className="flex-1 min-w-0 bg-[#141820] text-[11px] text-[#dfe4ec] px-1 py-0.5 rounded border border-[#2c3345] outline-none">
                    {targets.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                  <input
                    type="number"
                    aria-label={t('animationTab.crossfadeDurationS')}
                    min={0}
                    max={5}
                    step={0.1}
                    value={fadeSeconds}
                    onChange={(e) => setFadeSeconds(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-14 bg-[#141820] text-[11px] text-right font-mono text-[#dfe4ec] px-1 py-0.5 rounded border border-[#2c3345] outline-none"
                  />
                  <span className="text-[#8695ad]">s</span>
                  <button onClick={() => fadeTarget && a.crossFadeTo(fadeTarget, fadeSeconds)} disabled={!fadeTarget} className={`px-2 py-1 rounded border ${BTN}`}>
                    {t('shared.apply')}
                  </button>
                </div>
              )}
            </div>
          )}
          {!a.hasPlayer && a.library.length > 0 && (
            <div className={NOTE}>{t('animationTab.noClipIsInThe')}</div>
          )}
        </>
      )}
    </div>
  );
};

const ClipRow: React.FC<{ clip: LibraryClip; onPatch(p: { accepted?: boolean; loop?: boolean; inPlace?: boolean }): void }> = ({ clip, onPatch }) => {
  const { t } = useTranslation();
  return (
  <div role="listitem" className={`p-2 rounded-lg border text-[11px] space-y-1 ${clip.accepted ? 'bg-[#1b2230] border-[#29354a]' : 'bg-[#1b2230]/60 border-amber-500/40'}`} data-testid="anim-clip">
    <div className="flex items-center justify-between gap-2">
      <label className="flex items-center gap-1.5 min-w-0 cursor-pointer">
        <input type="checkbox" aria-label={t('animationTabMsg.include', { name: clip.name })} checked={clip.accepted} onChange={(e) => onPatch({ accepted: e.target.checked })} className="rounded bg-[#232c3d] border-[#384661] text-emerald-500 focus:ring-0" />
        <span className="font-bold text-white truncate">{clip.name}</span>
        {clip.renamedFrom && <span className="text-[9px] text-amber-300 font-mono" title={t('animationTabMsg.duplicateNameWas', { renamedFrom: clip.renamedFrom })}>{t('animationTab.renamed')}</span>}
      </label>
      <span className="font-mono text-[#8a98ae] shrink-0">
        {t('animationTab.sTrackS', { value: clip.duration.toFixed(2), trackCount: clip.trackCount })}
      </span>
    </div>
    <div className="flex items-center justify-between gap-2 text-[10px] text-[#8695ad]">
      <span className="truncate">
        {clip.sourceKind === 'embedded' ? t('animationTabMsg.embeddedInTheModel') : clip.fileName}
        {' · '}
        <span className={clip.compatible ? 'text-emerald-400' : 'text-amber-300'}>{t('animationTab.coverage', { value: Math.round(clip.coverage * 100) })}</span>
      </span>
      <span className="flex items-center gap-2 shrink-0">
        <label className="flex items-center gap-1 cursor-pointer text-[#b8c4d6]">
          <input type="checkbox" aria-label={t('animationTabMsg.loopOf', { name: clip.name })} checked={clip.loop} onChange={(e) => onPatch({ loop: e.target.checked })} className="rounded bg-[#232c3d] border-[#384661] text-emerald-500 focus:ring-0" />
          {t('animationTab.loop')}
        </label>
        <label className="flex items-center gap-1 cursor-pointer text-[#b8c4d6]" title={t('animationTab.noHorizontalRootDisplacementRecommende')}>
          <input type="checkbox" aria-label={t('animationTabMsg.inPlaceOf', { name: clip.name })} checked={clip.inPlace} onChange={(e) => onPatch({ inPlace: e.target.checked })} className="rounded bg-[#232c3d] border-[#384661] text-emerald-500 focus:ring-0" />
          {t('animationTab.inPlace')}
        </label>
      </span>
    </div>
    {!clip.compatible && (
      <div role="status" className="flex items-start gap-1.5 text-[10px] text-amber-300" data-testid="anim-incompatible">
        <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
        <span>
          <span className="font-mono">{t('animationTab.animIncompatibleSkeleton')}</span>{t('manualUi.clipCoversLess', { percent: Math.round(COVERAGE_THRESHOLD * 100) })}{' '}
          {clip.accepted ? t('manualUi.acceptedManually') : t('manualUi.outOfLibrary')}
        </span>
      </div>
    )}
  </div>
);
};
