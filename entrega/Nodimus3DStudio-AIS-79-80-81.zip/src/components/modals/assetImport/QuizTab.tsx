import React from 'react';
import { AlertTriangle, CheckCircle2, HelpCircle, Info, Undo2, Wand2 } from 'lucide-react';
import { QUIZ_GROUPS, fixableCount } from '../../../core/modelImport/diagnostics';
import type { ModelImportSession } from './useModelImportSession';
import { HEADER, NOTE, NoModel } from './tabParts';
import { useTranslation } from '../../../core/i18n/I18nContext';

const CARD = 'space-y-2 bg-[#1b2230] p-3 rounded-lg border border-[#273347]';
const BTN = 'px-2 py-1 rounded text-[11px] font-medium border bg-[#222a3b] hover:bg-[#2b354a] border-[#2e3b52] text-[#93a1b8] hover:text-white';

/** Aba 5 — Quiz / Diagnóstico (AIS-38): scanner automático sobre os dados reais do modelo; correções agem no rascunho. */
export const QuizTab: React.FC<{ session: ModelImportSession }> = ({ session: s }) => {
  const { t } = useTranslation();
  const model = s.loaded;
  const fixable = fixableCount(s.findings);

  return (
    <div className="p-4 space-y-4">
      <div className={HEADER}>
        <div className="flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-amber-400" />
          <h3 className="font-bold text-sm text-white">{t('quizTab.questionsDiagnosticsQuiz')}</h3>
        </div>
        {model && (
          <span className="text-[10px] text-[#8695ad]" data-testid="quiz-count">
            {t('quizTab.findingS', { length: s.findings.length })}
          </span>
        )}
      </div>

      {!model ? (
        <NoModel />
      ) : (
        <>
          <div className="flex items-center gap-2">
            <button
              onClick={s.fixAll}
              disabled={fixable === 0}
              title={fixable === 0 ? t('quizTabMsg.noItemWithAutomaticFix') : t('quizTabMsg.appliesToTheDraftThe')}
              className="flex-1 px-3 py-2 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-[11px] font-bold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              data-testid="quiz-fix-all"
            >
              <Wand2 className="w-3.5 h-3.5" />
              {t('manualUi.fixAllDiagnosed')}{fixable > 0 ? ` (${fixable})` : ''}
            </button>
            <button
              onClick={s.undoFixes}
              disabled={!s.canUndoFixes}
              title={s.canUndoFixes ? t('quizTabMsg.returnsTheDraftToThe') : t('quizTabMsg.noFixApplied')}
              className={`${BTN} py-2 flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed`}
              data-testid="quiz-undo"
            >
              <Undo2 className="w-3 h-3" /> {t('quizTab.undoFixes')}
            </button>
          </div>

          {QUIZ_GROUPS.map((g) => {
            const items = s.findings.filter((f) => f.group === g.id);
            return (
              <div key={g.id} className={CARD} data-testid={`quiz-group-${g.id}`}>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-white uppercase tracking-wider">{g.label}</span>
                  {items.length === 0 && (
                    <span className="flex items-center gap-1 text-[10px] text-emerald-400">
                      <CheckCircle2 className="w-3 h-3" /> {t('quizTab.noProblems')}
                    </span>
                  )}
                </div>
                {items.map((f) => (
                  <div
                    key={`${f.code}:${f.target ?? ''}`}
                    className={`flex items-start gap-2 text-[11px] rounded px-2 py-1.5 border ${f.severity === 'warning' ? 'text-amber-200 bg-amber-500/10 border-amber-500/30' : 'text-[#bac7db] bg-[#202838] border-[#2e3b52]'}`}
                    data-testid={`quiz-item-${f.code}`}
                  >
                    {f.severity === 'warning' ? <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" /> : <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-blue-400" />}
                    <div className="flex-1 min-w-0">
                      <span className="font-mono text-[10px] opacity-70">{f.code}</span>
                      <div className="break-words">{f.message}</div>
                    </div>
                    {f.fix && (
                      <button onClick={() => s.fixFinding(f)} className={`${BTN} shrink-0`} title={f.fix.label}>
                        {t('quizTab.fix')}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            );
          })}

          {s.questions.map((q) => (
            <div key={q.id} className={NOTE} data-testid={`quiz-question-${q.id}`}>
              <div className="text-white font-bold mb-2">{q.text}</div>
              <button onClick={() => s.answerQuestion(q.id)} className={BTN}>
                {q.yesLabel}
              </button>
            </div>
          ))}
        </>
      )}
    </div>
  );
};
