import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { Compass, Crosshair, Eye, FolderOpen, Layers, Loader2, User } from 'lucide-react';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { HUMAN_REFERENCE_HEIGHT_M, effectiveRotationDeg, type ImportTransformDraft, type Vec3 } from '../../../core/modelImport/calibration';
import { MANNEQUIN_NAME, RULER_NAME, buildRigOverlay, buildHeightBillboard, buildSketchUpHumanFigure, disposeTree } from './previewScene';
import { useTranslation } from '../../../core/i18n/I18nContext';

export type ImportStatus = 'empty' | 'loading' | 'ready' | 'error';

export interface PreviewStats {
  meshes: number;
  triangles: number;
  vertices: number;
  /** Altura nativa em metros (AABB do modelo carregado). */
  heightM: number | null;
}

interface ImportPreviewProps {
  /** Titular criado por `createModelObject` (marcador → modelo). */
  model: THREE.Object3D | null;
  /** Muda quando o modelo termina de carregar (recalcula a caixa delimitadora). */
  revision: number;
  transform: ImportTransformDraft;
  status: ImportStatus;
  stats: PreviewStats | null;
  showHuman: boolean;
  showRuler: boolean;
  humanDistance: number;
  wireframe: boolean;
  /** AIS-36: overlay do esqueleto mapeado (só os ossos dos 19, por nome do `THREE.Skeleton`). */
  showSkeleton?: boolean;
  skeletonBones?: readonly string[];
  /** Modo do gizmo RGB (edita só o rascunho; nunca o CommandManager). */
  gizmoMode: 'translate' | 'rotate' | 'scale';
  /** O gizmo moveu/girou/escalou o modelo: devolve valores já no formato do rascunho. */
  onGizmoChange(patch: { position: Vec3; rotationDeg: Vec3; scale: number; scaleAxes: Vec3 }): void;
  onShowHuman(value: boolean): void;
  onShowRuler(value: boolean): void;
  onHumanDistance(value: number): void;
  onToggleWireframe(): void;
  onCenterToOrigin(): void;
  onNormalizeToHuman(): void;
  onFlipZUp(): void;
  onPickFile(): void;
}

const toRad = (deg: number) => (deg * Math.PI) / 180;
const round4 = (n: number) => Math.round(n * 10000) / 10000;

/** Preview 3D do modelo REAL, a caixa delimitadora e as réguas. A cena é do modal: nada aqui toca o documento. */
export const ImportPreview: React.FC<ImportPreviewProps> = ({
  model,
  revision,
  transform,
  status,
  stats,
  showHuman,
  showRuler,
  humanDistance,
  wireframe,
  showSkeleton = false,
  skeletonBones,
  gizmoMode,
  onGizmoChange,
  onShowHuman,
  onShowRuler,
  onHumanDistance,
  onToggleWireframe,
  onCenterToOrigin,
  onNormalizeToHuman,
  onFlipZUp,
  onPickFile,
}) => {
  const { t } = useTranslation();
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const modelGroupRef = useRef<THREE.Group | null>(null);
  const humanRef = useRef<THREE.Group | null>(null);
  const controlsRef = useRef<TransformControls | null>(null);
  const billboardRef = useRef<ReturnType<typeof buildHeightBillboard> | null>(null);
  const boxRef = useRef<THREE.Box3Helper | null>(null);
  const showRulerRef = useRef(showRuler);
  showRulerRef.current = showRuler;
  const draftRef = useRef(transform);
  draftRef.current = transform;
  const gizmoChangeRef = useRef(onGizmoChange);
  gizmoChangeRef.current = onGizmoChange;

  // ── Cena, câmera, renderer e laço de desenho (uma vez por abertura; libera tudo ao fechar) ─────────────────
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;
    const width = () => Math.max(1, container.clientWidth);
    const height = () => Math.max(1, container.clientHeight);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x131722);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width() / height(), 0.1, 100);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width(), height());
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    scene.add(new THREE.HemisphereLight(0xffffff, 0x223344, 0.85));
    const dirLight = new THREE.DirectionalLight(0xfff8ee, 1.4);
    dirLight.position.set(4, 8, 4);
    dirLight.castShadow = true;
    scene.add(dirLight);
    const rimLight = new THREE.DirectionalLight(0x4982ea, 0.6);
    rimLight.position.set(-4, 3, -4);
    scene.add(rimLight);

    const grid = new THREE.GridHelper(10, 20, 0x4982ea, 0x273042);
    scene.add(grid);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), new THREE.ShadowMaterial({ opacity: 0.35 }));
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    const human = buildSketchUpHumanFigure();
    humanRef.current = human;
    scene.add(human);
    const billboard = buildHeightBillboard();
    billboard.sprite.visible = false;
    billboardRef.current = billboard;
    scene.add(billboard.sprite);
    const modelGroup = new THREE.Group();
    modelGroupRef.current = modelGroup;
    scene.add(modelGroup);

    // Gizmo RGB (X vermelho, Y verde, Z azul): TransformControls do Three, só sobre o RASCUNHO da sessão
    const controls = new TransformControls(camera, renderer.domElement);
    controlsRef.current = controls;
    const gizmoHelper = controls.getHelper();
    scene.add(gizmoHelper);
    controls.addEventListener('objectChange', () => {
      const g = modelGroup;
      const zUp = draftRef.current.zUpFlipped ? -90 : 0;
      const sx = g.scale.x || 1;
      const axes = { x: 1, y: round4(g.scale.y / sx), z: round4(g.scale.z / sx) };
      const uniform = Math.abs(axes.y - 1) < 1e-3 && Math.abs(axes.z - 1) < 1e-3;
      gizmoChangeRef.current({
        position: { x: round4(g.position.x), y: round4(g.position.y), z: round4(g.position.z) },
        rotationDeg: { x: round4(THREE.MathUtils.radToDeg(g.rotation.x) - zUp), y: round4(THREE.MathUtils.radToDeg(g.rotation.y)), z: round4(THREE.MathUtils.radToDeg(g.rotation.z)) },
        scale: round4(sx),
        scaleAxes: uniform ? { x: 1, y: 1, z: 1 } : axes,
      });
    });

    // órbita simples (botão esquerdo gira, scroll aproxima)
    let down = false;
    let px = 0;
    let py = 0;
    let radius = 4.8;
    let theta = 0.6;
    let phi = 1.1;
    const placeCamera = () => {
      camera.position.set(radius * Math.sin(phi) * Math.sin(theta), 0.9 + radius * Math.cos(phi), radius * Math.sin(phi) * Math.cos(theta));
      camera.lookAt(0, 0.9, 0);
    };
    placeCamera();
    const onDown = (e: MouseEvent) => {
      if (controls.dragging || controls.axis) return; // arrastando o gizmo: a câmera não gira
      down = true;
      px = e.clientX;
      py = e.clientY;
    };
    const onMove = (e: MouseEvent) => {
      if (!down || controls.dragging) return;
      theta -= (e.clientX - px) * 0.008;
      phi = Math.max(0.15, Math.min(Math.PI / 2 - 0.05, phi - (e.clientY - py) * 0.008));
      px = e.clientX;
      py = e.clientY;
      placeCamera();
    };
    const onUp = () => {
      down = false;
    };
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      radius = Math.max(1.5, Math.min(12, radius + e.deltaY * 0.005));
      placeCamera();
    };
    const dom = renderer.domElement;
    dom.addEventListener('mousedown', onDown);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    dom.addEventListener('wheel', onWheel, { passive: false });

    let frame = 0;
    const animate = () => {
      frame = requestAnimationFrame(animate);
      // a caixa delimitadora acompanha o modelo (pivô e carga assíncrona mudam a posição depois dos efeitos do React)
      const tag = billboardRef.current;
      if (boxRef.current) {
        modelGroup.updateMatrixWorld(true);
        const box = boxRef.current.box.setFromObject(modelGroup);
        if (tag) {
          const h = box.max.y - box.min.y;
          tag.setText(t('importPreviewMsg.mHuman', { h: h.toFixed(2), value: (h / HUMAN_REFERENCE_HEIGHT_M).toFixed(2) }));
          tag.sprite.position.set((box.min.x + box.max.x) / 2, box.max.y + 0.25, (box.min.z + box.max.z) / 2);
          tag.sprite.visible = showRulerRef.current;
        }
      } else if (tag) {
        tag.sprite.visible = false;
      }
      renderer.render(scene, camera);
    };
    animate();

    const resize = () => {
      camera.aspect = width() / height();
      camera.updateProjectionMatrix();
      renderer.setSize(width(), height());
    };
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(resize) : null;
    observer?.observe(container);
    window.addEventListener('resize', resize);

    return () => {
      cancelAnimationFrame(frame);
      observer?.disconnect();
      window.removeEventListener('resize', resize);
      dom.removeEventListener('mousedown', onDown);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
      dom.removeEventListener('wheel', onWheel);
      // o modelo é do cache (liberado pela sessão); aqui só o que o preview criou
      if (boxRef.current) {
        boxRef.current.removeFromParent();
        boxRef.current.geometry.dispose();
        (boxRef.current.material as THREE.Material).dispose();
        boxRef.current = null;
      }
      controls.detach();
      controls.dispose();
      gizmoHelper.removeFromParent();
      billboard.sprite.removeFromParent();
      disposeTree(billboard.sprite);
      modelGroup.clear();
      disposeTree(human);
      grid.geometry.dispose();
      for (const m of Array.isArray(grid.material) ? grid.material : [grid.material]) m.dispose();
      floor.geometry.dispose();
      (floor.material as THREE.Material).dispose();
      renderer.dispose();
      renderer.forceContextLoss(); // abrir/fechar 10× não esgota os contextos WebGL
      renderer.domElement.remove();
      sceneRef.current = null;
      modelGroupRef.current = null;
      humanRef.current = null;
      controlsRef.current = null;
      billboardRef.current = null;
    };
  }, [t]);

  // ── Modelo (titular da `createModelObject`) ─────────────────────────────────────────────────────────────
  useEffect(() => {
    const group = modelGroupRef.current;
    if (!group) return;
    group.clear();
    if (model) group.add(model);
  }, [model]);

  // ── Transform do rascunho + caixa delimitadora ─────────────────────────────────────────────────────────
  useEffect(() => {
    const group = modelGroupRef.current;
    const scene = sceneRef.current;
    if (!group || !scene) return;
    const rot = effectiveRotationDeg(transform);
    group.scale.setScalar(transform.scale);
    group.rotation.set(toRad(rot.x), toRad(rot.y), toRad(rot.z));
    group.position.set(transform.position.x, transform.position.y, transform.position.z);

    if (boxRef.current) {
      boxRef.current.removeFromParent();
      boxRef.current.geometry.dispose();
      (boxRef.current.material as THREE.Material).dispose();
      boxRef.current = null;
    }
    if (status === 'ready' && model) {
      group.updateMatrixWorld(true);
      const box = new THREE.Box3().setFromObject(group);
      if (!box.isEmpty()) {
        boxRef.current = new THREE.Box3Helper(box, new THREE.Color(0xfacc15));
        scene.add(boxRef.current);
      }
    }
  }, [transform, model, revision, status]);

  // ── Referência humana e wireframe ─────────────────────────────────────────────────────────────────────
  useEffect(() => {
    const human = humanRef.current;
    if (!human) return;
    human.position.set(humanDistance, 0, 0);
    const mannequin = human.getObjectByName(MANNEQUIN_NAME);
    const ruler = human.getObjectByName(RULER_NAME);
    if (mannequin) mannequin.visible = showHuman;
    if (ruler) ruler.visible = showRuler;
  }, [showHuman, showRuler, humanDistance]);

  // gizmo: modo e anexo ao modelo (só quando há modelo carregado)
  useEffect(() => {
    const controls = controlsRef.current;
    const group = modelGroupRef.current;
    if (!controls || !group) return;
    controls.setMode(gizmoMode);
    if (status === 'ready' && model) controls.attach(group);
    else controls.detach();
  }, [gizmoMode, status, model, revision]);

  useEffect(() => {
    model?.traverse((child) => {
      const mesh = child as THREE.Mesh;
      if (!mesh.isMesh || mesh.userData.modelMarker) return;
      for (const m of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) (m as THREE.MeshStandardMaterial).wireframe = wireframe;
    });
  }, [wireframe, model, revision]);

  // AIS-36: overlay de esqueleto (só desenho do preview; nunca vai para a cena)
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene || !showSkeleton || status !== 'ready' || !model) return;
    model.updateMatrixWorld(true);
    const overlay = buildRigOverlay(model, skeletonBones ?? []);
    if (!overlay) return;
    scene.add(overlay);
    return () => {
      overlay.removeFromParent();
      disposeTree(overlay);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showSkeleton, status, model, revision, (skeletonBones ?? []).join('|')]);

  const heightLabel = stats?.heightM != null ? `${(stats.heightM * transform.scale).toFixed(2)}m` : '—';

  return (
    <div className="flex-1 relative bg-[#131722] flex flex-col">
      {/* 3D Canvas Mount Point */}
      <div ref={mountRef} className="flex-1 w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Estado vazio / carregando (decisão 14: nada fictício) */}
      {status === 'empty' && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="bg-[#1b2230]/95 border border-[#2b374d] rounded-xl px-6 py-5 text-center space-y-3 pointer-events-auto shadow-xl">
            <div className="text-sm font-bold text-white">{t('importPreview.loadA3dFile')}</div>
            <p className="text-[11px] text-[#8695ad] max-w-[260px]">
              {t('importPreview.chooseAGlbGltfObj')}
            </p>
            <button
              onClick={onPickFile}
              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold flex items-center gap-1.5 mx-auto"
            >
              <FolderOpen className="w-3.5 h-3.5" />
              <span>{t('shared.loadFile')}</span>
            </button>
          </div>
        </div>
      )}
      {status === 'loading' && (
        <div className="absolute top-3 right-3 bg-[#1b2230]/95 border border-[#2b374d] rounded-lg px-3 py-1.5 flex items-center gap-2 text-[11px] text-[#bac7db] shadow-xl" role="status">
          <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-400" />
          <span>{t('importPreview.loadingModel')}</span>
        </div>
      )}

      {/* Overlaid Viewport HUD Controls */}
      <div className="absolute top-3 left-3 flex flex-col gap-1.5 pointer-events-auto">
        <div className="bg-[#1b2230]/90 backdrop-blur border border-[#2b374d] rounded-lg p-2 flex flex-col gap-2 shadow-xl">
          <span className="text-[10px] font-bold text-[#7d8da6] uppercase tracking-wider">{t('importPreview.humanReferenceSketchupStyle')}</span>

          <label className="flex items-center gap-2 cursor-pointer text-[11px] text-white font-medium hover:text-blue-400 transition-colors">
            <input
              type="checkbox"
              checked={showHuman}
              onChange={(e) => onShowHuman(e.target.checked)}
              className="rounded bg-[#232c3d] border-[#384661] text-blue-500 focus:ring-0"
            />
            <span>{t('importPreview.humanFigure180m')}</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer text-[11px] text-white font-medium hover:text-blue-400 transition-colors">
            <input
              type="checkbox"
              checked={showRuler}
              onChange={(e) => onShowRuler(e.target.checked)}
              className="rounded bg-[#232c3d] border-[#384661] text-blue-500 focus:ring-0"
            />
            <span>{t('importPreview.ruler05mAndHeight')}</span>
          </label>

          {(showHuman || showRuler) && (
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] text-[#8695ad]">
                <span>{t('importPreview.figureDistance')}</span>
                <span className="font-mono text-white">{humanDistance}m</span>
              </div>
              <input
                type="range"
                min={0.5}
                max={3.0}
                step={0.1}
                value={humanDistance}
                onChange={(e) => onHumanDistance(parseFloat(e.target.value))}
                className="w-full accent-blue-500 h-1 bg-[#2b374d] rounded"
              />
            </div>
          )}
        </div>

        <div className="bg-[#1b2230]/90 backdrop-blur border border-[#2b374d] rounded-lg px-2.5 py-1.5 flex items-center gap-2 text-[10px] text-[#93a2ba] shadow-lg">
          <Eye className="w-3 h-3 text-blue-400" />
          <span>{t('importPreview.rotateLeftButtonZoomScroll')}</span>
        </div>
      </div>

      {/* Viewport Floating Quick Action Bar */}
      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-1.5 bg-[#1b2230]/90 backdrop-blur border border-[#2b374d] rounded-lg px-3 py-1.5 pointer-events-auto shadow-xl">
          <button
            onClick={onCenterToOrigin}
            className="px-2 py-1 rounded bg-[#252f42] hover:bg-blue-600 hover:text-white text-[#bac7db] text-[11px] font-medium transition-colors flex items-center gap-1"
          >
            <Crosshair className="w-3 h-3 text-blue-400" />
            <span>{t('importPreview.centerOrigin')}</span>
          </button>

          <button
            onClick={onNormalizeToHuman}
            disabled={!stats?.heightM}
            title={stats?.heightM ? undefined : t('sharedMsg.loadAModelToCalibrate')}
            className="px-2 py-1 rounded bg-[#252f42] hover:bg-emerald-600 hover:text-white text-[#bac7db] text-[11px] font-medium transition-colors flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <User className="w-3 h-3 text-emerald-400" />
            <span>{t('importPreview.idealSize180m')}</span>
          </button>

          <button
            onClick={onFlipZUp}
            className={`px-2 py-1 rounded text-[11px] font-medium transition-colors flex items-center gap-1 ${
              transform.zUpFlipped ? 'bg-amber-600 text-white' : 'bg-[#252f42] hover:bg-[#313d54] text-[#bac7db]'
            }`}
            title={t('importPreview.invertTheZUpOrientation')}
          >
            <Compass className="w-3 h-3 text-amber-400" />
            <span>{transform.zUpFlipped ? t('importPreviewMsg.zUpBlender') : t('importPreviewMsg.yUpDefault')}</span>
          </button>

          <button
            onClick={onToggleWireframe}
            className={`px-2 py-1 rounded text-[11px] font-medium transition-colors flex items-center gap-1 ${
              wireframe ? 'bg-purple-600 text-white' : 'bg-[#252f42] hover:bg-[#313d54] text-[#bac7db]'
            }`}
          >
            <Layers className="w-3 h-3 text-purple-400" />
            <span>{t('shared.wireframe')}</span>
          </button>
        </div>

        {/* Model Stats Pill (dados REAIS do arquivo carregado) */}
        <div className="bg-[#1b2230]/90 backdrop-blur border border-[#2b374d] rounded-lg px-3 py-1.5 pointer-events-auto shadow-xl flex items-center gap-3 text-[11px]">
          <div className="flex items-center gap-1 text-[#8494ab]">
            <span>{t('shared.vertices')}</span>
            <span className="font-mono text-white">{stats ? stats.vertices : '—'}</span>
          </div>
          <div className="w-px h-3 bg-[#2d3a52]" />
          <div className="flex items-center gap-1 text-[#8494ab]">
            <span>{t('importPreview.polygons')}</span>
            <span className="font-mono text-white">{stats ? stats.triangles : '—'}</span>
          </div>
          <div className="w-px h-3 bg-[#2d3a52]" />
          <div className="flex items-center gap-1 text-[#8494ab]">
            <span>{t('importPreview.height')}</span>
            <span className="font-mono text-emerald-400">{heightLabel}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
