import React from 'react';
import { useTranslation } from '../../../core/i18n/I18nContext';

/** Peças comuns das abas 2 a 5 do importador (AIS-33). */
export const HEADER = 'flex items-center justify-between border-b border-[#252f42] pb-2';
export const NOTE = 'bg-[#1b2230] p-3 rounded-lg border border-[#273347] text-[11px] text-[#8695ad] leading-relaxed';

export const NoModel: React.FC = () => {
  const { t } = useTranslation();
  return <div className={NOTE}>{t('tabParts.loadA3dFileTo')}</div>;
};
