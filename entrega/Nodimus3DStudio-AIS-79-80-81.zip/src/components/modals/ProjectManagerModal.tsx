import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useEditor } from '../../core/EditorContext';
import { ProjectStorage } from '../../core/projectStorage';
import { globalDocumentManager } from '../../core/documents/DocumentManager';
import { sanitizeFolderName } from '../../core/pathSafety';
import { globalAuthoringModel } from '../../core/authoring';
import { TauriBridge } from '../../core/tauriBridge';
import { PROJECT_TEMPLATES, getProjectTemplate } from '../../core/projectTemplates';
import { importProjectFromFolder } from '../../core/projectFolder';
import { useTranslation } from '../../core/i18n/I18nContext';
import { tk, type TextRef } from '../../core/i18n/index';
import {
  DELETE_PROJECT_NOTICE,
  PROJECT_NAME_MAX,
  canDeleteProject,
  deleteConfirmationMatches,
  deleteStoredProject,
  duplicateStoredProject,
  renameStoredProject,
  sortProjectsByRecent,
  uniqueCopyName,
  validateProjectName,
} from '../../core/projectOps';
import {
  FolderOpen,
  Plus,
  Trash2,
  Download,
  Upload,
  Play,
  Box,
  HardDrive,
  X,
  Copy,
  Pencil,
  LayoutTemplate,
  AlertTriangle,
} from 'lucide-react';

/** AIS-30c: no desktop excluir apaga a PASTA do projeto (permanente; o Tauri não manda para a Lixeira). */
const DELETE_FOLDER_NOTICE: TextRef = tk('moduleUi.deleteFolderNotice');

type Dialog =
  | { kind: 'new' }
  | { kind: 'clone' }
  | { kind: 'duplicate'; id: string }
  | { kind: 'delete'; id: string };

const TEMPLATE_ICON: Record<string, React.ReactNode> = {
  '3d': <Box className="w-5 h-5 text-blue-400 shrink-0" />,
  empty: <HardDrive className="w-5 h-5 text-slate-400 shrink-0" />,
};

export const ProjectManagerModal: React.FC = () => {
  const { t } = useTranslation();
  const { t: tr } = useTranslation();
  const {
    isProjectManagerOpen,
    setIsProjectManagerOpen,
    switchProject,
    project: activeProject,
    addLog,
  } = useEditor();

  const [projectsList, setProjectsList] = useState(() => ProjectStorage.getProjectsList());
  const [selectedProjectId, setSelectedProjectId] = useState<string>(activeProject.id);
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Formulário Novo Projeto / Clonar Exemplo / Duplicar
  const [formName, setFormName] = useState('Nodimus 3D Adventure');
  const [formPath, setFormPath] = useState('~/Projects/Nodimus3D');
  const [formTemplate, setFormTemplate] = useState<string>('3d');
  const [formError, setFormError] = useState<string | null>(null);

  // Renomear inline
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [renameError, setRenameError] = useState<string | null>(null);

  // Excluir
  const [deleteTyped, setDeleteTyped] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const capabilities = TauriBridge.getCapabilities();
  // AIS-30c: no desktop os projetos são PASTAS reais; abrir lê a pasta inteira (com progresso e Cancelar)
  const isDisk = ProjectStorage.isDisk();
  const [busy, setBusy] = useState<{ message: string } | null>(null);
  const abortRef = useRef<{ aborted: boolean }>({ aborted: false });
  const [workspaceRoot, setWorkspaceRoot] = useState<string | null>(() => ProjectStorage.workspaceRoot());

  useEffect(
    () =>
      ProjectStorage.onOpenProgress((done, total, path) => {
        setBusy((b) => (b ? { message: total > 0 ? t('projectManagerModalMsg.openingProject2', { done, total, value: path ? ` · ${path}` : '' }) : t('projectManagerModalMsg.openingProject') } : b));
      }),
    [t],
  );

  /** Garante o projeto lido por inteiro (desktop: lê a pasta; web: já está no armazenamento). */
  const ensureLoaded = async (id: string) => {
    abortRef.current = { aborted: false };
    setBusy({ message: t('projectManagerModalMsg.openingProject') });
    try {
      return await ProjectStorage.openProject(id, abortRef.current);
    } finally {
      setBusy(null);
    }
  };

  const refresh = () => setProjectsList(ProjectStorage.getProjectsList());

  useEffect(() => {
    refresh();
    setError(null);
    setDialog(null);
    setRenamingId(null);
  }, [isProjectManagerOpen]);

  const sortedProjects = useMemo(() => sortProjectsByRecent(projectsList), [projectsList]);

  if (!isProjectManagerOpen) return null;

  const closeDialog = () => {
    setDialog(null);
    setFormError(null);
    setDeleteTyped('');
  };

  const handleOpenSelected = async () => {
    setError(null);
    try {
      const proj = await ensureLoaded(selectedProjectId);
      if (!proj) return;
      await ProjectStorage.flush(); // o projeto anterior termina de gravar antes da troca
      switchProject(proj);
      setIsProjectManagerOpen(false);
    } catch (e: any) {
      setError(e?.name === 'OpenCancelledError' ? t('projectManagerModalMsg.openingCancelled') : t('projectManagerModalMsg.couldNotOpenTheProject', { value: e?.message || t('projectManagerModalMsgNow.unknownError') }));
    }
  };

  // ── Renomear (inline) ────────────────────────────────────────────────────────────────────────────
  const startRename = (id: string, name: string) => {
    setRenamingId(id);
    setRenameValue(name);
    setRenameError(null);
  };

  const commitRename = async (id: string) => {
    const current = projectsList.find((p) => p.id === id);
    if (!current) return setRenamingId(null);
    if (renameValue.trim() === current.name) return setRenamingId(null);
    const isActive = id === activeProject.id;
    if (!isActive) await ensureLoaded(id);
    const result = renameStoredProject(id, renameValue, isActive ? globalAuthoringModel.getProject() : undefined);
    if (!result.ok) {
      setRenameError(result.error);
      return;
    }
    // o projeto aberto: a projeção do editor (título) acompanha pelo AuthoringModel
    if (isActive) globalAuthoringModel.setProject(result.value);
    setRenamingId(null);
    setRenameError(null);
    refresh();
    addLog('log', t('projectManagerModalMsg.projectRenamedTo', { name: result.value.name }));
  };

  // ── Novo Projeto / Clonar Exemplo ────────────────────────────────────────────────────────────────
  const openNewDialog = (kind: 'new' | 'clone') => {
    setError(null);
    setFormError(null);
    setFormName(kind === 'clone' ? 'Meu Exemplo' : 'Nodimus 3D Adventure');
    setFormPath('~/Projects/Nodimus3D');
    setFormTemplate('3d');
    setDialog({ kind });
  };

  const pickFolderInto = async (setter: (path: string) => void) => {
    try {
      const folder = await TauriBridge.openProjectFolderDialog();
      if (folder) setter(folder);
    } catch (e: any) {
      setFormError(t('projectManagerModalMsg.couldNotOpenTheFolder', { value: e?.message || t('projectManagerModalMsgNow.unknownError') }));
    }
  };

  const handleCreateProject = () => {
    const template = getProjectTemplate(formTemplate);
    if (!template || !template.available) return;
    const nameError = validateProjectName(formName, projectsList);
    if (nameError) return setFormError(nameError);
    const newProj = template.build(formName.trim(), isDisk ? '' : formPath.trim());
    if (!ProjectStorage.saveProject(newProj)) return setFormError(t('projectManagerModalMsg.couldNotSaveTheProject'));
    refresh();
    switchProject(ProjectStorage.loadProject(newProj.id) ?? newProj); // desktop: o espelho já traz a pasta real em `location`
    closeDialog();
    setIsProjectManagerOpen(false);
  };

  // ── Duplicar ─────────────────────────────────────────────────────────────────────────────────────
  const openDuplicate = (id: string) => {
    const p = projectsList.find((x) => x.id === id);
    if (!p) return;
    setError(null);
    setFormError(null);
    setFormName(uniqueCopyName(p.name, projectsList.map((x) => x.name)));
    setFormPath(p.location);
    setDialog({ kind: 'duplicate', id });
  };

  const handleDuplicate = async () => {
    if (dialog?.kind !== 'duplicate') return;
    if (dialog.id !== activeProject.id) await ensureLoaded(dialog.id);
    const result = duplicateStoredProject(dialog.id, { name: formName, location: isDisk ? '' : formPath });
    if (!result.ok) return setFormError(result.error);
    refresh();
    setSelectedProjectId(result.value.id);
    closeDialog();
    addLog('log', t('projectManagerModalMsg.projectDuplicatedAs', { name: result.value.name }));
  };

  // ── Excluir ──────────────────────────────────────────────────────────────────────────────────────
  const openDelete = (id: string) => {
    setError(null);
    setDeleteTyped('');
    setDialog({ kind: 'delete', id });
  };

  const handleDelete = () => {
    if (dialog?.kind !== 'delete') return;
    const target = projectsList.find((p) => p.id === dialog.id);
    if (!target || !deleteConfirmationMatches(deleteTyped, target.name)) return;
    const result = deleteStoredProject(dialog.id, activeProject.id);
    if (!result.ok) return setError(t('projectManagerModalMsg.couldNotDelete', { error: result.error }));
    const remaining = ProjectStorage.getProjectsList();
    setProjectsList(remaining);
    if (selectedProjectId === dialog.id) setSelectedProjectId(activeProject.id);
    closeDialog();
    addLog('log', t('projectManagerModalMsg.projectRemovedFromTheEditor', { name: target.name }));
  };

  // ── Exportar / Importar / Abrir Pasta ────────────────────────────────────────────────────────────
  const handleExport = async (id: string) => {
    // exporta do armazenamento: funciona para qualquer projeto, não só o aberto
    const proj = id === activeProject.id ? globalAuthoringModel.getProject() : await ensureLoaded(id);
    if (!proj) return;
    try {
      await ProjectStorage.exportProjectAsNodimusFile(proj);
      addLog('log', t('projectManagerModalMsg.exportedProjectNodimus', { name: proj.name }));
    } catch (e: any) {
      addLog('error', t('projectManagerModalMsg.failedToExportProject', { value: e?.message || t('projectManagerModalMsgNow.unknownError2') }));
    }
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (!file) return;
    setError(null);

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const content = reader.result as string;
        const imported = ProjectStorage.importProjectFromNodimus(content);
        refresh();
        switchProject(imported);
        setIsProjectManagerOpen(false);
        addLog('log', t('projectManagerModalMsg.importedProjectNodimus', { name: imported.name }));
      } catch (err: any) {
        setError(t('projectManagerModalMsg.failedToImportTheFile', { value: String(err?.message || t('projectManagerModalMsgNow.invalidFormat')).replace(/^\[ProjectStorage\]\s*/, '') }));
      }
    };
    reader.onerror = () => setError(t('projectManagerModalMsg.failedToReadTheSelected'));
    reader.readAsText(file);
  };

  const handleOpenFolder = async () => {
    setError(null);
    try {
      const folder = await TauriBridge.openProjectFolderDialog();
      if (!folder) return;
      if (isDisk) {
        // AIS-30c: abre a pasta NO LUGAR (vínculo vivo); nada é copiado para o localStorage
        abortRef.current = { aborted: false };
        setBusy({ message: t('projectManagerModalMsg.openingProject') });
        try {
          const opened = await ProjectStorage.openFolderInPlace(folder, abortRef.current);
          if ('error' in opened) return setError(opened.error);
          await ProjectStorage.flush();
          refresh();
          switchProject(opened.project);
          setIsProjectManagerOpen(false);
          addLog('log', t('projectManagerModalMsg.projectOpenedFrom', { name: opened.project.name, folder }));
        } finally {
          setBusy(null);
        }
        return;
      }
      const result = await importProjectFromFolder(folder, TauriBridge);
      if (!result.ok) return setError(result.error);
      if (!ProjectStorage.saveProject(result.project)) return setError(t('projectManagerModalMsg.couldNotSaveTheImported'));
      refresh();
      switchProject(result.project);
      setIsProjectManagerOpen(false);
      addLog('log', t('projectManagerModalMsg.folderImportedAsProject', { name: result.project.name, value: result.skipped.length ? t('projectManagerModalMsgNow.unsupportedFileSIgnored', { count: result.skipped.length }) : '' }));
    } catch (e: any) {
      setError(t('projectManagerModalMsg.failedToOpenTheFolder', { value: e?.message || t('projectManagerModalMsgNow.unknownError') }));
    }
  };

  const handleChangeWorkspace = async (reset: boolean) => {
    setError(null);
    if (globalDocumentManager.getDirtyDocuments().length > 0) return setError(t('projectManagerModalMsg.thereAreUnsavedChangesSave'));
    try {
      const folder = reset ? null : await TauriBridge.openProjectFolderDialog();
      if (!reset && !folder) return;
      await ProjectStorage.flush();
      ProjectStorage.setWorkspaceRootPreference(folder);
      addLog('log', reset ? t('projectManagerModalMsg.projectsFolderRestoredToThe') : t('projectManagerModalMsg.projectsFolderReloadingTheEditor', { folder }));
      window.location.reload();
    } catch (e: any) {
      setError(t('projectManagerModalMsg.couldNotChangeTheProjects', { value: e?.message || t('projectManagerModalMsgNow.unknownError') }));
    }
  };

  const deleteTarget = dialog?.kind === 'delete' ? projectsList.find((p) => p.id === dialog.id) : undefined;

  const renderTemplatePicker = (all: boolean) => {
    const templates = all ? PROJECT_TEMPLATES : PROJECT_TEMPLATES.filter((t) => t.available);
    return (
      <div className={all ? 'grid grid-cols-1 gap-2' : 'grid grid-cols-2 gap-2'}>
        {templates.map((t) => (
          <button
            key={t.id}
            type="button"
            disabled={!t.available}
            title={t.available ? undefined : t.unavailableReason}
            onClick={() => setFormTemplate(t.id)}
            className={`p-2.5 rounded border text-left flex items-center gap-2.5 ${
              !t.available
                ? 'border-[#2c3345] bg-[#141820] text-[#5d6a80] opacity-60 cursor-not-allowed'
                : formTemplate === t.id
                  ? 'border-[#4982ea] bg-[#4982ea]/15 text-white'
                  : 'border-[#2c3345] bg-[#141820] text-[#8b97a8]'
            }`}
          >
            {TEMPLATE_ICON[t.id] ?? <LayoutTemplate className="w-5 h-5 text-slate-500 shrink-0" />}
            <div>
              <div className="font-semibold text-xs text-white">{t.label}</div>
              <div className="text-[10px] text-[#8b97a8]">{t.available ? t.description : tr('sharedMsg.comingSoon')}</div>
            </div>
          </button>
        ))}
      </div>
    );
  };

  const renderLocationField = () =>
    isDisk ? (
      <div>
        <label className="text-[#8b97a8] text-[11px] block mb-1 font-medium">{tr('projectManagerModal.projectFolder')}</label>
        <div className="bg-[#141820] text-[#93a1b8] font-mono px-3 py-1.5 rounded border border-[#2c3345] text-[11px] break-all" data-testid="project-folder-preview">
          {workspaceRoot ?? ''}/{formName.trim() ? sanitizeFolderName(formName) : '…'}
        </div>
      </div>
    ) : (
    <div>
      <label className="text-[#8b97a8] text-[11px] block mb-1 font-medium">{tr('projectManagerModal.projectPath')}</label>
      <div className="flex items-center gap-2">
        <input
          type="text"
          value={formPath}
          onChange={(e) => setFormPath(e.target.value)}
          className="flex-1 bg-[#141820] text-white font-mono px-3 py-1.5 rounded border border-[#2c3345] outline-none text-[11px]"
        />
        {capabilities.hasNativeDialog && (
          <button
            type="button"
            onClick={() => pickFolderInto(setFormPath)}
            className="px-2.5 py-1.5 rounded bg-[#272e3d] hover:bg-[#323b4e] text-[#dfe4ec] border border-[#2c3345]"
          >
            {tr('projectManagerModal.choose')}
          </button>
        )}
      </div>
    </div>
    );

  const renderNameField = () => (
    <div>
      <label className="text-[#8b97a8] text-[11px] block mb-1 font-medium">{tr('shared.projectName')}</label>
      <input
        type="text"
        value={formName}
        maxLength={PROJECT_NAME_MAX}
        onChange={(e) => {
          setFormName(e.target.value);
          setFormError(null);
        }}
        className="w-full bg-[#141820] text-white px-3 py-1.5 rounded border border-[#2c3345] outline-none"
        placeholder={tr('projectManagerModal.enterProjectName')}
      />
    </div>
  );

  const renderFormError = () =>
    formError ? (
      <div role="alert" className="text-[11px] text-rose-400 bg-rose-500/10 border border-rose-500/30 rounded px-2.5 py-1.5">
        {formError}
      </div>
    ) : null;

  const renderFormFooter = (confirmLabel: string, onConfirm: () => void, disabled = false) => (
    <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#2c3345]">
      <button type="button" onClick={closeDialog} className="px-3 py-1.5 rounded hover:bg-[#2c3345] text-[#b3bed0]">
        {tr('shared.cancel')}
      </button>
      <button
        type="button"
        onClick={onConfirm}
        disabled={disabled}
        className="bg-[#4982ea] hover:bg-[#3d72d6] disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-1.5 rounded font-medium transition-colors"
      >
        {confirmLabel}
      </button>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none">
      <div className="w-[780px] h-[520px] bg-[#1e232f] border border-[#3b475f] rounded-lg shadow-2xl flex flex-col overflow-hidden text-xs">
        {/* Top Header */}
        <div className="h-12 bg-[#171b24] border-b border-[#2c3345] px-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded bg-[#4982ea] flex items-center justify-center font-bold text-xs text-white">
              N
            </div>
            <span className="font-bold text-sm text-white">{tr('projectManagerModal.nodimusProjectManager')}</span>
          </div>

          <button
            onClick={() => setIsProjectManagerOpen(false)}
            className="p-1 text-[#8b97a8] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Toolbar */}
        <div className="h-10 bg-[#1a1e29] border-b border-[#2c3345] px-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => openNewDialog('new')}
              className="flex items-center gap-1.5 bg-[#4982ea] hover:bg-[#3d72d6] text-white px-3 py-1 rounded font-medium transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{tr('projectManagerModal.newProject')}</span>
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 bg-[#272e3d] hover:bg-[#323b4e] text-[#dfe4ec] px-3 py-1 rounded border border-[#2c3345] transition-colors"
            >
              <Upload className="w-3.5 h-3.5 text-blue-400" />
              <span>{t('dialogs.projectManager.import')}</span>
            </button>

            <button
              onClick={() => openNewDialog('clone')}
              className="flex items-center gap-1.5 bg-[#272e3d] hover:bg-[#323b4e] text-[#dfe4ec] px-3 py-1 rounded border border-[#2c3345] transition-colors"
              title={tr('projectManagerModal.createAProjectFromAn')}
            >
              <LayoutTemplate className="w-3.5 h-3.5 text-blue-400" />
              <span>{tr('projectManagerModal.cloneExample')}</span>
            </button>

            <button
              onClick={handleOpenFolder}
              disabled={!capabilities.hasNativeFS}
              title={capabilities.hasNativeFS ? (isDisk ? t('projectManagerModalMsg.openAProjectFolderWith') : t('projectManagerModalMsg.importAProjectFolderWith')) : t('projectManagerModalMsg.comingSoonRequiresTheDesktop')}
              className="flex items-center gap-1.5 bg-[#272e3d] hover:bg-[#323b4e] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-[#272e3d] text-[#dfe4ec] px-3 py-1 rounded border border-[#2c3345] transition-colors"
            >
              <FolderOpen className="w-3.5 h-3.5 text-blue-400" />
              <span>{tr('projectManagerModal.openFolder')}</span>
            </button>

            <input
              ref={fileInputRef}
              type="file"
              accept=".nodimus,.nodimus.json,.json"
              className="hidden"
              onChange={handleImportFile}
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleOpenSelected}
              disabled={!selectedProjectId}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white px-4 py-1 rounded font-medium transition-colors"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{tr('projectManagerModal.openProject')}</span>
            </button>
          </div>
        </div>

        {isDisk && (
          <div className="px-4 py-1.5 bg-[#171b24] border-b border-[#2c3345] flex items-center gap-2 text-[11px]" data-testid="workspace-bar">
            <HardDrive className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span className="text-[#8b97a8] shrink-0">{tr('projectManagerModal.projectsFolder')}</span>
            <span className="font-mono text-[#dfe4ec] truncate" title={workspaceRoot ?? ''}>{workspaceRoot}</span>
            <button onClick={() => handleChangeWorkspace(false)} className="ml-auto shrink-0 px-2 py-0.5 rounded bg-[#272e3d] hover:bg-[#323b4e] border border-[#2c3345] text-[#dfe4ec]">{tr('projectManagerModal.change')}</button>
            <button onClick={() => handleChangeWorkspace(true)} className="shrink-0 px-2 py-0.5 rounded bg-[#272e3d] hover:bg-[#323b4e] border border-[#2c3345] text-[#dfe4ec]" title={tr('projectManagerModal.backToDocumentsNodimus3dstudio')}>{tr('projectManagerModal.default')}</button>
          </div>
        )}

        {busy && (
          <div role="status" className="px-4 py-1.5 bg-[#1a2233] border-b border-[#2c3345] flex items-center gap-2 text-[11px] text-[#93a1b8]" data-testid="open-progress">
            <span className="truncate flex-1">{busy.message}</span>
            <button onClick={() => (abortRef.current.aborted = true)} className="px-2 py-0.5 rounded bg-[#272e3d] hover:bg-[#323b4e] border border-[#2c3345] text-[#dfe4ec]">{tr('shared.cancel')}</button>
          </div>
        )}

        {/* Main Content Area */}
        <div className="flex-1 p-4 overflow-y-auto bg-[#141822]">
          {error && (
            <div role="alert" className="mb-3 flex items-start gap-2 text-[11px] text-rose-300 bg-rose-500/10 border border-rose-500/30 rounded px-3 py-2">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              <span className="flex-1 whitespace-pre-wrap break-words">{error}</span>
              <button onClick={() => setError(null)} className="text-rose-300 hover:text-white" aria-label={tr('shared.closeNotice')}>
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {dialog?.kind === 'new' || dialog?.kind === 'clone' ? (
            /* New Project / Clonar Exemplo Form */
            <div className="max-w-lg mx-auto bg-[#1c2230] p-5 rounded-lg border border-[#2c3345] space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#2c3345] pb-2">
                {dialog.kind === 'new' ? (
                  <>
                    <Plus className="w-4 h-4 text-[#4982ea]" /> {tr('projectManagerModal.createNewProject')}
                  </>
                ) : (
                  <>
                    <LayoutTemplate className="w-4 h-4 text-[#4982ea]" /> {tr('projectManagerModal.cloneExample')}
                  </>
                )}
              </h3>

              <div className="space-y-3">
                {renderNameField()}
                {renderLocationField()}

                <div>
                  <label className="text-[#8b97a8] text-[11px] block mb-1.5 font-medium">
                    {dialog.kind === 'new' ? t('projectManagerModalMsg.starterTemplate') : t('projectManagerModalMsgTwo.example')}
                  </label>
                  {renderTemplatePicker(dialog.kind === 'clone')}
                </div>

                <div>
                  <label className="text-[#8b97a8] text-[11px] block mb-1 font-medium">
                    {tr('shared.graphicsEngine')}
                  </label>
                  <div className="p-2 bg-[#141820] rounded border border-[#2c3345] text-white font-mono text-xs flex items-center justify-between">
                    <span>{tr('shared.threeJsWebgl')}</span>
                    <span className="text-[10px] text-emerald-400 font-sans font-medium px-2 py-0.5 rounded bg-emerald-500/10">{tr('projectManagerModal.default')}</span>
                  </div>
                </div>
              </div>

              {renderFormError()}
              {renderFormFooter(dialog.kind === 'new' ? tr('leftovers.createAndOpen') : tr('leftovers.cloneAndOpen'), handleCreateProject)}
            </div>
          ) : dialog?.kind === 'duplicate' ? (
            <div className="max-w-lg mx-auto bg-[#1c2230] p-5 rounded-lg border border-[#2c3345] space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#2c3345] pb-2">
                <Copy className="w-4 h-4 text-[#4982ea]" /> {tr('projectManagerModal.duplicateProject2')}
              </h3>
              <div className="space-y-3">
                {renderNameField()}
                {renderLocationField()}
              </div>
              {renderFormError()}
              {renderFormFooter(tr('leftovers.duplicate'), handleDuplicate)}
            </div>
          ) : dialog?.kind === 'delete' && deleteTarget ? (
            <div className="max-w-lg mx-auto bg-[#1c2230] p-5 rounded-lg border border-rose-500/40 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#2c3345] pb-2">
                <Trash2 className="w-4 h-4 text-rose-400" /> {tr('projectManagerModal.deleteProject')}
              </h3>
              <p className="text-[#b3bed0] leading-relaxed">
                {tr('projectManagerModal.toDelete')} <span className="font-semibold text-white">{deleteTarget.name}</span>{tr('projectManagerModal.typeTheExactProjectName')}
              </p>
              <input
                autoFocus
                type="text"
                value={deleteTyped}
                onChange={(e) => setDeleteTyped(e.target.value)}
                aria-label={tr('projectManagerModal.typeTheProjectNameTo')}
                className="w-full bg-[#141820] text-white px-3 py-1.5 rounded border border-[#2c3345] outline-none"
                placeholder={deleteTarget.name}
              />
              <p className="text-[11px] text-[#8b97a8] leading-relaxed" title={isDisk ? tr(DELETE_FOLDER_NOTICE.key) : DELETE_PROJECT_NOTICE}>
                {isDisk ? tr(DELETE_FOLDER_NOTICE.key) : DELETE_PROJECT_NOTICE}
              </p>
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#2c3345]">
                <button type="button" onClick={closeDialog} className="px-3 py-1.5 rounded hover:bg-[#2c3345] text-[#b3bed0]">
                  {tr('shared.cancel')}
                </button>
                <button
                  type="button"
                  onClick={handleDelete}
                  disabled={!deleteConfirmationMatches(deleteTyped, deleteTarget.name)}
                  className="bg-rose-600 hover:bg-rose-500 disabled:opacity-40 disabled:cursor-not-allowed text-white px-4 py-1.5 rounded font-medium transition-colors"
                >
                  {tr('shared.delete')}
                </button>
              </div>
            </div>
          ) : (
            /* Projects Grid / Table */
            <div className="space-y-2">
              {sortedProjects.map((p) => {
                const isSelected = selectedProjectId === p.id;
                const isCurrent = activeProject.id === p.id;
                const isRenaming = renamingId === p.id;
                const deleteGuard = canDeleteProject(p.id, activeProject.id);

                return (
                  <div
                    key={p.id}
                    onClick={() => setSelectedProjectId(p.id)}
                    onDoubleClick={() => !isRenaming && handleOpenSelected()}
                    className={`p-3 rounded-lg border cursor-pointer flex items-center justify-between transition-colors ${
                      isSelected
                        ? 'bg-[#272e3e] border-[#4982ea]'
                        : 'bg-[#181c24] border-[#2c3345] hover:border-[#3b475f]'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-9 rounded bg-[#2c3345] flex items-center justify-center font-bold text-sm text-[#4982ea] shrink-0">
                        {p.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          {isRenaming ? (
                            <input
                              autoFocus
                              value={renameValue}
                              maxLength={PROJECT_NAME_MAX}
                              aria-label={tr('projectManagerModal.newProjectName')}
                              aria-invalid={!!renameError}
                              title={renameError ?? undefined}
                              spellCheck={false}
                              onFocus={(e) => e.currentTarget.select()}
                              onChange={(e) => {
                                setRenameValue(e.target.value);
                                setRenameError(null);
                              }}
                              onClick={(e) => e.stopPropagation()}
                              onDoubleClick={(e) => e.stopPropagation()}
                              onBlur={() => (renameError ? setRenamingId(null) : commitRename(p.id))}
                              onKeyDown={(e) => {
                                e.stopPropagation();
                                if (e.key === 'Enter') commitRename(p.id);
                                else if (e.key === 'Escape') {
                                  setRenamingId(null);
                                  setRenameError(null);
                                }
                              }}
                              className={`bg-[#141820] text-white text-xs px-1.5 py-0.5 rounded border outline-none ${renameError ? 'border-rose-500' : 'border-[#4982ea]'}`}
                            />
                          ) : (
                            <span className="font-semibold text-white text-xs truncate">{p.name}</span>
                          )}
                          {isCurrent && (
                            <span className="bg-emerald-500/20 text-emerald-400 text-[10px] px-1.5 py-0.5 rounded font-medium">
                              {tr('shared.active')}
                            </span>
                          )}
                          <span className="bg-[#2c3345] text-[#8b97a8] text-[10px] px-1.5 py-0.5 rounded font-mono">
                            {tr('projectManagerModal.threeJs')}
                          </span>
                        </div>
                        {isRenaming && renameError && (
                          <div role="alert" className="text-[10px] text-rose-400 mt-0.5">{renameError}</div>
                        )}
                        <div className="text-[11px] text-[#8b97a8] font-mono mt-0.5 truncate">
                          {p.location}
                        </div>
                        <div className="text-[10px] text-[#6c788d] mt-0.5">
                          {p.updatedAt && !Number.isNaN(Date.parse(p.updatedAt)) ? new Date(p.updatedAt).toLocaleString() : '—'}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          startRename(p.id, p.name);
                        }}
                        className="p-1.5 rounded hover:bg-[#343e52] text-[#8b97a8] hover:text-white"
                        title={tr('projectManagerModal.renameProject')}
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          openDuplicate(p.id);
                        }}
                        className="p-1.5 rounded hover:bg-[#343e52] text-[#8b97a8] hover:text-white"
                        title={tr('projectManagerModal.duplicateProject')}
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleExport(p.id);
                        }}
                        className="p-1.5 rounded hover:bg-[#343e52] text-[#8b97a8] hover:text-white"
                        title={tr('projectManagerModal.exportProjectNodimus')}
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (deleteGuard.ok) openDelete(p.id);
                        }}
                        disabled={!deleteGuard.ok}
                        className="p-1.5 rounded hover:bg-rose-900/30 text-[#8b97a8] hover:text-rose-400 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-[#8b97a8]"
                        title={deleteGuard.ok ? t('projectManagerModalMsg.deleteProject') : deleteGuard.reason}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
