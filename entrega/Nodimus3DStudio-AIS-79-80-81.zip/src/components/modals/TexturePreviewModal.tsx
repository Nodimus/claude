import React, { useState, useEffect } from 'react';
import { useEditor } from '../../core/EditorContext';
import {
  MaterialProperties,
  DEFAULT_MATERIAL_PROPERTIES,
  MATERIAL_PRESETS,
  PreviewMeshShape,
  PreviewLightingEnvironment,
  ShadingModel,
  TexturePatternType,
  MaterialPreset,
} from '../../types/material';
import { TexturePreviewCanvas } from './TexturePreviewCanvas';
import { globalResourceRegistry, resourcePathOf } from '../../core/resources/global';
import { materialForRender, nodeMaterialOverride, textureRefFromPath, toMaterialOverride, TEXTURES_DIR } from '../../core/material/nodeMaterial';
import type { ResourceRef } from '../../types/node';
import { useTranslation } from '../../core/i18n/I18nContext';
import {
  X,
  Palette,
  Sliders,
  Layers,
  Sparkles,
  Save,
  Check,
  RotateCcw,
  Download,
  Upload,
  Box,
  Sun,
  Eye,
  Info,
} from 'lucide-react';

export const TexturePreviewModal: React.FC = () => {
  const { t } = useTranslation();
  const {
    isTexturePreviewOpen,
    setIsTexturePreviewOpen,
    selectedNode,
    project,
    changeNodeProperty,
    createFile,
    addLog,
  } = useEditor();

  const [activeTab, setActiveTab] = useState<'properties' | 'textures' | 'presets'>('properties');
  const [activeViewTab, setActiveViewTab] = useState<'3d' | '2d_albedo' | '2d_normal'>('3d');
  const [meshShape, setMeshShape] = useState<PreviewMeshShape>('Sphere');
  const [lighting, setLighting] = useState<PreviewLightingEnvironment>('StudioNeutral');

  // Working material properties
  const [properties, setProperties] = useState<MaterialProperties>(DEFAULT_MATERIAL_PROPERTIES);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [applySuccess, setApplySuccess] = useState(false);
  // AIS-25: textura de albedo = ResourceRef em res://textures/ (a imagem nunca vai para a cena)
  const [albedoRef, setAlbedoRef] = useState<ResourceRef | null>(null);
  const [presetId, setPresetId] = useState<string | null>(null);
  const [imageIsNew, setImageIsNew] = useState(false);

  // Initialize from selected MeshInstance if opened (mesma leitura do Inspector e da Viewport)
  useEffect(() => {
    if (isTexturePreviewOpen) {
      if (selectedNode && selectedNode.type === 'MeshInstance') {
        const { material } = materialForRender(selectedNode.properties, project.files, `${selectedNode.name}_Material`, resourcePathOf);
        const override = nodeMaterialOverride(selectedNode.properties);
        setProperties(material);
        setAlbedoRef(override.albedoTexture ?? null);
        setPresetId(override.presetId ?? null);
        setImageIsNew(false);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isTexturePreviewOpen, selectedNode?.id]);

  if (!isTexturePreviewOpen) return null;

  // Apply material settings back to the active MeshInstance node in the scene
  // (UM Command sobre `materialOverride`; imagem enviada vira arquivo em res://textures/ + referência)
  const handleApplyToNode = () => {
    if (!selectedNode || selectedNode.type !== 'MeshInstance') {
      addLog('warn', t('texturePreviewModalMsg.noMeshinstanceNodeSelectedTo'));
      return;
    }

    let ref = albedoRef;
    let working = properties;
    if (properties.textureType === 'custom_image' && properties.customImageDataUrl && (imageIsNew || !ref)) {
      const ext = (properties.customImageDataUrl.match(/^data:image\/(\w+)/)?.[1] ?? 'png').replace('jpeg', 'jpg');
      const base = (properties.textureFileName ?? `${selectedNode.name}_albedo`).replace(/\.[^.]+$/, '').replace(/[^a-zA-Z0-9_-]/g, '_') || 'textura';
      const path = `${TEXTURES_DIR}${base}.${ext}`;
      createFile(path, properties.customImageDataUrl);
      // AIS-28c: a referência usa a identidade do recurso recém-criado (o createFile já o registrou)
      ref = globalResourceRegistry.refForUri(path) ?? textureRefFromPath(path);
      setAlbedoRef(ref);
      setImageIsNew(false);
    } else if (properties.textureType === 'custom_image' && !ref) {
      working = { ...properties, textureType: 'none' };
    }

    changeNodeProperty(selectedNode.id, 'materialOverride', toMaterialOverride(working, { albedoTexture: ref, presetId }));

    setApplySuccess(true);
    setTimeout(() => setApplySuccess(false), 2000);
    addLog('log', t('texturePreviewModalMsg.materialSuccessfullyAppliedToNode', { name: selectedNode.name }));
  };

  // Save as .mat.json file in project
  const handleSaveToProject = () => {
    const fileName = properties.name.replace(/[^a-zA-Z0-9_-]/g, '_') || 'CustomMaterial';
    const filePath = `res://materials/${fileName}.mat.json`;
    const content = JSON.stringify(properties, null, 2);

    createFile(filePath, content);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
    addLog('log', t('texturePreviewModalMsg.materialFileSavedTo', { filePath }));
  };

  const handleApplyPreset = (preset: MaterialPreset) => {
    setProperties((prev) => ({
      ...prev,
      ...preset.properties,
      name: preset.name,
    }));
    setPresetId(preset.id);
  };

  // Color helper (RGBA to Hex)
  const toHex = (n: number) =>
    Math.round(Math.max(0, Math.min(1, n)) * 255)
      .toString(16)
      .padStart(2, '0');
  const colorHex = `#${toHex(properties.color.r)}${toHex(properties.color.g)}${toHex(properties.color.b)}`;

  const emissiveHex = `#${toHex(properties.emissiveColor.r)}${toHex(properties.emissiveColor.g)}${toHex(properties.emissiveColor.b)}`;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (uploadEv) => {
      const dataUrl = uploadEv.target?.result as string;
      setProperties((prev) => ({
        ...prev,
        textureType: 'custom_image',
        customImageDataUrl: dataUrl,
        textureFileName: file.name,
      }));
      setImageIsNew(true);
      addLog('log', t('texturePreviewModalMsg.customTextureLoaded', { name: file.name }));
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-150">
      <div className="bg-[#1e232f] border border-[#2c3345] rounded-xl shadow-2xl w-full max-w-6xl h-[88vh] flex flex-col overflow-hidden text-[#dfe4ec]">
        {/* Top Header */}
        <div className="h-12 border-b border-[#2c3345] px-4 flex items-center justify-between bg-[#191d27]">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md">
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-sm text-white">
                  {t('texturePreviewModal.textureMaterialEditorPreview')}
                </span>
                <span className="text-[11px] px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-mono border border-blue-500/30">
                  {properties.name}
                </span>
              </div>
              <p className="text-[11px] text-[#8b97a8] hidden sm:block">
                {t('texturePreviewModal.pbrShadingProceduralTextureGeneration')}
              </p>
            </div>
          </div>

          {/* Quick Header Actions */}
          <div className="flex items-center gap-2">
            {selectedNode && selectedNode.type === 'MeshInstance' && (
              <button
                onClick={handleApplyToNode}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  applySuccess
                    ? 'bg-emerald-600 text-white shadow-lg'
                    : 'bg-emerald-700 hover:bg-emerald-600 text-white'
                }`}
                title={t('texturePreviewModal.applyMaterialPropertiesToThe')}
              >
                <Check className="w-3.5 h-3.5" />
                <span>{applySuccess ? t('texturePreviewModalMsg.appliedToTheScene') : t('texturePreviewModalMsg.applyToNode')}</span>
              </button>
            )}

            <button
              onClick={handleSaveToProject}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                saveSuccess
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-[#273042] hover:bg-[#344057] text-[#dfe4ec] border border-[#3b4760]'
              }`}
              title={t('texturePreviewModalResA.saveAsAMatJson')}
            >
              <Save className="w-3.5 h-3.5 text-blue-400" />
              <span>{saveSuccess ? t('texturePreviewModalMsg.savedToTheProject') : t('texturePreviewModalMsg.saveMatJson')}</span>
            </button>

            <button
              onClick={() => setIsTexturePreviewOpen(false)}
              className="p-1.5 rounded-lg hover:bg-[#2c3345] text-[#8b97a8] hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Main Body (Left: Preview Viewport | Right: Tabs Editor) */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left: 3D / 2D Interactive Preview Canvas */}
          <div className="w-[52%] border-r border-[#2c3345] flex flex-col relative overflow-hidden bg-[#141822]">
            <TexturePreviewCanvas
              properties={properties}
              meshShape={meshShape}
              setMeshShape={setMeshShape}
              lighting={lighting}
              setLighting={setLighting}
              activeViewTab={activeViewTab}
              setActiveViewTab={setActiveViewTab}
              selectedNodeMeshType={selectedNode?.properties?.meshType}
            />
          </div>

          {/* Right: Property Tabs & Editor */}
          <div className="w-[48%] flex flex-col bg-[#1e232f] overflow-hidden">
            {/* Tab Selector Header */}
            <div className="h-10 border-b border-[#2c3345] px-3 flex items-center gap-1 bg-[#191d27]">
              <button
                onClick={() => setActiveTab('properties')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'properties'
                    ? 'bg-[#2c3345] text-white shadow-sm'
                    : 'text-[#8b97a8] hover:text-[#dfe4ec]'
                }`}
              >
                <Sliders className="w-3.5 h-3.5 text-blue-400" />
                <span>{t('texturePreviewModal.pbrProperties')}</span>
              </button>

              <button
                onClick={() => setActiveTab('textures')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'textures'
                    ? 'bg-[#2c3345] text-white shadow-sm'
                    : 'text-[#8b97a8] hover:text-[#dfe4ec]'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-emerald-400" />
                <span>{t('texturePreviewModal.texturesUvs')}</span>
              </button>

              <button
                onClick={() => setActiveTab('presets')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  activeTab === 'presets'
                    ? 'bg-[#2c3345] text-white shadow-sm'
                    : 'text-[#8b97a8] hover:text-[#dfe4ec]'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>{t('texturePreviewModal.presetLibrary')}</span>
              </button>
            </div>

            {/* Tab Contents */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {/* TAB 1: PROPERTIES */}
              {activeTab === 'properties' && (
                <div className="space-y-4">
                  {/* Material Name & Shading Model */}
                  <div className="p-3 bg-[#181c25] rounded-lg border border-[#2c3345] space-y-3">
                    <div className="flex items-center justify-between gap-3">
                      <label className="text-xs text-[#8b97a8] font-medium w-28">{t('texturePreviewModal.materialName')}</label>
                      <input
                        type="text"
                        value={properties.name}
                        onChange={(e) => setProperties({ ...properties, name: e.target.value })}
                        className="flex-1 bg-[#141820] text-xs text-white px-2 py-1 rounded border border-[#2c3345] focus:border-blue-500 outline-none"
                      />
                    </div>

                    <div className="flex items-center justify-between gap-3">
                      <label className="text-xs text-[#8b97a8] font-medium w-28">{t('texturePreviewModal.shadingModel')}</label>
                      <select
                        value={properties.shadingModel}
                        onChange={(e) =>
                          setProperties({ ...properties, shadingModel: e.target.value as ShadingModel })
                        }
                        className="flex-1 bg-[#141820] text-xs text-white px-2 py-1 rounded border border-[#2c3345] focus:border-blue-500 outline-none cursor-pointer"
                      >
                        <option value="Standard">{t('texturePreviewModal.standardDefaultPbrRoughnessMetal')}</option>
                        <option value="Physical">{t('texturePreviewModal.physicalAdvancedPbrClearcoatTransmissi')}</option>
                        <option value="Phong">{t('texturePreviewModal.phongClassicGlossySpecular')}</option>
                        <option value="Toon">{t('texturePreviewModal.toonCelShadedAnimeHq')}</option>
                        <option value="Basic">{t('texturePreviewModal.basicUnlit')}</option>
                      </select>
                    </div>
                  </div>

                  {/* Base Color & Alpha */}
                  <div className="p-3 bg-[#181c25] rounded-lg border border-[#2c3345] space-y-3">
                    <span className="text-xs font-semibold text-white uppercase tracking-wider block">
                      {t('texturePreviewModal.albedoBaseColor')}
                    </span>

                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={colorHex}
                          onChange={(e) => {
                            const hex = e.target.value;
                            const r = parseInt(hex.slice(1, 3), 16) / 255;
                            const g = parseInt(hex.slice(3, 5), 16) / 255;
                            const b = parseInt(hex.slice(5, 7), 16) / 255;
                            setProperties({
                              ...properties,
                              color: { ...properties.color, r, g, b },
                            });
                          }}
                          className="w-8 h-8 rounded border border-[#2c3345] bg-transparent cursor-pointer p-0"
                        />
                        <div>
                          <span className="font-mono text-xs text-white block uppercase">
                            {colorHex}
                          </span>
                          <span className="text-[10px] text-[#718096]">{t('texturePreviewModal.rgbColor')}</span>
                        </div>
                      </div>

                      {/* Quick Color Presets */}
                      <div className="flex items-center gap-1">
                        {['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#ffffff', '#1f2937'].map(
                          (c) => (
                            <button
                              key={c}
                              style={{ backgroundColor: c }}
                              onClick={() => {
                                const r = parseInt(c.slice(1, 3), 16) / 255;
                                const g = parseInt(c.slice(3, 5), 16) / 255;
                                const b = parseInt(c.slice(5, 7), 16) / 255;
                                setProperties({
                                  ...properties,
                                  color: { ...properties.color, r, g, b },
                                });
                              }}
                              className="w-5 h-5 rounded-full border border-black/40 hover:scale-110 transition-transform"
                            />
                          )
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Surface: Roughness & Metalness */}
                  <div className="p-3 bg-[#181c25] rounded-lg border border-[#2c3345] space-y-3">
                    <span className="text-xs font-semibold text-white uppercase tracking-wider block">
                      {t('texturePreviewModal.surfaceFinishPbr')}
                    </span>

                    {/* Roughness */}
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-[#8b97a8]">{t('shared.roughness2')}</span>
                        <span className="font-mono text-white">
                          {properties.roughness.toFixed(2)}{' '}
                          <span className="text-[10px] text-[#718096]">
                            {properties.roughness < 0.2
                              ? t('texturePreviewModalMsg.mirrored')
                              : properties.roughness > 0.8
                              ? t('texturePreviewModalMsg.matte')
                              : t('texturePreviewModalMsg.satin')}
                          </span>
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.01"
                        value={properties.roughness}
                        onChange={(e) =>
                          setProperties({ ...properties, roughness: parseFloat(e.target.value) })
                        }
                        className="w-full h-1.5 bg-[#2c3345] rounded-lg appearance-none cursor-pointer accent-blue-500"
                      />
                    </div>

                    {/* Metalness */}
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-[#8b97a8]">{t('shared.metalness2')}</span>
                        <span className="font-mono text-white">
                          {properties.metalness.toFixed(2)}{' '}
                          <span className="text-[10px] text-[#718096]">
                            {properties.metalness > 0.7
                              ? t('texturePreviewModalMsg.pureMetal')
                              : properties.metalness < 0.2
                              ? t('texturePreviewModalMsg.dielectricPlastic')
                              : t('texturePreviewModalMsg.semiMetallic')}
                          </span>
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.01"
                        value={properties.metalness}
                        onChange={(e) =>
                          setProperties({ ...properties, metalness: parseFloat(e.target.value) })
                        }
                        className="w-full h-1.5 bg-[#2c3345] rounded-lg appearance-none cursor-pointer accent-amber-500"
                      />
                    </div>
                  </div>

                  {/* Advanced PBR: Clearcoat, Transmission, Emissive */}
                  <div className="p-3 bg-[#181c25] rounded-lg border border-[#2c3345] space-y-3">
                    <span className="text-xs font-semibold text-white uppercase tracking-wider block">
                      {t('texturePreviewModal.specialEffectsSelfIllumination')}
                    </span>

                    {/* Emissive */}
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={emissiveHex}
                          onChange={(e) => {
                            const hex = e.target.value;
                            const r = parseInt(hex.slice(1, 3), 16) / 255;
                            const g = parseInt(hex.slice(3, 5), 16) / 255;
                            const b = parseInt(hex.slice(5, 7), 16) / 255;
                            setProperties({
                              ...properties,
                              emissiveColor: { ...properties.emissiveColor, r, g, b },
                            });
                          }}
                          className="w-6 h-6 rounded border border-[#2c3345] bg-transparent cursor-pointer p-0"
                        />
                        <span className="text-xs text-[#8b97a8]">{t('texturePreviewModal.emissiveGlow')}</span>
                      </div>
                      <div className="flex items-center gap-2 w-40">
                        <input
                          type="range"
                          min="0"
                          max="5"
                          step="0.1"
                          value={properties.emissiveIntensity}
                          onChange={(e) =>
                            setProperties({
                              ...properties,
                              emissiveIntensity: parseFloat(e.target.value),
                            })
                          }
                          className="w-full h-1.5 bg-[#2c3345] rounded-lg appearance-none cursor-pointer accent-emerald-500"
                        />
                        <span className="font-mono text-xs text-white w-8 text-right">
                          {properties.emissiveIntensity.toFixed(1)}
                        </span>
                      </div>
                    </div>

                    {/* Clearcoat (Verniz) */}
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-[#8b97a8]">{t('texturePreviewModal.topCoatClearcoat')}</span>
                        <span className="font-mono text-white">{properties.clearcoat.toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={properties.clearcoat}
                        onChange={(e) =>
                          setProperties({ ...properties, clearcoat: parseFloat(e.target.value) })
                        }
                        className="w-full h-1.5 bg-[#2c3345] rounded-lg appearance-none cursor-pointer accent-blue-400"
                      />
                    </div>

                    {/* Transmission (Glass) */}
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-[#8b97a8]">{t('texturePreviewModal.transmissionRefractionGlass')}</span>
                        <span className="font-mono text-white">
                          {properties.transmission.toFixed(2)}
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={properties.transmission}
                        onChange={(e) =>
                          setProperties({
                            ...properties,
                            transmission: parseFloat(e.target.value),
                            transparent: parseFloat(e.target.value) > 0,
                          })
                        }
                        className="w-full h-1.5 bg-[#2c3345] rounded-lg appearance-none cursor-pointer accent-sky-400"
                      />
                    </div>
                  </div>

                  {/* Wireframe & Flat Shading Toggles */}
                  <div className="p-3 bg-[#181c25] rounded-lg border border-[#2c3345] flex items-center justify-between gap-4">
                    <label className="flex items-center gap-2 text-xs text-[#8b97a8] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={properties.wireframe}
                        onChange={(e) => setProperties({ ...properties, wireframe: e.target.checked })}
                        className="rounded border-[#2c3345] bg-[#141820] text-blue-500 focus:ring-0 cursor-pointer"
                      />
                      <span>{t('texturePreviewModal.wireframe')}</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs text-[#8b97a8] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={properties.flatShading}
                        onChange={(e) => setProperties({ ...properties, flatShading: e.target.checked })}
                        className="rounded border-[#2c3345] bg-[#141820] text-blue-500 focus:ring-0 cursor-pointer"
                      />
                      <span>{t('texturePreviewModal.flatShadingPolygonal')}</span>
                    </label>

                    <div className="flex items-center gap-1.5">
                      <span className="text-xs text-[#8b97a8]">{t('texturePreviewModal.faces')}</span>
                      <select
                        value={properties.side}
                        onChange={(e) =>
                          setProperties({
                            ...properties,
                            side: e.target.value as 'front' | 'back' | 'double',
                          })
                        }
                        className="bg-[#141820] text-xs text-white py-0.5 px-1.5 rounded border border-[#2c3345] outline-none cursor-pointer"
                      >
                        <option value="front">{t('texturePreviewModal.front')}</option>
                        <option value="back">{t('texturePreviewModal.back')}</option>
                        <option value="double">{t('texturePreviewModal.bothSides')}</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: TEXTURES & UVs */}
              {activeTab === 'textures' && (
                <div className="space-y-4">
                  {/* Procedural Pattern Selector */}
                  <div className="p-3 bg-[#181c25] rounded-lg border border-[#2c3345] space-y-3">
                    <span className="text-xs font-semibold text-white uppercase tracking-wider block">
                      {t('texturePreviewModal.proceduralTexturePattern')}
                    </span>

                    <div className="grid grid-cols-3 gap-1.5">
                      {[
                        { id: 'none', label: t('texturePreviewModalMsg.noneSmooth') },
                        { id: 'checkerboard', label: t('texturePreviewModalMsg.checker') },
                        { id: 'grid', label: t('texturePreviewModalMsg.techGrid') },
                        { id: 'hex', label: t('texturePreviewModalMsg.hexHoneycomb') },
                        { id: 'brick', label: t('texturePreviewModalMsg.brick') },
                        { id: 'wood', label: t('texturePreviewModalMsg.wood') },
                        { id: 'brushed', label: t('texturePreviewModalMsg.brushedMetal') },
                        { id: 'marble', label: t('texturePreviewModalMsg.marbleVeins') },
                        { id: 'lava', label: t('texturePreviewModalMsg.volcanicMagma') },
                        { id: 'cyberpunk', label: t('texturePreviewModalMsg.cyberpunkNeon') },
                        { id: 'fabric', label: t('texturePreviewModalMsg.fabric') },
                        { id: 'dots', label: t('texturePreviewModalMsg.perforatedDots') },
                        { id: 'noise', label: t('texturePreviewModalMsg.noiseGrunge') },
                      ].map((item) => (
                        <button
                          key={item.id}
                          onClick={() => {
                            // escolher um padrão procedural substitui a textura de arquivo
                            setAlbedoRef(null);
                            setProperties({
                              ...properties,
                              textureType: item.id as TexturePatternType,
                              customImageDataUrl: undefined,
                            });
                          }}
                          className={`p-2 rounded-lg text-left text-xs font-medium border transition-all ${
                            properties.textureType === item.id
                              ? 'bg-blue-600/30 text-blue-300 border-blue-500 shadow-sm'
                              : 'bg-[#141820] text-[#8b97a8] border-[#2c3345] hover:text-white hover:border-[#3e485e]'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>

                    {/* Custom Image Upload */}
                    <div className="pt-2 border-t border-[#2c3345] flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Upload className="w-4 h-4 text-blue-400" />
                        <span className="text-xs text-white">{t('texturePreviewModal.loadLocalImagePngJpg')}</span>
                      </div>
                      <label className="px-3 py-1 bg-[#252c3c] hover:bg-[#323b50] text-xs text-white rounded border border-[#374258] cursor-pointer">
                        {t('texturePreviewModal.browse')}
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  {/* Pattern Colors & Scale */}
                  {properties.textureType !== 'none' && (
                    <div className="p-3 bg-[#181c25] rounded-lg border border-[#2c3345] space-y-3">
                      <span className="text-xs font-semibold text-white uppercase tracking-wider block">
                        {t('texturePreviewModal.patternColorsAndScale')}
                      </span>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={properties.textureColorA}
                            onChange={(e) =>
                              setProperties({ ...properties, textureColorA: e.target.value })
                            }
                            className="w-7 h-7 rounded border border-[#2c3345] bg-transparent cursor-pointer p-0"
                          />
                          <div>
                            <span className="text-[10px] text-[#718096] block">{t('texturePreviewModal.baseColorA')}</span>
                            <span className="font-mono text-xs text-white">
                              {properties.textureColorA}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={properties.textureColorB}
                            onChange={(e) =>
                              setProperties({ ...properties, textureColorB: e.target.value })
                            }
                            className="w-7 h-7 rounded border border-[#2c3345] bg-transparent cursor-pointer p-0"
                          />
                          <div>
                            <span className="text-[10px] text-[#718096] block">{t('texturePreviewModal.lineDetailColorB')}</span>
                            <span className="font-mono text-xs text-white">
                              {properties.textureColorB}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Scale */}
                      <div>
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-[#8b97a8]">{t('texturePreviewModal.patternDensityFrequency')}</span>
                          <span className="font-mono text-white">{properties.textureScale}x</span>
                        </div>
                        <input
                          type="range"
                          min="1"
                          max="24"
                          step="1"
                          value={properties.textureScale}
                          onChange={(e) =>
                            setProperties({
                              ...properties,
                              textureScale: parseInt(e.target.value, 10),
                            })
                          }
                          className="w-full h-1.5 bg-[#2c3345] rounded-lg appearance-none cursor-pointer accent-emerald-500"
                        />
                      </div>
                    </div>
                  )}

                  {/* Normal Map / Bump Relevo */}
                  <div className="p-3 bg-[#181c25] rounded-lg border border-[#2c3345] space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-white uppercase tracking-wider">
                        {t('texturePreviewModal.n3dReliefNormalMap')}
                      </span>
                      <label className="flex items-center gap-1.5 text-xs text-[#8b97a8] cursor-pointer">
                        <input
                          type="checkbox"
                          checked={properties.enableNormalMap}
                          onChange={(e) =>
                            setProperties({ ...properties, enableNormalMap: e.target.checked })
                          }
                          className="rounded border-[#2c3345] bg-[#141820] text-purple-500 focus:ring-0 cursor-pointer"
                        />
                        <span>{t('texturePreviewModal.enableTangentRelief')}</span>
                      </label>
                    </div>

                    {properties.enableNormalMap && (
                      <div>
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-[#8b97a8]">{t('texturePreviewModal.reliefIntensitySobelDepth')}</span>
                          <span className="font-mono text-purple-400">
                            {properties.normalScale.toFixed(1)}x
                          </span>
                        </div>
                        <input
                          type="range"
                          min="0.1"
                          max="4.0"
                          step="0.1"
                          value={properties.normalScale}
                          onChange={(e) =>
                            setProperties({
                              ...properties,
                              normalScale: parseFloat(e.target.value),
                            })
                          }
                          className="w-full h-1.5 bg-[#2c3345] rounded-lg appearance-none cursor-pointer accent-purple-500"
                        />
                      </div>
                    )}
                  </div>

                  {/* UV Mapping (Tiling, Offset, Rotation) */}
                  <div className="p-3 bg-[#181c25] rounded-lg border border-[#2c3345] space-y-3">
                    <span className="text-xs font-semibold text-white uppercase tracking-wider block">
                      {t('texturePreviewModal.uvMappingTilingRepeat')}
                    </span>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="text-[11px] text-[#8b97a8] block mb-1">{t('texturePreviewModal.uRepeatX')}</span>
                        <input
                          type="number"
                          step="0.5"
                          min="0.1"
                          max="32"
                          value={properties.uvTiling.x}
                          onChange={(e) =>
                            setProperties({
                              ...properties,
                              uvTiling: { ...properties.uvTiling, x: parseFloat(e.target.value) || 1 },
                            })
                          }
                          className="w-full bg-[#141820] text-xs font-mono text-white px-2 py-1 rounded border border-[#2c3345] outline-none"
                        />
                      </div>

                      <div>
                        <span className="text-[11px] text-[#8b97a8] block mb-1">{t('texturePreviewModal.vRepeatY')}</span>
                        <input
                          type="number"
                          step="0.5"
                          min="0.1"
                          max="32"
                          value={properties.uvTiling.y}
                          onChange={(e) =>
                            setProperties({
                              ...properties,
                              uvTiling: { ...properties.uvTiling, y: parseFloat(e.target.value) || 1 },
                            })
                          }
                          className="w-full bg-[#141820] text-xs font-mono text-white px-2 py-1 rounded border border-[#2c3345] outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs">
                      <span className="text-[#8b97a8]">{t('texturePreviewModal.wrapMode')}</span>
                      <select
                        value={properties.wrapMode}
                        onChange={(e) =>
                          setProperties({
                            ...properties,
                            wrapMode: e.target.value as 'repeat' | 'clamp' | 'mirror',
                          })
                        }
                        className="bg-[#141820] text-xs text-white py-1 px-2 rounded border border-[#2c3345] outline-none cursor-pointer"
                      >
                        <option value="repeat">{t('texturePreviewModal.repeatWrappingDefault')}</option>
                        <option value="mirror">{t('texturePreviewModal.mirroredRepeat')}</option>
                        <option value="clamp">{t('texturePreviewModal.clampToEdge')}</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: PRESETS */}
              {activeTab === 'presets' && (
                <div className="space-y-3">
                  <div className="text-xs text-[#8b97a8]">
                    {t('texturePreviewModal.selectAPresetToInstantly')}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    {MATERIAL_PRESETS.map((preset) => (
                      <div
                        key={preset.id}
                        onClick={() => handleApplyPreset(preset)}
                        className="p-3 bg-[#181c25] hover:bg-[#222735] border border-[#2c3345] hover:border-blue-500 rounded-lg cursor-pointer transition-all flex flex-col justify-between group"
                      >
                        <div className="flex items-start gap-2.5">
                          <div
                            style={{ backgroundColor: preset.previewColor }}
                            className="w-8 h-8 rounded-lg shadow-inner shrink-0 border border-white/20 group-hover:scale-105 transition-transform"
                          />
                          <div>
                            <span className="font-semibold text-xs text-white group-hover:text-blue-400 block">
                              {preset.name}
                            </span>
                            <span className="text-[10px] text-[#718096] font-mono">
                              {preset.category}
                            </span>
                          </div>
                        </div>

                        <p className="text-[11px] text-[#8b97a8] mt-2 line-clamp-2">
                          {preset.description}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="h-10 border-t border-[#2c3345] px-4 flex items-center justify-between bg-[#191d27] text-xs">
          <div className="flex items-center gap-2 text-[#718096] text-[11px]">
            <Info className="w-3.5 h-3.5" />
            <span>
              {t('texturePreviewModalResA.anyChangeMadeToThe')}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setProperties(DEFAULT_MATERIAL_PROPERTIES)}
              className="flex items-center gap-1 px-3 py-1 rounded bg-[#202636] hover:bg-[#2c3345] text-[#8b97a8] hover:text-white transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span>{t('texturePreviewModal.restoreDefault')}</span>
            </button>

            <button
              onClick={() => setIsTexturePreviewOpen(false)}
              className="px-4 py-1 rounded bg-[#273042] hover:bg-[#344057] text-white font-medium transition-colors"
            >
              {t('common.close')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
