import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import {
  Volume2,
  VolumeX,
  Volume1,
  Play,
  Pause,
  Square,
  Repeat,
  Radio,
  Sliders,
  Sparkles,
  X,
  RotateCcw,
  Check,
  Eye,
  Info,
  ExternalLink,
  Compass,
  Layers,
  Music,
  Headphones,
  Upload,
  RefreshCw,
  FolderOpen,
  Waves,
} from 'lucide-react';

import { isSoundPresetAvailable, SOUND_PRESETS, type SoundChannel, type SoundPlayMode, type SoundPresetSample } from '../../core/sound/soundPresets';
import { ensureLibraryEntry } from '../../core/library/libraryUse';
import { libraryAudioUri, libraryEntry } from '../../core/library/assetLibrary';
import { globalCommandManager } from '../../core/commandManager';
import type { ICommand } from '../../types/commands';
import { useGeneratorEdit } from '../../core/generators/useGeneratorEdit';
import { globalGeneratorRegistry } from '../../core/generators/generatorRegistry';
import { cloneGeneratorSource } from '../../types/generatorSource';
import { createSetGeneratorSourceCommand } from '../../core/generators/generatorCommands';
import { globalAuthoringModel } from '../../core/authoring';
import { decodeAudio, playVoice, resumeAudio, type Voice } from '../../core/sound/audioEngine';
import { getChannelGain } from '../../core/sound/audioMixer';
import { fxParams, normalizeFx } from '../../core/sound/audioMath';
import { resolveSoundSource } from '../../core/sound/soundSource';
import { useTranslation } from '../../core/i18n/I18nContext';

export type { SoundChannel, SoundPlayMode, SoundPresetSample };
export type AttenuationModel = 'inverse' | 'linear' | 'exponential';
export type SoundFXType = 'none' | 'reverb' | 'echo' | 'lowpass' | 'distortion';

export const SoundModal: React.FC = () => {
  const { t } = useTranslation();
  const {
    isSoundModalOpen,
    setIsSoundModalOpen,
    activeScene,
    project,
    addNode,
    selectNode,
    addLog,
  } = useEditor();

  // AIS-52: arquivo pré-carregado via duplo clique no FileSystem (null = criação/edição via menu)
  const soundModalFilePath = useEditorStore((s) => s.soundModalFilePath);
  const setIsSoundModalOpenStore = useEditorStore((s) => s.setIsSoundModalOpen);

  // AIS-52: modo edição via generatorSource (AIS-49b)
  const generatorEdit = useGeneratorEdit('sound');
  const isEditing = generatorEdit.editing;

  const [activeTab, setActiveTab] = useState<'playback' | 'spatial' | 'fx'>('playback');

  // Node & file configuration
  const [nodeName, setNodeName] = useState<string>('Audio_Ambient_01');
  const [soundPath, setSoundPath] = useState<string>(libraryAudioUri('Ambience_City'));
  const [is2D, setIs2D] = useState<boolean>(false); // PlayAs2D in CopperCube
  const [playMode, setPlayMode] = useState<SoundPlayMode>('loop');
  const [channel, setChannel] = useState<SoundChannel>('Ambience');
  const [autoplay, setAutoplay] = useState<boolean>(true);
  const [paused, setPaused] = useState<boolean>(false);

  // Volume & Pitch
  const [volume, setVolume] = useState<number>(85); // 0-100%
  const [pitch, setPitch] = useState<number>(1.0); // 0.2 - 2.5
  const [randomPitchVariation, setRandomPitchVariation] = useState<number>(0.05); // +/- 5%
  const [randomWaitTimeMin, setRandomWaitTimeMin] = useState<number>(6); // sec
  const [randomWaitTimeMax, setRandomWaitTimeMax] = useState<number>(18); // sec

  // 3D Spatial Attenuation (When !is2D)
  const [posX, setPosX] = useState<number>(0);
  const [posY, setPosY] = useState<number>(1.2);
  const [posZ, setPosZ] = useState<number>(0);
  const [minDist, setMinDist] = useState<number>(4.0); // Inner Radius (Max volume)
  const [maxDist, setMaxDist] = useState<number>(25.0); // Outer Radius (Cutoff)
  const [attenuation, setAttenuation] = useState<AttenuationModel>('inverse');
  const [dopplerEffect, setDopplerEffect] = useState<boolean>(false);

  // Sound FX (CopperCube 6 irrKlang SoundFX)
  const [soundFX, setSoundFX] = useState<SoundFXType>('none');
  const [fxGain, setFxGain] = useState<number>(40); // 0-100%
  const [fxRoomSize, setFxRoomSize] = useState<number>(65);

  // Interactive Player & Visualizer State
  const [isPlayingPreview, setIsPlayingPreview] = useState<boolean>(false);
  const [playbackProgress, setPlaybackProgress] = useState<number>(0.2); // 0.0 - 1.0
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [trackDuration, setTrackDuration] = useState<number>(16.0); // seconds

  // Simulated Listener Position for Radar
  const [listenerDist, setListenerDist] = useState<number>(8.5); // meters from source
  const [listenerAngle, setListenerAngle] = useState<number>(45); // degrees

  // Canvas refs
  const waveformCanvasRef = useRef<HTMLCanvasElement>(null);
  const radarCanvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number | null>(null);

  // AIS-52: helper para carregar params de um generatorSource no estado local
  const loadParamsFromSource = (params: Record<string, unknown>) => {
    if (typeof params.stream === 'string') setSoundPath(params.stream);
    if (typeof params.volumePercent === 'number') setVolume(params.volumePercent);
    if (typeof params.pitchScale === 'number') setPitch(params.pitchScale);
    if (typeof params.randomPitchVariation === 'number') setRandomPitchVariation(params.randomPitchVariation);
    if (typeof params.loop === 'boolean') setPlayMode(params.loop ? 'loop' : 'once');
    if (typeof params.playMode === 'string') setPlayMode(params.playMode as SoundPlayMode);
    if (typeof params.channel === 'string') setChannel(params.channel as SoundChannel);
    if (typeof params.autoplay === 'boolean') setAutoplay(params.autoplay);
    if (typeof params.paused === 'boolean') setPaused(params.paused);
    if (typeof params.is2D === 'boolean') setIs2D(params.is2D);
    if (typeof params.unitSize === 'number') setMinDist(params.unitSize);
    if (typeof params.maxDistance === 'number') setMaxDist(params.maxDistance);
    if (typeof params.attenuation === 'string') setAttenuation(params.attenuation as AttenuationModel);
    if (typeof params.dopplerEffect === 'boolean') setDopplerEffect(params.dopplerEffect);
    if (typeof params.soundFX === 'string') setSoundFX(params.soundFX as SoundFXType);
    if (typeof params.fxGain === 'number') setFxGain(params.fxGain);
    if (typeof params.fxRoomSize === 'number') setFxRoomSize(params.fxRoomSize);
    const pos = params.position as Record<string, number> | undefined;
    if (pos && typeof pos.x === 'number') { setPosX(pos.x); setPosY(pos.y ?? 1.2); setPosZ(pos.z ?? 0); }
  };

  // AIS-52: ao abrir em modo edição, carrega os parâmetros salvos do nó
  useEffect(() => {
    if (!isSoundModalOpen) return;
    if (isEditing && generatorEdit.source?.params) {
      const p = generatorEdit.source.params;
      loadParamsFromSource(p);
      // Tenta inferir nome do nó alvo
      if (generatorEdit.nodeName) setNodeName(generatorEdit.nodeName);
    } else if (soundModalFilePath) {
      // AIS-52-C08: modo "arquivo" — pré-carrega o path, não cria nó
      setSoundPath(soundModalFilePath);
      setNodeName(`Audio_${soundModalFilePath.split('/').pop()?.split('.')[0] ?? 'Importado'}`);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSoundModalOpen, isEditing]);

  // AIS-52: registra no globalGeneratorRegistry para que "Editar no gerador" funcione (AIS-49b)
  useEffect(() => {
    const unregister = globalGeneratorRegistry.register({
      id: 'sound',
      label: t('soundModalMsg.soundAudio'),
      open: (req) => {
        // Ao receber o pedido, o useGeneratorEdit já configura o generatorEdit no store;
        // o modal é aberto pelo InspectorPanel via startGeneratorEdit + setIsSoundModalOpen.
        setIsSoundModalOpenStore(true);
      },
    });
    return unregister;
  }, [setIsSoundModalOpenStore, t]);

  // Handle close: limpa soundModalFilePath e encerra edição de gerador se ativa
  const handleClose = () => {
    setIsSoundModalOpen(false); // também zera soundModalFilePath (via store)
    if (isEditing) generatorEdit.cancel();
    setIsPlayingPreview(false);
  };

  // Apply preset
  const applyPreset = (preset: SoundPresetSample) => {
    setSoundPath(preset.path);
    setNodeName(`Audio_${preset.name.split(' ')[0]}_${preset.is2D ? '2D' : '3D'}`);
    setIs2D(preset.is2D);
    setVolume(preset.volume);
    setPitch(preset.pitch);
    setPlayMode(preset.playMode);
    setMinDist(preset.minDist);
    setMaxDist(preset.maxDist);
    setChannel(preset.category);
    setTrackDuration(preset.duration);
    setPlaybackProgress(0);
  };

  // AIS-52: helper para construir os params do generatorSource
  const buildCurrentParams = () => ({
    stream: soundPath,
    volumeDb: Math.round(((volume - 100) / 100) * 40),
    volumePercent: volume,
    pitchScale: pitch,
    randomPitchVariation,
    loop: playMode === 'loop',
    playMode,
    channel,
    autoplay,
    paused,
    is2D,
    unitSize: minDist,
    maxDistance: maxDist,
    attenuation,
    dopplerEffect,
    soundFX,
    fxGain,
    fxRoomSize,
    position: { x: posX, y: posY, z: posZ },
  });

  // Calculate current effective volume perceived by listener in 3D
  const calculatedPerceivedVolume = useMemo(() => {
    if (isMuted || volume === 0) return 0;
    if (is2D) return volume;
    if (listenerDist <= minDist) return volume;
    if (listenerDist >= maxDist) return 0;

    let factor = 1.0;
    if (attenuation === 'linear') {
      factor = 1.0 - (listenerDist - minDist) / Math.max(0.1, maxDist - minDist);
    } else if (attenuation === 'inverse') {
      factor = minDist / (minDist + (listenerDist - minDist));
    } else {
      // exponential
      factor = Math.pow(1.0 - (listenerDist - minDist) / Math.max(0.1, maxDist - minDist), 2);
    }

    return Math.round(volume * Math.max(0, Math.min(1, factor)));
  }, [isMuted, volume, is2D, listenerDist, minDist, maxDist, attenuation]);

  // AIS-52: teste real (Web Audio) — a mesma voz do Play; ganho = atenuação do ouvinte simulado × mixer do projeto
  const voiceRef = useRef<Voice | null>(null);
  const trackDurationRef = useRef(trackDuration);
  trackDurationRef.current = trackDuration;
  const previewGain = (isMuted ? 0 : (is2D ? volume : calculatedPerceivedVolume) / 100) * getChannelGain(channel, project.settings?.audio);
  const previewGainRef = useRef(previewGain);
  previewGainRef.current = previewGain;
  const previewPitchRef = useRef(pitch);
  previewPitchRef.current = pitch;
  const previewFxRef = useRef(fxParams(normalizeFx(soundFX), fxGain, fxRoomSize));
  previewFxRef.current = fxParams(normalizeFx(soundFX), fxGain, fxRoomSize);

  useEffect(() => {
    if (!isPlayingPreview) return;
    let cancelled = false;
    void (async () => {
      await resumeAudio();
      const source = resolveSoundSource(soundPath, project.files);
      const buffer = source ? await decodeAudio(source) : null;
      if (cancelled) return;
      if (!buffer) {
        addLog('warn', t('soundModalMsg.couldNotPlayFileMissing', { soundPath }));
        setIsPlayingPreview(false);
        return;
      }
      setTrackDuration(buffer.duration);
      voiceRef.current = playVoice({
        buffer,
        gain: previewGainRef.current,
        pitch: previewPitchRef.current,
        fx: previewFxRef.current,
        loop: playMode === 'loop',
        onEnded: () => setIsPlayingPreview(false),
      });
    })();
    return () => {
      cancelled = true;
      voiceRef.current?.stop();
      voiceRef.current = null;
    };
  }, [isPlayingPreview, soundPath, playMode, soundFX, fxGain, fxRoomSize, project.files, addLog, t]);

  useEffect(() => {
    voiceRef.current?.setGain(previewGain);
    voiceRef.current?.setPitch(pitch);
  }, [previewGain, pitch]);

  // Audio Waveform & VU Meter Rendering Loop
  useEffect(() => {
    if (!isSoundModalOpen) return;
    const canvas = waveformCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let startTime = performance.now();

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const elapsed = (performance.now() - startTime) * 0.001;

      // Progresso real da voz em reprodução
      const liveVoice = voiceRef.current;
      if (isPlayingPreview && liveVoice) {
        const dur = Math.max(0.05, trackDurationRef.current);
        setPlaybackProgress((liveVoice.currentTime % dur) / dur);
      }

      // Background gradient
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, '#10141d');
      bgGrad.addColorStop(1, '#0c0f16');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // Center reference line
      const centerY = h * 0.5;
      ctx.strokeStyle = 'rgba(40, 50, 70, 0.4)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, centerY);
      ctx.lineTo(w, centerY);
      ctx.stroke();

      // Frequency / Waveform Bars
      const numBars = 48;
      const barW = (w - (numBars - 1) * 2) / numBars;
      const effectiveVol = isPlayingPreview ? (isMuted ? 0 : volume / 100) : 0.08;

      for (let i = 0; i < numBars; i++) {
        const norm = i / numBars;
        // Animated frequency amplitude
        const wave = Math.sin(norm * 14 + elapsed * 6 * pitch) * Math.cos(norm * 8 - elapsed * 3);
        const noise = Math.sin(i * 99 + elapsed * 12) * 0.3;
        const amplitude = Math.abs(wave + noise) * (h * 0.42) * effectiveVol;

        const bx = i * (barW + 2);
        const by = centerY - amplitude;
        const bh = amplitude * 2;

        // Color gradient: cyan to purple/pink
        const barGrad = ctx.createLinearGradient(0, centerY - amplitude, 0, centerY + amplitude);
        if (norm <= playbackProgress && isPlayingPreview) {
          barGrad.addColorStop(0, '#38bdf8');
          barGrad.addColorStop(0.5, '#818cf8');
          barGrad.addColorStop(1, '#c084fc');
        } else {
          barGrad.addColorStop(0, 'rgba(56, 189, 248, 0.25)');
          barGrad.addColorStop(1, 'rgba(192, 132, 252, 0.15)');
        }

        ctx.fillStyle = barGrad;
        ctx.fillRect(bx, by, barW, Math.max(2, bh));
      }

      // Playback head line
      const headX = playbackProgress * w;
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(headX, 0);
      ctx.lineTo(headX, h);
      ctx.stroke();

      if (isPlayingPreview) {
        animFrameRef.current = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isSoundModalOpen, isPlayingPreview, volume, pitch, isMuted, playbackProgress]);

  // 3D Spatial Radar Rendering
  useEffect(() => {
    if (!isSoundModalOpen || is2D) return;
    const canvas = radarCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Radar background
    ctx.fillStyle = '#0b0e14';
    ctx.fillRect(0, 0, w, h);

    const centerX = w * 0.5;
    const centerY = h * 0.5;
    const scale = (w * 0.44) / Math.max(30, maxDist * 1.15); // pixels per meter

    // Radar concentric distance rings
    ctx.strokeStyle = '#1e2838';
    ctx.lineWidth = 1;
    for (let r = 10; r <= maxDist * 1.2; r += 10) {
      ctx.beginPath();
      ctx.arc(centerX, centerY, r * scale, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Outer Max Distance Ring (Cutoff radius - Sky blue / dashed)
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
    ctx.setLineDash([4, 4]);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(centerX, centerY, maxDist * scale, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // Falloff fill area
    ctx.fillStyle = 'rgba(56, 189, 248, 0.04)';
    ctx.fill();

    // Inner Min Distance Ring (Max Volume 100% radius - Emerald Green)
    ctx.strokeStyle = '#10b981';
    ctx.fillStyle = 'rgba(16, 185, 129, 0.12)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(centerX, centerY, minDist * scale, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fill();

    // Center Crosshair (Sound Source Origin: X, Y, Z)
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(centerX - 8, centerY);
    ctx.lineTo(centerX + 8, centerY);
    ctx.moveTo(centerX, centerY - 8);
    ctx.lineTo(centerX, centerY + 8);
    ctx.stroke();

    // Sound Source Node Icon (Speaker)
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.arc(centerX, centerY, 5, 0, Math.PI * 2);
    ctx.fill();

    // Listener / Player Camera position relative to sound source
    const angleRad = (listenerAngle * Math.PI) / 180;
    const lx = centerX + Math.cos(angleRad) * (listenerDist * scale);
    const ly = centerY + Math.sin(angleRad) * (listenerDist * scale);

    // Dotted line from source to listener
    ctx.strokeStyle = calculatedPerceivedVolume > 0 ? '#10b981' : '#64748b';
    ctx.setLineDash([2, 3]);
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(lx, ly);
    ctx.stroke();
    ctx.setLineDash([]);

    // Listener Icon (Headphones indicator)
    ctx.fillStyle = calculatedPerceivedVolume > 0 ? '#34d399' : '#94a3b8';
    ctx.beginPath();
    ctx.arc(lx, ly, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Labels
    ctx.font = t('soundModalMsg.n9pxMonospace');
    ctx.fillStyle = '#10b981';
    ctx.fillText(t('soundModalMsg.minM100Vol', { minDist }), centerX + 8, centerY - minDist * scale - 4);

    ctx.fillStyle = '#38bdf8';
    ctx.fillText(t('soundModalMsg.maxMCutoff', { maxDist }), centerX + 8, centerY - maxDist * scale - 4);

    ctx.fillStyle = '#f8fafc';
    ctx.fillText(t('soundModalMsg.listenerM', { listenerDist: listenerDist.toFixed(1) }), lx + 10, ly + 3);
  }, [isSoundModalOpen, is2D, minDist, maxDist, listenerDist, listenerAngle, calculatedPerceivedVolume, t]);

  if (!isSoundModalOpen) return null;

  // Insert Sound Node into Active Scene (modo criação ou modo "arquivo")
  const handleInsertSound = async () => {
    const parentId = activeScene.rootNodeId;
    const finalType = is2D ? 'AudioPlayer' : 'AudioPlayer3D';
    const params = buildCurrentParams();

    // o áudio da biblioteca (padrão) é importado para o projeto junto com o nó; o Undo da inserção remove os dois
    const importCommands: ICommand[] = [];
    const libraryId = /^res:\/\/audio\/([^/]+)\.ogg$/.exec(soundPath)?.[1];
    if (libraryId && libraryEntry('audio', libraryId)) {
      const imported = await ensureLibraryEntry('audio', libraryId);
      if (imported.ok && imported.command) importCommands.push(imported.command);
      else if (!imported.ok) addLog('warn', t('soundModalMsg.audioNotImportedTheNode', { libraryId, error: imported.error, soundPath }));
    }
    // AIS-52-C05: Criação + propriedades + generatorSource num único MacroCommand (um Undo remove o nó).
    const newNode = globalCommandManager.transaction(t('leftovers.createSound'), () => {
      for (const c of importCommands) globalCommandManager.pushCommand(c);
      const node = addNode(finalType, parentId, nodeName, params);
      // Grava o generatorSource imediatamente após criar o nó (mesmo transaction = mesmo Undo)
      const marcaGen = createSetGeneratorSourceCommand({
        target: globalAuthoringModel,
        nodeId: node.id,
        source: { generatorId: 'sound', version: 1, params },
      });
      if (marcaGen) globalCommandManager.pushCommand(marcaGen);
      return node;
    });

    selectNode(newNode.id);
    addLog(
      'log',
      t('soundModalMsg.insertedNodeFileVolumeMode', { value: is2D ? '2D Audio Player' : '3D Spatial Sound', nodeName, value2: soundPath.split('/').pop(), volume, playMode })
    );

    setIsSoundModalOpen(false);
  };

  // AIS-52-C07: "Aplicar ao nó" — modo edição via generatorSource (MacroCommand, Undo restaura o estado anterior)
  const handleApplyToNode = () => {
    if (!isEditing) return;
    const params = buildCurrentParams();
    const applied = generatorEdit.apply(params, {
      generatorId: 'sound',
      version: 1,
      params,
    });
    if (applied) {
      addLog('log', t('soundModalMsg.soundUpdatedViaGeneratorClip', { nodeName, value: soundPath.split('/').pop(), volume }));
      setIsSoundModalOpen(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 select-none animate-in fade-in duration-150">
      <div className="bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-5xl h-[92vh] max-h-[820px] flex flex-col overflow-hidden text-sm text-[#d4dbe8]">
        {/* Header */}
        <div className="px-5 py-3.5 bg-[#141720] border-b border-[#242b3b] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-semibold text-white text-base">
                  {t('dialogs.sound.title')}
                </h2>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-indigo-950 text-indigo-300 border border-indigo-800">
                  {t('soundModal.coppercubeIrrklangSpec')}
                </span>
              </div>
              <p className="text-xs text-[#828f9f] mt-0.5">
                {t('soundModal.configure2dMusicTracks3d')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="https://www.ambiera.com/coppercube/doc/index.html"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 text-xs text-[#828f9f] hover:text-[#c5d0e2] hover:bg-[#202636] border border-transparent hover:border-[#2f394c] rounded flex items-center gap-1.5 transition-colors"
              title={t('shared.coppercubeDocumentation')}
            >
              <span>Doc</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={handleClose}
              className="p-1.5 text-[#828f9f] hover:text-white hover:bg-[#252c3c] rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Audio Presets Quick Bar */}
        <div className="px-5 py-2.5 bg-[#12151d] border-b border-[#202636] flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-[11px] font-semibold text-[#6d7a8d] uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" /> {t('shared.presets')}
          </span>
          {SOUND_PRESETS.map((p) => {
            const isSelected = soundPath === p.path;
            const available = isSoundPresetAvailable(p);
            return (
              <button
                key={p.id}
                disabled={!available}
                title={available ? p.description : t('soundModalMsg.comingSoonThereIsNo')}
                onClick={() => applyPreset(p)}
                className={`px-2.5 py-1 text-xs rounded-md border flex items-center gap-1.5 shrink-0 transition-all ${
                  isSelected
                    ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300 font-medium shadow-sm shadow-indigo-950'
                    : 'bg-[#181c26] border-[#262e3e] text-[#8e9cb0] hover:text-[#dfe4ec] hover:border-[#384358]'
                } ${available ? '' : 'opacity-40 cursor-not-allowed'}`}
              >
                {p.is2D ? <Music className="w-3 h-3 text-purple-400" /> : <Radio className="w-3 h-3 text-emerald-400" />}
                <span>{p.name.split(' ')[0]}</span>
                {isSelected && <Check className="w-3 h-3 text-indigo-400" />}
              </button>
            );
          })}
        </div>

        {/* Main Content: Two Columns */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Column: Properties & Tabs */}
          <div className="w-[58%] border-r border-[#242b3b] flex flex-col bg-[#161a24]">
            {/* Category Tabs */}
            <div className="flex border-b border-[#222838] bg-[#141721] px-3 pt-2 gap-1 shrink-0">
              <button
                onClick={() => setActiveTab('playback')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'playback'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Music className="w-3.5 h-3.5 text-indigo-400" />
                <span>{t('soundModal.playbackFile')}</span>
              </button>

              <button
                onClick={() => setActiveTab('spatial')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'spatial'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Radio className="w-3.5 h-3.5 text-emerald-400" />
                <span>{t('soundModal.n3dSpatialDistance')}</span>
              </button>

              <button
                onClick={() => setActiveTab('fx')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'fx'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Waves className="w-3.5 h-3.5 text-cyan-400" />
                <span>{t('soundModal.irrklangSoundfx')}</span>
              </button>
            </div>

            {/* Form Panels with Smooth Scroll */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs text-[#a9b6c8]">
              {/* TAB 1: PLAYBACK & SOURCE */}
              {activeTab === 'playback' && (
                <div className="space-y-4">
                  {/* File & Name Inputs */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-white font-medium block mb-1">{t('soundModal.nodeName')}</label>
                      <input
                        type="text"
                        value={nodeName}
                        onChange={(e) => setNodeName(e.target.value)}
                        className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
                      />
                    </div>

                    <div>
                      <label className="text-white font-medium block mb-1">{t('soundModal.audioChannelMixerChannel')}</label>
                      <select
                        value={channel}
                        onChange={(e) => setChannel(e.target.value as SoundChannel)}
                        className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs focus:outline-none focus:border-indigo-500"
                      >
                        <option value="Master">{t('soundModal.masterChannel')}</option>
                        <option value="Music">{t('soundModal.bgmBackgroundMusic')}</option>
                        <option value="Ambience">{t('soundModal.ambienceAtmosfera')}</option>
                        <option value="SFX">{t('soundModal.sfxSoundEffects')}</option>
                      </select>
                    </div>
                  </div>

                  {/* Sound File Path with Browse */}
                  <div>
                    <label className="text-white font-medium block mb-1">
                      {t('soundModal.audioFileSoundFileWav')}
                    </label>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 flex items-center justify-between">
                        <span className="font-mono text-white text-xs truncate">{soundPath}</span>
                        <span className="text-[10px] text-[#707e92] shrink-0 font-mono">
                          {soundPath.split('.').pop()?.toUpperCase()}
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          const custom = prompt(t('soundModalMsgResB.typeTheVirtualAudioPath'), soundPath);
                          if (custom) setSoundPath(custom);
                        }}
                        className="px-3 py-1.5 bg-[#212735] hover:bg-[#2b3346] border border-[#303a4e] text-white rounded text-xs flex items-center gap-1.5 shrink-0 transition-colors"
                      >
                        <FolderOpen className="w-3.5 h-3.5 text-indigo-400" />
                        <span>{t('soundModal.browse')}</span>
                      </button>
                    </div>
                    <span className="text-[10px] text-[#6d7b8e] mt-1 block">
                      {t('soundModal.coppercubeSupportsWavOggVorbis')}
                    </span>
                  </div>

                  {/* 2D vs 3D Mode (CopperCube PlayAs2D Flag) */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white flex items-center gap-2">
                        <Music className="w-4 h-4 text-purple-400" />
                        <span>{t('soundModal.playAsGlobal2dAudio')}</span>
                      </div>
                      <p className="text-[11px] text-[#778598] mt-0.5">
                        {is2D
                          ? t('soundModalMsg.enabledTheSoundPlaysAt')
                          : t('soundModalMsg.disabledTheSoundWillBe')}
                      </p>
                    </div>

                    <label className="relative inline-flex items-center cursor-pointer shrink-0">
                      <input
                        type="checkbox"
                        checked={is2D}
                        onChange={(e) => setIs2D(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-[#252c3c] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                    </label>
                  </div>

                  {/* Play Mode Selector */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-3">
                    <label className="text-white font-medium block">
                      {t('soundModal.playMode')}
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() => setPlayMode('loop')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          playMode === 'loop'
                            ? 'bg-indigo-500/20 border-indigo-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center gap-1.5">
                          <Repeat className="w-3.5 h-3.5 text-indigo-400" />
                          <span>{t('soundModal.infiniteLoop')}</span>
                        </div>
                        <div className="text-[10px] text-[#718096] mt-1">{t('soundModal.repeatsContinuously')}</div>
                      </button>

                      <button
                        onClick={() => setPlayMode('once')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          playMode === 'once'
                            ? 'bg-indigo-500/20 border-indigo-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center gap-1.5">
                          <Play className="w-3.5 h-3.5 text-emerald-400" />
                          <span>{t('soundModal.playOnce')}</span>
                        </div>
                        <div className="text-[10px] text-[#718096] mt-1">{t('soundModal.playsOnceWhenTriggered')}</div>
                      </button>

                      <button
                        onClick={() => setPlayMode('random')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          playMode === 'random'
                            ? 'bg-indigo-500/20 border-indigo-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center gap-1.5">
                          <Radio className="w-3.5 h-3.5 text-amber-400" />
                          <span>{t('soundModal.randomInterval')}</span>
                        </div>
                        <div className="text-[10px] text-[#718096] mt-1">{t('soundModal.playsAtRandomPauses')}</div>
                      </button>
                    </div>

                    {playMode === 'random' && (
                      <div className="pt-2 border-t border-[#232a3a] grid grid-cols-2 gap-3">
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-[#c4cfdf]">{t('soundModal.minimumWaitTime')}</span>
                            <span className="font-mono text-indigo-400">{randomWaitTimeMin}s</span>
                          </div>
                          <input
                            type="range"
                            min="1"
                            max="30"
                            step="1"
                            value={randomWaitTimeMin}
                            onChange={(e) => setRandomWaitTimeMin(parseInt(e.target.value))}
                            className="w-full accent-indigo-500"
                          />
                        </div>
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-[#c4cfdf]">{t('soundModal.maximumWaitTime')}</span>
                            <span className="font-mono text-indigo-400">{randomWaitTimeMax}s</span>
                          </div>
                          <input
                            type="range"
                            min="5"
                            max="60"
                            step="1"
                            value={randomWaitTimeMax}
                            onChange={(e) => setRandomWaitTimeMax(parseInt(e.target.value))}
                            className="w-full accent-indigo-500"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Volume & Pitch Controls */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <label className="text-white font-medium flex items-center gap-1.5">
                            <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
                            <span>{t('soundModal.volume')}</span>
                          </label>
                          <span className="font-mono text-indigo-400 font-semibold">{volume}%</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          step="1"
                          value={volume}
                          onChange={(e) => setVolume(parseInt(e.target.value))}
                          className="w-full accent-indigo-500"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between mb-1">
                          <label className="text-white font-medium">{t('soundModal.pitchSpeedFrequency')}</label>
                          <span className="font-mono text-indigo-400 font-semibold">{pitch.toFixed(2)}x</span>
                        </div>
                        <input
                          type="range"
                          min="0.4"
                          max="2.0"
                          step="0.05"
                          value={pitch}
                          onChange={(e) => setPitch(parseFloat(e.target.value))}
                          className="w-full accent-indigo-500"
                        />
                      </div>
                    </div>

                    <div className="pt-2 border-t border-[#232a3a]">
                      <div className="flex justify-between mb-1">
                        <span className="text-[#c4cfdf]">{t('soundModal.randomPitchVariationPitchJitter')}</span>
                        <span className="font-mono text-indigo-400 font-semibold">
                          {(randomPitchVariation * 100).toFixed(0)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0.0"
                        max="0.25"
                        step="0.01"
                        value={randomPitchVariation}
                        onChange={(e) => setRandomPitchVariation(parseFloat(e.target.value))}
                        className="w-full accent-indigo-500"
                      />
                      <span className="text-[10px] text-[#6d7b8e]">
                        {t('soundModal.ensuresContinuousRepeatsDoNot')}
                      </span>
                    </div>
                  </div>

                  {/* Autoplay & Paused flags */}
                  <div className="flex items-center gap-5 pt-1">
                    <label className="flex items-center gap-2 cursor-pointer text-[#c4cfdf]">
                      <input
                        type="checkbox"
                        checked={autoplay}
                        onChange={(e) => setAutoplay(e.target.checked)}
                        className="rounded border-[#2c3447] bg-[#1a1f2b] text-indigo-500 focus:ring-0"
                      />
                      <span>{t('soundModal.autoplayOnSceneStart')}</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer text-[#c4cfdf]">
                      <input
                        type="checkbox"
                        checked={paused}
                        onChange={(e) => setPaused(e.target.checked)}
                        className="rounded border-[#2c3447] bg-[#1a1f2b] text-indigo-500 focus:ring-0"
                      />
                      <span>{t('soundModal.startInPausedStatePaused')}</span>
                    </label>
                  </div>
                </div>
              )}

              {/* TAB 2: 3D SPATIAL & ATTENUATION */}
              {activeTab === 'spatial' && (
                <div className="space-y-4">
                  {is2D && (
                    <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg flex items-center gap-2 text-amber-200">
                      <Info className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>
                        {t('soundModal.warningTheOption')} <strong>{t('soundModal.playas2d')}</strong> {t('soundModal.isActiveOnTheFirst')}
                      </span>
                    </div>
                  )}

                  {/* 3D Coordinate Translation */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-3">
                    <h3 className="font-semibold text-white text-sm flex items-center gap-2">
                      <Compass className="w-4 h-4 text-emerald-400" />
                      {t('soundModal.n3dEmitterPosition')}
                    </h3>
                    <div className="grid grid-cols-3 gap-3 font-mono">
                      <div>
                        <label className="text-[10px] text-[#718096] uppercase block mb-1">{t('soundModal.xEastWest')}</label>
                        <input
                          type="number"
                          value={posX}
                          onChange={(e) => setPosX(parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-[#718096] uppercase block mb-1">{t('soundModal.yElevationHeight')}</label>
                        <input
                          type="number"
                          value={posY}
                          onChange={(e) => setPosY(parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-[#718096] uppercase block mb-1">{t('soundModal.zNorthSouth')}</label>
                        <input
                          type="number"
                          value={posZ}
                          onChange={(e) => setPosZ(parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Distance Attenuation Radii (Min & Max Distance) */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-4">
                    <div className="flex items-center justify-between pb-2 border-b border-[#232a3a]">
                      <div>
                        <div className="font-semibold text-white">{t('soundModal.attenuationRadiiCoppercube3dRadius')}</div>
                        <p className="text-[10px] text-[#778598] mt-0.5">
                          {t('soundModal.insideTheMinimumRadiusThe')}
                        </p>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-emerald-400 font-medium">{t('soundModal.minDistanceInnerRadiusMaximum')}</label>
                        <span className="font-mono text-emerald-400 font-semibold">{t('soundModal.meters', { value: minDist.toFixed(1) })}</span>
                      </div>
                      <input
                        type="range"
                        min="0.5"
                        max="30"
                        step="0.5"
                        value={minDist}
                        onChange={(e) => setMinDist(Math.min(maxDist - 1, parseFloat(e.target.value)))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-sky-400 font-medium">{t('soundModal.maxDistanceOuterRadiusLimit')}</label>
                        <span className="font-mono text-sky-400 font-semibold">{t('soundModal.meters', { value: maxDist.toFixed(1) })}</span>
                      </div>
                      <input
                        type="range"
                        min="5"
                        max="120"
                        step="1"
                        value={maxDist}
                        onChange={(e) => setMaxDist(Math.max(minDist + 1, parseFloat(e.target.value)))}
                        className="w-full accent-sky-500"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-2 border-t border-[#232a3a]">
                      <div>
                        <label className="text-white block mb-1">{t('soundModal.rolloffCurveFalloffModel')}</label>
                        <select
                          value={attenuation}
                          onChange={(e) => setAttenuation(e.target.value as AttenuationModel)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs"
                        >
                          <option value="inverse">{t('soundModal.inverseDistanceRealisticPhysical')}</option>
                          <option value="linear">{t('soundModal.linearFalloffConstant')}</option>
                          <option value="exponential">{t('soundModal.exponentialSteepFalloff')}</option>
                        </select>
                      </div>

                      <div className="flex items-center pt-4">
                        <label className="flex items-center gap-2 cursor-pointer text-[#c4cfdf]">
                          <input
                            type="checkbox"
                            checked={dopplerEffect}
                            onChange={(e) => setDopplerEffect(e.target.checked)}
                            className="rounded border-[#2c3447] bg-[#1a1f2b] text-emerald-500 focus:ring-0"
                          />
                          <span>{t('soundModal.dopplerEffectVelocity')}</span>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: SOUND FX & FILTERS */}
              {activeTab === 'fx' && (
                <div className="space-y-4">
                  <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg">
                    <h3 className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
                      <Waves className="w-4 h-4 text-cyan-400" />
                      {t('soundModal.irrklangEffectsProcessingSoundfx')}
                    </h3>
                    <p className="text-[11px] text-[#788496]">
                      {t('soundModal.coppercube6AddedSupportFor')}
                    </p>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="text-white font-medium block mb-1.5">{t('soundModal.selectedDspEffect')}</label>
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { id: 'none', label: t('soundModalMsg.noneClean') },
                          { id: 'reverb', label: t('soundModalMsg.reverbRoom') },
                          { id: 'echo', label: t('soundModalMsg.echoCaveEcho') },
                          { id: 'lowpass', label: t('soundModalMsg.lowpassMuffledSubmerged') },
                          { id: 'distortion', label: t('soundModalMsg.distortion') },
                        ].map((fx) => (
                          <button
                            key={fx.id}
                            onClick={() => setSoundFX(fx.id as SoundFXType)}
                            className={`p-2.5 rounded-lg border text-left transition-all ${
                              soundFX === fx.id
                                ? 'bg-cyan-500/20 border-cyan-500/60 text-white'
                                : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                            }`}
                          >
                            <span className="font-semibold text-xs">{fx.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {soundFX !== 'none' && (
                      <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-3">
                        <div>
                          <div className="flex justify-between mb-1">
                            <label className="text-white font-medium">{t('soundModal.fxGainEffectIntensityWet')}</label>
                            <span className="font-mono text-cyan-400 font-semibold">{fxGain}%</span>
                          </div>
                          <input
                            type="range"
                            min="0"
                            max="100"
                            step="5"
                            value={fxGain}
                            onChange={(e) => setFxGain(parseInt(e.target.value))}
                            className="w-full accent-cyan-500"
                          />
                        </div>

                        {soundFX === 'reverb' && (
                          <div>
                            <div className="flex justify-between mb-1">
                              <label className="text-white font-medium">{t('soundModal.roomSize')}</label>
                              <span className="font-mono text-cyan-400 font-semibold">{fxRoomSize}%</span>
                            </div>
                            <input
                              type="range"
                              min="10"
                              max="100"
                              step="5"
                              value={fxRoomSize}
                              onChange={(e) => setFxRoomSize(parseInt(e.target.value))}
                              className="w-full accent-cyan-500"
                            />
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Audio Waveform & Interactive 3D Radar */}
          <div className="w-[42%] flex flex-col bg-[#11141c]">
            {/* Waveform Player Section */}
            <div className="p-3.5 bg-[#141822] border-b border-[#212737] space-y-2.5 shrink-0">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Waves className="w-4 h-4 text-indigo-400" />
                  <span className="font-semibold text-white">{t('soundModal.playerWaveformInspector')}</span>
                </div>
                <span className="text-[10px] font-mono text-[#78879b]">
                  {isPlayingPreview ? t('soundModalMsgTwo.playing') : t('soundModalMsgTwo.stopped')}
                </span>
              </div>

              {/* Waveform Canvas */}
              <div className="h-20 bg-[#0d1017] rounded border border-[#242b3b] overflow-hidden relative">
                <canvas
                  ref={waveformCanvasRef}
                  width={340}
                  height={80}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Progress Bar & Timing */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] font-mono text-[#78879b]">
                  <span>{(trackDuration * playbackProgress).toFixed(1)}s</span>
                  <span>{trackDuration.toFixed(1)}s</span>
                </div>
                <div
                  onClick={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect();
                    const clickX = e.clientX - rect.left;
                    setPlaybackProgress(Math.max(0, Math.min(1, clickX / rect.width)));
                  }}
                  className="h-2 bg-[#1b212f] rounded-full overflow-hidden cursor-pointer relative"
                >
                  <div
                    className="h-full bg-gradient-to-r from-indigo-500 to-sky-400 transition-all"
                    style={{ width: `${playbackProgress * 100}%` }}
                  />
                </div>
              </div>

              {/* Playback Transport Buttons */}
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setIsPlayingPreview(!isPlayingPreview)}
                    className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors flex items-center gap-1.5 text-xs font-semibold px-3"
                  >
                    {isPlayingPreview ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                    <span>{isPlayingPreview ? t('sharedMsgTwo.pause') : t('soundModalMsg.listenToTest')}</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsPlayingPreview(false);
                      setPlaybackProgress(0);
                    }}
                    className="p-2 rounded-lg bg-[#202737] hover:bg-[#2b3449] text-[#93a2b7] hover:text-white transition-colors"
                    title={t('shared.stop')}
                  >
                    <Square className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className={`p-2 rounded-lg transition-colors ${
                      isMuted
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                        : 'bg-[#202737] text-[#93a2b7] hover:text-white'
                    }`}
                    title={isMuted ? t('soundModalMsgTwo.unmute') : t('soundModalMsgTwo.mute')}
                  >
                    {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                  </button>
                  <span className="font-mono text-xs text-white">{isMuted ? t('soundModalMsgTwo.muted') : `${volume}%`}</span>
                </div>
              </div>
            </div>

            {/* 3D Spatial Radar & Distance Simulation */}
            <div className="flex-1 flex flex-col p-3 bg-[#0d1017] overflow-hidden">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-semibold text-white flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-sky-400" />
                  <span>{t('soundModal.n3dAcousticRadarListenerPositioning')}</span>
                </span>
                <span className="text-[10px] font-mono text-emerald-400">
                  {t('soundModal.perceivedVol', { calculatedPerceivedVolume })}
                </span>
              </div>

              {/* Radar Canvas */}
              <div className="flex-1 relative flex items-center justify-center rounded-lg border border-[#212839] overflow-hidden bg-[#0a0d14]">
                <canvas
                  ref={radarCanvasRef}
                  width={340}
                  height={220}
                  className="w-full h-full object-contain"
                />

                {is2D && (
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] flex flex-col items-center justify-center text-center p-4">
                    <Music className="w-8 h-8 text-purple-400 mb-2" />
                    <span className="text-white font-medium text-xs">{t('soundModal.global2dAudioPlayas2dActive')}</span>
                    <span className="text-[11px] text-[#7f8da0] mt-1 max-w-[240px]">
                      {t('soundModal.n2dSoundsPlayUniformlyRegardless')}
                    </span>
                  </div>
                )}
              </div>

              {/* Interactive Listener Slider */}
              {!is2D && (
                <div className="pt-2 space-y-1.5">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#7c8b9e]">{t('soundModal.listenerDistanceSimulation')}</span>
                    <span className="font-mono text-white font-semibold">{listenerDist.toFixed(1)}m</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max={maxDist * 1.3}
                    step="0.5"
                    value={listenerDist}
                    onChange={(e) => setListenerDist(parseFloat(e.target.value))}
                    className="w-full accent-emerald-500 h-1.5"
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-[#13161f] border-t border-[#232938] flex items-center justify-between shrink-0">
          <button
            onClick={() => {
              setVolume(80);
              setPitch(1.0);
              setIs2D(false);
              setPlayMode('loop');
              setMinDist(4.0);
              setMaxDist(25.0);
              setSoundFX('none');
            }}
            className="px-2.5 py-1.5 text-xs text-[#7d8c9e] hover:text-[#d3dce9] transition-colors"
          >
            {t('shared.restoreDefaults')}
          </button>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleClose}
              className="px-4 py-1.5 text-xs font-medium text-[#92a1b5] hover:text-white hover:bg-[#202636] border border-transparent hover:border-[#2f384a] rounded-lg transition-colors"
            >
              {t('shared.cancel')}
            </button>

            {/* AIS-52: modo edição → "Aplicar ao nó"; modo arquivo → "Inserir na Cena"; modo criação → "Inserir Som na Cena" */}
            {isEditing ? (
              <button
                onClick={handleApplyToNode}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-lg shadow-emerald-950 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Headphones className="w-4 h-4" />
                <span>{t('dialogs.sound.applyToNode')}</span>
              </button>
            ) : (
              <button
                onClick={handleInsertSound}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-lg shadow-indigo-950 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Headphones className="w-4 h-4" />
                <span>{soundModalFilePath ? t('soundModalMsg.insertIntoScene') : t('soundModalMsg.insertSoundIntoScene')}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
