import React, { useSyncExternalStore } from 'react';
import { AlertTriangle } from 'lucide-react';
import { globalDocumentManager, type ConflictResolution } from '../../core/documents/DocumentManager';
import { useTranslation } from '../../core/i18n/I18nContext';

/**
 * AIS-18b — conflito por alteração externa. O arquivo mudou fora do editor desde a
 * última leitura/gravação: o usuário decide entre recarregar, manter a versão local
 * ou salvar uma cópia. Nada é sobrescrito sem essa confirmação.
 */
export const DocumentConflictDialog: React.FC = () => {
  const { t } = useTranslation();
  const documents = useSyncExternalStore(
    (cb) => globalDocumentManager.subscribe(cb),
    () => globalDocumentManager.list()
  );
  const conflict = documents.find((d) => d.loadState === 'conflict');
  if (!conflict) return null;

  const resolve = (resolution: ConflictResolution) => {
    void globalDocumentManager.resolveConflict(conflict.documentId, resolution);
  };

  return (
    <div
      role="alertdialog"
      aria-labelledby="doc-conflict-title"
      className="fixed inset-0 z-[60] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 select-none"
    >
      <div className="bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-md text-sm text-[#d4dbe8]">
        <div className="px-5 py-3.5 bg-[#141720] border-b border-[#242b3b] flex items-center gap-3 rounded-t-xl">
          <AlertTriangle className="w-5 h-5 text-amber-400" />
          <h2 id="doc-conflict-title" className="font-semibold text-white text-base">
            {t('documentConflictDialog.fileChangedExternally')}
          </h2>
        </div>
        <div className="px-5 py-4 space-y-2 text-xs text-[#b3bed0]">
          <p>
            <span className="text-white font-medium">{conflict.title}</span> {t('documentConflictDialog.wasModifiedOutsideTheEditor')}
          </p>
          <p>{t('documentConflictDialog.chooseHowToResolve')}</p>
        </div>
        <div className="px-5 pb-4 flex flex-col gap-2">
          <button
            onClick={() => resolve('reload')}
            className="w-full text-left px-3 py-2 rounded bg-[#232a3a] hover:bg-[#2c3345] text-[#dfe4ec]"
          >
            <div className="font-medium">{t('documentConflictDialog.reloadFromDisk')}</div>
            <div className="text-[10px] text-[#8b97a8]">{t('documentConflictDialog.discardsLocalChangesAndUses')}</div>
          </button>
          <button
            onClick={() => resolve('keepLocal')}
            className="w-full text-left px-3 py-2 rounded bg-[#232a3a] hover:bg-[#2c3345] text-[#dfe4ec]"
          >
            <div className="font-medium">{t('documentConflictDialog.keepMyVersion')}</div>
            <div className="text-[10px] text-[#8b97a8]">{t('documentConflictDialog.theNextSaveOverwritesThe')}</div>
          </button>
          <button
            onClick={() => resolve('saveCopy')}
            className="w-full text-left px-3 py-2 rounded bg-[#232a3a] hover:bg-[#2c3345] text-[#dfe4ec]"
          >
            <div className="font-medium">{t('documentConflictDialog.saveCopy')}</div>
            <div className="text-[10px] text-[#8b97a8]">{t('documentConflictDialog.savesMyVersionToA')}</div>
          </button>
        </div>
      </div>
    </div>
  );
};
