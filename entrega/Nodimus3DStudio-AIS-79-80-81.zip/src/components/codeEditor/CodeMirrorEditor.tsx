import React, { useState, useMemo, useCallback, useEffect } from 'react';
import CodeMirror, { Extension } from '@uiw/react-codemirror';
import { javascript } from '@codemirror/lang-javascript';
import { json } from '@codemirror/lang-json';
import { xml } from '@codemirror/lang-xml';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { markdown } from '@codemirror/lang-markdown';
import { oneDark } from '@codemirror/theme-one-dark';
import { linter, lintGutter, type Diagnostic } from '@codemirror/lint';
import { checkSyntax, isCheckableExtension, positionOf } from '../../core/scripts/syntaxCheck';
import { useTranslation } from '../../core/i18n/I18nContext';
import {
  Save,
  Check,
  Play,
  RotateCcw,
  Copy,
  Search,
  Maximize2,
  Minimize2,
  FileCode,
  FileJson,
  FileText,
  Code,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  WrapText,
  Type,
} from 'lucide-react';

export interface CodeEditorProps {
  filePath: string;
  initialContent: string;
  /** Retorne `false` quando o salvamento foi bloqueado (ex.: conflito externo): o editor segue "sujo". */
  onSave: (path: string, content: string) => void | boolean;
  /** AIS-18b: rascunho em edição (documento sujo/limpo no DocumentManager). */
  onDraftChange?: (path: string, content: string) => void;
  /** AIS-18b: arquivo com alterações ainda não salvas ao montar (rascunho restaurado). */
  initialDirty?: boolean;
  height?: string;
  readOnly?: boolean;
  className?: string;
  showToolbar?: boolean;
  onToggleMaximize?: () => void;
  isMaximized?: boolean;
}

export const CodeMirrorEditor: React.FC<CodeEditorProps> = ({
  filePath,
  initialContent,
  onSave,
  onDraftChange,
  initialDirty = false,
  height = '100%',
  readOnly = false,
  className = '',
  showToolbar = true,
  onToggleMaximize,
  isMaximized = false,
}) => {
  const { t } = useTranslation();
  const [content, setContent] = useState<string>(initialContent);
  const [isDirty, setIsDirty] = useState<boolean>(initialDirty);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [fontSize, setFontSize] = useState<number>(13);
  const [lineWrap, setLineWrap] = useState<boolean>(false);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [validationSuccess, setValidationSuccess] = useState<string | null>(null);
  const [cursorPos, setCursorPos] = useState<{ line: number; col: number }>({ line: 1, col: 1 });

  // Sync content when filePath or initialContent changes from outside
  useEffect(() => {
    setContent((prev) => (prev === initialContent ? prev : initialContent));
    setIsDirty(initialDirty);
    setValidationError(null);
    setValidationSuccess(null);
  }, [filePath, initialContent]);

  // Determine file extension and language mode
  const extension = useMemo(() => {
    const parts = filePath.split('.');
    return parts.length > 1 ? parts.pop()?.toLowerCase() || '' : '';
  }, [filePath]);

  const languageExtensions = useMemo((): Extension[] => {
    switch (extension) {
      case 'ts':
      case 'tsx':
        return [javascript({ jsx: true, typescript: true })];
      case 'js':
      case 'jsx':
      case 'mjs':
      case 'cjs':
        return [javascript({ jsx: true })];
      case 'json':
        return [json()];
      case 'xml':
      case 'svg':
        return [xml()];
      case 'html':
      case 'htm':
        return [html()];
      case 'css':
        return [css()];
      case 'md':
      case 'markdown':
        return [markdown()];
      default:
        return [];
    }
  }, [extension]);

  // AIS-28b: erros de sintaxe ficam no próprio editor (sublinhado + gutter); nada é executado
  const lintExtensions = useMemo((): Extension[] => {
    if (!isCheckableExtension(extension)) return [];
    return [
      lintGutter(),
      linter((view): Diagnostic[] =>
        checkSyntax(view.state.doc.toString(), extension).map((issue) => ({
          from: Math.min(issue.from, view.state.doc.length),
          to: Math.min(Math.max(issue.to, issue.from + 1), view.state.doc.length),
          severity: 'error',
          message: issue.message,
        }))
      ),
    ];
  }, [extension]);

  // Handle Save
  const handleSave = useCallback(() => {
    const result = onSave(filePath, content);
    if (result === false) return; // bloqueado: continua sujo e sem "Salvo!"
    setIsDirty(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  }, [filePath, content, onSave]);

  // Format Code
  const handleFormat = useCallback(() => {
    try {
      if (extension === 'json') {
        const parsed = JSON.parse(content);
        const formatted = JSON.stringify(parsed, null, 2);
        setContent(formatted);
        setIsDirty(true);
        setValidationSuccess(t('codeMirrorEditorMsg.jsonFormattedAndValidatedSuccessfully'));
        setValidationError(null);
        setTimeout(() => setValidationSuccess(null), 3000);
        return;
      }
      if (extension === 'xml' || extension === 'svg') {
        // Pretty print XML
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(content, 'text/xml');
        const parseError = xmlDoc.getElementsByTagName('parsererror');
        if (parseError.length > 0) {
          throw new Error(parseError[0].textContent || t('codeMirrorEditorMsg.xmlSyntaxError'));
        }
        // Basic format
        let formatted = '';
        let indent = 0;
        const pad = (count: number) => '  '.repeat(count);
        content.split(/>\s*</).forEach((element) => {
          if (element.match(/^\/\w/)) indent--;
          formatted += `${pad(indent)}<${element}>\r\n`;
          if (element.match(/^<?\w[^>]*[^\/]$/) && !element.startsWith('input')) indent++;
        });
        setValidationSuccess(t('codeMirrorEditorMsg.validXmlSyntax'));
        setValidationError(null);
        setTimeout(() => setValidationSuccess(null), 3000);
        return;
      }
      setValidationSuccess(t('codeMirrorEditorMsg.fileValidated'));
      setTimeout(() => setValidationSuccess(null), 2500);
    } catch (err: any) {
      setValidationError(err.message || t('codeMirrorEditorMsg.errorValidatingSyntax'));
      setValidationSuccess(null);
    }
  }, [extension, content, t]);

  // Validate Code
  const handleValidate = useCallback(() => {
    try {
      if (extension === 'json') {
        JSON.parse(content);
        setValidationSuccess(t('codeMirrorEditorMsg.json100Valid'));
        setValidationError(null);
        setTimeout(() => setValidationSuccess(null), 3000);
      } else if (extension === 'xml') {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(content, 'text/xml');
        const parseError = xmlDoc.getElementsByTagName('parsererror');
        if (parseError.length > 0) {
          throw new Error(parseError[0].textContent || t('codeMirrorEditorMsg.invalidXmlSyntax'));
        }
        setValidationSuccess(t('codeMirrorEditorMsg.wellFormedAndValidXml'));
        setValidationError(null);
        setTimeout(() => setValidationSuccess(null), 3000);
      } else if (isCheckableExtension(extension)) {
        // AIS-28b: checagem pelo parser do CodeMirror (nunca new Function/eval)
        const issues = checkSyntax(content, extension);
        if (issues.length > 0) {
          const where = positionOf(content, issues[0].from);
          throw new Error(`${issues[0].message} na linha ${where.line}, coluna ${where.column}`);
        }
        setValidationSuccess(t('codeMirrorEditorMsg.noSyntaxErrorsDetected'));
        setValidationError(null);
        setTimeout(() => setValidationSuccess(null), 3000);
      } else {
        setValidationSuccess(t('codeMirrorEditorMsg.plainTextFile'));
        setTimeout(() => setValidationSuccess(null), 2000);
      }
    } catch (err: any) {
      setValidationError(err.message || t('codeMirrorEditorMsg.syntaxErrorFound'));
      setValidationSuccess(null);
    }
  }, [extension, content, t]);

  // Copy All
  const handleCopyAll = () => {
    navigator.clipboard.writeText(content);
    setValidationSuccess(t('codeMirrorEditorMsg.codeCopiedToTheClipboard'));
    setTimeout(() => setValidationSuccess(null), 2500);
  };

  // Keyboard shortcut Ctrl+S / Cmd+S
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        handleSave();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleSave]);

  const getLanguageBadge = () => {
    switch (extension) {
      case 'ts':
      case 'tsx':
        return <span className="text-blue-400 font-mono font-medium">{t('codeMirrorEditor.typescript')}</span>;
      case 'js':
      case 'jsx':
        return <span className="text-amber-300 font-mono font-medium">{t('codeMirrorEditor.javascript')}</span>;
      case 'json':
        return <span className="text-emerald-400 font-mono font-medium">JSON</span>;
      case 'xml':
      case 'svg':
        return <span className="text-orange-400 font-mono font-medium">XML</span>;
      case 'html':
        return <span className="text-rose-400 font-mono font-medium">{t('codeMirrorEditor.html')}</span>;
      case 'css':
        return <span className="text-cyan-400 font-mono font-medium">CSS</span>;
      case 'md':
        return <span className="text-indigo-400 font-mono font-medium">{t('codeMirrorEditor.markdown')}</span>;
      default:
        return <span className="text-[#9ca7b7] font-mono font-medium">{extension ? extension.toUpperCase() : t('codeMirrorEditorMsg.plainText')}</span>;
    }
  };

  const linesCount = useMemo(() => content.split('\n').length, [content]);

  return (
    <div className={`flex flex-col bg-[#141822] text-[#dfe4ec] border border-[#2c3345] rounded-sm overflow-hidden ${className}`}>
      {/* Code Editor Header & Action Bar */}
      {showToolbar && (
        <div className="h-9 px-3 bg-[#1e232f] border-b border-[#2c3345] flex items-center justify-between shrink-0 select-none">
          {/* File path & Dirty Indicator */}
          <div className="flex items-center gap-2 min-w-0">
            <FileCode className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-mono text-xs text-white truncate max-w-[260px] md:max-w-[400px]">
              {filePath}
            </span>
            {isDirty && (
              <span className="px-1.5 py-0.2 text-[10px] rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {t('codeMirrorEditor.modified')}
              </span>
            )}
          </div>

          {/* Actions & Utilities */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Save Button */}
            <button
              onClick={handleSave}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-all ${
                saveSuccess
                  ? 'bg-emerald-600 text-white'
                  : isDirty
                  ? 'bg-[#4982ea] hover:bg-[#3b71d4] text-white shadow-sm'
                  : 'bg-[#272e3d] hover:bg-[#323b4e] text-[#c2cbdb]'
              }`}
              title={t('codeMirrorEditor.saveChangesCtrlS')}
            >
              {saveSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-white" />
                  <span>{t('codeMirrorEditor.saved')}</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>{t('shared.save')}</span>
                </>
              )}
            </button>

            {/* Validate / Format */}
            <button
              onClick={handleFormat}
              className="flex items-center gap-1 px-2 py-1 rounded bg-[#272e3d] hover:bg-[#323b4e] text-[#c2cbdb] hover:text-white transition-colors text-xs"
              title={t('codeMirrorEditor.formatAndCheckSyntax')}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">{t('codeMirrorEditor.format')}</span>
            </button>

            {/* Executar: desabilitado até o sandbox de scripts (AIS-79); scripts só rodam pela ação Executar Script */}
            {(extension === 'js' || extension === 'ts') && (
              <button
                disabled
                aria-disabled="true"
                className="flex items-center gap-1 px-2 py-1 rounded bg-[#272e3d] text-[#485368] cursor-not-allowed text-xs"
                title={t('codeMirrorEditor.comingSoonScriptsRunOnly')}
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span className="hidden sm:inline">{t('codeMirrorEditor.test')}</span>
              </button>
            )}

            {/* Copy All */}
            <button
              onClick={handleCopyAll}
              className="p-1.5 rounded hover:bg-[#2c3345] text-[#8b97a8] hover:text-white transition-colors"
              title={t('codeMirrorEditor.copyAllContent')}
            >
              <Copy className="w-3.5 h-3.5" />
            </button>

            {/* Word wrap toggle */}
            <button
              onClick={() => setLineWrap(!lineWrap)}
              className={`p-1.5 rounded transition-colors ${
                lineWrap ? 'bg-[#2c3345] text-blue-400' : 'text-[#8b97a8] hover:bg-[#2c3345] hover:text-white'
              }`}
              title={t('codeMirrorEditor.toggleAutomaticLineWrapping')}
            >
              <WrapText className="w-3.5 h-3.5" />
            </button>

            {/* Font size control */}
            <div className="flex items-center bg-[#181c25] rounded border border-[#2c3345] px-1">
              <button
                onClick={() => setFontSize((s) => Math.max(11, s - 1))}
                className="px-1 text-[10px] text-[#8b97a8] hover:text-white"
                title={t('codeMirrorEditor.decreaseFont')}
              >
                -
              </button>
              <span className="text-[10px] font-mono px-1 text-[#dfe4ec]">{fontSize}px</span>
              <button
                onClick={() => setFontSize((s) => Math.min(20, s + 1))}
                className="px-1 text-[10px] text-[#8b97a8] hover:text-white"
                title={t('codeMirrorEditor.increaseFont')}
              >
                +
              </button>
            </div>

            {/* Maximize / Restore */}
            {onToggleMaximize && (
              <button
                onClick={onToggleMaximize}
                className="p-1.5 rounded hover:bg-[#2c3345] text-[#8b97a8] hover:text-white transition-colors"
                title={isMaximized ? t('sharedMsg.restoreSize') : t('codeMirrorEditorMsg.maximizeEditor')}
              >
                {isMaximized ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              </button>
            )}
          </div>
        </div>
      )}

      {/* Validation Banner if any error or success */}
      {validationError && (
        <div className="px-3 py-1.5 bg-rose-950/60 border-b border-rose-800/40 text-xs text-rose-300 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span className="font-mono text-[11px] truncate">{validationError}</span>
          </div>
          <button
            onClick={() => setValidationError(null)}
            className="text-rose-400 hover:text-white text-xs px-1"
          >
            ×
          </button>
        </div>
      )}

      {validationSuccess && (
        <div className="px-3 py-1 bg-emerald-950/60 border-b border-emerald-800/40 text-xs text-emerald-300 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-[11px]">{validationSuccess}</span>
          </div>
          <button
            onClick={() => setValidationSuccess(null)}
            className="text-emerald-400 hover:text-white text-xs px-1"
          >
            ×
          </button>
        </div>
      )}

      {/* CodeMirror Surface */}
      <div className="flex-1 overflow-auto bg-[#141822] relative font-mono text-[13px]">
        <CodeMirror
          value={content}
          height={height}
          theme={oneDark}
          extensions={[...languageExtensions, ...lintExtensions]}
          readOnly={readOnly}
          basicSetup={{
            lineNumbers: true,
            highlightActiveLineGutter: true,
            highlightSpecialChars: true,
            history: true,
            foldGutter: true,
            drawSelection: true,
            dropCursor: true,
            allowMultipleSelections: true,
            indentOnInput: true,
            syntaxHighlighting: true,
            bracketMatching: true,
            closeBrackets: true,
            autocompletion: true,
            rectangularSelection: true,
            crosshairCursor: true,
            highlightActiveLine: true,
            highlightSelectionMatches: true,
            closeBracketsKeymap: true,
            defaultKeymap: true,
            searchKeymap: true,
            historyKeymap: true,
            foldKeymap: true,
            completionKeymap: true,
            lintKeymap: true,
          }}
          onChange={(val, viewUpdate) => {
            setContent(val);
            setIsDirty(true);
            onDraftChange?.(filePath, val);
            const head = viewUpdate.state.selection.main.head;
            const line = viewUpdate.state.doc.lineAt(head);
            setCursorPos({ line: line.number, col: head - line.from + 1 });
          }}
          onUpdate={(viewUpdate) => {
            if (viewUpdate.selectionSet) {
              const head = viewUpdate.state.selection.main.head;
              const line = viewUpdate.state.doc.lineAt(head);
              setCursorPos({ line: line.number, col: head - line.from + 1 });
            }
          }}
          style={{
            fontSize: `${fontSize}px`,
          }}
          className={lineWrap ? 'cm-line-wrap' : ''}
        />
      </div>

      {/* Editor Status Bar */}
      <div className="h-6 px-3 bg-[#181c25] border-t border-[#2c3345] flex items-center justify-between text-[11px] text-[#8b97a8] shrink-0 font-mono select-none">
        <div className="flex items-center gap-3">
          <span>{getLanguageBadge()}</span>
          <span>{t('codeMirrorEditor.lines', { linesCount })}</span>
          <span>{t('codeMirrorEditor.characters', { length: content.length })}</span>
          <span>{t('codeMirrorEditor.lnCol', { line: cursorPos.line, col: cursorPos.col })}</span>
        </div>

        <div className="flex items-center gap-3">
          <span>{t('codeMirrorEditor.utf8')}</span>
          <span>LF</span>
          <span className={isDirty ? 'text-amber-400' : 'text-emerald-400'}>
            {isDirty ? t('codeMirrorEditorMsg.unsaved') : t('codeMirrorEditorMsg.synced')}
          </span>
        </div>
      </div>
    </div>
  );
};
