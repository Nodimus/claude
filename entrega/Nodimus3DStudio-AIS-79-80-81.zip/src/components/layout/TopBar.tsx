import React, { useState, useRef, useEffect, useSyncExternalStore } from 'react';
import { useEditor, WorkspaceMode } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { useTranslation } from '../../core/i18n/I18nContext';
import { LANGUAGES, LANGUAGE_NAMES, isLanguage } from '../../core/i18n';
import { ProjectStorage } from '../../core/projectStorage';
import { globalCommandManager } from '../../core/commandManager';
import { globalDocumentManager } from '../../core/documents/DocumentManager';
import {
  Play,
  Square,
  Pause,
  Film,
  RotateCcw,
  RotateCw,
  Settings,
  FolderOpen,
  Save,
  Download,
  Plus,
  HelpCircle,
  Code2,
  Box,
  Layers,
  Sparkles,
  Mountain,
  Trees,
  CloudFog,
  Headphones,
  Upload,
  Sliders,
  Terminal,
  FileCode,
  Palette,
  Puzzle,
} from 'lucide-react';

export const TopBar: React.FC = () => {
  const { t, language, setLanguage } = useTranslation();
  // AIS-03f: Workspace mode, dock controls and modal toggles migrated to canonical Zustand EditorStore
  const workspaceMode             = useEditorStore((s) => s.workspaceMode);
  const setWorkspaceMode          = useEditorStore((s) => s.setWorkspaceMode);
  const isBottomOpen              = useEditorStore((s) => s.isBottomOpen);
  const setIsBottomOpen           = useEditorStore((s) => s.setIsBottomOpen);
  const setBottomTab              = useEditorStore((s) => s.setBottomTab);

  // Modal dialog toggles from Zustand
  const setIsPostProcessingOpen   = useEditorStore((s) => s.setIsPostProcessingOpen);
  const setIsTerrainEditorOpen    = useEditorStore((s) => s.setIsTerrainEditorOpen);
  const setIsTreeEditorOpen       = useEditorStore((s) => s.setIsTreeEditorOpen);
  const setIsFogModalOpen         = useEditorStore((s) => s.setIsFogModalOpen);
  const setIsSoundModalOpen       = useEditorStore((s) => s.setIsSoundModalOpen);
  const setIsParticleModalOpen    = useEditorStore((s) => s.setIsParticleModalOpen);
  const setIsAssetImportModalOpen = useEditorStore((s) => s.setIsAssetImportModalOpen);
  const setIsProjectSettingsOpen  = useEditorStore((s) => s.setIsProjectSettingsOpen);
  const setIsProjectManagerOpen   = useEditorStore((s) => s.setIsProjectManagerOpen);
  const setIsCreateNodeModalOpen  = useEditorStore((s) => s.setIsCreateNodeModalOpen);
  const setIsScriptEditorModalOpen= useEditorStore((s) => s.setIsScriptEditorModalOpen);
  const setIsTexturePreviewOpen   = useEditorStore((s) => s.setIsTexturePreviewOpen);
  const isExtensionsPanelOpen     = useEditorStore((s) => s.isExtensionsPanelOpen);
  const setIsExtensionsPanelOpen  = useEditorStore((s) => s.setIsExtensionsPanelOpen);
  const setIsVideoEditorOpen      = useEditorStore((s) => s.setIsVideoEditorOpen);
  const setIsSpriteEditorOpen     = useEditorStore((s) => s.setIsSpriteEditorOpen);

  // AIS-18: rótulos do próximo Undo/Redo (tooltip), reativos ao histórico do CommandManager
  useSyncExternalStore(
    (cb) => globalCommandManager.subscribe(cb),
    () => globalCommandManager.getVersion()
  );
  // AIS-18b: marcador de alterações não salvas (dirty por checkpoint do DocumentManager)
  const openDocuments = useSyncExternalStore(
    (cb) => globalDocumentManager.subscribe(cb),
    () => globalDocumentManager.list()
  );
  const sceneDirty = openDocuments.some((d) => d.kind === 'scene' && d.dirty);
  const undoLabel = globalCommandManager.getUndoLabel();
  const redoLabel = globalCommandManager.getRedoLabel();

  // Facade consumption for project, activeScene, undo/redo, play controls
  const {
    project,
    activeScene,
    isPlaying,
    isPaused,
    canUndo,
    canRedo,
    undo,
    redo,
    playProject,
    playScene,
    playMode,
    pauseGame,
    stopGame,
    saveCurrentScene,
    createNewScene,
  } = useEditor();

  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setActiveMenu(null);
      }
    };
    window.addEventListener('mousedown', handleClickOutside);
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleMenuClick = (menu: string) => {
    setActiveMenu(activeMenu === menu ? null : menu);
  };

  return (
    <header
      ref={menuRef}
      className="h-10 bg-[var(--gl-bg-strong)] border-b border-[var(--gl-border)] px-2 flex items-center justify-between select-none text-xs text-[var(--gl-text)] z-40 relative"
    >
      {/* Left Zone: Brand & Menu bar */}
      <div className="flex items-center gap-1">
        {/* Brand mark */}
        <div
          onClick={() => setIsProjectManagerOpen(true)}
          className="flex items-center gap-1.5 px-2 py-1 rounded bg-[var(--gl-panel-alt)] hover:bg-[var(--gl-accent-bg)] cursor-pointer mr-2 border border-[var(--gl-border-subtle)] transition-colors"
          title={t('topBar.switchProject')}
        >
          <div className="w-4 h-4 rounded bg-[var(--gl-accent)] flex items-center justify-center font-bold text-[10px] text-white">
            N
          </div>
          <span className="font-semibold text-[13px] tracking-wide text-white">{t('topBarUi.nodimus')}</span>
          <span className="text-[var(--gl-text-muted)] text-[11px] font-normal truncate max-w-[110px]">
            {project.name}
          </span>
        </div>

        {/* Menu Dropdowns */}
        <div className="flex items-center space-x-0.5">
          {/* Project Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('project')}
              className={`px-2 py-1 rounded hover:bg-[#2c3345] transition-colors ${
                activeMenu === 'project' ? 'bg-[#2c3345] text-white' : 'text-[#c2cbdb]'
              }`}
            >
              {t('menus.project')}
            </button>
            {activeMenu === 'project' && (
              <div className="absolute top-full left-0 mt-0.5 w-48 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50">
                <button
                  onClick={() => {
                    setIsProjectSettingsOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Settings className="w-3.5 h-3.5 text-[#8b97a8]" /> {t('projectMenu.settings')}
                  </span>
                </button>
                <button
                  onClick={() => {
                    setIsExtensionsPanelOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2 text-indigo-300">
                    <Puzzle className="w-3.5 h-3.5 text-indigo-400" /> {t('projectMenu.extensions')}
                  </span>
                </button>
                <button
                  onClick={() => {
                    setIsProjectManagerOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <FolderOpen className="w-3.5 h-3.5 text-[#8b97a8]" /> {t('projectMenu.manager')}
                  </span>
                </button>
                <div className="my-1 border-t border-[#2c3345]" />
                <button
                  onClick={() => {
                    saveCurrentScene();
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Save className="w-3.5 h-3.5 text-[#8b97a8]" /> {t('projectMenu.save')}
                  </span>
                  <span className="text-[10px] text-[#8b97a8]">Ctrl+S</span>
                </button>
                <button
                  onClick={async () => {
                    setActiveMenu(null);
                    await ProjectStorage.exportProjectAsNodimusFile(project);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Download className="w-3.5 h-3.5 text-[#8b97a8]" /> {t('projectMenu.export')}
                  </span>
                </button>
              </div>
            )}
          </div>

          {/* Scene Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('scene')}
              className={`px-2 py-1 rounded hover:bg-[#2c3345] transition-colors ${
                activeMenu === 'scene' ? 'bg-[#2c3345] text-white' : 'text-[#c2cbdb]'
              }`}
            >
              {t('menus.scene')}
            </button>
            {activeMenu === 'scene' && (
              <div className="absolute top-full left-0 mt-0.5 w-56 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50">
                <button
                  onClick={() => {
                    createNewScene('3D');
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Plus className="w-3.5 h-3.5 text-emerald-400" /> {t('sceneMenu.new3d')}
                </button>
                <button
                  onClick={() => {
                    createNewScene('Empty');
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Box className="w-3.5 h-3.5 text-[#8b97a8]" /> {t('sceneMenu.newEmpty')}
                </button>
                <button
                  onClick={() => {
                    saveCurrentScene();
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Save className="w-3.5 h-3.5 text-[#8b97a8]" /> {t('sceneMenu.save')}
                  </span>
                  <span className="text-[10px] text-[#8b97a8]">Ctrl+S</span>
                </button>

                <div className="my-1 border-t border-[#2c3345]" />
                <div className="px-3 py-1 text-[10px] font-semibold text-[#64748b] uppercase tracking-wider">
                  {t('sceneMenu.environmentHeading')}
                </div>

                <button
                  onClick={() => {
                    setIsPostProcessingOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  <span className="text-[#dfe4ec]">{t('sceneMenu.postProcessing')}</span>
                </button>
                <button
                  onClick={() => {
                    setIsFogModalOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <CloudFog className="w-3.5 h-3.5 text-sky-400" />
                  <span className="text-[#dfe4ec]">{t('sceneMenu.fog')}</span>
                </button>
                <button
                  onClick={() => {
                    setIsSoundModalOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Headphones className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="text-[#dfe4ec]">{t('sceneMenu.sound')}</span>
                </button>
              </div>
            )}
          </div>

          {/* Edit Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('edit')}
              className={`px-2 py-1 rounded hover:bg-[#2c3345] transition-colors ${
                activeMenu === 'edit' ? 'bg-[#2c3345] text-white' : 'text-[#c2cbdb]'
              }`}
            >
              {t('menus.edit')}
            </button>
            {activeMenu === 'edit' && (
              <div className="absolute top-full left-0 mt-0.5 w-44 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50">
                <button
                  disabled={!canUndo}
                  title={undoLabel ? t('editMenu.undoTooltip', { label: undoLabel }) : undefined}
                  onClick={() => {
                    undo();
                    setActiveMenu(null);
                  }}
                  className={`w-full text-left px-3 py-1.5 flex items-center justify-between ${
                    canUndo ? 'hover:bg-[#2c3345] text-[#dfe4ec]' : 'text-[#586377] cursor-not-allowed'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <RotateCcw className="w-3.5 h-3.5" /> {t('editMenu.undo')}
                  </span>
                  <span className="text-[10px]">Ctrl+Z</span>
                </button>
                <button
                  disabled={!canRedo}
                  title={redoLabel ? t('editMenu.redoTooltip', { label: redoLabel }) : undefined}
                  onClick={() => {
                    redo();
                    setActiveMenu(null);
                  }}
                  className={`w-full text-left px-3 py-1.5 flex items-center justify-between ${
                    canRedo ? 'hover:bg-[#2c3345] text-[#dfe4ec]' : 'text-[#586377] cursor-not-allowed'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <RotateCw className="w-3.5 h-3.5" /> {t('editMenu.redo')}
                  </span>
                  <span className="text-[10px]">Ctrl+Y</span>
                </button>
              </div>
            )}
          </div>

          {/* Debug Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('debug')}
              className={`px-2 py-1 rounded hover:bg-[#2c3345] transition-colors ${
                activeMenu === 'debug' ? 'bg-[#2c3345] text-white' : 'text-[#c2cbdb]'
              }`}
            >
              {t('menus.debug')}
            </button>
            {activeMenu === 'debug' && (
              <div className="absolute top-full left-0 mt-0.5 w-52 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50">
                <button
                  onClick={() => {
                    playProject();
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Play className="w-3.5 h-3.5 text-emerald-400" /> {t('debugMenu.playProject')}
                  </span>
                  <span className="text-[10px] text-[#8b97a8]">F5</span>
                </button>
                <button
                  onClick={() => {
                    playScene();
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Film className="w-3.5 h-3.5 text-sky-400" /> {t('debugMenu.playScene')}
                  </span>
                  <span className="text-[10px] text-[#8b97a8]">F6</span>
                </button>
                <button
                  disabled={!isPlaying}
                  onClick={() => {
                    stopGame();
                    setActiveMenu(null);
                  }}
                  className={`w-full text-left px-3 py-1.5 flex items-center justify-between ${
                    isPlaying ? 'hover:bg-[#2c3345] text-[#dfe4ec]' : 'text-[#485368] cursor-not-allowed'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <Square className="w-3.5 h-3.5 text-rose-400" /> {t('debugMenu.stop')}
                  </span>
                  <span className="text-[10px] text-[#8b97a8]">F8</span>
                </button>
                <div className="my-1 border-t border-[#2c3345]" />
                <button
                  onClick={() => {
                    setIsBottomOpen(true);
                    setBottomTab('debugger');
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Terminal className="w-3.5 h-3.5 text-[#8b97a8]" /> {t('debugMenu.openMonitor')}
                </button>
              </div>
            )}
          </div>

          {/* Editor Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('editor')}
              className={`px-2 py-1 rounded hover:bg-[#2c3345] transition-colors ${
                activeMenu === 'editor' ? 'bg-[#2c3345] text-white' : 'text-[#c2cbdb]'
              }`}
            >
              {t('menus.editor')}
            </button>
            {activeMenu === 'editor' && (
              <div className="absolute top-full left-0 mt-0.5 w-64 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50">
                <div className="px-3 py-1 text-[10px] font-semibold text-[#64748b] uppercase tracking-wider">
                  {t('editorMenu.codeHeading')}
                </div>
                <button
                  onClick={() => {
                    setWorkspaceMode('Script');
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <FileCode className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.codeMode')}</span>
                </button>
                <button
                  onClick={() => {
                    setIsScriptEditorModalOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Code2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.scriptModal')}</span>
                </button>
                <button
                  onClick={() => {
                    setWorkspaceMode('VisualLogic');
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.visualLogic')}</span>
                </button>

                <div className="my-1 border-t border-[#2c3345]" />
                <div className="px-3 py-1 text-[10px] font-semibold text-[#64748b] uppercase tracking-wider">
                  {t('editorMenu.terrainHeading')}
                </div>
                <button
                  onClick={() => {
                    setIsTerrainEditorOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Mountain className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.terrain')}</span>
                </button>
                <button
                  onClick={() => {
                    setIsTreeEditorOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Trees className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.tree')}</span>
                </button>
                <button
                  onClick={() => {
                    setIsParticleModalOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.particles')}</span>
                </button>
                <button
                  onClick={() => {
                    setIsAssetImportModalOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Upload className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.importAsset')}</span>
                </button>

                <div className="my-1 border-t border-[#2c3345]" />
                <div className="px-3 py-1 text-[10px] font-semibold text-[#64748b] uppercase tracking-wider">
                  {t('editorMenu.studiosHeading')}
                </div>
                <button
                  onClick={() => {
                    setIsTexturePreviewOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Palette className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.texture')}</span>
                </button>
                <button
                  onClick={() => {
                    setIsVideoEditorOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Film className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.video')}</span>
                </button>
                <button
                  onClick={() => {
                    setIsSpriteEditorOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Layers className="w-3.5 h-3.5 text-sky-400" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.sprite')}</span>
                </button>
                <button
                  onClick={() => {
                    setIsExtensionsPanelOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Puzzle className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.extensions')}</span>
                </button>

                <div className="my-1 border-t border-[#2c3345]" />
                <button
                  onClick={() => {
                    setIsCreateNodeModalOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Plus className="w-3.5 h-3.5 text-[#8b97a8]" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.createNode')}</span>
                </button>
                <button
                  onClick={() => {
                    setIsBottomOpen(!isBottomOpen);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Sliders className="w-3.5 h-3.5 text-[#8b97a8]" />
                  <span className="text-[#dfe4ec]">{t('editorMenu.toggleOutput')}</span>
                </button>
              </div>
            )}
          </div>

          {/* Help Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('help')}
              className={`px-2 py-1 rounded hover:bg-[#2c3345] transition-colors ${
                activeMenu === 'help' ? 'bg-[#2c3345] text-white' : 'text-[#c2cbdb]'
              }`}
            >
              {t('menus.help')}
            </button>
            {activeMenu === 'help' && (
              <div className="absolute top-full left-0 mt-0.5 w-52 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50">
                <div className="px-3 py-2 text-[11px] text-[#8b97a8] border-b border-[#2c3345]">
                  <strong className="text-white block">{t('helpMenu.title')}</strong>
                  {t('helpMenu.description')}
                </div>
                <div className="px-3 py-2 text-[11px] text-[#9ca7b7]">
                  {t('helpMenu.shortcuts')}
                  <div className="mt-1 space-y-0.5 font-mono text-[10px]">
                    <div>{t('helpMenu.shortcutPlay')}</div>
                    <div>{t('helpMenu.shortcutStop')}</div>
                    <div>{t('helpMenu.shortcutSave')}</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Center Zone: Workspace Mode Switcher (3D Scene | Visual Logic | Script) */}
      <div className="flex items-center bg-[var(--gl-bg)] p-0.5 rounded-md border border-[var(--gl-border)]">
        <button
          onClick={() => setWorkspaceMode('3D')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-all ${
            workspaceMode === '3D'
              ? 'bg-[var(--gl-accent)] text-white shadow-sm'
              : 'text-[var(--gl-text-muted)] hover:text-[var(--gl-text)] hover:bg-[var(--gl-panel)]'
          }`}
          title={t('workspaces.scene3dTooltip')}
        >
          <Box className="w-3.5 h-3.5" />
          <span>{t('workspaces.scene3d')}</span>
        </button>

        <button
          onClick={() => setWorkspaceMode('VisualLogic')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-all ${
            workspaceMode === 'VisualLogic'
              ? 'bg-[var(--gl-accent)] text-white shadow-sm'
              : 'text-[var(--gl-text-muted)] hover:text-[var(--gl-text)] hover:bg-[var(--gl-panel)]'
          }`}
          title={t('workspaces.visualLogicTooltip')}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>{t('workspaces.visualLogic')}</span>
        </button>

        <button
          onClick={() => setWorkspaceMode('Script')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-all ${
            workspaceMode === 'Script'
              ? 'bg-[var(--gl-accent)] text-white shadow-sm'
              : 'text-[var(--gl-text-muted)] hover:text-[var(--gl-text)] hover:bg-[var(--gl-panel)]'
          }`}
          title={t('workspaces.scriptTooltip')}
        >
          <FileCode className="w-3.5 h-3.5 text-blue-400" />
          <span>{t('workspaces.script')}</span>
        </button>
      </div>

      {/* Right Zone: Play / Pause / Stop Simulation Controls */}
      <div className="flex items-center gap-1">
        {/* AIS-80: seletor PROVISÓRIO de idioma (migra para a aba Geral das Preferências no AIS-82) */}
        <select
          value={language}
          onChange={(e) => isLanguage(e.target.value) && setLanguage(e.target.value)}
          title={t('topBar.languageTooltip')}
          aria-label={t('common.language')}
          className="h-6 px-1 mr-1 rounded bg-[var(--gl-panel-alt)] border border-[var(--gl-border-subtle)] text-[11px] text-[var(--gl-text)] outline-none"
        >
          {LANGUAGES.map((code) => (
            <option key={code} value={code}>
              {LANGUAGE_NAMES[code]}
            </option>
          ))}
        </select>

        {/* Current scene name indicator */}
        <div className="px-2 py-0.5 text-[11px] text-[var(--gl-text-muted)] hidden md:block max-w-[150px] truncate">
          {activeScene.name}.scene{sceneDirty ? t('topBar.unsavedMark') : ''}
        </div>

        {/* Play Project (F5) */}
        <button
          onClick={playProject}
          className={`p-1.5 rounded transition-all flex items-center justify-center ${
            isPlaying && !isPaused && playMode === 'project'
              ? 'bg-emerald-600/30 text-emerald-400 border border-emerald-500/40'
              : 'hover:bg-[var(--gl-hover-bg)] text-[#b3bed0] hover:text-emerald-400'
          }`}
          title={t('playControls.playProject')}
        >
          <Play className="w-4 h-4 fill-current" />
        </button>

        {/* Play Scene (F6) */}
        <button
          onClick={playScene}
          className={`p-1.5 rounded transition-all flex items-center justify-center ${
            isPlaying && !isPaused && playMode === 'scene'
              ? 'bg-sky-600/30 text-sky-400 border border-sky-500/40'
              : 'hover:bg-[var(--gl-hover-bg)] text-[#b3bed0] hover:text-sky-400'
          }`}
          title={t('playControls.playScene')}
        >
          <Film className="w-4 h-4 fill-current" />
        </button>

        {/* Pause */}
        <button
          disabled={!isPlaying}
          onClick={pauseGame}
          className={`p-1.5 rounded transition-all flex items-center justify-center ${
            isPaused
              ? 'bg-amber-600/30 text-amber-400 border border-amber-500/40'
              : isPlaying
              ? 'hover:bg-[var(--gl-hover-bg)] text-[#b3bed0] hover:text-amber-400'
              : 'text-[#485368] cursor-not-allowed'
          }`}
          title={t('playControls.pause')}
        >
          <Pause className="w-4 h-4" />
        </button>

        {/* Stop (F8) */}
        <button
          disabled={!isPlaying}
          onClick={stopGame}
          className={`p-1.5 rounded transition-all flex items-center justify-center ${
            isPlaying
              ? 'bg-rose-600/30 text-rose-400 border border-rose-500/40 hover:bg-rose-600/50'
              : 'text-[#485368] cursor-not-allowed'
          }`}
          title={t('playControls.stop')}
        >
          <Square className="w-4 h-4 fill-current" />
        </button>
      </div>
    </header>
  );
};
