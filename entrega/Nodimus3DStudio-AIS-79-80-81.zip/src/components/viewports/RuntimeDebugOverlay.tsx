import React, { useEffect, useRef, useState } from 'react';
import { useEditorStore } from '../../core/editorStore';
import { getActiveRuntimeSession } from '../../runtime/RuntimeSession';
import { logicExecutionLog } from '../../runtime/logicRunnerSession';
import { globalDiagnosticService } from '../../core/diagnostics/global';
import { formatSignalArgs } from '../../core/signalMonitorFormat';
import { buildConsoleFeed, summarizeDiagnostics, type ConsoleLine, type DebugSnapshot, type DebugStats } from '../../core/debug/debugStats';
import { useTranslation } from '../../core/i18n/I18nContext';

/**
 * AIS-77 — overlay de debug do Play (HTML sobre a viewport; só existe montado durante o Play com o overlay ligado, então desligado não coleta nem
 * desenha nada). SOMENTE LEITURA: lê as métricas do renderer (`DebugStats`), o `SignalBus` e o log de execução da sessão e os diagnósticos do
 * `DiagnosticService` (fonte canônica de erros); o único controle é "Colisores", que liga o MESMO desenho de colisores da toolbar (preferência de
 * visualização, nunca estado da cena). Não edita nada e não intercepta o mouse da viewport fora do próprio painel.
 */

const POLL_MS = 250;
const CONSOLE_LINES = 12;

interface Sample {
  snap: DebugSnapshot;
  liveNodes: number;
  authoredNodes: number;
  feed: ConsoleLine[];
  diag: { errors: number; warnings: number; last: ConsoleLine[] };
}

const SEVERITY_CLASS: Record<ConsoleLine['severity'], string> = { info: 'text-[#9fb4d0]', warn: 'text-amber-300', error: 'text-rose-300' };

export const RuntimeDebugOverlay: React.FC<{ stats: DebugStats; authoredNodeCount: number }> = ({ stats, authoredNodeCount }) => {
  const { t } = useTranslation();
  const showColliders = useEditorStore((s) => s.showColliders);
  const setShowColliders = useEditorStore((s) => s.setShowColliders);
  const [sample, setSample] = useState<Sample | null>(null);
  const authoredRef = useRef(authoredNodeCount);
  authoredRef.current = authoredNodeCount;

  useEffect(() => {
    const collect = () => {
      const session = getActiveRuntimeSession();
      const scene = session?.currentScene ?? null;
      const nameOf = (id: string) => scene?.getInstance(id)?.name;
      const feed = session
        ? buildConsoleFeed({
            signals: session.signalBus.getHistory().slice(-CONSOLE_LINES * 2),
            logic: logicExecutionLog.getEntries().slice(-CONSOLE_LINES * 2),
            nodeName: nameOf,
            formatArgs: formatSignalArgs,
            limit: CONSOLE_LINES,
          })
        : [];
      const diagnostics = session ? globalDiagnosticService.list({ sessionId: session.id }) : [];
      setSample({
        snap: stats.snapshot(),
        liveNodes: scene && !scene.disposed ? scene.getAllInstances().length : 0,
        authoredNodes: authoredRef.current,
        feed,
        diag: summarizeDiagnostics(diagnostics, 3),
      });
    };
    collect();
    const id = window.setInterval(collect, POLL_MS);
    return () => window.clearInterval(id);
  }, [stats]);

  const s = sample;
  const fmt = (n: number) => n.toLocaleString('pt-BR');
  const fpsColor = !s || s.snap.fps === 0 ? 'text-[#9fb4d0]' : s.snap.fps >= 55 ? 'text-emerald-300' : s.snap.fps >= 30 ? 'text-amber-300' : 'text-rose-300';

  return (
    <div
      className="absolute top-2 right-2 z-30 w-[330px] max-h-[calc(100%-16px)] overflow-hidden flex flex-col rounded-md border border-[#2c3345] bg-[#0b0e14]/85 backdrop-blur-sm font-mono text-[10px] text-[#cbd5e1] pointer-events-none select-none"
      data-testid="debug-overlay"
      role="status"
      aria-label={t('runtimeDebugOverlay.playDebugOverlay')}
    >
      <div className="flex items-center justify-between px-2 py-1 bg-[#161b25] border-b border-[#2c3345]">
        <span className="font-bold text-sky-300">{t('runtimeDebugOverlay.debugPlay')}</span>
        <span className="text-[#64748b]">{t('runtimeDebugOverlay.f3ClosesReadOnly')}</span>
      </div>

      <div className="px-2 py-1 grid grid-cols-2 gap-x-3 gap-y-0.5 border-b border-[#222a39]" data-testid="debug-metrics">
        <span>FPS</span>
        <span className={`text-right ${fpsColor}`} data-testid="debug-fps">{s ? s.snap.fps.toFixed(1) : '–'}</span>
        <span>{t('runtimeDebugOverlay.frameTime')}</span>
        <span className="text-right" data-testid="debug-frame-ms">{s ? t('runtimeDebugOverlayMsg.ms', { frameMs: s.snap.frameMs.toFixed(2) }) : '–'}</span>
        <span>{t('runtimeDebugOverlay.minMax')}</span>
        <span className="text-right text-[#8b97a8]">{s ? `${s.snap.frameMinMs.toFixed(1)} / ${s.snap.frameMaxMs.toFixed(1)} ms` : '–'}</span>
        <span>{t('runtimeDebugOverlay.drawCalls')}</span>
        <span className="text-right" data-testid="debug-calls">{s ? fmt(s.snap.drawCalls) : '–'}</span>
        <span>{t('runtimeDebugOverlay.triangles')}</span>
        <span className="text-right" data-testid="debug-triangles">{s ? fmt(s.snap.triangles) : '–'}</span>
        <span>{t('runtimeDebugOverlay.geometriesTextures')}</span>
        <span className="text-right">{s ? `${fmt(s.snap.geometries)} / ${fmt(s.snap.textures)}` : '–'}</span>
        <span>{t('runtimeDebugOverlay.liveNodesPlay')}</span>
        <span className="text-right" data-testid="debug-nodes">{s ? fmt(s.liveNodes) : '–'}</span>
        <span>{t('runtimeDebugOverlay.sceneNodesAuthored')}</span>
        <span className="text-right text-[#8b97a8]">{s ? fmt(s.authoredNodes) : '–'}</span>
      </div>

      <label className="px-2 py-1 flex items-center gap-2 border-b border-[#222a39] pointer-events-auto cursor-pointer" title={t('runtimeDebugOverlay.drawsTheColliderWireframeRapier')}>
        <input type="checkbox" checked={showColliders} onChange={(e) => setShowColliders(e.target.checked)} data-testid="debug-colliders" className="w-3 h-3 accent-sky-500" />
        <span>{t('runtimeDebugOverlay.colliderWireframe')}</span>
      </label>

      <div className="px-2 py-1 border-b border-[#222a39]" data-testid="debug-diagnostics">
        <div>
          {t('runtimeDebugOverlay.sessionDiagnostics')} <span className={s && s.diag.errors > 0 ? 'text-rose-300' : 'text-[#9fb4d0]'}>{t('runtimeDebugOverlay.errorS', { value: s?.diag.errors ?? 0 })}</span> · <span className={s && s.diag.warnings > 0 ? 'text-amber-300' : 'text-[#9fb4d0]'}>{t('runtimeDebugOverlay.warningS', { value: s?.diag.warnings ?? 0 })}</span>
        </div>
        {s?.diag.last.map((l) => (
          <div key={l.key} className={`truncate ${SEVERITY_CLASS[l.severity]}`} title={l.text}>{l.text}</div>
        ))}
      </div>

      <div className="px-2 py-1 overflow-hidden flex-1 min-h-[60px]" data-testid="debug-console">
        <div className="text-[#64748b] mb-0.5">{t('runtimeDebugOverlay.signalsAndActionsLast', { CONSOLE_LINES })}</div>
        {s && s.feed.length === 0 && <div className="text-[#64748b]">{t('runtimeDebugOverlay.noEventsYet')}</div>}
        {s?.feed.map((l) => (
          <div key={l.key} className={`truncate ${SEVERITY_CLASS[l.severity]}`} title={l.text}>
            <span className="text-[#475569]">{l.time.toFixed(2)}s </span>
            {l.text}
          </div>
        ))}
      </div>
    </div>
  );
};

