import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import type { GameNode } from '../../types/node';
import { resolveSelectableHitNodeId, updateViewportSelection } from './viewportSelection';

const node = (id: string, options: Partial<GameNode> = {}) => ({
  id,
  name: id,
  type: 'MeshInstance',
  parentId: null,
  childrenIds: [],
  visible: true,
  locked: false,
  properties: {},
  ...options,
}) as GameNode;

describe('viewportSelection', () => {
  it('resolves the first eligible hit, skipping locked and invisible nodes', () => {
    const scene = new THREE.Scene();
    const locked = new THREE.Mesh();
    const invisible = new THREE.Mesh();
    const eligible = new THREE.Mesh();
    for (const [object, id] of [[locked, 'locked'], [invisible, 'invisible'], [eligible, 'eligible']] as const) {
      (object as THREE.Mesh & { __nodeId: string }).__nodeId = id;
    }

    expect(resolveSelectableHitNodeId(
      [{ object: locked }, { object: invisible }, { object: eligible }],
      scene,
      {
        locked: node('locked', { locked: true }),
        invisible: node('invisible', { visible: false }),
        eligible: node('eligible'),
      }
    )).toBe('eligible');
  });

  it('replaces, adds with Shift, and toggles with Ctrl including the primary selection', () => {
    expect(updateViewportSelection('a', ['b'], 'c', 'replace')).toEqual({ primaryId: 'c', additionalIds: [] });
    expect(updateViewportSelection('a', [], 'b', 'add')).toEqual({ primaryId: 'a', additionalIds: ['b'] });
    expect(updateViewportSelection('a', ['b'], 'a', 'toggle')).toEqual({ primaryId: 'b', additionalIds: [] });
    expect(updateViewportSelection('a', ['b'], 'b', 'toggle')).toEqual({ primaryId: 'a', additionalIds: [] });
    expect(updateViewportSelection('a', [], 'a', 'toggle')).toEqual({ primaryId: null, additionalIds: [] });
  });
});