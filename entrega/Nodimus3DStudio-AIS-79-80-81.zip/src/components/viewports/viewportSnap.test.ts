import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import { DEFAULT_VIEWPORT_SNAP, editorStoreApi } from '../../core/editorStore';
import {
  firstSurfaceHit,
  gizmoSnapValues,
  isSurfaceCandidate,
  SCALE_SNAP_STEP,
  surfaceSnapPosition,
} from './viewportSnap';

const node = (over: Record<string, unknown>) =>
  ({ id: 'a', name: 'A', type: 'MeshInstance', parentId: null, childrenIds: [], visible: true, locked: false, properties: {}, ...over }) as any;

describe('viewportSnap (AIS-09)', () => {
  it('padrões preservam o snap anterior da casca (1 m, 15°, escala 0,25)', () => {
    const v = gizmoSnapValues(DEFAULT_VIEWPORT_SNAP);
    expect(v.translation).toBe(1);
    expect(v.rotation).toBeCloseTo(THREE.MathUtils.degToRad(15));
    expect(v.scale).toBe(SCALE_SNAP_STEP);
    expect(DEFAULT_VIEWPORT_SNAP.surfaceEnabled).toBe(false);
  });

  it('toggles independentes e passos configuráveis', () => {
    const v = gizmoSnapValues({ ...DEFAULT_VIEWPORT_SNAP, gridStep: 0.25, angleEnabled: false });
    expect(v.translation).toBe(0.25);
    expect(v.rotation).toBeNull();
    const off = gizmoSnapValues({ ...DEFAULT_VIEWPORT_SNAP, gridEnabled: false, angleStep: 90 });
    expect(off.translation).toBeNull();
    expect(off.scale).toBeNull();
    expect(off.rotation).toBeCloseTo(Math.PI / 2);
  });

  it('EditorStore guarda e mescla as configurações de snap', () => {
    const { setViewportSnap } = editorStoreApi.getState();
    setViewportSnap({ gridStep: 0.5, surfaceEnabled: true });
    expect(editorStoreApi.getState().viewportSnap).toEqual({ ...DEFAULT_VIEWPORT_SNAP, gridStep: 0.5, surfaceEnabled: true });
    setViewportSnap(DEFAULT_VIEWPORT_SNAP);
  });

  it('surface snap leva o centro inferior da caixa ao ponto atingido', () => {
    // cubo 1×1×1 com origem no centro (0,5 acima da base)
    const pos = { x: 0, y: 0.5, z: 0 };
    const bounds = { min: { x: -0.5, y: 0, z: -0.5 }, max: { x: 0.5, y: 1, z: 0.5 } };
    expect(surfaceSnapPosition(pos, bounds, { x: 3, y: 2, z: -1 })).toEqual({ x: 3, y: 2.5, z: -1 });
    // origem fora do centro da caixa: o deslocamento é preservado
    const offset = { min: { x: 1, y: -2, z: 0 }, max: { x: 3, y: 0, z: 2 } };
    expect(surfaceSnapPosition({ x: 0, y: 0, z: 0 }, offset, { x: 0, y: 0, z: 0 })).toEqual({ x: -2, y: 2, z: -1 });
  });

  it('candidatos: só MeshInstance visível, não travado e diferente do arrastado', () => {
    expect(isSurfaceCandidate(node({ id: 'floor' }), 'box')).toBe(true);
    expect(isSurfaceCandidate(node({ id: 'box' }), 'box')).toBe(false);
    expect(isSurfaceCandidate(node({ id: 'f', locked: true }), 'box')).toBe(false);
    expect(isSurfaceCandidate(node({ id: 'f', visible: false }), 'box')).toBe(false);
    expect(isSurfaceCandidate(node({ id: 'l', type: 'OmniLight' }), 'box')).toBe(false);
  });

  it('firstSurfaceHit acerta a malha de cima e ignora linhas/helpers', () => {
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial());
    const platform = new THREE.Mesh(new THREE.BoxGeometry(2, 1, 2), new THREE.MeshBasicMaterial());
    platform.position.set(0, 0.5, 0);
    const line = new THREE.LineSegments(
      new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(-5, 3, 0), new THREE.Vector3(5, 3, 0)])
    );
    for (const o of [floor, platform, line]) o.updateMatrixWorld();
    const ray = new THREE.Raycaster(new THREE.Vector3(0, 10, 0), new THREE.Vector3(0, -1, 0));
    expect(firstSurfaceHit(ray, [floor, platform, line])!.y).toBeCloseTo(1);
    const miss = new THREE.Raycaster(new THREE.Vector3(50, 10, 0), new THREE.Vector3(0, -1, 0));
    expect(firstSurfaceHit(miss, [floor, platform])).toBeNull();
  });
});
