/**
 * Adaptador de render dos nós `ParticleSystem` (AIS-18c): um `THREE.Points` por nó, filho do grupo
 * do nó, alimentado pelo motor único `src/core/particles/`. O loop pertence ao `RendererCore`
 * (`onFrame` chama `update`); aqui não há `requestAnimationFrame` próprio.
 *
 * Simula no Play (respeitando pausa) e, no editor, só enquanto o nó está selecionado.
 */
import * as THREE from 'three';
import type { SceneData } from '../../types/scene';
import {
  PARTICLE_CAPACITY,
  createState,
  emitBurst,
  forwardParticleSignals,
  resetState,
  step,
  writeParticleBuffers,
  type ParticleState,
} from '../../core/particles/particleEngine';
import { normalizeParticleProps, type ParticleBlendMode, type ParticleProps } from '../../core/particles/particleTypes';
import { getParticleMaskCanvas, onParticleMasksChanged } from '../../core/particles/particleTextures';

const VERTEX_SHADER = /* glsl */ `
  attribute vec4 aColor;
  attribute float aSize;
  uniform float uSizeScale;
  uniform float uOrtho;
  varying vec4 vColor;
  void main() {
    vColor = aColor;
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    float depth = max(-mv.z, 0.0001);
    gl_PointSize = uOrtho > 0.5 ? aSize * uSizeScale : aSize * uSizeScale / depth;
    gl_Position = projectionMatrix * mv;
  }
`;

const FRAGMENT_SHADER = /* glsl */ `
  uniform sampler2D uMap;
  varying vec4 vColor;
  void main() {
    float mask = texture2D(uMap, gl_PointCoord).a;
    float alpha = vColor.a * mask;
    if (alpha < 0.003) discard;
    gl_FragColor = vec4(vColor.rgb, alpha);
  }
`;

const BLENDING: Record<ParticleBlendMode, THREE.Blending> = {
  additive: THREE.AdditiveBlending,
  alpha: THREE.NormalBlending,
  modulate: THREE.MultiplyBlending,
};

interface Entry {
  nodeId: string;
  props: ParticleProps;
  state: ParticleState;
  host: THREE.Object3D;
  points: THREE.Points;
  geometry: THREE.BufferGeometry;
  material: THREE.ShaderMaterial;
  positions: THREE.BufferAttribute;
  colors: THREE.BufferAttribute;
  sizes: THREE.BufferAttribute;
  textureKind: string;
  texture: THREE.CanvasTexture | null;
  offMasks?: () => void;
  /** Estado simulado desde o último reset (para reiniciar ao sair da seleção/Play). */
  active: boolean;
}

export interface ParticleFrameContext {
  dt: number;
  playing: boolean;
  paused: boolean;
  selectedIds: Iterable<string>;
  camera: THREE.Camera;
  viewportHeight: number;
  pixelRatio: number;
  /** AIS-57: `started`/`finished` do motor viram sinais do nó (só no Play; a prévia de seleção no editor não emite). */
  onSignal?: (nodeId: string, signal: 'started' | 'finished') => void;
}

/** Prefixo da chave dos sistemas de partículas de spawn (nunca colide com um id de nó autoral). */
const SPAWN_KEY = 'spawn:';

export class ViewportParticles {
  private entries = new Map<string, Entry>();

  /** Cria/atualiza/descarta os sistemas conforme a cena e os objetos já montados pela viewport. */
  sync(scene: SceneData, objects: ReadonlyMap<string, THREE.Object3D>): void {
    const seen = new Set<string>();
    for (const node of Object.values(scene.nodes)) {
      if (node.type !== 'ParticleSystem') continue;
      const host = objects.get(node.id);
      if (!host) continue;
      seen.add(node.id);

      let entry = this.entries.get(node.id);
      if (entry && entry.host !== host) {
        this.disposeEntry(entry);
        this.entries.delete(node.id);
        entry = undefined;
      }
      const props = normalizeParticleProps(node.properties);
      if (!entry) {
        entry = this.createEntry(node.id, host, props);
        this.entries.set(node.id, entry);
      }
      if (entry.props.seed !== props.seed) {
        entry.state.seed = props.seed >>> 0;
        resetState(entry.state);
      }
      entry.props = props;
      this.applyMaterial(entry);
    }
    for (const [id, entry] of this.entries) {
      if (id.startsWith(SPAWN_KEY)) continue; // spawns são do `syncSpawned`
      if (!seen.has(id)) {
        this.disposeEntry(entry);
        this.entries.delete(id);
      }
    }
  }

  /**
   * AIS-44e — partículas de nós criados DURANTE o jogo (`spawnPrefab`): mesmo motor, mesmo material, sem segundo simulador. O host é o
   * objeto vivo da `RuntimeScene` (as partículas ficam no espaço local dele, como nos nós da cena). Chamar quando os spawns mudarem.
   */
  syncSpawned(instances: ReadonlyArray<{ persistentNodeId: string; type: string; properties: Record<string, any>; object: THREE.Object3D | null }>): void {
    const seen = new Set<string>();
    for (const instance of instances) {
      if (instance.type !== 'ParticleSystem' || !instance.object) continue;
      const key = SPAWN_KEY + instance.persistentNodeId;
      seen.add(key);
      let entry = this.entries.get(key);
      if (entry && entry.host !== instance.object) {
        this.disposeEntry(entry);
        this.entries.delete(key);
        entry = undefined;
      }
      const props = normalizeParticleProps(instance.properties);
      if (!entry) {
        entry = this.createEntry(instance.persistentNodeId, instance.object, props);
        this.entries.set(key, entry);
      }
      entry.props = props;
      this.applyMaterial(entry);
    }
    for (const [key, entry] of this.entries) {
      if (key.startsWith(SPAWN_KEY) && !seen.has(key)) {
        this.disposeEntry(entry);
        this.entries.delete(key);
      }
    }
  }

  /**
   * AIS-59c — rajada pedida pela Action `emit_particles`: usa o MESMO `emitBurst` do motor único, no estado do sistema do nó (da cena
   * ou criado em jogo). Devolve quantas partículas nasceram (0 = nó sem sistema ativo, ex.: oculto ou fora do Play).
   */
  burst(nodeId: string, count: number): number {
    const entry = this.entries.get(nodeId) ?? this.entries.get(SPAWN_KEY + nodeId);
    if (!entry || !entry.host.visible) return 0;
    return emitBurst(entry.state, entry.props, count);
  }

  update(ctx: ParticleFrameContext): void {
    const selected = new Set(ctx.selectedIds);
    const cam = ctx.camera as THREE.PerspectiveCamera & THREE.OrthographicCamera;
    for (const entry of this.entries.values()) {
      const visible = entry.host.visible;
      const simulate = visible && (ctx.playing || selected.has(entry.nodeId));

      if (!simulate) {
        if (entry.active) {
          resetState(entry.state);
          entry.active = false;
        }
        entry.points.visible = false;
        continue;
      }

      entry.active = true;
      if (!(ctx.playing && ctx.paused)) {
        forwardParticleSignals(ctx.playing, step(entry.state, entry.props, ctx.dt), entry.nodeId, ctx.onSignal);
      }

      const count = writeParticleBuffers(
        entry.state,
        entry.props,
        entry.positions.array as Float32Array,
        entry.colors.array as Float32Array,
        entry.sizes.array as Float32Array
      );
      entry.positions.needsUpdate = true;
      entry.colors.needsUpdate = true;
      entry.sizes.needsUpdate = true;
      entry.geometry.setDrawRange(0, count);
      entry.points.visible = count > 0;

      const uniforms = entry.material.uniforms;
      if (cam.isOrthographicCamera) {
        uniforms.uOrtho.value = 1;
        uniforms.uSizeScale.value = (ctx.viewportHeight * ctx.pixelRatio) / Math.max(cam.top - cam.bottom, 1e-4) * cam.zoom;
      } else {
        uniforms.uOrtho.value = 0;
        const fov = THREE.MathUtils.degToRad(cam.fov || 50);
        uniforms.uSizeScale.value = (ctx.viewportHeight * ctx.pixelRatio) / (2 * Math.tan(fov / 2));
      }
    }
  }

  dispose(): void {
    for (const entry of this.entries.values()) this.disposeEntry(entry);
    this.entries.clear();
  }

  private createEntry(nodeId: string, host: THREE.Object3D, props: ParticleProps): Entry {
    const geometry = new THREE.BufferGeometry();
    const positions = new THREE.BufferAttribute(new Float32Array(PARTICLE_CAPACITY * 3), 3).setUsage(THREE.DynamicDrawUsage);
    const colors = new THREE.BufferAttribute(new Float32Array(PARTICLE_CAPACITY * 4), 4).setUsage(THREE.DynamicDrawUsage);
    const sizes = new THREE.BufferAttribute(new Float32Array(PARTICLE_CAPACITY), 1).setUsage(THREE.DynamicDrawUsage);
    geometry.setAttribute('position', positions);
    geometry.setAttribute('aColor', colors);
    geometry.setAttribute('aSize', sizes);
    geometry.setDrawRange(0, 0);

    const material = new THREE.ShaderMaterial({
      vertexShader: VERTEX_SHADER,
      fragmentShader: FRAGMENT_SHADER,
      uniforms: {
        uMap: { value: null },
        uSizeScale: { value: 1 },
        uOrtho: { value: 0 },
      },
      transparent: true,
      depthWrite: false,
    });

    const points = new THREE.Points(geometry, material);
    points.frustumCulled = false;
    points.visible = false;
    points.name = '__particles';
    // Não é alvo de seleção/picking: o ícone-helper do nó é o alvo.
    points.raycast = () => {};
    host.add(points);

    return {
      nodeId,
      props,
      state: createState(props),
      host,
      points,
      geometry,
      material,
      positions,
      colors,
      sizes,
      textureKind: '',
      texture: null,
      active: false,
    };
  }

  private applyMaterial(entry: Entry): void {
    const { props, material } = entry;
    const blending = BLENDING[props.blending];
    if (material.blending !== blending) {
      material.blending = blending;
      material.needsUpdate = true;
    }
    if (entry.textureKind !== props.texture) {
      entry.texture?.dispose();
      entry.offMasks?.();
      const texture = new THREE.CanvasTexture(getParticleMaskCanvas(props.texture));
      entry.offMasks = onParticleMasksChanged(() => { texture.needsUpdate = true; }); // o sprite real chega depois do procedural
      texture.colorSpace = THREE.SRGBColorSpace;
      entry.texture = texture;
      entry.textureKind = props.texture;
      material.uniforms.uMap.value = texture;
    }
  }

  private disposeEntry(entry: Entry): void {
    entry.host.remove(entry.points);
    entry.geometry.dispose();
    entry.material.dispose();
    entry.texture?.dispose();
    entry.offMasks?.();
  }
}
