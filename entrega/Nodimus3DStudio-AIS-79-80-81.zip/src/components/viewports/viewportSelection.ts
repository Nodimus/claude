import * as THREE from 'three';
import type { GameNode } from '../../types/node';

export interface ViewportSelection {
  primaryId: string | null;
  additionalIds: string[];
}

export type ViewportSelectionMode = 'replace' | 'add' | 'toggle';

export function isViewportNodeSelectable(node: GameNode | undefined): boolean {
  return Boolean(node && node.visible && !node.locked);
}

export function resolveSelectableHitNodeId(
  intersections: readonly { object: THREE.Object3D }[],
  scene: THREE.Scene,
  nodes: Record<string, GameNode>
): string | null {
  for (const intersection of intersections) {
    let current: THREE.Object3D | null = intersection.object;
    while (current && current !== scene) {
      const nodeId = (current as THREE.Object3D & { __nodeId?: string }).__nodeId;
      if (nodeId) {
        if (isViewportNodeSelectable(nodes[nodeId])) return nodeId;
        break;
      }
      current = current.parent;
    }
  }
  return null;
}

export function updateViewportSelection(
  primaryId: string | null,
  additionalIds: readonly string[],
  hitId: string,
  mode: ViewportSelectionMode
): ViewportSelection {
  const selected = [...new Set([...(primaryId ? [primaryId] : []), ...additionalIds])];
  if (mode === 'replace') return { primaryId: hitId, additionalIds: [] };

  if (mode === 'add') {
    if (selected.includes(hitId)) return { primaryId, additionalIds: [...additionalIds] };
    if (!primaryId) return { primaryId: hitId, additionalIds: [...additionalIds] };
    return { primaryId, additionalIds: [...additionalIds, hitId] };
  }

  if (!selected.includes(hitId)) {
    if (!primaryId) return { primaryId: hitId, additionalIds: [...additionalIds] };
    return { primaryId, additionalIds: [...additionalIds, hitId] };
  }

  if (hitId === primaryId) {
    const [nextPrimaryId = null, ...remainingIds] = additionalIds;
    return { primaryId: nextPrimaryId, additionalIds: remainingIds };
  }
  return { primaryId, additionalIds: additionalIds.filter((id) => id !== hitId) };
}