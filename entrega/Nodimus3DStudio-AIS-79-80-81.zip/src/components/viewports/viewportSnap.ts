import * as THREE from 'three';
import type { ViewportSnapSettings } from '../../core/editorStore';
import type { GameNode } from '../../types/node';

/**
 * AIS-09 — snapping da viewport 3D (barra de precisão).
 *
 * Grid e ângulo vão para o `TransformControls` (setTranslationSnap / setRotationSnap).
 * Surface Snap: durante um arraste de Translate, o objeto é posicionado com a base
 * (centro inferior da caixa) no primeiro ponto de malha estática sob o cursor.
 */

/** Passo de escala mantido da casca: acompanha o toggle de grid (não configurável neste prompt). */
export const SCALE_SNAP_STEP = 0.25;

export interface GizmoSnapValues {
  /** metros; null = livre */
  translation: number | null;
  /** radianos; null = livre */
  rotation: number | null;
  scale: number | null;
}

export function gizmoSnapValues(settings: ViewportSnapSettings): GizmoSnapValues {
  return {
    translation: settings.gridEnabled ? settings.gridStep : null,
    rotation: settings.angleEnabled ? THREE.MathUtils.degToRad(settings.angleStep) : null,
    scale: settings.gridEnabled ? SCALE_SNAP_STEP : null,
  };
}

export interface Vec3Like {
  x: number;
  y: number;
  z: number;
}

/**
 * Nova posição que leva o centro inferior da caixa (`bounds`, em mundo) até `hit`,
 * preservando o deslocamento entre a origem do objeto e a caixa.
 */
export function surfaceSnapPosition(
  position: Vec3Like,
  bounds: { min: Vec3Like; max: Vec3Like },
  hit: Vec3Like
): Vec3Like {
  const anchorX = (bounds.min.x + bounds.max.x) / 2;
  const anchorZ = (bounds.min.z + bounds.max.z) / 2;
  return {
    x: position.x + (hit.x - anchorX),
    y: position.y + (hit.y - bounds.min.y),
    z: position.z + (hit.z - anchorZ),
  };
}

/** Malhas estáticas que servem de superfície: MeshInstance visível, não travado, exceto o arrastado. */
export function isSurfaceCandidate(node: GameNode, draggedNodeId: string): boolean {
  return node.type === 'MeshInstance' && node.visible && !node.locked && node.id !== draggedNodeId;
}

/** Primeiro ponto de superfície atingido pelo raio (só malhas; helpers/linhas ignorados). */
export function firstSurfaceHit(raycaster: THREE.Raycaster, surfaces: THREE.Object3D[]): THREE.Vector3 | null {
  const hits = raycaster.intersectObjects(surfaces, true);
  for (const hit of hits) {
    if ((hit.object as THREE.Mesh).isMesh && hit.object.visible) return hit.point.clone();
  }
  return null;
}
