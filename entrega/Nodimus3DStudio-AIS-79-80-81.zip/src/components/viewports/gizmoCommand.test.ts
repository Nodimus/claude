import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import { CommandManager } from '../../core/commandManager';
import {
  createGizmoTransformCommand,
  NodeTransform,
  readNodeTransform,
  readObjectTransform,
  transformsEqual,
} from './gizmoCommand';

const T = (px: number, ry = 0, s = 1): NodeTransform => ({
  position: { x: px, y: 0, z: 0 },
  rotation: { x: 0, y: ry, z: 0 },
  scale: { x: s, y: s, z: s },
});

describe('gizmoCommand (AIS-08)', () => {
  it('readObjectTransform arredonda como a casca (3 casas; rotação em graus, 1 casa)', () => {
    const obj = new THREE.Object3D();
    obj.position.set(1.23456, -2, 0.0004);
    obj.rotation.set(0, Math.PI / 2, 0);
    obj.scale.set(1.5, 2.00049, 1);
    expect(readObjectTransform(obj)).toEqual({
      position: { x: 1.235, y: -2, z: 0 },
      rotation: { x: 0, y: 90, z: 0 },
      scale: { x: 1.5, y: 2, z: 1 },
    });
  });

  it('readNodeTransform aplica os padrões do sync (posição/rotação 0, escala 1)', () => {
    expect(readNodeTransform({})).toEqual({
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
    });
    expect(readNodeTransform({ position: { x: 2, y: 3, z: 4 } }).position).toEqual({ x: 2, y: 3, z: 4 });
  });

  it('clique sem arrastar não gera Command', () => {
    expect(transformsEqual(T(1), T(1))).toBe(true);
    expect(createGizmoTransformCommand({ nodeId: 'n', nodeName: 'Box', mode: 'translate', before: T(1), after: T(1), apply: () => {} })).toBeNull();
  });

  it('um arraste = um Command; Ctrl+Z volta ao início e Ctrl+Y reaplica o fim', () => {
    const authoring: Record<string, NodeTransform> = { n: T(0) };
    const apply = (id: string, t: NodeTransform) => {
      authoring[id] = t;
    };
    const manager = new CommandManager();

    // Durante o arraste nada é gravado; ao soltar, um único Command:
    const cmd = createGizmoTransformCommand({ nodeId: 'n', nodeName: 'Pillar', mode: 'translate', before: T(0), after: T(3.5), apply });
    expect(cmd?.label).toBe('Move Node');
    manager.execute(cmd!);
    expect(authoring.n.position.x).toBe(3.5);
    expect(manager.getUndoActionName()).toBe('Move Node');

    manager.undo();
    expect(authoring.n.position.x).toBe(0);
    expect(manager.canUndo()).toBe(false);

    manager.redo();
    expect(authoring.n.position.x).toBe(3.5);
  });

  it('nome do Command segue o modo; snapshots não mudam se os objetos de origem mudarem', () => {
    const before = T(0, 0);
    const after = T(0, 45);
    const applied: NodeTransform[] = [];
    const cmd = createGizmoTransformCommand({ nodeId: 'n', nodeName: 'Orb', mode: 'rotate', before, after, apply: (_id, t) => applied.push(t) })!;
    expect(cmd.label).toBe('Rotate Node');
    after.rotation.y = 999; // mutação posterior não vaza para o Command
    cmd.execute();
    expect(applied[0].rotation.y).toBe(45);
    expect(createGizmoTransformCommand({ nodeId: 'n', nodeName: 'Orb', mode: 'scale', before: T(0), after: T(0, 0, 2), apply: () => {} })!.label).toBe('Scale Node');
  });
});

import { createGroupTransformCommand } from './gizmoCommand';
import { setCurrentLanguage } from '../../core/i18n';

// AIS-80: rótulos de Command em inglês (idioma padrão do produto); a suíte fixa pt-BR em `src/test-setup.ts`.
setCurrentLanguage('en');

describe('createGroupTransformCommand (AIS-17)', () => {
  const t = (x: number): NodeTransform => ({
    position: { x, y: 0, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    scale: { x: 1, y: 1, z: 1 },
  });

  it('um Command restaura todos os nós no undo', () => {
    const state: Record<string, NodeTransform> = { a: t(5), b: t(7), c: t(9) };
    const cmd = createGroupTransformCommand({
      mode: 'translate',
      items: [
        { nodeId: 'a', nodeName: 'A', before: t(0), after: t(5) },
        { nodeId: 'b', nodeName: 'B', before: t(2), after: t(7) },
        { nodeId: 'c', nodeName: 'C', before: t(9), after: t(9) }, // sem mudança: descartado
      ],
      apply: (id, tr) => {
        state[id] = tr;
      },
    })!;
    expect(cmd.label).toBe('Move Nodes (2)');
    cmd.undo();
    expect(state.a.position.x).toBe(0);
    expect(state.b.position.x).toBe(2);
    expect(state.c.position.x).toBe(9);
    cmd.execute();
    expect(state.a.position.x).toBe(5);
    expect(state.b.position.x).toBe(7);
  });

  it('retorna null quando nada mudou e usa nome individual com um item', () => {
    expect(createGroupTransformCommand({ mode: 'translate', items: [{ nodeId: 'a', nodeName: 'A', before: t(1), after: t(1) }], apply: () => {} })).toBeNull();
    const one = createGroupTransformCommand({ mode: 'translate', items: [{ nodeId: 'a', nodeName: 'A', before: t(1), after: t(2) }], apply: () => {} })!;
    expect(one.label).toBe('Move Node');
  });
});
