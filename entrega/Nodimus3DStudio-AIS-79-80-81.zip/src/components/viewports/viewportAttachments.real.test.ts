import { describe, expect, it } from 'vitest';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import * as THREE from 'three';
import type { GameNode, ResourceRef } from '../../types/node';
import { bytesToDataUrl } from '../../core/models/modelBytes';
import { ModelCache } from '../../core/models/modelCache';
import { createModelObject, type ModelSourceBinding } from '../../core/models/createModelObject';
import { loadModelBoneNames } from '../../core/models/modelBones';
import { AttachmentHost } from '../../runtime/attachmentRuntime';
import { findBone } from '../../core/attachment/boneAttachment';
import { ViewportAttachments } from './viewportAttachments';

/** AIS-61 §4 — reparent real no `Bone` do Mixamo REAL (docs/arquivos_teste/mixamo/Characters/Big Vegas.glb). */

const CHARACTER = resolve(__dirname, '../../../docs/arquivos_teste/mixamo/Characters/Big Vegas.glb');
const available = existsSync(CHARACTER);
const HERO: ResourceRef = { id: 'hero', type: 'model', path: 'res://models/hero.glb' };

const g = globalThis as Record<string, unknown>;
if (typeof g.self === 'undefined') g.self = globalThis;
if (typeof g.createImageBitmap === 'undefined') g.createImageBitmap = async () => ({ width: 1, height: 1, close() {} });

const source: ModelSourceBinding = {
  resolve: (r) => (r.id === 'hero' ? { resourceId: 'hero', uri: 'res://models/hero.glb', contentHash: 'h', content: bytesToDataUrl(new Uint8Array(readFileSync(CHARACTER)), 'model/gltf-binary') } : null),
  readFile: () => undefined,
  report: () => {},
};

const node = (id: string, parentId: string | null, props: Record<string, any> = {}): GameNode =>
  ({ id, name: id, type: 'MeshInstance', parentId, childrenIds: [], visible: true, locked: false, properties: props }) as unknown as GameNode;

async function setup(swordProps: Record<string, any>) {
  const cache = new ModelCache();
  const handle = createModelObject(HERO, { source, cache });
  await handle.ready;
  const root = new THREE.Group();
  const sword = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 0.1));
  root.add(handle.object, sword);
  handle.object.add(sword);
  const nodes = { hero: node('hero', null, { model: HERO }), sword: node('sword', 'hero', swordProps) };
  const objects = new Map<string, THREE.Object3D>([['hero', handle.object], ['sword', sword]]);
  return { handle, root, sword, nodes, objects, presenter: new ViewportAttachments() };
}

describe.skipIf(!available)('attachments com Mixamo real', () => {
  it('modelBones lê os ossos reais do personagem (mixamorigRightHand incluso)', async () => {
    const names = await loadModelBoneNames(HERO, source, new ModelCache());
    expect(names.length).toBeGreaterThan(40);
    expect(names).toContain('mixamorigRightHand');
  });

  it('attachment autoral: o nó vira filho do osso e acompanha o osso; sem o bloco volta ao pai', async () => {
    const s = await setup({ attachment: { bone: 'mixamorigRightHand' } });
    const frame = { nodes: s.nodes, objects: s.objects, root: s.root };
    s.presenter.update(frame);
    const bone = findBone(s.handle.object, 'mixamorigRightHand')!;
    expect(bone).toBeDefined();
    expect(s.sword.parent?.name).toBe('AttachSocket:mixamorigRightHand');
    expect(s.sword.parent?.parent).toBe(bone);
    // o osso anima: o nó preso o segue
    s.root.updateMatrixWorld(true);
    const before = new THREE.Vector3().setFromMatrixPosition(s.sword.matrixWorld);
    bone.position.x += 5;
    s.root.updateMatrixWorld(true);
    const after = new THREE.Vector3().setFromMatrixPosition(s.sword.matrixWorld);
    expect(after.distanceTo(before)).toBeGreaterThan(0.001);
    // vínculo removido: volta ao pai autoral (o objeto do modelo)
    s.nodes.sword = node('sword', 'hero', {});
    s.presenter.update({ nodes: s.nodes, objects: s.objects, root: s.root });
    expect(s.sword.parent).toBe(s.handle.object);
    s.handle.release();
  });

  it('attach/detach em jogo (AttachmentHost): vence o autoral; osso inexistente avisa UMA vez e não move o nó', async () => {
    const s = await setup({});
    const host = new AttachmentHost();
    const reports: string[] = [];
    const frame = { nodes: s.nodes, objects: s.objects, root: s.root, host, report: (code: string) => reports.push(code) };
    host.attach('sword', { holder: 'hero', bone: 'mixamorigLeftHand' });
    s.presenter.update(frame);
    expect(s.sword.parent?.parent).toBe(findBone(s.handle.object, 'mixamorigLeftHand'));
    host.detach('sword');
    s.presenter.update(frame);
    expect(s.sword.parent).toBe(s.handle.object);
    host.attach('sword', { holder: 'hero', bone: 'OssoQueNaoExiste' });
    s.presenter.update(frame);
    s.presenter.update(frame);
    expect(s.sword.parent).toBe(s.handle.object);
    expect(reports).toEqual(['attachment.bone_missing']);
    s.handle.release();
  });

  it('soquete compensa a escala 0,01 do esqueleto: o nó fica em metros, na mão, e o gizmo (matriz do pai) é coerente', async () => {
    const s = await setup({ attachment: { bone: 'mixamorigRightHand' } });
    s.presenter.update({ nodes: s.nodes, objects: s.objects, root: s.root });
    s.root.updateMatrixWorld(true);
    const bone = findBone(s.handle.object, 'mixamorigRightHand')!;
    const hand = new THREE.Vector3().setFromMatrixPosition(bone.matrixWorld);
    // escala do nó = 1 → tamanho mundial = 1 (sem o soquete seria 0,01)
    const worldScale = new THREE.Vector3().setFromMatrixScale(s.sword.matrixWorld);
    expect(worldScale.x).toBeCloseTo(1, 4);
    expect(new THREE.Vector3().setFromMatrixPosition(s.sword.matrixWorld).distanceTo(hand)).toBeLessThan(1e-4);
    // 0,5 m locais = 0,5 m no mundo (sem o soquete seriam 0,005)
    s.sword.position.set(0, 0.5, 0);
    s.root.updateMatrixWorld(true);
    expect(new THREE.Vector3().setFromMatrixPosition(s.sword.matrixWorld).distanceTo(hand)).toBeCloseTo(0.5, 3);
    // o pai Three do nó (o que o gizmo usa) tem escala mundial 1
    expect(new THREE.Vector3().setFromMatrixScale(s.sword.parent!.matrixWorld).x).toBeCloseTo(1, 4);
    // dono do modelo escalado: a compensação segue (hero a 2×)
    s.handle.object.scale.setScalar(2);
    s.presenter.update({ nodes: s.nodes, objects: s.objects, root: s.root });
    s.root.updateMatrixWorld(true);
    expect(new THREE.Vector3().setFromMatrixScale(s.sword.matrixWorld).x).toBeCloseTo(2, 4);
    // soltar remove o soquete
    const socket = s.sword.parent!;
    s.nodes.sword = node('sword', 'hero', {});
    s.presenter.update({ nodes: s.nodes, objects: s.objects, root: s.root });
    expect(socket.parent).toBeNull();
    expect(s.sword.parent).toBe(s.handle.object);
    s.handle.release();
  });

  it('holder sem modelo avisa e não quebra', async () => {
    const s = await setup({ attachment: { bone: 'mixamorigRightHand' } });
    const plain = new THREE.Group();
    const reports: string[] = [];
    s.presenter.update({ nodes: s.nodes, objects: new Map<string, THREE.Object3D>([['hero', plain], ['sword', s.sword]]), root: s.root, report: (c) => reports.push(c) });
    expect(reports).toEqual(['attachment.no_model']);
    s.handle.release();
  });
});
