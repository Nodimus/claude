import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import { boundingSphereForObjects, metricRulerScale, projectWorldPosition } from './viewportGuides';

describe('viewportGuides', () => {
  it('chooses a readable metric scale that tracks camera zoom', () => {
    const near = metricRulerScale(2, 720);
    const far = metricRulerScale(20, 720);
    expect(near.pixels).toBeGreaterThan(50);
    expect(near.pixels).toBeLessThanOrEqual(96);
    expect(far.meters).toBeGreaterThan(near.meters);
    expect(far.pixels).toBeGreaterThan(50);
    expect(far.pixels).toBeLessThanOrEqual(96);
  });

  it('projects a world point into viewport pixels and rejects points behind the camera', () => {
    const camera = new THREE.PerspectiveCamera(60, 2, 0.1, 100);
    camera.position.set(0, 0, 5);
    camera.lookAt(0, 0, 0);
    camera.updateMatrixWorld(true);

    expect(projectWorldPosition(camera, { x: 0, y: 0, z: 0 }, 800, 400)).toEqual({ x: 400, y: 200, visible: true });
    expect(projectWorldPosition(camera, { x: 0, y: 0, z: 10 }, 800, 400).visible).toBe(false);
  });

  it('builds one bounding sphere around all selected objects and handles empty groups', () => {
    const left = new THREE.Mesh(new THREE.BoxGeometry(2, 2, 2));
    const right = new THREE.Mesh(new THREE.BoxGeometry(2, 2, 2));
    left.position.x = -3;
    right.position.x = 3;
    const sphere = boundingSphereForObjects([left, right]);
    expect(sphere?.center.x).toBeCloseTo(0);
    expect(sphere?.radius).toBeCloseTo(Math.sqrt(18));

    const emptyGroup = new THREE.Group();
    emptyGroup.position.set(1, 2, 3);
    const pointBounds = boundingSphereForObjects([emptyGroup]);
    expect(pointBounds?.center.toArray()).toEqual([1, 2, 3]);
    expect(pointBounds?.radius).toBe(0);
    expect(boundingSphereForObjects([])).toBeNull();
  });
});