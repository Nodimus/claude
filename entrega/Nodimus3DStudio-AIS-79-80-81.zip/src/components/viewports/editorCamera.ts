import * as THREE from 'three';

/**
 * AIS-07 — câmera de edição da viewport (navegação orbital desktop).
 *
 * Ferramenta do editor: não é `GameNode`, não entra em `SceneData`, não é
 * persistida e não substitui a `Camera` GameNode do jogo. Sem React: o
 * `Viewport3D` encaminha mouse/teclado e chama `update()` a cada quadro do
 * `RendererCore` (interpolação do zoom e aspecto).
 *
 * - Órbita: botão direito · Pan: botão do meio · Zoom: roda (suavizado).
 * - Projeção: Perspective (FOV 60°) ou ortográfica — vistas alinhadas
 *   Top/Front/Right e "Ortho" livre (orbitar numa vista alinhada mantém a
 *   ortográfica em ângulo livre).
 */

export type EditorViewPreset = 'Perspective' | 'Top' | 'Front' | 'Right' | 'Ortho';
export type EditorAxisView = '+X' | '-X' | '+Y' | '+Z';

export interface OrbitState {
  radius: number;
  theta: number;
  phi: number;
}

export interface EditorCameraState {
  view: EditorViewPreset;
  target: THREE.Vector3;
  spherical: OrbitState;
}

interface CameraFrameTransition {
  startTarget: THREE.Vector3;
  endTarget: THREE.Vector3;
  startRadius: number;
  endRadius: number;
  elapsed: number;
  duration: number;
}

export const EDITOR_CAMERA_FOV = 60;
export const MIN_RADIUS = 1.5;
export const MAX_RADIUS = 80;
const MIN_PHI = 0.1;
const MAX_PHI = Math.PI - 0.1;
/** phi quase zero: vista de topo sem degenerar o `lookAt` (up = +Y). */
const TOP_PHI = 1e-4;
const ORBIT_SPEED = 0.008;
/** Fator por unidade de `deltaY` da roda (100 ≈ ×1,13 por "clique"). */
const ZOOM_STEP = 1.0012;
/** Constante da interpolação exponencial do zoom (1/s). */
const ZOOM_SMOOTHING = 14;

const DEFAULT_PERSPECTIVE_ANGLES = { theta: 0.8, phi: 1.1 };

const AXIS_PRESET_ANGLES: Record<'Top' | 'Front' | 'Right', { theta: number; phi: number }> = {
  Top: { theta: 0, phi: TOP_PHI },
  Front: { theta: 0, phi: Math.PI / 2 },
  Right: { theta: Math.PI / 2, phi: Math.PI / 2 },
};

export function isOrthographicView(view: EditorViewPreset): boolean {
  return view !== 'Perspective';
}

export function isAxisAlignedView(view: EditorViewPreset): view is 'Top' | 'Front' | 'Right' {
  return view === 'Top' || view === 'Front' || view === 'Right';
}

export interface ShortcutKeyEvent {
  code: string;
  ctrlKey: boolean;
  metaKey: boolean;
  altKey: boolean;
  shiftKey: boolean;
}

const VIEW_BY_DIGIT: Record<string, EditorViewPreset> = {
  '0': 'Perspective',
  '1': 'Perspective',
  '2': 'Top',
  '3': 'Front',
  '4': 'Right',
};

/**
 * Atalhos de vista da câmera de edição (decisão do usuário no AIS-07, em vez de F1–F4:
 * F2 fica livre para Renomear do AIS-16): Ctrl/Cmd+0 ou +1 Perspective · +2 Top · +3 Front · +4 Right.
 * Aceita a fileira de números e o teclado numérico; Alt/Shift não disparam.
 */
export function viewPresetForShortcut(e: ShortcutKeyEvent): EditorViewPreset | null {
  if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey) return null;
  const match = /^(?:Digit|Numpad)([0-4])$/.exec(e.code);
  return match ? VIEW_BY_DIGIT[match[1]] : null;
}

/**
 * Distância do Frame Selected (`F`): o maior lado da caixa cabe na vista com folga de 60%,
 * nunca abaixo de 2,5 (mesma regra que já existia no handler da viewport).
 */
export function frameDistanceFor(size: { x: number; y: number; z: number }, fovDeg = EDITOR_CAMERA_FOV): number {
  const maxDim = Math.max(size.x, size.y, size.z, 0.5);
  const halfFov = THREE.MathUtils.degToRad(fovDeg) / 2;
  return Math.max(Math.abs(maxDim / 2 / Math.tan(halfFov)) * 1.6, 2.5);
}

export function frameDistanceForSphere(radius: number, fovDeg = EDITOR_CAMERA_FOV): number {
  const safeRadius = Number.isFinite(radius) ? Math.max(radius, 0.25) : 0.25;
  const halfFov = THREE.MathUtils.degToRad(fovDeg) / 2;
  return Math.max(Math.abs(safeRadius / Math.tan(halfFov)) * 1.6, 2.5);
}

/** Altura do mundo visível no plano do alvo — mesma escala nas duas projeções. */
export function visibleHeightAt(radius: number, fovDeg = EDITOR_CAMERA_FOV): number {
  return 2 * radius * Math.tan(THREE.MathUtils.degToRad(fovDeg) / 2);
}

export class EditorCameraController {
  readonly perspective: THREE.PerspectiveCamera;
  readonly orthographic: THREE.OrthographicCamera;
  readonly target = new THREE.Vector3(0, 1, 0);
  readonly spherical: OrbitState = { radius: 14, ...DEFAULT_PERSPECTIVE_ANGLES };

  /** Notificado quando a vista/projeção muda (ex.: órbita tira de Top para Ortho). */
  onViewChange: ((view: EditorViewPreset) => void) | null = null;

  private view: EditorViewPreset = 'Perspective';
  private targetRadius = this.spherical.radius;
  private aspect = 1;
  private frameTransition: CameraFrameTransition | null = null;
  /** AIS-74 — Travar View: congela só a ROTAÇÃO orbital (theta/phi); pan, zoom e a projeção seguem livres. */
  private orbitLocked = false;

  constructor() {
    this.perspective = new THREE.PerspectiveCamera(EDITOR_CAMERA_FOV, 1, 0.1, 1000);
    // near negativo: nada entre a câmera e o alvo é recortado na ortográfica.
    this.orthographic = new THREE.OrthographicCamera(-1, 1, 1, -1, -1000, 2000);
    this.apply();
  }

  get camera(): THREE.PerspectiveCamera | THREE.OrthographicCamera {
    return isOrthographicView(this.view) ? this.orthographic : this.perspective;
  }

  get currentView(): EditorViewPreset {
    return this.view;
  }

  /** Raio para onde o zoom suavizado está convergindo. */
  get zoomTarget(): number {
    return this.targetRadius;
  }

  /** Travar View ligado? (a rotação orbital não responde a input). */
  get isOrbitLocked(): boolean {
    return this.orbitLocked;
  }

  /**
   * AIS-74 — liga/desliga o Travar View. Ligar congela os ângulos de AGORA (ou `at`, ao restaurar uma cena salva); desligar devolve a
   * rotação ao input. Não mexe em alvo, raio (pan/zoom) nem na projeção: a vista (Perspective/Ortho) é independente do lock.
   */
  setOrbitLocked(locked: boolean, at?: { theta: number; phi: number }): void {
    this.orbitLocked = locked;
    if (locked && at && Number.isFinite(at.theta) && Number.isFinite(at.phi)) {
      this.spherical.theta = at.theta;
      this.spherical.phi = THREE.MathUtils.clamp(at.phi, 1e-4, Math.PI - 1e-4);
      this.apply();
    }
  }

  /** Arraste do botão direito, em pixels. Travar View ligado = ignorado (a rotação fica congelada). */
  orbit(dx: number, dy: number): void {
    if (this.orbitLocked) return;
    this.cancelFrameTransition();
    const s = this.spherical;
    s.theta -= dx * ORBIT_SPEED;
    s.phi = THREE.MathUtils.clamp(s.phi - dy * ORBIT_SPEED, MIN_PHI, MAX_PHI);
    if (isAxisAlignedView(this.view)) this.setViewState('Ortho');
    this.apply();
  }

  /** Arraste do botão do meio, em pixels; o ponto sob o cursor acompanha o mouse. */
  pan(dx: number, dy: number, viewportHeightPx: number): void {
    this.cancelFrameTransition();
    const worldPerPixel = visibleHeightAt(this.spherical.radius) / Math.max(viewportHeightPx, 1);
    const cam = this.camera;
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(cam.quaternion);
    const up = new THREE.Vector3(0, 1, 0).applyQuaternion(cam.quaternion);
    this.target.addScaledVector(right, -dx * worldPerPixel);
    this.target.addScaledVector(up, dy * worldPerPixel);
    this.apply();
  }

  /** Roda do mouse: só define o alvo; `update()` interpola. */
  zoom(deltaY: number): void {
    this.cancelFrameTransition();
    this.targetRadius = THREE.MathUtils.clamp(this.targetRadius * Math.pow(ZOOM_STEP, deltaY), MIN_RADIUS, MAX_RADIUS);
  }

  /**
   * Troca vista/projeção. Perspective volta ao ângulo padrão; Ortho mantém o ângulo atual. Com Travar View ligado só a PROJEÇÃO muda
   * (Perspective ⇄ ortográfica): os ângulos ficam congelados, então as vistas alinhadas Top/Front/Right viram "Ortho (livre)".
   */
  setView(view: EditorViewPreset): void {
    this.cancelFrameTransition();
    if (this.orbitLocked) {
      this.setViewState(view === 'Perspective' ? 'Perspective' : 'Ortho');
      this.apply();
      return;
    }
    if (isAxisAlignedView(view)) {
      Object.assign(this.spherical, AXIS_PRESET_ANGLES[view]);
    } else if (view === 'Perspective') {
      Object.assign(this.spherical, DEFAULT_PERSPECTIVE_ANGLES);
    }
    this.setViewState(view);
    this.apply();
  }

  /** Aligns the orthographic editor camera to a world axis for the viewport orientation widget. */
  setAxisView(axis: EditorAxisView): void {
    if (this.orbitLocked) return; // alinhar a um eixo é girar a câmera: congelado
    this.cancelFrameTransition();
    const angles: Record<EditorAxisView, { theta: number; phi: number }> = {
      '+X': { theta: Math.PI / 2, phi: Math.PI / 2 },
      '-X': { theta: -Math.PI / 2, phi: Math.PI / 2 },
      '+Y': { theta: 0, phi: TOP_PHI },
      '+Z': { theta: 0, phi: Math.PI / 2 },
    };
    Object.assign(this.spherical, angles[axis]);
    this.setViewState('Ortho');
    this.apply();
  }

  /** Enquadra o alvo com uma transição suave, preservando o ângulo atual da câmera. */
  frame(center: THREE.Vector3, distance: number, duration = 0.35): void {
    const endRadius = THREE.MathUtils.clamp(distance, MIN_RADIUS, MAX_RADIUS);
    const safeDuration = Math.max(duration, 0);
    this.targetRadius = endRadius;
    if (safeDuration === 0) {
      this.frameTransition = null;
      this.target.copy(center);
      this.spherical.radius = endRadius;
      this.apply();
      return;
    }
    this.frameTransition = {
      startTarget: this.target.clone(),
      endTarget: center.clone(),
      startRadius: this.spherical.radius,
      endRadius,
      elapsed: 0,
      duration: safeDuration,
    };
  }

  /** Por quadro: interpola o zoom e ajusta o aspecto das duas câmeras. Retorna se moveu. */
  update(dt: number, aspect: number): boolean {
    if (aspect > 0 && Number.isFinite(aspect)) this.aspect = aspect;
    const s = this.spherical;
    let moved = false;

    if (this.frameTransition) {
      const transition = this.frameTransition;
      transition.elapsed = Math.min(transition.elapsed + Math.max(dt, 0), transition.duration);
      const progress = transition.duration === 0 ? 1 : transition.elapsed / transition.duration;
      const eased = progress * progress * (3 - 2 * progress);
      this.target.lerpVectors(transition.startTarget, transition.endTarget, eased);
      s.radius = transition.startRadius + (transition.endRadius - transition.startRadius) * eased;
      moved = true;
      if (progress >= 1) {
        this.target.copy(transition.endTarget);
        s.radius = transition.endRadius;
        this.frameTransition = null;
      }
    } else {
      const diff = this.targetRadius - s.radius;
      if (Math.abs(diff) > 1e-4) {
        s.radius += diff * (1 - Math.exp(-ZOOM_SMOOTHING * Math.max(dt, 0)));
        moved = true;
      } else if (diff !== 0) {
        s.radius = this.targetRadius;
        moved = true;
      }
    }
    this.apply();
    return moved;
  }

  /** Reposiciona as câmeras a partir de alvo/esféricas (use após mutar `target`/`spherical` por fora). */
  apply(): void {
    const { radius, theta, phi } = this.spherical;
    const offset = new THREE.Vector3(
      radius * Math.sin(phi) * Math.sin(theta),
      radius * Math.cos(phi),
      radius * Math.sin(phi) * Math.cos(theta)
    );

    for (const cam of [this.perspective, this.orthographic]) {
      cam.position.copy(this.target).add(offset);
      cam.lookAt(this.target);
    }

    this.perspective.aspect = this.aspect;
    this.perspective.updateProjectionMatrix();

    const halfH = visibleHeightAt(radius) / 2;
    const halfW = halfH * this.aspect;
    this.orthographic.left = -halfW;
    this.orthographic.right = halfW;
    this.orthographic.top = halfH;
    this.orthographic.bottom = -halfH;
    this.orthographic.updateProjectionMatrix();
  }

  getState(): EditorCameraState {
    return { view: this.view, target: this.target.clone(), spherical: { ...this.spherical } };
  }

  setState(state: EditorCameraState): void {
    this.frameTransition = null;
    this.target.copy(state.target);
    Object.assign(this.spherical, state.spherical);
    this.targetRadius = this.spherical.radius;
    this.setViewState(state.view);
    this.apply();
  }

  private setViewState(view: EditorViewPreset): void {
    if (view === this.view) return;
    this.view = view;
    this.onViewChange?.(view);
  }

  private cancelFrameTransition(): void {
    if (!this.frameTransition) return;
    this.frameTransition = null;
    this.targetRadius = this.spherical.radius;
  }
}
