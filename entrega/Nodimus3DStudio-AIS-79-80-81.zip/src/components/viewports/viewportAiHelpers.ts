import * as THREE from 'three';
import type { GameNode } from '../../types/node';
import { readAiParams } from '../../runtime/ai/params';

/**
 * AIS-71 §D — helpers de editor da IA: círculos horizontais de `perceptionRadius` (ciano), `loseRadius` (vermelho) e, em `random_area`,
 * `patrolRadius` (verde), em torno do nó com `ai_state_machine` SELECIONADO. Só no editor: somem no Play e no publish; descartados ao remover
 * o nó ou desselecionar. Mesmo padrão dos helpers do Hotspot/Path/Waypoint (um só caminho de criação e descarte).
 */

export const AI_RING_COLORS = { perception: 0x38bdf8, lose: 0xf87171, patrol: 0x34d399 } as const;

export interface AiHelperSpec {
  perception: number;
  lose: number;
  /** Só com `patrolSource: 'random_area'`. */
  patrol: number | null;
}

/** Raios a desenhar para o nó (`null` = o nó não tem `ai_state_machine` ligado). Puro. */
export function aiHelperSpec(node: Pick<GameNode, 'behaviors'> | undefined): AiHelperSpec | null {
  const behavior = node?.behaviors?.find((b) => b.behaviorType === 'ai_state_machine' && b.enabled);
  if (!behavior) return null;
  const p = readAiParams(behavior.properties);
  return { perception: p.perceptionRadius, lose: p.loseRadius, patrol: p.patrolSource === 'random_area' ? p.patrolRadius : null };
}

const SEGMENTS = 64;

function ring(radius: number, color: number): THREE.LineLoop {
  const points: THREE.Vector3[] = [];
  for (let i = 0; i < SEGMENTS; i++) {
    const a = (i / SEGMENTS) * Math.PI * 2;
    points.push(new THREE.Vector3(Math.cos(a) * radius, 0, Math.sin(a) * radius));
  }
  const loop = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(points), new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.8, depthTest: false }));
  loop.renderOrder = 996;
  loop.raycast = () => {};
  loop.userData.isEditorHelper = true;
  return loop;
}

interface Entry {
  group: THREE.Group;
  signature: string;
}

export class AiHelpers {
  private readonly entries = new Map<string, Entry>();
  private readonly world = new THREE.Vector3();

  constructor(private readonly scene: THREE.Object3D) {}

  update(input: { nodes: Readonly<Record<string, GameNode>>; objects: ReadonlyMap<string, THREE.Object3D>; selectedIds: readonly string[]; playing: boolean }): void {
    const wanted = new Set<string>();
    if (!input.playing) {
      for (const id of input.selectedIds) {
        const object = input.objects.get(id);
        const spec = aiHelperSpec(input.nodes[id]);
        if (!object || !spec) continue;
        wanted.add(id);
        const signature = `${spec.perception}|${spec.lose}|${spec.patrol}`;
        let entry = this.entries.get(id);
        if (entry && entry.signature !== signature) {
          this.dispose(id);
          entry = undefined;
        }
        if (!entry) {
          const group = new THREE.Group();
          group.name = 'ai-helpers';
          group.add(ring(spec.perception, AI_RING_COLORS.perception), ring(spec.lose, AI_RING_COLORS.lose));
          if (spec.patrol !== null) group.add(ring(spec.patrol, AI_RING_COLORS.patrol));
          this.scene.add(group);
          entry = { group, signature };
          this.entries.set(id, entry);
        }
        object.updateWorldMatrix(true, false);
        entry.group.position.copy(object.getWorldPosition(this.world));
        entry.group.visible = object.visible;
      }
    }
    for (const id of [...this.entries.keys()]) if (!wanted.has(id)) this.dispose(id);
  }

  /** Há helpers vivos? (testes e diagnóstico) */
  get count(): number {
    return this.entries.size;
  }

  private dispose(id: string): void {
    const entry = this.entries.get(id);
    if (!entry) return;
    entry.group.removeFromParent();
    for (const child of entry.group.children) {
      (child as THREE.Line).geometry.dispose();
      ((child as THREE.Line).material as THREE.Material).dispose();
    }
    this.entries.delete(id);
  }

  disposeAll(): void {
    for (const id of [...this.entries.keys()]) this.dispose(id);
  }
}
