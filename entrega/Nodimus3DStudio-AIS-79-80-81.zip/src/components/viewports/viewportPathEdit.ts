import * as THREE from 'three';
import { appendPoint, insertPoint, movePoint, removePoint, type PathPoint } from '../../core/path/pathData';
import { commitPathNodes, currentPathNodes } from '../../core/path/pathCommands';
import { pathHandles, previewPathNodes, selectedHandleIndex, setSelectedHandle } from '../../core/path/pathObject';

/**
 * AIS-72 §B — modo de edição de waypoints na viewport. Fica FORA do `Viewport3D` (que só o cria/descarta): o botão esquerdo é consumido
 * aqui (captura + `stopPropagation`), então seleção e gizmo não o recebem; meio/direito (pan e órbita) seguem intactos.
 *
 *  - clique num handle: seleciona e arrasta (plano horizontal à altura do ponto; Shift = só vertical);
 *  - clique perto de um segmento: insere um waypoint ali;
 *  - clique no vazio: adiciona um waypoint no fim (sobre a superfície sob o cursor, ou no plano horizontal do último ponto);
 *  - Delete/Backspace com um handle selecionado: remove o waypoint.
 * Cada operação é UM Command (`commitPathNodes`). Arrastar só move o objeto Three durante o gesto (preview) e emite um único Command ao
 * soltar. Toda assinatura devolve disposer (AIS-48b).
 */

export interface PathEditHost {
  canvas: HTMLCanvasElement;
  getCamera(): THREE.Camera;
  nodeId: string;
  getNodeName(): string;
  /** Objeto Three do nó `Path` (relido a cada evento: o sync pode recriá-lo). */
  getPathObject(): THREE.Object3D | null;
  /** Superfícies para posicionar um novo ponto (malhas/terreno visíveis; sem o próprio Path). */
  getSurfaces(): THREE.Object3D[];
}

interface Drag {
  index: number;
  before: PathPoint[];
  current: PathPoint[];
  plane: THREE.Plane;
  vertical: boolean;
  startWorld: THREE.Vector3;
  moved: boolean;
}

/** Tolerância de clique em segmento: fração da distância até a câmera (≈ 14 px a 60° de FOV, em 800 px de altura). */
const SEGMENT_PICK_FRACTION = 0.02;

export class PathEditController {
  private readonly raycaster = new THREE.Raycaster();
  private drag: Drag | null = null;
  private readonly disposers: (() => void)[] = [];
  private previousCursor = '';

  constructor(private readonly host: PathEditHost) {}

  attach(): () => void {
    const { canvas } = this.host;
    this.previousCursor = canvas.style.cursor;
    canvas.style.cursor = 'crosshair';
    const on = (target: HTMLElement | Window, type: string, fn: (e: any) => void, capture = false) => {
      target.addEventListener(type, fn as EventListener, { capture });
      this.disposers.push(() => target.removeEventListener(type, fn as EventListener, { capture }));
    };
    on(canvas, 'mousedown', (e: MouseEvent) => this.onDown(e), true);
    on(canvas, 'mousemove', (e: MouseEvent) => this.onMove(e), true);
    on(window, 'mouseup', (e: MouseEvent) => this.onUp(e));
    on(window, 'keydown', (e: KeyboardEvent) => this.onKey(e), true); // captura: o Delete do handle vem antes do "excluir nó" global
    return () => this.dispose();
  }

  dispose(): void {
    if (this.drag) this.finishDrag(); // o arrasto em andamento não se perde ao sair do modo
    for (const off of this.disposers.splice(0)) off();
    this.host.canvas.style.cursor = this.previousCursor;
  }

  // ── raycast ────────────────────────────────────────────────────────────────────────────────

  private aim(e: MouseEvent): void {
    const rect = this.host.canvas.getBoundingClientRect();
    const ndc = new THREE.Vector2(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
    this.raycaster.setFromCamera(ndc, this.host.getCamera());
  }

  private toLocal(group: THREE.Object3D, world: THREE.Vector3): PathPoint {
    group.updateWorldMatrix(true, false);
    const p = group.worldToLocal(world.clone());
    return { x: p.x, y: p.y, z: p.z };
  }

  private toWorld(group: THREE.Object3D, p: PathPoint): THREE.Vector3 {
    group.updateWorldMatrix(true, false);
    return group.localToWorld(new THREE.Vector3(p.x, p.y, p.z));
  }

  private handleAt(group: THREE.Object3D): number | null {
    const hit = this.raycaster.intersectObjects(pathHandles(group), false)[0];
    return hit ? ((hit.object.userData.pathIndex as number | undefined) ?? null) : null;
  }

  /** Segmento reto mais próximo do raio (dentro da tolerância): onde inserir e o ponto (mundo) sobre ele. */
  private segmentAt(group: THREE.Object3D, nodes: readonly PathPoint[], closed: boolean): { insertIndex: number; world: THREE.Vector3 } | null {
    if (nodes.length < 2) return null;
    const camera = this.host.getCamera();
    const eye = camera.getWorldPosition(new THREE.Vector3());
    const count = closed ? nodes.length : nodes.length - 1;
    let best: { insertIndex: number; world: THREE.Vector3; d2: number } | null = null;
    for (let i = 0; i < count; i++) {
      const a = this.toWorld(group, nodes[i]);
      const b = this.toWorld(group, nodes[(i + 1) % nodes.length]);
      const onSegment = new THREE.Vector3();
      const d2 = this.raycaster.ray.distanceSqToSegment(a, b, undefined, onSegment);
      const tolerance = SEGMENT_PICK_FRACTION * Math.max(0.5, eye.distanceTo(onSegment));
      if (d2 <= tolerance * tolerance && (!best || d2 < best.d2)) best = { insertIndex: i + 1, world: onSegment, d2 };
    }
    return best;
  }

  /** Ponto mundial para um waypoint novo: superfície sob o cursor, senão o plano horizontal do último ponto. */
  private newPointWorld(group: THREE.Object3D, nodes: readonly PathPoint[]): THREE.Vector3 | null {
    const surface = this.raycaster.intersectObjects(this.host.getSurfaces(), true).find((hit) => (hit.object as THREE.Mesh).isMesh && hit.object.visible);
    if (surface) return surface.point.clone();
    const reference = nodes.length ? this.toWorld(group, nodes[nodes.length - 1]) : group.getWorldPosition(new THREE.Vector3());
    return this.raycaster.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 1, 0), -reference.y), new THREE.Vector3());
  }

  // ── eventos ────────────────────────────────────────────────────────────────────────────────

  private onDown(e: MouseEvent): void {
    if (e.button !== 0) return; // meio/direito: pan e órbita da câmera
    e.stopPropagation(); // o botão esquerdo é da edição do caminho: nem seleção nem gizmo o recebem
    e.preventDefault();
    const group = this.host.getPathObject();
    if (!group) return;
    this.aim(e);
    const nodes = currentPathNodes(this.host.nodeId);
    const name = this.host.getNodeName();

    const handle = this.handleAt(group);
    if (handle !== null) {
      setSelectedHandle(group, handle);
      const startWorld = this.toWorld(group, nodes[handle]);
      const vertical = e.shiftKey;
      const plane = vertical
        ? new THREE.Plane().setFromNormalAndCoplanarPoint(this.horizontalViewDirection().negate(), startWorld)
        : new THREE.Plane(new THREE.Vector3(0, 1, 0), -startWorld.y);
      this.drag = { index: handle, before: nodes, current: nodes, plane, vertical, startWorld, moved: false };
      return;
    }

    const config = { closed: group.userData.path?.config?.closed === true };
    const segment = this.segmentAt(group, nodes, config.closed);
    if (segment) {
      setSelectedHandle(group, segment.insertIndex);
      commitPathNodes(this.host.nodeId, insertPoint(nodes, segment.insertIndex, this.toLocal(group, segment.world)), 'insert', name);
      return;
    }

    const world = this.newPointWorld(group, nodes);
    if (!world) return;
    setSelectedHandle(group, nodes.length);
    commitPathNodes(this.host.nodeId, appendPoint(nodes, this.toLocal(group, world)), 'add', name);
  }

  private horizontalViewDirection(): THREE.Vector3 {
    const direction = this.host.getCamera().getWorldDirection(new THREE.Vector3());
    direction.y = 0;
    return direction.lengthSq() < 1e-8 ? new THREE.Vector3(0, 0, 1) : direction.normalize();
  }

  private onMove(e: MouseEvent): void {
    const group = this.host.getPathObject();
    if (!group) return;
    this.aim(e);
    if (!this.drag) {
      this.host.canvas.style.cursor = this.handleAt(group) !== null ? 'grab' : 'crosshair';
      return;
    }
    if ((e.buttons & 1) === 0) return this.finishDrag(); // soltou fora da janela
    const drag = this.drag;
    const hit = this.raycaster.ray.intersectPlane(drag.plane, new THREE.Vector3());
    if (!hit) return;
    // Shift: só Y (x/z ficam onde o ponto estava); padrão: só o plano horizontal (Y fica)
    const world = drag.vertical ? new THREE.Vector3(drag.startWorld.x, hit.y, drag.startWorld.z) : hit;
    drag.current = movePoint(drag.before, drag.index, this.toLocal(group, world));
    drag.moved = true;
    previewPathNodes(group, drag.current);
    this.host.canvas.style.cursor = 'grabbing';
  }

  private onUp(e: MouseEvent): void {
    if (e.button === 0 && this.drag) this.finishDrag();
  }

  /** Solta: UM Command com o array antes × depois (nunca um por quadro de arrasto). */
  private finishDrag(): void {
    const drag = this.drag;
    this.drag = null;
    this.host.canvas.style.cursor = 'crosshair';
    if (!drag?.moved) return;
    commitPathNodes(this.host.nodeId, drag.current, 'move', this.host.getNodeName());
  }

  private onKey(e: KeyboardEvent): void {
    if (e.key !== 'Delete' && e.key !== 'Backspace') return;
    const tag = (e.target as HTMLElement | null)?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || (e.target as HTMLElement | null)?.isContentEditable) return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const group = this.host.getPathObject();
    const index = group ? selectedHandleIndex(group) : null;
    if (!group || index === null) return; // sem handle selecionado: o Delete é do atalho global (excluir nó)
    e.preventDefault(); // decisão 11: só quando tratado
    e.stopImmediatePropagation(); // o atalho global "excluir nó" não pode apagar o Path inteiro
    const nodes = currentPathNodes(this.host.nodeId);
    if (index >= nodes.length) return;
    setSelectedHandle(group, null);
    commitPathNodes(this.host.nodeId, removePoint(nodes, index), 'remove', this.host.getNodeName());
  }
}
