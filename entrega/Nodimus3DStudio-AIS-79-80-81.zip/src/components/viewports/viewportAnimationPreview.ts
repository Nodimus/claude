import { tNow } from '../../core/i18n';
import * as THREE from 'three';
import type { GameNode } from '../../types/node';
import { applyMixerLayers } from '../../core/models/clipPlayer';
import type { ModelObjectHandle, ModelSourceBinding } from '../../core/models/createModelObject';
import { loadPlayerClips } from '../../core/models/playClips';
import { readPhysics } from '../../core/physics/physicsConfig';
import { readAnimation } from '../../core/animation/animationConfig';
import { captureRestPose, type RestPose } from '../../core/models/restPose';

/**
 * AIS-60b (decisão 30) — Prévia da animação padrão no editor (botão ▶ do Inspector), fora do Play. Carrega os clipes com a MESMA regra
 * do Play (`loadPlayerClips`) e aplica a pose ao esqueleto que a viewport já desenha (`applyMixerLayers`). É preview AUTORAL:
 * transitório, nunca grava no authoring nem gera Undo; ao parar (⏹), desselecionar, trocar de objeto ou entrar em Play o esqueleto volta
 * à pose de bind. Substitui a Timeline do AIS-61 (eliminada).
 */

export interface AnimationPreviewStatus {
  nodeId: string | null;
  /** `loading` enquanto os clipes carregam; `error` com `message`. */
  status: 'idle' | 'loading' | 'playing' | 'error';
  message: string;
}

const IDLE: AnimationPreviewStatus = { nodeId: null, status: 'idle', message: '' };

/** Estado compartilhado Inspector ↔ viewport (tiny store; não toca o `EditorStore`). */
class PreviewControl {
  private state: AnimationPreviewStatus = IDLE;
  private readonly listeners = new Set<() => void>();
  /** Incrementa a cada pedido: força recarregar mesmo no mesmo nó. */
  requestSeq = 0;

  get = (): AnimationPreviewStatus => this.state;

  subscribe = (cb: () => void): (() => void) => {
    this.listeners.add(cb);
    return () => void this.listeners.delete(cb);
  };

  set(next: AnimationPreviewStatus): void {
    if (next.nodeId === this.state.nodeId && next.status === this.state.status && next.message === this.state.message) return;
    this.state = next;
    for (const l of this.listeners) l();
  }

  start(nodeId: string): void {
    this.requestSeq++;
    this.set({ nodeId, status: 'loading', message: '' });
  }

  stop(): void {
    this.requestSeq++;
    this.set(IDLE);
  }
}

export const animationPreviewControl = new PreviewControl();

interface View {
  mixer: THREE.AnimationMixer;
  root: THREE.Object3D;
  rest: RestPose;
  actions: Map<string, THREE.AnimationAction>;
  durations: Map<string, number>;
  clip: string;
  time: number;
  loop: boolean;
  speed: number;
  lastKey: string;
}

export interface PreviewFrame {
  nodes: Readonly<Record<string, GameNode>>;
  selectedId: string | null;
  /** O Play assume o esqueleto: a prévia se desfaz. */
  playing: boolean;
  objects: ReadonlyMap<string, THREE.Object3D>;
  dt: number;
}

export class ViewportAnimationPreview {
  private view: View | null = null;
  private loading = false;
  private epoch = 0;
  private seq = -1;

  constructor(private readonly source: ModelSourceBinding) {}

  update(frame: PreviewFrame): void {
    const s = animationPreviewControl.get();
    if (s.nodeId === null) {
      if (this.view || this.loading) this.dispose();
      return;
    }
    const node = frame.nodes[s.nodeId];
    // Play, outra seleção ou nó que deixou de ser animado: encerra
    if (frame.playing || frame.selectedId !== s.nodeId || !node || !readAnimation(node.properties)) {
      this.dispose();
      animationPreviewControl.stop();
      return;
    }
    if (this.seq !== animationPreviewControl.requestSeq) {
      this.dispose();
      this.seq = animationPreviewControl.requestSeq;
    }
    if (!this.view && !this.loading) void this.load(node, frame);
    if (this.view) this.tick(frame.dt, node);
  }

  /** Solta o mixer e devolve o esqueleto à pose de bind. */
  dispose(): void {
    this.epoch++;
    this.loading = false;
    const view = this.view;
    if (view) {
      view.mixer.stopAllAction();
      view.mixer.uncacheRoot(view.root);
      view.rest.restore();
    }
    this.view = null;
    this.seq = -1;
  }

  private fail(epoch: number, nodeId: string, message: string): void {
    if (epoch !== this.epoch) return;
    this.loading = false;
    animationPreviewControl.set({ nodeId, status: 'error', message });
  }

  private async load(node: GameNode, frame: PreviewFrame): Promise<void> {
    const object = frame.objects.get(node.id);
    if (!object) return; // a viewport ainda não desenhou o nó: tenta no próximo quadro
    const handle = object.userData?.modelHandle as ModelObjectHandle | undefined;
    const config = readAnimation(node.properties)!;
    const epoch = this.epoch;
    this.loading = true;
    if (!handle) return this.fail(epoch, node.id, tNow('viewportAnimationPreviewMsgNow.thisObjectHasNo3d'));
    await handle.ready;
    if (epoch !== this.epoch) return;
    const model = handle.loaded();
    if (!model) return this.fail(epoch, node.id, tNow('viewportAnimationPreviewMsgNow.theModelOfDidNot', { name: node.name }));
    const physics = readPhysics(node.properties);
    const forceInPlace = !!physics?.enabled && (physics.bodyMode === 'character' || physics.bodyMode === 'dynamic');
    const set = await loadPlayerClips({ model, rigConfig: config.rig, forceInPlace, source: this.source });
    if (epoch !== this.epoch) return;
    if (set.clips.length === 0) return this.fail(epoch, node.id, set.problems[0]?.message ?? tNow('viewportAnimationPreviewMsgNow.thisObjectHasNoAnimations'));
    const rest = captureRestPose(handle.object); // antes de qualquer clipe: parar devolve ESTA pose
    const mixer = new THREE.AnimationMixer(handle.object);
    const actions = new Map<string, THREE.AnimationAction>();
    const durations = new Map<string, number>();
    for (const clip of set.clips) {
      actions.set(clip.name, mixer.clipAction(clip));
      durations.set(clip.name, clip.duration);
    }
    const clip = set.clips.find((c) => c.name === config.default)?.name ?? set.clips[0].name;
    this.view = { mixer, root: handle.object, rest, actions, durations, clip, time: 0, loop: config.loop, speed: config.speed, lastKey: '' };
    this.loading = false;
    animationPreviewControl.set({ nodeId: node.id, status: 'playing', message: set.problems.find((p) => p.code !== 'animation.no_clips')?.message ?? '' });
  }

  private tick(dt: number, node: GameNode): void {
    const view = this.view;
    if (!view) return;
    const config = readAnimation(node.properties);
    if (config) {
      view.loop = config.loop;
      view.speed = config.speed;
    }
    const duration = view.durations.get(view.clip) ?? 0;
    view.time += dt * view.speed;
    if (duration > 0 && view.time >= duration) {
      if (view.loop) view.time %= duration;
      else {
        // sem loop: toca uma vez e a prévia termina (a pose volta ao bind)
        this.dispose();
        animationPreviewControl.stop();
        return;
      }
    }
    const key = `${view.clip}:${view.time.toFixed(4)}`;
    if (key === view.lastKey) return;
    view.lastKey = key;
    applyMixerLayers(view.mixer, view.actions, view.durations, [{ clip: view.clip, time: view.time, weight: 1 }]);
  }
}
