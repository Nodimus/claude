import * as THREE from 'three';
import { ICommand } from '../../types/commands';
import {
  createSetTransformCommand,
  toSetTransformItem,
  transformsEqual,
  type NodeTransform,
  type TransformMode,
  type Vec3,
} from '../../core/commands/SetTransformCommand';

export { transformsEqual };
export type { NodeTransform, Vec3 };

/**
 * AIS-08 — Command único por arraste do gizmo (TransformControls).
 *
 * Durante o arraste só o objeto Three se move (prévia imperativa); o authoring
 * não é tocado. Ao soltar, um único Command grava o transform final e guarda o
 * inicial para o Ctrl+Z — sem micro-movimentos na pilha (State Mutation Policy:
 * mutação autoral reversível = CommandManager).
 */

export type GizmoMode = TransformMode;

const round = (value: number, digits: number) => Number(value.toFixed(digits));
const vec = (v: Partial<Vec3> | undefined, fallback: number): Vec3 => ({
  x: typeof v?.x === 'number' ? v.x : fallback,
  y: typeof v?.y === 'number' ? v.y : fallback,
  z: typeof v?.z === 'number' ? v.z : fallback,
});

/** Lê o transform do objeto Three com a mesma precisão já usada pela casca (3 casas; rotação 1 casa em graus). */
export function readObjectTransform(obj: THREE.Object3D): NodeTransform {
  return {
    position: { x: round(obj.position.x, 3), y: round(obj.position.y, 3), z: round(obj.position.z, 3) },
    rotation: {
      x: round(THREE.MathUtils.radToDeg(obj.rotation.x), 1),
      y: round(THREE.MathUtils.radToDeg(obj.rotation.y), 1),
      z: round(THREE.MathUtils.radToDeg(obj.rotation.z), 1),
    },
    scale: { x: round(obj.scale.x, 3), y: round(obj.scale.y, 3), z: round(obj.scale.z, 3) },
  };
}

/** Lê o transform das propriedades do GameNode (mesmos padrões do sync da viewport). */
export function readNodeTransform(properties: Record<string, any>): NodeTransform {
  return {
    position: vec(properties.position, 0),
    rotation: vec(properties.rotation, 0),
    scale: vec(properties.scale, 1),
  };
}

export interface GizmoCommandInput {
  nodeId: string;
  nodeName: string;
  mode: GizmoMode;
  before: NodeTransform;
  after: NodeTransform;
  /** Grava o transform no authoring (sem registrar histórico próprio). */
  apply: (nodeId: string, transform: NodeTransform) => void;
}

/** Command do término do arraste; `null` quando nada mudou (clique sem arrastar). */
export function createGizmoTransformCommand(input: GizmoCommandInput): ICommand | null {
  const { nodeId, mode, before, after, apply } = input;
  return createSetTransformCommand({ mode, items: [toSetTransformItem(nodeId, before, after)], apply });
}

export interface GroupTransformItem {
  nodeId: string;
  nodeName: string;
  before: NodeTransform;
  after: NodeTransform;
}

export interface GroupGizmoCommandInput {
  mode: GizmoMode;
  items: GroupTransformItem[];
  apply: (nodeId: string, transform: NodeTransform) => void;
}

/**
 * AIS-17/19 — Command único para o arraste do gizmo sobre vários nós (`SetTransformCommand`).
 * Um gesto = uma entrada no histórico; Ctrl+Z restaura todos os nós.
 */
export function createGroupTransformCommand(input: GroupGizmoCommandInput): ICommand | null {
  const items = input.items.map((i) => toSetTransformItem(i.nodeId, i.before, i.after));
  return createSetTransformCommand({ mode: input.mode, items, apply: input.apply });
}
