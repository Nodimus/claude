import * as THREE from 'three';
import type { SceneData } from '../../types/scene';
import { readPhysics } from '../../core/physics/physicsConfig';
import { measureLocalBounds } from '../../core/physics/bounds';
import { vegetationDataOf } from '../../core/vegetation/vegetationBuild';
import { resolveCollider } from '../../core/physics/resolveCollider';
import { buildColliderWireframe, colliderSignature } from '../../core/physics/colliderWireframe';

interface Entry {
  holder: THREE.Group;
  signature: string;
  child: THREE.LineSegments | null;
}

/**
 * AIS-26b — "Mostrar colisores": adaptador que desenha, por nó com `properties.physics`, o wireframe vindo de
 * `resolveCollider` + `buildColliderWireframe`. Vale na edição e no Play; só lê a cena e os objetos Three — nunca
 * escreve em dados. Os helpers ficam num grupo próprio no `scene` raiz (não filhos dos nós: não entram em
 * seleção, bounding boxes nem snapshots).
 */
export class ViewportColliders {
  private readonly group = new THREE.Group();
  private readonly entries = new Map<string, Entry>();
  private readonly tmpScale = new THREE.Vector3();
  private readonly tmpQuat = new THREE.Quaternion();
  /** Forma/tamanho mudam raramente: recalcula a cada 0,25 s; a pose é copiada em todo quadro. */
  private sinceResolve = Infinity;
  private lastScene: SceneData | null = null;

  constructor(scene: THREE.Scene) {
    this.group.name = 'collider-helpers';
    this.group.visible = false;
    scene.add(this.group);
  }

  update(show: boolean, sceneData: SceneData, objects: ReadonlyMap<string, THREE.Object3D>, dt = 0): void {
    this.group.visible = show;
    if (!show) {
      this.clear();
      this.sinceResolve = Infinity;
      return;
    }
    this.sinceResolve += dt;
    if (this.sinceResolve < 0.25 && this.lastScene === sceneData) {
      this.syncPoses(objects);
      return;
    }
    this.sinceResolve = 0;
    this.lastScene = sceneData;
    const live = new Set<string>();
    for (const node of Object.values(sceneData.nodes)) {
      const object = objects.get(node.id);
      const physics = readPhysics(node.properties);
      if (!object || !physics) continue;
      object.updateWorldMatrix(true, false);
      object.getWorldScale(this.tmpScale);
      // desligado: desenha tracejado, resolvendo como se estivesse ligado
      const spec = resolveCollider(
        { ...physics, enabled: true },
        { nodeType: node.type, properties: node.properties, bounds: measureLocalBounds(object), scale: { x: this.tmpScale.x, y: this.tmpScale.y, z: this.tmpScale.z }, parts: vegetationDataOf(object)?.colliders }
      );
      if (!spec) continue;
      live.add(node.id);
      const style = { bodyMode: physics.bodyMode, disabled: !physics.enabled };
      const signature = colliderSignature(spec, style);
      let entry = this.entries.get(node.id);
      if (!entry) {
        entry = { holder: new THREE.Group(), signature: '', child: null };
        this.group.add(entry.holder);
        this.entries.set(node.id, entry);
      }
      if (entry.signature !== signature) {
        this.disposeChild(entry);
        entry.child = buildColliderWireframe(spec, style);
        entry.holder.add(entry.child);
        entry.signature = signature;
      }
      this.syncPose(entry, object);
    }
    for (const [id, entry] of this.entries) {
      if (live.has(id)) continue;
      this.remove(id, entry);
    }
  }

  private syncPose(entry: Entry, object: THREE.Object3D) {
    object.updateWorldMatrix(true, false);
    object.getWorldPosition(entry.holder.position);
    object.getWorldQuaternion(this.tmpQuat);
    entry.holder.quaternion.copy(this.tmpQuat); // a escala já está no tamanho do colisor
    entry.holder.visible = object.visible;
  }

  private syncPoses(objects: ReadonlyMap<string, THREE.Object3D>) {
    for (const [id, entry] of this.entries) {
      const object = objects.get(id);
      if (object) this.syncPose(entry, object);
    }
  }

  private disposeChild(entry: Entry) {
    if (!entry.child) return;
    entry.holder.remove(entry.child);
    entry.child.geometry.dispose();
    (entry.child.material as THREE.Material).dispose();
    entry.child = null;
  }

  private remove(id: string, entry: Entry) {
    this.disposeChild(entry);
    this.group.remove(entry.holder);
    this.entries.delete(id);
  }

  private clear() {
    for (const [id, entry] of this.entries) this.remove(id, entry);
  }

  dispose(): void {
    this.clear();
    this.group.removeFromParent();
  }
}
