import React from 'react';
import { Pause, Play, SkipForward, Square } from 'lucide-react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { requestStepFrame } from '../../runtime/logicRunnerSession';
import { useTranslation } from '../../core/i18n/I18nContext';

/**
 * AIS-46 — barra de controle SOBREPOSTA à viewport durante o Play: Pausar/Continuar, Avançar 1 Quadro e Parar. Não é modal e não
 * guarda estado de jogo: só aciona o ciclo canônico (`pauseGame`/`stopGame`, que falam com a `RuntimeSession`) e pede UM quadro à
 * sessão (`requestStepFrame`, só vale em pausa). Estilo e densidade da toolbar da viewport.
 */
const BTN =
  'flex items-center gap-1 px-2 py-1 rounded text-[11px] transition-colors text-[#dfe4ec] hover:bg-[#2c3345] disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent';

export const PlayControlBar: React.FC = () => {
  const { t } = useTranslation();
  const { pauseGame, stopGame } = useEditor();
  const isPaused = useEditorStore((s) => s.isPaused);

  return (
    <div
      role="toolbar"
      aria-label={t('playControlBar.playControls')}
      data-testid="play-control-bar"
      className="absolute top-10 left-1/2 -translate-x-1/2 z-30 flex items-center gap-0.5 bg-[#202531]/90 backdrop-blur-sm border border-[#2c3345] rounded px-1 py-0.5 shadow"
    >
      <button type="button" className={BTN} onClick={pauseGame} title={isPaused ? t('playControlBarMsg.resumeTheSimulation') : t('playControlBarMsg.pauseTheSimulationFreezesPhysics')} data-testid="play-bar-pause">
        {isPaused ? <Play className="w-3.5 h-3.5 text-emerald-400" /> : <Pause className="w-3.5 h-3.5 text-amber-300" />}
        <span>{isPaused ? t('playControlBarMsgTwo.continue') : t('sharedMsgTwo.pause')}</span>
      </button>
      <button type="button" className={BTN} onClick={requestStepFrame} disabled={!isPaused} title={isPaused ? t('playControlBarMsg.advance1Frame160') : t('playControlBarMsg.pauseTheSimulationToAdvance')} data-testid="play-bar-step">
        <SkipForward className="w-3.5 h-3.5 text-sky-300" />
        <span>{t('playControlBar.advance1Frame')}</span>
      </button>
      <button type="button" className={BTN} onClick={stopGame} title={t('playControlBar.stopTheSimulationF8')} data-testid="play-bar-stop">
        <Square className="w-3.5 h-3.5 text-rose-400" />
        <span>{t('shared.stop')}</span>
      </button>
    </div>
  );
};
