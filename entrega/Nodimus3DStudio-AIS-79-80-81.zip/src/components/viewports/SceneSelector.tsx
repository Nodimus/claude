import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Check, ChevronDown, Copy, Film, Pencil, Plus, Save, Settings, Star, Trash2, X } from 'lucide-react';
import { useEditor } from '../../core/EditorContext';
import { listScenes, planSceneDeletion, sceneNameOf, validateSceneName, type SceneInfo } from '../../core/sceneManager';
import { duplicateSceneNow, renameSceneNow, setInitialSceneNow } from '../../core/sceneManagerGlobal';
import { deleteResource, planResourceDeletion, type DeleteDecision, type DeletionPlan } from '../../core/resourceDeletion';
import { ConfirmDeleteDialog } from '../fileSystem/FileDialogs';
import { useTranslation } from '../../core/i18n/I18nContext';

/**
 * Seletor de cenas da barra da viewport (extraído do Viewport3D, AIS-29f): troca de cena + Add, Duplicar, Renomear,
 * Excluir, Definir como inicial e Settings. Toda a lógica vive em `sceneManager` (puro), `sceneManagerGlobal` e no
 * `deleteResource` (AIS-29e); este componente só apresenta e aciona.
 */

const dialogShell = 'fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 select-none';
const dialogBox = 'bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-sm text-xs text-[#d4dbe8] overflow-hidden';
const fieldCls = 'w-full bg-[#141820] text-xs text-[#dfe4ec] px-2 py-1.5 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none';

export const SceneSelector: React.FC = () => {
  const { t: tr } = useTranslation();
  const { project, activeScene, loadScene, createNewScene, saveCurrentScene, openSceneThen, addLog } = useEditor();
  const [open, setOpen] = useState(false);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [renameError, setRenameError] = useState<string | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  // exclusão: passo 1 (escolhas) → passo 2 (confirmação do AIS-29e com os consumidores)
  const [del, setDel] = useState<{ path: string; plan: ReturnType<typeof planSceneDeletion>; newInitial: string; openNext: string } | null>(null);
  const [delPlan, setDelPlan] = useState<DeletionPlan | null>(null);
  const [delStep, setDelStep] = useState<'choose' | 'confirm'>('choose');

  const scenes = useMemo<SceneInfo[]>(() => {
    const list = listScenes(project);
    // a cena aberta ainda não salva também aparece
    if (activeScene && !list.some((s) => s.path === activeScene.path)) {
      list.unshift({ path: activeScene.path, name: activeScene.name, sceneId: activeScene.id, isInitial: false });
    }
    return list;
  }, [project, activeScene]);

  const select = (path: string) => {
    if (path === activeScene?.path) return setOpen(false);
    saveCurrentScene();
    loadScene(path);
    setOpen(false);
  };

  const startRename = (s: SceneInfo) => {
    setRenaming(s.path);
    setRenameValue(s.name);
    setRenameError(null);
  };

  const commitRename = (s: SceneInfo) => {
    if (renameValue === s.name) return setRenaming(null);
    const check = validateSceneName(project, renameValue, undefined, s.path);
    if (!check.ok) return setRenameError(check.error ?? tr('sharedMsg.invalidName'));
    const result = renameSceneNow(s.path, renameValue);
    if (!result.ok) return setRenameError(result.error);
    addLog('log', tr('sceneSelectorMsg.sceneRenamed', { name: s.name, renameValue }));
    setRenaming(null);
  };

  const duplicate = (s: SceneInfo) => {
    const result = duplicateSceneNow(s.path);
    if ('error' in result) return setNotice(result.error);
    addLog('log', tr('sceneSelectorMsg.sceneDuplicated', { name: s.name, name2: result.name }));
    setNotice(null);
  };

  const setInitial = (s: SceneInfo) => {
    const result = setInitialSceneNow(s.path);
    if (!result.ok) return setNotice(result.error);
    addLog('log', tr('sceneSelectorMsg.startScene2', { name: s.name }));
    setNotice(null);
  };

  const requestDelete = (s: SceneInfo) => {
    const plan = planSceneDeletion(project, s.path, activeScene?.path);
    if (plan.blocked) {
      setNotice(plan.blocked);
      return;
    }
    setNotice(null);
    const first = plan.candidates[0]?.path ?? '';
    setDel({ path: s.path, plan, newInitial: first, openNext: first });
    setDelStep('choose');
    setDelPlan(null);
    setOpen(false);
  };

  const closeDelete = () => {
    setDel(null);
    setDelPlan(null);
    setDelStep('choose');
  };

  const confirmChoices = () => {
    if (!del) return;
    setDelStep('confirm');
    void planResourceDeletion({ path: del.path }).then(setDelPlan);
  };

  const performDelete = (decision?: DeleteDecision) => {
    if (!del) return;
    const target = del;
    closeDelete();
    const run = () => {
      // só depois de a cena aberta poder sair (guarda de alterações) é que algo é gravado
      if (target.plan.needsNewInitial) {
        const r = setInitialSceneNow(target.newInitial);
        if (!r.ok) {
          addLog('warn', tr('sceneSelectorMsg.deletionCancelled', { error: r.error }));
          return;
        }
      }
      void deleteResource({ path: target.path }, { confirmed: true, decision }).then((result) => {
        if (!result.ok) {
          addLog('warn', tr('sceneSelectorMsg.sceneDeletionNotPerformed', { message: result.message }));
          return;
        }
        addLog('log', tr('sceneSelectorMsg.sceneDeleted', { value: sceneNameOf(target.path) }));
        if (result.plan.consumers.length > 0) addLog('warn', tr('sceneSelectorMsg.sceneReferenceSWereLeft', { count: result.plan.consumers.length }));
      });
    };
    if (target.plan.isActive) openSceneThen(target.openNext, run);
    else run();
  };

  const current = scenes.find((s) => s.path === activeScene?.path);

  // o menu vive num portal (position: fixed): a barra do viewport tem overflow-hidden e o cortava
  const buttonRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [menuPos, setMenuPos] = useState<{ top: number; left: number } | null>(null);
  useEffect(() => {
    if (!open) return;
    const r = buttonRef.current?.getBoundingClientRect();
    if (r) setMenuPos({ top: r.bottom + 4, left: r.left });
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (menuRef.current?.contains(t) || buttonRef.current?.contains(t)) return;
      setOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [open]);

  return (
    <div className="relative">
      <button
        ref={buttonRef}
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#202531] hover:bg-[#2c3345] text-blue-400 font-medium border border-[#2c3345] transition-colors"
        title={tr('sceneSelector.selectScene')}
      >
        <Film className="w-3.5 h-3.5 text-blue-400 shrink-0" />
        <span className="text-[#8b97a8] text-[11px] font-normal">{tr('shared.scene')}</span>
        <span className="text-[#dfe4ec] font-semibold truncate max-w-[120px]">{activeScene?.name || tr('sceneSelectorMsgTwo.main')}</span>
        <ChevronDown className="w-3 h-3 text-[#8b97a8] shrink-0" />
      </button>

      {open && menuPos && createPortal(
        <div ref={menuRef} style={{ position: 'fixed', top: menuPos.top, left: menuPos.left }} className="w-72 bg-[#1a1e29] border border-[#3b475f] rounded-md shadow-2xl py-1 z-[1000] text-xs divide-y divide-[#2c3345]" role="menu" aria-label={tr('sceneSelector.scenes')}>
          <div className="px-3 py-1.5 flex items-center justify-between text-[11px] font-semibold text-[#8b97a8] uppercase tracking-wider bg-[#141822]">
            <span>{tr('sceneSelector.scenes')}</span>
            <span className="text-[10px] text-[#55637a] lowercase">{tr('sceneSelector.total', { length: scenes.length })}</span>
          </div>

          <div className="py-1 max-h-56 overflow-y-auto">
            {scenes.map((s) => {
              const isCurrent = s.path === activeScene?.path;
              return (
                <div key={s.path} data-scene-path={s.path} className={`group flex items-center gap-1 px-2 py-1 hover:bg-[#2c3345] ${isCurrent ? 'bg-[#20293d] text-white font-medium' : 'text-[#dfe4ec]'}`}>
                  {renaming === s.path ? (
                    <input
                      autoFocus
                      value={renameValue}
                      aria-label={tr('sceneSelector.newSceneName')}
                      aria-invalid={!!renameError}
                      title={renameError ?? undefined}
                      spellCheck={false}
                      onFocus={(e) => e.currentTarget.select()}
                      onChange={(e) => {
                        setRenameValue(e.target.value);
                        setRenameError(null);
                      }}
                      onBlur={() => commitRename(s)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          commitRename(s);
                        } else if (e.key === 'Escape') {
                          e.preventDefault();
                          setRenaming(null);
                          setRenameError(null);
                        }
                      }}
                      className={`${fieldCls} ${renameError ? 'border-rose-500' : ''}`}
                    />
                  ) : (
                    <button onClick={() => select(s.path)} className="flex-1 min-w-0 flex items-center gap-2 text-left py-0.5">
                      <Film className={`w-3.5 h-3.5 shrink-0 ${isCurrent ? 'text-blue-400' : 'text-[#8b97a8]'}`} />
                      <div className="truncate min-w-0">
                        <div className="truncate text-xs">{s.name}</div>
                        <div className="text-[10px] text-[#718096] truncate">{s.path}</div>
                      </div>
                      {isCurrent && (
                        <span className="flex items-center gap-1 shrink-0 text-emerald-400 text-[10px] font-semibold px-1.5 py-0.5 rounded bg-emerald-950/60 border border-emerald-800/60">
                          <Check className="w-3 h-3" />
                          {tr('shared.active')}
                        </span>
                      )}
                    </button>
                  )}
                  <div className="flex items-center shrink-0">
                    <button
                      onClick={() => setInitial(s)}
                      aria-label={s.isInitial ? tr('sceneSelectorMsg.startScene') : tr('sceneSelectorMsg.setAsStart')}
                      aria-pressed={s.isInitial}
                      title={s.isInitial ? tr('sceneSelectorMsg.projectStartScene') : tr('sceneSelectorMsg.setAsStartScene')}
                      className={`p-1 rounded ${s.isInitial ? 'text-amber-400' : 'text-[#55637a] hover:text-amber-300'}`}
                    >
                      <Star className={`w-3 h-3 ${s.isInitial ? 'fill-current' : ''}`} />
                    </button>
                    <button onClick={() => startRename(s)} aria-label={tr('sceneSelector.renameScene')} title={tr('shared.rename')} className="p-1 rounded text-[#8b97a8] hover:text-white">
                      <Pencil className="w-3 h-3" />
                    </button>
                    <button onClick={() => duplicate(s)} aria-label={tr('sceneSelector.duplicateScene')} title={tr('shared.duplicate')} className="p-1 rounded text-[#8b97a8] hover:text-white">
                      <Copy className="w-3 h-3" />
                    </button>
                    <button onClick={() => requestDelete(s)} aria-label={tr('sceneSelector.deleteScene')} title={tr('shared.delete')} className="p-1 rounded text-[#8b97a8] hover:text-rose-400">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {notice && (
            <div role="alert" className="px-3 py-2 text-[11px] text-amber-300 bg-amber-500/10 flex items-start gap-2">
              <span className="flex-1">{notice}</span>
              <button onClick={() => setNotice(null)} aria-label={tr('shared.closeNotice')} className="text-amber-200/70 hover:text-white">
                <X className="w-3 h-3" />
              </button>
            </div>
          )}

          <div className="py-1 bg-[#141822]">
            <div className="px-2.5 py-1 text-[10px] font-semibold text-[#8b97a8] uppercase tracking-wider">{tr('sceneSelector.sceneActions')}</div>
            <button
              onClick={() => {
                saveCurrentScene();
                setOpen(false);
              }}
              className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 text-[#dfe4ec]"
            >
              <Save className="w-3.5 h-3.5 text-amber-400" />
              <span>{tr('sceneSelector.saveCurrentScene')}</span>
            </button>
            <button
              onClick={() => {
                createNewScene('3D');
                setOpen(false);
              }}
              className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 text-[#dfe4ec]"
            >
              <Plus className="w-3.5 h-3.5 text-blue-400" />
              <span>{tr('sceneSelector.new3dScene')}</span>
            </button>
            <button
              onClick={() => {
                createNewScene('Empty');
                setOpen(false);
              }}
              className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 text-[#dfe4ec]"
            >
              <Plus className="w-3.5 h-3.5 text-emerald-400" />
              <span>{tr('sceneSelector.newEmptyScene')}</span>
            </button>
            <button
              onClick={() => {
                setSettingsOpen(true);
                setOpen(false);
              }}
              className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 text-[#dfe4ec]"
            >
              <Settings className="w-3.5 h-3.5 text-[#9ca7b7]" />
              <span>{tr('sceneSelector.sceneSettings2')}</span>
            </button>
          </div>
        </div>,
        document.body,
      )}

      {settingsOpen && current && (
        <SceneSettingsDialog
          scene={current}
          onClose={() => setSettingsOpen(false)}
          onRename={(name) => renameSceneNow(current.path, name)}
          onSetInitial={() => setInitialSceneNow(current.path)}
          validate={(name) => validateSceneName(project, name, undefined, current.path)}
        />
      )}

      {del && delStep === 'choose' && (
        <div className={dialogShell} onKeyDown={(e) => e.key === 'Escape' && closeDelete()}>
          <div role="dialog" aria-label={tr('sceneSelector.deleteScene')} className={dialogBox}>
            <div className="px-4 py-3 bg-[#141720] border-b border-[#242b3b] font-semibold text-white">{tr('sceneSelector.deleteScene2', { value: sceneNameOf(del.path) })}</div>
            <div className="p-4 space-y-3">
              {del.plan.needsNewInitial && (
                <label className="block">
                  <span className="text-[#8b97a8] block mb-1">{tr('sceneSelector.thisIsTheStartScene')}</span>
                  <select
                    value={del.newInitial}
                    aria-label={tr('sceneSelector.newStartScene')}
                    onChange={(e) => setDel({ ...del, newInitial: e.target.value, openNext: del.plan.isActive ? e.target.value : del.openNext })}
                    className={fieldCls}
                  >
                    {del.plan.candidates.map((c) => (
                      <option key={c.path} value={c.path}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              {del.plan.isActive && (
                <label className="block">
                  <span className="text-[#8b97a8] block mb-1">{tr('sceneSelector.thisIsTheOpenScene')}</span>
                  <select value={del.openNext} aria-label={tr('sceneSelector.openNext')} onChange={(e) => setDel({ ...del, openNext: e.target.value })} className={fieldCls}>
                    {del.plan.candidates.map((c) => (
                      <option key={c.path} value={c.path}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </label>
              )}
              {!del.plan.needsNewInitial && !del.plan.isActive && <p>{tr('sceneSelector.theSceneWillBeDeleted')}</p>}
              {del.plan.isActive && <p className="text-[#8b97a8]">{tr('sceneSelector.ifTheOpenSceneHas')}</p>}
            </div>
            <div className="px-4 py-3 bg-[#171b24] border-t border-[#2c3345] flex justify-end gap-2">
              <button onClick={closeDelete} className="px-3 py-1.5 rounded hover:bg-[#2c3345] text-[#b3bed0]">
                {tr('shared.cancel')}
              </button>
              <button onClick={confirmChoices} className="bg-[#4982ea] hover:bg-[#3d72d6] text-white px-4 py-1.5 rounded font-medium">
                {tr('sceneSelector.continue')}
              </button>
            </div>
          </div>
        </div>
      )}

      {del && delStep === 'confirm' && <ConfirmDeleteDialog path={del.path} plan={delPlan} onConfirm={(decision) => performDelete(decision)} onCancel={closeDelete} />}
    </div>
  );
};

/** Settings da cena aberta: nome e cena inicial. */
const SceneSettingsDialog: React.FC<{
  scene: SceneInfo;
  onClose: () => void;
  onRename: (name: string) => { ok: boolean; error?: string };
  onSetInitial: () => { ok: boolean; error?: string };
  validate: (name: string) => { ok: boolean; error?: string };
}> = ({ scene, onClose, onRename, onSetInitial, validate }) => {
  const { t } = useTranslation();
  const [name, setName] = useState(scene.name);
  const [initial, setInitialFlag] = useState(scene.isInitial);
  const [error, setError] = useState<string | null>(null);
  const check = validate(name);
  const nameChanged = name !== scene.name;

  const apply = () => {
    if (nameChanged) {
      const r = onRename(name);
      if (!r.ok) return setError(r.error ?? t('sharedMsg.couldNotRename'));
    }
    if (initial && !scene.isInitial) {
      const r = onSetInitial();
      if (!r.ok) return setError(r.error ?? t('sceneSelectorMsg.couldNotSetTheStart'));
    }
    onClose();
  };

  return (
    <div className={dialogShell} onKeyDown={(e) => e.key === 'Escape' && onClose()}>
      <div role="dialog" aria-label={t('sceneSelector.sceneSettings')} className={dialogBox}>
        <div className="px-4 py-3 bg-[#141720] border-b border-[#242b3b] font-semibold text-white">{t('sceneSelector.sceneSettings')}</div>
        <div className="p-4 space-y-3">
          <label className="block">
            <span className="text-[#8b97a8] block mb-1">{t('shared.name')}</span>
            <input value={name} onChange={(e) => { setName(e.target.value); setError(null); }} aria-label={t('sceneSelector.sceneName')} aria-invalid={nameChanged && !check.ok} spellCheck={false} className={fieldCls} />
          </label>
          {nameChanged && !check.ok && <p role="alert" className="text-amber-300">{check.error}</p>}
          <label className="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked={initial} disabled={scene.isInitial} onChange={(e) => setInitialFlag(e.target.checked)} className="w-3.5 h-3.5" />
            <span>{t('sceneSelector.projectStartScene', { value: scene.isInitial ? t('sceneSelectorMsg.alreadyIs') : '' })}</span>
          </label>
          <p className="text-[#8b97a8] font-mono break-all">{scene.path}</p>
          {error && <p role="alert" className="text-amber-300">{error}</p>}
        </div>
        <div className="px-4 py-3 bg-[#171b24] border-t border-[#2c3345] flex justify-end gap-2">
          <button onClick={onClose} className="px-3 py-1.5 rounded hover:bg-[#2c3345] text-[#b3bed0]">
            {t('shared.cancel')}
          </button>
          <button onClick={apply} disabled={nameChanged && !check.ok} className="bg-[#4982ea] hover:bg-[#3d72d6] disabled:opacity-50 text-white px-4 py-1.5 rounded font-medium">
            {t('shared.apply')}
          </button>
        </div>
      </div>
    </div>
  );
};
