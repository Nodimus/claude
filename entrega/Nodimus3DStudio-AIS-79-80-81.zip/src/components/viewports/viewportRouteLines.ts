import * as THREE from 'three';
import { resolveRoute, type RouteSceneLike } from '../../core/waypoints/resolveRoute';
import { waypointColor } from '../../core/waypoints/waypointObject';

/**
 * AIS-72b §B — linhas retas que ligam, em ordem, os Waypoints filhos do contêiner de rota SELECIONADO (ou, com um Waypoint selecionado, os da
 * rota do pai dele). Apenas visual de edição: some no Play e não captura raycast. Os pontos vêm de `resolveRoute` (a única leitura de rota).
 * Recalcula só quando a cena (`nodes`) ou a seleção mudam; assim mover com o gizmo atualiza as linhas ao soltar (o Command grava o novo nó).
 */
export class RouteLinesHelper {
  private line: THREE.Line | null = null;
  private cacheNodes: RouteSceneLike['nodes'] | null = null;
  private cacheSelected: string | null | undefined = undefined;

  constructor(private readonly scene: THREE.Object3D) {}

  /** `selectedId`: nó primário selecionado. */
  update(input: { scene: RouteSceneLike; selectedId: string | null; playing: boolean }): void {
    if (input.playing) {
      if (this.line) this.line.visible = false;
      return;
    }
    if (this.cacheNodes !== input.scene.nodes || this.cacheSelected !== input.selectedId) {
      this.cacheNodes = input.scene.nodes;
      this.cacheSelected = input.selectedId;
      this.rebuild(input.scene, input.selectedId);
    }
    if (this.line) this.line.visible = this.line.userData.hasRoute === true;
  }

  private rebuild(scene: RouteSceneLike, selectedId: string | null): void {
    this.dispose();
    const selected = selectedId ? scene.nodes[selectedId] : undefined;
    if (!selected) return;
    const containerId = selected.type === 'Waypoint' ? selected.parentId : selected.id;
    if (!containerId) return;
    const route = resolveRoute(scene, containerId);
    if (!route.ok || route.points.length < 2) return;
    const first = scene.nodes[route.points[0].id];
    const geometry = new THREE.BufferGeometry().setFromPoints(route.points.map((p) => new THREE.Vector3(p.position.x, p.position.y, p.position.z)));
    const line = new THREE.Line(geometry, new THREE.LineBasicMaterial({ color: waypointColor(first?.properties), transparent: true, opacity: 0.85, depthTest: false }));
    line.name = 'waypoint-route-lines';
    line.renderOrder = 997;
    line.raycast = () => {};
    line.userData.isEditorHelper = true;
    line.userData.hasRoute = true;
    this.scene.add(line);
    this.line = line;
  }

  dispose(): void {
    if (!this.line) return;
    this.line.removeFromParent();
    this.line.geometry.dispose();
    (this.line.material as THREE.Material).dispose();
    this.line = null;
  }
}
