import * as THREE from 'three';
import type { ResourceRef } from '../../types/node';
import type { RuntimeSession } from '../../runtime/RuntimeSession';
import { hashContent } from '../../core/documents/documentKinds';
import { frameRect, planeShift, resolveSprite, spriteClips, textureWindow, type FilesLike, type ResolvedSprite } from '../../core/sprites/spriteResource';

/**
 * AIS-76 (decisão 24) — desenho do `Billboard` como `AnimatedSprite3D`: o quadro ativo é uma REGIÃO do atlas PNG (UV do `textureWindow`),
 * `NearestFilter` quando o recurso pede pixel perfeito. O mesmo código serve a edição (quadro estático: animação/`frame` do nó) e o Play
 * (quadro vindo do `SpriteHost` da sessão, que usa `clipFrameIndexAtTime`): nunca lógica de frame inline aqui.
 *
 * O nó REFERENCIA o `SpriteProject` por `ResourceRef`; o apresentador o lê do projeto aberto (`env.files`) e nunca o copia para `properties`.
 */

export interface SpriteEnv {
  files(): FilesLike;
  pathOf(ref: ResourceRef): string | undefined;
}

const keyOf = (r: ResolvedSprite, files: FilesLike): string => {
  const tex = r.project.sheetConfig.texture;
  const texPath = tex?.path;
  return `${r.path ?? 'embedded'}|${hashContent(r.path ? files[r.path]?.content : r.atlasUrl)}|${hashContent(r.atlasUrl)}|${texPath ?? ''}`;
};

/** Controlador de UM mesh de Billboard: carrega o atlas, aplica a região do frame, flips, tamanho, `centered` e `offset`. */
export class BillboardSpriteView {
  /** `true` enquanto o apresentador do Play dirige o quadro (a sincronização de edição não o sobrescreve). */
  driven = false;
  private key = '';
  private resolved: ResolvedSprite | null = null;
  private texture: THREE.Texture | null = null;
  private atlasW = 0;
  private atlasH = 0;
  private epoch = 0;
  private geometryKey = '';
  private lastWindow = '';

  constructor(
    private readonly mesh: THREE.Mesh,
    private readonly env: SpriteEnv
  ) {}

  /** O que está resolvido agora (clipes, avisos…). `null` = sem sprite ou erro. */
  get sprite(): ResolvedSprite | null {
    return this.resolved;
  }

  /**
   * Edição: aplica as propriedades do nó. `frameGlobal` (Play) é o índice global do frame no atlas; ausente = quadro estático da animação do
   * nó (posição `frame` da animação escolhida ou da padrão).
   */
  sync(properties: Record<string, any>, frameGlobal?: number): ResolvedSprite | null {
    if (this.driven && frameGlobal === undefined) return this.resolved;
    const files = this.env.files();
    const r = resolveSprite(properties.spriteProject, files, this.env.pathOf);
    if (!r || !r.ok) {
      this.clear();
      return null;
    }
    const key = keyOf(r, files);
    if (key !== this.key) {
      this.key = key;
      this.resolved = r;
      this.loadTexture(r);
    } else {
      this.resolved = r;
    }
    this.applyGeometry(properties);
    this.applyMaterial(r);
    const frame = frameGlobal ?? this.staticFrame(r, properties);
    this.applyFrame(r, frame, properties);
    return r;
  }

  /** Quadro estático da edição: posição `frame` dentro da animação do nó (vazia = a padrão). */
  private staticFrame(r: ResolvedSprite, properties: Record<string, any>): number {
    const { clips, defaultAnimation } = spriteClips(r.project);
    const name = typeof properties.animation === 'string' ? properties.animation.trim() : '';
    const clip = clips.find((c) => c.name === name) ?? clips.find((c) => c.name === defaultAnimation) ?? clips[0];
    const pos = Math.max(0, Math.floor(Number.isFinite(properties.frame) ? properties.frame : 0));
    if (!clip || clip.frameIndices.length === 0) return Math.min(pos, Math.max(0, r.project.frames.length - 1));
    return clip.frameIndices[Math.min(pos, clip.frameIndices.length - 1)];
  }

  private loadTexture(r: ResolvedSprite): void {
    const epoch = ++this.epoch;
    this.disposeTexture();
    this.lastWindow = '';
    if (!r.atlasUrl) return;
    new THREE.TextureLoader().load(
      r.atlasUrl,
      (tex) => {
        if (epoch !== this.epoch) {
          tex.dispose();
          return;
        }
        const img = tex.image as { width?: number; height?: number } | undefined;
        this.atlasW = img?.width || r.project.sheetConfig.imageWidth || 1;
        this.atlasH = img?.height || r.project.sheetConfig.imageHeight || 1;
        this.texture = tex;
        this.configureTexture(r);
        const mat = this.mesh.material as THREE.MeshBasicMaterial;
        mat.map = tex;
        mat.needsUpdate = true;
        this.lastWindow = '';
        this.pendingFrame && this.applyFrame(this.pendingFrame.r, this.pendingFrame.frame, this.pendingFrame.props);
      },
      undefined,
      () => {
        if (epoch === this.epoch) this.texture = null;
      }
    );
  }

  private pendingFrame: { r: ResolvedSprite; frame: number; props: Record<string, any> } | null = null;

  private configureTexture(r: ResolvedSprite): void {
    const tex = this.texture;
    if (!tex) return;
    const s = r.project.settings3D;
    const filter = s.pixelPerfectFilter ? THREE.NearestFilter : THREE.LinearFilter;
    tex.magFilter = filter;
    tex.minFilter = filter;
    tex.generateMipmaps = false;
    tex.wrapS = s.tileH ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
    tex.wrapT = s.tileV ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
    tex.premultiplyAlpha = !!s.premultiplyAlpha;
    tex.needsUpdate = true;
  }

  private applyMaterial(r: ResolvedSprite): void {
    const s = r.project.settings3D;
    const mat = this.mesh.material as THREE.MeshBasicMaterial;
    const side = s.doubleSided ? THREE.DoubleSide : THREE.FrontSide;
    if (mat.side !== side || mat.alphaTest !== s.alphaTest) {
      mat.side = side;
      mat.alphaTest = s.alphaTest;
      mat.needsUpdate = true;
    }
    if (this.texture && (this.texture.magFilter === THREE.NearestFilter) !== !!s.pixelPerfectFilter) this.configureTexture(r);
  }

  private applyGeometry(properties: Record<string, any>): void {
    const width = Number.isFinite(properties.width) && properties.width > 0 ? properties.width : 1.5;
    const height = Number.isFinite(properties.height) && properties.height > 0 ? properties.height : 2;
    const centered = properties.centered !== false;
    const shift = planeShift(width, height, centered, properties.offset);
    const key = `${width}|${height}|${shift.x}|${shift.y}`;
    if (key === this.geometryKey) return;
    this.geometryKey = key;
    const geo = new THREE.PlaneGeometry(width, height);
    geo.translate(shift.x, shift.y, 0);
    const old = this.mesh.geometry;
    this.mesh.geometry = geo;
    old.dispose();
    for (const child of this.mesh.children) {
      if ((child as THREE.LineSegments).isLineSegments) {
        const lines = child as THREE.LineSegments;
        lines.geometry.dispose();
        lines.geometry = new THREE.EdgesGeometry(geo);
      }
    }
  }

  private applyFrame(r: ResolvedSprite, frame: number, properties: Record<string, any>): void {
    this.pendingFrame = { r, frame, props: properties };
    const tex = this.texture;
    if (!tex) return;
    const rect = frameRect(r.project, frame);
    if (!rect) return;
    const flipH = properties.flipH === true;
    const flipV = properties.flipV === true;
    const w = textureWindow(rect, this.atlasW, this.atlasH, flipH, flipV);
    const k = `${w.repeatX}|${w.repeatY}|${w.offsetX}|${w.offsetY}`;
    if (k === this.lastWindow) return;
    this.lastWindow = k;
    tex.repeat.set(w.repeatX, w.repeatY);
    tex.offset.set(w.offsetX, w.offsetY);
  }

  private clear(): void {
    if (!this.key) return;
    this.key = '';
    this.resolved = null;
    this.epoch++;
    this.pendingFrame = null;
    this.disposeTexture();
    const mat = this.mesh.material as THREE.MeshBasicMaterial;
    mat.map = null;
    mat.needsUpdate = true;
  }

  private disposeTexture(): void {
    this.texture?.dispose();
    this.texture = null;
  }

  dispose(): void {
    this.epoch++;
    this.disposeTexture();
    this.pendingFrame = null;
  }
}

/** Mesh do Billboard → seu controlador (criado sob demanda). */
export function spriteViewOf(mesh: THREE.Mesh, env: SpriteEnv): BillboardSpriteView {
  const holder = mesh as THREE.Mesh & { __spriteView?: BillboardSpriteView };
  return (holder.__spriteView ??= new BillboardSpriteView(mesh, env));
}

/**
 * Apresentador do Play: registra os clipes de cada `Billboard` vivo no `SpriteHost` da sessão, mantém as propriedades vivas
 * (`animation`, `speedScale`, `autoplay`/`frame`) sincronizadas e entrega o quadro ativo ao desenho. Mesmo desenho do `ViewportAnimation`.
 */
export class ViewportSprites {
  private scene: object | null = null;
  private readonly driven = new Map<string, BillboardSpriteView>();

  constructor(private readonly env: SpriteEnv) {}

  get activeCount(): number {
    return this.driven.size;
  }

  get hasScene(): boolean {
    return this.scene !== null;
  }

  /** Um quadro do Play. */
  update(session: RuntimeSession, objects: ReadonlyMap<string, THREE.Object3D>): void {
    const scene = session.currentScene;
    if (!scene || scene.disposed) {
      this.reset(session);
      return;
    }
    if (scene !== this.scene) {
      this.reset(session);
      this.scene = scene;
    }
    for (const instance of scene.getAllInstances()) {
      if (instance.type !== 'Billboard' || instance.disposed) continue;
      const nodeId = instance.persistentNodeId;
      const obj = objects.get(nodeId) as THREE.Mesh | undefined;
      if (!obj || !obj.isMesh) continue;
      const props = instance.properties;
      const view = spriteViewOf(obj, this.env);
      let driven = this.driven.get(nodeId);
      if (!driven) {
        const r = view.sync(props); // resolve e carrega o atlas
        if (!r) continue; // sem sprite (ou erro): o desenho de edição fica como está
        const { clips, defaultAnimation } = spriteClips(r.project);
        session.sprites.register(nodeId, { clips, defaultAnimation, animation: String(props.animation ?? ''), speedScale: props.speedScale, autoplay: props.autoplay !== false, frame: props.frame, frameCount: r.project.frames.length });
        view.driven = true;
        this.driven.set(nodeId, view);
        driven = view;
      }
      const host = session.sprites;
      const wanted = typeof props.animation === 'string' ? props.animation.trim() : '';
      const current = host.animationOf(nodeId);
      if (wanted && wanted !== current) host.setAnimation(nodeId, wanted);
      host.setSpeedScale(nodeId, typeof props.speedScale === 'number' ? props.speedScale : 1);
      if (!host.isPlaying(nodeId)) host.setFrame(nodeId, Number.isFinite(props.frame) ? props.frame : 0);
      const frame = host.frameOf(nodeId);
      driven.sync(props, frame >= 0 ? frame : 0);
    }
  }

  /** Stop, restart e troca de cena: devolve os desenhos ao quadro estático de edição. */
  reset(session?: RuntimeSession): void {
    for (const [nodeId, view] of this.driven) {
      view.driven = false;
      session?.sprites.unregister(nodeId);
    }
    this.driven.clear();
    this.scene = null;
  }
}
