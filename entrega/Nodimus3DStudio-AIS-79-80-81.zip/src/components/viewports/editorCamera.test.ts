import { describe, expect, it, vi } from 'vitest';
import * as THREE from 'three';
import {
  EditorCameraController,
  EDITOR_CAMERA_FOV,
  frameDistanceFor,
  frameDistanceForSphere,
  MAX_RADIUS,
  MIN_RADIUS,
  viewPresetForShortcut,
  visibleHeightAt,
} from './editorCamera';

const settle = (c: EditorCameraController, aspect = 1.5) => {
  for (let i = 0; i < 240; i++) c.update(1 / 60, aspect);
};

describe('EditorCameraController (AIS-07)', () => {
  it('começa em Perspective com FOV 60° e a câmera olhando para o alvo', () => {
    const c = new EditorCameraController();
    expect(c.currentView).toBe('Perspective');
    expect(c.camera).toBe(c.perspective);
    expect(c.perspective.fov).toBe(EDITOR_CAMERA_FOV);
    expect(c.camera.position.distanceTo(c.target)).toBeCloseTo(c.spherical.radius);
  });

  it('órbita (botão direito) gira em torno do alvo sem mudar a distância e respeita os limites de phi', () => {
    const c = new EditorCameraController();
    const target = c.target.clone();
    c.orbit(120, 0);
    expect(c.target.equals(target)).toBe(true);
    expect(c.camera.position.distanceTo(c.target)).toBeCloseTo(14);
    c.orbit(0, -100000);
    expect(c.spherical.phi).toBeLessThan(Math.PI);
    c.orbit(0, 100000);
    expect(c.spherical.phi).toBeGreaterThan(0);
  });

  it('pan (botão do meio) desloca alvo e câmera juntos, na escala do mundo visível', () => {
    const c = new EditorCameraController();
    c.setView('Front'); // direita da tela = +X
    const before = c.target.clone();
    const px = 100;
    const viewportH = 500;
    c.pan(-px, 0, viewportH); // arrastar para a esquerda move o alvo para +X
    const expected = (visibleHeightAt(c.spherical.radius) / viewportH) * px;
    expect(c.target.x - before.x).toBeCloseTo(expected);
    expect(c.camera.position.distanceTo(c.target)).toBeCloseTo(c.spherical.radius);
  });

  it('zoom (roda) é suave: converge ao alvo em vários quadros e fica nos limites', () => {
    const c = new EditorCameraController();
    c.zoom(500);
    const goal = c.zoomTarget;
    expect(goal).toBeGreaterThan(14);
    c.update(1 / 60, 1.5);
    expect(c.spherical.radius).toBeGreaterThan(14);
    expect(c.spherical.radius).toBeLessThan(goal); // um quadro não chega lá
    settle(c);
    expect(c.spherical.radius).toBeCloseTo(goal);

    c.zoom(1e6);
    settle(c);
    expect(c.spherical.radius).toBeCloseTo(MAX_RADIUS);
    c.zoom(-1e6);
    settle(c);
    expect(c.spherical.radius).toBeCloseTo(MIN_RADIUS);
  });

  it('vistas Top/Front/Right usam câmera ortográfica alinhada ao eixo', () => {
    const c = new EditorCameraController();
    const dir = new THREE.Vector3();

    c.setView('Top');
    expect(c.camera).toBe(c.orthographic);
    c.camera.getWorldDirection(dir);
    expect(dir.y).toBeCloseTo(-1);

    c.setView('Front');
    c.camera.getWorldDirection(dir);
    expect(dir.z).toBeCloseTo(-1);

    c.setView('Right');
    c.camera.getWorldDirection(dir);
    expect(dir.x).toBeCloseTo(-1);

    c.setView('Perspective');
    expect(c.camera).toBe(c.perspective);
  });

  it('setAxisView alinha a câmera ortográfica aos quatro eixos do gizmo', () => {
    const c = new EditorCameraController();
    const dir = new THREE.Vector3();
    const cases = [
      ['+X', [-1, 0, 0]],
      ['-X', [1, 0, 0]],
      ['+Y', [0, -1, 0]],
      ['+Z', [0, 0, -1]],
    ] as const;

    for (const [axis, expected] of cases) {
      c.setAxisView(axis);
      c.camera.getWorldDirection(dir);
      expect(dir.x).toBeCloseTo(expected[0]);
      expect(dir.y).toBeCloseTo(expected[1]);
      expect(dir.z).toBeCloseTo(expected[2]);
      expect(c.camera).toBe(c.orthographic);
    }
  });

  it('ortográfica tem a mesma escala visível da perspectiva e acompanha o aspecto', () => {
    const c = new EditorCameraController();
    c.setView('Front');
    c.update(0, 2);
    const h = visibleHeightAt(c.spherical.radius);
    expect(c.orthographic.top - c.orthographic.bottom).toBeCloseTo(h);
    expect(c.orthographic.right - c.orthographic.left).toBeCloseTo(h * 2);
    expect(c.perspective.aspect).toBe(2);
  });

  it('orbitar numa vista alinhada mantém ortográfica em ângulo livre (Ortho) e notifica', () => {
    const c = new EditorCameraController();
    const onViewChange = vi.fn();
    c.onViewChange = onViewChange;
    c.setView('Top');
    c.orbit(50, 40);
    expect(c.currentView).toBe('Ortho');
    expect(c.camera).toBe(c.orthographic);
    expect(onViewChange).toHaveBeenLastCalledWith('Ortho');
    c.pan(10, 10, 400);
    c.zoom(100);
    expect(c.currentView).toBe('Ortho'); // pan/zoom não trocam a vista
  });

  it('Ortho escolhido pelo seletor preserva o ângulo atual', () => {
    const c = new EditorCameraController();
    c.orbit(77, 13);
    const { theta, phi } = c.spherical;
    c.setView('Ortho');
    expect(c.camera).toBe(c.orthographic);
    expect(c.spherical.theta).toBe(theta);
    expect(c.spherical.phi).toBe(phi);
  });

  it('frame interpola target e distância suavemente; getState/setState restauram tudo', () => {
    const c = new EditorCameraController();
    c.orbit(30, 10);
    const saved = c.getState();
    const startTarget = c.target.clone();
    const startRadius = c.spherical.radius;
    const frameTarget = new THREE.Vector3(5, 0, -3);
    c.frame(frameTarget, 6, 0.4);
    expect(c.target.equals(startTarget)).toBe(true);
    expect(c.spherical.radius).toBe(startRadius);
    c.update(0.2, 1.5);
    expect(c.target.x).toBeCloseTo((startTarget.x + frameTarget.x) / 2);
    expect(c.spherical.radius).toBeCloseTo((startRadius + 6) / 2);
    c.update(0.2, 1.5);
    expect(c.target.toArray()).toEqual([5, 0, -3]);
    expect(c.camera.position.distanceTo(c.target)).toBeCloseTo(6);
    c.setView('Top');
    c.setState(saved);
    expect(c.currentView).toBe('Perspective');
    expect(c.target.equals(saved.target)).toBe(true);
    expect(c.spherical).toEqual(saved.spherical);
  });

  it('frameDistanceFor: maior lado cabe na vista com folga; mínimo 2,5', () => {
    // FOV 60 → tan(30°) ≈ 0,577; lado 4 → 2/0,577·1,6 ≈ 5,543
    expect(frameDistanceFor({ x: 1, y: 4, z: 1 })).toBeCloseTo(5.543, 2);
    expect(frameDistanceFor({ x: 0.1, y: 0.1, z: 0.1 })).toBe(2.5);
    expect(frameDistanceFor({ x: 10, y: 1, z: 1 })).toBeGreaterThan(frameDistanceFor({ x: 4, y: 1, z: 1 }));
  });

  it('frameDistanceForSphere escala com o raio e mantém distância mínima para objetos minúsculos', () => {
    expect(frameDistanceForSphere(2)).toBeCloseTo(frameDistanceFor({ x: 4, y: 4, z: 4 }));
    expect(frameDistanceForSphere(0)).toBe(2.5);
    expect(frameDistanceForSphere(4)).toBeGreaterThan(frameDistanceForSphere(2));
  });

  it('Ctrl/Cmd + 1–4 mapeiam as vistas (fileira e numpad); demais combinações não', () => {
    const k = (code: string, mods: Partial<{ ctrlKey: boolean; metaKey: boolean; altKey: boolean; shiftKey: boolean }> = {}) =>
      viewPresetForShortcut({ code, ctrlKey: false, metaKey: false, altKey: false, shiftKey: false, ...mods });
    expect(k('Digit0', { ctrlKey: true })).toBe('Perspective');
    expect(k('Numpad0', { metaKey: true })).toBe('Perspective');
    expect(k('Digit1', { ctrlKey: true })).toBe('Perspective');
    expect(k('Digit2', { ctrlKey: true })).toBe('Top');
    expect(k('Numpad3', { ctrlKey: true })).toBe('Front');
    expect(k('Digit4', { metaKey: true })).toBe('Right');
    expect(k('Digit1')).toBeNull(); // sem modificador
    expect(k('Digit5', { ctrlKey: true })).toBeNull();
    expect(k('Digit2', { ctrlKey: true, shiftKey: true })).toBeNull();
    expect(k('Digit2', { ctrlKey: true, altKey: true })).toBeNull();
    expect(k('F2', { ctrlKey: true })).toBeNull();
  });
});

describe('Travar View (AIS-74)', () => {
  const angles = (c: EditorCameraController) => ({ theta: c.spherical.theta, phi: c.spherical.phi });

  it('ligado, a órbita NÃO responde ao input (rotação congelada); desligado, volta a responder', () => {
    const c = new EditorCameraController();
    c.orbit(50, 20);
    const frozen = angles(c);
    c.setOrbitLocked(true);
    expect(c.isOrbitLocked).toBe(true);
    c.orbit(300, -120);
    c.orbit(-80, 40);
    expect(angles(c)).toEqual(frozen);
    c.setOrbitLocked(false);
    c.orbit(50, 20);
    expect(angles(c)).not.toEqual(frozen);
  });

  it('com o lock ligado, pan e zoom continuam LIVRES e não alteram a rotação', () => {
    const c = new EditorCameraController();
    c.setOrbitLocked(true);
    const before = angles(c);
    const targetBefore = c.target.clone();
    const radiusBefore = c.spherical.radius;
    c.pan(120, -60, 600);
    c.zoom(-400);
    settle(c);
    expect(c.target.distanceTo(targetBefore)).toBeGreaterThan(0.1); // pan moveu
    expect(c.spherical.radius).toBeLessThan(radiusBefore); // zoom aproximou
    expect(angles(c)).toEqual(before); // rotação intacta
    c.frame(new THREE.Vector3(5, 0, 5), 9, 0); // enquadrar (F) também preserva os ângulos
    expect(angles(c)).toEqual(before);
  });

  it('a projeção é independente do lock: Perspective ⇄ ortográfica troca com o lock ligado, sem mudar a rotação nem o lock', () => {
    const c = new EditorCameraController();
    c.orbit(40, 10);
    c.setOrbitLocked(true);
    const before = angles(c);
    c.setView('Top'); // pedir uma vista alinhada = girar a câmera: com lock só a projeção muda
    expect(c.camera).toBe(c.orthographic);
    expect(c.currentView).toBe('Ortho'); // rotulada "livre": os ângulos não são os de Top
    expect(angles(c)).toEqual(before);
    expect(c.isOrbitLocked).toBe(true);
    c.setView('Perspective');
    expect(c.camera).toBe(c.perspective);
    expect(angles(c)).toEqual(before); // não volta ao ângulo padrão
    expect(c.isOrbitLocked).toBe(true);
    c.setAxisView('+X'); // alinhar ao eixo também é girar: ignorado
    expect(angles(c)).toEqual(before);
  });

  it('alternar a projeção SEM lock continua como antes (Top alinha) e não liga nem desliga o lock', () => {
    const c = new EditorCameraController();
    c.setView('Top');
    expect(c.spherical.phi).toBeLessThan(0.01);
    expect(c.isOrbitLocked).toBe(false);
    c.setView('Perspective');
    expect(c.isOrbitLocked).toBe(false);
  });

  it('restaurar uma cena salva: setOrbitLocked(true, ângulos) leva a rotação ao valor congelado e trava', () => {
    const c = new EditorCameraController();
    c.setOrbitLocked(true, { theta: 1.25, phi: 0.9 });
    expect(angles(c)).toEqual({ theta: 1.25, phi: 0.9 });
    c.orbit(100, 100);
    expect(angles(c)).toEqual({ theta: 1.25, phi: 0.9 });
    expect(c.camera.position.distanceTo(c.target)).toBeCloseTo(c.spherical.radius); // a câmera foi reposicionada
    c.setOrbitLocked(true, { theta: Number.NaN, phi: 0.5 }); // ângulo inválido é ignorado
    expect(angles(c)).toEqual({ theta: 1.25, phi: 0.9 });
  });
});
