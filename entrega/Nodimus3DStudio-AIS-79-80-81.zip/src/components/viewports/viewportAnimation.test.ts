import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import type { GameNode, ResourceRef } from '../../types/node';
import type { SceneData } from '../../types/scene';
import { createDefault3DStarterScene } from '../../core/defaultProject';
import { createRuntimeSnapshot } from '../../core/authoring/snapshot';
import { ModelCache } from '../../core/models/modelCache';
import { createModelObject, type ModelSourceBinding } from '../../core/models/createModelObject';
import { buildAnimatedGlb, buildAnimationOnlyGlb } from '../../core/models/modelFixtures';
import { bytesToDataUrl } from '../../core/models/modelBytes';
import { loadPlayerClips } from '../../core/models/playClips';
import { loadModel } from '../../core/models/modelLoader';
import { RuntimeSession } from '../../runtime/RuntimeSession';
import { ViewportAnimation } from './viewportAnimation';

/**
 * AIS-60/60b — o apresentador carrega os clipes do objeto animado (MeshInstance com `animated`) (embutidos e da biblioteca do rig), cria o mixer sobre o objeto do modelo
 * e aplica as camadas da sessão ao esqueleto: Idle → Walk com crossfade em segundos, pausa, Stop devolvendo a pose.
 */

const HERO: ResourceRef = { id: 'hero', type: 'model', path: 'res://models/hero.glb' };
const RIG: ResourceRef = { id: 'rig', type: 'rig', path: 'res://materials/hero_rig.json' };
const EXTRA: ResourceRef = { id: 'extra', type: 'model', path: 'res://models/extra_walk.glb' };

const glb = (clips?: { name: string; dx: number }[]) => bytesToDataUrl(buildAnimatedGlb(clips), 'model/gltf-binary');

function makeSource(files: Record<string, { uri: string; content?: string }>): ModelSourceBinding {
  return {
    resolve: (ref) => {
      const f = files[ref.id];
      return f ? { resourceId: ref.id, uri: f.uri, contentHash: 'h1', content: f.content } : null;
    },
    readFile: (uri) => Object.values(files).find((f) => f.uri === uri)?.content,
    report: () => {},
  };
}

const rigJson = (clips: unknown[]) =>
  JSON.stringify({ schemaVersion: 1, asset: HERO, standard: 'humanoid19', bones: {}, clips });

const node = (id: string, type: string, parentId: string, props: Record<string, any> = {}, extra: Partial<GameNode> = {}): GameNode =>
  ({ id, name: id, type, parentId, childrenIds: [], visible: true, locked: false, properties: props, ...extra }) as unknown as GameNode;

async function setup(source: ModelSourceBinding, animation: Record<string, any> = {}) {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = {
    [root.id]: { ...root, childrenIds: ['hero'] } as GameNode,
    hero: node('hero', 'MeshInstance', root.id, { meshType: 'CubeMesh', animated: true, animation }),
  };
  const session = new RuntimeSession({
    snapshot: createRuntimeSnapshot({ ...scene, nodes } as unknown as SceneData),
    input: { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never,
  });
  session.start();
  const handle = createModelObject(HERO, { source, cache: new ModelCache() });
  await handle.ready;
  const objects = new Map<string, THREE.Object3D>([['hero', handle.object]]);
  const presenter = new ViewportAnimation(source);
  presenter.update(session, objects);
  for (let i = 0; i < 200 && !session.animation.isRegistered('hero'); i++) await new Promise((r) => setTimeout(r, 5));
  presenter.update(session, objects);
  const bodyX = () => handle.object.getObjectByName('Body')!.position.x;
  return { session, presenter, handle, objects, bodyX };
}

const frame = (s: Awaited<ReturnType<typeof setup>>, seconds: number) => {
  for (let t = 0; t < seconds - 1e-9; t += 1 / 60) {
    s.session.step(1 / 60);
    s.presenter.update(s.session, s.objects);
  }
};

describe('clipes embutidos no modelo (sem rig)', () => {
  const source = makeSource({ hero: { uri: 'res://models/hero.glb', content: glb([{ name: 'Idle', dx: 0.5 }, { name: 'Walk', dx: 2 }]) } });

  it('registra os clipes do modelo na sessão e o esqueleto (nó Body) segue o clipe tocado', async () => {
    const s = await setup(source);
    expect(s.session.animation.clipsOf('hero').map((c) => c.name)).toEqual(['Idle', 'Walk']);
    s.session.animation.play('hero', 'Walk', { crossfade: 0 });
    frame(s, 0.5);
    expect(s.bodyX()).toBeCloseTo(1, 1); // Walk: 0 → 2 em 1 s; aos 0,5 s está em 1
    frame(s, 0.25);
    expect(s.bodyX()).toBeCloseTo(1.5, 1);
    s.presenter.reset();
    s.handle.release();
    s.session.dispose();
  });

  it('crossfade Idle → Walk em segundos mistura as poses e termina no clipe novo', async () => {
    const s = await setup(source);
    s.session.animation.play('hero', 'Idle', { crossfade: 0 });
    frame(s, 0.5); // Idle: 0 → 0,5 em 1 s → 0,25
    expect(s.bodyX()).toBeCloseTo(0.25, 1);
    s.session.animation.play('hero', 'Walk', { crossfade: 0.4 });
    frame(s, 0.2); // metade do crossfade: peso 0,5 em cada clipe
    const mid = s.bodyX();
    const idleAt = 0.35 * 0.5 + 0; // Idle em ~0,7 s
    expect(mid).toBeGreaterThan(idleAt); // já puxado para o Walk
    expect(mid).toBeLessThan(0.2 * 2 + 1); // e ainda não é o Walk puro
    frame(s, 0.3);
    expect(s.session.animation.layersOf('hero')).toHaveLength(1);
    expect(s.bodyX()).toBeCloseTo((0.5 / 1) * 2, 0); // Walk puro depois do crossfade
    s.presenter.reset();
    s.handle.release();
    s.session.dispose();
  });

  it('a pausa do Play congela o esqueleto; pause_animation também', async () => {
    const s = await setup(source);
    s.session.animation.play('hero', 'Walk', { crossfade: 0 });
    frame(s, 0.3);
    s.session.pause();
    const x = s.bodyX();
    for (let i = 0; i < 30; i++) {
      s.session.step(1 / 60); // pausada: não passa o tempo
      s.presenter.update(s.session, s.objects);
    }
    expect(s.bodyX()).toBeCloseTo(x, 6);
    s.session.resume();
    s.session.animation.pause('hero', true);
    frame(s, 0.3);
    expect(s.bodyX()).toBeCloseTo(x, 6);
    s.presenter.reset();
    s.handle.release();
    s.session.dispose();
  });

  it('Stop/reset devolve a pose original ao esqueleto e desregistra o player', async () => {
    const s = await setup(source);
    s.session.animation.play('hero', 'Walk', { crossfade: 0 });
    frame(s, 0.5);
    expect(s.bodyX()).toBeGreaterThan(0.5);
    s.presenter.reset();
    expect(s.bodyX()).toBeCloseTo(0, 6);
    expect(s.session.animation.isRegistered('hero')).toBe(false);
    s.handle.release();
    s.session.dispose();
  });

  it('autoplay + animação padrão do objeto começam tocando; speed vale', async () => {
    const s = await setup(source, { autoplay: true, default: 'Walk', speed: 2, loop: true });
    expect(s.session.animation.stateOf('hero')).toMatchObject({ clip: 'Walk', playing: true, speed: 2 });
    frame(s, 0.25); // 2× → 0,5 s no clipe
    expect(s.bodyX()).toBeCloseTo(1, 1);
    s.presenter.reset();
    s.handle.release();
    s.session.dispose();
  });
});

describe('biblioteca do rig (RigConfig.clips por referência)', () => {
  it('clipe da biblioteca (sourceClip → nome do rig, loop) substitui os embutidos e toca', async () => {
    const source = makeSource({
      hero: { uri: 'res://models/hero.glb', content: glb([{ name: 'Idle', dx: 0.5 }, { name: 'Walk', dx: 2 }]) },
      rig: { uri: 'res://materials/hero_rig.json', content: rigJson([{ name: 'Andar', source: HERO, sourceClip: 'Walk', loop: false }]) },
    });
    const s = await setup(source, { rig: RIG });
    expect(s.session.animation.clipsOf('hero')).toEqual([expect.objectContaining({ name: 'Andar', loop: false })]);
    s.session.animation.play('hero', 'Andar', { crossfade: 0 });
    frame(s, 0.5);
    expect(s.bodyX()).toBeCloseTo(1, 1);
    frame(s, 0.8); // sem loop: fica no fim e emite animation_finished
    expect(s.bodyX()).toBeCloseTo(2, 1);
    expect(s.session.signalBus.getHistory().some((e) => e.signal === 'animation_finished' && e.args[0] === 'Andar')).toBe(true);
    s.presenter.reset();
    s.handle.release();
    s.session.dispose();
  });

  it('rig ausente: cai nos clipes embutidos e avisa (sem exceção)', async () => {
    const source = makeSource({ hero: { uri: 'res://models/hero.glb', content: glb() } }); // o rig NÃO existe no projeto
    const model = await loadModel({ bytes: buildAnimatedGlb(), ext: 'glb', name: 'hero.glb' });
    const set = await loadPlayerClips({ model, rigConfig: RIG, source });
    expect(set.infos.map((i) => i.name)).toEqual(['Idle', 'Walk']);
    expect(set.problems.map((p) => p.code)).toContain('animation.rig_unreadable');
  });
});

describe('loadPlayerClips: arquivos de animação e problemas', () => {
  it('clipe de um arquivo extra entra pelo prepareClip; arquivo ausente e clipe inexistente viram problemas', async () => {
    const model = await loadModel({ bytes: buildAnimatedGlb(), ext: 'glb', name: 'hero.glb' });
    const source = makeSource({
      extra: { uri: 'res://models/extra_walk.glb', content: bytesToDataUrl(buildAnimationOnlyGlb(['Body'], 'Walk'), 'model/gltf-binary') },
      rig: { uri: 'res://materials/hero_rig.json', content: rigJson([
        { name: 'Caminhar', source: EXTRA, sourceClip: 'Walk' },
        { name: 'Sumiu', source: { id: 'ghost', path: 'res://models/ghost.glb' } },
        { name: 'SemClip', source: HERO, sourceClip: 'Inexistente' },
      ]) },
    });
    const set = await loadPlayerClips({ model, rigConfig: RIG, source });
    expect(set.clips.map((c) => c.name)).toEqual(['Caminhar']);
    expect(set.problems.map((p) => p.code).sort()).toEqual(['animation.clip_file_unresolved', 'animation.clip_missing']);
  });

  it('modelo sem animações e sem rig: avisa que não há clipes', async () => {
    const plain = await loadModel({ bytes: buildAnimatedGlb([]), ext: 'glb', name: 'p.glb' });
    const set = await loadPlayerClips({ model: plain, rigConfig: null, source: makeSource({}) });
    expect(set.clips).toEqual([]);
    expect(set.problems.map((p) => p.code)).toContain('animation.no_clips');
  });
});

describe('objeto animado sem modelo', () => {
  it('MeshInstance animado sem modelo 3D: aviso e objeto vazio (as Actions dão erro claro)', async () => {
    const source = makeSource({});
    const scene = createDefault3DStarterScene();
    const root = scene.nodes[scene.rootNodeId];
    const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: ['hero'] } as GameNode, hero: node('hero', 'MeshInstance', root.id, { meshType: 'CubeMesh', animated: true, animation: {} }) };
    const session = new RuntimeSession({
      snapshot: createRuntimeSnapshot({ ...scene, nodes } as unknown as SceneData),
      input: { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never,
    });
    session.start();
    const presenter = new ViewportAnimation(source);
    presenter.update(session, new Map());
    await new Promise((r) => setTimeout(r, 10));
    expect(session.animation.isRegistered('hero')).toBe(true);
    expect(session.animation.clipsOf('hero')).toEqual([]);
    expect(session.animation.play('hero', 'Walk')).toMatch(/nenhum clipe carregado/);
    presenter.reset();
    session.dispose();
  });
});
