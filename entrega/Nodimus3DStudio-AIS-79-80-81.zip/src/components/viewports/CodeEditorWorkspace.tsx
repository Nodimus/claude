import React, { useState, useMemo, useEffect, useSyncExternalStore } from 'react';
import { useEditor } from '../../core/EditorContext';
import { CodeMirrorEditor } from '../codeEditor/CodeMirrorEditor';
import { globalDocumentManager } from '../../core/documents/DocumentManager';
import { planNewFile, type NewFileType } from '../../core/scripts/scriptFiles';
import { useTranslation } from '../../core/i18n/I18nContext';
import {
  closeScriptWithDecision,
  ensureScriptDocument,
  getScriptDraft,
  saveScript,
  setScriptDraft,
} from '../../core/documents/scriptDocuments';
import {
  FileCode,
  FileText,
  FileJson,
  Code2,
  Plus,
  X,
  Search,
  FolderOpen,
  Sparkles,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  FilePlus,
  Check,
  Braces,
} from 'lucide-react';

export const CodeEditorWorkspace: React.FC = () => {
  const { t } = useTranslation();
  const {
    project,
    activeScriptPath,
    setActiveScriptPath,
    openScriptTabs,
    closeScriptTab,
    openFileInScriptEditor,
    updateFileContent,
    createFile,
    setIsScriptEditorModalOpen,
    addLog,
  } = useEditor();

  // AIS-18b: cada arquivo aberto é um documento (dirty/save/conflito); o rascunho sobrevive à troca de aba
  const documents = useSyncExternalStore(
    (cb) => globalDocumentManager.subscribe(cb),
    () => globalDocumentManager.list()
  );
  const dirtyPaths = useMemo(
    () => new Set(documents.filter((d) => d.kind === 'script' && d.dirty).map((d) => d.resourceRef.path as string)),
    [documents]
  );
  useEffect(() => {
    if (activeScriptPath) void ensureScriptDocument(activeScriptPath);
  }, [activeScriptPath]);

  const [filterQuery, setFilterQuery] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [showNewFileDropdown, setShowNewFileDropdown] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [newFileType, setNewFileType] = useState<'ts' | 'js' | 'json' | 'xml' | 'txt'>('ts');
  const [isCreatingFile, setIsCreatingFile] = useState(false);

  // List all text/code editable files in the project
  const editableFiles = useMemo(() => {
    return Object.values(project.files).filter((file) => {
      if (file.isDirectory) return false;
      const ext = file.extension?.toLowerCase() || '';
      return [
        'txt',
        'js',
        'ts',
        'jsx',
        'tsx',
        'json',
        'xml',
        'svg',
        'html',
        'css',
        'md',
        'glsl',
        'shader',
      ].includes(ext) || file.path.endsWith('.txt') || file.path.endsWith('.json');
    });
  }, [project.files]);

  const filteredFiles = useMemo(() => {
    if (!filterQuery.trim()) return editableFiles;
    return editableFiles.filter(
      (f) =>
        f.name.toLowerCase().includes(filterQuery.toLowerCase()) ||
        f.path.toLowerCase().includes(filterQuery.toLowerCase())
    );
  }, [editableFiles, filterQuery]);

  // Current active file content
  const activeFile = activeScriptPath ? project.files[activeScriptPath] : null;

  // Handle creating a new script or data file
  const handleCreateNewFile = (type: NewFileType, customBaseName?: string) => {
    // AIS-28b: scripts em res://scripts/, dados/texto na raiz; nunca sobrescreve um arquivo existente
    const plan = planNewFile(type, project.files, { baseName: customBaseName });
    createFile(plan.path, plan.content);
    openFileInScriptEditor(plan.path, false);
    setIsCreatingFile(false);
    setNewFileName('');
    addLog('log', t('codeEditorWorkspaceMsg.createdNewFile', { type: type.toUpperCase(), path: plan.path, value: plan.renamed ? t('codeEditorWorkspaceMsgNow.nameAlreadyExistedAFree') : '' }));
  };

  const getFileIcon = (ext?: string) => {
    switch (ext?.toLowerCase()) {
      case 'ts':
      case 'tsx':
        return <FileCode className="w-3.5 h-3.5 text-blue-400 shrink-0" />;
      case 'js':
      case 'jsx':
        return <Code2 className="w-3.5 h-3.5 text-amber-300 shrink-0" />;
      case 'json':
        return <FileJson className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
      case 'xml':
      case 'svg':
        return <Braces className="w-3.5 h-3.5 text-orange-400 shrink-0" />;
      default:
        return <FileText className="w-3.5 h-3.5 text-[#8b97a8] shrink-0" />;
    }
  };

  return (
    <div className="flex h-full w-full bg-[#181c24] text-[#dfe4ec] overflow-hidden select-none">
      {/* Left Sidebar: Scripts & Text Files Explorer */}
      <div
        className={`${
          isSidebarOpen ? 'w-64' : 'w-10'
        } shrink-0 bg-[#202531] border-r border-[#2c3345] flex flex-col transition-all duration-200 overflow-hidden`}
      >
        {/* Sidebar Header */}
        <div className="h-10 px-2.5 border-b border-[#2c3345] bg-[#1e232f] flex items-center justify-between">
          {isSidebarOpen ? (
            <div className="flex items-center gap-2 text-xs font-semibold text-white truncate">
              <Code2 className="w-4 h-4 text-emerald-400" />
              <span>{t('codeEditorWorkspace.codeFiles')}</span>
            </div>
          ) : (
            <Code2 className="w-4 h-4 text-emerald-400 mx-auto" />
          )}

          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-1 rounded hover:bg-[#2c3345] text-[#8b97a8] hover:text-white transition-colors"
            title={isSidebarOpen ? t('codeEditorWorkspaceMsg.collapsePanel') : t('codeEditorWorkspaceMsg.expandPanel')}
          >
            {isSidebarOpen ? <ChevronLeft className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>
        </div>

        {isSidebarOpen && (
          <>
            {/* Quick Actions Bar */}
            <div className="p-2 border-b border-[#2c3345] bg-[#1a1e29] flex flex-col gap-1.5">
              {/* New File Trigger */}
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setIsCreatingFile(!isCreatingFile)}
                  className="flex-1 flex items-center justify-center gap-1.5 px-2 py-1.5 rounded bg-[#4982ea] hover:bg-[#3b71d4] text-white text-xs font-medium transition-colors"
                  title={t('codeEditorWorkspace.newFileTsJsJson')}
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{t('codeEditorWorkspace.newFile')}</span>
                </button>

                <button
                  onClick={() => setIsScriptEditorModalOpen(true)}
                  className="p-1.5 rounded bg-[#272e3d] hover:bg-[#323b4e] text-blue-300 hover:text-white border border-[#374158] transition-colors"
                  title={t('codeEditorWorkspace.openAsFloatingModalWindow')}
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Create File Mini-Form */}
              {isCreatingFile && (
                <div className="p-2 mt-1 rounded bg-[#151922] border border-[#374158] flex flex-col gap-2">
                  <div className="text-[11px] font-semibold text-white flex items-center justify-between">
                    <span>{t('codeEditorWorkspace.createFile')}</span>
                    <button
                      onClick={() => setIsCreatingFile(false)}
                      className="text-[#8b97a8] hover:text-white"
                    >
                      ×
                    </button>
                  </div>

                  <input
                    type="text"
                    placeholder={t('codeEditorWorkspace.fileNameEGScript')}
                    value={newFileName}
                    onChange={(e) => setNewFileName(e.target.value)}
                    className="w-full bg-[#1e232f] text-xs text-white px-2 py-1 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none font-mono"
                  />

                  {/* Format Pills */}
                  <div className="grid grid-cols-5 gap-1 text-[10px] font-mono text-center">
                    {(['ts', 'js', 'json', 'xml', 'txt'] as const).map((ext) => (
                      <button
                        key={ext}
                        onClick={() => setNewFileType(ext)}
                        className={`py-1 rounded border transition-colors ${
                          newFileType === ext
                            ? 'bg-[#4982ea] text-white border-[#5b91f5]'
                            : 'bg-[#1e232f] text-[#8b97a8] border-[#2c3345] hover:text-white'
                        }`}
                      >
                        .{ext}
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={() => handleCreateNewFile(newFileType, newFileName.trim() || undefined)}
                    className="w-full py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium transition-colors"
                  >
                    {t('codeEditorWorkspace.confirmCreation')}
                  </button>
                </div>
              )}

              {/* Search Filter */}
              <div className="relative flex items-center mt-1">
                <Search className="w-3.5 h-3.5 absolute left-2 text-[#8b97a8] pointer-events-none" />
                <input
                  type="text"
                  placeholder={t('codeEditorWorkspace.filterFiles')}
                  value={filterQuery}
                  onChange={(e) => setFilterQuery(e.target.value)}
                  className="w-full bg-[#141820] text-xs text-[#dfe4ec] pl-7 pr-2 py-1 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none"
                />
              </div>
            </div>

            {/* Editable Files List */}
            <div className="flex-1 overflow-y-auto p-1.5 space-y-0.5 text-xs">
              <div className="px-2 py-1 text-[10px] font-semibold text-[#8b97a8] uppercase tracking-wider">
                {t('codeEditorWorkspace.scriptsDocuments', { length: filteredFiles.length })}
              </div>

              {filteredFiles.map((f) => {
                const isActive = activeScriptPath === f.path;
                return (
                  <div
                    key={f.path}
                    onClick={() => openFileInScriptEditor(f.path, false)}
                    className={`flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer transition-colors ${
                      isActive
                        ? 'bg-[#4982ea] text-white font-medium'
                        : 'hover:bg-[#272e3d] text-[#dfe4ec]'
                    }`}
                  >
                    {getFileIcon(f.extension)}
                    <span className="truncate flex-1 font-mono text-[12px]">{f.name}</span>
                    <span className="text-[10px] text-white/50 uppercase font-mono">
                      {f.extension || 'txt'}
                    </span>
                  </div>
                );
              })}

              {filteredFiles.length === 0 && (
                <div className="px-3 py-6 text-center text-xs text-[#8b97a8]">
                  {t('codeEditorWorkspace.noFileFoundWithThis')}
                </div>
              )}
            </div>

            {/* Quick Templates Footer */}
            <div className="p-2 border-t border-[#2c3345] bg-[#1a1e29] text-[11px]">
              <span className="text-[#8b97a8] block mb-1.5 font-medium">{t('codeEditorWorkspace.quickTemplates')}</span>
              <div className="grid grid-cols-2 gap-1 font-mono text-[10px]">
                <button
                  onClick={() => handleCreateNewFile('ts', 'GameManager')}
                  className="p-1 rounded bg-[#202531] hover:bg-[#2c3345] text-blue-300 text-left truncate"
                >
                  {t('codeEditorWorkspace.tsManager')}
                </button>
                <button
                  onClick={() => handleCreateNewFile('json', 'LevelData')}
                  className="p-1 rounded bg-[#202531] hover:bg-[#2c3345] text-emerald-300 text-left truncate"
                >
                  {t('codeEditorWorkspace.jsonLevel')}
                </button>
                <button
                  onClick={() => handleCreateNewFile('xml', 'UI_Layout')}
                  className="p-1 rounded bg-[#202531] hover:bg-[#2c3345] text-orange-300 text-left truncate"
                >
                  {t('codeEditorWorkspace.xmlUi')}
                </button>
                <button
                  onClick={() => handleCreateNewFile('txt', 'TodoList')}
                  className="p-1 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] text-left truncate"
                >
                  {t('codeEditorWorkspace.txtNotes')}
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Main Center Area: Tab bar + CodeMirror Editor */}
      <div className="flex-1 flex flex-col overflow-hidden bg-[#141822]">
        {/* Open Files Tabs Bar */}
        <div className="h-9 bg-[#1a1e29] border-b border-[#2c3345] flex items-center overflow-x-auto shrink-0 select-none px-1">
          {openScriptTabs.map((path) => {
            const isActive = activeScriptPath === path;
            const file = project.files[path];
            const fileName = file?.name || path.split('/').pop() || 'Arquivo';
            const ext = file?.extension || fileName.split('.').pop() || '';

            return (
              <div
                key={path}
                onClick={() => setActiveScriptPath(path)}
                className={`group flex items-center gap-1.5 h-8 px-3 border-r border-[#2c3345] text-xs font-mono cursor-pointer transition-colors shrink-0 max-w-[200px] ${
                  isActive
                    ? 'bg-[#141822] text-white border-t-2 border-t-[#4982ea]'
                    : 'bg-[#1e232f] text-[#8b97a8] hover:text-[#dfe4ec] hover:bg-[#242a38]'
                }`}
              >
                {getFileIcon(ext)}
                <span className="truncate flex-1">{fileName}</span>
                {dirtyPaths.has(path) && (
                  <span className="text-amber-400 text-[10px] leading-none" title={t('codeEditorWorkspace.unsavedChanges')}>
                    ●
                  </span>
                )}

                {/* Close Tab Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    void closeScriptWithDecision(path, closeScriptTab);
                  }}
                  className="w-4 h-4 rounded hover:bg-[#343e52] flex items-center justify-center text-[#8b97a8] hover:text-white transition-colors"
                  title={t('codeEditorWorkspace.closeTab')}
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}

          {/* Quick Open or New Tab Button */}
          <button
            onClick={() => setIsCreatingFile(true)}
            className="w-7 h-7 ml-1 rounded hover:bg-[#2c3345] text-[#8b97a8] hover:text-white flex items-center justify-center transition-colors"
            title={t('codeEditorWorkspace.createNewFile')}
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {/* Editor Body */}
        <div className="flex-1 overflow-hidden relative">
          {activeScriptPath && activeFile ? (
            <CodeMirrorEditor
              key={activeScriptPath}
              filePath={activeScriptPath}
              initialContent={getScriptDraft(activeScriptPath) ?? (activeFile.content || '')}
              initialDirty={dirtyPaths.has(activeScriptPath)}
              onDraftChange={(path, content) => setScriptDraft(path, content, project.files[path]?.content || '')}
              onSave={(path, content) => {
                const ok = saveScript(path, content);
                if (ok) addLog('log', t('codeEditorWorkspaceMsg.fileSavedToTheVirtual', { path }));
                return ok;
              }}
              className="h-full border-none rounded-none"
            />
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 select-none">
              <FileCode className="w-16 h-16 text-[#3b455b] mb-4" />
              <h3 className="text-base font-semibold text-white mb-1">
                {t('codeEditorWorkspace.noFileOpenInThe')}
              </h3>
              <p className="text-xs text-[#8b97a8] max-w-sm mb-4">
                {t('codeEditorWorkspace.selectAScriptTsJs')}
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    const first = editableFiles[0];
                    if (first) openFileInScriptEditor(first.path, false);
                  }}
                  className="px-3 py-1.5 rounded bg-[#4982ea] hover:bg-[#3b71d4] text-white text-xs font-medium transition-colors"
                >
                  {t('codeEditorWorkspace.openStartFile')}
                </button>
                <button
                  onClick={() => handleCreateNewFile('ts', 'CustomScript')}
                  className="px-3 py-1.5 rounded bg-[#272e3d] hover:bg-[#323b4e] text-white text-xs font-medium border border-[#374158] transition-colors"
                >
                  {t('codeEditorWorkspace.createTsScript')}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
