import { describe, expect, it } from 'vitest';
import { PrefabV1Schema } from '../../schemas/v1/prefab.schema';
import type { SceneData } from '../../types/scene';
import { buildBranchPrefab, sanitizePrefabName } from './branchPrefab';

const gameNode = (id: string, parentId: string | null, childrenIds: string[] = []) => ({
  id,
  name: id,
  type: 'Spatial' as const,
  parentId,
  childrenIds,
  visible: true,
  locked: false,
  properties: {},
});

describe('branchPrefab', () => {
  it('serializes only the selected subtree with a detached root', () => {
    const scene = {
      id: 'scene-1',
      name: 'Main',
      path: 'res://scenes/Main.scene.json',
      rootNodeId: 'scene-root',
      nodes: {
        'scene-root': gameNode('scene-root', null, ['branch', 'outside']),
        branch: gameNode('branch', 'scene-root', ['child']),
        child: gameNode('child', 'branch'),
        outside: gameNode('outside', 'scene-root'),
      },
      createdAt: '2026-10-01T00:00:00.000Z',
      updatedAt: '2026-10-01T00:00:00.000Z',
    } satisfies SceneData;

    const prefab = buildBranchPrefab(scene, 'branch', 'Room.prefab.json', 'res://prefabs/Room.prefab.json', 'prefab-1', '2026-10-01T00:00:00.000Z');
    expect(prefab).not.toBeNull();
    expect(Object.keys(prefab!.nodes)).toEqual(['branch', 'child']);
    expect(prefab!.nodes.branch.parentId).toBeNull();
    expect(prefab!.nodes.branch.childrenIds).toEqual(['child']);
    expect(PrefabV1Schema.safeParse(prefab).success).toBe(true);
  });

  it('rejects the scene root and missing nodes', () => {
    const scene = {
      id: 'scene-1',
      name: 'Main',
      path: 'res://scenes/Main.scene.json',
      rootNodeId: 'root',
      nodes: { root: gameNode('root', null) },
      createdAt: '2026-10-01T00:00:00.000Z',
      updatedAt: '2026-10-01T00:00:00.000Z',
    } satisfies SceneData;
    expect(buildBranchPrefab(scene, 'root', 'Root', 'res://prefabs/Root.prefab.json', 'p', 'now')).toBeNull();
    expect(buildBranchPrefab(scene, 'missing', 'Missing', 'res://prefabs/Missing.prefab.json', 'p', 'now')).toBeNull();
  });

  it('sanitizes names for res:// paths', () => {
    expect(sanitizePrefabName('  Room: East.prefab.json ')).toBe('Room_ East');
    expect(sanitizePrefabName('...')).toBe('Prefab');
  });
});