import React, { useState, useRef, useEffect } from 'react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { SceneTreeNode } from './SceneTreeNode';
import { buildBranchPrefab, sanitizePrefabName } from './branchPrefab';
import { useTranslation } from '../../core/i18n/I18nContext';
import {
  Plus,
  Trash2,
  Copy,
  Search,
  Layers,
  Sparkles,
  EyeOff,
} from 'lucide-react';

export const SceneTreePanel: React.FC = () => {
  const { t } = useTranslation();
  // AIS-03f: Selection, modal toggle and workspace mode migrated to canonical Zustand EditorStore
  const selectedNodeId          = useEditorStore((s) => s.selectedNodeId);
  const selectNode              = useEditorStore((s) => s.selectNode);
  const setIsCreateNodeModalOpen= useEditorStore((s) => s.setIsCreateNodeModalOpen);
  const setWorkspaceMode        = useEditorStore((s) => s.setWorkspaceMode);
  const multiSelectedNodeIds    = useEditorStore((s) => s.multiSelectedNodeIds);

  // AuthoringModel mutations & active scene from facade
  const {
    activeScene,
    project,
    deleteNode,
    deleteMultipleNodes,
    setNodesVisibility,
    duplicateNode,
    addNode,
    createFile,
    updateNodeProperties,
    addLog,
    saveCurrentScene,
  } = useEditor();

  // AIS-17: seleção completa = primário + adicionais (sem duplicatas)
  const allSelectedIds = [...new Set([...(selectedNodeId ? [selectedNodeId] : []), ...multiSelectedNodeIds])];
  const isBatch = allSelectedIds.length > 1;

  const [searchFilter, setSearchFilter] = useState('');
  const [contextMenu, setContextMenu] = useState<{
    x: number;
    y: number;
    nodeId: string;
  } | null>(null);
  const [renameRequestNodeId, setRenameRequestNodeId] = useState<string | null>(null);
  const [isSavingPrefab, setIsSavingPrefab] = useState(false);
  const [prefabName, setPrefabName] = useState('');
  const [prefabSaveError, setPrefabSaveError] = useState<string | null>(null);

  const menuRef = useRef<HTMLDivElement>(null);

  const nodeCount = Object.keys(activeScene.nodes).length;

  // Track reachable nodes to guarantee 100% of scene nodes appear in the tree
  const renderedIds = new Set<string>();
  const collectReachable = (id: string) => {
    renderedIds.add(id);
    const n = activeScene.nodes[id];
    if (n && n.childrenIds) {
      n.childrenIds.forEach(collectReachable);
    }
  };
  if (activeScene.rootNodeId) {
    collectReachable(activeScene.rootNodeId);
  }
  const orphanIds = Object.keys(activeScene.nodes).filter((id) => !renderedIds.has(id));

  // Close context menu on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setContextMenu(null);
      }
    };
    window.addEventListener('mousedown', handleClickOutside);
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleContextMenu = (e: React.MouseEvent, nodeId: string) => {
    setRenameRequestNodeId(null);
    setIsSavingPrefab(false);
    setPrefabSaveError(null);
    setPrefabName(activeScene.nodes[nodeId]?.name ?? 'Prefab');
    setContextMenu({
      x: Math.min(e.clientX, window.innerWidth - 200),
      y: Math.min(e.clientY, window.innerHeight - 220),
      nodeId,
    });
  };

  const handleSaveBranchAsPrefab = () => {
    if (!contextMenu) return;
    const node = activeScene.nodes[contextMenu.nodeId];
    if (!node || node.id === activeScene.rootNodeId) {
      setPrefabSaveError(t('sceneTreePanelMsg.theSceneRootCannotBe'));
      return;
    }
    const name = sanitizePrefabName(prefabName);
    const path = `res://prefabs/${name}.prefab.json`;
    if (project.files[path]) {
      setPrefabSaveError(t('sharedMsg.aPrefabAlreadyExistsAt', { path }));
      return;
    }

    const timestamp = new Date().toISOString();
    const prefabId = `prefab_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    const prefab = buildBranchPrefab(activeScene, node.id, name, path, prefabId, timestamp);
    if (!prefab) {
      setPrefabSaveError(t('sceneTreePanelMsg.couldNotSerializeThisSubtree'));
      return;
    }

    createFile(path, JSON.stringify(prefab, null, 2));
    updateNodeProperties(node.id, {
      prefabRef: { id: prefab.id, path, rootNodeId: prefab.rootNodeId, status: 'resolved' },
    });
    saveCurrentScene();
    addLog('log', t('sceneTreePanelMsg.savedBranchAsPrefab', { name: node.name, path }));
    setContextMenu(null);
    setIsSavingPrefab(false);
  };

  return (
    <div className="flex flex-col h-full bg-[#202531] border-r border-[#2c3345] select-none">
      {/* Top Header bar */}
      <div className="h-8 border-b border-[#2c3345] px-2.5 flex items-center justify-between bg-[#1e232f]">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-[#dfe4ec]">
          <Layers className="w-3.5 h-3.5 text-[#4982ea]" />
          <span>{t('sceneTreePanel.scene', { nodeCount })}</span>
        </div>

        {/* Action icons (+ Add Node, Duplicate, Trash) */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsCreateNodeModalOpen(true)}
            className="p-1 rounded hover:bg-[#2c3345] text-[#b3bed0] hover:text-white transition-colors"
            title={t('sceneTreePanel.addChildNode')}
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400" />
          </button>

          <button
            disabled={!selectedNodeId}
            onClick={() => selectedNodeId && duplicateNode(selectedNodeId)}
            className={`p-1 rounded transition-colors ${
              selectedNodeId
                ? 'hover:bg-[#2c3345] text-[#b3bed0] hover:text-white'
                : 'text-[#485368] cursor-not-allowed'
            }`}
            title={t('sceneTreePanel.duplicateSelectedNodeCtrlD')}
          >
            <Copy className="w-3.5 h-3.5" />
          </button>

          <button
            disabled={!selectedNodeId || selectedNodeId === activeScene.rootNodeId}
            onClick={() => selectedNodeId && (isBatch ? deleteMultipleNodes(allSelectedIds) : deleteNode(selectedNodeId))}
            className={`p-1 rounded transition-colors ${
              selectedNodeId && selectedNodeId !== activeScene.rootNodeId
                ? 'hover:bg-rose-900/30 text-[#b3bed0] hover:text-rose-400'
                : 'text-[#485368] cursor-not-allowed'
            }`}
            title={isBatch ? t('sceneTreePanelMsg.deleteSelectedNodesDel', { count: allSelectedIds.length }) : t('sceneTreePanelMsg.deleteSelectedNodeDel')}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="px-2 py-1.5 border-b border-[#2c3345] bg-[#1a1e29]">
        <div className="relative flex items-center">
          <Search className="w-3.5 h-3.5 absolute left-2 text-[#8b97a8] pointer-events-none" />
          <input
            type="text"
            placeholder={t('sceneTreePanel.filterNodes')}
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            className="w-full bg-[#141820] text-xs text-[#dfe4ec] pl-7 pr-2 py-1 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none"
          />
        </div>
      </div>

      {/* Tree View Content */}
      <div data-scene-tree className="flex-1 overflow-y-auto py-1 px-1 text-xs">
        {activeScene.rootNodeId && activeScene.nodes[activeScene.rootNodeId] ? (
          <>
            <SceneTreeNode
              nodeId={activeScene.rootNodeId}
              depth={0}
              searchFilter={searchFilter}
              onContextMenu={handleContextMenu}
              renameRequestNodeId={renameRequestNodeId}
              onRenameRequest={setRenameRequestNodeId}
              onRenameRequestConsumed={() => setRenameRequestNodeId(null)}
            />
            {orphanIds.map((orphanId) => (
              <SceneTreeNode
                key={orphanId}
                nodeId={orphanId}
                depth={1}
                searchFilter={searchFilter}
                onContextMenu={handleContextMenu}
                renameRequestNodeId={renameRequestNodeId}
                onRenameRequest={setRenameRequestNodeId}
                onRenameRequestConsumed={() => setRenameRequestNodeId(null)}
              />
            ))}
          </>
        ) : (
          <div className="p-4 text-center space-y-2">
            <div className="text-[#8b97a8] text-xs">{t('sceneTreePanel.noRootNodeInThe')}</div>
            <button
              onClick={() => {
                const root = addNode('Spatial', null, 'World3D');
                selectNode(root.id);
              }}
              className="px-3 py-1.5 bg-[#4982ea] hover:bg-[#3b6ecc] text-white rounded text-xs font-medium transition-colors"
            >
              {t('sceneTreePanel.createWorld3dRootNode')}
            </button>
          </div>
        )}
      </div>

      {/* Right Click Context Menu */}
      {contextMenu && (
        <div
          ref={menuRef}
          style={{ top: contextMenu.y, left: contextMenu.x }}
          className="fixed z-50 w-48 bg-[#1e232f] border border-[#2c3345] rounded-md shadow-2xl py-1 text-xs text-[#dfe4ec]"
        >
          <button
            onClick={() => {
              setIsCreateNodeModalOpen(true);
              setContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 font-medium text-white"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400" />
            <span>{t('sceneTreePanel.addChildNode2')}</span>
          </button>

          <button
            onClick={() => {
              duplicateNode(contextMenu.nodeId);
              setContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
          >
            <Copy className="w-3.5 h-3.5 text-[#8b97a8]" />
            <span>{t('sceneTreePanel.duplicateNode')}</span>
          </button>

          <button
            onClick={() => {
              setRenameRequestNodeId(contextMenu.nodeId);
              setContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
          >
            <span className="w-3.5 text-center font-mono text-[10px] text-[#8b97a8]">F2</span>
            <span>{t('sceneTreePanel.renameNode')}</span>
          </button>

          <button
            onClick={() => {
              window.dispatchEvent(new CustomEvent('nodimus:frame-selected', { detail: { nodeId: contextMenu.nodeId } }));
              setContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
          >
            <span className="w-3.5 text-center font-mono text-[10px] text-[#8b97a8]">F</span>
            <span>{t('sceneTreePanel.focusInViewport')}</span>
          </button>

          <button
            disabled={contextMenu.nodeId === activeScene.rootNodeId}
            onClick={() => {
              setPrefabName(activeScene.nodes[contextMenu.nodeId]?.name ?? 'Prefab');
              setPrefabSaveError(null);
              setIsSavingPrefab(true);
            }}
            className={`w-full text-left px-3 py-1.5 flex items-center gap-2 ${
              contextMenu.nodeId !== activeScene.rootNodeId
                ? 'hover:bg-[#2c3345] text-[#dfe4ec]'
                : 'text-[#586377] cursor-not-allowed'
            }`}
            title={t('sceneTreePanel.saveThisNodeBranchAs')}
          >
            <span className="w-3.5 text-center text-emerald-400">◆</span>
            <span>{t('sceneTreePanel.saveBranchAsPrefab')}</span>
          </button>

          {isSavingPrefab && (
            <form
              onSubmit={(event) => {
                event.preventDefault();
                handleSaveBranchAsPrefab();
              }}
              className="border-t border-[#2c3345] mt-1 pt-2 px-2 space-y-1.5"
            >
              <label className="block text-[10px] text-[#8b97a8]" htmlFor="scene-tree-prefab-name">
                {t('sceneTreePanel.prefabName')}
              </label>
              <input
                id="scene-tree-prefab-name"
                autoFocus
                value={prefabName}
                onChange={(event) => {
                  setPrefabName(event.target.value);
                  setPrefabSaveError(null);
                }}
                className="w-full bg-[#141820] border border-[#3b475f] rounded px-2 py-1 text-[#dfe4ec] outline-none focus:border-[#4982ea]"
                aria-label={t('sceneTreePanel.prefabName')}
              />
              {prefabSaveError && <div role="alert" className="text-[10px] text-rose-300">{prefabSaveError}</div>}
              <div className="flex justify-end gap-1">
                <button type="button" onClick={() => setIsSavingPrefab(false)} className="px-2 py-1 text-[#8b97a8] hover:text-white">
                  {t('shared.cancel')}
                </button>
                <button type="submit" className="px-2 py-1 rounded bg-[#4982ea] text-white hover:bg-[#3d72d6]">
                  {t('sceneTreePanel.savePrefab')}
                </button>
              </div>
            </form>
          )}

          <button
            onClick={() => {
              setWorkspaceMode('VisualLogic');
              setContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{t('sceneTreePanel.addVisualBehavior')}</span>
          </button>

          {isBatch && allSelectedIds.includes(contextMenu.nodeId) && (
            <>
              <button
                onClick={() => {
                  const target = !allSelectedIds.every((id) => activeScene.nodes[id]?.visible === false);
                  setNodesVisibility(allSelectedIds, !target);
                  setContextMenu(null);
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
              >
                <EyeOff className="w-3.5 h-3.5 text-[#8b97a8]" />
                <span>
                  {allSelectedIds.every((id) => activeScene.nodes[id]?.visible === false)
                    ? t('sceneTreePanelMsg.showNodes', { count: allSelectedIds.length })
                    : t('sceneTreePanelMsg.hideNodes', { count: allSelectedIds.length })}
                </span>
              </button>
            </>
          )}

          <div className="my-1 border-t border-[#2c3345]" />

          <button
            disabled={contextMenu.nodeId === activeScene.rootNodeId}
            onClick={() => {
              if (isBatch && allSelectedIds.includes(contextMenu.nodeId)) {
                deleteMultipleNodes(allSelectedIds);
              } else {
                deleteNode(contextMenu.nodeId);
              }
              setContextMenu(null);
            }}
            className={`w-full text-left px-3 py-1.5 flex items-center gap-2 ${
              contextMenu.nodeId !== activeScene.rootNodeId
                ? 'hover:bg-rose-900/30 text-rose-300'
                : 'text-[#586377] cursor-not-allowed'
            }`}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{isBatch && allSelectedIds.includes(contextMenu.nodeId) ? t('sceneTreePanelMsg.deleteNodes', { count: allSelectedIds.length }) : t('sceneTreePanelMsgTwo.delete')}</span>
          </button>
        </div>
      )}
    </div>
  );
};
