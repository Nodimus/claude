import { updateViewportSelection } from '../viewports/viewportSelection';

export interface TreeSelection {
  primaryId: string | null;
  additionalIds: string[];
}

export interface TreeClickModifiers {
  ctrl: boolean;
  shift: boolean;
}

/** Ids no intervalo [a, b] (inclusive) da lista ordenada de linhas visíveis. */
export function rangeBetween(orderedIds: readonly string[], a: string, b: string): string[] {
  const ia = orderedIds.indexOf(a);
  const ib = orderedIds.indexOf(b);
  if (ia < 0 || ib < 0) return [b];
  const [from, to] = ia <= ib ? [ia, ib] : [ib, ia];
  return orderedIds.slice(from, to + 1);
}

/**
 * Clique na SceneTree:
 *  - sem modificador: seleção simples;
 *  - Ctrl/Cmd: alterna o nó na seleção;
 *  - Shift: seleciona o intervalo entre o nó primário (âncora) e o clicado.
 * `orderedVisibleIds` = linhas visíveis na ordem de exibição.
 */
export function applyTreeClick(
  primaryId: string | null,
  additionalIds: readonly string[],
  clickedId: string,
  orderedVisibleIds: readonly string[],
  mods: TreeClickModifiers
): TreeSelection {
  if (mods.shift && primaryId) {
    const range = rangeBetween(orderedVisibleIds, primaryId, clickedId);
    return { primaryId, additionalIds: range.filter((id) => id !== primaryId) };
  }
  if (mods.ctrl) {
    return updateViewportSelection(primaryId, additionalIds, clickedId, 'toggle');
  }
  return { primaryId: clickedId, additionalIds: [] };
}
