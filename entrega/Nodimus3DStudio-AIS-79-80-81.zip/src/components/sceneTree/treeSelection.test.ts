import { describe, it, expect } from 'vitest';
import { applyTreeClick, rangeBetween } from './treeSelection';

const order = ['r', 'a', 'b', 'c', 'd'];

describe('treeSelection', () => {
  it('intervalo inclusive em qualquer direção', () => {
    expect(rangeBetween(order, 'a', 'c')).toEqual(['a', 'b', 'c']);
    expect(rangeBetween(order, 'd', 'b')).toEqual(['b', 'c', 'd']);
  });
  it('clique simples substitui', () => {
    expect(applyTreeClick('a', ['b'], 'd', order, { ctrl: false, shift: false })).toEqual({ primaryId: 'd', additionalIds: [] });
  });
  it('Ctrl alterna', () => {
    expect(applyTreeClick('a', [], 'c', order, { ctrl: true, shift: false })).toEqual({ primaryId: 'a', additionalIds: ['c'] });
    expect(applyTreeClick('a', ['c'], 'c', order, { ctrl: true, shift: false })).toEqual({ primaryId: 'a', additionalIds: [] });
  });
  it('Shift seleciona intervalo a partir do primário', () => {
    expect(applyTreeClick('b', [], 'd', order, { ctrl: false, shift: true })).toEqual({ primaryId: 'b', additionalIds: ['c', 'd'] });
  });
  it('Shift sem primário vira seleção simples', () => {
    expect(applyTreeClick(null, [], 'c', order, { ctrl: false, shift: true })).toEqual({ primaryId: 'c', additionalIds: [] });
  });
});
