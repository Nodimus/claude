import type { SceneData } from '../../types/scene';
import type { GameNode } from '../../types/node';
import type { GameNodeV1 } from '../../schemas/v1/node.schema';
import type { PrefabV1 } from '../../schemas/v1/prefab.schema';
import { restoreMissingNodes } from '../../schemas/missingNodes';

export function sanitizePrefabName(name: string): string {
  const stem = name.trim().replace(/\.prefab\.json$/i, '');
  const safe = stem.replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').replace(/[. ]+$/g, '');
  return safe || 'Prefab';
}

export function buildBranchPrefab(
  scene: SceneData,
  rootNodeId: string,
  name: string,
  sourcePath: string,
  prefabId: string,
  timestamp: string
): PrefabV1 | null {
  if (!rootNodeId || rootNodeId === scene.rootNodeId || !scene.nodes[rootNodeId]) return null;

  const branchIds = new Set<string>();
  const visit = (nodeId: string) => {
    if (branchIds.has(nodeId)) return;
    const node = scene.nodes[nodeId];
    if (!node) return;
    branchIds.add(nodeId);
    node.childrenIds.forEach(visit);
  };
  visit(rootNodeId);

  const nodes: Record<string, GameNodeV1> = {};
  for (const nodeId of branchIds) {
    const node = scene.nodes[nodeId];
    nodes[nodeId] = {
      ...JSON.parse(JSON.stringify(node)),
      schemaVersion: 1,
      parentId: nodeId === rootNodeId ? null : node.parentId,
      childrenIds: node.childrenIds.filter((childId) => branchIds.has(childId)),
    };
  }

  return {
    schemaVersion: 1,
    id: prefabId,
    name: sanitizePrefabName(name),
    rootNodeId,
    nodes: restoreMissingNodes(nodes), // Missing Node volta ao tipo/dados originais (AIS-18d)
    sourcePath,
    createdAt: timestamp,
    updatedAt: timestamp,
  };
}