import React, { useState } from 'react';
import { AlertTriangle, Ban, Info, Wrench, XCircle } from 'lucide-react';
import { useDiagnostics } from '../../core/diagnostics/useDiagnostics';
import { globalDiagnosticService } from '../../core/diagnostics/global';
import type { DiagnosticSeverity, RuntimeDiagnostic } from '../../core/diagnostics/DiagnosticService';
import { ALL, NO_FILTERS, filterOptions, filterProblems, groupBySeverity, isSessionProblem, problemOrigin, problemTarget, type ProblemFilters } from '../../core/diagnostics/problemsModel';
import { globalSelectionService } from '../../core/selection/SelectionService';
import { useEditor } from '../../core/EditorContext';
import { useTranslation } from '../../core/i18n/I18nContext';

/**
 * AIS-77 (emenda v5.8) — aba "Problemas": uma VISÃO do `useDiagnostics` (nunca um canal de erro paralelo; o Output segue igual). Agrupa por
 * severidade, filtra por fase/fonte/severidade e atualiza ao vivo (assinatura do serviço). Clique em item com alvo seleciona o nó
 * (`SelectionService`); o botão de correção só aparece para diagnóstico com `fix` e executor registrado.
 */

const SEVERITY_LABEL: Record<DiagnosticSeverity, string> = { blocking: 'Bloqueios', error: 'Erros', warning: 'Avisos', info: 'Informações' };

const SeverityIcon: React.FC<{ severity: DiagnosticSeverity }> = ({ severity }) => {
  if (severity === 'blocking') return <Ban className="w-3 h-3 text-rose-500 shrink-0" />;
  if (severity === 'error') return <XCircle className="w-3 h-3 text-rose-400 shrink-0" />;
  if (severity === 'warning') return <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />;
  return <Info className="w-3 h-3 text-[#8b97a8] shrink-0" />;
};

const selectClass = 'bg-[#1c2230] border border-[#2c3345] rounded px-1.5 py-0.5 text-[11px] text-[#dfe4ec] outline-none';

export const ProblemsPanel: React.FC = () => {
  const { t } = useTranslation();
  const all = useDiagnostics();
  const { activeScene } = useEditor();
  const [filters, setFilters] = useState<ProblemFilters>(NO_FILTERS);
  const [fixError, setFixError] = useState<string | null>(null);

  const options = filterOptions(all);
  const groups = groupBySeverity(filterProblems(all, filters));

  const open = (d: RuntimeDiagnostic) => {
    if (d.nodeId && activeScene.nodes[d.nodeId]) globalSelectionService.replace(d.nodeId);
  };

  const fix = async (d: RuntimeDiagnostic) => {
    const result = await globalDiagnosticService.applyFix(d.id);
    setFixError(result.ok ? null : result.error);
  };

  return (
    <div className="h-full flex flex-col bg-[#12151d]" data-testid="problems-panel">
      <div className="flex items-center gap-2 px-2 py-1 border-b border-[#2c3345] text-[11px] text-[#8b97a8]">
        <span>{t('problemsPanel.phase')}</span>
        <select aria-label={t('problemsPanel.filterByPhase')} className={selectClass} value={filters.phase} onChange={(e) => setFilters({ ...filters, phase: e.target.value })}>
          <option value={ALL}>{t('problemsPanel.all')}</option>
          {options.phases.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </select>
        <span>{t('problemsPanel.source')}</span>
        <select aria-label={t('problemsPanel.filterBySource')} className={selectClass} value={filters.source} onChange={(e) => setFilters({ ...filters, source: e.target.value })}>
          <option value={ALL}>{t('problemsPanel.all')}</option>
          {options.sources.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <span>{t('problemsPanel.severity')}</span>
        <select aria-label={t('problemsPanel.filterBySeverity')} className={selectClass} value={filters.severity} onChange={(e) => setFilters({ ...filters, severity: e.target.value as ProblemFilters['severity'] })}>
          <option value={ALL}>{t('problemsPanel.all')}</option>
          {(['blocking', 'error', 'warning', 'info'] as const).map((s) => (
            <option key={s} value={s}>
              {SEVERITY_LABEL[s]}
            </option>
          ))}
        </select>
        {fixError && (
          <span className="text-rose-400 truncate" title={fixError}>
            {fixError}
          </span>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-2 font-mono text-xs space-y-2">
        {groups.length === 0 && <div className="text-[#5b687c]">{all.length === 0 ? t('problemsPanelMsg.noProblems') : t('problemsPanelMsg.noProblemsForTheseFilters')}</div>}
        {groups.map((g) => (
          <div key={g.severity} data-severity={g.severity}>
            <div className="text-[11px] text-[#8b97a8] mb-1">
              {SEVERITY_LABEL[g.severity]} ({g.items.length})
            </div>
            <div className="space-y-0.5">
              {g.items.map((d) => {
                const target = problemTarget(d);
                const selectable = !!d.nodeId && !!activeScene.nodes[d.nodeId];
                return (
                  <div key={d.id} className={`flex items-start gap-2 leading-tight rounded px-1 py-0.5 ${selectable ? 'cursor-pointer hover:bg-[#1c2230]' : ''}`} onClick={() => open(d)} data-code={d.code}>
                    <SeverityIcon severity={d.severity} />
                    <span className="text-[#dfe4ec] break-words min-w-0">
                      [{d.code}] {d.message}
                      <span className="text-[#5b687c]">
                        {' '}
                        · {problemOrigin(d)}
                        {target ? ` · ${target}` : ''}
                        {isSessionProblem(d) ? t('problemsPanelMsg.play') : ''}
                        {d.occurrences > 1 ? ` · ×${d.occurrences}` : ''}
                      </span>
                    </span>
                    {d.fix && globalDiagnosticService.hasFixHandler(d.fix.fixId) && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          void fix(d);
                        }}
                        className="ml-auto shrink-0 flex items-center gap-1 px-1.5 py-0.5 rounded border border-[#2c3345] text-[#dfe4ec] hover:bg-[#2c3345]"
                        title={d.fix.label}
                      >
                        <Wrench className="w-3 h-3" /> {d.fix.label}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
