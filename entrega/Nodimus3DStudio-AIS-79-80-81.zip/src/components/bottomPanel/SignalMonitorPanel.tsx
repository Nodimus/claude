import React, { useCallback, useMemo, useState, useSyncExternalStore } from 'react';
import { Radio, Trash2 } from 'lucide-react';
import { useEditor } from '../../core/EditorContext';
import { signalMonitor, type SignalEmission } from '../../core/signalBus';
import { formatSignalArgs, formatSignalTime, matchesSignalFilter } from '../../core/signalMonitorFormat';
import { useTranslation } from '../../core/i18n/I18nContext';

/**
 * AIS-57 — Monitor de Sinais (BottomPanel): depuração em tempo real do `SignalBus` da sessão de Play, com a lista de sinais
 * registrados (emissões e ouvintes) e o histórico de emissões com timestamps. Só leitura. O histórico continua visível
 * depois do Stop, até o próximo Play.
 */
export const SignalMonitorPanel: React.FC = () => {
  const { t } = useTranslation();
  const { activeScene } = useEditor();
  const bus = useSyncExternalStore(signalMonitor.subscribe, signalMonitor.get);
  const subscribeBus = useCallback((cb: () => void) => (bus ? bus.subscribe(cb) : () => undefined), [bus]);
  const version = useSyncExternalStore(subscribeBus, () => bus?.getVersion() ?? 0);
  const [filter, setFilter] = useState('');

  const history = bus?.getHistory() ?? [];
  const signals = useMemo(() => bus?.listSignals() ?? [], [bus, version]); // eslint-disable-line react-hooks/exhaustive-deps
  const nameOf = (id?: string) => (id === undefined ? '(global)' : (activeScene.nodes[id]?.name ?? id));
  const rows = useMemo(
    () => history.filter((e) => matchesSignalFilter(e, filter, nameOf(e.source))).slice(-300).reverse(),
    [history, filter, activeScene.nodes], // eslint-disable-line react-hooks/exhaustive-deps
  );

  if (!bus) {
    return (
      <div className="h-full p-3 bg-[#12151d] text-[#8b97a8] text-xs flex items-center gap-2" data-testid="signal-monitor-empty">
        <Radio className="w-3.5 h-3.5 text-emerald-400" />
        {t('signalMonitorPanel.noSignalsYetStartPlay')}
      </div>
    );
  }

  return (
    <div className="h-full flex bg-[#12151d] text-xs" data-testid="signal-monitor">
      {/* Sinais registrados */}
      <div className="w-64 shrink-0 border-r border-[#2c3345] overflow-y-auto">
        <div className="px-2 py-1 text-[11px] text-[#8b97a8] border-b border-[#2c3345] sticky top-0 bg-[#12151d]">
          {t('signalMonitorPanel.registeredSignals', { length: signals.length })}
        </div>
        {signals.length === 0 ? (
          <div className="p-2 text-[#6b788a]">{t('signalMonitorPanel.noSignalEmittedOrConnected')}</div>
        ) : (
          signals.map((s) => (
            <div key={s.name} className="px-2 py-1 border-b border-[#1c2230] flex items-center gap-2" title={s.description || undefined}>
              <span className="font-mono text-[#dfe4ec] truncate flex-1">{s.name}</span>
              <span className="text-emerald-400 font-mono" title={t('signalMonitorPanel.emissions')}>{s.emitCount}×</span>
              <span className="text-sky-400 font-mono" title={t('signalMonitorPanel.listenersConnected')}>{s.listenerCount}👂</span>
            </div>
          ))
        )}
      </div>

      {/* Histórico */}
      <div className="flex-1 min-w-0 flex flex-col">
        <div className="px-2 py-1 border-b border-[#2c3345] flex items-center gap-2">
          <span className="text-[11px] text-[#8b97a8]">{t('signalMonitorPanel.history', { length: history.length })}</span>
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder={t('signalMonitorPanel.filterBySignalNodeOr')}
            aria-label={t('signalMonitorPanel.filterSignals')}
            className="flex-1 bg-[#141820] border border-[#2c3345] rounded px-2 py-0.5 text-[#dfe4ec] outline-none focus:border-[#4982ea]"
          />
          <button
            type="button"
            onClick={() => bus.clearHistory()}
            disabled={history.length === 0}
            className="p-1 rounded text-[#8b97a8] hover:text-white hover:bg-[#2c3345] disabled:opacity-40"
            title={t('signalMonitorPanel.clearHistory')}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto font-mono leading-snug">
          {rows.length === 0 ? (
            <div className="p-2 text-[#6b788a]">{history.length === 0 ? t('signalMonitorPanelMsg.waitingForEmissions') : t('signalMonitorPanelMsg.nothingMatchesTheFilter')}</div>
          ) : (
            rows.map((e) => <HistoryRow key={e.seq} e={e} source={nameOf(e.source)} />)
          )}
        </div>
      </div>
    </div>
  );
};

const HistoryRow: React.FC<{ e: SignalEmission; source: string }> = ({ e, source }) => {
  const { t } = useTranslation();
  return (
  <div className={`px-2 py-0.5 flex items-baseline gap-2 border-b border-[#1c2230] ${e.errors.length ? 'text-red-300' : 'text-[#dfe4ec]'}`} data-testid="signal-row">
    <span className="text-[#5b687c] shrink-0">{formatSignalTime(e.wallTime)}</span>
    <span className="text-[#8b97a8] shrink-0 w-14 text-right">{e.sceneTime.toFixed(2)}s</span>
    <span className="text-emerald-300 shrink-0">{e.signal}</span>
    <span className="text-[#8b97a8] shrink-0">{t('signalMonitorPanel.of', { source })}</span>
    <span className="truncate flex-1" title={formatSignalArgs(e.args)}>{formatSignalArgs(e.args)}</span>
    <span className="text-[#6b788a] shrink-0" title={t('signalMonitorPanel.listenersCalledDeferred')}>
      → {e.delivered}
      {e.deferred > 0 ? t('signalMonitorPanelMsg.deferred', { deferred: e.deferred, value: e.deferred > 1 ? 's' : '' }) : ''}
    </span>
    {e.errors.length > 0 && <span className="text-red-400 shrink-0" title={e.errors.join('\n')}>⚠ {e.errors.length}</span>}
  </div>
);
};
