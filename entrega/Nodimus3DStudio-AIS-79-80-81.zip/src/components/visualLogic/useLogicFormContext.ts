import { createContext, useMemo } from 'react';
import { useEditor } from '../../core/EditorContext';
import type { FormContext } from '../../logic/paramForm';
import { collectBehaviors } from '../../core/authoring/behaviors';
import { localEntries } from '../../core/variableManager';
import { DEFAULT_INPUT_ACTIONS, projectActionsToMap } from '../../core/inputMap';
import { animationNamesOf, findAnimatedNode } from '../../core/animation/animationNames';
import { resolveSprite } from '../../core/sprites/spriteResource';
import { resourcePathOf } from '../../core/resources/global';

/** Nó dono do Behavior em edição (alvo padrão de uma variável local com Target vazio). */
export const VariableOwnerContext = createContext<string | undefined>(undefined);

export interface FormNodeOption {
  id: string;
  name: string;
  type: string;
}

export interface LogicFormEnvironment {
  /** Nós da cena ativa (sem os Missing), por nome. */
  nodes: FormNodeOption[];
  /** Caminhos `res://` de todos os arquivos do projeto (os seletores filtram por `accept`/`root`). */
  files: string[];
  /** AIS-58: ações do Input Map do projeto (vazio = padrões), para os seletores de ação. */
  inputActions: string[];
  /** AIS-60b: animações do objeto animado do alvo (`targetRef` vazio = o dono do Behavior). */
  animationsOf(targetRef: string, ownerNodeId?: string): string[] | undefined;
  ctx: FormContext;
  /** Nome das variáveis declaradas no escopo (mesma fonte da validação). */
  variablesOf(scope: 'global' | 'local', targetRef: string, ownerNodeId?: string): string[] | undefined;
  /** Nó dono de um Behavior da cena ativa. */
  ownerOf(behaviorId: string): string | undefined;
}

/**
 * AIS-42 — o que os seletores do formulário de parâmetros enxergam: os nós da cena ativa e os arquivos do projeto. A mesma
 * fonte alimenta o seletor de nó, o de arquivo, a validação inline e o preview textual (nada é copiado para outro estado).
 */
export function useLogicFormEnvironment(): LogicFormEnvironment {
  const { activeScene, project } = useEditor();
  return useMemo(() => {
    const all = Object.values(activeScene.nodes ?? {});
    const nodes = all
      .filter((n) => n.type !== 'Missing')
      .map((n) => ({ id: n.id, name: n.name, type: n.type as string }))
      .sort((a, b) => a.name.localeCompare(b.name));
    const find = (ref: string) => activeScene.nodes[ref] ?? all.find((n) => n.name === ref);
    const files = Object.values(project.files ?? {})
      .filter((f) => !f.isDirectory)
      .map((f) => f.path);
    const fileSet = new Set(files);
    const variablesOf: LogicFormEnvironment['variablesOf'] = (scope, targetRef, ownerNodeId) => {
      if (scope === 'global') return (project.globalVariables ?? []).map((v) => v.name);
      const node = targetRef.trim() ? find(targetRef.trim()) : ownerNodeId ? activeScene.nodes[ownerNodeId] : undefined;
      return node ? localEntries(node.variables).map((v) => v.name) : undefined;
    };
    const inputActions = Object.keys(projectActionsToMap(project.settings?.input?.actions));
    const animationsOf: LogicFormEnvironment['animationsOf'] = (targetRef, ownerNodeId) => {
      const start = targetRef.trim() ? find(targetRef.trim()) : ownerNodeId ? activeScene.nodes[ownerNodeId] : undefined;
      if (!start) return undefined;
      // AIS-76b: num Billboard, as animações são as do Sprite Project referenciado (ResourceRegistry), não as de um modelo animado
      if (start.type === 'Billboard') {
        const sprite = resolveSprite(start.properties.spriteProject, project.files ?? {}, resourcePathOf);
        return sprite?.ok ? sprite.project.animations.map((a) => a.name) : [];
      }
      const animated = findAnimatedNode(start, activeScene.nodes);
      return animated ? animationNamesOf(animated.properties, project.files ?? {}) : [];
    };
    const ownerOf = (behaviorId: string) => collectBehaviors(activeScene).find((b) => b.id === behaviorId)?.targetNodeId;
    return {
      nodes,
      files,
      variablesOf,
      ownerOf,
      inputActions,
      animationsOf,
      ctx: { inputActions: () => inputActions, animationsOf, nodeExists: (ref) => !!find(ref), nodeName: (ref) => find(ref)?.name, fileExists: (path) => fileSet.has(path), variablesOf },
    };
  }, [activeScene, project.files, project.globalVariables, project.settings?.input?.actions]);
}
