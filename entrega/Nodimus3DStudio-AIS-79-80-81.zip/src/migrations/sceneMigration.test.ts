import { beforeEach, describe, expect, it } from 'vitest';
import { migrateStepwise } from './index';
import { migrateSceneV1ToV2 } from './sceneMigrations';
import { SCENE_FUTURE_FIXTURE, SCENE_UNVERSIONED_FIXTURE, SCENE_V1_CANONICAL_FIXTURE, SCENE_V1_FIXTURE, SCENE_V2_FIXTURE } from './fixtures';
import { deserializeScene, parseSceneJson, serializeScene, serializeSceneToJson } from '../core/serialization/sceneSerializer';
import { collectUnresolvedContributions } from '../core/serialization/contributions';
import { isKnownLogicContribution } from '../core/serialization/logicResolver';
import { backupStorageKey, clearPendingBackups, flushPendingBackup, hasPendingBackup, notePendingBackup } from '../core/serialization/migrationBackup';
import { blockWrites, clearWriteBlocks, unblockWrites, writeBlockedReason } from '../core/serialization/writeGuard';
import { CURRENT_SCENE_SCHEMA_VERSION } from '../core/persistenceVersions';
import { validateSceneFile } from '../schemas';

const PATH = 'res://scenes/Fixture.scene.json';
const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v));

describe('migração de cena v1 → v2 → v3 (AIS-29b-C01, AIS-41b)', () => {
  it('fixture v1 (SceneData direto) migra para a versão corrente e valida no schema do formato canônico', () => {
    const r = migrateStepwise('scene', SCENE_V1_FIXTURE);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.migrated).toBe(true);
    expect(r.fromVersion).toBe(1);
    expect(r.toVersion).toBe(CURRENT_SCENE_SCHEMA_VERSION);
    expect(r.steps.map((s) => `${s.fromVersion}→${s.toVersion}`)).toEqual(['1→2', '2→3']); // um salto por vez
    const doc = r.data;
    expect(doc.sceneId).toBe('scene_fixture');
    expect(doc).not.toHaveProperty('id');
    expect(doc).not.toHaveProperty('path');
    expect(doc.sceneSettings).toEqual({ environment: { ambientColor: '#334155', ambientIntensity: 0.45 }, cameraSettings: { fov: 65 }, fog: { enabled: false } });
    expect(doc.schemaVersion).toBe(CURRENT_SCENE_SCHEMA_VERSION);
    expect(validateSceneFile(doc).success).toBe(true);
  });
  it('todos os nós passam intactos pela migração (nada é descartado)', () => {
    const r = migrateStepwise('scene', SCENE_V1_FIXTURE);
    if (!r.ok) throw new Error('falhou');
    const { hero: _heroOriginal, ...others } = SCENE_V1_FIXTURE.nodes;
    const { hero: _heroMigrated, ...migratedOthers } = r.data.nodes;
    expect(migratedOthers).toEqual(others); // os outros nós passam idênticos
    // v3 (AIS-41b): os Behaviors do herói saem de `visualLogic.behaviors` para `behaviors` (instâncias inline) SEM perder nenhum campo
    const original = SCENE_V1_FIXTURE.nodes.hero.visualLogic;
    expect(r.data.nodes.hero.behaviors).toEqual(original.behaviors);
    expect(r.data.nodes.hero.visualLogic).toEqual({ actions: original.actions });
    expect(Object.keys(r.data.nodes.hero).sort()).toEqual(Object.keys(SCENE_V1_FIXTURE.nodes.hero).sort());
  });
  it('v1 já no formato canônico só ganha o carimbo da versão corrente; documento sem schemaVersion vale v1', () => {
    const canonical = migrateStepwise('scene', SCENE_V1_CANONICAL_FIXTURE);
    expect(canonical.ok && canonical.migrated && canonical.toVersion).toBe(CURRENT_SCENE_SCHEMA_VERSION);
    if (canonical.ok) expect(canonical.data.sceneSettings).toEqual(SCENE_V1_CANONICAL_FIXTURE.sceneSettings);
    const legacy = migrateStepwise('scene', SCENE_UNVERSIONED_FIXTURE);
    expect(legacy.ok && legacy.fromVersion).toBe(1);
    if (legacy.ok) expect(legacy.data.sceneId).toBe('scene_fixture');
  });
  it('a migração é pura: não muda a entrada', () => {
    const input = clone(SCENE_V1_FIXTURE);
    const frozen = clone(input);
    migrateStepwise('scene', input);
    expect(input).toEqual(frozen);
    expect(migrateSceneV1ToV2(input)).not.toBe(input);
  });
  it('o editor abre a fixture v1 (cena inteira) pelo pipeline completo', () => {
    const r = deserializeScene(clone(SCENE_V1_FIXTURE), PATH);
    expect(r.ok).toBe(true);
    expect(r.migration).toMatchObject({ migrated: true, fromVersion: 1, toVersion: CURRENT_SCENE_SCHEMA_VERSION });
    expect(r.scene!.schemaVersion).toBe(CURRENT_SCENE_SCHEMA_VERSION);
    expect(r.scene!.nodes.cube.properties.position).toEqual({ x: 1, y: 2, z: 3 });
    expect(r.scene!.environment).toEqual({ ambientColor: '#334155', ambientIntensity: 0.45 });
    expect(r.scene!.path).toBe(PATH);
  });
});

describe('idempotência (AIS-29b-C04)', () => {
  it('migrar duas vezes dá o mesmo documento na versão corrente', () => {
    const once = migrateStepwise('scene', SCENE_V1_FIXTURE);
    if (!once.ok) throw new Error('falhou');
    const twice = migrateStepwise('scene', once.data);
    expect(twice.ok && twice.migrated).toBe(false);
    if (twice.ok) expect(twice.data).toEqual(once.data);
    // uma v2 migra uma vez (v2→v3) e a partir daí é estável
    const fromV2 = migrateStepwise('scene', SCENE_V2_FIXTURE);
    expect(fromV2.ok && fromV2.migrated).toBe(true);
    if (fromV2.ok) expect(migrateStepwise('scene', fromV2.data).ok && (migrateStepwise('scene', fromV2.data) as any).migrated).toBe(false);
  });
  it('abrir → salvar → abrir → salvar produz o mesmo texto (ponto fixo)', () => {
    const first = deserializeScene(clone(SCENE_V1_FIXTURE), PATH).scene!;
    const text1 = serializeSceneToJson(first);
    const second = parseSceneJson(text1, PATH);
    expect(second.migration?.migrated).toBe(false);
    expect(serializeSceneToJson(second.scene!)).toBe(text1);
  });
});

describe('falhas bloqueiam, nunca gravam parcial (AIS-29b-C05)', () => {
  it('versão mais nova é recusada, sem dado parcial; downgrade não é automático', () => {
    const r = migrateStepwise('scene', SCENE_FUTURE_FIXTURE);
    expect(r).toMatchObject({ ok: false, code: 'migration.version_newer' });
    expect('data' in r).toBe(false);
    const parsed = deserializeScene(clone(SCENE_FUTURE_FIXTURE), PATH);
    expect(parsed.ok).toBe(false);
    expect(parsed.scene).toBeUndefined();
    expect(parsed.diagnostics.map((d) => d.code)).toContain('scene.version_newer');
  });
  it('schemaVersion inválido e documento que não é objeto', () => {
    for (const bad of ['2', 0, -1, 1.5, null]) {
      const r = migrateStepwise('scene', { ...SCENE_V2_FIXTURE, schemaVersion: bad });
      if (bad === null) expect(r.ok).toBe(false);
      else expect(r).toMatchObject({ ok: false, code: 'migration.invalid_version' });
    }
    expect(migrateStepwise('scene', 'texto')).toMatchObject({ ok: false, code: 'migration.invalid_input' });
    expect(migrateStepwise('scene', [1, 2])).toMatchObject({ ok: false, code: 'migration.invalid_input' });
  });
  it('JSON inválido vira diagnóstico, sem exceção e sem cena', () => {
    const r = parseSceneJson('{ "schemaVersion": 1, ', PATH);
    expect(r.ok).toBe(false);
    expect(r.scene).toBeUndefined();
    expect(r.diagnostics[0].code).toBe('scene.json_invalid');
  });
});

describe('guarda de escrita: arquivo ilegível nunca é sobrescrito (AIS-29b-C05)', () => {
  beforeEach(() => clearWriteBlocks());
  it('bloqueia o caminho até ser aberto com sucesso ou salvo em outro lugar', () => {
    expect(writeBlockedReason(PATH)).toBeNull();
    blockWrites(PATH, 'JSON inválido');
    expect(writeBlockedReason(PATH)).toBe('JSON inválido');
    expect(writeBlockedReason('res://scenes/Outra.scene.json')).toBeNull();
    unblockWrites(PATH);
    expect(writeBlockedReason(PATH)).toBeNull();
  });
});

describe('contribuições não resolvidas (AIS-29b-C02)', () => {
  const opts = { isKnownContribution: isKnownLogicContribution };
  it('Behavior/Action de ID desconhecido são sinalizados com tudo o que veio (inclusive addonId legado)', () => {
    const scene = deserializeScene(clone(SCENE_V1_FIXTURE), PATH, opts);
    expect(scene.unresolved.map((u) => `${u.kind}:${u.contributionId}`).sort()).toEqual(['action:acao_inexistente', 'behavior:comportamento_removido']);
    const behavior = scene.unresolved.find((u) => u.kind === 'behavior')!;
    expect(behavior).toMatchObject({ nodeId: 'hero', source: 'custom', properties: { speed: 3, nested: { list: [1, 2, 3] } }, extras: { id: 'b_unknown', name: 'Meu Comportamento', addonId: 'pacote_legado', label: 'Meu Comportamento' } });
    // `raw` é o bloco na forma de arquivo: tudo o que veio (inclusive addonId, label e source) continua lá
    expect(behavior.raw).toMatchObject(SCENE_V1_FIXTURE.nodes.hero.visualLogic.behaviors[0]);
    expect(behavior.path).toBe('behaviors.0');
    expect(scene.diagnostics.filter((d) => d.code === 'logic.unresolved_contribution')).toHaveLength(2);
  });
  it('item conhecido do LogicRegistry não é sinalizado; sem resolvedor não há varredura', () => {
    const known = collectUnresolvedContributions({ nodes: { n: { id: 'n', visualLogic: { behaviors: [{ id: 'x', contributionId: 'continuous_rotation', source: 'builtin', properties: {} }] } } as any } }, isKnownLogicContribution);
    expect(known).toEqual([]);
    expect(deserializeScene(clone(SCENE_V1_FIXTURE), PATH).unresolved).toEqual([]);
  });
  it('abrir e salvar NÃO altera os blocos desconhecidos: propriedades idênticas', () => {
    const opened = deserializeScene(clone(SCENE_V1_FIXTURE), PATH, opts).scene!;
    const saved = serializeScene(opened);
    const savedHero = saved.nodes.hero as any;
    const original = SCENE_V1_FIXTURE.nodes.hero.visualLogic;
    expect(savedHero.visualLogic).toEqual({ actions: original.actions }); // as Actions soltas ficam exatamente como vieram
    expect(savedHero.behaviors).toHaveLength(2);
    original.behaviors.forEach((b: any, i: number) => expect(savedHero.behaviors[i]).toMatchObject(b)); // id, contributionId, source, addonId, label, properties
    // e de novo, depois de reabrir o que foi salvo
    const reopened = parseSceneJson(serializeSceneToJson(opened), PATH, opts);
    const again = serializeScene(reopened.scene!).nodes.hero as any;
    expect(again.visualLogic).toEqual({ actions: original.actions });
    expect(again.behaviors).toEqual(savedHero.behaviors);
    expect(reopened.unresolved).toHaveLength(2);
  });
});

describe('IDs estáveis (AIS-29b-C03)', () => {
  it('renomear o rótulo de um nó ou de um Behavior não altera nenhum ID', () => {
    const opened = deserializeScene(clone(SCENE_V1_FIXTURE), PATH).scene!;
    const before = Object.keys(opened.nodes).map((k) => [k, opened.nodes[k].id]);
    opened.nodes.cube = { ...opened.nodes.cube, name: 'Outro Nome' };
    const hero: any = opened.nodes.hero;
    hero.behaviors[0] = { ...hero.behaviors[0], name: 'Rótulo Novo' };
    const saved = serializeScene(opened);
    expect(Object.keys(saved.nodes)).toEqual(Object.keys(clone(serializeScene(deserializeScene(clone(SCENE_V1_FIXTURE), PATH).scene!).nodes)));
    for (const [key, id] of before) expect((saved.nodes[key] as any).id).toBe(id);
    expect((saved.nodes.hero as any).behaviors[0].id).toBe('b_unknown');
    expect((saved.nodes.hero as any).behaviors[0].contributionId).toBe('comportamento_removido');
    expect((saved.nodes.hero as any).behaviors[0].name).toBe('Rótulo Novo');
    expect((saved.nodes.cube as any).name).toBe('Outro Nome');
  });
});

describe('política de backup antes de sobrescrever arquivo migrado', () => {
  beforeEach(() => clearPendingBackups());
  const makeWriter = () => {
    const store = new Map<string, string>();
    return { store, writer: { exists: (k: string) => store.has(k), write: (k: string, c: string) => void store.set(k, c) } };
  };
  it('o original é gravado no primeiro salvamento, uma vez por caminho e versão de origem', () => {
    const { store, writer } = makeWriter();
    const original = JSON.stringify(SCENE_V1_FIXTURE);
    notePendingBackup(PATH, 1, original);
    expect(hasPendingBackup(PATH)).toBe(true);
    const key = flushPendingBackup('proj1', PATH, writer);
    expect(key).toBe(backupStorageKey('proj1', PATH, 1));
    expect(store.get(key!)).toBe(original);
    expect(hasPendingBackup(PATH)).toBe(false);
    expect(flushPendingBackup('proj1', PATH, writer)).toBeNull(); // segundo salvamento: nada a fazer
  });
  it('nunca sobrescreve um backup existente', () => {
    const { store, writer } = makeWriter();
    store.set(backupStorageKey('p', PATH, 1), 'backup antigo');
    notePendingBackup(PATH, 1, 'conteúdo novo');
    expect(flushPendingBackup('p', PATH, writer)).toBeNull();
    expect(store.get(backupStorageKey('p', PATH, 1))).toBe('backup antigo');
  });
  it('chaves distintas por projeto, caminho e versão', () => {
    const a = backupStorageKey('p', PATH, 1);
    expect(a).not.toBe(backupStorageKey('q', PATH, 1));
    expect(a).not.toBe(backupStorageKey('p', 'res://scenes/Outra.scene.json', 1));
    expect(a).not.toBe(backupStorageKey('p', PATH, 2));
  });
});
