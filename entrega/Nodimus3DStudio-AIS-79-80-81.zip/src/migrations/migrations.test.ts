import { describe, expect, it, vi, beforeEach } from 'vitest';

describe('applyMigrations (alvo = versão corrente do registry)', () => {
  beforeEach(() => {
    vi.resetModules();
  });

  it('sem alvo explícito usa CURRENT_*; versão igual não migra', async () => {
    const { applyMigrations } = await import('./index');
    const r = applyMigrations('prefab', { schemaVersion: 1, x: 1 });
    expect(r.migrated).toBe(false);
    expect(r.toVersion).toBe(1);
    // 'scene' já está na v3 (AIS-41b): um documento na versão corrente também não migra
    const s = applyMigrations('scene', { schemaVersion: 3, x: 1 });
    expect(s.migrated).toBe(false);
    expect(s.toVersion).toBe(3);
  });

  it('migra até a versão registrada quando a v2 existir (sem 1 fixo)', async () => {
    const { applyMigrations, registerMigration } = await import('./index');
    registerMigration('prefab', {
      fromVersion: 1,
      toVersion: 2,
      description: 'teste',
      migrate: (d: any) => ({ ...d, migratedFlag: true }),
    });
    const r = applyMigrations('prefab', { schemaVersion: 1 });
    expect(r.migrated).toBe(true);
    expect(r.toVersion).toBe(2);
    expect((r.data as any).migratedFlag).toBe(true);
    expect((r.data as any).schemaVersion).toBe(2);
  });

  it('dado mais novo que o corrente é preservado, sem rebaixar', async () => {
    const { applyMigrations } = await import('./index');
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const r = applyMigrations('project', { schemaVersion: 9, keep: 'sim' });
    expect(r.toVersion).toBe(9);
    expect((r.data as any).keep).toBe('sim');
    warn.mockRestore();
  });
});
