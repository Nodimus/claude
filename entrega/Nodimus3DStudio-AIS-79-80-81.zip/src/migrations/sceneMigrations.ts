/**
 * AIS-29b — migrações de `*.scene.json`. Funções PURAS (raw in → document out), uma por salto de versão, nunca
 * monolíticas. Registradas em `src/migrations/index.ts`.
 *
 *  v1 → v2: o formato antigo (`SceneData` gravado direto: `id`, `path`, `environment`/`cameraSettings`/… na raiz)
 *           vira o formato canônico `SceneFile` (`sceneId`, `sceneSettings`; sem `path`, que é onde o arquivo mora).
 *           Já no formato canônico (arquivos gravados pelo AIS-29 antes do carimbo v2): só a versão muda.
 *           Nada é descartado: campos desconhecidos da raiz e todos os nós passam intactos.
 *
 *  v2 → v3 (AIS-41b): `GameNode.behaviors` deixa de ser uma lista de IDs de uma lista global e passa a ser a lista de
 *           instâncias inline do nó. Três origens são migradas:
 *             1. `behaviors: ['id', …]` no nó + a definição em `visualLogic.behaviors` (convenção do AIS-29);
 *             2. a lista global `behaviors: [Behavior…]` na raiz da cena (com `targetNodeId`), anexada ao nó referenciado;
 *             3. IDs `beh_*` do projeto inicial, resolvidos pelos Behaviors de exemplo (`core/starterBehaviors`).
 *           O que não acha dono (Behavior sem nó, ID sem definição, entrada que não é um objeto) NÃO é apagado nem
 *           anexado a um nó errado: vai intacto para `metadata.legacyBehaviors`, com o motivo. A lista global é removida;
 *           lida e migrada, nunca regravada.
 */
import { behaviorToFile } from '../core/serialization/behaviorFile';
import { createStarterBehavior } from '../core/starterBehaviors';
import type { BehaviorInstance } from '../types/visualLogic';

type AnyRecord = Record<string, any>;
const isRecord = (v: unknown): v is AnyRecord => typeof v === 'object' && v !== null && !Array.isArray(v);
const clone = <T>(v: T): T => (v === undefined ? v : JSON.parse(JSON.stringify(v)));

const SETTINGS_KEYS = ['environment', 'cameraSettings', 'postProcessing', 'fog'] as const;

export function migrateSceneV1ToV2(data: unknown): unknown {
  if (!isRecord(data)) return data;
  const out: AnyRecord = { ...data };

  // identidade da cena: `id` (antigo) → `sceneId` (canônico); nunca inventada
  if (typeof out.sceneId !== 'string' && typeof out.id === 'string') out.sceneId = out.id;
  delete out.id;
  // `path` é a localização do arquivo, não um dado da cena
  delete out.path;

  // configurações da cena que estavam na raiz passam para `sceneSettings`
  const settings: AnyRecord = isRecord(out.sceneSettings) ? { ...out.sceneSettings } : {};
  for (const key of SETTINGS_KEYS) {
    if (key in out) {
      if (settings[key] === undefined) settings[key] = out[key];
      delete out[key];
    }
  }
  if (isRecord(out.environmentSettings)) {
    if (settings.environment === undefined) settings.environment = out.environmentSettings;
    delete out.environmentSettings;
  }
  if (Object.keys(settings).length > 0) out.sceneSettings = settings;
  return out;
}

/** Motivo pelo qual um Behavior ficou em `metadata.legacyBehaviors` em vez de num nó. */
export type LegacyBehaviorReason = 'unattached' | 'unresolved_id' | 'invalid_entry';

export interface LegacyBehaviorEntry {
  reason: LegacyBehaviorReason;
  /** Nó que o listava (`unresolved_id`/`invalid_entry`) ou o alvo declarado (`unattached`). */
  nodeId?: string;
  /** O Behavior (forma da lista global) ou a entrada original, intacta. */
  behavior?: unknown;
  /** ID listado no nó, sem definição em lugar nenhum. */
  id?: string;
}

/** Entrada da lista global (forma de autoria, com `behaviorType` e `targetNodeId`) → forma de arquivo v3 (`contributionId`). */
function legacyGlobalToFile(entry: AnyRecord): AnyRecord | null {
  if (typeof entry.id !== 'string' || !entry.id) return null;
  const { targetNodeId: _target, ...rest } = entry;
  const behaviorType = typeof rest.behaviorType === 'string' ? rest.behaviorType : typeof rest.contributionId === 'string' ? rest.contributionId : '';
  const instance: BehaviorInstance = {
    id: entry.id,
    name: typeof rest.name === 'string' && rest.name ? rest.name : behaviorType || entry.id,
    behaviorType,
    enabled: rest.enabled !== false,
    properties: isRecord(rest.properties) ? clone(rest.properties) : {},
    rules: Array.isArray(rest.rules) ? clone(rest.rules) : [],
  };
  const file = behaviorToFile(instance);
  // campos desconhecidos da entrada (versão futura, dados legados) seguem junto
  for (const key of Object.keys(rest)) {
    if (!['id', 'name', 'behaviorType', 'contributionId', 'enabled', 'properties', 'rules', 'schemaVersion'].includes(key) && file[key] === undefined) file[key] = clone(rest[key]);
  }
  return file;
}

export function migrateSceneV2ToV3(data: unknown): unknown {
  if (!isRecord(data) || !isRecord(data.nodes)) return data;
  const out: AnyRecord = { ...data };
  const nodes: AnyRecord = {};
  const legacy: LegacyBehaviorEntry[] = [];

  // lista global antiga (raiz da cena): nunca regravada
  const globalList: AnyRecord[] = Array.isArray(out.behaviors) ? out.behaviors.filter(isRecord) : [];
  const globalRejected = Array.isArray(out.behaviors) ? out.behaviors.filter((e: unknown) => !isRecord(e)) : [];
  delete out.behaviors;
  for (const junk of globalRejected) legacy.push({ reason: 'invalid_entry', behavior: clone(junk) });
  const globalById = new Map<string, AnyRecord>();
  for (const entry of globalList) if (typeof entry.id === 'string' && entry.id) globalById.set(entry.id, entry);
  const consumed = new Set<string>();
  // o ID de uma instância é único NA CENA (a lista achatada da UI e os Commands a endereçam por ele): dois nós que listavam o
  // mesmo ID antigo ficam com instâncias independentes, a segunda com o ID sufixado pelo nó dono
  const usedIds = new Set<string>();
  const uniqueId = (id: string, nodeId: string) => {
    let next = id;
    for (let n = 2; usedIds.has(next); n++) next = n === 2 ? `${id}__${nodeId}` : `${id}__${nodeId}_${n}`;
    usedIds.add(next);
    return next;
  };

  for (const [nodeId, node] of Object.entries(data.nodes)) {
    if (!isRecord(node)) {
      nodes[nodeId] = node; // corrompido: o parser trata como Missing
      continue;
    }
    const next: AnyRecord = { ...node };
    const attached: AnyRecord[] = [];
    const seen = new Set<string>();
    const attach = (file: AnyRecord | null) => {
      if (!file || typeof file.id !== 'string' || seen.has(file.id)) return;
      seen.add(file.id);
      const id = uniqueId(file.id, nodeId);
      attached.push(id === file.id ? file : { ...file, id });
    };

    // definições persistidas pelo AIS-29 em `visualLogic.behaviors` (instâncias com `contributionId`)
    const visualLogic = isRecord(next.visualLogic) ? { ...next.visualLogic } : undefined;
    const inVisualLogic = new Map<string, AnyRecord>();
    if (visualLogic && Array.isArray(visualLogic.behaviors)) {
      for (const entry of visualLogic.behaviors) if (isRecord(entry) && typeof entry.id === 'string') inVisualLogic.set(entry.id, entry);
    }

    const listed: unknown[] = Array.isArray(next.behaviors) ? next.behaviors : [];
    for (const entry of listed) {
      if (typeof entry === 'string') {
        const definition = inVisualLogic.get(entry);
        if (definition) {
          attach(clone(definition));
          continue;
        }
        const fromGlobal = globalById.get(entry);
        if (fromGlobal) {
          consumed.add(entry);
          attach(legacyGlobalToFile(fromGlobal));
          continue;
        }
        const starter = createStarterBehavior(entry);
        if (starter) {
          attach(behaviorToFile(starter));
          continue;
        }
        legacy.push({ reason: 'unresolved_id', nodeId, id: entry });
      } else if (isRecord(entry) && typeof entry.id === 'string' && entry.id) {
        attach(clone(entry)); // já inline (tolerância): o parser v3 converte
      } else {
        legacy.push({ reason: 'invalid_entry', nodeId, behavior: clone(entry) });
      }
    }
    // definições do nó que a lista de IDs não citava continuam sendo DELE
    for (const [id, definition] of inVisualLogic) if (!seen.has(id)) attach(clone(definition));
    if (visualLogic) {
      delete visualLogic.behaviors;
      if (Object.keys(visualLogic).length > 0) next.visualLogic = visualLogic;
      else delete next.visualLogic;
    }
    if (attached.length > 0) next.behaviors = attached;
    else delete next.behaviors;
    nodes[nodeId] = next;
  }

  // Behaviors da lista global que nenhum nó citou por ID: o `targetNodeId` decide (id, ou nome único)
  const nameCount = new Map<string, string[]>();
  for (const [id, node] of Object.entries(nodes)) {
    const name = isRecord(node) && typeof node.name === 'string' ? node.name : id;
    nameCount.set(name, [...(nameCount.get(name) ?? []), id]);
  }
  for (const entry of globalList) {
    if (typeof entry.id !== 'string' || !entry.id) {
      legacy.push({ reason: 'invalid_entry', behavior: clone(entry) });
      continue;
    }
    if (consumed.has(entry.id)) continue;
    const target = typeof entry.targetNodeId === 'string' ? entry.targetNodeId : '';
    const byName = nameCount.get(target) ?? [];
    const ownerId = isRecord(nodes[target]) ? target : byName.length === 1 ? byName[0] : null;
    const file = legacyGlobalToFile(entry);
    const owner = ownerId ? nodes[ownerId] : null;
    if (!owner || !file) {
      legacy.push({ reason: 'unattached', nodeId: target || undefined, behavior: clone(entry) });
      continue;
    }
    const current: AnyRecord[] = Array.isArray(owner.behaviors) ? owner.behaviors : [];
    if (!current.some((b) => b.id === file.id) && !usedIds.has(file.id)) {
      usedIds.add(file.id);
      nodes[ownerId!] = { ...owner, behaviors: [...current, file] };
    } else if (usedIds.has(file.id) && !current.some((b) => b.id === file.id)) {
      const id = uniqueId(file.id, ownerId!);
      nodes[ownerId!] = { ...owner, behaviors: [...current, { ...file, id }] };
    }
  }

  out.nodes = nodes;
  if (legacy.length > 0) {
    const metadata: AnyRecord = isRecord(out.metadata) ? { ...out.metadata } : {};
    metadata.legacyBehaviors = [...(Array.isArray(metadata.legacyBehaviors) ? metadata.legacyBehaviors : []), ...legacy];
    out.metadata = metadata;
  }
  return out;
}
