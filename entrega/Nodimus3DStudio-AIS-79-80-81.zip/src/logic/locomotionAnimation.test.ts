import { describe, expect, it, vi } from 'vitest';
import type { BehaviorRuntimeContext } from './types';
import { buildEngineApi } from '../runtime/engineApi';
import { applyLocomotionAnimation } from './locomotionAnimation';

const node = (id: string, props: Record<string, unknown> = {}, children: unknown[] = []) => ({ persistentNodeId: id, type: 'MeshInstance', disposed: false, properties: props, children });

function ctxWith(props: Record<string, unknown>, animation: { play: ReturnType<typeof vi.fn> } | null, self: unknown = node('hero', { animated: true })) {
  const logs: string[] = [];
  const noop = () => undefined;
  const known = new Map<string, unknown>([['hero', node('hero', { animated: true })], ['other', node('other', { animated: true })], ['model', node('model', { animated: true })], ['actor', node('actor')]]);
  // a Behavior toca a animação pela `EngineApi.animation` (decisão 32); o host de animação da sessão é injetado aqui
  const engine = buildEngineApi({
    instanceById: (ref: string) => (ref === (self as { persistentNodeId: string }).persistentNodeId ? self : known.get(ref)) as never,
    instanceByName: () => undefined,
    variables: () => null,
    input: () => ({}) as never,
    physics: () => null,
    sceneTime: () => 0,
    emitSignal: noop,
    connectSignal: () => noop,
    onPhysicsEvent: () => noop,
    log: noop,
    commitTransform: noop,
    animation: () => animation as never,
  } as never);
  const ctx = {
    engine,
    node: self,
    state: { properties: props, memory: {} },
    getNode: (id: string) => (id === 'other' ? node('other', { animated: true }) : undefined),
    log: (_level: string, message: string) => logs.push(message),
  } as unknown as BehaviorRuntimeContext;
  return { ctx, logs };
}
const S = (state: 'idle' | 'walk' | 'run' | 'jump' | 'fall') => ({ state, speed: 0, grounded: true });

describe('applyLocomotionAnimation (decisão 30)', () => {
  it('só pede ao host quando o estado MUDA, com o crossfade do Behavior', () => {
    const play = vi.fn(() => null);
    const { ctx } = ctxWith({ idle: 'Idle', walk: 'Walk', crossfade: 0.4 }, { play });
    applyLocomotionAnimation(ctx, S('idle'));
    applyLocomotionAnimation(ctx, S('idle'));
    applyLocomotionAnimation(ctx, S('walk'));
    expect(play.mock.calls).toEqual([
      ['hero', 'Idle', { crossfade: 0.4 }],
      ['hero', 'Walk', { crossfade: 0.4 }],
    ]);
  });

  it('estado sem animação escolhida = nenhuma troca; sem host = nada', () => {
    const play = vi.fn(() => null);
    applyLocomotionAnimation(ctxWith({ idle: '' }, { play }).ctx, S('idle'));
    applyLocomotionAnimation(ctxWith({ idle: 'Idle' }, null).ctx, S('idle'));
    expect(play).not.toHaveBeenCalled();
  });

  it('usa o objeto escolhido em animationTarget e cai no primeiro descendente animado', () => {
    const play = vi.fn(() => null);
    applyLocomotionAnimation(ctxWith({ animationTarget: 'other', walk: 'Walk' }, { play }).ctx, S('walk'));
    expect(play).toHaveBeenLastCalledWith('other', 'Walk', expect.anything());
    const child = node('model', { animated: true });
    applyLocomotionAnimation(ctxWith({ walk: 'Walk' }, { play }, node('actor', {}, [child])).ctx, S('walk'));
    expect(play).toHaveBeenLastCalledWith('model', 'Walk', expect.anything());
  });

  it('animação inexistente ou sem objeto animado: aviso UMA vez por mensagem, sem exceção', () => {
    const play = vi.fn(() => 'o clipe "Voar" não existe');
    const a = ctxWith({ idle: 'Voar', walk: 'Voar' }, { play });
    applyLocomotionAnimation(a.ctx, S('idle'));
    applyLocomotionAnimation(a.ctx, S('walk'));
    expect(a.logs).toHaveLength(2); // estados diferentes = mensagens diferentes, cada uma uma vez
    const b = ctxWith({ idle: 'Idle' }, { play }, node('semAnim', {}));
    applyLocomotionAnimation(b.ctx, S('idle'));
    expect(b.logs[0]).toMatch(/não há objeto animado/);
  });
});
