import { afterEach, describe, expect, it } from 'vitest';
import { LOGIC_TEXTS, logicText } from './logicTexts';
import { LogicRegistry } from './registry';
import { getCurrentLanguage, setCurrentLanguage } from '../core/i18n';

/** AIS-80 — o catálogo de lógica troca de idioma sem recarregar, e nenhum texto em português fica sem tradução para o inglês. */
describe('textos do catálogo de lógica (AIS-80)', () => {
  const original = getCurrentLanguage();
  afterEach(() => setCurrentLanguage(original));

  const PT = /[ãõçáéíóúâêôà]|\b(para|com|não|quando|enquanto|ação|nenhum|nenhuma)\b/i;
  const texts = (): string[] => {
    const out: string[] = [];
    for (const def of [...LogicRegistry.listTriggers(), ...LogicRegistry.listConditions(), ...LogicRegistry.listActions(), ...LogicRegistry.listBehaviors()]) {
      out.push(def.label, def.description);
      for (const p of def.params) out.push(p.label, ...(p.emptyLabel ? [p.emptyLabel] : []));
    }
    return out;
  };

  it('todo texto em português do catálogo tem entrada em LOGIC_TEXTS (e a entrada difere do original)', () => {
    setCurrentLanguage('pt-BR'); // os acessores devolvem o texto-fonte; o que o `pt` não resolve ficaria em português no `en`
    const missing = [...new Set(texts())].filter((t) => PT.test(t) && !LOGIC_TEXTS[t]);
    expect(missing).toEqual([]);
  });

  it('as entradas têm os dois idiomas e preservam {placeholders}', () => {
    for (const [source, entry] of Object.entries(LOGIC_TEXTS)) {
      expect(entry.en.length, source).toBeGreaterThan(0);
      expect(entry.pt.length, source).toBeGreaterThan(0);
      expect((entry.en.match(/\{\w+\}/g) ?? []).sort(), source).toEqual((entry.pt.match(/\{\w+\}/g) ?? []).sort());
    }
  });

  it('trocar o idioma troca label/description na hora (acessores), sem recarregar', () => {
    const def = LogicRegistry.listActions().find((a) => a.id === 'play_sound')!;
    setCurrentLanguage('pt-BR');
    const pt = def.description;
    setCurrentLanguage('en');
    const en = def.description;
    expect(en).toBe('Plays a sound effect, spatial (3D), from the emitter node.');
    expect(pt).toBe('Toca um efeito sonoro, espacial (3D) a partir do nó emissor.');
    expect(logicText('Add Force')).toBe('Add Force'); // nome técnico: igual nos dois idiomas
  });
});
