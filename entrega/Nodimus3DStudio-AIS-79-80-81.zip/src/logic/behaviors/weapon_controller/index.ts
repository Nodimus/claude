import { defineBehavior, newLogicId } from '../../types';
import { WEAPON_DEFAULTS as D } from '../../../runtime/weapons/params';
import { WEAPON_HOOK_TRIGGERS } from '../../../runtime/weapons/types';

/**
 * AIS-69 (ARM-01): Behavior sobre o núcleo `src/runtime/weapons/`. Cadência, munição e recarga ficam aqui; disparo, impacto e dano são do
 * núcleo (o mesmo das Actions e da IA). Os hooks são Triggers das PRÓPRIAS regras: On Weapon Shoot / Impact / Empty Magazine / Reload.
 */
export default defineBehavior({
  id: 'weapon_controller',
  label: 'Weapon Controller',
  description:
    'Arma do nó (jogador ou inimigo): lê a ação Fire, respeita cadência e munição (variável Local), e dispara projétil físico (prefab em res://prefabs/) ou hitscan (raycast). Os hooks On Weapon Shoot/Impact/Empty/Reload são Triggers das regras deste Behavior. Plano 2D vem de Colisão → constrainToPlane do atirador e do projétil.',
  category: 'Physics',
  requires: ['requiresPhysics'],
  params: [
    { key: 'gunName', label: 'Gun Name', type: 'string', default: D.gunName },
    { key: 'bullet', label: 'Bullet (prefab)', type: 'file', default: D.bullet, accept: ['.prefab.json'], root: 'res://prefabs/', visibleWhen: { key: 'fireMode', equals: 'physical' } },
    { key: 'firepoint', label: 'Firepoint', type: 'node', default: D.firepoint, emptyLabel: '(este nó)' },
    { key: 'impactEffect', label: 'Impact Effect (prefab)', type: 'file', default: D.impactEffect, accept: ['.prefab.json'], root: 'res://prefabs/' },
    { key: 'aimTarget', label: 'Aim Target', type: 'node', default: D.aimTarget, emptyLabel: '(frente do Firepoint)' },
    { key: 'aimFromCamera', label: 'Aim From Camera', type: 'boolean', default: D.aimFromCamera },
    { key: 'aimWithPitch', label: 'Aim With Camera Pitch (1st person)', type: 'boolean', default: D.aimWithPitch, visibleWhen: { key: 'aimFromCamera', equals: true } },
    { key: 'fireMode', label: 'Fire Mode', type: 'enum', default: D.fireMode, options: ['physical', 'hitscan'] },
    { key: 'fireAction', label: 'Fire Action', type: 'enum', default: D.fireAction, options: ['Fire'], optionsFrom: 'inputActions' },
    { key: 'shootDelay', label: 'Shoot Delay (ms)', type: 'number', default: D.shootDelay },
    { key: 'shootOnce', label: 'Shoot Once Per Press', type: 'boolean', default: D.shootOnce },
    { key: 'recoil', label: 'Recoil', type: 'boolean', default: D.recoil },
    { key: 'recoilHorizontal', label: 'Recoil Horizontal (°)', type: 'number', default: D.recoilHorizontal, visibleWhen: { key: 'recoil', equals: true } },
    { key: 'recoilVertical', label: 'Recoil Vertical (°)', type: 'number', default: D.recoilVertical, visibleWhen: { key: 'recoil', equals: true } },
    { key: 'magazine', label: 'Magazine (0 = infinite)', type: 'number', default: D.magazine },
    { key: 'ammo', label: 'Ammo Variable (Local)', type: 'string', default: D.ammo },
    { key: 'maxAmmo', label: 'Max Ammo (0 = no cap)', type: 'number', default: D.maxAmmo },
    { key: 'reloadAction', label: 'Reload Action', type: 'enum', default: D.reloadAction, options: ['Reload'], optionsFrom: 'inputActions' },
    { key: 'reloadDelay', label: 'Reload Delay (ms)', type: 'number', default: D.reloadDelay },
    { key: 'autoReload', label: 'Auto Reload', type: 'boolean', default: D.autoReload },
    { key: 'bulletSpeed', label: 'Bullet Speed (m/s)', type: 'number', default: D.bulletSpeed, visibleWhen: { key: 'fireMode', equals: 'physical' } },
    { key: 'bulletDamage', label: 'Bullet Damage', type: 'number', default: D.bulletDamage },
    { key: 'damageVariable', label: 'Damage Variable', type: 'string', default: D.damageVariable },
    { key: 'bulletRange', label: 'Bullet Range (m)', type: 'number', default: D.bulletRange },
    { key: 'rangeMode', label: 'Range Mode', type: 'enum', default: D.rangeMode, options: ['distance', 'time'], visibleWhen: { key: 'fireMode', equals: 'physical' } },
    { key: 'bulletLifetimeMs', label: 'Bullet Lifetime (ms)', type: 'number', default: D.bulletLifetimeMs, visibleWhen: { key: 'rangeMode', equals: 'time' } },
    { key: 'bulletFacesMotion', label: 'Bullet Faces Motion', type: 'boolean', default: D.bulletFacesMotion, visibleWhen: { key: 'fireMode', equals: 'physical' } },
    { key: 'collisionDestroyDelayMs', label: 'Destroy Delay After Hit (ms)', type: 'number', default: D.collisionDestroyDelayMs, visibleWhen: { key: 'fireMode', equals: 'physical' } },
    { key: 'ignoreTags', label: 'Ignore Tags (a, b)', type: 'string', default: D.ignoreTags },
    { key: 'onlyTags', label: 'Only Tags (a, b)', type: 'string', default: D.onlyTags },
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Weapon Controller (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'weapon_controller',
    enabled: true,
    properties: { ...D },
    // os 4 hooks nascem como regras vazias: o usuário só liga Actions a cada uma (o editor de regras não cria regras novas)
    rules: WEAPON_HOOK_TRIGGERS.map((eventType) => ({ id: newLogicId('rule_'), eventType, parameters: {}, conditions: [{ id: newLogicId('c_'), type: 'always', parameters: {} }], actions: [] })),
  }),
});
