import { defineBehavior, newLogicId } from '../../types';
import { LOCOMOTION_ANIMATION_DEFAULTS, LOCOMOTION_ANIMATION_PARAMS } from '../../locomotionAnimation';
import { FIRST_PERSON_MOVEMENT_DEFAULTS as D } from '../../../runtime/cameraRig/params';

export default defineBehavior({
  id: 'first_person_movement',
  label: 'First Person Movement',
  description:
    'Movimento em primeira pessoa do ATOR (decisão 28): WASD relativo ao olhar da câmera ativa, pulo (Jump) e corrida (Sprint); o corpo acompanha o olhar. Não controla câmera: adicione um nó Camera com "First Person Camera" apontando para este nó. Exige Colisão do nó como "Personagem" (character).',
  category: 'Movement',
  requires: ['requiresPhysics'],
  presetPhysics: { bodyMode: 'character' },
  preset: { label: 'First Person', order: 4 },
  params: [
    { key: 'moveSpeed', label: 'Move Speed (m/s)', type: 'number', default: D.moveSpeed },
    { key: 'jumpSpeed', label: 'Jump Speed (m/s)', type: 'number', default: D.jumpSpeed },
    { key: 'sprintMultiplier', label: 'Sprint Multiplier (1 = sem corrida)', type: 'number', default: D.sprintMultiplier },
    { key: 'smoothing', label: 'Smooth Moving (1/s, 0 = off)', type: 'number', default: D.smoothing },
    { key: 'bodyFollowsView', label: 'Body Follows View', type: 'boolean', default: D.bodyFollowsView },
    ...LOCOMOTION_ANIMATION_PARAMS,
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `First Person Movement (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'first_person_movement',
    enabled: true,
    properties: { ...D, ...LOCOMOTION_ANIMATION_DEFAULTS },
    rules: [],
  }),
});
