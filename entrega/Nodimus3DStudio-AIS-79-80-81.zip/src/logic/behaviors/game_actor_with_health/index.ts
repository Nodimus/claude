import { defineBehavior, newLogicId } from '../../types';
import { ACTOR_DEFAULTS as D } from '../../../runtime/ai/params';

/**
 * AIS-71: VITAIS do ator — reage ao dano (`damage_taken` do núcleo de armas, AIS-69) e à morte. Não move, não percebe, não ataca. A vida é
 * uma variável Local comum (`#nome.health` funciona sem caso especial), DECLARADA ao adicionar o Behavior (Command com Undo, `presetVariables`);
 * o runtime nunca cria variável. Os ganchos são as regras do próprio Behavior (nascem vazias).
 */
const hook = (eventType: string) => ({ id: newLogicId('rule_'), eventType, parameters: {}, conditions: [{ id: newLogicId('c_'), type: 'always', parameters: {} }], actions: [] });

export default defineBehavior({
  id: 'game_actor_with_health',
  label: 'Game Actor with Health',
  description:
    'Vida do ator (variável Local, padrão "health", declarada ao adicionar este Behavior): dispara On Actor Hit a cada dano e On Actor Die UMA vez quando chega a 0 (toca a animação de morte). Não destrói o nó: ligue uma Action ao gancho. Combine com AI State Machine para NPCs.',
  category: 'AI',
  params: [
    { key: 'health', label: 'Health (initial value)', type: 'number', default: D.health },
    { key: 'healthVariable', label: 'Health Variable (Local)', type: 'string', default: D.healthVariable, variable: true, variableScope: 'local' },
    { key: 'dieAnimation', label: 'Die Animation', type: 'enum', default: D.dieAnimation, optionsFrom: 'animations' },
  ],
  presetVariables: (p) => ({ [typeof p.healthVariable === 'string' && p.healthVariable.trim() ? p.healthVariable.trim() : D.healthVariable]: typeof p.health === 'number' && Number.isFinite(p.health) ? p.health : D.health }),
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Game Actor with Health (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'game_actor_with_health',
    enabled: true,
    properties: { ...D },
    rules: [hook('on_actor_hit'), hook('on_actor_die')],
  }),
});
