import { defineBehavior, newLogicId } from '../../types';
import { CAMERA_RTS_DEFAULTS as D } from '../../../runtime/cameraRig/params';

export default defineBehavior({
  id: 'camera_rts',
  label: 'RTS Camera',
  description:
    'Câmera de estratégia (decisão 28): vista inclinada que anda pelo chão — pan com WASD e pelas bordas da viewport — e dá zoom com a roda do mouse. Sem alvo e sem player. Limites opcionais da área jogável (Bounds Min/Max no plano XZ; min ≥ max = sem limite). Só em nó Camera ativo.',
  category: 'Camera',
  allowedNodeTypes: ['Camera'],
  params: [
    { key: 'distanceFromBoundary', label: 'Distance From Boundary (px, 0 = off)', type: 'number', default: D.distanceFromBoundary },
    { key: 'panSpeed', label: 'Pan Speed (m/s)', type: 'number', default: D.panSpeed },
    { key: 'enableZoomScroll', label: 'Enable Zoom Scroll', type: 'boolean', default: D.enableZoomScroll },
    { key: 'zoomScrollDistance', label: 'Zoom Scroll Distance (m/click)', type: 'number', default: D.zoomScrollDistance },
    { key: 'minZoomDistance', label: 'Min Zoom Distance (m)', type: 'number', default: D.minZoomDistance },
    { key: 'maxZoomDistance', label: 'Max Zoom Distance (m)', type: 'number', default: D.maxZoomDistance },
    { key: 'tilt', label: 'Tilt (°, 90 = de cima)', type: 'number', default: D.tilt },
    { key: 'fov', label: 'Field of View (°)', type: 'number', default: D.fov },
    { key: 'boundsMin', label: 'Bounds Min', type: 'vector3', default: D.boundsMin },
    { key: 'boundsMax', label: 'Bounds Max', type: 'vector3', default: D.boundsMax },
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `RTS Camera (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'camera_rts',
    enabled: true,
    properties: { ...D, boundsMin: { ...D.boundsMin }, boundsMax: { ...D.boundsMax } },
    rules: [],
  }),
});
