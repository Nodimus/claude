import type { BehaviorRuntime, BehaviorRuntimeModule } from '../../types';
import { edgePanAxes, initialRtsState, readCameraRtsParams, rtsLimits, rtsPose, stepRts, type RtsState } from '../../../runtime/cameraRig';
import { cameraNodeActive } from '../../cameraRuntime';

/**
 * RTS Camera (AIS-47d, decisão 28): sem alvo e sem player. Anda pelo chão (pan com `Move*` e pelas bordas da viewport) e dá zoom
 * pela roda, tudo pelo `InputManager` (`pointer.x/y/bounds/wheel`). O yaw é o do nó `Camera`; o foco, a distância e os limites são
 * estado do RIG (runtime). Só publica com o nó `active`.
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let state: RtsState = { fx: 0, fz: 0, distance: 10 };
    let yaw = 0;
    return {
      attach(ctx) {
        yaw = ctx.initialTransform.rotation[1];
        const [x, y, z] = ctx.initialTransform.position;
        const p = readCameraRtsParams(ctx.state.properties);
        state = initialRtsState({ x, y, z }, yaw, { ...p, limits: rtsLimits(p) });
      },
      onLateUpdate(ctx, dt) {
        if (!cameraNodeActive(ctx)) {
          ctx.setGameCamera(null);
          return;
        }
        const p = readCameraRtsParams(ctx.state.properties);
        const pointer = ctx.input.pointer;
        const edge = edgePanAxes(pointer, pointer?.bounds, p.distanceFromBoundary);
        const params = { ...p, limits: rtsLimits(p) };
        state = stepRts(
          state,
          params,
          {
            forward: Math.max(-1, Math.min(1, ctx.input.getAxis('MoveBackward', 'MoveForward') + edge.forward)),
            strafe: Math.max(-1, Math.min(1, ctx.input.getAxis('MoveLeft', 'MoveRight') + edge.strafe)),
            wheel: pointer?.wheel ?? 0,
          },
          yaw,
          dt
        );
        const pose = rtsPose(state, p, yaw);
        ctx.setGameCamera({ position: pose.position, quaternion: pose.quaternion, fov: p.fov, pointerLock: false, view: { yaw, pitch: -p.tilt }, kind: 'camera' });
      },
      detach(ctx) {
        ctx.setGameCamera(null);
      },
    };
  },
};
export default mod;
