import { defineBehavior, newLogicId } from '../../types';
import { CAMERA_FIRST_PERSON_DEFAULTS as D } from '../../../runtime/cameraRig/params';

export default defineBehavior({
  id: 'camera_first_person',
  label: 'First Person Camera',
  description:
    'Câmera em primeira pessoa (decisão 28): olha com o mouse (clique na viewport captura o ponteiro; Esc libera) e fica nos olhos do nó-alvo. Sem alvo, só olha no lugar onde está. Não move o alvo: use "First Person Movement" no personagem. Só em nó Camera ativo.',
  category: 'Camera',
  allowedNodeTypes: ['Camera'],
  params: [
    { key: 'targetNodeId', label: 'Target', type: 'node', default: D.targetNodeId, emptyLabel: '(sem alvo)' },
    { key: 'targetSpace', label: 'Target Space', type: 'enum', default: D.targetSpace, options: ['world', 'local'] },
    { key: 'eyeHeight', label: 'Eye Height (m)', type: 'number', default: D.eyeHeight },
    { key: 'offset', label: 'Offset (espaço do alvo)', type: 'vector3', default: D.offset },
    { key: 'mouseSensitivity', label: 'Mouse Sensitivity (°/px)', type: 'number', default: D.mouseSensitivity },
    { key: 'maxVerticalAngle', label: 'Max Vertical Angle (°)', type: 'number', default: D.maxVerticalAngle },
    { key: 'fov', label: 'Field of View (°)', type: 'number', default: D.fov },
    { key: 'smoothing', label: 'Follow Smoothing (1/s, 0 = rígido)', type: 'number', default: D.smoothing },
    { key: 'hideTarget', label: 'Hide Target Body', type: 'boolean', default: D.hideTarget },
    { key: 'pointerLock', label: 'Capture Pointer', type: 'boolean', default: D.pointerLock },
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `First Person Camera (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'camera_first_person',
    enabled: true,
    properties: { ...D, offset: { ...D.offset } },
    rules: [],
  }),
});
