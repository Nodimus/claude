import type { BehaviorRuntime, BehaviorRuntimeModule } from '../../types';
import { clamp, smoothingFactor, type V3 } from '../../../runtime/controllers/controllerMath';
import { firstPersonRigPose, readCameraFirstPersonParams, stepFirstPersonLook, type LookAngles } from '../../../runtime/cameraRig';
import { pointerLookActive } from '../../controllerRuntime';
import { cameraNodeActive, hideTarget, nodePosition, resolveCameraTarget, restoreTarget, targetPoseOf, type HiddenTarget, type TargetWarning } from '../../cameraRuntime';
import { tNow } from '../../../core/i18n';

/**
 * First Person Camera (AIS-47c, decisão 28): dono do OLHAR (yaw/pitch), do PointerLock e da pose publicada. Com alvo, os olhos ficam
 * em `eyeHeight` + `offset` (espaço do alvo, girado pelo yaw dele) acima da origem do alvo, que pode ficar escondido SÓ no Play.
 * Sem alvo, só olha no lugar do próprio nó. NÃO move o alvo e não lê teclas de movimento. Publica no `onLateUpdate` (depois da
 * física) com `view` = o olhar, que o Behavior de movimento lê no quadro seguinte (`ctx.view`). Só publica com o nó `active`.
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let look: LookAngles = { yaw: 0, pitch: 0 };
    let eye: V3 | null = null;
    let hidden: HiddenTarget | null = null;
    const warning: TargetWarning = { warned: null };
    const release = () => {
      restoreTarget(hidden);
      hidden = null;
    };
    return {
      attach(ctx) {
        // recomeça da pose AUTORAL da câmera (Restart Behavior zera o olhar)
        const p = readCameraFirstPersonParams(ctx.state.properties);
        look = { yaw: ctx.initialTransform.rotation[1], pitch: clamp(ctx.initialTransform.rotation[0], -p.maxVerticalAngle, p.maxVerticalAngle) };
        eye = null;
        warning.warned = null;
      },
      onPlayStart(ctx) {
        if (readCameraFirstPersonParams(ctx.state.properties).pointerLock && cameraNodeActive(ctx)) ctx.log('info', tNow('runtimeMsgCore.firstPersonCameraClickThe'));
      },
      onLateUpdate(ctx, dt) {
        if (!cameraNodeActive(ctx)) {
          release();
          ctx.setGameCamera(null);
          return;
        }
        const p = readCameraFirstPersonParams(ctx.state.properties);
        const target = resolveCameraTarget(ctx, p.targetNodeId, warning);
        if (p.hideTarget && target && !hidden) hidden = hideTarget(target);
        else if ((!p.hideTarget || !target) && hidden) release();

        if (pointerLookActive()) {
          const pointer = ctx.input.pointer;
          look = stepFirstPersonLook(look, { rotateSpeed: p.mouseSensitivity, maxVerticalAngle: p.maxVerticalAngle }, pointer?.dx ?? 0, pointer?.dy ?? 0);
        }

        let anchor: V3;
        let eyeHeight: number;
        if (target) {
          const pose = targetPoseOf(target, p.targetSpace);
          const base = pose.position;
          const yaw = (pose.rotation[1] * Math.PI) / 180;
          const c = Math.cos(yaw);
          const s = Math.sin(yaw);
          // offset no espaço do alvo (girado em Y pelo yaw dele)
          anchor = { x: base.x + p.offset.x * c + p.offset.z * s, y: base.y + p.offset.y, z: base.z - p.offset.x * s + p.offset.z * c };
          eyeHeight = p.eyeHeight;
        } else {
          anchor = nodePosition(ctx.node);
          eyeHeight = 0;
        }
        const pose = firstPersonRigPose(anchor, look, { eyeHeight });
        const k = p.smoothing > 0 && eye ? smoothingFactor(p.smoothing, dt) : 1;
        eye = eye ? { x: eye.x + (pose.position.x - eye.x) * k, y: eye.y + (pose.position.y - eye.y) * k, z: eye.z + (pose.position.z - eye.z) * k } : pose.position;
        ctx.setGameCamera({ position: eye, quaternion: pose.quaternion, fov: p.fov, pointerLock: p.pointerLock, view: { yaw: look.yaw, pitch: look.pitch }, kind: 'camera' });
      },
      onPlayStop() {
        release();
      },
      detach(ctx) {
        release();
        ctx.setGameCamera(null);
      },
    };
  },
};
export default mod;
