import { defineBehavior, newLogicId } from '../../types';
import { CAMERA_THIRD_PERSON_DEFAULTS as D } from '../../../runtime/cameraRig/params';

export default defineBehavior({
  id: 'camera_third_person',
  label: 'Third Person Camera',
  description:
    'Câmera de perseguição/órbita (decisão 28): segue o nó-alvo com suavização elástica e orbita com a ação de órbita (botão direito + arrastar por padrão). Sem alvo, orbita em torno da própria posição. Serve para personagens, veículos e aeronaves ("Follow Target Rotation"). Não move o alvo. Só em nó Camera ativo.',
  category: 'Camera',
  allowedNodeTypes: ['Camera'],
  params: [
    { key: 'targetNodeId', label: 'Target', type: 'node', default: D.targetNodeId, emptyLabel: '(sem alvo)' },
    { key: 'targetSpace', label: 'Target Space', type: 'enum', default: D.targetSpace, options: ['world', 'local'] },
    { key: 'distance', label: 'Distance (m)', type: 'number', default: D.distance },
    { key: 'targetHeight', label: 'Target Height (m)', type: 'number', default: D.targetHeight },
    { key: 'followSmoothingSpeed', label: 'Follow Smoothing (1/s)', type: 'number', default: D.followSmoothingSpeed },
    { key: 'mouseSensitivity', label: 'Mouse Sensitivity (°/px)', type: 'number', default: D.mouseSensitivity },
    { key: 'startPitch', label: 'Start Pitch (°, 0 = de lado, 85 = de cima)', type: 'number', default: D.startPitch },
    { key: 'minPitch', label: 'Min Pitch (°)', type: 'number', default: D.minPitch },
    { key: 'maxPitch', label: 'Max Pitch (°)', type: 'number', default: D.maxPitch },
    { key: 'fov', label: 'Field of View (°)', type: 'number', default: D.fov },
    { key: 'orbitAction', label: 'Orbit Action (Input Map)', type: 'enum', default: D.orbitAction, options: ['AltFire', 'Fire'], optionsFrom: 'inputActions' },
    { key: 'followTargetRotation', label: 'Follow Target Rotation', type: 'enum', default: D.followTargetRotation, options: ['none', 'yaw', 'full'] },
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Third Person Camera (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'camera_third_person',
    enabled: true,
    properties: { ...D },
    rules: [],
  }),
});
