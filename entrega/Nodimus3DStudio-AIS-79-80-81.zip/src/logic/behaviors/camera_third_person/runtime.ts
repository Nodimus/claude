import { tNow } from '../../../core/i18n';
import type { BehaviorRuntime, BehaviorRuntimeModule } from '../../types';
import type { V3 } from '../../../runtime/controllers/controllerMath';
import { chaseRigPose, effectiveOrbit, readCameraThirdPersonParams, stepChaseOrbit, type ChaseOrbitState } from '../../../runtime/cameraRig';
import { cameraNodeActive, resolveCameraTarget, targetPoseOf, type TargetWarning } from '../../cameraRuntime';

/**
 * Third Person Camera (AIS-47c, decisão 28): dono da ÓRBITA e da pose de perseguição. Segue o alvo (qualquer nó: personagem,
 * veículo, aeronave) com suavização elástica; sem alvo, orbita em torno da própria posição autoral (pivô fixo). A órbita usa a
 * AÇÃO lógica `orbitAction` do Input Map (nunca código de tecla). `followTargetRotation` faz a órbita acompanhar a rotação do alvo
 * (`yaw`; `full` = yaw + pitch, sem roll). NÃO move o alvo. Publica `view` = a órbita efetiva (o movimento a lê no quadro seguinte).
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let orbit: ChaseOrbitState = { orbitYaw: 0, orbitPitch: 20 };
    let camera: V3 | null = null;
    let pivot: V3 = { x: 0, y: 0, z: 0 };
    const warning: TargetWarning = { warned: null };
    return {
      attach(ctx) {
        // recomeça da pose AUTORAL: a câmera nasce atrás de onde o nó `Camera` está virado; o pivô sem alvo é a posição autoral
        const start = readCameraThirdPersonParams(ctx.state.properties);
        orbit = { orbitYaw: ctx.initialTransform.rotation[1], orbitPitch: Math.min(start.maxPitch, Math.max(start.minPitch, start.startPitch)) };
        camera = null;
        const [x, y, z] = ctx.initialTransform.position;
        pivot = { x, y, z };
        warning.warned = null;
      },
      onPlayStart(ctx) {
        if (cameraNodeActive(ctx)) ctx.log('info', tNow('runtimeMsgCore.thirdPersonCameraRightButton'));
      },
      onLateUpdate(ctx, dt) {
        if (!cameraNodeActive(ctx)) {
          ctx.setGameCamera(null);
          return;
        }
        const p = readCameraThirdPersonParams(ctx.state.properties);
        const target = resolveCameraTarget(ctx, p.targetNodeId, warning);
        const pointer = ctx.input.pointer;
        orbit = stepChaseOrbit(orbit, { rotateSpeed: p.mouseSensitivity, minPitch: p.minPitch, maxPitch: p.maxPitch }, pointer?.dx ?? 0, pointer?.dy ?? 0, ctx.input.isActionPressed(p.orbitAction));
        const targetPose = target ? targetPoseOf(target, p.targetSpace) : null;
        const anchor = targetPose ? targetPose.position : pivot;
        const eff = targetPose ? effectiveOrbit(orbit.orbitYaw, orbit.orbitPitch, p.followTargetRotation, targetPose.rotation) : orbit;
        const rig = chaseRigPose(anchor, eff, camera, { distance: p.distance, targetHeight: p.targetHeight, followSmoothingSpeed: p.followSmoothingSpeed }, dt);
        camera = rig.camera;
        ctx.setGameCamera({ position: rig.position, quaternion: rig.quaternion, fov: p.fov, pointerLock: false, view: { yaw: eff.orbitYaw, pitch: -eff.orbitPitch /* contrato do ViewBasis: pitch > 0 olha para CIMA; a órbita com a câmera acima do alvo olha para baixo */ }, kind: 'camera' });
      },
      detach(ctx) {
        ctx.setGameCamera(null);
      },
    };
  },
};
export default mod;
