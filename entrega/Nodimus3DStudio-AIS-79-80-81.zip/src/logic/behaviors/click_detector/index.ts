import { defineBehavior, newLogicId } from '../../types';

export default defineBehavior({
  id: 'click_detector',
  label: 'On Click',
  description: 'Executa ações quando o objeto é clicado.',
  category: 'Interaction',
  params: [],
  preset: { label: 'Click Event Trigger', order: 3, wide: true },
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `On Click (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'click_detector',
    enabled: true,
    properties: {},
    rules: [
      {
        id: newLogicId('r_', 5),
        eventType: 'on_click',
        parameters: {},
        conditions: [{ id: 'c1', type: 'always', parameters: {} }],
        actions: [
          { id: newLogicId('act_', 5), type: 'print_log', parameters: { text: `Clicked ${targetNodeId}!` } },
        ],
      },
    ],
  }),
});
