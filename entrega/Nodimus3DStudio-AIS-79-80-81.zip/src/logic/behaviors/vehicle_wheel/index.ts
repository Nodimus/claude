import { defineBehavior, newLogicId } from '../../types';
import { drivePreset } from '../../../core/vehicles/vehiclePresets';

const D = drivePreset('arcade').values;

export default defineBehavior({
  id: 'vehicle_wheel',
  label: 'Vehicle Wheel',
  description:
    'Roda de um veículo: anexe a uma malha FILHA de um nó com "Vehicle Controller". A posição é a do próprio nó (gizmo e campos do Inspector); não tem corpo físico. O giro e o esterçamento visuais acontecem só no Play. Sem "Suspension Override" a roda herda a suspensão do veículo.',
  category: 'Movement',
  requires: ['requiresPhysics'],
  allowedNodeTypes: ['MeshInstance', 'Spatial'],
  params: [
    { key: 'radius', label: 'Radius (m)', type: 'number', default: 0.35 },
    { key: 'width', label: 'Width (m)', type: 'number', default: 0.25 },
    { key: 'isSteering', label: 'Is Steering', type: 'boolean', default: false },
    { key: 'isMotorized', label: 'Is Motorized', type: 'boolean', default: false },
    { key: 'suspensionOverride', label: 'Suspension Override', type: 'boolean', default: false },
    { key: 'suspensionStiffness', label: 'Suspension Stiffness', type: 'number', default: D.suspensionStiffness, visibleWhen: { key: 'suspensionOverride', equals: true } },
    { key: 'suspensionDamping', label: 'Suspension Damping', type: 'number', default: D.suspensionDamping, visibleWhen: { key: 'suspensionOverride', equals: true } },
    { key: 'suspensionTravel', label: 'Suspension Travel (m)', type: 'number', default: D.suspensionTravel, visibleWhen: { key: 'suspensionOverride', equals: true } },
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Vehicle Wheel (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'vehicle_wheel',
    enabled: true,
    properties: {
      radius: 0.35,
      width: 0.25,
      isSteering: false,
      isMotorized: false,
      suspensionOverride: false,
      suspensionStiffness: D.suspensionStiffness,
      suspensionDamping: D.suspensionDamping,
      suspensionTravel: D.suspensionTravel,
    },
    rules: [],
  }),
});
