import type { BehaviorRuntime, BehaviorRuntimeModule } from '../../types';
import { readDriveParams, wheelSpinFromBridge } from '../../../runtime/vehicle/vehicleDrive';
import { wheelRotationDegrees } from '../../../runtime/vehicle/wheelPose';
import { tNow } from '../../../core/i18n';

/**
 * Vehicle Wheel (AIS-73): a roda é um nó filho SEM corpo físico; quem a registra e comanda é o `vehicle_controller` do pai. Este executor
 * só APRESENTA: sobe/desce com a suspensão, gira com o veículo e esterça com as rodas dianteiras, escrevendo no transform da INSTÂNCIA
 * VIVA (runtime). Nunca grava no authoring, não usa Rapier e não relê a pose para escrever (sempre parte da pose autoral). Sem pai com
 * `vehicle_controller`, avisa uma vez.
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let warned = false;
    return {
      attach() {
        warned = false;
      },
      onLateUpdate(ctx) {
        const parent = ctx.node.parent;
        const vehicle = parent ? ctx.engine.nodes.behaviorProperties(parent.persistentNodeId, 'vehicle_controller') : undefined;
        if (!parent || !vehicle) {
          if (!warned && ctx.sceneTime >= 1) {
            warned = true;
            ctx.log('warn', tNow('runtimeMsgCore.vehicleWheelTheParentNode'));
          }
          return;
        }
        const bridge = ctx.physics;
        const state = bridge?.vehicleWheelState(parent.persistentNodeId, ctx.node.persistentNodeId);
        if (!bridge || !state) return; // ainda não registrada pelo controlador (o Rapier carrega em segundo plano)

        const init = ctx.initialTransform;
        const p = readDriveParams(vehicle);
        const rest = ctx.state.properties.suspensionOverride === true ? Math.max(0.02, Number(ctx.state.properties.suspensionTravel) || p.suspensionTravel) : p.suspensionTravel;
        const sy = Math.abs(parent.transform.scale[1]) > 1e-6 ? parent.transform.scale[1] : 1;
        const [x, y, z] = init.position;
        ctx.node.transform.position = [x, y + (rest - state.suspensionLength) / sy, z];

        ctx.node.transform.rotation = wheelRotationDegrees(init.rotation, state.steering, wheelSpinFromBridge(state.rotation));
        ctx.applyTransform(ctx.node);
      },
    };
  },
};
export default mod;
