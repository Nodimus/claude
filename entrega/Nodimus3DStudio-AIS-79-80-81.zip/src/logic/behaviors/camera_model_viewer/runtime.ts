import type { BehaviorRuntime, BehaviorRuntimeModule } from '../../types';
import type { V3 } from '../../../runtime/controllers/controllerMath';
import { chaseRigPose, readCameraModelViewerParams, stepChaseOrbit, type ChaseOrbitState } from '../../../runtime/cameraRig';
import { cameraNodeActive, resolveCameraTarget, targetPoseOf, type TargetWarning } from '../../cameraRuntime';

/**
 * Model Viewer Camera (AIS-47d, decisão 28): órbita de inspeção à distância fixa (`radius`) em torno do alvo (ou do pivô autoral,
 * sem alvo), arrastando com a AÇÃO `orbitAction`. Reusa o `chaseRig` (sem suavização: a câmera cola na órbita) e NUNCA altera o
 * modelo. `verticalMovementAllowed: false` trava a elevação inicial. Só publica com o nó `active`.
 */
const INITIAL_PITCH = 20;

const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let orbit: ChaseOrbitState = { orbitYaw: 0, orbitPitch: INITIAL_PITCH };
    let pivot: V3 = { x: 0, y: 0, z: 0 };
    const warning: TargetWarning = { warned: null };
    return {
      attach(ctx) {
        orbit = { orbitYaw: ctx.initialTransform.rotation[1], orbitPitch: INITIAL_PITCH };
        const [x, y, z] = ctx.initialTransform.position;
        pivot = { x, y, z };
        warning.warned = null;
      },
      onLateUpdate(ctx, dt) {
        if (!cameraNodeActive(ctx)) {
          ctx.setGameCamera(null);
          return;
        }
        const p = readCameraModelViewerParams(ctx.state.properties);
        const target = resolveCameraTarget(ctx, p.targetNodeId, warning);
        const pointer = ctx.input.pointer;
        const limits = p.verticalMovementAllowed ? { minPitch: -89, maxPitch: 89 } : { minPitch: INITIAL_PITCH, maxPitch: INITIAL_PITCH };
        orbit = stepChaseOrbit(orbit, { rotateSpeed: p.rotateSpeed, ...limits }, pointer?.dx ?? 0, pointer?.dy ?? 0, ctx.input.isActionPressed(p.orbitAction));
        const anchor = target ? targetPoseOf(target, p.targetSpace).position : pivot;
        const rig = chaseRigPose(anchor, orbit, null, { distance: p.radius, targetHeight: 0, followSmoothingSpeed: 0 }, dt);
        ctx.setGameCamera({ position: rig.position, quaternion: rig.quaternion, fov: p.fov, pointerLock: false, view: { yaw: orbit.orbitYaw, pitch: -orbit.orbitPitch }, kind: 'camera' });
      },
      detach(ctx) {
        ctx.setGameCamera(null);
      },
    };
  },
};
export default mod;
