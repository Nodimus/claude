import { defineBehavior, newLogicId } from '../../types';
import { CAMERA_MODEL_VIEWER_DEFAULTS as D } from '../../../runtime/cameraRig/params';

export default defineBehavior({
  id: 'camera_model_viewer',
  label: 'Model Viewer Camera',
  description:
    'Câmera de inspeção (decisão 28): orbita um objeto à distância fixa (Radius) arrastando com a ação de órbita (botão esquerdo por padrão). Sem alvo, orbita a própria posição. Nunca altera o modelo. Só em nó Camera ativo.',
  category: 'Camera',
  allowedNodeTypes: ['Camera'],
  params: [
    { key: 'targetNodeId', label: 'Target', type: 'node', default: D.targetNodeId, emptyLabel: '(sem alvo)' },
    { key: 'targetSpace', label: 'Target Space', type: 'enum', default: D.targetSpace, options: ['world', 'local'] },
    { key: 'radius', label: 'Radius (m)', type: 'number', default: D.radius },
    { key: 'rotateSpeed', label: 'Rotate Speed (°/px)', type: 'number', default: D.rotateSpeed },
    { key: 'verticalMovementAllowed', label: 'Vertical Movement Allowed', type: 'boolean', default: D.verticalMovementAllowed },
    { key: 'fov', label: 'Field of View (°)', type: 'number', default: D.fov },
    { key: 'orbitAction', label: 'Orbit Action (Input Map)', type: 'enum', default: D.orbitAction, options: ['Fire', 'AltFire'], optionsFrom: 'inputActions' },
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Model Viewer Camera (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'camera_model_viewer',
    enabled: true,
    properties: { ...D },
    rules: [],
  }),
});
