import { defineBehavior, newLogicId } from '../../types';
import { controllerProperties, drivePreset } from '../../../core/vehicles/vehiclePresets';

const D = drivePreset('arcade').values;

export default defineBehavior({
  id: 'vehicle_controller',
  label: 'Vehicle Controller',
  description:
    'Veículo terrestre ARCADE (não é simulação real): suspensão por raycast, uma por roda filha com "Vehicle Wheel"; motor, freio e esterçamento por Accelerate/Brake/SteerLeft/SteerRight/Handbrake do Input Map (preset "Vehicle"). Exige Colisão "Físico" (dynamic) no nó. NÃO controla câmera: adicione um nó Camera com "Third Person Camera" apontando para este nó. Os campos gerais são editados no botão "Configure Vehicle…".',
  category: 'Movement',
  requires: ['requiresPhysics'],
  presetPhysics: { bodyMode: 'dynamic' },
  /** Campos gerais só pelo `VehicleDialog` (o card mostra o resumo); `mass` também vai ao bloco de Colisão (autoridade em jogo). */
  configure: {
    dialog: 'vehicle',
    label: 'Configure Vehicle…',
    summaryKeys: ['enginePower', 'brakeForce', 'steerAngle', 'maxSpeed', 'mass', 'suspensionStiffness', 'suspensionDamping', 'suspensionTravel', 'groundAlignmentSpeed'],
  },
  params: [
    { key: 'enginePower', label: 'Engine Power (N)', type: 'number', default: D.enginePower },
    { key: 'brakeForce', label: 'Brake Force (N)', type: 'number', default: D.brakeForce },
    { key: 'steerAngle', label: 'Steer Angle (°)', type: 'number', default: D.steerAngle },
    { key: 'maxSpeed', label: 'Max Speed (m/s)', type: 'number', default: D.maxSpeed },
    { key: 'mass', label: 'Mass (kg)', type: 'number', default: D.mass },
    { key: 'suspensionStiffness', label: 'Suspension Stiffness', type: 'number', default: D.suspensionStiffness },
    { key: 'suspensionDamping', label: 'Suspension Damping', type: 'number', default: D.suspensionDamping },
    { key: 'suspensionTravel', label: 'Suspension Travel (m)', type: 'number', default: D.suspensionTravel },
    { key: 'groundAlignmentSpeed', label: 'Ground Alignment Speed (1/s)', type: 'number', default: D.groundAlignmentSpeed },
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Vehicle Controller (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'vehicle_controller',
    enabled: true,
    properties: controllerProperties(D),
    rules: [],
  }),
});
