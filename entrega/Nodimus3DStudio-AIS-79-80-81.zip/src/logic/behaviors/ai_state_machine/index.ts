import { defineBehavior, newLogicId } from '../../types';
import { AI_DEFAULTS as D } from '../../../runtime/ai/params';
import { AI_STATES } from '../../../runtime/ai/types';

/**
 * AIS-71: decisão e movimento do NPC — percepção do alvo, 5 estados FIXOS (Idle, Patrol, Chase, Attack, Flee; sem editor de estados) e
 * animação por estado. Os ganchos são Triggers das PRÓPRIAS regras (nascem vazias: o editor de regras não cria regras novas): uma regra
 * "On AI State Changed" por estado e "On AI Attack". Movimento só por `moveNodeToward` (AIS-72); consulta espacial só por `overlapSphere`.
 */
const rule = (eventType: string, parameters: Record<string, unknown> = {}) => ({
  id: newLogicId('rule_'),
  eventType,
  parameters,
  conditions: [{ id: newLogicId('c_'), type: 'always', parameters: {} }],
  actions: [],
});

export default defineBehavior({
  id: 'ai_state_machine',
  label: 'AI State Machine',
  description:
    'IA de NPC: percebe o alvo (Tags, raio), alterna Idle → Patrol → Chase → Attack → Flee por prioridade fixa e se move só pela física (corpo "character" ou "kinematic"; "dynamic" é incompatível). Patrulha: área aleatória, rota de Waypoints, ou Path. Os ganchos On AI State Changed / On AI Attack são regras deste Behavior. Exige Colisão ligada no nó.',
  category: 'AI',
  params: [
    { key: 'perceptionRadius', label: 'Perception Radius (m)', type: 'number', default: D.perceptionRadius },
    { key: 'loseRadius', label: 'Lose Radius (m)', type: 'number', default: D.loseRadius },
    { key: 'perceptionIntervalMs', label: 'Perception Interval (ms)', type: 'number', default: D.perceptionIntervalMs },
    { key: 'targetTags', label: 'Target Tags (a, b)', type: 'string', default: D.targetTags },
    { key: 'attackRange', label: 'Attack Range (m)', type: 'number', default: D.attackRange },
    { key: 'attackCooldownMs', label: 'Attack Cooldown (ms)', type: 'number', default: D.attackCooldownMs },
    { key: 'idleTimeMs', label: 'Idle Time (ms)', type: 'number', default: D.idleTimeMs },
    { key: 'fleeBelowHealth', label: 'Flee Below Health (0 = never)', type: 'number', default: D.fleeBelowHealth },
    { key: 'fleeDurationMs', label: 'Flee Duration (ms)', type: 'number', default: D.fleeDurationMs },
    { key: 'healthVariable', label: 'Health Variable (Local)', type: 'string', default: D.healthVariable, variable: true, variableScope: 'local' },
    { key: 'movementSpeed', label: 'Movement Speed (m/s)', type: 'number', default: D.movementSpeed },
    { key: 'canFly', label: 'Can Fly', type: 'boolean', default: D.canFly },
    { key: 'patrolSource', label: 'Patrol Source', type: 'enum', default: D.patrolSource, options: ['none', 'random_area', 'waypoints', 'path'] },
    { key: 'patrolRadius', label: 'Patrol Radius (m)', type: 'number', default: D.patrolRadius, visibleWhen: { key: 'patrolSource', equals: 'random_area' } },
    { key: 'patrolWaitMs', label: 'Patrol Wait (ms)', type: 'number', default: D.patrolWaitMs, visibleWhen: { key: 'patrolSource', equals: 'random_area' } },
    { key: 'patrolRoute', label: 'Patrol Route (container of Waypoints)', type: 'node', default: D.patrolRoute, emptyLabel: '(escolha a rota)', visibleWhen: { key: 'patrolSource', equals: 'waypoints' } },
    { key: 'patrolLoop', label: 'Patrol Loop', type: 'enum', default: D.patrolLoop, options: ['loop', 'pingpong'], visibleWhen: { key: 'patrolSource', equals: 'waypoints' } },
    { key: 'patrolPath', label: 'Patrol Path', type: 'node', default: D.patrolPath, emptyLabel: '(escolha um Path)', nodeTypes: ['Path'], visibleWhen: { key: 'patrolSource', equals: 'path' } },
    { key: 'idleAnimation', label: 'Idle Animation', type: 'enum', default: D.idleAnimation, optionsFrom: 'animations' },
    { key: 'walkAnimation', label: 'Walk Animation', type: 'enum', default: D.walkAnimation, optionsFrom: 'animations' },
    { key: 'attackAnimation', label: 'Attack Animation', type: 'enum', default: D.attackAnimation, optionsFrom: 'animations' },
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `AI State Machine (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'ai_state_machine',
    enabled: true,
    properties: { ...D },
    // os ganchos nascem como regras vazias: uma por estado + o ataque (o usuário só liga Actions a cada uma)
    rules: [...AI_STATES.map((state) => rule('on_ai_state_changed', { state })), rule('on_ai_attack')],
  }),
});
