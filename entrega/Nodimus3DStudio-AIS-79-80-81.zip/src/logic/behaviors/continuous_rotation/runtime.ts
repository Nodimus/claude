import type { BehaviorRuntimeModule } from '../../types';
import { spinDynamicBody, stopSpinningBody } from '../../../runtime/spinBody';

/**
 * Gira o nó dono em `rotationSpeed` graus/s no eixo `axis`. Estado (propriedades de trabalho) por instância.
 * Corpo DINÂMICO: a física é a dona da pose, então gira por velocidade angular pela `PhysicsBridge` (escrever no `transform` seria
 * desfeito no mesmo quadro); nos demais (sem corpo, `static`, `kinematic`) escreve no `transform`.
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create: () => {
    let spinning = false; // este Behavior zerou a velocidade angular de um corpo dinâmico ao sair? só se foi ele quem a ligou
    return {
      onUpdate(ctx, dt) {
        const p = ctx.state.properties;
        const speed = typeof p.rotationSpeed === 'number' ? p.rotationSpeed : 60;
        const axis = p.axis === 'x' ? 'x' : p.axis === 'z' ? 'z' : 'y';
        if (spinDynamicBody(ctx.physics, ctx.node.persistentNodeId, axis, speed)) {
          spinning = true;
          return;
        }
        const index = axis === 'x' ? 0 : axis === 'z' ? 2 : 1;
        const next: [number, number, number] = [...ctx.node.transform.rotation];
        next[index] += speed * dt;
        ctx.node.transform.rotation = next;
        ctx.applyTransform(ctx.node);
      },
      detach(ctx) {
        if (spinning) stopSpinningBody(ctx.physics, ctx.node.persistentNodeId);
        spinning = false;
      },
    };
  },
};
export default mod;
