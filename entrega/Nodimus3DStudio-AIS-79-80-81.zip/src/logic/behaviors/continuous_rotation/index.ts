import { defineBehavior, newLogicId } from '../../types';

export default defineBehavior({
  id: 'continuous_rotation',
  label: 'Continuous Rotation',
  description: 'Rotaciona o objeto continuamente.',
  category: 'Movement',
  params: [
    { key: 'rotationSpeed', label: 'Rotation Speed', type: 'number', default: 60 },
    { key: 'axis', label: 'Axis', type: 'enum', default: 'y', options: ['x', 'y', 'z'] },
  ],
  preset: { label: 'Spin Object', order: 2 },
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Continuous Rotation (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'continuous_rotation',
    enabled: true,
    properties: { rotationSpeed: 60, axis: 'y' },
    rules: [
      {
        id: newLogicId('r_', 5),
        eventType: 'on_update',
        parameters: {},
        conditions: [{ id: 'c1', type: 'always', parameters: {} }],
        actions: [
          { id: newLogicId('act_', 5), type: 'rotate_by', parameters: { degrees: 1 } },
        ],
      },
    ],
  }),
});
