import { defineBehavior, newLogicId } from '../../types';

export default defineBehavior({
  id: 'timer_trigger',
  label: 'Timer Trigger',
  description: 'Executa ações a cada intervalo de tempo.',
  category: 'Interaction',
  // o intervalo vive na regra (Trigger `on_timeout`), editável na própria cadeia; sem parâmetro duplicado no Behavior
  params: [],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Timer Trigger (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'timer_trigger',
    enabled: true,
    properties: {},
    rules: [
      {
        id: newLogicId('r_', 5),
        eventType: 'on_timeout',
        parameters: { interval: 1, repeat: true },
        conditions: [{ id: 'c1', type: 'always', parameters: {} }],
        actions: [{ id: newLogicId('act_', 5), type: 'print_log', parameters: { text: `Timer tick (${targetNodeId})` } }],
      },
    ],
  }),
});
