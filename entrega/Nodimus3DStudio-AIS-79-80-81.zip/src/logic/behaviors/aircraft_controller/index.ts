import { defineBehavior, newLogicId } from '../../types';
import { aircraftControllerProperties, aircraftPreset } from '../../../core/vehicles/vehiclePresets';

const D = aircraftPreset('light').values;

export default defineBehavior({
  id: 'aircraft_controller',
  label: 'Aircraft Controller',
  description:
    'Aeronave ARCADE (não é aerodinâmica real): empuxo, arrasto, sustentação proporcional à velocidade (cheia a partir de "Min Speed To Fly"; abaixo dela a aeronave perde sustentação e cai) e taxas de rotação nos 3 eixos, só pela PhysicsBridge. Lê Throttle, PitchUp/PitchDown (W/↑ sobe, S/↓ desce), RollLeft/RollRight e YawLeft/YawRight do Input Map (preset "Flight"). Sem comando num eixo, a aeronave se NIVELA sozinha (asas niveladas, nariz no horizonte); em estol não nivela e o nariz cai até recuperar velocidade. Exige Colisão "Físico" (dynamic) no nó. NÃO controla câmera: adicione um nó Camera com "Third Person Camera" apontando para este nó. Os campos gerais são editados no botão "Configure Aircraft…".',
  category: 'Movement',
  requires: ['requiresPhysics'],
  presetPhysics: { bodyMode: 'dynamic' },
  /** Campos gerais só pelo `VehicleDialog` (o card mostra o resumo); `mass` também vai ao bloco de Colisão (autoridade em jogo). */
  configure: { dialog: 'vehicle', label: 'Configure Aircraft…', summaryKeys: ['thrust', 'lift', 'drag', 'pitchSpeed', 'yawSpeed', 'rollSpeed', 'minSpeedToFly', 'mass'] },
  params: [
    { key: 'thrust', label: 'Thrust (N)', type: 'number', default: D.thrust },
    { key: 'lift', label: 'Lift (× peso)', type: 'number', default: D.lift },
    { key: 'drag', label: 'Drag (N·s²/m²)', type: 'number', default: D.drag },
    { key: 'pitchSpeed', label: 'Pitch Speed (°/s)', type: 'number', default: D.pitchSpeed },
    { key: 'yawSpeed', label: 'Yaw Speed (°/s)', type: 'number', default: D.yawSpeed },
    { key: 'rollSpeed', label: 'Roll Speed (°/s)', type: 'number', default: D.rollSpeed },
    { key: 'minSpeedToFly', label: 'Min Speed To Fly (m/s)', type: 'number', default: D.minSpeedToFly },
    { key: 'mass', label: 'Mass (kg)', type: 'number', default: D.mass },
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Aircraft Controller (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'aircraft_controller',
    enabled: true,
    properties: aircraftControllerProperties(D),
    rules: [],
  }),
});
