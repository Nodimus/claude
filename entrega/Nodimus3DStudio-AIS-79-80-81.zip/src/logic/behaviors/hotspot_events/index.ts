import { defineBehavior, newLogicId } from '../../types';

/**
 * AIS-70: eventos de um Hotspot. As 3 regras nascem prontas (Enter, Exit, Click) com um `print_log` de exemplo: o usuário troca/acrescenta
 * Actions em cada uma (o editor de regras não cria regras novas). Só em nó `Hotspot`.
 */
const rule = (eventType: string, text: string) => ({
  id: newLogicId('r_', 5),
  eventType,
  parameters: {},
  conditions: [{ id: newLogicId('c_', 5), type: 'always', parameters: {} }],
  actions: [{ id: newLogicId('act_', 5), type: 'print_log', parameters: { text } }],
});

export default defineBehavior({
  id: 'hotspot_events',
  label: 'Hotspot Events',
  description: 'Executa Actions quando um corpo entra/sai do volume do Hotspot e quando ele é clicado. Só em nó Hotspot.',
  category: 'Interaction',
  allowedNodeTypes: ['Hotspot'],
  params: [],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Hotspot Events (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'hotspot_events',
    enabled: true,
    properties: {},
    rules: [rule('on_hotspot_enter', `Entrou em ${targetNodeId}`), rule('on_hotspot_exit', `Saiu de ${targetNodeId}`), rule('on_hotspot_click', `Clicou em ${targetNodeId}`)],
  }),
});
