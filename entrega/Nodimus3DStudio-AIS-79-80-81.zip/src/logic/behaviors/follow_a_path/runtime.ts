import { tNow } from '../../../core/i18n';
import type { BehaviorRuntimeContext, BehaviorRuntimeModule } from '../../types';
import { pathProblem, readPath } from '../../../core/path/pathData';
import { advancePathProgress, initialPathProgress, type PathProgress } from '../../../core/path/pathProgress';
import { moveNodeToward } from '../../../runtime/motion/moveToward';
import { buildWorldPathCurve, type WorldPathCurve } from '../../../runtime/motion/worldPath';
import { readFollowPathParams } from './params';

/**
 * Follow a Path (AIS-72). O executor só decide ONDE o nó deve estar (progresso ao longo da spline); COMO ele chega lá (character,
 * kinematic, sem corpo, ou incompatível) é `moveNodeToward` — este arquivo não tem lógica de movimento por corpo.
 *
 * Fases (estado da instância na RuntimeSession; os waypoints autorais nunca são tocados):
 *  - `approach`: vai até o ponto inicial da spline na velocidade configurada (o nó pode começar longe do caminho);
 *  - `follow`: o progresso avança `speed·dt` por quadro e o nó acompanha o ponto correspondente;
 *  - `finished`: `once` chegou ao último ponto;
 *  - `invalid`: referência/configuração inválida — diagnóstico emitido uma vez e o Behavior não se move.
 */

type Phase = 'approach' | 'follow' | 'finished' | 'invalid';

/** Folga de velocidade ao acompanhar o ponto-alvo: absorve o erro de ponto flutuante (o alvo anda `speed·dt` por quadro). */
const CATCH_UP = 1.25;

const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create: () => {
    let phase: Phase = 'approach';
    let progress: PathProgress = initialPathProgress();
    let cached: WorldPathCurve | null = null;
    let reported = false;

    const fail = (ctx: BehaviorRuntimeContext, code: string, message: string) => {
      phase = 'invalid';
      if (reported) return;
      reported = true;
      ctx.log('error', message, { code });
    };

    /** Spline em coordenadas MUNDIAIS (a curva Catmull-Rom é invariante por transformação afim: transformar os pontos basta). */
    const worldCurve = (ctx: BehaviorRuntimeContext, pathId: string): WorldPathCurve | null => {
      const path = ctx.getNode(pathId);
      if (!path) {
        fail(ctx, 'follow_a_path.path_missing', pathId ? tNow('runtimeMsgCore.thePathDoesNotExist', { pathId }) : tNow('runtimeMsgCore.noPathChosenChooseA'));
        return null;
      }
      if (path.type !== 'Path') {
        fail(ctx, 'follow_a_path.not_a_path', tNow('runtimeMsgCore.isANodeNotA', { name: path.name, type: path.type }));
        return null;
      }
      const config = readPath(path.properties);
      const problem = pathProblem(config);
      if (problem) {
        fail(ctx, 'follow_a_path.path_too_short', `"${path.name}": ${problem}`);
        return null;
      }
      const built = buildWorldPathCurve(path, config); // spline em coordenadas MUNDIAIS, como dado (o Three fica no runtime)
      if (!built) return null;
      if (cached?.key === built.key) return cached;
      if (!(built.length > 1e-6)) {
        // todos os waypoints no mesmo ponto: não há por onde andar — diagnóstico, nunca "seguir" parado em silêncio
        fail(ctx, 'follow_a_path.path_too_short', tNow('runtimeMsgCore.allWaypointsAreAtThe', { name: path.name }));
        return null;
      }
      cached = built;
      return cached;
    };

    const reset = () => {
      phase = 'approach';
      progress = initialPathProgress();
      cached = null;
      reported = false;
    };

    return {
      attach: reset,
      onPlayStart: reset,
      onUpdate(ctx, dt) {
        if (phase === 'finished') return;
        const params = readFollowPathParams(ctx.state.properties);
        if (!(params.speed > 0)) {
          fail(ctx, 'follow_a_path.invalid_speed', tNow('runtimeMsgCore.speedMustBeGreaterThan', { speed: params.speed }));
          return;
        }
        const path = worldCurve(ctx, params.pathId);
        if (!path) return;
        if (phase === 'invalid') {
          phase = 'approach'; // a referência voltou a ser válida (Path corrigido durante o jogo)
          reported = false;
        }
        const id = ctx.node.persistentNodeId;
        const at = (s: number) => path.pointAt(s);

        if (phase === 'approach') {
          const result = moveNodeToward(ctx, id, at(0), params.speed, dt);
          if (result.status === 'incompatible') return fail(ctx, result.code!, result.message!);
          if (result.status === 'arrived') {
            phase = 'follow';
            progress = initialPathProgress();
          }
          return;
        }

        const before = progress;
        progress = advancePathProgress(progress, params.speed * dt, path.length, params.loopMode);
        if (params.loopMode === 'loop' && !path.closed && progress.s < before.s) {
          phase = 'approach'; // fim do caminho aberto: volta ao início e recomeça
          return;
        }
        const result = moveNodeToward(ctx, id, at(progress.s), params.speed * CATCH_UP, dt);
        if (result.status === 'incompatible') return fail(ctx, result.code!, result.message!);
        if (progress.done && result.status === 'arrived') phase = 'finished';
      },
    };
  },
};
export default mod;
