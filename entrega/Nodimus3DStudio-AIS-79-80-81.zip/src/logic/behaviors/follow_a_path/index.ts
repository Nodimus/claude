import { defineBehavior, newLogicId } from '../../types';
import { FOLLOW_PATH_DEFAULTS as D } from './params';

/**
 * AIS-72: o nó segue, na ordem, os waypoints de um nó `Path` da mesma cena (spline Catmull-Rom), em unidades/s. Sem regras de preset: o
 * executor por propriedades (`runtime.ts`) é o dono. Qualquer GameNode; o movimento por tipo de corpo é `moveNodeToward`.
 */
export default defineBehavior({
  id: 'follow_a_path',
  label: 'Follow a Path',
  description: 'Move o objeto ao longo de um nó Path da cena (spline pelos waypoints), com velocidade e modo de término: Once (para no fim), Loop (volta ao início) ou Ping-pong (inverte nas pontas). Funciona com corpo "character", "kinematic" ou sem colisão; corpo dinâmico é incompatível.',
  category: 'Movement',
  params: [
    { key: 'pathId', label: 'Path', type: 'node', default: D.pathId, emptyLabel: '(escolha um Path)', nodeTypes: ['Path'], required: true },
    { key: 'speed', label: 'Speed (m/s)', type: 'number', default: D.speed },
    { key: 'loopMode', label: 'Loop Mode', type: 'enum', default: D.loopMode, options: ['once', 'loop', 'pingpong'] },
  ],
  preset: { label: 'Follow a Path', order: 7 },
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Follow a Path (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'follow_a_path',
    enabled: true,
    properties: { ...D },
    rules: [],
  }),
});
