import { readLoopMode, type PathLoopMode } from '../../../core/path/pathProgress';

/** AIS-72 — parâmetros do Behavior `follow_a_path` (um só lugar: definição, executor e testes leem daqui). */
export interface FollowPathParams {
  /** ID estável (`GameNode.id`) do nó `Path` da mesma cena; vazio = não configurado. */
  pathId: string;
  /** Unidades por segundo (> 0). */
  speed: number;
  loopMode: PathLoopMode;
}

export const FOLLOW_PATH_DEFAULTS: FollowPathParams = { pathId: '', speed: 2, loopMode: 'loop' };

export function readFollowPathParams(raw: Record<string, any> | undefined): FollowPathParams {
  const speed = raw?.speed;
  return {
    pathId: typeof raw?.pathId === 'string' ? raw.pathId : FOLLOW_PATH_DEFAULTS.pathId,
    speed: typeof speed === 'number' && Number.isFinite(speed) ? speed : FOLLOW_PATH_DEFAULTS.speed,
    loopMode: raw?.loopMode === undefined ? FOLLOW_PATH_DEFAULTS.loopMode : readLoopMode(raw.loopMode),
  };
}
