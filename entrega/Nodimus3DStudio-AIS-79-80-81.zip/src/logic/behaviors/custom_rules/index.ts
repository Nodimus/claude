import { defineBehavior, newLogicId } from '../../types';

export default defineBehavior({
  id: 'custom_rules',
  label: 'Custom Rules',
  description: 'Behavior livre, composto só por regras Trigger → Condition → Action.',
  category: 'Logic',
  params: [],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Custom Rules (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'custom_rules',
    enabled: true,
    properties: {},
    rules: [],
  }),
});
