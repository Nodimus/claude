import { defineBehavior, newLogicId } from '../../types';
import { CAMERA_FREE_FLYING_DEFAULTS as D } from '../../../runtime/cameraRig/params';

export default defineBehavior({
  id: 'camera_free_flying',
  label: 'Free Flying Camera',
  description:
    'Câmera de voo livre (decisão 28): voa sozinha, sem ator, sem gravidade e sem colisão. WASD relativo ao olhar, Jump sobe e Crouch desce; olha com o mouse (clique na viewport captura o ponteiro; Esc libera). Só em nó Camera ativo.',
  category: 'Camera',
  allowedNodeTypes: ['Camera'],
  params: [
    { key: 'moveSpeed', label: 'Move Speed (m/s)', type: 'number', default: D.moveSpeed },
    { key: 'rotateSpeed', label: 'Mouse Sensitivity (°/px)', type: 'number', default: D.rotateSpeed },
    { key: 'smoothMoving', label: 'Smooth Moving (1/s, 0 = off)', type: 'number', default: D.smoothMoving },
    { key: 'fov', label: 'Field of View (°)', type: 'number', default: D.fov },
    { key: 'pointerLock', label: 'Capture Pointer', type: 'boolean', default: D.pointerLock },
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Free Flying Camera (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'camera_free_flying',
    enabled: true,
    properties: { ...D },
    rules: [],
  }),
});
