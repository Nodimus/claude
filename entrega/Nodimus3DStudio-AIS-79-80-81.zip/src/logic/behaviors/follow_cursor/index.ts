import { defineBehavior, newLogicId } from '../../types';

export default defineBehavior({
  id: 'follow_cursor',
  label: 'Follow Cursor',
  description: 'Faz o objeto seguir o cursor.',
  category: 'Movement',
  // sem runtime nem prompt dono ainda: aparece "em breve" no picker, nunca habilitado sem fazer nada (decisão 14)
  status: 'disabled',
  params: [],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Follow Cursor (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'follow_cursor',
    enabled: true,
    properties: {},
    rules: [],
  }),
});
