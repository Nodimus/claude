import type { BehaviorRuntimeModule } from '../../types';
import { tNow } from '../../../core/i18n';

/**
 * Object Moved By Physics Engine (AIS-48): as regras (On Collision Enter com força mínima/debounce) rodam no `LogicRunner`; este
 * executor só confere que o corpo do nó é `dynamic` (um só mecanismo: o Behavior nunca cria corpo nem define forma) e avisa uma vez.
 */
const mod: BehaviorRuntimeModule = {
  create: () => {
    let checked = false;
    return {
      onUpdate(ctx) {
        if (checked) return;
        const bridge = ctx.physics;
        if (!bridge) {
          if (ctx.sceneTime >= 1) {
            checked = true;
            ctx.log('warn', tNow('runtimeMsgCore.objectMovedByPhysicsThe'));
          }
          return;
        }
        checked = true;
        const mode = bridge.modeOf(ctx.node.persistentNodeId);
        if (mode !== 'dynamic') ctx.log('warn', mode ? tNow('runtimeMsgCore.objectMovedByPhysicsThis', { mode }) : tNow('runtimeMsgCore.objectMovedByPhysicsThe2'));
      },
    };
  },
};
export default mod;
