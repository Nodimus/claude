import type { BehaviorRuntime, BehaviorRuntimeModule } from '../../types';
import { PhysicsBridgeError } from '../../../core/physics/PhysicsBridge';
import {
  facingAngleDeg,
  initialTopDownState,
  planeAxes,
  pointerDirection,
  readTopDown2DParams,
  resolvePlane,
  stepTopDown,
  turnFacing,
  type TopDownState,
} from '../../../runtime/controllers/controller2d';
import { controllerPreflight, publishLocomotion } from '../../controllerRuntime';

const INDEX = { x: 0, y: 1, z: 2 } as const;

/**
 * Top-Down 2D (AIS-75): movimento livre nos 2 eixos do plano (`physics.constrainToPlane`, padrão `xz`), sem gravidade própria: o eixo
 * normal fica congelado na pose autoral e a queda acumulada da ponte é zerada a cada quadro. Facing = direção do movimento (teclado/analógico)
 * ou do mouse em relação ao centro da viewport. Só gira em torno do eixo normal ao plano.
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let state: TopDownState = initialTopDownState();
    let facing = 0;
    let warnedPhysics = false;
    return {
      attach(ctx) {
        state = initialTopDownState();
        const { plane } = resolvePlane(ctx.node.properties?.physics?.constrainToPlane, 'xz');
        facing = ctx.initialTransform.rotation[INDEX[planeAxes(plane).normal]];
      },
      onUpdate(ctx, dt) {
        if (!warnedPhysics && controllerPreflight(ctx, 'Top-Down 2D Movement')) warnedPhysics = true;
        const p = readTopDown2DParams(ctx.state.properties);
        const { plane } = resolvePlane(ctx.node.properties?.physics?.constrainToPlane, 'xz');
        const axes = planeAxes(plane);
        const step = stepTopDown(
          state,
          p,
          { right: ctx.input.getAxis('MoveLeft', 'MoveRight'), up: ctx.input.getAxis('MoveBackward', 'MoveForward') },
          axes.upSign,
          dt
        );
        state = step.state;

        let want: { right: number; up: number } | null = step.moving ? { right: step.dirRight, up: step.dirUp } : null;
        if (p.facing === 'mouse') want = pointerDirection(ctx.input.pointer, ctx.input.pointer?.bounds) ?? want;
        if (want) facing = turnFacing(facing, facingAngleDeg(want.right, want.up), p.turnSpeed, dt);

        const pos: [number, number, number] = [...ctx.node.transform.position];
        pos[INDEX[axes.right]] += step.dRight;
        pos[INDEX[axes.up]] += step.dUp;
        pos[INDEX[axes.normal]] = ctx.initialTransform.position[INDEX[axes.normal]]; // o plano não se abandona
        ctx.node.transform.position = pos;
        // gira só em torno do eixo normal; os outros dois ficam na inclinação AUTORAL (a pose simulada volta como Euler e não serve de base)
        const rot: [number, number, number] = [...ctx.initialTransform.rotation];
        rot[INDEX[axes.normal]] = facing;
        ctx.node.transform.rotation = rot;
        ctx.applyTransform(ctx.node);

        const bridge = ctx.physics;
        const id = ctx.node.persistentNodeId;
        if (bridge && bridge.modeOf(id) === 'character') {
          try {
            bridge.setLinearVelocity(id, { x: 0, y: 0, z: 0 }); // sem gravidade: nada de queda acumulada
          } catch (error) {
            if (error instanceof PhysicsBridgeError) ctx.log('error', error.message);
            else throw error;
          }
        }
        publishLocomotion(ctx, { moving: step.moving, sprinting: false, speed: step.speed });
      },
      detach(ctx) {
        ctx.setLocomotion(null);
      },
    };
  },
};
export default mod;
