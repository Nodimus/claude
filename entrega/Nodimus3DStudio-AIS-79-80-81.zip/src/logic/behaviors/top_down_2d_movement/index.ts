import { defineBehavior, newLogicId } from '../../types';
import { LOCOMOTION_ANIMATION_DEFAULTS, LOCOMOTION_ANIMATION_PARAMS } from '../../locomotionAnimation';
import { TOP_DOWN_2D_DEFAULTS as D } from '../../../runtime/controllers/controller2d';

export default defineBehavior({
  id: 'top_down_2d_movement',
  label: 'Top-Down 2D Movement',
  description:
    'Movimento livre nos 2 eixos do plano do ATOR (AIS-75), sem gravidade: MoveForward/MoveBackward/MoveLeft/MoveRight (WASD, setas, analógico). "Facing": o personagem olha na direção do movimento ou na do mouse (em relação ao centro da viewport). Plano XZ (visto de cima) por padrão; XY e YZ também valem pela Colisão. Não controla câmera. Visual recomendado: Billboard com Sprite (opcional). Exige Colisão do nó como "Personagem" (character).',
  category: 'Movement',
  requires: ['requiresPhysics'],
  presetPhysics: { bodyMode: 'character', constrainToPlane: 'xz' },
  preset: { label: 'Top-Down 2D', order: 7 },
  params: [
    { key: 'moveSpeed', label: 'Move Speed (m/s)', type: 'number', default: D.moveSpeed },
    { key: 'smoothing', label: 'Smooth Moving (1/s, 0 = off)', type: 'number', default: D.smoothing },
    { key: 'facing', label: 'Facing', type: 'enum', default: D.facing, options: ['movement', 'mouse'] },
    { key: 'turnSpeed', label: 'Turn Speed (1/s)', type: 'number', default: D.turnSpeed },
    ...LOCOMOTION_ANIMATION_PARAMS,
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Top-Down 2D Movement (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'top_down_2d_movement',
    enabled: true,
    properties: { ...D, ...LOCOMOTION_ANIMATION_DEFAULTS },
    rules: [],
  }),
});
