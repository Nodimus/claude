import { defineBehavior, newLogicId } from '../../types';
import { LOCOMOTION_ANIMATION_DEFAULTS, LOCOMOTION_ANIMATION_PARAMS } from '../../locomotionAnimation';
import { PLATFORMER_2D_DEFAULTS as D } from '../../../runtime/controllers/controller2d';

export default defineBehavior({
  id: 'platformer_2d_movement',
  label: 'Platformer 2D Movement',
  description:
    'Plataforma 2D do ATOR (AIS-75): ←/→ (MoveLeft/MoveRight), pulo (Jump) com detecção de chão, coyote time, buffer de pulo, pulo de altura variável e gravidade configurável. É o mesmo mundo 3D restrito ao plano da Colisão (plano XY por padrão). Não controla câmera: use um nó Camera com Behavior de câmera. Visual recomendado: Billboard com Sprite (opcional). Exige Colisão do nó como "Personagem" (character).',
  category: 'Movement',
  requires: ['requiresPhysics'],
  presetPhysics: { bodyMode: 'character', constrainToPlane: 'xy' },
  preset: { label: 'Platformer 2D', order: 6 },
  params: [
    { key: 'moveSpeed', label: 'Move Speed (m/s)', type: 'number', default: D.moveSpeed },
    { key: 'jumpSpeed', label: 'Jump Speed (m/s)', type: 'number', default: D.jumpSpeed },
    { key: 'smoothing', label: 'Smooth Moving (1/s, 0 = off)', type: 'number', default: D.smoothing },
    { key: 'coyoteTime', label: 'Coyote Time (s)', type: 'number', default: D.coyoteTime },
    { key: 'jumpBuffer', label: 'Jump Buffer (s)', type: 'number', default: D.jumpBuffer },
    { key: 'gravityScale', label: 'Gravity Scale (1 = a do mundo)', type: 'number', default: D.gravityScale },
    { key: 'variableJump', label: 'Variable Jump Height', type: 'boolean', default: D.variableJump },
    ...LOCOMOTION_ANIMATION_PARAMS,
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Platformer 2D Movement (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'platformer_2d_movement',
    enabled: true,
    properties: { ...D, ...LOCOMOTION_ANIMATION_DEFAULTS },
    rules: [],
  }),
});
