import { defineBehavior, newLogicId } from '../../types';
import { CAMERA_PANORAMA_DEFAULTS as D } from '../../../runtime/cameraRig/params';

export default defineBehavior({
  id: 'camera_panorama',
  label: 'Panorama Camera',
  description: 'Câmera de panorama (decisão 28): posição fixa; só rotaciona, arrastando com a ação de órbita (botão esquerdo por padrão), para tours de 360°. Sem alvo. Só em nó Camera ativo.',
  category: 'Camera',
  allowedNodeTypes: ['Camera'],
  params: [
    { key: 'rotateSpeed', label: 'Rotate Speed (°/px)', type: 'number', default: D.rotateSpeed },
    { key: 'fov', label: 'Field of View (°)', type: 'number', default: D.fov },
    { key: 'orbitAction', label: 'Rotate Action (Input Map)', type: 'enum', default: D.orbitAction, options: ['Fire', 'AltFire'], optionsFrom: 'inputActions' },
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Panorama Camera (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'camera_panorama',
    enabled: true,
    properties: { ...D },
    rules: [],
  }),
});
