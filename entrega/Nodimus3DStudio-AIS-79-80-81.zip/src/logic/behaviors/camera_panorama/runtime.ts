import type { BehaviorRuntime, BehaviorRuntimeModule } from '../../types';
import { clamp } from '../../../runtime/controllers/controllerMath';
import { firstPersonRigPose, readCameraPanoramaParams, stepFirstPersonLook, type LookAngles } from '../../../runtime/cameraRig';
import { cameraNodeActive, nodePosition } from '../../cameraRuntime';

/**
 * Panorama Camera (AIS-47d, decisão 28): posição FIXA (a do nó `Camera`), só rotaciona — arrastando com a ação `orbitAction`, sem
 * capturar o ponteiro. Reusa o `firstPersonRig` (olhar + pose com olhos a altura 0). Não depende de Hotspots (AIS-70). Só publica
 * com o nó `active`.
 */
const MAX_VERTICAL = 85;

const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let look: LookAngles = { yaw: 0, pitch: 0 };
    return {
      attach(ctx) {
        look = { yaw: ctx.initialTransform.rotation[1], pitch: clamp(ctx.initialTransform.rotation[0], -MAX_VERTICAL, MAX_VERTICAL) };
      },
      onLateUpdate(ctx) {
        if (!cameraNodeActive(ctx)) {
          ctx.setGameCamera(null);
          return;
        }
        const p = readCameraPanoramaParams(ctx.state.properties);
        if (ctx.input.isActionPressed(p.orbitAction)) {
          const pointer = ctx.input.pointer;
          look = stepFirstPersonLook(look, { rotateSpeed: p.rotateSpeed, maxVerticalAngle: MAX_VERTICAL }, pointer?.dx ?? 0, pointer?.dy ?? 0);
        }
        const pose = firstPersonRigPose(nodePosition(ctx.node), look, { eyeHeight: 0 });
        ctx.setGameCamera({ position: pose.position, quaternion: pose.quaternion, fov: p.fov, pointerLock: false, view: { yaw: look.yaw, pitch: look.pitch }, kind: 'camera' });
      },
      detach(ctx) {
        ctx.setGameCamera(null);
      },
    };
  },
};
export default mod;
