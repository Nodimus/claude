import { defineBehavior, newLogicId } from '../../types';
import { LOCOMOTION_ANIMATION_DEFAULTS, LOCOMOTION_ANIMATION_PARAMS } from '../../locomotionAnimation';
import { THIRD_PERSON_MOVEMENT_DEFAULTS as D } from '../../../runtime/cameraRig/params';

export default defineBehavior({
  id: 'third_person_movement',
  label: 'Third Person Movement',
  description:
    'Movimento em terceira pessoa do ATOR (decisão 28): WASD relativo à câmera ativa, o personagem vira para onde anda, pulo (Jump) e corrida (Sprint). Não controla câmera: adicione um nó Camera com "Third Person Camera" apontando para este nó. Exige Colisão do nó como "Personagem" (character).',
  category: 'Movement',
  requires: ['requiresPhysics'],
  presetPhysics: { bodyMode: 'character' },
  preset: { label: 'Third Person', order: 5 },
  params: [
    { key: 'moveSpeed', label: 'Move Speed (m/s)', type: 'number', default: D.moveSpeed },
    { key: 'jumpSpeed', label: 'Jump Speed (m/s)', type: 'number', default: D.jumpSpeed },
    { key: 'sprintMultiplier', label: 'Sprint Multiplier (1 = sem corrida)', type: 'number', default: D.sprintMultiplier },
    { key: 'turnSpeed', label: 'Turn Speed (1/s)', type: 'number', default: D.turnSpeed },
    ...LOCOMOTION_ANIMATION_PARAMS,
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Third Person Movement (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'third_person_movement',
    enabled: true,
    properties: { ...D, ...LOCOMOTION_ANIMATION_DEFAULTS },
    rules: [],
  }),
});
