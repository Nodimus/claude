import type { BehaviorRuntime, BehaviorRuntimeModule } from '../../types';
import { initialPlanarMoveState, readThirdPersonMovementParams, stepPlanarMove, turnTowardMovement, type PlanarMoveState } from '../../../runtime/cameraRig';
import { yawKeepingAuthoredTilt } from '../../../runtime/controllers/controllerMath';
import { controllerPreflight, publishLocomotion, tryJump } from '../../controllerRuntime';
import { tNow } from '../../../core/i18n';

/**
 * Third Person Movement (AIS-47c, decisão 28): SÓ locomoção do ator. Movimento relativo ao `ctx.view` da câmera ativa (quadro
 * anterior); o personagem vira para onde anda. Sem câmera ativa, os eixos são os do MUNDO (W = -Z): relativo ao yaw do próprio nó
 * o corpo giraria em espiral ao andar de lado. NUNCA publica pose de câmera, captura o ponteiro nem esconde o corpo.
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let move: PlanarMoveState = initialPlanarMoveState();
    let faceYaw = 0;
    let warnedPhysics = false;
    let warnedNoView = false;
    return {
      attach(ctx) {
        move = initialPlanarMoveState();
        faceYaw = ctx.initialTransform.rotation[1];
        ctx.node.transform.rotation = yawKeepingAuthoredTilt(ctx.initialTransform.rotation, faceYaw);
      },
      onUpdate(ctx, dt) {
        if (!warnedPhysics && controllerPreflight(ctx, 'Third Person Movement')) warnedPhysics = true;
        const p = readThirdPersonMovementParams(ctx.state.properties);
        const view = ctx.engine.camera.view();
        if (!view && !warnedNoView) {
          warnedNoView = true;
          ctx.log('info', tNow('runtimeMsgCore.noActiveCameraMovementUses'));
        }
        const sprinting = p.sprintMultiplier > 1 && ctx.input.isActionPressed('Sprint');
        const next = stepPlanarMove(
          move,
          { moveSpeed: p.moveSpeed, smoothing: 0, speedMultiplier: sprinting ? p.sprintMultiplier : 1 },
          { forward: ctx.input.getAxis('MoveBackward', 'MoveForward'), strafe: ctx.input.getAxis('MoveLeft', 'MoveRight') },
          view ? view.yaw : 0,
          dt
        );
        move = next.state;
        faceYaw = turnTowardMovement(faceYaw, next.dirX, next.dirZ, p.turnSpeed, dt);
        const [x, y, z] = ctx.node.transform.position;
        ctx.node.transform.position = [x + next.delta.x, y, z + next.delta.z];
        // a pose simulada volta como Euler XYZ (yaw > 90° vem como 180/180-yaw/180): reescrever só o Y com o X/Z relidos fazia o corpo tremer entre dois espelhos
        ctx.node.transform.rotation = yawKeepingAuthoredTilt(ctx.initialTransform.rotation, faceYaw);
        ctx.applyTransform(ctx.node);
        if (ctx.input.isActionJustPressed('Jump')) tryJump(ctx, p.jumpSpeed);
        publishLocomotion(ctx, { moving: next.moving, sprinting, speed: next.speed });
      },
      detach(ctx) {
        ctx.setLocomotion(null);
      },
    };
  },
};
export default mod;
