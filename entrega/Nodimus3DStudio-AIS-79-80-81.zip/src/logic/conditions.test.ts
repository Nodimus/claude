import { describe, expect, it } from 'vitest';
import { InputManager } from '../runtime/input/InputManager';
import { CommandManager } from '../core/commandManager';
import { createBehaviorOps, type BehaviorStore } from '../core/commands/BehaviorCommands';
import type { Behavior } from '../types/visualLogic';
import { EXPECTED_NATIVE_LOGIC, LogicRegistry, verifyLogicRegistry } from './registry';
import { evaluateCondition, evaluateConditionOrNull, evaluateConditions, type ConditionWorld } from './evaluateCondition';
import { compareValues, readNodeProperty } from './conditionHelpers';
import type { ConditionNode } from './types';

const node = (id: string, name: string, over: Partial<ConditionNode> = {}): ConditionNode => ({ id, name, type: 'MeshInstance', visible: true, properties: {}, ...over });

interface WorldOptions {
  nodes?: ConditionNode[];
  positions?: Record<string, { x: number; y: number; z: number }>;
  keys?: string[];
  time?: number;
  random?: number;
  self?: string;
}

function world(o: WorldOptions = {}): ConditionWorld {
  const nodes = o.nodes ?? [];
  const find = (ref: string) => nodes.find((n) => n.id === ref || n.name === ref);
  const input = new InputManager();
  input.setEnabled(true);
  for (const key of o.keys ?? []) input.handleKey(key, true);
  return {
    selfNodeId: o.self,
    getNode: find,
    getWorldPosition: (ref) => {
      const n = find(ref);
      return n ? o.positions?.[n.id] : undefined;
    },
    input,
    sceneTime: o.time ?? 0,
    random: () => o.random ?? 0.5,
  };
}

const check = (type: string, parameters: Record<string, unknown>, w: ConditionWorld) => evaluateCondition({ type, parameters }, w);

describe('AIS-40c — catálogo (C01, C02)', () => {
  const NEW = ['property_compare', 'key_pressed', 'node_visible', 'distance_between', 'random_chance', 'timer_elapsed', 'not'];

  it('cada Condition nova tem pasta própria, id, schema e avaliador puro', () => {
    for (const id of NEW) {
      const def = LogicRegistry.getCondition(id);
      expect(def, id).toBeDefined();
      expect(def!.id).toBe(id);
      expect(typeof def!.evaluate).toBe('function');
      expect(def!.paramsSchema.safeParse({}).success, `${id} aceita parâmetros vazios (padrões)`).toBe(true);
      expect(def!.params.length === 0 || def!.label.length > 0).toBe(true);
    }
  });

  it('as 5 Conditions antigas continuam com os mesmos IDs, mais as novas, todas em EXPECTED_NATIVE_LOGIC', () => {
    for (const id of ['always', 'key_down', 'node_exists', 'property_equals', 'property_greater', ...NEW]) {
      expect(LogicRegistry.isKnownCondition(id), id).toBe(true);
      expect(EXPECTED_NATIVE_LOGIC.condition).toContain(id);
    }
    expect(LogicRegistry.listConditions().map((c) => c.id).sort()).toEqual([...EXPECTED_NATIVE_LOGIC.condition].sort());
  });

  it('o teste de enumeração falha se uma Condition do catálogo sumir', () => {
    const r = verifyLogicRegistry();
    expect(r.results.filter((x) => !x.passed)).toEqual([]);
    const missing = EXPECTED_NATIVE_LOGIC.condition.filter((id) => !LogicRegistry.isKnownCondition(id));
    expect(missing).toEqual([]);
    // simulando a perda de uma pasta: a lista esperada passa a apontar um ID que o registro não tem
    expect([...EXPECTED_NATIVE_LOGIC.condition, 'pasta_removida'].filter((id) => !LogicRegistry.isKnownCondition(id))).toEqual(['pasta_removida']);
  });

  it('o padrão declarado de cada parâmetro é aceito pelo schema da própria pasta', () => {
    for (const def of LogicRegistry.listConditions()) {
      const defaults = Object.fromEntries(def.params.map((p) => [p.key, p.default]));
      expect(def.paramsSchema.safeParse(defaults).success, def.id).toBe(true);
    }
  });
});

describe('AIS-40c — avaliação pura de cada Condition nova (C03)', () => {
  const player = node('p', 'Player', { visible: true, properties: { health: 40, alive: true, position: { x: 1, y: 2, z: 3 }, label: 'hero' } });
  const hidden = node('h', 'Ghost', { visible: false });
  const w = (o: WorldOptions = {}) => world({ nodes: [player, hidden, node('s', 'Self', { properties: { health: 5 } })], self: 's', ...o });

  it('property_compare: todos os operadores, caminhos e tipos', () => {
    const cmp = (property: string, operator: string, value: unknown, target = 'Player') => check('property_compare', { target, property, operator, value }, w());
    expect(cmp('health', '=', 40)).toBe(true);
    expect(cmp('health', '=', '40')).toBe(true);
    expect(cmp('health', '=', 41)).toBe(false);
    expect(cmp('health', '!=', 41)).toBe(true);
    expect(cmp('health', '<', 50)).toBe(true);
    expect(cmp('health', '<', 40)).toBe(false);
    expect(cmp('health', '>', 39)).toBe(true);
    expect(cmp('health', '>', 40)).toBe(false);
    expect(cmp('health', '<=', 40)).toBe(true);
    expect(cmp('health', '<=', 39)).toBe(false);
    expect(cmp('health', '>=', 40)).toBe(true);
    expect(cmp('health', '>=', 41)).toBe(false);
    expect(cmp('position.y', '=', 2)).toBe(true); // caminho aninhado
    expect(cmp('visible', '=', 'true')).toBe(true); // campo do nó, booleano como texto
    expect(cmp('visible', '=', 'false', 'Ghost')).toBe(true);
    expect(cmp('label', '=', 'hero')).toBe(true);
    expect(cmp('label', '<', 5)).toBe(false); // ordenação exige números
    expect(cmp('inexistente', '=', '')).toBe(true); // ausente == vazio
    expect(cmp('inexistente', '!=', 'x')).toBe(true);
  });

  it('property_compare: alvo vazio = o próprio nó da regra; nó inexistente é falsa', () => {
    expect(check('property_compare', { property: 'health', operator: '=', value: 5 }, w())).toBe(true);
    expect(check('property_compare', { target: 'NaoExiste', property: 'health', operator: '=', value: 5 }, w())).toBe(false);
    expect(check('property_compare', { property: 'health', operator: '=', value: 5 }, world({ nodes: [] }))).toBe(false);
  });

  it('key_pressed: consulta a AÇÃO do InputManager, não a tecla', () => {
    expect(check('key_pressed', { action: 'Jump' }, w({ keys: ['Space'] }))).toBe(true);
    expect(check('key_pressed', { action: 'Jump' }, w())).toBe(false);
    expect(check('key_pressed', { action: 'MoveForward' }, w({ keys: ['ArrowUp'] }))).toBe(true); // W ou seta: o mapa decide
    expect(check('key_pressed', { action: 'AcaoQueNaoExiste' }, w({ keys: ['Space'] }))).toBe(false);
    const remapped = w();
    (remapped.input as InputManager).rebind('Jump', ['KeyJ']);
    (remapped.input as InputManager).handleKey('KeyJ', true);
    expect(check('key_pressed', { action: 'Jump' }, remapped)).toBe(true);
  });

  it('key_down (existente): tecla fixa pelo nome amigável', () => {
    expect(check('key_down', { key: 'w' }, w({ keys: ['KeyW'] }))).toBe(true);
    expect(check('key_down', { key: 'w' }, w())).toBe(false);
    expect(check('key_down', { key: '' }, w({ keys: ['KeyW'] }))).toBe(false);
  });

  it('node_exists / node_visible', () => {
    expect(check('node_exists', { target: 'Player' }, w())).toBe(true);
    expect(check('node_exists', { target: 'Nada' }, w())).toBe(false);
    expect(check('node_exists', { target: 'Ghost' }, w())).toBe(true); // existe, mesmo invisível
    expect(check('node_exists', { node: 'Player' }, w())).toBe(true); // chave antiga de cenas existentes
    expect(check('node_visible', { target: 'Player' }, w())).toBe(true);
    expect(check('node_visible', { target: 'Ghost' }, w())).toBe(false);
    expect(check('node_visible', { target: 'Nada' }, w())).toBe(false);
  });

  it('distance_between: ≤, ≥ e = com tolerância; nó ausente é falsa', () => {
    const positions = { p: { x: 0, y: 0, z: 0 }, h: { x: 3, y: 4, z: 0 }, s: { x: 0, y: 0, z: 10 } };
    const d = (operator: string, threshold: number, nodeA = 'Player', nodeB = 'Ghost') => check('distance_between', { nodeA, nodeB, operator, threshold }, w({ positions }));
    expect(d('<=', 5)).toBe(true);
    expect(d('<=', 4.9)).toBe(false);
    expect(d('>=', 5)).toBe(true);
    expect(d('>=', 5.1)).toBe(false);
    expect(d('=', 5)).toBe(true);
    expect(d('=', 5.0004)).toBe(true);
    expect(d('=', 5.1)).toBe(false);
    expect(d('<=', 10, 'Player', '')).toBe(true); // vazio = o próprio nó (Self, a 10 m)
    expect(d('<=', 5, 'Player', 'Nada')).toBe(false);
  });

  it('random_chance: usa o sorteio injetado; 0 nunca, 1 sempre; fora do intervalo é limitado', () => {
    const r = (probability: number, random: number) => check('random_chance', { probability }, w({ random }));
    expect(r(0.5, 0.2)).toBe(true);
    expect(r(0.5, 0.7)).toBe(false);
    expect(r(0.5, 0.5)).toBe(false); // [0, p)
    expect(r(0, 0)).toBe(false);
    expect(r(1, 0.999)).toBe(true);
    expect(r(5, 0.999)).toBe(true); // vira 1
    expect(r(-2, 0)).toBe(false); // vira 0
  });

  it('timer_elapsed: tempo da cena >= segundos', () => {
    expect(check('timer_elapsed', { seconds: 2 }, w({ time: 2 }))).toBe(true);
    expect(check('timer_elapsed', { seconds: 2 }, w({ time: 5.5 }))).toBe(true);
    expect(check('timer_elapsed', { seconds: 2 }, w({ time: 1.99 }))).toBe(false);
  });

  it('not: nega a aninhada; aninhada desconhecida ou inválida NÃO vira verdadeira', () => {
    const inner = (type: string, parameters: Record<string, unknown> = {}) => ({ condition: { type, parameters } });
    expect(check('not', inner('always'), w())).toBe(false);
    expect(check('not', inner('node_exists', { target: 'Nada' }), w())).toBe(true);
    expect(check('not', inner('node_exists', { target: 'Player' }), w())).toBe(false);
    expect(check('not', inner('not', {}), w())).toBe(true); // not(not(always)) com aninhada padrão
    expect(check('not', inner('acao_de_outra_versao'), w())).toBe(false); // falha fechada
    expect(evaluateConditionOrNull({ type: 'not', parameters: inner('acao_de_outra_versao') }, w())).toBe(false);
    expect(check('not', {}, w())).toBe(false); // padrão: not(always)
  });

  it('Conditions das regras se combinam em E; lista vazia = sempre', () => {
    expect(evaluateConditions([], w())).toBe(true);
    expect(evaluateConditions([{ type: 'always' }, { type: 'node_exists', parameters: { target: 'Player' } }], w())).toBe(true);
    expect(evaluateConditions([{ type: 'always' }, { type: 'node_exists', parameters: { target: 'Nada' } }], w())).toBe(false);
  });
});

describe('AIS-40c — revisão das 5 Conditions existentes (3.1)', () => {
  const w = (o: WorldOptions = {}) => world({ nodes: [node('p', 'Player', { properties: { health: 40, name2: 'x' } })], self: 'p', ...o });
  it('always é sempre verdadeira', () => expect(check('always', {}, w())).toBe(true));
  it('property_equals e property_greater seguem funcionando (valor como texto ou número)', () => {
    expect(check('property_equals', { property: 'health', value: '40' }, w())).toBe(true);
    expect(check('property_equals', { property: 'health', value: '41' }, w())).toBe(false);
    expect(check('property_greater', { property: 'health', value: 30 }, w())).toBe(true);
    expect(check('property_greater', { property: 'health', value: 40 }, w())).toBe(false);
    expect(check('property_greater', { property: 'health', value: '30' }, w())).toBe(true);
  });
  it('parâmetros gravados por cenas antigas (sem target) continuam válidos', () => {
    for (const id of ['always', 'key_down', 'node_exists', 'property_equals', 'property_greater']) {
      expect(LogicRegistry.getCondition(id)!.paramsSchema.safeParse({}).success, id).toBe(true);
    }
  });
});

describe('AIS-40c — ID desconhecido e parâmetros inválidos (C04)', () => {
  const w = world({ nodes: [node('p', 'Player')] });

  it('ID desconhecido não lança: avalia como não resolvida (null) e a regra não executa', () => {
    expect(evaluateConditionOrNull({ type: 'condicao_futura', parameters: { a: 1 } }, w)).toBeNull();
    expect(evaluateCondition({ type: 'condicao_futura', parameters: { a: 1 } }, w)).toBe(false);
  });

  it('parâmetro inválido também é não resolvido, sem lançar', () => {
    expect(evaluateConditionOrNull({ type: 'timer_elapsed', parameters: { seconds: 'abc' } }, w)).toBeNull();
    expect(evaluateConditionOrNull({ type: 'property_compare', parameters: { operator: '≈' } }, w)).toBeNull();
  });

  it('aninhamento sem fim é cortado', () => {
    let ref: any = { type: 'always', parameters: {} };
    for (let i = 0; i < 40; i++) ref = { type: 'not', parameters: { condition: ref } };
    expect(() => evaluateCondition(ref, w)).not.toThrow();
  });

  const behavior = (): Behavior => ({
    id: 'b',
    name: 'B',
    targetNodeId: 'Player',
    behaviorType: 'custom_rules',
    enabled: true,
    properties: {},
    rules: [
      {
        id: 'r',
        eventType: 'on_update',
        parameters: {},
        conditions: [
          { id: 'c_new', type: 'condicao_de_outra_versao', parameters: { limite: [1, { fundo: true }], texto: 'x' } },
          { id: 'c1', type: 'always', parameters: {} },
        ],
        actions: [],
      },
    ],
  });

  it('o editor preserva os parâmetros de uma Condition desconhecida ao adicionar/remover outras e no Undo', () => {
    let list: Behavior[] = [behavior()];
    const store: BehaviorStore = { get: () => list, set: (n) => void (list = n) };
    const manager = new CommandManager();
    const ops = createBehaviorOps(store, (c) => manager.execute(c));
    const original = structuredClone(list[0].rules[0].conditions[0]);
    ops.addCondition('b', 'r', 'distance_between');
    ops.removeCondition('b', 'r', 'c1');
    expect(list[0].rules[0].conditions[0]).toEqual(original);
    manager.undo();
    manager.undo();
    expect(list[0].rules[0].conditions[0]).toEqual(original);
    expect(list[0].rules[0].conditions.map((c) => c.type)).toEqual(['condicao_de_outra_versao', 'always']);
  });

  it('o schema de cena aceita Condition de ID desconhecido (ID é string livre)', async () => {
    const { BehaviorV1Schema } = await import('../schemas/v1/visualLogic.schema');
    const parsed = BehaviorV1Schema.safeParse(behavior());
    expect(parsed.success).toBe(true);
    if (parsed.success) expect(parsed.data.rules[0].conditions[0].parameters).toEqual({ limite: [1, { fundo: true }], texto: 'x' });
  });
});

describe('AIS-40c — helpers puros', () => {
  it('readNodeProperty: campos do nó vencem properties; caminho ausente é undefined', () => {
    const n = node('a', 'A', { visible: false, properties: { visible: true, deep: { x: { y: 3 } } } });
    expect(readNodeProperty(n, 'visible')).toBe(false);
    expect(readNodeProperty(n, 'deep.x.y')).toBe(3);
    expect(readNodeProperty(n, 'deep.z.y')).toBeUndefined();
    expect(readNodeProperty(n, '')).toBeUndefined();
  });
  it('compareValues: números como texto, booleanos e nulos', () => {
    expect(compareValues('7', '>', 3)).toBe(true);
    expect(compareValues('abc', '>', 3)).toBe(false);
    expect(compareValues(true, '=', 'TRUE')).toBe(true);
    expect(compareValues(null, '=', '')).toBe(true);
    expect(compareValues(2, '!=', 3)).toBe(true);
  });
});
