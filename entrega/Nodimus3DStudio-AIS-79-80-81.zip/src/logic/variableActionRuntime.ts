/** AIS-44 — esqueleto comum das Actions de variável (resolve o alvo local, aplica e diz POR QUE falhou). */
import type { VariableManager, VariableScope } from '../core/variableManager';
import type { ActionRuntimeContext } from './types';
import { tNow } from '../core/i18n';

export function runVariableAction(
  label: string,
  p: { scope: VariableScope; target: string; variable: string },
  ctx: ActionRuntimeContext,
  apply: (vars: VariableManager, scope: VariableScope, name: string, nodeId?: string) => boolean
): void {
  const vars = ctx.variables;
  if (!vars) return ctx.log('error', tNow('variableActionRuntimeMsgCore.thereIsNoVariablesSession', { label }));
  if (!p.variable) return ctx.log('error', tNow('variableActionRuntimeMsgCore.provideTheVariableName', { label }));
  let nodeId: string | undefined;
  if (p.scope === 'local') {
    const owner = ctx.resolve(p.target.trim());
    if (!owner) return ctx.log('error', tNow('variableActionRuntimeMsgCore.theNodeOfTheLocal', { label, target: p.target }));
    nodeId = owner.persistentNodeId;
  }
  if (!apply(vars, p.scope, p.variable, nodeId)) {
    ctx.log('error', tNow('variableActionRuntimeMsgCore.theVariableDoesNotExist', { label, value: p.scope === 'local' ? 'local' : 'global', variable: p.variable }));
  }
}
