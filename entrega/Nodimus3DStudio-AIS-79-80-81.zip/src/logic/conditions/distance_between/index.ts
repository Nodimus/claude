import { z } from 'zod';
import { defineCondition } from '../../types';

/** Tolerância da igualdade (metros): distância é número real, "=" nunca é exato. */
export const DISTANCE_EPSILON = 1e-3;

export default defineCondition({
  id: 'distance_between',
  label: 'Distance Between',
  description: 'Compara a distância entre dois nós (≤, ≥ ou =) com um limite em metros. Vazio em um dos nós = o próprio nó da regra.',
  category: 'Logic',
  params: [
    { key: 'nodeA', label: 'Node A', type: 'node', default: '' },
    { key: 'nodeB', label: 'Node B', type: 'node', default: '' },
    { key: 'operator', label: 'Operator', type: 'enum', default: '<=', options: ['<=', '>=', '='] },
    { key: 'threshold', label: 'Threshold (m)', type: 'number', default: 5 },
  ],
  paramsSchema: z.object({
    nodeA: z.string().default(''),
    nodeB: z.string().default(''),
    operator: z.enum(['<=', '>=', '=']).default('<='),
    threshold: z.coerce.number().default(5),
  }),
  evaluate: ({ nodeA, nodeB, operator, threshold }, ctx) => {
    const refA = nodeA.trim() || ctx.selfNodeId;
    const refB = nodeB.trim() || ctx.selfNodeId;
    if (!refA || !refB) return false;
    const a = ctx.getWorldPosition(refA);
    const b = ctx.getWorldPosition(refB);
    if (!a || !b) return false; // nó ausente: a distância não existe
    const d = Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
    return operator === '<=' ? d <= threshold : operator === '>=' ? d >= threshold : Math.abs(d - threshold) <= DISTANCE_EPSILON;
  },
});
