import { z } from 'zod';
import { defineCondition } from '../../types';
import { keyCodesOf } from '../../../runtime/input/inputTriggers';

export default defineCondition({
  id: 'key_down',
  label: 'Key Down',
  description: 'Verdadeira enquanto a tecla está pressionada. Prefira Key Pressed (ação lógica, segue o remapeamento).',
  category: 'Interaction',
  params: [
    { key: 'key', label: 'Key', type: 'key', default: '', required: true },
  ],
  paramsSchema: z.object({ key: z.string().default('') }),
  // tecla fixa lida pelo InputManager (nunca por KeyboardEvent); tecla vazia = falsa
  evaluate: ({ key }, ctx) => keyCodesOf(key).some((code) => ctx.input.isBindingPressed(code)),
});
