import { z } from 'zod';
import { defineCondition } from '../../types';
import { compareValues, readNodeProperty, resolveTarget } from '../../conditionHelpers';

export default defineCondition({
  id: 'property_greater',
  label: 'Property Greater',
  description: 'Verdadeira quando a propriedade do nó é maior que o valor. Prefira Property Compare (todos os operadores).',
  category: 'Logic',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'property', label: 'Property', type: 'string', default: '', required: true },
    { key: 'value', label: 'Value', type: 'number', default: 0 },
  ],
  paramsSchema: z.object({ target: z.string().default(''), property: z.string().default(''), value: z.coerce.number().default(0) }),
  evaluate: ({ target, property, value }, ctx) => {
    const node = resolveTarget(ctx, target);
    return !!node && compareValues(readNodeProperty(node, property), '>', value);
  },
});
