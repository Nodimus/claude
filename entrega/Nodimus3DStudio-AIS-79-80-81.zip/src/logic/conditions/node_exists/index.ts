import { z } from 'zod';
import { defineCondition } from '../../types';
import { resolveTarget } from '../../conditionHelpers';

export default defineCondition({
  id: 'node_exists',
  label: 'Node Exists',
  description: 'Verdadeira quando o nó indicado existe na cena e está ativo.',
  category: 'Logic',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
  ],
  // `node` é a chave que cenas antigas gravaram: continua lida (e preservada), só não aparece mais no editor
  paramsSchema: z.object({ target: z.string().default(''), node: z.string().optional() }),
  evaluate: ({ target, node }, ctx) => resolveTarget(ctx, target || node) !== undefined,
});
