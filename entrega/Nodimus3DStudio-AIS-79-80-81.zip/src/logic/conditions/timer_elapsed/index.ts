import { z } from 'zod';
import { defineCondition } from '../../types';

export default defineCondition({
  id: 'timer_elapsed',
  label: 'Timer Elapsed',
  description: 'Verdadeira quando o tempo desde o início da cena é maior ou igual a N segundos.',
  category: 'Utility',
  params: [
    { key: 'seconds', label: 'Seconds', type: 'number', default: 1 },
  ],
  paramsSchema: z.object({ seconds: z.coerce.number().default(1) }),
  evaluate: ({ seconds }, ctx) => ctx.sceneTime >= seconds,
});
