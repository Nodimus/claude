import { z } from 'zod';
import { defineCondition } from '../../types';
import { COMPARE_OPERATORS, compareValues, resolveTarget, type CompareOperator } from '../../conditionHelpers';

export default defineCondition({
  id: 'variable_compare',
  label: 'Variable Compare',
  description: 'Compara uma variável Global ou Local (do nó Target; vazio = o nó dono) com um valor: =, ≠, <, >, ≤, ≥.',
  category: 'Logic',
  params: [
    { key: 'scope', label: 'Scope', type: 'enum', default: 'global', options: ['global', 'local'] },
    { key: 'target', label: 'Target', type: 'node', default: '', visibleWhen: { key: 'scope', equals: 'local' } },
    { key: 'variableName', label: 'Variable', type: 'string', default: '', required: true, variable: true },
    { key: 'operator', label: 'Operator', type: 'enum', default: '=', options: [...COMPARE_OPERATORS] },
    { key: 'value', label: 'Value', type: 'string', default: '' },
  ],
  paramsSchema: z.object({
    scope: z.enum(['global', 'local']).default('global'),
    target: z.string().default(''),
    variableName: z.string().default(''),
    operator: z.enum(COMPARE_OPERATORS as unknown as [CompareOperator, ...CompareOperator[]]).default('='),
    value: z.union([z.string(), z.number(), z.boolean()]).default(''),
  }),
  evaluate: ({ scope, target, variableName, operator, value }, ctx) => {
    if (!variableName || !ctx.getVariable) return false;
    // global: o alvo não conta; local: o nó alvo (vazio = dono da regra) precisa existir
    const nodeId = scope === 'local' ? resolveTarget(ctx, target)?.id : undefined;
    if (scope === 'local' && !nodeId) return false;
    const actual = ctx.getVariable(scope, variableName, nodeId);
    return actual !== undefined && compareValues(actual, operator, value);
  },
});
