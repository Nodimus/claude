import { z } from 'zod';
import { defineCondition } from '../../types';
import { COMPARE_OPERATORS, compareValues, readNodeProperty, resolveTarget, type CompareOperator } from '../../conditionHelpers';

export default defineCondition({
  id: 'property_compare',
  label: 'Property Compare',
  description: 'Compara uma propriedade do nó (visible, position.x, health…) com um valor: =, ≠, <, >, ≤, ≥.',
  category: 'Logic',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'property', label: 'Property', type: 'string', default: '', required: true },
    { key: 'operator', label: 'Operator', type: 'enum', default: '=', options: [...COMPARE_OPERATORS] },
    { key: 'value', label: 'Value', type: 'string', default: '' },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    property: z.string().default(''),
    operator: z.enum(COMPARE_OPERATORS as unknown as [CompareOperator, ...CompareOperator[]]).default('='),
    value: z.union([z.string(), z.number(), z.boolean()]).default(''),
  }),
  evaluate: ({ target, property, operator, value }, ctx) => {
    const node = resolveTarget(ctx, target);
    return !!node && compareValues(readNodeProperty(node, property), operator, value);
  },
});
