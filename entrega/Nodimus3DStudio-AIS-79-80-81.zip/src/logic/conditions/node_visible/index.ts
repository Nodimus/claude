import { z } from 'zod';
import { defineCondition } from '../../types';
import { resolveTarget } from '../../conditionHelpers';

export default defineCondition({
  id: 'node_visible',
  label: 'Node Visible',
  description: 'Verdadeira quando o nó existe e está visível.',
  category: 'Logic',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
  ],
  paramsSchema: z.object({ target: z.string().default('') }),
  evaluate: ({ target }, ctx) => {
    const node = resolveTarget(ctx, target);
    return !!node && node.visible !== false;
  },
});
