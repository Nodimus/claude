import { z } from 'zod';
import { defineCondition } from '../../types';

export default defineCondition({
  id: 'random_chance',
  label: 'Random Chance',
  description: 'Verdadeira com a probabilidade indicada (0 = nunca, 1 = sempre).',
  category: 'Logic',
  params: [
    { key: 'probability', label: 'Probability (0–1)', type: 'number', default: 0.5 },
  ],
  // fora de [0, 1] vira o extremo mais próximo (nunca invalida a regra por causa de um número digitado)
  paramsSchema: z.object({ probability: z.coerce.number().default(0.5).transform((p) => Math.min(1, Math.max(0, p))) }),
  // o sorteio vem do contexto: determinístico nos testes e reproduzível por seed no Play (AIS-44)
  evaluate: ({ probability }, ctx) => probability > 0 && ctx.random() < probability,
});
