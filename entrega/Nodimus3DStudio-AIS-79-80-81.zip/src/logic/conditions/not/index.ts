import { z } from 'zod';
import { defineCondition } from '../../types';

const ConditionRefSchema = z.object({ type: z.string(), parameters: z.record(z.string(), z.unknown()).default({}) });

export default defineCondition({
  id: 'not',
  label: 'Not',
  description: 'Nega outra Condition (verdadeira quando a aninhada é falsa).',
  category: 'Logic',
  params: [
    { key: 'condition', label: 'Condition', type: 'condition', default: { type: 'always', parameters: {} } },
  ],
  paramsSchema: z.object({ condition: ConditionRefSchema.default({ type: 'always', parameters: {} }) }),
  // aninhada desconhecida ou inválida (`null`) NÃO vira verdadeira ao negar: falha fechada
  evaluate: ({ condition }, ctx) => {
    const inner = ctx.evaluate(condition);
    return inner === null ? false : !inner;
  },
});
