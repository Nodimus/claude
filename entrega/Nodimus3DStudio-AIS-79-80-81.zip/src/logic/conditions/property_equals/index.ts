import { z } from 'zod';
import { defineCondition } from '../../types';
import { compareValues, readNodeProperty, resolveTarget } from '../../conditionHelpers';

export default defineCondition({
  id: 'property_equals',
  label: 'Property Equals',
  description: 'Verdadeira quando a propriedade do nó é igual ao valor. Prefira Property Compare (todos os operadores).',
  category: 'Logic',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'property', label: 'Property', type: 'string', default: '', required: true },
    { key: 'value', label: 'Value', type: 'string', default: '' },
  ],
  paramsSchema: z.object({ target: z.string().default(''), property: z.string().default(''), value: z.union([z.string(), z.number(), z.boolean()]).default('') }),
  evaluate: ({ target, property, value }, ctx) => {
    const node = resolveTarget(ctx, target);
    return !!node && compareValues(readNodeProperty(node, property), '=', value);
  },
});
