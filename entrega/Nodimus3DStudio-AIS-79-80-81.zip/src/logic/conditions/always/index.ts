import { z } from 'zod';
import { defineCondition } from '../../types';

export default defineCondition({
  id: 'always',
  label: 'Always',
  description: 'Sempre verdadeira.',
  category: 'Logic',
  params: [],
  paramsSchema: z.object({}),
  evaluate: () => true,
});
