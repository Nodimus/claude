/**
 * AIS-41 — helpers PUROS compartilhados pelas Actions (fora das pastas de `src/logic/actions/`, que o registry varre).
 * Validações de contexto devolvem `ActionValidation` com código estável e mensagem em português: uma Action incompatível com o
 * alvo FALHA com erro explícito, nunca vira transformação ignorada em silêncio (skill `nodimus-catalogo-behaviors-actions` §9).
 */
import { z } from 'zod';
import type { PhysicsBodyMode } from '../types/node';
import type { ActionContext, ActionValidation, ConditionNode } from './types';
import { tNow } from '../core/i18n';

export const OK: ActionValidation = { ok: true };
export const fail = (code: string, message: string): ActionValidation => ({ ok: false, code, message });

/** Vetor 3D com padrão (parâmetros do tipo `vector3`; número digitado como texto é coagido). */
export const vec3Schema = (defaultX = 0, defaultY = 0, defaultZ = 0) =>
  z
    .object({ x: z.coerce.number().default(defaultX), y: z.coerce.number().default(defaultY), z: z.coerce.number().default(defaultZ) })
    .default({ x: defaultX, y: defaultY, z: defaultZ });

export const SPACES = ['world', 'local'] as const;
export type Space = (typeof SPACES)[number];

/** Os tipos de nó que contam como UI 2D (Overlay2D e derivados). */
export const UI_NODE_TYPES: readonly string[] = ['Overlay2D', 'TextOverlay2D', 'ButtonOverlay2D'];
export const isUiNode = (node: ConditionNode | undefined): boolean => !!node && UI_NODE_TYPES.includes(node.type);

const nameOf = (node: ConditionNode) => `"${node.name}"`;

/** Falha se não há nó alvo (nó ausente na cena). */
function needTarget(label: string, ctx: ActionContext): ActionValidation | ConditionNode {
  return ctx.target ?? fail('action.no_target', tNow('actionHelpersMsgCore.theTargetNodeDoesNot', { label }));
}

/**
 * Valida um corpo físico: o alvo precisa ter o bloco `properties.physics` (decisão 26), estar ligado (salvo `allowDisabled`) e
 * ter um `bodyMode` aceito. Ex.: `Add Force` num corpo `static`/`kinematic` é erro explícito.
 */
export function requirePhysicsBody(label: string, allowed: readonly PhysicsBodyMode[], options: { allowDisabled?: boolean } = {}) {
  return (_params: unknown, ctx: ActionContext): ActionValidation => {
    const target = needTarget(label, ctx);
    if (!('id' in target)) return target;
    const physics = target.properties?.physics as { enabled?: boolean; bodyMode?: PhysicsBodyMode } | undefined;
    if (!physics || typeof physics !== 'object') {
      return fail('physics.no_body', tNow('actionHelpersMsgCore.hasNoPhysicsBodyEnable', { label, value: nameOf(target) }));
    }
    if (physics.enabled === false && !options.allowDisabled) {
      return fail('physics.body_disabled', tNow('actionHelpersMsgCore.thePhysicsBodyOfIs', { label, value: nameOf(target) }));
    }
    const mode = physics.bodyMode ?? 'static';
    if (!allowed.includes(mode)) {
      return fail('physics.incompatible_body_mode', tNow('actionHelpersMsgCore.doesNotWorkOnA', { label, mode, value: nameOf(target), value2: allowed.map((m) => `"${m}"`).join(' ou ') }));
    }
    return OK;
  };
}

/** Valida o TIPO do nó alvo (ex.: `change_text` só em nós de texto). */
export function requireNodeType(label: string, types: readonly string[]) {
  return (_params: unknown, ctx: ActionContext): ActionValidation => {
    const target = needTarget(label, ctx);
    if (!('id' in target)) return target;
    return types.includes(target.type) ? OK : fail('action.incompatible_node_type', tNow('actionHelpersMsgCore.doesNotWorkOnA2', { label, type: target.type, value: nameOf(target), value2: types.map((t) => `"${t}"`).join(' ou ') }));
  };
}

/** Só nós 3D (não UI): transformações no espaço 3D. */
export function require3dNode(label: string) {
  return (_params: unknown, ctx: ActionContext): ActionValidation => {
    const target = needTarget(label, ctx);
    if (!('id' in target)) return target;
    return isUiNode(target) ? fail('action.incompatible_node_type', tNow('actionHelpersMsgCore.isA3dActionAnd', { label, value: nameOf(target) })) : OK;
  };
}
