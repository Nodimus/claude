/**
 * AIS-40c — helpers PUROS compartilhados pelas Conditions (fora das pastas de `src/logic/conditions/`, que o registry varre:
 * uma pasta sem definição seria reportada como inválida). Sem DOM, sem relógio, sem `Math.random`.
 */
import type { ConditionContext, ConditionNode } from './types';

export type CompareOperator = '=' | '!=' | '<' | '>' | '<=' | '>=';
export const COMPARE_OPERATORS: readonly CompareOperator[] = ['=', '!=', '<', '>', '<=', '>='];

const TOP_LEVEL = new Set(['id', 'name', 'type', 'visible', 'locked']);

/** Valor de uma propriedade do nó por caminho (`visible`, `position.x`, `health`…). Campos do nó vencem `properties`. */
export function readNodeProperty(node: ConditionNode, path: string): unknown {
  const segments = path.split('.').filter(Boolean);
  if (segments.length === 0) return undefined;
  const [head, ...rest] = segments;
  let current: any = TOP_LEVEL.has(head) ? (node as unknown as Record<string, unknown>)[head] : node.properties?.[head];
  for (const seg of rest) {
    if (current === null || typeof current !== 'object') return undefined;
    current = current[seg];
  }
  return current;
}

const numberOf = (v: unknown): number | null => {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
  return null;
};

/** Compara o valor atual com o esperado (digitado como texto, número ou booleano). Ordenação exige números. */
export function compareValues(actual: unknown, operator: CompareOperator, expected: unknown): boolean {
  if (operator === '=' || operator === '!=') {
    const equal = valuesEqual(actual, expected);
    return operator === '=' ? equal : !equal;
  }
  const a = numberOf(actual);
  const b = numberOf(expected);
  if (a === null || b === null) return false;
  switch (operator) {
    case '<':
      return a < b;
    case '>':
      return a > b;
    case '<=':
      return a <= b;
    case '>=':
      return a >= b;
  }
}

function valuesEqual(actual: unknown, expected: unknown): boolean {
  if (actual === undefined || actual === null) return expected === undefined || expected === null || expected === '';
  if (typeof actual === 'boolean') {
    if (typeof expected === 'boolean') return actual === expected;
    return String(expected).trim().toLowerCase() === String(actual);
  }
  if (typeof actual === 'number') {
    const b = numberOf(expected);
    return b !== null && actual === b;
  }
  return String(actual) === String(expected);
}

/** Nó-alvo de uma Condition: `target` vazio = o próprio nó da regra. */
export function resolveTarget(ctx: ConditionContext, target: string | undefined): ConditionNode | undefined {
  const ref = target && target.trim() ? target.trim() : ctx.selfNodeId;
  return ref ? ctx.getNode(ref) : undefined;
}
