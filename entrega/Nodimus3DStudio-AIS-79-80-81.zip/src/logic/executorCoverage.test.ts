import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { LogicRegistry } from './registry';
import { ActionRuntime } from './actionRuntime';
import { BehaviorRuntimeCatalog } from './behaviorRuntime';
import { INPUT_TRIGGER_IDS } from '../runtime/input/inputTriggers';

/**
 * AIS-59c — COBERTURA DE EXECUTORES. Todo item do catálogo de lógica que o picker oferece tem de FAZER algo no Play, ou aparecer
 * desabilitado com "em breve" e um prompt dono registrado (decisão 14: nunca um item habilitado que não faz nada).
 *
 * Origem do teste: o AIS-41 definiu `emit_particles`/`play_animation`/`pause_animation`/`stop_animation` e o AIS-53/AIS-60 deixaram a
 * execução "para o AIS-41" — cada um empurrou para o outro e ninguém criou o executor; os itens ficaram habilitados e mudos. Prompt que
 * registra um item de lógica entrega o executor no MESMO prompt (ou marca `status: 'disabled'` e entra na tabela abaixo).
 */

/** Itens desabilitados ("em breve") e o prompt que os habilita. Entrada sem item desabilitado, ou item desabilitado sem entrada, falha. */
const DISABLED_OWNERS: Record<string, string> = {
  'behavior:follow_cursor': 'SEM PROMPT DONO — decidir onde implementar (precisa da posição do cursor no mundo, vinda da viewport)',
};

/** Behaviors cujo conteúdo é montado pelo usuário (o preset nasce sem regras de propósito). */
const USER_AUTHORED_BEHAVIORS = new Set(['custom_rules']);

describe('cobertura de executores do catálogo (AIS-59c)', () => {
  it('toda Action habilitada tem executor no runtime', () => {
    const missing = LogicRegistry.listActions().filter((a) => a.status !== 'disabled' && !ActionRuntime.get(a.id)).map((a) => a.id);
    expect(missing, `Actions habilitadas SEM executor (crie src/logic/actions/<id>/runtime.ts ou marque status:'disabled' + dono): ${missing.join(', ')}`).toEqual([]);
  });

  it('toda Action desabilitada ("em breve") tem dono registrado e NÃO tem executor (senão habilite-a)', () => {
    for (const a of LogicRegistry.listActions().filter((x) => x.status === 'disabled')) {
      expect(DISABLED_OWNERS[`action:${a.id}`], `Action desabilitada sem dono: ${a.id}`).toBeTruthy();
      expect(ActionRuntime.get(a.id), `A Action "${a.id}" já tem executor: remova status:'disabled' e a entrada da tabela`).toBeUndefined();
    }
  });

  it('todo Behavior habilitado faz algo: runtime por propriedades, regras de preset ou conteúdo montado pelo usuário', () => {
    const idle: string[] = [];
    for (const b of LogicRegistry.listBehaviors()) {
      if (b.status === 'disabled' || USER_AUTHORED_BEHAVIORS.has(b.id) || BehaviorRuntimeCatalog.get(b.id)) continue;
      const created = (b as any).create({ targetNodeId: 'alvo', targetName: 'Alvo', nodeType: 'MeshInstance' });
      if (!created?.rules?.length) idle.push(b.id);
    }
    expect(idle, `Behaviors habilitados que não fazem nada (sem runtime nem regras): ${idle.join(', ')}`).toEqual([]);
  });

  it('todo Behavior desabilitado tem dono registrado', () => {
    for (const b of LogicRegistry.listBehaviors().filter((x) => x.status === 'disabled')) {
      expect(DISABLED_OWNERS[`behavior:${b.id}`], `Behavior desabilitado sem dono: ${b.id}`).toBeTruthy();
    }
  });

  it('a tabela de donos não guarda itens que já não estão desabilitados', () => {
    const live = new Set([
      ...LogicRegistry.listActions().filter((a) => a.status === 'disabled').map((a) => `action:${a.id}`),
      ...LogicRegistry.listBehaviors().filter((b) => b.status === 'disabled').map((b) => `behavior:${b.id}`),
    ]);
    expect(Object.keys(DISABLED_OWNERS).filter((k) => !live.has(k))).toEqual([]);
  });

  it('todo Trigger é despachado: pelo runner ou pelos Triggers de entrada', () => {
    const source = readFileSync('src/runtime/logicRunner.ts', 'utf8');
    const input = new Set(INPUT_TRIGGER_IDS);
    const never = LogicRegistry.listTriggers()
      .filter((t) => t.status !== 'disabled' && !input.has(t.id) && !source.includes(`'${t.id}'`))
      .map((t) => t.id);
    expect(never, `Triggers que nunca são despachados: ${never.join(', ')}`).toEqual([]);
  });
});
