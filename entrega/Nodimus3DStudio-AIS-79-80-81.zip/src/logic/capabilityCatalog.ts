import { buildCatalog, unsupportedFor, type CatalogEntry, type PublishTarget } from '../core/capabilities';
import { NODE_DEFINITIONS } from '../nodes/registry';
import { ENGINE_OPERATIONS } from '../runtime/engineApi';
import { LogicRegistry } from './registry';

/**
 * AIS-78c — o catálogo VIVO de capacidades: agrega o `LogicRegistry` (pastas de `src/logic/`, decisão 21), o `NODE_DEFINITIONS` (decisão 19) e as
 * operações da `EngineApi` sem copiar nenhum deles. É o que o Publish (AIS-85/85b) consulta; as definições continuam a única fonte dos `requires`.
 */
export function liveCapabilityCatalog(): CatalogEntry[] {
  return buildCatalog({ logic: LogicRegistry, nodes: NODE_DEFINITIONS as unknown as Record<string, { name?: string; requires?: readonly unknown[] }>, engine: ENGINE_OPERATIONS });
}

/** Itens (lógica, nós e operações) que o target não suporta por inteiro. */
export function liveUnsupportedFor(target: PublishTarget) {
  return unsupportedFor(liveCapabilityCatalog(), target);
}
