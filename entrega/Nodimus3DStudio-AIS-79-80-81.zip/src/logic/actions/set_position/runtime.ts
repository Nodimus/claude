import type { ActionExecutor } from '../../types';
import { isUiInstance } from '../../actionRuntimeHelpers';

/** Teleporta o nó dono (UI: grava os offsets `posX/posY` do layout). */
const run: ActionExecutor<{ x: number; y: number; z: number }> = ({ x, y, z }, ctx) => {
  const node = ctx.self;
  if (isUiInstance(node)) {
    node.properties.posX = x;
    node.properties.posY = y;
    ctx.markUiDirty();
    return;
  }
  node.transform.position = [x, y, z];
  ctx.applyTransform(node);
};
export default run;
