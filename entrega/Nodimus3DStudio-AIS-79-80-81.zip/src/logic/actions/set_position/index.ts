import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'set_position',
  label: 'Teleport To Position',
  description: 'Teleporta o nó para uma posição absoluta (Overlay2D: offsets do layout; o Z some).',
  category: 'Movement',
  params: [
    { key: 'x', label: 'X', type: 'number', default: 0 },
    { key: 'y', label: 'Y', type: 'number', default: 0 },
    { key: 'z', label: 'Z', type: 'number', default: 0, hideForUi: true },
  ],
  paramsSchema: z.object({
    x: z.coerce.number().default(0),
    y: z.coerce.number().default(0),
    z: z.coerce.number().default(0),
  }),
});
