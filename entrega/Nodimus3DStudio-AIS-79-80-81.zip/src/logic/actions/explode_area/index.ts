import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'explode_area',
  label: 'Explode Area',
  description: 'Dano e impulso em um raio ao redor do centro: cada alvo é atingido uma vez; o impulso cai do centro até a borda. Ignora o próprio nó (e filhos) e respeita Ignore/Only Tags.',
  category: 'Physics',
  requires: ['requiresPhysics'],
  params: [
    { key: 'center', label: 'Center', type: 'node', default: '', emptyLabel: '(este nó)' },
    { key: 'radius', label: 'Radius (m)', type: 'number', default: 5 },
    { key: 'damage', label: 'Damage', type: 'number', default: 25 },
    { key: 'damageVariable', label: 'Damage Variable', type: 'string', default: 'health' },
    { key: 'impulse', label: 'Impulse (N·s)', type: 'number', default: 10 },
    { key: 'ignoreTags', label: 'Ignore Tags (a, b)', type: 'string', default: '' },
    { key: 'onlyTags', label: 'Only Tags (a, b)', type: 'string', default: '' },
  ],
  paramsSchema: z.object({
    center: z.string().default(''),
    radius: z.coerce.number().default(5),
    damage: z.coerce.number().default(25),
    damageVariable: z.string().default('health'),
    impulse: z.coerce.number().default(10),
    ignoreTags: z.string().default(''),
    onlyTags: z.string().default(''),
  }),
});
