import { z } from 'zod';
import { defineAction } from '../../types';
import { requireNodeType } from '../../actionHelpers';

export default defineAction({
  id: 'play_sprite_animation',
  label: 'Play Sprite Animation',
  description: 'Toca uma animação do Sprite Project de um Billboard (como AnimatedSprite3D.play): troca o clipe, reinicia o tempo e aplica a velocidade. Animação vazia = a padrão do recurso.',
  category: 'Visual',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'animation', label: 'Animação', type: 'enum', default: '', optionsFrom: 'animations', inline: { prefix: 'anim:', width: 'sm' } },
    { key: 'restart', label: 'Reiniciar', type: 'boolean', default: true },
    { key: 'speedScale', label: 'Speed Scale', type: 'number', default: 1 },
    { key: 'fromEnd', label: 'Começar pelo fim', type: 'boolean', default: false },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    animation: z.string().default(''),
    restart: z.boolean().default(true),
    speedScale: z.coerce.number().min(0).max(10).default(1),
    fromEnd: z.boolean().default(false),
  }),
  validate: requireNodeType('Play Sprite Animation', ['Billboard']),
});
