import { describe, expect, it } from 'vitest';
import { SpriteHost } from '../../../runtime/spriteHost';
import { buildEngineApi } from '../../../runtime/engineApi';
import run from './runtime';

/** O contexto do executor traz a `EngineApi` (decisão 32); o host injeta o SpriteHost e o log da sessão. */
function engineOf(node: any, sprites: SpriteHost | null, log: (level: string, message: string, options?: { code?: string }) => void) {
  const noop = () => undefined;
  return buildEngineApi({
    instanceById: (ref: string) => (ref === node.persistentNodeId ? node : undefined),
    instanceByName: () => undefined,
    variables: () => null,
    input: () => ({}) as never,
    physics: () => null,
    sceneTime: () => 0,
    emitSignal: noop,
    connectSignal: () => noop,
    onPhysicsEvent: () => noop,
    log: (level: any, message: string, _n: unknown, options?: { code?: string }) => log(level, message, options),
    commitTransform: noop,
    sprites: () => sprites,
  } as never);
}

/** AIS-76b — play_sprite_animation com handle simulado (contexto mínimo): troca, restart, speedScale, diagnósticos sem exceção, authoring intocado. */
const CLIPS = [
  { name: 'idle', frameIndices: [0, 1, 2], fps: 10, loopMode: 'loop' as const },
  { name: 'hit', frameIndices: [4, 5], fps: 10, loopMode: 'once' as const },
];

function setup(nodeProps: Record<string, unknown> = { spriteProject: { id: 'r' } }, type = 'Billboard') {
  const sprites = new SpriteHost();
  sprites.register('n', { clips: CLIPS, defaultAnimation: 'idle' });
  const node = { persistentNodeId: 'n', name: 'Heroi', type, disposed: false, properties: { ...nodeProps } };
  const logs: { level: string; message: string; code?: string }[] = [];
  const log = (level: string, message: string, o?: { code?: string }) => logs.push({ level, message, code: o?.code });
  const ctx = { engine: engineOf(node, sprites, log), resolve: () => node, log } as any;
  const call = (p: Partial<{ animation: string; restart: boolean; speedScale: number; fromEnd: boolean }>) => (run as any)({ target: '', animation: '', restart: true, speedScale: 1, fromEnd: false, ...p }, ctx);
  return { sprites, node, logs, call };
}
const tick = (h: SpriteHost, seconds: number) => {
  for (let t = 0; t < seconds - 1e-9; t += 1 / 60) h.step(1 / 60);
};

describe('play_sprite_animation (executor)', () => {
  it('troca a animação e reinicia o tempo', () => {
    const { sprites, call } = setup();
    tick(sprites, 0.25);
    call({ animation: 'hit' });
    expect(sprites.animationOf('n')).toBe('hit');
    expect(sprites.frameOf('n')).toBe(4);
  });
  it('restart:false na mesma animação não reinicia', () => {
    const { sprites, call } = setup();
    tick(sprites, 0.25);
    const before = sprites.frameOf('n');
    call({ animation: 'idle', restart: false });
    expect(sprites.frameOf('n')).toBe(before);
  });
  it('speedScale altera o frame no mesmo tempo decorrido', () => {
    const slow = setup();
    const fast = setup();
    slow.call({ animation: 'idle', speedScale: 1 });
    fast.call({ animation: 'idle', speedScale: 2 });
    tick(slow.sprites, 0.13);
    tick(fast.sprites, 0.13);
    expect(slow.sprites.frameOf('n')).toBe(1);
    expect(fast.sprites.frameOf('n')).toBe(2);
  });
  it('fromEnd começa no último quadro', () => {
    const { sprites, call } = setup();
    call({ animation: 'idle', fromEnd: true });
    expect(sprites.frameOf('n')).toBe(2);
  });
  it('animação inexistente: diagnóstico, a atual continua, sem exceção', () => {
    const { sprites, logs, call } = setup();
    expect(() => call({ animation: 'zzz' })).not.toThrow();
    expect(sprites.animationOf('n')).toBe('idle');
    expect(logs[0]).toMatchObject({ level: 'error', code: 'sprite.unknown_animation' });
  });
  it('alvo que não é Billboard, ou sem Sprite Project: diagnóstico e nada muda', () => {
    const a = setup({ spriteProject: { id: 'r' } }, 'MeshInstance');
    a.call({ animation: 'hit' });
    expect(a.logs[0].code).toBe('sprite.invalid_target');
    expect(a.sprites.animationOf('n')).toBe('idle');
    const b = setup({ spriteProject: null });
    b.call({ animation: 'hit' });
    expect(b.logs[0].code).toBe('sprite.invalid_target');
  });
  it('grava só as propriedades VIVAS do handle (a instância, não o authoring)', () => {
    const { node, call } = setup();
    call({ animation: 'hit', speedScale: 2 });
    expect(node.properties).toMatchObject({ animation: 'hit', speedScale: 2, autoplay: true });
  });
  it('sem host de sprites na sessão: erro explícito, sem exceção', () => {
    const logs: any[] = [];
    const node = { persistentNodeId: 'n', name: 'X', type: 'Billboard', properties: { spriteProject: { id: 'r' } } };
    expect(() => (run as any)({ target: '', animation: '', restart: true, speedScale: 1, fromEnd: false }, { engine: engineOf({ ...node, disposed: false }, null, () => undefined), resolve: () => ({ ...node, disposed: false }), log: (...a: any[]) => logs.push(a) })).not.toThrow();
    expect(logs[0][2]).toMatchObject({ code: 'sprite.unavailable' });
  });
});
