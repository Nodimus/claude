import type { ActionExecutor } from '../../types';
import { logServiceFailure, resolveSpriteTarget } from '../../actionRuntimeHelpers';

/**
 * AIS-76b — `play_sprite_animation` pela `EngineApi.sprites` (decisão 32): o serviço troca o clipe no `SpriteHost` da sessão (tempo de
 * `clipFrameIndexAtTime`), grava as propriedades VIVAS do nó (estado de sessão, nunca do authoring) e adia o pedido até o sprite carregar.
 * Animação inexistente → diagnóstico e a atual continua.
 */
const run: ActionExecutor<{ target: string; animation: string; restart: boolean; speedScale: number; fromEnd: boolean }> = (params, ctx) => {
  const node = resolveSpriteTarget('Play Sprite Animation', params.target, ctx);
  if (!node) return;
  const result = ctx.engine.sprites.play(node.persistentNodeId, { animation: params.animation, restart: params.restart, speedScale: params.speedScale, fromEnd: params.fromEnd });
  // animação inexistente: o próprio serviço já registrou o diagnóstico (com as disponíveis); aqui não se duplica
  if (!result.ok && result.code !== 'sprite.unknown_animation') logServiceFailure('Play Sprite Animation', ctx, result);
};
export default run;
