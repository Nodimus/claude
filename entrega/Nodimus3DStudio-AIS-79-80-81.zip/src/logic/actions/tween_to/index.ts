import { z } from 'zod';
import { defineAction } from '../../types';
import { EASING_NAMES } from '../../../animation/easing';
import { TWEEN_PROPERTIES } from '../../../runtime/propertyTweens';

/**
 * AIS-59 — "opção animada" de Change Position/Rotation/Scale/Color/Opacity: interpola a propriedade do nó ao longo do tempo
 * (curvas, atraso, ida e volta) sem travar a cadeia (fire-and-continue). `onCompleteSignal` emite um sinal global ao terminar:
 * com `on_signal` é assim que se ENCADEIA um passo no outro (o encadeamento do motor, na lógica visual).
 */
export default defineAction({
  id: 'tween_to',
  label: 'Tween Property',
  description: 'Anima posição, rotação, escala, cor ou opacidade do nó ao longo do tempo, com curva de transição.',
  category: 'Movement',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'property', label: 'Property', type: 'enum', default: 'position', options: [...TWEEN_PROPERTIES], inline: { width: 'sm' } },
    { key: 'x', label: 'X', type: 'number', default: 0, visibleWhen: { key: 'property', oneOf: ['position', 'rotation', 'scale'] }, inline: { prefix: 'x:', width: 'xs' } },
    { key: 'y', label: 'Y', type: 'number', default: 0, visibleWhen: { key: 'property', oneOf: ['position', 'rotation', 'scale'] }, inline: { prefix: 'y:', width: 'xs' } },
    { key: 'z', label: 'Z', type: 'number', default: 0, visibleWhen: { key: 'property', oneOf: ['position', 'rotation', 'scale'] }, hideForUi: true },
    { key: 'color', label: 'Color', type: 'string', default: '#ffffff', visibleWhen: { key: 'property', equals: 'color' } },
    { key: 'opacity', label: 'Opacity (0-1)', type: 'number', default: 1, visibleWhen: { key: 'property', equals: 'opacity' } },
    { key: 'relative', label: 'Relative (add to current)', type: 'boolean', default: false },
    { key: 'duration', label: 'Duration (s)', type: 'number', default: 1, inline: { prefix: 'em', width: 'xs' } },
    { key: 'delay', label: 'Delay (s)', type: 'number', default: 0 },
    { key: 'easing', label: 'Easing', type: 'enum', default: 'Linear', options: [...EASING_NAMES] },
    { key: 'loop', label: 'Loop', type: 'enum', default: 'once', options: ['once', 'loop', 'pingpong'] },
    { key: 'onCompleteSignal', label: 'Signal when done', type: 'string', default: '' },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    property: z.enum(TWEEN_PROPERTIES).default('position'),
    x: z.coerce.number().default(0),
    y: z.coerce.number().default(0),
    z: z.coerce.number().default(0),
    color: z.string().default('#ffffff'),
    opacity: z.coerce.number().min(0).max(1).default(1),
    relative: z.boolean().default(false),
    duration: z.coerce.number().min(0, 'A duração não pode ser negativa.').default(1),
    delay: z.coerce.number().min(0, 'O atraso não pode ser negativo.').default(0),
    easing: z.enum(EASING_NAMES).default('Linear'),
    loop: z.enum(['once', 'loop', 'pingpong']).default('once'),
    onCompleteSignal: z.string().default(''),
  }),
});
