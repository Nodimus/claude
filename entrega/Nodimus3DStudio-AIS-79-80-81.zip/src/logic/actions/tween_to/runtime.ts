import type { ActionExecutor } from '../../types';
import { resolveTarget } from '../../actionRuntimeHelpers';
import type { PropertyTweenRequest, TweenProperty } from '../../../runtime/propertyTweens';
import type { LoopMode } from '../../../animation/tweener';
import { tNow } from '../../../core/i18n';

interface Params {
  target: string;
  property: TweenProperty;
  x: number;
  y: number;
  z: number;
  color: string;
  opacity: number;
  relative: boolean;
  duration: number;
  delay: number;
  easing: string;
  loop: LoopMode;
  onCompleteSignal: string;
}

/**
 * Inicia o tween e segue (a cadeia não espera). Um novo tween da mesma propriedade do mesmo nó substitui o anterior. `loop`
 * infinito só termina com Stop/Restart. Erro (nó sem material, corpo físico, cor inválida…) é log explícito, nunca silêncio.
 */
const run: ActionExecutor<Params> = (p, ctx) => {
  const node = resolveTarget('Tween Property', p.target, ctx);
  if (!node) return;
  const signal = p.onCompleteSignal.trim();
  const to: PropertyTweenRequest['to'] = p.property === 'color' ? p.color : p.property === 'opacity' ? p.opacity : { x: p.x, y: p.y, z: p.z };
  const result = ctx.engine.tweens.start(node.persistentNodeId, {
    property: p.property,
    to,
    relative: p.relative,
    duration: p.duration,
    delay: p.delay,
    easing: p.easing,
    loop: p.loop,
    onCompleteSignal: signal || undefined,
  });
  if (!result.ok) ctx.log('error', tNow('runtimeMsgCore.tweenProperty', { message: result.message }), { code: result.code === 'tween.unavailable' ? 'tween.unavailable' : 'tween.failed' });
};
export default run;
