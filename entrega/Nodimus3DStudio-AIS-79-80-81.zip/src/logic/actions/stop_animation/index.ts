import { z } from 'zod';
import { defineAction } from '../../types';
import { requireNodeType } from '../../actionHelpers';

export default defineAction({
  id: 'stop_animation',
  label: 'Stop Animation',
  description: 'Para a animação do objeto animado e volta ao primeiro quadro.',
  category: 'Visual',
  params: [{ key: 'target', label: 'Target', type: 'node', default: '' }],
  paramsSchema: z.object({ target: z.string().default('') }),
  validate: requireNodeType('Stop Animation', ['MeshInstance']),
});
