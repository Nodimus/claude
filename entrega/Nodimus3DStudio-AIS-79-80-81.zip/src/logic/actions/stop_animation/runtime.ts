import type { ActionExecutor } from '../../types';
import { logServiceFailure, resolveAnimatedObject } from '../../actionRuntimeHelpers';

/** Para a animação do objeto animado do alvo pela `EngineApi.animation`. */
const run: ActionExecutor<{ target: string }> = (params, ctx) => {
  const object = resolveAnimatedObject('Stop Animation', params.target, ctx);
  if (!object) return;
  const result = ctx.engine.animation.stop(object.persistentNodeId);
  if (!result.ok) logServiceFailure('Stop Animation', ctx, result);
};
export default run;
