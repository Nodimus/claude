import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'set_variable',
  label: 'Set Variable',
  description: 'Define o valor de uma variável Global ou Local (Target vazio = o nó dono da regra).',
  category: 'Logic',
  params: [
    { key: 'scope', label: 'Scope', type: 'enum', default: 'global', options: ['global', 'local'] },
    { key: 'target', label: 'Target', type: 'node', default: '', visibleWhen: { key: 'scope', equals: 'local' } },
    { key: 'variable', label: 'Variable', type: 'string', default: '', required: true, variable: true },
    { key: 'value', label: 'Value', type: 'string', default: '' },
  ],
  paramsSchema: z.object({
    scope: z.enum(['global', 'local']).default('global'),
    target: z.string().default(''),
    variable: z.string().default(''),
    value: z.union([z.string(), z.number(), z.boolean()]).default(''),
  }),
});
