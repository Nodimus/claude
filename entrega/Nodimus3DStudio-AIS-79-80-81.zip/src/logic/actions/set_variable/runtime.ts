import type { ActionExecutor } from '../../types';
import { runVariableAction } from '../../variableActionRuntime';

const run: ActionExecutor<{ scope: 'global' | 'local'; target: string; variable: string; value: string | number | boolean }> = (p, ctx) =>
  runVariableAction('Set Variable', p, ctx, (vars, scope, name, nodeId) =>
    vars.setVariable(scope, name, typeof p.value === 'string' ? ctx.interpolate(p.value) : p.value, nodeId)
  );
export default run;
