import type { ActionExecutor } from '../../types';
import { resolveTarget } from '../../actionRuntimeHelpers';

const run: ActionExecutor<{ target: string; texture: string }> = ({ target, texture }, ctx) => {
  const node = resolveTarget('Change Texture', target, ctx);
  if (!node) return;
  node.properties.texture = texture;
  ctx.markUiDirty();
};
export default run;
