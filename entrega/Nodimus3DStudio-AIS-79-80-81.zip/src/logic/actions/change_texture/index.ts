import { z } from 'zod';
import { defineAction } from '../../types';
import { requireNodeType } from '../../actionHelpers';

export default defineAction({
  id: 'change_texture',
  label: 'Change Texture',
  description: 'Troca a textura/imagem de um overlay 2D (alias: change_image).',
  category: 'Visual',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'texture', label: 'Texture', type: 'file', default: '', accept: ['.png', '.jpg', '.jpeg', '.webp'], required: true },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    texture: z.string().default(''),
    image: z.string().optional(),
  }),
  validate: requireNodeType('Change Texture', ['Overlay2D', 'ButtonOverlay2D']),
});
