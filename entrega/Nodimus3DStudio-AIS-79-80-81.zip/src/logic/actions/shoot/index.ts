import { z } from 'zod';
import { defineAction } from '../../types';

/**
 * AIS-71: disparo da IA — só CONFIGURAÇÃO simples sobre o núcleo de armas (AIS-69). Sem cadência, munição nem recarga (para isso o ator usa o
 * `weapon_controller`). Ligue-a ao gancho "On AI Attack" do AI State Machine.
 */
export default defineAction({
  id: 'shoot',
  label: 'Shoot',
  description:
    'Ataque da IA em UM alvo: com Bullet (prefab) dispara um projétil físico em direção ao alvo; com Fire Mode "hitscan", um raycast; sem Bullet, aplica o dano direto. Alvo vazio = o alvo atual do AI State Machine deste nó (sem alvo, falha com erro). Usa o mesmo núcleo de armas do Weapon Controller; sem cadência, munição ou recarga.',
  category: 'AI',
  requires: ['requiresPhysics'],
  params: [
    { key: 'bullet', label: 'Bullet (prefab; empty = direct damage)', type: 'file', default: '', accept: ['.prefab.json'], root: 'res://prefabs/' },
    { key: 'damage', label: 'Damage', type: 'number', default: 10 },
    { key: 'damageVariable', label: 'Damage Variable', type: 'string', default: 'health' },
    { key: 'shootPositionDisplacement', label: 'Shoot Position Displacement', type: 'vector3', default: { x: 0, y: 0, z: 0 } },
    { key: 'fireMode', label: 'Fire Mode', type: 'enum', default: 'physical', options: ['physical', 'hitscan'] },
    { key: 'target', label: 'Target', type: 'node', default: '', emptyLabel: '(alvo atual da IA)' },
  ],
  paramsSchema: z.object({
    bullet: z.string().default(''),
    damage: z.coerce.number().default(10),
    damageVariable: z.string().default('health'),
    shootPositionDisplacement: z.object({ x: z.coerce.number().default(0), y: z.coerce.number().default(0), z: z.coerce.number().default(0) }).default({ x: 0, y: 0, z: 0 }),
    fireMode: z.enum(['physical', 'hitscan']).default('physical'),
    target: z.string().default(''),
  }),
});
