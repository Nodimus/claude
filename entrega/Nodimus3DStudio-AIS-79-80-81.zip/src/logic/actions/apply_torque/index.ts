import { z } from 'zod';
import { defineAction } from '../../types';
import { requirePhysicsBody, vec3Schema } from '../../actionHelpers';

export default defineAction({
  id: 'apply_torque',
  label: 'Apply Torque',
  description: 'Aplica torque ao corpo (contínuo ou impulso angular). Só corpos "dynamic".',
  category: 'Physics',
  requires: ['requiresPhysics'],
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'torque', label: 'Torque', type: 'vector3', default: { x: 0, y: 1, z: 0 } },
    { key: 'mode', label: 'Mode', type: 'enum', default: 'continuous', options: ['continuous', 'impulse'] },
    { key: 'space', label: 'Space', type: 'enum', default: 'world', options: ['world', 'local'] },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    torque: vec3Schema(0, 1, 0),
    mode: z.enum(['continuous', 'impulse']).default('continuous'),
    space: z.enum(['world', 'local']).default('world'),
  }),
  validate: requirePhysicsBody('Apply Torque', ['dynamic']),
});
