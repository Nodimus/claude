import type { ActionExecutor } from '../../types';
import { runPhysics } from '../../actionRuntimeHelpers';

/** Torque contínuo (sustentado a cada quadro) ou impulso angular. Só corpos `dynamic`. */
const run: ActionExecutor<{ target: string; torque: { x: number; y: number; z: number }; mode: 'continuous' | 'impulse'; space: 'world' | 'local' }> = ({ target, torque, mode, space }, ctx) =>
  runPhysics('Apply Torque', target, ctx, (bridge, id) => bridge.applyTorque(id, torque, mode, space));
export default run;
