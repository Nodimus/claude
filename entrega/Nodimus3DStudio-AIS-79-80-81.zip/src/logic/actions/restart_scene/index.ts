import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'restart_scene',
  label: 'Restart Scene',
  description: 'Reinicia a cena atual (aborta o restante da cadeia).',
  category: 'Scene',
  params: [],
  paramsSchema: z.object({}),
});
