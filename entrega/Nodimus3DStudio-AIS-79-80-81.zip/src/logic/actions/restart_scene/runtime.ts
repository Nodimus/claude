import type { ActionExecutor } from '../../types';

/** Pede o reinício da cena (feito depois da cadeia; esta é abortada). */
const run: ActionExecutor<Record<string, never>> = (_p, ctx) => {
  ctx.engine.scene.restart();
  return 'stop';
};
export default run;
