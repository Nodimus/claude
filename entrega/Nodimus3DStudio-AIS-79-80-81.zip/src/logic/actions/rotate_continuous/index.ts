import { z } from 'zod';
import { defineAction } from '../../types';
import { require3dNode } from '../../actionHelpers';

export default defineAction({
  id: 'rotate_continuous',
  label: 'Rotate Continuous',
  description: 'Gira o nó continuamente em torno de um eixo (graus por segundo).',
  category: 'Movement',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'axis', label: 'Axis', type: 'enum', default: 'y', options: ['x', 'y', 'z'] },
    { key: 'degreesPerSecond', label: 'Degrees / s', type: 'number', default: 45 },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    axis: z.enum(['x', 'y', 'z']).default('y'),
    degreesPerSecond: z.coerce.number().default(45),
  }),
  validate: require3dNode('Rotate Continuous'),
});
