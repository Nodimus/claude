import type { ActionExecutor } from '../../types';
import { resolveTarget } from '../../actionRuntimeHelpers';

/** Liga a rotação contínua (o runner a aplica a cada quadro, respeitando a pausa); 0°/s a desliga. */
const run: ActionExecutor<{ target: string; axis: 'x' | 'y' | 'z'; degreesPerSecond: number }> = ({ target, axis, degreesPerSecond }, ctx) => {
  const node = resolveTarget('Rotate Continuous', target, ctx);
  if (node) ctx.setContinuousRotation(node, axis, degreesPerSecond);
};
export default run;
