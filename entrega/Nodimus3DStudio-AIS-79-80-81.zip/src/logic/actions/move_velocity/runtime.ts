import type { ActionExecutor } from '../../types';
import { resolveTarget } from '../../actionRuntimeHelpers';

/**
 * Move o nó continuamente por uma velocidade (m/s). Corpo `dynamic`/`character`: a velocidade vai pela ponte física (o corpo é
 * o dono da pose). Qualquer outro nó (sem corpo, `kinematic`, `trigger`): o runner translada a instância a cada quadro e a ponte
 * física segue essa pose. Velocidade zero a para.
 */
const run: ActionExecutor<{ target: string; velocity: { x: number; y: number; z: number }; space: 'world' | 'local' }> = ({ target, velocity, space }, ctx) => {
  const node = resolveTarget('Move With Velocity', target, ctx);
  if (!node) return;
  const mode = ctx.physics?.modeOf(node.persistentNodeId);
  if (mode === 'dynamic' || mode === 'character') {
    try {
      ctx.physics!.setLinearVelocity(node.persistentNodeId, velocity, space);
    } catch (error) {
      ctx.log('error', error instanceof Error ? error.message : String(error));
    }
    return;
  }
  ctx.setContinuousVelocity(node, velocity, space);
};
export default run;
