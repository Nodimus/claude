import { z } from 'zod';
import { defineAction } from '../../types';
import { require3dNode, vec3Schema } from '../../actionHelpers';

export default defineAction({
  id: 'move_velocity',
  label: 'Move With Velocity',
  description: 'Move o nó continuamente por uma velocidade vetorial (metros por segundo).',
  category: 'Movement',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'velocity', label: 'Velocity (m/s)', type: 'vector3', default: { x: 0, y: 0, z: -1 } },
    { key: 'space', label: 'Space', type: 'enum', default: 'world', options: ['world', 'local'] },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    velocity: vec3Schema(0, 0, -1),
    space: z.enum(['world', 'local']).default('world'),
  }),
  validate: require3dNode('Move With Velocity'),
});
