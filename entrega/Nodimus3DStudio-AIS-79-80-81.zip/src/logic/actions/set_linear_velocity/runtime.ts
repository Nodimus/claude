import type { ActionExecutor } from '../../types';
import { runPhysics } from '../../actionRuntimeHelpers';

/** Define a velocidade linear (`dynamic`; em `character` vira o movimento dirigido do controlador). */
const run: ActionExecutor<{ target: string; velocity: { x: number; y: number; z: number }; space: 'world' | 'local' }> = ({ target, velocity, space }, ctx) =>
  runPhysics('Set Linear Velocity', target, ctx, (bridge, id) => bridge.setLinearVelocity(id, velocity, space));
export default run;
