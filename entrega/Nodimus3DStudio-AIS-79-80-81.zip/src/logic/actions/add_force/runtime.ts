import type { ActionExecutor } from '../../types';
import { runPhysics } from '../../actionRuntimeHelpers';

/** Força contínua (sustentada chamando a cada quadro, p.ex. numa regra `on_update`). Só corpos `dynamic`. */
const run: ActionExecutor<{ target: string; force: { x: number; y: number; z: number }; space: 'world' | 'local' }> = ({ target, force, space }, ctx) =>
  runPhysics('Add Force', target, ctx, (bridge, id) => bridge.addForce(id, force, space));
export default run;
