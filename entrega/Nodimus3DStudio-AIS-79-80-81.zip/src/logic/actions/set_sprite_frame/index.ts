import { z } from 'zod';
import { defineAction } from '../../types';
import { requireNodeType } from '../../actionHelpers';

export default defineAction({
  id: 'set_sprite_frame',
  label: 'Set Sprite Frame',
  description: 'Mostra um quadro do atlas de um Billboard (índice global, clampado ao atlas). Com Pausar, a reprodução para nele (como AnimatedSprite3D.frame + pause).',
  category: 'Visual',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'frame', label: 'Quadro (índice no atlas)', type: 'number', default: 0, inline: { prefix: 'frame:', width: 'xs' } },
    { key: 'pause', label: 'Pausar', type: 'boolean', default: true },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    frame: z.coerce.number().default(0),
    pause: z.boolean().default(true),
  }),
  validate: requireNodeType('Set Sprite Frame', ['Billboard']),
});
