import { describe, expect, it } from 'vitest';
import { SpriteHost } from '../../../runtime/spriteHost';
import { buildEngineApi } from '../../../runtime/engineApi';
import run from './runtime';

/** O contexto do executor traz a `EngineApi` (decisão 32); o host injeta o SpriteHost e o log da sessão. */
function engineOf(node: any, sprites: SpriteHost, log: (level: string, message: string, options?: { code?: string }) => void) {
  const noop = () => undefined;
  return buildEngineApi({
    instanceById: (ref: string) => (ref === node.persistentNodeId ? node : undefined),
    instanceByName: () => undefined,
    variables: () => null,
    input: () => ({}) as never,
    physics: () => null,
    sceneTime: () => 0,
    emitSignal: noop,
    connectSignal: () => noop,
    onPhysicsEvent: () => noop,
    log: (level: any, message: string, _n: unknown, options?: { code?: string }) => log(level, message, options),
    commitTransform: noop,
    sprites: () => sprites,
  } as never);
}

/** AIS-76b — set_sprite_frame com handle simulado: clamp ao atlas, arredonda, pausa, adia antes do registro, diagnósticos sem exceção. */
const CLIPS = [{ name: 'idle', frameIndices: [0, 1, 2], fps: 10, loopMode: 'loop' as const }];

function setup(type = 'Billboard', registered = true) {
  const sprites = new SpriteHost();
  if (registered) sprites.register('n', { clips: CLIPS, defaultAnimation: 'idle', frameCount: 6 });
  const node = { persistentNodeId: 'n', name: 'Heroi', type, disposed: false, properties: { spriteProject: { id: 'r' } } };
  const logs: { level: string; message: string; code?: string }[] = [];
  const log = (level: string, message: string, o?: { code?: string }) => logs.push({ level, message, code: o?.code });
  const ctx = { engine: engineOf(node, sprites, log), resolve: () => node, log } as any;
  const call = (p: Partial<{ frame: number; pause: boolean }>) => (run as any)({ target: '', frame: 0, pause: true, ...p }, ctx);
  return { sprites, logs, call };
}

describe('set_sprite_frame (executor)', () => {
  it('mostra o quadro e pausa', () => {
    const { sprites, call } = setup();
    call({ frame: 4 });
    expect(sprites.frameOf('n')).toBe(4);
    expect(sprites.isPlaying('n')).toBe(false);
    for (let i = 0; i < 60; i++) sprites.step(1 / 60);
    expect(sprites.frameOf('n')).toBe(4); // continua parado
  });
  it('clampa ao atlas (com aviso) e arredonda valor não inteiro', () => {
    const { sprites, logs, call } = setup();
    call({ frame: 99 });
    expect(sprites.frameOf('n')).toBe(5);
    expect(logs[0]).toMatchObject({ level: 'warn', code: 'sprite.frame_clamped' });
    call({ frame: -3 });
    expect(sprites.frameOf('n')).toBe(0);
    call({ frame: 2.6 });
    expect(sprites.frameOf('n')).toBe(3);
  });
  it('antes de o sprite carregar o pedido é adiado e roda no registro', () => {
    const { sprites, call } = setup('Billboard', false);
    call({ frame: 3 });
    sprites.register('n', { clips: CLIPS, defaultAnimation: 'idle', frameCount: 6 });
    expect(sprites.frameOf('n')).toBe(3);
  });
  it('alvo inválido: diagnóstico e nada muda', () => {
    const { sprites, logs, call } = setup('Spatial');
    expect(() => call({ frame: 4 })).not.toThrow();
    expect(logs[0].code).toBe('sprite.invalid_target');
    expect(sprites.isPlaying('n')).toBe(true);
  });
});
