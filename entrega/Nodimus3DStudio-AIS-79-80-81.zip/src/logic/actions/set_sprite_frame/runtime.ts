import type { ActionExecutor } from '../../types';
import { logServiceFailure, resolveSpriteTarget } from '../../actionRuntimeHelpers';

/** AIS-76b — `set_sprite_frame` pela `EngineApi.sprites`: quadro GLOBAL clampado ao atlas e, com `pause`, a reprodução para nele; pedido adiado até o sprite carregar. */
const run: ActionExecutor<{ target: string; frame: number; pause: boolean }> = (params, ctx) => {
  const node = resolveSpriteTarget('Set Sprite Frame', params.target, ctx);
  if (!node) return;
  const result = ctx.engine.sprites.show(node.persistentNodeId, params.frame, params.pause);
  if (!result.ok) logServiceFailure('Set Sprite Frame', ctx, result);
};
export default run;
