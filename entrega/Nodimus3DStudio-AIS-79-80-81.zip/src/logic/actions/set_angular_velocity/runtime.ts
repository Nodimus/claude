import type { ActionExecutor } from '../../types';
import { runPhysics } from '../../actionRuntimeHelpers';

const run: ActionExecutor<{ target: string; velocity: { x: number; y: number; z: number } }> = ({ target, velocity }, ctx) =>
  runPhysics('Set Angular Velocity', target, ctx, (bridge, id) => bridge.setAngularVelocity(id, velocity));
export default run;
