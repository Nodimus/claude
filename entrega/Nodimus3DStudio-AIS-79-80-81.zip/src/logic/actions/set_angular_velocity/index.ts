import { z } from 'zod';
import { defineAction } from '../../types';
import { requirePhysicsBody, vec3Schema } from '../../actionHelpers';

export default defineAction({
  id: 'set_angular_velocity',
  label: 'Set Angular Velocity',
  description: 'Define a velocidade angular do corpo (rad/s). Só corpos "dynamic".',
  category: 'Physics',
  requires: ['requiresPhysics'],
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'velocity', label: 'Velocity (rad/s)', type: 'vector3', default: { x: 0, y: 0, z: 0 } },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    velocity: vec3Schema(0, 0, 0),
  }),
  validate: requirePhysicsBody('Set Angular Velocity', ['dynamic']),
});
