import { z } from 'zod';
import { defineAction } from '../../types';
import { requireNodeType } from '../../actionHelpers';

export default defineAction({
  id: 'pause_animation',
  label: 'Pause Animation',
  description: 'Pausa ou retoma a animação do nó.',
  category: 'Visual',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'paused', label: 'Paused', type: 'boolean', default: true },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    paused: z.boolean().default(true),
  }),
  validate: requireNodeType('Pause Animation', ['MeshInstance']),
});
