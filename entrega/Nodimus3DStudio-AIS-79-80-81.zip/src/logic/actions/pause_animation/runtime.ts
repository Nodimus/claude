import type { ActionExecutor } from '../../types';
import { logServiceFailure, resolveAnimatedObject } from '../../actionRuntimeHelpers';

/** Pausa/retoma a animação do objeto animado do alvo pela `EngineApi.animation`. */
const run: ActionExecutor<{ target: string; paused: boolean }> = (params, ctx) => {
  const player = resolveAnimatedObject('Pause Animation', params.target, ctx);
  if (!player) return;
  const result = ctx.engine.animation.pause(player.persistentNodeId, params.paused);
  if (!result.ok) logServiceFailure('Pause Animation', ctx, result);
};
export default run;
