import { z } from 'zod';
import { defineAction } from '../../types';
import { requireNodeType } from '../../actionHelpers';

export default defineAction({
  id: 'set_emissive_color',
  label: 'Set Emissive Color',
  description: 'Muda a cor (e a intensidade) emissiva do material do nó.',
  category: 'Visual',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'color', label: 'Color (#rrggbb)', type: 'string', default: '#ffffff' },
    { key: 'intensity', label: 'Intensity', type: 'number', default: 1 },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    color: z.string().regex(/^#[0-9a-fA-F]{6}$/).default('#ffffff'),
    intensity: z.coerce.number().default(1),
  }),
  validate: requireNodeType('Set Emissive Color', ['MeshInstance']),
});
