import type { ActionExecutor } from '../../types';
import { logServiceFailure, resolveTarget } from '../../actionRuntimeHelpers';
import { tNow } from '../../../core/i18n';

/** Cor emissiva dos materiais do nó (só no objeto vivo do Play), pela EngineApi.materials. */
const run: ActionExecutor<{ target: string; color: string; intensity: number }> = ({ target, color, intensity }, ctx) => {
  const node = resolveTarget('Set Emissive Color', target, ctx);
  if (!node) return;
  const result = ctx.engine.materials.setEmissive(node.persistentNodeId, color, intensity);
  if (!result.ok) return logServiceFailure('Set Emissive Color', ctx, result);
  if (result.count === 0) ctx.log('warn', tNow('runtimeMsgCore.setEmissiveColorHasNo', { name: node.name }));
};
export default run;
