import { tNow } from '../../../core/i18n';
import type { ActionExecutor } from '../../types';
import { logServiceFailure, resolveTarget } from '../../actionRuntimeHelpers';
import { readPhysics } from '../../../core/physics/physicsConfig';

/**
 * Prende o alvo a um osso do modelo `holder` (vazio = o pai autoral do alvo). O vínculo é estado da sessão (`AttachmentHost`); quem
 * faz o reparent no `Bone` é o apresentador da viewport. O `offset` vira a posição LOCAL ao osso. Alvo/holder inexistente, holder sem
 * modelo ou sessão sem host → erro explícito no log; osso inexistente é avisado pelo apresentador (o modelo é quem conhece os ossos).
 */
const run: ActionExecutor<{ target: string; holder: string; bone: string; offset: { x: number; y: number; z: number } }> = (params, ctx) => {
  const node = resolveTarget('Attach To Bone', params.target, ctx);
  if (!node) return;
  const bone = params.bone.trim();
  if (!bone) return ctx.log('error', tNow('sharedMsgCore.attachToBoneProvideThe'), { code: 'attachment.no_bone' });
  let holderId: string | null = null;
  if (params.holder.trim()) {
    const holder = resolveTarget('Attach To Bone', params.holder, ctx);
    if (!holder) return;
    holderId = holder.persistentNodeId;
  }
  if (holderId === node.persistentNodeId) return ctx.log('error', tNow('runtimeMsgCore.attachToBoneANode'), { code: 'attachment.self' });
  const attached = ctx.engine.attachments.attach(node.persistentNodeId, { holder: holderId, bone });
  if (!attached.ok) return logServiceFailure('Attach To Bone', ctx, attached);
  // corpo físico não acompanha o osso: desliga o dele (o Play já criou o corpo) e avisa
  if (readPhysics(node.properties)?.enabled && ctx.physics) {
    try {
      ctx.physics.setEnabled(node.persistentNodeId, false);
    } catch {
      /* sem corpo ainda (mundo carregando): o host já não cria corpo para nó com attachment autoral; o aviso abaixo basta */
    }
    ctx.log('warn', tNow('runtimeMsgCore.attachToBoneTheCollision', { name: node.name }), { code: 'physics.attached_to_bone' });
  }
  node.transform.position = [params.offset.x, params.offset.y, params.offset.z];
  ctx.applyTransform(node);
};
export default run;
