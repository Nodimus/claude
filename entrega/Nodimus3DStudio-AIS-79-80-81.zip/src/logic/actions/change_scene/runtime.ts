import type { ActionExecutor } from '../../types';
import { tNow } from '../../../core/i18n';

/** Pede a troca de cena à sessão (feita no fim do quadro, depois de abortar as cadeias); o resto da cadeia NÃO roda. */
const run: ActionExecutor<{ scenePath: string }> = ({ scenePath }, ctx) => {
  if (!scenePath.trim()) {
    ctx.log('error', tNow('runtimeMsgCore.changeSceneProvideTheDestination'));
    return;
  }
  ctx.engine.scene.change(scenePath.trim());
  return 'stop';
};
export default run;
