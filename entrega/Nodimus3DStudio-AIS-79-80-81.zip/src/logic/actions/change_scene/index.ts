import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'change_scene',
  label: 'Change Scene',
  description: 'Troca para outra cena (aborta o restante da cadeia).',
  category: 'Scene',
  params: [
    { key: 'scenePath', label: 'Scene', type: 'file', default: '', accept: ['.scene.json'], required: true },
  ],
  paramsSchema: z.object({
    scenePath: z.string().default(''),
  }),
});
