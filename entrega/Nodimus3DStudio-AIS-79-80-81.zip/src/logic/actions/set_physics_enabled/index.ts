import { z } from 'zod';
import { defineAction } from '../../types';
import { requirePhysicsBody } from '../../actionHelpers';

export default defineAction({
  id: 'set_physics_enabled',
  label: 'Set Physics Enabled',
  description: 'Liga ou desliga o corpo físico sem remover o nó.',
  category: 'Physics',
  requires: ['requiresPhysics'],
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'enabled', label: 'Enabled', type: 'boolean', default: true },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    enabled: z.boolean().default(true),
  }),
  validate: requirePhysicsBody('Set Physics Enabled', ['static', 'dynamic', 'kinematic', 'character', 'trigger'], { allowDisabled: true }),
});
