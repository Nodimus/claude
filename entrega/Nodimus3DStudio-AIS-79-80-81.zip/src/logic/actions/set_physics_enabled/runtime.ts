import type { ActionExecutor } from '../../types';
import { runPhysics } from '../../actionRuntimeHelpers';

/** Liga/desliga o corpo sem remover a GameNode. */
const run: ActionExecutor<{ target: string; enabled: boolean }> = ({ target, enabled }, ctx) =>
  runPhysics('Set Physics Enabled', target, ctx, (bridge, id) => bridge.setEnabled(id, enabled));
export default run;
