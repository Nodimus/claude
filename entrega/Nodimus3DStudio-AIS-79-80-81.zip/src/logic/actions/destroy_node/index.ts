import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'destroy_node',
  label: 'Destroy Node',
  description: 'Remove o nó da cena em execução.',
  category: 'Utility',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
  }),
});
