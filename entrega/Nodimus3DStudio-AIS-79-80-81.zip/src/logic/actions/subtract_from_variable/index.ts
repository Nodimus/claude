import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'subtract_from_variable',
  label: 'Subtract From Variable',
  description: 'Subtrai um valor de uma variável Global ou Local (Target vazio = o nó dono da regra).',
  category: 'Logic',
  params: [
    { key: 'scope', label: 'Scope', type: 'enum', default: 'global', options: ['global', 'local'] },
    { key: 'target', label: 'Target', type: 'node', default: '', visibleWhen: { key: 'scope', equals: 'local' } },
    { key: 'variable', label: 'Variable', type: 'string', default: '', required: true, variable: true },
    { key: 'amount', label: 'Amount', type: 'number', default: 1 },
  ],
  paramsSchema: z.object({
    scope: z.enum(['global', 'local']).default('global'),
    target: z.string().default(''),
    variable: z.string().default(''),
    amount: z.coerce.number().default(1),
  }),
});
