import type { ActionExecutor } from '../../types';
import { runVariableAction } from '../../variableActionRuntime';

const run: ActionExecutor<{ scope: 'global' | 'local'; target: string; variable: string; amount: number }> = (p, ctx) =>
  runVariableAction('Subtract From Variable', p, ctx, (vars, scope, name, nodeId) => vars.addToVariable(scope, name, -p.amount, nodeId) !== undefined);
export default run;
