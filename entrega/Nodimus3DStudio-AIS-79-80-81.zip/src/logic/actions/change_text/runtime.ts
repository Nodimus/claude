import type { ActionExecutor } from '../../types';
import { resolveTarget } from '../../actionRuntimeHelpers';

/** Troca o texto de um TextOverlay2D/ButtonOverlay2D (aceita `$variavel$`); só o HUD é redesenhado. */
const run: ActionExecutor<{ target: string; text: string }> = ({ target, text }, ctx) => {
  const node = resolveTarget('Change Text', target, ctx);
  if (!node) return;
  node.properties.text = ctx.interpolate(text);
  ctx.markUiDirty();
};
export default run;
