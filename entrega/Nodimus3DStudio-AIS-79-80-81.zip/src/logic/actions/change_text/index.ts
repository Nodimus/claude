import { z } from 'zod';
import { defineAction } from '../../types';
import { requireNodeType } from '../../actionHelpers';

export default defineAction({
  id: 'change_text',
  label: 'Change Text',
  description: 'Troca o texto de um overlay; aceita interpolação de variável ("Score: $score$").',
  category: 'Visual',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'text', label: 'Text', type: 'string', default: '' },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    text: z.string().default(''),
  }),
  validate: requireNodeType('Change Text', ['TextOverlay2D', 'ButtonOverlay2D']),
});
