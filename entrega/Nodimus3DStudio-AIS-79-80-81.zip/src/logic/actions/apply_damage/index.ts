import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'apply_damage',
  label: 'Apply Damage',
  description: 'Subtrai dano da variável Local do alvo (padrão "health", nunca abaixo de 0) e emite o sinal damage_taken. Variável ausente ou não numérica gera diagnóstico e não altera nada.',
  category: 'Physics',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'amount', label: 'Amount', type: 'number', default: 10 },
    { key: 'variable', label: 'Damage Variable', type: 'string', default: 'health' },
    { key: 'ignoreTags', label: 'Ignore Tags (a, b)', type: 'string', default: '' },
    { key: 'onlyTags', label: 'Only Tags (a, b)', type: 'string', default: '' },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    amount: z.coerce.number().default(10),
    variable: z.string().default('health'),
    ignoreTags: z.string().default(''),
    onlyTags: z.string().default(''),
  }),
});
