import type { ActionExecutor } from '../../types';
import { resolveTarget } from '../../actionRuntimeHelpers';
import { parseTagList } from '../../../runtime/weapons/tags';
import { tNow } from '../../../core/i18n';

/** Dano pelo contrato único (`WeaponService.damage` → `applyDamage`). O dono da regra é a origem (`sourceId`) do `damage_taken`. */
const run: ActionExecutor<{ target: string; amount: number; variable: string; ignoreTags: string; onlyTags: string }> = (p, ctx) => {
  const target = resolveTarget('Apply Damage', p.target, ctx);
  if (!target) return;
  const result = ctx.engine.weapons.damage({ sourceId: ctx.self.persistentNodeId, targetId: target.persistentNodeId, amount: p.amount, variable: p.variable, ignoreTags: parseTagList(p.ignoreTags), onlyTags: parseTagList(p.onlyTags) });
  if ('ok' in result && result.ok === false) ctx.log('error', tNow('runtimeMsgCore.applyDamage', { message: result.message }), { code: result.code });
};
export default run;
