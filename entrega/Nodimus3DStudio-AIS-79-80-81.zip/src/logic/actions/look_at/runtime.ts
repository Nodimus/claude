import type { ActionExecutor } from '../../types';
import { resolveTarget } from '../../actionRuntimeHelpers';

/** Vira o nó alvo para outro nó (se informado) ou para uma posição do mundo, pela EngineApi (como Node3D.look_at, decisão 32). */
const run: ActionExecutor<{ target: string; lookAtNode: string; position: { x: number; y: number; z: number } }> = ({ target, lookAtNode, position }, ctx) => {
  const subject = resolveTarget('Look At', target, ctx);
  if (!subject) return;
  let point: { x: number; y: number; z: number } | undefined = position;
  if (lookAtNode.trim()) {
    const other = resolveTarget('Look At', lookAtNode, ctx);
    if (!other) return;
    point = ctx.engine.transform.worldPosition(other.persistentNodeId);
    if (!point) return; // alvo sem objeto vivo: nada a olhar
  }
  ctx.engine.transform.lookAt(subject.persistentNodeId, point);
};
export default run;
