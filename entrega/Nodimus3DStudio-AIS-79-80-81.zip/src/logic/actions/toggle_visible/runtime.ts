import type { ActionExecutor } from '../../types';
import { isUiInstance, resolveTarget } from '../../actionRuntimeHelpers';

const run: ActionExecutor<{ target: string }> = ({ target }, ctx) => {
  const node = resolveTarget('Toggle Visible', target, ctx);
  if (!node) return;
  node.visible = !node.visible;
  if (node.object) node.object.visible = node.visible;
  if (isUiInstance(node)) ctx.markUiDirty();
};
export default run;
