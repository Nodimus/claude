import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'toggle_visible',
  label: 'Toggle Visible',
  description: 'Alterna a visibilidade do nó.',
  category: 'Visual',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
  }),
});
