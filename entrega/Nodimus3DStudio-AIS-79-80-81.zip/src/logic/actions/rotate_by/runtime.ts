import type { ActionExecutor } from '../../types';

/** Gira o nó dono em torno do eixo Y (graus). */
const run: ActionExecutor<{ degrees: number }> = ({ degrees }, ctx) => {
  const node = ctx.self;
  const [rx, ry, rz] = node.transform.rotation;
  node.transform.rotation = [rx, ry + degrees, rz];
  ctx.applyTransform(node);
};
export default run;
