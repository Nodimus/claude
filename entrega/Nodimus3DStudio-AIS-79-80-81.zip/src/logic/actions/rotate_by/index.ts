import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'rotate_by',
  label: 'Rotate By',
  description: 'Rotaciona o nó por um ângulo relativo (graus).',
  category: 'Movement',
  params: [
    { key: 'degrees', label: 'Degrees', type: 'number', default: 1, inline: { prefix: 'deg:', width: 'sm' } },
  ],
  quickAdd: { label: 'Rotate', order: 3, parameters: { degrees: 2 } },
  paramsSchema: z.object({
    degrees: z.coerce.number().default(1),
  }),
});
