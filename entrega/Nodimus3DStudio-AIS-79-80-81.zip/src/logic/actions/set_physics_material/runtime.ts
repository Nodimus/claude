import type { ActionExecutor } from '../../types';
import { runPhysics } from '../../actionRuntimeHelpers';

const run: ActionExecutor<{ target: string; friction: number; bounce: number }> = ({ target, friction, bounce }, ctx) =>
  runPhysics('Set Physics Material', target, ctx, (bridge, id) => bridge.setMaterial(id, friction, bounce));
export default run;
