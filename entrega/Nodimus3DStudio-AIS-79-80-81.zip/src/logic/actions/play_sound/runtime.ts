import type { ActionExecutor } from '../../types';
import { logServiceFailure, num, resolveTarget } from '../../actionRuntimeHelpers';

/** Toca um som a partir de um emissor (AIS-52), agora pela `EngineApi.audio` (decisão 32). Falha do serviço vira log com o código estável. */
const run: ActionExecutor<{ sound: string; target: string; volume: number; pitch: number; spatial: boolean }> = (params, ctx) => {
  const emitter = resolveTarget('Play Sound', params.target, ctx);
  if (!emitter) return;
  const result = ctx.engine.audio.play(emitter.persistentNodeId, { path: params.sound, volume: num(params.volume, 1), pitch: num(params.pitch, 1), spatial: params.spatial !== false });
  if (!result.ok) logServiceFailure('Play Sound', ctx, result);
};
export default run;
