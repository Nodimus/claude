import type { ActionExecutor } from '../../types';
import { resolveTarget } from '../../actionRuntimeHelpers';
import { parseTagList } from '../../../runtime/weapons/tags';

/**
 * Dispara uma vez pelo NÚCLEO de armas da sessão (`WeaponService.fire` → `fireWeapon`): o MESMO caminho do Behavior Weapon Controller e
 * da `Shoot` da IA. Falha (prefab não carregado, Firepoint inexistente, sem física…) vira erro explícito no log, nunca silêncio.
 */
const run: ActionExecutor<{
  target: string;
  mode: 'physical' | 'hitscan';
  firepoint: string;
  aimTarget: string;
  bullet: string;
  impactEffect: string;
  speed: number;
  damage: number;
  damageVariable: string;
  range: number;
  rangeMode: 'distance' | 'time';
  lifetimeMs: number;
  facesMotion: boolean;
  collisionDestroyDelayMs: number;
  ignoreTags: string;
  onlyTags: string;
}> = (p, ctx) => {
  const shooter = resolveTarget('Fire Projectile', p.target, ctx);
  if (!shooter) return;
  const result = ctx.engine.weapons.fire({
    sourceId: shooter.persistentNodeId,
    mode: p.mode,
    firepoint: p.firepoint,
    aimTarget: p.aimTarget,
    bullet: p.bullet,
    impactEffect: p.impactEffect,
    speed: p.speed,
    damage: p.damage,
    damageVariable: p.damageVariable,
    range: p.range,
    rangeMode: p.rangeMode,
    lifetimeMs: p.lifetimeMs,
    facesMotion: p.facesMotion,
    collisionDestroyDelayMs: p.collisionDestroyDelayMs,
    ignoreTags: parseTagList(p.ignoreTags),
    onlyTags: parseTagList(p.onlyTags),
  });
  if (!result.ok) ctx.log('error', result.message, { code: result.code });
};
export default run;
