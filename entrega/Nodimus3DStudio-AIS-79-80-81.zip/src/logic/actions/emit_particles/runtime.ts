import type { ActionExecutor } from '../../types';
import { logServiceFailure } from '../../actionRuntimeHelpers';
import { tNow } from '../../../core/i18n';

/** Rajada de partículas num ParticleSystem (AIS-59c) pela `EngineApi.particles`; o estado da simulação continua no apresentador da viewport. */
const run: ActionExecutor<{ targetNodeId: string; count: number }> = (params, ctx) => {
  const target = params.targetNodeId ? ctx.resolve(params.targetNodeId) : undefined;
  if (!target) return ctx.log('error', tNow('runtimeMsgCore.emitParticlesTheParticlesystemDoes', { value: params.targetNodeId || '(vazio)' }), { code: 'particles.no_target' });
  const result = ctx.engine.particles.burst(target.persistentNodeId, params.count);
  if (!result.ok) logServiceFailure('Emit Particles', ctx, result);
};
export default run;
