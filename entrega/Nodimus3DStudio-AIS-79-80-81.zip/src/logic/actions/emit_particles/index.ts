import { z } from 'zod';
import { defineAction } from '../../types';
import { requireNodeType } from '../../actionHelpers';

export default defineAction({
  id: 'emit_particles',
  label: 'Emit Particles',
  description: 'Emite uma rajada de partículas no ParticleSystem indicado (motor único, AIS-18c).',
  category: 'Visual',
  params: [
    { key: 'targetNodeId', label: 'Particle system', type: 'node', default: '', required: true },
    { key: 'count', label: 'Count', type: 'number', default: 20 },
  ],
  paramsSchema: z.object({
    targetNodeId: z.string().default(''),
    count: z.coerce.number().int().min(1).default(20),
  }),
  validate: requireNodeType('Emit Particles', ['ParticleSystem']),
});
