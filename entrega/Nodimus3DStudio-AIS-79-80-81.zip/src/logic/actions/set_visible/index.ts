import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'set_visible',
  label: 'Set Visible',
  description: 'Mostra ou oculta o nó.',
  category: 'Visual',
  params: [
    { key: 'visible', label: 'Visible', type: 'boolean', default: true },
  ],
  paramsSchema: z.object({
    visible: z.boolean().default(true),
  }),
});
