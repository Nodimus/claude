import type { ActionExecutor } from '../../types';
import { isUiInstance } from '../../actionRuntimeHelpers';

const run: ActionExecutor<{ visible: boolean }> = ({ visible }, ctx) => {
  const node = ctx.self;
  node.visible = visible;
  if (node.object) node.object.visible = visible;
  if (isUiInstance(node)) ctx.markUiDirty();
};
export default run;
