import type { ActionExecutor } from '../../types';
import { logServiceFailure, resolveTarget } from '../../actionRuntimeHelpers';

/** Solta o alvo do osso: o nó volta a ser filho do pai autoral e segue a própria transformação de jogo. Estado só da sessão. */
const run: ActionExecutor<{ target: string }> = ({ target }, ctx) => {
  const node = resolveTarget('Detach From Bone', target, ctx);
  if (!node) return;
  const result = ctx.engine.attachments.detach(node.persistentNodeId);
  if (!result.ok) logServiceFailure('Detach From Bone', ctx, result);
};
export default run;
