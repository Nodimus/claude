import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'detach_from_bone',
  label: 'Detach From Bone',
  description: 'Solta o nó do osso (também o vínculo definido no Inspector, só durante o Play).',
  category: 'Visual',
  params: [{ key: 'target', label: 'Target', type: 'node', default: '' }],
  paramsSchema: z.object({ target: z.string().default('') }),
});
