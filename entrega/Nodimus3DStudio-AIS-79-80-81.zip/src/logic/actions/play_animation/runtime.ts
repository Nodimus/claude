import type { ActionExecutor } from '../../types';
import { logServiceFailure, resolveAnimatedObject } from '../../actionRuntimeHelpers';

/**
 * Toca uma animação do objeto animado do alvo com crossfade em segundos pela `EngineApi.animation`. O estado de reprodução vive na sessão
 * (`AnimationHost`); quem aplica os clipes ao esqueleto é o apresentador da viewport. Clipe inexistente, nó sem player ou sessão sem host → erro
 * explícito no log, nunca silêncio.
 */
const run: ActionExecutor<{ target: string; animation: string; crossfade: number; loop: boolean; speed: number }> = (params, ctx) => {
  const player = resolveAnimatedObject('Play Animation', params.target, ctx);
  if (!player) return;
  const result = ctx.engine.animation.play(player.persistentNodeId, params.animation, { crossfade: params.crossfade, loop: params.loop, speed: params.speed });
  if (!result.ok) logServiceFailure('Play Animation', ctx, result);
};
export default run;
