import { z } from 'zod';
import { defineAction } from '../../types';
import { requireNodeType } from '../../actionHelpers';
import { MIN_SPEED, MAX_SPEED } from '../../../runtime/skeletalAnimation';

export default defineAction({
  id: 'play_animation',
  label: 'Play Animation',
  description: 'Toca uma animação do objeto animado, com crossfade.',
  category: 'Visual',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'animation', label: 'Animação', type: 'enum', default: '', required: true, optionsFrom: 'animations' },
    { key: 'crossfade', label: 'Crossfade (s)', type: 'number', default: 0.2 },
    { key: 'loop', label: 'Loop', type: 'boolean', default: true },
    { key: 'speed', label: 'Speed', type: 'number', default: 1 },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    animation: z.string().default(''),
    crossfade: z.coerce.number().default(0.2),
    loop: z.boolean().default(true),
    speed: z.coerce.number().min(MIN_SPEED).max(MAX_SPEED).default(1),
  }),
  validate: requireNodeType('Play Animation', ['MeshInstance']),
});
