import type { ActionExecutor } from '../../types';
import { runPhysics } from '../../actionRuntimeHelpers';

/** Reposiciona o corpo (pose MUNDIAL), opcionalmente limpando velocidades; a instância de runtime acompanha na hora. */
const run: ActionExecutor<{ target: string; position: { x: number; y: number; z: number }; clearVelocities: boolean }> = ({ target, position, clearVelocities }, ctx) =>
  runPhysics('Teleport Physics Body', target, ctx, (bridge, id, instance) => {
    bridge.teleport(id, position, clearVelocities);
    ctx.engine.transform.setWorldPosition(instance.persistentNodeId, position);
  });
export default run;
