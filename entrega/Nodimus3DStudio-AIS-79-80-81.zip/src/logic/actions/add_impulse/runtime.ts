import type { ActionExecutor } from '../../types';
import { runPhysics } from '../../actionRuntimeHelpers';

/** Impulso instantâneo (world/local). Só corpos `dynamic`. */
const run: ActionExecutor<{ target: string; impulse: { x: number; y: number; z: number }; space: 'world' | 'local' }> = ({ target, impulse, space }, ctx) =>
  runPhysics('Add Impulse', target, ctx, (bridge, id) => bridge.addImpulse(id, impulse, space));
export default run;
