import type { ActionExecutor } from '../../types';
import { logServiceFailure, num, resolveTarget } from '../../actionRuntimeHelpers';
import { tNow } from '../../../core/i18n';

/** Ajusta volume/pitch das vozes de um emissor (AIS-52) pela `EngineApi.audio`. */
const run: ActionExecutor<{ target: string; volume: number; pitch: number }> = ({ target, volume, pitch }, ctx) => {
  const emitter = resolveTarget('Set Sound Volume / Pitch', target, ctx);
  if (!emitter) return;
  const result = ctx.engine.audio.setProperties(emitter.persistentNodeId, { volume: num(volume, 1), pitch: num(pitch, 1) });
  if (!result.ok) return logServiceFailure('Set Sound Volume / Pitch', ctx, result);
  if (result.count === 0) ctx.log('warn', tNow('runtimeMsgCore.setSoundVolumePitchHad', { name: emitter.name }));
};
export default run;
