import type { ActionExecutor } from '../../types';

/** Escreve no Output e no Debugger (aceita `$variavel$`). */
const run: ActionExecutor<{ text: string }> = ({ text }, ctx) => ctx.log('info', ctx.interpolate(text), { toOutput: true });
export default run;
