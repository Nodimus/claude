import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'print_log',
  label: 'Print Log',
  description: 'Escreve uma mensagem no console do editor/jogo.',
  category: 'Debug',
  params: [
    { key: 'text', label: 'Text', type: 'string', default: '', inline: { width: 'lg', placeholder: 'Message...' } },
  ],
  quickAdd: { label: 'Log', order: 1, parameters: { text: 'Action executed' } },
  paramsSchema: z.object({
    text: z.string().default(''),
  }),
});
