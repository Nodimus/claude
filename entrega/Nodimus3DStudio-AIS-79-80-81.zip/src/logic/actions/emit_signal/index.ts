import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'emit_signal',
  label: 'Emit Signal',
  description: 'Emite um sinal.',
  category: 'Logic',
  params: [
    { key: 'signal', label: 'Signal', type: 'string', default: '', required: true },
  ],
  paramsSchema: z.object({
    signal: z.string().default(''),
  }),
});
