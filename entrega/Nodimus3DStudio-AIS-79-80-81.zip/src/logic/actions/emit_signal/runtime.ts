import type { ActionExecutor } from '../../types';
import { tNow } from '../../../core/i18n';

const run: ActionExecutor<{ signal: string }> = ({ signal }, ctx) => {
  if (!signal.trim()) return ctx.log('error', tNow('runtimeMsgCore.emitSignalProvideTheSignal'));
  ctx.emitSignal(signal.trim());
};
export default run;
