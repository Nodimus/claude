import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'quit_game',
  label: 'Quit Game',
  description: 'Sai do jogo. No editor é ignorada com aviso (só faz sentido no jogo publicado).',
  category: 'Scene',
  params: [],
  paramsSchema: z.object({}),
});
