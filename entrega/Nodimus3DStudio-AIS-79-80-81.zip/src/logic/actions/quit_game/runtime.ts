import type { ActionExecutor } from '../../types';

const run: ActionExecutor<Record<string, never>> = (_p, ctx) => {
  ctx.engine.scene.quit();
  return 'stop';
};
export default run;
