import type { ActionExecutor } from '../../types';
import { logServiceFailure, resolveTarget } from '../../actionRuntimeHelpers';
import { tNow } from '../../../core/i18n';

/** Para os sons de um emissor (AIS-52) pela `EngineApi.audio`. */
const run: ActionExecutor<{ target: string; sound: string }> = ({ target, sound }, ctx) => {
  const emitter = resolveTarget('Stop Sound', target, ctx);
  if (!emitter) return;
  const result = ctx.engine.audio.stop(emitter.persistentNodeId, sound || undefined);
  if (!result.ok) return logServiceFailure('Stop Sound', ctx, result);
  if (result.count === 0) ctx.log('warn', tNow('runtimeMsgCore.stopSoundHadNoSound', { name: emitter.name }));
};
export default run;
