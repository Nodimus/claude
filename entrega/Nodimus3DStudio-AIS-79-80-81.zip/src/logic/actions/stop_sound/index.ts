import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'stop_sound',
  label: 'Stop Sound',
  description: 'Para o som indicado; sem som, para todos os sons do nó.',
  category: 'Audio',
  requires: ['requiresDOM'],
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'sound', label: 'Sound', type: 'file', default: '', accept: ['.wav', '.ogg', '.mp3'] },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    sound: z.string().default(''),
  }),
});
