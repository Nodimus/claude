import type { ActionExecutor } from '../../types';
import { isUiInstance, num } from '../../actionRuntimeHelpers';

/** Desloca o nó dono por (dx, dy, dz). UI: soma nos offsets `posX/posY`. */
const run: ActionExecutor<{ dx: number; dy: number; dz: number }> = ({ dx, dy, dz }, ctx) => {
  const node = ctx.self;
  if (isUiInstance(node)) {
    node.properties.posX = num(node.properties.posX) + dx;
    node.properties.posY = num(node.properties.posY) + dy;
    ctx.markUiDirty();
    return;
  }
  const [px, py, pz] = node.transform.position;
  node.transform.position = [px + dx, py + dy, pz + dz];
  ctx.applyTransform(node);
};
export default run;
