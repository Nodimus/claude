import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'run_script',
  label: 'Run Script',
  description: 'Executa um script .js de res://scripts/ no sandbox (Web Worker, AIS-79): `run(engine, args)` com o nó dono da regra. O efeito chega no quadro seguinte. Scripts .ts: em breve.',
  category: 'Logic',
  requires: ['requiresDOM'],
  params: [
    { key: 'scriptRef', label: 'Script', type: 'file', default: '', accept: ['.js'], required: true, root: 'res://scripts/' },
  ],
  paramsSchema: z.object({
    scriptRef: z.string().default('').refine((v) => v === '' || /^res:\/\/scripts\/.+\.js$/i.test(v), { message: 'O script precisa ser um .js de res://scripts/ (.ts: em breve)' }),
  }),
});
