import type { LocomotionState } from '../runtime/cameraRig/movement';
import type { BehaviorRuntimeContext, LogicParamDescriptor } from './types';
import type { RuntimeInstance } from '../runtime/RuntimeScene';
import { tNow } from '../core/i18n';

/**
 * AIS-60b (decisão 30) — grupo "Animações" dos Behaviors de movimento: o ator escolhe a animação de cada estado de locomoção
 * (idle/walk/run/jump/fall) e o crossfade. Mora FORA das pastas varridas pelo registry. O Behavior de movimento continua só
 * movendo (decisão 28); ele apenas PEDE ao host de animação a troca quando o estado muda. Campo vazio = nenhuma troca; nome que não
 * existe → aviso UMA vez por nome (nunca exceção, nunca silêncio).
 */

export const LOCOMOTION_ANIMATION_DEFAULTS = { animationTarget: '', idle: '', walk: '', run: '', jump: '', fall: '', crossfade: 0.2 } as const;

const state = (key: string, label: string): LogicParamDescriptor => ({ key, label: tNow('locomotionAnimationMsgCore.animation', { label }), type: 'enum', default: '', optionsFrom: 'animations' });

export const LOCOMOTION_ANIMATION_PARAMS: LogicParamDescriptor[] = [
  { key: 'animationTarget', label: 'Animação: Objeto', type: 'node', default: '', emptyLabel: '(este nó)' },
  state('idle', 'Parado (Idle)'),
  state('walk', 'Andando (Walk)'),
  state('run', 'Correndo (Run)'),
  state('jump', 'Pulando (Jump)'),
  state('fall', 'Caindo (Fall)'),
  { key: 'crossfade', label: 'Animação: Crossfade (s)', type: 'number', default: LOCOMOTION_ANIMATION_DEFAULTS.crossfade },
];

/** O próprio nó se for animado, senão o primeiro descendente animado. */
function findAnimated(node: RuntimeInstance): RuntimeInstance | undefined {
  if (!node.disposed && node.type === 'MeshInstance' && node.properties.animated === true) return node;
  for (const child of node.children) {
    const hit = findAnimated(child);
    if (hit) return hit;
  }
  return undefined;
}

/**
 * Chamada a cada quadro por `publishLocomotion`: só age quando o estado MUDA (memória do Behavior). Estado sem animação escolhida não troca
 * nada. Sem host de animação (testes, sem Play) não faz nada.
 */
export function applyLocomotionAnimation(ctx: BehaviorRuntimeContext, locomotion: LocomotionState): void {
  const memory = ctx.state.memory as { lastAnimState?: string; warned?: Set<string> };
  if (memory.lastAnimState === locomotion.state) return;
  memory.lastAnimState = locomotion.state;
  const p = ctx.state.properties;
  const name = typeof p[locomotion.state] === 'string' ? (p[locomotion.state] as string).trim() : '';
  if (!name) return;
  const ref = typeof p.animationTarget === 'string' ? p.animationTarget.trim() : '';
  const start = ref ? ctx.getNode(ref) : ctx.node;
  const target = start ? findAnimated(start) : undefined;
  const warn = (message: string) => {
    const warned = (memory.warned ??= new Set<string>());
    if (warned.has(message)) return;
    warned.add(message);
    ctx.log('warn', message, { code: 'animation.locomotion' });
  };
  if (!target) return warn(tNow('locomotionAnimationMsgCore.animationsThereIsNoAnimated', { value: ref ? tNow('locomotionAnimationMsgLast.in', { ref }) : tNow('locomotionAnimationMsgLast.onThisNodeOrIts') }));
  const crossfade = typeof p.crossfade === 'number' && p.crossfade >= 0 ? p.crossfade : LOCOMOTION_ANIMATION_DEFAULTS.crossfade;
  const result = ctx.engine.animation.play(target.persistentNodeId, name, { crossfade });
  if (!result.ok && result.code !== 'animation.unavailable') warn(tNow('locomotionAnimationMsgCore.animationsTheStateAsksFor', { state: locomotion.state, name, message: result.message })); // sem host de animação (testes, sem Play) não faz nada
}
