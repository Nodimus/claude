import { describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { RuntimeSession } from '../runtime/RuntimeSession';
import { ACTION_CONTEXT_SOURCE, BEHAVIOR_CONTEXT_SOURCE, KNOWN_CONTEXT_GAPS, createEngineCore, deriveActionContext, deriveBehaviorContext } from '../runtime/engineScope';
import type { EngineHost } from '../runtime/engineApi';
import type { BehaviorRuntime, BehaviorRuntimeContext } from './types';
import { LogicRegistry } from './registry';
import { liveCapabilityCatalog, liveUnsupportedFor } from './capabilityCatalog';
import { resolveSupport } from '../core/capabilities';

/**
 * AIS-78c (decisão 32) — fronteira da EngineApi, no estilo de `executorCoverage.test.ts`:
 *  1. os contextos de Action e de Behavior só têm membros CLASSIFICADOS (`engine` | `scope` | `extra`); a lista dos `extra` é congelada aqui: membro
 *     novo fora da EngineApi exige decisão explícita (edite este teste junto com `engineScope.ts`);
 *  2. `src/logic/**` não importa Three, Rapier nem Tauri fora de uma allowlist que SÓ PODE ENCOLHER;
 *  3. os `requires` das pastas são capacidades conhecidas e resolvem de forma determinística por target.
 */

const keysOf = (source: Record<string, string>, kind: string) => Object.entries(source).filter(([, v]) => v === kind).map(([k]) => k).sort();

/** Congelado: o que os contextos têm ALÉM da EngineApi. Crescer exige aprovação (decisão 32); só deve encolher conforme os executores migram. */
const FROZEN_ACTION_EXTRAS = ([] as string[]).sort();
const FROZEN_BEHAVIOR_EXTRAS = ([] as string[]).sort() // AIS-78d: contextos 100% derivados — nenhum membro fora da EngineApi/escopo;

describe('contextos derivados da EngineApi (membros classificados)', () => {
  it('os membros "extra" são exatamente a lista congelada (membro novo fora da EngineApi falha aqui)', () => {
    expect(keysOf(ACTION_CONTEXT_SOURCE, 'extra'), 'ActionRuntimeContext ganhou/perdeu um membro fora da EngineApi: decida e atualize FROZEN_ACTION_EXTRAS').toEqual(FROZEN_ACTION_EXTRAS);
    expect(keysOf(BEHAVIOR_CONTEXT_SOURCE, 'extra'), 'BehaviorRuntimeContext ganhou/perdeu um membro fora da EngineApi: decida e atualize FROZEN_BEHAVIOR_EXTRAS').toEqual(FROZEN_BEHAVIOR_EXTRAS);
  });

  it('as lacunas conhecidas ficam REGISTRADAS (Action sem onFrame, por design) e batem com os contextos', () => {
    const actionKeys = Object.keys(ACTION_CONTEXT_SOURCE);
    const behaviorKeys = Object.keys(BEHAVIOR_CONTEXT_SOURCE);
    for (const k of KNOWN_CONTEXT_GAPS.behaviorLacks) expect(behaviorKeys, `Behavior passou a ter "${k}": tire da lacuna`).not.toContain(k);
    for (const k of KNOWN_CONTEXT_GAPS.actionLacks) expect(actionKeys, `Action passou a ter "${k}": tire da lacuna`).not.toContain(k);
  });

  it('o contexto REAL de um Behavior (montado pelo lifecycle da sessão) tem exatamente os membros do manifesto', () => {
    const behavior: BehaviorInstance = { id: 'b1', name: 'Probe', behaviorType: 'probe', enabled: true, properties: {}, rules: [] };
    const hero = { id: 'hero', name: 'hero', type: 'Spatial', parentId: null, childrenIds: [], visible: true, locked: false, properties: {}, behaviors: [behavior] } as unknown as GameNode;
    const scene = createDefault3DStarterScene();
    const root = scene.nodes[scene.rootNodeId];
    const full: SceneData = { ...scene, nodes: { ...scene.nodes, hero: { ...hero, parentId: root.id } as GameNode, [root.id]: { ...root, childrenIds: [...root.childrenIds, 'hero'] } } };
    let captured: BehaviorRuntimeContext | null = null;
    const runtime: BehaviorRuntime = { attach: (ctx) => void (captured = ctx) };
    const session = new RuntimeSession({
      snapshot: createRuntimeSnapshot(full),
      mode: 'scene',
      input: { isActionPressed: () => false, isActionJustPressed: () => false, isActionJustReleased: () => false, getAxis: () => 0, isBindingPressed: () => false, isBindingJustPressed: () => false, isBindingJustReleased: () => false } as never,
      behaviorCatalog: { get: (t: string) => (t === 'probe' ? { create: () => runtime, replacesRules: true } : undefined) },
    } as never);
    session.start();
    expect(captured).not.toBeNull();
    expect(Object.keys(captured!).sort()).toEqual(Object.keys(BEHAVIOR_CONTEXT_SOURCE).sort());
    expect(Object.keys(captured!)).not.toContain('ai'); // AIS-78d: a IA fala só pela EngineApi
    session.stop();
  });

  it('derive*Context: a interseção sai do host/EngineApi (chamadas observadas) e os extras entram por descritor (getters preservados)', () => {
    const calls: string[] = [];
    const self: any = { id: 'i', persistentNodeId: 'n', name: 'N', transform: { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] }, properties: {}, tags: [], disposed: false, visible: true, parent: null };
    const host: EngineHost = {
      instanceById: (r) => (r === 'n' ? self : undefined),
      instanceByName: (n) => (n === 'N' ? self : undefined),
      variables: () => null,
      input: () => ({ tag: 'input' }) as never,
      physics: () => null,
      sceneTime: () => 12.5,
      emitSignal: (name) => void calls.push(`emit:${name}`),
      connectSignal: (name, _l, owner) => (calls.push(`connect:${name}:${owner?.id}`), () => undefined),
      onPhysicsEvent: (name, _cb, owner) => (calls.push(`phys:${name}:${owner?.id}`), () => undefined),
      log: (level, message, node, o) => void calls.push(`log:${level}:${message}:${node?.persistentNodeId}:${o?.behaviorId ?? '-'}`),
      commitTransform: () => void calls.push('commit'),
    };
    const core = createEngineCore(host);
    let lazyReads = 0;
    const action = deriveActionContext(core, { self, owner: null }, { get tweens() { lazyReads++; return null; } } as never);
    expect(action.sceneTime).toBe(12.5);
    expect(action.resolve('')).toBe(self);
    expect(action.resolve('N')).toBe(self); // por nome
    expect(action.resolve('x')).toBeUndefined();
    action.emitSignal('s');
    action.applyTransform(self);
    action.log('warn', 'oi', { code: 'c' });
    expect(calls).toEqual(['emit:s', 'commit', 'log:warn:oi:n:-']);
    expect(lazyReads).toBe(0); // os getters dos extras não foram avaliados na derivação

    calls.length = 0;
    const owner = { kind: 'behavior' as const, id: 'n::b' };
    const beh = deriveBehaviorContext(core, { self, behavior: { id: 'b', name: 'Meu', behaviorType: 'meu_tipo', enabled: true, properties: {}, rules: [] } as never, state: { properties: {}, memory: {} }, initialTransform: { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] }, owner }, {} as never);
    beh.onSignal('x', () => undefined);
    beh.onPhysicsEvent('collisionEnter', () => undefined);
    beh.log('error', 'ops', { code: 'k' });
    expect(beh.getNode('n')).toBe(self);
    expect(beh.getNode('N')).toBeUndefined(); // Behavior só resolve por ID (comportamento anterior preservado)
    expect(calls).toEqual(['connect:x:n::b', 'phys:collisionEnter:n::b', 'log:error:Meu: ops:n:b']);
    expect(beh.input).toEqual({ tag: 'input' });
  });
});

// ── imports indevidos em src/logic/** ──────────────────────────────────────────────────────────────────────────────────────────────────────

const sources = import.meta.glob('./**/*.ts', { query: '?raw', import: 'default', eager: true }) as Record<string, string>;
const FORBIDDEN = /(?:from|import\()\s*['"](?:three(?:\/[^'"]*)?|@dimforge\/[^'"]+|rapier[^'"]*|@tauri-apps\/[^'"]+|[^'"]*tauriBridge|[^'"]*core\/physics\/(?:rapierInit|createPhysicsBody))['"]/;

/**
 * Allowlist INICIAL = o estado atual do código (look_at, set_emissive_color, follow_a_path, cameraRuntime — e vehicle_wheel, que também importa
 * Three hoje). SÓ PODE ENCOLHER: ao migrar um arquivo para a EngineApi, remova-o daqui (o teste cobra).
 */
// ZERADA (AIS-78c, execução 3): look_at/set_emissive_color usam a EngineApi; follow_a_path, vehicle_wheel e cameraRuntime pedem dados ao runtime. Nada novo pode entrar.
const ALLOWLIST: readonly string[] = [];

describe('src/logic/** não importa three/Rapier/Tauri fora da allowlist', () => {
  const violators = Object.entries(sources)
    .filter(([path]) => !path.endsWith('.test.ts') && FORBIDDEN.test(sources[path]))
    .map(([path]) => path)
    .sort();

  it('nenhum arquivo novo importa three, Rapier ou Tauri', () => {
    const fresh = violators.filter((p) => !ALLOWLIST.includes(p));
    expect(fresh, `Import indevido em src/logic (use a EngineApi/PhysicsBridge; a allowlist só pode encolher): ${fresh.join(', ')}`).toEqual([]);
  });

  it('a allowlist só encolhe: entrada que já não importa nada deve ser removida', () => {
    const stale = ALLOWLIST.filter((p) => !violators.includes(p));
    expect(stale, `Remova da allowlist (já migrou): ${stale.join(', ')}`).toEqual([]);
  });

  it('o glob enxerga os arquivos de lógica (o teste não passa por falta de varredura)', () => {
    expect(Object.keys(sources).length).toBeGreaterThan(100);
    expect(Object.keys(sources)).toContain('./actions/look_at/runtime.ts');
  });
});

// ── requires das pastas ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────

describe('requires declarados nas pastas (CapabilityRegistry)', () => {
  it('todo `requires` é de capacidades CONHECIDAS (id desconhecido falha aqui)', () => {
    const all = [...LogicRegistry.listTriggers(), ...LogicRegistry.listConditions(), ...LogicRegistry.listActions(), ...LogicRegistry.listBehaviors()];
    for (const def of all) for (const r of def.requires ?? []) expect(resolveSupport([r], 'web').unresolved, `${def.kind}:${def.id}`).toEqual([]);
  });

  it('física e áudio estão declarados; o catálogo agrega lógica + nós + EngineApi sem duplicar', () => {
    expect(LogicRegistry.listActions().find((a) => a.id === 'add_force')?.requires).toEqual(['requiresPhysics']);
    expect(LogicRegistry.listActions().find((a) => a.id === 'play_sound')?.requires).toEqual(['requiresDOM']);
    expect(LogicRegistry.listBehaviors().find((b) => b.id === 'platformer_2d_movement')?.requires).toEqual(['requiresPhysics']);
    expect(LogicRegistry.listTriggers().find((t) => t.id === 'on_collision_enter')?.requires).toEqual(['requiresPhysics']);
    const cat = liveCapabilityCatalog();
    const keys = cat.map((e) => `${e.kind}:${e.id}`);
    expect(new Set(keys).size).toBe(keys.length);
    expect(cat.some((e) => e.kind === 'node' && e.id === 'MeshInstance')).toBe(true);
    expect(cat.some((e) => e.kind === 'engine' && e.id === 'nodes.get')).toBe(true);
    expect(cat.filter((e) => e.kind === 'action').length).toBe(LogicRegistry.listActions().length);
  });

  it('com os perfis atuais, todos os itens de lógica rodam nos 3 targets (física/DOM existem em todos); o relatório é determinístico', () => {
    for (const target of ['web', 'desktop', 'mobile'] as const) {
      const notFull = liveUnsupportedFor(target).filter((x) => x.entry.kind !== 'engine');
      expect(notFull, target).toEqual([]);
    }
    expect(liveUnsupportedFor('web')).toEqual(liveUnsupportedFor('web'));
  });
});
