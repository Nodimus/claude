/**
 * AIS-44b — catálogo de executores de Behavior: descobre `src/logic/behaviors/<id>/runtime.ts` (mesma pasta da definição;
 * decisão 21). Behavior sem `runtime.ts` é só de regras (executadas pelo `LogicRunner`).
 */
import type { BehaviorRuntimeModule } from './types';

const modules = import.meta.glob<{ default?: BehaviorRuntimeModule }>('./behaviors/*/runtime.ts', { eager: true });

const catalog = new Map<string, BehaviorRuntimeModule>();
for (const [path, mod] of Object.entries(modules)) {
  const id = path.split('/').slice(-2, -1)[0];
  if (id && mod.default && typeof mod.default.create === 'function') catalog.set(id, mod.default);
}

export interface BehaviorRuntimeLookup {
  get(behaviorType: string): BehaviorRuntimeModule | undefined;
}

export const BehaviorRuntimeCatalog: BehaviorRuntimeLookup & { list(): string[] } = {
  get: (id) => catalog.get(id),
  list: () => [...catalog.keys()].sort(),
};
