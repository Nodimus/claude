/**
 * AIS-40c — avaliador de Conditions (puro). O runtime (AIS-44) monta o `ConditionContext` e chama estas funções; a UI nunca
 * avalia nada. Parâmetros passam pelo `paramsSchema` da pasta (padrões aplicados); ID desconhecido ou parâmetro inválido NÃO
 * lança nem altera os dados da cena: a avaliação devolve `null` e o chamador decide (a regra, por padrão, não executa).
 */
import { LogicRegistry } from './registry';
import type { ConditionContext, ConditionRef } from './types';

export type ConditionWorld = Omit<ConditionContext, 'evaluate'>;

/** Verdadeiro/falso, ou `null` se a Condition não é conhecida ou os parâmetros não passam no schema. */
export function evaluateConditionOrNull(ref: ConditionRef, world: ConditionWorld, depth = 0): boolean | null {
  const definition = LogicRegistry.getCondition(ref.type);
  if (!definition || depth > 16) return null; // `not` dentro de `not` sem fim: corta
  const parsed = definition.paramsSchema.safeParse(ref.parameters ?? {});
  if (!parsed.success) return null;
  const context: ConditionContext = { ...world, evaluate: (inner) => evaluateConditionOrNull(inner, world, depth + 1) };
  return definition.evaluate(parsed.data, context);
}

/** Como `evaluateConditionOrNull`, mas não resolvida = falsa (a regra não executa). */
export const evaluateCondition = (ref: ConditionRef, world: ConditionWorld): boolean => evaluateConditionOrNull(ref, world) === true;

/** Todas as Conditions da regra (E). Lista vazia = sempre. */
export const evaluateConditions = (refs: readonly ConditionRef[], world: ConditionWorld): boolean => refs.every((ref) => evaluateCondition(ref, world));
