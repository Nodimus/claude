import { describe, expect, it } from 'vitest';
import { LogicRegistry, verifyLogicRegistry, collectLogicDefinitions, EXPECTED_NATIVE_LOGIC, type LogicRegistryDiagnostic } from './registry';
import { z } from 'zod';
import { defineAction } from './types';

describe('LogicRegistry (AIS-05r)', () => {
  it('enumera todos os itens nativos esperados, sem pastas inválidas', () => {
    const r = verifyLogicRegistry();
    expect(r.results.filter((x) => !x.passed)).toEqual([]);
    expect(LogicRegistry.diagnostics).toEqual([]);
  });

  it('cada behavior cria uma instância com o próprio behaviorType e IDs novos', () => {
    for (const b of LogicRegistry.listBehaviors()) {
      const a = b.create({ targetNodeId: 'Alvo' });
      const c = b.create({ targetNodeId: 'Alvo' });
      expect(a.behaviorType).toBe(b.id);
      expect(a.targetNodeId).toBe('Alvo');
      expect(a.id).not.toBe(c.id);
      for (const rule of a.rules) {
        expect(LogicRegistry.isKnownTrigger(rule.eventType)).toBe(true);
        rule.conditions.forEach((cond) => expect(LogicRegistry.isKnownCondition(cond.type)).toBe(true));
        rule.actions.forEach((act) => expect(LogicRegistry.isKnownAction(act.type)).toBe(true));
      }
    }
  });

  it('rejeita pasta com id diferente, id duplicado e módulo sem default', () => {
    const diag: LogicRegistryDiagnostic[] = [];
    const ok = defineAction({ id: 'good_one', label: 'Good', description: '', category: 'Logic', params: [], paramsSchema: z.object({}) });
    const map = collectLogicDefinitions(
      {
        './actions/good_one/index.ts': { default: ok },
        './actions/other_name/index.ts': { default: { ...ok } },
        './actions/empty/index.ts': {},
      },
      'action',
      diag
    );
    expect([...map.keys()]).toEqual(['good_one']);
    expect(diag).toHaveLength(2);
  });
});

describe('Catálogo de Triggers (AIS-40)', () => {
  /** Nome da especificação → pasta (ID estável). `on_start`, `on_click` e `on_timeout` já existiam e só ganharam o rótulo da spec. */
  const SPEC_TRIGGERS: Record<string, string> = {
    OnSceneStart: 'on_start',
    OnKeyDown: 'on_key_down',
    OnKeyUp: 'on_key_up',
    OnMouseDown: 'on_mouse_down',
    OnMouseClick: 'on_click',
    OnCollisionEnter: 'on_collision_enter',
    OnCollisionExit: 'on_collision_exit',
    OnTimerInterval: 'on_timeout',
    OnVariableChanged: 'on_variable_changed',
  };

  it('todo trigger da especificação existe no registro (teste de enumeração)', () => {
    for (const [name, id] of Object.entries(SPEC_TRIGGERS)) {
      expect(LogicRegistry.isKnownTrigger(id), `${name} → ${id}`).toBe(true);
    }
    // e a lista esperada do registro os contém: sumir uma pasta derruba o teste
    for (const id of Object.values(SPEC_TRIGGERS)) expect(EXPECTED_NATIVE_LOGIC.trigger).toContain(id);
  });

  it('IDs antigos continuam resolvendo (cenas existentes não quebram)', () => {
    for (const id of ['on_update', 'on_signal', 'on_key_press']) expect(LogicRegistry.isKnownTrigger(id)).toBe(true);
  });

  it('nenhum Trigger fica desabilitado: On Variable Changed foi habilitado no AIS-43', () => {
    const disabled = LogicRegistry.listTriggers().filter((t) => t.status === 'disabled').map((t) => t.id);
    expect(disabled).toEqual([]);
  });

  it('teclado e mouse expõem parâmetros com padrão válido', () => {
    const down = LogicRegistry.getTrigger('on_key_down')!;
    expect(down.params.map((p) => p.type)).toEqual(['key']);
    const mouse = LogicRegistry.getTrigger('on_mouse_down')!;
    const button = mouse.params.find((p) => p.key === 'button')!;
    expect(button.options).toContain(button.default as string);
    const target = mouse.params.find((p) => p.key === 'target')!;
    expect(target.options).toContain(target.default as string);
  });

  it('todo trigger tem rótulo, descrição e categoria; nenhum rótulo se repete', () => {
    const all = LogicRegistry.listTriggers();
    for (const t of all) {
      expect(t.label.length).toBeGreaterThan(0);
      expect(t.description.length).toBeGreaterThan(0);
    }
    expect(new Set(all.map((t) => t.label)).size).toBe(all.length);
  });
});
