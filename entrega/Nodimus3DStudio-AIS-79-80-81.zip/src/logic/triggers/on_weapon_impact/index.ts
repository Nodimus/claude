import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_weapon_impact',
  label: 'On Weapon Impact',
  description:
    'Disparado quando um projétil (ou hitscan) deste Weapon Controller acerta algo (depois do dano). Só funciona nas regras de um Behavior Weapon Controller.',
  category: 'Physics',
  params: [],
});
