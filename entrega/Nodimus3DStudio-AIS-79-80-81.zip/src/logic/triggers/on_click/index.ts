import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_click',
  label: 'On Mouse Click',
  description: 'Disparado por clique do mouse sobre o objeto 3D (raycast).',
  category: 'Interaction',
  params: [{ key: 'button', label: 'Button', type: 'enum', default: 'left', options: ['left', 'middle', 'right'] }],
});
