import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_hotspot_exit',
  label: 'On Hotspot Exit',
  description:
    'Disparado quando um corpo sai do volume do Hotspot. Opcional: só corpos com a Tag indicada.',
  category: 'Interaction',
  requires: ['requiresPhysics'],
  params: [{ key: 'tag', label: 'Only Tag (optional)', type: 'string', default: '' }],
});
