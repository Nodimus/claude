import { defineTrigger } from '../../types';
import { DEFAULT_INPUT_ACTIONS } from '../../../runtime/input/InputManager';

export default defineTrigger({
  id: 'on_input_action',
  label: 'On Input Action',
  description: 'Disparado por uma ação lógica do InputManager (Jump, Interact…): vale para teclado e mouse e segue o remapeamento.',
  category: 'Interaction',
  params: [
    { key: 'action', label: 'Action', type: 'enum', default: 'Jump', options: [...DEFAULT_INPUT_ACTIONS], optionsFrom: 'inputActions' },
    { key: 'phase', label: 'Phase', type: 'enum', default: 'pressed', options: ['pressed', 'released', 'held'] },
  ],
});
