import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_key_down',
  label: 'On Key Down',
  description: 'Disparado ao pressionar uma tecla do teclado desktop (WASD, setas, espaço, Shift, Esc, letras e números).',
  category: 'Interaction',
  params: [{ key: 'key', label: 'Key', type: 'key', default: '', required: true }],
});
