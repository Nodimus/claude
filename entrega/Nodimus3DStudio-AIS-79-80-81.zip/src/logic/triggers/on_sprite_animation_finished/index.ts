import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_sprite_animation_finished',
  label: 'On Sprite Animation Finished',
  description: 'Disparado quando uma animação de sprite em modo "uma vez" (once) chega ao fim no Billboard dono do Behavior. Animação vazia = qualquer. (animation_looped e frame_changed seguem como sinais do nó.)',
  category: 'Visual',
  params: [{ key: 'animation', label: 'Animação', type: 'string', default: '', inline: { prefix: 'anim:', width: 'sm', placeholder: '(qualquer)' } }],
});
