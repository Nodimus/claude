import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_hotspot_enter',
  label: 'On Hotspot Enter',
  description:
    'Disparado quando um corpo (dynamic ou personagem) entra no volume do Hotspot. Opcional: só corpos com a Tag indicada.',
  category: 'Interaction',
  requires: ['requiresPhysics'],
  params: [{ key: 'tag', label: 'Only Tag (optional)', type: 'string', default: '' }],
});
