import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_weapon_reload',
  label: 'On Weapon Reload',
  description:
    'Disparado quando a recarga começa (manual ou automática). Só funciona nas regras de um Behavior Weapon Controller.',
  category: 'Physics',
  params: [],
});
