/**
 * AIS-44 — catálogo de EXECUTORES de Action: descobre, em tempo de build, `src/logic/actions/<id>/runtime.ts` (mesma pasta
 * da definição; decisão 21). A definição (UI, schema, validação) continua no `LogicRegistry`; aqui só mora o "como executar".
 * Action sem `runtime.ts` não executa: o runner avisa de forma explícita (nunca ignora em silêncio).
 */
import type { ActionExecutor } from './types';

const modules = import.meta.glob<{ default?: ActionExecutor }>('./actions/*/runtime.ts', { eager: true });

const executors = new Map<string, ActionExecutor>();
for (const [path, mod] of Object.entries(modules)) {
  const id = path.split('/').slice(-2, -1)[0];
  if (id && typeof mod.default === 'function') executors.set(id, mod.default);
}

export const ActionRuntime = {
  get: (id: string): ActionExecutor | undefined => executors.get(id),
  has: (id: string): boolean => executors.has(id),
  list: (): string[] => [...executors.keys()].sort(),
} as const;
