import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { EXPECTED_NATIVE_LOGIC, LogicRegistry, PHYSICS_ACTION_IDS, verifyLogicRegistry } from './registry';
import { validateAction } from './validateAction';
import type { ConditionNode } from './types';

const node = (type: string, properties: Record<string, any> = {}, over: Partial<ConditionNode> = {}): ConditionNode => ({ id: 'n1', name: 'Alvo', type, visible: true, properties, ...over });
const body = (bodyMode: string, extra: Record<string, unknown> = {}) => node('MeshInstance', { physics: { enabled: true, bodyMode, shape: 'auto', ...extra } });
const ctx = (target?: ConditionNode) => ({ target });

describe('AIS-41 — catálogo de Actions (C01)', () => {
  it('tem mais de 30 Actions, todas em EXPECTED_NATIVE_LOGIC, e a lista esperada é exatamente o registro', () => {
    const ids = LogicRegistry.listActions().map((a) => a.id);
    expect(ids.length).toBeGreaterThan(30);
    expect([...ids].sort()).toEqual([...EXPECTED_NATIVE_LOGIC.action].sort());
    for (const id of EXPECTED_NATIVE_LOGIC.action) expect(LogicRegistry.isKnownAction(id), id).toBe(true);
  });

  it('cobre as famílias da especificação (movimento, física, áudio, animação, cena, variável, visual, overlay, script)', () => {
    const spec: Record<string, string[]> = {
      'Mover Objeto (velocidade vetorial)': ['move_velocity'],
      'Rotacionar Contínuo': ['rotate_continuous'],
      'Teleportar para Posição': ['set_position'],
      'Olhar Para': ['look_at'],
      'Tocar Efeito Sonoro 3D': ['play_sound'],
      'Parar Som': ['stop_sound'],
      'Alterar Volume/Pitch': ['set_sound_properties'],
      'Executar Animação': ['play_animation'],
      Pausar: ['pause_animation'],
      'Parar Animação': ['stop_animation'],
      'Trocar de Cena': ['change_scene'],
      'Reiniciar Cena Atual': ['restart_scene'],
      'Sair do Jogo': ['quit_game'],
      'Somar/Subtrair/Definir Variável': ['add_to_variable', 'subtract_from_variable', 'set_variable'],
      'Alternar Visibilidade': ['toggle_visible', 'set_visible'],
      'Instanciar Partículas': ['emit_particles'],
      'Mudar Cor de Emissivo': ['set_emissive_color'],
      'Overlay: texto e textura': ['change_text', 'change_texture'],
      'Executar Script': ['run_script'],
    };
    for (const [name, ids] of Object.entries(spec)) for (const id of ids) expect(LogicRegistry.isKnownAction(id), `${name} → ${id}`).toBe(true);
  });

  it('as 8 Actions de física existem como pastas, são Physics, validam o corpo e estão na lista esperada', () => {
    expect(PHYSICS_ACTION_IDS).toHaveLength(8);
    for (const id of ['add_force', 'add_impulse', 'set_linear_velocity', 'set_angular_velocity', 'teleport_physics_body', 'set_physics_enabled', 'set_physics_material', 'apply_torque']) {
      expect(PHYSICS_ACTION_IDS).toContain(id);
      const def = LogicRegistry.getAction(id)!;
      expect(def, id).toBeDefined();
      expect(def.category).toBe('Physics');
      expect(typeof def.validate).toBe('function');
      expect(EXPECTED_NATIVE_LOGIC.action).toContain(id);
    }
    // nenhuma Action fora das 8 usa a categoria Physics — exceto as 3 de armas do AIS-69 (categoria Física por decisão do prompt)
    const weaponActions = ['apply_damage', 'explode_area', 'fire_projectile'];
    expect(LogicRegistry.listActions().filter((a) => a.category === 'Physics' && !weaponActions.includes(a.id)).map((a) => a.id).sort()).toEqual([...PHYSICS_ACTION_IDS].sort());
    for (const id of weaponActions) expect(LogicRegistry.getAction(id)?.category).toBe('Physics');
  });

  it('Set Collision Filter NÃO existe (pendente até layers/masks terem schema persistido)', () => {
    expect(LogicRegistry.isKnownAction('set_collision_filter')).toBe(false);
  });

  it('o padrão declarado de cada parâmetro é aceito pelo schema da própria pasta', () => {
    for (const def of LogicRegistry.listActions()) {
      const defaults = Object.fromEntries(def.params.map((p) => [p.key, p.default]));
      expect(def.paramsSchema.safeParse(defaults).success, def.id).toBe(true);
      expect(def.paramsSchema.safeParse({}).success, `${def.id} (vazio)`).toBe(true);
    }
  });

  it('a verificação do registro (schema em toda Action, física completa) passa e a ordem de adição rápida se mantém', () => {
    expect(verifyLogicRegistry().results.filter((r) => !r.passed)).toEqual([]);
    expect(LogicRegistry.listQuickAddActions().map((a) => a.id).slice(0, 3)).toEqual(['print_log', 'move_by', 'rotate_by']);
  });

  it('nenhuma Action fica desabilitada: Execute Script foi habilitada no AIS-79 (sandbox); as de variável no AIS-43, emit_particles no AIS-59c e as de animação no AIS-60', () => {
    const disabled = LogicRegistry.listActions().filter((a) => a.status === 'disabled').map((a) => a.id).sort();
    expect(disabled).toEqual([]);
  });
});

describe('AIS-41 — física valida o bodyMode (C02, C03)', () => {
  const run = (id: string, target?: ConditionNode, parameters: Record<string, unknown> = {}) => validateAction({ type: id, parameters }, ctx(target));

  it('Add Force num corpo dynamic é aceita (e devolve os parâmetros com padrões)', () => {
    const r = run('add_force', body('dynamic'), { force: { x: 1, y: 2, z: 3 }, space: 'local' });
    expect(r).toEqual({ ok: true, params: { target: '', force: { x: 1, y: 2, z: 3 }, space: 'local' } });
  });

  it('Add Force em static ou kinematic é REJEITADA com erro explícito (nunca ignorada)', () => {
    for (const mode of ['static', 'kinematic', 'character', 'trigger']) {
      const r = run('add_force', body(mode));
      expect(r.ok, mode).toBe(false);
      if (!r.ok) {
        expect(r.code).toBe('physics.incompatible_body_mode');
        expect(r.message).toContain(`"${mode}"`);
        expect(r.message).toContain('Add Force');
      }
    }
  });

  it('cada Action de física aceita só os corpos previstos e rejeita os outros', () => {
    const table: Record<string, string[]> = {
      add_force: ['dynamic'],
      add_impulse: ['dynamic'],
      apply_torque: ['dynamic'],
      set_angular_velocity: ['dynamic'],
      set_linear_velocity: ['dynamic', 'character'],
      teleport_physics_body: ['static', 'dynamic', 'kinematic', 'character', 'trigger'],
      set_physics_enabled: ['static', 'dynamic', 'kinematic', 'character', 'trigger'],
      set_physics_material: ['static', 'dynamic', 'kinematic', 'character'],
    };
    const modes = ['static', 'dynamic', 'kinematic', 'character', 'trigger'];
    for (const [id, accepted] of Object.entries(table)) {
      for (const mode of modes) {
        const r = run(id, body(mode));
        expect(r.ok, `${id} × ${mode}`).toBe(accepted.includes(mode));
        if (!r.ok) expect(r.code).toBe('physics.incompatible_body_mode');
      }
    }
  });

  it('sem corpo físico, ou sem nó, é erro explícito; corpo desligado só vale para Set Physics Enabled', () => {
    const noBody = node('MeshInstance', {});
    const r1 = run('add_impulse', noBody);
    expect(r1.ok).toBe(false);
    if (!r1.ok) expect(r1.code).toBe('physics.no_body');
    const r2 = run('add_impulse', undefined);
    expect(r2.ok).toBe(false);
    if (!r2.ok) expect(r2.code).toBe('action.no_target');
    const off = body('dynamic', { enabled: false });
    const r3 = run('add_force', off);
    expect(r3.ok).toBe(false);
    if (!r3.ok) expect(r3.code).toBe('physics.body_disabled');
    expect(run('set_physics_enabled', off, { enabled: true }).ok).toBe(true); // religar o corpo desligado
  });

  it('parâmetros: física de material limita a [0, 1]; vetor digitado como texto é coagido; inválido é rejeitado', () => {
    const mat = run('set_physics_material', body('dynamic'), { friction: 9, bounce: -2 });
    expect(mat.ok && mat.params).toMatchObject({ friction: 1, bounce: 0 });
    const imp = run('add_impulse', body('dynamic'), { impulse: { x: '2', y: '0', z: '0' } });
    expect(imp.ok && imp.params.impulse).toEqual({ x: 2, y: 0, z: 0 });
    const bad = run('add_force', body('dynamic'), { space: 'galaxy' });
    expect(bad.ok).toBe(false);
    if (!bad.ok) expect(bad.code).toBe('action.invalid_params');
  });
});

describe('AIS-79 — Executar Script habilitada pelo sandbox (C02b)', () => {
  const def = () => LogicRegistry.getAction('run_script')!;

  it('declara scriptRef (file) restrito a .js de res://scripts/ e está habilitada (.ts: em breve)', () => {
    expect(def().status).not.toBe('disabled');
    expect(def().category).toBe('Logic');
    const p = def().params.find((x) => x.key === 'scriptRef')!;
    expect(p.type).toBe('file');
    expect(p.accept).toEqual(['.js']);
  });

  it('o schema só aceita .js em res://scripts/ (ou vazio); .ts é recusado até a transpilação existir', () => {
    const ok = (v: string) => def().paramsSchema.safeParse({ scriptRef: v }).success;
    expect(ok('')).toBe(true);
    expect(ok('res://scripts/boss.js')).toBe(true);
    expect(ok('res://scripts/ai/boss.js')).toBe(true);
    expect(ok('res://scripts/ai/boss.ts')).toBe(false);
    expect(ok('res://scenes/Main.scene.json')).toBe(false);
    expect(ok('res://scripts/boss.json')).toBe(false);
    expect(ok('res://other/boss.js')).toBe(false);
    expect(ok('https://evil.example/boss.js')).toBe(false);
  });

  it('executa: a validação aceita e o executor só chama a EngineApi (nunca eval/new Function/Worker direto)', () => {
    const r = validateAction({ type: 'run_script', parameters: { scriptRef: 'res://scripts/boss.js' } }, ctx(node('Spatial')));
    expect(r.ok).toBe(true);
    const source = fs.readFileSync(path.join(__dirname, 'actions', 'run_script', 'runtime.ts'), 'utf8');
    expect(source).toContain('ctx.engine.scripts.run');
    expect(source).not.toMatch(/new Function|eval\(|new Worker/);
  });
});

describe('AIS-41 — validação de contexto das demais Actions', () => {
  const run = (id: string, target?: ConditionNode, parameters: Record<string, unknown> = {}) => validateAction({ type: id, parameters }, ctx(target));

  it('change_text só em nós de texto; change_texture só em overlays de imagem', () => {
    expect(run('change_text', node('TextOverlay2D'), { text: 'Score: $score$' }).ok).toBe(true);
    const bad = run('change_text', node('MeshInstance'));
    expect(bad.ok).toBe(false);
    if (!bad.ok) expect(bad.code).toBe('action.incompatible_node_type');
    expect(run('change_texture', node('Overlay2D'), { texture: 'res://textures/a.png' }).ok).toBe(true);
    expect(run('change_texture', node('Camera')).ok).toBe(false);
  });

  it('aceita o alias image de change_texture sem perder o parâmetro', () => {
    const r = run('change_texture', node('Overlay2D'), { image: 'res://textures/a.png' });
    expect(r.ok && r.params.image).toBe('res://textures/a.png');
  });

  it('emit_particles exige ParticleSystem e count inteiro >= 1', () => {
    expect(run('emit_particles', node('ParticleSystem'), { count: 12 }).ok).toBe(true);
    expect(run('emit_particles', node('MeshInstance'), { count: 12 }).ok).toBe(false);
    expect(run('emit_particles', node('ParticleSystem'), { count: 0 }).ok).toBe(false);
    expect(run('emit_particles', node('ParticleSystem'), { count: 2.5 }).ok).toBe(false);
  });

  it('ações 3D (look_at, move_velocity, rotate_continuous) rejeitam nós de UI', () => {
    for (const id of ['look_at', 'move_velocity', 'rotate_continuous']) {
      expect(run(id, node('Spatial')).ok, id).toBe(true);
      const r = run(id, node('ButtonOverlay2D'));
      expect(r.ok, id).toBe(false);
      if (!r.ok) expect(r.code).toBe('action.incompatible_node_type');
    }
  });

  it('animação exige MeshInstance; emissivo exige MeshInstance com cor hexadecimal', () => {
    expect(run('play_animation', node('MeshInstance'), { animation: 'Walk' }).ok).toBe(true);
    expect(run('stop_animation', node('Camera')).ok).toBe(false);
    expect(run('set_emissive_color', node('MeshInstance'), { color: '#ff8800' }).ok).toBe(true);
    expect(run('set_emissive_color', node('MeshInstance'), { color: 'laranja' }).ok).toBe(false);
  });

  it('Actions sem restrição de alvo (print_log, toggle_visible, restart_scene) aceitam sem contexto', () => {
    expect(validateAction({ type: 'print_log', parameters: { text: 'oi' } }).ok).toBe(true);
    expect(validateAction({ type: 'toggle_visible', parameters: {} }).ok).toBe(true);
    expect(validateAction({ type: 'restart_scene', parameters: {} }).ok).toBe(true);
  });
});

describe('AIS-41 — dados antigos e IDs desconhecidos', () => {
  it('parâmetros gravados por cenas antigas das 9 Actions originais continuam válidos', () => {
    const old: [string, Record<string, unknown>][] = [
      ['move_by', { dx: 1, dz: 0 }],
      ['rotate_by', { degrees: 2 }],
      ['print_log', { text: 'oi' }],
      ['set_position', { x: 1, y: 2, z: 3 }],
      ['set_visible', { visible: false }],
      ['play_sound', { sound: 'res://audio/a.wav' }],
      ['change_scene', { scenePath: 'res://scenes/B.scene.json' }],
      ['destroy_node', { target: 'X' }],
      ['emit_signal', { signal: 'hit' }],
    ];
    for (const [id, parameters] of old) {
      const r = validateAction({ type: id, parameters });
      expect(r.ok, id).toBe(true);
    }
  });

  it('ID desconhecido não lança: vira action.unknown (dados preservados) e não executa', () => {
    const r = validateAction({ type: 'acao_de_outra_versao', parameters: { segredo: [1, 2] } });
    expect(r.ok).toBe(false);
    if (!r.ok) {
      expect(r.code).toBe('action.unknown');
      expect(r.message).toContain('preservados');
    }
  });

  it('campos de 3D marcados para esconder em nós de UI: o Z de set_position e o dz de move_by', () => {
    const hidden = (id: string) => LogicRegistry.getAction(id)!.params.filter((p) => p.hideForUi).map((p) => p.key);
    expect(hidden('set_position')).toEqual(['z']);
    expect(hidden('move_by')).toEqual(['dz']);
  });
});
