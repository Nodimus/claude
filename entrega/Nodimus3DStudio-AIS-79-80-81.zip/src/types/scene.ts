import { GameNode, NodeData } from './node';

export type { NodeData };

export interface BloomSettings {
  enabled: boolean;
  blurIterations: number; // Bloom_BlurIterations (1-10)
  threshold: number;      // Bloom_Threshold (0.0-1.0)
  radius: number;         // Bloom spread radius (0.0-1.0)
}

export interface BlurSettings {
  enabled: boolean;
  iterations: number;     // Blur_Iterations (1-10)
}

export interface ColorizeSettings {
  enabled: boolean;
  color: string;          // Colorize_Color (hex or color string)
}

export interface VignetteSettings {
  enabled: boolean;
  intensity: number;      // Vignette_Intensity (0.0-1.0)
  radiusA: number;        // Vignette_RadiusA (0.0-1.0)
  radiusB: number;        // Vignette_RadiusB (0.0-1.0)
}

/** AIS-55: Screen Space Ambient Occlusion settings */
export interface SsaoSettings {
  enabled: boolean;
  intensity: number;      // SSAO intensity (0.0-2.0)
  radius: number;         // Shadow corner radius in world units (0.01-1.0)
}

/** AIS-55: Image color/tone adjustment settings */
export type ToneMappingMode = 'none' | 'filmic' | 'reinhard';

export interface ImageAdjustSettings {
  enabled: boolean;
  brightness: number;     // 0 to 200 (100 = default)
  contrast: number;       // 0 to 200 (100 = default)
  saturation: number;     // 0 to 200 (100 = default)
  toneMapping: ToneMappingMode;
}

export interface PostProcessingSettings {
  bloom: BloomSettings;
  blackAndWhite: { enabled: boolean };
  invert: { enabled: boolean };
  blur: BlurSettings;
  colorize: ColorizeSettings;
  vignette: VignetteSettings;
  /** AIS-55: Screen Space Ambient Occlusion */
  ssao: SsaoSettings;
  /** AIS-55: Image brightness/contrast/saturation/tone mapping */
  imageAdjust: ImageAdjustSettings;
}

export const DEFAULT_POST_PROCESSING: PostProcessingSettings = {
  bloom: {
    enabled: false,
    blurIterations: 3,
    threshold: 0.8,
    radius: 0.4,
  },
  blackAndWhite: {
    enabled: false,
  },
  invert: {
    enabled: false,
  },
  blur: {
    enabled: false,
    iterations: 2,
  },
  colorize: {
    enabled: false,
    color: '#ff6600',
  },
  vignette: {
    enabled: false,
    intensity: 0.6,
    radiusA: 0.4,
    radiusB: 0.8,
  },
  ssao: {
    enabled: false,
    intensity: 1.0,
    radius: 0.1,
  },
  imageAdjust: {
    enabled: false,
    brightness: 100,
    contrast: 100,
    saturation: 100,
    toneMapping: 'filmic',
  },
};


export type FogMode = 'exponential2' | 'exponential' | 'linear' | 'height';

export interface SceneFogSettings {
  enabled: boolean;
  mode: FogMode;
  color: string;
  density: number;        // e.g. 0.0001 to 0.05 (for exponential/exp2)
  near: number;           // linear start distance in meters
  far: number;            // linear end distance in meters
  height: number;         // ground/height fog elevation ceiling in meters
  heightFalloff: number;  // falloff rate with altitude (0.1 - 2.0)
  affectSkybox: boolean;  // whether fog tints the background sky
  windDrift: boolean;     // animated fog wave drift
  windSpeed: number;      // drift velocity
}

export const DEFAULT_SCENE_FOG: SceneFogSettings = {
  enabled: false,
  mode: 'exponential2',
  color: '#8fa4b8',
  density: 0.008,
  near: 15,
  far: 180,
  height: 12,
  heightFalloff: 0.6,
  affectSkybox: false,
  windDrift: true,
  windSpeed: 0.5,
};

export interface SceneEnvironment {
  /** Ambient light color (hex) */
  ambientColor: string;
  /** Ambient light intensity (0–1) */
  ambientIntensity: number;
  /** Background/sky color (hex) */
  backgroundColor: string;
  /** Enable real-time shadows */
  realtimeShadows: boolean;
  /** Gravity vector for the scene */
  gravity: { x: number; y: number; z: number };
  /** Global wind vector */
  wind: { x: number; y: number; z: number };
}

export const DEFAULT_SCENE_ENVIRONMENT: SceneEnvironment = {
  ambientColor: '#334155',
  ambientIntensity: 0.4,
  backgroundColor: '#1a1a2e',
  realtimeShadows: true,
  gravity: { x: 0, y: -9.8, z: 0 },
  wind: { x: 0, y: 0, z: 0 },
};

/** AIS-74 — "Travar View" da câmera de EDIÇÃO, por cena: ligado + a rotação orbital (radianos) congelada ao ligar. */
export interface ViewLockState {
  locked: boolean;
  theta: number;
  phi: number;
}

export interface SceneCameraSettings {
  /** Field of view in degrees */
  fov: number;
  /** Near clipping plane */
  near: number;
  /** Far clipping plane */
  far: number;
  /** Editor camera position (authoring only) */
  position: { x: number; y: number; z: number };
  /** Editor camera look-at target */
  target: { x: number; y: number; z: number };
  /** AIS-74: Travar View (ausente = desligado). Só a rotação orbital; pan e zoom seguem livres. */
  viewLock?: ViewLockState;
}

export const DEFAULT_SCENE_CAMERA: SceneCameraSettings = {
  fov: 65,
  near: 0.1,
  far: 1000,
  position: { x: 0, y: 3, z: 8 },
  target: { x: 0, y: 0, z: 0 },
};

export type EnvironmentSettings = SceneEnvironment;

export interface SceneData {
  schemaVersion?: number;
  id: string;
  name: string;
  path: string; // e.g. "res://scenes/Main.scene.json"
  rootNodeId: string;
  /** ID of the 0..1 Environment node in this scene (if present) */
  environmentNodeId?: string | null;
  nodes: Record<string, GameNode>;
  environment?: SceneEnvironment;
  /** Canonical environment settings alias for environment */
  environmentSettings?: SceneEnvironment;
  cameraSettings?: SceneCameraSettings;
  postProcessing?: PostProcessingSettings;
  fog?: SceneFogSettings;
  /**
   * Dados da cena fora do grafo de nós (AIS-41b): `legacyBehaviors` guarda, intacto, o que a migração não conseguiu anexar a um
   * nó (Behavior sem dono, ID de lista global sem definição). É gravado de volta; nada é descartado.
   */
  metadata?: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
}

export * from './sceneFile';
export * from './runtime';

/**
 * AIS-04: Desktop shortcut actions for scene lifecycle and playback.
 * Conforms to Item 2 Opção C (Desktop Keyboard Shortcuts).
 */
export type SceneShortcutAction =
  | 'save_scene' // Ctrl+S / Cmd+S
  | 'play_project' // F5
  | 'play_scene' // F6
  | 'stop_simulation'; // F8

