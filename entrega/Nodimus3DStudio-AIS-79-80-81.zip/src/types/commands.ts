/**
 * Command do editor (AIS-18 · decisão canônica 10).
 *
 * `label` é o campo canônico. `name` é aceito por compatibilidade com os Commands
 * já existentes e `description` é alias; informe ao menos um dos três (use
 * `getCommandLabel` para ler). `timestamp` é atribuído pelo `CommandManager` ao
 * registrar o Command — quem cria o Command não precisa informá-lo.
 */
export interface ICommandBase {
  execute: () => void;
  undo: () => void;
  redo?: () => void;
  /** Atribuído pelo CommandManager (ms desde a época) ao entrar no histórico. */
  timestamp?: number;
  /**
   * AIS-24 — mescla por gesto: dentro de `beginGesture()`/`endGesture()`, um Command com a mesma
   * `mergeKey` do primeiro Command do gesto é absorvido por ele (`merge`) em vez de virar nova
   * entrada. O resultado é UMA entrada: valor inicial → valor final.
   */
  mergeKey?: string;
  /** Absorve `next` (já executado); devolve `false` se não puder (vira entrada própria). */
  merge?: (next: ICommand) => boolean;
}

export type ICommand = ICommandBase &
  (
    | { label: string; name?: string; description?: string }
    | { name: string; label?: string; description?: string }
    | { description: string; label?: string; name?: string }
  );

/** Rótulo canônico do Command: `label` → `name` → `description`. */
export function getCommandLabel(command: ICommand): string {
  return command.label ?? command.name ?? command.description ?? '';
}

/** Item do histórico exposto para a UI (sem as funções do Command). */
export interface CommandHistoryEntry {
  label: string;
  timestamp: number;
}
