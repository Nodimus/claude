import { ColorData, ResourceRef, Vector2Data } from './node';

export type ShadingModel = 'Standard' | 'Physical' | 'Phong' | 'Toon' | 'Basic';

export type TexturePatternType =
  | 'none'
  | 'checkerboard'
  | 'grid'
  | 'hex'
  | 'noise'
  | 'brick'
  | 'dots'
  | 'wood'
  | 'brushed'
  | 'marble'
  | 'lava'
  | 'cyberpunk'
  | 'fabric'
  | 'custom_image';

export type PreviewMeshShape =
  | 'Sphere'
  | 'Cube'
  | 'Cylinder'
  | 'Torus'
  | 'TorusKnot'
  | 'Plane'
  | 'Capsule'
  | 'CurrentSceneMesh';

export type PreviewLightingEnvironment =
  | 'StudioNeutral'
  | 'GoldenHour'
  | 'CyberpunkNeon'
  | 'OvercastSoft'
  | 'DramaticSpotlight'
  | 'DarkVoid';

export interface MaterialProperties {
  id?: string;
  name: string;
  shadingModel: ShadingModel;
  
  // Base Surface
  color: ColorData;
  roughness: number;
  metalness: number;
  wireframe: boolean;
  flatShading: boolean;
  side: 'front' | 'back' | 'double';
  
  // Advanced PBR & Physical
  emissiveColor: ColorData;
  emissiveIntensity: number;
  clearcoat: number;
  clearcoatRoughness: number;
  transmission: number; // Glass / transparent refraction
  opacity: number;
  transparent: boolean;
  ior: number; // Index of Refraction (default 1.5)
  
  // Textures & Maps
  textureType: TexturePatternType;
  customImageDataUrl?: string;
  textureFileName?: string;
  textureScale: number;
  textureColorA: string;
  textureColorB: string;
  
  // Normal & Bump
  enableNormalMap: boolean;
  normalMapType: 'procedural' | 'none';
  normalScale: number;
  
  // UV Mapping
  uvTiling: Vector2Data;
  uvOffset: Vector2Data;
  uvRotation: number;
  wrapMode: 'repeat' | 'clamp' | 'mirror';
}

/**
 * AIS-25 — material por nó: `GameNode.properties.materialOverride` (modelo único; as antigas chaves planas
 * `materialColor`/`roughness`/... são lidas só por compatibilidade, ver `src/core/material/nodeMaterial.ts`).
 *
 * Guarda os mesmos canais de `MaterialProperties` (parcial: o que falta vem dos padrões), sem `name`
 * (o nome é do nó) e SEM `customImageDataUrl` (nunca base64 na cena): a textura de albedo é uma
 * referência `ResourceRef` a um arquivo de `res://textures/`.
 */
export type MaterialOverride = Partial<Omit<MaterialProperties, 'name' | 'customImageDataUrl'>> & {
  /** Textura de albedo em `res://textures/` (referência, nunca o conteúdo). */
  albedoTexture?: ResourceRef;
  /** Mapa normal em `res://textures/` (referência; AIS-35: gerado no import para padrões procedurais de modelos). */
  normalTexture?: ResourceRef;
  /** Último preset aplicado (marca informativa; os valores vivem no override). */
  presetId?: string;
};

export const DEFAULT_MATERIAL_PROPERTIES: MaterialProperties = {
  name: 'Standard PBR Material',
  shadingModel: 'Standard',
  color: { r: 0.28, g: 0.52, b: 0.92, a: 1 },
  roughness: 0.35,
  metalness: 0.15,
  wireframe: false,
  flatShading: false,
  side: 'front',
  emissiveColor: { r: 0, g: 0, b: 0, a: 1 },
  emissiveIntensity: 0,
  clearcoat: 0,
  clearcoatRoughness: 0.1,
  transmission: 0,
  opacity: 1,
  transparent: false,
  ior: 1.5,
  textureType: 'none',
  textureScale: 4,
  textureColorA: '#2c3345',
  textureColorB: '#4982ea',
  enableNormalMap: false,
  normalMapType: 'none',
  normalScale: 1.0,
  uvTiling: { x: 1, y: 1 },
  uvOffset: { x: 0, y: 0 },
  uvRotation: 0,
  wrapMode: 'repeat',
};

export interface MaterialPreset {
  id: string;
  name: string;
  category: 'Metals' | 'Architectural' | 'Sci-Fi' | 'Organic' | 'Natural' | 'Gems & Glass' | 'Stylized';
  description: string;
  properties: Partial<MaterialProperties>;
  previewColor: string;
}

export const MATERIAL_PRESETS: MaterialPreset[] = [
  // METALS
  {
    id: 'gold_polished',
    name: 'Ouro Polido 24K (Gold)',
    category: 'Metals',
    description: 'Metal dourado de altíssima refletividade com brilho especular fino e bordas suaves.',
    previewColor: '#e5b33b',
    properties: {
      name: 'Ouro Polido 24K',
      shadingModel: 'Standard',
      color: { r: 0.96, g: 0.78, b: 0.25, a: 1 },
      roughness: 0.12,
      metalness: 0.95,
      clearcoat: 0.4,
      clearcoatRoughness: 0.1,
      textureType: 'none',
    },
  },
  {
    id: 'chrome_mirror',
    name: 'Cromo Espelhado (Chrome)',
    category: 'Metals',
    description: 'Reflexo puro ultra-liso com espelhamento perfeito do ambiente.',
    previewColor: '#d6dfe8',
    properties: {
      name: 'Cromo Espelhado',
      shadingModel: 'Standard',
      color: { r: 0.92, g: 0.95, b: 0.98, a: 1 },
      roughness: 0.05,
      metalness: 1.0,
      clearcoat: 0.8,
      textureType: 'none',
    },
  },
  {
    id: 'copper_brushed',
    name: 'Cobre Escovado (Brushed Copper)',
    category: 'Metals',
    description: 'Cobre metálico avermelhado com ranhuras de escovamento direcional.',
    previewColor: '#c86432',
    properties: {
      name: 'Cobre Escovado',
      shadingModel: 'Standard',
      color: { r: 0.88, g: 0.44, b: 0.25, a: 1 },
      roughness: 0.38,
      metalness: 0.88,
      textureType: 'brushed',
      textureScale: 6,
      textureColorA: '#a03b14',
      textureColorB: '#d66c3d',
      enableNormalMap: true,
      normalScale: 0.6,
    },
  },
  {
    id: 'dark_steel',
    name: 'Aço Escuro Gunmetal',
    category: 'Metals',
    description: 'Metal industrial fosco resistente com acabamento tático escuro.',
    previewColor: '#3a414f',
    properties: {
      name: 'Aço Gunmetal',
      shadingModel: 'Standard',
      color: { r: 0.22, g: 0.25, b: 0.3, a: 1 },
      roughness: 0.45,
      metalness: 0.8,
      textureType: 'none',
    },
  },

  // SCI-FI
  {
    id: 'scifi_hex_armor',
    name: 'Blindagem Hexagonal Sci-Fi',
    category: 'Sci-Fi',
    description: 'Placas hexagonais de blindagem reforçada com canais de energia e micro-detalhes.',
    previewColor: '#1e2638',
    properties: {
      name: 'Blindagem Hexagonal',
      shadingModel: 'Standard',
      color: { r: 0.16, g: 0.2, b: 0.28, a: 1 },
      roughness: 0.28,
      metalness: 0.75,
      textureType: 'hex',
      textureScale: 6,
      textureColorA: '#151b27',
      textureColorB: '#3a5078',
      enableNormalMap: true,
      normalScale: 1.2,
      uvTiling: { x: 2, y: 2 },
    },
  },
  {
    id: 'cyber_neon_matrix',
    name: 'Matriz Cyberpunk Neon',
    category: 'Sci-Fi',
    description: 'Superfície escura com grade cibernética emissiva pulsante azul-ciano.',
    previewColor: '#00e5ff',
    properties: {
      name: 'Cyberpunk Neon Matrix',
      shadingModel: 'Standard',
      color: { r: 0.08, g: 0.1, b: 0.15, a: 1 },
      roughness: 0.2,
      metalness: 0.4,
      emissiveColor: { r: 0.0, g: 0.9, b: 1.0, a: 1 },
      emissiveIntensity: 1.8,
      textureType: 'cyberpunk',
      textureScale: 5,
      textureColorA: '#0d131d',
      textureColorB: '#00f0ff',
      enableNormalMap: true,
      normalScale: 0.8,
    },
  },
  {
    id: 'carbon_fiber',
    name: 'Fibra de Carbono Trançada',
    category: 'Sci-Fi',
    description: 'Tecido de carbono composto leve de alto desempenho com reflexos anisotrópicos.',
    previewColor: '#22252a',
    properties: {
      name: 'Fibra de Carbono',
      shadingModel: 'Physical',
      color: { r: 0.12, g: 0.13, b: 0.15, a: 1 },
      roughness: 0.35,
      metalness: 0.2,
      clearcoat: 0.9,
      clearcoatRoughness: 0.15,
      textureType: 'checkerboard',
      textureScale: 16,
      textureColorA: '#141618',
      textureColorB: '#282b30',
      enableNormalMap: true,
      normalScale: 1.5,
    },
  },

  // ARCHITECTURAL
  {
    id: 'red_brick_wall',
    name: 'Tijolo Aparente (Red Brick)',
    category: 'Architectural',
    description: 'Alvenaria clássica com relevo acentuado de argamassa e textura áspera.',
    previewColor: '#96422f',
    properties: {
      name: 'Tijolo Aparente',
      shadingModel: 'Standard',
      color: { r: 0.62, g: 0.28, b: 0.2, a: 1 },
      roughness: 0.85,
      metalness: 0.02,
      textureType: 'brick',
      textureScale: 5,
      textureColorA: '#8b3824',
      textureColorB: '#d1cdc7',
      enableNormalMap: true,
      normalScale: 1.6,
      uvTiling: { x: 2, y: 2 },
    },
  },
  {
    id: 'marble_carrara',
    name: 'Mármore Nobre (White Marble)',
    category: 'Architectural',
    description: 'Pedra de mármore polida com veios escuros elegantes e reflexos cerâmicos.',
    previewColor: '#e8edf2',
    properties: {
      name: 'Mármore Branco',
      shadingModel: 'Physical',
      color: { r: 0.92, g: 0.94, b: 0.96, a: 1 },
      roughness: 0.15,
      metalness: 0.05,
      clearcoat: 0.7,
      clearcoatRoughness: 0.1,
      textureType: 'marble',
      textureScale: 4,
      textureColorA: '#f2f5f8',
      textureColorB: '#768296',
    },
  },
  {
    id: 'wood_oak_parquet',
    name: 'Madeira Carvalho Nobre',
    category: 'Architectural',
    description: 'Madeira natural com anéis de crescimento e tom acolhedor.',
    previewColor: '#9e6231',
    properties: {
      name: 'Madeira Carvalho',
      shadingModel: 'Standard',
      color: { r: 0.68, g: 0.42, b: 0.22, a: 1 },
      roughness: 0.6,
      metalness: 0.0,
      textureType: 'wood',
      textureScale: 4,
      textureColorA: '#593214',
      textureColorB: '#995f32',
      enableNormalMap: true,
      normalScale: 0.8,
    },
  },

  // GEMS & GLASS
  {
    id: 'emerald_gem',
    name: 'Esmeralda Cristalina (Gem)',
    category: 'Gems & Glass',
    description: 'Pedra preciosa verde vítrea translúcida com brilho cristalino intenso.',
    previewColor: '#10b981',
    properties: {
      name: 'Esmeralda',
      shadingModel: 'Physical',
      color: { r: 0.08, g: 0.78, b: 0.48, a: 0.85 },
      roughness: 0.08,
      metalness: 0.1,
      transmission: 0.8,
      transparent: true,
      opacity: 0.9,
      ior: 1.58,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
      textureType: 'none',
    },
  },
  {
    id: 'frosted_glass',
    name: 'Vidro Jateado (Frosted Glass)',
    category: 'Gems & Glass',
    description: 'Vidro translúcido com dispersão de luz fosca suave.',
    previewColor: '#b0d4f1',
    properties: {
      name: 'Vidro Jateado',
      shadingModel: 'Physical',
      color: { r: 0.85, g: 0.92, b: 0.98, a: 0.6 },
      roughness: 0.42,
      metalness: 0.0,
      transmission: 0.75,
      transparent: true,
      opacity: 0.65,
      ior: 1.5,
      textureType: 'none',
    },
  },
  {
    id: 'ruby_red',
    name: 'Rubi Cintilante',
    category: 'Gems & Glass',
    description: 'Gema vermelha profunda com refração acentuada.',
    previewColor: '#e11d48',
    properties: {
      name: 'Rubi Vermelho',
      shadingModel: 'Physical',
      color: { r: 0.9, g: 0.1, b: 0.28, a: 0.9 },
      roughness: 0.06,
      metalness: 0.15,
      transmission: 0.7,
      transparent: true,
      opacity: 0.92,
      clearcoat: 0.9,
      textureType: 'none',
    },
  },

  // ORGANIC & ELEMENTAL
  {
    id: 'lava_magma',
    name: 'Magma / Rocha Vulcânica',
    category: 'Organic',
    description: 'Crosta basáltica negra fissurada com lava incandescente emissiva.',
    previewColor: '#ff4d00',
    properties: {
      name: 'Magma Vulcânico',
      shadingModel: 'Standard',
      color: { r: 0.15, g: 0.12, b: 0.12, a: 1 },
      roughness: 0.75,
      metalness: 0.1,
      emissiveColor: { r: 1.0, g: 0.32, b: 0.0, a: 1 },
      emissiveIntensity: 2.5,
      textureType: 'lava',
      textureScale: 4,
      textureColorA: '#151313',
      textureColorB: '#ff3700',
      enableNormalMap: true,
      normalScale: 1.8,
    },
  },
  {
    id: 'mossy_stone',
    name: 'Pedra com Musgo (Mossy Stone)',
    category: 'Organic',
    description: 'Rocha calcária desgastada com manchas orgânicas de musgo úmido.',
    previewColor: '#4d6347',
    properties: {
      name: 'Pedra com Musgo',
      shadingModel: 'Standard',
      color: { r: 0.32, g: 0.4, b: 0.28, a: 1 },
      roughness: 0.9,
      metalness: 0.02,
      textureType: 'noise',
      textureScale: 6,
      textureColorA: '#4a5345',
      textureColorB: '#2a3a22',
      enableNormalMap: true,
      normalScale: 1.4,
    },
  },

  // NATURAL (AIS-25) — usam só os padrões procedurais já existentes (noise/wood/brushed)
  {
    id: 'water_clear',
    name: 'Água Cristalina (Water)',
    category: 'Natural',
    description: 'Superfície de água translúcida e lisa, com leve ondulação no normal map.',
    previewColor: '#1f6f9c',
    properties: {
      name: 'Água Cristalina',
      shadingModel: 'Physical',
      color: { r: 0.1, g: 0.42, b: 0.62, a: 1 },
      roughness: 0.05,
      metalness: 0,
      opacity: 0.85,
      transparent: true,
      transmission: 0.5,
      clearcoat: 1,
      clearcoatRoughness: 0.05,
      ior: 1.33,
      textureType: 'noise',
      textureScale: 8,
      textureColorA: '#1c5f87',
      textureColorB: '#0d3550',
      enableNormalMap: true,
      normalScale: 0.5,
    },
  },
  {
    id: 'wood_rustic',
    name: 'Madeira Rústica (Wood)',
    category: 'Natural',
    description: 'Madeira escura com veios marcados e acabamento fosco, boa para postes e caixas.',
    previewColor: '#5e3d20',
    properties: {
      name: 'Madeira Rústica',
      shadingModel: 'Standard',
      color: { r: 0.45, g: 0.3, b: 0.17, a: 1 },
      roughness: 0.8,
      metalness: 0,
      textureType: 'wood',
      textureScale: 5,
      textureColorA: '#5e3d20',
      textureColorB: '#3a2412',
      enableNormalMap: true,
      normalScale: 0.8,
    },
  },
  {
    id: 'dirt_soil',
    name: 'Terra Batida (Dirt)',
    category: 'Natural',
    description: 'Solo marrom irregular, totalmente fosco, para chão e trilhas.',
    previewColor: '#4d3623',
    properties: {
      name: 'Terra Batida',
      shadingModel: 'Standard',
      color: { r: 0.33, g: 0.23, b: 0.15, a: 1 },
      roughness: 0.97,
      metalness: 0,
      textureType: 'noise',
      textureScale: 8,
      textureColorA: '#4d3623',
      textureColorB: '#2c1e12',
      enableNormalMap: true,
      normalScale: 1.2,
    },
  },
  {
    id: 'stone_gray',
    name: 'Pedra Cinza (Stone)',
    category: 'Natural',
    description: 'Rocha cinza áspera com relevo pronunciado.',
    previewColor: '#7d7d82',
    properties: {
      name: 'Pedra Cinza',
      shadingModel: 'Standard',
      color: { r: 0.5, g: 0.5, b: 0.52, a: 1 },
      roughness: 0.88,
      metalness: 0.02,
      textureType: 'noise',
      textureScale: 6,
      textureColorA: '#7d7d82',
      textureColorB: '#4a4a50',
      enableNormalMap: true,
      normalScale: 1.6,
    },
  },
  {
    id: 'grass_lawn',
    name: 'Grama (Grass)',
    category: 'Natural',
    description: 'Gramado verde denso e fosco para terrenos e planícies.',
    previewColor: '#3f8a2c',
    properties: {
      name: 'Grama',
      shadingModel: 'Standard',
      color: { r: 0.25, g: 0.55, b: 0.18, a: 1 },
      roughness: 0.95,
      metalness: 0,
      textureType: 'noise',
      textureScale: 10,
      textureColorA: '#3f8a2c',
      textureColorB: '#1f5a14',
      enableNormalMap: true,
      normalScale: 0.8,
    },
  },
  {
    id: 'metal_iron',
    name: 'Ferro Industrial (Iron)',
    category: 'Metals',
    description: 'Metal cinza escovado de aspecto industrial, rugosidade média.',
    previewColor: '#8d9299',
    properties: {
      name: 'Ferro Industrial',
      shadingModel: 'Standard',
      color: { r: 0.55, g: 0.57, b: 0.6, a: 1 },
      roughness: 0.45,
      metalness: 0.9,
      textureType: 'brushed',
      textureScale: 4,
      textureColorA: '#8d9299',
      textureColorB: '#5b6168',
      enableNormalMap: true,
      normalScale: 0.6,
    },
  },

  // STYLIZED
  {
    id: 'toon_cel_shaded',
    name: 'Toon Cel-Shaded (Anime / HQ)',
    category: 'Stylized',
    description: 'Sombreamento plano em faixas demarcadas estilo desenho animado e quadrinhos.',
    previewColor: '#3b82f6',
    properties: {
      name: 'Toon Cel-Shaded',
      shadingModel: 'Toon',
      color: { r: 0.25, g: 0.55, b: 0.95, a: 1 },
      roughness: 0.1,
      metalness: 0.0,
      textureType: 'none',
    },
  },
  {
    id: 'prototype_grid',
    name: 'Grade de Prototipagem UV (Dev Grid)',
    category: 'Stylized',
    description: 'Textura padrão de desenvolvimento com marcações quadriculadas de escala 1x1m.',
    previewColor: '#ff9900',
    properties: {
      name: 'Dev Grid Prototype',
      shadingModel: 'Standard',
      color: { r: 0.95, g: 0.55, b: 0.1, a: 1 },
      roughness: 0.5,
      metalness: 0.05,
      textureType: 'grid',
      textureScale: 8,
      textureColorA: '#1c222e',
      textureColorB: '#f59e0b',
      uvTiling: { x: 2, y: 2 },
    },
  },
  {
    id: 'wireframe_hologram',
    name: 'Holograma Wireframe Neon',
    category: 'Stylized',
    description: 'Aparência holográfica futurista com malha aramada transparente brilhante.',
    previewColor: '#10b981',
    properties: {
      name: 'Holograma Wireframe',
      shadingModel: 'Basic',
      color: { r: 0.1, g: 0.95, b: 0.6, a: 0.8 },
      wireframe: true,
      transparent: true,
      opacity: 0.75,
      textureType: 'none',
    },
  },
];
