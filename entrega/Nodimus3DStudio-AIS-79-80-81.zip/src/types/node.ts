import type { NODE_DEFINITIONS } from '../nodes/registry';
import type { NodeSignalConnection } from './signal';
import type { BehaviorInstance } from './visualLogic';
import type { GeneratorSource } from './generatorSource';

export type NodeCategory = 'Core' | '3D' | '2D Overlay' | 'Audio' | 'Misc';

/** Aba do diálogo "Create New Node" em que o tipo aparece. */
export type CreateNodeCategory = '3D Nodes' | 'Lights' | 'Animation & Audio' | 'Environment' | 'UI' | 'Special';

/**
 * Fonte única dos tipos de nó: as chaves de `NODE_DEFINITIONS` (`src/nodes/registry.ts`, decisão 19).
 * Adicionar um tipo = adicionar uma entrada no registry; não editar união, schema nem listas de UI.
 */
export type NodeType = keyof typeof NODE_DEFINITIONS;

export interface Vector2Data {
  x: number;
  y: number;
}

export interface Vector3Data {
  x: number;
  y: number;
  z: number;
}

export interface ColorData {
  r: number;
  g: number;
  b: number;
  a: number;
}

export type Vector3Tuple = [x: number, y: number, z: number];
export type QuaternionTuple = [x: number, y: number, z: number, w: number];

export interface QuaternionData {
  x: number;
  y: number;
  z: number;
  w: number;
}

/** Rotation can be represented as Euler angles in degrees or Quaternion */
export type Rotation3D = Vector3Data | QuaternionData | Vector3Tuple | QuaternionTuple;
export type Position3D = Vector3Data | Vector3Tuple;
export type Scale3D = Vector3Data | Vector3Tuple;

/**
 * Transform3D — local transform of a GameNode relative to its parent.
 * Rotation is stored in Euler degrees (XYZ order) or Quaternion [x, y, z, w].
 * No Three.js types or runtime instances are referenced here.
 */
export interface Transform3D {
  position: Position3D;
  /** Euler angles in degrees or Quaternion */
  rotation: Rotation3D;
  scale: Scale3D;
}

export const DEFAULT_TRANSFORM_3D: Transform3D = {
  position: { x: 0, y: 0, z: 0 },
  rotation: { x: 0, y: 0, z: 0 },
  scale: { x: 1, y: 1, z: 1 },
};

/**
 * ResourceRef — canonical cross-document contract for resource references (AIS-03b).
 * Preserves identity independent of file path or human-readable label.
 * Survives file rename and move operations.
 */
export interface ResourceRef {
  /** Stable, globally unique identifier (UUID/nanoid) — never the file path */
  id: string;
  /** Resource type ('scene', 'mesh', 'texture', 'material', 'audio', 'script', etc.) */
  type?: string;
  /** Normalized project-relative path, e.g. "res://scenes/Main.scene.json" */
  path?: string;
  /** Human-readable label (translatable/authoring). NOT used as identity key */
  label?: string;
  /** Flag marking missing or unresolved references — preserved without silent deletion */
  unresolved?: boolean;
  /** Opaque additional data (preserved, never discarded) */
  [key: string]: unknown;
}

/**
 * AIS-26b (decisão 26): colisão é propriedade do objeto, em `GameNode.properties.physics`.
 * Um colisor por objeto; `shape: 'auto'` e `size` ausente = forma/tamanho calculados por `resolveCollider`.
 */
export type PhysicsBodyMode = 'static' | 'dynamic' | 'kinematic' | 'character' | 'trigger';
export type PhysicsShape = 'auto' | 'box' | 'sphere' | 'capsule' | 'cylinder' | 'mesh';
export type PhysicsPlane = 'none' | 'xy' | 'xz' | 'yz';

export interface PhysicsConfig {
  /** Interruptor "Colisão": desligado = não colide, mas a configuração fica guardada. */
  enabled: boolean;
  bodyMode: PhysicsBodyMode;
  shape: PhysicsShape;
  /** AUSENTE = tamanho automático. Tamanho TOTAL (não metade), no espaço local do nó. */
  size?: Vector3Data;
  /** Deslocamento do centro (espaço local); ausente = centro da malha. */
  offset?: Vector3Data;
  /** 0..1, padrão 0.5 */
  friction?: number;
  /** 0..1, padrão 0 */
  bounce?: number;
  /** Ausente = automática pelo volume. */
  mass?: number;
  /** 8 bits, padrão 1 */
  layer?: number;
  /** 8 bits, padrão 255 */
  mask?: number;
  constrainToPlane?: PhysicsPlane;
  forwardAxis?: 'x' | 'z';
  /** Flutua na água (só `dynamic`). */
  floats?: boolean;
}

export type PropertyFieldType =
  | 'boolean'
  | 'integer'
  | 'float'
  | 'string'
  | 'vector2'
  | 'vector3'
  | 'color'
  | 'enum'
  | 'resource'
  | 'texture'
  | 'mesh'
  | 'material'
  | 'file'
  | 'node_ref'
  /** Inteiro de bits (Collision Layer/Mask): grade de checkboxes numerados de 1 a `bitCount`. */
  | 'bitmask';

export interface PropertyDescriptor {
  key: string;
  label: string;
  type: PropertyFieldType;
  category: string; // e.g. "Transform", "2D Overlay", "Rendering", "Physics"
  defaultValue: any;
  /** For enums. `disabled` = recurso não implementado (decisão 14): visível, não selecionável, tooltip "em breve". */
  options?: { label: string; value: any; disabled?: boolean }[];
  min?: number;
  max?: number;
  step?: number;
  /** `bitmask`: quantidade de bits exibidos (padrão 8). */
  bitCount?: number;
  description?: string;
  /** Rótulo que depende de outras propriedades (ex.: "Position X" × "Margin Left" conforme o Layout Preset). */
  dynamicLabel?: (properties: Record<string, any>) => string;
  /** Conditionally show/hide this field based on sibling property values. */
  visibleWhen?: (properties: Record<string, any>) => boolean;
}

export interface NodeTypeMetadata<T extends string = NodeType> {
  type: T;
  name: string;
  category: NodeCategory;
  /** Aba do diálogo de criação (AIS-15); um só lugar, junto do tipo. */
  createCategory: CreateNodeCategory;
  /** `false` = não aparece no diálogo de criação (ex.: `Missing`). Padrão `true`. */
  creatable?: boolean;
  /** AIS-56: no máximo UM nó deste tipo por cena (`Environment`, `Terrain`); criar outro devolve o existente. */
  singleton?: boolean;
  is2D: boolean;
  is3D: boolean;
  isUI: boolean;
  /** AIS-78c: capacidades do host de que o tipo de nó depende (ver `CapabilityRegistry`); ausente = nenhuma. */
  requires?: import('../core/capabilities').Capability[];
  description: string;
  icon: string;
  defaultProperties: Record<string, any>;
  /** AIS-49b/50: o nó nasce com este `generatorSource` (marca de origem do gerador); opcional, só tipos criados por gerador. */
  defaultGeneratorSource?: GeneratorSource;
  propertyDescriptors: PropertyDescriptor[];
  availableSignals: string[];
}

export interface GameNode {
  schemaVersion?: number;
  id: string;
  name: string;
  type: NodeType;
  parentId: string | null;
  childrenIds: string[];
  visible: boolean;
  locked: boolean;
  /** Explicit local 3D transform (AIS-03 / AIS-03c) */
  transform?: Transform3D;
  properties: Record<string, any>;
  script?: string; // Path or inline code
  /** AIS-41b: instâncias inline dos Behaviors deste nó (única representação; antes era uma lista de IDs de uma lista global). */
  behaviors?: BehaviorInstance[];
  signals?: NodeSignalConnection[];
  /** AIS-49b: como o nó foi gerado (Terrain/Tree/Sound/Particle); permite "Editar no gerador". Opcional; `generatorId` desconhecido é preservado. */
  generatorSource?: GeneratorSource;
  tags?: string[];
  variables?: Record<string, any>;
  visualLogic?: any;
}

/**
 * NodeData — canonical scene node data contract.
 * Alias for GameNode, conforming to the AIS-03 specification:
 * id, name, type, parentId, childrenIds, properties específicas por tipo, visible, locked.
 * In the casca codebase, GameNode is used interchangeably with NodeData.
 */
export type NodeData = GameNode;

/**
 * AIS-04: Desktop shortcut actions that target nodes.
 * Conforms to Item 2 Opção C (Desktop Keyboard Shortcuts).
 */
export type NodeShortcutAction =
  | 'frame_selected' // F
  | 'delete_selected' // Delete / Backspace
  | 'duplicate_selected' // Ctrl+D / Cmd+D
  | 'translate_mode' // W
  | 'rotate_mode' // E
  | 'scale_mode' // R
  | 'deselect'; // Escape
