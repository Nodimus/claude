export interface SignalConnection {
  id: string;
  sourceNodeId: string;
  signalName: string;
  targetNodeId: string;
  targetMethod: string;
  arguments?: any[];
}

export interface SignalDefinition {
  name: string;
  description: string;
  parameters?: { name: string; type: string }[];
}

/** AIS-27 — tipos de argumento que uma conexão de sinal pode passar ao método alvo. */
export type SignalArgumentType = 'string' | 'number' | 'boolean' | 'node';

/**
 * Argumento tipado de uma conexão (AIS-27). `value` guarda o valor já convertido ao tipo:
 * `node` guarda o `id` do GameNode (identidade estável, nunca o nome).
 */
export interface SignalArgument {
  type: SignalArgumentType;
  value: string | number | boolean | null;
}

/** Conexão de sinal gravada em `GameNode.signals` (a origem é o próprio nó). */
export interface NodeSignalConnection {
  id: string;
  signalName: string;
  targetNodeId: string;
  targetMethod: string;
  arguments?: SignalArgument[];
  /** AIS-57 — Godot `CONNECT_ONE_SHOT`: desconecta depois da primeira chamada. */
  oneShot?: boolean;
  /** AIS-57 — Godot `CONNECT_DEFERRED`: chama no fim do quadro, não na hora da emissão. */
  deferred?: boolean;
}
