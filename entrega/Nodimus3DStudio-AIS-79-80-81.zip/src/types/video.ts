export type VideoScreenShape =
  | 'CurvedScreen'
  | 'FlatDisplay'
  | 'HologramBillboard'
  | 'CinemaRoom'
  | 'Sphere360'
  | 'Cube'
  | 'Cylinder'
  | 'SelectedMesh';

export type VideoFilter = {
  brightness: number; // 50 to 200 (100 = default)
  contrast: number; // 50 to 200 (100 = default)
  saturation: number; // 0 to 200 (100 = default)
  hueRotate: number; // 0 to 360 deg
  grayscale: number; // 0 to 100%
  invert: boolean;
  sepia: number; // 0 to 100%
  scanlines: boolean;
};

export interface VideoClipSettings {
  url: string;
  name: string;
  duration: number;
  currentTime: number;
  trimStart: number;
  trimEnd: number;
  playbackRate: number;
  loop: boolean;
  muted: boolean;
  volume: number;
  aspectRatio: '16:9' | '4:3' | '21:9' | '1:1' | '9:16';
  emissiveIntensity: number;
  roughness: number;
  metalness: number;
  shape: VideoScreenShape;
  filters: VideoFilter;
  chromaKey: {
    enabled: boolean;
    color: string; // e.g. "#00ff00"
    similarity: number;
    smoothness: number;
  };
}

export const DEFAULT_VIDEO_SETTINGS: VideoClipSettings = {
  url: '',
  name: 'Cyberpunk_City_Display',
  duration: 10,
  currentTime: 0,
  trimStart: 0,
  trimEnd: 10,
  playbackRate: 1,
  loop: true,
  muted: true,
  volume: 0.8,
  aspectRatio: '16:9',
  emissiveIntensity: 0.65,
  roughness: 0.35,
  metalness: 0.1,
  shape: 'CurvedScreen',
  filters: {
    brightness: 100,
    contrast: 105,
    saturation: 110,
    hueRotate: 0,
    grayscale: 0,
    invert: false,
    sepia: 0,
    scanlines: false,
  },
  chromaKey: {
    enabled: false,
    color: '#00ff00',
    similarity: 0.3,
    smoothness: 0.1,
  },
};
