import type { EasingName } from '../animation/easing';

export interface Keyframe {
  time: number; // In seconds
  value: any;
  /** Curva do trecho: os nomes do Tweener (AIS-59, `src/animation/easing.ts`) ou os legados; `normalizeEasing` unifica. */
  easing?: EasingName | 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out';
}

export interface AnimationTrack {
  id: string;
  nodeId: string;
  property: string; // e.g. "position.x", "position.y", "rotation", "scale.x", "scale.y", "visible"
  keyframes: Keyframe[];
}

export interface AnimationClip {
  id: string;
  name: string;
  duration: number; // Total length in seconds
  loop: boolean;
  tracks: AnimationTrack[];
}
