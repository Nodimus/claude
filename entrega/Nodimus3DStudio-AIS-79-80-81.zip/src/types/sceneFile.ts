import { GameNode, ResourceRef } from './node';
import { SceneEnvironment, SceneCameraSettings, PostProcessingSettings, SceneFogSettings } from './scene';
import { CURRENT_SCENE_SCHEMA_VERSION } from '../core/persistenceVersions';

export type { ResourceRef };

/**
 * Persisted Behavior instance contract
 * id identifies the occurrence in the scene;
 * contributionId identifies the registered type.
 * Label is NOT identity.
 */
export interface PersistedBehaviorInstance {
  /** Stable UUID for this attached behavior instance */
  id: string;
  /**
   * Registered behavior definition ID — the folder name under
   * `src/logic/behaviors/<id>/` (v4.7.0). An ID that the current editor build
   * does not know is preserved as-is (unresolved), never discarded.
   */
  contributionId: string;
  /** Origin of the behavior implementation (v4.7.0: no project addons) */
  source: 'builtin' | 'custom' | 'script';
  /** Serializable properties defined for this instance */
  properties: Record<string, unknown>;
  /** Preserves unknown/legacy data without discarding */
  [key: string]: unknown;
}

/**
 * Persisted Action instance contract
 */
export interface PersistedActionInstance {
  /** Stable UUID for this action step */
  id: string;
  /** Registered action type — folder name under `src/logic/actions/<id>/` (v4.7.0) */
  contributionId: string;
  /** Origin (v4.7.0: no project addons) */
  source: 'builtin' | 'custom';
  /** Serializable action parameters */
  parameters: Record<string, unknown>;
  /** Preserves unknown/legacy data without discarding */
  [key: string]: unknown;
}

/**
 * Persisted Scene Settings within `*.scene.json`
 */
export interface SceneSettingsFile {
  environment?: SceneEnvironment;
  cameraSettings?: SceneCameraSettings;
  postProcessing?: PostProcessingSettings;
  fog?: SceneFogSettings;
  [key: string]: unknown;
}

/**
 * Canonical contract for `*.scene.json`
 *
 * Rules:
 * - Hierarchy is exclusively expressed by `rootNodeId` + `nodes` + `parentId`.
 * - No parallel collections `layers` / `instances` are permitted.
 * - No runtime Three.js, Rapier physics, React or DOM instances are persisted.
 */
export interface SceneFile {
  /** Integer schema version */
  schemaVersion: number;
  /** Globally unique, stable scene UUID (independent of filename) */
  sceneId: string;
  /** Scene display name */
  name: string;
  /** ID of the root GameNode */
  rootNodeId: string;
  /** ID of the 0..1 Environment node in this scene (if present) */
  environmentNodeId?: string | null;
  /** Canonical node graph indexed by stable node ID */
  nodes: Record<string, GameNode>;
  /** Serialized scene atmosphere, camera, and post-effects */
  sceneSettings?: SceneSettingsFile;
  /** Optional metadata and tags */
  metadata?: Record<string, unknown>;
  /** Creation timestamp */
  createdAt?: string;
  /** Last update timestamp */
  updatedAt?: string;
  /** Preserves unknown top-level properties */
  [key: string]: unknown;
}

/**
 * Helper to build a clean default SceneFile
 */
export function createDefaultSceneFile(name = 'Main', sceneId?: string): SceneFile {
  const rootId = 'spatial_root';
  const id = sceneId || 'scene_' + Math.random().toString(36).substring(2, 10);

  return {
    schemaVersion: CURRENT_SCENE_SCHEMA_VERSION,
    sceneId: id,
    name,
    rootNodeId: rootId,
    environmentNodeId: null,
    nodes: {
      [rootId]: {
        schemaVersion: 1,
        id: rootId,
        name: 'World3D',
        type: 'Spatial',
        parentId: null,
        childrenIds: [],
        visible: true,
        locked: false,
        properties: {
          position: { x: 0, y: 0, z: 0 },
          rotation: { x: 0, y: 0, z: 0 },
          scale: { x: 1, y: 1, z: 1 },
          visible: true,
        },
        signals: [],
        behaviors: [],
      },
    },
    sceneSettings: {
      environment: {
        ambientColor: '#334155',
        ambientIntensity: 0.45,
        backgroundColor: '#141822',
        realtimeShadows: true,
        gravity: { x: 0, y: -9.8, z: 0 },
        wind: { x: 0, y: 0, z: 0 },
      },
      cameraSettings: {
        fov: 65,
        near: 0.1,
        far: 1000,
        position: { x: 0, y: 3, z: 8 },
        target: { x: 0, y: 0, z: 0 },
      },
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}
