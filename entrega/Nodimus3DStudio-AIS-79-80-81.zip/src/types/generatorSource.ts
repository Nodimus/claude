/**
 * AIS-49b — contrato `generatorSource`: um nó criado por um gerador (Terrain, Tree, Sound, Particle) guarda COMO foi gerado, para ser
 * reaberto no gerador com os parâmetros originais e atualizado sem criar um nó novo ("Aplicar ao nó" = um `MacroCommand`, um Undo).
 *
 * Campo OPCIONAL de `GameNode` (nível do nó, não de `properties`). Serializado na cena; um `generatorId` desconhecido é preservado
 * como veio (nunca descartado nem tratado como erro).
 */
export interface GeneratorSource {
  /** ID estável do gerador (`'terrain'`, `'tree'`, `'sound'`, `'particle'`…). */
  generatorId: string;
  /** Versão do schema de `params` (migrações futuras do gerador). */
  version: number;
  /** Parâmetros serializáveis do gerador (JSON puro; nunca base64, `ResourceRef` no lugar de arquivos). */
  params: Record<string, unknown>;
  /** Semente aleatória usada na geração (opcional). */
  seed?: number;
}

const isRecord = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);

/** Lê o campo bruto de um nó; devolve `null` se não for um `GeneratorSource` bem-formado (o dado bruto continua no nó). */
export function parseGeneratorSource(raw: unknown): GeneratorSource | null {
  if (!isRecord(raw)) return null;
  if (typeof raw.generatorId !== 'string' || raw.generatorId.length === 0) return null;
  if (typeof raw.version !== 'number' || !Number.isFinite(raw.version)) return null;
  if (!isRecord(raw.params)) return null;
  if (raw.seed !== undefined && (typeof raw.seed !== 'number' || !Number.isFinite(raw.seed))) return null;
  const source: GeneratorSource = { generatorId: raw.generatorId, version: raw.version, params: raw.params };
  if (raw.seed !== undefined) source.seed = raw.seed as number;
  return source;
}

/** Cópia profunda (JSON) para guardar/comparar sem compartilhar referência com o estado do modal. */
export function cloneGeneratorSource(source: GeneratorSource): GeneratorSource {
  return JSON.parse(JSON.stringify(source)) as GeneratorSource;
}
