/**
 * Visual Logic — tipos das INSTÂNCIAS autorais (v4.7.0 · AIS-05r).
 *
 * Os IDs de trigger/condition/action/behavior deixaram de ser uniões fechadas
 * neste arquivo único: cada item nativo é uma pasta em `src/logic/<tipo>/<id>/`
 * e o nome da pasta é o ID. O catálogo vivo é `LogicRegistry`
 * (`src/logic/registry.ts`). Um ID desconhecido lido de uma cena é preservado.
 */

/** ID de trigger = pasta em `src/logic/triggers/<id>/`. */
export type LogicEventType = string;
/** ID de condition = pasta em `src/logic/conditions/<id>/`. */
export type LogicConditionType = string;
/** ID de action = pasta em `src/logic/actions/<id>/`. */
export type LogicActionType = string;
/** ID de behavior = pasta em `src/logic/behaviors/<id>/`. */
export type BehaviorType = string;

export interface LogicCondition {
  id: string;
  type: LogicConditionType;
  parameters: Record<string, any>;
  /** Campos desconhecidos do arquivo (versão futura/legado): preservados e regravados, nunca descartados (AIS-41b). */
  extra?: Record<string, unknown>;
}

/**
 * ActionInstance (AIS-41b): a configuração concreta de UMA Action numa regra — `type` é o ID da `ActionDefinition` (pasta
 * em `src/logic/actions/<id>/`), `parameters` o que o usuário configurou. Estado mutável do Play NÃO mora aqui.
 * ID e tipo desconhecidos continuam representados com todos os parâmetros.
 */
export interface LogicAction {
  id: string;
  type: LogicActionType;
  parameters: Record<string, any>;
  extra?: Record<string, unknown>;
}
export type ActionInstance = LogicAction;

export interface LogicEventRule {
  id: string;
  eventType: LogicEventType;
  parameters: Record<string, any>;
  conditions: LogicCondition[];
  actions: LogicAction[];
  extra?: Record<string, unknown>;
}

/**
 * BehaviorInstance (AIS-41b): a configuração concreta de UM Behavior anexado a UM `GameNode` (`GameNode.behaviors`). O tipo
 * (`behaviorType` = ID da `BehaviorDefinition` em `src/logic/behaviors/<id>/`) descreve schema/executor; a instância guarda
 * `properties` e as regras. Duas instâncias da mesma Definition em nós distintos são independentes. No arquivo o tipo vai
 * como `contributionId` (conversão em `core/serialization/behaviorFile.ts`).
 */
export interface BehaviorInstance {
  schemaVersion?: number;
  id: string;
  name: string;
  behaviorType: BehaviorType;
  enabled: boolean;
  properties: Record<string, any>;
  rules: LogicEventRule[];
  /** Campos desconhecidos do arquivo (inclui `source`): preservados e regravados. */
  extra?: Record<string, unknown>;
}

/**
 * Visão achatada de um Behavior para a UI e os Commands: a instância + o nó dono (`targetNodeId` = ID do nó). A fonte da
 * verdade é `GameNode.behaviors`; esta visão é derivada (`core/authoring/behaviors.ts`) e nunca é gravada.
 */
export interface Behavior extends BehaviorInstance {
  targetNodeId: string;
}
