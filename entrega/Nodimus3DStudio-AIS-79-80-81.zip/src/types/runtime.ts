/**
 * Nodimus 3D Studio — Runtime State Contracts
 *
 * ============================================================================
 * STATE ARCHITECTURE V4.1 INVARIANTS:
 * 1. Authoring State != Runtime State
 * 2. Play: Authoring -> snapshot -> RuntimeSession
 * 3. Stop: dispose RuntimeSession; Authoring state remains intact
 * 4. Runtime NEVER writes back to Authoring State.
 * 5. Runtime NEVER generates Undo/Redo in CommandManager.
 * 6. React components are NEVER the authority of game state.
 * ============================================================================
 */

import { GameNode, NodeType } from './node';
import { SceneEnvironment } from './scene';
import { SceneSettingsFile } from './sceneFile';

/**
 * Immutable, serializable snapshot of the authoring scene at the moment
 * Play mode is triggered. Runtime instances are materialized from this snapshot.
 */
export interface AuthoringSceneSnapshot {
  readonly snapshotId: string;
  readonly sceneId: string;
  readonly name: string;
  readonly schemaVersion: number;
  readonly rootNodeId: string;
  readonly nodes: Readonly<Record<string, Readonly<GameNode>>>;
  readonly environmentNodeId?: string | null;
  readonly sceneSettings?: Readonly<SceneSettingsFile | SceneEnvironment>;
  readonly createdAt: string;
}

/**
 * Runtime instance handle representing an active entity inside the simulation.
 * The runtime handle ID is distinct from the persistent node ID to decouple
 * authoring identity from runtime instance lifecycle.
 */
export interface RuntimeInstanceHandle {
  /** Unique handle for this runtime instance (e.g. `runtime-inst-${nodeId}-${nanoid()}`) */
  readonly id: string;
  /** Stable authoring persistent ID of the node */
  readonly persistentNodeId: string;
  /** Authoring node name */
  readonly name: string;
  /** Node type */
  readonly type: NodeType;
  /** Runtime transform — freely mutable by physics/runtime, NEVER written back to authoring */
  transform: {
    position: [number, number, number];
    rotation: [number, number, number];
    scale: [number, number, number];
  };
  /** Runtime properties copy — mutable by scripts/behaviors */
  properties: Record<string, any>;
  /** Tags for fast runtime queries */
  tags: string[];
  /** Runtime visibility state */
  visible: boolean;
  /** Set to true when this runtime instance is destroyed during gameplay */
  disposed: boolean;
}

/**
 * Contract for a runtime scene running inside a simulation session.
 */
export interface RuntimeSceneContract {
  readonly sceneId: string;
  readonly name: string;
  readonly rootNodeId: string;
  /** Retrieve a runtime instance by its runtime handle ID or persistent nodeId */
  getInstance(idOrNodeId: string): RuntimeInstanceHandle | undefined;
  /** Retrieve all active runtime instances */
  getAllInstances(): RuntimeInstanceHandle[];
  /** Query runtime instances by tag */
  findInstancesByTag(tag: string): RuntimeInstanceHandle[];
  /** Query runtime instances by NodeType */
  findInstancesByType(type: NodeType): RuntimeInstanceHandle[];
}

export type RuntimeSessionStatus = 'idle' | 'running' | 'paused' | 'stopped';
export type RuntimeSessionMode = 'project' | 'scene';

/**
 * Contract for the runtime simulation session.
 * Governs the lifecycle of Play mode and execution loop.
 */
export interface RuntimeSessionContract {
  readonly id: string;
  readonly status: RuntimeSessionStatus;
  readonly mode: RuntimeSessionMode;
  readonly scene: RuntimeSceneContract;
  readonly snapshot: AuthoringSceneSnapshot;
  readonly elapsedTime: number;

  start(): void;
  pause(): void;
  resume(): void;
  stop(): void;
  dispose(): void;
  step(deltaTime: number): void;
}
