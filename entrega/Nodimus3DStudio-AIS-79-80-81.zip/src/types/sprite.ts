import type { ResourceRef } from './node';

export type BillboardMode = 'spherical' | 'cylindrical_y' | 'flat_quad' | 'isometric';

export type SpriteTool = 'pencil' | 'eraser' | 'picker' | 'bucket';

export type LoopMode = 'loop' | 'once' | 'ping-pong';

export type LightingPreset = 'studio' | 'night' | 'sunset' | 'retro_arcade' | 'cyberpunk';

export interface SpriteFrame {
  id: string;
  index: number;
  x: number;
  y: number;
  width: number;
  height: number;
  /** LEGADO (AIS-76, decisão 24): lido de forma tolerante, não é autoridade de tempo (valem `fps` e `frameDurations`) e frames novos não o gravam. */
  durationMs?: number;
  /** ESTADO DE SESSÃO do editor (pixels editados no canvas): nunca persistido, nunca em `properties` nem em snapshots de Undo. */
  customDataUrl?: string;
}

export interface SpriteAnimation {
  id: string;
  name: string;
  frameIndices: number[];
  fps: number;
  loopMode: LoopMode;
  /** Multiplicadores relativos de tempo, paralelos a `frameIndices` (padrão 1) — a `duration` do Godot. */
  frameDurations?: number[];
}

export interface SpriteSheetConfig {
  name: string;
  /** Atlas PNG em `res://textures/` (decisão 24). Ausente = o atlas ainda não foi gravado (nasce ao salvar pela primeira vez). */
  texture?: ResourceRef;
  /** ESTADO DE SESSÃO do editor (data URL do atlas carregado): nunca persistido em `.sprite.json`. */
  imageUrl: string;
  imageWidth: number;
  imageHeight: number;
  frameWidth: number;
  frameHeight: number;
  columns: number;
  rows: number;
  spacing: number;
  margin: number;
  totalFrames: number;
}

export interface Sprite3DSettings {
  billboardMode: BillboardMode;
  renderScale: { x: number; y: number };
  pixelPerfectFilter: boolean; // Nearest vs Linear
  tintColor: { r: number; g: number; b: number; a: number };
  emissiveColor: string;
  emissiveIntensity: number;
  alphaTest: number;
  doubleSided: boolean;
  castShadow: boolean;
  receiveShadow: boolean;
  turntableSpeed: number; // 0 = stationary, >0 = rpm
  environmentLighting: LightingPreset;
  showGroundGrid: boolean;
  showPixelWireframe: boolean;
  /** Texture Settings (AIS-76 §3.2.5): `Tile H/V` = RepeatWrapping; `Premultiply Alpha`. `pixelPerfectFilter` = Edge Filtering desligado (Nearest). */
  tileH: boolean;
  tileV: boolean;
  premultiplyAlpha: boolean;
}

export interface SpriteProject {
  /** Versão do formato persistido (`CURRENT_SPRITE_SCHEMA_VERSION`). */
  schemaVersion?: number;
  id: string;
  name: string;
  sheetConfig: SpriteSheetConfig;
  frames: SpriteFrame[];
  animations: SpriteAnimation[];
  activeAnimationId: string;
  currentFrameIndex: number;
  settings3D: Sprite3DSettings;
  palette: string[];
}

export const DEFAULT_SPRITE_3D_SETTINGS: Sprite3DSettings = {
  billboardMode: 'spherical',
  renderScale: { x: 1.5, y: 1.5 },
  pixelPerfectFilter: true,
  tintColor: { r: 1, g: 1, b: 1, a: 1 },
  emissiveColor: '#000000',
  emissiveIntensity: 0.2,
  alphaTest: 0.5,
  doubleSided: true,
  castShadow: true,
  receiveShadow: true,
  turntableSpeed: 0,
  environmentLighting: 'studio',
  showGroundGrid: true,
  showPixelWireframe: false,
  tileH: false,
  tileV: false,
  premultiplyAlpha: false,
};
