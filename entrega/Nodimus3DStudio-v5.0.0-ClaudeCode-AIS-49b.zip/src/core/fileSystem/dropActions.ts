/**
 * AIS-31 — arrastar arquivos do FileSystemPanel para o Viewport 3D ou a SceneTree.
 *
 * `resolveDropAction` é função pura e CONSOME `resolveFileAction` (AIS-28): não existe tabela de tipos própria
 * aqui, só o que cada destino de arquivo significa ao ser solto na cena. Quem executa (Commands, modal) é o hook
 * `useFileDrop`.
 */
import type { ResourceRef } from '../../types/node';
import { DEFAULT_VIDEO_SETTINGS, type VideoClipSettings } from '../../types/video';
import type { MaterialOverride } from '../../types/material';
import { readNodeMaterial, patchNodeMaterial, toMaterialOverride } from '../material/nodeMaterial';
import { resolveFileAction, type FileLike } from './fileActions';

/** Tipo MIME do arrasto interno de arquivos do FileSystemPanel (valor = caminho `res://`). */
export const FS_DRAG_MIME = 'application/x-nodimus-fs';

export const SCENE_DROP_HINT = 'cena não é instanciável; para reutilizar, use um prefab (em breve — AIS-81)';

export type DropAction =
  /** Modelo 3D: abre o AssetImportModal com o arquivo pré-carregado. */
  | { kind: 'importModel'; path: string }
  /** Textura de `res://textures/` sobre uma malha: aplica ao material (albedo). */
  | { kind: 'applyTexture'; path: string }
  /** `.mat.json` sobre uma malha: aplica o material inteiro. */
  | { kind: 'applyMaterial'; path: string }
  /** `.sprite.json`: cria um `Billboard` referenciando o `SpriteProject`. */
  | { kind: 'createBillboard'; path: string }
  /** `.video.json`: cria a tela de vídeo (mesmo nó do VideoEditorModal). */
  | { kind: 'createVideoScreen'; path: string }
  /** Reconhecido, mas sem efeito ao soltar: loga o motivo (nunca falha em silêncio). */
  | { kind: 'reject'; reason: string }
  /** Arquivo sem significado na cena (scripts, áudio…): nada acontece. */
  | { kind: 'ignore' };

const IMAGE_RE = /\.(png|jpe?g|webp)$/i;

/**
 * Decide o que soltar `file` significa. `meshUnderCursor` = há uma malha (MeshInstance) sob o cursor/linha.
 * Textura e material só valem sobre malha; sem ela o drop é recusado com mensagem (sem aplicar em outro nó).
 */
export function resolveDropAction(file: FileLike, meshUnderCursor: boolean): DropAction {
  const action = resolveFileAction(file);
  const path = file.path;
  const lower = path.toLowerCase();

  switch (action.kind) {
    case 'assetImport':
      return { kind: 'importModel', path };
    case 'texturePreview':
      if (lower.endsWith('.mat.json') || lower.endsWith('.material.json')) {
        return meshUnderCursor ? { kind: 'applyMaterial', path } : { kind: 'reject', reason: 'solte o material sobre uma malha 3D' };
      }
      if (IMAGE_RE.test(lower)) {
        return meshUnderCursor ? { kind: 'applyTexture', path } : { kind: 'reject', reason: 'solte a textura sobre uma malha 3D' };
      }
      return { kind: 'ignore' };
    case 'spriteEditor':
      return lower.endsWith('.sprite.json') ? { kind: 'createBillboard', path } : { kind: 'ignore' };
    case 'videoEditor':
      return lower.endsWith('.video.json') ? { kind: 'createVideoScreen', path } : { kind: 'reject', reason: 'arraste o preset .video.json (o vídeo cru é configurado no Editor de Vídeo)' };
    case 'loadScene':
      return { kind: 'reject', reason: SCENE_DROP_HINT };
    case 'comingSoon':
      return { kind: 'reject', reason: action.hint ?? 'em breve' };
    default:
      // scriptEditor, audio, none: scripts nunca instanciam (só pela ação Executar Script)
      return { kind: 'ignore' };
  }
}

type Props = Record<string, any> | undefined;

/** Override que aplica a textura `ref` como albedo, mantendo o resto do material do nó (um único Command). */
export function textureDropOverride(nodeProps: Props, ref: ResourceRef): MaterialOverride {
  return patchNodeMaterial(nodeProps, { albedoTexture: ref });
}

export type MaterialFileResult = { ok: true; override: MaterialOverride } | { ok: false; error: string };

/**
 * Conteúdo de um `.mat.json` (as `MaterialProperties` salvas pelo TexturePreviewModal) → `materialOverride` do nó.
 * O arquivo não guarda textura de albedo: o material aplicado substitui o anterior e o albedo fica vazio.
 */
export function materialDropOverride(content: string | undefined): MaterialFileResult {
  if (typeof content !== 'string' || !content.trim()) return { ok: false, error: 'arquivo de material vazio' };
  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    return { ok: false, error: 'JSON de material inválido' };
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return { ok: false, error: 'o material deve ser um objeto' };
  const { albedoTexture: _a, presetId, ...channels } = parsed as Record<string, unknown>;
  const material = readNodeMaterial({ materialOverride: channels });
  // sem arquivo de imagem associado, `custom_image` não tem o que mostrar
  const working = material.textureType === 'custom_image' ? { ...material, textureType: 'none' as const } : material;
  return { ok: true, override: toMaterialOverride(working, { albedoTexture: null, presetId: typeof presetId === 'string' ? presetId : null }) };
}

export type VideoFileResult = { ok: true; settings: VideoClipSettings } | { ok: false; error: string };

/** Conteúdo de um `.video.json` → configurações completas (campos ausentes vêm dos padrões). */
export function videoDropSettings(content: string | undefined): VideoFileResult {
  if (typeof content !== 'string' || !content.trim()) return { ok: false, error: 'arquivo de vídeo vazio' };
  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    return { ok: false, error: 'JSON de vídeo inválido' };
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return { ok: false, error: 'o preset de vídeo deve ser um objeto' };
  return { ok: true, settings: { ...DEFAULT_VIDEO_SETTINGS, ...(parsed as Partial<VideoClipSettings>) } };
}

/** Nome do nó a partir do caminho: `res://sprites/Hero.sprite.json` → `Hero`. */
export function nodeNameFromPath(path: string): string {
  const file = path.split('/').pop() ?? path;
  return file.replace(/\.(sprite|video|mat|material|scene|prefab)\.json$/i, '').replace(/\.[^.]+$/, '') || 'Node';
}

/** Referência a um `.sprite.json` (decisão 24: o Billboard referencia o `SpriteProject`, nunca copia). */
export function spriteProjectRef(path: string, registryRef?: ResourceRef): ResourceRef {
  return registryRef ?? { id: `res:${path}`, type: 'sprite', path, label: path.split('/').pop() || path };
}
