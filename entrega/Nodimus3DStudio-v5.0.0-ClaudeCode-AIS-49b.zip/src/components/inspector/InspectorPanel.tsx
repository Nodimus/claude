import React, { useEffect, useState } from 'react';
import { useEditor } from '../../core/EditorContext';
import { getNodeMetadata } from '../../nodes/registry';
import { PropertyField } from './PropertyField';
import { getAtPath } from '../../core/commands/ChangePropertyCommand';
import { DraftNumberInput } from './DraftNumberInput';
import { PARTICLE_PRESETS, presetProperties } from '../../core/particles/particlePresets';
import { NodeSignalsTab } from './NodeSignalsTab';
import { LocalVariablesSection } from './LocalVariablesSection';
import { isLayoutContainerType } from '../../runtime/containerLayout';
import { NodeIcon } from '../common/NodeIcon';
import { CollisionSection, supportsCollision } from './CollisionSection';
import { MeshMaterialSection } from './MeshMaterialSection';
import { ModelSection } from './ModelSection';
import { GeneratorSection } from './GeneratorSection';
import { DEFAULT_SCENE_ENVIRONMENT } from '../../types/scene';
import {
  Sliders,
  Radio,
  ChevronDown,
  ChevronRight,
  FileCode,
  Sparkles,
  Layers,
  Sun,
  Eye,
  EyeOff,
} from 'lucide-react';

/** Nome do nó editável: Enter/blur gravam (Command de renomear), Escape descarta, vazio volta ao nome atual. */
const NodeNameField: React.FC<{ nodeId: string; name: string; onRename: (id: string, name: string) => void }> = ({
  nodeId,
  name,
  onRename,
}) => {
  const [draft, setDraft] = useState(name);
  const [focused, setFocused] = useState(false);

  // acompanha mudanças externas (Undo/Redo, renomear pela árvore) quando o campo não está em edição
  useEffect(() => {
    if (!focused) setDraft(name);
  }, [name, nodeId, focused]);

  const commit = () => {
    const trimmed = draft.trim();
    if (trimmed && trimmed !== name) onRename(nodeId, trimmed);
    else setDraft(name);
  };

  return (
    <input
      type="text"
      value={draft}
      aria-label="Nome do nó"
      title="Renomear nó"
      spellCheck={false}
      onFocus={(e) => {
        setFocused(true);
        e.currentTarget.select();
      }}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => {
        setFocused(false);
        commit();
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          e.currentTarget.blur();
        } else if (e.key === 'Escape') {
          e.stopPropagation();
          setDraft(name);
          e.currentTarget.blur();
        }
      }}
      className="font-semibold text-white block w-full truncate bg-transparent border border-transparent hover:border-[#2c3345] focus:border-[#4982ea] focus:bg-[#141820] rounded px-1 -mx-1 outline-none select-text"
    />
  );
};

/** Campos de âncora/offset do layout livre (somem quando o pai é um Container). */
const ANCHOR_KEYS = new Set(['alignment', 'posX', 'posY']);
/** Campos de filho de Container (somem quando o pai não é um Container). */
const CHILD_LAYOUT_KEYS = new Set(['sizeFlagsH', 'sizeFlagsV', 'minSize', 'stretchRatio']);

export const InspectorPanel: React.FC = () => {
  const {
    activeScene,
    selectedNode,
    updateNodeProperties,
    updateNodeTransform,
    changeNodeProperty,
    changeNodeProperties,
    renameNode,
    toggleNodeVisibility,
    updateSceneEnvironment,
    setIsFogModalOpen,
    setIsPostProcessingOpen,
    setWorkspaceMode,
  } = useEditor();

  const [activeTab, setActiveTab] = useState<'inspector' | 'node'>('inspector');
  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({});

  const toggleCategory = (cat: string) => {
    setCollapsedCategories((prev) => ({ ...prev, [cat]: !prev[cat] }));
  };

  if (!selectedNode) {
    return (
      <div className="flex flex-col h-full bg-[#202531] border-l border-[#2c3345] select-none text-xs">
        <div className="h-8 border-b border-[#2c3345] px-3 flex items-center bg-[#1e232f] text-xs font-semibold text-[#dfe4ec]">
          Inspector
        </div>
        <div className="flex-1 flex flex-col items-center justify-center text-[#8b97a8] p-4 text-center">
          <Layers className="w-8 h-8 mb-2 opacity-30" />
          <p>No node selected.</p>
          <p className="text-[11px] text-[#637185] mt-1">Select a node from the Scene Tree to inspect its properties.</p>
        </div>
      </div>
    );
  }

  const meta = getNodeMetadata(selectedNode.type);

  // Group descriptors by category
  const categories: Record<string, typeof meta.propertyDescriptors> = {};
  // AIS-25c: filho de um Container é posicionado pelo pai (Godot) — âncoras/offsets somem e entram os size flags;
  // fora de um Container os size flags não se aplicam.
  const parentNode = selectedNode.parentId && activeScene ? activeScene.nodes[selectedNode.parentId] : undefined;
  const inContainer = !!meta.isUI && !!parentNode && isLayoutContainerType(parentNode.type);
  for (const desc of meta.propertyDescriptors) {
    if (meta.isUI) {
      if (inContainer && ANCHOR_KEYS.has(desc.key)) continue;
      if (!inContainer && desc.category === 'Container Layout' && CHILD_LAYOUT_KEYS.has(desc.key)) continue;
    }
    if (!categories[desc.category]) {
      categories[desc.category] = [];
    }
    categories[desc.category].push(desc);
  }

  const isRootNode = Boolean(
    activeScene && (activeScene.rootNodeId === selectedNode.id || selectedNode.parentId === null)
  );

  // AIS-06: Resolve canonical Environment GameNode as authority
  const envNode = activeScene ? (
    (activeScene.environmentNodeId && activeScene.nodes[activeScene.environmentNodeId]) ||
    Object.values(activeScene.nodes).find((n) => n.type === 'Environment')
  ) : undefined;

  const toHex = (c: any, fallback: string): string => {
    if (!c) return fallback;
    if (typeof c === 'string') return c.startsWith('#') ? c : `#${c}`;
    if (typeof c.r === 'number' && typeof c.g === 'number' && typeof c.b === 'number') {
      const f = (n: number) => Math.round(Math.max(0, Math.min(1, n)) * 255).toString(16).padStart(2, '0');
      return `#${f(c.r)}${f(c.g)}${f(c.b)}`;
    }
    return fallback;
  };

  const env = {
    ambientColor: toHex(envNode?.properties?.ambientColor, activeScene?.environment?.ambientColor || '#334155'),
    ambientIntensity: typeof envNode?.properties?.ambientIntensity === 'number'
      ? envNode.properties.ambientIntensity
      : (activeScene?.environment?.ambientIntensity ?? 0.4),
    backgroundColor: toHex(envNode?.properties?.backgroundColor, activeScene?.environment?.backgroundColor || '#1a1a2e'),
    realtimeShadows: envNode?.properties?.realtimeShadows !== undefined
      ? Boolean(envNode.properties.realtimeShadows)
      : (activeScene?.environment?.realtimeShadows ?? true),
    gravity: activeScene?.environment?.gravity || { x: 0, y: -9.8, z: 0 },
    wind: activeScene?.environment?.wind || { x: 0, y: 0, z: 0 },
  };

  return (
    <div className="flex flex-col h-full bg-[#202531] border-l border-[#2c3345] select-none text-xs">
      {/* Top Tab Bar (Inspector | Node) */}
      <div className="h-8 border-b border-[#2c3345] px-2 flex items-center justify-between bg-[#1e232f]">
        <div className="flex items-center space-x-1">
          <button
            onClick={() => setActiveTab('inspector')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === 'inspector'
                ? 'bg-[#2c3345] text-white shadow-sm'
                : 'text-[#8b97a8] hover:text-[#dfe4ec]'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Inspector</span>
          </button>
          <button
            onClick={() => setActiveTab('node')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === 'node'
                ? 'bg-[#2c3345] text-white shadow-sm'
                : 'text-[#8b97a8] hover:text-[#dfe4ec]'
            }`}
          >
            <Radio className="w-3.5 h-3.5 text-emerald-400" />
            <span>Node</span>
          </button>
        </div>
      </div>

      {/* Selected Node Summary Header */}
      <div className="px-3 py-2 border-b border-[#2c3345] bg-[#1a1e29] flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <NodeIcon type={selectedNode.type} className="w-4 h-4" />
          <div className="truncate">
            <NodeNameField nodeId={selectedNode.id} name={selectedNode.name} onRename={renameNode} />
            <span className="text-[11px] text-[#8b97a8] font-mono">{selectedNode.type}</span>
          </div>
        </div>

        {/* Ativação do nó (visible) + atalhos */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => toggleNodeVisibility(selectedNode.id)}
            aria-pressed={selectedNode.visible}
            aria-label={selectedNode.visible ? 'Desativar nó (ocultar)' : 'Ativar nó (mostrar)'}
            title={selectedNode.visible ? 'Nó ativo — clique para ocultar' : 'Nó oculto — clique para ativar'}
            className={`p-1 rounded bg-[#272e3d] hover:bg-[#343e52] ${selectedNode.visible ? 'text-emerald-400' : 'text-[#637185]'}`}
          >
            {selectedNode.visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={() => setWorkspaceMode('VisualLogic')}
            className="p-1 rounded bg-[#272e3d] hover:bg-[#343e52] text-amber-400"
            title="Visual Logic Behaviors"
          >
            <Sparkles className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Tab Body */}
      <div className="flex-1 overflow-y-auto">
        {activeTab === 'inspector' ? (
          <div className="divide-y divide-[#2c3345]/60">
            {/* AIS-49b: só em nó com generatorSource */}
            {selectedNode.generatorSource && <GeneratorSection node={selectedNode} />}

            {supportsCollision(selectedNode.type) && <CollisionSection node={selectedNode} />}

            {/* AIS-38c: referência do modelo 3D (trocar, editar importação, reimportar, mostrar no FileSystem) */}
            {selectedNode.type === 'MeshInstance' && selectedNode.properties.model && <ModelSection node={selectedNode} />}

            {/* Mesh Material & Texture Editor Section */}
            {selectedNode.type === 'MeshInstance' && (
              <div className="px-2 pt-2">
                <MeshMaterialSection node={selectedNode} />
              </div>
            )}

            {/* Scene Environment Section (Shown when Root Node is selected) */}
            {isRootNode && (
              <div className="py-1 border-b border-[#2c3345]/80">
                <div
                  onClick={() => toggleCategory('SceneEnvironment')}
                  className="flex items-center justify-between px-3 py-1 cursor-pointer hover:bg-[#272e3d] text-amber-400 font-semibold text-[11px] uppercase tracking-wider select-none"
                >
                  <span className="flex items-center gap-1.5">
                    <Sun className="w-3.5 h-3.5" />
                    Scene Environment
                  </span>
                  {collapsedCategories['SceneEnvironment'] ? (
                    <ChevronRight className="w-3.5 h-3.5" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5" />
                  )}
                </div>

                {!collapsedCategories['SceneEnvironment'] && (
                  <div className="px-2 py-1 space-y-1.5 bg-[#171b23]/60 rounded m-1 p-2">
                    {/* Ambient Light Color */}
                    <div className="flex items-center justify-between py-1 px-1">
                      <label className="text-xs text-[#b8c4d6]">Ambient Color</label>
                      <input
                        type="color"
                        value={env.ambientColor}
                        onChange={(e) => updateSceneEnvironment({ ambientColor: e.target.value })}
                        className="w-8 h-6 bg-transparent border border-[#2c3345] rounded cursor-pointer"
                      />
                    </div>

                    {/* Ambient Intensity */}
                    <div className="flex items-center justify-between py-1 px-1 gap-2">
                      <label className="text-xs text-[#b8c4d6]">Ambient Intensity</label>
                      <DraftNumberInput
                        aria-label="Ambient Intensity"
                        min={0}
                        max={2}
                        step={0.05}
                        value={env.ambientIntensity}
                        onCommit={(v) => updateSceneEnvironment({ ambientIntensity: v })}
                        className="w-20 bg-[#141820] text-xs text-right font-mono text-[#dfe4ec] px-1.5 py-0.5 rounded border border-[#2c3345]"
                      />
                    </div>

                    {/* Background Color */}
                    <div className="flex items-center justify-between py-1 px-1">
                      <label className="text-xs text-[#b8c4d6]">Background Color</label>
                      <input
                        type="color"
                        value={env.backgroundColor}
                        onChange={(e) => updateSceneEnvironment({ backgroundColor: e.target.value })}
                        className="w-8 h-6 bg-transparent border border-[#2c3345] rounded cursor-pointer"
                      />
                    </div>

                    {/* Realtime Shadows */}
                    <div className="flex items-center justify-between py-1 px-1">
                      <label className="text-xs text-[#b8c4d6]">Realtime Shadows</label>
                      <input
                        type="checkbox"
                        checked={env.realtimeShadows}
                        onChange={(e) => updateSceneEnvironment({ realtimeShadows: e.target.checked })}
                        className="w-4 h-4 rounded bg-[#181c24] border border-[#2c3345] text-[#4982ea] cursor-pointer"
                      />
                    </div>

                    {/* Gravity Vector */}
                    <div className="py-1 px-1">
                      <div className="text-xs text-[#b8c4d6] mb-1 select-none">Gravity Vector</div>
                      <div className="grid grid-cols-3 gap-1">
                        <div className="flex items-center bg-[#141820] rounded border border-[#2c3345] overflow-hidden">
                          <span className="bg-red-500/20 text-red-400 font-bold px-1 py-0.5 text-[10px] select-none">x</span>
                          <DraftNumberInput
                            aria-label="Gravity X"
                            step={0.5}
                            value={env.gravity.x}
                            onCommit={(v) => updateSceneEnvironment({ gravity: { ...env.gravity, x: v } })}
                            className="w-full bg-transparent text-xs text-right font-mono text-[#dfe4ec] px-1 py-0.5 outline-none"
                          />
                        </div>
                        <div className="flex items-center bg-[#141820] rounded border border-[#2c3345] overflow-hidden">
                          <span className="bg-emerald-500/20 text-emerald-400 font-bold px-1 py-0.5 text-[10px] select-none">y</span>
                          <DraftNumberInput
                            aria-label="Gravity Y"
                            step={0.5}
                            value={env.gravity.y}
                            onCommit={(v) => updateSceneEnvironment({ gravity: { ...env.gravity, y: v } })}
                            className="w-full bg-transparent text-xs text-right font-mono text-[#dfe4ec] px-1 py-0.5 outline-none"
                          />
                        </div>
                        <div className="flex items-center bg-[#141820] rounded border border-[#2c3345] overflow-hidden">
                          <span className="bg-blue-500/20 text-blue-400 font-bold px-1 py-0.5 text-[10px] select-none">z</span>
                          <DraftNumberInput
                            aria-label="Gravity Z"
                            step={0.5}
                            value={env.gravity.z}
                            onCommit={(v) => updateSceneEnvironment({ gravity: { ...env.gravity, z: v } })}
                            className="w-full bg-transparent text-xs text-right font-mono text-[#dfe4ec] px-1 py-0.5 outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Wind Vector */}
                    <div className="py-1 px-1">
                      <div className="text-xs text-[#b8c4d6] mb-1 select-none">Global Wind</div>
                      <div className="grid grid-cols-3 gap-1">
                        <div className="flex items-center bg-[#141820] rounded border border-[#2c3345] overflow-hidden">
                          <span className="bg-red-500/20 text-red-400 font-bold px-1 py-0.5 text-[10px] select-none">x</span>
                          <DraftNumberInput
                            aria-label="Wind X"
                            step={0.2}
                            value={env.wind.x}
                            onCommit={(v) => updateSceneEnvironment({ wind: { ...env.wind, x: v } })}
                            className="w-full bg-transparent text-xs text-right font-mono text-[#dfe4ec] px-1 py-0.5 outline-none"
                          />
                        </div>
                        <div className="flex items-center bg-[#141820] rounded border border-[#2c3345] overflow-hidden">
                          <span className="bg-emerald-500/20 text-emerald-400 font-bold px-1 py-0.5 text-[10px] select-none">y</span>
                          <DraftNumberInput
                            aria-label="Wind Y"
                            step={0.2}
                            value={env.wind.y}
                            onCommit={(v) => updateSceneEnvironment({ wind: { ...env.wind, y: v } })}
                            className="w-full bg-transparent text-xs text-right font-mono text-[#dfe4ec] px-1 py-0.5 outline-none"
                          />
                        </div>
                        <div className="flex items-center bg-[#141820] rounded border border-[#2c3345] overflow-hidden">
                          <span className="bg-blue-500/20 text-blue-400 font-bold px-1 py-0.5 text-[10px] select-none">z</span>
                          <DraftNumberInput
                            aria-label="Wind Z"
                            step={0.2}
                            value={env.wind.z}
                            onCommit={(v) => updateSceneEnvironment({ wind: { ...env.wind, z: v } })}
                            className="w-full bg-transparent text-xs text-right font-mono text-[#dfe4ec] px-1 py-0.5 outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Dialog triggers for Fog and PostProcessing */}
                    <div className="flex items-center gap-1.5 pt-1.5">
                      <button
                        onClick={() => setIsFogModalOpen(true)}
                        className="flex-1 py-1 px-2 rounded bg-[#202531] hover:bg-[#2c3345] text-[#b8c4d6] hover:text-white border border-[#2c3345] text-[11px] transition-colors"
                      >
                        Fog Settings...
                      </button>
                      <button
                        onClick={() => setIsPostProcessingOpen(true)}
                        className="flex-1 py-1 px-2 rounded bg-[#202531] hover:bg-[#2c3345] text-[#b8c4d6] hover:text-white border border-[#2c3345] text-[11px] transition-colors"
                      >
                        Post Effects...
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {selectedNode.type === 'Missing' && (
              <div className="mx-2 my-2 p-2 rounded border border-orange-400/40 bg-orange-400/10 text-[11px] text-[#dfe4ec]">
                <div className="font-semibold text-orange-300 mb-0.5">
                  Tipo original: {String(selectedNode.properties?.__missing?.originalType ?? 'desconhecido')}
                </div>
                Tipo ausente nesta versão do editor; dados preservados.
              </div>
            )}

            {/* Emenda v5.1.3: preset de partículas preenche as propriedades do nó (um Command), sem recriá-lo */}
            {selectedNode.type === 'ParticleSystem' && (
              <div className="py-1">
                <div className="px-3 py-1 text-amber-400 font-semibold text-[11px] uppercase tracking-wider select-none">Presets</div>
                <div className="flex items-center justify-between py-1 px-3 gap-2">
                  <label htmlFor="particle-preset" className="text-xs text-[#b8c4d6] select-none">Preset</label>
                  <select
                    id="particle-preset"
                    value={String(selectedNode.properties.presetId ?? '')}
                    onChange={(e) => {
                      const preset = PARTICLE_PRESETS.find((p) => p.id === e.target.value);
                      if (preset) changeNodeProperties(selectedNode.id, { ...presetProperties(preset.id) }, `Apply Particle Preset ${preset.shortName}`);
                    }}
                    className="flex-1 bg-[#141820] text-xs text-[#dfe4ec] px-1.5 py-0.5 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none cursor-pointer"
                  >
                    {!PARTICLE_PRESETS.some((p) => p.id === selectedNode.properties.presetId) && (
                      <option value={String(selectedNode.properties.presetId ?? '')}>Personalizado</option>
                    )}
                    {PARTICLE_PRESETS.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {inContainer && (
              <div className="mx-3 mt-1 px-2 py-1 rounded bg-[#272e3d] text-[11px] text-[#8b97a8]">
                Posição controlada pelo Container <span className="font-mono text-[#dfe4ec]">{parentNode!.name}</span>
              </div>
            )}

            {/* Property Categories */}
            {Object.entries(categories).map(([category, descriptors]) => {
              const isCollapsed = collapsedCategories[category];

              return (
                <div key={category} className="py-1">
                  {/* Category Header */}
                  <div
                    onClick={() => toggleCategory(category)}
                    className="flex items-center justify-between px-3 py-1 cursor-pointer hover:bg-[#272e3d] text-[#8b97a8] font-semibold text-[11px] uppercase tracking-wider select-none"
                  >
                    <span>{category}</span>
                    {isCollapsed ? (
                      <ChevronRight className="w-3.5 h-3.5" />
                    ) : (
                      <ChevronDown className="w-3.5 h-3.5" />
                    )}
                  </div>

                  {/* Category Fields */}
                  {!isCollapsed && (
                    <div className="px-2 py-0.5 space-y-0.5">
                      {descriptors
                        .filter((desc) => !desc.visibleWhen || desc.visibleWhen(selectedNode.properties))
                        .map((desc) => (
                          <PropertyField
                            key={desc.key}
                            descriptor={desc.dynamicLabel ? { ...desc, label: desc.dynamicLabel(selectedNode.properties) } : desc}
                            value={getAtPath(selectedNode.properties, desc.key).value}
                            onChange={(newVal) =>
                              // AIS-19: Move/Rotate/Scale = SetTransformCommand (atua no grupo com 2+ selecionados)
                              meta.is3D &&
                              desc.type === 'vector3' &&
                              (desc.key === 'position' || desc.key === 'rotation' || desc.key === 'scale')
                                ? updateNodeTransform(selectedNode.id, desc.key, newVal)
                                : changeNodeProperty(selectedNode.id, desc.key, newVal)
                            }
                          />
                        ))}
                    </div>
                  )}
                </div>
              );
            })}

            {/* AIS-43: variáveis locais do nó (Commands; abaixo dos atributos) */}
            <LocalVariablesSection node={selectedNode} />
          </div>
        ) : (
          <NodeSignalsTab node={selectedNode} />
        )}
      </div>
    </div>
  );
};
