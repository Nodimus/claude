import React, { useState, useRef, useEffect } from 'react';
import { GameNode } from '../../types/node';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { applyTreeClick } from './treeSelection';
import { NodeIcon } from '../common/NodeIcon';
import { useFileDrop, isFileSystemDrag } from '../../hooks/useFileDrop';
import { FS_DRAG_MIME } from '../../core/fileSystem/dropActions';
import {
  ChevronRight,
  ChevronDown,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  FileCode,
  Sparkles,
  Radio,
} from 'lucide-react';

interface SceneTreeNodeProps {
  nodeId: string;
  depth: number;
  searchFilter: string;
  onContextMenu: (e: React.MouseEvent, nodeId: string) => void;
  renameRequestNodeId?: string | null;
  onRenameRequest?: (nodeId: string) => void;
  onRenameRequestConsumed?: () => void;
}

export const SceneTreeNode: React.FC<SceneTreeNodeProps> = ({
  nodeId,
  depth,
  searchFilter,
  onContextMenu,
  renameRequestNodeId,
  onRenameRequest,
  onRenameRequestConsumed,
}) => {
  const {
    activeScene,
    selectedNodeId,
    selectNode,
    renameNode,
    toggleNodeVisibility,
    setNodesVisibility,
    toggleNodeLock,
    reparentOrReorderNode,
    behaviors,
  } = useEditor();
  const dropFile = useFileDrop(); // AIS-31

  const node = activeScene.nodes[nodeId];
  const [isExpanded, setIsExpanded] = useState(true);
  const [isRenaming, setIsRenaming] = useState(false);
  const [renameText, setRenameText] = useState(node?.name || '');
  const [dropZone, setDropZone] = useState<'before' | 'inside' | 'after' | null>(null);
  const isDragOver = dropZone === 'inside';
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isRenaming && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isRenaming]);

  useEffect(() => {
    if (node) {
      setRenameText(node.name);
    }
  }, [node?.name]);

  useEffect(() => {
    if (renameRequestNodeId === nodeId) {
      setIsRenaming(true);
      onRenameRequestConsumed?.();
    }
  }, [nodeId, onRenameRequestConsumed, renameRequestNodeId]);

  if (!node) return null;

  const hasChildren = node.childrenIds && node.childrenIds.length > 0;
  const multiSelectedNodeIds = useEditorStore((s) => s.multiSelectedNodeIds);
  const setMultiSelectedNodeIds = useEditorStore((s) => s.setMultiSelectedNodeIds);
  const isSelected = selectedNodeId === nodeId;
  const isMultiSelected = !isSelected && multiSelectedNodeIds.includes(nodeId);
  const inSelection = isSelected || isMultiSelected;

  // Filter logic
  const matchesSearch =
    !searchFilter ||
    node.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
    node.type.toLowerCase().includes(searchFilter.toLowerCase());

  // Check if node has visual logic behaviors attached
  const nodeBehaviors = behaviors.filter(
    (b) => b.targetNodeId === node.id || b.targetNodeId === node.name
  );
  const hasSignals = node.signals && node.signals.length > 0;
  const hasScript = Boolean(node.script);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      e.stopPropagation();
      renameNode(nodeId, renameText);
      setIsRenaming(false);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      setRenameText(node.name);
      setIsRenaming(false);
    }
  };

  const handleBlur = () => {
    renameNode(nodeId, renameText);
    setIsRenaming(false);
  };

  // Drag & Drop
  const handleDragStart = (e: React.DragEvent) => {
    e.stopPropagation();
    e.dataTransfer.setData('text/nodimus-node-id', nodeId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const zoneFromEvent = (e: React.DragEvent): 'before' | 'inside' | 'after' => {
    if (nodeId === activeScene.rootNodeId) return 'inside';
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const y = (e.clientY - r.top) / r.height;
    return y < 0.25 ? 'before' : y > 0.75 ? 'after' : 'inside';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // AIS-31: arquivo do FileSystemPanel solto sobre a linha (sempre "dentro": aplica no nó ou cria como filho)
    if (isFileSystemDrag(e)) {
      e.dataTransfer.dropEffect = 'copy';
      setDropZone('inside');
      return;
    }
    e.dataTransfer.dropEffect = 'move';
    setDropZone(zoneFromEvent(e));
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.stopPropagation();
    setDropZone(null);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const zone = zoneFromEvent(e);
    setDropZone(null);
    if (isFileSystemDrag(e)) {
      const path = e.dataTransfer.getData(FS_DRAG_MIME);
      if (path) dropFile(path, nodeId, nodeId);
      return;
    }
    const draggedNodeId = e.dataTransfer.getData('text/nodimus-node-id');
    if (!draggedNodeId || draggedNodeId === nodeId) return;
    if (zone === 'inside') {
      reparentOrReorderNode(draggedNodeId, nodeId);
      return;
    }
    const parentId = node.parentId;
    const parent = parentId ? activeScene.nodes[parentId] : null;
    if (!parentId || !parent) return;
    const idx = parent.childrenIds.indexOf(nodeId);
    reparentOrReorderNode(draggedNodeId, parentId, zone === 'before' ? idx : idx + 1);
  };

  return (
    <div className="select-none text-xs">
      {/* Node Row */}
      <div
        draggable
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        tabIndex={0}
        data-node-id={nodeId}
        onClick={(e) => {
          e.stopPropagation();
          // AIS-17: Ctrl/Cmd alterna, Shift seleciona intervalo (ordem visual das linhas)
          const rows = Array.from(
            (e.currentTarget.closest('[data-scene-tree]') ?? document).querySelectorAll<HTMLElement>('[data-node-id]')
          ).map((el) => el.dataset.nodeId as string);
          const next = applyTreeClick(selectedNodeId, multiSelectedNodeIds, nodeId, rows, {
            ctrl: e.ctrlKey || e.metaKey,
            shift: e.shiftKey,
          });
          selectNode(next.primaryId);
          setMultiSelectedNodeIds(next.additionalIds);
        }}
        onKeyDown={(e) => {
          if (e.key === 'F2' && !isRenaming) {
            e.preventDefault();
            onRenameRequest?.(nodeId);
          }
        }}
        onDoubleClick={(e) => {
          e.stopPropagation();
          setIsRenaming(true);
        }}
        onContextMenu={(e) => {
          e.preventDefault();
          e.stopPropagation();
          // AIS-17: botão direito dentro da seleção múltipla preserva a seleção
          if (!inSelection) selectNode(nodeId);
          onContextMenu(e, nodeId);
        }}
        style={{ paddingLeft: `${depth * 14 + 6}px` }}
        className={`group flex items-center h-6 pr-2 rounded-sm cursor-pointer transition-colors border ${
          isSelected
            ? 'bg-[#4982ea] text-white border-[#bbc7dc]'
            : isMultiSelected
            ? 'bg-[#2f4f8f] text-white border-[#4982ea]'
            : isDragOver
            ? 'bg-[#3b455b] text-[#dfe4ec] outline outline-1 outline-[#4982ea] border-transparent'
            : 'hover:bg-[#272e3d] text-[#dfe4ec] border-transparent'
        } ${dropZone === 'before' ? 'shadow-[inset_0_2px_0_0_#4982ea]' : ''} ${
          dropZone === 'after' ? 'shadow-[inset_0_-2px_0_0_#4982ea]' : ''
        } ${!matchesSearch && searchFilter ? 'opacity-40' : 'opacity-100'}`}
      >
        {/* Expand / Collapse arrow */}
        <div
          onClick={(e) => {
            e.stopPropagation();
            setIsExpanded(!isExpanded);
          }}
          className="w-4 h-4 flex items-center justify-center shrink-0 text-[#8b97a8] hover:text-white"
        >
          {hasChildren && (
            isExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />
          )}
        </div>

        {/* Node Type Icon */}
        <div className="mr-1.5 shrink-0 flex items-center">
          <NodeIcon type={node.type} />
        </div>

        {/* Node Name or Renaming Input */}
        <div className="flex-1 truncate min-w-0 pr-1">
          {isRenaming ? (
            <input
              ref={inputRef}
              type="text"
              value={renameText}
              onChange={(e) => setRenameText(e.target.value)}
              onKeyDown={handleKeyDown}
              onBlur={handleBlur}
              className="w-full bg-[#181c24] text-white px-1 py-0.5 text-xs rounded border border-[#4982ea] outline-none"
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <span
              className={`font-normal truncate ${
                isSelected ? 'text-white font-medium' : 'text-[#dfe4ec]'
              } ${!node.visible ? 'line-through opacity-60' : ''}`}
            >
              {node.name}
            </span>
          )}
        </div>

        {/* Node indicators (Script, Behaviors, Signals) */}
        <div className="flex items-center gap-1 shrink-0 mr-1 text-[#8b97a8]">
          {hasScript && (
            <span title="Script attached">
              <FileCode className={`w-3 h-3 ${isSelected ? 'text-white' : 'text-blue-400'}`} />
            </span>
          )}
          {nodeBehaviors.length > 0 && (
            <span title={`${nodeBehaviors.length} Visual Behavior(s) attached`}>
              <Sparkles className={`w-3 h-3 ${isSelected ? 'text-white' : 'text-amber-400'}`} />
            </span>
          )}
          {hasSignals && (
            <span title={`Connected signals (${node.signals?.length ?? 0})`}>
              <Radio className={`w-3 h-3 ${isSelected ? 'text-white' : 'text-purple-400'}`} />
            </span>
          )}
        </div>

        {/* Action icons (Visibility, Lock) */}
        <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
          {/* Eye visibility toggle */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              // AIS-17: com seleção múltipla, o olho atua em todos os selecionados (um Command)
              if (inSelection && multiSelectedNodeIds.length > 0) {
                setNodesVisibility([selectedNodeId as string, ...multiSelectedNodeIds].filter(Boolean), !node.visible);
              } else {
                toggleNodeVisibility(nodeId);
              }
            }}
            className={`p-0.5 rounded hover:bg-[#343e52] ${
              node.visible ? 'text-[#8b97a8]' : 'text-amber-400 opacity-100'
            }`}
            title={node.visible ? 'Hide Node' : 'Show Node'}
          >
            {node.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
          </button>

          {/* Lock toggle */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleNodeLock(nodeId);
            }}
            className={`p-0.5 rounded hover:bg-[#343e52] ${
              node.locked ? 'text-rose-400 opacity-100' : 'text-[#8b97a8]'
            }`}
            title={node.locked ? 'Unlock Node' : 'Lock Node in Viewport'}
          >
            {node.locked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
          </button>
        </div>
      </div>

      {/* Children Recursion */}
      {hasChildren && isExpanded && (
        <div>
          {node.childrenIds.map((childId) => (
            <SceneTreeNode
              key={childId}
              nodeId={childId}
              depth={depth + 1}
              searchFilter={searchFilter}
              onContextMenu={onContextMenu}
              renameRequestNodeId={renameRequestNodeId}
              onRenameRequest={onRenameRequest}
              onRenameRequestConsumed={onRenameRequestConsumed}
            />
          ))}
        </div>
      )}
    </div>
  );
};
