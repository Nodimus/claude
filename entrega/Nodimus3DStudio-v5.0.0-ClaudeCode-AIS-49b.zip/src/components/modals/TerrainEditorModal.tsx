import React, { useState, useRef, useEffect } from 'react';
import { useEditor } from '../../core/EditorContext';
import { globalCommandManager } from '../../core/commandManager';
import {
  Mountain,
  Trees,
  Layers,
  Sparkles,
  X,
  Upload,
  RotateCcw,
  Check,
  Eye,
  Sliders,
  Palette,
  Wind,
  Info,
  ExternalLink,
  ChevronRight,
  Maximize2,
  Paintbrush,
  Flame,
  Waves,
  Sun,
  Hammer,
} from 'lucide-react';

export type TerrainTopology = 'hills' | 'mountains' | 'flat' | 'desert' | 'canyon';
export type SculptTool = 'raise_lower' | 'mountain_valley' | 'smooth' | 'flatten' | 'noise' | 'paint_grass';

export const TerrainEditorModal: React.FC = () => {
  const {
    isTerrainEditorOpen,
    setIsTerrainEditorOpen,
    setIsTreeEditorOpen,
    activeScene,
    addNode,
    selectNode,
    addLog,
  } = useEditor();

  const [activeTab, setActiveTab] = useState<'generate' | 'textures' | 'sculpt' | 'vegetation'>('generate');

  // 1. Generation Parameters
  const [sideLength, setSideLength] = useState<number>(120);
  const [resolution, setResolution] = useState<number>(128); // 64, 128, 256
  const [maxHeight, setMaxHeight] = useState<number>(24);
  const [topology, setTopology] = useState<TerrainTopology>('hills');
  const [heightmapFileName, setHeightmapFileName] = useState<string>('');
  const [invertHeightmap, setInvertHeightmap] = useState<boolean>(false);
  const [smoothImport, setSmoothImport] = useState<boolean>(true);

  // 2. Texture Splatting Parameters
  const [groundTexture, setGroundTexture] = useState<string>('Grass_Green');
  const [midTexture, setMidTexture] = useState<string>('Rock_Cliff');
  const [highTexture, setHighTexture] = useState<string>('Snow_Mountain');
  const [textureTiling, setTextureTiling] = useState<number>(16);
  const [blendSharpness, setBlendSharpness] = useState<number>(0.5);

  // 3. Sculpt & Brush Tool Parameters
  const [activeTool, setActiveTool] = useState<SculptTool>('raise_lower');
  const [brushRadius, setBrushRadius] = useState<number>(15);
  const [brushStrength, setBrushStrength] = useState<number>(0.4);
  const [brushFalloff, setBrushFalloff] = useState<'smooth' | 'linear' | 'spherical'>('smooth');
  const [flattenTargetHeight, setFlattenTargetHeight] = useState<number>(8);

  // 4. Vegetation & Procedural Tree Generator
  const [enableGrass, setEnableGrass] = useState<boolean>(true);
  const [grassDensity, setGrassDensity] = useState<number>(60);
  const [grassPatchSize, setGrassPatchSize] = useState<number>(1.2);
  const [grassWindAnimation, setGrassWindAnimation] = useState<boolean>(true);

  const [enableTrees, setEnableTrees] = useState<boolean>(true);
  const [treeCount, setTreeCount] = useState<number>(24);
  const [treeSpecies, setTreeSpecies] = useState<'oak' | 'pine' | 'palm'>('oak');
  const [proceduralTrunkHeight, setProceduralTrunkHeight] = useState<number>(4.5);
  const [proceduralBranchDensity, setProceduralBranchDensity] = useState<number>(0.7);

  // Preview canvas
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Draw procedural 2.5D isometric terrain preview
  useEffect(() => {
    if (!isTerrainEditorOpen) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Background gradient
    const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
    bgGrad.addColorStop(0, '#151922');
    bgGrad.addColorStop(1, '#0e1118');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // Draw isometric grid / terrain contours
    const cols = 22;
    const rows = 22;
    const originX = w / 2;
    const originY = h * 0.42;
    const tileW = (w * 0.7) / cols;
    const tileH = tileW * 0.5;

    // Height generator function based on topology
    const getHeight = (r: number, c: number) => {
      const nx = (c / cols - 0.5) * 2;
      const ny = (r / rows - 0.5) * 2;
      const dist = Math.sqrt(nx * nx + ny * ny);

      let val = 0;
      if (topology === 'flat') {
        val = 0.05 * Math.sin(c * 0.5) * Math.cos(r * 0.5);
      } else if (topology === 'hills') {
        val =
          Math.sin(c * 0.4) * 0.4 +
          Math.cos(r * 0.45) * 0.35 +
          Math.sin((c + r) * 0.3) * 0.25;
      } else if (topology === 'mountains') {
        const peak = Math.max(0, 1 - dist * 1.1);
        val =
          peak * 1.5 +
          Math.sin(c * 0.7) * 0.3 +
          Math.cos(r * 0.7) * 0.3;
      } else if (topology === 'desert') {
        val = Math.sin(c * 0.3 + r * 0.4) * 0.45 + Math.cos(c * 0.1) * 0.2;
      } else if (topology === 'canyon') {
        const canyonCut = Math.abs(nx - ny * 0.4);
        val = canyonCut < 0.25 ? -0.4 : 0.6 + Math.sin(c * 0.5) * 0.15;
      }
      return val * (maxHeight / 24);
    };

    // Render terrain grid lines and faces
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const val = getHeight(r, c);
        const isoX = originX + (c - r) * (tileW * 0.5);
        const isoY = originY + (c + r) * (tileH * 0.5) - val * 18;

        // Neighbor points
        const valRight = getHeight(r, c + 1);
        const nextX = originX + (c + 1 - r) * (tileW * 0.5);
        const nextY = originY + (c + 1 + r) * (tileH * 0.5) - valRight * 18;

        const valDown = getHeight(r + 1, c);
        const downX = originX + (c - (r + 1)) * (tileW * 0.5);
        const downY = originY + (c + r + 1) * (tileH * 0.5) - valDown * 18;

        // Quad shading based on height
        const avgH = (val + valRight + valDown) / 3;
        let fillStyle = '#2a3b2a'; // ground
        if (avgH > 0.8) fillStyle = '#e2e8f0'; // snow
        else if (avgH > 0.35) fillStyle = '#64748b'; // rock
        else if (topology === 'desert') fillStyle = '#d97706';

        ctx.beginPath();
        ctx.moveTo(isoX, isoY);
        ctx.lineTo(nextX, nextY);
        ctx.lineTo(downX + (tileW * 0.5), downY + (tileH * 0.5));
        ctx.lineTo(downX, downY);
        ctx.closePath();

        ctx.fillStyle = fillStyle;
        ctx.globalAlpha = 0.65;
        ctx.fill();
        ctx.strokeStyle = '#3b475f';
        ctx.lineWidth = 0.8;
        ctx.stroke();
      }
    }
    ctx.globalAlpha = 1.0;

    // Overlay Trees indicator
    if (enableTrees) {
      ctx.fillStyle = '#22c55e';
      for (let i = 0; i < Math.min(treeCount, 20); i++) {
        const tc = (i * 7) % cols;
        const tr = (i * 11) % rows;
        const val = getHeight(tr, tc);
        if (val < 0.75) {
          const tx = originX + (tc - tr) * (tileW * 0.5);
          const ty = originY + (tc + tr) * (tileH * 0.5) - val * 18 - 8;
          ctx.beginPath();
          ctx.arc(tx, ty, 3, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    // Overlay label
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px monospace';
    ctx.fillText(`${sideLength}m x ${sideLength}m | Res: ${resolution}x${resolution} | ${topology.toUpperCase()}`, 12, h - 12);
  }, [isTerrainEditorOpen, sideLength, resolution, maxHeight, topology, enableTrees, treeCount]);

  if (!isTerrainEditorOpen) return null;

  // Handle Heightmap file selection
  const handleHeightmapSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setHeightmapFileName(file.name);
      addLog('log', `Loaded heightmap file: ${file.name}`);
    }
  };

  // Generate / Create Terrain into Scene
  const createTerrainNodes = (parentId: string) => {
    // Cada nó nasce completo (propriedades iniciais no próprio Command de criação)
    const terrainNode = addNode('MeshInstance', parentId, `Terrain_${topology}`, {
      meshType: 'Plane',
      width: sideLength,
      depth: sideLength,
      height: maxHeight,
      isTerrain: true,
      terrainResolution: resolution,
      topology,
      groundTexture,
      midTexture,
      highTexture,
      enableGrass,
      grassDensity,
    });

    // Add trees as child nodes in the scene graph (as CopperCube does)
    if (enableTrees && treeCount > 0) {
      for (let i = 0; i < Math.min(treeCount, 8); i++) {
        const angle = (i / 8) * Math.PI * 2;
        const dist = (sideLength * 0.25) * (0.5 + 0.5 * Math.sin(i * 3));
        addNode('Billboard', terrainNode.id, `Tree_${treeSpecies}_${i + 1}`, {
          position: {
            x: Math.cos(angle) * dist,
            y: maxHeight * 0.2,
            z: Math.sin(angle) * dist,
          },
        });
      }
    }
    return terrainNode;
  };

  const handleCreateTerrain = () => {
    const parentId = activeScene.rootNodeId;
    // AIS-22: terreno + árvores = UMA transação (um Ctrl+Z desfaz o conjunto)
    const terrainNode = globalCommandManager.transaction('Create Terrain', () => createTerrainNodes(parentId));

    selectNode(terrainNode.id);
    addLog('log', `Created terrain '${terrainNode.name}' with resolution ${resolution}x${resolution}`);
    setIsTerrainEditorOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none">
      <div className="w-[840px] h-[610px] bg-[#1e232f] border border-[#3b475f] rounded-lg shadow-2xl flex flex-col overflow-hidden text-xs text-[#dfe4ec]">
        {/* Header */}
        <div className="h-11 bg-[#171b24] border-b border-[#2c3345] px-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5 font-semibold text-white">
            <div className="p-1 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Mountain className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[13px]">Terrain Editor & Generator</span>
                <span className="px-1.5 py-0.2 bg-[#2a3244] text-[#8b97a8] rounded text-[10px] font-normal">
                  Heightmap & Sculpting
                </span>
              </div>
              <div className="text-[10px] text-[#8b97a8] font-normal">
                Scene: <span className="text-white">{activeScene?.name}</span> (CopperCube & Three.js compatible)
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="https://www.ambiera.com/coppercube/doc/cnt_terrain.html"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#8b97a8] hover:text-emerald-400 p-1 flex items-center gap-1 transition-colors"
              title="Open documentation"
            >
              <Info className="w-3.5 h-3.5" />
              <span className="text-[10px]">Doc</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <button
              onClick={() => setIsTerrainEditorOpen(false)}
              className="p-1 text-[#8b97a8] hover:text-white rounded hover:bg-[#2c3345] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar Tabs */}
          <div className="w-48 border-r border-[#2c3345] bg-[#171b24] p-2 space-y-1">
            <button
              onClick={() => setActiveTab('generate')}
              className={`w-full text-left px-3 py-2 rounded flex items-center gap-2 transition-colors ${
                activeTab === 'generate'
                  ? 'bg-[#4982ea] text-white font-medium shadow-sm'
                  : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <Mountain className="w-3.5 h-3.5 text-amber-400" />
              <span>Generation & Size</span>
            </button>

            <button
              onClick={() => setActiveTab('textures')}
              className={`w-full text-left px-3 py-2 rounded flex items-center gap-2 transition-colors ${
                activeTab === 'textures'
                  ? 'bg-[#4982ea] text-white font-medium shadow-sm'
                  : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <Palette className="w-3.5 h-3.5 text-sky-400" />
              <span>Textures & Splatting</span>
            </button>

            <button
              onClick={() => setActiveTab('sculpt')}
              className={`w-full text-left px-3 py-2 rounded flex items-center gap-2 transition-colors ${
                activeTab === 'sculpt'
                  ? 'bg-[#4982ea] text-white font-medium shadow-sm'
                  : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <Paintbrush className="w-3.5 h-3.5 text-pink-400" />
              <span>Sculpt & Brush Tools</span>
            </button>

            <button
              onClick={() => setActiveTab('vegetation')}
              className={`w-full text-left px-3 py-2 rounded flex items-center gap-2 transition-colors ${
                activeTab === 'vegetation'
                  ? 'bg-[#4982ea] text-white font-medium shadow-sm'
                  : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <Trees className="w-3.5 h-3.5 text-emerald-400" />
              <span>Grass & Tree Generator</span>
            </button>

            {/* Quick Live Preview Box */}
            <div className="pt-3">
              <div className="px-2 pb-1 text-[10px] font-semibold text-[#68768e] uppercase tracking-wider">
                Topology Preview
              </div>
              <div className="p-1 rounded bg-[#13161f] border border-[#2c3345]">
                <canvas
                  ref={canvasRef}
                  width={172}
                  height={130}
                  className="w-full rounded bg-[#0f1219] block"
                />
              </div>
            </div>
          </div>

          {/* Configuration Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#1b202c]">
            {/* 1. Generate & Dimensions Tab */}
            {activeTab === 'generate' && (
              <div className="space-y-4">
                {/* Dimensions Card */}
                <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-[#2c3345]">
                    <Mountain className="w-4 h-4 text-amber-400" />
                    <div>
                      <div className="font-semibold text-white">Terrain Dimensions & Geometry</div>
                      <div className="text-[10px] text-[#8b97a8]">
                        Configure world side length, tile resolution, and height scaling.
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-[#8b97a8]">
                        <span>Side Length (World units)</span>
                        <span className="text-white font-mono">{sideLength}m</span>
                      </div>
                      <input
                        type="range"
                        min={30}
                        max={500}
                        step={10}
                        value={sideLength}
                        onChange={(e) => setSideLength(parseInt(e.target.value) || 100)}
                        className="w-full accent-[#4982ea]"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-[#8b97a8]">
                        <span>Max Height (Elevation)</span>
                        <span className="text-white font-mono">{maxHeight}m</span>
                      </div>
                      <input
                        type="range"
                        min={5}
                        max={80}
                        step={1}
                        value={maxHeight}
                        onChange={(e) => setMaxHeight(parseInt(e.target.value) || 20)}
                        className="w-full accent-[#4982ea]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-1">
                    <div>
                      <label className="text-[#8b97a8] block mb-1">Tile Size / Resolution:</label>
                      <select
                        value={resolution}
                        onChange={(e) => setResolution(parseInt(e.target.value))}
                        className="w-full px-2.5 py-1.5 bg-[#171b24] border border-[#2c3345] rounded text-white"
                      >
                        <option value={64}>64 x 64 (Low poly / High perf)</option>
                        <option value={128}>128 x 128 (Recommended for WebGL)</option>
                        <option value={256}>256 x 256 (High resolution detail)</option>
                      </select>
                      <span className="text-[10px] text-[#718096] mt-0.5 block">
                        Doc recommends 128x128 for optimal mobile & WebGL load times.
                      </span>
                    </div>

                    <div>
                      <label className="text-[#8b97a8] block mb-1">Topology Preset:</label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {(['hills', 'mountains', 'flat', 'desert', 'canyon'] as TerrainTopology[]).map((t) => (
                          <button
                            key={t}
                            onClick={() => setTopology(t)}
                            className={`px-2 py-1.5 rounded text-center capitalize transition-colors border ${
                              topology === t
                                ? 'bg-[#4982ea] text-white border-blue-400 font-medium'
                                : 'bg-[#171b24] text-[#8b97a8] border-[#2c3345] hover:text-white'
                            }`}
                          >
                            {t}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Heightmap Import Card */}
                <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-[#2c3345]">
                    <Upload className="w-4 h-4 text-sky-400" />
                    <div>
                      <div className="font-semibold text-white">Import Heightmap (Optional)</div>
                      <div className="text-[10px] text-[#8b97a8]">
                        Import raw elevation data (.png, .raw, .r16, .r32, .tga, .pgm)
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <label className="px-3 py-1.5 rounded bg-[#2a3244] hover:bg-[#343e54] text-white font-medium cursor-pointer border border-[#3b475f] flex items-center gap-1.5 transition-colors">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Choose Heightmap File...</span>
                      <input
                        type="file"
                        accept=".png,.raw,.r16,.r32,.tga,.pgm,.jpg,.jpeg"
                        onChange={handleHeightmapSelect}
                        className="hidden"
                      />
                    </label>

                    <span className="text-[#8b97a8] truncate max-w-xs font-mono">
                      {heightmapFileName ? heightmapFileName : 'No file chosen (using procedural generator)'}
                    </span>
                  </div>

                  <div className="flex items-center gap-6 pt-1 text-[#8b97a8]">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={invertHeightmap}
                        onChange={(e) => setInvertHeightmap(e.target.checked)}
                        className="rounded bg-[#171b24] border-[#2c3345] text-[#4982ea]"
                      />
                      <span>Invert Heightmap</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={smoothImport}
                        onChange={(e) => setSmoothImport(e.target.checked)}
                        className="rounded bg-[#171b24] border-[#2c3345] text-[#4982ea]"
                      />
                      <span>Smooth Heightmap Filtering</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* 2. Textures & Splatting Tab */}
            {activeTab === 'textures' && (
              <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-[#2c3345]">
                  <Palette className="w-4 h-4 text-sky-400" />
                  <div>
                    <div className="font-semibold text-white">Multi-Texture Elevation Splatting</div>
                    <div className="text-[10px] text-[#8b97a8]">
                      Assign ground, slope, and peak textures based on height and incline.
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  {/* Ground Texture */}
                  <div className="p-3 rounded bg-[#171b24] border border-[#2c3345] space-y-2">
                    <div className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                      <span>Ground (Valley/Base)</span>
                    </div>
                    <select
                      value={groundTexture}
                      onChange={(e) => setGroundTexture(e.target.value)}
                      className="w-full px-2 py-1 bg-[#202636] border border-[#2c3345] rounded text-white"
                    >
                      <option value="Grass_Green">Grass (Green Spring)</option>
                      <option value="Sand_Desert">Desert Sand</option>
                      <option value="Dirt_Soil">Dark Soil / Mud</option>
                      <option value="Pebbles_Gravel">River Pebbles</option>
                    </select>
                    <div className="h-14 rounded border border-[#2c3345] bg-[#224422] flex items-center justify-center text-[10px] text-emerald-200">
                      Texture Preview: {groundTexture}
                    </div>
                  </div>

                  {/* Mid-Level Texture */}
                  <div className="p-3 rounded bg-[#171b24] border border-[#2c3345] space-y-2">
                    <div className="text-[11px] font-semibold text-amber-400 flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                      <span>Mid-Level (Slope/Cliff)</span>
                    </div>
                    <select
                      value={midTexture}
                      onChange={(e) => setMidTexture(e.target.value)}
                      className="w-full px-2 py-1 bg-[#202636] border border-[#2c3345] rounded text-white"
                    >
                      <option value="Rock_Cliff">Rock Cliff (Slate)</option>
                      <option value="Granite_Rough">Rough Granite</option>
                      <option value="Dry_Dirt">Dry Rocky Dirt</option>
                    </select>
                    <div className="h-14 rounded border border-[#2c3345] bg-[#443828] flex items-center justify-center text-[10px] text-amber-200">
                      Texture Preview: {midTexture}
                    </div>
                  </div>

                  {/* High-Point Texture */}
                  <div className="p-3 rounded bg-[#171b24] border border-[#2c3345] space-y-2">
                    <div className="text-[11px] font-semibold text-cyan-300 flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                      <span>High-Point (Mountain Peak)</span>
                    </div>
                    <select
                      value={highTexture}
                      onChange={(e) => setHighTexture(e.target.value)}
                      className="w-full px-2 py-1 bg-[#202636] border border-[#2c3345] rounded text-white"
                    >
                      <option value="Snow_Mountain">Alpine Snow</option>
                      <option value="Bare_Rock">Dark Peak Stone</option>
                      <option value="Ice_Glacier">Glacier Ice</option>
                    </select>
                    <div className="h-14 rounded border border-[#2c3345] bg-[#334455] flex items-center justify-center text-[10px] text-cyan-100">
                      Texture Preview: {highTexture}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div className="space-y-1">
                    <div className="flex justify-between text-[#8b97a8]">
                      <span>Texture UV Tiling Repeat</span>
                      <span className="text-white font-mono">{textureTiling}x</span>
                    </div>
                    <input
                      type="range"
                      min={4}
                      max={64}
                      step={4}
                      value={textureTiling}
                      onChange={(e) => setTextureTiling(parseInt(e.target.value) || 16)}
                      className="w-full accent-[#4982ea]"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[#8b97a8]">
                      <span>Layer Blend Sharpness</span>
                      <span className="text-white font-mono">{blendSharpness.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min={0.1}
                      max={1.0}
                      step={0.05}
                      value={blendSharpness}
                      onChange={(e) => setBlendSharpness(parseFloat(e.target.value) || 0.5)}
                      className="w-full accent-[#4982ea]"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 3. Sculpt & Brush Tools Tab */}
            {activeTab === 'sculpt' && (
              <div className="space-y-4">
                <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-[#2c3345]">
                    <Paintbrush className="w-4 h-4 text-pink-400" />
                    <div>
                      <div className="font-semibold text-white">Terrain Sculpting & Brush Tools</div>
                      <div className="text-[10px] text-[#8b97a8]">
                        Direct viewport manipulation: drag with left mouse button to sculpt.
                      </div>
                    </div>
                  </div>

                  {/* Tool selection grid */}
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'raise_lower', label: 'Raise / Lower', desc: 'Hold LMB and move mouse up/down' },
                      { id: 'mountain_valley', label: 'Mountain / Valley', desc: 'Creates peaks or dips' },
                      { id: 'smooth', label: 'Smooth', desc: 'Smooths out harsh jagged edges' },
                      { id: 'flatten', label: 'Flatten', desc: 'Levels terrain to target height' },
                      { id: 'noise', label: 'Noise', desc: 'Adds natural organic roughness' },
                      { id: 'paint_grass', label: 'Paint Grass / Texture', desc: 'Paint patches (Shift to erase)' },
                    ].map((tool) => (
                      <button
                        key={tool.id}
                        onClick={() => setActiveTool(tool.id as SculptTool)}
                        className={`p-2.5 rounded text-left border transition-all ${
                          activeTool === tool.id
                            ? 'bg-[#4982ea] text-white border-blue-400 shadow-md'
                            : 'bg-[#171b24] text-[#8b97a8] border-[#2c3345] hover:text-white'
                        }`}
                      >
                        <div className="font-semibold text-xs text-white">{tool.label}</div>
                        <div className="text-[10px] text-[#8b97a8] mt-0.5 line-clamp-1">{tool.desc}</div>
                      </button>
                    ))}
                  </div>

                  {/* Brush settings */}
                  <div className="grid grid-cols-2 gap-4 pt-3 border-t border-[#2c3345]">
                    <div className="space-y-1">
                      <div className="flex justify-between text-[#8b97a8]">
                        <span>Brush Radius</span>
                        <span className="text-white font-mono">{brushRadius}m</span>
                      </div>
                      <input
                        type="range"
                        min={2}
                        max={50}
                        step={1}
                        value={brushRadius}
                        onChange={(e) => setBrushRadius(parseInt(e.target.value) || 10)}
                        className="w-full accent-[#4982ea]"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-[#8b97a8]">
                        <span>Brush Strength / Speed</span>
                        <span className="text-white font-mono">{brushStrength.toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min={0.05}
                        max={1.0}
                        step={0.05}
                        value={brushStrength}
                        onChange={(e) => setBrushStrength(parseFloat(e.target.value) || 0.3)}
                        className="w-full accent-[#4982ea]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-1">
                    <div>
                      <label className="text-[#8b97a8] block mb-1">Brush Falloff Curve:</label>
                      <select
                        value={brushFalloff}
                        onChange={(e) => setBrushFalloff(e.target.value as any)}
                        className="w-full px-2.5 py-1.5 bg-[#171b24] border border-[#2c3345] rounded text-white"
                      >
                        <option value="smooth">Smooth Bell (Gaussian)</option>
                        <option value="linear">Linear Cone</option>
                        <option value="spherical">Spherical Dome</option>
                      </select>
                    </div>

                    <div>
                      <div className="flex justify-between text-[#8b97a8] mb-1">
                        <span>Flatten Target Elevation:</span>
                        <span className="text-white font-mono">{flattenTargetHeight}m</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={40}
                        step={0.5}
                        value={flattenTargetHeight}
                        onChange={(e) => setFlattenTargetHeight(parseFloat(e.target.value) || 0)}
                        className="w-full accent-[#4982ea]"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 4. Vegetation & Procedural Tree Generator Tab */}
            {activeTab === 'vegetation' && (
              <div className="space-y-4">
                {/* Grass Decoration */}
                <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-[#2c3345]">
                    <div className="flex items-center gap-2">
                      <Wind className="w-4 h-4 text-emerald-400" />
                      <div>
                        <div className="font-semibold text-white">Grass Decoration & Wind</div>
                        <div className="text-[10px] text-[#8b97a8]">
                          Distribute animated 3D grass patches across flat terrain areas.
                        </div>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={enableGrass}
                        onChange={(e) => setEnableGrass(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-[#2c3345] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-[#3b475f] after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#4982ea]"></div>
                    </label>
                  </div>

                  <div
                    className={`grid grid-cols-2 gap-4 transition-opacity ${
                      enableGrass ? 'opacity-100' : 'opacity-40 pointer-events-none'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="flex justify-between text-[#8b97a8]">
                        <span>Grass Density</span>
                        <span className="text-white font-mono">{grassDensity}%</span>
                      </div>
                      <input
                        type="range"
                        min={10}
                        max={100}
                        step={5}
                        value={grassDensity}
                        onChange={(e) => setGrassDensity(parseInt(e.target.value) || 50)}
                        className="w-full accent-[#4982ea]"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-[#8b97a8]">
                        <span>Patch Size Scale</span>
                        <span className="text-white font-mono">{grassPatchSize.toFixed(1)}x</span>
                      </div>
                      <input
                        type="range"
                        min={0.5}
                        max={3.0}
                        step={0.1}
                        value={grassPatchSize}
                        onChange={(e) => setGrassPatchSize(parseFloat(e.target.value) || 1.0)}
                        className="w-full accent-[#4982ea]"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-1 text-[#8b97a8]">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={grassWindAnimation}
                        onChange={(e) => setGrassWindAnimation(e.target.checked)}
                        className="rounded bg-[#171b24] border-[#2c3345] text-[#4982ea]"
                      />
                      <span>Enable Wind Waving Animation on Grass</span>
                    </label>
                  </div>
                </div>

                {/* Procedural Tree Generator */}
                <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-[#2c3345]">
                    <div className="flex items-center gap-2">
                      <Trees className="w-4 h-4 text-emerald-400" />
                      <div>
                        <div className="font-semibold text-white">Procedural Tree Generator</div>
                        <div className="text-[10px] text-[#8b97a8]">
                          Generate procedural 3D animated trees distributed as children in the Scene Graph.
                        </div>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={enableTrees}
                        onChange={(e) => setEnableTrees(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-[#2c3345] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-[#3b475f] after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#4982ea]"></div>
                    </label>
                  </div>

                  <div
                    className={`space-y-3 transition-opacity ${
                      enableTrees ? 'opacity-100' : 'opacity-40 pointer-events-none'
                    }`}
                  >
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-[#8b97a8] block mb-1">Tree Species / Foliage Type:</label>
                        <select
                          value={treeSpecies}
                          onChange={(e) => setTreeSpecies(e.target.value as any)}
                          className="w-full px-2.5 py-1.5 bg-[#171b24] border border-[#2c3345] rounded text-white"
                        >
                          <option value="oak">Deciduous Oak / Broadleaf</option>
                          <option value="pine">Conifer Pine / Evergreen</option>
                          <option value="palm">Tropical Palm</option>
                        </select>
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[#8b97a8]">
                          <span>Tree Count</span>
                          <span className="text-white font-mono">{treeCount} trees</span>
                        </div>
                        <input
                          type="range"
                          min={0}
                          max={100}
                          step={4}
                          value={treeCount}
                          onChange={(e) => setTreeCount(parseInt(e.target.value) || 0)}
                          className="w-full accent-[#4982ea]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-1">
                      <div className="space-y-1">
                        <div className="flex justify-between text-[#8b97a8]">
                          <span>Trunk Height</span>
                          <span className="text-white font-mono">{proceduralTrunkHeight.toFixed(1)}m</span>
                        </div>
                        <input
                          type="range"
                          min={2.0}
                          max={10.0}
                          step={0.5}
                          value={proceduralTrunkHeight}
                          onChange={(e) => setProceduralTrunkHeight(parseFloat(e.target.value) || 4.0)}
                          className="w-full accent-[#4982ea]"
                        />
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-[#8b97a8]">
                          <span>Branch & Canopy Density</span>
                          <span className="text-white font-mono">{(proceduralBranchDensity * 100).toFixed(0)}%</span>
                        </div>
                        <input
                          type="range"
                          min={0.2}
                          max={1.0}
                          step={0.05}
                          value={proceduralBranchDensity}
                          onChange={(e) => setProceduralBranchDensity(parseFloat(e.target.value) || 0.7)}
                          className="w-full accent-[#4982ea]"
                        />
                      </div>
                    </div>

                    <div className="pt-2 border-t border-[#2c3345] flex items-center justify-between">
                      <span className="text-[11px] text-[#8b97a8]">
                        Deseja customizar tronco, ramificações, casca e folhagem em detalhe?
                      </span>
                      <button
                        onClick={() => {
                          setIsTerrainEditorOpen(false);
                          setIsTreeEditorOpen(true);
                        }}
                        className="px-2.5 py-1 bg-[#1b202c] hover:bg-[#252c3c] border border-emerald-500/40 text-emerald-400 rounded text-xs flex items-center gap-1.5 transition-colors shrink-0"
                      >
                        <Trees className="w-3.5 h-3.5" />
                        <span>Tree Editor Dedicado...</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="h-12 bg-[#171b24] border-t border-[#2c3345] px-4 flex items-center justify-between">
          <button
            onClick={() => {
              setSideLength(120);
              setMaxHeight(24);
              setResolution(128);
              setTopology('hills');
              setEnableGrass(true);
              setEnableTrees(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#8b97a8] hover:text-white transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Defaults</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsTerrainEditorOpen(false)}
              className="px-3.5 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleCreateTerrain}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-[#4982ea] hover:bg-[#3b6ecc] text-white font-medium shadow-md transition-colors"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Create Terrain in Scene</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
