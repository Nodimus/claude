import type { NodeType, NodeTypeMetadata, GameNode, PropertyDescriptor } from '../types/node';
import { PARTICLE_DEFAULTS, PARTICLE_LIMITS } from '../core/particles/particleTypes';
import { LAYOUT_PRESET_ORDER, layoutFieldLabels, normalizeLayoutPreset } from '../runtime/overlay';
import { SIZE_FLAG_VALUES } from '../runtime/containerLayout';

/** Layout Presets do Godot (AIS-25b): 9 de ponto + 6 esticados + Full-Rect. */
const LAYOUT_PRESET_OPTIONS = LAYOUT_PRESET_ORDER.map((preset) => ({ label: preset, value: preset }));
const layoutLabel = (field: 'posX' | 'posY' | 'width' | 'height') => (properties: Record<string, any>) =>
  layoutFieldLabels(normalizeLayoutPreset(properties.alignment))[field];

// ── AIS-25c: Containers e controles de UI (modelo Control/Container da Godot sobre o UIKit) ─────────
// Um filho de Container tem o posicionamento assumido pelo Container: valem os size flags, `minSize` e
// `stretchRatio` (categoria 'Container Layout'); fora de Container valem o preset + offsets ('2D Coordinates').
// O Inspector mostra uma ou outra conforme o pai (ver `uiLayoutCategories`).

/** Size flags do Godot (por eixo; definição em `runtime/containerLayout.ts`). */
const SIZE_FLAG_OPTIONS = SIZE_FLAG_VALUES.map((value) => ({ label: value, value }));

/** Categorias de descriptor de layout de UI (o Inspector escolhe uma conforme o pai ser Container). */
export const UI_FREE_LAYOUT_CATEGORY = '2D Coordinates';
export const UI_CONTAINER_LAYOUT_CATEGORY = 'Container Layout';

/** Campos de layout "em Container", comuns a TODO nó de UI (inclusive Overlay2D/TextOverlay2D/ButtonOverlay2D). */
const UI_CHILD_DESCRIPTORS: PropertyDescriptor[] = [
  { key: 'sizeFlagsH', label: 'Size Flags H', type: 'enum', category: UI_CONTAINER_LAYOUT_CATEGORY, defaultValue: 'fill', options: SIZE_FLAG_OPTIONS },
  { key: 'sizeFlagsV', label: 'Size Flags V', type: 'enum', category: UI_CONTAINER_LAYOUT_CATEGORY, defaultValue: 'fill', options: SIZE_FLAG_OPTIONS },
  { key: 'minSize', label: 'Min Size (px)', type: 'vector2', category: UI_CONTAINER_LAYOUT_CATEGORY, defaultValue: { x: 0, y: 0 } },
  { key: 'stretchRatio', label: 'Stretch Ratio', type: 'float', category: UI_CONTAINER_LAYOUT_CATEGORY, defaultValue: 1, min: 0.1, step: 0.1 },
];

const UI_LAYOUT_DESCRIPTORS = (width: number, height: number): PropertyDescriptor[] => [
  { key: 'posX', label: 'Position X (px)', type: 'integer', category: UI_FREE_LAYOUT_CATEGORY, defaultValue: 20, dynamicLabel: layoutLabel('posX') },
  { key: 'posY', label: 'Position Y (px)', type: 'integer', category: UI_FREE_LAYOUT_CATEGORY, defaultValue: 20, dynamicLabel: layoutLabel('posY') },
  { key: 'width', label: 'Width (px)', type: 'integer', category: UI_FREE_LAYOUT_CATEGORY, defaultValue: width, dynamicLabel: layoutLabel('width') },
  { key: 'height', label: 'Height (px)', type: 'integer', category: UI_FREE_LAYOUT_CATEGORY, defaultValue: height, dynamicLabel: layoutLabel('height') },
  {
    key: 'alignment',
    label: 'Layout Preset',
    type: 'enum',
    category: UI_FREE_LAYOUT_CATEGORY,
    defaultValue: 'Top-Left',
    options: LAYOUT_PRESET_OPTIONS,
  },
];

const UI_BOX_APPEARANCE: PropertyDescriptor[] = [
  { key: 'color', label: 'Background Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.1, g: 0.13, b: 0.19, a: 0.9 } },
  { key: 'borderColor', label: 'Border Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.29, g: 0.51, b: 0.92, a: 1 } },
  { key: 'borderWidth', label: 'Border Width', type: 'integer', category: 'Appearance', defaultValue: 1, min: 0, max: 10 },
  { key: 'cornerRadius', label: 'Corner Radius', type: 'integer', category: 'Appearance', defaultValue: 6, min: 0, max: 64 },
];

const UI_VISIBLE: PropertyDescriptor = { key: 'visible', label: 'Visible', type: 'boolean', category: 'General', defaultValue: true };

/** Entrada de nó de UI: layout livre + layout de Container + o que for específico do tipo. */
function defineUiNode<T extends string>(def: {
  type: T;
  description: string;
  icon: string;
  size: { width: number; height: number };
  defaults: Record<string, any>;
  descriptors?: PropertyDescriptor[];
  signals?: string[];
}): NodeTypeMetadata<T> {
  return {
    type: def.type,
    name: def.type,
    category: '2D Overlay',
    createCategory: 'UI',
    is2D: true,
    is3D: false,
    isUI: true,
    description: def.description,
    icon: def.icon,
    defaultProperties: {
      posX: 20,
      posY: 20,
      width: def.size.width,
      height: def.size.height,
      alignment: 'Top-Left',
      visible: true,
      ...def.defaults,
    },
    propertyDescriptors: [
      ...UI_LAYOUT_DESCRIPTORS(def.size.width, def.size.height),
      ...UI_CHILD_DESCRIPTORS,
      ...(def.descriptors ?? []),
      UI_VISIBLE,
    ],
    availableSignals: def.signals ?? [],
  };
}

const CONTAINER_ALIGNMENT_OPTIONS = ['begin', 'center', 'end'].map((value) => ({ label: value, value }));
const SCROLL_MODE_OPTIONS = ['auto', 'always', 'never'].map((value) => ({ label: value, value }));
const UI_TEXT_COLOR: PropertyDescriptor = { key: 'textColor', label: 'Text Color', type: 'color', category: 'Typography', defaultValue: { r: 1, g: 1, b: 1, a: 1 } };
const UI_FONT_SIZE: PropertyDescriptor = { key: 'fontSize', label: 'Font Size (px)', type: 'integer', category: 'Typography', defaultValue: 13, min: 8, max: 64 };

/** Infere as chaves e exige, em compilação, que `type` de cada entrada seja igual à sua chave. */
function defineNodeTypes<K extends string>(defs: { [P in K]: NodeTypeMetadata<P> }): { [P in K]: NodeTypeMetadata<P> } {
  return defs;
}


export const NODE_DEFINITIONS = defineNodeTypes({
  // CORE
  Node: {
    type: 'Node',
    name: 'Node',
    category: 'Core',
    createCategory: 'Special',
    is2D: false,
    is3D: false,
    isUI: false,
    description: 'Base node for all scene objects. Has no spatial transform.',
    icon: 'Circle',
    defaultProperties: {
      pauseMode: 'inherit',
    },
    propertyDescriptors: [
      {
        key: 'pauseMode',
        label: 'Pause Mode',
        type: 'enum',
        category: 'General',
        defaultValue: 'inherit',
        options: [
          { label: 'Inherit', value: 'inherit' },
          { label: 'Stop', value: 'stop' },
          { label: 'Process', value: 'process' },
        ],
      },
    ],
    availableSignals: ['tree_entered', 'tree_exited', 'ready'],
  },

  Spatial: {
    type: 'Spatial',
    name: 'Spatial',
    category: 'Core',
    createCategory: '3D Nodes',
    is2D: false,
    is3D: true,
    isUI: false,
    description: '3D root node with position, rotation, and scale in Three.js world space.',
    icon: 'Box',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      visible: true,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'rotation', label: 'Rotation (deg)', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'scale', label: 'Scale', type: 'vector3', category: 'Transform', defaultValue: { x: 1, y: 1, z: 1 } },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'Rendering', defaultValue: true },
    ],
    availableSignals: ['visibility_changed'],
  },

  // 3D NODES
  MeshInstance: {
    type: 'MeshInstance',
    name: 'MeshInstance',
    category: '3D',
    createCategory: '3D Nodes',
    is2D: false,
    is3D: true,
    isUI: false,
    description: '3D Mesh geometry (Cube, Sphere, Cylinder, Plane, Torus) or an imported 3D model (res://models/) with PBR material.',
    icon: 'Box',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      visible: true,
      meshType: 'CubeMesh',
      // AIS-25: material único do nó (parcial; o que falta vem dos padrões de `MaterialProperties`)
      materialOverride: { color: { r: 0.28, g: 0.52, b: 0.92, a: 1 }, roughness: 0.4, metalness: 0.1 },
      castShadow: true,
      receiveShadow: true,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'scale', label: 'Scale', type: 'vector3', category: 'Transform', defaultValue: { x: 1, y: 1, z: 1 } },
      {
        key: 'meshType',
        label: 'Mesh Shape',
        type: 'enum',
        category: 'Mesh',
        defaultValue: 'CubeMesh',
        // com `model` o nó desenha o modelo importado; `meshType` fica guardado (fallback e Undo), sem efeito (AIS-33a)
        visibleWhen: (p) => !p.model,
        options: [
          { label: 'Cube Mesh', value: 'CubeMesh' },
          { label: 'Sphere Mesh', value: 'SphereMesh' },
          { label: 'Cylinder Mesh', value: 'CylinderMesh' },
          { label: 'Plane Mesh', value: 'PlaneMesh' },
          { label: 'Torus Mesh', value: 'TorusMesh' },
        ],
      },
      // AIS-33a (decisão 27): modelo 3D real. `model` é um `ResourceRef` para `res://models/`; só aparece quando existe.
      { key: 'model', label: 'Model', type: 'resource', category: 'Mesh', defaultValue: null, visibleWhen: (p) => !!p.model, description: 'Modelo 3D importado (res://models/). A troca de modelo é feita pela reedição da importação.' },
      { key: 'modelOffset', label: 'Model Offset', type: 'vector3', category: 'Mesh', defaultValue: { x: 0, y: 0, z: 0 }, visibleWhen: (p) => !!p.model, description: 'Compensação de pivô aplicada ao modelo dentro do nó.' },
      // O material (shader, albedo, rugosidade, metal, emissivo, textura, tiling, wireframe) é editado só pela
      // seção "Material & Textura" (MeshMaterialSection) sobre `materialOverride`: sem descriptors duplicados.
      { key: 'castShadow', label: 'Cast Shadow', type: 'boolean', category: 'Rendering', defaultValue: true },
      { key: 'receiveShadow', label: 'Receive Shadow', type: 'boolean', category: 'Rendering', defaultValue: true },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'Rendering', defaultValue: true },
    ],
    availableSignals: [],
  },

  Camera: {
    type: 'Camera',
    name: 'Camera',
    category: '3D',
    createCategory: '3D Nodes',
    is2D: false,
    is3D: true,
    isUI: false,
    description: '3D perspective or orthographic game camera. Exactly one active camera is used at game start.',
    icon: 'Video',
    defaultProperties: {
      position: { x: 0, y: 3, z: 8 },
      rotation: { x: -15, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      fov: 65,
      near: 0.1,
      far: 1000,
      active: true,
      /** @deprecated use 'active' — kept for backwards compat with existing scenes */
      current: true,
      projection: 'perspective',
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 3, z: 8 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: -15, y: 0, z: 0 } },
      {
        key: 'projection',
        label: 'Projection',
        type: 'enum',
        category: 'Camera',
        defaultValue: 'perspective',
        options: [
          { label: 'Perspective', value: 'perspective' },
          { label: 'Orthographic', value: 'orthographic' },
        ],
      },
      {
        key: 'fov',
        label: 'Field of View',
        type: 'float',
        category: 'Camera',
        defaultValue: 65,
        min: 20,
        max: 120,
        visibleWhen: (p) => (p.projection ?? 'perspective') === 'perspective',
      },
      { key: 'near', label: 'Near Clip', type: 'float', category: 'Camera', defaultValue: 0.1, min: 0.01 },
      { key: 'far', label: 'Far Clip', type: 'float', category: 'Camera', defaultValue: 1000, min: 10 },
      { key: 'active', label: 'Active Camera', type: 'boolean', category: 'Camera', defaultValue: true, description: 'The game will use exactly one active camera. Switching at runtime via Actions.' },
    ],
    availableSignals: [],
  },

  DirectionalLight: {
    type: 'DirectionalLight',
    name: 'DirectionalLight',
    category: '3D',
    createCategory: 'Lights',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Simulates parallel sunlight across the entire 3D scene. Direction only — position does not affect the light calculation.',
    icon: 'Sun',
    defaultProperties: {
      position: { x: 4, y: 8, z: 4 },
      rotation: { x: -45, y: 30, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      lightColor: { r: 1, g: 0.98, b: 0.9, a: 1 },
      energy: 1.2,
      castShadow: true,
      shadowFrustum: 15,
      shadowBias: -0.0005,
      shadowNormalBias: 0.02,
      shadowNear: 0.5,
      shadowFar: 100,
      shadowMapSize: 2048,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 4, y: 8, z: 4 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: -45, y: 30, z: 0 } },
      { key: 'lightColor', label: 'Color', type: 'color', category: 'Light', defaultValue: { r: 1, g: 0.98, b: 0.9, a: 1 } },
      { key: 'energy', label: 'Intensity', type: 'float', category: 'Light', defaultValue: 1.2, min: 0, max: 10, step: 0.1 },
      { key: 'castShadow', label: 'Cast Shadows', type: 'boolean', category: 'Shadows', defaultValue: true },
      { key: 'shadowFrustum', label: 'Shadow Frustum', type: 'float', category: 'Shadows', defaultValue: 15, min: 2, max: 100, step: 1, visibleWhen: (p) => Boolean(p.castShadow) },
      { key: 'shadowBias', label: 'Shadow Bias', type: 'float', category: 'Shadows', defaultValue: -0.0005, min: -0.01, max: 0.01, step: 0.0001, visibleWhen: (p) => Boolean(p.castShadow) },
      { key: 'shadowNormalBias', label: 'Normal Bias', type: 'float', category: 'Shadows', defaultValue: 0.02, min: 0, max: 0.1, step: 0.005, visibleWhen: (p) => Boolean(p.castShadow) },
      { key: 'shadowNear', label: 'Shadow Near', type: 'float', category: 'Shadows', defaultValue: 0.5, min: 0.1, max: 50, step: 0.5, visibleWhen: (p) => Boolean(p.castShadow) },
      { key: 'shadowFar', label: 'Shadow Far', type: 'float', category: 'Shadows', defaultValue: 100, min: 5, max: 1000, step: 5, visibleWhen: (p) => Boolean(p.castShadow) },
    ],
    availableSignals: [],
  },

  OmniLight: {
    type: 'OmniLight',
    name: 'OmniLight',
    category: '3D',
    createCategory: 'Lights',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Point light (OmniLight) emitting in all directions from a 3D origin. Maps to THREE.PointLight at runtime.',
    icon: 'Zap',
    defaultProperties: {
      position: { x: 0, y: 2, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      lightColor: { r: 1, g: 0.8, b: 0.4, a: 1 },
      energy: 2.0,
      range: 12,
      decay: 2.0,
      castShadow: false,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 2, z: 0 } },
      { key: 'lightColor', label: 'Color', type: 'color', category: 'Light', defaultValue: { r: 1, g: 0.8, b: 0.4, a: 1 } },
      { key: 'energy', label: 'Intensity', type: 'float', category: 'Light', defaultValue: 2.0, min: 0, max: 10 },
      { key: 'range', label: 'Distance', type: 'float', category: 'Light', defaultValue: 12, min: 0.1, max: 200, description: 'Maximum range. 0 = infinite.' },
      { key: 'decay', label: 'Decay', type: 'float', category: 'Light', defaultValue: 2.0, min: 0, max: 4, step: 0.1 },
      { key: 'castShadow', label: 'Cast Shadows', type: 'boolean', category: 'Shadows', defaultValue: false },
    ],
    availableSignals: [],
  },

  SpotLight: {
    type: 'SpotLight',
    name: 'SpotLight',
    category: '3D',
    createCategory: 'Lights',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Conical spotlight with angle and penumbra controls. Deliberate product addition — three.js supports natively.',
    icon: 'Flashlight',
    defaultProperties: {
      position: { x: 0, y: 4, z: 0 },
      rotation: { x: -90, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      lightColor: { r: 1, g: 1, b: 1, a: 1 },
      energy: 3.0,
      distance: 20,
      decay: 2.0,
      angle: 45,
      penumbra: 0.1,
      castShadow: false,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 4, z: 0 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: -90, y: 0, z: 0 } },
      { key: 'lightColor', label: 'Color', type: 'color', category: 'Light', defaultValue: { r: 1, g: 1, b: 1, a: 1 } },
      { key: 'energy', label: 'Intensity', type: 'float', category: 'Light', defaultValue: 3.0, min: 0, max: 10, step: 0.1 },
      { key: 'distance', label: 'Distance', type: 'float', category: 'Light', defaultValue: 20, min: 0.1, max: 200, description: 'Maximum cone reach. 0 = infinite.' },
      { key: 'decay', label: 'Decay', type: 'float', category: 'Light', defaultValue: 2.0, min: 0, max: 4, step: 0.1 },
      { key: 'angle', label: 'Cone Angle (deg)', type: 'float', category: 'Light', defaultValue: 45, min: 1, max: 90 },
      { key: 'penumbra', label: 'Penumbra', type: 'float', category: 'Light', defaultValue: 0.1, min: 0, max: 1, step: 0.05, description: 'Softness of the cone edge (0 = hard, 1 = fully soft).' },
      { key: 'castShadow', label: 'Cast Shadows', type: 'boolean', category: 'Shadows', defaultValue: false },
    ],
    availableSignals: [],
  },

  AnimationPlayer: {
    type: 'AnimationPlayer',
    name: 'AnimationPlayer',
    category: '3D',
    createCategory: 'Animation & Audio',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Controls 3D animations, skeletal playback, Mixamo 19-bone retargeting, and track blending.',
    icon: 'Film',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      currentAnimation: '',
      playbackSpeed: 1.0,
      autoplay: false,
      loop: true,
      rigConfig: null, // AIS-36: ResourceRef do `res://materials/<asset>_rig.json` (a string legada continua sendo lida)
      crossfadeDuration: 0.2,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'currentAnimation', label: 'Current Animation', type: 'string', category: 'Animation', defaultValue: '' },
      { key: 'playbackSpeed', label: 'Speed', type: 'float', category: 'Playback', defaultValue: 1.0, min: -5.0, max: 5.0, step: 0.1 },
      { key: 'autoplay', label: 'Autoplay', type: 'boolean', category: 'Playback', defaultValue: false },
      { key: 'loop', label: 'Loop', type: 'boolean', category: 'Playback', defaultValue: true },
      { key: 'rigConfig', label: 'Rig Configuration', type: 'resource', category: 'Skeletal', defaultValue: null, description: 'Rig de 19 ossos (res://materials/<asset>_rig.json) gerado na importação do modelo.' },
      { key: 'crossfadeDuration', label: 'Crossfade (s)', type: 'float', category: 'Playback', defaultValue: 0.2, min: 0, max: 2, step: 0.05 },
    ],
    availableSignals: ['animation_started', 'animation_finished', 'animation_changed'],
  },

  Environment: {
    type: 'Environment',
    name: 'Environment',
    category: '3D',
    createCategory: 'Special',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Defines 3D world environment settings (ambient lighting, background clear color, realtime shadows, atmospheric fog). A scene permits exactly 0..1 Environment node.',
    icon: 'Sun',
    defaultProperties: {
      ambientColor: { r: 0.5, g: 0.6, b: 0.75, a: 1 },
      ambientIntensity: 0.45,
      backgroundMode: 'Color',
      backgroundColor: { r: 0.08, g: 0.1, b: 0.14, a: 1 },
      realtimeShadows: true,
      fogEnabled: false,
      fogMode: 'exponential2',
      fogColor: { r: 0.56, g: 0.64, b: 0.72, a: 1 },
      fogDensity: 0.008,
      fogNear: 15,
      fogFar: 180,
      tonemapping: 'ACESFilmic',
      tonemappingExposure: 1.0,
      ssao: 'Disabled',
      ssr: 'Disabled',
    },
    propertyDescriptors: [
      { key: 'ambientColor', label: 'Ambient Color', type: 'color', category: 'Ambient Light', defaultValue: { r: 0.5, g: 0.6, b: 0.75, a: 1 } },
      { key: 'ambientIntensity', label: 'Ambient Intensity', type: 'float', category: 'Ambient Light', defaultValue: 0.45, min: 0, max: 3, step: 0.05 },
      {
        key: 'backgroundMode',
        label: 'Background Mode',
        type: 'enum',
        category: 'Background',
        defaultValue: 'Color',
        options: [
          { label: 'Solid Color', value: 'Color' },
          // AIS-06: Cubemap/HDRI só ficam funcionais no prompt nodimus-skybox-cubemap (decisão 14).
          { label: 'Skybox Cubemap (em breve)', value: 'Skybox_Pending', disabled: true },
        ],
      },
      {
        key: 'backgroundColor',
        label: 'Clear Color',
        type: 'color',
        category: 'Background',
        defaultValue: { r: 0.08, g: 0.1, b: 0.14, a: 1 },
        visibleWhen: (p) => (p.backgroundMode ?? 'Color') === 'Color',
      },
      { key: 'realtimeShadows', label: 'Realtime Shadows', type: 'boolean', category: 'Shadows', defaultValue: true },
      { key: 'fogEnabled', label: 'Enable Fog', type: 'boolean', category: 'Atmosphere / Fog', defaultValue: false },
      {
        key: 'fogMode',
        label: 'Fog Mode',
        type: 'enum',
        category: 'Atmosphere / Fog',
        defaultValue: 'exponential2',
        options: [
          { label: 'Exponential Squared (Exp2)', value: 'exponential2' },
          { label: 'Linear', value: 'linear' },
        ],
        visibleWhen: (p) => Boolean(p.fogEnabled),
      },
      {
        key: 'fogColor',
        label: 'Fog Color',
        type: 'color',
        category: 'Atmosphere / Fog',
        defaultValue: { r: 0.56, g: 0.64, b: 0.72, a: 1 },
        visibleWhen: (p) => Boolean(p.fogEnabled),
      },
      {
        key: 'fogDensity',
        label: 'Density',
        type: 'float',
        category: 'Atmosphere / Fog',
        defaultValue: 0.008,
        min: 0.0001,
        max: 0.1,
        step: 0.001,
        visibleWhen: (p) => Boolean(p.fogEnabled) && (p.fogMode ?? 'exponential2') === 'exponential2',
      },
      {
        key: 'fogNear',
        label: 'Near Distance',
        type: 'float',
        category: 'Atmosphere / Fog',
        defaultValue: 15,
        min: 0.1,
        max: 500,
        visibleWhen: (p) => Boolean(p.fogEnabled) && p.fogMode === 'linear',
      },
      {
        key: 'fogFar',
        label: 'Far Distance',
        type: 'float',
        category: 'Atmosphere / Fog',
        defaultValue: 180,
        min: 1,
        max: 2000,
        visibleWhen: (p) => Boolean(p.fogEnabled) && p.fogMode === 'linear',
      },
      {
        key: 'tonemapping',
        label: 'Tone Mapping',
        type: 'enum',
        category: 'Rendering Pipeline',
        defaultValue: 'ACESFilmic',
        options: [
          { label: 'ACES Filmic', value: 'ACESFilmic' },
          { label: 'None', value: 'None' },
        ],
        description: 'High dynamic range tone mapping curve applied to WebGL output.',
      },
      {
        key: 'tonemappingExposure',
        label: 'Exposure',
        type: 'float',
        category: 'Rendering Pipeline',
        defaultValue: 1.0,
        min: 0.1,
        max: 3.0,
        step: 0.05,
        description: 'Exposure level for ACESFilmic tone mapping.',
      },
      {
        key: 'ssao',
        label: 'SSAO',
        type: 'enum',
        category: 'Post Pipeline (Pending)',
        defaultValue: 'Disabled',
        options: [
          { label: 'Disabled (Pending Stage B)', value: 'Disabled' },
        ],
        description: 'Screen Space Ambient Occlusion is pending Stage B pass integration.',
      },
      {
        key: 'ssr',
        label: 'SSR',
        type: 'enum',
        category: 'Post Pipeline (Pending)',
        defaultValue: 'Disabled',
        options: [
          { label: 'Disabled (Pending Stage B)', value: 'Disabled' },
        ],
        description: 'Screen Space Reflections are pending Stage B pass integration.',
      },
    ],
    availableSignals: ['environment_changed'],
  },

  // 2D OVERLAY NODES:
  // 1. Overlay2D (2D Screen Image / HUD Rect)
  // 2. TextOverlay2D (2D Screen Text / Label HUD)
  // 3. ButtonOverlay2D (2D Screen Button / Clickable HUD)
  // 4. Billboard (3D Sprite facing active camera)
  Overlay2D: {
    type: 'Overlay2D',
    name: 'Overlay2D',
    category: '2D Overlay',
    createCategory: 'UI',
    is2D: true,
    is3D: false,
    isUI: true,
    description: '2D Screen Overlay. Draws a 2D image, HUD panel, healthbar or texture over the 3D viewport.',
    icon: 'Image',
    defaultProperties: {
      posX: 20,
      posY: 20,
      width: 140,
      height: 48,
      alignment: 'Top-Left',
      color: { r: 0.15, g: 0.2, b: 0.28, a: 0.85 },
      borderColor: { r: 0.29, g: 0.51, b: 0.92, a: 1 },
      borderWidth: 2,
      texture: '',
      alpha: 0.9,
      visible: true,
      onClickAction: 'none',
    },
    propertyDescriptors: [
      { key: 'posX', label: 'Position X (px)', type: 'integer', category: '2D Coordinates', defaultValue: 20, dynamicLabel: layoutLabel('posX') },
      { key: 'posY', label: 'Position Y (px)', type: 'integer', category: '2D Coordinates', defaultValue: 20, dynamicLabel: layoutLabel('posY') },
      { key: 'width', label: 'Width (px)', type: 'integer', category: '2D Coordinates', defaultValue: 140, dynamicLabel: layoutLabel('width') },
      { key: 'height', label: 'Height (px)', type: 'integer', category: '2D Coordinates', defaultValue: 48, dynamicLabel: layoutLabel('height') },
      {
        key: 'alignment',
        label: 'Layout Preset',
        type: 'enum',
        category: '2D Coordinates',
        defaultValue: 'Top-Left',
        options: LAYOUT_PRESET_OPTIONS,
      },
      { key: 'color', label: 'Background Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.15, g: 0.2, b: 0.28, a: 0.85 } },
      { key: 'borderColor', label: 'Border Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.29, g: 0.51, b: 0.92, a: 1 } },
      { key: 'borderWidth', label: 'Border Width', type: 'integer', category: 'Appearance', defaultValue: 2, min: 0, max: 10 },
      { key: 'texture', label: 'Texture Path', type: 'string', category: 'Appearance', defaultValue: '' },
      { key: 'alpha', label: 'Opacity', type: 'float', category: 'Appearance', defaultValue: 0.9, min: 0, max: 1, step: 0.05 },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'Appearance', defaultValue: true },
      ...UI_CHILD_DESCRIPTORS,
    ],
    availableSignals: ['on_click', 'on_hover'],
  },

  TextOverlay2D: {
    type: 'TextOverlay2D',
    name: 'TextOverlay2D',
    category: '2D Overlay',
    createCategory: 'UI',
    is2D: true,
    is3D: false,
    isUI: true,
    description: '2D Screen Text Overlay. Displays HUD scores, dialogue subtitles, messages and health counter text.',
    icon: 'Type',
    defaultProperties: {
      text: 'HP: 100 / 100',
      posX: 28,
      posY: 28,
      fontSize: 15,
      textColor: { r: 1, g: 1, b: 1, a: 1 },
      alignment: 'Top-Left',
      fontFamily: 'sans-serif',
      shadow: true,
      visible: true,
    },
    propertyDescriptors: [
      { key: 'text', label: 'Text Message', type: 'string', category: 'Content', defaultValue: 'HP: 100 / 100' },
      { key: 'posX', label: 'Position X', type: 'integer', category: '2D Coordinates', defaultValue: 28, dynamicLabel: layoutLabel('posX') },
      { key: 'posY', label: 'Position Y', type: 'integer', category: '2D Coordinates', defaultValue: 28, dynamicLabel: layoutLabel('posY') },
      { key: 'width', label: 'Width (px)', type: 'integer', category: '2D Coordinates', defaultValue: 140, dynamicLabel: layoutLabel('width') },
      { key: 'height', label: 'Height (px)', type: 'integer', category: '2D Coordinates', defaultValue: 24, dynamicLabel: layoutLabel('height') },
      {
        key: 'alignment',
        label: 'Layout Preset',
        type: 'enum',
        category: '2D Coordinates',
        defaultValue: 'Top-Left',
        options: LAYOUT_PRESET_OPTIONS,
      },
      { key: 'fontSize', label: 'Font Size (px)', type: 'integer', category: 'Typography', defaultValue: 15, min: 8, max: 64 },
      { key: 'textColor', label: 'Font Color', type: 'color', category: 'Typography', defaultValue: { r: 1, g: 1, b: 1, a: 1 } },
      { key: 'shadow', label: 'Text Shadow', type: 'boolean', category: 'Typography', defaultValue: true },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'General', defaultValue: true },
      ...UI_CHILD_DESCRIPTORS,
    ],
    availableSignals: ['on_click'],
  },

  ButtonOverlay2D: {
    type: 'ButtonOverlay2D',
    name: 'ButtonOverlay2D',
    category: '2D Overlay',
    createCategory: 'UI',
    is2D: true,
    is3D: false,
    isUI: true,
    description: '2D Screen Button Overlay. Interactive clickable UI button that triggers actions on click or hover.',
    icon: 'MousePointerClick',
    defaultProperties: {
      text: 'Inventory',
      posX: 20,
      posY: 80,
      width: 140,
      height: 38,
      alignment: 'Top-Left',
      buttonColor: { r: 0.16, g: 0.42, b: 0.85, a: 1 },
      hoverColor: { r: 0.22, g: 0.52, b: 0.95, a: 1 },
      textColor: { r: 1, g: 1, b: 1, a: 1 },
      fontSize: 13,
      visible: true,
    },
    propertyDescriptors: [
      { key: 'text', label: 'Button Label', type: 'string', category: 'Content', defaultValue: 'Inventory' },
      { key: 'posX', label: 'Position X', type: 'integer', category: '2D Coordinates', defaultValue: 20, dynamicLabel: layoutLabel('posX') },
      { key: 'posY', label: 'Position Y', type: 'integer', category: '2D Coordinates', defaultValue: 80, dynamicLabel: layoutLabel('posY') },
      { key: 'width', label: 'Width (px)', type: 'integer', category: '2D Coordinates', defaultValue: 140, dynamicLabel: layoutLabel('width') },
      { key: 'height', label: 'Height (px)', type: 'integer', category: '2D Coordinates', defaultValue: 38, dynamicLabel: layoutLabel('height') },
      {
        key: 'alignment',
        label: 'Layout Preset',
        type: 'enum',
        category: '2D Coordinates',
        defaultValue: 'Top-Left',
        options: LAYOUT_PRESET_OPTIONS,
      },
      { key: 'buttonColor', label: 'Normal Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.16, g: 0.42, b: 0.85, a: 1 } },
      { key: 'hoverColor', label: 'Hover Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.22, g: 0.52, b: 0.95, a: 1 } },
      { key: 'textColor', label: 'Text Color', type: 'color', category: 'Typography', defaultValue: { r: 1, g: 1, b: 1, a: 1 } },
      { key: 'fontSize', label: 'Font Size', type: 'integer', category: 'Typography', defaultValue: 13 },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'General', defaultValue: true },
      ...UI_CHILD_DESCRIPTORS,
    ],
    availableSignals: ['on_click', 'on_hover'],
  },

  // ── AIS-25c: Containers (organizam os filhos; Yoga/Flexbox do UIKit) ────────────────────────────
  Panel: defineUiNode({
    type: 'Panel',
    description: 'UI Panel: fundo/borda e área de conteúdo. Posiciona como um Control.',
    icon: 'PanelTop',
    size: { width: 200, height: 120 },
    defaults: { color: { r: 0.1, g: 0.13, b: 0.19, a: 0.9 }, borderColor: { r: 0.29, g: 0.51, b: 0.92, a: 1 }, borderWidth: 1, cornerRadius: 6 },
    descriptors: UI_BOX_APPEARANCE,
  }),

  Container: defineUiNode({
    type: 'Container',
    description: 'UI Container base: empilha os filhos em coluna, sem fundo.',
    icon: 'LayoutPanelTop',
    size: { width: 200, height: 120 },
    defaults: {},
  }),

  HBox: defineUiNode({
    type: 'HBox',
    description: 'UI HBox: organiza os filhos em linha (esquerda → direita).',
    icon: 'Columns3',
    size: { width: 240, height: 48 },
    defaults: { separation: 8, contentAlignment: 'begin' },
    descriptors: [
      { key: 'separation', label: 'Separation (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0, max: 256 },
      { key: 'contentAlignment', label: 'Content Alignment', type: 'enum', category: 'Container', defaultValue: 'begin', options: CONTAINER_ALIGNMENT_OPTIONS },
    ],
  }),

  VBox: defineUiNode({
    type: 'VBox',
    description: 'UI VBox: organiza os filhos em coluna (cima → baixo).',
    icon: 'Rows3',
    size: { width: 160, height: 160 },
    defaults: { separation: 8, contentAlignment: 'begin' },
    descriptors: [
      { key: 'separation', label: 'Separation (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0, max: 256 },
      { key: 'contentAlignment', label: 'Content Alignment', type: 'enum', category: 'Container', defaultValue: 'begin', options: CONTAINER_ALIGNMENT_OPTIONS },
    ],
  }),

  Grid: defineUiNode({
    type: 'Grid',
    description: 'UI Grid: organiza os filhos em grade de N colunas (colunas de largura igual).',
    icon: 'Grid3x3',
    size: { width: 240, height: 160 },
    defaults: { columns: 2, hSeparation: 8, vSeparation: 8 },
    descriptors: [
      { key: 'columns', label: 'Columns', type: 'integer', category: 'Container', defaultValue: 2, min: 1, max: 32 },
      { key: 'hSeparation', label: 'H Separation (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0, max: 256 },
      { key: 'vSeparation', label: 'V Separation (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0, max: 256 },
    ],
  }),

  MarginContainer: defineUiNode({
    type: 'MarginContainer',
    description: 'UI MarginContainer: afasta os filhos das bordas por margens em px.',
    icon: 'Frame',
    size: { width: 200, height: 120 },
    defaults: { marginLeft: 8, marginTop: 8, marginRight: 8, marginBottom: 8 },
    descriptors: [
      { key: 'marginLeft', label: 'Margin Left (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0 },
      { key: 'marginTop', label: 'Margin Top (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0 },
      { key: 'marginRight', label: 'Margin Right (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0 },
      { key: 'marginBottom', label: 'Margin Bottom (px)', type: 'integer', category: 'Container', defaultValue: 8, min: 0 },
    ],
  }),

  CenterContainer: defineUiNode({
    type: 'CenterContainer',
    description: 'UI CenterContainer: centraliza o conteúdo nos dois eixos.',
    icon: 'Focus',
    size: { width: 200, height: 120 },
    defaults: {},
  }),

  ScrollContainer: defineUiNode({
    type: 'ScrollContainer',
    description: 'UI ScrollContainer: o conteúdo maior que a caixa rola.',
    icon: 'ScrollText',
    size: { width: 200, height: 120 },
    defaults: { scrollH: 'auto', scrollV: 'auto' },
    descriptors: [
      { key: 'scrollH', label: 'Scroll H', type: 'enum', category: 'Container', defaultValue: 'auto', options: SCROLL_MODE_OPTIONS },
      { key: 'scrollV', label: 'Scroll V', type: 'enum', category: 'Container', defaultValue: 'auto', options: SCROLL_MODE_OPTIONS },
    ],
  }),

  // ── AIS-25c: controles de uso geral (Image/Label/Button = Overlay2D/TextOverlay2D/ButtonOverlay2D) ──
  CheckBox: defineUiNode({
    type: 'CheckBox',
    description: 'UI CheckBox: caixa de marcação com rótulo.',
    icon: 'SquareCheck',
    size: { width: 140, height: 24 },
    defaults: { text: 'CheckBox', checked: false, fontSize: 13, textColor: { r: 1, g: 1, b: 1, a: 1 } },
    descriptors: [
      { key: 'text', label: 'Text', type: 'string', category: 'Content', defaultValue: 'CheckBox' },
      { key: 'checked', label: 'Checked', type: 'boolean', category: 'Content', defaultValue: false },
      UI_FONT_SIZE,
      UI_TEXT_COLOR,
    ],
    signals: ['toggled'],
  }),

  Slider: defineUiNode({
    type: 'Slider',
    description: 'UI Slider: valor numérico entre mínimo e máximo.',
    icon: 'SlidersHorizontal',
    size: { width: 160, height: 20 },
    defaults: { min: 0, max: 100, step: 1, value: 50 },
    descriptors: [
      { key: 'min', label: 'Min', type: 'float', category: 'Value', defaultValue: 0 },
      { key: 'max', label: 'Max', type: 'float', category: 'Value', defaultValue: 100 },
      { key: 'step', label: 'Step', type: 'float', category: 'Value', defaultValue: 1, min: 0 },
      { key: 'value', label: 'Value', type: 'float', category: 'Value', defaultValue: 50 },
    ],
    signals: ['value_changed'],
  }),

  ProgressBar: defineUiNode({
    type: 'ProgressBar',
    description: 'UI ProgressBar: barra de progresso (vida, carregamento).',
    icon: 'Loader',
    size: { width: 160, height: 20 },
    defaults: { min: 0, max: 100, value: 50, showPercent: true },
    descriptors: [
      { key: 'min', label: 'Min', type: 'float', category: 'Value', defaultValue: 0 },
      { key: 'max', label: 'Max', type: 'float', category: 'Value', defaultValue: 100 },
      { key: 'value', label: 'Value', type: 'float', category: 'Value', defaultValue: 50 },
      { key: 'showPercent', label: 'Show Percent', type: 'boolean', category: 'Value', defaultValue: true },
    ],
    signals: ['value_changed'],
  }),

  TextInput: defineUiNode({
    type: 'TextInput',
    description: 'UI TextInput: campo de texto de uma linha.',
    icon: 'TextCursorInput',
    size: { width: 160, height: 30 },
    defaults: { text: '', placeholder: 'Text...', maxLength: 0, fontSize: 13, textColor: { r: 1, g: 1, b: 1, a: 1 } },
    descriptors: [
      { key: 'text', label: 'Text', type: 'string', category: 'Content', defaultValue: '' },
      { key: 'placeholder', label: 'Placeholder', type: 'string', category: 'Content', defaultValue: 'Text...' },
      { key: 'maxLength', label: 'Max Length (0 = ilimitado)', type: 'integer', category: 'Content', defaultValue: 0, min: 0 },
      UI_FONT_SIZE,
      UI_TEXT_COLOR,
    ],
    signals: ['text_changed', 'text_submitted'],
  }),

  Billboard: {
    type: 'Billboard',
    name: 'Billboard',
    category: '3D', // AIS-25b: ancorado no mundo 3D; fora da unificação de overlays de tela
    createCategory: 'Special',
    is2D: true,
    is3D: true,
    isUI: false,
    description: '3D Billboard Sprite. A 2D plane in 3D space that automatically faces the active camera (trees, projectiles, particles, items).',
    icon: 'Radio',
    defaultProperties: {
      position: { x: 0, y: 1.5, z: 0 },
      width: 1.5,
      height: 2.0,
      color: { r: 0.2, g: 0.85, b: 0.4, a: 1 },
      texture: '',
      alwaysFaceCamera: true,
      visible: true,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation (3D)', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 1.5, z: 0 } },
      { key: 'width', label: 'Width (m)', type: 'float', category: 'Dimensions', defaultValue: 1.5, min: 0.1, max: 20 },
      { key: 'height', label: 'Height (m)', type: 'float', category: 'Dimensions', defaultValue: 2.0, min: 0.1, max: 20 },
      { key: 'color', label: 'Tint Color', type: 'color', category: 'Appearance', defaultValue: { r: 0.2, g: 0.85, b: 0.4, a: 1 } },
      { key: 'texture', label: 'Texture Path', type: 'string', category: 'Appearance', defaultValue: '' },
      { key: 'alwaysFaceCamera', label: 'Face Active Camera', type: 'boolean', category: 'Billboard', defaultValue: true },
      { key: 'visible', label: 'Visible', type: 'boolean', category: 'General', defaultValue: true },
    ],
    availableSignals: [],
  },

  // AUDIO & MISC
  AudioPlayer: {
    type: 'AudioPlayer',
    name: 'AudioPlayer',
    category: 'Audio',
    createCategory: 'Animation & Audio',
    is2D: false,
    is3D: false,
    isUI: false,
    description: 'Plays global non-positional background music or ambient tracks.',
    icon: 'Volume2',
    defaultProperties: {
      stream: 'res://audio/bgm.ogg',
      volumeDb: 0,
      pitchScale: 1.0,
      autoplay: false,
      loop: true,
    },
    propertyDescriptors: [
      { key: 'stream', label: 'Audio Stream', type: 'file', category: 'Stream', defaultValue: 'res://audio/bgm.ogg' },
      { key: 'volumeDb', label: 'Volume (dB)', type: 'float', category: 'Audio', defaultValue: 0, min: -40, max: 6 },
      { key: 'pitchScale', label: 'Pitch Scale', type: 'float', category: 'Audio', defaultValue: 1.0, min: 0.1, max: 4.0 },
      { key: 'autoplay', label: 'Autoplay', type: 'boolean', category: 'Playback', defaultValue: false },
      { key: 'loop', label: 'Loop', type: 'boolean', category: 'Playback', defaultValue: true },
    ],
    availableSignals: ['finished'],
  },

  AudioPlayer3D: {
    type: 'AudioPlayer3D',
    name: 'AudioPlayer3D',
    category: 'Audio',
    createCategory: 'Animation & Audio',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Plays spatial 3D audio with positional distance attenuation.',
    icon: 'Headphones',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      stream: 'res://audio/sfx_spatial.wav',
      unitSize: 10.0,
      maxDistance: 40.0,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'stream', label: 'Audio Stream', type: 'file', category: 'Stream', defaultValue: 'res://audio/sfx_spatial.wav' },
      { key: 'unitSize', label: 'Unit Size', type: 'float', category: '3D Attenuation', defaultValue: 10.0 },
      { key: 'maxDistance', label: 'Max Distance', type: 'float', category: '3D Attenuation', defaultValue: 40.0 },
    ],
    availableSignals: ['finished'],
  },

  ParticleSystem: {
    type: 'ParticleSystem',
    name: 'ParticleSystem',
    category: '3D',
    createCategory: 'Special',
    is2D: false,
    is3D: true,
    isUI: false,
    description: 'Generates 3D animated particle effects like fire, smoke, rain, snow, sparks, and magic.',
    icon: 'Sparkles',
    defaultProperties: {
      position: { x: 0, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: 1, y: 1, z: 1 },
      ...PARTICLE_DEFAULTS,
    },
    propertyDescriptors: [
      { key: 'position', label: 'Translation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'rotation', label: 'Rotation', type: 'vector3', category: 'Transform', defaultValue: { x: 0, y: 0, z: 0 } },
      { key: 'scale', label: 'Scale', type: 'vector3', category: 'Transform', defaultValue: { x: 1, y: 1, z: 1 } },
      { key: 'emitting', label: 'Emitting', type: 'boolean', category: 'Emission', defaultValue: PARTICLE_DEFAULTS.emitting },
      { key: 'emitterType', label: 'Emitter Shape', type: 'enum', category: 'Emitter', defaultValue: PARTICLE_DEFAULTS.emitterType, options: [
        { label: 'Point Emitter', value: 'point' },
        { label: 'Box / Area Emitter', value: 'box' },
        { label: 'Ring / Cylinder Emitter', value: 'ring' },
        { label: 'Sphere Emitter', value: 'sphere' },
      ]},
      { key: 'emitterRadius', label: 'Emitter Radius (m)', type: 'float', category: 'Emitter', defaultValue: PARTICLE_DEFAULTS.emitterRadius, ...PARTICLE_LIMITS.emitterRadius, step: 0.1 },
      { key: 'emitterBoxSize', label: 'Emitter Box Size (m)', type: 'vector3', category: 'Emitter', defaultValue: PARTICLE_DEFAULTS.emitterBoxSize, ...PARTICLE_LIMITS.emitterBoxSize },
      { key: 'particlesPerSecond', label: 'Emission Rate (pts/s)', type: 'integer', category: 'Emission', defaultValue: PARTICLE_DEFAULTS.particlesPerSecond, ...PARTICLE_LIMITS.particlesPerSecond },
      { key: 'maxParticles', label: 'Max Particles', type: 'integer', category: 'Emission', defaultValue: PARTICLE_DEFAULTS.maxParticles, ...PARTICLE_LIMITS.maxParticles },
      { key: 'lifetimeMin', label: 'Min Lifetime (s)', type: 'float', category: 'Lifetime', defaultValue: PARTICLE_DEFAULTS.lifetimeMin, ...PARTICLE_LIMITS.lifetimeMin },
      { key: 'lifetimeMax', label: 'Max Lifetime (s)', type: 'float', category: 'Lifetime', defaultValue: PARTICLE_DEFAULTS.lifetimeMax, ...PARTICLE_LIMITS.lifetimeMax },
      { key: 'direction', label: 'Direction Vector', type: 'vector3', category: 'Physics', defaultValue: PARTICLE_DEFAULTS.direction },
      { key: 'maxAngleDeviation', label: 'Cone Angle Spread (°)', type: 'float', category: 'Physics', defaultValue: PARTICLE_DEFAULTS.maxAngleDeviation, ...PARTICLE_LIMITS.maxAngleDeviation },
      { key: 'speedMin', label: 'Min Speed', type: 'float', category: 'Physics', defaultValue: PARTICLE_DEFAULTS.speedMin, ...PARTICLE_LIMITS.speedMin },
      { key: 'speedMax', label: 'Max Speed', type: 'float', category: 'Physics', defaultValue: PARTICLE_DEFAULTS.speedMax, ...PARTICLE_LIMITS.speedMax },
      { key: 'gravity', label: 'Gravity Vector', type: 'vector3', category: 'Physics', defaultValue: PARTICLE_DEFAULTS.gravity, ...PARTICLE_LIMITS.gravity },
      { key: 'startColor', label: 'Start Color', type: 'color', category: 'Appearance', defaultValue: PARTICLE_DEFAULTS.startColor },
      { key: 'endColor', label: 'End / Fade Color', type: 'color', category: 'Appearance', defaultValue: PARTICLE_DEFAULTS.endColor },
      { key: 'startSize', label: 'Start Size (m)', type: 'float', category: 'Appearance', defaultValue: PARTICLE_DEFAULTS.startSize, ...PARTICLE_LIMITS.startSize },
      { key: 'endSize', label: 'End Size (m)', type: 'float', category: 'Appearance', defaultValue: PARTICLE_DEFAULTS.endSize, ...PARTICLE_LIMITS.endSize },
      { key: 'fadeOut', label: 'Fade Out Over Life', type: 'boolean', category: 'Appearance', defaultValue: PARTICLE_DEFAULTS.fadeOut },
      { key: 'blending', label: 'Blend Mode', type: 'enum', category: 'Rendering', defaultValue: PARTICLE_DEFAULTS.blending, options: [
        { label: 'Additive (Glow/Fire/Sparks)', value: 'additive' },
        { label: 'Alpha Blend (Translucent/Smoke)', value: 'alpha' },
        { label: 'Multiply / Modulate', value: 'modulate' },
      ]},
      { key: 'texture', label: 'Texture', type: 'enum', category: 'Rendering', defaultValue: PARTICLE_DEFAULTS.texture, options: [
        { label: 'Glow', value: 'glow' },
        { label: 'Flame', value: 'flame' },
        { label: 'Smoke', value: 'smoke' },
        { label: 'Spark', value: 'spark' },
        { label: 'Drop', value: 'drop' },
        { label: 'Snow', value: 'snow' },
        { label: 'Star', value: 'star' },
      ]},
      { key: 'presetId', label: 'Preset', type: 'string', category: 'Origin', defaultValue: PARTICLE_DEFAULTS.presetId, description: 'Preset de origem (marca informativa; os valores vivem no nó).', visibleWhen: () => false /* o Inspector escolhe o preset pelo dropdown (AIS-23) */ },
      { key: 'seed', label: 'Seed', type: 'integer', category: 'Origin', defaultValue: PARTICLE_DEFAULTS.seed, ...PARTICLE_LIMITS.seed },
    ],
    availableSignals: ['started', 'finished'],
  },

  Timer: {
    type: 'Timer',
    name: 'Timer',
    category: 'Misc',
    createCategory: 'Special',
    is2D: false,
    is3D: false,
    isUI: false,
    description: 'Counts down a specified interval and fires timeout event.',
    icon: 'Timer',
    defaultProperties: {
      waitTime: 1.0,
      oneShot: false,
      autostart: true,
    },
    propertyDescriptors: [
      { key: 'waitTime', label: 'Wait Time (sec)', type: 'float', category: 'Timer', defaultValue: 1.0, min: 0.01 },
      { key: 'oneShot', label: 'One Shot', type: 'boolean', category: 'Timer', defaultValue: false },
      { key: 'autostart', label: 'Autostart', type: 'boolean', category: 'Timer', defaultValue: true },
    ],
    availableSignals: ['timeout'],
  },

  // Nó de tipo ausente nesta versão do editor (AIS-18d): preservado e regravado intacto.
  Missing: {
    type: 'Missing',
    name: 'Missing Node',
    category: 'Misc',
    createCategory: 'Special',
    creatable: false,
    is2D: false,
    is3D: false,
    isUI: false,
    description: 'Tipo ausente nesta versão do editor; dados preservados.',
    icon: 'AlertTriangle',
    defaultProperties: {},
    propertyDescriptors: [], // o Inspector mostra o tipo original (somente leitura)
    availableSignals: [],
  },
});

/**
 * Registro único dos tipos de nó. `NodeType` é derivado das chaves; o schema Zod e o diálogo de
 * criação leem daqui. Tipo novo = uma entrada nova neste objeto (decisão 19).
 */
export const NODE_REGISTRY: Record<NodeType, NodeTypeMetadata> = NODE_DEFINITIONS;

export function getNodeMetadata(type: NodeType): NodeTypeMetadata {
  return (
    NODE_REGISTRY[type] || {
      type,
      name: type,
      category: 'Core',
      is2D: false,
      is3D: true,
      isUI: false,
      description: 'Node of type ' + type,
      icon: 'Circle',
      defaultProperties: {},
      propertyDescriptors: [],
      availableSignals: [],
    }
  );
}

/**
 * `initialProperties` é mesclado sobre os defaults do tipo (cópia profunda) antes de o nó existir:
 * quem grava o nó (Command de criação) já o recebe completo, sem mutação posterior (AIS-18c).
 */
export function createDefaultNode(
  type: NodeType,
  customName?: string,
  parentId: string | null = null,
  initialProperties?: Record<string, any>
): GameNode {
  const meta = getNodeMetadata(type);
  const id = `${type.toLowerCase()}_${Math.random().toString(36).substring(2, 9)}`;
  const name = customName || `${type}`;

  return {
    id,
    name,
    type,
    parentId,
    childrenIds: [],
    visible: true,
    locked: false,
    properties: {
      ...JSON.parse(JSON.stringify(meta.defaultProperties)),
      ...(initialProperties ? JSON.parse(JSON.stringify(initialProperties)) : {}),
    },
    signals: [],
    behaviors: [],
  };
}
