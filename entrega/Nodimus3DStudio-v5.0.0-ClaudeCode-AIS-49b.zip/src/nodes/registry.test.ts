import { describe, expect, it } from 'vitest';
import { NODE_REGISTRY, NODE_DEFINITIONS } from './registry';
import { NodeTypeV1Schema } from '../schemas/v1/node.schema';
import { NodeIcon } from '../components/common/NodeIcon';
import type { NodeType } from '../types/node';

describe('NODE_REGISTRY — fonte única de tipos de nó (decisão 19)', () => {
  it('a chave de cada entrada é igual ao seu `type`', () => {
    for (const [key, meta] of Object.entries(NODE_DEFINITIONS)) expect(meta.type).toBe(key);
  });

  it('o schema Zod aceita exatamente os tipos do registry', () => {
    const keys = Object.keys(NODE_REGISTRY).sort();
    expect([...NodeTypeV1Schema.options].sort()).toEqual(keys);
    expect(NodeTypeV1Schema.safeParse('TipoInexistente').success).toBe(false);
  });

  it('toda entrada tem aba no diálogo de criação', () => {
    const tabs = ['3D Nodes', 'Lights', 'Animation & Audio', 'UI', 'Special'];
    for (const meta of Object.values(NODE_REGISTRY)) expect(tabs).toContain(meta.createCategory);
  });

  it('todo nó de UI (isUI) fica na aba UI', () => {
    for (const meta of Object.values(NODE_REGISTRY)) if (meta.isUI) expect(meta.createCategory).toBe('UI');
  });

  it('Missing é tipo do registry, mas não é criável', () => {
    expect(NODE_REGISTRY.Missing).toBeDefined();
    expect(NODE_REGISTRY.Missing.creatable).toBe(false);
    const creatable = Object.values(NODE_REGISTRY).filter((m) => m.creatable !== false).map((m) => m.type);
    expect(creatable).not.toContain('Missing');
    expect(creatable.length).toBe(Object.keys(NODE_REGISTRY).length - 1);
  });

  it('todo tipo do registry renderiza um ícone', () => {
    for (const type of Object.keys(NODE_REGISTRY) as NodeType[]) expect(NodeIcon({ type })).toBeTruthy();
  });
});
