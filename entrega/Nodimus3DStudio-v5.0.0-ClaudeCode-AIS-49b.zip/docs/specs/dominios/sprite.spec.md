# sprite

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** MÉDIA
- **Prompts/etapas relacionados:** AIS-76
- **Papel no produto:** Contrato do elemento documentado, preservando o estado observado no código.
- **Fronteira obrigatória:** Não duplicar serviços centrais; integrar por contratos públicos e manter separação Editor/Authoring/Runtime quando aplicável.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

### Decisões de contrato fechadas (AIS-76 v5.2 — Decisão Canônica 24)
- **Modelo Godot:** `SpriteProject` ↔ `SpriteFrames` (recurso `res://sprites/<nome>.sprite.json`); `SpriteFrame` ↔ região de `AtlasTexture`; `SpriteAnimation` ↔ animação (`fps` = `speed`); nó `Billboard` ↔ `AnimatedSprite3D`, referenciando o recurso por `ResourceRef`.
- **`frameIndices: number[]`** é o schema canônico de `SpriteAnimation`; nunca migrar para `startFrame/endFrame`.
- **`frameDurations?: number[]`** (paralelo a `frameIndices`): multiplicadores relativos, padrão 1. `SpriteFrame.durationMs` é legado (lido, não autoritativo).
- **`LoopMode`** mapeia para `LOOP_LINEAR / LOOP_NONE / LOOP_PINGPONG`; os três modos são canônicos.
- **Sem base64 persistido:** `imageUrl` e `customDataUrl` são transitórios; atlas = PNG em `res://textures/` via `sheetConfig.texture: ResourceRef`.
- **Schema versionado:** `SpriteProject.schemaVersion` + Zod (`src/schemas/v1/sprite.schema.ts`) + normalizador de formatos legados (`src/schemas/spriteNormalize.ts`).
- **`src/runtime/sprite.ts`** (CRIAR no AIS-76): `clipFrameIndexAtTime(animation, elapsedMs)` — única implementação autorizada da lógica de frame.

## 1. Identificação
- **Nome:** sprite
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/types/sprite.ts`
- **Linhas (auditado v4.4):** 86

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `sprite`.

## 3. Estrutura
- Declarações exportadas: `BillboardMode`, `SpriteTool`, `LoopMode`, `LightingPreset`, `SpriteFrame`, `SpriteAnimation`, `SpriteSheetConfig`, `Sprite3DSettings`, `SpriteProject`, `DEFAULT_SPRITE_3D_SETTINGS`
- **Runtime canônico (CRIAR em AIS-76):** `src/runtime/sprite.ts` exporta `clipFrameIndexAtTime(animation, elapsedMs): number`

## 4. Campos
### `SpriteFrame`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `index` | `number` | Não definido na interface | obrigatório |
| `x` | `number` | Não definido na interface | obrigatório |
| `y` | `number` | Não definido na interface | obrigatório |
| `width` | `number` | Não definido na interface | obrigatório |
| `height` | `number` | Não definido na interface | obrigatório |
| `durationMs` | `number` | Não definido na interface | **legado** (tolerado na leitura; não autoridade de tempo — AIS-76) |
| `customDataUrl` | `string` | Não definido na interface | **transitório** (não persistido — AIS-76; pixels editados vão para o atlas PNG) |
### `SpriteAnimation`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `frameIndices` | `number[]` | Não definido na interface | obrigatório |
| `fps` | `number` | Não definido na interface | obrigatório |
| `loopMode` | `LoopMode` | Não definido na interface | obrigatório |
| `frameDurations` | `number[]` | `1` por frame | opcional (AIS-76) |

> **Contrato fechado (Decisão B / Decisão 24):** `frameIndices: number[]` é a representação canônica — lista arbitrária de índices globais no atlas. `startFrame/endFrame` é apenas atalho de UI ("Convert to Frames") que converte para esta lista antes de persistir. `LoopMode 'once'` para no último frame (corrige bug histórico). Godot equivalente: `SpriteFrames` com lista de `AtlasTexture` por clipe.
### `SpriteSheetConfig`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `name` | `string` | Não definido na interface | obrigatório |
| `imageUrl` | `string` | Não definido na interface | **transitório** (estado de sessão; não persistido — AIS-76) |
| `texture` | `ResourceRef` | — | a CRIAR no AIS-76 (referência ao atlas PNG em `res://textures/`) |
| `imageWidth` | `number` | Não definido na interface | obrigatório |
| `imageHeight` | `number` | Não definido na interface | obrigatório |
| `frameWidth` | `number` | Não definido na interface | obrigatório |
| `frameHeight` | `number` | Não definido na interface | obrigatório |
| `columns` | `number` | Não definido na interface | obrigatório |
| `rows` | `number` | Não definido na interface | obrigatório |
| `spacing` | `number` | Não definido na interface | obrigatório |
| `margin` | `number` | Não definido na interface | obrigatório |
| `totalFrames` | `number` | Não definido na interface | obrigatório |
### `Sprite3DSettings`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `billboardMode` | `BillboardMode` | Não definido na interface | obrigatório |
| `renderScale` | `{ x: number` | Não definido na interface | obrigatório |
### `SpriteProject`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `sheetConfig` | `SpriteSheetConfig` | Não definido na interface | obrigatório |
| `frames` | `SpriteFrame[]` | Não definido na interface | obrigatório |
| `animations` | `SpriteAnimation[]` | Não definido na interface | obrigatório |
| `activeAnimationId` | `string` | Não definido na interface | obrigatório |
| `currentFrameIndex` | `number` | Não definido na interface | obrigatório |
| `settings3D` | `Sprite3DSettings` | Não definido na interface | obrigatório |
| `palette` | `string[]` | Não definido na interface | obrigatório |
| `schemaVersion` | `number` | `CURRENT_SPRITE_SCHEMA_VERSION` | a CRIAR no AIS-76 |

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.
- **`clipFrameIndexAtTime(animation, elapsedMs): number`** (em `src/runtime/sprite.ts`, criado no AIS-76): recebe um `SpriteAnimation` (com `frameDurations?`) e o tempo decorrido em ms; retorna o índice global do frame ativo no atlas (`-1` se não há frames). Comportamento por `loopMode`: `'loop'` cicla, `'once'` para no último frame, `'ping-pong'` vai e volta sem repetir as pontas. É a única implementação autorizada desta lógica — usada pelo editor e pelo runtime publicado.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.
- `SpriteAnimation.frameIndices` nunca é substituído por `startFrame/endFrame` no schema persistido (Decisão Canônica 24).
- `LoopMode` nunca é simplificado para `boolean loop` — os três modos são canônicos.
- O tempo por frame é relativo, como no Godot: `fps` da animação × `frameDurations` (padrão 1). `SpriteFrame.durationMs` é legado.

## 7. Dependências
- Importações diretas: Nenhuma importação explícita.
- **Consumidor de runtime (AIS-76):** `src/runtime/sprite.ts` importa os tipos deste arquivo e exporta `clipFrameIndexAtTime`.
