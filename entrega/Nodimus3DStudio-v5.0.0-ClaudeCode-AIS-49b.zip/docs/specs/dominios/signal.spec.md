# signal

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** ALTA
- **Prompts/etapas relacionados:** AIS-27, AIS-45, AIS-48, AIS-49, AIS-57, AIS-74
- **Papel no produto:** Contrato de eventos/sinais.
- **Fronteira obrigatória:** Definições persistem; subscriptions temporárias são descartadas com RuntimeSession.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

## 1. Identificação
- **Nome:** signal
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/types/signal.ts`
- **Linhas (auditado v4.4):** 14

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `signal`.

## 3. Estrutura
- Declarações exportadas: `SignalConnection`, `SignalDefinition`

## 4. Campos
### `SignalConnection`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `sourceNodeId` | `string` | Não definido na interface | obrigatório |
| `signalName` | `string` | Não definido na interface | obrigatório |
| `targetNodeId` | `string` | Não definido na interface | obrigatório |
| `targetMethod` | `string` | Não definido na interface | obrigatório |
| `arguments` | `any[]` | Não definido na interface | opcional |
### `SignalDefinition`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `name` | `string` | Não definido na interface | obrigatório |
| `description` | `string` | Não definido na interface | obrigatório |
| `parameters` | `{ name: string` | Não definido na interface | opcional |

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: Nenhuma importação explícita.


## Emenda v5.5 — AIS-27
- `SignalArgument { type: 'string'|'number'|'boolean'|'node'; value }` e `NodeSignalConnection { id, signalName, targetNodeId, targetMethod, arguments? }` (em `src/types/signal.ts`) são o formato gravado em `GameNode.signals`; `arguments` é opcional (conexões antigas continuam válidas). Argumento `node` guarda o `id` do nó.
