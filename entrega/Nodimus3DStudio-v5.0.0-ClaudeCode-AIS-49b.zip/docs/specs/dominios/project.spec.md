# project

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** ALTA
- **Prompts/etapas relacionados:** AIS-03b, AIS-03c, AIS-05, AIS-28c, AIS-29c, AIS-32
- **Papel no produto:** Raiz persistente do conteúdo autoral.
- **Fronteira obrigatória:** IDs/referências devem sobreviver a save/load e alimentar ResourceRegistry/DependencyGraph.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

## 1. Identificação
- **Nome:** project
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/types/project.ts`
- **Linhas (auditado v4.4):** 68

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `project`.

## 3. Estrutura
- Declarações exportadas: `RendererType`, `InputActionBinding`, `InputAction`, `ProjectSettings`, `VirtualFile`, `ProjectData`

## 4. Campos
### `InputActionBinding`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `type` | `'key' \| 'mouse' \| 'gamepad'` | Não definido na interface | obrigatório |
| `code` | `string` | Não definido na interface | obrigatório |
### `InputAction`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `name` | `string` | Não definido na interface | obrigatório |
| `bindings` | `InputActionBinding[]` | Não definido na interface | obrigatório |
### `ProjectSettings`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `general` | `{` | Não definido na interface | obrigatório |
| `projectName` | `string` | Não definido na interface | obrigatório |
| `version` | `string` | Não definido na interface | obrigatório |
| `mainScene` | `string` | Não definido na interface | obrigatório |
| `author` | `string` | Não definido na interface | obrigatório |
### `VirtualFile`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `path` | `string` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `isDirectory` | `boolean` | Não definido na interface | obrigatório |
| `extension` | `string` | Não definido na interface | opcional |
| `content` | `string` | Não definido na interface | opcional |
| `size` | `number` | Não definido na interface | opcional |
| `updatedAt` | `string` | Não definido na interface | obrigatório |
### `ProjectData`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `location` | `string` | Não definido na interface | obrigatório |
| `renderer` | `RendererType` | Não definido na interface | obrigatório |
| `lastOpenedScene` | `string` | Não definido na interface | obrigatório |
| `createdAt` | `string` | Não definido na interface | obrigatório |
| `updatedAt` | `string` | Não definido na interface | obrigatório |
| `settings` | `ProjectSettings` | Não definido na interface | obrigatório |
| `files` | `Record<string, VirtualFile>` | Não definido na interface | obrigatório |

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: Nenhuma importação explícita.


## Emenda v5.5 — AIS-28c
- `VirtualFile` ganhou campos opcionais de recurso: `resourceId` (identidade persistente; acompanha o arquivo em renomear/mover), `importerId`, `importerVersion`, `importSettings` e `contentHash`. `VirtualFileV1Schema` os preserva ao validar.

## Emenda v5.5 — AIS-29f
- `project.json`: `scenes[].id` = `sceneId` do arquivo; `startSceneId`/`isStartScene` vêm de `settings.general.mainScene`. A gravação do projeto relê o que escreveu e recusa conteúdo divergente (no Tauri: arquivo temporário + rename, AIS-AP).
