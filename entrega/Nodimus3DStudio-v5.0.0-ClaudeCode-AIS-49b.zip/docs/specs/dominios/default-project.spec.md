# defaultProject

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** MÉDIA
- **Prompts/etapas relacionados:** AIS-05
- **Papel no produto:** Contrato do elemento documentado, preservando o estado observado no código.
- **Fronteira obrigatória:** Não duplicar serviços centrais; integrar por contratos públicos e manter separação Editor/Authoring/Runtime quando aplicável.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

## 1. Identificação
- **Nome:** defaultProject
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/core/defaultProject.ts`
- **Linhas (auditado v4.4):** 656

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `defaultProject`.

## 3. Estrutura
- Declarações exportadas: `DEFAULT_PROJECT_SETTINGS`, `createDefault3DStarterScene`, `createEmptyScene`, `createNewProject`, `PlayerController`, `lerp`, `clamp`, `degToRad`, `radToDeg`, `distance3D`, `ensureStarterFiles`, `PlayerController`, `removeLegacyAddonSample` (v4.7.0: remove o sample de addon gerado por builds antigos; não cria `res://addons/`)

## 4. Campos
O arquivo não declara interfaces com campos diretamente extraíveis.

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: `../types/project`, `../types/scene`, `../types/node`, `../nodes/registry`
