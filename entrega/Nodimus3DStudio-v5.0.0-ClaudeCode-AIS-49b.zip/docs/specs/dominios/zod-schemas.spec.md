# Zod Schemas

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** contrato de evolução v4.1 (não há baseline no código analisado); descreve o alvo que os prompts devem criar.
- **Criticidade arquitetural:** ALTA
- **Prompts/etapas relacionados:** AIS-02b
- **Papel no produto:** Validação e versionamento (`schemaVersion` + migrações) nas fronteiras.
- **Fronteira obrigatória:** Zod valida fronteiras; não é state manager.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

## 1. Identificação
- **Nome:** Zod Schemas
- **Tipo:** Domínio / contratos de validação
- **Localização no código:** a criar no AIS-02b (`src/schemas/`)

## 0.1 Contrato canônico v4.1
Schemas versionados validam dados nas fronteiras. V1 mínimo: Project, Scene, Node, Behavior, Action, Prefab. Persistidos carregam `schemaVersion`. Migrações são explícitas Vn -> Vn+1.

## Não fazer
Não usar Zod como store; não validar cada frame; não criar tipos concorrentes desconectados dos contratos TypeScript.

## Aceite
Fixtures válidas/inválidas, diagnósticos estruturados e integração de load/import.
