# particle-system

## 0. Alinhamento arquitetural Nodimus v5.1.3
- **Status desta SPEC:** contrato de evolução (alvo do AIS-18c; consumido por AIS-23, AIS-41, AIS-49b e AIS-53). O código ainda não o implementa.
- **Criticidade arquitetural:** MÉDIA
- **Prompts/etapas relacionados:** AIS-18c, AIS-23, AIS-41, AIS-49b, AIS-53, AIS-56
- **Fronteira obrigatória:** nó `ParticleSystem` único + motor único em `src/core/particles/`; o `ParticleModal` é só catálogo. Sem segundo simulador, sem `ParticleEmitter`.
- **Referência de modelo (Godot):** os valores vivem no nó; preset apenas preenche valores; não há gerador dono dos valores.

## 1. Identificação
- **Nós:** `ParticleSystem` (`src/nodes/registry.ts`)
- **Núcleo:** `src/core/particles/{particleTypes,particleEngine,particlePresets,particleTextures}.ts`
- **Adaptador de render:** `src/components/viewports/viewportParticles.ts` (`THREE.Points`, ligado a `RendererCore.onFrame`)
- **Preview do modal:** `ParticlePreviewCanvas` (canvas 2D sobre o mesmo `step()`)

## 2. Propriedades do nó (fonte de verdade = `GameNode.properties`)
`emitting`, `emitterType` (`point|box|ring|sphere`), `emitterRadius`, `emitterBoxSize`, `particlesPerSecond`, `maxParticles`, `lifetimeMin/Max`, `direction`, `maxAngleDeviation`, `speedMin/Max`, `gravity` (vetor), `startColor`/`endColor`, `startSize`/`endSize`, `fadeOut`, `blending` (`additive|alpha|modulate`), `texture` (`glow|flame|smoke|spark|drop|snow|star`), `presetId`, `seed`. Toda chave de `defaultProperties` tem descriptor com `min/max`.

## 3. API do motor (funções puras, sem React/THREE/DOM)
- `createState(props, seed)`
- `step(state, props, dt)` — **acumulador de spawn**; cor/tamanho interpolados início → fim
- `emitBurst(state, props, n)` — usado pela Action `emit_particles` (AIS-41)
- RNG determinístico por `seed`

## 4. Presets (dados em `particlePresets.ts`)
Fogo, Fumaça, Chuva, Neve, Faíscas, Explosão, Poeira Mágica, Vaga-lumes. Todo preset respeita os limites dos descriptors.

## 5. Sinais
`started` (quando `emitting` passa a verdadeiro) e `finished` (quando `emitting` é falso e não há partículas vivas).

## 6. `generatorSource`
`{ generatorId: 'particle', version: 1, params: { presetId } }` — apenas marca de origem. "Editar no gerador" reabre o modal **a partir das propriedades do nó**.

## 7. Fora de escopo
`GPUComputationRenderer`; curvas multiponto de cor/tamanho; paridade pixel a pixel entre preview 2D e WebGL.
