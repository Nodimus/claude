# commands

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** CRÍTICA
- **Prompts/etapas relacionados:** AIS-18, AIS-19, AIS-20, AIS-22
- **Papel no produto:** Contratos concretos de edição reversível.
- **Fronteira obrigatória:** Commands operam Authoring State; não representar mutações temporárias do Play.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.


### 0.1 Revisão v4.1 — política de comandos
- Criar Command para mutação autoral persistente que o usuário espera desfazer/refazer.
- Commands não devem conter estado React/Zustand nem referências runtime pesadas.
- Agrupamentos contínuos (ex.: drag de gizmo) devem produzir transação/macro coerente, não centenas de entradas de histórico.

## 1. Identificação
- **Nome:** commands
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/types/commands.ts`
- **Linhas (auditado v4.4):** 6

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `commands`.

## 3. Estrutura
- Declarações exportadas: `ICommand`

## 4. Campos
### `ICommand`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `name` | `string` | Não definido na interface | obrigatório |
| `execute` | `() => void` | Não definido na interface | obrigatório |
| `undo` | `() => void` | Não definido na interface | obrigatório |
| `redo` | `() => void` | Não definido na interface | opcional |

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: Nenhuma importação explícita.
