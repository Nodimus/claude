# animation

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** MÉDIA
- **Prompts/etapas relacionados:** AIS-59, AIS-60, AIS-61
- **Papel no produto:** Dados/contratos de animação.
- **Fronteira obrigatória:** Preview autoral e animação de runtime devem permanecer distinguíveis.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

## 1. Identificação
- **Nome:** animation
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/types/animation.ts`
- **Linhas (auditado v4.4):** 20

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `animation`.

## 3. Estrutura
- Declarações exportadas: `Keyframe`, `AnimationTrack`, `AnimationClip`

## 4. Campos
### `Keyframe`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `time` | `number` | Não definido na interface | obrigatório |
| `value` | `any` | Não definido na interface | obrigatório |
| `easing` | `'linear' \| 'ease-in' \| 'ease-out' \| 'ease-in-out'` | Não definido na interface | opcional |
### `AnimationTrack`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `nodeId` | `string` | Não definido na interface | obrigatório |
| `property` | `string` | Não definido na interface | obrigatório |
| `keyframes` | `Keyframe[]` | Não definido na interface | obrigatório |
### `AnimationClip`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `duration` | `number` | Não definido na interface | obrigatório |
| `loop` | `boolean` | Não definido na interface | obrigatório |
| `tracks` | `AnimationTrack[]` | Não definido na interface | obrigatório |

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: Nenhuma importação explícita.

## Emenda v5.10 (AIS-36) — rig e retarget
- **`AnimationPlayer.rigConfig`** passou a `type: 'resource'` (`ResourceRef`), padrão `null`; a string legada (`'res://materials/rig.json'`) continua sendo lida e exibida como caminho (nada é apagado). O `AnimationPlayer` não é criado pelo AIS-36 (o import de clipes e o nó são do AIS-37, que preenche `rigConfig`).
- **`src/runtime/skeletalAnimation.ts`** é a função canônica (modal, Play e Publish): `normalizeBoneName`/`parseBoneName`, `autoMapBones`, `validateBoneMap`, `rigDiagnostics`, `retargetClip`. O retarget v1 só renomeia trilhas pelos nomes canônicos e escala a translação do `Hips` pela razão de altura do quadril; **não** corrige T-pose × A-pose (`anim.rest_pose_mismatch` quando as poses de repouso conhecidas divergem; `anim.target_bone_missing` quando o alvo não tem o osso).
- **`RigConfig`** (`res://materials/<asset>_rig.json`): só mapeamento (19 ossos → nome no arquivo) e `clips` por referência; nenhum keyframe.

## Emenda v5.11 (AIS-37) — biblioteca, amostragem e player
- `RigConfig.clips[]` = `{ name, source?: ResourceRef, sourceClip?, loop?, inPlace? }` (campos extras preservados); fonte única são os arquivos de `res://models/` (decisão 3.2).
- `src/runtime/skeletalAnimation.ts` ganhou `sampleClipAt` (tempo → pose; slerp para `quaternion`), `createClipMixer` (estado puro do player: velocidade 0.25–2×, loop, scrub por quadro a 30 fps, crossfade em segundos), `wrapClipTime`, `frameCount` e `stripRootMotion` (in-place). O Play (AIS-60) reutiliza o mesmo módulo; `core/models/clipPlayer.ts` é só a ponte do preview com o `THREE.AnimationMixer`.
- `AnimationPlayer` criado pelo import: filho do `MeshInstance`, `rigConfig` = `ResourceRef` do `_rig.json`.
- `loadModel({ allowAnimationOnly })`: arquivo sem malha mas com animações é válido como arquivo de animação (o importador de modelos o aceita); como modelo principal do modal continua `model.empty`.

### Emenda v5.11.1 (AIS-37, Execução 2)
- `prepareClip` (`core/modelImport/animationLibrary.ts`) é o caminho único de preparo de um clipe para o modelo: retarget (quando o clipe vem de outro arquivo e o modelo é humanoide) com a escala do `Hips` = `|bind do Hips do alvo| ÷ |bind do Hips da origem|` (posição local no bind, no mesmo espaço das trilhas `.position`); trilhas sem osso no esqueleto do modelo são descartadas (`targetBones`); depois, in-place.
- **In-place = congelar as duas componentes horizontais do `Hips`**, nunca "X e Z" fixos: o eixo vertical é a maior componente do bind do `Hips` do esqueleto de origem (`verticalAxisOf`). Mixamo em glTF/FBX traz a altura em -Z e o avanço em Y.
- Clipe de arquivo com nome genérico (`mixamo.com`, `Take 001`…) usa o nome do arquivo na biblioteca; a referência (`sourceClip`) guarda o nome original.
