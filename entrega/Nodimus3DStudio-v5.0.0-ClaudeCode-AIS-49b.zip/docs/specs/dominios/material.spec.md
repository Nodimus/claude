# material

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** MÉDIA
- **Prompts/etapas relacionados:** AIS-25
- **Papel no produto:** Contrato do elemento documentado, preservando o estado observado no código.
- **Fronteira obrigatória:** Não duplicar serviços centrais; integrar por contratos públicos e manter separação Editor/Authoring/Runtime quando aplicável.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

## 1. Identificação
- **Nome:** material
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/types/material.ts`
- **Linhas (auditado v4.4):** 477

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `material`.

## 3. Estrutura
- Declarações exportadas: `ShadingModel`, `TexturePatternType`, `PreviewMeshShape`, `PreviewLightingEnvironment`, `MaterialProperties`, `DEFAULT_MATERIAL_PROPERTIES`, `MaterialPreset`, `MATERIAL_PRESETS`

## 4. Campos
### `MaterialProperties`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | opcional |
| `name` | `string` | Não definido na interface | obrigatório |
| `shadingModel` | `ShadingModel` | Não definido na interface | obrigatório |
| `color` | `ColorData` | Não definido na interface | obrigatório |
| `roughness` | `number` | Não definido na interface | obrigatório |
| `metalness` | `number` | Não definido na interface | obrigatório |
| `wireframe` | `boolean` | Não definido na interface | obrigatório |
| `flatShading` | `boolean` | Não definido na interface | obrigatório |
| `side` | `'front' \| 'back' \| 'double'` | Não definido na interface | obrigatório |
| `emissiveColor` | `ColorData` | Não definido na interface | obrigatório |
| `emissiveIntensity` | `number` | Não definido na interface | obrigatório |
| `clearcoat` | `number` | Não definido na interface | obrigatório |
| `clearcoatRoughness` | `number` | Não definido na interface | obrigatório |
| `transmission` | `number` | Não definido na interface | obrigatório |
| `opacity` | `number` | Não definido na interface | obrigatório |
| `transparent` | `boolean` | Não definido na interface | obrigatório |
| `ior` | `number` | Não definido na interface | obrigatório |
| `textureType` | `TexturePatternType` | Não definido na interface | obrigatório |
| `customImageDataUrl` | `string` | Não definido na interface | opcional |
| `textureFileName` | `string` | Não definido na interface | opcional |
| `textureScale` | `number` | Não definido na interface | obrigatório |
| `textureColorA` | `string` | Não definido na interface | obrigatório |
| `textureColorB` | `string` | Não definido na interface | obrigatório |
| `enableNormalMap` | `boolean` | Não definido na interface | obrigatório |
| `normalMapType` | `'procedural' \| 'none'` | Não definido na interface | obrigatório |
| `normalScale` | `number` | Não definido na interface | obrigatório |
| `uvTiling` | `Vector2Data` | Não definido na interface | obrigatório |
| `uvOffset` | `Vector2Data` | Não definido na interface | obrigatório |
| `uvRotation` | `number` | Não definido na interface | obrigatório |
| `wrapMode` | `'repeat' \| 'clamp' \| 'mirror'` | Não definido na interface | obrigatório |
### `MaterialPreset`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `category` | `'Metals' \| 'Architectural' \| 'Sci-Fi' \| 'Organic' \| 'Gems & Glass' \| 'Stylized'` | Não definido na interface | obrigatório |
| `description` | `string` | Não definido na interface | obrigatório |
| `properties` | `Partial<MaterialProperties>` | Não definido na interface | obrigatório |
| `previewColor` | `string` | Não definido na interface | obrigatório |

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: `./node`

## Emenda v5.9 (AIS-35) — `materialSlots` e manifesto de extração
- **`properties.materialSlots?: Record<string, MaterialOverride>`** em `MeshInstance` com `model` (chave = nome do material no arquivo). Resolução por slot (`resolveSlotMaterial`): slot com entrada → o slot; sem entrada → `materialOverride` do nó, **exceto** o override padrão do registry (azul), que não vale para modelos; sem nenhum → material original do arquivo. Aplicado por `createModelObject` (`ModelMaterialApplier`): material alterado é clone do original (o cache não é tocado).
- **`ModelMaterialManifest`** (`res://textures/<asset>_material.json`, `src/schemas/v1/modelMaterialManifest.schema.ts`): o que o import extraiu do arquivo; `ResourceRef` para os PNG em `res://textures/<asset>/`; nunca base64. Leitura tolerante (formato antigo sem `schemaVersion`, material inválido descartado). Não substitui `.mat.json`.
- O Inspector (`ModelMaterialSlots`, dentro de `MeshMaterialSection`) lista um slot por material do manifesto e grava só `materialSlots[<nome>]` por Command.

### Emenda v5.9.1 (AIS-35, Execução 2) — canais de textura de modelo
- `MaterialOverride.normalTexture?: ResourceRef` (como `albedoTexture`; nunca base64). O slot gerado no import referencia o PNG normal do padrão procedural.
- Regras puras em `src/core/models/materialChannels.ts`: albedo `SRGBColorSpace`, normal `NoColorSpace`; `flipY = false` em glTF/GLB (UV com origem no topo; o mapa original do material manda quando existe); `normalScale = (k, -k)` com `flipY = false` e `(k, k)` com `flipY = true` (mesma convenção do GLTFLoader do three r186, confirmada no navegador).
- `ModelMaterialApplier`: albedo = PNG do slot → padrão procedural do override (`textureType`, gerador único, só CLONES; o cache do gerador não é descartado) → mapa original; normal idem com `enableNormalMap`. Clones e texturas criados pelo applier são descartados ao trocar o plano e no dispose.
