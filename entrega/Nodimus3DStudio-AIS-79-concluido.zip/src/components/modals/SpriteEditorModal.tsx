import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useEditor } from '../../core/EditorContext';
import {
  SpriteProject,
  SpriteFrame,
  SpriteAnimation,
  SpriteSheetConfig,
  BillboardMode,
  LightingPreset,
} from '../../types/sprite';
import { SPRITE_PRESETS, createEmptySpriteProject } from '../../utils/spritePresets';
import { CURRENT_SPRITE_SCHEMA_VERSION } from '../../core/persistenceVersions';
import type { ResourceRef } from '../../types/node';
import { gridFrames, parseSpriteJson, serializeSprite, textureRefForPath } from '../../schemas/spriteNormalize';
import { atlasPathFor, planSpriteSave, sanitizeSpriteName, writeSpriteFiles } from '../../core/sprites/spriteSave';
import { composeAtlas, raiseAtlasMode, type AtlasWriteMode } from './sprite/spriteAtlas';
import { useSpritePlayback } from './sprite/useSpritePlayback';
import { globalAuthoringModel } from '../../core/authoring';
import { globalAssetPipeline, globalResourceRegistry, resourcePathOf } from '../../core/resources/global';
import { ProjectStorage } from '../../core/projectStorage';
import { globalDocumentManager } from '../../core/documents/DocumentManager';
import { SPRITE_KIND, hashContent } from '../../core/documents/documentKinds';
import { SAVE_DISCARD_CANCEL, getPendingDecision, requestDecision } from '../../core/documents/decisions';
import { spriteProjectRef } from '../../core/fileSystem/dropActions';
import { SpriteCanvasEditor } from './sprite/SpriteCanvasEditor';
import { SpriteTimeline } from './sprite/SpriteTimeline';
import { SpritePropertiesPanel } from './sprite/SpritePropertiesPanel';
import { SpriteVisualizer3D } from './sprite/SpriteVisualizer3D';
import { SpriteSheetAtlasView } from './sprite/SpriteSheetAtlasView';
import {
  Sparkles,
  Layers,
  Box,
  Download,
  Upload,
  Check,
  Plus,
  Play,
  Pause,
  X,
  Sliders,
  Sun,
  Eye,
  FileCode,
  FolderOpen,
  Save,
  Palette,
} from 'lucide-react';

/** Mantém um id de documento por montagem (o StrictMode monta/desmonta/monta). */
let spriteDocSeq = 0;

/** Cancelamento deliberado do usuário (ex.: recusou sobrescrever): não é erro. */
class SaveCancelled extends Error {}

const readFileAsDataUrl = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error ?? new Error('Falha ao ler o arquivo.'));
    reader.readAsDataURL(file);
  });

const measureImage = (url: string): Promise<{ w: number; h: number } | null> =>
  new Promise((resolve) => {
    if (!url) return resolve(null);
    const img = new Image();
    img.onload = () => resolve({ w: img.naturalWidth, h: img.naturalHeight });
    img.onerror = () => resolve(null);
    img.src = url;
  });

interface LoadState {
  status: 'loading' | 'ready' | 'error';
  error?: string;
  /** Versão futura do schema: aberto só para leitura, nunca regravado. */
  readOnly: boolean;
  warnings: string[];
}

export const SpriteEditorModal: React.FC = () => {
  const {
    isSpriteEditorOpen,
    setIsSpriteEditorOpen,
    activeSpriteFilePath,
    setActiveSpriteFilePath,
    project: editorProject,
    selectedNodeId,
    selectedNode,
    updateNodeProperties,
    addNode,
    addLog,
  } = useEditor();

  // Active Tab
  const [activeTab, setActiveTab] = useState<'editor' | 'atlas'>('editor');

  // Sprite Project State (AIS-76: carregado do ARQUIVO ao abrir; o preset só existe quando o usuário o escolhe)
  const [project, setProject] = useState<SpriteProject>(() => createEmptySpriteProject('New_Sprite'));
  const [loadState, setLoadState] = useState<LoadState>({ status: 'loading', readOnly: false, warnings: [] });
  /** JSON persistido de referência (dirty = o JSON atual difere, ou há pixels/atlas a gravar). */
  const [savedJson, setSavedJson] = useState<string>('');
  /** Como o atlas PNG precisa ser gravado no próximo Salvar (pixels editados, frames reorganizados). */
  const [atlasMode, setAtlasMode] = useState<AtlasWriteMode>('none');
  /** Conversão de um formato legado (base64 separado do JSON) pede um Salvar. */
  const [needsSave, setNeedsSave] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [docId, setDocId] = useState<string | null>(null);
  /** Reabre o documento depois de uma gravação que falhou no meio (o token de versão do DocumentManager ficou defasado). */
  const [docEpoch, setDocEpoch] = useState(0);
  const [warningsDismissed, setWarningsDismissed] = useState(false);

  // Current Frame & Animation state
  const [activeFrameIndex, setActiveFrameIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [onionSkinEnabled, setOnionSkinEnabled] = useState<boolean>(false);

  // Cache for rendered frame canvases
  const [frameCanvases, setFrameCanvases] = useState<(HTMLCanvasElement | null)[]>([]);

  const storageError = useRef<string | null>(null);
  const loadedKeyRef = useRef<string | null | undefined>(undefined);
  const filesRef = useRef(editorProject.files);
  filesRef.current = editorProject.files;

  const currentJson = useMemo(() => {
    try {
      return serializeSprite(project);
    } catch {
      return '!invalido';
    }
  }, [project]);
  const readOnly = loadState.readOnly;
  const dirty = isSpriteEditorOpen && loadState.status === 'ready' && !readOnly && (currentJson !== savedJson || atlasMode !== 'none' || needsSave);

  const markAtlas = useCallback((mode: AtlasWriteMode) => setAtlasMode((m) => raiseAtlasMode(m, mode)), []);

  // ── Carregar o arquivo (ou um sprite novo) ao abrir ────────────────────────────────────────────────────────────
  const loadSprite = useCallback(async (path: string | null) => {
    setLoadState({ status: 'loading', readOnly: false, warnings: [] });
    setSaveError(null);
    setWarningsDismissed(false);
    setActiveFrameIndex(0);
    setFrameCanvases([]);
    setAtlasMode('none');
    setNeedsSave(false);
    setIsPlaying(true);

    if (path === null) {
      const fresh = createEmptySpriteProject('New_Sprite');
      setProject(fresh);
      setSavedJson(serializeSprite(fresh));
      setLoadState({ status: 'ready', readOnly: false, warnings: [] });
      return;
    }

    const file = filesRef.current[path];
    if (!file || typeof file.content !== 'string') {
      setLoadState({ status: 'error', error: `Arquivo não encontrado: ${path}`, readOnly: false, warnings: [] });
      return;
    }
    const result = parseSpriteJson(file.content);
    if (!result.ok) {
      // arquivo inválido: erro visível; o arquivo NUNCA é tocado
      setLoadState({ status: 'error', error: result.error, readOnly: false, warnings: [] });
      return;
    }

    let loaded: SpriteProject = result.project;
    const warnings = [...result.warnings];
    // atlas: PNG do projeto (texture) ou, num formato legado embutido, o base64 que será movido para o PNG ao salvar
    let atlasUrl = result.session.atlas ?? '';
    const texture = loaded.sheetConfig.texture;
    if (!atlasUrl && texture) {
      const texPath = resourcePathOf(texture) ?? texture.path;
      const data = texPath ? filesRef.current[texPath]?.content : undefined;
      if (typeof data === 'string' && data.startsWith('data:')) {
        atlasUrl = data;
        const stable = texPath ? globalResourceRegistry.refForUri(texPath) : undefined;
        if (stable && (stable.id !== texture.id || stable.path !== texture.path)) loaded = { ...loaded, sheetConfig: { ...loaded.sheetConfig, texture: stable } };
      } else {
        // recurso sumiu: referência preservada como não resolvida (nunca apagada) + aviso
        warnings.push(`Atlas não encontrado: ${texPath ?? texture.id}. A referência foi preservada como não resolvida.`);
        loaded = { ...loaded, sheetConfig: { ...loaded.sheetConfig, texture: { ...texture, unresolved: true } } };
      }
    }
    // amostra sem tamanho de atlas: mede a imagem real e refaz a grade (frameCount frames)
    if (atlasUrl && !loaded.sheetConfig.imageWidth) {
      const size = await measureImage(atlasUrl);
      if (size) {
        const cfg = loaded.sheetConfig;
        const cols = Math.max(1, Math.floor(size.w / cfg.frameWidth));
        const rows = Math.max(1, Math.floor(size.h / cfg.frameHeight));
        loaded = { ...loaded, sheetConfig: { ...cfg, imageWidth: size.w, imageHeight: size.h, columns: cols, rows }, frames: gridFrames(cols, rows, cfg.frameWidth, cfg.frameHeight, 0, 0, Math.max(1, loaded.frames.length)) };
      }
    }
    const frames = loaded.frames.map((f) => (result.session.frames[f.id] ? { ...f, customDataUrl: result.session.frames[f.id] } : f));
    const hasLegacyImages = !!result.session.atlas || Object.keys(result.session.frames).length > 0;
    loaded = { ...loaded, frames, sheetConfig: { ...loaded.sheetConfig, imageUrl: atlasUrl } };

    setProject(loaded);
    setSavedJson(serializeSprite(loaded));
    if (hasLegacyImages) {
      setAtlasMode(Object.keys(result.session.frames).length > 0 ? 'pixels' : 'none');
      setNeedsSave(true); // base64 do formato legado → atlas PNG + JSON limpo
    }
    setLoadState({ status: 'ready', readOnly: result.readOnly, warnings });
  }, []);

  useEffect(() => {
    if (!isSpriteEditorOpen) {
      loadedKeyRef.current = undefined;
      return;
    }
    if (loadedKeyRef.current === activeSpriteFilePath) return; // gravado agora neste caminho: não recarrega
    loadedKeyRef.current = activeSpriteFilePath;
    void loadSprite(activeSpriteFilePath);
  }, [isSpriteEditorOpen, activeSpriteFilePath, loadSprite]);

  // Initialize or re-render frame canvases from project spritesheet
  const regionsKey = useMemo(
    () =>
      project.frames
        .map((f) => `${f.x},${f.y},${f.width},${f.height}`)
        .sort()
        .join(';'),
    [project.frames]
  );
  useEffect(() => {
    const fw = project.sheetConfig.frameWidth || 32;
    const fh = project.sheetConfig.frameHeight || 32;
    let cancelled = false;

    const build = (img: HTMLImageElement | null) => {
      const canvases: (HTMLCanvasElement | null)[] = project.frames.map((frame) => {
        const c = document.createElement('canvas');
        c.width = fw;
        c.height = fh;
        const ctx = c.getContext('2d')!;
        ctx.imageSmoothingEnabled = false;

        if (frame.customDataUrl) {
          const frameImg = new Image();
          frameImg.onload = () => {
            ctx.clearRect(0, 0, fw, fh);
            ctx.drawImage(frameImg, 0, 0);
          };
          frameImg.src = frame.customDataUrl;
        } else if (img) {
          ctx.drawImage(img, frame.x, frame.y, frame.width, frame.height, 0, 0, fw, fh);
        }
        return c;
      });
      if (!cancelled) setFrameCanvases(canvases);
    };

    if (!project.sheetConfig.imageUrl) {
      build(null);
    } else {
      const img = new Image();
      img.onload = () => build(img);
      img.onerror = () => build(null);
      img.src = project.sheetConfig.imageUrl;
    }
    return () => {
      cancelled = true;
    };
  }, [project.sheetConfig.imageUrl, regionsKey]);

  // Update canvas for specific frame
  const handleUpdateFrameCanvas = useCallback(
    (index: number, canvas: HTMLCanvasElement, initial?: boolean) => {
      // só (re)carregou o canvas ao navegar entre frames: NÃO é edição (nada de dirty, de pixels a gravar nem de troca da miniatura)
      if (initial) return;
      // o editor reutiliza UM canvas para todos os frames: guarda uma CÓPIA por frame (senão todas as miniaturas mostram o frame atual)
      const copy = document.createElement('canvas');
      copy.width = canvas.width;
      copy.height = canvas.height;
      copy.getContext('2d')?.drawImage(canvas, 0, 0);
      setFrameCanvases((prev) => {
        const next = [...prev];
        next[index] = copy;
        return next;
      });
      markAtlas('pixels');

      // pixels editados: estado de SESSÃO (customDataUrl nunca é persistido); a gravação os escreve na região do atlas
      setProject((prev) => {
        const nextFrames = [...prev.frames];
        if (nextFrames[index]) {
          nextFrames[index] = {
            ...nextFrames[index],
            customDataUrl: canvas.toDataURL(),
          };
        }
        return {
          ...prev,
          frames: nextFrames,
        };
      });
    },
    [markAtlas]
  );

  // ── Reprodução: requestAnimationFrame + tempo absoluto + clipFrameIndexAtTime (AIS-76) ──────────────────────
  const activeAnim = project.animations.find((a) => a.id === project.activeAnimationId) || project.animations[0];
  const clipKey = `${activeAnim?.id}|${activeAnim?.frameIndices.join(',')}|${activeAnim?.fps}|${activeAnim?.loopMode}|${activeAnim?.frameDurations?.join(',')}`;
  const playback = useSpritePlayback({
    animation: activeAnim,
    playing: isPlaying && loadState.status === 'ready',
    onFrame: setActiveFrameIndex,
    onFinished: () => setIsPlaying(false),
    clipKey,
  });

  const selectFrame = (index: number) => {
    setActiveFrameIndex(index);
    playback.seekFrame(index);
  };

  // Frame Stepping (por POSIÇÃO na animação: frameIndices pode repetir e ficar fora de ordem)
  const handleStepFrame = (dir: number) => {
    if (!activeAnim || activeAnim.frameIndices.length === 0) return;
    const n = activeAnim.frameIndices.length;
    const cur = Math.max(0, activeAnim.frameIndices.indexOf(activeFrameIndex));
    const target = dir === 1000 ? n - 1 : dir === -1000 ? 0 : (cur + dir + n) % n;
    setActiveFrameIndex(playback.seekPosition(target));
  };

  // Add blank frame
  const handleAddFrame = () => {
    const fw = project.sheetConfig.frameWidth || 32;
    const fh = project.sheetConfig.frameHeight || 32;
    const newIdx = project.frames.length;

    const dummyCanvas = document.createElement('canvas');
    dummyCanvas.width = fw;
    dummyCanvas.height = fh;

    const newFrame: SpriteFrame = {
      id: `frame_${Date.now()}`,
      index: newIdx,
      x: 0,
      y: 0,
      width: fw,
      height: fh,
      customDataUrl: dummyCanvas.toDataURL(),
    };

    setProject((prev) => {
      const nextFrames = [...prev.frames, newFrame];
      const nextAnimations = prev.animations.map((anim) => {
        if (anim.id === prev.activeAnimationId) {
          return {
            ...anim,
            frameIndices: [...anim.frameIndices, newIdx],
            frameDurations: anim.frameDurations ? [...anim.frameDurations, 1] : undefined,
          };
        }
        return anim;
      });

      return {
        ...prev,
        frames: nextFrames,
        animations: nextAnimations,
      };
    });
    markAtlas('repack');

    setFrameCanvases((prev) => [...prev, dummyCanvas]);
    setActiveFrameIndex(newIdx);
  };

  // Duplicate frame
  const handleDuplicateFrame = (index: number) => {
    const frame = project.frames[index];
    if (!frame) return;

    const newIdx = project.frames.length;
    const canvas = frameCanvases[index];
    const dataUrl = canvas ? canvas.toDataURL() : frame.customDataUrl;

    const newFrame: SpriteFrame = {
      ...frame,
      id: `frame_${Date.now()}`,
      index: newIdx,
      customDataUrl: dataUrl,
    };

    setProject((prev) => {
      const nextFrames = [...prev.frames, newFrame];
      const nextAnimations = prev.animations.map((anim) => {
        if (anim.id === prev.activeAnimationId) {
          return {
            ...anim,
            frameIndices: [...anim.frameIndices, newIdx],
            frameDurations: anim.frameDurations ? [...anim.frameDurations, 1] : undefined,
          };
        }
        return anim;
      });

      return {
        ...prev,
        frames: nextFrames,
        animations: nextAnimations,
      };
    });
    markAtlas('repack');

    setFrameCanvases((prev) => [...prev, canvas || null]);
    setActiveFrameIndex(newIdx);
  };

  // Delete frame
  const handleDeleteFrame = (index: number) => {
    if (project.frames.length <= 1) return;

    setProject((prev) => {
      const nextFrames = prev.frames.filter((_, idx) => idx !== index);
      // Remap frame indices in animations (frameDurations acompanha cada uso removido)
      const nextAnimations = prev.animations.map((anim) => {
        const keep = anim.frameIndices.map((idx) => idx !== index);
        return {
          ...anim,
          frameIndices: anim.frameIndices.filter((_, k) => keep[k]).map((idx) => (idx > index ? idx - 1 : idx)),
          frameDurations: anim.frameDurations ? anim.frameDurations.filter((_, k) => keep[k]) : undefined,
        };
      });

      return {
        ...prev,
        frames: nextFrames,
        animations: nextAnimations,
      };
    });
    markAtlas('repack');

    setFrameCanvases((prev) => prev.filter((_, idx) => idx !== index));
    setActiveFrameIndex(Math.max(0, index - 1));
  };

  // Move frame in strip
  const handleMoveFrame = (fromIndex: number, toIndex: number) => {
    if (toIndex < 0 || toIndex >= project.frames.length) return;

    setProject((prev) => {
      const nextFrames = [...prev.frames];
      const [moved] = nextFrames.splice(fromIndex, 1);
      nextFrames.splice(toIndex, 0, moved);

      return {
        ...prev,
        frames: nextFrames,
      };
    });
    markAtlas('repack');

    setFrameCanvases((prev) => {
      const next = [...prev];
      const [moved] = next.splice(fromIndex, 1);
      next.splice(toIndex, 0, moved);
      return next;
    });

    setActiveFrameIndex(toIndex);
  };

  // Load preset (procedural: o atlas PNG nasce ao SALVAR pela primeira vez)
  const handleLoadPreset = (presetId: string) => {
    const item = SPRITE_PRESETS.find((p) => p.id === presetId);
    if (!item || readOnly) return;
    const preset = item.create();
    const keepIdentity = activeSpriteFilePath !== null;
    setProject((prev) => ({
      ...preset,
      schemaVersion: CURRENT_SPRITE_SCHEMA_VERSION,
      id: keepIdentity ? prev.id : preset.id,
      name: keepIdentity ? prev.name : preset.name,
      sheetConfig: { ...preset.sheetConfig, texture: prev.sheetConfig.texture },
    }));
    markAtlas('repack');
    setActiveFrameIndex(0);
    setIsPlaying(true);
    addLog('log', `Preset de sprite carregado: ${item.name}`);
  };

  // Upload image → res://textures/ (AssetPipeline) e vira o atlas (sheetConfig.texture: ResourceRef)
  const handleUploadImage = async (file: File) => {
    if (readOnly) return;
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const size = await measureImage(dataUrl);
      if (!size) throw new Error('Não foi possível ler a imagem.');
      const dot = file.name.lastIndexOf('.');
      const stem = sanitizeSpriteName(dot > 0 ? file.name.slice(0, dot) : file.name);
      const ext = dot > 0 ? file.name.slice(dot + 1).toLowerCase() : 'png';
      let uri = `res://textures/${stem}.${ext}`;
      for (let i = 2; globalAuthoringModel.getProject().files[uri] && i < 1000; i++) uri = `res://textures/${stem}_${i}.${ext}`;
      storageError.current = null;
      const imported = await globalAssetPipeline.import({ uri, content: dataUrl });
      if (!imported.ok) throw new Error(imported.diagnostics.find((d) => d.severity === 'error')?.message ?? 'Falha ao importar a imagem.');
      if (storageError.current) throw new Error(storageError.current);
      const ref = globalResourceRegistry.refForUri(uri) ?? textureRefForPath(uri);

      const fw = 32;
      const fh = 32;
      const cols = Math.max(1, Math.floor(size.w / fw));
      const rows = Math.max(1, Math.floor(size.h / fh));
      const frames = gridFrames(cols, rows, fw, fh);
      setProject((prev) => ({
        ...prev,
        name: activeSpriteFilePath === null ? stem : prev.name,
        sheetConfig: { name: stem, texture: ref, imageUrl: dataUrl, imageWidth: size.w, imageHeight: size.h, frameWidth: fw, frameHeight: fh, columns: cols, rows, spacing: 0, margin: 0, totalFrames: frames.length },
        frames,
        animations: [{ id: 'anim_default', name: 'default', frameIndices: frames.map((_, i) => i), fps: 8, loopMode: 'loop' }],
        activeAnimationId: 'anim_default',
        currentFrameIndex: 0,
      }));
      setAtlasMode('none'); // o PNG importado já é o atlas; os pixels originais não mudam
      setActiveFrameIndex(0);
      setSaveError(null);
      addLog('log', `Imagem de sprite importada: ${uri} (${size.w}x${size.h}px)`);
    } catch (error) {
      setSaveError(error instanceof Error ? error.message : String(error));
    }
  };

  // Convert to Frames: regiões do atlas pela grade (Colunas/Linhas, tamanho, separação, margem)
  const handleSliceGrid = (cols: number, rows: number, fw: number, fh: number, spacing: number, margin: number) => {
    if (readOnly) return;
    const frames = gridFrames(cols, rows, fw, fh, spacing, margin);
    setProject((prev) => {
      const valid = prev.animations.filter((a) => a.frameIndices.length > 0 && a.frameIndices.every((i) => i < frames.length));
      const animations = valid.length > 0 ? valid : [{ id: 'anim_default', name: 'default', frameIndices: frames.map((_, i) => i), fps: 8, loopMode: 'loop' as const }];
      return {
        ...prev,
        sheetConfig: { ...prev.sheetConfig, columns: cols, rows, frameWidth: fw, frameHeight: fh, spacing, margin, totalFrames: frames.length },
        frames,
        animations,
        activeAnimationId: animations.some((a) => a.id === prev.activeAnimationId) ? prev.activeAnimationId : animations[0].id,
        currentFrameIndex: 0,
      };
    });
    setActiveFrameIndex(0);
    addLog('log', `Convert to Frames: ${cols} colunas x ${rows} linhas (${frames.length} quadros)`);
  };

  // Cria uma animação a partir dos quadros selecionados no atlas (índices globais, qualquer ordem)
  const handleCreateAnimation = (name: string, frameIndices: number[]) => {
    if (readOnly || frameIndices.length === 0) return;
    setProject((prev) => {
      let unique = name;
      for (let i = 2; prev.animations.some((a) => a.name === unique); i++) unique = `${name}_${i}`;
      const anim: SpriteAnimation = { id: `anim_${Date.now()}`, name: unique, frameIndices: [...frameIndices], fps: 8, loopMode: 'loop' };
      return { ...prev, animations: [...prev.animations, anim], activeAnimationId: anim.id };
    });
    setActiveFrameIndex(frameIndices[0]);
    addLog('log', `Animação criada com ${frameIndices.length} quadro(s).`);
  };

  // Acrescenta quadros do atlas (índices globais) ao fim da animação ativa
  const handleAppendToAnimation = (frameIndices: number[]) => {
    if (readOnly || frameIndices.length === 0) return;
    setProject((prev) => ({
      ...prev,
      animations: prev.animations.map((a) =>
        a.id === prev.activeAnimationId ? { ...a, frameIndices: [...a.frameIndices, ...frameIndices], frameDurations: a.frameDurations ? [...a.frameDurations, ...frameIndices.map(() => 1)] : undefined } : a
      ),
    }));
    addLog('log', `${frameIndices.length} quadro(s) adicionados à animação ativa.`);
  };

  // Export Spritesheet PNG
  const handleExportPng = () => {
    const fw = project.sheetConfig.frameWidth || 32;
    const fh = project.sheetConfig.frameHeight || 32;
    const cols = project.sheetConfig.columns || 4;
    const rows = Math.ceil(project.frames.length / cols);

    const canvas = document.createElement('canvas');
    canvas.width = cols * fw;
    canvas.height = rows * fh;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;

    project.frames.forEach((frame, idx) => {
      const c = idx % cols;
      const r = Math.floor(idx / cols);
      const frameCanvas = frameCanvases[idx];
      if (frameCanvas) {
        ctx.drawImage(frameCanvas, c * fw, r * fh);
      }
    });

    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = `${sanitizeSpriteName(project.name)}_spritesheet.png`;
    a.click();
    addLog('log', `Spritesheet exportado: ${sanitizeSpriteName(project.name)}_spritesheet.png`);
  };

  // ── Salvar (DocumentManager, kind `sprite`; AssetPipeline: atlas PNG em res://textures/ + .sprite.json sem base64) ────────
  const performSave = async (): Promise<string | null> => {
    if (readOnly) throw new Error('Este sprite é de uma versão mais nova do editor: somente leitura.');
    const files = globalAuthoringModel.getProject().files;
    const plan = planSpriteSave({ name: project.name, activeFilePath: activeSpriteFilePath, files });
    if (plan.needsOverwriteConfirm) {
      const choice = await requestDecision({
        title: 'Sobrescrever sprite?',
        message: `Já existe ${plan.targetPath}. Deseja substituí-lo?`,
        options: [
          { id: 'overwrite', label: 'Sobrescrever', variant: 'danger' },
          { id: 'cancel', label: 'Cancelar', variant: 'neutral' },
        ],
      });
      if (choice !== 'overwrite') throw new SaveCancelled('cancelado');
    }

    storageError.current = null;
    const texture = project.sheetConfig.texture;
    const texPath = texture ? resourcePathOf(texture) ?? texture.path : undefined;
    const imageUrl = project.sheetConfig.imageUrl;
    const needAtlas = atlasMode !== 'none' || !texture;
    let working = project;
    let atlas: { uri: string; dataUrl: string } | null = null;
    if (needAtlas) {
      const mode = !imageUrl || atlasMode === 'repack' ? 'repack' : 'pixels';
      const composed = await composeAtlas({ mode, baseImageUrl: imageUrl, frames: project.frames, config: project.sheetConfig, canvases: frameCanvases });
      const own = texPath && /\.png$/i.test(texPath) ? texPath : undefined;
      atlas = { uri: atlasPathFor(plan.name, files, own), dataUrl: composed.dataUrl };
      working = { ...project, frames: composed.frames.map(({ customDataUrl: _drop, ...rest }) => rest), sheetConfig: { ...composed.config, imageUrl: composed.dataUrl } };
    }

    const written = await writeSpriteFiles({ pipeline: globalAssetPipeline, refForUri: (uri) => globalResourceRegistry.refForUri(uri) }, { project: working, targetPath: plan.targetPath, atlas });
    if (storageError.current) throw new Error(storageError.current); // quota/disco: o erro real, nunca "salvo"

    const next: SpriteProject = { ...written.project, sheetConfig: { ...written.project.sheetConfig, imageUrl: working.sheetConfig.imageUrl } };
    setProject(next);
    setSavedJson(serializeSprite(next));
    setAtlasMode('none');
    setNeedsSave(false);
    if (activeSpriteFilePath === null) {
      loadedKeyRef.current = plan.targetPath; // já está carregado: só passa a ter caminho
      setActiveSpriteFilePath(plan.targetPath);
    }
    addLog('log', `Sprite salvo: ${plan.targetPath}${atlas ? ` (atlas ${atlas.uri})` : ''}`);
    return hashContent(globalAuthoringModel.getProject().files[plan.targetPath]?.content);
  };
  const performSaveRef = useRef(performSave);
  performSaveRef.current = performSave;

  // documento `sprite` no DocumentManager (dirty único do editor; Ctrl/Cmd+S passa por ele)
  const docPathKey = activeSpriteFilePath ?? '';
  useEffect(() => {
    if (!isSpriteEditorOpen) return;
    let id: string | null = null;
    let disposed = false;
    const label = activeSpriteFilePath ? activeSpriteFilePath.split('/').pop() ?? activeSpriteFilePath : 'Novo sprite';
    void globalDocumentManager
      .open({
        kind: SPRITE_KIND,
        resourceRef: { id: activeSpriteFilePath ?? `new-sprite:${++spriteDocSeq}`, ...(activeSpriteFilePath ? { path: activeSpriteFilePath } : {}), type: 'sprite', label },
        title: label,
        adapter: {
          readVersionToken: () => (activeSpriteFilePath ? hashContent(filesRef.current[activeSpriteFilePath]?.content) : null),
          save: () => performSaveRef.current(),
        },
      })
      .then((doc) => {
        id = doc.documentId;
        if (disposed) void globalDocumentManager.close(id, 'discard');
        else setDocId(id);
      });
    return () => {
      disposed = true;
      setDocId(null);
      if (id) void globalDocumentManager.close(id, 'discard');
    };
  }, [isSpriteEditorOpen, docPathKey, docEpoch]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!docId) return;
    if (dirty) globalDocumentManager.markDirty(docId);
    else globalDocumentManager.markClean(docId);
  }, [dirty, docId]);

  // erros de gravação reportados pelo ProjectStorage (quota etc.) durante o Salvar
  useEffect(
    () =>
      ProjectStorage.onSaveError((message) => {
        storageError.current = message;
      }),
    []
  );

  /** Salva pelo DocumentManager. `false` = cancelado, erro (mostrado na UI) ou nada a fazer. */
  const trySave = async (): Promise<boolean> => {
    if (saving) return false;
    setSaving(true);
    setSaveError(null);
    try {
      if (docId) {
        const result = await globalDocumentManager.save(docId);
        if (result.ok) return true;
        const err = (result as { error?: unknown }).error;
        if (err instanceof SaveCancelled) return false;
        const reason = (result as { reason?: string }).reason;
        // a gravação pode ter mudado o arquivo em memória antes de falhar: o documento é reaberto com o token atual (continua sujo)
        if (reason === 'error') setDocEpoch((e) => e + 1);
        setSaveError(err instanceof Error ? err.message : reason === 'conflict' ? 'O arquivo mudou fora do editor: resolva o conflito antes de salvar.' : 'Não foi possível salvar o sprite.');
        return false;
      }
      await performSave();
      return true;
    } catch (error) {
      if (error instanceof SaveCancelled) return false;
      setSaveError(error instanceof Error ? error.message : String(error));
      return false;
    } finally {
      setSaving(false);
    }
  };
  const trySaveRef = useRef(trySave);
  trySaveRef.current = trySave;

  // Ctrl/Cmd+S salva o sprite (o modal captura o atalho; a cena não é salva por trás dele)
  const requestClose = () => {
    if (!dirty) return setIsSpriteEditorOpen(false);
    void requestDecision({ title: 'Alterações não salvas', message: 'O sprite tem alterações não salvas.', options: SAVE_DISCARD_CANCEL }).then(async (choice) => {
      if (choice === 'save') {
        if (await trySaveRef.current()) setIsSpriteEditorOpen(false);
      } else if (choice === 'discard') setIsSpriteEditorOpen(false);
    });
  };
  const requestCloseRef = useRef(requestClose);
  requestCloseRef.current = requestClose;
  useEffect(() => {
    if (!isSpriteEditorOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        e.stopPropagation();
        if (!readOnlyRef.current) void trySaveRef.current();
        return;
      }
      if (e.key === 'Escape' && !e.defaultPrevented && !getPendingDecision()) requestCloseRef.current();
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [isSpriteEditorOpen]);
  const readOnlyRef = useRef(readOnly);
  readOnlyRef.current = readOnly;

  /** Garante um `.sprite.json` salvo e devolve a referência estável do recurso. */
  const ensureSavedRef = async (): Promise<ResourceRef | null> => {
    if (readOnly) return null;
    if (dirty || activeSpriteFilePath === null) {
      if (!(await trySave())) return null;
    }
    const path = activeSpriteFilePath ?? planSpriteSave({ name: project.name, activeFilePath: null, files: globalAuthoringModel.getProject().files }).targetPath;
    return globalResourceRegistry.refForUri(path) ?? spriteProjectRef(path);
  };

  // Valores do nó derivados de settings3D (padrão inicial; o nó guarda só o ResourceRef + estes valores)
  const nodeValues = () => ({
    width: project.settings3D.renderScale.x,
    height: project.settings3D.renderScale.y,
    color: project.settings3D.tintColor,
    faceMode: project.settings3D.billboardMode === 'spherical' ? 'camera' : project.settings3D.billboardMode === 'cylindrical_y' ? 'y-axis' : 'none',
  });

  // Direct Engine Action: Create Sprite3D / Billboard Node in Scene (um Command: Ctrl+Z desfaz; guarda o delta, nunca o SpriteProject)
  const handleAddToScene = async () => {
    const ref = await ensureSavedRef();
    if (!ref) return;
    const billboard = addNode('Billboard', null, `${sanitizeSpriteName(project.name)}_Sprite3D`, { ...nodeValues(), spriteProject: ref });
    addLog('log', `Nó Sprite 3D '${billboard.name}' adicionado à cena (referencia ${ref.path ?? ref.id}).`);
  };

  // Direct Engine Action: Apply to selected node (só Billboard; um Command)
  const handleApplyToSelectedNode = async () => {
    if (!selectedNodeId || selectedNode?.type !== 'Billboard') return;
    const ref = await ensureSavedRef();
    if (!ref) return;
    updateNodeProperties(selectedNodeId, { ...nodeValues(), spriteProject: ref });
    addLog('log', `Sprite aplicado ao nó selecionado '${selectedNode.name}' (referencia ${ref.path ?? ref.id}).`);
  };

  // Save to the project (DocumentManager)
  const handleSaveToFilesystem = () => {
    void trySave();
  };

  if (!isSpriteEditorOpen) return null;

  const currentCanvas = frameCanvases[activeFrameIndex] || null;
  const prevCanvas = frameCanvases[activeFrameIndex - 1] || null;
  const nextCanvas = frameCanvases[activeFrameIndex + 1] || null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in select-none">
      <div className="flex flex-col w-[96vw] max-w-[1340px] h-[92vh] bg-[#1a1f2c] border border-[#2e3748] rounded-xl shadow-2xl overflow-hidden text-[#dfe4ec]">
        {/* Modal Header */}
        <header className="flex items-center justify-between px-4 py-2.5 bg-[#202531] border-b border-[#2c3345] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-md">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white tracking-wide">
                  Sprite Studio & Visualizador 3D
                </h2>
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-sky-500/20 text-sky-300 font-semibold border border-sky-500/30">
                  Three.js Billboard & Atlas
                </span>
              </div>
              <p className="text-[11px] text-[#8b97a8]">
                Editor de Pixel Art, Sequenciador de Animações e Visualizador 3D em Tempo Real
              </p>
              <p className="text-[10px] text-[#64748b] font-mono" data-testid="sprite-file-label">
                {activeSpriteFilePath ?? 'Novo sprite (ainda sem arquivo)'}
                {dirty ? ' ●' : ''}
                {readOnly ? ' · somente leitura' : ''}
              </p>
            </div>
          </div>

          {/* Quick Actions & Close */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => void handleAddToScene()}
              disabled={loadState.status !== 'ready' || readOnly || saving}
              data-testid="sprite-add-to-scene"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs shadow-md transition-colors disabled:opacity-50"
              title="Instanciar novo nó Billboard 3D na cena ativa"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Adicionar Sprite3D à Cena</span>
            </button>

            {selectedNode && (
              <button
                onClick={() => void handleApplyToSelectedNode()}
                disabled={selectedNode.type !== 'Billboard' || loadState.status !== 'ready' || readOnly || saving}
                data-testid="sprite-apply-to-node"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#273042] hover:bg-[#344059] text-sky-300 hover:text-white border border-[#3b475e] text-xs transition-colors disabled:opacity-50"
                title={selectedNode.type === 'Billboard' ? `Aplicar ao nó selecionado: ${selectedNode.name}` : 'Selecione um nó Billboard para aplicar o sprite'}
              >
                <Check className="w-3.5 h-3.5" />
                <span>Aplicar no Nó Ativo</span>
              </button>
            )}

            <button
              onClick={handleSaveToFilesystem}
              disabled={saving || readOnly || loadState.status !== 'ready'}
              data-testid="sprite-save"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#273042] hover:bg-[#344059] text-[#cbd5e1] hover:text-white border border-[#3b475e] text-xs transition-colors disabled:opacity-50"
              title="Salvar (Ctrl/Cmd+S): .sprite.json em res://sprites/ e o atlas PNG em res://textures/"
            >
              <Save className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{saving ? 'Salvando…' : dirty ? 'Salvar ●' : 'Salvar'}</span>
            </button>

            <button
              onClick={handleExportPng}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#273042] hover:bg-[#344059] text-sky-300 hover:text-white border border-[#3b475e] text-xs transition-colors"
              title="Baixar Spritesheet empacotado (PNG)"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Baixar PNG</span>
            </button>

            <div className="h-5 w-[1px] bg-[#374158] mx-1" />

            <button
              onClick={requestClose}
              data-testid="sprite-close"
              className="p-1.5 rounded-lg text-[#8b97a8] hover:text-white hover:bg-[#2c3345] transition-colors"
              title="Fechar (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Barra de modos (estilo GameMaker): Imagem (editor de pixel) ⇄ Spritesheet (importar / fatiar) */}
        <div className="flex items-center justify-between px-3 py-1 bg-[#181c24] border-b border-[#2c3345] shrink-0 text-xs">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveTab('editor')}
              data-testid="sprite-view-image"
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-colors ${activeTab === 'editor' ? 'bg-[#4982ea] text-white shadow-sm' : 'text-[#9ca7b7] hover:text-white hover:bg-[#202531]'}`}
              title="Editar a imagem do quadro (lápis, borracha, balde, conta-gotas)"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Imagem</span>
            </button>
            <button
              onClick={() => setActiveTab('atlas')}
              data-testid="sprite-view-sheet"
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-colors ${activeTab === 'atlas' ? 'bg-[#4982ea] text-white shadow-sm' : 'text-[#9ca7b7] hover:text-white hover:bg-[#202531]'}`}
              title="Importar imagem, converter em quadros (grade) e criar animações pela seleção"
            >
              <Box className="w-3.5 h-3.5" />
              <span>Spritesheet</span>
            </button>
          </div>
          <div className="flex items-center gap-3 text-[11px] text-[#8b97a8] font-mono">
            <span data-testid="sprite-frame-readout">
              Quadro {Math.max(0, (activeAnim?.frameIndices.indexOf(activeFrameIndex) ?? -1)) + 1} / {activeAnim?.frameIndices.length ?? 0}
            </span>
            <span>{project.sheetConfig.frameWidth}×{project.sheetConfig.frameHeight}px</span>
          </div>
        </div>

        {/* AIS-76: erro de gravação / avisos de leitura */}
        {saveError && (
          <div className="flex items-start justify-between gap-3 px-4 py-2 bg-rose-950/60 border-b border-rose-800 text-xs text-rose-200" role="alert" data-testid="sprite-save-error">
            <span>Erro: {saveError}</span>
            <button onClick={() => setSaveError(null)} className="text-rose-300 hover:text-white">×</button>
          </div>
        )}
        {loadState.status === 'ready' && loadState.warnings.length > 0 && !warningsDismissed && (
          <div className="flex items-start justify-between gap-3 px-4 py-1.5 bg-amber-950/40 border-b border-amber-800/60 text-[11px] text-amber-200" data-testid="sprite-warnings">
            <span>{loadState.warnings.join(' · ')}</span>
            <button onClick={() => setWarningsDismissed(true)} className="text-amber-300 hover:text-white">×</button>
          </div>
        )}

        {/* Modal Body / Tab Views */}
        <div className="flex-1 overflow-hidden flex flex-col">
          {loadState.status === 'loading' && <div className="flex-1 flex items-center justify-center text-sm text-[#8b97a8]">Carregando sprite…</div>}
          {loadState.status === 'error' && (
            <div className="flex-1 flex flex-col items-center justify-center gap-3 p-8 text-center" data-testid="sprite-load-error">
              <div className="text-sm font-semibold text-rose-300">Não foi possível abrir o sprite</div>
              <div className="max-w-xl text-xs text-[#cbd5e1] break-words">{loadState.error}</div>
              {activeSpriteFilePath && <div className="text-[11px] font-mono text-[#8b97a8]">{activeSpriteFilePath} — o arquivo foi preservado e NÃO foi alterado.</div>}
              <div className="flex gap-2">
                <button onClick={() => setIsSpriteEditorOpen(false)} className="px-3 py-1.5 rounded-lg bg-[#273042] hover:bg-[#344059] text-xs text-white border border-[#3b475e]">Fechar</button>
                <button onClick={() => setActiveSpriteFilePath(null)} className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-xs text-white">Começar um sprite novo (sem tocar no arquivo)</button>
              </div>
            </div>
          )}
          {loadState.status === 'ready' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="flex-1 flex overflow-hidden">
                {/* Esquerda: propriedades do sprite (como o GameMaker) */}
                <SpritePropertiesPanel
                  project={project}
                  onChange={(updater) => setProject(updater)}
                  readOnly={readOnly}
                  activeAnim={activeAnim}
                  onSelectAnimation={(animId) => setProject((p) => ({ ...p, activeAnimationId: animId }))}
                  onUpdateAnimation={(updated) => setProject((p) => ({ ...p, animations: p.animations.map((a) => (a.id === updated.id ? updated : a)) }))}
                />

                {activeTab === 'editor' ? (
                  <>
                    {/* Centro: imagem do quadro */}
                    <div className="flex-1 min-w-0 h-full flex flex-col border-r border-[#2c3345] overflow-hidden">
                      <SpriteCanvasEditor
                        project={project}
                        activeFrameIndex={activeFrameIndex}
                        onUpdateFrameCanvas={handleUpdateFrameCanvas}
                        onionSkinEnabled={onionSkinEnabled}
                        onToggleOnionSkin={() => setOnionSkinEnabled(!onionSkinEnabled)}
                        previousFrameCanvas={prevCanvas}
                        nextFrameCanvas={nextCanvas}
                      />
                    </div>
                    {/* Direita: prévia da animação (Billboard 3D em tempo real) */}
                    <div className="w-[320px] shrink-0 h-full flex flex-col overflow-hidden bg-[#141822]" data-testid="sprite-preview">
                      <SpriteVisualizer3D project={project} currentFrameCanvas={currentCanvas} isPlaying={isPlaying} onTogglePlay={() => setIsPlaying(!isPlaying)} />
                    </div>
                  </>
                ) : (
                  <div className="flex-1 min-w-0 h-full overflow-hidden">
                    <SpriteSheetAtlasView
                      project={project}
                      onUpdateSheetConfig={(cfg) => setProject({ ...project, sheetConfig: cfg })}
                      onSelectFrame={(idx) => {
                        selectFrame(idx);
                        setActiveTab('editor');
                      }}
                      onLoadPreset={handleLoadPreset}
                      onUploadImage={(file) => void handleUploadImage(file)}
                      onSliceGrid={handleSliceGrid}
                      onCreateAnimation={handleCreateAnimation}
                      onAppendToAnimation={handleAppendToAnimation}
                      activeAnimationName={activeAnim?.name}
                      currentFrameIndex={activeFrameIndex}
                      readOnly={readOnly}
                    />
                  </div>
                )}
              </div>

              {/* Embaixo: faixa de quadros e sequência (como a timeline do GameMaker) */}
              <SpriteTimeline
                project={project}
                currentFrameIndex={activeFrameIndex}
                onSelectFrame={selectFrame}
                isPlaying={isPlaying}
                onTogglePlay={() => setIsPlaying(!isPlaying)}
                onStepFrame={handleStepFrame}
                onAddFrame={handleAddFrame}
                onDuplicateFrame={handleDuplicateFrame}
                onDeleteFrame={handleDeleteFrame}
                onMoveFrame={handleMoveFrame}
                onSelectAnimation={(animId) => setProject({ ...project, activeAnimationId: animId })}
                onAddAnimation={(name) => {
                  const newAnim: SpriteAnimation = { id: `anim_${Date.now()}`, name, frameIndices: [activeFrameIndex], fps: 8, loopMode: 'loop' };
                  setProject({ ...project, animations: [...project.animations, newAnim], activeAnimationId: newAnim.id });
                }}
                onUpdateAnimation={(updated) => setProject({ ...project, animations: project.animations.map((a) => (a.id === updated.id ? updated : a)) })}
                onDeleteAnimation={(animId) => {
                  const remaining = project.animations.filter((a) => a.id !== animId);
                  setProject({ ...project, animations: remaining, activeAnimationId: remaining[0]?.id || '' });
                }}
                frameCanvases={frameCanvases}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
