import React, { useEffect, useState } from 'react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { globalAuthoringModel } from '../../core/authoring/AuthoringModel';
import { PARTICLE_PRESETS, getParticlePreset, presetProperties } from '../../core/particles/particlePresets';
import {
  hexToRgba,
  normalizeParticleProps,
  rgbaToHex,
  type EmitterType,
  type ParticleBlendMode,
  type ParticleProps,
} from '../../core/particles/particleTypes';
import { ParticlePreviewCanvas } from './ParticlePreviewCanvas';
import { useGeneratorEdit } from '../../core/generators/useGeneratorEdit';
import { globalGeneratorRegistry } from '../../core/generators/generatorRegistry';
import { createApplyGeneratorCommand, createSetGeneratorSourceCommand } from '../../core/generators/generatorCommands';
import { globalCommandManager } from '../../core/commandManager';
import {
  Sparkles,
  Layers,
  Play,
  Pause,
  RotateCcw,
  Check,
  X,
  Eye,
  Compass,
  Palette,
  CircleDot,
  Box,
  Circle,
  MoveUp,
  MoveDown,
} from 'lucide-react';

/** Campo de cor hexadecimal com texto local: só confirma no draft quando o valor é um hex válido. */
const HexField: React.FC<{ value: string; onCommit: (hex: string) => void; className?: string }> = ({ value, onCommit, className }) => {
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);
  return (
    <input
      type="text"
      value={text}
      onChange={(e) => {
        setText(e.target.value);
        if (/^#[0-9a-f]{6}$/i.test(e.target.value)) onCommit(e.target.value.toLowerCase());
      }}
      className={className}
    />
  );
};

export const ParticleModal: React.FC = () => {
  const isParticleModalOpen = useEditorStore((s) => s.isParticleModalOpen);
  const setIsParticleModalOpen = useEditorStore((s) => s.setIsParticleModalOpen);
  const targetNodeIdFromStore = useEditorStore((s) => s.particleModalTargetNodeId);
  const setParticleModalTargetNodeId = useEditorStore((s) => s.setParticleModalTargetNodeId);
  // `addNode` (criação + propriedades iniciais num único Command) ainda vive no EditorContext.
  const { addNode, activeScene, addLog } = useEditor();

  // AIS-53: ciclo de edição via generatorSource (AIS-49b) ou particleModalTargetNodeId (AIS-18c)
  const generatorEdit = useGeneratorEdit('particle');
  const effectiveTargetNodeId = generatorEdit.nodeId ?? targetNodeIdFromStore;
  const editingNode = effectiveTargetNodeId ? activeScene.nodes[effectiveTargetNodeId] : undefined;
  const isEditing = generatorEdit.editing || (!!editingNode && editingNode.type === 'ParticleSystem');
  const editingNodeName = generatorEdit.nodeName ?? editingNode?.name ?? null;

  // Estado de UI do catálogo (não é parâmetro de simulação)
  const [activeTab, setActiveTab] = useState<'emitter' | 'physics' | 'appearance'>('emitter');
  const [nodeName, setNodeName] = useState<string>('ParticleSystem_Fogo');
  const [isSimPaused, setIsSimPaused] = useState<boolean>(false);
  const [resetKey, setResetKey] = useState<number>(0);

  // Único draft: mesmo formato das propriedades do nó `ParticleSystem`
  const [draft, setDraft] = useState<ParticleProps>(() => presetProperties('fire'));
  const patch = (changes: Partial<ParticleProps>) => setDraft((d) => normalizeParticleProps({ ...d, ...changes }));

  const selectedPresetId = draft.presetId;

  const applyPreset = (id: string) => {
    const preset = getParticlePreset(id);
    if (!preset) return;
    setDraft(presetProperties(id));
    setNodeName(`ParticleSystem_${preset.nodeNameSuffix}`);
    setResetKey((k) => k + 1);
  };

  // AIS-53-C06: ao abrir em modo edição, carrega props do NÓ (fonte de verdade)
  useEffect(() => {
    if (!isParticleModalOpen) return;
    if (isEditing && editingNode) {
      // Fonte de verdade = propriedades do nó (não o generatorSource.params)
      const nodeProps = normalizeParticleProps({ ...presetProperties('fire'), ...(editingNode.properties as Partial<ParticleProps>) });
      setDraft(nodeProps);
      setNodeName(editingNode.name);
      setResetKey((k) => k + 1);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isParticleModalOpen, isEditing, effectiveTargetNodeId]);

  // AIS-53: registra no globalGeneratorRegistry para que "Editar no gerador" funcione (AIS-49b)
  useEffect(() => {
    const unregister = globalGeneratorRegistry.register({
      id: 'particle',
      label: 'Particle System',
      open: (req) => {
        useEditorStore.getState().setParticleModalTargetNodeId(req.nodeId);
        setIsParticleModalOpen(true);
      },
    });
    return unregister;
  }, [setIsParticleModalOpen]);

  // Handle close: encerra edição de gerador se ativa
  const handleClose = () => {
    setIsParticleModalOpen(false);
    if (generatorEdit.editing) generatorEdit.cancel();
    setParticleModalTargetNodeId(null);
    setIsSimPaused(false);
  };

  // Leituras/gravações do draft com os nomes usados pelos controles abaixo
  const { emitterType, particlesPerSecond, maxParticles, lifetimeMin, lifetimeMax, maxAngleDeviation, speedMin, speedMax, startSize, endSize, fadeOut, blending } = draft;
  const boxDimensions = draft.emitterBoxSize;
  const ringRadius = draft.emitterRadius;
  const dirX = draft.direction.x;
  const dirY = draft.direction.y;
  const dirZ = draft.direction.z;
  const gravityY = draft.gravity.y;
  const startColor = rgbaToHex(draft.startColor);
  const endColor = rgbaToHex(draft.endColor);
  const startAlpha = draft.startColor.a;
  const endAlpha = draft.endColor.a;

  const setEmitterType = (v: EmitterType) => patch({ emitterType: v });
  const setBoxDimensions = (v: { x: number; y: number; z: number }) => patch({ emitterBoxSize: v });
  const setRingRadius = (v: number) => patch({ emitterRadius: v });
  const setParticlesPerSecond = (v: number) => patch({ particlesPerSecond: v });
  const setMaxParticles = (v: number) => patch({ maxParticles: v });
  const setLifetimeMin = (v: number) => patch({ lifetimeMin: v });
  const setLifetimeMax = (v: number) => patch({ lifetimeMax: v });
  const setMaxAngleDeviation = (v: number) => patch({ maxAngleDeviation: v });
  const setSpeedMin = (v: number) => patch({ speedMin: v });
  const setSpeedMax = (v: number) => patch({ speedMax: v });
  const setStartSize = (v: number) => patch({ startSize: v });
  const setEndSize = (v: number) => patch({ endSize: v });
  const setFadeOut = (v: boolean) => patch({ fadeOut: v });
  const setBlending = (v: ParticleBlendMode) => patch({ blending: v });
  const setGravityY = (v: number) => setDraft((d) => normalizeParticleProps({ ...d, gravity: { ...d.gravity, y: v } }));
  const setDirX = (v: number) => setDraft((d) => normalizeParticleProps({ ...d, direction: { ...d.direction, x: v } }));
  const setDirY = (v: number) => setDraft((d) => normalizeParticleProps({ ...d, direction: { ...d.direction, y: v } }));
  const setDirZ = (v: number) => setDraft((d) => normalizeParticleProps({ ...d, direction: { ...d.direction, z: v } }));
  const setStartColor = (hex: string) => setDraft((d) => normalizeParticleProps({ ...d, startColor: hexToRgba(hex, d.startColor.a) }));
  const setEndColor = (hex: string) => setDraft((d) => normalizeParticleProps({ ...d, endColor: hexToRgba(hex, d.endColor.a) }));
  const setStartAlpha = (a: number) => setDraft((d) => normalizeParticleProps({ ...d, startColor: { ...d.startColor, a } }));
  const setEndAlpha = (a: number) => setDraft((d) => normalizeParticleProps({ ...d, endColor: { ...d.endColor, a } }));

  if (!isParticleModalOpen) return null;

  // AIS-53-C05: Inserir na cena — criação + props + generatorSource num único MacroCommand (um Undo)
  const handleInsert = () => {
    const node = globalCommandManager.transaction('Create Particle System', () => {
      const n = addNode('ParticleSystem', globalAuthoringModel.getScene().rootNodeId, nodeName, draft);
      // generatorSource.params contém APENAS presetId (C14); as props ficam no nó (fonte de verdade)
      const cmd = createSetGeneratorSourceCommand({
        target: globalAuthoringModel,
        nodeId: n.id,
        source: { generatorId: 'particle', version: 1, params: { presetId: draft.presetId ?? 'fire' } },
      });
      if (cmd) globalCommandManager.pushCommand(cmd);
      return n;
    });
    addLog('log', `Inserted ParticleSystem "${nodeName}" (preset: ${draft.presetId ?? 'fire'})`);
    handleClose();
  };

  // AIS-53-C07/C08: "Aplicar ao nó" — atualiza props + generatorSource in-place via MacroCommand (não cria nó novo)
  const handleApplyToNode = () => {
    if (!isEditing || !effectiveTargetNodeId) return;
    const source = {
      generatorId: 'particle',
      version: 1,
      params: { presetId: draft.presetId ?? 'fire' },
    };
    if (generatorEdit.editing) {
      const applied = generatorEdit.apply(draft as unknown as Record<string, any>, source);
      if (applied) {
        addLog('log', `ParticleSystem "${nodeName}" atualizado via gerador (preset: ${draft.presetId ?? 'fire'}).`);
        handleClose();
      }
    } else {
      const cmd = createApplyGeneratorCommand({
        target: globalAuthoringModel,
        nodeId: effectiveTargetNodeId,
        properties: draft as unknown as Record<string, any>,
        source,
        label: 'Aplicar ao nó',
      });
      if (cmd) {
        globalCommandManager.execute(cmd);
        addLog('log', `ParticleSystem "${nodeName}" atualizado via gerador (preset: ${draft.presetId ?? 'fire'}).`);
      }
      handleClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 select-none animate-in fade-in duration-150">
      <div className="bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-5xl h-[92vh] max-h-[820px] flex flex-col overflow-hidden text-sm text-[#d4dbe8]">
        {/* Header */}
        <div className="px-5 py-3.5 bg-[#141720] border-b border-[#242b3b] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-semibold text-white text-base">
                  Particle System Generator (Gerador de Partículas)
                </h2>
                {isEditing && (
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
                    Editando: {editingNodeName}
                  </span>
                )}
              </div>
              <p className="text-xs text-[#828f9f] mt-0.5">
                {isEditing ? 'Reconfigurar emissor existente e aplicar ao nó' : 'Crie efeitos visuais 3D de fogo, fumaça, chuva, neve, faíscas arcanas e explosões'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleClose}
              className="p-1.5 text-[#828f9f] hover:text-white hover:bg-[#252c3c] rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Quick Presets Bar */}
        <div className="px-5 py-2.5 bg-[#12151d] border-b border-[#202636] flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-[11px] font-semibold text-[#6d7a8d] uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" /> Presets:
          </span>
          {PARTICLE_PRESETS.map((p) => {
            const isSelected = selectedPresetId === p.id;
            const swatch = rgbaToHex(p.properties.startColor);
            return (
              <button
                key={p.id}
                onClick={() => applyPreset(p.id)}
                className={`px-2.5 py-1 text-xs rounded-md border flex items-center gap-1.5 shrink-0 transition-all ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-500/50 text-amber-300 font-medium shadow-sm shadow-amber-950'
                    : 'bg-[#181c26] border-[#262e3e] text-[#8e9cb0] hover:text-[#dfe4ec] hover:border-[#384358]'
                }`}
              >
                <div
                  className="w-2.5 h-2.5 rounded-full border border-black/40"
                  style={{ backgroundColor: swatch }}
                />
                <span>{p.shortName}</span>
                {isSelected && <Check className="w-3 h-3 text-amber-400" />}
              </button>
            );
          })}
        </div>

        {/* Main Content: Two Columns */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Column: Properties & Tabs */}
          <div className="w-[58%] border-r border-[#242b3b] flex flex-col bg-[#161a24]">
            {/* Category Tabs */}
            <div className="flex border-b border-[#222838] bg-[#141721] px-3 pt-2 gap-1 shrink-0">
              <button
                onClick={() => setActiveTab('emitter')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'emitter'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-amber-400" />
                <span>Emissor & Taxa</span>
              </button>

              <button
                onClick={() => setActiveTab('physics')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'physics'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Compass className="w-3.5 h-3.5 text-sky-400" />
                <span>Física & Vetor</span>
              </button>

              <button
                onClick={() => setActiveTab('appearance')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'appearance'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Palette className="w-3.5 h-3.5 text-rose-400" />
                <span>Cores & Blend</span>
              </button>
            </div>

            {/* Scrollable Form Panels */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs text-[#a9b6c8]">
              {/* TAB 1: EMITTER & RATE */}
              {activeTab === 'emitter' && (
                <div className="space-y-4">
                  {/* Node Name */}
                  <div>
                    <label className="text-white font-medium block mb-1">Nome do Nó de Partículas</label>
                    <input
                      type="text"
                      value={nodeName}
                      onChange={(e) => setNodeName(e.target.value)}
                      className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  {/* Emitter Shape */}
                  <div>
                    <label className="text-white font-medium block mb-1.5">
                      Formato da Área de Emissão (Emitter Shape)
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      {[
                        { id: 'point', label: 'Point', icon: CircleDot, desc: 'Ponto único' },
                        { id: 'box', label: 'Box Area', icon: Box, desc: 'Volume 3D' },
                        { id: 'ring', label: 'Ring', icon: Circle, desc: 'Anel horizontal' },
                        { id: 'sphere', label: 'Sphere', icon: CircleDot, desc: 'Esfera radial' },
                      ].map((item) => {
                        const Icon = item.icon;
                        const isSelected = emitterType === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={() => setEmitterType(item.id as EmitterType)}
                            className={`p-2.5 rounded-lg border text-center transition-all ${
                              isSelected
                                ? 'bg-amber-500/20 border-amber-500/60 text-white'
                                : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                            }`}
                          >
                            <Icon className="w-4 h-4 mx-auto mb-1 text-amber-400" />
                            <div className="font-semibold text-xs">{item.label}</div>
                            <div className="text-[9px] text-[#718096] mt-0.5">{item.desc}</div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Specific Emitter Shape Dimensions */}
                  {emitterType === 'box' && (
                    <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-2">
                      <span className="text-white font-medium block">Dimensões da Caixa de Emissão (Metros)</span>
                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <span className="text-[10px] text-[#718096]">Largura X:</span>
                          <input
                            type="number"
                            value={boxDimensions.x}
                            step="0.5"
                            onChange={(e) => setBoxDimensions({ ...boxDimensions, x: parseFloat(e.target.value) || 1 })}
                            className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-2 py-1 text-white text-xs font-mono"
                          />
                        </div>
                        <div>
                          <span className="text-[10px] text-[#718096]">Altura Y:</span>
                          <input
                            type="number"
                            value={boxDimensions.y}
                            step="0.5"
                            onChange={(e) => setBoxDimensions({ ...boxDimensions, y: parseFloat(e.target.value) || 0 })}
                            className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-2 py-1 text-white text-xs font-mono"
                          />
                        </div>
                        <div>
                          <span className="text-[10px] text-[#718096]">Profundidade Z:</span>
                          <input
                            type="number"
                            value={boxDimensions.z}
                            step="0.5"
                            onChange={(e) => setBoxDimensions({ ...boxDimensions, z: parseFloat(e.target.value) || 1 })}
                            className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-2 py-1 text-white text-xs font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {(emitterType === 'ring' || emitterType === 'sphere') && (
                    <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg">
                      <div className="flex justify-between mb-1">
                        <span className="text-white font-medium">Raio do Emissor (Radius)</span>
                        <span className="font-mono text-amber-400">{ringRadius.toFixed(1)}m</span>
                      </div>
                      <input
                        type="range"
                        min="0.2"
                        max="5.0"
                        step="0.1"
                        value={ringRadius}
                        onChange={(e) => setRingRadius(parseFloat(e.target.value))}
                        className="w-full accent-amber-500"
                      />
                    </div>
                  )}

                  {/* Emission Rates & Counts */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-white font-medium">Taxa de Emissão (Particles Per Second)</label>
                        <span className="font-mono text-amber-400 font-semibold">{particlesPerSecond} p/s</span>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="400"
                        step="5"
                        value={particlesPerSecond}
                        onChange={(e) => setParticlesPerSecond(parseInt(e.target.value))}
                        className="w-full accent-amber-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-white font-medium">Limite Máximo de Partículas Ativas</label>
                        <span className="font-mono text-amber-400 font-semibold">{maxParticles} máx</span>
                      </div>
                      <input
                        type="range"
                        min="50"
                        max="1200"
                        step="25"
                        value={maxParticles}
                        onChange={(e) => setMaxParticles(parseInt(e.target.value))}
                        className="w-full accent-amber-500"
                      />
                      <span className="text-[10px] text-[#6d7b8e] block mt-0.5">
                        O motor otimiza o buffer de vértices reaproveitando partículas no pool.
                      </span>
                    </div>
                  </div>

                  {/* Lifespan */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-white">Tempo de Vida Mínimo</label>
                        <span className="font-mono text-amber-400">{lifetimeMin.toFixed(1)}s</span>
                      </div>
                      <input
                        type="range"
                        min="0.1"
                        max="6.0"
                        step="0.1"
                        value={lifetimeMin}
                        onChange={(e) => setLifetimeMin(Math.min(lifetimeMax - 0.1, parseFloat(e.target.value)))}
                        className="w-full accent-amber-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-white">Tempo de Vida Máximo</label>
                        <span className="font-mono text-amber-400">{lifetimeMax.toFixed(1)}s</span>
                      </div>
                      <input
                        type="range"
                        min="0.2"
                        max="10.0"
                        step="0.1"
                        value={lifetimeMax}
                        onChange={(e) => setLifetimeMax(Math.max(lifetimeMin + 0.1, parseFloat(e.target.value)))}
                        className="w-full accent-amber-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: PHYSICS & DIRECTION */}
              {activeTab === 'physics' && (
                <div className="space-y-4">
                  {/* Direction Vector with Quick Buttons */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-white font-medium">Vetor de Direção Inicial (Direction Vector)</label>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => { setDirX(0); setDirY(1); setDirZ(0); }}
                          className="px-2 py-0.5 rounded bg-[#1f2533] hover:bg-[#2b3345] text-[10px] text-sky-300 flex items-center gap-1"
                        >
                          <MoveUp className="w-3 h-3" /> Cima (Y:1)
                        </button>
                        <button
                          onClick={() => { setDirX(0); setDirY(-1); setDirZ(0); }}
                          className="px-2 py-0.5 rounded bg-[#1f2533] hover:bg-[#2b3345] text-[10px] text-sky-300 flex items-center gap-1"
                        >
                          <MoveDown className="w-3 h-3" /> Baixo (Y:-1)
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 font-mono">
                      <div>
                        <span className="text-[10px] text-[#718096]">X:</span>
                        <input
                          type="number"
                          value={dirX}
                          step="0.1"
                          onChange={(e) => setDirX(parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-2 py-1 text-white text-xs"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-[#718096]">Y:</span>
                        <input
                          type="number"
                          value={dirY}
                          step="0.1"
                          onChange={(e) => setDirY(parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-2 py-1 text-white text-xs"
                        />
                      </div>
                      <div>
                        <span className="text-[10px] text-[#718096]">Z:</span>
                        <input
                          type="number"
                          value={dirZ}
                          step="0.1"
                          onChange={(e) => setDirZ(parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-2 py-1 text-white text-xs"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Cone Angle Deviation (Spread) */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg">
                    <div className="flex justify-between mb-1">
                      <label className="text-white font-medium">Ângulo de Abertura / Dispersão (Cone Deviation)</label>
                      <span className="font-mono text-sky-400 font-semibold">{maxAngleDeviation}°</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="180"
                      step="1"
                      value={maxAngleDeviation}
                      onChange={(e) => setMaxAngleDeviation(parseInt(e.target.value))}
                      className="w-full accent-sky-500"
                    />
                    <div className="flex justify-between text-[10px] text-[#6c7b8e] mt-1">
                      <span>0° (Foco laser retilíneo)</span>
                      <span>45° (Cone médio)</span>
                      <span>180° (Esfera 360° total)</span>
                    </div>
                  </div>

                  {/* Velocity Range */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-white">Velocidade Mínima</label>
                        <span className="font-mono text-sky-400">{speedMin.toFixed(1)} m/s</span>
                      </div>
                      <input
                        type="range"
                        min="0.1"
                        max="25.0"
                        step="0.5"
                        value={speedMin}
                        onChange={(e) => setSpeedMin(Math.min(speedMax - 0.5, parseFloat(e.target.value)))}
                        className="w-full accent-sky-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-white">Velocidade Máxima</label>
                        <span className="font-mono text-sky-400">{speedMax.toFixed(1)} m/s</span>
                      </div>
                      <input
                        type="range"
                        min="0.5"
                        max="35.0"
                        step="0.5"
                        value={speedMax}
                        onChange={(e) => setSpeedMax(Math.max(speedMin + 0.5, parseFloat(e.target.value)))}
                        className="w-full accent-sky-500"
                      />
                    </div>
                  </div>

                  {/* Gravity Vector (Vertical) */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-2">
                    <div className="flex justify-between mb-1">
                      <label className="text-white font-medium">Força de Gravidade / Empuxo (Gravity Y)</label>
                      <span className="font-mono text-sky-400 font-semibold">{gravityY.toFixed(1)} m/s²</span>
                    </div>
                    <input
                      type="range"
                      min="-15.0"
                      max="5.0"
                      step="0.5"
                      value={gravityY}
                      onChange={(e) => setGravityY(parseFloat(e.target.value))}
                      className="w-full accent-sky-500"
                    />
                    <div className="flex justify-between text-[10px] text-[#6c7b8e]">
                      <span>-9.8 (Gravidade terrestre/chuva)</span>
                      <span>0.0 (Zero G / Espaço)</span>
                      <span>+2.0 (Empuxo térmico/fogo)</span>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: APPEARANCE & COLORS */}
              {activeTab === 'appearance' && (
                <div className="space-y-4">
                  {/* Blending Mode */}
                  <div>
                    <label className="text-white font-medium block mb-1.5">
                      Modo de Mistura Óptica (Blending Mode)
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() => setBlending('additive')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          blending === 'additive'
                            ? 'bg-amber-500/20 border-amber-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center justify-between">
                          <span>Additive (Glow)</span>
                          {blending === 'additive' && <Check className="w-3.5 h-3.5 text-amber-400" />}
                        </div>
                        <div className="text-[10px] text-[#718096] mt-0.5">Brilho intenso (Fogo, raios, magia)</div>
                      </button>

                      <button
                        onClick={() => setBlending('alpha')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          blending === 'alpha'
                            ? 'bg-amber-500/20 border-amber-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center justify-between">
                          <span>Alpha Blend</span>
                          {blending === 'alpha' && <Check className="w-3.5 h-3.5 text-amber-400" />}
                        </div>
                        <div className="text-[10px] text-[#718096] mt-0.5">Translúcido (Fumaça, chuva, poeira)</div>
                      </button>

                      <button
                        onClick={() => setBlending('modulate')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          blending === 'modulate'
                            ? 'bg-amber-500/20 border-amber-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center justify-between">
                          <span>Modulate</span>
                          {blending === 'modulate' && <Check className="w-3.5 h-3.5 text-amber-400" />}
                        </div>
                        <div className="text-[10px] text-[#718096] mt-0.5">Multiplica luz de fundo</div>
                      </button>
                    </div>
                  </div>

                  {/* Colors: Start & End */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      {/* Start Color */}
                      <div className="space-y-1.5">
                        <label className="text-white font-medium block">Cor Inicial (Start Color)</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={startColor}
                            onChange={(e) => setStartColor(e.target.value)}
                            className="w-9 h-9 rounded border border-[#2b3345] bg-transparent cursor-pointer p-0.5"
                          />
                          <HexField
                            value={startColor}
                            onCommit={setStartColor}
                            className="flex-1 bg-[#1b202c] border border-[#2c3447] rounded px-2.5 py-1.5 text-white font-mono text-xs uppercase"
                          />
                        </div>
                        <div className="flex justify-between text-[11px] pt-1">
                          <span className="text-[#7c8b9e]">Opacidade Inicial</span>
                          <span className="font-mono text-amber-400">{Math.round(startAlpha * 100)}%</span>
                        </div>
                        <input
                          type="range"
                          min="0.1"
                          max="1.0"
                          step="0.05"
                          value={startAlpha}
                          onChange={(e) => setStartAlpha(parseFloat(e.target.value))}
                          className="w-full accent-amber-500"
                        />
                      </div>

                      {/* End Color */}
                      <div className="space-y-1.5">
                        <label className="text-white font-medium block">Cor Final (End / Fade Color)</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={endColor}
                            onChange={(e) => setEndColor(e.target.value)}
                            className="w-9 h-9 rounded border border-[#2b3345] bg-transparent cursor-pointer p-0.5"
                          />
                          <HexField
                            value={endColor}
                            onCommit={setEndColor}
                            className="flex-1 bg-[#1b202c] border border-[#2c3447] rounded px-2.5 py-1.5 text-white font-mono text-xs uppercase"
                          />
                        </div>
                        <div className="flex justify-between text-[11px] pt-1">
                          <span className="text-[#7c8b9e]">Opacidade Final</span>
                          <span className="font-mono text-amber-400">{Math.round(endAlpha * 100)}%</span>
                        </div>
                        <input
                          type="range"
                          min="0.0"
                          max="1.0"
                          step="0.05"
                          value={endAlpha}
                          onChange={(e) => setEndAlpha(parseFloat(e.target.value))}
                          className="w-full accent-amber-500"
                        />
                      </div>
                    </div>

                    <div className="pt-2 border-t border-[#232a3a] flex items-center justify-between">
                      <label className="flex items-center gap-2 text-white cursor-pointer">
                        <input
                          type="checkbox"
                          checked={fadeOut}
                          onChange={(e) => setFadeOut(e.target.checked)}
                          className="rounded border-[#2c3447] bg-[#1a1f2b] text-amber-500 focus:ring-0"
                        />
                        <span>Desvanecer Gradualmente (Fade Out Over Lifetime)</span>
                      </label>
                    </div>
                  </div>

                  {/* Size Growth / Shrink */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-white">Tamanho Inicial (Start Size)</label>
                        <span className="font-mono text-amber-400">{startSize.toFixed(2)}m</span>
                      </div>
                      <input
                        type="range"
                        min="0.05"
                        max="3.0"
                        step="0.05"
                        value={startSize}
                        onChange={(e) => setStartSize(parseFloat(e.target.value))}
                        className="w-full accent-amber-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-white">Tamanho Final (End Size)</label>
                        <span className="font-mono text-amber-400">{endSize.toFixed(2)}m</span>
                      </div>
                      <input
                        type="range"
                        min="0.05"
                        max="5.0"
                        step="0.05"
                        value={endSize}
                        onChange={(e) => setEndSize(parseFloat(e.target.value))}
                        className="w-full accent-amber-500"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Real-time 3D Particle Viewport Preview */}
          <div className="w-[42%] flex flex-col bg-[#11141c]">
            {/* Toolbar */}
            <div className="px-3.5 py-2.5 bg-[#141822] border-b border-[#212737] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Eye className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-xs font-semibold text-white">Preview 3D em Tempo Real</span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setIsSimPaused(!isSimPaused)}
                  className={`px-2 py-0.5 rounded text-[11px] font-medium flex items-center gap-1 transition-colors ${
                    isSimPaused
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-[#202737] text-[#9bb0c9] hover:text-white'
                  }`}
                >
                  {isSimPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
                  <span>{isSimPaused ? 'Retomar' : 'Pausar'}</span>
                </button>
                <button
                  onClick={() => setResetKey((k) => k + 1)}
                  className="p-1 rounded bg-[#202737] text-[#9bb0c9] hover:text-white"
                  title="Limpar Partículas"
                >
                  <RotateCcw className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* Canvas */}
            <div className="flex-1 relative flex items-center justify-center p-2 bg-[#080a0f] overflow-hidden">
              <ParticlePreviewCanvas
                draft={draft}
                paused={isSimPaused}
                resetKey={resetKey}
                width={380}
                height={460}
                className="w-full h-full max-h-[480px] object-contain rounded-md"
              />
            </div>

            {/* Footer Summary Bar */}
            <div className="p-3 bg-[#141822] border-t border-[#212737] space-y-1.5 shrink-0 text-xs">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-[#728094] uppercase tracking-wider font-semibold">Gradiente de Cor e Alpha</span>
                <span className="font-mono text-amber-400">
                  {startSize}m ➔ {endSize}m
                </span>
              </div>

              {/* Color Bar */}
              <div className="h-3.5 rounded border border-[#2b3345] overflow-hidden flex relative">
                <div
                  className="h-full w-full"
                  style={{
                    background: `linear-gradient(to right, ${startColor} 0%, ${endColor} 100%)`,
                    opacity: startAlpha,
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-[#13161f] border-t border-[#232938] flex items-center justify-between shrink-0">
          <button
            onClick={() => applyPreset(PARTICLE_PRESETS[0].id)}
            className="px-2.5 py-1.5 text-xs text-[#7d8c9e] hover:text-[#d3dce9] transition-colors"
          >
            Restaurar Padrões
          </button>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleClose}
              className="px-4 py-1.5 text-xs font-medium text-[#92a1b5] hover:text-white hover:bg-[#202636] border border-transparent hover:border-[#2f384a] rounded-lg transition-colors"
            >
              Cancelar
            </button>

            {isEditing ? (
              <>
                <button
                  type="button"
                  onClick={handleInsert}
                  title="Cria outro emissor independente na cena com estas configurações"
                  className="px-3 py-1.5 text-xs font-medium text-[#c4cfdf] bg-[#1b202c] hover:bg-[#252c3c] border border-[#2a3346] rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Inserir novo</span>
                </button>
                <button
                  data-testid="particle-apply"
                  onClick={handleApplyToNode}
                  title={`Atualiza "${editingNodeName}" no lugar (um Ctrl+Z desfaz)`}
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-lg shadow-emerald-950 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
                >
                  <Check className="w-4 h-4" />
                  <span>Aplicar ao nó</span>
                </button>
              </>
            ) : (
              <button
                data-testid="particle-insert"
                onClick={handleInsert}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 rounded-lg shadow-lg shadow-amber-950 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Sparkles className="w-4 h-4" />
                <span>Inserir Sistema de Partículas na Cena</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
