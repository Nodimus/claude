import React, { useEffect, useMemo, useState } from 'react';
import { Car, Plane } from 'lucide-react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { globalAuthoringModel } from '../../core/authoring';
import { globalCommandManager } from '../../core/commandManager';
import { globalGeneratorRegistry } from '../../core/generators/generatorRegistry';
import { createSetGeneratorSourceCommand } from '../../core/generators/generatorCommands';
import { nodeObjectRegistry } from '../../core/rendering/nodeObjectRegistry';
import { measureLocalBounds } from '../../core/physics/bounds';
import { bindingLabel, effectiveProjectActions, FLIGHT_INPUT_ACTIONS, projectActionsToMap, VEHICLE_INPUT_ACTIONS, withVehicleDefaults } from '../../core/inputMap';
import {
  AIRCRAFT_GENERATOR_ID,
  AIRCRAFT_KEYS,
  AIRCRAFT_PRESETS,
  AIRCRAFT_TYPES,
  aircraftPreset,
  aircraftType,
  defaultAircraftForm,
  readAircraftGeneratorSource,
  type AircraftFormValues,
  type AircraftPresetId,
  type AircraftType,
  type AircraftValues,
  DRIVE_KEYS,
  DRIVE_PRESETS,
  MAX_CUSTOM_AXLES,
  MIN_CUSTOM_AXLES,
  VEHICLE_GENERATOR_ID,
  VEHICLE_TYPES,
  defaultVehicleForm,
  drivePreset,
  readVehicleGeneratorSource,
  vehicleType,
  wheelRoles,
  type DrivePresetId,
  type DriveValues,
  type Traction,
  type Vec3,
  type VehicleFormValues,
  type VehicleType,
} from '../../core/vehicles/vehiclePresets';
import { applyAircraft, applyAircraftDrive, applyVehicle, applyVehicleDrive, chassisBoxOf, createAircraft, createVehicle, planAircraftEdit, planVehicleEdit, type VehicleDeps } from '../../core/vehicles/vehicleCommands';

/**
 * AIS-73 — diálogo "Criar Veículo" (um único componente, dois modos). Abre pelo atalho "Veículo…" do `CreateNodeModal` (criar), pelo duplo
 * clique no veículo, por "Editar no gerador" do Inspector e por "Configure Vehicle…" do card do Behavior (editar). Só coleta o formulário:
 * toda regra (rodas, presets, reconciliação) mora em `src/core/vehicles/`; criar e "Aplicar ao nó" são UMA transação (um Undo).
 * Seção "Entrada" é só leitura (o diálogo não cria ações próprias). Esc cancela.
 */

const FIELD = 'bg-[#0f121a] border border-[#2c3345] rounded px-2 py-1 text-xs text-[#dfe4ec] focus:border-sky-500 outline-none w-full';
const SECTION = 'text-[10px] uppercase tracking-wider text-[#68768e] mb-1.5';

const DRIVE_FIELDS: { key: keyof DriveValues; label: string; unit: string; min: number }[] = [
  { key: 'enginePower', label: 'Engine Power', unit: 'N', min: 0 },
  { key: 'brakeForce', label: 'Brake Force', unit: 'N', min: 0 },
  { key: 'steerAngle', label: 'Steer Angle', unit: '°', min: 0 },
  { key: 'maxSpeed', label: 'Max Speed', unit: 'm/s', min: 0.1 },
  { key: 'mass', label: 'Mass', unit: 'kg', min: 1 },
  { key: 'suspensionStiffness', label: 'Susp. Stiffness', unit: '', min: 0.1 },
  { key: 'suspensionDamping', label: 'Susp. Damping', unit: '', min: 0 },
  { key: 'suspensionTravel', label: 'Susp. Travel', unit: 'm', min: 0.02 },
  { key: 'groundAlignmentSpeed', label: 'Ground Align', unit: '1/s', min: 0 },
];

const FLIGHT_FIELDS: { key: keyof AircraftValues; label: string; unit: string; min: number }[] = [
  { key: 'thrust', label: 'Thrust', unit: 'N', min: 0 },
  { key: 'lift', label: 'Lift', unit: '× peso', min: 0 },
  { key: 'drag', label: 'Drag', unit: 'N·s²/m²', min: 0 },
  { key: 'pitchSpeed', label: 'Pitch Speed', unit: '°/s', min: 0 },
  { key: 'yawSpeed', label: 'Yaw Speed', unit: '°/s', min: 0 },
  { key: 'rollSpeed', label: 'Roll Speed', unit: '°/s', min: 0 },
  { key: 'minSpeedToFly', label: 'Min Speed To Fly', unit: 'm/s', min: 1 },
  { key: 'mass', label: 'Mass', unit: 'kg', min: 1 },
];

const TRACTIONS: { id: Traction; label: string }[] = [
  { id: 'front', label: 'Dianteira' },
  { id: 'rear', label: 'Traseira' },
  { id: 'all', label: 'Integral' },
];

const ROLE_LABEL = (role: string): string =>
  role
    .replace('front', 'Diant.')
    .replace('rear2', 'Meio')
    .replace('rear3', 'Meio 2')
    .replace('rear', 'Tras.')
    .replace('_left', ' esq.')
    .replace('_right', ' dir.')
    .replace('_center', '');

/** Campo numérico que aceita digitação livre e só confirma números finitos (inválido = borda vermelha, sem aplicar). */
const NumberField: React.FC<{ label: string; value: number; min?: number; unit?: string; step?: number; onChange(v: number): void; testId?: string }> = ({ label, value, min = 0, unit, step = 0.1, onChange, testId }) => {
  const [text, setText] = useState(String(value));
  useEffect(() => setText((t) => (Number(t) === value ? t : String(value))), [value]);
  const parsed = Number(text);
  const invalid = text.trim() === '' || !Number.isFinite(parsed) || parsed < min;
  return (
    <label className="block text-[10px] text-[#8b97a8]">
      <span>
        {label}
        {unit ? ` (${unit})` : ''}
      </span>
      <input
        type="number"
        value={text}
        step={step}
        min={min}
        data-testid={testId}
        aria-invalid={invalid}
        onChange={(e) => {
          setText(e.target.value);
          const n = Number(e.target.value);
          if (e.target.value.trim() !== '' && Number.isFinite(n) && n >= min) onChange(n);
        }}
        onKeyDown={(e) => e.stopPropagation()}
        className={`${FIELD} mt-0.5 ${invalid ? '!border-rose-500' : ''}`}
      />
    </label>
  );
};

export const VehicleDialog: React.FC = () => {
  const dialog = useEditorStore((s) => s.vehicleDialog);
  const setVehicleDialog = useEditorStore((s) => s.setVehicleDialog);
  const setIsProjectSettingsOpen = useEditorStore((s) => s.setIsProjectSettingsOpen);
  const selectedNodeId = useEditorStore((s) => s.selectedNodeId);
  const { activeScene, project, addNode, changeNodeProperties, deleteMultipleNodes, behaviorOps, addLog } = useEditor();

  const [form, setForm] = useState<VehicleFormValues>(() => defaultVehicleForm('car'));
  /** AIS-73b: modo (só ao criar; ao editar vem do nó) e o formulário da aeronave. */
  const [kind, setKind] = useState<'ground' | 'aircraft'>('ground');
  const [air, setAir] = useState<AircraftFormValues>(() => defaultAircraftForm('light'));
  const [airSize, setAirSize] = useState<Vec3>(aircraftType('light').fuselage);
  const [name, setName] = useState('Carro');
  const [chassisChoice, setChassisChoice] = useState<'prototype' | 'selected'>('prototype');
  const [size, setSize] = useState<Vec3>(vehicleType('car').chassis);
  const [createCamera, setCreateCamera] = useState(true);
  const [cameraActive, setCameraActive] = useState(true);
  const [missing, setMissing] = useState<string[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const editingNode = dialog?.mode === 'edit' ? activeScene.nodes[dialog.nodeId] : undefined;
  const saved = useMemo(() => readVehicleGeneratorSource(editingNode?.generatorSource), [editingNode?.generatorSource]);
  const savedAir = useMemo(() => readAircraftGeneratorSource(editingNode?.generatorSource), [editingNode?.generatorSource]);
  const hasAirController = !!editingNode?.behaviors?.some((b) => b.behaviorType === 'aircraft_controller');
  const isAir = dialog?.mode === 'edit' ? !!savedAir || (hasAirController && !saved) : kind === 'aircraft';
  const manual = dialog?.mode === 'edit' && !saved && !savedAir; // veículo/aeronave montado à mão (só os campos gerais)
  const hasController = !!editingNode?.behaviors?.some((b) => b.behaviorType === (isAir ? 'aircraft_controller' : 'vehicle_controller'));

  // o gerador `vehicle` sabe reabrir o nó ("Editar no gerador" do Inspector): sem código novo no botão (contrato do AIS-49b)
  useEffect(
    () =>
      globalGeneratorRegistry.register({
        id: VEHICLE_GENERATOR_ID,
        label: 'Vehicle',
        open: ({ nodeId }) => {
          const store = useEditorStore.getState();
          store.selectNode(nodeId);
          store.setVehicleDialog({ mode: 'edit', nodeId });
        },
      }),
    []
  );

  // o gerador `aircraft` também reabre o nó pelo "Editar no gerador"
  useEffect(
    () =>
      globalGeneratorRegistry.register({
        id: AIRCRAFT_GENERATOR_ID,
        label: 'Aircraft',
        open: ({ nodeId }) => {
          const store = useEditorStore.getState();
          store.selectNode(nodeId);
          store.setVehicleDialog({ mode: 'edit', nodeId });
        },
      }),
    []
  );

  const selectedNode = selectedNodeId ? activeScene.nodes[selectedNodeId] : undefined;
  const selectedUsable = !!selectedNode && selectedNode.id !== activeScene.rootNodeId && (selectedNode.type === 'MeshInstance' || selectedNode.type === 'Spatial') && !selectedNode.behaviors?.some((b) => b.behaviorType === 'vehicle_controller' || b.behaviorType === 'aircraft_controller');

  // abre com os valores salvos (editar) ou os padrões do tipo (criar)
  useEffect(() => {
    if (!dialog) return;
    setMissing(null);
    setError(null);
    if (dialog.mode === 'edit' && editingNode && (savedAir || (hasAirController && !saved))) {
      if (savedAir) setAir({ ...savedAir, flight: { ...savedAir.flight } });
      else {
        const props = (editingNode.behaviors?.find((b) => b.behaviorType === 'aircraft_controller')?.properties ?? {}) as Record<string, unknown>;
        const base = defaultAircraftForm('light');
        const flight = { ...base.flight };
        for (const key of AIRCRAFT_KEYS) if (typeof props[key] === 'number' && Number.isFinite(props[key])) flight[key] = props[key] as number;
        setAir({ ...base, flight });
      }
      setName(editingNode.name);
    } else if (dialog.mode === 'edit' && editingNode) {
      if (saved) setForm({ ...saved, drive: { ...saved.drive } });
      else {
        const controller = editingNode.behaviors?.find((b) => b.behaviorType === 'vehicle_controller');
        const base = defaultVehicleForm('car');
        const props = (controller?.properties ?? {}) as Record<string, unknown>;
        const drive = { ...base.drive };
        for (const key of DRIVE_KEYS) if (typeof props[key] === 'number' && Number.isFinite(props[key])) drive[key] = props[key] as number;
        setForm({ ...base, drive });
      }
      setName(editingNode.name);
    } else {
      const startKind = dialog.mode === 'create' && dialog.kind === 'aircraft' ? 'aircraft' : 'ground';
      setKind(startKind);
      setAir(defaultAircraftForm('light'));
      setAirSize({ ...aircraftType('light').fuselage });
      if (startKind === 'aircraft') setName(aircraftType('light').label);
      const base = defaultVehicleForm('car');
      setForm(base);
      if (startKind === 'ground') setName(vehicleType('car').label.split(' ')[0]);
      setSize({ ...vehicleType('car').chassis });
      setChassisChoice('prototype');
      setCreateCamera(true);
      setCameraActive(true);
    }
  }, [dialog]); // eslint-disable-line react-hooks/exhaustive-deps

  const close = () => setVehicleDialog(null);

  useEffect(() => {
    if (!dialog) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        setVehicleDialog(null);
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [dialog, setVehicleDialog]);

  const inputSummary = useMemo(() => {
    const map = withVehicleDefaults(projectActionsToMap(effectiveProjectActions(project.settings?.input?.actions)));
    return (isAir ? FLIGHT_INPUT_ACTIONS : VEHICLE_INPUT_ACTIONS).map((action) => ({ action, bindings: (map[action] ?? []).map(bindingLabel) }));
  }, [project.settings?.input?.actions, isAir]);
  const missingInput = inputSummary.filter((i) => i.bindings.length === 0).map((i) => i.action);

  if (!dialog) return null;

  const isEdit = dialog.mode === 'edit';
  const roles = wheelRoles(form.type, form.customAxles);

  const setType = (type: VehicleType) => {
    if (isEdit) {
      setForm((f) => ({ ...f, type }));
      return;
    }
    const base = defaultVehicleForm(type);
    setForm({ ...base, customAxles: type === 'custom' ? Math.max(MIN_CUSTOM_AXLES, form.customAxles) : base.customAxles });
    setSize({ ...vehicleType(type).chassis });
    setName(vehicleType(type).label.split(' ')[0]);
  };
  const setAirType = (type: AircraftType) => {
    if (isEdit) {
      setAir((a) => ({ ...a, type }));
      return;
    }
    setAir(defaultAircraftForm(type));
    setAirSize({ ...aircraftType(type).fuselage });
    setName(aircraftType(type).label);
  };
  const setAirPreset = (preset: AircraftPresetId) => setAir((a) => ({ ...a, preset, flight: { ...aircraftPreset(preset).values } }));
  const setFlight = (key: keyof AircraftValues, value: number) => setAir((a) => ({ ...a, flight: { ...a.flight, [key]: value } }));
  const switchKind = (next: 'ground' | 'aircraft') => {
    setKind(next);
    setName(next === 'aircraft' ? aircraftType(air.type).label : vehicleType(form.type).label.split(' ')[0]);
  };
  const setPreset = (preset: DrivePresetId) => setForm((f) => ({ ...f, preset, drive: { ...drivePreset(preset).values } }));
  const setDrive = (key: keyof DriveValues, value: number) => setForm((f) => ({ ...f, drive: { ...f.drive, [key]: value } }));

  const flightValid = FLIGHT_FIELDS.every((d) => Number.isFinite(air.flight[d.key]) && air.flight[d.key] >= d.min) && (isEdit || chassisChoice === 'selected' || (airSize.x > 0 && airSize.y > 0 && airSize.z > 0));
  const valid = isAir ? flightValid : form.wheelRadius >= 0.05 && form.wheelWidth >= 0.02 && DRIVE_FIELDS.every((d) => Number.isFinite(form.drive[d.key]) && form.drive[d.key] >= d.min) && (isEdit || chassisChoice === 'selected' || (size.x > 0 && size.y > 0 && size.z > 0));

  const deps = (): VehicleDeps => ({
    nodes: () => globalAuthoringModel.getScene().nodes, // sempre o estado VIVO (a transação cria nós no meio do caminho)
    addNode: (type, parentId, nodeName, properties) => addNode(type, parentId ?? undefined, nodeName, properties),
    ops: behaviorOps,
    changeNodeProperties,
    deleteNodes: (ids) => deleteMultipleNodes([...ids]), // o MESMO Command de exclusão do ContextMenu
    setGeneratorSource: (nodeId, source) => {
      const command = createSetGeneratorSourceCommand({ target: globalAuthoringModel, nodeId, source });
      if (command) globalCommandManager.execute(command);
    },
    transaction: (label, fn) => globalCommandManager.transaction(label, fn),
  });

  const measuredBox = (fallback: Vec3 = size) => {
    if (!selectedNode) return { size: { ...fallback }, center: { x: 0, y: 0, z: 0 } };
    const object = nodeObjectRegistry.get(selectedNode.id);
    const bounds = object ? measureLocalBounds(object) : null;
    return bounds ? { size: { ...bounds.size }, center: { ...bounds.center } } : { size: { ...fallback }, center: { x: 0, y: 0, z: 0 } };
  };

  const confirm = (options: { recreateMissing?: boolean; skipMissing?: boolean } = {}) => {
    setError(null);
    try {
      if (isAir) {
        if (!isEdit) {
          const useSelected = chassisChoice === 'selected' && selectedUsable && selectedNode;
          const created = createAircraft(deps(), {
            form: air,
            parentId: dialog.mode === 'create' ? dialog.parentId : null,
            name: name.trim() || undefined,
            fuselage: useSelected ? { mode: 'existing', nodeId: selectedNode!.id, box: measuredBox(airSize) } : { mode: 'prototype', size: airSize },
            camera: createCamera ? { active: cameraActive } : null,
          });
          useEditorStore.getState().selectNode(created.aircraftId);
          addLog('log', `Aeronave criada: ${globalAuthoringModel.getNode(created.aircraftId)?.name ?? created.aircraftId}`);
          return close();
        }
        if (manual) {
          if (applyAircraftDrive(deps(), dialog.nodeId, air.flight)) addLog('log', 'Aeronave atualizada.');
          return close();
        }
        const applied = applyAircraft(deps(), dialog.nodeId, air);
        if (!applied.ok) return setError(applied.message);
        if (applied.changed) addLog('log', 'Aeronave atualizada (Aplicar ao nó).');
        return close();
      }
      if (!isEdit) {
        const useSelected = chassisChoice === 'selected' && selectedUsable && selectedNode;
        const result = createVehicle(deps(), {
          form,
          parentId: dialog.mode === 'create' ? dialog.parentId : null,
          name: name.trim() || undefined,
          chassis: useSelected ? { mode: 'existing', nodeId: selectedNode!.id, box: measuredBox() } : { mode: 'prototype', size },
          camera: createCamera ? { active: cameraActive } : null,
        });
        useEditorStore.getState().selectNode(result.vehicleId);
        addLog('log', `Veículo criado: ${globalAuthoringModel.getNode(result.vehicleId)?.name ?? result.vehicleId}`);
        return close();
      }
      if (manual) {
        if (applyVehicleDrive(deps(), dialog.nodeId, form.drive)) addLog('log', 'Veículo atualizado.');
        return close();
      }
      const result = applyVehicle(deps(), dialog.nodeId, form, { ...options });
      if (!result.ok) {
        if (result.reason === 'missing_wheels') return setMissing(result.missing ?? []); // pergunta antes de recriar
        return setError(result.message);
      }
      if (result.changed) addLog('log', 'Veículo atualizado (Aplicar ao nó).');
      close();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  };

  const airPreview = isAir && isEdit && !manual && editingNode ? planAircraftEdit({ nodes: () => globalAuthoringModel.getScene().nodes }, editingNode.id, air) : null;
  const preview = !isAir && isEdit && !manual && editingNode ? planVehicleEdit({ nodes: () => globalAuthoringModel.getScene().nodes }, editingNode.id, form, { chassis: chassisBoxOf(editingNode, { size: { ...size }, center: { x: 0, y: 0, z: 0 } }) }) : null;
  const colisor = !isAir && editingNode ? chassisBoxOf(editingNode, { size: { ...size }, center: { x: 0, y: 0, z: 0 } }).size : null;

  return (
    <div role="dialog" aria-labelledby="vehicle-dialog-title" data-testid="vehicle-dialog" className="fixed inset-0 z-[70] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 select-none">
      <div className="bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col text-sm text-[#d4dbe8]">
        <div className="px-5 py-3.5 bg-[#141720] border-b border-[#242b3b] flex items-center gap-3 rounded-t-xl shrink-0">
          {isAir ? <Plane className="w-5 h-5 text-sky-400" /> : <Car className="w-5 h-5 text-sky-400" />}
          <h2 id="vehicle-dialog-title" className="font-semibold text-white text-base">
            {isEdit ? `${isAir ? 'Aeronave' : 'Veículo'}: ${editingNode?.name ?? ''}` : isAir ? 'Criar Aeronave' : 'Criar Veículo'}
          </h2>
          {isEdit && manual && <span className="text-[10px] text-amber-300">montado à mão: só os campos gerais</span>}
        </div>

        <div className="px-5 py-4 space-y-4 overflow-y-auto">
          {isEdit && !editingNode && <p className="text-rose-300 text-xs">{isAir ? 'A aeronave' : 'O veículo'} não existe mais.</p>}
          {isEdit && editingNode && manual && !hasController && <p className="text-rose-300 text-xs">Este nó não tem o Behavior "{isAir ? 'Aircraft Controller' : 'Vehicle Controller'}".</p>}
          {!isEdit && (
            <div className="flex gap-2" role="radiogroup" aria-label="Tipo de criação">
              {([['ground', 'Veículo terrestre'], ['aircraft', 'Aeronave']] as const).map(([id, label]) => (
                <button key={id} type="button" role="radio" aria-checked={kind === id} onClick={() => switchKind(id)} data-testid={`vehicle-kind-${id}`} className={`px-3 py-1.5 rounded border text-xs ${kind === id ? 'border-sky-500 bg-[#1c2536] text-white' : 'border-[#2c3345] bg-[#141822] hover:border-[#3a4560]'}`}>
                  {label}
                </button>
              ))}
            </div>
          )}

          {isAir && (
            <>
              {/* 1. Tipo */}
              {!manual && (
                <div>
                  <div className={SECTION}>1 · Tipo</div>
                  <div className="grid grid-cols-3 gap-2">
                    {AIRCRAFT_TYPES.map((t) => (
                      <label key={t.id} title={t.description} className={`flex flex-col gap-0.5 px-3 py-2 rounded border cursor-pointer ${air.type === t.id ? 'border-sky-500 bg-[#1c2536]' : 'border-[#2c3345] bg-[#141822] hover:border-[#3a4560]'}`}>
                        <span className="flex items-center gap-2">
                          <input type="radio" name="aircraft-type" checked={air.type === t.id} onChange={() => setAirType(t.id)} data-testid={`aircraft-type-${t.id}`} />
                          <span className="font-medium text-[#dfe4ec] text-xs">{t.label}</span>
                        </span>
                        <span className="text-[10px] text-[#8b97a8]">{t.description}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {/* 2. Fuselagem */}
              {!isEdit && (
                <div>
                  <div className={SECTION}>2 · Fuselagem</div>
                  <label className={`flex items-center gap-2 text-xs mb-1 ${selectedUsable ? '' : 'opacity-40'}`}>
                    <input type="radio" name="aircraft-fuselage" disabled={!selectedUsable} checked={chassisChoice === 'selected'} onChange={() => setChassisChoice('selected')} data-testid="aircraft-fuselage-selected" />
                    Usar o objeto selecionado{selectedUsable ? `: ${selectedNode!.name}` : ' (nenhum objeto utilizável selecionado)'}
                  </label>
                  <label className="flex items-center gap-2 text-xs mb-1">
                    <input type="radio" name="aircraft-fuselage" checked={chassisChoice === 'prototype'} onChange={() => setChassisChoice('prototype')} data-testid="aircraft-fuselage-prototype" />
                    Criar um protótipo (caixa, com asas e cauda)
                  </label>
                  {chassisChoice === 'prototype' && (
                    <div className="grid grid-cols-4 gap-2 mt-1.5">
                      <label className="block text-[10px] text-[#8b97a8]">
                        Nome
                        <input value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.stopPropagation()} className={`${FIELD} mt-0.5`} data-testid="aircraft-name" />
                      </label>
                      <NumberField label="Largura X" unit="m" value={airSize.x} min={0.1} onChange={(v) => setAirSize((s) => ({ ...s, x: v }))} testId="aircraft-size-x" />
                      <NumberField label="Altura Y" unit="m" value={airSize.y} min={0.1} onChange={(v) => setAirSize((s) => ({ ...s, y: v }))} testId="aircraft-size-y" />
                      <NumberField label="Compr. Z" unit="m" value={airSize.z} min={0.1} onChange={(v) => setAirSize((s) => ({ ...s, z: v }))} testId="aircraft-size-z" />
                    </div>
                  )}
                </div>
              )}

              {/* 3. Voo */}
              <div>
                <div className={SECTION}>{manual ? 'Voo' : '3 · Voo'}</div>
                <div className="grid grid-cols-3 gap-2 mb-2">
                  {AIRCRAFT_PRESETS.map((p) => (
                    <button key={p.id} type="button" title={p.description} aria-pressed={air.preset === p.id} onClick={() => setAirPreset(p.id)} data-testid={`aircraft-preset-${p.id}`} className={`px-2 py-1.5 rounded border text-xs ${air.preset === p.id ? 'border-sky-500 bg-[#1c2536] text-white' : 'border-[#2c3345] bg-[#141822] hover:border-[#3a4560]'}`}>
                      {p.label}
                    </button>
                  ))}
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {FLIGHT_FIELDS.map((d) => (
                    <NumberField key={d.key} label={d.label} unit={d.unit} value={air.flight[d.key]} min={d.min} onChange={(v) => setFlight(d.key, v)} testId={`aircraft-flight-${d.key}`} />
                  ))}
                </div>
                <p className="text-[10px] text-[#68768e] mt-1">Voo arcade (não é aerodinâmica real): abaixo de "Min Speed To Fly" a sustentação some e a aeronave cai. A massa também vai para a Colisão.</p>
                {airPreview && !airPreview.plan.empty && (
                  <p className="text-[10px] text-sky-300 mt-1" data-testid="aircraft-plan-preview">
                    Aplicar: {Object.keys(airPreview.plan.controllerChanges).length} campo(s) alterado(s). O que você editou à mão em outros campos não muda.
                  </p>
                )}
              </div>
            </>
          )}


          {!isAir && (
            <>
          {/* 1. Tipo */}
          {!manual && (
            <div>
              <div className={SECTION}>1 · Tipo</div>
              <div className="grid grid-cols-2 gap-2">
                {VEHICLE_TYPES.map((t) => (
                  <label key={t.id} title={t.description} className={`flex flex-col gap-0.5 px-3 py-2 rounded border cursor-pointer ${form.type === t.id ? 'border-sky-500 bg-[#1c2536]' : 'border-[#2c3345] bg-[#141822] hover:border-[#3a4560]'}`}>
                    <span className="flex items-center gap-2">
                      <input type="radio" name="vehicle-type" checked={form.type === t.id} onChange={() => setType(t.id)} data-testid={`vehicle-type-${t.id}`} />
                      <span className="font-medium text-[#dfe4ec] text-xs">{t.label}</span>
                    </span>
                    <span className="text-[10px] text-[#8b97a8]">{t.description}</span>
                  </label>
                ))}
              </div>
              {form.type === 'custom' && (
                <div className="mt-2 w-40">
                  <NumberField label="Eixos (2 a 4)" value={form.customAxles} min={MIN_CUSTOM_AXLES} step={1} onChange={(v) => setForm((f) => ({ ...f, customAxles: Math.min(MAX_CUSTOM_AXLES, Math.round(v)) }))} testId="vehicle-axles" />
                </div>
              )}
            </div>
          )}

          {/* 2. Carroceria */}
          {!isEdit && (
            <div>
              <div className={SECTION}>2 · Carroceria</div>
              <label className={`flex items-center gap-2 text-xs mb-1 ${selectedUsable ? '' : 'opacity-40'}`} title={selectedUsable ? '' : 'Selecione um MeshInstance/Spatial (sem Vehicle Controller) na árvore da cena'}>
                <input type="radio" name="vehicle-chassis" disabled={!selectedUsable} checked={chassisChoice === 'selected'} onChange={() => setChassisChoice('selected')} data-testid="vehicle-chassis-selected" />
                Usar o objeto selecionado{selectedUsable ? `: ${selectedNode!.name}` : ' (nenhum objeto utilizável selecionado)'}
              </label>
              <label className="flex items-center gap-2 text-xs mb-1">
                <input type="radio" name="vehicle-chassis" checked={chassisChoice === 'prototype'} onChange={() => setChassisChoice('prototype')} data-testid="vehicle-chassis-prototype" />
                Criar um protótipo (caixa)
              </label>
              {chassisChoice === 'prototype' && (
                <div className="grid grid-cols-4 gap-2 mt-1.5">
                  <label className="block text-[10px] text-[#8b97a8]">
                    Nome
                    <input value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.stopPropagation()} className={`${FIELD} mt-0.5`} data-testid="vehicle-name" />
                  </label>
                  <NumberField label="Largura X" unit="m" value={size.x} min={0.1} onChange={(v) => setSize((s) => ({ ...s, x: v }))} testId="vehicle-size-x" />
                  <NumberField label="Altura Y" unit="m" value={size.y} min={0.1} onChange={(v) => setSize((s) => ({ ...s, y: v }))} testId="vehicle-size-y" />
                  <NumberField label="Compr. Z" unit="m" value={size.z} min={0.1} onChange={(v) => setSize((s) => ({ ...s, z: v }))} testId="vehicle-size-z" />
                </div>
              )}
              {chassisChoice === 'selected' && <p className="text-[10px] text-[#8b97a8] mt-1">O colisor ganha o tamanho medido do objeto e a colisão vira "Físico" (dynamic); as rodas nascem como filhas dele.</p>}
            </div>
          )}
          {isEdit && colisor && !manual && (
            <p className="text-[10px] text-[#8b97a8]">
              Carroceria (colisor): {colisor.x.toFixed(2)} × {colisor.y.toFixed(2)} × {colisor.z.toFixed(2)} m. Rodas novas nascem por esta caixa; as existentes nunca são movidas.
            </p>
          )}

          {/* 3. Rodas */}
          {!manual && (
            <div>
              <div className={SECTION}>3 · Rodas ({roles.length})</div>
              <div className="grid grid-cols-3 gap-2">
                <NumberField label="Raio" unit="m" value={form.wheelRadius} min={0.05} onChange={(v) => setForm((f) => ({ ...f, wheelRadius: v }))} testId="vehicle-wheel-radius" />
                <NumberField label="Largura" unit="m" value={form.wheelWidth} min={0.02} onChange={(v) => setForm((f) => ({ ...f, wheelWidth: v }))} testId="vehicle-wheel-width" />
                <label className="block text-[10px] text-[#8b97a8]">
                  Tração
                  <select value={form.traction} onChange={(e) => setForm((f) => ({ ...f, traction: e.target.value as Traction }))} className={`${FIELD} mt-0.5`} data-testid="vehicle-traction">
                    {TRACTIONS.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.label}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
              <div className="flex flex-wrap gap-1 mt-1.5" data-testid="vehicle-wheel-roles">
                {roles.map((r) => (
                  <span key={r} className="px-1.5 py-0.5 rounded bg-[#141822] border border-[#2c3345] text-[10px] text-[#8b97a8]">
                    {ROLE_LABEL(r)}
                    {r.startsWith('front') ? ' · esterça' : ''}
                  </span>
                ))}
              </div>
              {isEdit && preview && (preview.plan.add.length > 0 || preview.plan.remove.length > 0) && (
                <p className="text-[10px] text-sky-300 mt-1" data-testid="vehicle-plan-preview">
                  Aplicar: +{preview.plan.add.length} roda(s), −{preview.plan.remove.length} roda(s) gerada(s). As rodas existentes não são movidas.
                </p>
              )}
            </div>
          )}

          {/* 4. Condução */}
          <div>
            <div className={SECTION}>{manual ? 'Condução' : '4 · Condução'}</div>
            <div className="grid grid-cols-4 gap-2 mb-2">
              {DRIVE_PRESETS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  title={p.description}
                  aria-pressed={form.preset === p.id}
                  onClick={() => setPreset(p.id)}
                  data-testid={`vehicle-preset-${p.id}`}
                  className={`px-2 py-1.5 rounded border text-xs ${form.preset === p.id ? 'border-sky-500 bg-[#1c2536] text-white' : 'border-[#2c3345] bg-[#141822] hover:border-[#3a4560]'}`}
                >
                  {p.label}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-2">
              {DRIVE_FIELDS.map((d) => (
                <NumberField key={d.key} label={d.label} unit={d.unit} value={form.drive[d.key]} min={d.min} onChange={(v) => setDrive(d.key, v)} testId={`vehicle-drive-${d.key}`} />
              ))}
            </div>
            <p className="text-[10px] text-[#68768e] mt-1">Modelo arcade (não é simulação real). A massa também vai para a Colisão do veículo.</p>
          </div>

            </>
          )}

          {/* 5. Câmera */}
          {!isEdit && (
            <div>
              <div className={SECTION}>{isAir ? '4 · Câmera' : '5 · Câmera'}</div>
              <label className="flex items-center gap-2 text-xs mb-1">
                <input type="checkbox" checked={createCamera} onChange={(e) => setCreateCamera(e.target.checked)} data-testid="vehicle-camera" />
                Criar câmera de perseguição
              </label>
              <label className={`flex items-center gap-2 text-xs ${createCamera ? '' : 'opacity-40'}`}>
                <input type="checkbox" disabled={!createCamera} checked={cameraActive} onChange={(e) => setCameraActive(e.target.checked)} data-testid="vehicle-camera-active" />
                Esta é a câmera ativa
              </label>
              <p className="text-[10px] text-[#8b97a8] mt-1">Cria um nó Camera separado ("Third Person Camera" seguindo {isAir ? 'a aeronave, com Follow Target Rotation = full' : 'o veículo'}). {isAir ? 'A aeronave' : 'O veículo'} não controla a câmera.</p>
            </div>
          )}

          {/* 6. Entrada (somente leitura) */}
          <div>
            <div className={SECTION}>{manual ? 'Entrada' : isAir ? '5 · Entrada' : '6 · Entrada'} (somente leitura)</div>
            <div className="grid grid-cols-5 gap-2" data-testid="vehicle-input-summary">
              {inputSummary.map((i) => (
                <div key={i.action} className="bg-[#141822] border border-[#2c3345] rounded px-2 py-1">
                  <div className="text-[10px] font-mono text-[#dfe4ec]">{i.action}</div>
                  <div className={`text-[10px] ${i.bindings.length ? 'text-[#8b97a8]' : 'text-rose-300'}`}>{i.bindings.length ? i.bindings.slice(0, 2).join(' · ') : 'sem binding'}</div>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between mt-1.5">
              <p className={`text-[10px] ${missingInput.length ? 'text-amber-300' : 'text-[#68768e]'}`}>
                {missingInput.length ? `Faltam no Input Map do projeto: ${missingInput.join(', ')}. Use "Preset: ${isAir ? 'Voo' : 'Veículo'}" no Input Map.` : 'As ações vêm do Input Map do projeto; o diálogo não cria ações próprias.'}
              </p>
              <button type="button" onClick={() => setIsProjectSettingsOpen(true)} className="text-[10px] text-sky-300 hover:text-sky-200 underline shrink-0 ml-2" data-testid="vehicle-open-input-map">
                Abrir Input Map
              </button>
            </div>
          </div>

          {missing && (
            <div role="alert" className="border border-amber-500/40 bg-amber-500/10 rounded px-3 py-2 text-xs text-amber-200" data-testid="vehicle-missing-wheels">
              Você apagou à mão rodas geradas por este veículo: <strong>{missing.map(ROLE_LABEL).join(', ')}</strong>. Recriar?
              <div className="flex gap-2 mt-2">
                <button type="button" onClick={() => confirm({ recreateMissing: true })} className="px-2.5 py-1 rounded bg-[#4982ea] hover:bg-[#3b71d4] text-white" data-testid="vehicle-recreate">
                  Recriar
                </button>
                <button type="button" onClick={() => confirm({ skipMissing: true })} className="px-2.5 py-1 rounded bg-[#272e3d] hover:bg-[#323b4e] text-[#c2cbdb]" data-testid="vehicle-skip-missing">
                  Não recriar
                </button>
              </div>
            </div>
          )}
          {error && (
            <p role="alert" className="text-rose-300 text-xs" data-testid="vehicle-error">
              {error}
            </p>
          )}
        </div>

        <div className="px-5 py-3 flex justify-end gap-2 border-t border-[#242b3b] shrink-0">
          <button type="button" onClick={close} className="px-3 py-1.5 rounded text-xs bg-[#272e3d] hover:bg-[#323b4e] text-[#c2cbdb]">
            Cancel
          </button>
          <button
            type="button"
            onClick={() => confirm()}
            disabled={!valid || (isEdit && !editingNode) || (manual && !hasController)}
            data-testid="vehicle-dialog-ok"
            className="px-3 py-1.5 rounded text-xs bg-[#4982ea] hover:bg-[#3b71d4] text-white disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {isEdit ? 'Aplicar ao nó' : 'Criar'}
          </button>
        </div>
      </div>
    </div>
  );
};
