import React, { useMemo, useState } from 'react';
import { Trees } from 'lucide-react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import type { GameNode } from '../../types/node';
import { distributeVegetation } from '../../core/vegetation/distributeVegetation';
import { listTreeSources } from '../../core/vegetation/treeSources';
import { SCATTER_DEFAULTS, readScatterParams } from '../../core/vegetation/scatter';

/**
 * AIS-51d — aba **Vegetação** do Editor de Terreno. Usa a MESMA função de distribuição do Editor de Árvore e do arrastar-e-soltar
 * de Prefab (`distributeVegetation`): cria UM nó `Vegetation` filho do terreno (seed + parâmetros), um Ctrl+Z desfaz.
 * Fonte: nó de árvore do editor ou Prefab de árvore. Mesh/modelo arbitrário continua "em breve" (decisão 14).
 */
export const TerrainVegetationTab: React.FC<{ terrain: GameNode | undefined; onDone: () => void }> = ({ terrain, onDone }) => {
  const { activeScene, project, addNode, addLog } = useEditor();
  const setIsTreeEditorOpen = useEditorStore((s) => s.setIsTreeEditorOpen);
  const sources = useMemo(() => listTreeSources(activeScene.nodes as any, project.files as any), [activeScene.nodes, project.files]);
  const [sourceKey, setSourceKey] = useState<string>('');
  const [draft, setDraft] = useState({ ...SCATTER_DEFAULTS });
  const set = (key: keyof typeof SCATTER_DEFAULTS, value: number) => setDraft((d) => ({ ...d, [key]: value }));

  const source = sources.find((s) => s.key === sourceKey) ?? sources[0];
  const params = readScatterParams(draft);

  const num = (label: string, key: keyof typeof SCATTER_DEFAULTS, min: number, max: number, step: number) => (
    <label className="flex flex-col gap-1 text-[#8b97a8]">
      <span>{label}</span>
      <input
        type="number"
        min={min}
        max={max}
        step={step}
        value={draft[key]}
        onChange={(e) => set(key, parseFloat(e.target.value) || 0)}
        className="px-2 py-1 bg-[#171b24] border border-[#2c3345] rounded text-white"
        aria-label={label}
        data-testid={`veg-${key}`}
      />
    </label>
  );

  const handleDistribute = () => {
    if (!terrain || !source) return;
    const node = distributeVegetation({ terrainId: terrain.id, treeProps: source.props, params, name: `Vegetation_${source.label.replace(/^(Nó|Prefab): /, '')}` }, addNode);
    addLog('log', `Vegetação distribuída em "${terrain.name}" (${node.name}, ${params.count} árvores, seed ${params.seed}).`);
    onDone();
  };

  return (
    <div className="space-y-4" data-testid="terrain-vegetation-tab">
      <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-[#2c3345]">
          <Trees className="w-4 h-4 text-emerald-400" />
          <div>
            <div className="font-semibold text-white">Vegetação</div>
            <div className="text-[10px] text-[#8b97a8]">Árvores por InstancedMesh sobre o relevo; mesma seed = mesmo resultado. Um Ctrl+Z desfaz tudo.</div>
          </div>
        </div>

        {!terrain && <div className="text-amber-300 text-[11px]" role="status">Crie ou selecione um Terrain para distribuir vegetação.</div>}

        {terrain && sources.length === 0 && (
          <div className="text-[11px] text-[#b8c4d6] space-y-2" role="status" data-testid="veg-no-source">
            <div>Nenhuma árvore do editor no projeto. Crie uma no Editor de Árvore (ou salve um Prefab de árvore) para distribuí-la.</div>
            <button onClick={() => { onDone(); setIsTreeEditorOpen(true); }} className="px-3 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec]">
              Abrir Editor de Árvore...
            </button>
          </div>
        )}

        {terrain && sources.length > 0 && (
          <>
            <label className="flex flex-col gap-1 text-[#8b97a8]">
              <span>Árvore (nó ou Prefab)</span>
              <select value={source?.key ?? ''} onChange={(e) => setSourceKey(e.target.value)} className="px-2 py-1.5 bg-[#171b24] border border-[#2c3345] rounded text-white" aria-label="Árvore" data-testid="veg-source">
                {sources.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
              </select>
              <span className="text-[10px] text-[#68768e]">Mesh/modelo arbitrário: em breve.</span>
            </label>
            <div className="grid grid-cols-3 gap-3">
              {num('Quantidade', 'count', 1, 2000, 1)}
              {num('Seed', 'seed', -999999, 999999, 1)}
              {num('Variações', 'variants', 1, 6, 1)}
              {num('Escala mín.', 'scaleMin', 0.05, 20, 0.05)}
              {num('Escala máx.', 'scaleMax', 0.05, 20, 0.05)}
              {num('Inclinação máx. (°)', 'maxSlope', 0, 90, 1)}
              {num('Altitude mín. (0–1)', 'altitudeMin', 0, 1, 0.05)}
              {num('Altitude máx. (0–1)', 'altitudeMax', 0, 1, 0.05)}
              {num('Espaçamento (m)', 'minSpacing', 0, 1000, 0.5)}
              {num('Margem (m)', 'margin', 0, 1000, 0.5)}
            </div>
            <div className="flex justify-end">
              <button onClick={handleDistribute} data-testid="veg-distribute" className="px-4 py-1.5 rounded bg-[#4982ea] hover:bg-[#3b6ecc] text-white font-medium shadow-md transition-colors">
                Distribuir em "{terrain.name}"
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
