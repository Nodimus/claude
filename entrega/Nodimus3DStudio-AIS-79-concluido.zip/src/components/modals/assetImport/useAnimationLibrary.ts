/**
 * AIS-37 — estado da aba Animation Player: biblioteca de clipes (embutidos + arquivos extras só de animação), compatibilidade
 * por cobertura de ossos, e o player do preview (`ClipPlayer` sobre o modelo carregado). Rascunho de sessão: nada daqui toca o
 * documento até o Importar (`importModelAsset` grava o rig com `clips` por referência e o nó nasce Animado).
 * Amostragem/mixer/retarget vêm de `runtime/skeletalAnimation.ts` (um só módulo, também usado pelo Play).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ModelObjectHandle } from '../../../core/models/createModelObject';
import { loadModel } from '../../../core/models/modelLoader';
import { ClipPlayer, boneLocalPositions, clipFromLike, likeFromClip, type PlayerSnapshot } from '../../../core/models/clipPlayer';
import { isModelExt, type LoadedModel, type ModelExt } from '../../../core/models/types';
import { acceptedClips, buildLibrary, prepareClip, type ClipCandidate, type LibraryClip } from '../../../core/modelImport/animationLibrary';
import { extOf } from '../../../core/modelImport/importPlan';
import type { BoneMap, ClipLike } from '../../../runtime/skeletalAnimation';

export interface ExtraAnimationFile {
  name: string;
  ext: ModelExt;
  bytes: ArrayBuffer;
  clips: ClipLike[];
  /** Posição local de cada osso do arquivo no bind (escala do `Hips` entre unidades e eixo vertical do in-place). */
  bonePositions: Record<string, [number, number, number]>;
}

export interface AnimationLibraryInput {
  loaded: LoadedModel | null;
  handle: ModelObjectHandle | null;
  /** Aba ativa: o player só anima o preview enquanto a aba Animation Player está aberta. */
  active: boolean;
  boneNames: readonly string[];
  rigMap: BoneMap;
  humanoid: boolean;
}

interface LibraryOverride {
  accepted?: boolean;
  loop?: boolean;
  inPlace?: boolean;
}

const EMPTY_SNAPSHOT: PlayerSnapshot = { clip: null, time: 0, duration: 0, playing: false, speed: 1, loop: true, fading: false };

export function useAnimationLibrary({ loaded, handle, active, boneNames, rigMap, humanoid }: AnimationLibraryInput) {
  const [extraFiles, setExtraFiles] = useState<ExtraAnimationFile[]>([]);
  const [overrides, setOverrides] = useState<Record<string, LibraryOverride>>({});
  const [notice, setNotice] = useState<string | null>(null);
  const [snapshot, setSnapshot] = useState<PlayerSnapshot>(EMPTY_SNAPSHOT);
  const playerRef = useRef<ClipPlayer | null>(null);
  const lastClipRef = useRef<string | null>(null);

  // novo modelo = biblioteca nova
  useEffect(() => {
    setExtraFiles([]);
    setOverrides({});
    setNotice(null);
  }, [loaded]);

  const candidates = useMemo<ClipCandidate[]>(() => {
    const embedded = (loaded?.animations ?? []).map((a): ClipCandidate => ({ sourceKind: 'embedded', clip: likeFromClip(a) }));
    const files = extraFiles.flatMap((f) => f.clips.map((clip): ClipCandidate => ({ sourceKind: 'file', fileName: f.name, clip })));
    return [...embedded, ...files];
  }, [loaded, extraFiles]);

  const baseLibrary = useMemo(() => buildLibrary(candidates, { modelBones: boneNames, humanoidMap: humanoid ? rigMap : null }), [candidates, boneNames, rigMap, humanoid]);

  const library = useMemo<LibraryClip[]>(
    () =>
      baseLibrary.map((c) => {
        const o = overrides[c.id];
        return o ? { ...c, accepted: o.accepted ?? c.accepted, loop: o.loop ?? c.loop, inPlace: o.inPlace ?? c.inPlace } : c;
      }),
    [baseLibrary, overrides]
  );

  // anim.incompatible_skeleton / anim.duplicate_name são publicados pelo scanner do Quiz (AIS-38), junto dos demais achados

  const patchClip = useCallback((id: string, patch: LibraryOverride) => setOverrides((o) => ({ ...o, [id]: { ...o[id], ...patch } })), []);

  const addFiles = useCallback(
    async (files: readonly File[]) => {
      if (!loaded) return;
      const added: ExtraAnimationFile[] = [];
      const problems: string[] = [];
      for (const file of files) {
        const ext = extOf(file.name);
        if (!isModelExt(ext)) {
          problems.push(`${file.name}: extensão .${ext} não suportada.`);
          continue;
        }
        if (extraFiles.some((f) => f.name === file.name) || added.some((f) => f.name === file.name)) {
          problems.push(`${file.name}: arquivo já está na biblioteca.`);
          continue;
        }
        try {
          const bytes = await file.arrayBuffer();
          const model = await loadModel({ bytes, ext: ext as ModelExt, name: file.name, allowAnimationOnly: true });
          if (model.animations.length === 0) {
            problems.push(`${file.name}: o arquivo não traz animações.`);
            continue;
          }
          added.push({ name: file.name, ext: ext as ModelExt, bytes, clips: model.animations.map(likeFromClip), bonePositions: boneLocalPositions(model.root) });
        } catch (error) {
          problems.push(`${file.name}: ${error instanceof Error ? error.message : String(error)}`);
        }
      }
      if (added.length > 0) setExtraFiles((list) => [...list, ...added]);
      setNotice(problems.length > 0 ? problems.join(' ') : null);
    },
    [loaded, extraFiles]
  );

  const removeFile = useCallback((name: string) => setExtraFiles((list) => list.filter((f) => f.name !== name)), []);

  // Clipes do preview: aceitos, retargetados quando vêm de OUTRO esqueleto humanoide, e in-place quando marcados
  const targetBonePositions = useMemo(() => (loaded ? boneLocalPositions(loaded.root) : {}), [loaded]);
  const previewClips = useMemo(() => {
    const out: { key: string; clip: ReturnType<typeof clipFromLike> }[] = [];
    library.forEach((c, i) => {
      if (!c.accepted) return;
      const cand = candidates[i];
      // escala do Hips entre unidades (cm × m), trilhas sem osso no modelo descartadas e in-place: regra pura em animationLibrary
      const prepared = prepareClip({ ...cand.clip, name: c.name }, cand.sourceKind, c.inPlace, {
        humanoid,
        rigMap,
        modelBones: boneNames,
        targetBonePositions,
        sourceBonePositions: extraFiles.find((f) => f.name === cand.fileName)?.bonePositions,
      });
      out.push({ key: `${c.id}|${c.inPlace}`, clip: clipFromLike(prepared.clip) });
    });
    return out;
  }, [library, candidates, humanoid, rigMap, boneNames, targetBonePositions, extraFiles]);

  const previewKey = previewClips.map((p) => p.key).join(';');

  // Player: só com a aba aberta e o modelo pronto; ao sair, o esqueleto volta à pose de bind (dispose)
  useEffect(() => {
    if (!active || !handle || !loaded || previewClips.length === 0) {
      setSnapshot(EMPTY_SNAPSHOT);
      return;
    }
    const player = new ClipPlayer(handle.object, previewClips.map((p) => p.clip), setSnapshot);
    if (lastClipRef.current && previewClips.some((p) => p.clip.name === lastClipRef.current)) player.mixer.select(lastClipRef.current);
    playerRef.current = player;
    player.refresh();
    return () => {
      lastClipRef.current = player.snapshot().clip;
      player.dispose();
      if (playerRef.current === player) playerRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, handle, loaded, previewKey]);

  const act = useCallback((fn: (p: ClipPlayer) => void) => {
    const player = playerRef.current;
    if (!player) return;
    fn(player);
    player.refresh();
  }, []);

  const accepted = useMemo(() => acceptedClips(library), [library]);

  return {
    library,
    accepted,
    extraFiles,
    notice,
    snapshot,
    hasPlayer: previewClips.length > 0,
    patchClip,
    addFiles,
    removeFile,
    toggle: () => act((p) => p.mixer.toggle()),
    setSpeed: (v: number) => act((p) => p.mixer.setSpeed(v)),
    setLoop: (v: boolean) => act((p) => p.mixer.setLoop(v)),
    seek: (t: number) => act((p) => p.mixer.seek(t)),
    stepFrame: (d: number) => act((p) => p.mixer.stepFrame(d)),
    select: (name: string) => act((p) => p.mixer.select(name)),
    crossFadeTo: (name: string, seconds: number) => act((p) => p.mixer.crossFadeTo(name, seconds)),
    /** Arquivos extras que a importação precisa gravar (só os de clipes aceitos entram — o filtro é do `importModelAsset`). */
    importFiles: extraFiles.map((f) => ({ name: f.name, bytes: f.bytes })),
  };
}

export type AnimationLibrary = ReturnType<typeof useAnimationLibrary>;
