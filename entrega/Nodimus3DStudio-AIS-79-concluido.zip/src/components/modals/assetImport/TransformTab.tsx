import React, { useEffect, useState } from 'react';
import { AlertTriangle, Crosshair, Magnet, Move, Maximize, RotateCcw, RotateCw, User, ArrowUpFromLine } from 'lucide-react';
import { rotate90, type LengthUnit, type PivotPreset } from '../../../core/modelImport/calibration';
import type { ModelImportSession } from './useModelImportSession';

const PIVOT_BUTTONS: { id: PivotPreset; label: string }[] = [
  { id: 'bottom', label: 'Pés / Base (Y=0)' },
  { id: 'center', label: 'Centróide (Meio)' },
  { id: 'top', label: 'Topo / Teto' },
  { id: 'custom', label: 'Personalizado' },
];

const SCALE_PRESETS: { value: number; label: string }[] = [
  { value: 0.1, label: '0.1x' },
  { value: 1.0, label: '1.0x (1:1)' },
  { value: 2.0, label: '2.0x' },
];

const UNITS: { id: LengthUnit; label: string; title: string }[] = [
  { id: 'm', label: 'm', title: 'O modelo já está em metros (×1)' },
  { id: 'cm', label: 'cm → m', title: 'O modelo foi feito em centímetros (×0.01)' },
  { id: 'mm', label: 'mm → m', title: 'O modelo foi feito em milímetros (×0.001)' },
  { id: 'in', label: 'pol → m', title: 'O modelo foi feito em polegadas (×0.0254)' },
];

const GIZMO_MODES: { id: 'translate' | 'rotate' | 'scale'; label: string; icon: React.ReactNode }[] = [
  { id: 'translate', label: 'Mover', icon: <Move className="w-3 h-3" /> },
  { id: 'rotate', label: 'Rotacionar', icon: <RotateCw className="w-3 h-3" /> },
  { id: 'scale', label: 'Escalar', icon: <Maximize className="w-3 h-3" /> },
];

const AXES: { id: 'x' | 'y' | 'z'; label: string; color: string; text: string }[] = [
  { id: 'x', label: 'Eixo X', color: 'text-red-400', text: 'text-red-400' },
  { id: 'y', label: 'Eixo Y', color: 'text-green-400', text: 'text-green-400' },
  { id: 'z', label: 'Eixo Z', color: 'text-blue-400', text: 'text-blue-400' },
];

const POSITIONS: { id: 'x' | 'y' | 'z'; label: string; min: number; max: number; accent: string; text: string }[] = [
  { id: 'x', label: 'Posição X:', min: -3, max: 3, accent: 'accent-red-500', text: 'text-red-400' },
  { id: 'y', label: 'Posição Y (Elevação):', min: -2, max: 3, accent: 'accent-green-500', text: 'text-green-400' },
  { id: 'z', label: 'Posição Z:', min: -3, max: 3, accent: 'accent-blue-500', text: 'text-blue-400' },
];

const CARD = 'space-y-2 bg-[#1b2230] p-3 rounded-lg border border-[#273347]';
const BTN = 'bg-[#222a3b] hover:bg-[#2b354a] border border-[#2e3b52] text-[#93a1b8]';
const ACTIVE = 'bg-blue-600/30 border-blue-500 text-blue-300 font-bold';

/** Campo numérico com rascunho textual: só grava valor finito > 0 (Enter/blur); vírgula decimal aceita. */
const PositiveNumberField: React.FC<{ value: number; label: string; onCommit(v: number): void; width?: string }> = ({ value, label, onCommit, width = 'w-20' }) => {
  const [text, setText] = useState<string | null>(null);
  useEffect(() => setText(null), [value]);
  const commit = () => {
    if (text === null) return;
    const n = Number(text.trim().replace(',', '.'));
    if (Number.isFinite(n) && n > 0) onCommit(n);
    setText(null);
  };
  return (
    <input
      type="text"
      inputMode="decimal"
      aria-label={label}
      value={text ?? String(value)}
      onChange={(e) => setText(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === 'Enter') commit();
        else if (e.key === 'Escape') setText(null);
      }}
      className={`${width} bg-[#141820] text-xs text-right font-mono text-[#dfe4ec] px-1.5 py-0.5 rounded border border-[#2c3345] focus:border-blue-500 outline-none`}
    />
  );
};

/** Aba 1 — Transform & Gizmo (AIS-33 casca; AIS-34: calibração de 1 clique, pivô, unidades, gizmo RGB e escala por eixo). */
export const TransformTab: React.FC<{ session: ModelImportSession }> = ({ session: s }) => {
  const { draft, patchDraft } = s;
  const hasModel = !!s.stats?.heightM;
  const heightM = s.stats?.heightM != null ? s.stats.heightM * draft.scale : null;

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between border-b border-[#252f42] pb-2">
        <div className="flex items-center gap-2">
          <Move className="w-4 h-4 text-blue-400" />
          <h3 className="font-bold text-sm text-white">Configurar Gizmo & Posição Ideal</h3>
        </div>
        <button onClick={s.resetAll} className="text-[11px] text-blue-400 hover:underline flex items-center gap-1" title="Volta tudo ao valor inicial">
          <RotateCcw className="w-3 h-3" /> Resetar
        </button>
      </div>

      {/* Calibração de 1 clique (funções puras e idempotentes) */}
      <div className={CARD}>
        <div className="flex justify-between items-center">
          <label className="text-[11px] font-bold text-white uppercase tracking-wider">Calibração em 1 clique</label>
          <span className="font-mono text-emerald-400 text-[11px]">{heightM != null ? `${heightM.toFixed(2)} m de altura` : '—'}</span>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            onClick={s.applyAutoCenter}
            disabled={!hasModel}
            title={hasModel ? 'Centro da caixa em X=0, Z=0 (sem mexer na altura)' : 'Carregue um modelo'}
            className={`px-2 py-1.5 rounded text-[11px] font-medium border flex items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed ${draft.centerXZ ? ACTIVE : BTN}`}
          >
            <Crosshair className="w-3 h-3 text-blue-400" />
            <span>Auto Centralizar (X, Z)</span>
          </button>
          <button
            onClick={s.applySnapToFloor}
            disabled={!hasModel}
            title={hasModel ? 'Base da caixa em Y=0' : 'Carregue um modelo'}
            className={`px-2 py-1.5 rounded text-[11px] font-medium border flex items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed ${draft.pivot === 'bottom' ? ACTIVE : BTN}`}
          >
            <Magnet className="w-3 h-3 text-green-400" />
            <span>Snap ao Chão (Y=0)</span>
          </button>
          <button
            onClick={s.applyZUp}
            disabled={!hasModel}
            title={hasModel ? 'Gira −90° em X (Blender / 3ds Max → Y-Up); a caixa é recalculada' : 'Carregue um modelo'}
            className={`px-2 py-1.5 rounded text-[11px] font-medium border flex items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed ${draft.zUpFlipped ? ACTIVE : BTN}`}
          >
            <ArrowUpFromLine className="w-3 h-3 text-amber-400" />
            <span>Z-Up → Y-Up</span>
          </button>
          <button
            onClick={s.normalizeToHuman}
            disabled={!hasModel}
            title={hasModel ? 'scale = 1.80 m ÷ altura da caixa já calibrada' : 'Carregue um modelo para calibrar a altura'}
            className={`px-2 py-1.5 rounded text-[11px] font-medium border flex items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed ${BTN}`}
          >
            <User className="w-3 h-3 text-emerald-400" />
            <span>Escala Humana (1.80 m)</span>
          </button>
        </div>
        {s.notice && (
          <div role="status" className="flex items-start gap-1.5 text-[10px] text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded px-2 py-1.5">
            <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
            <span>{s.notice}</span>
          </div>
        )}
      </div>

      {/* Gizmo RGB (edita só o rascunho) */}
      <div className={CARD}>
        <label className="text-[11px] font-bold text-white uppercase tracking-wider block">Gizmo no Preview</label>
        <div className="grid grid-cols-3 gap-1.5" role="group" aria-label="Modo do gizmo">
          {GIZMO_MODES.map((m) => (
            <button
              key={m.id}
              onClick={() => s.setGizmoMode(m.id)}
              aria-pressed={s.gizmoMode === m.id}
              disabled={!hasModel}
              title={hasModel ? 'Arraste as setas coloridas no preview: X vermelho, Y verde, Z azul' : 'Carregue um modelo'}
              className={`px-2 py-1.5 rounded text-[11px] font-medium border flex items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed ${s.gizmoMode === m.id ? ACTIVE : BTN}`}
            >
              {m.icon}
              <span>{m.label}</span>
            </button>
          ))}
        </div>
        <p className="text-[10px] text-[#8695ad]">O gizmo ajusta o rascunho desta janela; o Undo do documento só existe depois de importar.</p>
      </div>

      {/* Pivot / Gizmo Placement */}
      <div className={CARD}>
        <label className="text-[11px] font-bold text-white uppercase tracking-wider block">Ponto Pivô (Origem do Gizmo)</label>
        <p className="text-[10px] text-[#8695ad]">Define onde o objeto será agarrado e rotacionado ao ser colocado no chão da cena.</p>

        <div className="grid grid-cols-2 gap-1.5 pt-1">
          {PIVOT_BUTTONS.map((p) => (
            <button
              key={p.id}
              onClick={() => patchDraft({ pivot: p.id })}
              className={`px-2 py-1.5 rounded text-[11px] font-medium border text-center transition-all ${draft.pivot === p.id ? ACTIVE : 'bg-[#222a3b] border-[#2e3b52] text-[#93a1b8] hover:bg-[#2b354a]'}`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {draft.pivot === 'custom' && (
          <div className="pt-2 space-y-1">
            <div className="flex justify-between text-[11px]">
              <span className="text-[#8695ad]">Offset do Pivô Y:</span>
              <span className="font-mono text-white">{draft.pivotOffsetY.toFixed(2)}m</span>
            </div>
            <input
              type="range"
              min={-2}
              max={2}
              step={0.05}
              value={draft.pivotOffsetY}
              onChange={(e) => patchDraft({ pivotOffsetY: parseFloat(e.target.value) })}
              aria-label="Offset do pivô Y"
              className="w-full accent-blue-500 h-1 bg-[#253042] rounded"
            />
          </div>
        )}
      </div>

      {/* Scale Calibration */}
      <div className={CARD}>
        <div className="flex justify-between items-center">
          <label className="text-[11px] font-bold text-white uppercase tracking-wider">Escala & Dimensões Ideais</label>
          <PositiveNumberField value={draft.scale} label="Escala uniforme" onCommit={(v) => patchDraft({ scale: v })} />
        </div>

        <input
          type="range"
          min={0.1}
          max={5.0}
          step={0.05}
          value={Math.min(5, Math.max(0.1, draft.scale))}
          onChange={(e) => patchDraft({ scale: parseFloat(e.target.value) })}
          aria-label="Escala"
          className="w-full accent-emerald-500 h-1.5 bg-[#253042] rounded"
        />

        <div className="flex items-center gap-1.5 pt-1">
          {SCALE_PRESETS.map((p) => (
            <button key={p.value} onClick={() => patchDraft({ scale: p.value })} className={`flex-1 py-1 rounded ${BTN} text-[10px]`}>
              {p.label}
            </button>
          ))}
        </div>

        <div className="pt-1 space-y-1">
          <div className="text-[10px] text-[#8695ad]">Unidade do arquivo (atalho de escala):</div>
          <div className="grid grid-cols-4 gap-1.5">
            {UNITS.map((u) => (
              <button key={u.id} onClick={() => s.applyUnit(u.id)} title={u.title} className={`py-1 rounded ${BTN} text-[10px]`}>
                {u.label}
              </button>
            ))}
          </div>
        </div>

        <div className="pt-1 space-y-1">
          <div className="text-[10px] text-[#8695ad]">Escala por eixo (avançado — multiplica a escala):</div>
          <div className="grid grid-cols-3 gap-1.5">
            {AXES.map((a) => (
              <label key={a.id} className="flex items-center gap-1 bg-[#141820] rounded border border-[#2c3345] pl-1.5 overflow-hidden">
                <span className={`font-bold text-[10px] uppercase ${a.text}`}>{a.id}</span>
                <PositiveNumberField value={draft.scaleAxes[a.id]} label={`Escala ${a.id.toUpperCase()}`} onCommit={(v) => s.setScaleAxis(a.id, v)} width="w-full" />
              </label>
            ))}
          </div>
          {s.warnings.map((w) => (
            <div key={w.code} role="status" className="flex items-start gap-1.5 text-[10px] text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded px-2 py-1.5">
              <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
              <span>
                <span className="font-mono">[{w.code}]</span> {w.message}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Frente do modelo: glTF/Mixamo olham para +Z e o motor anda para -Z; o ajuste vive no modelo (os Behaviors giram o nó) */}
      <div className={CARD}>
        <label className="text-[11px] font-bold text-white uppercase tracking-wider block">Frente do Modelo</label>
        <div className="text-[10px] text-[#8695ad]">Gire até o personagem olhar para onde ele anda. 180° é o padrão para glTF/Mixamo (frente em +Z).</div>
        <div className="grid grid-cols-4 gap-1.5">
          {[0, 90, 180, 270].map((deg) => (
            <button
              key={deg}
              type="button"
              aria-pressed={draft.modelYawDeg === deg}
              onClick={() => patchDraft((d) => ({ ...d, modelYawDeg: deg }))}
              className={`px-2 py-1.5 rounded text-[11px] ${draft.modelYawDeg === deg ? 'bg-sky-600 text-white' : BTN}`}
            >
              {deg}°
            </button>
          ))}
        </div>
      </div>

      {/* Quick 90° Rotations */}
      <div className={CARD}>
        <label className="text-[11px] font-bold text-white uppercase tracking-wider block">Girar para Posição Ideal (+90°)</label>
        <div className="grid grid-cols-3 gap-1.5">
          {AXES.map((a) => (
            <button key={a.id} onClick={() => patchDraft((d) => rotate90(d, a.id))} className={`px-2 py-1.5 rounded ${BTN} text-[11px] flex items-center justify-center gap-1`}>
              <RotateCw className={`w-3 h-3 ${a.color}`} />
              <span>
                {a.label} ({draft.rotationDeg[a.id]}°)
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Fine Manual Transform Sliders */}
      <div className="space-y-3 bg-[#1b2230] p-3 rounded-lg border border-[#273347]">
        <label className="text-[11px] font-bold text-white uppercase tracking-wider block">Ajuste Fino de Translação (Metros)</label>
        {POSITIONS.map((p) => (
          <div key={p.id} className="space-y-1">
            <div className="flex justify-between text-[10px] text-[#8695ad]">
              <span className={`${p.text} font-bold`}>{p.label}</span>
              <span className="font-mono text-white">{draft.position[p.id].toFixed(2)}m</span>
            </div>
            <input
              type="range"
              min={p.min}
              max={p.max}
              step={0.05}
              value={Math.min(p.max, Math.max(p.min, draft.position[p.id]))}
              onChange={(e) => patchDraft((d) => ({ ...d, position: { ...d.position, [p.id]: parseFloat(e.target.value) } }))}
              aria-label={`Posição ${p.id.toUpperCase()}`}
              className={`w-full ${p.accent} h-1 bg-[#253042] rounded`}
            />
          </div>
        ))}
      </div>
    </div>
  );
};
