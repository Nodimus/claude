import React, { useRef, useState } from 'react';
import { AlertTriangle, ChevronLeft, ChevronRight, FilePlus2, Pause, Play, Sparkles, X } from 'lucide-react';
import { COVERAGE_THRESHOLD, type LibraryClip } from '../../../core/modelImport/animationLibrary';
import { MAX_SPEED, MIN_SPEED, PREVIEW_FPS, frameCount, timeToFrame } from '../../../runtime/skeletalAnimation';
import type { ModelImportSession } from './useModelImportSession';
import { HEADER, NOTE, NoModel } from './tabParts';

const CARD = 'space-y-2 bg-[#1b2230] p-3 rounded-lg border border-[#273347]';
const LABEL = 'text-[11px] font-bold text-white uppercase tracking-wider block';
const BTN = 'bg-[#222a3b] hover:bg-[#2b354a] border border-[#2e3b52] text-[#93a1b8] disabled:opacity-50 disabled:cursor-not-allowed';
const SPEEDS = [0.25, 0.5, 1, 1.5, 2];

/** Aba 4 — Animation Player (AIS-37): biblioteca de clipes (embutidos + arquivos só de animação) e player com scrub, velocidade, loop e crossfade. */
export const AnimationTab: React.FC<{ session: ModelImportSession }> = ({ session: s }) => {
  const a = s.animation;
  const model = s.loaded;
  const picker = useRef<HTMLInputElement>(null);
  const [fadeTo, setFadeTo] = useState('');
  const [fadeSeconds, setFadeSeconds] = useState(0.3);

  const snap = a.snapshot;
  const frames = frameCount(snap.duration);
  const frame = timeToFrame(snap.time);
  const targets = a.accepted.filter((c) => c.name !== snap.clip);
  const fadeTarget = targets.some((c) => c.name === fadeTo) ? fadeTo : targets[0]?.name ?? '';

  return (
    <div className="p-4 space-y-4">
      <div className={HEADER}>
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <h3 className="font-bold text-sm text-white">Animation Player</h3>
        </div>
        <span className="text-[10px] text-[#8695ad]" data-testid="anim-counts">
          {a.accepted.length}/{a.library.length} clipe(s) na biblioteca
        </span>
      </div>

      {s.isReedit && (
        <div className={NOTE} role="status" data-testid="anim-reedit-note">
          <b className="text-white">Editar importação:</b> a biblioteca de clipes não é reeditada aqui. Os clipes já importados são mantidos como estão; use esta aba só para pré-visualizar.
        </div>
      )}

      {!model ? (
        <NoModel />
      ) : (
        <>
          <div className={CARD}>
            <div className="flex items-center justify-between">
              <label className={LABEL}>Biblioteca de Clipes</label>
              <button onClick={() => picker.current?.click()} className={`px-2 py-1 rounded text-[11px] border flex items-center gap-1 ${BTN}`} title="Arquivos .fbx/.glb/.gltf/.dae só de animação (ex.: Walk.fbx sem malha)">
                <FilePlus2 className="w-3 h-3 text-emerald-400" /> Adicionar animações…
              </button>
              <input
                ref={picker}
                type="file"
                multiple
                accept=".fbx,.glb,.gltf,.dae"
                className="hidden"
                data-testid="anim-file-input"
                onChange={(e) => {
                  const files = Array.from(e.target.files ?? []);
                  e.target.value = '';
                  if (files.length > 0) void a.addFiles(files);
                }}
              />
            </div>
            {a.library.length === 0 ? (
              <div className={NOTE} data-testid="anim-empty">
                Este modelo não traz animações. Adicione arquivos de animação ou importe o objeto como Estático.
              </div>
            ) : (
              <div className="space-y-1" role="list" aria-label="Biblioteca de clipes">
                {a.library.map((c) => (
                  <ClipRow key={c.id} clip={c} onPatch={(p) => a.patchClip(c.id, p)} />
                ))}
              </div>
            )}
            {a.extraFiles.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {a.extraFiles.map((f) => (
                  <span key={f.name} className="inline-flex items-center gap-1 bg-[#222a3b] border border-[#2e3b52] rounded px-1.5 py-0.5 text-[10px] text-[#b8c4d6]">
                    <span className="font-mono">{f.name}</span>
                    <button onClick={() => a.removeFile(f.name)} aria-label={`Remover ${f.name}`} className="text-[#8695ad] hover:text-white">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
            {a.notice && (
              <div role="status" className="flex items-start gap-1.5 text-[10px] text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded px-2 py-1.5">
                <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
                <span>{a.notice}</span>
              </div>
            )}
            <p className="text-[10px] text-[#8695ad]">
              A biblioteca guarda <b className="text-white">referências</b> (arquivo + nome do clipe), nunca keyframes: o rig <span className="font-mono">res://materials/&lt;asset&gt;_rig.json</span> lista os clipes e o objeto importado já nasce Animado, com a animação padrão escolhida no Inspector. Mínimo de {Math.round(COVERAGE_THRESHOLD * 100)}% de ossos cobertos.
            </p>
          </div>

          {a.hasPlayer && (
            <div className={CARD} data-testid="anim-player">
              <label className={LABEL}>Player</label>
              <select
                aria-label="Clipe do player"
                value={snap.clip ?? ''}
                onChange={(e) => a.select(e.target.value)}
                className="w-full bg-[#141820] text-[11px] text-[#dfe4ec] px-1.5 py-1 rounded border border-[#2c3345] outline-none focus:border-blue-500"
              >
                {a.accepted.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>

              <div className="flex items-center gap-1.5">
                <button onClick={() => a.stepFrame(-1)} aria-label="Quadro anterior" className={`p-1.5 rounded border ${BTN}`}>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <button onClick={a.toggle} aria-label={snap.playing ? 'Pausar' : 'Reproduzir'} className={`px-3 py-1.5 rounded border flex items-center gap-1 text-[11px] ${snap.playing ? 'bg-blue-600/30 border-blue-500 text-blue-300' : BTN}`}>
                  {snap.playing ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{snap.playing ? 'Pausar' : 'Reproduzir'}</span>
                </button>
                <button onClick={() => a.stepFrame(1)} aria-label="Próximo quadro" className={`p-1.5 rounded border ${BTN}`}>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
                <span className="ml-auto font-mono text-[10px] text-[#b8c4d6]" data-testid="anim-frame">
                  quadro {frame}/{frames - 1} · {snap.time.toFixed(2)}s / {snap.duration.toFixed(2)}s
                </span>
              </div>

              <input
                type="range"
                aria-label="Linha do tempo"
                min={0}
                max={Math.max(0, frames - 1)}
                step={1}
                value={Math.min(frame, frames - 1)}
                onChange={(e) => a.seek(parseInt(e.target.value, 10) / PREVIEW_FPS)}
                className="w-full accent-emerald-500 h-1.5 bg-[#253042] rounded"
              />

              <div className="flex items-center justify-between gap-2 text-[11px]">
                <label className="flex items-center gap-1.5 text-[#8695ad]">
                  Velocidade
                  <select
                    aria-label="Velocidade"
                    value={snap.speed}
                    onChange={(e) => a.setSpeed(parseFloat(e.target.value))}
                    className="bg-[#141820] text-[11px] text-[#dfe4ec] px-1 py-0.5 rounded border border-[#2c3345] outline-none"
                  >
                    {SPEEDS.filter((v) => v >= MIN_SPEED && v <= MAX_SPEED).map((v) => (
                      <option key={v} value={v}>
                        {v}×
                      </option>
                    ))}
                  </select>
                </label>
                <label className="flex items-center gap-1.5 text-white cursor-pointer">
                  <input type="checkbox" aria-label="Loop" checked={snap.loop} onChange={(e) => a.setLoop(e.target.checked)} className="rounded bg-[#232c3d] border-[#384661] text-emerald-500 focus:ring-0" />
                  Loop
                </label>
              </div>

              {targets.length > 0 && (
                <div className="flex items-center gap-1.5 pt-1 border-t border-[#273347] text-[11px]">
                  <span className="text-[#8695ad]">Crossfade →</span>
                  <select aria-label="Clipe de destino do crossfade" value={fadeTarget} onChange={(e) => setFadeTo(e.target.value)} className="flex-1 min-w-0 bg-[#141820] text-[11px] text-[#dfe4ec] px-1 py-0.5 rounded border border-[#2c3345] outline-none">
                    {targets.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                  <input
                    type="number"
                    aria-label="Duração do crossfade (s)"
                    min={0}
                    max={5}
                    step={0.1}
                    value={fadeSeconds}
                    onChange={(e) => setFadeSeconds(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-14 bg-[#141820] text-[11px] text-right font-mono text-[#dfe4ec] px-1 py-0.5 rounded border border-[#2c3345] outline-none"
                  />
                  <span className="text-[#8695ad]">s</span>
                  <button onClick={() => fadeTarget && a.crossFadeTo(fadeTarget, fadeSeconds)} disabled={!fadeTarget} className={`px-2 py-1 rounded border ${BTN}`}>
                    Aplicar
                  </button>
                </div>
              )}
            </div>
          )}
          {!a.hasPlayer && a.library.length > 0 && (
            <div className={NOTE}>Nenhum clipe está na biblioteca: aceite um clipe incompatível ou adicione outro arquivo para usar o player.</div>
          )}
        </>
      )}
    </div>
  );
};

const ClipRow: React.FC<{ clip: LibraryClip; onPatch(p: { accepted?: boolean; loop?: boolean; inPlace?: boolean }): void }> = ({ clip, onPatch }) => (
  <div role="listitem" className={`p-2 rounded-lg border text-[11px] space-y-1 ${clip.accepted ? 'bg-[#1b2230] border-[#29354a]' : 'bg-[#1b2230]/60 border-amber-500/40'}`} data-testid="anim-clip">
    <div className="flex items-center justify-between gap-2">
      <label className="flex items-center gap-1.5 min-w-0 cursor-pointer">
        <input type="checkbox" aria-label={`Incluir ${clip.name}`} checked={clip.accepted} onChange={(e) => onPatch({ accepted: e.target.checked })} className="rounded bg-[#232c3d] border-[#384661] text-emerald-500 focus:ring-0" />
        <span className="font-bold text-white truncate">{clip.name}</span>
        {clip.renamedFrom && <span className="text-[9px] text-amber-300 font-mono" title={`Nome repetido: era "${clip.renamedFrom}"`}>renomeado</span>}
      </label>
      <span className="font-mono text-[#8a98ae] shrink-0">
        {clip.duration.toFixed(2)}s · {clip.trackCount} trilha(s)
      </span>
    </div>
    <div className="flex items-center justify-between gap-2 text-[10px] text-[#8695ad]">
      <span className="truncate">
        {clip.sourceKind === 'embedded' ? 'embutido no modelo' : clip.fileName}
        {' · '}
        <span className={clip.compatible ? 'text-emerald-400' : 'text-amber-300'}>cobertura {Math.round(clip.coverage * 100)}%</span>
      </span>
      <span className="flex items-center gap-2 shrink-0">
        <label className="flex items-center gap-1 cursor-pointer text-[#b8c4d6]">
          <input type="checkbox" aria-label={`Loop de ${clip.name}`} checked={clip.loop} onChange={(e) => onPatch({ loop: e.target.checked })} className="rounded bg-[#232c3d] border-[#384661] text-emerald-500 focus:ring-0" />
          loop
        </label>
        <label className="flex items-center gap-1 cursor-pointer text-[#b8c4d6]" title="Sem deslocamento horizontal da raiz (recomendado com física)">
          <input type="checkbox" aria-label={`In-place de ${clip.name}`} checked={clip.inPlace} onChange={(e) => onPatch({ inPlace: e.target.checked })} className="rounded bg-[#232c3d] border-[#384661] text-emerald-500 focus:ring-0" />
          in-place
        </label>
      </span>
    </div>
    {!clip.compatible && (
      <div role="status" className="flex items-start gap-1.5 text-[10px] text-amber-300" data-testid="anim-incompatible">
        <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
        <span>
          <span className="font-mono">anim.incompatible_skeleton</span>: o clipe cobre menos de {Math.round(COVERAGE_THRESHOLD * 100)}% dos ossos do modelo.{' '}
          {clip.accepted ? 'Aceito manualmente.' : 'Fora da biblioteca até o aceite (marque “Incluir”).'}
        </span>
      </div>
    )}
  </div>
);
