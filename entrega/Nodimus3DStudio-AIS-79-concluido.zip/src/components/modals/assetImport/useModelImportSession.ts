/**
 * AIS-33 — estado de RASCUNHO do importador. Nada daqui toca o documento autoral até `importNow` (um Command). O modelo é
 * carregado pela MESMA `createModelObject` do editor (com um cache privado da sessão, liberado ao fechar); falha de carga
 * vira erro tipado no modal e diagnóstico no `DiagnosticService` (fase `import`).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useEditor } from '../../../core/EditorContext';
import { useEditorStore } from '../../../core/editorStore';
import { TauriBridge } from '../../../core/tauriBridge';
import { globalAuthoringModel } from '../../../core/authoring';
import { globalAssetPipeline, globalResourceRegistry } from '../../../core/resources/global';
import { globalDiagnosticService } from '../../../core/diagnostics/global';
import { deleteResource } from '../../../core/resourceDeletion';
import { globalCommandManager } from '../../../core/commandManager';
import { useAnimationLibrary } from './useAnimationLibrary';
import { createModelObject, type ModelObjectHandle, type ModelSourceBinding } from '../../../core/models/createModelObject';
import { ModelCache } from '../../../core/models/modelCache';
import { contentToBytes, resolveRelativeUri } from '../../../core/models/modelBytes';
import { isModelExt, type LoadedModel, type ModelExt } from '../../../core/models/types';
import {
  DEFAULT_TRANSFORM_DRAFT,
  autoCenter,
  calibratedBounds,
  calibrationWarnings,
  centerToOrigin,
  convertUnit,
  humanScale,
  isTransformDirty,
  modelOffsetFor,
  resetDraft,
  snapToFloor,
  zUpToYUp,
  type ImportTransformDraft,
  type LengthUnit,
  type Vec3,
} from '../../../core/modelImport/calibration';
import { applyAllFixes, importQuestions, scanImport, type ImportDraft, type ImportFinding } from '../../../core/modelImport/diagnostics';
import { contentForFile, importModelAsset, type ImportDeps } from '../../../core/modelImport/importModelAsset';
import { readImportWithCollision, writeImportWithCollision } from '../../../core/modelImport/importPrefs';
import { autoMapBones, emptyBoneMap, validateBoneMap, type BoneMap, type CanonicalBone } from '../../../runtime/skeletalAnimation';
import { buildPreviewPlan, renderMaterialImages } from '../../../core/modelImport/materialImages';
import { diagnoseMaterials, editFromInfo, editsFromModel, isEditDirty, type MaterialEdit } from '../../../core/modelImport/materials';
import {
  DEFAULT_COLLISION_OPTIONS,
  allowedShapes,
  chooseParentId,
  extOf,
  selectModelFiles,
  type CollisionOptions,
  type ImportFile,
  type PickedFile,
} from '../../../core/modelImport/importPlan';
import { requestDecision } from '../../../core/documents/decisions';
import { reeditModelAsset, type ReeditDeps } from '../../../core/modelImport/reeditModelAsset';
import { detectManualChanges, draftFromSettings, editFromManifestMaterial, isMaterialTouched } from '../../../core/modelImport/modelLifecycle';
import { parseModelImportSettings, type ModelImportSettings } from '../../../schemas/v1/modelImportSettings.schema';
import { parseModelMaterialManifest } from '../../../schemas/v1/modelMaterialManifest.schema';
import { RigConfigSchema } from '../../../schemas/v1/rig.schema';
import type { MaterialEdit as ReeditMaterialEdit } from '../../../core/modelImport/materials';
import type { ResourceRef } from '../../../types/node';
import type { ImportStatus, PreviewStats } from './ImportPreview';

export type ImportTab = 'transform' | 'texture' | 'skeleton' | 'animation' | 'quiz';

export interface LoadedFile {
  name: string;
  ext: ModelExt;
  bytes: ArrayBuffer;
  siblings: ImportFile[];
  /** Arquivo que já está em `res://` (as dependências do `.gltf` saem do projeto). */
  sourceUri?: string;
}

export interface ImportError {
  code: string;
  message: string;
}

/** AIS-38c: "Editar importação…" — o que foi restaurado do import (a base para saber o que o usuário mudou). */
interface ReeditState {
  nodeId: string;
  nodeName: string;
  uri: string;
  model: ResourceRef;
  restoredDraft: ImportTransformDraft;
  baselineEdits: ReeditMaterialEdit[];
  /** Mapeamento de ossos gravado no rig (ou `null` se o modelo não tem rig). */
  baselineBones: BoneMap | null;
}

const toBuffer = (data: string | ArrayBuffer): ArrayBuffer => (typeof data === 'string' ? (new TextEncoder().encode(data).buffer as ArrayBuffer) : data);

export function useModelImportSession() {
  const { activeScene, selectedNodeId, addNode, addLog, setIsAssetImportModalOpen, changeNodeProperties } = useEditor();
  const source = useEditorStore((s) => s.assetImportSource);

  const [tab, setTab] = useState<ImportTab>('transform');
  const [file, setFile] = useState<LoadedFile | null>(null);
  const [status, setStatus] = useState<ImportStatus>('empty');
  const [error, setError] = useState<ImportError | null>(null);
  const [draft, setDraft] = useState<ImportTransformDraft>(DEFAULT_TRANSFORM_DRAFT);
  const [collision, setCollision] = useState<CollisionOptions>(() => ({ ...DEFAULT_COLLISION_OPTIONS, enabled: readImportWithCollision() }));
  const [wireframe, setWireframe] = useState(false);
  /** AIS-35: rascunho por material do arquivo (nome → edição); nada daqui vai à cena até o Importar. */
  const [materialEdits, setMaterialEdits] = useState<MaterialEdit[]>([]);
  const [selectedMaterial, setSelectedMaterial] = useState<string | null>(null);
  /** AIS-36: mapeamento osso do arquivo → osso canônico (rascunho; vira `_rig.json` no Importar, só se humanoide). */
  const [rigMap, setRigMap] = useState<BoneMap>(() => emptyBoneMap());
  const [rigConvention, setRigConvention] = useState<'rigify' | 'generic'>('generic');
  const [skeletonOverlay, setSkeletonOverlay] = useState(true);
  const [showHuman, setShowHuman] = useState(true);
  const [showRuler, setShowRuler] = useState(true);
  const [gizmoMode, setGizmoMode] = useState<'translate' | 'rotate' | 'scale'>('translate');
  /** Aviso (não erro) da última calibração, ex.: proporção que não parece humana. */
  const [notice, setNotice] = useState<string | null>(null);
  const [humanDistance, setHumanDistance] = useState(1.2);
  const [handle, setHandle] = useState<ModelObjectHandle | null>(null);
  const [loaded, setLoaded] = useState<LoadedModel | null>(null);
  const [revision, setRevision] = useState(0);
  const [importing, setImporting] = useState(false);

  const handleRef = useRef<ModelObjectHandle | null>(null);

  // ── Carregar o modelo (bytes de verdade) quando o arquivo muda ───────────────────────────────────────────
  useEffect(() => {
    if (!file) {
      setHandle(null);
      setLoaded(null);
      return;
    }
    let cancelled = false;
    globalDiagnosticService.clear({ source: 'assetImport', phase: 'import' });
    const cache = new ModelCache(); // privado da sessão: liberado ao trocar de arquivo e ao fechar
    const uri = file.sourceUri ?? `res://__draft__/${file.name}`;
    const siblings = new Map<string, string>();
    for (const s of file.siblings) siblings.set(resolveRelativeUri(uri, s.rel), contentForFile(s.rel, s.bytes));
    const mainContent = contentForFile(file.name, file.bytes);

    const binding: ModelSourceBinding = {
      resolve: () => ({ resourceId: 'draft', uri, contentHash: `${file.name}:${file.bytes.byteLength}`, content: mainContent }),
      readFile: (u) => siblings.get(u) ?? globalAuthoringModel.getProject().files[u]?.content,
      report: (d) => {
        setError({ code: d.code, message: d.message });
        globalDiagnosticService.report({ source: 'assetImport', sourceId: file.name, severity: d.severity, phase: 'import', code: d.code, message: d.message, uri: file.sourceUri });
      },
    };

    setError(null);
    setStatus('loading');
    const created = createModelObject({ id: 'draft', type: 'mesh', path: uri }, { source: binding, cache });
    handleRef.current = created;
    setHandle(created);
    setLoaded(null);
    void created.ready.then((result) => {
      if (cancelled) return;
      if (result === 'ready') {
        setLoaded(created.loaded());
        setStatus('ready');
        setRevision((r) => r + 1);
      } else {
        setStatus('error');
      }
    });

    return () => {
      cancelled = true;
      created.release();
      cache.clear();
      if (handleRef.current === created) handleRef.current = null;
    };
  }, [file]);

  // pivô + centragem: o `modelOffset` (recalculado depois de girar/escalar) vai para dentro do titular — o preview mostra
  // exatamente o que o nó receberá
  useEffect(() => {
    handle?.setYaw(draft.modelYawDeg);
    handle?.setOffset(modelOffsetFor(draft, loaded?.bounds ?? null));
  }, [handle, loaded, draft]);

  // AIS-35: ao carregar um modelo, o rascunho de cada material = o material do arquivo
  useEffect(() => {
    const edits = loaded ? editsFromModel(loaded.materials) : [];
    setMaterialEdits(edits);
    setSelectedMaterial(edits[0]?.name ?? null);
  }, [loaded]);

  // AIS-35: pré-visualização em tempo real (a mesma regra de slots do nó); imagens procedurais/filtradas com debounce curto
  useEffect(() => {
    if (!handle || !loaded) return;
    const timer = setTimeout(() => handle.setMaterialPlan(buildPreviewPlan(loaded, materialEdits)), 60);
    return () => clearTimeout(timer);
  }, [handle, loaded, materialEdits]);

  // (AIS-38: os diagnósticos de material, rig e clipes são publicados pelo scanner do Quiz, mais abaixo)

  // AIS-36: ao carregar, detecta os 19 ossos do esqueleto real (Mixamo, Rigify, Unity, Godot)
  const boneNames = useMemo(() => loaded?.boneNames ?? [], [loaded]);
  /** Ossos para os quais o `rigMap` já foi detectado: o scanner do Quiz só roda depois (sem achado de rig transitório). */
  const [rigSyncedFor, setRigSyncedFor] = useState<readonly string[] | null>(null);
  useEffect(() => {
    const detected = autoMapBones(boneNames);
    setRigMap(detected.map);
    setRigConvention(detected.convention);
    setRigSyncedFor(boneNames);
  }, [boneNames]);

  const mappedBoneNames = useMemo(() => Object.values(rigMap).filter((n): n is string => !!n), [rigMap]);
  const rigValidation = useMemo(() => validateBoneMap(rigMap), [rigMap]);
  const rigFound = useMemo(() => Object.values(rigMap).filter(Boolean).length, [rigMap]);

  const setRigBone = useCallback((bone: CanonicalBone, fileBone: string | null) => {
    setRigMap((m) => ({ ...m, [bone]: fileBone }));
  }, []);
  const redetectRig = useCallback(() => {
    const detected = autoMapBones(boneNames);
    setRigMap(detected.map);
    setRigConvention(detected.convention);
  }, [boneNames]);

  // ── AIS-38c: "Editar importação…" restaura calibração, materiais e rig gravados; quem mexeu no que fica comparável ──
  const [reedit, setReedit] = useState<ReeditState | null>(null);
  useEffect(() => {
    if (!source?.reeditNodeId || !source.path) {
      setReedit(null);
      return;
    }
    if (!loaded) return;
    const node = globalAuthoringModel.getNode(source.reeditNodeId);
    const entry = globalResourceRegistry.getByUri(source.path);
    const model = entry ? globalResourceRegistry.makeRef(entry.resourceId) : undefined;
    if (!node || !entry || !model) {
      setError({ code: 'model.unresolved', message: 'Não foi possível reabrir a importação: o nó ou o arquivo do modelo não existe mais.' });
      return;
    }
    const settings = parseModelImportSettings(entry.importSettings);
    const restored = draftFromSettings(settings, node.properties.position);
    setDraft(restored);
    // materiais: o que o import gravou no manifesto (sobre o material do arquivo)
    const manifestUri = settings.materials ? (() => { const r = globalResourceRegistry.resolve(settings.materials as never); return r.status === 'resolved' ? r.entry.uri : null; })() : null;
    const parsed = manifestUri ? parseModelMaterialManifest(globalAuthoringModel.getProject().files[manifestUri]?.content ?? '') : null;
    const fromManifest = parsed?.ok ? parsed.manifest.materials : [];
    const baseline = editsFromModel(loaded.materials).map((edit) => {
      const saved = fromManifest.find((m) => m.name === edit.name);
      return saved ? editFromManifestMaterial(saved) : edit;
    });
    setMaterialEdits(baseline);
    setSelectedMaterial(baseline[0]?.name ?? null);
    // rig: o mapeamento gravado (se o arquivo ainda o tem)
    const rigUri = settings.rig ? (() => { const r = globalResourceRegistry.resolve(settings.rig as never); return r.status === 'resolved' ? r.entry.uri : null; })() : null;
    let rigText: unknown;
    try {
      rigText = rigUri ? JSON.parse(globalAuthoringModel.getProject().files[rigUri]?.content ?? 'null') : null;
    } catch {
      rigText = null;
    }
    const rig = rigText ? RigConfigSchema.safeParse(rigText) : null;
    if (rig?.success) setRigMap(rig.data.bones as BoneMap);
    setReedit({ nodeId: node.id, nodeName: node.name, uri: entry.uri, model, restoredDraft: restored, baselineEdits: baseline, baselineBones: rig?.success ? (rig.data.bones as BoneMap) : null });
  }, [loaded, source]);

  // AIS-37: biblioteca de clipes + player do preview (só anima com a aba Animation Player aberta)
  const animation = useAnimationLibrary({ loaded, handle, active: tab === 'animation' && status === 'ready', boneNames, rigMap, humanoid: rigValidation.humanoid });

  const patchMaterial = useCallback((name: string, patch: Partial<MaterialEdit>) => {
    setMaterialEdits((list) => list.map((e) => (e.name === name ? { ...e, ...patch } : e)));
  }, []);

  const resetMaterial = useCallback(
    (name: string) => {
      const info = loaded?.materials.find((m) => m.name === name);
      if (!info) return;
      setMaterialEdits((list) => list.map((e) => (e.name === name ? editFromInfo(info) : e)));
    },
    [loaded]
  );

  // ── AIS-38: scanner automático (Quiz) sobre os dados reais; correções editam o RASCUNHO, nunca o documento ───────
  const importDraft = useMemo<ImportDraft>(() => ({ transform: draft, collision, materials: materialEdits }), [draft, collision, materialEdits]);
  const findings = useMemo<ImportFinding[]>(
    () =>
      loaded && rigSyncedFor === boneNames
        ? scanImport({ bounds: loaded.bounds, stats: loaded.stats, materials: loaded.materials, upAxisHint: loaded.upAxisHint, draft: importDraft, boneNames, rigMap, library: animation.library })
        : [],
    [loaded, importDraft, boneNames, rigMap, rigSyncedFor, animation.library]
  );
  const questions = useMemo(() => importQuestions(findings, loaded?.bounds ?? null), [findings, loaded]);
  /** Rascunho de antes da primeira correção; "Desfazer correções" volta a ele. */
  const [preFixDraft, setPreFixDraft] = useState<ImportDraft | null>(null);
  useEffect(() => setPreFixDraft(null), [file]);

  const commitDraft = useCallback((next: ImportDraft) => {
    setNotice(null);
    setPreFixDraft((snapshot) => snapshot ?? importDraft);
    setDraft(next.transform);
    setCollision(next.collision);
    setMaterialEdits(next.materials);
  }, [importDraft]);
  const fixFinding = useCallback((f: ImportFinding) => f.fix && commitDraft(f.fix.apply(importDraft)), [commitDraft, importDraft]);
  const fixAll = useCallback(() => {
    const next = applyAllFixes(findings, importDraft);
    commitDraft(next);
    addLog('log', 'Correções do diagnóstico aplicadas ao rascunho de importação.');
  }, [findings, importDraft, commitDraft, addLog]);
  const answerQuestion = useCallback((id: string) => {
    const q = questions.find((x) => x.id === id);
    if (q) commitDraft(q.apply(importDraft));
  }, [questions, importDraft, commitDraft]);
  const undoFixes = useCallback(() => {
    if (!preFixDraft) return;
    setDraft(preFixDraft.transform);
    setCollision(preFixDraft.collision);
    setMaterialEdits(preFixDraft.materials);
    setPreFixDraft(null);
  }, [preFixDraft]);

  // achados no DiagnosticService (fase `import`): o BottomPanel os lê por filtro; revalidar SUBSTITUI os anteriores do dono
  useEffect(() => {
    const where = file?.sourceUri ?? file?.name ?? 'draft';
    globalDiagnosticService.replaceForOwner(
      { source: 'assetImport', sourceId: 'quiz' },
      findings.map((f) => ({ source: 'assetImport', sourceId: 'quiz', severity: f.severity, phase: 'import', code: f.code, message: f.message, uri: f.target ? `${where}#${f.target}` : undefined })),
      { announce: 'changes' }
    );
  }, [findings, file]);

  const materialDiagnostics = useMemo(() => (loaded ? diagnoseMaterials(loaded.materials) : []), [loaded]);

  // avisos de calibração (escala não uniforme etc.) no DiagnosticService, fase `physics`; somem ao fechar o modal
  useEffect(() => {
    globalDiagnosticService.replaceForOwner(
      { source: 'assetImport', sourceId: 'calibration' },
      calibrationWarnings(draft).map((w) => ({ source: 'assetImport', sourceId: 'calibration', severity: 'warning' as const, phase: 'physics', code: w.code, message: w.message })),
      { announce: 'changes' }
    );
  }, [draft]);
  useEffect(() => () => void globalDiagnosticService.clear({ source: 'assetImport' }), []);

  // ── Fonte vinda do editor (duplo clique, drop do AIS-31, upload) ─────────────────────────────────────────
  useEffect(() => {
    if (!source) {
      setFile(null);
      setStatus('empty');
      return;
    }
    const ext = extOf(source.name);
    if (!isModelExt(ext)) {
      setFile(null);
      setStatus('error');
      setError({ code: 'model.unsupported_extension', message: `${source.name}: extensão .${ext} não suportada.` });
      return;
    }
    let bytes = source.bytes;
    if (!bytes && source.path) {
      const content = globalAuthoringModel.getProject().files[source.path]?.content;
      if (content === undefined) {
        setFile(null);
        setStatus('error');
        setError({ code: 'model.unresolved', message: `${source.path} não tem conteúdo para importar.` });
        return;
      }
      bytes = contentToBytes(content);
    }
    if (!bytes) return;
    setDraft(DEFAULT_TRANSFORM_DRAFT);
    setFile({ name: source.name, ext, bytes, siblings: source.siblings ?? [], sourceUri: source.path });
  }, [source]);

  // ── Ações ─────────────────────────────────────────────────────────────────────────────────────────────
  const loadPicked = useCallback((picked: PickedFile[]) => {
    const selection = selectModelFiles(picked);
    if (!selection.main) {
      setError({ code: 'model.unsupported_extension', message: 'Nenhum arquivo 3D (.glb, .gltf, .obj, .fbx, .dae) na seleção.' });
      return;
    }
    setDraft(DEFAULT_TRANSFORM_DRAFT);
    setFile({ name: selection.main.name, ext: selection.main.ext, bytes: selection.main.bytes, siblings: selection.siblings });
  }, []);

  /** "Carregar Arquivo…": seletor do TauriBridge (nativo no desktop, `<input>` no web), lendo os BYTES. */
  const pickFiles = useCallback(async () => {
    try {
      const results = await TauriBridge.openFileDialog({ multiple: true, binary: true, extensions: ['glb', 'gltf', 'obj', 'fbx', 'dae', 'bin', 'png', 'jpg', 'jpeg', 'webp'] });
      if (results.length) loadPicked(results.map((r) => ({ name: r.name, bytes: toBuffer(r.data) })));
    } catch (e) {
      setError({ code: 'model.parse_failed', message: `Não foi possível ler o arquivo: ${e instanceof Error ? e.message : String(e)}` });
    }
  }, [loadPicked]);

  /** Arquivos soltos sobre o modal. */
  const dropFiles = useCallback(
    async (files: File[]) => {
      if (!files.length) return;
      loadPicked(await Promise.all(files.map(async (f) => ({ name: f.name, bytes: await f.arrayBuffer() }))));
    },
    [loadPicked]
  );

  const patchDraft = useCallback((patch: Partial<ImportTransformDraft> | ((d: ImportTransformDraft) => ImportTransformDraft)) => {
    setDraft((d) => (typeof patch === 'function' ? patch(d) : { ...d, ...patch }));
  }, []);

  // AIS-60b: objeto Animado (padrão com esqueleto/clipes) ou Estático. O interruptor só SUGERE o tipo de corpo: o usuário ajusta no
  // seletor do rodapé (e depois no Inspector); nada é sobrescrito sozinho.
  const [animatedChoice, setAnimatedChoice] = useState<boolean | null>(null);
  useEffect(() => setAnimatedChoice(null), [file]);

  const setImportWithCollision = useCallback((value: boolean) => {
    writeImportWithCollision(value);
    setCollision((c) => ({ ...c, enabled: value }));
  }, []);

  const setBodyMode = useCallback((bodyMode: CollisionOptions['bodyMode']) => {
    setCollision((c) => ({ ...c, bodyMode, shape: allowedShapes(bodyMode).includes(c.shape) ? c.shape : 'auto' }));
  }, []);

  const hasAnimationData = boneNames.length > 0 || animation.library.length > 0;
  const animated = animatedChoice ?? hasAnimationData;
  const setAnimated = useCallback((value: boolean) => {
    setAnimatedChoice(value);
    // sugestão (nunca imposição): Animado → "Movido pela lógica"; Estático → "Sólido parado"
    setCollision((c) => {
      if (!c.enabled) return c;
      const bodyMode: CollisionOptions['bodyMode'] = value ? 'kinematic' : 'static';
      return { ...c, bodyMode, shape: allowedShapes(bodyMode).includes(c.shape) ? c.shape : 'auto' };
    });
    if (!value) setTab((t) => (t === 'animation' ? 'transform' : t));
  }, []);

  // altura da caixa JÁ calibrada (girada e escalada por eixo), antes da escala uniforme: o preview multiplica por `scale`
  const calibratedHeightM = useMemo(() => calibratedBounds(draft, loaded?.bounds ?? null)?.size.y ?? null, [draft, loaded]);
  const stats: PreviewStats | null = useMemo(
    () => (loaded ? { meshes: loaded.stats.meshes, triangles: loaded.stats.triangles, vertices: loaded.stats.vertices, heightM: calibratedHeightM } : null),
    [loaded, calibratedHeightM]
  );

  // ── Botões de 1 clique (AIS-34): funções puras e idempotentes de `core/modelImport/calibration` ───────────────
  const applyDraft = useCallback((fn: (d: ImportTransformDraft) => ImportTransformDraft, message?: string) => {
    setNotice(null);
    setDraft((d) => fn(d));
    if (message) addLog('log', message);
  }, [addLog]);

  const normalizeToHuman = useCallback(() => {
    const bounds = loaded?.bounds ?? null;
    const result = humanScale(draft, bounds);
    if (!bounds) {
      setNotice(result.warning);
      return;
    }
    setDraft(result.draft);
    setNotice(result.warning);
    addLog(result.warning ? 'warn' : 'log', result.warning ?? `Escala calibrada para a altura humana ideal de 1.80m (${Math.round(result.draft.scale * 100)}%).`);
  }, [draft, loaded, addLog]);

  const center = useCallback(() => applyDraft(centerToOrigin, 'Asset centralizado em (0, 0, 0) com pivô no chão.'), [applyDraft]);
  const applyAutoCenter = useCallback(() => applyDraft(autoCenter, 'Centro do modelo levado a X=0, Z=0.'), [applyDraft]);
  const applySnapToFloor = useCallback(() => applyDraft(snapToFloor, 'Base do modelo no chão (Y=0).'), [applyDraft]);
  const applyZUp = useCallback(() => applyDraft(zUpToYUp, 'Orientação corrigida de Z-Up (Blender/3ds Max) para Y-Up.'), [applyDraft]);
  const applyUnit = useCallback((unit: LengthUnit) => applyDraft((d) => convertUnit(d, unit), `Unidade do modelo: ${unit} → metros.`), [applyDraft]);
  const resetAll = useCallback(() => {
    setNotice(null);
    setDraft(resetDraft());
  }, []);

  /** Alternar Y-Up/Z-Up pelo botão do preview (o botão de 1 clique da aba é a versão idempotente). */
  const flipZUp = useCallback(() => {
    setNotice(null);
    setDraft((d) => ({ ...d, zUpFlipped: !d.zUpFlipped }));
    addLog('log', 'Eixo Up alternado entre Y-Up (Padrão Web/Godot) e Z-Up (Blender/3ds Max).');
  }, [addLog]);

  /** O gizmo do preview edita SÓ o rascunho da sessão (nada passa pelo CommandManager). */
  const onGizmoChange = useCallback((patch: { position: Vec3; rotationDeg: Vec3; scale: number; scaleAxes: Vec3 }) => {
    setDraft((d) => ({ ...d, ...patch, scale: patch.scale > 0 ? patch.scale : d.scale }));
  }, []);

  const setScaleAxis = useCallback((axis: 'x' | 'y' | 'z', value: number) => {
    setDraft((d) => ({ ...d, scaleAxes: { ...d.scaleAxes, [axis]: Number.isFinite(value) && value > 0 ? value : d.scaleAxes[axis] } }));
  }, []);

  const warnings = useMemo(() => calibrationWarnings(draft), [draft]);

  const materialsDirty = loaded ? materialEdits.some((e) => { const info = loaded.materials.find((m) => m.name === e.name); return !!info && isEditDirty(e, info); }) : false;
  const reeditDirty =
    reedit !== null &&
    (JSON.stringify(draft) !== JSON.stringify(reedit.restoredDraft) ||
      materialEdits.some((e) => isMaterialTouched(e, reedit.baselineEdits.find((b) => b.name === e.name))) ||
      (reedit.baselineBones !== null && JSON.stringify(rigMap) !== JSON.stringify(reedit.baselineBones)));
  const dirty = reedit ? reeditDirty : file !== null && (isTransformDirty(draft) || materialsDirty);
  const canImport = status === 'ready' && file !== null && !importing;

  const close = useCallback(() => setIsAssetImportModalOpen(false), [setIsAssetImportModalOpen]);

  /** Importar & Adicionar à Cena: grava pelo AssetPipeline e cria o nó (UM Command). */
  const importNow = useCallback(async (): Promise<boolean> => {
    if (!file || status !== 'ready') return false;
    setImporting(true);
    setError(null);
    const deps: ImportDeps = {
      pipeline: globalAssetPipeline,
      existingUris: () => new Set(Object.keys(globalAuthoringModel.getProject().files)),
      refForUri: (uri) => globalResourceRegistry.refForUri(uri),
      readContent: (uri) => globalAuthoringModel.getProject().files[uri]?.content,
      addNode: (type, parentId, name, props) => addNode(type, parentId, name, props),
      // o nó (com o bloco de animação, se Animado) é UMA entrada de Undo
      transaction: (label, fn) => globalCommandManager.transaction(label, fn),
      discard: async (uri) => {
        await deleteResource({ path: uri }, { confirmed: true });
      },
    };
    const parentId = chooseParentId(activeScene.nodes, selectedNodeId, activeScene.rootNodeId);
    const result = await importModelAsset(
      {
        fileName: file.name,
        bytes: file.bytes,
        siblings: file.siblings,
        sourceUri: file.sourceUri,
        draft,
        bounds: loaded?.bounds ?? null,
        collision,
        parentId,
        // AIS-35: texturas embutidas e procedurais viram PNG em res://textures/<asset>/ + manifesto (antes do nó)
        materials: loaded ? { edits: materialEdits, infos: loaded.materials, images: renderMaterialImages(loaded, materialEdits) } : undefined,
        // AIS-36: rig só quando há esqueleto e os obrigatórios estão mapeados (sem rig fictício)
        rig: boneNames.length > 0 && rigValidation.humanoid ? { bones: rigMap } : undefined,
        // AIS-37/60b: clipes aceitos entram no rig por REFERÊNCIA; com ao menos um, o próprio MeshInstance nasce Animado (decisão 30)
        animations: { library: animation.library, files: animation.importFiles },
        animated,
      },
      deps
    );
    setImporting(false);
    if (!result.ok) {
      setError({ code: result.code, message: result.error });
      globalDiagnosticService.report({ source: 'assetImport', sourceId: file.name, severity: 'error', phase: 'import', code: result.code, message: result.error });
      return false;
    }
    addLog('log', `✅ Modelo '${file.name}' importado para ${result.mainUri}${result.reused ? ' (arquivo reutilizado)' : ''} e adicionado à cena.`);
    close();
    return true;
  }, [file, status, draft, loaded, materialEdits, boneNames, rigMap, rigValidation, animation.library, animation.importFiles, animated, collision, activeScene, selectedNodeId, addNode, addLog, close]);

  /** "Aplicar" da reedição: arquivos gerados regravados nos mesmos caminhos + o nó em UM Command. Cancelar não altera nada. */
  const reeditNow = useCallback(async (): Promise<boolean> => {
    if (!reedit || !file || status !== 'ready' || !loaded) return false;
    const node = globalAuthoringModel.getNode(reedit.nodeId);
    const entry = globalResourceRegistry.getByUri(reedit.uri);
    if (!node || !entry) {
      setError({ code: 'model.unresolved', message: 'O nó ou o arquivo deste modelo não existe mais.' });
      return false;
    }
    const settings: ModelImportSettings = parseModelImportSettings(entry.importSettings);
    const touched = materialEdits.filter((e) => isMaterialTouched(e, reedit.baselineEdits.find((b) => b.name === e.name)));
    // o que o usuário ajustou à mão no Inspector depois do import NÃO é sobrescrito sem confirmação
    const manual = detectManualChanges(node.properties, settings, touched.map((e) => e.name), reedit.baselineEdits);
    if (manual.length > 0) {
      const choice = await requestDecision({
        title: 'Ajustes feitos no Inspector',
        message: `Estes valores foram alterados no Inspector depois da importação e serão substituídos pelos desta janela:\n${manual.map((c) => `• ${c.label}: importado ${c.imported} → atual ${c.current}`).join('\n')}`,
        options: [
          { id: 'apply', label: 'Aplicar e substituir', variant: 'primary' },
          { id: 'cancel', label: 'Cancelar', variant: 'neutral' },
        ],
      });
      if (choice !== 'apply') return false;
    }
    setImporting(true);
    setError(null);
    const deps: ReeditDeps = {
      pipeline: globalAssetPipeline,
      existingUris: () => new Set(Object.keys(globalAuthoringModel.getProject().files)),
      refForUri: (uri) => globalResourceRegistry.refForUri(uri),
      readContent: (uri) => globalAuthoringModel.getProject().files[uri]?.content,
      discard: async (uri) => {
        await deleteResource({ path: uri }, { confirmed: true });
      },
      resolveRef: (ref) => {
        const r = globalResourceRegistry.resolve(ref as never);
        return r.status === 'resolved' ? { uri: r.entry.uri, kind: r.entry.kind } : null;
      },
      changeNode: (nodeId, changes, label) => changeNodeProperties(nodeId, changes, label),
    };
    const result = await reeditModelAsset(
      {
        nodeId: node.id,
        nodeName: node.name,
        nodeProps: node.properties,
        modelUri: reedit.uri,
        model: reedit.model,
        settings,
        draft,
        bounds: loaded.bounds,
        materials: { edits: materialEdits, baseline: reedit.baselineEdits, infos: loaded.materials, images: renderMaterialImages(loaded, touched) },
        rig: boneNames.length > 0 && rigValidation.humanoid ? { bones: rigMap } : undefined,
      },
      deps
    );
    setImporting(false);
    if (!result.ok) {
      setError({ code: result.code, message: result.error });
      globalDiagnosticService.report({ source: 'assetImport', sourceId: file.name, severity: 'error', phase: 'import', code: result.code, message: result.error });
      return false;
    }
    addLog('log', `✅ Importação de '${reedit.uri}' reeditada${result.touchedMaterials.length ? ` (materiais: ${result.touchedMaterials.join(', ')})` : ''}${result.rigRewritten ? ' (rig regravado)' : ''}. Ctrl+Z desfaz as propriedades do nó; os arquivos gerados continuam no projeto.`);
    close();
    return true;
  }, [reedit, file, status, loaded, materialEdits, draft, boneNames, rigMap, rigValidation, changeNodeProperties, addLog, close]);

  /** Importar & Adicionar (modelo novo) ou Aplicar (reedição). */
  const applyNow = reedit ? reeditNow : importNow;

  /** Fechar: com rascunho alterado, pergunta antes (nunca descarta em silêncio). */
  const requestClose = useCallback(async () => {
    if (!dirty) return close();
    const choice = await requestDecision({
      title: 'Importação não concluída',
      message: 'A calibração deste modelo ainda não foi importada para a cena.',
      options: [
        { id: 'import', label: 'Importar & Adicionar', variant: 'primary' },
        { id: 'discard', label: 'Descartar', variant: 'danger' },
        { id: 'cancel', label: 'Cancelar', variant: 'neutral' },
      ],
    });
    if (choice === 'import') await applyNow();
    else if (choice === 'discard') close();
  }, [dirty, close, applyNow]);

  return {
    tab,
    setTab,
    file,
    status,
    error,
    clearError: () => setError(null),
    draft,
    patchDraft,
    collision,
    animated,
    setAnimated,
    hasAnimationData,
    setImportWithCollision,
    setBodyMode,
    setShape: (shape: CollisionOptions['shape']) => setCollision((c) => ({ ...c, shape })),
    wireframe,
    toggleWireframe: () => setWireframe((w) => !w),
    showHuman,
    setShowHuman,
    showRuler,
    setShowRuler,
    gizmoMode,
    setGizmoMode,
    notice,
    warnings,
    humanDistance,
    setHumanDistance,
    handle,
    loaded,
    materialEdits,
    selectedMaterial,
    setSelectedMaterial,
    patchMaterial,
    resetMaterial,
    materialDiagnostics,
    materialsDirty,
    findings,
    questions,
    fixFinding,
    fixAll,
    answerQuestion,
    undoFixes,
    canUndoFixes: preFixDraft !== null,
    animation,
    boneNames,
    rigMap,
    rigConvention,
    rigValidation,
    rigFound,
    mappedBoneNames,
    setRigBone,
    redetectRig,
    skeletonOverlay,
    setSkeletonOverlay,
    revision,
    stats,
    importing,
    canImport,
    dirty,
    pickFiles,
    dropFiles,
    normalizeToHuman,
    center,
    flipZUp,
    applyAutoCenter,
    applySnapToFloor,
    applyZUp,
    applyUnit,
    resetAll,
    onGizmoChange,
    setScaleAxis,
    importNow: applyNow,
    isReedit: reedit !== null,
    reeditName: reedit?.nodeName ?? null,
    requestClose,
  };
}

export type ModelImportSession = ReturnType<typeof useModelImportSession>;
