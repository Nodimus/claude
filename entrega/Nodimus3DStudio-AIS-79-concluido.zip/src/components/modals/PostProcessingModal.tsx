import React, { useState, useEffect, useCallback } from 'react';
import { useEditor } from '../../core/EditorContext';
import {
  PostProcessingSettings,
  DEFAULT_POST_PROCESSING,
} from '../../types/scene';
import { globalCommandManager } from '../../core/commandManager';
import {
  createTogglePostEffectCommand,
  createRestorePostEffectCommand,
  createApplyPostProcessingCommand,
} from '../../core/postProcessing/postProcessingCommands';
import {
  Sparkles,
  X,
  RotateCcw,
  Check,
  Eye,
  Sliders,
  Sun,
  Contrast,
  Palette,
  CircleDot,
  Info,
  ExternalLink,
  Layers,
  ImageIcon,
} from 'lucide-react';

type EffectKey = keyof PostProcessingSettings;
type TabId = 'all' | 'bloom' | 'ssao' | 'color' | 'blur' | 'vignette' | 'image';

// ─── helper: toggle switch ─────────────────────────────────────────────────

interface ToggleSwitchProps {
  checked: boolean;
  onChange: (val: boolean) => void;
  size?: 'sm' | 'md';
}
const ToggleSwitch: React.FC<ToggleSwitchProps> = ({ checked, onChange, size = 'md' }) => {
  const wh = size === 'sm' ? 'w-8 h-4' : 'w-9 h-5';
  const dot = size === 'sm'
    ? "after:h-3 after:w-3 after:top-[2px] after:left-[2px]"
    : "after:h-4 after:w-4 after:top-[2px] after:left-[2px]";
  return (
    <label className="relative inline-flex items-center cursor-pointer">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="sr-only peer"
      />
      <div
        className={`${wh} bg-[#2c3345] peer-focus:outline-none rounded-full peer
          peer-checked:after:translate-x-full peer-checked:after:border-white
          after:content-[''] after:absolute ${dot} after:bg-white
          after:border-[#3b475f] after:border after:rounded-full after:transition-all
          peer-checked:bg-[#4982ea]`}
      />
    </label>
  );
};

// ─── helper: slider row ────────────────────────────────────────────────────

interface SliderRowProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  format?: (v: number) => string;
  onChange: (v: number) => void;
}
const SliderRow: React.FC<SliderRowProps> = ({ label, value, min, max, step, format, onChange }) => (
  <div className="space-y-1">
    <div className="flex justify-between text-[#8b97a8]">
      <span>{label}</span>
      <span className="text-white font-mono">{format ? format(value) : value}</span>
    </div>
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(step < 1 ? parseFloat(e.target.value) : parseInt(e.target.value))}
      className="w-full accent-[#4982ea]"
    />
  </div>
);

// ─── helper: effect card header ────────────────────────────────────────────

interface CardHeaderProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  effectKey: EffectKey;
  enabled: boolean;
  onToggle: (key: EffectKey, val: boolean) => void;
  onRestore: (key: EffectKey) => void;
}
const CardHeader: React.FC<CardHeaderProps> = ({
  icon, title, description, effectKey, enabled, onToggle, onRestore
}) => (
  <div className="flex items-center justify-between pb-2 border-b border-[#2c3345]">
    <div className="flex items-center gap-2">
      {icon}
      <div>
        <div className="font-semibold text-white text-[12px]">{title}</div>
        <div className="text-[11px] text-[#8b97a8]">{description}</div>
      </div>
    </div>
    <div className="flex items-center gap-2">
      <button
        onClick={() => onRestore(effectKey)}
        title="Restaurar padrão deste efeito (Ctrl+Z desfaz)"
        className="p-1 text-[#8b97a8] hover:text-amber-400 hover:bg-amber-400/10 rounded transition-colors"
      >
        <RotateCcw className="w-3.5 h-3.5" />
      </button>
      <ToggleSwitch
        checked={enabled}
        onChange={(val) => onToggle(effectKey, val)}
      />
    </div>
  </div>
);

// ─── Main component ────────────────────────────────────────────────────────

export const PostProcessingModal: React.FC = () => {
  const {
    isPostProcessingOpen,
    setIsPostProcessingOpen,
    activeScene,
    saveCurrentScene,
    addLog,
  } = useEditor();

  const [activeTab, setActiveTab] = useState<TabId>('all');

  const makeSettings = useCallback((): PostProcessingSettings => {
    const base = activeScene?.postProcessing
      ? JSON.parse(JSON.stringify(activeScene.postProcessing))
      : JSON.parse(JSON.stringify(DEFAULT_POST_PROCESSING));
    // Garantir que novos campos existam mesmo em cenas antigas
    return {
      ...JSON.parse(JSON.stringify(DEFAULT_POST_PROCESSING)),
      ...base,
      bloom: { ...DEFAULT_POST_PROCESSING.bloom, ...base.bloom },
      ssao: { ...DEFAULT_POST_PROCESSING.ssao, ...base.ssao },
      imageAdjust: { ...DEFAULT_POST_PROCESSING.imageAdjust, ...base.imageAdjust },
      vignette: { ...DEFAULT_POST_PROCESSING.vignette, ...base.vignette },
      blur: { ...DEFAULT_POST_PROCESSING.blur, ...base.blur },
      colorize: { ...DEFAULT_POST_PROCESSING.colorize, ...base.colorize },
    };
  }, [activeScene]);

  const [settings, setSettings] = useState<PostProcessingSettings>(makeSettings);

  // Sync when modal opens or activeScene changes
  useEffect(() => {
    if (isPostProcessingOpen) {
      setSettings(makeSettings());
    }
  }, [isPostProcessingOpen, makeSettings]);

  if (!isPostProcessingOpen) return null;

  // ─── AIS-55-C06: toggle individual por efeito via Command ──────────────
  const handleToggleEffect = (effectKey: EffectKey, val: boolean) => {
    const updated = {
      ...settings,
      [effectKey]: { ...settings[effectKey], enabled: val },
    };
    setSettings(updated);
    const cmd = createTogglePostEffectCommand({ effectKey, enabled: val });
    globalCommandManager.execute(cmd);
    addLog('log', `Post-processing: ${String(effectKey)} → ${val ? 'ativado' : 'desativado'} (Ctrl+Z desfaz).`);
  };

  // ─── AIS-55-C05: restaurar defaults de um efeito via Command ───────────
  const handleRestoreEffect = (effectKey: EffectKey) => {
    const defaultEffect = DEFAULT_POST_PROCESSING[effectKey];
    const updated = {
      ...settings,
      [effectKey]: JSON.parse(JSON.stringify(defaultEffect)),
    };
    setSettings(updated);
    const cmd = createRestorePostEffectCommand({ effectKey });
    globalCommandManager.execute(cmd);
    addLog('log', `Post-processing: ${String(effectKey)} restaurado para defaults (Ctrl+Z desfaz).`);
  };

  // Reset ALL effects (global button)
  const handleReset = () => {
    setSettings(JSON.parse(JSON.stringify(DEFAULT_POST_PROCESSING)));
  };

  // Apply all via Command
  const handleApply = () => {
    const cmd = createApplyPostProcessingCommand({ settings });
    globalCommandManager.execute(cmd);
    saveCurrentScene();
    addLog('log', `Applied post-processing to "${activeScene?.name}" (Ctrl+Z desfaz).`);
    setIsPostProcessingOpen(false);
  };

  const countActiveEffects = () => {
    let count = 0;
    if (settings.bloom.enabled) count++;
    if (settings.blackAndWhite.enabled) count++;
    if (settings.invert.enabled) count++;
    if (settings.blur.enabled) count++;
    if (settings.colorize.enabled) count++;
    if (settings.vignette.enabled) count++;
    if (settings.ssao.enabled) count++;
    if (settings.imageAdjust.enabled) count++;
    return count;
  };

  const tabBtn = (id: TabId, label: React.ReactNode, dot?: boolean) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`w-full text-left px-3 py-1.5 rounded flex items-center justify-between transition-colors ${
        activeTab === id
          ? 'bg-[#4982ea] text-white font-medium'
          : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'
      }`}
    >
      {label}
      {dot && <div className="w-2 h-2 rounded-full bg-emerald-400" />}
    </button>
  );

  const disabledCls = (enabled: boolean) =>
    `transition-opacity ${enabled ? 'opacity-100' : 'opacity-40 pointer-events-none'}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none">
      <div className="w-[820px] h-[620px] bg-[#1e232f] border border-[#3b475f] rounded-lg shadow-2xl flex flex-col overflow-hidden text-xs text-[#dfe4ec]">
        {/* Header */}
        <div className="h-11 bg-[#171b24] border-b border-[#2c3345] px-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5 font-semibold text-white">
            <div className="p-1 rounded bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[13px]">Post Processing Effects</span>
                <span className="px-1.5 py-0.5 bg-[#2a3244] text-[#8b97a8] rounded text-[10px] font-normal">
                  {countActiveEffects()} active
                </span>
              </div>
              <div className="text-[10px] text-[#8b97a8] font-normal">
                Scene: <span className="text-white">{activeScene?.name}</span> (WebGL &amp; Runtime Post-Effects)
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="https://www.ambiera.com/coppercube/doc/cnt_posteffects.html"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#8b97a8] hover:text-purple-400 p-1 flex items-center gap-1 transition-colors"
              title="Open documentation"
            >
              <Info className="w-3.5 h-3.5" />
              <span className="text-[10px]">Doc</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <button
              onClick={() => setIsPostProcessingOpen(false)}
              className="p-1 text-[#8b97a8] hover:text-white rounded hover:bg-[#2c3345] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar Navigation */}
          <div className="w-44 border-r border-[#2c3345] bg-[#171b24] p-2 space-y-1 flex-shrink-0">
            <button
              onClick={() => setActiveTab('all')}
              className={`w-full text-left px-3 py-2 rounded flex items-center justify-between transition-colors ${
                activeTab === 'all'
                  ? 'bg-[#4982ea] text-white font-medium shadow-sm'
                  : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <span className="flex items-center gap-2">
                <Sliders className="w-3.5 h-3.5" />
                <span>All Effects</span>
              </span>
              <span className="text-[10px] opacity-75">{countActiveEffects()}</span>
            </button>

            <div className="pt-2 pb-1 px-2 text-[10px] font-semibold text-[#68768e] uppercase tracking-wider">
              Effects
            </div>

            {tabBtn('bloom',
              <span className="flex items-center gap-2"><Sun className="w-3.5 h-3.5 text-amber-400" /><span>Bloom</span></span>,
              settings.bloom.enabled
            )}
            {tabBtn('ssao',
              <span className="flex items-center gap-2"><Layers className="w-3.5 h-3.5 text-cyan-400" /><span>SSAO</span></span>,
              settings.ssao.enabled
            )}
            {tabBtn('color',
              <span className="flex items-center gap-2"><Palette className="w-3.5 h-3.5 text-sky-400" /><span>Color &amp; Invert</span></span>,
              settings.blackAndWhite.enabled || settings.invert.enabled || settings.colorize.enabled
            )}
            {tabBtn('blur',
              <span className="flex items-center gap-2"><Eye className="w-3.5 h-3.5 text-indigo-400" /><span>Blur</span></span>,
              settings.blur.enabled
            )}
            {tabBtn('vignette',
              <span className="flex items-center gap-2"><CircleDot className="w-3.5 h-3.5 text-purple-400" /><span>Vignette</span></span>,
              settings.vignette.enabled
            )}
            {tabBtn('image',
              <span className="flex items-center gap-2"><ImageIcon className="w-3.5 h-3.5 text-green-400" /><span>Image Adjust</span></span>,
              settings.imageAdjust.enabled
            )}

            <div className="pt-4 px-1">
              <div className="p-2.5 rounded bg-[#13161f] border border-[#2c3345] text-[11px] text-[#7d8ba1] space-y-1">
                <div className="font-semibold text-[#a0aec0] flex items-center gap-1">
                  <Info className="w-3 h-3 text-blue-400" />
                  <span>Engine Notes</span>
                </div>
                <p className="text-[10px] leading-relaxed">
                  Post effects can be toggled individually. Each has Undo support via Ctrl+Z.
                </p>
              </div>
            </div>
          </div>

          {/* Configuration Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#1b202c]">

            {/* 1. Bloom */}
            {(activeTab === 'all' || activeTab === 'bloom') && (
              <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                <CardHeader
                  icon={<Sun className="w-4 h-4 text-amber-400" />}
                  title="Bloom"
                  description="Fakes a glow — bleeding shiny light on top of bright light sources."
                  effectKey="bloom"
                  enabled={settings.bloom.enabled}
                  onToggle={handleToggleEffect}
                  onRestore={handleRestoreEffect}
                />
                <div className={`grid grid-cols-3 gap-4 pt-1 ${disabledCls(settings.bloom.enabled)}`}>
                  <SliderRow
                    label="Intensity"
                    value={settings.bloom.blurIterations}
                    min={1} max={10} step={1}
                    onChange={(v) => setSettings({ ...settings, bloom: { ...settings.bloom, blurIterations: v } })}
                  />
                  <SliderRow
                    label="Threshold"
                    value={settings.bloom.threshold}
                    min={0} max={1} step={0.05}
                    format={(v) => v.toFixed(2)}
                    onChange={(v) => setSettings({ ...settings, bloom: { ...settings.bloom, threshold: v } })}
                  />
                  <SliderRow
                    label="Radius"
                    value={settings.bloom.radius}
                    min={0} max={1} step={0.05}
                    format={(v) => v.toFixed(2)}
                    onChange={(v) => setSettings({ ...settings, bloom: { ...settings.bloom, radius: v } })}
                  />
                </div>
              </div>
            )}

            {/* 2. SSAO — AIS-55 */}
            {(activeTab === 'all' || activeTab === 'ssao') && (
              <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                <CardHeader
                  icon={<Layers className="w-4 h-4 text-cyan-400" />}
                  title="Ambient Occlusion (SSAO)"
                  description="Darkens crevices and corners with screen-space ambient occlusion."
                  effectKey="ssao"
                  enabled={settings.ssao.enabled}
                  onToggle={handleToggleEffect}
                  onRestore={handleRestoreEffect}
                />
                <div className={`grid grid-cols-2 gap-4 pt-1 ${disabledCls(settings.ssao.enabled)}`}>
                  <SliderRow
                    label="Intensity"
                    value={settings.ssao.intensity}
                    min={0} max={2} step={0.05}
                    format={(v) => v.toFixed(2)}
                    onChange={(v) => setSettings({ ...settings, ssao: { ...settings.ssao, intensity: v } })}
                  />
                  <SliderRow
                    label="Radius"
                    value={settings.ssao.radius}
                    min={0.01} max={1} step={0.01}
                    format={(v) => v.toFixed(2)}
                    onChange={(v) => setSettings({ ...settings, ssao: { ...settings.ssao, radius: v } })}
                  />
                </div>
              </div>
            )}

            {/* 3. Color Effects (Black & White, Invert, Colorize) */}
            {(activeTab === 'all' || activeTab === 'color') && (
              <div className="space-y-4">
                {/* Black and White & Invert in row */}
                <div className="grid grid-cols-2 gap-3">
                  {/* Black and White */}
                  <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Contrast className="w-4 h-4 text-slate-300" />
                        <div>
                          <div className="font-semibold text-white">Black and White</div>
                          <div className="text-[10px] text-[#8b97a8]">Renders scene in grayscale</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleRestoreEffect('blackAndWhite')}
                          title="Restaurar padrão (Ctrl+Z desfaz)"
                          className="p-1 text-[#8b97a8] hover:text-amber-400 hover:bg-amber-400/10 rounded transition-colors"
                        >
                          <RotateCcw className="w-3 h-3" />
                        </button>
                        <ToggleSwitch
                          size="sm"
                          checked={settings.blackAndWhite.enabled}
                          onChange={(val) => handleToggleEffect('blackAndWhite', val)}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Invert */}
                  <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Palette className="w-4 h-4 text-emerald-400" />
                        <div>
                          <div className="font-semibold text-white">Invert</div>
                          <div className="text-[10px] text-[#8b97a8]">Inverts colors (e.g. night vision)</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleRestoreEffect('invert')}
                          title="Restaurar padrão (Ctrl+Z desfaz)"
                          className="p-1 text-[#8b97a8] hover:text-amber-400 hover:bg-amber-400/10 rounded transition-colors"
                        >
                          <RotateCcw className="w-3 h-3" />
                        </button>
                        <ToggleSwitch
                          size="sm"
                          checked={settings.invert.enabled}
                          onChange={(val) => handleToggleEffect('invert', val)}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Colorize */}
                <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                  <CardHeader
                    icon={<Palette className="w-4 h-4 text-pink-400" />}
                    title="Colorize"
                    description="Multiplies pixel colors with the specified color."
                    effectKey="colorize"
                    enabled={settings.colorize.enabled}
                    onToggle={handleToggleEffect}
                    onRestore={handleRestoreEffect}
                  />
                  <div className={`flex items-center gap-4 pt-1 ${disabledCls(settings.colorize.enabled)}`}>
                    <span className="text-[#8b97a8] whitespace-nowrap">Colorize_Color:</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={settings.colorize.color}
                        onChange={(e) =>
                          setSettings({ ...settings, colorize: { ...settings.colorize, color: e.target.value } })
                        }
                        className="w-8 h-8 rounded border border-[#2c3345] bg-transparent cursor-pointer"
                      />
                      <input
                        type="text"
                        value={settings.colorize.color}
                        onChange={(e) =>
                          setSettings({ ...settings, colorize: { ...settings.colorize, color: e.target.value } })
                        }
                        className="w-24 px-2 py-1 bg-[#171b24] border border-[#2c3345] rounded font-mono text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 4. Blur */}
            {(activeTab === 'all' || activeTab === 'blur') && (
              <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                <CardHeader
                  icon={<Eye className="w-4 h-4 text-indigo-400" />}
                  title="Blur"
                  description="Blurs the entire image, reducing its sharpness."
                  effectKey="blur"
                  enabled={settings.blur.enabled}
                  onToggle={handleToggleEffect}
                  onRestore={handleRestoreEffect}
                />
                <div className={`pt-1 max-w-xs ${disabledCls(settings.blur.enabled)}`}>
                  <SliderRow
                    label="Blur_Iterations"
                    value={settings.blur.iterations}
                    min={1} max={10} step={1}
                    onChange={(v) => setSettings({ ...settings, blur: { ...settings.blur, iterations: v } })}
                  />
                </div>
              </div>
            )}

            {/* 5. Vignette */}
            {(activeTab === 'all' || activeTab === 'vignette') && (
              <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                <CardHeader
                  icon={<CircleDot className="w-4 h-4 text-purple-400" />}
                  title="Vignette"
                  description="Fades out the borders of the screen for a cinematic look."
                  effectKey="vignette"
                  enabled={settings.vignette.enabled}
                  onToggle={handleToggleEffect}
                  onRestore={handleRestoreEffect}
                />
                <div className={`grid grid-cols-3 gap-4 pt-1 ${disabledCls(settings.vignette.enabled)}`}>
                  <SliderRow
                    label="Intensity"
                    value={settings.vignette.intensity}
                    min={0} max={1} step={0.05}
                    format={(v) => v.toFixed(2)}
                    onChange={(v) => setSettings({ ...settings, vignette: { ...settings.vignette, intensity: v } })}
                  />
                  <SliderRow
                    label="Radius A"
                    value={settings.vignette.radiusA}
                    min={0} max={1} step={0.05}
                    format={(v) => v.toFixed(2)}
                    onChange={(v) => setSettings({ ...settings, vignette: { ...settings.vignette, radiusA: v } })}
                  />
                  <SliderRow
                    label="Radius B"
                    value={settings.vignette.radiusB}
                    min={0} max={1} step={0.05}
                    format={(v) => v.toFixed(2)}
                    onChange={(v) => setSettings({ ...settings, vignette: { ...settings.vignette, radiusB: v } })}
                  />
                </div>
              </div>
            )}

            {/* 6. Image Adjust — AIS-55 */}
            {(activeTab === 'all' || activeTab === 'image') && (
              <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                <CardHeader
                  icon={<ImageIcon className="w-4 h-4 text-green-400" />}
                  title="Image Adjust"
                  description="Brilho, Contraste, Saturação e Tone Mapping cinematográfico."
                  effectKey="imageAdjust"
                  enabled={settings.imageAdjust.enabled}
                  onToggle={handleToggleEffect}
                  onRestore={handleRestoreEffect}
                />
                <div className={`space-y-4 pt-1 ${disabledCls(settings.imageAdjust.enabled)}`}>
                  <div className="grid grid-cols-3 gap-4">
                    <SliderRow
                      label="Brightness"
                      value={settings.imageAdjust.brightness}
                      min={0} max={200} step={1}
                      format={(v) => `${v}%`}
                      onChange={(v) =>
                        setSettings({ ...settings, imageAdjust: { ...settings.imageAdjust, brightness: v } })
                      }
                    />
                    <SliderRow
                      label="Contrast"
                      value={settings.imageAdjust.contrast}
                      min={0} max={200} step={1}
                      format={(v) => `${v}%`}
                      onChange={(v) =>
                        setSettings({ ...settings, imageAdjust: { ...settings.imageAdjust, contrast: v } })
                      }
                    />
                    <SliderRow
                      label="Saturation"
                      value={settings.imageAdjust.saturation}
                      min={0} max={200} step={1}
                      format={(v) => `${v}%`}
                      onChange={(v) =>
                        setSettings({ ...settings, imageAdjust: { ...settings.imageAdjust, saturation: v } })
                      }
                    />
                  </div>
                  {/* Tone Mapping */}
                  <div className="space-y-1">
                    <div className="text-[#8b97a8]">Tone Mapping</div>
                    <div className="flex gap-2">
                      {(['none', 'filmic', 'reinhard'] as const).map((mode) => (
                        <button
                          key={mode}
                          onClick={() =>
                            setSettings({ ...settings, imageAdjust: { ...settings.imageAdjust, toneMapping: mode } })
                          }
                          className={`px-3 py-1.5 rounded text-[11px] border transition-colors capitalize ${
                            settings.imageAdjust.toneMapping === mode
                              ? 'bg-[#4982ea] border-[#4982ea] text-white font-medium'
                              : 'bg-[#171b24] border-[#2c3345] text-[#8b97a8] hover:text-white hover:border-[#4982ea]'
                          }`}
                        >
                          {mode === 'none' ? 'None (Linear)' : mode.charAt(0).toUpperCase() + mode.slice(1)}
                        </button>
                      ))}
                    </div>
                    <div className="text-[10px] text-[#68768e] pt-1">
                      Filmic — compressão cinematográfica de altas luzes · Reinhard — tone mapping clássico
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="h-12 bg-[#171b24] border-t border-[#2c3345] px-4 flex items-center justify-between">
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#8b97a8] hover:text-white transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset All to Defaults</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPostProcessingOpen(false)}
              className="px-3.5 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-[#4982ea] hover:bg-[#3b6ecc] text-white font-medium shadow-md transition-colors"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Apply &amp; Save</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
