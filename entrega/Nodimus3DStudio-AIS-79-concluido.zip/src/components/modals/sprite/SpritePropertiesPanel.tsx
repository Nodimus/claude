import React, { useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';
import type { BillboardMode, LightingPreset, LoopMode, SpriteAnimation, SpriteProject } from '../../../types/sprite';
import { sanitizeSpriteName } from '../../../core/sprites/spriteSave';
import { clipDurationMs } from '../../../runtime/sprite';

/**
 * Painel de propriedades à esquerda, no desenho do Sprite Editor do GameMaker: seções recolhíveis (Sprite, Reprodução, Textura, Billboard 3D)
 * com os campos do `SpriteProject` (decisão 24). Só edita dados do recurso — nada de estado novo; quem grava é o editor (DocumentManager).
 */

interface Props {
  project: SpriteProject;
  onChange: (updater: (prev: SpriteProject) => SpriteProject) => void;
  readOnly: boolean;
  activeAnim: SpriteAnimation | undefined;
  onUpdateAnimation: (anim: SpriteAnimation) => void;
  onSelectAnimation: (animId: string) => void;
}

const inputCls = 'w-full bg-[#141822] text-xs text-white px-2 py-1 rounded border border-[#374158] focus:outline-none focus:border-sky-400 disabled:opacity-60';
const labelCls = 'text-[11px] text-[#9ca7b7]';

const Section: React.FC<{ title: string; testId: string; defaultOpen?: boolean; children: React.ReactNode }> = ({ title, testId, defaultOpen = true, children }) => {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-[#2c3345]" data-testid={testId}>
      <button type="button" onClick={() => setOpen(!open)} aria-expanded={open} className="w-full flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold uppercase tracking-wide text-[#cbd5e1] bg-[#1c222e] hover:bg-[#222a39]">
        {open ? <ChevronDown className="w-3.5 h-3.5 text-sky-400" /> : <ChevronRight className="w-3.5 h-3.5 text-sky-400" />}
        {title}
      </button>
      {open && <div className="px-3 py-2 flex flex-col gap-2">{children}</div>}
    </div>
  );
};

const Row: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <label className="flex flex-col gap-0.5">
    <span className={labelCls}>{label}</span>
    {children}
  </label>
);

export const SpritePropertiesPanel: React.FC<Props> = ({ project, onChange, readOnly, activeAnim, onUpdateAnimation, onSelectAnimation }) => {
  const s = project.settings3D;
  const cfg = project.sheetConfig;
  const set3D = (patch: Partial<SpriteProject['settings3D']>) => onChange((p) => ({ ...p, settings3D: { ...p.settings3D, ...patch } }));
  const duration = activeAnim ? clipDurationMs(activeAnim) / 1000 : 0;

  return (
    <aside className="w-[270px] shrink-0 flex flex-col bg-[#181c24] border-r border-[#2c3345] overflow-y-auto select-none" data-testid="sprite-properties">
      <Section title="Sprite" testId="sprite-section-sprite">
        <Row label="Nome">
          <input
            type="text"
            value={project.name}
            onChange={(e) => onChange((p) => ({ ...p, name: e.target.value }))}
            disabled={readOnly}
            data-testid="sprite-name"
            title={`Nome do arquivo: ${sanitizeSpriteName(project.name)} (apenas letras, números, _ e -)`}
            className={inputCls}
          />
        </Row>
        <div className="grid grid-cols-2 gap-2 text-[11px]">
          <div className="bg-[#141822] rounded border border-[#2c3345] px-2 py-1">
            <div className={labelCls}>Tamanho do quadro</div>
            <div className="font-mono text-white" data-testid="sprite-frame-size">{cfg.frameWidth} × {cfg.frameHeight} px</div>
          </div>
          <div className="bg-[#141822] rounded border border-[#2c3345] px-2 py-1">
            <div className={labelCls}>Quadros</div>
            <div className="font-mono text-white" data-testid="sprite-frame-count">{project.frames.length}</div>
          </div>
        </div>
        <div className="text-[10px] text-[#64748b] font-mono break-all" title="Atlas PNG referenciado por ResourceRef">
          Atlas: {cfg.texture?.path ?? '(será criado ao salvar)'}
          {cfg.texture?.unresolved ? ' — não encontrado' : ''}
          {cfg.imageWidth ? ` · ${cfg.imageWidth}×${cfg.imageHeight}` : ''}
        </div>
      </Section>

      <Section title="Reprodução" testId="sprite-section-playback">
        <Row label="Animação">
          <select value={activeAnim?.id ?? ''} onChange={(e) => onSelectAnimation(e.target.value)} className={inputCls} data-testid="sprite-anim-select">
            {project.animations.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name} ({a.frameIndices.length})
              </option>
            ))}
          </select>
        </Row>
        {activeAnim && (
          <>
            <Row label="Velocidade de reprodução (quadros por segundo)">
              <input
                type="number"
                min={1}
                max={60}
                value={activeAnim.fps}
                disabled={readOnly}
                data-testid="sprite-fps"
                onChange={(e) => onUpdateAnimation({ ...activeAnim, fps: Math.max(1, Math.min(60, parseInt(e.target.value) || 8)) })}
                className={inputCls}
              />
            </Row>
            <div className="flex flex-wrap gap-1">
              {[6, 8, 12, 16, 24, 30].map((f) => (
                <button
                  key={f}
                  type="button"
                  disabled={readOnly}
                  onClick={() => onUpdateAnimation({ ...activeAnim, fps: f })}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${activeAnim.fps === f ? 'bg-[#4982ea] text-white' : 'bg-[#202531] text-[#8b97a8] hover:text-white'}`}
                >
                  {f}
                </button>
              ))}
            </div>
            <Row label="Modo">
              <div className="flex gap-1" role="group" aria-label="Modo de reprodução">
                {(
                  [
                    ['loop', 'Loop', 'Repete em loop'],
                    ['once', '1x', 'Toca uma vez e para no último quadro'],
                    ['ping-pong', 'Ping-pong', 'Ida e volta'],
                  ] as [LoopMode, string, string][]
                ).map(([mode, label, hint]) => (
                  <button
                    key={mode}
                    type="button"
                    disabled={readOnly}
                    title={hint}
                    data-testid={`sprite-loop-${mode}`}
                    onClick={() => onUpdateAnimation({ ...activeAnim, loopMode: mode })}
                    className={`flex-1 px-1.5 py-1 rounded text-[11px] font-medium ${activeAnim.loopMode === mode ? 'bg-[#4982ea] text-white' : 'bg-[#202531] text-[#8b97a8] hover:text-white'}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </Row>
            <div className="text-[10px] text-[#64748b]">Duração de uma passada: {duration.toFixed(2)} s</div>
          </>
        )}
      </Section>

      <Section title="Textura" testId="sprite-section-texture">
        <label className="flex items-center gap-2 text-xs text-[#cbd5e1]" title="Ligado = LinearFilter; desligado = NearestFilter (pixels nítidos)">
          <input type="checkbox" checked={!s.pixelPerfectFilter} disabled={readOnly} data-testid="sprite-edge-filter" onChange={(e) => set3D({ pixelPerfectFilter: !e.target.checked })} className="w-4 h-4 accent-sky-500" />
          Suavizar bordas (Edge Filtering)
        </label>
        {(
          [
            ['tileH', 'Tile horizontal', 'RepeatWrapping na horizontal'],
            ['tileV', 'Tile vertical', 'RepeatWrapping na vertical'],
            ['premultiplyAlpha', 'Premultiply Alpha', 'Multiplica o RGB pelo alfa ao enviar a textura'],
          ] as const
        ).map(([key, label, hint]) => (
          <label key={key} className="flex items-center gap-2 text-xs text-[#cbd5e1]" title={hint}>
            <input type="checkbox" checked={s[key]} disabled={readOnly} data-testid={`sprite-${key}`} onChange={(e) => set3D({ [key]: e.target.checked })} className="w-4 h-4 accent-sky-500" />
            {label}
          </label>
        ))}
        <label className="flex items-center gap-2 text-xs text-[#64748b] cursor-not-allowed" title="em breve">
          <input type="checkbox" disabled className="w-4 h-4" />
          Separate Texture Page <span className="text-[10px]">(em breve)</span>
        </label>
        <button type="button" disabled className="text-left text-xs text-[#64748b] cursor-not-allowed" title="em breve: Collision Mask (Box/Sphere) a partir do quadro">
          Máscara de colisão <span className="text-[10px]">(em breve)</span>
        </button>
      </Section>

      <Section title="Billboard 3D" testId="sprite-section-billboard" defaultOpen={false}>
        <Row label="Modo (alinhamento com a câmera)">
          <select value={s.billboardMode} disabled={readOnly} onChange={(e) => set3D({ billboardMode: e.target.value as BillboardMode })} className={inputCls}>
            <option value="spherical">Esférico (todos os eixos)</option>
            <option value="cylindrical_y">Cilíndrico Y (em pé no chão)</option>
            <option value="flat_quad">Quad plano fixo</option>
            <option value="isometric">Isométrico (45°)</option>
          </select>
        </Row>
        <div className="grid grid-cols-2 gap-2">
          <Row label="Largura (m)">
            <input type="number" step={0.1} min={0.1} max={20} value={s.renderScale.x} disabled={readOnly} onChange={(e) => set3D({ renderScale: { ...s.renderScale, x: parseFloat(e.target.value) || 1 } })} className={inputCls} />
          </Row>
          <Row label="Altura (m)">
            <input type="number" step={0.1} min={0.1} max={20} value={s.renderScale.y} disabled={readOnly} onChange={(e) => set3D({ renderScale: { ...s.renderScale, y: parseFloat(e.target.value) || 1 } })} className={inputCls} />
          </Row>
        </div>
        <Row label={`Corte alfa: ${s.alphaTest.toFixed(2)}`}>
          <input type="range" min={0} max={1} step={0.05} value={s.alphaTest} disabled={readOnly} onChange={(e) => set3D({ alphaTest: parseFloat(e.target.value) })} className="accent-sky-500" />
        </Row>
        <div className="grid grid-cols-2 gap-2 items-end">
          <Row label="Cor emissiva">
            <input type="color" value={s.emissiveColor} disabled={readOnly} onChange={(e) => set3D({ emissiveColor: e.target.value })} className="w-full h-7 rounded border border-[#374158] bg-transparent cursor-pointer" />
          </Row>
          <Row label={`Intensidade: ${s.emissiveIntensity.toFixed(1)}`}>
            <input type="range" min={0} max={3} step={0.1} value={s.emissiveIntensity} disabled={readOnly} onChange={(e) => set3D({ emissiveIntensity: parseFloat(e.target.value) })} className="accent-sky-500" />
          </Row>
        </div>
        <Row label="Iluminação da prévia">
          <select value={s.environmentLighting} disabled={readOnly} onChange={(e) => set3D({ environmentLighting: e.target.value as LightingPreset })} className={inputCls}>
            <option value="studio">Estúdio neutro</option>
            <option value="cyberpunk">Cyberpunk neon</option>
            <option value="night">Noite enluarada</option>
            <option value="sunset">Pôr do sol</option>
            <option value="retro_arcade">Fliperama retrô</option>
          </select>
        </Row>
      </Section>
    </aside>
  );
};
