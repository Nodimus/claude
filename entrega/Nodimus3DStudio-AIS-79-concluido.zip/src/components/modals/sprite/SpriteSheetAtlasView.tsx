import React, { useEffect, useMemo, useRef, useState } from 'react';
import { SpriteProject, SpriteSheetConfig } from '../../../types/sprite';
import { Upload, Sparkles, Scissors, Check, RefreshCw, ListPlus, MousePointerClick } from 'lucide-react';
import { SPRITE_PRESETS } from '../../../utils/spritePresets';
import { gridFrames } from '../../../schemas/spriteNormalize';

interface SpriteSheetAtlasViewProps {
  project: SpriteProject;
  onUpdateSheetConfig: (newConfig: SpriteSheetConfig) => void;
  /** Abre o quadro no editor de pixel (duplo clique / botão). */
  onSelectFrame: (index: number) => void;
  onLoadPreset: (presetId: string) => void;
  onUploadImage: (file: File) => void;
  /** "Convert to Frames": gera as regiões do atlas (colunas × linhas, tamanho, separação e margem). */
  onSliceGrid: (cols: number, rows: number, fw: number, fh: number, spacing: number, margin: number) => void;
  /** Cria uma animação com os índices GLOBAIS escolhidos (qualquer ordem, repetidos). */
  onCreateAnimation: (name: string, frameIndices: number[]) => void;
  /** Acrescenta os quadros escolhidos (índices globais) ao fim da animação ATIVA. */
  onAppendToAnimation: (frameIndices: number[]) => void;
  activeAnimationName?: string;
  currentFrameIndex: number;
  readOnly?: boolean;
}

const numberField = 'w-14 bg-transparent text-center font-mono text-white text-xs border-b border-[#475569] focus:outline-none';

export const SpriteSheetAtlasView: React.FC<SpriteSheetAtlasViewProps> = ({
  project,
  onSelectFrame,
  onLoadPreset,
  onUploadImage,
  onSliceGrid,
  onCreateAnimation,
  onAppendToAnimation,
  activeAnimationName,
  currentFrameIndex,
  readOnly = false,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cfg = project.sheetConfig;

  const [cols, setCols] = useState(cfg.columns || 4);
  const [rows, setRows] = useState(cfg.rows || 1);
  const [fw, setFw] = useState(cfg.frameWidth || 32);
  const [fh, setFh] = useState(cfg.frameHeight || 32);
  const [spacing, setSpacing] = useState(cfg.spacing || 0);
  const [margin, setMargin] = useState(cfg.margin || 0);
  const [naturalSize, setNaturalSize] = useState<{ w: number; h: number } | null>(null);
  const [animName, setAnimName] = useState('');

  // Seleção de células (clique, Ctrl/Cmd alterna, Shift faixa, arrastar): a ORDEM dos cliques vira a ordem da animação.
  const [selected, setSelected] = useState<number[]>([]);
  const anchorRef = useRef<number | null>(null);
  const draggingRef = useRef(false);

  // sincroniza os campos quando o projeto muda por fora (preset, abrir outro arquivo)
  useEffect(() => {
    setCols(cfg.columns || 1);
    setRows(cfg.rows || 1);
    setFw(cfg.frameWidth || 32);
    setFh(cfg.frameHeight || 32);
    setSpacing(cfg.spacing || 0);
    setMargin(cfg.margin || 0);
  }, [cfg.columns, cfg.rows, cfg.frameWidth, cfg.frameHeight, cfg.spacing, cfg.margin]);

  useEffect(() => {
    const up = () => {
      draggingRef.current = false;
    };
    window.addEventListener('mouseup', up);
    return () => window.removeEventListener('mouseup', up);
  }, []);

  useEffect(() => {
    setSelected((s) => s.filter((i) => i < project.frames.length));
  }, [project.frames.length]);

  const atlasW = cfg.imageWidth || naturalSize?.w || 256;
  const atlasH = cfg.imageHeight || naturalSize?.h || 256;

  // pré-visualização ao vivo da grade que o "Converter" vai gerar
  const preview = useMemo(() => gridFrames(Math.min(cols, 64), Math.min(rows, 64), fw, fh, spacing, margin), [cols, rows, fw, fh, spacing, margin]);

  const handleApplySlice = () => onSliceGrid(cols, rows, fw, fh, spacing, margin);

  const handleAutoCalc = () => {
    if (atlasW && fw > 0) {
      const cell = fw + spacing;
      const cellH = fh + spacing;
      const calculatedCols = Math.max(1, Math.floor((atlasW - margin * 2 + spacing) / cell));
      const calculatedRows = Math.max(1, Math.floor((atlasH - margin * 2 + spacing) / cellH));
      setCols(calculatedCols);
      setRows(calculatedRows);
      onSliceGrid(calculatedCols, calculatedRows, fw, fh, spacing, margin);
    }
  };

  const range = (a: number, b: number): number[] => {
    const [lo, hi] = a <= b ? [a, b] : [b, a];
    return Array.from({ length: hi - lo + 1 }, (_, k) => lo + k);
  };

  const handleCellDown = (e: React.MouseEvent, index: number) => {
    if (e.button !== 0) return;
    if (e.shiftKey && anchorRef.current !== null) {
      setSelected(range(anchorRef.current, index));
    } else if (e.ctrlKey || e.metaKey) {
      setSelected((s) => (s.includes(index) ? s.filter((i) => i !== index) : [...s, index]));
      anchorRef.current = index;
    } else {
      setSelected([index]);
      anchorRef.current = index;
    }
    draggingRef.current = true;
  };

  const handleCellEnter = (index: number) => {
    if (draggingRef.current && anchorRef.current !== null) setSelected(range(anchorRef.current, index));
  };

  const handleCreateAnimation = () => {
    const name = animName.trim() || `anim_${project.animations.length + 1}`;
    if (selected.length === 0) return;
    onCreateAnimation(name, selected);
    setAnimName('');
  };

  return (
    <div className="flex flex-col h-full bg-[#181c24] select-none overflow-y-auto">
      {/* Top Config Header */}
      <div className="flex flex-wrap items-center justify-between p-3 bg-[#202531] border-b border-[#2c3345] gap-3">
        {/* Presets Selector */}
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-semibold text-[#dfe4ec]">Modelos Prontos:</span>
          <select
            onChange={(e) => {
              if (e.target.value) {
                onLoadPreset(e.target.value);
                e.target.value = '';
              }
            }}
            defaultValue=""
            disabled={readOnly}
            className="bg-[#141822] text-xs text-[#cbd5e1] border border-[#374158] rounded px-2.5 py-1 focus:outline-none focus:border-sky-400 disabled:opacity-50"
          >
            <option value="" disabled>
              -- Carregar Personagem / Efeito --
            </option>
            {SPRITE_PRESETS.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.category})
              </option>
            ))}
          </select>
        </div>

        {/* Upload Custom Image */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={readOnly}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#2c374b] hover:bg-[#384660] text-sky-300 hover:text-white border border-[#3c4a64] text-xs transition-colors shadow-sm disabled:opacity-50"
            title="Importa a imagem para res://textures/ e a usa como atlas"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Importar Imagem (PNG/JPG/WebP)</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="hidden"
            data-testid="sprite-import-input"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                onUploadImage(e.target.files[0]);
                e.target.value = '';
              }
            }}
          />
        </div>
      </div>

      {/* Convert to Frames (grade) */}
      <div className="flex flex-wrap items-center gap-3 px-3 py-2 bg-[#1c222e] border-b border-[#2c3345] text-xs">
        <span className="font-semibold text-sky-400 flex items-center gap-1">
          <Scissors className="w-3.5 h-3.5 text-sky-400" />
          Convert to Frames:
        </span>

        {(
          [
            ['Colunas', cols, setCols, 1, 64, 'sprite-cols'],
            ['Linhas', rows, setRows, 1, 64, 'sprite-rows'],
            ['Largura (px)', fw, setFw, 1, 2048, 'sprite-fw'],
            ['Altura (px)', fh, setFh, 1, 2048, 'sprite-fh'],
            ['Separação', spacing, setSpacing, 0, 256, 'sprite-spacing'],
            ['Margem', margin, setMargin, 0, 256, 'sprite-margin'],
          ] as const
        ).map(([label, value, setter, min, max, testId]) => (
          <div key={label} className="flex items-center gap-1.5 bg-[#141822] px-2 py-1 rounded border border-[#2c3345]">
            <span className="text-[#8b97a8]">{label}:</span>
            <input
              type="number"
              min={min}
              max={max}
              value={value}
              data-testid={testId}
              onChange={(e) => setter(Math.max(min, Math.min(max, parseInt(e.target.value) || min)))}
              className={numberField}
            />
          </div>
        ))}

        <button
          onClick={handleApplySlice}
          disabled={readOnly}
          data-testid="sprite-convert"
          className="flex items-center gap-1 px-3 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded font-medium shadow-sm transition-colors disabled:opacity-50"
          title="Gera os quadros (regiões do atlas) pela grade ao lado"
        >
          <Check className="w-3.5 h-3.5" />
          <span>Converter ({cols * rows} quadros)</span>
        </button>

        <button
          onClick={handleAutoCalc}
          disabled={readOnly}
          className="flex items-center gap-1 px-2 py-1 bg-[#252d3d] hover:bg-[#323d53] text-[#cbd5e1] rounded transition-colors disabled:opacity-50"
          title="Auto-calcular colunas/linhas pelo tamanho da imagem, do quadro, da separação e da margem"
        >
          <RefreshCw className="w-3 h-3" />
          <span>Auto-Ajustar</span>
        </button>
      </div>

      {/* Seleção → animação */}
      <div className="flex flex-wrap items-center gap-3 px-3 py-1.5 bg-[#181c24] border-b border-[#2c3345] text-xs">
        <span className="font-semibold text-emerald-400 flex items-center gap-1">
          <MousePointerClick className="w-3.5 h-3.5" />
          Seleção:
        </span>
        <span className="text-[#8b97a8]" data-testid="sprite-selection-count">
          {selected.length === 0 ? 'clique, Shift (faixa), Ctrl/Cmd (alterna) ou arraste sobre os quadros' : `${selected.length} quadro(s): ${selected.slice(0, 12).map((i) => `#${i + 1}`).join(' ')}${selected.length > 12 ? '…' : ''}`}
        </span>
        <button onClick={() => setSelected(project.frames.map((_, i) => i))} className="px-2 py-0.5 rounded bg-[#252d3d] hover:bg-[#323d53] text-[#cbd5e1]">
          Todos
        </button>
        <button onClick={() => setSelected([])} disabled={selected.length === 0} className="px-2 py-0.5 rounded bg-[#252d3d] hover:bg-[#323d53] text-[#cbd5e1] disabled:opacity-40">
          Limpar
        </button>
        <input
          type="text"
          value={animName}
          onChange={(e) => setAnimName(e.target.value)}
          placeholder="nome da animação"
          data-testid="sprite-anim-name"
          className="w-36 px-1.5 py-0.5 bg-[#141822] text-white border border-[#2c3345] rounded"
        />
        <button
          onClick={handleCreateAnimation}
          disabled={selected.length === 0 || readOnly}
          data-testid="sprite-create-anim"
          className="flex items-center gap-1 px-2.5 py-0.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-40"
          title="Cria uma animação com os quadros selecionados, na ordem dos cliques"
        >
          <ListPlus className="w-3.5 h-3.5" />
          <span>Criar animação da seleção</span>
        </button>
        <button
          onClick={() => selected.length > 0 && onAppendToAnimation(selected)}
          disabled={selected.length === 0 || readOnly}
          data-testid="sprite-append-anim"
          className="px-2 py-0.5 rounded bg-[#273042] hover:bg-[#344059] text-emerald-300 border border-[#3b475e] disabled:opacity-40"
          title="Acrescenta os quadros selecionados ao fim da animação ativa"
        >
          Adicionar à animação{activeAnimationName ? ` "${activeAnimationName}"` : ''}
        </button>
        <button
          onClick={() => selected.length > 0 && onSelectFrame(selected[selected.length - 1])}
          disabled={selected.length === 0}
          className="px-2 py-0.5 rounded bg-[#273042] hover:bg-[#344059] text-sky-300 border border-[#3b475e] disabled:opacity-40"
          title="Abrir o último quadro selecionado no editor de pixel (ou duplo clique no quadro)"
        >
          Editar quadro
        </button>
      </div>

      {/* Spritesheet Canvas Display */}
      <div className="flex-1 p-6 flex flex-col items-center justify-center bg-[#12151d] overflow-auto">
        <div className="relative border-2 border-[#3b475e] rounded shadow-2xl bg-[#0c0e14] p-2">
          <div className="relative" style={{ width: atlasW, height: atlasH }}>
            {cfg.imageUrl ? (
              <img
                src={cfg.imageUrl}
                alt="Spritesheet Atlas"
                className="w-full h-full object-contain pointer-events-none"
                style={{ imageRendering: 'pixelated' }}
                onLoad={(e) => setNaturalSize({ w: e.currentTarget.naturalWidth, h: e.currentTarget.naturalHeight })}
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-xs text-[#64748b]">Nenhuma imagem carregada</div>
            )}

            {/* Pré-visualização ao vivo da grade do "Converter" */}
            {preview.map((p) => (
              <div
                key={`pv_${p.index}`}
                className="absolute border border-dashed border-amber-400/60 pointer-events-none"
                style={{ left: `${(p.x / atlasW) * 100}%`, top: `${(p.y / atlasH) * 100}%`, width: `${(p.width / atlasW) * 100}%`, height: `${(p.height / atlasH) * 100}%` }}
              />
            ))}

            {/* Células dos quadros atuais (selecionáveis) */}
            {project.frames.map((frame, index) => {
              const isCurrent = index === currentFrameIndex;
              const order = selected.indexOf(index);
              const isSelected = order >= 0;
              return (
                <div
                  key={frame.id || index}
                  data-testid={`sprite-cell-${index}`}
                  onMouseDown={(e) => handleCellDown(e, index)}
                  onMouseEnter={() => handleCellEnter(index)}
                  onDoubleClick={() => onSelectFrame(index)}
                  style={{
                    position: 'absolute',
                    left: `${(frame.x / atlasW) * 100}%`,
                    top: `${(frame.y / atlasH) * 100}%`,
                    width: `${(frame.width / atlasW) * 100}%`,
                    height: `${(frame.height / atlasH) * 100}%`,
                  }}
                  className={`border cursor-pointer transition-all flex items-start justify-start p-0.5 ${
                    isSelected ? 'border-emerald-400 bg-emerald-500/25 ring-2 ring-emerald-400' : isCurrent ? 'border-sky-400 bg-sky-500/20 ring-1 ring-sky-400' : 'border-white/20 hover:border-white/60 hover:bg-white/10'
                  }`}
                  title={`Quadro #${index + 1} (${frame.width}x${frame.height}px) — duplo clique abre no editor`}
                >
                  <span className={`font-mono text-[9px] px-1 rounded ${isSelected ? 'bg-emerald-500 text-white font-bold' : isCurrent ? 'bg-sky-500 text-white font-bold' : 'bg-black/60 text-white/80'}`}>
                    #{index + 1}
                    {isSelected && selected.length > 1 ? `·${order + 1}` : ''}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-4 text-xs text-[#8b97a8] flex items-center gap-4 flex-wrap justify-center">
          <span>
            Dimensões do Atlas: <strong>{cfg.imageWidth || naturalSize?.w || '?'}x{cfg.imageHeight || naturalSize?.h || '?'}px</strong>
          </span>
          <span>•</span>
          <span>
            Total de Quadros: <strong>{project.frames.length}</strong>
          </span>
          <span>•</span>
          <span>Tracejado âmbar = grade do Converter (ao vivo)</span>
        </div>
      </div>
    </div>
  );
};
