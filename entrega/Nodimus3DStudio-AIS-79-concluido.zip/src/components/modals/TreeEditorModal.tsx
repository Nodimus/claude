import React, { useState, useEffect, useMemo } from 'react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { globalCommandManager } from '../../core/commandManager';
import {
  Trees,
  Wind,
  Sliders,
  Palette,
  Layers,
  Sparkles,
  X,
  RotateCcw,
  Check,
  Eye,
  Info,
  ExternalLink,
  ChevronRight,
  Maximize2,
  RefreshCw,
  Mountain,
  Sun,
  Flame,
  CheckSquare,
  Square,
  Compass,
} from 'lucide-react';

import { PRESETS, type TreePresetConfig, type TreeSpeciesPreset, type FoliageStyle } from '../../core/tree/treePresets';
import { presetToGenerator } from '../../core/tree/treeParams';
import type { TreeStats } from '../../core/tree/treeBuild';
import { TreePreview3D } from './TreePreview3D';
import { barkManifestUri, listBarkOptions, resolveBarkMaps } from '../../core/tree/treeBark';
import { listLeafOptions, resolveLeafAtlas } from '../../core/tree/treeLeaf';
import { libraryManifestUri } from '../../core/library/assetLibrary';
import { ensureLibraryEntry } from '../../core/library/libraryUse';
import type { ICommand } from '../../types/commands';
import { globalAuthoringModel } from '../../core/authoring';
import { globalResourceRegistry, resourcePathOf } from '../../core/resources/global';
import { useResourceRegistryVersion } from '../../core/resources/useResources';
import { useGeneratorEdit } from '../../core/generators/useGeneratorEdit';
import { applyTreeToNode, registerTreeGenerator } from '../../core/generators/treeGenerator';
import { createSetGeneratorSourceCommand } from '../../core/generators/generatorCommands';
import { buildTreeNodeProperties, readTreeGeneratorSource, TREE_GENERATOR_ID, treeGeneratorSource, type TreeNodeInput } from '../../core/tree/treeNode';
import { distributeVegetation } from '../../core/vegetation/distributeVegetation';
import { buildBranchPrefab, sanitizePrefabName } from '../sceneTree/branchPrefab';

export const TreeEditorModal: React.FC = () => {
  const {
    isTreeEditorOpen,
    setIsTreeEditorOpen,
    activeScene,
    addNode,
    selectNode,
    addLog,
    createFile,
    updateNodeProperties,
    saveCurrentScene,
    project,
  } = useEditor();

  // "Editar no gerador" (AIS-49b/51c): o nó de árvore guarda como foi gerado e o modal reabre preenchido
  const gen = useGeneratorEdit(TREE_GENERATOR_ID);
  useEffect(() => registerTreeGenerator(), []);
  const [vegCount, setVegCount] = useState<number>(60);
  const [prefabName, setPrefabName] = useState<string>('');
  const [prefabError, setPrefabError] = useState<string | null>(null);

  const addWithCollision = useEditorStore((s) => s.addWithCollision); // preferência do editor (decisão 26, emenda v5.5)
  const setAddWithCollision = useEditorStore((s) => s.setAddWithCollision);

  // cascas = MaterialAssets do projeto + biblioteca embutida (AIS-51b); o select e o preview se refazem quando o projeto muda
  const resourcesVersion = useResourceRegistryVersion();
  const barkCtx = useMemo(() => ({ files: globalAuthoringModel.getProject().files as never, pathOf: resourcePathOf }), [resourcesVersion]); // eslint-disable-line react-hooks/exhaustive-deps

  const [activeTab, setActiveTab] = useState<'trunk' | 'branches' | 'leaves' | 'wind_lod'>('trunk');
  const [selectedPreset, setSelectedPreset] = useState<TreeSpeciesPreset>('oak');

  // Parameters state
  const [trunkHeight, setTrunkHeight] = useState<number>(PRESETS.oak.trunkHeight);
  const [trunkRadiusBase, setTrunkRadiusBase] = useState<number>(PRESETS.oak.trunkRadiusBase);
  const [trunkRadiusTop, setTrunkRadiusTop] = useState<number>(PRESETS.oak.trunkRadiusTop);
  const [trunkGnarl, setTrunkGnarl] = useState<number>(PRESETS.oak.trunkGnarl);
  const [trunkSegments, setTrunkSegments] = useState<number>(PRESETS.oak.trunkSegments);
  const [radialSegments, setRadialSegments] = useState<number>(PRESETS.oak.radialSegments);
  const [barkTexture, setBarkTexture] = useState<string>(PRESETS.oak.barkTexture);
  const [barkColor, setBarkColor] = useState<string>(PRESETS.oak.barkColor);
  const [rootFlare, setRootFlare] = useState<boolean>(PRESETS.oak.rootFlare);

  // Branches
  const [branchLevels, setBranchLevels] = useState<number>(PRESETS.oak.branchLevels);
  const [branchStartHeight, setBranchStartHeight] = useState<number>(PRESETS.oak.branchStartHeight);
  const [branchesPerLevel, setBranchesPerLevel] = useState<number>(PRESETS.oak.branchesPerLevel);
  const [branchAngle, setBranchAngle] = useState<number>(PRESETS.oak.branchAngle);
  const [branchLength, setBranchLength] = useState<number>(PRESETS.oak.branchLength);
  const [branchDroop, setBranchDroop] = useState<number>(PRESETS.oak.branchDroop);
  const [subBranching, setSubBranching] = useState<boolean>(PRESETS.oak.subBranching);

  // Foliage
  const [foliageStyle, setFoliageStyle] = useState<FoliageStyle>(PRESETS.oak.foliageStyle);
  const [leafSize, setLeafSize] = useState<number>(PRESETS.oak.leafSize);
  const [leafDensity, setLeafDensity] = useState<number>(PRESETS.oak.leafDensity);
  const [leafTexture, setLeafTexture] = useState<string>(PRESETS.oak.leafTexture);
  const [leafColor, setLeafColor] = useState<string>(PRESETS.oak.leafColor);
  const [leafRandomAngle, setLeafRandomAngle] = useState<number>(PRESETS.oak.leafRandomAngle);

  // Wind & LOD
  const [windEnabled, setWindEnabled] = useState<boolean>(PRESETS.oak.windEnabled);
  const [windStrength, setWindStrength] = useState<number>(PRESETS.oak.windStrength);
  const [windFrequency, setWindFrequency] = useState<number>(PRESETS.oak.windFrequency);
  const [leafFlutter, setLeafFlutter] = useState<number>(PRESETS.oak.leafFlutter);
  const [randomSeed, setRandomSeed] = useState<number>(42);
  const [wireframeMode, setWireframeMode] = useState<boolean>(false);
  const [animateWindPreview, setAnimateWindPreview] = useState<boolean>(true);
  const [previewRotation, setPreviewRotation] = useState<number>(0);

  /** Preenche todos os campos do modal a partir de uma configuração (espécie ou sobrescritas salvas no nó). */
  const loadFields = (p: TreePresetConfig) => {
    setTrunkHeight(p.trunkHeight);
    setTrunkRadiusBase(p.trunkRadiusBase);
    setTrunkRadiusTop(p.trunkRadiusTop);
    setTrunkGnarl(p.trunkGnarl);
    setTrunkSegments(p.trunkSegments);
    setRadialSegments(p.radialSegments);
    setBarkTexture(p.barkTexture);
    setBarkColor(p.barkColor);
    setRootFlare(p.rootFlare);
    setBranchLevels(p.branchLevels);
    setBranchStartHeight(p.branchStartHeight);
    setBranchesPerLevel(p.branchesPerLevel);
    setBranchAngle(p.branchAngle);
    setBranchLength(p.branchLength);
    setBranchDroop(p.branchDroop);
    setSubBranching(p.subBranching);
    setFoliageStyle(p.foliageStyle);
    setLeafSize(p.leafSize);
    setLeafDensity(p.leafDensity);
    setLeafTexture(p.leafTexture);
    setLeafColor(p.leafColor);
    setLeafRandomAngle(p.leafRandomAngle);
    setWindEnabled(p.windEnabled);
    setWindStrength(p.windStrength);
    setWindFrequency(p.windFrequency);
    setLeafFlutter(p.leafFlutter);
  };

  // Apply preset
  const applyPreset = (presetKey: TreeSpeciesPreset) => {
    setSelectedPreset(presetKey);
    loadFields(PRESETS[presetKey]);
    setRandomSeed(Math.floor(Math.random() * 9999));
  };

  // Re-roll seed
  const randomizeSeed = () => {
    setRandomSeed(Math.floor(Math.random() * 99999));
  };

  // TreeParams corrente: os campos do modal sobre o preset da espécie (uma só fonte para preview e cena)
  const currentPreset: TreePresetConfig = useMemo(() => ({
    ...PRESETS[selectedPreset],
    trunkHeight, trunkRadiusBase, trunkRadiusTop, trunkGnarl, trunkSegments, radialSegments, barkTexture, barkColor, rootFlare,
    branchLevels, branchStartHeight, branchesPerLevel, branchAngle, branchLength, branchDroop, subBranching,
    foliageStyle, leafSize, leafDensity, leafTexture, leafColor, leafRandomAngle,
    windEnabled, windStrength, windFrequency, leafFlutter,
  }), [selectedPreset, trunkHeight, trunkRadiusBase, trunkRadiusTop, trunkGnarl, trunkSegments, radialSegments, barkTexture, barkColor, rootFlare,
    branchLevels, branchStartHeight, branchesPerLevel, branchAngle, branchLength, branchDroop, subBranching,
    foliageStyle, leafSize, leafDensity, leafTexture, leafColor, leafRandomAngle, windEnabled, windStrength, windFrequency, leafFlutter]);
  const treeParams = useMemo(() => presetToGenerator(currentPreset, randomSeed), [currentPreset, randomSeed]);
  const barkOptions = useMemo(() => listBarkOptions(barkCtx.files), [barkCtx]);
  const barkMaps = useMemo(() => resolveBarkMaps(barkTexture, null, barkCtx), [barkTexture, barkCtx]);
  const leafOptions = useMemo(() => listLeafOptions(barkCtx.files), [barkCtx]);
  const leafAtlas = useMemo(() => resolveLeafAtlas(leafTexture, null, barkCtx), [leafTexture, barkCtx]);

  // estatísticas reais, vindas da geometria construída pelo preview
  const [stats, setStats] = useState<TreeStats>({ triangles: 0, vertices: 0, branchTriangles: 0, foliageInstances: 0, materials: 1 });
  const estimatedStats = {
    triangles: Math.round(stats.triangles),
    vertices: Math.round(stats.vertices),
    materials: stats.materials,
    estimatedMemoryKb: Math.max(1, Math.round((stats.vertices * 24 + stats.triangles * 12) / 1024)),
  };

  // "Editar no gerador": reabre o modal com a espécie, as sobrescritas e a seed salvas no nó
  const editedSourceKey = gen.editing ? `${gen.nodeId}` : '';
  useEffect(() => {
    if (!isTreeEditorOpen || !gen.editing) return;
    const saved = readTreeGeneratorSource(gen.source);
    if (!saved) {
      addLog('warn', 'O generatorSource deste nó não é de uma árvore reconhecível; o modal abre com os padrões (o dado bruto continua no nó).');
      return;
    }
    setSelectedPreset(saved.params.preset);
    loadFields(saved.params.config);
    setRandomSeed(saved.seed);
    setPrefabName(gen.nodeName ?? '');
  }, [isTreeEditorOpen, editedSourceKey]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!isTreeEditorOpen) return null;

  /** Fecha o modal e encerra a edição do gerador (nada é aplicado ao nó sem "Aplicar ao nó"). */
  const close = () => {
    gen.cancel();
    setPrefabError(null);
    setIsTreeEditorOpen(false);
  };

  /**
   * Casca e folhagem: as da biblioteca (padrão) são importadas para o projeto (AssetPipeline) só agora; a árvore guarda o ResourceRef do
   * MaterialAsset. Devolve os `TreeParams` finais e os Commands de importação (o Undo da ação os remove).
   */
  const prepareTree = async (): Promise<{ input: TreeNodeInput; importCommands: ICommand[] }> => {
    const importCommands: ICommand[] = [];
    let barkMaterial = globalResourceRegistry.refForUri(barkManifestUri(barkTexture)) ?? null;
    if (!barkMaterial) {
      const bark = await ensureLibraryEntry('tree', barkTexture);
      if (bark.ok && bark.manifest) { barkMaterial = bark.manifest; if (bark.command) importCommands.push(bark.command); }
      else addLog('warn', `Casca "${barkTexture}" não importada (${bark.ok ? 'sem manifesto' : bark.error}); a árvore usa só a cor da casca.`);
    }
    let leafMaterial = leafTexture === 'None' ? null : (globalResourceRegistry.refForUri(libraryManifestUri(leafTexture)) ?? null);
    if (!leafMaterial && leafTexture !== 'None') {
      const leaf = await ensureLibraryEntry('tree', leafTexture);
      if (leaf.ok && leaf.manifest) { leafMaterial = leaf.manifest; if (leaf.command) importCommands.push(leaf.command); }
      else addLog('warn', `Folhagem "${leafTexture}" não importada (${leaf.ok ? 'sem manifesto' : leaf.error}); a árvore usa só a cor da folha.`);
    }
    const params = { ...treeParams, material: { ...treeParams.material, barkMaterial }, foliage: { ...treeParams.foliage, leafMaterial } };
    return { input: { preset: selectedPreset, config: currentPreset, treeParams: params, seed: randomSeed }, importCommands };
  };

  /** Cria um nó de árvore novo (um MacroCommand: imports + nó + `generatorSource`); devolve o id. */
  const insertNewTree = async (): Promise<string> => {
    const { input, importCommands } = await prepareTree();
    const treeNodeName = `Tree_${PRESETS[selectedPreset].species.toUpperCase()}_${Date.now().toString().slice(-4)}`;
    // decisão 26: a árvore nasce com o bloco de colisão (estático, auto = cilindro no tronco) ligado ou desligado pela preferência
    const newNode = globalCommandManager.transaction('Create Tree', () => {
      // o que esta inserção importou sai junto no Undo (antes do nó na pilha: o Undo dos imports roda por último)
      for (const c of importCommands) globalCommandManager.pushCommand(c);
      const node = addNode('MeshInstance', activeScene.rootNodeId, treeNodeName, {
        ...buildTreeNodeProperties(input),
        physics: { enabled: addWithCollision, bodyMode: 'static', shape: 'auto' },
      });
      const marca = createSetGeneratorSourceCommand({ target: globalAuthoringModel, nodeId: node.id, source: treeGeneratorSource(input) });
      if (marca) globalCommandManager.pushCommand(marca);
      return node;
    });
    selectNode(newNode.id);
    addLog('log', `Generated procedural tree "${treeNodeName}" (${estimatedStats.triangles} triangles, ${estimatedStats.vertices} vertices, Wind: ${windEnabled ? 'Enabled' : 'Disabled'})`);
    return newNode.id;
  };

  // Insert tree into active scene ("Inserir novo" também em modo edição: cria outra árvore, o nó editado não muda)
  const handleInsertTree = async () => {
    await insertNewTree();
    close();
  };

  /** Terrain que recebe a floresta: o selecionado ou, na falta, o primeiro da cena. */
  const targetTerrain = (() => {
    const sel = useEditorStore.getState().selectedNodeId;
    const selected = sel ? activeScene.nodes[sel] : undefined;
    if (selected?.type === 'Terrain') return selected;
    return Object.values(activeScene.nodes).find((n) => n.type === 'Terrain');
  })();

  /** "Distribuir no Terreno" (AIS-51d): UM Command (imports + nó Vegetation filho do terreno); Ctrl+Z desfaz tudo. */
  const handleDistribute = async () => {
    if (!targetTerrain) return;
    const { input, importCommands } = await prepareTree();
    const node = distributeVegetation(
      { terrainId: targetTerrain.id, treeProps: buildTreeNodeProperties(input), params: { count: vegCount, seed: randomSeed }, name: `Vegetation_${PRESETS[selectedPreset].species}`, importCommands },
      addNode,
    );
    addLog('log', `Árvore distribuída em "${targetTerrain.name}" (${node.name}, ${vegCount} árvores, seed ${randomSeed}).`);
    close();
  };

  /** "Aplicar ao nó": propriedades + `generatorSource` do nó editado como UM MacroCommand (1 Undo), in-place. */
  const handleApplyToNode = async () => {
    if (!gen.editing || !gen.nodeId) return;
    const nodeId = gen.nodeId;
    const { input, importCommands } = await prepareTree();
    globalCommandManager.transaction('Apply Tree', () => {
      for (const c of importCommands) globalCommandManager.pushCommand(c);
      applyTreeToNode(nodeId, input, 'Aplicar ao nó');
    });
    addLog('log', `Árvore "${gen.nodeName}" atualizada.`);
    close();
  };

  /** "Salvar como Prefab" (decisão 18): `res://prefabs/<nome>.prefab.json` com o mesmo serviço da SceneTree; preserva `generatorSource` e o ResourceRef da casca. */
  const handleSaveAsPrefab = async () => {
    setPrefabError(null);
    const name = sanitizePrefabName(prefabName || `Tree_${PRESETS[selectedPreset].species}`);
    const path = `res://prefabs/${name}.prefab.json`;
    if (project.files[path]) {
      setPrefabError(`Já existe um Prefab em ${path}.`);
      return;
    }
    // sem nó em edição, a árvore atual é inserida na cena e salva (o nó continua na cena, ligado ao prefab)
    const nodeId = gen.editing && gen.nodeId ? gen.nodeId : await insertNewTree();
    if (gen.editing && gen.nodeId) {
      // em edição: o prefab leva o estado atual do modal (aplicado ao nó antes)
      const { input, importCommands } = await prepareTree();
      globalCommandManager.transaction('Apply Tree', () => {
        for (const c of importCommands) globalCommandManager.pushCommand(c);
        applyTreeToNode(nodeId, input, 'Aplicar ao nó');
      });
    }
    const scene = globalAuthoringModel.getScene();
    const node = scene.nodes[nodeId];
    if (!node) { setPrefabError('Não foi possível localizar a árvore na cena.'); return; }
    const timestamp = new Date().toISOString();
    const prefabId = `prefab_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    const prefab = buildBranchPrefab(scene, nodeId, name, path, prefabId, timestamp);
    if (!prefab) { setPrefabError('Não foi possível serializar esta árvore.'); return; }
    createFile(path, JSON.stringify(prefab, null, 2));
    updateNodeProperties(nodeId, { prefabRef: { id: prefab.id, path, rootNodeId: prefab.rootNodeId, status: 'resolved' } });
    saveCurrentScene();
    addLog('log', `Árvore "${node.name}" salva como Prefab ${path}`);
    close();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 select-none animate-in fade-in duration-150">
      <div className="bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-5xl h-[92vh] max-h-[820px] flex flex-col overflow-hidden text-sm text-[#d4dbe8]">
        {/* Header */}
        <div className="px-5 py-3.5 bg-[#141720] border-b border-[#242b3b] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <Trees className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-semibold text-white text-base">
                  Tree Editor & Generator
                </h2>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
                  CopperCube Procedural
                </span>
              </div>
              <p className="text-xs text-[#828f9f] mt-0.5">
                Gere árvores 3D procedurais e folhagens otimizadas com animação de vento em tempo real{gen.editing && <span data-testid="tree-editing-badge" className="ml-2 px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">Editando: {gen.nodeName}</span>}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="https://www.ambiera.com/coppercube/doc/cnt_terrain.html"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 text-xs text-[#828f9f] hover:text-[#c5d0e2] hover:bg-[#202636] border border-transparent hover:border-[#2f394c] rounded flex items-center gap-1.5 transition-colors"
              title="CopperCube Documentation"
            >
              <span>Doc</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={close}
              className="p-1.5 text-[#828f9f] hover:text-white hover:bg-[#252c3c] rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Species Presets Quick Toolbar */}
        <div className="px-5 py-2.5 bg-[#12151d] border-b border-[#202636] flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-[11px] font-semibold text-[#6d7a8d] uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" /> Presets:
          </span>
          {(Object.keys(PRESETS) as TreeSpeciesPreset[]).map((key) => {
            const p = PRESETS[key];
            const isSelected = selectedPreset === key;
            return (
              <button
                key={key}
                onClick={() => applyPreset(key)}
                className={`px-2.5 py-1 text-xs rounded-md border flex items-center gap-1.5 shrink-0 transition-all ${
                  isSelected
                    ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 font-medium shadow-sm shadow-emerald-950'
                    : 'bg-[#181c26] border-[#262e3e] text-[#8e9cb0] hover:text-[#dfe4ec] hover:border-[#384358]'
                }`}
              >
                <span>{p.name.split(' ')[0]}</span>
                {isSelected && <Check className="w-3 h-3 text-emerald-400" />}
              </button>
            );
          })}
        </div>

        {/* Main Content: Two Columns */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Column: Tabs & Parameters */}
          <div className="w-[58%] border-r border-[#242b3b] flex flex-col bg-[#161a24]">
            {/* Category Tabs */}
            <div className="flex border-b border-[#222838] bg-[#141721] px-3 pt-2 gap-1 shrink-0">
              <button
                onClick={() => setActiveTab('trunk')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'trunk'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-amber-400" />
                <span>Trunk (Tronco)</span>
              </button>

              <button
                onClick={() => setActiveTab('branches')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'branches'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                <span>Branches (Galhos)</span>
              </button>

              <button
                onClick={() => setActiveTab('leaves')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'leaves'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Trees className="w-3.5 h-3.5 text-emerald-400" />
                <span>Leaves & Foliage</span>
              </button>

              <button
                onClick={() => setActiveTab('wind_lod')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'wind_lod'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Wind className="w-3.5 h-3.5 text-cyan-400" />
                <span>Wind & LOD</span>
              </button>
            </div>

            {/* Tab Panels with Smooth Scroll */}
            <div className="flex-1 overflow-y-auto p-5 space-y-5 text-xs text-[#a9b6c8]">
              {/* TAB 1: TRUNK */}
              {activeTab === 'trunk' && (
                <div className="space-y-4">
                  <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg">
                    <h3 className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
                      <Layers className="w-4 h-4 text-amber-400" />
                      Geometria do Tronco (Trunk Geometry)
                    </h3>
                    <p className="text-[11px] text-[#788496]">
                      Ajuste altura, curvatura orgânica, espessura e resolução radial para a malha cilíndrica.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Trunk Height (Altura)</label>
                        <span className="font-mono text-emerald-400">{trunkHeight.toFixed(1)}m</span>
                      </div>
                      <input
                        type="range"
                        min="2.0"
                        max="22.0"
                        step="0.5"
                        value={trunkHeight}
                        onChange={(e) => setTrunkHeight(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Base Radius (Raio da Base)</label>
                        <span className="font-mono text-emerald-400">{trunkRadiusBase.toFixed(2)}m</span>
                      </div>
                      <input
                        type="range"
                        min="0.1"
                        max="1.5"
                        step="0.05"
                        value={trunkRadiusBase}
                        onChange={(e) => setTrunkRadiusBase(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Top Radius (Raio do Topo)</label>
                        <span className="font-mono text-emerald-400">{trunkRadiusTop.toFixed(2)}m</span>
                      </div>
                      <input
                        type="range"
                        min="0.05"
                        max="0.8"
                        step="0.02"
                        value={trunkRadiusTop}
                        onChange={(e) => setTrunkRadiusTop(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Gnarl / Curvature (Curvatura)</label>
                        <span className="font-mono text-emerald-400">{(trunkGnarl * 100).toFixed(0)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0.0"
                        max="1.0"
                        step="0.05"
                        value={trunkGnarl}
                        onChange={(e) => setTrunkGnarl(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>
                  </div>

                  <div className="border-t border-[#232a3a] pt-4 grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Radial Segments (Resolução Vértices)</label>
                        <span className="font-mono text-emerald-400">{radialSegments} lados</span>
                      </div>
                      <input
                        type="range"
                        min="5"
                        max="16"
                        step="1"
                        value={radialSegments}
                        onChange={(e) => setRadialSegments(parseInt(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                      <span className="text-[10px] text-[#697587]">
                        CopperCube padrão: 7 a 9 vértices para performance máxima em tempo real.
                      </span>
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Height Segments (Anéis)</label>
                        <span className="font-mono text-emerald-400">{trunkSegments}</span>
                      </div>
                      <input
                        type="range"
                        min="4"
                        max="16"
                        step="1"
                        value={trunkSegments}
                        onChange={(e) => setTrunkSegments(parseInt(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>
                  </div>

                  {/* Bark Material */}
                  <div className="border-t border-[#232a3a] pt-4 space-y-3">
                    <h4 className="text-white font-medium flex items-center gap-2">
                      <Palette className="w-3.5 h-3.5 text-amber-400" />
                      Material e Textura da Casca (Bark Texture)
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-[#98a5b8] mb-1 block">Textura da Casca</label>
                        <select
                          value={barkTexture}
                          onChange={(e) => setBarkTexture(e.target.value)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs focus:outline-none focus:border-emerald-500"
                        >
                          {barkOptions.map((o) => (
                            <option key={o.id} value={o.id} title={o.note}>
                              {o.label}
                              {o.source === 'library' ? ' · biblioteca' : ''}
                            </option>
                          ))}
                          {!barkOptions.some((o) => o.id === barkTexture) && <option value={barkTexture}>{barkTexture} (sem textura)</option>}
                        </select>
                      </div>

                      <div>
                        <label className="text-[#98a5b8] mb-1 block">Tonalidade / Bark Color</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={barkColor}
                            onChange={(e) => setBarkColor(e.target.value)}
                            className="w-8 h-8 rounded border border-[#2b3345] bg-transparent cursor-pointer p-0.5"
                          />
                          <input
                            type="text"
                            value={barkColor}
                            onChange={(e) => setBarkColor(e.target.value)}
                            className="flex-1 bg-[#1b202c] border border-[#2c3447] rounded px-2.5 py-1.5 text-white font-mono text-xs uppercase"
                          />
                        </div>
                      </div>
                    </div>

                    <label className="flex items-center gap-2 text-[#c4cfdf] cursor-pointer mt-2">
                      <input
                        type="checkbox"
                        checked={rootFlare}
                        onChange={(e) => setRootFlare(e.target.checked)}
                        className="rounded border-[#2c3447] bg-[#1a1f2b] text-emerald-500 focus:ring-0"
                      />
                      <span>Gerar raízes superficiais na base (Root Flare / Buttress)</span>
                    </label>
                  </div>
                </div>
              )}

              {/* TAB 2: BRANCHES */}
              {activeTab === 'branches' && (
                <div className="space-y-4">
                  <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg">
                    <h3 className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
                      <ChevronRight className="w-4 h-4 text-blue-400" />
                      Sistema de Ramos e Galhos (Branching Architecture)
                    </h3>
                    <p className="text-[11px] text-[#788496]">
                      Controle os parâmetros de ramificação idênticos ao CopperCube (First branch segment, Branch degrees, Segment count).
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Branch Levels (Níveis de Ramos)</label>
                        <span className="font-mono text-blue-400">{branchLevels}</span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="8"
                        step="1"
                        value={branchLevels}
                        onChange={(e) => setBranchLevels(parseInt(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Branches Per Level (Ramos p/ Nível)</label>
                        <span className="font-mono text-blue-400">{branchesPerLevel}</span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="10"
                        step="1"
                        value={branchesPerLevel}
                        onChange={(e) => setBranchesPerLevel(parseInt(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">First Branch Height (Início da Copa)</label>
                        <span className="font-mono text-blue-400">{(branchStartHeight * 100).toFixed(0)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0.1"
                        max="0.95"
                        step="0.05"
                        value={branchStartHeight}
                        onChange={(e) => setBranchStartHeight(parseFloat(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                      <span className="text-[10px] text-[#697587]">
                        Define onde o tronco começa a ramificar (alto para palmeiras, médio para carvalho).
                      </span>
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Branch Degrees / Angle (Ângulo)</label>
                        <span className="font-mono text-blue-400">{branchAngle}°</span>
                      </div>
                      <input
                        type="range"
                        min="20"
                        max="88"
                        step="2"
                        value={branchAngle}
                        onChange={(e) => setBranchAngle(parseInt(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Branch Length (Comprimento)</label>
                        <span className="font-mono text-blue-400">{branchLength.toFixed(1)}m</span>
                      </div>
                      <input
                        type="range"
                        min="1.0"
                        max="8.0"
                        step="0.2"
                        value={branchLength}
                        onChange={(e) => setBranchLength(parseFloat(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Branch Droop / Gravity (Gravidade)</label>
                        <span className="font-mono text-blue-400">{branchDroop.toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min="-1.0"
                        max="1.0"
                        step="0.05"
                        value={branchDroop}
                        onChange={(e) => setBranchDroop(parseFloat(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                      <span className="text-[10px] text-[#697587]">
                        Negativo: galhos caídos (salgueiro). Positivo: apontando para cima (pinheiro).
                      </span>
                    </div>
                  </div>

                  <div className="border-t border-[#232a3a] pt-4">
                    <label className="flex items-center gap-2 text-[#c4cfdf] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={subBranching}
                        onChange={(e) => setSubBranching(e.target.checked)}
                        className="rounded border-[#2c3447] bg-[#1a1f2b] text-blue-500 focus:ring-0"
                      />
                      <div>
                        <span className="font-medium">Ativar Sub-ramificação (Secondary Twig Splits)</span>
                        <p className="text-[10px] text-[#697587]">
                          Cria ramificações finas secundárias nas extremidades dos galhos principais.
                        </p>
                      </div>
                    </label>
                  </div>
                </div>
              )}

              {/* TAB 3: LEAVES & FOLIAGE */}
              {activeTab === 'leaves' && (
                <div className="space-y-4">
                  <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg">
                    <h3 className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
                      <Trees className="w-4 h-4 text-emerald-400" />
                      Folhas e Copa (Leaves & Foliage Cards)
                    </h3>
                    <p className="text-[11px] text-[#788496]">
                      Configuração de planos de folhas com recorte alfa, tamanho e densidade de cobertura.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[#c4cfdf] font-medium mb-1 block">Estilo de Folhagem</label>
                      <select
                        value={foliageStyle}
                        onChange={(e) => setFoliageStyle(e.target.value as FoliageStyle)}
                        className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs focus:outline-none focus:border-emerald-500"
                      >
                        <option value="cards">Cross Quads (Cartões Cruzados Alpha)</option>
                        <option value="clusters">Volumetric Puffs (Moitas Esféricas)</option>
                        <option value="fronds">Tropical Fronds (Palmas Grandes)</option>
                        <option value="needles">Pine Needles (Agulhas de Conífera)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[#c4cfdf] font-medium mb-1 block">Textura da Folhagem</label>
                      <select
                        value={leafTexture}
                        onChange={(e) => setLeafTexture(e.target.value)}
                        className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs focus:outline-none focus:border-emerald-500"
                      >
                        <option value="None">Sem textura (cor sólida)</option>
                        {leafOptions.map((o) => (
                          <option key={o.id} value={o.id} title={o.note}>
                            {o.label}
                            {o.source === 'library' ? ' · biblioteca' : ''}
                          </option>
                        ))}
                        {leafTexture !== 'None' && !leafOptions.some((o) => o.id === leafTexture) && <option value={leafTexture}>{leafTexture} (sem textura)</option>}
                      </select>
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Leaf Size (Tamanho da Folha)</label>
                        <span className="font-mono text-emerald-400">{leafSize.toFixed(2)}m</span>
                      </div>
                      <input
                        type="range"
                        min="0.0"
                        max="2.5"
                        step="0.05"
                        value={leafSize}
                        onChange={(e) => setLeafSize(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Leaf Density (Densidade da Copa)</label>
                        <span className="font-mono text-emerald-400">{leafDensity}</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        step="2"
                        value={leafDensity}
                        onChange={(e) => setLeafDensity(parseInt(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                      <span className="text-[10px] text-[#697587]">
                        Defina 0 para árvores mortas/secas sem folhas.
                      </span>
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Leaf Rotation Randomness</label>
                        <span className="font-mono text-emerald-400">{(leafRandomAngle * 100).toFixed(0)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0.0"
                        max="1.0"
                        step="0.05"
                        value={leafRandomAngle}
                        onChange={(e) => setLeafRandomAngle(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="text-[#c4cfdf] font-medium mb-1 block">Cor da Folhagem (Leaf Tint)</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={leafColor}
                          onChange={(e) => setLeafColor(e.target.value)}
                          className="w-8 h-8 rounded border border-[#2b3345] bg-transparent cursor-pointer p-0.5"
                        />
                        <input
                          type="text"
                          value={leafColor}
                          onChange={(e) => setLeafColor(e.target.value)}
                          className="flex-1 bg-[#1b202c] border border-[#2c3447] rounded px-2.5 py-1.5 text-white font-mono text-xs uppercase"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-[#232a3a] pt-3 flex items-center justify-between">
                    <span className="text-[11px] text-[#8695a8]">
                      ✔ Alpha Cutout habilitado (sem artefatos de ordenação de transparência)
                    </span>
                    <span className="text-[11px] text-[#8695a8]">
                      ✔ Double-Sided Rendering ativado
                    </span>
                  </div>
                </div>
              )}

              {/* TAB 4: WIND & LOD */}
              {activeTab === 'wind_lod' && (
                <div className="space-y-4">
                  <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg">
                    <h3 className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
                      <Wind className="w-4 h-4 text-cyan-400" />
                      Animação de Vento em Tempo Real (CopperCube Animated Mesh)
                    </h3>
                    <p className="text-[11px] text-[#788496]">
                      O CopperCube suporta movimento automático de folhas e galhos por vento com parâmetros na raiz.
                    </p>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-[#181d29] border border-[#262f40] rounded-lg">
                    <div>
                      <div className="font-medium text-white flex items-center gap-2">
                        <Wind className="w-4 h-4 text-cyan-400" />
                        <span>Ativar Animação Procedural de Vento</span>
                      </div>
                      <p className="text-[10px] text-[#7c889a] mt-0.5">
                        Aplica shader vertex displacement oscilatório nos galhos e folhas
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={windEnabled}
                        onChange={(e) => setWindEnabled(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-[#252c3c] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500"></div>
                    </label>
                  </div>

                  {windEnabled && (
                    <div className="grid grid-cols-2 gap-4 pt-2">
                      <div>
                        <div className="flex justify-between mb-1">
                          <label className="text-[#c4cfdf] font-medium">Wind Sway Strength (Força do Balanço)</label>
                          <span className="font-mono text-cyan-400">{(windStrength * 100).toFixed(0)}%</span>
                        </div>
                        <input
                          type="range"
                          min="0.05"
                          max="1.0"
                          step="0.05"
                          value={windStrength}
                          onChange={(e) => setWindStrength(parseFloat(e.target.value))}
                          className="w-full accent-cyan-500"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between mb-1">
                          <label className="text-[#c4cfdf] font-medium">Wind Frequency (Velocidade do Vento)</label>
                          <span className="font-mono text-cyan-400">{windFrequency.toFixed(1)} Hz</span>
                        </div>
                        <input
                          type="range"
                          min="0.3"
                          max="3.0"
                          step="0.1"
                          value={windFrequency}
                          onChange={(e) => setWindFrequency(parseFloat(e.target.value))}
                          className="w-full accent-cyan-500"
                        />
                      </div>

                      <div className="col-span-2">
                        <div className="flex justify-between mb-1">
                          <label className="text-[#c4cfdf] font-medium">Leaf Flutter (Tremulação das Folhas)</label>
                          <span className="font-mono text-cyan-400">{(leafFlutter * 100).toFixed(0)}%</span>
                        </div>
                        <input
                          type="range"
                          min="0.0"
                          max="1.0"
                          step="0.05"
                          value={leafFlutter}
                          onChange={(e) => setLeafFlutter(parseFloat(e.target.value))}
                          className="w-full accent-cyan-500"
                        />
                      </div>
                    </div>
                  )}

                  {/* Seed and Randomizer */}
                  <div className="border-t border-[#232a3a] pt-4 space-y-3">
                    <h4 className="text-white font-medium flex items-center gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      Semente de Variação (Random Seed)
                    </h4>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 flex items-center justify-between">
                        <span className="text-[#7f8da0] text-xs">Seed ID:</span>
                        <span className="font-mono text-white text-xs font-semibold">{randomSeed}</span>
                      </div>
                      <button
                        onClick={randomizeSeed}
                        className="px-3 py-1.5 bg-[#212735] hover:bg-[#2b3346] border border-[#303a4e] text-white rounded text-xs flex items-center gap-1.5 transition-colors"
                      >
                        <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
                        <span>Sortear Variação</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Live 3D / 2.5D Real-Time Preview Canvas */}
          <div className="w-[42%] flex flex-col bg-[#11141c]">
            {/* Canvas Header Toolbar */}
            <div className="px-3.5 py-2 bg-[#141822] border-b border-[#212737] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Eye className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-xs font-medium text-white">Preview 3D Interativo</span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setAnimateWindPreview(!animateWindPreview)}
                  className={`px-2 py-0.5 text-[11px] rounded flex items-center gap-1 transition-colors ${
                    animateWindPreview
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                      : 'bg-[#1b202c] text-[#7c889a] border border-[#2a3244]'
                  }`}
                  title="Alternar simulação de vento em tempo real no preview"
                >
                  <Wind className="w-3 h-3" />
                  <span>Vento</span>
                </button>

                <button
                  onClick={() => setWireframeMode(!wireframeMode)}
                  className={`px-2 py-0.5 text-[11px] rounded flex items-center gap-1 transition-colors ${
                    wireframeMode
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-[#1b202c] text-[#7c889a] border border-[#2a3244]'
                  }`}
                  title="Alternar visualização em arame (wireframe)"
                >
                  <span>Wireframe</span>
                </button>
              </div>
            </div>

            {/* Interactive Canvas */}
            <div className="flex-1 relative flex items-center justify-center p-2 bg-[#0e1117] overflow-hidden">
              <TreePreview3D
                active={isTreeEditorOpen}
                params={treeParams}
                barkMaps={barkMaps}
                leafAtlas={leafAtlas}
                wireframeMode={wireframeMode}
                animateWindPreview={animateWindPreview}
                previewRotation={previewRotation}
                onStats={setStats}
              />

              {/* Angle rotation slider overlay */}
              <div className="absolute bottom-3 left-3 right-3 bg-[#161a25]/90 border border-[#262e40] rounded-lg px-3 py-1.5 flex items-center gap-2 backdrop-blur-sm">
                <Compass className="w-3.5 h-3.5 text-[#738297] shrink-0" />
                <span className="text-[10px] text-[#738297] shrink-0">Rotação:</span>
                <input
                  type="range"
                  min="-180"
                  max="180"
                  value={previewRotation}
                  onChange={(e) => setPreviewRotation(parseInt(e.target.value))}
                  className="flex-1 accent-emerald-500 h-1.5"
                />
                <button
                  onClick={() => setPreviewRotation(0)}
                  className="text-[10px] text-[#8695a8] hover:text-white px-1.5 py-0.5 rounded bg-[#202636]"
                >
                  0°
                </button>
              </div>
            </div>

            {/* Mesh Statistics Readout */}
            <div className="p-3 bg-[#141822] border-t border-[#212737] space-y-2 shrink-0">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-[#728094] uppercase tracking-wider font-semibold">Estatísticas da Malha</span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-[#1c2230] text-emerald-400 border border-[#293246]">
                  Game Ready
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-[#181d29] px-2.5 py-1.5 rounded border border-[#242c3d] flex justify-between items-center">
                  <span className="text-[#8492a5]">Triângulos:</span>
                  <span className="font-mono text-white font-medium">~{estimatedStats.triangles.toLocaleString()}</span>
                </div>
                <div className="bg-[#181d29] px-2.5 py-1.5 rounded border border-[#242c3d] flex justify-between items-center">
                  <span className="text-[#8492a5]">Vértices:</span>
                  <span className="font-mono text-white font-medium">~{estimatedStats.vertices.toLocaleString()}</span>
                </div>
                <div className="bg-[#181d29] px-2.5 py-1.5 rounded border border-[#242c3d] flex justify-between items-center">
                  <span className="text-[#8492a5]">Materiais:</span>
                  <span className="font-mono text-white font-medium">{estimatedStats.materials} (Bark + Leaves)</span>
                </div>
                <div className="bg-[#181d29] px-2.5 py-1.5 rounded border border-[#242c3d] flex justify-between items-center">
                  <span className="text-[#8492a5]">Memória GPU:</span>
                  <span className="font-mono text-white font-medium">~{estimatedStats.estimatedMemoryKb} KB</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-[#13161f] border-t border-[#232938] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1" title={targetTerrain ? `Distribui esta árvore em "${targetTerrain.name}" (InstancedMesh, seed determinística)` : 'Crie ou selecione um Terrain para distribuir'}>
              <input
                data-testid="tree-distribute-count"
                type="number"
                min={1}
                max={2000}
                value={vegCount}
                onChange={(e) => setVegCount(Math.max(1, Math.min(2000, parseInt(e.target.value) || 1)))}
                className="w-16 px-1.5 py-1.5 text-xs bg-[#171b24] border border-[#2a3346] rounded-lg text-white"
                aria-label="Quantidade de árvores"
              />
              <button
                data-testid="tree-distribute"
                onClick={() => void handleDistribute()}
                disabled={!targetTerrain}
                className="px-3 py-1.5 text-xs text-[#a0aebf] hover:text-white bg-[#1b202c] hover:bg-[#252c3c] border border-[#2a3346] rounded-lg flex items-center gap-1.5 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Mountain className="w-3.5 h-3.5 text-emerald-400" />
                <span>Distribuir no Terreno...</span>
              </button>
            </div>

            <div className="flex items-center gap-1" title="Salva a árvore como res://prefabs/<nome>.prefab.json (preserva generatorSource e a casca)">
              <input
                data-testid="tree-prefab-name"
                value={prefabName}
                onChange={(e) => { setPrefabName(e.target.value); setPrefabError(null); }}
                placeholder={`Tree_${PRESETS[selectedPreset].species}`}
                aria-label="Nome do Prefab"
                className="w-28 px-2 py-1 text-xs text-white bg-[#181c24] border border-[#2c3345] rounded focus:outline-none focus:border-emerald-500"
              />
              <button
                data-testid="tree-save-prefab"
                onClick={handleSaveAsPrefab}
                className="px-2.5 py-1.5 text-xs text-[#a0aebf] hover:text-white bg-[#1b202c] hover:bg-[#252c3c] border border-[#2a3346] rounded-lg transition-colors"
              >
                Salvar como Prefab
              </button>
            </div>
            {prefabError && <span role="alert" className="text-[11px] text-amber-400 max-w-[200px] truncate" title={prefabError}>{prefabError}</span>}

            <button
              onClick={() => applyPreset(selectedPreset)}
              className="px-2.5 py-1.5 text-xs text-[#7d8c9e] hover:text-[#d3dce9] transition-colors"
            >
              Restaurar Padrões
            </button>
          </div>

          <div className="flex items-center gap-2.5">
            <label className="flex items-center gap-1.5 text-xs text-[#8b97a8] cursor-pointer" title="Vale para a árvore inserida por este modal">
              <input
                type="checkbox"
                checked={addWithCollision}
                onChange={(e) => setAddWithCollision(e.target.checked)}
                className="w-3.5 h-3.5 rounded bg-[#181c24] border border-[#2c3345] text-emerald-500 focus:ring-0 focus:ring-offset-0 cursor-pointer"
              />
              Adicionar com colisão
            </label>
            <button
              onClick={close}
              className="px-4 py-1.5 text-xs font-medium text-[#92a1b5] hover:text-white hover:bg-[#202636] border border-transparent hover:border-[#2f384a] rounded-lg transition-colors"
            >
              Cancelar
            </button>

            {gen.editing ? (
              <>
                <button
                  data-testid="tree-insert-new"
                  onClick={handleInsertTree}
                  title="Cria outra árvore com estes parâmetros; o nó editado não muda"
                  className="px-3 py-1.5 text-xs font-medium text-[#c4cfdf] bg-[#1b202c] hover:bg-[#252c3c] border border-[#2a3346] rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <Trees className="w-3.5 h-3.5" />
                  <span>Inserir novo</span>
                </button>
                <button
                  data-testid="tree-apply"
                  onClick={handleApplyToNode}
                  title={`Atualiza "${gen.nodeName}" no lugar (um Ctrl+Z desfaz)`}
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-lg shadow-emerald-950 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
                >
                  <Check className="w-4 h-4" />
                  <span>Aplicar ao nó</span>
                </button>
              </>
            ) : (
              <button
                onClick={handleInsertTree}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-lg shadow-emerald-950 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Trees className="w-4 h-4" />
                <span>Inserir Árvore na Cena</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
