import React, { useMemo, useState } from 'react';
import { Link2, Plus, Trash2, X } from 'lucide-react';
import type { GameNode } from '../../types/node';
import type { NodeSignalConnection, SignalArgumentType } from '../../types/signal';
import { NATIVE_METHODS } from '../../runtime/nodeMethods';
import { SIGNALS_WITHOUT_EMITTER } from '../../core/signals/emittedSignals';
import {
  SIGNAL_ARGUMENT_LABEL,
  SIGNAL_ARGUMENT_TYPES,
  argumentToText,
  buildConnectionFromDraft,
  defaultMethodFor,
  findDuplicateConnection,
  type ConnectionDraft,
} from '../../core/signals/signalConnections';

interface SignalConnectionModalProps {
  /** Nó emissor. */
  node: GameNode;
  /** Sinais que o nó emite. */
  signals: string[];
  /** Todos os nós da cena (alvos e argumentos de tipo Nó). */
  nodes: Record<string, GameNode>;
  /** Conexão a editar; `null` = nova conexão. */
  editing: NodeSignalConnection | null;
  /** Sinal pré-selecionado numa nova conexão. */
  initialSignal?: string;
  onConfirm: (connection: Omit<NodeSignalConnection, 'id'>) => void;
  onCancel: () => void;
}

const fieldClass =
  'w-full bg-[#141820] text-xs text-[#dfe4ec] px-2 py-1.5 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none';

/**
 * AIS-27 — modal "Conectar Sinal...": vincula um sinal do nó a um método de um nó alvo, com argumentos tipados.
 * Só valida e devolve a conexão; quem grava é o Command do chamador. Cancelar (botão, X ou Esc) não altera nada.
 */
export const SignalConnectionModal: React.FC<SignalConnectionModalProps> = ({ node, signals, nodes, editing, initialSignal, onConfirm, onCancel }) => {
  const firstSignal = editing?.signalName ?? initialSignal ?? signals[0] ?? '';
  const [draft, setDraft] = useState<ConnectionDraft>(() => ({
    signalName: firstSignal,
    targetNodeId: editing?.targetNodeId ?? node.id,
    targetMethod: editing?.targetMethod ?? defaultMethodFor(firstSignal),
    args: (editing?.arguments ?? []).map((a) => ({ type: a.type, text: argumentToText(a) })),
    oneShot: editing?.oneShot === true,
    deferred: editing?.deferred === true,
  }));
  const [submitted, setSubmitted] = useState(false);

  const nodeIds = useMemo(() => new Set(Object.keys(nodes)), [nodes]);
  const result = useMemo(() => buildConnectionFromDraft(draft, nodeIds), [draft, nodeIds]);
  const duplicate = result.connection ? findDuplicateConnection(node.signals ?? [], result.connection, editing?.id) : undefined;
  const canConfirm = result.ok && !duplicate;

  const patch = (p: Partial<ConnectionDraft>) => setDraft((d) => ({ ...d, ...p }));
  const setArg = (i: number, p: Partial<ConnectionDraft['args'][number]>) =>
    setDraft((d) => ({ ...d, args: d.args.map((a, j) => (j === i ? { ...a, ...p } : a)) }));

  const confirm = () => {
    setSubmitted(true);
    if (canConfirm && result.connection) onConfirm(result.connection);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 select-none"
      onKeyDown={(e) => {
        if (e.key === 'Escape') {
          e.stopPropagation();
          onCancel();
        } else if (e.key === 'Enter' && (e.target as HTMLElement).tagName !== 'BUTTON') {
          e.preventDefault();
          confirm();
        }
      }}
    >
      <div role="dialog" aria-label={editing ? 'Editar conexão de sinal' : 'Conectar sinal'} className="bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-md text-xs text-[#d4dbe8] overflow-hidden">
        <div className="px-4 py-3 bg-[#141720] border-b border-[#242b3b] flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-white">
            <Link2 className="w-4 h-4 text-emerald-400" />
            <span>{editing ? 'Editar conexão de sinal' : 'Conectar sinal'}</span>
            <span className="text-[#8b97a8] font-normal">· {node.name}</span>
          </div>
          <button onClick={onCancel} aria-label="Cancelar" className="p-1 rounded hover:bg-[#2c3345] text-[#8b97a8] hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-3 max-h-[70vh] overflow-y-auto">
          <div>
            <label className="text-[#8b97a8] text-[11px] block mb-1" htmlFor="sig-signal">Sinal</label>
            <select
              id="sig-signal"
              value={draft.signalName}
              onChange={(e) => {
                // o método sugerido acompanha o sinal enquanto o usuário não o personalizou
                const wasDefault = draft.targetMethod === defaultMethodFor(draft.signalName);
                patch({ signalName: e.target.value, ...(wasDefault ? { targetMethod: defaultMethodFor(e.target.value) } : {}) });
              }}
              className={fieldClass}
            >
              {signals.map((s) => (
                <option key={s} value={s}>
                  {SIGNALS_WITHOUT_EMITTER[s] ? `${s} (em breve)` : s}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[#8b97a8] text-[11px] block mb-1" htmlFor="sig-target">Nó alvo</label>
            <select id="sig-target" value={draft.targetNodeId} onChange={(e) => patch({ targetNodeId: e.target.value })} className={fieldClass}>
              {Object.values(nodes).map((n) => (
                <option key={n.id} value={n.id}>
                  {n.name} ({n.type})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[#8b97a8] text-[11px] block mb-1" htmlFor="sig-method">Método ou script alvo</label>
            <input
              id="sig-method"
              type="text"
              value={draft.targetMethod}
              onChange={(e) => patch({ targetMethod: e.target.value })}
              placeholder="_on_signal"
              list="sig-native-methods"
              spellCheck={false}
              aria-invalid={submitted && !result.ok}
              className={`${fieldClass} font-mono`}
            />
          </div>

          <datalist id="sig-native-methods">
            {NATIVE_METHODS.filter((m) => !m.appliesTo || m.appliesTo(nodes[draft.targetNodeId]?.type ?? 'Spatial')).map((m) => (
              <option key={m.name} value={m.name}>{m.description}</option>
            ))}
          </datalist>

          <div className="flex items-center gap-4 text-[11px] text-[#c4cfdf]">
            <label className="flex items-center gap-1.5 cursor-pointer" title="Desconecta depois da primeira chamada (Godot CONNECT_ONE_SHOT)">
              <input type="checkbox" checked={draft.oneShot === true} onChange={(e) => patch({ oneShot: e.target.checked })} className="rounded border-[#2c3345] bg-[#141820]" />
              Uma vez (one-shot)
            </label>
            <label className="flex items-center gap-1.5 cursor-pointer" title="Chama no fim do quadro, não na hora da emissão (Godot CONNECT_DEFERRED)">
              <input type="checkbox" checked={draft.deferred === true} onChange={(e) => patch({ deferred: e.target.checked })} className="rounded border-[#2c3345] bg-[#141820]" />
              Adiada (deferred)
            </label>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-[#8b97a8] text-[11px]">Argumentos tipados</span>
              <button
                type="button"
                onClick={() => setDraft((d) => ({ ...d, args: [...d.args, { type: 'string', text: '' }] }))}
                className="flex items-center gap-1 text-[11px] text-[#9db8ee] hover:text-white"
              >
                <Plus className="w-3 h-3" />
                Adicionar argumento
              </button>
            </div>
            {draft.args.length === 0 ? (
              <div className="text-[11px] text-[#6e7b91] italic bg-[#141820] p-2 rounded border border-[#2c3345]">Sem argumentos.</div>
            ) : (
              <div className="space-y-1.5">
                {draft.args.map((a, i) => (
                  <div key={i} className="flex items-center gap-1.5">
                    <span className="text-[#6e7b91] w-4 text-right">{i + 1}</span>
                    <select
                      value={a.type}
                      aria-label={`Tipo do argumento ${i + 1}`}
                      onChange={(e) => setArg(i, { type: e.target.value as SignalArgumentType, text: e.target.value === 'boolean' ? 'true' : e.target.value === 'node' ? node.id : '' })}
                      className={`${fieldClass} w-24 shrink-0`}
                    >
                      {SIGNAL_ARGUMENT_TYPES.map((t) => (
                        <option key={t} value={t}>
                          {SIGNAL_ARGUMENT_LABEL[t]}
                        </option>
                      ))}
                    </select>
                    {a.type === 'boolean' ? (
                      <select value={a.text || 'true'} aria-label={`Valor do argumento ${i + 1}`} onChange={(e) => setArg(i, { text: e.target.value })} className={fieldClass}>
                        <option value="true">true</option>
                        <option value="false">false</option>
                      </select>
                    ) : a.type === 'node' ? (
                      <select value={a.text} aria-label={`Valor do argumento ${i + 1}`} onChange={(e) => setArg(i, { text: e.target.value })} className={fieldClass}>
                        {Object.values(nodes).map((n) => (
                          <option key={n.id} value={n.id}>
                            {n.name}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type="text"
                        value={a.text}
                        aria-label={`Valor do argumento ${i + 1}`}
                        onChange={(e) => setArg(i, { text: e.target.value })}
                        placeholder={a.type === 'number' ? '0' : 'texto'}
                        className={`${fieldClass} font-mono`}
                      />
                    )}
                    <button
                      type="button"
                      onClick={() => setDraft((d) => ({ ...d, args: d.args.filter((_, j) => j !== i) }))}
                      aria-label={`Remover argumento ${i + 1}`}
                      className="p-1 text-[#8b97a8] hover:text-rose-400"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {(submitted || duplicate) && (!result.ok || duplicate) && (
            <div role="alert" className="px-2 py-1.5 rounded bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-300 space-y-0.5">
              {result.errors.map((err) => (
                <div key={err}>{err}</div>
              ))}
              {duplicate && <div>Já existe uma conexão idêntica (mesmo sinal, alvo, método e argumentos).</div>}
            </div>
          )}
        </div>

        <div className="px-4 py-3 bg-[#171b24] border-t border-[#2c3345] flex justify-end gap-2">
          <button onClick={onCancel} className="px-3 py-1.5 rounded hover:bg-[#2c3345] text-[#b3bed0]">
            Cancelar
          </button>
          <button
            onClick={confirm}
            disabled={submitted && !canConfirm}
            className="bg-[#4982ea] hover:bg-[#3d72d6] disabled:opacity-50 text-white px-4 py-1.5 rounded font-medium transition-colors"
          >
            {editing ? 'Salvar' : 'Conectar'}
          </button>
        </div>
      </div>
    </div>
  );
};
