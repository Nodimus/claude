import React from 'react';
import { Brush, MousePointer2 } from 'lucide-react';
import type { GameNode } from '../../types/node';
import { useEditorStore } from '../../core/editorStore';
import { SCULPT_TOOLS, type BrushFalloff, type PaintLayer } from '../../core/terrainBrush';
import { hasSculptedHeights } from '../../core/terrainOps';

const BTN = 'px-2 py-1 rounded text-[10px] font-medium border bg-[#222a3b] hover:bg-[#2b354a] border-[#2e3b52] text-[#93a1b8] hover:text-white flex items-center justify-center gap-1';
const SLIDER = 'w-full accent-[#4982ea]';

/**
 * AIS-50b §3.1 — seção "Esculpir" do Inspector (só nó `Terrain`, fora do Play). Os controles são UI TRANSITÓRIA no `EditorStore`
 * (não são Command, não vão para a cena). "Esculpir na viewport" liga/desliga o modo terreno (`manipulationMode === 'terrain'`).
 */
export const TerrainSculptSection: React.FC<{ node: GameNode }> = ({ node }) => {
  const mode = useEditorStore((s) => s.manipulationMode);
  const setMode = useEditorStore((s) => s.setManipulationMode);
  const tool = useEditorStore((s) => s.activeSculptTool);
  const radius = useEditorStore((s) => s.brushRadius);
  const strength = useEditorStore((s) => s.brushStrength);
  const falloff = useEditorStore((s) => s.brushFalloff);
  const target = useEditorStore((s) => s.flattenTargetHeight);
  const layer = useEditorStore((s) => s.paintLayer);
  const set = useEditorStore((s) => s.setSculptBrush);
  const active = mode === 'terrain';
  const edited = hasSculptedHeights(node.properties);

  return (
    <div className="px-2 pt-2" data-testid="terrain-sculpt-section">
      <div className="rounded border border-[#252c3c] bg-[#171b23]/60 p-2 space-y-2">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-green-500 uppercase tracking-wider">
          <Brush className="w-3.5 h-3.5" /> Esculpir
          {edited && <span className="ml-auto text-[9px] normal-case font-normal text-amber-400">editado manualmente</span>}
        </div>

        <div className="grid grid-cols-3 gap-1" role="radiogroup" aria-label="Ferramenta do pincel">
          {SCULPT_TOOLS.map((t) => (
            <button
              key={t.id}
              role="radio"
              aria-checked={tool === t.id}
              onClick={() => set({ activeSculptTool: t.id })}
              className={`${BTN} ${tool === t.id ? '!bg-[#4982ea] !text-white !border-[#6b9bff]' : ''}`}
              title={t.id === 'paint' ? 'Pinta a camada escolhida (Shift apaga)' : t.id === 'raise' || t.id === 'lower' ? 'Shift inverte Raise ↔ Lower' : undefined}
            >
              {t.label}
            </button>
          ))}
        </div>

        <label className="block text-[11px] text-[#8b97a8]">
          <span className="flex justify-between">
            <span>Raio</span>
            <span className="font-mono text-white">{radius.toFixed(1)} m</span>
          </span>
          <input type="range" min={0.5} max={60} step={0.5} value={Math.min(60, radius)} onChange={(e) => set({ brushRadius: parseFloat(e.target.value) })} className={SLIDER} aria-label="Raio do pincel" />
        </label>
        <label className="block text-[11px] text-[#8b97a8]">
          <span className="flex justify-between">
            <span>Força</span>
            <span className="font-mono text-white">{strength.toFixed(2)}</span>
          </span>
          <input type="range" min={0.02} max={1} step={0.02} value={strength} onChange={(e) => set({ brushStrength: parseFloat(e.target.value) })} className={SLIDER} aria-label="Força do pincel" />
        </label>
        <label className="flex items-center justify-between gap-2 text-[11px] text-[#8b97a8]">
          Falloff
          <select value={falloff} onChange={(e) => set({ brushFalloff: e.target.value as BrushFalloff })} aria-label="Falloff do pincel" className="bg-[#141820] text-[11px] text-[#dfe4ec] px-1.5 py-0.5 rounded border border-[#2c3345] outline-none">
            <option value="smooth">smooth</option>
            <option value="linear">linear</option>
            <option value="spherical">spherical</option>
          </select>
        </label>
        {tool === 'flatten' && (
          <label className="flex items-center justify-between gap-2 text-[11px] text-[#8b97a8]">
            Altura-alvo (m)
            <input type="number" min={0} step={0.5} value={target} onChange={(e) => set({ flattenTargetHeight: parseFloat(e.target.value) || 0 })} aria-label="Altura-alvo" className="w-20 bg-[#141820] text-right font-mono text-[11px] text-[#dfe4ec] px-1.5 py-0.5 rounded border border-[#2c3345] outline-none" />
          </label>
        )}
        {tool === 'paint' && (
          <label className="flex items-center justify-between gap-2 text-[11px] text-[#8b97a8]">
            Camada
            <select value={layer} onChange={(e) => set({ paintLayer: e.target.value as PaintLayer })} aria-label="Camada de pintura" className="bg-[#141820] text-[11px] text-[#dfe4ec] px-1.5 py-0.5 rounded border border-[#2c3345] outline-none">
              <option value="ground">ground</option>
              <option value="mid">mid</option>
              <option value="high">high</option>
            </select>
          </label>
        )}

        <button onClick={() => setMode(active ? 'select' : 'terrain')} aria-pressed={active} className={`${BTN} w-full ${active ? '!bg-amber-500/20 !text-amber-200 !border-amber-500/50' : ''}`} title={active ? 'Sai do modo terreno (Esc)' : 'Esculpe com o botão esquerdo na viewport · [ ] ajustam o raio · Shift inverte · Esc sai'} data-testid="terrain-sculpt-toggle">
          <MousePointer2 className="w-3 h-3" />
          {active ? 'Sair do modo terreno' : 'Esculpir na viewport'}
        </button>
      </div>
    </div>
  );
};
