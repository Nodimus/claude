import React, { useMemo, useState } from 'react';
import { Droplets, Save } from 'lucide-react';
import type { GameNode } from '../../types/node';
import { useEditor } from '../../core/EditorContext';
import { globalAssetPipeline } from '../../core/resources/global';
import { appearanceOf, presetValues, WATER_PRESET_ORDER, WATER_PRESETS, type WaterPresetId } from '../../core/water/waterConfig';
import { buildWaterPresetFile, isWaterPresetPath, readWaterPresetValues, waterPresetLabel, waterPresetPath, sanitizeWaterPresetName } from '../../core/water/waterPresets';

const FIELD = 'flex-1 min-w-0 bg-[#12151c] rounded border border-[#2c3345] px-2 py-1 text-[11px] text-[#dfe4ec] outline-none focus:border-blue-500';
const BTN = 'px-2 py-1 rounded text-[10px] font-medium border bg-[#222a3b] hover:bg-[#2b354a] border-[#2e3b52] text-[#93a1b8] hover:text-white flex items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed';

const sameAppearance = (a: Record<string, any>, b: Record<string, any>): boolean => JSON.stringify(a) === JSON.stringify(b);

/**
 * AIS-68 — seção "Água": presets (Lago/Rio/Oceano embutidos + `res://materials/*_water.json` do projeto) e "Salvar preset…". O nó guarda
 * os próprios campos (fonte da verdade); aplicar um preset é UM Command que os preenche. O preset exibido é DERIVADO: o que combina
 * exatamente com os campos atuais, senão "Personalizado".
 */
export const WaterSection: React.FC<{ node: GameNode }> = ({ node }) => {
  const { changeNodeProperties, project, addLog } = useEditor();
  const [name, setName] = useState('');
  const files = project.files ?? {};
  const projectPresets = useMemo(() => Object.keys(files).filter(isWaterPresetPath).sort(), [files]);
  const current = appearanceOf(node.properties);

  const matchedBuiltin = WATER_PRESET_ORDER.find((id) => sameAppearance(presetValues(id), current));
  const matchedFile = projectPresets.find((path) => {
    const r = readWaterPresetValues(files[path]?.content);
    return r.ok && sameAppearance(r.values, current);
  });
  const value = matchedBuiltin ?? matchedFile ?? 'custom';

  const apply = (choice: string) => {
    if (choice === 'custom') return;
    if (choice in WATER_PRESETS) {
      changeNodeProperties(node.id, presetValues(choice as WaterPresetId), `Preset de água: ${WATER_PRESETS[choice as WaterPresetId].label}`);
      return;
    }
    const result = readWaterPresetValues(files[choice]?.content);
    if (!result.ok) {
      addLog('warn', `Preset de água "${waterPresetLabel(choice)}": ${result.error}. O nó não foi alterado.`);
      return;
    }
    changeNodeProperties(node.id, result.values, `Preset de água: ${waterPresetLabel(choice)}`);
  };

  const save = async () => {
    const path = waterPresetPath(name);
    if (files[path] && !window.confirm(`Já existe ${path}. Substituir?`)) return;
    const result = await globalAssetPipeline.import({ uri: path, content: buildWaterPresetFile(name, node.properties) });
    if (!result.ok) {
      addLog('error', `Não foi possível salvar o preset de água em ${path}: ${result.diagnostics[0]?.message ?? 'falha na importação'}`);
      return;
    }
    addLog('log', `Preset de água salvo em ${path}.`);
    setName('');
  };

  return (
    <div className="p-2.5 space-y-1.5" data-testid="water-section">
      <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-cyan-400">
        <Droplets className="w-3.5 h-3.5" />
        <span>Água</span>
      </div>
      <div className="flex items-center gap-2 text-[11px]">
        <label htmlFor={`water-preset-${node.id}`} className="w-24 shrink-0 text-[#93a1b8]">Preset</label>
        <select id={`water-preset-${node.id}`} aria-label="Preset de água" className={FIELD} value={value} onChange={(e) => apply(e.target.value)}>
          {value === 'custom' && <option value="custom">Personalizado</option>}
          {WATER_PRESET_ORDER.map((id) => (
            <option key={id} value={id}>{WATER_PRESETS[id].label}</option>
          ))}
          {projectPresets.length > 0 && (
            <optgroup label="Do projeto">
              {projectPresets.map((path) => (
                <option key={path} value={path}>{waterPresetLabel(path)}</option>
              ))}
            </optgroup>
          )}
        </select>
      </div>
      <div className="flex items-center gap-2 text-[11px]">
        <span className="w-24 shrink-0 text-[#93a1b8]">Salvar como</span>
        <input aria-label="Nome do preset de água" className={FIELD} value={name} placeholder="nome do preset" onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.stopPropagation()} />
        <button type="button" className={BTN} disabled={!name.trim()} title={`Grava ${waterPresetPath(name || sanitizeWaterPresetName(''))}`} onClick={() => void save()}>
          <Save className="w-3 h-3" />
          Salvar
        </button>
      </div>
      <p className="text-[10px] leading-snug text-[#8b97a8]">
        O reflexo <b>Planar</b> renderiza a cena uma vez a mais por quadro (por água visível): use <b>Ambiente</b> para um custo quase nulo ou para várias águas.
      </p>
    </div>
  );
};
