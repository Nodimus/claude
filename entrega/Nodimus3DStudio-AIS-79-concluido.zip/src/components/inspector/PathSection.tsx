import React from 'react';
import { MousePointer2, Route } from 'lucide-react';
import type { GameNode } from '../../types/node';
import { useEditorStore } from '../../core/editorStore';
import { buildPathCurve, pathProblem, readPath } from '../../core/path/pathData';

const BTN = 'px-2 py-1 rounded text-[10px] font-medium border bg-[#222a3b] hover:bg-[#2b354a] border-[#2e3b52] text-[#93a1b8] hover:text-white flex items-center justify-center gap-1';

/**
 * AIS-72 §B — seção "Caminho" do Inspector (só nó `Path`, fora do Play): resumo (waypoints, comprimento) e o botão que liga/desliga o
 * modo de edição de pontos na viewport (`manipulationMode === 'path'`, transitório no `EditorStore`). `closed`, `tightness` e
 * `showInPlay` são campos comuns do registry (um Command cada, pelo Inspector).
 */
export const PathSection: React.FC<{ node: GameNode }> = ({ node }) => {
  const mode = useEditorStore((s) => s.manipulationMode);
  const setMode = useEditorStore((s) => s.setManipulationMode);
  const active = mode === 'path';
  const config = readPath(node.properties);
  const problem = pathProblem(config);
  const length = buildPathCurve(config)?.getLength() ?? 0;

  return (
    <div className="px-2 pt-2" data-testid="path-section">
      <div className="rounded border border-[#252c3c] bg-[#171b23]/60 p-2 space-y-2">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-500 uppercase tracking-wider">
          <Route className="w-3.5 h-3.5" /> Caminho
        </div>
        <div className="flex justify-between text-[11px] text-[#8b97a8]">
          <span>
            Waypoints <span className="font-mono text-white" data-testid="path-count">{config.nodes.length}</span>
          </span>
          <span>
            Comprimento <span className="font-mono text-white">{length.toFixed(2)} m</span>
          </span>
        </div>
        {problem && <p className="text-[10px] text-amber-400">{problem[0].toUpperCase() + problem.slice(1)}.</p>}
        <button
          onClick={() => setMode(active ? 'select' : 'path')}
          aria-pressed={active}
          className={`${BTN} w-full ${active ? '!bg-amber-500/20 !text-amber-200 !border-amber-500/50' : ''}`}
          title={active ? 'Sai da edição de pontos (Esc)' : 'Clique no vazio adiciona · arraste um handle move (Shift = só altura) · clique num segmento insere · Delete remove o ponto selecionado · Esc sai'}
          data-testid="path-edit-toggle"
        >
          <MousePointer2 className="w-3 h-3" />
          {active ? 'Sair da edição de pontos' : 'Editar pontos'}
        </button>
        {active && <p className="text-[10px] text-[#8b97a8]">Vazio: adiciona · Handle: move (Shift = altura) · Segmento: insere · Delete: remove · Esc: sai</p>}
      </div>
    </div>
  );
};
