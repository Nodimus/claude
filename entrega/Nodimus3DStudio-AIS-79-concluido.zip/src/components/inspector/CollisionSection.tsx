import React, { useMemo, useState } from 'react';
import { ChevronDown, ChevronRight, Maximize, Plus, Trash2, TriangleAlert } from 'lucide-react';
import { useEditor } from '../../core/EditorContext';
import type { GameNode, PhysicsBodyMode, PhysicsConfig, PhysicsShape, PropertyDescriptor } from '../../types/node';
import { nodeObjectRegistry } from '../../core/rendering/nodeObjectRegistry';
import { measureLocalBounds } from '../../core/physics/bounds';
import {
  BODY_MODE_LABEL,
  BODY_MODE_ORDER,
  PHYSICS_DEFAULTS,
  SHAPE_LABEL,
  SHAPE_ORDER,
  applyPhysicsPatch,
  defaultPhysicsConfig,
  diffPhysics,
  isShapeAllowed,
  readPhysics,
} from '../../core/physics/physicsConfig';
import { autoLocalSize, autoShapeFor } from '../../core/physics/resolveCollider';
import { PropertyField } from './PropertyField';

/** Tipos de nó 3D que carregam o bloco de colisão (decisão 26): têm transform e podem ter malha. */
const COLLISION_NODE_TYPES = new Set<string>(['MeshInstance', 'Spatial', 'Billboard', 'Terrain', 'Vegetation', 'Hotspot']);
export const supportsCollision = (type: string): boolean => COLLISION_NODE_TYPES.has(type);

const round = (n: number) => Math.round(n * 1000) / 1000;

const d = (key: string, label: string, type: PropertyDescriptor['type'], defaultValue: any, extra: Partial<PropertyDescriptor> = {}): PropertyDescriptor => ({
  key,
  label,
  type,
  category: 'Colisão',
  defaultValue,
  ...extra,
});

const SHAPE_NAME_FOR_AUTO: Record<string, string> = {
  box: 'caixa',
  sphere: 'esfera',
  capsule: 'cápsula',
  cylinder: 'cilindro',
  mesh: 'malha exata',
  heightfield: 'terreno',
  compound: 'um cilindro por árvore',
};

/**
 * AIS-26b — seção **Colisão** do Inspector (decisão 26): interruptor, Tipo, Forma/Tamanho e Avançado. Toda escrita é um
 * `ChangePropertyCommand` sobre `physics.*` (um gesto = um Undo); nada de Command novo.
 */
export const CollisionSection: React.FC<{ node: GameNode }> = ({ node }) => {
  const { changeNodeProperties, activeScene } = useEditor();
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const physics = readPhysics(node.properties);

  const autoSize = useMemo(() => {
    if (!physics) return null;
    const object = nodeObjectRegistry.get(node.id);
    return autoLocalSize(physics, {
      nodeType: node.type,
      properties: node.properties,
      bounds: object ? measureLocalBounds(object) : null,
      scale: { x: 1, y: 1, z: 1 },
    });
    // a malha/propriedades mudam via Command → `node` troca de identidade
  }, [physics, node]);

  const header = (
    <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-[#8b97a8]">
      <Maximize className="w-3.5 h-3.5" />
      <span>Colisão</span>
    </div>
  );

  if (!physics) {
    const hasInvalid = node.properties?.physics !== undefined && node.properties?.physics !== null;
    return (
      <div className="p-2.5 space-y-1.5" data-testid="collision-section">
        {header}
        {hasInvalid && (
          <div role="alert" className="px-2 py-1.5 rounded bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-300 flex gap-1.5">
            <TriangleAlert className="w-3.5 h-3.5 shrink-0 mt-px" />
            <span>O bloco de colisão deste nó é inválido e foi ignorado. Adicionar colisão o substitui.</span>
          </div>
        )}
        <button
          onClick={() => changeNodeProperties(node.id, { physics: defaultPhysicsConfig() }, 'Adicionar colisão')}
          title="Liga a colisão deste objeto (sólido parado, forma automática)"
          className="w-full flex items-center justify-center gap-1.5 py-1 px-2 rounded bg-[#202531] hover:bg-[#2c3345] text-[#b8c4d6] hover:text-white border border-[#2c3345] text-[11px] transition-colors"
        >
          <Plus className="w-3 h-3" />
          Adicionar colisão
        </button>
      </div>
    );
  }

  const patch = (change: Partial<PhysicsConfig>, label?: string) => {
    const next = applyPhysicsPatch(physics, change);
    const diff = diffPhysics(physics, next);
    if (Object.keys(diff).length) changeNodeProperties(node.id, diff, label);
  };

  const effectiveAutoShape = physics.shape === 'auto' ? autoShapeFor(physics.bodyMode, { nodeType: node.type, properties: node.properties }) : physics.shape;
  const shapeOptions = SHAPE_ORDER.map((s) => ({
    label: s === 'auto' ? `Auto (${SHAPE_NAME_FOR_AUTO[effectiveAutoShape] ?? effectiveAutoShape})` : SHAPE_LABEL[s],
    value: s,
    disabled: !isShapeAllowed(s, physics.bodyMode) || (physics.bodyMode === 'character' && s !== 'capsule' && s !== 'auto'),
  }));
  const sizeShown = physics.size ?? (autoSize ? { x: round(autoSize.x), y: round(autoSize.y), z: round(autoSize.z) } : { x: 1, y: 1, z: 1 });
  // objeto animado (`properties.animated`, decisão 30): o colisor mede a pose de repouso
  const isAnimated = node.properties.animated === true;
  const bodyOptions = BODY_MODE_ORDER.map((m) => ({ label: BODY_MODE_LABEL[m], value: m }));

  return (
    <div className="p-2.5 space-y-1" data-testid="collision-section">
      <div className="flex items-center justify-between">
        {header}
        <label className="flex items-center gap-1.5 text-[11px] text-[#b8c4d6] cursor-pointer select-none" title="Liga ou desliga a colisão; a configuração fica guardada">
          <input
            type="checkbox"
            role="switch"
            aria-label="Colisão ligada"
            checked={physics.enabled}
            onChange={(e) => patch({ enabled: e.target.checked }, e.target.checked ? 'Ligar colisão' : 'Desligar colisão')}
            className="w-4 h-4 rounded bg-[#181c24] border border-[#2c3345] text-[#4982ea] focus:ring-0 focus:ring-offset-0 cursor-pointer"
          />
          {physics.enabled ? 'ligado' : 'desligado'}
        </label>
      </div>

      <PropertyField
        descriptor={d('bodyMode', 'Tipo', 'enum', 'static', { options: bodyOptions })}
        value={physics.bodyMode}
        onChange={(v: PhysicsBodyMode) => patch({ bodyMode: v }, 'Mudar tipo de colisão')}
      />
      <PropertyField
        descriptor={d('shape', 'Forma', 'enum', 'auto', { options: shapeOptions })}
        value={physics.shape}
        onChange={(v: PhysicsShape) => patch({ shape: v }, 'Mudar forma de colisão')}
      />
      <div className="flex items-start gap-1">
        <div className="flex-1 min-w-0">
          <PropertyField
            descriptor={d('size', physics.size ? 'Tamanho' : 'Tamanho (auto)', 'vector3', { x: 1, y: 1, z: 1 }, {
              description: physics.size
                ? 'Tamanho total do colisor. Caixa: largura/altura/profundidade · esfera: x = diâmetro · cápsula e cilindro: x = diâmetro, y = altura.'
                : 'Calculado a partir da malha. Editar fixa o tamanho.',
            })}
            value={sizeShown}
            onChange={(v: { x: number; y: number; z: number }) =>
              patch({ size: { x: Math.max(0.001, v.x), y: Math.max(0.001, v.y), z: Math.max(0.001, v.z) } }, 'Mudar tamanho do colisor')
            }
          />
        </div>
      </div>
      <div className="flex items-center gap-1.5">
        <button
          onClick={() => patch({ size: undefined }, 'Ajustar colisor à malha')}
          disabled={!physics.size}
          title={physics.size ? 'Volta ao tamanho automático (medido da malha)' : 'O tamanho já é automático'}
          className="py-1 px-2 rounded bg-[#202531] hover:bg-[#2c3345] disabled:opacity-40 disabled:hover:bg-[#202531] text-[#b8c4d6] hover:text-white border border-[#2c3345] text-[11px] transition-colors whitespace-nowrap"
        >
          Ajustar à malha
        </button>
      </div>

      {isAnimated && (
        <div role="note" className="px-2 py-1.5 rounded bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-300 flex gap-1.5">
          <TriangleAlert className="w-3.5 h-3.5 shrink-0 mt-px" />
          <span>O colisor usa a pose inicial e não acompanha a animação.</span>
        </div>
      )}

      <button
        onClick={() => setAdvancedOpen((o) => !o)}
        aria-expanded={advancedOpen}
        className="flex items-center gap-1 text-[11px] text-[#8b97a8] hover:text-white"
      >
        {advancedOpen ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
        Avançado
      </button>
      {advancedOpen && (
        <div className="pl-1 border-l border-[#2c3345]">
          <PropertyField
            descriptor={d('friction', 'Atrito', 'float', PHYSICS_DEFAULTS.friction, { min: 0, max: 1, step: 0.05 })}
            value={physics.friction}
            onChange={(v: number) => patch({ friction: v }, 'Mudar atrito')}
          />
          <PropertyField
            descriptor={d('bounce', 'Quique', 'float', PHYSICS_DEFAULTS.bounce, { min: 0, max: 1, step: 0.05 })}
            value={physics.bounce}
            onChange={(v: number) => patch({ bounce: v }, 'Mudar quique')}
          />
          {physics.bodyMode === 'dynamic' && (
            <PropertyField
              descriptor={d('mass', 'Massa (kg)', 'float', 1, { min: 0.001, step: 0.5, description: 'Sem valor = massa automática pelo volume.' })}
              value={physics.mass}
              onChange={(v: number) => patch({ mass: v }, 'Mudar massa')}
            />
          )}
          <PropertyField
            descriptor={d('layer', 'Camada', 'bitmask', PHYSICS_DEFAULTS.layer, { bitCount: 8, description: 'Em quais camadas este objeto existe.' })}
            value={physics.layer}
            onChange={(v: number) => patch({ layer: v }, 'Mudar camada')}
          />
          <PropertyField
            descriptor={d('mask', 'Máscara', 'bitmask', PHYSICS_DEFAULTS.mask, { bitCount: 8, description: 'Com quais camadas este objeto colide (os dois lados precisam aceitar).' })}
            value={physics.mask}
            onChange={(v: number) => patch({ mask: v }, 'Mudar máscara')}
          />
          <PropertyField
            descriptor={d('constrainToPlane', 'Travar no plano', 'enum', 'none', {
              options: [
                { label: 'Nenhum', value: 'none' },
                { label: 'XY', value: 'xy' },
                { label: 'XZ', value: 'xz' },
                { label: 'YZ', value: 'yz' },
              ],
            })}
            value={physics.constrainToPlane}
            onChange={(v: PhysicsConfig['constrainToPlane']) => patch({ constrainToPlane: v }, 'Mudar plano travado')}
          />
          <PropertyField
            descriptor={d('forwardAxis', 'Eixo frontal', 'enum', 'z', {
              options: [
                { label: 'Z', value: 'z' },
                { label: 'X', value: 'x' },
              ],
            })}
            value={physics.forwardAxis}
            onChange={(v: 'x' | 'z') => patch({ forwardAxis: v }, 'Mudar eixo frontal')}
          />
          {physics.bodyMode === 'dynamic' && (
            <PropertyField
              descriptor={d('floats', 'Flutua na água', 'boolean', false)}
              value={physics.floats}
              onChange={(v: boolean) => patch({ floats: v }, 'Mudar flutuação')}
            />
          )}
        </div>
      )}

      <button
        onClick={() => changeNodeProperties(node.id, { physics: undefined }, 'Remover colisão')}
        title="Apaga o bloco de colisão deste objeto"
        className="flex items-center gap-1 text-[11px] text-[#8b97a8] hover:text-red-300"
      >
        <Trash2 className="w-3 h-3" />
        Remover colisão
      </button>
    </div>
  );
};
