import React, { useMemo, useSyncExternalStore } from 'react';
import { Play, Square } from 'lucide-react';
import type { GameNode } from '../../types/node';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { applyAnimationPatch, defaultAnimationConfig, diffAnimation, isAnimated, readAnimation, type AnimationConfig } from '../../core/animation/animationConfig';
import { rigAnimationNames } from '../../core/animation/animationNames';
import { ANIMATION_SPEED_MAX, ANIMATION_SPEED_MIN } from '../../schemas/v1/animation.schema';
import { animationPreviewControl } from '../viewports/viewportAnimationPreview';
import { useResourceRegistryVersion } from '../../core/resources/useResources';

const FIELD = 'flex-1 min-w-0 bg-[#12151c] rounded border border-[#2c3345] px-2 py-1 text-[11px] text-[#dfe4ec] outline-none focus:border-blue-500 disabled:opacity-50';
const ROW = 'flex items-center gap-2 text-[11px]';
const LABEL = 'w-24 shrink-0 text-[#93a1b8]';

/**
 * AIS-60b (decisão 30) — seção "Animação" do MeshInstance: interruptor Animado, animação padrão (lista do RigConfig), Autoplay, Loop,
 * Velocidade (0,25–2), Crossfade e a Prévia ▶/⏹ (transitória: nunca grava nem gera Undo). Toda edição é UM `ChangePropertyCommand`.
 */
export const AnimationSection: React.FC<{ node: GameNode }> = ({ node }) => {
  const { changeNodeProperties, project } = useEditor();
  const isPlaying = useEditorStore((s) => s.isPlaying);
  const preview = useSyncExternalStore(animationPreviewControl.subscribe, animationPreviewControl.get);
  const version = useResourceRegistryVersion();
  const animated = isAnimated(node.properties);
  const config = readAnimation(node.properties);
  const rig = config?.rig;
  const names = useMemo(() => (rig ? rigAnimationNames(rig, project.files ?? {}) : []), [rig, project.files, version]);

  const toggle = (on: boolean) => {
    if (!on) {
      if (preview.nodeId === node.id) animationPreviewControl.stop();
      changeNodeProperties(node.id, { animated: false }, 'Desligar animado');
      return;
    }
    // religa preservando a configuração anterior (o bloco nunca é apagado ao desligar)
    const base = defaultAnimationConfig(node.properties.animation && typeof node.properties.animation === 'object' ? node.properties.animation : {});
    changeNodeProperties(node.id, { animated: true, animation: base }, 'Ligar animado');
  };

  const patch = (change: Partial<AnimationConfig>, label: string) => {
    if (!config) return;
    const next = applyAnimationPatch(config, change);
    const diff = diffAnimation(config, next);
    if (Object.keys(diff).length) changeNodeProperties(node.id, diff, label);
  };

  const previewing = preview.nodeId === node.id && (preview.status === 'playing' || preview.status === 'loading');
  const canPreview = animated && names.length > 0 && !isPlaying;

  return (
    <div className="p-2.5 space-y-1.5" data-testid="animation-section">
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-400">Animação</span>
        <label className="flex items-center gap-1.5 text-[11px] text-[#b8c4d6] cursor-pointer select-none" title="Objeto animado: guarda as animações do modelo e toca no Play">
          <input type="checkbox" role="switch" aria-label="Animado" checked={animated} onChange={(e) => toggle(e.target.checked)} />
          Animado
        </label>
      </div>
      {animated && config && (
        <>
          {names.length === 0 ? (
            <p className="text-[10px] text-[#8b97a8]" data-testid="animation-empty">
              {rig ? 'O rig deste objeto não lista animações.' : 'Este objeto não tem animações.'} Importe o modelo com animações (Importador → "Adicionar animações…"); para juntar animações novas, reimporte.
            </p>
          ) : (
            <>
              <div className={ROW}>
                <label htmlFor={`anim-default-${node.id}`} className={LABEL}>Animação padrão</label>
                <select id={`anim-default-${node.id}`} aria-label="Animação padrão" className={FIELD} value={config.default} onChange={(e) => patch({ default: e.target.value }, 'Animação padrão')}>
                  <option value="">(nenhuma)</option>
                  {config.default && !names.includes(config.default) && <option value={config.default}>{config.default} (fora da biblioteca)</option>}
                  {names.map((n) => (
                    <option key={n} value={n}>{n}</option>
                  ))}
                </select>
              </div>
              <div className={ROW}>
                <span className={LABEL}>Prévia</span>
                <button
                  type="button"
                  aria-label={previewing ? 'Parar prévia' : 'Prévia da animação'}
                  disabled={!canPreview}
                  title={isPlaying ? 'Pare o Play para pré-visualizar' : previewing ? 'Parar a prévia (a pose volta ao repouso)' : 'Tocar a animação padrão no editor (não grava nada)'}
                  onClick={() => (previewing ? animationPreviewControl.stop() : animationPreviewControl.start(node.id))}
                  className="px-2 py-1 rounded text-[10px] font-medium border bg-[#222a3b] hover:bg-[#2b354a] border-[#2e3b52] text-[#93a1b8] hover:text-white flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {previewing ? <Square className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                  {previewing ? 'Parar' : 'Prévia'}
                </button>
                {preview.nodeId === node.id && preview.status === 'error' && (
                  <span className="text-[10px] text-rose-300 truncate" title={preview.message}>{preview.message}</span>
                )}
              </div>
            </>
          )}
          <div className={ROW}>
            <label htmlFor={`anim-auto-${node.id}`} className={LABEL}>Autoplay</label>
            <input id={`anim-auto-${node.id}`} type="checkbox" aria-label="Autoplay" checked={config.autoplay} onChange={(e) => patch({ autoplay: e.target.checked }, 'Autoplay')} />
          </div>
          <div className={ROW}>
            <label htmlFor={`anim-loop-${node.id}`} className={LABEL}>Loop</label>
            <input id={`anim-loop-${node.id}`} type="checkbox" aria-label="Loop" checked={config.loop} onChange={(e) => patch({ loop: e.target.checked }, 'Loop')} />
          </div>
          <div className={ROW}>
            <label htmlFor={`anim-speed-${node.id}`} className={LABEL}>Velocidade</label>
            <input
              id={`anim-speed-${node.id}`}
              type="number"
              aria-label="Velocidade"
              min={ANIMATION_SPEED_MIN}
              max={ANIMATION_SPEED_MAX}
              step={0.05}
              className={FIELD}
              defaultValue={config.speed}
              key={`speed-${config.speed}`}
              onBlur={(e) => {
                const v = Number(e.target.value);
                if (Number.isFinite(v)) patch({ speed: v }, 'Velocidade da animação');
              }}
            />
          </div>
          <div className={ROW}>
            <label htmlFor={`anim-fade-${node.id}`} className={LABEL}>Crossfade (s)</label>
            <input
              id={`anim-fade-${node.id}`}
              type="number"
              aria-label="Crossfade"
              min={0}
              step={0.05}
              className={FIELD}
              defaultValue={config.crossfade}
              key={`fade-${config.crossfade}`}
              onBlur={(e) => {
                const v = Number(e.target.value);
                if (Number.isFinite(v)) patch({ crossfade: v }, 'Crossfade da animação');
              }}
            />
          </div>
        </>
      )}
    </div>
  );
};
