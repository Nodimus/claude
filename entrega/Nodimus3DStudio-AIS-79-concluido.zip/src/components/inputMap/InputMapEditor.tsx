import React, { useEffect, useRef, useState } from 'react';
import { Gamepad2, Keyboard, MousePointer2, Pencil, Plus, RotateCcw, Trash2, X } from 'lucide-react';
import type { InputAction } from '../../types/project';
import {
  COMMON_BINDINGS,
  INPUT_PRESETS,
  addAction,
  addBindingTo,
  bindingFromGamepads,
  bindingFromKeyboardEvent,
  bindingFromMouseEvent,
  bindingKind,
  bindingLabel,
  removeAction,
  removeBindingFrom,
  renameAction,
  toBinding,
  type ActionReferences,
  type InputBinding,
  type InputPresetId,
} from '../../core/inputMap';

/**
 * AIS-58 — editor do Input Map (aba do Project Settings): CRUD de ações e bindings sobre o RASCUNHO do modal. Nada grava aqui:
 * quem salva é o Salvar do modal (dirty/Cancelar do AIS-32b), e as operações não são Commands (configuração global do projeto,
 * não estado autoral de cena). Toda regra mora em `src/core/inputMap.ts`; este componente só desenha e captura.
 */

interface Props {
  actions: InputAction[];
  onChange(actions: InputAction[]): void;
  deadzone: string;
  deadzoneError?: string;
  onDeadzoneChange(value: string): void;
  /** Referências à ação em Behaviors/Conditions (aviso ao excluir). */
  findUsage(action: string): ActionReferences;
  onResetDefaults(): void;
  /** AIS-73: repõe as ações de um preset (Personagem / Veículo) com os bindings padrão. */
  onApplyPreset?(preset: InputPresetId): void;
}

const CHIP_ICON = { key: Keyboard, mouse: MousePointer2, gamepad: Gamepad2 } as const;
const FIELD = 'bg-[#141820] text-white px-2 py-1 rounded border border-[#2c3345] outline-none focus:border-[#4982ea]';

export const InputMapEditor: React.FC<Props> = ({ actions, onChange, deadzone, deadzoneError, onDeadzoneChange, findUsage, onResetDefaults, onApplyPreset }) => {
  const [newName, setNewName] = useState('');
  const [createError, setCreateError] = useState<string | null>(null);
  const [renaming, setRenaming] = useState<{ from: string; text: string; error: string | null } | null>(null);
  const [capturing, setCapturing] = useState<string | null>(null);
  const [bindingError, setBindingError] = useState<{ action: string; message: string } | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const create = () => {
    const result = addAction(actions, newName);
    if (!result.ok) return setCreateError(result.error);
    onChange(result.actions);
    setNewName('');
    setCreateError(null);
  };

  const commitRename = () => {
    if (!renaming) return;
    if (renaming.text.trim() === renaming.from) return setRenaming(null);
    const result = renameAction(actions, renaming.from, renaming.text);
    if (!result.ok) return setRenaming({ ...renaming, error: result.error });
    onChange(result.actions);
    setRenaming(null);
  };

  const addBinding = (action: string, binding: InputBinding) => {
    const result = addBindingTo(actions, action, binding);
    if (!result.ok) return setBindingError({ action, message: result.error });
    setBindingError(null);
    onChange(result.actions);
  };

  const usage = confirmDelete ? findUsage(confirmDelete) : null;

  return (
    <div className="space-y-3" data-testid="input-map-editor">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-white font-medium mb-0.5">Input Map</div>
          <p className="text-[#8b97a8] leading-relaxed">
            Ações lógicas e as teclas, botões do mouse e do gamepad que as ativam. Behaviors, Triggers e Conditions leem a AÇÃO: trocar um binding aqui vale para todos, sem editar nenhum. Entra em Salvar.
          </p>
        </div>
        <div className="shrink-0 flex flex-col items-end gap-1">
        {onApplyPreset && (
          <div className="flex items-center gap-1 text-[#8b97a8]" data-testid="input-presets">
            <span>Preset:</span>
            {(Object.keys(INPUT_PRESETS) as InputPresetId[]).map((id) => (
              <button
                key={id}
                type="button"
                onClick={() => onApplyPreset(id)}
                className="px-2 py-1 rounded hover:text-white hover:bg-[#202531]"
                title={`Repõe as ações de ${INPUT_PRESETS[id].label} (${INPUT_PRESETS[id].actions.join(', ')}) com os bindings padrão; as outras ações não mudam`}
                data-testid={`input-preset-${id}`}
              >
                {INPUT_PRESETS[id].label}
              </button>
            ))}
          </div>
        )}
        <button type="button" onClick={onResetDefaults} className="shrink-0 flex items-center gap-1.5 px-2 py-1 rounded text-[#8b97a8] hover:text-white hover:bg-[#202531]" title="Repõe o conjunto de ações padrão do projeto" data-testid="input-reset">
          <RotateCcw className="w-3 h-3" />
          <span>Restaurar padrões</span>
        </button>
        </div>
      </div>

      {/* Criar ação */}
      <div>
        <div className="flex items-center gap-2">
          <input
            value={newName}
            onChange={(e) => {
              setNewName(e.target.value);
              setCreateError(null);
            }}
            onKeyDown={(e) => {
              e.stopPropagation();
              if (e.key === 'Enter') create();
            }}
            placeholder="Nome da nova ação (ex.: Dash)"
            aria-label="Nome da nova ação"
            aria-invalid={!!createError}
            spellCheck={false}
            className={`${FIELD} flex-1 font-mono ${createError ? '!border-rose-500' : ''}`}
          />
          <button type="button" onClick={create} className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#4982ea] hover:bg-[#3b6ecc] text-white" aria-label="Criar ação" data-testid="input-create">
            <Plus className="w-3.5 h-3.5" />
            Criar
          </button>
        </div>
        {createError && (
          <span role="alert" className="text-[10px] text-rose-400 mt-1 block" data-testid="input-create-error">
            {createError}
          </span>
        )}
      </div>

      {/* Lista de ações */}
      <div className="space-y-1.5">
        {actions.length === 0 && <div className="text-[#6b788a] italic">Nenhuma ação. Crie a primeira acima ou restaure os padrões.</div>}
        {actions.map((action) => (
          <div key={action.name} className="bg-[#141820] border border-[#2c3345] rounded p-2" data-testid="input-action" data-action={action.name}>
            <div className="flex items-center gap-2">
              {renaming?.from === action.name ? (
                <div className="flex-1">
                  <input
                    autoFocus
                    value={renaming.text}
                    onChange={(e) => setRenaming({ ...renaming, text: e.target.value, error: null })}
                    onBlur={commitRename}
                    onKeyDown={(e) => {
                      e.stopPropagation();
                      if (e.key === 'Enter') commitRename();
                      if (e.key === 'Escape') setRenaming(null);
                    }}
                    aria-label={`Renomear ${action.name}`}
                    aria-invalid={!!renaming.error}
                    spellCheck={false}
                    className={`${FIELD} w-full font-mono ${renaming.error ? '!border-rose-500' : ''}`}
                  />
                  {renaming.error && (
                    <span role="alert" className="text-[10px] text-rose-400 mt-1 block" data-testid="input-rename-error">
                      {renaming.error}
                    </span>
                  )}
                </div>
              ) : (
                <>
                  <span className="font-mono text-emerald-300 flex-1 truncate" title={action.name}>
                    {action.name}
                  </span>
                  <button type="button" onClick={() => setRenaming({ from: action.name, text: action.name, error: null })} className="p-1 rounded text-[#8b97a8] hover:text-white hover:bg-[#202531]" title="Renomear" aria-label={`Renomear ${action.name}`}>
                    <Pencil className="w-3 h-3" />
                  </button>
                  <button type="button" onClick={() => setConfirmDelete(action.name)} className="p-1 rounded text-[#8b97a8] hover:text-rose-400 hover:bg-[#202531]" title="Excluir ação" aria-label={`Excluir ${action.name}`}>
                    <Trash2 className="w-3 h-3" />
                  </button>
                </>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
              {action.bindings.map((b) => {
                const binding = toBinding(b);
                const Icon = CHIP_ICON[bindingKind(binding)];
                return (
                  <span key={binding} className="inline-flex items-center gap-1 pl-1.5 pr-0.5 py-0.5 rounded bg-[#202737] border border-[#2c3345] text-[#dfe4ec]" data-testid="input-chip">
                    <Icon className="w-3 h-3 text-sky-400" />
                    {bindingLabel(binding)}
                    <button type="button" onClick={() => onChange(removeBindingFrom(actions, action.name, binding))} className="p-0.5 rounded hover:bg-[#2c3345] text-[#8b97a8] hover:text-white" aria-label={`Remover ${bindingLabel(binding)} de ${action.name}`}>
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                );
              })}
              <button type="button" onClick={() => { setCapturing(action.name); setBindingError(null); }} className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded border border-dashed border-[#3b475f] text-[#8b97a8] hover:text-white hover:border-[#4982ea]" aria-label={`Adicionar binding a ${action.name}`} data-testid="input-add-binding">
                <Plus className="w-3 h-3" />
                binding
              </button>
            </div>

            {capturing === action.name && (
              <BindingCapture
                onCapture={(binding) => {
                  setCapturing(null);
                  addBinding(action.name, binding);
                }}
                onCancel={() => setCapturing(null)}
              />
            )}
            {bindingError?.action === action.name && (
              <span role="alert" className="text-[10px] text-rose-400 mt-1 block">
                {bindingError.message}
              </span>
            )}

            {confirmDelete === action.name && (
              <div className="mt-2 p-2 rounded border border-rose-500/40 bg-rose-500/10" role="alertdialog" aria-label={`Excluir ${action.name}`} data-testid="input-delete-confirm">
                <div className="text-rose-200">
                  Excluir <span className="font-mono">{action.name}</span> e os {action.bindings.length} binding(s)?
                </div>
                {usage && usage.count > 0 && (
                  <div className="text-amber-300 mt-1" data-testid="input-delete-usage">
                    Usada em {usage.count} lugar(es): {usage.where.slice(0, 4).join('; ')}
                    {usage.where.length > 4 ? '…' : ''}. As referências ficarão não resolvidas.
                  </div>
                )}
                <div className="flex gap-2 mt-2">
                  <button
                    type="button"
                    onClick={() => {
                      onChange(removeAction(actions, action.name));
                      setConfirmDelete(null);
                    }}
                    className="px-2 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white"
                    data-testid="input-delete-ok"
                  >
                    Excluir
                  </button>
                  <button type="button" onClick={() => setConfirmDelete(null)} className="px-2 py-1 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec]">
                    Cancelar
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <p className="text-[10px] text-[#8b97a8]">Renomear atualiza o nome aqui, mas não reescreve as cenas: referências antigas ficam não resolvidas até serem corrigidas.</p>

      {/* Zona morta do gamepad */}
      <div className="flex items-center gap-2" title="Eixos analógicos abaixo deste valor são ignorados (0 a 0,95)">
        <label htmlFor="input-deadzone" className="text-[#8b97a8] text-[11px]">
          Zona morta do gamepad
        </label>
        <input
          id="input-deadzone"
          value={deadzone}
          onChange={(e) => onDeadzoneChange(e.target.value)}
          inputMode="decimal"
          aria-invalid={!!deadzoneError}
          className={`${FIELD} w-20 text-right font-mono ${deadzoneError ? '!border-rose-500' : ''}`}
        />
        {deadzoneError && (
          <span role="alert" className="text-[10px] text-rose-400">
            {deadzoneError}
          </span>
        )}
      </div>
    </div>
  );
};

/**
 * Captura de binding: a próxima tecla, botão do mouse ou botão/eixo do gamepad vira o binding (Esc cancela); ou escolha na
 * lista. A captura intercepta o teclado ANTES do modal (Esc cancela só a captura, não fecha o Project Settings).
 */
const BindingCapture: React.FC<{ onCapture(binding: InputBinding): void; onCancel(): void }> = ({ onCapture, onCancel }) => {
  const done = useRef(false);
  const finish = (binding: InputBinding) => {
    if (done.current) return;
    done.current = true;
    onCapture(binding);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (e.code === 'Escape') return onCancel();
      const binding = bindingFromKeyboardEvent(e);
      if (binding) finish(binding);
    };
    window.addEventListener('keydown', onKey, true);
    let raf = 0;
    const poll = () => {
      const binding = typeof navigator !== 'undefined' && navigator.getGamepads ? bindingFromGamepads(Array.from(navigator.getGamepads())) : null;
      if (binding) return finish(binding);
      raf = requestAnimationFrame(poll);
    };
    raf = requestAnimationFrame(poll);
    return () => {
      window.removeEventListener('keydown', onKey, true);
      cancelAnimationFrame(raf);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      className="mt-2 p-2 rounded border border-[#4982ea]/50 bg-[#4982ea]/10"
      onMouseDown={(e) => {
        // o clique do mouse dentro do quadro de captura é o binding (esquerdo, meio ou direito)
        if ((e.target as HTMLElement).closest('[data-no-capture]')) return;
        e.preventDefault();
        finish(bindingFromMouseEvent(e));
      }}
      onContextMenu={(e) => e.preventDefault()}
      role="dialog"
      aria-label="Capturar binding"
      data-testid="input-capture"
    >
      <div className="text-[#cfe0ff]">Pressione uma tecla, clique aqui com um botão do mouse ou aperte um botão do gamepad… <span className="text-[#8b97a8]">(Esc cancela)</span></div>
      <div className="flex items-center gap-2 mt-2" data-no-capture>
        <select
          aria-label="Ou escolha da lista"
          defaultValue=""
          onChange={(e) => e.target.value && finish(e.target.value)}
          className={`${FIELD} flex-1`}
        >
          <option value="">Ou escolha da lista…</option>
          {COMMON_BINDINGS.map((g) => (
            <optgroup key={g.group} label={g.group}>
              {g.bindings.map((b) => (
                <option key={b} value={b}>
                  {bindingLabel(b)}
                </option>
              ))}
            </optgroup>
          ))}
        </select>
        <button type="button" onClick={onCancel} className="px-2 py-1 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] flex items-center gap-1">
          Cancelar
        </button>
      </div>
    </div>
  );
};
