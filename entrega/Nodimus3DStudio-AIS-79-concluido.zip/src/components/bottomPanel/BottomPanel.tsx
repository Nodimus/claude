import React from 'react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { VariablesDebugPanel } from './VariablesDebugPanel';
import { LogicExecutionPanel } from './LogicExecutionPanel';
import { SignalMonitorPanel } from './SignalMonitorPanel';
import { ProblemsPanel } from './ProblemsPanel';
import { useDiagnostics } from '../../core/diagnostics/useDiagnostics';
import { countErrors } from '../../core/diagnostics/problemsModel';
import {
  Terminal,
  Bug,
  Trash2,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Info,
  Cpu,
  Layers,
  Box,
  Radio,
  OctagonAlert,
} from 'lucide-react';

export const BottomPanel: React.FC = () => {
  // AIS-03f: UI layout and docking state migrated directly to canonical Zustand EditorStore
  const bottomTab       = useEditorStore((s) => s.bottomTab);
  const setBottomTab    = useEditorStore((s) => s.setBottomTab);
  const isBottomOpen    = useEditorStore((s) => s.isBottomOpen);
  const setIsBottomOpen = useEditorStore((s) => s.setIsBottomOpen);
  const isPlaying       = useEditorStore((s) => s.isPlaying);

  // Facade consumption for logs and authoring projections
  const {
    logs,
    clearLogs,
    activeScene,
    project,
    selectedNode,
  } = useEditor();

  const activeTab = bottomTab;

  // AIS-77: contador de erros/bloqueios do serviço único (a aba Problemas é só uma visão dele)
  const problems = useDiagnostics();
  const errorCount = countErrors(problems);
  const problemsLabel = `Problemas (${problems.length})`;
  const problemsIconClass = errorCount > 0 ? 'text-rose-400' : 'text-[#8b97a8]';

  if (!isBottomOpen) {
    return (
      <div className="h-7 bg-[#1a1f2b] border-t border-[#2c3345] px-2 flex items-center justify-between select-none text-xs">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => {
              setIsBottomOpen(true);
              setBottomTab('output');
            }}
            className="flex items-center gap-1.5 px-2 py-0.5 rounded text-[#8b97a8] hover:text-[#dfe4ec] hover:bg-[#2c3345] transition-colors"
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Output ({logs.length})</span>
          </button>

          <button
            onClick={() => {
              setIsBottomOpen(true);
              setBottomTab('debugger');
            }}
            className="flex items-center gap-1.5 px-2 py-0.5 rounded text-[#8b97a8] hover:text-[#dfe4ec] hover:bg-[#2c3345] transition-colors"
          >
            <Bug className="w-3.5 h-3.5 text-amber-400" />
            <span>Debugger</span>
          </button>

          <button
            onClick={() => {
              setIsBottomOpen(true);
              setBottomTab('signals');
            }}
            className="flex items-center gap-1.5 px-2 py-0.5 rounded text-[#8b97a8] hover:text-[#dfe4ec] hover:bg-[#2c3345] transition-colors"
          >
            <Radio className="w-3.5 h-3.5 text-emerald-400" />
            <span>Signals</span>
          </button>

          <button
            onClick={() => {
              setIsBottomOpen(true);
              setBottomTab('problems');
            }}
            className="flex items-center gap-1.5 px-2 py-0.5 rounded text-[#8b97a8] hover:text-[#dfe4ec] hover:bg-[#2c3345] transition-colors"
          >
            <OctagonAlert className={`w-3.5 h-3.5 ${problemsIconClass}`} />
            <span>{problemsLabel}</span>
          </button>

        </div>

        <button
          onClick={() => setIsBottomOpen(true)}
          className="p-1 text-[#8b97a8] hover:text-white"
          title="Expand Panel"
        >
          <ChevronUp className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  return (
    <div className={`h-48 bg-[#1a1f2b] border-t border-[#2c3345] flex flex-col select-none text-xs z-20`}>
      {/* Tab Navigation */}
      <div className="h-7 border-b border-[#2c3345] px-2 flex items-center justify-between bg-[#151922]">
        <div className="flex items-center space-x-1">
          <button
            onClick={() => setBottomTab('output')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === 'output'
                ? 'bg-[#2c3345] text-white'
                : 'text-[#8b97a8] hover:text-[#dfe4ec]'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Output ({logs.length})</span>
          </button>

          <button
            onClick={() => setBottomTab('debugger')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === 'debugger'
                ? 'bg-[#2c3345] text-white'
                : 'text-[#8b97a8] hover:text-[#dfe4ec]'
            }`}
          >
            <Bug className="w-3.5 h-3.5 text-amber-400" />
            <span>Debugger</span>
          </button>

          <button
            onClick={() => setBottomTab('signals')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === 'signals'
                ? 'bg-[#2c3345] text-white'
                : 'text-[#8b97a8] hover:text-[#dfe4ec]'
            }`}
          >
            <Radio className="w-3.5 h-3.5 text-emerald-400" />
            <span>Signals</span>
          </button>

          <button
            onClick={() => setBottomTab('problems')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === 'problems'
                ? 'bg-[#2c3345] text-white'
                : 'text-[#8b97a8] hover:text-[#dfe4ec]'
            }`}
          >
            <OctagonAlert className={`w-3.5 h-3.5 ${problemsIconClass}`} />
            <span>{problemsLabel}</span>
            {errorCount > 0 && <span className="px-1 rounded bg-rose-500/20 text-rose-300 text-[10px]" title="Erros e bloqueios">{errorCount}</span>}
          </button>

        </div>

        <div className="flex items-center gap-1">
          {activeTab === 'output' && (
            <button
              onClick={clearLogs}
              className="p-1 rounded text-[#8b97a8] hover:text-white hover:bg-[#2c3345] transition-colors"
              title="Clear Output"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            onClick={() => setIsBottomOpen(false)}
            className="p-1 text-[#8b97a8] hover:text-white"
            title="Collapse Panel"
          >
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Tab Body */}
      <div className="flex-1 overflow-hidden">
        {/* Output Tab */}
        {activeTab === 'output' && (
          <div className="h-full overflow-y-auto p-2 font-mono text-xs space-y-1 bg-[#12151d]">
            {logs.map((log) => (
              <div key={log.id} className="flex items-start gap-2 leading-tight">
                <span className="text-[#5b687c] shrink-0">{log.timestamp}</span>
                {log.type === 'error' ? (
                  <span className="text-rose-400 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 shrink-0" /> {log.message}
                  </span>
                ) : log.type === 'warn' ? (
                  <span className="text-amber-400 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 shrink-0" /> {log.message}
                  </span>
                ) : (
                  <span className="text-[#dfe4ec] flex items-center gap-1">
                    <Info className="w-3 h-3 text-[#8b97a8] shrink-0" /> {log.message}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}


        {/* Signals Tab (AIS-57) */}
        {activeTab === 'signals' && <SignalMonitorPanel />}

        {/* Problemas (AIS-77, emenda v5.8): visão do DiagnosticService */}
        {activeTab === 'problems' && <ProblemsPanel />}

        {/* Debugger Tab */}
        {activeTab === 'debugger' && (
          <div className="h-full p-3 bg-[#12151d] overflow-y-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
              <div className="bg-[#1c2230] p-3 rounded border border-[#2c3345]">
                <span className="text-[#8b97a8] block text-[11px] flex items-center gap-1">
                  <Box className="w-3 h-3 text-blue-400" /> Total Scene Nodes
                </span>
                <span className="text-lg font-bold text-white font-mono mt-0.5 block">
                  {Object.keys(activeScene.nodes).length}
                </span>
              </div>

              <div className="bg-[#1c2230] p-3 rounded border border-[#2c3345]">
                <span className="text-[#8b97a8] block text-[11px] flex items-center gap-1">
                  <Cpu className="w-3 h-3 text-emerald-400" /> Simulation State
                </span>
                <span className="text-lg font-bold text-emerald-400 font-mono mt-0.5 block">
                  {isPlaying ? '60 FPS (Running)' : 'Idle (Editor)'}
                </span>
              </div>

              <div className="bg-[#1c2230] p-3 rounded border border-[#2c3345]">
                <span className="text-[#8b97a8] block text-[11px] flex items-center gap-1">
                  <Layers className="w-3 h-3 text-sky-400" /> Active Renderer
                </span>
                <span className="text-sm font-semibold text-white font-mono mt-1 block">
                  {project.renderer}
                </span>
              </div>

              <div className="bg-[#1c2230] p-3 rounded border border-[#2c3345]">
                <span className="text-[#8b97a8] block text-[11px]">Scene Resource Path</span>
                <span className="text-xs font-semibold text-amber-300 font-mono truncate block mt-1">
                  {activeScene.path}
                </span>
              </div>
            </div>
            <VariablesDebugPanel />
            <LogicExecutionPanel />
          </div>
        )}
      </div>
    </div>
  );
};
