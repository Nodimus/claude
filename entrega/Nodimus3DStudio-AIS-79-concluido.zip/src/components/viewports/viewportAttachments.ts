import * as THREE from 'three';
import type { GameNode } from '../../types/node';
import type { AttachmentHost, AttachmentRecord } from '../../runtime/attachmentRuntime';
import { findBone, readAttachment } from '../../core/attachment/boneAttachment';
import type { ModelObjectHandle } from '../../core/models/createModelObject';

/**
 * AIS-61 §4 — apresentador dos attachments a ossos: faz o reparent REAL do objeto Three do nó para o esqueleto do modelo (o nó
 * acompanha a animação). Duas fontes, uma regra (`core/attachment/boneAttachment.ts`): o bloco autoral `properties.attachment`
 * (Inspector; vale no editor e no Play) e o `AttachmentHost` da sessão (Actions; só no Play, vence o autoral).
 *
 * SOQUETE: o objeto não entra direto no `Bone`. Fica num `Group` filho do osso cuja escala COMPENSA a escala acumulada do osso em
 * relação ao dono do modelo (esqueleto Mixamo vem a 0,01: sem isso o nó preso encolheria 100× e a posição seria em centímetros). Assim
 * `position/rotation/scale` do nó são locais à MÃO, em metros, como no resto do editor — e o gizmo, que converte pela matriz do pai
 * Three (agora o soquete, de escala 1), grava valores coerentes. Osso ainda inexistente (modelo carregando) = tenta no quadro seguinte;
 * osso que não existe no modelo é avisado UMA vez. Ao soltar, o objeto volta ao pai autoral e o soquete some.
 */

export interface AttachmentFrame {
  nodes: Readonly<Record<string, GameNode>>;
  objects: ReadonlyMap<string, THREE.Object3D>;
  /** Raiz da cena Three (pai dos nós sem ancestral desenhado). */
  root: THREE.Object3D;
  /** Estado da sessão (só durante o Play). */
  host?: Pick<AttachmentHost, 'get'> | null;
  /** Avisos (osso inexistente, holder sem modelo). */
  report?: (code: string, message: string, nodeId: string) => void;
}

interface Attached {
  bone: THREE.Bone;
  socket: THREE.Group;
  holder: THREE.Object3D;
}

const _bp = new THREE.Vector3();
const _bq = new THREE.Quaternion();
const _bs = new THREE.Vector3();
const _hp = new THREE.Vector3();
const _hq = new THREE.Quaternion();
const _hs = new THREE.Vector3();

/** Escala do soquete = escala mundial do dono do modelo ÷ escala mundial do osso, eixo a eixo (1 se o osso estiver degenerado). */
export function compensationScale(bone: THREE.Object3D, holder: THREE.Object3D, out: THREE.Vector3): THREE.Vector3 {
  bone.updateWorldMatrix(true, false);
  holder.updateWorldMatrix(true, false);
  bone.matrixWorld.decompose(_bp, _bq, _bs);
  holder.matrixWorld.decompose(_hp, _hq, _hs);
  const ratio = (h: number, b: number) => (Math.abs(b) > 1e-9 ? h / b : 1);
  return out.set(ratio(_hs.x, _bs.x), ratio(_hs.y, _bs.y), ratio(_hs.z, _bs.z));
}

export class ViewportAttachments {
  private readonly attached = new Map<string, Attached>();
  private readonly warned = new Set<string>();

  get activeCount(): number {
    return this.attached.size;
  }

  /** Desejado hoje para o nó: o vínculo vivo da sessão (vence), o autoral, ou nada. */
  private desired(node: GameNode, host: AttachmentFrame['host']): AttachmentRecord | null {
    const live = host?.get(node.id);
    if (live === null) return null; // solto em jogo
    if (live) return live;
    const authored = readAttachment(node.properties);
    return authored ? { holder: null, bone: authored.bone } : null;
  }

  update(frame: AttachmentFrame): void {
    const wanted = new Map<string, Attached>();
    for (const node of Object.values(frame.nodes)) {
      const record = this.desired(node, frame.host);
      if (!record) continue;
      const object = frame.objects.get(node.id);
      if (!object) continue;
      const holderId = record.holder ?? node.parentId;
      const holderObject = holderId ? frame.objects.get(holderId) : undefined;
      const handle = holderObject?.userData?.modelHandle as ModelObjectHandle | undefined;
      if (!handle || !holderObject) {
        this.warn(frame, node, 'attachment.no_model', `"${node.name}" não pode ser preso a um osso: ${holderId ? `"${frame.nodes[holderId]?.name ?? holderId}"` : 'o nó'} não tem um modelo 3D.`);
        continue;
      }
      if (handle.status() === 'loading') continue; // os ossos ainda não existem
      const bone = findBone(handle.object, record.bone);
      if (!bone) {
        if (handle.status() === 'ready') this.warn(frame, node, 'attachment.bone_missing', `O osso "${record.bone}" não existe no modelo de "${frame.nodes[holderId!]?.name ?? holderId}"; "${node.name}" ficou no lugar.`);
        continue;
      }
      const previous = this.attached.get(node.id);
      const socket = previous && previous.bone === bone ? previous.socket : new THREE.Group();
      socket.name = `AttachSocket:${bone.name}`;
      if (socket.parent !== bone) bone.add(socket);
      compensationScale(bone, holderObject, socket.scale);
      if (object.parent !== socket) socket.add(object);
      const entry: Attached = { bone, socket, holder: holderObject };
      wanted.set(node.id, entry);
      this.attached.set(node.id, entry);
    }
    // soltos (ou trocados de osso): voltam ao pai autoral e o soquete antigo sai
    for (const [nodeId, entry] of [...this.attached]) {
      if (wanted.get(nodeId)?.socket === entry.socket) continue;
      this.attached.delete(nodeId);
      const object = frame.objects.get(nodeId);
      if (object) this.restoreParent(frame, nodeId, object, entry.socket);
      entry.socket.removeFromParent();
    }
  }

  /** Solta tudo (Stop, troca de cena, desmontagem). */
  reset(frame?: Pick<AttachmentFrame, 'nodes' | 'objects' | 'root'>): void {
    for (const [nodeId, entry] of this.attached) {
      const object = frame?.objects.get(nodeId);
      if (frame && object) this.restoreParent(frame, nodeId, object, entry.socket);
      entry.socket.removeFromParent();
    }
    this.attached.clear();
    this.warned.clear();
  }

  private restoreParent(frame: Pick<AttachmentFrame, 'nodes' | 'objects' | 'root'>, nodeId: string, object: THREE.Object3D, fromSocket: THREE.Group): void {
    if (object.parent !== fromSocket) return; // já foi movido por outro caminho (ex.: o sync de hierarquia do editor)
    let parent: THREE.Object3D | null = null;
    const seen = new Set<string>([nodeId]);
    for (let pid = frame.nodes[nodeId]?.parentId; pid && !seen.has(pid); pid = frame.nodes[pid]?.parentId ?? null) {
      seen.add(pid);
      const candidate = frame.objects.get(pid);
      if (candidate) {
        parent = candidate;
        break;
      }
    }
    (parent ?? frame.root).add(object);
  }

  private warn(frame: AttachmentFrame, node: GameNode, code: string, message: string): void {
    const key = `${node.id}:${code}`;
    if (this.warned.has(key)) return;
    this.warned.add(key);
    frame.report?.(code, message, node.id);
  }
}
