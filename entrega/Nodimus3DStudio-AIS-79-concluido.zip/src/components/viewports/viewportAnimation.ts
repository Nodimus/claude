import * as THREE from 'three';
import type { RuntimeInstance, RuntimeScene } from '../../runtime/RuntimeScene';
import type { RuntimeSession } from '../../runtime/RuntimeSession';
import { applyMixerLayers } from '../../core/models/clipPlayer';
import type { ModelSourceBinding, ModelObjectHandle } from '../../core/models/createModelObject';
import { loadPlayerClips } from '../../core/models/playClips';
import { readPhysics } from '../../core/physics/physicsConfig';
import { readAnimation } from '../../core/animation/animationConfig';
import { captureRestPose, type RestPose } from '../../core/models/restPose';

/**
 * AIS-60/60b — apresentador das animações do Play. A `RuntimeSession` é dona do ESTADO de reprodução (`AnimationHost`, um `createClipMixer`
 * do AIS-37 por objeto animado); este módulo só (1) carrega os clipes do objeto animado (MeshInstance com `properties.animated`) (embutidos + `RigConfig.clips`, via `loadPlayerClips`),
 * (2) cria o `THREE.AnimationMixer` sobre o objeto do modelo que a viewport já desenha, (3) registra os clipes na sessão e (4) aplica as
 * camadas do host às ações a cada quadro (`applyMixerLayers`, a mesma função do preview do modal). Mesmo desenho dos spawns e partículas:
 * a lógica nunca conhece o Three.
 *
 * A animação move ossos internos do modelo (espaço local do rig); a pose do nó segue com a física/lógica. Um nó com `character`
 * ou corpo dinâmico força clipes IN-PLACE (o deslocamento é da física: sem duplicar movimento, skill §5).
 */

interface PlayerView {
  mixer: THREE.AnimationMixer;
  root: THREE.Object3D;
  actions: Map<string, THREE.AnimationAction>;
  durations: Map<string, number>;
  rest: RestPose;
  lastKey: string;
}

export class ViewportAnimation {
  private scene: RuntimeScene | null = null;
  private session: RuntimeSession | null = null;
  private readonly players = new Map<string, PlayerView>();
  /** Cada cena de runtime tem uma época; a carga assíncrona só vale para a época que a pediu. */
  private epoch = 0;

  constructor(private readonly source: ModelSourceBinding) {}

  /** Há uma cena de runtime acompanhada (mesmo sem players prontos)? */
  get hasScene(): boolean {
    return this.scene !== null;
  }

  /** Quantos players têm clipes aplicados ao esqueleto agora. */
  get activeCount(): number {
    return this.players.size;
  }

  /** Um quadro do Play: (re)descobre os players quando a cena de runtime muda e aplica as camadas do host. */
  update(session: RuntimeSession, objects: ReadonlyMap<string, THREE.Object3D>): void {
    const scene = session.currentScene;
    if (!scene || scene.disposed) {
      this.reset();
      return;
    }
    if (scene !== this.scene) {
      this.reset();
      this.scene = scene;
      this.session = session;
      for (const instance of scene.getAllInstances()) if (instance.type === 'MeshInstance' && readAnimation(instance.properties)) void this.load(session, scene, instance, objects, this.epoch);
    }
    for (const [playerId, view] of this.players) {
      const layers = session.animation.layersOf(playerId);
      const key = layers.map((l) => `${l.clip}:${l.time.toFixed(4)}:${l.weight.toFixed(3)}`).join('|');
      if (key === view.lastKey) continue; // pausado e sem crossfade: nada mudou
      view.lastKey = key;
      applyMixerLayers(view.mixer, view.actions, view.durations, layers);
    }
  }

  /** Solta os mixers e devolve os esqueletos à pose de repouso (Stop, restart, troca de cena). */
  reset(): void {
    this.epoch++;
    for (const [playerId, view] of this.players) {
      view.mixer.stopAllAction();
      view.mixer.uncacheRoot(view.root);
      view.rest.restore();
      this.session?.animation.unregister(playerId);
    }
    this.players.clear();
    this.scene = null;
    this.session = null;
  }

  private async load(session: RuntimeSession, scene: RuntimeScene, instance: RuntimeInstance, objects: ReadonlyMap<string, THREE.Object3D>, epoch: number): Promise<void> {
    const playerId = instance.persistentNodeId;
    const problem = (severity: 'error' | 'warning', code: string, message: string) => {
      if (epoch === this.epoch) session.reportRuntimeProblem(severity, code, message, playerId);
    };
    const handle = objects.get(playerId)?.userData?.modelHandle as ModelObjectHandle | undefined;
    if (!handle) {
      problem('warning', 'animation.no_model', `O objeto animado "${instance.name}" precisa ter um modelo 3D para animar (nada foi carregado).`);
      session.animation.register(playerId, { clips: [] });
      return;
    }
    await handle.ready;
    if (epoch !== this.epoch || scene.disposed) return;
    const model = handle.loaded();
    if (!model) {
      problem('warning', 'animation.model_not_ready', `O modelo de "${instance.name}" não carregou; não há o que animar.`);
      session.animation.register(playerId, { clips: [] });
      return;
    }
    const config = readAnimation(instance.properties)!;
    const physics = readPhysics(instance.properties);
    const forceInPlace = !!physics?.enabled && (physics.bodyMode === 'character' || physics.bodyMode === 'dynamic');
    const set = await loadPlayerClips({ model, rigConfig: config.rig, forceInPlace, source: this.source });
    if (epoch !== this.epoch || scene.disposed) return;
    for (const p of set.problems) problem('warning', p.code, p.message);

    const rest = captureRestPose(handle.object); // antes de qualquer clipe: o Stop devolve ESTA pose
    const mixer = new THREE.AnimationMixer(handle.object);
    const actions = new Map<string, THREE.AnimationAction>();
    const durations = new Map<string, number>();
    for (const clip of set.clips) {
      actions.set(clip.name, mixer.clipAction(clip));
      durations.set(clip.name, clip.duration);
    }
    this.players.set(playerId, { mixer, root: handle.object, actions, durations, rest, lastKey: '' });
    session.animation.register(playerId, {
      clips: set.infos,
      speed: config.speed,
      loop: config.loop,
      crossfade: config.crossfade,
      initial: config.default || undefined,
      autoplay: config.autoplay,
    });
  }
}
