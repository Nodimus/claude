import React, { useRef, useEffect, useState, useCallback, useMemo } from 'react';
import * as THREE from 'three';
import { TransformControls } from 'three/examples/jsm/controls/TransformControls.js';
import { useEditor } from '../../core/EditorContext';
import {
  useEditorStore,
  isBrushMode,
  GRID_SNAP_STEPS,
  ANGLE_SNAP_STEPS,
  GridSnapStep,
  AngleSnapStep,
} from '../../core/editorStore';
import { firstSurfaceHit, gizmoSnapValues, isSurfaceCandidate, surfaceSnapPosition } from './viewportSnap';
import { useFileDrop, isFileSystemDrag } from '../../hooks/useFileDrop';
import { FS_DRAG_MIME } from '../../core/fileSystem/dropActions';
import { isViewportNodeSelectable, resolveSelectableHitNodeId, updateViewportSelection } from './viewportSelection';
import { GameNode, NodeType } from '../../types/node';
import { NODE_REGISTRY } from '../../nodes/registry';
import { VirtualFile } from '../../types/project';
import { createThreeMaterial } from '../../utils/materialBuilder';
import { listProjectTextures, materialForRender, nodeMaterialOverride } from '../../core/material/nodeMaterial';
import { toThreeColor } from '../../utils/sceneColor';
import { projectActionsToMap, resolveDeadzone, withVehicleDefaults } from '../../core/inputMap';
import { createSoundHost, setActiveSoundHost } from '../../runtime/audioRuntime';
import { resolveSoundSource } from '../../core/sound/soundSource';
import { installGroundFog, setGroundFog } from '../../core/environment/groundFog';
import { PostProcessingPipeline } from '../../core/postProcessing/PostProcessingPipeline';
import { RendererCore, createDefaultRenderer } from '../../core/rendering/RendererCore';
import { effectiveShadowMapSize, fitFrame, resolveRenderSettings } from '../../runtime/renderSettings';
import { applyGameCameraPose, stepRuntimeViewportHost } from '../../runtime/runtimeViewportHost';
import { globalInputManager } from '../../runtime/input/global';
import { globalCommandManager } from '../../core/commandManager';
import { nodeObjectRegistry } from '../../core/rendering/nodeObjectRegistry';
import { ViewportColliders } from './viewportColliders';
import { SceneSelector } from './SceneSelector';
import { resourcePathOf, globalResourceRegistry } from '../../core/resources/global';
import { modelRefOf, releaseModelNodeObject, syncModelNodeObject } from '../../core/models/modelNodeSync';
import { registerViewportProbe } from '../../devHooks';
import { TerrainSculptController } from './viewportTerrainSculpt';
import { releaseTerrainEdit, terrainEditOverrideFor } from '../../core/terrainEdit';
import { disposeTerrainMesh, syncTerrainMesh, terrainDataOf } from '../../core/terrainObject';
import { disposeWaterObject, isWaterObject, syncWaterObject, tagWaterNode, updateWaterObject } from '../../core/water/waterObject';
import { billboardYaw, readFaceMode } from '../../core/billboard';
import { applyPathVisibility, disposePathObject, isPathObject, syncPathObject, tagPathNode } from '../../core/path/pathObject';
import { PathEditController } from './viewportPathEdit';
import { disposeHotspotObject, isHotspotObject, setHotspotPlayMode, syncHotspotObject, tagHotspotNode } from '../../core/hotspot/hotspotObject';
import { disposeTree, isTreeNodeProps, syncTreeObject } from '../../core/tree/treeBuild';
import { disposeVegetation, syncVegetationObject } from '../../core/vegetation/vegetationBuild';
import { SkyController } from '../../core/environment/skyBackground';
import { readSkySettings } from '../../core/environment/skyTypes';
import { subscribeHeightmapDecoded } from '../../core/terrainHeightmapCache';
import { isModelExt } from '../../core/models/types';
import { OverlayHud } from '../../runtime/overlayHud';
import { getLogicRunner, takeStepFrameRequest } from '../../runtime/logicRunnerSession';
import { PlayControlBar } from './PlayControlBar';
import { getActiveRuntimeSession } from '../../runtime/RuntimeSession';
import type { AuthoringSceneSnapshot } from '../../types/runtime';
import { readViewLock } from '../../core/commands/ViewLockCommand';
import { mergeRuntimeHudNodes } from '../../runtime/runtimeHudNodes';
import { isLayoutContainerType } from '../../runtime/containerLayout';
import {
  hitTestOverlays,
  normalizeLayoutPreset,
  rectToOverlayOffsets,
  resolveOverlayRects,
  isOverlayNodeType,
  type LayoutPreset,
  type Rect,
} from '../../runtime/overlay';
import { groupTransformTargets } from '../../core/authoring/selectionUtils';
import { applyGroupDelta } from '../../core/authoring/groupTransform';
import {
  createGizmoTransformCommand,
  createGroupTransformCommand,
  type GroupTransformItem,
  GizmoMode,
  NodeTransform,
  readNodeTransform,
  readObjectTransform,
} from './gizmoCommand';
import {
  EditorCameraController,
  EditorCameraState,
  EditorAxisView,
  EditorViewPreset,
  frameDistanceForSphere,
  viewPresetForShortcut,
} from './editorCamera';
import { boundingSphereForObjects, metricRulerScale, projectWorldPosition } from './viewportGuides';
import { ViewportParticles } from './viewportParticles';
import { SpawnPresenter } from '../../runtime/spawnPresenter';
import { ViewportAnimation } from './viewportAnimation';
import { ViewportSprites, spriteViewOf, type SpriteEnv } from './viewportSprites';
import { RuntimeDebugOverlay } from './RuntimeDebugOverlay';
import { DebugStats } from '../../core/debug/debugStats';
import { hashContent } from '../../core/documents/documentKinds';
import { ViewportAnimationPreview } from './viewportAnimationPreview';
import { RouteLinesHelper } from './viewportRouteLines';
import { AiHelpers } from './viewportAiHelpers';
import { disposeWaypointObject, isWaypointObject, setWaypointPlayMode, syncWaypointObject, tagWaypointNode } from '../../core/waypoints/waypointObject';
import { ViewportAttachments } from './viewportAttachments';
import { projectModelSource } from '../../core/models/global';
import { DEFAULT_MATERIAL_PROPERTIES } from '../../types/material';
import {
  Move,
  RotateCw,
  Maximize,
  Compass,
  Layers,
  Sparkles,
  Mountain,
  Trees,
  CloudFog,
  Headphones,
  Plus,
  ChevronDown,
  Film,
  Check,
  Save,
  Box,
  Image as ImageIcon,
  Type,
  MousePointerClick,
  Sun,
  Zap,
  Video,
  Grid,
  Eye,
  EyeOff,
  Magnet,
  BoxSelect,
  Lock,
  Unlock,
} from 'lucide-react';

/**
 * Creates a high-resolution billboard icon sprite for non-mesh scene objects.
 * Represents the appearance of cameras, lights, audio players, spatials, etc.
 */
function createNodeIconSprite(type: string): THREE.Sprite {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.Sprite();

  ctx.clearRect(0, 0, 128, 128);

  // Background color and icon symbol per node type (Godot colors)
  let bg = '#3b82f6';
  let symbol = '📦';
  if (type === 'Camera') {
    bg = '#c026d3';
    symbol = '🎥';
  } else if (type === 'DirectionalLight') {
    bg = '#d97706';
    symbol = '☀️';
  } else if (type === 'OmniLight') {
    bg = '#ea580c';
    symbol = '💡';
  } else if (type === 'SpotLight') {
    bg = '#ca8a04';
    symbol = '🔦';
  } else if (type === 'AudioPlayer3D' || type === 'AudioPlayer') {
    bg = '#db2777';
    symbol = '🔊';
  } else if (type === 'ParticleSystem') {
    bg = '#d97706';
    symbol = '✨';
  } else if (type === 'Spatial' || type === 'World3D' || type === 'Node') {
    bg = '#059669';
    symbol = '🌐';
  } else if (type === 'Environment') {
    bg = '#0284c7';
    symbol = '🌍';
  }

  // Draw circular badge
  ctx.beginPath();
  ctx.arc(64, 64, 50, 0, Math.PI * 2);
  ctx.fillStyle = bg;
  ctx.fill();

  // Crisp white border
  ctx.lineWidth = 5;
  ctx.strokeStyle = '#ffffff';
  ctx.stroke();

  // Draw symbol in center
  ctx.font = '52px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(symbol, 64, 66);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;

  const mat = new THREE.SpriteMaterial({
    map: texture,
    transparent: true,
    depthTest: false,
    depthWrite: false,
  });

  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(0.9, 0.9, 0.9);
  sprite.renderOrder = 999;
  return sprite;
}

export const Viewport3D: React.FC = () => {
  const {
    project,
    activeScene,
    loadScene,
    createNewScene,
    saveCurrentScene,
    setIsPostProcessingOpen,
    setIsTerrainEditorOpen,
    setIsTreeEditorOpen,
    setIsFogModalOpen,
    setIsSoundModalOpen,
    setIsParticleModalOpen,
    selectedNodeId,
    multiSelectedNodeIds,
    selectedNode,
    selectNode,
    setMultiSelectedNodeIds,
    updateNodeProperties,
    addNode,
    addLog,
    isPlaying,
    isPaused,
    stopGame,
    behaviors,
    setViewLock,
  } = useEditor();

  const dropFile = useFileDrop(); // AIS-31

  // AIS-25: arquivos do projeto para resolver a textura de albedo (ResourceRef) sem refazer o sync a cada gravação
  const projectSettingsRef = useRef(project.settings);
  projectSettingsRef.current = project.settings;
  const projectFilesRef = useRef(project.files);
  projectFilesRef.current = project.files;
  const texturesSignature = useMemo(
    () => listProjectTextures(project.files).map((t) => `${t.path}:${t.dataUrl?.length ?? 0}`).join('|'),
    [project.files]
  );
  // AIS-76: o Billboard referencia um `.sprite.json`; mudou o arquivo (ou o atlas), o desenho se refaz
  const spritesSignature = useMemo(
    () => Object.values(project.files).filter((f) => f.path.endsWith('.sprite.json')).map((f) => `${f.path}:${hashContent(f.content)}`).join('|'),
    [project.files]
  );
  const spriteEnv = useMemo<SpriteEnv>(() => ({ files: () => projectFilesRef.current, pathOf: resourcePathOf }), []);

  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  // AIS-07: editor camera (not a GameNode, never persisted) — orbit/pan/zoom + perspective/orthographic
  const editorCameraRef = useRef<EditorCameraController | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const ambientLightRef = useRef<THREE.AmbientLight | null>(null);
  const objectsMapRef = useRef<Map<string, THREE.Object3D>>(nodeObjectRegistry);

  // Viewport tools state
  const [activeTool, setActiveTool] = useState<'move' | 'rotate' | 'scale'>('move');
  const [cameraView, setCameraView] = useState<EditorViewPreset>('Perspective');
  const [showOverlaysHUD, setShowOverlaysHUD] = useState<boolean>(true);
  // AIS-33a: muda quando um arquivo de modelo é criado, reimportado, movido ou removido (refaz os objetos de modelo)
  const [modelsVersion, setModelsVersion] = useState(0);
  // AIS-50: muda quando um heightmap termina de decodificar ou um arquivo de imagem/.height do projeto é alterado (refaz o terreno)
  const [terrainVersion, setTerrainVersion] = useState(0);
  // céu do Environment (HDRI carrega de forma assíncrona: o controlador avisa quando muda)
  const skyRef = useRef<SkyController | null>(null);
  const [skyVersion, setSkyVersion] = useState(0);
  useEffect(() => {
    const offDecoded = subscribeHeightmapDecoded(() => setTerrainVersion((v) => v + 1));
    const offResources = globalResourceRegistry.subscribe((event) => {
      const uris = event.type === 'moved' ? [event.from, event.to] : [event.uri];
      if (uris.some((u) => /\.(png|jpe?g|height)$/i.test(u))) setTerrainVersion((v) => v + 1);
    });
    return () => {
      offDecoded();
      offResources();
    };
  }, []);
  useEffect(
    () =>
      globalResourceRegistry.subscribe((event) => {
        const uris = event.type === 'moved' ? [event.from, event.to] : [event.uri];
        if (uris.some((u) => isModelExt((u.split('.').pop() ?? '').toLowerCase()))) setModelsVersion((v) => v + 1);
      }),
    []
  );
  const [snapToGrid, setSnapToGrid] = useState<boolean>(true);

  // 2D Overlay Interactive Drag & Resize State (AIS-25b: em retângulos de tela; os offsets saem do layout do preset)
  const [dragState, setDragState] = useState<{
    nodeId: string;
    action: 'move' | 'resize';
    handle?: 'tl' | 'tr' | 'bl' | 'br' | 't' | 'b' | 'l' | 'r';
    startX: number;
    startY: number;
    preset: LayoutPreset;
    parentRect: Rect;
    origRect: Rect;
  } | null>(null);

  // AIS-25b: HUD UIKit (motor único de overlays) e tamanho da viewport para o layout
  const hudRef = useRef<OverlayHud | null>(null);
  const [viewportSize, setViewportSize] = useState({ width: 0, height: 0 });
  /** AIS-44d: palco (área do canvas) — em Play a viewport vira uma moldura na proporção de `display.width × height`. */
  const stageRef = useRef<HTMLDivElement>(null);
  const [stageSize, setStageSize] = useState({ width: 0, height: 0 });
  const [hudRects, setHudRects] = useState<ReadonlyMap<string, Rect>>(new Map());

  // Orbit controls state
  const isMouseDownRef = useRef(false);
  const mouseButtonRef = useRef(0);
  const mouseStartRef = useRef({ x: 0, y: 0 });
  const selectionBoxesRef = useRef<Map<string, THREE.BoxHelper>>(new Map());
  // AIS-17: bounding box composta da seleção múltipla
  const compositeBoxRef = useRef<THREE.Box3Helper | null>(null);
  /** AIS-19: pivô do gizmo em grupo (centro da bounding box composta dos alvos). */
  const groupPivotRef = useRef<THREE.Object3D | null>(null);
  const guideLabelRefs = useRef<Map<string, HTMLDivElement>>(new Map());
  const rulerLineRef = useRef<HTMLDivElement>(null);
  const rulerLabelRef = useRef<HTMLSpanElement>(null);
  const transformControlsRef = useRef<TransformControls | null>(null);
  const isGizmoDraggingRef = useRef(false);

  // Game Runtime Simulation State (Executed directly in Viewport)
  const initialTransformsRef = useRef<
    Map<string, { position: THREE.Vector3; rotation: THREE.Euler; scale: THREE.Vector3; visible: boolean }>
  >(new Map());
  const initialCameraRef = useRef<EditorCameraState | null>(null);
  // AIS-06b: renderer, loop de quadros e relógio pertencem ao RendererCore (fora do React).
  const coreRef = useRef<RendererCore | null>(null);
  const postPipelineRef = useRef<PostProcessingPipeline | null>(null);

  // Synchronized refs for render loop
  const isPlayingRef = useRef(isPlaying);
  isPlayingRef.current = isPlaying;
  const isPausedRef = useRef(isPaused);
  isPausedRef.current = isPaused;
  const showOverlaysRef = useRef(showOverlaysHUD);
  showOverlaysRef.current = showOverlaysHUD;
  /** AIS-44: última revisão de UI do runner já refletida no HUD (por runner: Restart cria outro). */
  /** AIS-73: snapshot da cena VIVA quando o Play trocou de cena (Change Scene) e ela difere da aberta no editor; `null` = a cena aberta. */
  const [foreignSnapshot, setForeignSnapshot] = useState<AuthoringSceneSnapshot | null>(null);
  const foreignSnapshotRef = useRef<AuthoringSceneSnapshot | null>(null);
  const hudRevisionRef = useRef<{ runner: object | null; revision: number; /** AIS-73: snapshot da cena VIVA (muda com Change Scene). */ snapshot: object | null }>({ runner: null, revision: -1, snapshot: null });
  const behaviorsRef = useRef(behaviors);
  behaviorsRef.current = behaviors;
  const activeSceneRef = useRef(activeScene);
  activeSceneRef.current = activeScene;
  const selectedGuideNodeIds = useMemo(
    () => [...new Set([...(selectedNodeId ? [selectedNodeId] : []), ...multiSelectedNodeIds])],
    [selectedNodeId, multiSelectedNodeIds]
  );
  const selectedGuideNodeIdsRef = useRef(selectedGuideNodeIds);
  const particlesRef = useRef<ViewportParticles | null>(null);
  selectedGuideNodeIdsRef.current = selectedGuideNodeIds;

  // AIS-09: precision toolbar (grid / angle / surface snapping), transient IDE state
  const viewportSnap = useEditorStore((s) => s.viewportSnap);
  const setViewportSnap = useEditorStore((s) => s.setViewportSnap);
  const viewportSnapRef = useRef(viewportSnap);
  viewportSnapRef.current = viewportSnap;
  // AIS-26b: "Mostrar colisores" (preferência do editor)
  const showColliders = useEditorStore((s) => s.showColliders);
  // AIS-77: overlay de debug — só existe (montado e com sonda no renderer) durante o Play com F3 ligado; desligado não coleta nada
  const showDebugOverlay = useEditorStore((s) => s.showDebugOverlay);
  const debugStatsRef = useRef<DebugStats | null>(null);
  if (!debugStatsRef.current) debugStatsRef.current = new DebugStats(60);
  const setShowColliders = useEditorStore((s) => s.setShowColliders);
  const showCollidersRef = useRef(showColliders);
  showCollidersRef.current = showColliders;
  /** Last pointer position over the canvas in NDC (surface snapping raycast). */
  const pointerNdcRef = useRef(new THREE.Vector2());

  // Simulation start / stop lifecycle
  useEffect(() => {
    hudRevisionRef.current = { runner: null, revision: -1, snapshot: null };
    if (isPlaying) {
      // Backup all Three.js object transforms
      const map = new Map<
        string,
        { position: THREE.Vector3; rotation: THREE.Euler; scale: THREE.Vector3; visible: boolean }
      >();
      for (const [id, obj] of objectsMapRef.current.entries()) {
        map.set(id, {
          position: obj.position.clone(),
          rotation: obj.rotation.clone(),
          scale: obj.scale.clone(),
          visible: obj.visible,
        });
      }
      initialTransformsRef.current = map;

      if (editorCameraRef.current) {
        initialCameraRef.current = editorCameraRef.current.getState();
      }
      coreRef.current?.resetClock();
      addLog('log', `--- Simulation Started in Viewport (${activeScene.name}) ---`);
    } else {
      // Restore initial transforms
      if (initialTransformsRef.current.size > 0) {
        for (const [id, saved] of initialTransformsRef.current.entries()) {
          const obj = objectsMapRef.current.get(id);
          if (obj) {
            obj.position.copy(saved.position);
            obj.rotation.copy(saved.rotation);
            obj.scale.copy(saved.scale);
            obj.visible = saved.visible; // o Play pode ter escondido/destruído objetos: o Stop devolve a cena exata
          }
        }
        initialTransformsRef.current.clear();
      }

      if (initialCameraRef.current && editorCameraRef.current) {
        editorCameraRef.current.setState(initialCameraRef.current);
        initialCameraRef.current = null;
      }
    }
  }, [isPlaying, activeScene.name, addLog]);

  // AIS-47: o ponteiro capturado não sobrevive ao Play (Stop libera)
  useEffect(() => {
    if (isPlaying) return;
    if (typeof document !== 'undefined' && document.pointerLockElement) document.exitPointerLock?.();
  }, [isPlaying]);

  // AIS-52: áudio do Play (mixer do projeto + atenuação 3D + Doppler); o Stop descarta todas as vozes
  const activeSceneNodesRef = useRef(activeScene.nodes);
  activeSceneNodesRef.current = activeScene.nodes;
  useEffect(() => {
    const core = coreRef.current;
    if (!isPlaying || !core) return;
    const audio = createSoundHost({
      nodes: activeSceneNodesRef.current,
      objectOf: (id) => objectsMapRef.current.get(id),
      sourceOf: (path) => resolveSoundSource(path, projectFilesRef.current),
      getSettings: () => projectSettingsRef.current?.audio,
      getListener: () => editorCameraRef.current?.camera,
      onFinished: (emitterId, path) => void getActiveRuntimeSession()?.emitSignal('finished', { source: emitterId, args: [path], origin: 'audio' }),
    });
    setActiveSoundHost(audio); // as Actions play_sound/stop_sound/set_sound_properties alcançam as vozes por aqui
    const offFrame = core.onFrame(({ dt }) => audio.update(dt));
    return () => {
      offFrame();
      setActiveSoundHost(null);
      audio.dispose();
    };
  }, [isPlaying]);

  // AIS-40b: input do JOGO. Só existe durante o Play: o InputManager liga ao entrar e o disposer o desliga ao sair (Play/Stop
  // repetido não acumula listeners). Esc/F8 (parar) são ATALHOS DO EDITOR e seguem em `useDesktopShortcuts`, não aqui.
  useEffect(() => {
    if (!isPlaying) return;
    // AIS-58: o Input Map do PROJETO (Project Settings › Input Map) vale em todo Play; sem configuração, o mapa padrão (teclado, mouse e gamepad)
    globalInputManager.setMap(withVehicleDefaults(projectActionsToMap(projectSettingsRef.current?.input?.actions))); // AIS-73: ações de condução ausentes valem pelos padrões
    globalInputManager.setDeadzone(resolveDeadzone(projectSettingsRef.current?.input?.deadzone));
    return globalInputManager.attach({ keyTarget: window, pointerTarget: mountRef.current ?? undefined });
  }, [isPlaying]);

  // Initialize Three.js Scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x141822);
    sceneRef.current = scene;

    // 2. Editor camera (AIS-07) — one controller per component, kept across StrictMode re-runs
    const editorCamera = editorCameraRef.current ?? (editorCameraRef.current = new EditorCameraController());
    editorCamera.update(0, container.clientWidth / Math.max(container.clientHeight, 1));

    // Play follow-camera mutates the controller's target/spherical (applied to both projections each frame)
    const rig = { camera: editorCamera.perspective, target: editorCamera.target, spherical: editorCamera.spherical };

    // 3. Renderer — AIS-06b: created, resized, looped and disposed by RendererCore (outside React).
    // The pipeline (ACESFilmic + sRGB + PCF shadows) is the AIS-06 default of createDefaultRenderer().
    // AIS-44d (msaa, opção C): o antialias é lido das settings do projeto AO CRIAR o renderer; mudar depois vale na próxima abertura
    installGroundFog();
    const core = new RendererCore({ createRenderer: () => createDefaultRenderer({ antialias: resolveRenderSettings(projectSettingsRef.current).msaa.antialias }) });
    const hud = new OverlayHud();
    hudRef.current = hud;
    core.setOverlayPass(hud);
    // AIS-55: pós-processamento real (EffectComposer) para editor e Play; sem efeitos ligados o core renderiza direto
    const postPipeline = new PostProcessingPipeline(core.renderer);
    postPipelineRef.current = postPipeline;
    core.setPostProcess(postPipeline);
    hud.setRectsListener((rects) => setHudRects(rects));
    coreRef.current = core;
    const renderer = core.renderer;
    skyRef.current = new SkyController(scene, renderer, () => setSkyVersion((v) => v + 1));
    rendererRef.current = renderer;
    core.setView({ scene, camera: editorCamera.camera });

    // 4. Ambient Light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.45);
    ambientLightRef.current = ambientLight;
    scene.add(ambientLight);

    // 5. Grid Helper & Origin Axes
    const gridHelper = new THREE.GridHelper(24, 24, 0x4982ea, 0x2c3345);
    gridHelper.position.y = -0.01;
    scene.add(gridHelper);

    const axesHelper = new THREE.AxesHelper(3);
    scene.add(axesHelper);

    // 6. Interactive 3D TransformControls Gizmo (Godot / Blender style)
    const transformControls = new TransformControls(editorCamera.camera, renderer.domElement);
    const gizmoHelper = transformControls.getHelper ? transformControls.getHelper() : (transformControls as any);
    scene.add(gizmoHelper);
    transformControlsRef.current = transformControls;

    // Projection switch (Perspective ⇄ orthographic): renderer view and gizmo follow the active camera
    editorCamera.onViewChange = (view) => {
      core.setView({ scene, camera: editorCamera.camera });
      transformControls.camera = editorCamera.camera;
      setCameraView(view);
    };
    setCameraView(editorCamera.currentView);

    // AIS-08: during the drag only the Three object moves (imperative preview); on release a
    // single Command records before → after in the CommandManager (one Ctrl+Z per drag).
    let gizmoDragStart: { nodeId: string; before: NodeTransform } | null = null;
    // AIS-19: transformação em grupo — o gizmo fica num pivô (centro da bounding box composta);
    // o delta do pivô (translação/rotação/escala) vale para todos os alvos, em torno do pivô.
    type GroupDrag = {
      pivotStart: THREE.Vector3;
      targets: { nodeId: string; obj: THREE.Object3D; world: THREE.Matrix4; parentWorld: THREE.Matrix4; before: NodeTransform }[];
    };
    let groupDrag: GroupDrag | null = null;
    const groupPivot = new THREE.Object3D();
    scene.add(groupPivot);
    groupPivotRef.current = groupPivot;
    const resetGroupPivot = (position: THREE.Vector3) => {
      groupPivot.position.copy(position);
      groupPivot.quaternion.identity();
      groupPivot.scale.set(1, 1, 1);
      groupPivot.updateMatrixWorld(true);
    };
    transformControls.addEventListener('dragging-changed', (event: any) => {
      isGizmoDraggingRef.current = Boolean(event.value);
      const target = transformControls.object;
      const isGroup = target === groupPivot;
      const nodeId: string | undefined = target && !isGroup ? (target as any).__nodeId : undefined;
      const mode = transformControls.mode as GizmoMode;

      if (event.value) {
        groupDrag = null;
        gizmoDragStart = null;
        if (isGroup) {
          const scene = activeSceneRef.current;
          const ids = groupTransformTargets(scene.nodes, selectedGuideNodeIdsRef.current, scene.rootNodeId);
          const targets: GroupDrag['targets'] = [];
          for (const id of ids) {
            const obj = objectsMapRef.current.get(id);
            const node = scene.nodes[id];
            if (!obj || !node) continue;
            obj.updateMatrixWorld(true);
            targets.push({
              nodeId: id,
              obj,
              world: obj.matrixWorld.clone(),
              parentWorld: obj.parent ? obj.parent.matrixWorld.clone() : new THREE.Matrix4(),
              before: readNodeTransform(node.properties),
            });
          }
          groupDrag = { pivotStart: groupPivot.position.clone(), targets };
        } else {
          const node = nodeId ? activeSceneRef.current.nodes[nodeId] : undefined;
          gizmoDragStart = node && nodeId ? { nodeId, before: readNodeTransform(node.properties) } : null;
        }
        return;
      }

      const apply = (id: string, transform: NodeTransform) => updateNodeProperties(id, { ...transform }, false);
      const group: GroupDrag | null = groupDrag;
      const start = gizmoDragStart;
      gizmoDragStart = null;
      groupDrag = null;

      if (isGroup && group) {
        // um gesto = um SetTransformCommand de grupo ("Move Nodes (N)" etc.); Ctrl+Z desfaz todos
        const items: GroupTransformItem[] = group.targets.map((t) => ({
          nodeId: t.nodeId,
          nodeName: activeSceneRef.current.nodes[t.nodeId]?.name ?? t.nodeId,
          before: t.before,
          after: readObjectTransform(t.obj),
        }));
        resetGroupPivot(group.pivotStart);
        const command = createGroupTransformCommand({ mode, items, apply });
        if (command) globalCommandManager.execute(command);
        return;
      }

      if (!start || !target || nodeId !== start.nodeId) return;
      const node = activeSceneRef.current.nodes[start.nodeId];
      if (!node) return;
      const command = createGizmoTransformCommand({
        nodeId: start.nodeId,
        nodeName: node.name,
        mode,
        before: start.before,
        after: readObjectTransform(target),
        apply,
      });
      if (command) globalCommandManager.execute(command);
    });

    // AIS-09: track the cursor (capture phase → runs before TransformControls' own pointermove)
    const canvas = renderer.domElement;
    const handleCanvasPointerMove = (e: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      pointerNdcRef.current.set(
        ((e.clientX - rect.left) / rect.width) * 2 - 1,
        -((e.clientY - rect.top) / rect.height) * 2 + 1
      );
    };
    canvas.addEventListener('pointermove', handleCanvasPointerMove, { capture: true });

    // AIS-09: Surface Snapping — while translating, put the object's base on the static mesh under
    // the cursor (preview only; the AIS-08 Command records the final pose on release).
    const surfaceRaycaster = new THREE.Raycaster();
    transformControls.addEventListener('objectChange', () => {
      if (!viewportSnapRef.current.surfaceEnabled || transformControls.mode !== 'translate') return;
      if (!isGizmoDraggingRef.current) return;
      const target = transformControls.object;
      const draggedId: string | undefined = target ? (target as any).__nodeId : undefined;
      if (!target || !draggedId) return;

      const surfaces: THREE.Object3D[] = [];
      for (const node of Object.values(activeSceneRef.current.nodes)) {
        if (!isSurfaceCandidate(node, draggedId)) continue;
        const obj = objectsMapRef.current.get(node.id);
        if (obj && obj.visible) surfaces.push(obj);
      }
      surfaceRaycaster.setFromCamera(pointerNdcRef.current, editorCamera.camera);
      const hit = firstSurfaceHit(surfaceRaycaster, surfaces);
      if (!hit) return; // nothing under the cursor: keep the gizmo (grid) position

      target.updateMatrixWorld(true);
      const bounds = new THREE.Box3().setFromObject(target);
      if (bounds.isEmpty()) return;
      const snapped = surfaceSnapPosition(target.position, bounds, hit);
      target.position.set(snapped.x, snapped.y, snapped.z);
    });

    // AIS-19: durante o arraste do pivô, todos os alvos recebem o mesmo delta em torno do pivô
    // (prévia imperativa; snaps do gizmo já atuam sobre o pivô, logo valem para o grupo)
    transformControls.addEventListener('objectChange', () => {
      const drag = groupDrag as GroupDrag | null;
      if (!drag || transformControls.object !== groupPivot || !isGizmoDraggingRef.current) return;
      const mode = transformControls.mode as GizmoMode;
      const delta = {
        translation: groupPivot.position.clone().sub(drag.pivotStart),
        rotation: groupPivot.quaternion.clone(),
        scale: groupPivot.scale.clone(),
      };
      for (const t of drag.targets) {
        const next = applyGroupDelta(mode, drag.pivotStart, delta, { world: t.world, parentWorld: t.parentWorld });
        t.obj.position.set(next.position.x, next.position.y, next.position.z);
        t.obj.rotation.set(
          THREE.MathUtils.degToRad(next.rotation.x),
          THREE.MathUtils.degToRad(next.rotation.y),
          THREE.MathUtils.degToRad(next.rotation.z)
        );
        t.obj.scale.set(next.scale.x, next.scale.y, next.scale.z);
      }
    });

    // AIS-18c: partículas (adaptador THREE.Points sobre o motor único) — loop pelo RendererCore
    const particles = new ViewportParticles();
    particlesRef.current = particles;
    // AIS-44e: objetos criados em jogo (`spawnPrefab`) entram na cena Three só durante o Play
    const spawnPresenter = new SpawnPresenter();
    // AIS-60: animações esqueléticas do Play (o estado vive na sessão; aqui só se aplica aos esqueletos que a viewport já desenha)
    const viewportAnimation = new ViewportAnimation(projectModelSource);
    // AIS-76: Billboards animados do Play (estado no SpriteHost da sessão; aqui só se aplica a região do atlas ao desenho)
    const viewportSprites = new ViewportSprites(spriteEnv);
    // AIS-60b: Prévia ▶ da animação padrão (fora do Play): pose do objeto animado selecionado, transitória, nunca no authoring
    const viewportAnimationPreview = new ViewportAnimationPreview(projectModelSource);
    const routeLines = new RouteLinesHelper(scene); // AIS-72b: linhas da rota selecionada (só editor)
    const aiHelpers = new AiHelpers(scene); // AIS-71: círculos de percepção/perda/patrulha do nó selecionado (só editor)
    // AIS-61 §4: nós presos a ossos (Inspector e Actions); reparent real no `Bone` do modelo
    const viewportAttachments = new ViewportAttachments();
    const colliders = new ViewportColliders(scene);

    // Per-frame editor work — the loop itself belongs to RendererCore (AIS-06b)
    const offEditorFrame = core.onFrame(({ dt }) => {
      // Hide editor helpers during play
      gridHelper.visible = !isPlayingRef.current;
      axesHelper.visible = !isPlayingRef.current;
      gizmoHelper.visible = !isPlayingRef.current;

      // Update 3D selection box helper
      for (const box of selectionBoxesRef.current.values()) box.update();

      // AIS-17: bounding box composta (união das caixas dos selecionados visíveis)
      const composite = compositeBoxRef.current;
      if (composite) {
        const union = new THREE.Box3();
        for (const id of selectedGuideNodeIdsRef.current) {
          const obj = objectsMapRef.current.get(id);
          if (obj?.visible) union.union(new THREE.Box3().setFromObject(obj));
        }
        composite.box.copy(union);
        composite.visible = !union.isEmpty();
      }

      // AIS-44c: Play no MESMO canvas — a RuntimeSession (AIS-44b) avança (Behaviors + regras do AIS-44) e o estado vivo é
      // espelhado nos objetos que este renderer já desenha. Pausa = o host não é chamado (o renderer segue desenhando).
      // AIS-46: "Avançar 1 Quadro" — em pausa, cada pedido da barra roda UM quadro de 1/60 s e a sessão segue pausada
      if (isPlayingRef.current) globalInputManager.poll(); // AIS-58: gamepads por polling, uma vez por quadro, antes da simulação
      const stepOne = isPlayingRef.current && isPausedRef.current && takeStepFrameRequest();
      if (isPlayingRef.current && (!isPausedRef.current || stepOne)) {
        const session = getActiveRuntimeSession();
        if (session) stepRuntimeViewportHost({ dt: stepOne ? 1 / 60 : dt, input: globalInputManager, session, objects: objectsMapRef.current, rig, singleStep: stepOne });
        const logicRunner = getLogicRunner();
        const seen = hudRevisionRef.current;
        // AIS-73: Change Scene em jogo troca o snapshot da sessão; o HUD (e os cliques) passam a ser os da cena VIVA, não os da cena aberta no editor
        const liveSnapshot = getActiveRuntimeSession()?.snapshot ?? null;
        const sceneChanged = seen.snapshot !== null && seen.snapshot !== liveSnapshot;
        if (logicRunner && (seen.runner !== logicRunner || seen.revision !== logicRunner.uiRevision || sceneChanged)) {
          hudRevisionRef.current = { runner: logicRunner, revision: logicRunner.uiRevision, snapshot: liveSnapshot };
          // só o HUD é redesenhado (texto/posição/visibilidade vindos do estado vivo); a cena 3D não é tocada
          if (seen.runner !== null || logicRunner.uiRevision > 0 || sceneChanged) {
            hudRef.current?.setNodes(showOverlaysRef.current ? mergeRuntimeHudNodes((liveSnapshot?.nodes as Record<string, any> | undefined) ?? activeSceneRef.current.nodes, getActiveRuntimeSession()?.currentScene ?? null) : {});
          }
        } else if (seen.snapshot === null && liveSnapshot) hudRevisionRef.current = { ...seen, snapshot: liveSnapshot };
      }
      if (isPlayingRef.current) globalInputManager.endFrame(); // justPressed/justReleased valem por um quadro

      // AIS-60: clipes do objeto animado aplicados ao esqueleto do modelo (reset devolve a pose de bind no Stop)
      if (isPlayingRef.current) {
        const animationSession = getActiveRuntimeSession();
        if (animationSession) viewportAnimation.update(animationSession, objectsMapRef.current);
      } else if (viewportAnimation.activeCount > 0 || viewportAnimation.hasScene) viewportAnimation.reset();
      if (isPlayingRef.current) {
        const spriteSession = getActiveRuntimeSession();
        if (spriteSession) viewportSprites.update(spriteSession, objectsMapRef.current);
      } else if (viewportSprites.activeCount > 0 || viewportSprites.hasScene) viewportSprites.reset();
      viewportAttachments.update({ nodes: activeSceneRef.current.nodes, objects: objectsMapRef.current, root: scene, host: isPlayingRef.current ? getActiveRuntimeSession()?.attachments : null, report: (code, message, nodeId) => { if (isPlayingRef.current) getActiveRuntimeSession()?.reportRuntimeProblem('warning', code, message, nodeId); } });
      for (const waterObject of objectsMapRef.current.values()) if (isWaterObject(waterObject)) updateWaterObject(waterObject, dt); // AIS-68: ondulação
      aiHelpers.update({ nodes: activeSceneRef.current.nodes, objects: objectsMapRef.current, selectedIds: selectedGuideNodeIdsRef.current, playing: isPlayingRef.current });
      routeLines.update({ scene: activeSceneRef.current, selectedId: useEditorStore.getState().selectedNodeId, playing: isPlayingRef.current });
      viewportAnimationPreview.update({ nodes: activeSceneRef.current.nodes, selectedId: useEditorStore.getState().selectedNodeId, playing: isPlayingRef.current, objects: objectsMapRef.current, dt });

      // AIS-44e: o que nasce durante o jogo aparece (a rootObject da RuntimeScene entra na cena; o que o espelho já desenha sai pela camada)
      if (isPlayingRef.current) {
        const playSession = getActiveRuntimeSession();
        const runtimeScene = playSession?.currentScene ?? null;
        // AIS-73: Change Scene em jogo — a cena viva não é a aberta: o Viewport a desenha inteira (objetos de edição escondidos)
        const liveForeign = playSession && playSession.snapshot.sceneId !== activeSceneRef.current.id ? playSession.snapshot : null;
        if (liveForeign !== foreignSnapshotRef.current) {
          foreignSnapshotRef.current = liveForeign;
          setForeignSnapshot(liveForeign);
        }
        if (runtimeScene) {
          if (liveForeign) for (const editorObject of objectsMapRef.current.values()) editorObject.visible = false;
          spawnPresenter.mount(runtimeScene, scene, !!liveForeign);
        } else spawnPresenter.unmount();
        if (spawnPresenter.takeChanged()) particles.syncSpawned(spawnPresenter.spawnedInstances());
      } else if (spawnPresenter.mounted) {
        spawnPresenter.unmount();
        particles.syncSpawned([]);
      }
      if (!isPlayingRef.current && foreignSnapshotRef.current) {
        foreignSnapshotRef.current = null;
        setForeignSnapshot(null);
      }

      // AIS-26b: wireframe dos colisores (só leitura; edição e Play)
      colliders.update(showCollidersRef.current, activeSceneRef.current, objectsMapRef.current, dt);

      // AIS-07: smooth zoom + aspect for both projections (after the follow-camera moved the target)
      editorCamera.update(dt, container.clientWidth / Math.max(container.clientHeight, 1));
      // AIS-47: câmera de jogo de um controlador (1ª/3ª pessoa) por cima da orbital — só no Play e só com controlador
      if (isPlayingRef.current) {
        const gameCamera = getActiveRuntimeSession()?.gameCamera;
        if (gameCamera) applyGameCameraPose(editorCamera.camera, gameCamera);
      }

      // AIS-59c: rajadas pedidas pela Action `emit_particles` entram no motor único antes do passo das partículas
      if (isPlayingRef.current && !isPausedRef.current) for (const b of getActiveRuntimeSession()?.takeParticleBursts() ?? []) particles.burst(b.nodeId, b.count);

      particles.update({
        dt,
        playing: isPlayingRef.current,
        paused: isPausedRef.current,
        selectedIds: selectedGuideNodeIdsRef.current,
        camera: editorCamera.camera,
        viewportHeight: container.clientHeight,
        pixelRatio: renderer.getPixelRatio(),
        onSignal: (nodeId, signal) => void getActiveRuntimeSession()?.emitSignal(signal, { source: nodeId, origin: 'particles' }),
      });

      const ruler = metricRulerScale(editorCamera.spherical.radius, container.clientHeight);
      if (rulerLineRef.current) rulerLineRef.current.style.width = `${ruler.pixels}px`;
      if (rulerLabelRef.current) rulerLabelRef.current.textContent = ruler.label;

      const guideCamera = editorCamera.camera;
      guideCamera.updateMatrixWorld(true);
      const guideWorldPosition = new THREE.Vector3();
      for (const nodeId of selectedGuideNodeIdsRef.current) {
        const label = guideLabelRefs.current.get(nodeId);
        const node = activeSceneRef.current.nodes[nodeId];
        const object = objectsMapRef.current.get(nodeId);
        if (!label) continue;
        if (isPlayingRef.current || !node?.visible || !object?.visible) {
          label.style.display = 'none';
          continue;
        }
        object.updateMatrixWorld(true);
        object.getWorldPosition(guideWorldPosition);
        const point = projectWorldPosition(
          guideCamera,
          guideWorldPosition,
          container.clientWidth,
          container.clientHeight
        );
        const onScreen = point.visible && point.x >= 0 && point.x <= container.clientWidth && point.y >= 0 && point.y <= container.clientHeight;
        label.style.display = onScreen ? 'block' : 'none';
        if (onScreen) {
          label.style.left = `${point.x}px`;
          label.style.top = `${point.y}px`;
          label.textContent = `${node.name} · X ${guideWorldPosition.x.toFixed(2)}  Y ${guideWorldPosition.y.toFixed(2)}  Z ${guideWorldPosition.z.toFixed(2)}`;
        }
      }

      // CopperCube Billboards: always face active camera
      const activeCamera = editorCamera.camera;
      // AIS-70: faceMode — `camera` (3 eixos) copia a rotação da câmera; `y-axis` gira só em Y e fica em pé; Hotspot: helper só no editor
      const cameraWorld = activeCamera.getWorldPosition(new THREE.Vector3());
      const objectWorld = new THREE.Vector3();
      scene.traverse((obj) => {
        const faceMode = (obj as any).__faceMode as string | undefined;
        if (faceMode === 'camera') obj.quaternion.copy(activeCamera.quaternion);
        else if (faceMode === 'y-axis') {
          obj.getWorldPosition(objectWorld);
          obj.rotation.set(0, billboardYaw(objectWorld, cameraWorld), 0);
        } else if (isHotspotObject(obj)) setHotspotPlayMode(obj, isPlayingRef.current);
        else if (isWaypointObject(obj)) setWaypointPlayMode(obj, isPlayingRef.current); // AIS-72b: helper só no editor
        else if (isPathObject(obj)) {
          // AIS-72: spline sempre no editor; handles/linhas só com o Path selecionado; no Play, só a spline (se `showInPlay`)
          const pathId = (obj as any).__nodeId as string | undefined;
          applyPathVisibility(obj, { playing: isPlayingRef.current, showInPlay: !!(pathId && activeSceneRef.current.nodes[pathId]?.properties.showInPlay), selected: !!pathId && selectedGuideNodeIdsRef.current.includes(pathId) });
        }
      });
    });

    // Canvas + reactive resize (ResizeObserver + window) + single RAF loop
    core.mount(container);
    const offProbe = registerViewportProbe({ editor: editorCamera, renderer: core.renderer, scene }); // gancho e2e (dev)

    return () => {
      offProbe();
      skyRef.current?.dispose();
      skyRef.current = null;
      offEditorFrame();
      spawnPresenter.unmount();
      viewportAnimation.reset();
      viewportSprites.reset();
      viewportAnimationPreview.dispose();
      routeLines.dispose();
      aiHelpers.disposeAll();
      viewportAttachments.reset({ nodes: activeSceneRef.current.nodes, objects: objectsMapRef.current, root: scene });
      particles.dispose();
      colliders.dispose();
      particlesRef.current = null;
      canvas.removeEventListener('pointermove', handleCanvasPointerMove, { capture: true });
      editorCamera.onViewChange = null;
      core.setOverlayPass(null);
      core.setPostProcess(null);
      postPipeline.dispose();
      postPipelineRef.current = null;
      hud.dispose();
      hudRef.current = null;
      transformControls.dispose();
      scene.remove(groupPivot);
      groupPivotRef.current = null;
      core.dispose();
      coreRef.current = null;
      rendererRef.current = null;
      // AIS-06: a cena é recriada no próximo mount (StrictMode monta→desmonta→remonta em dev).
      // Sem limpar o mapa, o sync acharia os objetos da cena descartada e não os adicionaria à nova.
      for (const obj of objectsMapRef.current.values()) {
        releaseModelNodeObject(obj);
        if (terrainDataOf(obj)) disposeTerrainMesh(obj);
        if (isWaterObject(obj)) disposeWaterObject(obj);
        if (obj.userData.treeSignature) disposeTree(obj);
        if (obj.userData.vegetationSignature) disposeVegetation(obj);
      }
      objectsMapRef.current.clear();
    };
  }, []);

  // Update Three.js objects based on activeScene nodes
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    // Remove obsolete objects
    const currentKeys = new Set(Object.keys(activeScene.nodes));
    for (const [id, obj] of objectsMapRef.current.entries()) {
      if (!currentKeys.has(id)) {
        releaseModelNodeObject(obj); // AIS-33a: modelo sai do cache quando o último nó o solta
        if (terrainDataOf(obj)) disposeTerrainMesh(obj); // AIS-50: geometria/material do terreno
        if (isWaterObject(obj)) disposeWaterObject(obj); // AIS-68: alvo de render do espelho + texturas clonadas
        if (isHotspotObject(obj)) disposeHotspotObject(obj);
        if (isPathObject(obj)) disposePathObject(obj); // AIS-72
        if (isWaypointObject(obj)) disposeWaypointObject(obj); // AIS-72b
        if (obj.userData.treeSignature) disposeTree(obj); // AIS-51a: galhos + folhagem
        if (obj.userData.vegetationSignature) disposeVegetation(obj); // AIS-51d: floresta (InstancedMesh por tile)
        if (transformControlsRef.current?.object === obj) transformControlsRef.current.detach(); // gizmo nunca fica preso a objeto fora da cena
        obj.removeFromParent(); // AIS-19: o objeto pode estar aninhado no pai
        objectsMapRef.current.delete(id);
      }
    }

    // Add or update 3D nodes
    for (const node of Object.values(activeScene.nodes)) {
      if (!node.visible) {
        const existing = objectsMapRef.current.get(node.id);
        if (existing) existing.visible = false;
        continue;
      }

      let threeObj = objectsMapRef.current.get(node.id);

      if (node.type === 'MeshInstance' && isTreeNodeProps(node.properties)) {
        // AIS-51a: a árvore é construída pela MESMA `buildTree` do preview e do Play (galhos do TreeGenerator + folhagem instanciada)
        const treeObj = syncTreeObject(node.properties, threeObj, { files: projectFilesRef.current, pathOf: resourcePathOf });
        if (treeObj !== threeObj) {
          if (threeObj && transformControlsRef.current?.object === threeObj) transformControlsRef.current.detach(); // a árvore antiga saiu da cena
          (treeObj as any).__nodeId = node.id;
          scene.add(treeObj);
          objectsMapRef.current.set(node.id, treeObj);
        }
        threeObj = treeObj;
      } else if (node.type === 'MeshInstance' && modelRefOf(node)) {
        // AIS-33a (decisão 27): o nó desenha o MODELO real (marcador enquanto carrega; vermelho se ausente). `meshType` é ignorado.
        const previousObj = threeObj;
        const modelObj = syncModelNodeObject(node, threeObj, scene);
        // AIS-61b: trocar/mover/perder o arquivo do modelo recria o objeto; o gizmo nunca fica preso ao antigo (já fora da cena)
        if (previousObj && modelObj !== previousObj && transformControlsRef.current?.object === previousObj) transformControlsRef.current.detach();
        if (modelObj) {
          objectsMapRef.current.set(node.id, modelObj);
          threeObj = modelObj;
        }
      } else if (node.type === 'MeshInstance') {
        const meshType = node.properties.meshType || 'CubeMesh';
        // AIS-25: material único do nó = `properties.materialOverride` (chaves planas antigas só são lidas)
        const { material: nodeMaterial, texture: albedo } = materialForRender(node.properties, projectFilesRef.current, node.name, resourcePathOf);
        const materialSignature = JSON.stringify([
          nodeMaterialOverride(node.properties),
          albedo.status,
          albedo.status === 'resolved' ? `${albedo.path}:${albedo.dataUrl?.length ?? 0}` : '',
        ]);

        if (!threeObj || (threeObj as any).__meshType !== meshType) {
          if (threeObj) {
            releaseModelNodeObject(threeObj); // o nó pode ter deixado de usar modelo (Undo)
            threeObj.removeFromParent();
          }

          let geo: THREE.BufferGeometry;
          if (meshType === 'SphereMesh') {
            geo = new THREE.SphereGeometry(0.7, 32, 24);
          } else if (meshType === 'CylinderMesh') {
            geo = new THREE.CylinderGeometry(0.6, 0.6, 1.6, 24);
          } else if (meshType === 'PlaneMesh') {
            geo = new THREE.PlaneGeometry(1, 1);
            geo.rotateX(-Math.PI / 2);
          } else if (meshType === 'TorusMesh') {
            geo = new THREE.TorusGeometry(0.6, 0.25, 16, 32);
          } else {
            geo = new THREE.BoxGeometry(1, 1, 1);
          }

          const mat = createThreeMaterial(nodeMaterial);

          const mesh = new THREE.Mesh(geo, mat);
          mesh.castShadow = true;
          mesh.receiveShadow = true;
          (mesh as any).__meshType = meshType;
          (mesh as any).__materialSignature = materialSignature;
          (mesh as any).__nodeId = node.id;

          scene.add(mesh);
          objectsMapRef.current.set(node.id, mesh);
          threeObj = mesh;
        } else {
          // Update existing material (só recria quando o material do nó mudou)
          const mesh = threeObj as THREE.Mesh;
          if ((mesh as any).__materialSignature !== materialSignature) {
            if (mesh.material) {
              (mesh.material as any).dispose?.();
            }
            mesh.material = createThreeMaterial(nodeMaterial);
            (mesh as any).__materialSignature = materialSignature;
          }
        }
      } else if (node.type === 'Terrain') {
        // AIS-50 (decisão 23): geometria CPU pela fábrica única (a mesma do Play); o buffer fica em `userData.terrain.heights`
        const { mesh } = syncTerrainMesh(threeObj as THREE.Mesh | undefined, node.properties, {
          files: projectFilesRef.current,
          pathOf: resourcePathOf,
        }, terrainEditOverrideFor(node.id)); // AIS-50b: a sessão de escultura manda enquanto existir
        (mesh as any).__nodeId = node.id;
        if (!threeObj) {
          scene.add(mesh);
          objectsMapRef.current.set(node.id, mesh);
          threeObj = mesh;
        }
      } else if (node.type === 'Hotspot') {
        // AIS-70: volume de detecção (forma/tamanho = bloco de física `trigger`); helper só no editor, volume de clique só no Play
        const hotspot = syncHotspotObject(threeObj, node.properties);
        tagHotspotNode(hotspot, node.id);
        if (hotspot !== threeObj) {
          if (threeObj && transformControlsRef.current?.object === threeObj) transformControlsRef.current.detach();
          scene.add(hotspot);
          objectsMapRef.current.set(node.id, hotspot);
          threeObj = hotspot;
        }
      } else if (node.type === 'Waypoint') {
        // AIS-72b: marcador sprite (+ rótulo) só no editor; fábrica única, descarte ao remover o nó
        const waypoint = syncWaypointObject(threeObj, node.properties);
        tagWaypointNode(waypoint, node.id);
        if (waypoint !== threeObj) {
          if (threeObj && transformControlsRef.current?.object === threeObj) transformControlsRef.current.detach();
          scene.add(waypoint);
          objectsMapRef.current.set(node.id, waypoint);
          threeObj = waypoint;
        }
      } else if (node.type === 'Path') {
        // AIS-72: spline + linhas + handles (fábrica única); a visibilidade de edição/Play é aplicada por quadro
        const path = syncPathObject(threeObj, node.properties);
        tagPathNode(path, node.id);
        if (path !== threeObj) {
          if (threeObj && transformControlsRef.current?.object === threeObj) transformControlsRef.current.detach();
          scene.add(path);
          objectsMapRef.current.set(node.id, path);
          threeObj = path;
        }
      } else if (node.type === 'WaterPlane') {
        // AIS-68: a mesma fábrica do runtime; troca de modo/tamanho recria só a superfície, o resto é em lugar
        const water = syncWaterObject(threeObj, node.properties);
        tagWaterNode(water, node.id);
        if (water !== threeObj) {
          if (threeObj && transformControlsRef.current?.object === threeObj) transformControlsRef.current.detach();
          scene.add(water);
          objectsMapRef.current.set(node.id, water);
          threeObj = water;
        }
      } else if (node.type === 'Vegetation') {
        // AIS-51d: floresta = N árvores por InstancedMesh sobre o buffer de alturas do Terrain PAI (decisão 23); sem terreno pai, grupo vazio
        const parent = node.parentId ? activeScene.nodes[node.parentId] : undefined;
        const terrain = parent?.type === 'Terrain'
          ? { properties: parent.properties, ctx: { files: projectFilesRef.current, pathOf: resourcePathOf }, override: terrainEditOverrideFor(parent.id) }
          : null;
        const vegObj = syncVegetationObject(node.properties, threeObj, terrain);
        if (vegObj !== threeObj) {
          if (threeObj && transformControlsRef.current?.object === threeObj) transformControlsRef.current.detach();
          (vegObj as any).__nodeId = node.id;
          scene.add(vegObj);
          objectsMapRef.current.set(node.id, vegObj);
        }
        threeObj = vegObj;
      } else if (node.type === 'Billboard') {
        // CopperCube / Godot 3D Billboard Sprite: camera-facing quad
        if (!threeObj) {
          const width = node.properties.width || 1.5;
          const height = node.properties.height || 2.0;
          const geo = new THREE.PlaneGeometry(width, height);
          const col = node.properties.color || { r: 1, g: 1, b: 1, a: 1 };
          const mat = new THREE.MeshBasicMaterial({
            color: toThreeColor(col, 0xffffff),
            side: THREE.DoubleSide,
            transparent: true,
            opacity: col.a ?? 1,
            alphaTest: 0.1,
          });

          // textura legada (data URL no nó, sem Sprite Project); o sprite referenciado é desenhado pelo BillboardSpriteView (AIS-76)
          const spriteUrl = !node.properties.spriteProject && typeof node.properties.texture === 'string' && node.properties.texture.startsWith('data:') ? node.properties.texture : null;
          if (spriteUrl) {
            const loader = new THREE.TextureLoader();
            loader.load(spriteUrl, (tex) => {
              tex.magFilter = THREE.NearestFilter;
              tex.minFilter = THREE.NearestFilter;
              mat.map = tex;
              mat.needsUpdate = true;
            });
          }

          const billboardMesh = new THREE.Mesh(geo, mat);
          (billboardMesh as any).__faceMode = readFaceMode(node.properties);
          (billboardMesh as any).__isBillboard = (billboardMesh as any).__faceMode !== 'none';
          (billboardMesh as any).__nodeId = node.id;

          // Add subtle border marker
          const wire = new THREE.LineSegments(
            new THREE.EdgesGeometry(geo),
            new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.35 })
          );
          billboardMesh.add(wire);

          scene.add(billboardMesh);
          objectsMapRef.current.set(node.id, billboardMesh);
          threeObj = billboardMesh;
          spriteViewOf(billboardMesh, spriteEnv).sync(node.properties); // AIS-76: região do atlas do frame ativo
        } else {
          // Update existing billboard
          (threeObj as any).__faceMode = readFaceMode(node.properties);
          (threeObj as any).__isBillboard = (threeObj as any).__faceMode !== 'none';
          const mesh = threeObj as THREE.Mesh;
          spriteViewOf(mesh, spriteEnv).sync(node.properties); // AIS-76: nome/animação/frame/flip/centered/offset e o recurso referenciado
        }
      } else if (node.type === 'DirectionalLight') {
        if (!threeObj) {
          const group = new THREE.Group();
          (group as any).__nodeId = node.id;

          // 1. DirectionalLight with target positioned at (0, 0, -5) so rotation redirects the light beam
          const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
          dirLight.castShadow = node.properties.castShadow !== false;
          // Shadow frustum defaults (AIS-06: PCFSoftShadowMap orthographic)
          {
            const frustum = node.properties.shadowFrustum ?? 15;
            const shadowCam = dirLight.shadow.camera as THREE.OrthographicCamera;
            shadowCam.left = -frustum;
            shadowCam.right = frustum;
            shadowCam.top = frustum;
            shadowCam.bottom = -frustum;
            shadowCam.near = node.properties.shadowNear ?? 0.5;
            shadowCam.far = node.properties.shadowFar ?? 100;
            shadowCam.updateProjectionMatrix();
            dirLight.shadow.bias = node.properties.shadowBias ?? -0.0005;
            dirLight.shadow.normalBias = node.properties.shadowNormalBias ?? 0.02;
            dirLight.shadow.mapSize.setScalar(node.properties.shadowMapSize ?? 2048);
          }
          const targetObj = new THREE.Object3D();
          targetObj.position.set(0, 0, -5);
          group.add(targetObj);
          dirLight.target = targetObj;
          group.add(dirLight);

          // 2. Billboard icon sprite (Appearance)
          const iconSprite = createNodeIconSprite('DirectionalLight');
          (iconSprite as any).__nodeId = node.id;
          group.add(iconSprite);

          // 3. Wireframe (Aramado) representing direction and parallel light rays along -Z
          const wireGroup = new THREE.Group();
          const wireMat = new THREE.LineBasicMaterial({ color: 0xfbbf24, transparent: true, opacity: 0.85 });

          // Base ring at z = 0
          const circleGeo = new THREE.BufferGeometry();
          const cPoints: THREE.Vector3[] = [];
          for (let i = 0; i <= 32; i++) {
            const th = (i / 32) * Math.PI * 2;
            cPoints.push(new THREE.Vector3(Math.cos(th) * 0.75, Math.sin(th) * 0.75, 0));
          }
          circleGeo.setFromPoints(cPoints);
          wireGroup.add(new THREE.Line(circleGeo, wireMat));

          // Center arrow & parallel beam rays pointing along -Z
          const rayPoints: THREE.Vector3[] = [
            // Center main direction ray with arrow tip
            new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 0, -3.0),
            new THREE.Vector3(0, 0, -3.0), new THREE.Vector3(0.2, 0, -2.7),
            new THREE.Vector3(0, 0, -3.0), new THREE.Vector3(-0.2, 0, -2.7),
            new THREE.Vector3(0, 0, -3.0), new THREE.Vector3(0, 0.2, -2.7),
            new THREE.Vector3(0, 0, -3.0), new THREE.Vector3(0, -0.2, -2.7),
            // 4 Parallel beam rays showing light cylinder
            new THREE.Vector3(0.75, 0, 0), new THREE.Vector3(0.75, 0, -2.6),
            new THREE.Vector3(0.75, 0, -2.6), new THREE.Vector3(0.85, 0, -2.4),
            new THREE.Vector3(-0.75, 0, 0), new THREE.Vector3(-0.75, 0, -2.6),
            new THREE.Vector3(-0.75, 0, -2.6), new THREE.Vector3(-0.85, 0, -2.4),
            new THREE.Vector3(0, 0.75, 0), new THREE.Vector3(0, 0.75, -2.6),
            new THREE.Vector3(0, 0.75, -2.6), new THREE.Vector3(0, 0.85, -2.4),
            new THREE.Vector3(0, -0.75, 0), new THREE.Vector3(0, -0.75, -2.6),
            new THREE.Vector3(0, -0.75, -2.6), new THREE.Vector3(0, -0.85, -2.4),
          ];
          const raysGeo = new THREE.BufferGeometry().setFromPoints(rayPoints);
          wireGroup.add(new THREE.LineSegments(raysGeo, wireMat));
          group.add(wireGroup);

          scene.add(group);
          objectsMapRef.current.set(node.id, group);
          threeObj = group;
        }
        const col = node.properties.lightColor || { r: 1, g: 1, b: 1 };
        const light = (threeObj as THREE.Group).children.find((c) => c instanceof THREE.DirectionalLight) as THREE.DirectionalLight;
        if (light) {
          light.color.copy(toThreeColor(col, 0xffffff));
          light.intensity = node.properties.energy || 1.2;
          light.castShadow = node.properties.castShadow !== false;
        }
      } else if (node.type === 'OmniLight') {
        if (!threeObj) {
          const group = new THREE.Group();
          (group as any).__nodeId = node.id;

          const range = node.properties.range || 6;
          const point = new THREE.PointLight(0xffaa44, 2, range);
          group.add(point);

          // 1. Billboard icon (Appearance)
          const iconSprite = createNodeIconSprite('OmniLight');
          (iconSprite as any).__nodeId = node.id;
          group.add(iconSprite);

          // 2. Wireframe (Aramado) representing the spherical light radius / attenuation
          const wireMat = new THREE.LineBasicMaterial({ color: 0xf97316, transparent: true, opacity: 0.55 });
          const rPoints: THREE.Vector3[] = [];
          const segs = 32;
          for (let i = 0; i < segs; i++) {
            const t1 = (i / segs) * Math.PI * 2;
            const t2 = ((i + 1) / segs) * Math.PI * 2;
            // XY circle
            rPoints.push(new THREE.Vector3(Math.cos(t1) * range, Math.sin(t1) * range, 0));
            rPoints.push(new THREE.Vector3(Math.cos(t2) * range, Math.sin(t2) * range, 0));
            // XZ circle
            rPoints.push(new THREE.Vector3(Math.cos(t1) * range, 0, Math.sin(t1) * range));
            rPoints.push(new THREE.Vector3(Math.cos(t2) * range, 0, Math.sin(t2) * range));
            // YZ circle
            rPoints.push(new THREE.Vector3(0, Math.cos(t1) * range, Math.sin(t1) * range));
            rPoints.push(new THREE.Vector3(0, Math.cos(t2) * range, Math.sin(t2) * range));
          }
          const rGeo = new THREE.BufferGeometry().setFromPoints(rPoints);
          group.add(new THREE.LineSegments(rGeo, wireMat));

          scene.add(group);
          objectsMapRef.current.set(node.id, group);
          threeObj = group;
        }
        const col = node.properties.lightColor || { r: 1, g: 0.8, b: 0.4 };
        const light = (threeObj as THREE.Group).children.find((c) => c instanceof THREE.PointLight) as THREE.PointLight;
        if (light) {
          light.color.copy(toThreeColor(col, 0xffcc66));
          light.intensity = node.properties.energy || 2.0;
        }
      } else if (node.type === 'Camera') {
        if (!threeObj) {
          const camGroup = new THREE.Group();
          (camGroup as any).__nodeId = node.id;

          // 1. Billboard icon (Appearance)
          const iconSprite = createNodeIconSprite('Camera');
          (iconSprite as any).__nodeId = node.id;
          camGroup.add(iconSprite);

          // 2. Wireframe Frustum (Aramado) pointing strictly forward down -Z (Camera view axis)
          const wireMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.85 });
          const frustumPoints: THREE.Vector3[] = [
            // 4 Rays from apex (0, 0, 0) forward to the view rectangle at z = -2.2
            new THREE.Vector3(0, 0, 0), new THREE.Vector3(0.9, 0.55, -2.2),
            new THREE.Vector3(0, 0, 0), new THREE.Vector3(-0.9, 0.55, -2.2),
            new THREE.Vector3(0, 0, 0), new THREE.Vector3(-0.9, -0.55, -2.2),
            new THREE.Vector3(0, 0, 0), new THREE.Vector3(0.9, -0.55, -2.2),
            // View rectangle connecting the 4 corners at z = -2.2
            new THREE.Vector3(0.9, 0.55, -2.2), new THREE.Vector3(-0.9, 0.55, -2.2),
            new THREE.Vector3(-0.9, 0.55, -2.2), new THREE.Vector3(-0.9, -0.55, -2.2),
            new THREE.Vector3(-0.9, -0.55, -2.2), new THREE.Vector3(0.9, -0.55, -2.2),
            new THREE.Vector3(0.9, -0.55, -2.2), new THREE.Vector3(0.9, 0.55, -2.2),
            // Top orientation indicator triangle (points UP on the camera)
            new THREE.Vector3(-0.35, 0.55, -2.2), new THREE.Vector3(0, 0.85, -2.2),
            new THREE.Vector3(0, 0.85, -2.2), new THREE.Vector3(0.35, 0.55, -2.2),
          ];
          const frustumGeo = new THREE.BufferGeometry().setFromPoints(frustumPoints);
          camGroup.add(new THREE.LineSegments(frustumGeo, wireMat));

          scene.add(camGroup);
          objectsMapRef.current.set(node.id, camGroup);
          threeObj = camGroup;
        }
      } else if (node.type === 'Spatial' || node.type === 'Node') {
        if (!threeObj) {
          const group = new THREE.Group();
          (group as any).__nodeId = node.id;

          // 1. Billboard icon (Appearance)
          const iconSprite = createNodeIconSprite(node.type === 'Spatial' ? 'Spatial' : 'Node');
          (iconSprite as any).__nodeId = node.id;
          group.add(iconSprite);

          // 2. Mini coordinate axes
          const axes = new THREE.AxesHelper(0.8);
          group.add(axes);

          scene.add(group);
          objectsMapRef.current.set(node.id, group);
          threeObj = group;
        }
      } else if (node.type === 'SpotLight') {
        if (!threeObj) {
          const group = new THREE.Group();
          (group as any).__nodeId = node.id;

          const range = node.properties.range || 8;
          const angleDeg = node.properties.angle || 30;
          const angleRad = THREE.MathUtils.degToRad(angleDeg);

          // 1. Three.js SpotLight with target at (0, 0, -5) so rotation redirects the spot
          const spot = new THREE.SpotLight(0xffffff, 2.5, range, angleRad, 0.3);
          const targetObj = new THREE.Object3D();
          targetObj.position.set(0, 0, -5);
          group.add(targetObj);
          spot.target = targetObj;
          group.add(spot);

          // 2. Billboard icon (Appearance)
          const iconSprite = createNodeIconSprite('SpotLight');
          (iconSprite as any).__nodeId = node.id;
          group.add(iconSprite);

          // 3. Wireframe Cone (Aramado) showing direction and cone radius/angle
          const wireMat = new THREE.LineBasicMaterial({ color: 0xfde047, transparent: true, opacity: 0.85 });
          const baseR = range * Math.tan(angleRad);
          const conePoints: THREE.Vector3[] = [
            // 4 Edge lines from (0, 0, 0) forward to base at z = -range
            new THREE.Vector3(0, 0, 0), new THREE.Vector3(baseR, 0, -range),
            new THREE.Vector3(0, 0, 0), new THREE.Vector3(-baseR, 0, -range),
            new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, baseR, -range),
            new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, -baseR, -range),
          ];
          // Base circle at z = -range
          for (let i = 0; i < 32; i++) {
            const t1 = (i / 32) * Math.PI * 2;
            const t2 = ((i + 1) / 32) * Math.PI * 2;
            conePoints.push(
              new THREE.Vector3(Math.cos(t1) * baseR, Math.sin(t1) * baseR, -range),
              new THREE.Vector3(Math.cos(t2) * baseR, Math.sin(t2) * baseR, -range)
            );
          }
          const coneGeo = new THREE.BufferGeometry().setFromPoints(conePoints);
          group.add(new THREE.LineSegments(coneGeo, wireMat));

          scene.add(group);
          objectsMapRef.current.set(node.id, group);
          threeObj = group;
        }
        const col = node.properties.lightColor || { r: 1, g: 1, b: 1 };
        const light = (threeObj as THREE.Group).children.find((c) => c instanceof THREE.SpotLight) as THREE.SpotLight;
        if (light) {
          light.color.copy(toThreeColor(col, 0xffffff));
          light.intensity = node.properties.energy || 2.5;
        }
      } else if (node.type === 'AudioPlayer3D') {
        if (!threeObj) {
          const group = new THREE.Group();
          (group as any).__nodeId = node.id;

          // 1. Billboard icon (Appearance)
          const iconSprite = createNodeIconSprite('AudioPlayer3D');
          (iconSprite as any).__nodeId = node.id;
          group.add(iconSprite);

          // 2. Wireframe (Aramado) showing audio radius / max distance
          const maxDist = node.properties.maxDistance || 5;
          const wireMat = new THREE.LineBasicMaterial({ color: 0xec4899, transparent: true, opacity: 0.6 });
          const aPoints: THREE.Vector3[] = [];
          for (let i = 0; i < 32; i++) {
            const t1 = (i / 32) * Math.PI * 2;
            const t2 = ((i + 1) / 32) * Math.PI * 2;
            aPoints.push(new THREE.Vector3(Math.cos(t1) * maxDist, 0, Math.sin(t1) * maxDist));
            aPoints.push(new THREE.Vector3(Math.cos(t2) * maxDist, 0, Math.sin(t2) * maxDist));
          }
          const aGeo = new THREE.BufferGeometry().setFromPoints(aPoints);
          group.add(new THREE.LineSegments(aGeo, wireMat));

          scene.add(group);
          objectsMapRef.current.set(node.id, group);
          threeObj = group;
        }
      } else if (node.type === 'ParticleSystem') {
        if (!threeObj) {
          const group = new THREE.Group();
          (group as any).__nodeId = node.id;
          const iconSprite = createNodeIconSprite('ParticleSystem');
          (iconSprite as any).__nodeId = node.id;
          group.add(iconSprite);
          scene.add(group);
          objectsMapRef.current.set(node.id, group);
          threeObj = group;
        }
      } else if (node.type === 'Environment') {
        if (!threeObj) {
          const group = new THREE.Group();
          (group as any).__nodeId = node.id;
          const iconSprite = createNodeIconSprite('Environment');
          (iconSprite as any).__nodeId = node.id;
          group.add(iconSprite);
          scene.add(group);
          objectsMapRef.current.set(node.id, group);
          threeObj = group;
        }
      }

      // Update 3D transforms
      if (threeObj) {
        threeObj.visible = node.visible;
        const pos = node.properties.position || { x: 0, y: 0, z: 0 };
        const rot = node.properties.rotation || { x: 0, y: 0, z: 0 };
        const scale = node.properties.scale || { x: 1, y: 1, z: 1 };

        threeObj.position.set(pos.x, pos.y, pos.z);
        if (!(threeObj as any).__isBillboard) {
          threeObj.rotation.set(
            THREE.MathUtils.degToRad(rot.x),
            THREE.MathUtils.degToRad(rot.y),
            THREE.MathUtils.degToRad(rot.z)
          );
        }
        threeObj.scale.set(scale.x, scale.y, scale.z);
      }
    }

    // AIS-19: a hierarquia Three segue a hierarquia autoral — o filho herda mover/girar/escalar do pai.
    // As propriedades position/rotation/scale são locais ao pai; `add` mantém o transform local.
    for (const node of Object.values(activeScene.nodes)) {
      const obj = objectsMapRef.current.get(node.id);
      if (!obj) continue;
      let parent: THREE.Object3D = scene;
      const seen = new Set<string>([node.id]);
      for (let pid = node.parentId; pid && !seen.has(pid); pid = activeScene.nodes[pid]?.parentId ?? null) {
        seen.add(pid);
        const parentObj = objectsMapRef.current.get(pid);
        if (parentObj) {
          parent = parentObj;
          break;
        }
      }
      if (obj.parent !== parent) parent.add(obj);
    }

    // AIS-18c: cria/atualiza/descarta os sistemas de partículas sobre os grupos recém-sincronizados
    particlesRef.current?.sync(activeScene, objectsMapRef.current);
  }, [activeScene, texturesSignature, spritesSignature, modelsVersion, terrainVersion]);

  // AIS-25b: overlays desenhados pelo UIKit — nós, visibilidade da camada e texturas do projeto
  useEffect(() => {
    const hud = hudRef.current;
    if (!hud) return;
    hud.setTextureResolver((path) => {
      const content = projectFilesRef.current[path]?.content;
      return typeof content === 'string' && content.startsWith('data:image') ? content : null;
    });
    hud.setNodes(showOverlaysHUD ? activeScene.nodes : {});
  }, [activeScene, showOverlaysHUD, texturesSignature]);

  // AIS-73: ao parar o Play o HUD volta aos nós da cena aberta (o Play pode ter trocado de cena, e `activeScene` pode manter a identidade)
  useEffect(() => {
    if (!isPlaying) hudRef.current?.setNodes(showOverlaysRef.current ? activeSceneRef.current.nodes : {});
  }, [isPlaying]);

  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const update = () => setStageSize({ width: el.clientWidth, height: el.clientHeight });
    update();
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(update) : null;
    observer?.observe(el);
    return () => observer?.disconnect();
  }, []);

  // AIS-25b: tamanho da viewport (mesmo retângulo do canvas) para calcular os retângulos dos overlays
  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;
    const update = () => setViewportSize({ width: el.clientWidth, height: el.clientHeight });
    update();
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(update) : null;
    observer?.observe(el);
    window.addEventListener('resize', update);
    return () => {
      observer?.disconnect();
      window.removeEventListener('resize', update);
    };
  }, []);

  // AIS-06: Apply environment from canonical Environment GameNode (authority)
  // fallback to legacy scene.environment / scene.fog for backward compatibility
  useEffect(() => {
    const scene = sceneRef.current;
    const renderer = rendererRef.current;
    const ambientLight = ambientLightRef.current;
    if (!scene || !renderer || !ambientLight) return;

    // Canonical Environment GameNode (0..1 per scene)
    // AIS-73: depois de um Change Scene em jogo o ambiente (céu, ambiente, névoa) é o da cena VIVA, não o da cena aberta no editor
    const envSource = foreignSnapshot
      ? { nodes: foreignSnapshot.nodes as unknown as Record<string, GameNode>, environmentNodeId: foreignSnapshot.environmentNodeId ?? undefined, environment: undefined, fog: undefined }
      : activeScene;
    const envNodeId = envSource.environmentNodeId
      || Object.values(envSource.nodes).find((n) => n.type === 'Environment')?.id;
    const envNode = envNodeId ? envSource.nodes[envNodeId] : undefined;
    const fallbackEnv = envSource.environment;
    const fallbackFog = envSource.fog;

    // AIS-44d: no PLAY o projeto (via resolveRenderSettings, única leitora) refina o que o Environment da Scene define;
    // em Edit nada muda. O Environment continua dono do ambiente (decisão 17): realtimeShadows entra por AND.
    const envRealtime = envNode && envNode.visible ? envNode.properties.realtimeShadows !== false : fallbackEnv ? fallbackEnv.realtimeShadows !== false : true;
    const playSettings = isPlaying ? resolveRenderSettings(project.settings, { realtimeShadows: envRealtime }) : null;
    let definesOwnBackground = false;

    if (envNode && envNode.visible) {
      const p = envNode.properties;
      definesOwnBackground = (p.backgroundMode ?? 'Color') !== 'Color' || p.backgroundColor != null;

      // 1. Ambient Light
      const ambColor = toThreeColor(p.ambientColor, '#8099c0');
      ambientLight.color.copy(ambColor);
      ambientLight.intensity = typeof p.ambientIntensity === 'number' ? p.ambientIntensity : 0.45;

      // 2. Fundo: cor sólida ou céu (Gradient / Procedural / HDRI) pelo controlador único (Viewport e Play)
      const sky = readSkySettings(p);
      if (sky.mode === 'Color') {
        skyRef.current?.clear();
        const bgColor = toThreeColor(p.backgroundColor, '#141822');
        scene.background = bgColor;
      } else {
        skyRef.current?.apply(sky);
        // HDRI ainda carregando (ou id desconhecido): cor sólida até o céu chegar
        if (!scene.background) scene.background = toThreeColor(p.backgroundColor, '#141822');
      }

      // 3. Realtime Shadows toggle
      renderer.shadowMap.enabled = playSettings ? playSettings.shadows.enabled : p.realtimeShadows !== false;

      // 4. Tone Mapping (ACESFilmic active; further options pending Post-Processing pipeline)
      if (p.tonemapping === 'None') {
        renderer.toneMapping = THREE.NoToneMapping;
      } else {
        // AIS-44d: `rendering.hdr` troca o tone mapping do PLAY (AgX); o render target HDR do composer é do AIS-55
        renderer.toneMapping = playSettings?.hdr ? THREE.AgXToneMapping : THREE.ACESFilmicToneMapping;
      }
      renderer.toneMappingExposure = typeof p.tonemappingExposure === 'number' ? p.tonemappingExposure : 1.0;

      // 5. Atmospheric Fog
      if (p.fogEnabled) {
        const fogColor = toThreeColor(p.fogColor, '#8fa4b8');
        if (p.fogMode === 'linear') {
          scene.fog = new THREE.Fog(fogColor.getHex(), p.fogNear ?? 15, p.fogFar ?? 180);
          setGroundFog(0, 0);
        } else {
          scene.fog = new THREE.FogExp2(fogColor.getHex(), p.fogDensity ?? 0.008);
          // AIS-54: modo 'height' = névoa exponencial que se dissipa com a altitude (Ground Fog)
          if (p.fogMode === 'height') setGroundFog(p.fogHeight ?? 12, p.fogHeightFalloff ?? 0.6);
          else setGroundFog(0, 0);
        }
      } else {
        scene.fog = null;
        setGroundFog(0, 0);
      }
    } else if (fallbackEnv) {
      // Legacy fallback — no new features added here, transitional compat only
      definesOwnBackground = fallbackEnv.backgroundColor != null;
      const ambColor = toThreeColor(fallbackEnv.ambientColor, '#334155');
      ambientLight.color.copy(ambColor);
      ambientLight.intensity = typeof fallbackEnv.ambientIntensity === 'number' ? fallbackEnv.ambientIntensity : 0.45;

      const bgColor = toThreeColor(fallbackEnv.backgroundColor, '#141822');
      scene.background = bgColor;

      renderer.shadowMap.enabled = playSettings ? playSettings.shadows.enabled : fallbackEnv.realtimeShadows !== false;
      if (playSettings?.hdr) renderer.toneMapping = THREE.AgXToneMapping;
      else if (renderer.toneMapping === THREE.AgXToneMapping) renderer.toneMapping = THREE.ACESFilmicToneMapping; // Stop devolve o padrão

      if (fallbackFog && fallbackFog.enabled) {
        const fogColor = toThreeColor(fallbackFog.color, '#8fa4b8');
        if (fallbackFog.mode === 'linear') {
          scene.fog = new THREE.Fog(fogColor.getHex(), fallbackFog.near ?? 15, fallbackFog.far ?? 180);
          setGroundFog(0, 0);
        } else {
          scene.fog = new THREE.FogExp2(fogColor.getHex(), fallbackFog.density ?? 0.008);
          if (fallbackFog.mode === 'height') setGroundFog(fallbackFog.height ?? 12, fallbackFog.heightFalloff ?? 0.6);
          else setGroundFog(0, 0);
        }
      } else {
        scene.fog = null;
        setGroundFog(0, 0);
      }
    }

    // sem Environment ativo: nenhum céu
    if (!envNode || !envNode.visible) skyRef.current?.clear();

    // AIS-54-C07: excluir o nó Environment retorna a cena ao estado padrão de ambiente do schema (sem nevoeiro, iluminação padrão, etc.)
    if (!envNode && !fallbackEnv) {
      const envDefaults = NODE_REGISTRY.Environment.defaultProperties;
      ambientLight.color.copy(toThreeColor(envDefaults.ambientColor, '#8099c0'));
      ambientLight.intensity = envDefaults.ambientIntensity ?? 0.45;
      scene.fog = null;
      setGroundFog(0, 0);
    }

    // AIS-44d: sem Environment (ou sem fundo próprio nele) o Play usa o `clearColor` do projeto; em Edit, o fundo histórico
    if (!definesOwnBackground) {
      scene.background = new THREE.Color(playSettings ? playSettings.clearColor : '#141822');
      if (!envNode && !fallbackEnv) {
        renderer.shadowMap.enabled = playSettings ? playSettings.shadows.enabled : true;
        renderer.toneMapping = playSettings?.hdr ? THREE.AgXToneMapping : THREE.ACESFilmicToneMapping;
      }
    }

    // 6. Sync DirectionalLight shadow frustum from node properties (castShadow, frustum, bias)
    for (const node of Object.values(activeScene.nodes)) {
      if (node.type !== 'DirectionalLight') continue;
      const obj = objectsMapRef.current.get(node.id);
      if (!obj) continue;
      const dirLight = (obj as THREE.Group).children.find((c) => c instanceof THREE.DirectionalLight) as THREE.DirectionalLight | undefined;
      if (!dirLight) continue;

      const castShadow = node.properties.castShadow !== false;
      dirLight.castShadow = castShadow && renderer.shadowMap.enabled;
      if (dirLight.shadow) {
        const frustum = node.properties.shadowFrustum ?? 15;
        const cam = dirLight.shadow.camera as THREE.OrthographicCamera;
        cam.left = -frustum;
        cam.right = frustum;
        cam.top = frustum;
        cam.bottom = -frustum;
        cam.near = node.properties.shadowNear ?? 0.5;
        cam.far = node.properties.shadowFar ?? 100;
        cam.updateProjectionMatrix();
        dirLight.shadow.bias = node.properties.shadowBias ?? -0.0005;
        dirLight.shadow.normalBias = node.properties.shadowNormalBias ?? 0.02;
        // AIS-44d: o `shadowMapSize` do nó continua vencendo; sem ele, o Play usa `shadowQuality` e a Edição os 2048 de sempre
        const mapSize = effectiveShadowMapSize(node.properties.shadowMapSize, playSettings?.shadows.mapSize);
        if (dirLight.shadow.mapSize.x !== mapSize) {
          dirLight.shadow.mapSize.setScalar(mapSize);
          dirLight.shadow.map?.dispose(); // o shadow map só é recriado com o novo lado depois de descartado
          dirLight.shadow.map = null;
        }
      }
    }
  }, [activeScene.nodes, activeScene.environmentNodeId, activeScene.environment, activeScene.fog, isPlaying, project.settings, skyVersion, foreignSnapshot]);

  // AIS-55: Emenda v5.7 — hdr/msaa do projeto definem o render target do composer no Play; no editor: HDR + 4x
  useEffect(() => {
    const post = postPipelineRef.current;
    if (!post) return;
    post.setSettings(activeScene.postProcessing);
    const rs = isPlaying ? resolveRenderSettings(project.settings) : null;
    post.setTarget({ hdr: rs ? rs.hdr : true, samples: rs ? rs.msaa.samples : 4 });
  }, [activeScene.postProcessing, isPlaying, project.settings]);

  const manipulationMode = useEditorStore((s) => s.manipulationMode);
  const setManipulationMode = useEditorStore((s) => s.setManipulationMode);

  // Synchronize activeTool with manipulationMode from Zustand store (AIS-04)
  useEffect(() => {
    if (manipulationMode === 'translate') setActiveTool('move');
    else if (manipulationMode === 'rotate') setActiveTool('rotate');
    else if (manipulationMode === 'scale') setActiveTool('scale');
  }, [manipulationMode]);

  // Synchronize TransformControls mode with activeTool
  useEffect(() => {
    if (!transformControlsRef.current) return;
    if (activeTool === 'move') {
      transformControlsRef.current.setMode('translate');
    } else if (activeTool === 'rotate') {
      transformControlsRef.current.setMode('rotate');
    } else if (activeTool === 'scale') {
      transformControlsRef.current.setMode('scale');
    }
  }, [activeTool]);

  // AIS-04: Frame Selected camera listener (F shortcut)
  useEffect(() => {
    const handleFrameSelected = (e: Event) => {
      const customEvent = e as CustomEvent<{ nodeId?: string; nodeIds?: string[] }>;
      const targetId = customEvent.detail?.nodeId || selectedNodeId;
      const editorCamera = editorCameraRef.current;
      if (!targetId || !editorCamera) return;

      const nodeIds = customEvent.detail?.nodeIds ?? selectedGuideNodeIds;
      const objects = [...new Set([targetId, ...nodeIds])]
        .map((nodeId) => objectsMapRef.current.get(nodeId))
        .filter((object): object is THREE.Object3D => Boolean(object?.visible));
      const bounds = boundingSphereForObjects(objects);
      if (!bounds) return;

      // AIS-07: through the controller (keeps the current orbit angle; works in both projections)
      editorCamera.frame(bounds.center, frameDistanceForSphere(bounds.radius, editorCamera.perspective.fov));
    };

    window.addEventListener('nodimus:frame-selected', handleFrameSelected);
    return () => window.removeEventListener('nodimus:frame-selected', handleFrameSelected);
  }, [selectedNodeId, selectedGuideNodeIds]);

  // AIS-09: grid / angle snapping of the gizmo follow the precision toolbar (EditorStore).
  // The "Snap 8px" button only drives the 2D overlay layer.
  useEffect(() => {
    const tc = transformControlsRef.current;
    if (!tc) return;
    const snap = gizmoSnapValues(viewportSnap);
    tc.setTranslationSnap(snap.translation);
    tc.setRotationSnap(snap.rotation);
    tc.setScaleSnap(snap.scale);
  }, [viewportSnap]);

  // Keyboard shortcuts W (move), E (rotate), R (scale) and Escape (deselect)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;
      // AIS-07: editor camera views — Ctrl/Cmd+0 or +1 Persp · +2 Top · +3 Front · +4 Right
      const viewPreset = viewPresetForShortcut(e);
      if (viewPreset) {
        e.preventDefault();
        if (!isPlayingRef.current) editorCameraRef.current?.setView(viewPreset);
        return;
      }
      // AIS-40b: em Play as teclas são do JOGO (W é MoveForward): W/E/R/Escape do editor não valem
      if (isPlayingRef.current) return;
      if (e.ctrlKey || e.metaKey) return; // W/E/R are bare keys; never steal Ctrl/Cmd combos
      // AIS-50b: no modo terreno W/E/R ficam bloqueados; o Esc (sai do modo) é tratado em `useDesktopShortcuts`
      if (isBrushMode(useEditorStore.getState().manipulationMode)) return;
      if (e.key === 'Escape') {
        selectNode(null);
      } else if (e.key === 'w' || e.key === 'W') {
        setActiveTool('move');
        setManipulationMode('translate');
      } else if (e.key === 'e' || e.key === 'E') {
        setActiveTool('rotate');
        setManipulationMode('rotate');
      } else if (e.key === 'r' || e.key === 'R') {
        setActiveTool('scale');
        setManipulationMode('scale');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectNode, setManipulationMode]);

  // Synchronize selection boxes and the primary TransformControls target.
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    for (const box of selectionBoxesRef.current.values()) {
      scene.remove(box);
      box.dispose();
    }
    selectionBoxesRef.current.clear();
    if (compositeBoxRef.current) {
      scene.remove(compositeBoxRef.current);
      compositeBoxRef.current.dispose();
      compositeBoxRef.current = null;
    }

    const tc = transformControlsRef.current;
    const selectedIds = [...new Set([...(selectedNodeId ? [selectedNodeId] : []), ...multiSelectedNodeIds])];

    // AIS-50b: modo terreno = gizmo oculto e bloqueado
    if (!selectedIds.length || isPlaying || isBrushMode(manipulationMode)) {
      if (tc) tc.detach();
      if (!selectedIds.length || isPlaying) return;
    }

    for (const nodeId of selectedIds) {
      const selectedObj = objectsMapRef.current.get(nodeId);
      if (!selectedObj?.visible) continue;
      try {
        const box = new THREE.BoxHelper(selectedObj, 0xff8c00);
        (box.material as THREE.LineBasicMaterial).depthTest = false;
        (box.material as THREE.LineBasicMaterial).transparent = true;
        (box.material as THREE.LineBasicMaterial).opacity = 0.95;
        scene.add(box);
        selectionBoxesRef.current.set(nodeId, box);
      } catch {
        // If box helper cannot be computed, ignore
      }
    }

    if (selectedIds.length > 1) {
      const composite = new THREE.Box3Helper(new THREE.Box3(), 0xffffff);
      (composite.material as THREE.LineBasicMaterial).depthTest = false;
      (composite.material as THREE.LineBasicMaterial).transparent = true;
      (composite.material as THREE.LineBasicMaterial).opacity = 0.6;
      composite.visible = false;
      scene.add(composite);
      compositeBoxRef.current = composite;
    }

    // AIS-19: 2+ alvos (sem aninhados nem locked) → gizmo no pivô = centro da bounding box composta
    const groupTargets = groupTransformTargets(activeScene.nodes, selectedIds, activeScene.rootNodeId)
      .map((id) => objectsMapRef.current.get(id))
      .filter((obj): obj is THREE.Object3D => Boolean(obj?.visible));
    const pivotObj = groupPivotRef.current;
    if (tc && pivotObj && groupTargets.length > 1 && !isBrushMode(manipulationMode)) {
      const union = new THREE.Box3();
      for (const obj of groupTargets) union.union(new THREE.Box3().setFromObject(obj));
      pivotObj.position.copy(union.isEmpty() ? new THREE.Vector3() : union.getCenter(new THREE.Vector3()));
      pivotObj.quaternion.identity();
      pivotObj.scale.set(1, 1, 1);
      pivotObj.updateMatrixWorld(true);
      tc.attach(pivotObj);
      return;
    }

    const primaryObj = selectedNodeId ? objectsMapRef.current.get(selectedNodeId) : null;
    // AIS-59b (D1): nó bloqueado ("Lock Node in Viewport") não recebe o gizmo — nada o move/gira/escala pela viewport
    const primaryLocked = selectedNodeId ? activeScene.nodes[selectedNodeId]?.locked === true : false;
    if (tc && primaryObj?.visible && !primaryLocked && !isBrushMode(manipulationMode)) {
      tc.attach(primaryObj);
    } else if (tc) {
      tc.detach();
    }
  }, [selectedNodeId, multiSelectedNodeIds, activeScene, isPlaying, manipulationMode]);

  // AIS-50b: modo terreno — pincel na viewport. Sai ao selecionar outro nó, ao entrar no Play ou quando o alvo deixa de ser um Terrain.
  useEffect(() => {
    if (manipulationMode !== 'terrain') return;
    const node = selectedNodeId ? activeSceneRef.current.nodes[selectedNodeId] : undefined;
    const canvas = rendererRef.current?.domElement;
    if (isPlaying || !node || node.type !== 'Terrain' || !canvas || !editorCameraRef.current) {
      setManipulationMode('select');
      return;
    }
    const nodeId = node.id;
    const controller = new TerrainSculptController({
      canvas,
      getCamera: () => editorCameraRef.current!.camera,
      getTerrainMesh: () => (objectsMapRef.current.get(nodeId) as THREE.Mesh | undefined) ?? null,
      nodeId,
      getNodeName: () => activeSceneRef.current.nodes[nodeId]?.name ?? 'Terrain',
      getBrush: () => {
        const st = useEditorStore.getState();
        return { tool: st.activeSculptTool, radius: st.brushRadius, strength: st.brushStrength, falloff: st.brushFalloff, targetHeight: st.flattenTargetHeight, paintLayer: st.paintLayer };
      },
      setRadius: (radius) => useEditorStore.getState().setSculptBrush({ brushRadius: radius }),
    });
    const detach = controller.attach();
    return () => {
      detach(); // fecha a pincelada pendente, solta os eventos, descarta o cursor e libera a sessão de escultura
      releaseTerrainEdit(nodeId);
    };
  }, [manipulationMode, selectedNodeId, isPlaying]);

  // AIS-72: modo caminho — handles/segmentos de um nó Path. Sai ao selecionar outro nó, ao entrar no Play ou quando o alvo deixa de ser um Path.
  useEffect(() => {
    if (manipulationMode !== 'path') return;
    const node = selectedNodeId ? activeSceneRef.current.nodes[selectedNodeId] : undefined;
    const canvas = rendererRef.current?.domElement;
    if (isPlaying || !node || node.type !== 'Path' || !canvas || !editorCameraRef.current) {
      setManipulationMode('select');
      return;
    }
    const nodeId = node.id;
    const controller = new PathEditController({
      canvas,
      getCamera: () => editorCameraRef.current!.camera,
      nodeId,
      getNodeName: () => activeSceneRef.current.nodes[nodeId]?.name ?? 'Path',
      getPathObject: () => objectsMapRef.current.get(nodeId) ?? null,
      getSurfaces: () => {
        const surfaces: THREE.Object3D[] = [];
        for (const other of Object.values(activeSceneRef.current.nodes)) {
          if (!isSurfaceCandidate(other, nodeId) && !(other.type === 'Terrain' && other.visible)) continue; // malhas e terreno
          const obj = objectsMapRef.current.get(other.id);
          if (obj && obj.visible) surfaces.push(obj);
        }
        return surfaces;
      },
    });
    return controller.attach(); // solta os eventos e fecha o arrasto pendente ao sair do modo
  }, [manipulationMode, selectedNodeId, isPlaying]);

  /** Raycast da tela para o nó selecionável sob o ponto (seleção por clique e alvo de arrastar-e-soltar, AIS-31). */
  const hitNodeAt = (clientX: number, clientY: number): string | null => {
    const container = mountRef.current;
    if (!container || !editorCameraRef.current || !sceneRef.current) return null;
    const rect = container.getBoundingClientRect();
    const mouse = new THREE.Vector2(
      ((clientX - rect.left) / container.clientWidth) * 2 - 1,
      -((clientY - rect.top) / container.clientHeight) * 2 + 1
    );

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, editorCameraRef.current.camera);

    const testObjects = Object.values(activeScene.nodes)
      .filter(isViewportNodeSelectable)
      .map((node) => objectsMapRef.current.get(node.id))
      .filter((object): object is THREE.Object3D => Boolean(object?.visible));
    const intersects = raycaster.intersectObjects(testObjects, true);
    return resolveSelectableHitNodeId(intersects, sceneRef.current, activeScene.nodes);
  };

  // AIS-31: arquivos do FileSystemPanel soltos no viewport (o alvo é a malha sob o cursor, por raycast)
  const handleFsDragOver = (e: React.DragEvent) => {
    if (isPlaying || !isFileSystemDrag(e)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  };
  const handleFsDrop = (e: React.DragEvent) => {
    if (isPlaying || !isFileSystemDrag(e)) return;
    e.preventDefault();
    const path = e.dataTransfer.getData(FS_DRAG_MIME);
    if (path) dropFile(path, hitNodeAt(e.clientX, e.clientY));
  };

  // Orbit camera mouse controls
  const handleMouseDown = (e: React.MouseEvent) => {
    // If dragging TransformControls gizmo, ignore orbit controls
    if (isGizmoDraggingRef.current) return;
    // Middle button pans the camera: block the browser's autoscroll cursor
    if (e.button === 1) e.preventDefault();

    isMouseDownRef.current = true;
    mouseButtonRef.current = e.button;
    mouseStartRef.current = { x: e.clientX, y: e.clientY };

    // When playing in viewport, skip node selection
    if (isPlaying) return;

    // Raycast on left click to select 3D node
    if (e.button === 0 && editorCameraRef.current && sceneRef.current) {
      const hitId = hitNodeAt(e.clientX, e.clientY);
      if (hitId) {
        const mode = e.ctrlKey || e.metaKey ? 'toggle' : e.shiftKey ? 'add' : 'replace';
        const next = updateViewportSelection(selectedNodeId, multiSelectedNodeIds, hitId, mode);
        selectNode(next.primaryId);
        setMultiSelectedNodeIds(next.additionalIds);
      } else if (!e.ctrlKey && !e.metaKey && !e.shiftKey && activeScene.rootNodeId) {
        selectNode(activeScene.rootNodeId);
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    // If dragging TransformControls gizmo, ignore orbit camera
    if (isGizmoDraggingRef.current) return;

    const editorCamera = editorCameraRef.current;
    if (!isMouseDownRef.current || !editorCamera) return;
    const dx = e.clientX - mouseStartRef.current.x;
    const dy = e.clientY - mouseStartRef.current.y;
    mouseStartRef.current = { x: e.clientX, y: e.clientY };

    // AIS-07: right = orbit, middle = pan; left only selects (and drives the gizmo)
    const btn = mouseButtonRef.current;
    if (btn === 2) {
      editorCamera.orbit(dx, dy);
    } else if (btn === 1) {
      editorCamera.pan(dx, dy, mountRef.current?.clientHeight ?? 1);
    }
  };

  const handleMouseUp = () => {
    isMouseDownRef.current = false;
  };

  // AIS-07: continuous zoom; the controller interpolates the radius every frame
  const handleWheel = (e: React.WheelEvent) => {
    editorCameraRef.current?.zoom(e.deltaY);
  };

  const setViewpoint = (view: EditorViewPreset) => {
    editorCameraRef.current?.setView(view);
  };

  // AIS-77: a sonda de métricas só fica plugada no RendererCore enquanto o overlay está visível (fora disso o quadro não paga nada)
  const debugVisible = isPlaying && showDebugOverlay;
  useEffect(() => {
    const core = coreRef.current;
    const stats = debugStatsRef.current;
    if (!core || !stats) return;
    core.setProbe(debugVisible ? stats : null);
    return () => core.setProbe(null);
  }, [debugVisible]);

  // AIS-74 — Travar View: trava só a ROTAÇÃO orbital da câmera do editor (pan e zoom livres, projeção independente). O estado
  // (ligado + a rotação congelada) é da CENA: vai por Command para `cameraSettings.viewLock` e é restaurado ao reabrir a cena.
  const sceneViewLock = readViewLock(activeScene);
  const viewLocked = !!sceneViewLock;
  const toggleViewLock = () => {
    const camera = editorCameraRef.current;
    if (!camera || isPlayingRef.current) return;
    if (viewLocked) setViewLock(undefined);
    else setViewLock({ locked: true, theta: camera.spherical.theta, phi: camera.spherical.phi });
  };
  // a câmera segue o estado da cena aberta: trocar de cena (ou Undo/Redo) liga/desliga o lock sem vazar para a outra cena
  useEffect(() => {
    const camera = editorCameraRef.current;
    if (!camera) return;
    if (sceneViewLock) camera.setOrbitLocked(true, { theta: sceneViewLock.theta, phi: sceneViewLock.phi });
    else camera.setOrbitLocked(false);
  }, [activeScene.id, sceneViewLock?.theta, sceneViewLock?.phi, !!sceneViewLock]); // eslint-disable-line react-hooks/exhaustive-deps

  // ----------------------------------------------------------------------
  // CopperCube 2D Overlays Layer on 3D Viewport
  // ----------------------------------------------------------------------
  const overlayNodes = Object.values(activeScene.nodes).filter((n) => isOverlayNodeType(n.type));
  /** AIS-25c: filho de um Container não é livre — o pai manda na posição/tamanho (só seleciona; sem arrastar/redimensionar). */
  const isFlowItem = (node: GameNode) => {
    const parent = node.parentId ? activeScene.nodes[node.parentId] : undefined;
    return !!parent && isLayoutContainerType(parent.type);
  };
  const alignCameraToAxis = (axis: EditorAxisView) => {
    if (!isPlaying) editorCameraRef.current?.setAxisView(axis);
  };
  const handleAxisFaceKeyDown = (event: React.KeyboardEvent<SVGPolygonElement>, axis: EditorAxisView) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      alignCameraToAxis(axis);
    }
  };

  // Global mouse handlers for 2D Overlay dragging and resizing (AIS-25b)
  // Um arrasto = UM gesto no CommandManager (uma entrada de Undo); o retângulo novo é convertido para os
  // offsets do preset do nó por `rectToOverlayOffsets` (inverso de `computeOverlayScreenRect`).
  useEffect(() => {
    if (!dragState) return;
    globalCommandManager.beginGesture();

    const handleGlobalMouseMove = (e: MouseEvent) => {
      const dx = e.clientX - dragState.startX;
      const dy = e.clientY - dragState.startY;
      const snap = snapToGrid ? 8 : 1;
      const snapTo = (v: number) => Math.round(v / snap) * snap;
      const o = dragState.origRect;
      let left = o.left;
      let top = o.top;
      let width = o.width;
      let height = o.height;

      if (dragState.action === 'move') {
        left = snapTo(o.left + dx);
        top = snapTo(o.top + dy);
      } else {
        const h = dragState.handle;
        if (h === 'br' || h === 'r' || h === 'tr') width = Math.max(20, snapTo(o.width + dx));
        if (h === 'br' || h === 'b' || h === 'bl') height = Math.max(16, snapTo(o.height + dy));
        if (h === 'tl' || h === 'l' || h === 'bl') {
          const deltaW = snapTo(dx);
          width = Math.max(20, o.width - deltaW);
          left = o.left + (o.width - width);
        }
        if (h === 'tl' || h === 't' || h === 'tr') {
          const deltaH = snapTo(dy);
          height = Math.max(16, o.height - deltaH);
          top = o.top + (o.height - height);
        }
      }

      const offsets = rectToOverlayOffsets(dragState.preset, dragState.parentRect, { left, top, width, height });
      updateNodeProperties(dragState.nodeId, {
        posX: Math.round(offsets.posX),
        posY: Math.round(offsets.posY),
        width: Math.round(offsets.width),
        height: Math.round(offsets.height),
      });
    };

    const handleGlobalMouseUp = () => {
      globalCommandManager.endGesture();
      setDragState(null);
    };

    window.addEventListener('mousemove', handleGlobalMouseMove);
    window.addEventListener('mouseup', handleGlobalMouseUp);
    return () => {
      globalCommandManager.endGesture();
      window.removeEventListener('mousemove', handleGlobalMouseMove);
      window.removeEventListener('mouseup', handleGlobalMouseUp);
    };
  }, [dragState, snapToGrid, updateNodeProperties]);

  /** Retângulos de tela dos overlays (os mesmos que o UIKit desenha) e o do pai de cada um. */
  // AIS-25c: com Containers, o retângulo vem do layout do próprio UIKit (medido pelo HUD, o mesmo que desenha); a função
  // pura `resolveOverlayRects` só cobre o instante antes do primeiro layout.
  const fallbackRects = useMemo(
    () => resolveOverlayRects(activeScene.nodes, viewportSize),
    [activeScene.nodes, viewportSize]
  );
  const overlayRects = hudRects.size > 0 ? hudRects : fallbackRects;

  const startOverlayDrag = (node: GameNode, action: 'move' | 'resize', handle: 'tl' | 'tr' | 'bl' | 'br' | 't' | 'b' | 'l' | 'r' | undefined, e: React.MouseEvent) => {
    e.stopPropagation();
    selectNode(node.id);
    if (isFlowItem(node)) return;
    const rect = overlayRects.get(node.id);
    if (!rect) return;
    const parent = node.parentId ? activeScene.nodes[node.parentId] : undefined;
    const parentRect =
      (parent && overlayRects.get(parent.id)) || { left: 0, top: 0, width: viewportSize.width, height: viewportSize.height };
    setDragState({
      nodeId: node.id,
      action,
      handle,
      startX: e.clientX,
      startY: e.clientY,
      preset: normalizeLayoutPreset(node.properties.alignment),
      parentRect,
      origRect: rect,
    });
  };

  const handleStartMoveOverlay = (node: GameNode, e: React.MouseEvent) => startOverlayDrag(node, 'move', undefined, e);

  const handleStartResizeOverlay = (
    node: GameNode,
    handle: 'tl' | 'tr' | 'bl' | 'br' | 't' | 'b' | 'l' | 'r',
    e: React.MouseEvent
  ) => startOverlayDrag(node, 'resize', handle, e);

  /** Play (AIS-25b): clique em ButtonOverlay2D por hit-test sobre os retângulos (log como antes; triggers = AIS-44c). */
  /**
   * AIS-44: o que está sob o ponteiro no Play — controle de UI (retângulos do HUD; só os que são botão ou têm Behaviors, para
   * um painel de fundo não engolir o 3D) ou, senão, o objeto 3D por raycast. `null` = nada.
   */
  /** Nó de UI do Play: o da cena VIVA (Change Scene troca o snapshot da sessão); fora do Play, o da cena aberta. */
  const playNodeOf = (id: string): GameNode | undefined => (getActiveRuntimeSession()?.snapshot?.nodes?.[id] as GameNode | undefined) ?? activeScene.nodes[id];

  const playPickAt = (clientX: number, clientY: number): string | null => {
    const el = mountRef.current;
    if (!el) return null;
    const box = el.getBoundingClientRect();
    if (showOverlaysHUD) {
      const ui = hitTestOverlays(overlayRects, clientX - box.left, clientY - box.top, (id) => {
        const n = playNodeOf(id);
        return n?.type === 'ButtonOverlay2D' || (n?.behaviors?.length ?? 0) > 0;
      });
      if (ui) return ui;
    }
    return hitNodeAt(clientX, clientY);
  };

  /** Play (AIS-25b/44): clique em UI/objeto → log como antes + Trigger `on_click` do runner. */
  const handleViewportClick = (e: React.MouseEvent) => {
    if (!isPlaying) return;
    // AIS-47: primeiro clique do Play captura o ponteiro quando o controlador usa olhar com mouse (Esc libera)
    const el = mountRef.current;
    if (el && getActiveRuntimeSession()?.gameCamera?.pointerLock && document.pointerLockElement !== el) {
      // a captura pode ser recusada (janela sem foco, contexto embutido): vira aviso no Output, nunca rejeição sem tratamento
      Promise.resolve(el.requestPointerLock?.()).catch((error: unknown) =>
        addLog('warn', `First Person: o navegador não permitiu capturar o mouse (${error instanceof Error ? error.message : String(error)}).`)
      );
    }
    const hit = playPickAt(e.clientX, e.clientY);
    if (!hit) return;
    const node = playNodeOf(hit);
    if (node?.type === 'ButtonOverlay2D') addLog('log', `[Game UI] Clicked: ${node.name} ("${node.properties.text || 'Button'}")`);
    if (!isPaused) getLogicRunner()?.notifyClick(hit, e.button === 1 ? 'middle' : e.button === 2 ? 'right' : 'left');
  };

  /** Play (AIS-44): rastreio de entrada/saída do ponteiro para `on_hover`. */
  const handlePlayHover = (e: React.MouseEvent) => {
    if (isPaused) return;
    getLogicRunner()?.setPointerTarget(playPickAt(e.clientX, e.clientY));
  };

  // AIS-44d: moldura do Play (única leitura: resolveRenderSettings). Em Edit: sem caixa, o canvas ocupa tudo como sempre.
  const playRender = useMemo(() => resolveRenderSettings(project.settings), [project.settings]);
  const playFrame = useMemo(
    () => ({ clearColor: playRender.clearColor, box: isPlaying && stageSize.width > 0 && stageSize.height > 0 ? fitFrame(stageSize, playRender.frame.aspect) : null }),
    [isPlaying, stageSize, playRender]
  );

  return (
    <div className="flex-1 h-full bg-[#141822] flex flex-col select-none overflow-hidden relative">
      {/* Viewport Toolbar */}
      {/* AIS-09: min-w-0 + overflow-hidden keep a too-wide toolbar from scrolling the whole viewport sideways */}
      <div className="h-8 border-b border-[#2c3345] px-2 flex items-center justify-between bg-[#181c25] z-30 text-xs min-w-0 overflow-hidden">
        {/* Left tools: Gizmos, Viewpoint, and Scene Selector Dropdown */}
        <div className="flex items-center space-x-1">
          {/* Scene Selection Dropdown (AIS-29f: SceneSelector) */}
          <SceneSelector />

          <div className="w-[1px] h-4 bg-[#2c3345] mx-1" />

          {/* Gizmo tools */}
          <button
            onClick={() => setActiveTool('move')}
            className={`p-1.5 rounded transition-colors ${
              activeTool === 'move' ? 'bg-[#4982ea] text-white' : 'text-[#8b97a8] hover:text-[#dfe4ec]'
            }`}
            title="Translate Gizmo"
          >
            <Move className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setActiveTool('rotate')}
            className={`p-1.5 rounded transition-colors ${
              activeTool === 'rotate' ? 'bg-[#4982ea] text-white' : 'text-[#8b97a8] hover:text-[#dfe4ec]'
            }`}
            title="Rotate Gizmo"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setActiveTool('scale')}
            className={`p-1.5 rounded transition-colors ${
              activeTool === 'scale' ? 'bg-[#4982ea] text-white' : 'text-[#8b97a8] hover:text-[#dfe4ec]'
            }`}
            title="Scale Gizmo"
          >
            <Maximize className="w-3.5 h-3.5" />
          </button>

          <div className="w-[1px] h-4 bg-[#2c3345] mx-1" />

          {/* Viewpoint dropdown */}
          <div className="flex items-center gap-1">
            <Compass className="w-3.5 h-3.5 text-[#8b97a8]" />
            <select
              value={cameraView}
              onChange={(e) => setViewpoint(e.target.value as EditorViewPreset)}
              title="Editor camera view (Ctrl+0 / Ctrl+1 Perspective · Ctrl+2 Top · Ctrl+3 Front · Ctrl+4 Right)"
              className="bg-[#141820] text-xs text-[#dfe4ec] px-1.5 py-0.5 rounded border border-[#2c3345] outline-none"
            >
              <option value="Perspective">Perspective</option>
              <option value="Top">Top (Y)</option>
              <option value="Front">Front (Z)</option>
              <option value="Right">Right (X)</option>
              <option value="Ortho">Ortho (livre)</option>
            </select>
          </div>

          {/* AIS-74: Travar View — só a rotação orbital da câmera do editor; pan, zoom e projeção seguem livres */}
          <button
            type="button"
            onClick={toggleViewLock}
            disabled={isPlaying}
            aria-pressed={viewLocked}
            data-testid="lock-view-toggle"
            className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[11px] transition-colors border ${
              viewLocked ? 'bg-[#273247] text-blue-300 border-[#3b4b6d]' : 'text-[#8b97a8] hover:bg-[#202531] border-transparent'
            } disabled:opacity-40`}
            title={viewLocked ? 'Travar View ligado: a rotação orbital está congelada (pan e zoom livres). Clique para destravar.' : 'Travar View: congela só a rotação orbital da câmera do editor (pan e zoom continuam livres).'}
          >
            {viewLocked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
            <span>Travar View</span>
          </button>

          <div className="w-[1px] h-4 bg-[#2c3345] mx-1" />

          {/* AIS-09: precision toolbar — independent grid / angle / surface snapping.
              Compact: icon toggles (label in tooltip); each step selector shows only while its snap is on. */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setViewportSnap({ gridEnabled: !viewportSnap.gridEnabled })}
              className={`p-1 rounded transition-colors ${
                viewportSnap.gridEnabled
                  ? 'bg-[#273247] text-blue-300 border border-[#3b4b6d]'
                  : 'text-[#8b97a8] hover:bg-[#202531] border border-transparent'
              }`}
              title={`Grid Snapping (translate): ${viewportSnap.gridEnabled ? 'on' : 'off'}`}
              aria-pressed={viewportSnap.gridEnabled}
            >
              <Grid className="w-3 h-3" />
            </button>
            {viewportSnap.gridEnabled && (
              <select
                value={viewportSnap.gridStep}
                onChange={(e) => setViewportSnap({ gridStep: Number(e.target.value) as GridSnapStep })}
                title="Grid snapping step"
                className="bg-[#141820] text-xs text-[#dfe4ec] px-1 py-0.5 rounded border border-[#2c3345] outline-none"
              >
                {GRID_SNAP_STEPS.map((step) => (
                  <option key={step} value={step}>
                    {step}m
                  </option>
                ))}
              </select>
            )}

            <button
              onClick={() => setViewportSnap({ angleEnabled: !viewportSnap.angleEnabled })}
              className={`p-1 rounded transition-colors ${
                viewportSnap.angleEnabled
                  ? 'bg-[#273247] text-blue-300 border border-[#3b4b6d]'
                  : 'text-[#8b97a8] hover:bg-[#202531] border border-transparent'
              }`}
              title={`Angle Snapping (rotate): ${viewportSnap.angleEnabled ? 'on' : 'off'}`}
              aria-pressed={viewportSnap.angleEnabled}
            >
              <RotateCw className="w-3 h-3" />
            </button>
            {viewportSnap.angleEnabled && (
              <select
                value={viewportSnap.angleStep}
                onChange={(e) => setViewportSnap({ angleStep: Number(e.target.value) as AngleSnapStep })}
                title="Angle snapping step"
                className="bg-[#141820] text-xs text-[#dfe4ec] px-1 py-0.5 rounded border border-[#2c3345] outline-none"
              >
                {ANGLE_SNAP_STEPS.map((step) => (
                  <option key={step} value={step}>
                    {step}°
                  </option>
                ))}
              </select>
            )}

            <button
              onClick={() => setViewportSnap({ surfaceEnabled: !viewportSnap.surfaceEnabled })}
              className={`p-1 rounded transition-colors ${
                viewportSnap.surfaceEnabled
                  ? 'bg-[#273247] text-blue-300 border border-[#3b4b6d]'
                  : 'text-[#8b97a8] hover:bg-[#202531] border border-transparent'
              }`}
              title={`Surface Snapping: translate drags place the object's base on the static mesh under the cursor (${viewportSnap.surfaceEnabled ? 'on' : 'off'})`}
              aria-pressed={viewportSnap.surfaceEnabled}
            >
              <Magnet className="w-3 h-3" />
            </button>

            <button
              onClick={() => setShowColliders(!showColliders)}
              className={`p-1 rounded transition-colors ${
                showColliders
                  ? 'bg-[#273247] text-cyan-300 border border-[#3b4b6d]'
                  : 'text-[#8b97a8] hover:bg-[#202531] border border-transparent'
              }`}
              title={`Mostrar colisores: desenha o wireframe de colisão dos objetos, na edição e no Play (${showColliders ? 'ligado' : 'desligado'})`}
              aria-pressed={showColliders}
              aria-label="Mostrar colisores"
            >
              <BoxSelect className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Right side controls: Snap to grid & 2D Overlays Layer Toggle */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSnapToGrid(!snapToGrid)}
            className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
              snapToGrid
                ? 'bg-[#273247] text-blue-300 border border-[#3b4b6d]'
                : 'text-[#8b97a8] hover:bg-[#202531]'
            }`}
            title="Snap 2D Overlays to 8px Grid"
          >
            <Grid className="w-3 h-3" />
            <span>Snap 8px</span>
          </button>

          <button
            onClick={() => setShowOverlaysHUD(!showOverlaysHUD)}
            className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
              showOverlaysHUD
                ? 'bg-[#273247] text-sky-400 border border-[#3b4b6d]'
                : 'text-[#8b97a8] hover:bg-[#202531]'
            }`}
            title="Toggle 2D Overlay Layer"
          >
            {showOverlaysHUD ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            <span>2D Overlay Layer ({overlayNodes.length})</span>
          </button>
        </div>
      </div>

      {/* AIS-44d: palco do canvas; em Play, moldura na proporção do projeto com barras na cor de limpeza (Edit não muda) */}
      <div
        ref={stageRef}
        className="flex-1 flex flex-col relative"
        style={isPlaying ? { backgroundColor: playFrame.clearColor, alignItems: 'center', justifyContent: 'center' } : undefined}
      >
      {/* AIS-77: overlay de debug (somente leitura) — só no Play com o overlay ligado */}
      {isPlaying && showDebugOverlay && <RuntimeDebugOverlay stats={debugStatsRef.current} authoredNodeCount={Object.keys(activeScene.nodes).length} />}
      {/* WebGL Mount Point (3D Three.js Viewport) */}
      <div
        ref={mountRef}
        onMouseDown={handleMouseDown}
        onMouseMove={(e) => {
          if (isPlaying) handlePlayHover(e);
          handleMouseMove(e);
        }}
        onMouseLeave={() => isPlaying && getLogicRunner()?.setPointerTarget(null)}
        onMouseUp={handleMouseUp}
        onClick={handleViewportClick}
        onDragOver={handleFsDragOver}
        onDrop={handleFsDrop}
        onContextMenu={(e) => e.preventDefault()}
        onWheel={handleWheel}
        className="w-full flex-1 cursor-grab active:cursor-grabbing relative overflow-hidden"
        style={playFrame.box ? { width: playFrame.box.width, height: playFrame.box.height, flex: 'none' } : undefined}
      >
      </div>
      </div>

      {/* AIS-25b: os overlays são DESENHADOS pelo UIKit (passada de HUD no canvas). Esta camada DOM é fina e só do
          editor: caixa de seleção/arraste e handles de resize, posicionados por computeOverlayScreenRect. */}
      {showOverlaysHUD && !isPlaying && (
        <div className="absolute inset-0 pointer-events-none mt-8 overflow-hidden z-20">
          {overlayNodes.map((node) => {
            const rect = overlayRects.get(node.id);
            if (!rect) return null;
            const isSelected = selectedNodeId === node.id;
            const flow = isFlowItem(node);

            return (
              <div
                key={node.id}
                onMouseDown={(e) => handleStartMoveOverlay(node, e)}
                title={flow ? 'Posição e tamanho controlados pelo Container' : undefined}
                style={{ left: `${rect.left}px`, top: `${rect.top}px`, width: `${rect.width}px`, height: `${rect.height}px` }}
                className={`pointer-events-auto absolute select-none transition-shadow ${
                  isSelected ? 'ring-2 ring-[#4982ea] shadow-lg' : 'hover:ring-1 hover:ring-white/40'
                } ${flow ? 'cursor-pointer' : 'cursor-move'}`}
              >
                {/* Resize Handles & Dimension Badge when Selected */}
                {isSelected && !flow && node.type !== 'TextOverlay2D' && (
                  <>
                    <div className="absolute -top-6 left-0 bg-[#4982ea] text-white px-1.5 py-0.2 rounded text-[9px] font-mono whitespace-nowrap shadow pointer-events-none">
                      {node.name} ({Math.round(rect.width)} × {Math.round(rect.height)}px)
                    </div>

                    {/* Corner Handles */}
                    <div onMouseDown={(e) => handleStartResizeOverlay(node, 'tl', e)} className="absolute -top-1.5 -left-1.5 w-3 h-3 bg-white border-2 border-[#4982ea] rounded-sm cursor-nwse-resize z-30" />
                    <div onMouseDown={(e) => handleStartResizeOverlay(node, 'tr', e)} className="absolute -top-1.5 -right-1.5 w-3 h-3 bg-white border-2 border-[#4982ea] rounded-sm cursor-nesw-resize z-30" />
                    <div onMouseDown={(e) => handleStartResizeOverlay(node, 'bl', e)} className="absolute -bottom-1.5 -left-1.5 w-3 h-3 bg-white border-2 border-[#4982ea] rounded-sm cursor-nesw-resize z-30" />
                    <div onMouseDown={(e) => handleStartResizeOverlay(node, 'br', e)} className="absolute -bottom-1.5 -right-1.5 w-3 h-3 bg-white border-2 border-[#4982ea] rounded-sm cursor-nwse-resize z-30" />

                    {/* Edge Handles */}
                    <div onMouseDown={(e) => handleStartResizeOverlay(node, 't', e)} className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-2 bg-white border border-[#4982ea] rounded-sm cursor-ns-resize z-30" />
                    <div onMouseDown={(e) => handleStartResizeOverlay(node, 'b', e)} className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-2 bg-white border border-[#4982ea] rounded-sm cursor-ns-resize z-30" />
                    <div onMouseDown={(e) => handleStartResizeOverlay(node, 'l', e)} className="absolute top-1/2 -left-1.5 -translate-y-1/2 w-2 h-3 bg-white border border-[#4982ea] rounded-sm cursor-ew-resize z-30" />
                    <div onMouseDown={(e) => handleStartResizeOverlay(node, 'r', e)} className="absolute top-1/2 -right-1.5 -translate-y-1/2 w-2 h-3 bg-white border border-[#4982ea] rounded-sm cursor-ew-resize z-30" />
                  </>
                )}
              </div>
            );
          })}
        </div>
      )}

      {!isPlaying && (
        <div className="absolute inset-x-0 top-8 bottom-0 pointer-events-none overflow-hidden z-40">
          {selectedGuideNodeIds.map((nodeId) => {
            const node = activeScene.nodes[nodeId];
            if (!node) return null;
            const position = node.properties.position || { x: 0, y: 0, z: 0 };
            return (
              <div
                key={nodeId}
                ref={(element) => {
                  if (element) guideLabelRefs.current.set(nodeId, element);
                  else guideLabelRefs.current.delete(nodeId);
                }}
                className="absolute -translate-x-1/2 -translate-y-[calc(100%+8px)] whitespace-nowrap rounded-sm border border-[#ff8c00]/70 bg-[#151922]/90 px-1.5 py-1 font-mono text-[10px] text-[#ffd29a] shadow pointer-events-none"
                style={{ left: 0, top: 0, display: 'none' }}
              >
                {node.name} · X {Number(position.x).toFixed(2)} Y {Number(position.y).toFixed(2)} Z {Number(position.z).toFixed(2)}
              </div>
            );
          })}

          <div className="absolute top-2 right-2 pointer-events-auto" aria-label="World axis orientation">
            <svg viewBox="0 0 96 88" className="h-[88px] w-[96px] overflow-visible" role="group" aria-label="Align camera to world axis">
              <polygon
                points="48,5 84,25 48,45 12,25"
                className="cursor-pointer fill-[#39485d] stroke-[#aab9ce] hover:fill-[#52647d] focus:fill-[#52647d]"
                strokeWidth="1.5"
                role="button"
                tabIndex={0}
                aria-label="Align camera to +Y"
                onClick={() => alignCameraToAxis('+Y')}
                onKeyDown={(event) => handleAxisFaceKeyDown(event, '+Y')}
              />
              <polygon
                points="12,25 48,45 48,83 12,63"
                className="cursor-pointer fill-[#2e665f] stroke-[#aab9ce] hover:fill-[#43877e] focus:fill-[#43877e]"
                strokeWidth="1.5"
                role="button"
                tabIndex={0}
                aria-label="Align camera to +X"
                onClick={() => alignCameraToAxis('+X')}
                onKeyDown={(event) => handleAxisFaceKeyDown(event, '+X')}
              />
              <polygon
                points="84,25 48,45 48,83 84,63"
                className="cursor-pointer fill-[#715438] stroke-[#aab9ce] hover:fill-[#936c42] focus:fill-[#936c42]"
                strokeWidth="1.5"
                role="button"
                tabIndex={0}
                aria-label="Align camera to +Z"
                onClick={() => alignCameraToAxis('+Z')}
                onKeyDown={(event) => handleAxisFaceKeyDown(event, '+Z')}
              />
              <g fill="#f1f5f9" fontSize="10" fontFamily="monospace" textAnchor="middle" dominantBaseline="middle" pointerEvents="none">
                <text x="48" y="26">+Y</text>
                <text x="31" y="59">+X</text>
                <text x="66" y="59">+Z</text>
              </g>
            </svg>
            <button
              type="button"
              onClick={() => alignCameraToAxis('-X')}
              title="Align camera to -X"
              aria-label="Align camera to -X"
              className="absolute top-0 right-0 rounded-sm border border-[#53627a] bg-[#202531] px-1 py-0.5 font-mono text-[9px] text-[#dfe4ec] hover:bg-[#2c3345] focus:outline focus:outline-1 focus:outline-[#ff8c00]"
            >
              -X
            </button>
          </div>

          <div className="absolute bottom-2 left-3 min-w-[72px] rounded-sm border border-[#2c3345] bg-[#151922]/90 px-2 py-1 text-[10px] font-mono text-[#dfe4ec] pointer-events-none">
            <span ref={rulerLabelRef}>2 m</span>
            <div ref={rulerLineRef} className="relative mt-1 h-2 border-t-2 border-[#dfe4ec]" style={{ width: 96 }}>
              <span className="absolute left-0 top-[-2px] h-2 border-l-2 border-[#dfe4ec]" />
              <span className="absolute right-0 top-[-2px] h-2 border-r-2 border-[#dfe4ec]" />
            </div>
          </div>
        </div>
      )}

      {/* AIS-46: barra de controle sobreposta (Pausar / Avançar 1 Quadro / Parar) */}
      {isPlaying && <PlayControlBar />}

      {/* 3D Navigation Hints */}
      <div className="absolute bottom-2 right-2 bg-[#202531]/85 backdrop-blur-sm border border-[#2c3345] px-2.5 py-1 rounded text-[10px] font-mono text-[#8b97a8] pointer-events-none z-30 flex items-center gap-2">
        {isPlaying ? (
          <span className="text-emerald-400 font-semibold flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block" />
            Simulation Active • WASD to Move • Esc / F8 to Stop
          </span>
        ) : selectedNode ? (
          <span>
            Selected: <strong className="text-white">{selectedNode.name}</strong> ({selectedNode.type})
          </span>
        ) : (
          <span>Orbit: Right Drag | Pan: Middle Drag | Zoom: Scroll</span>
        )}
      </div>
    </div>
  );
};
