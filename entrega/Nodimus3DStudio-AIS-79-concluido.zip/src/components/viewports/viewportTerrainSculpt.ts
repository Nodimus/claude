import * as THREE from 'three';
import { applyBrush, applyPaintBrush, extractRect, SCULPT_TOOLS, unionRect, writeRect, type BrushFalloff, type DirtyRect, type PaintLayer, type SculptTool } from '../../core/terrainBrush';
import { sampleHeight, terrainAutoWeights } from '../../core/terrainGeometry';
import { beginTerrainEdit, commitStroke, ensureSessionWeights, updateMeshRegion, type TerrainEditSession } from '../../core/terrainEdit';
import { terrainDataOf } from '../../core/terrainObject';

/**
 * AIS-50b §3.2–3.5 — modo terreno da viewport: cursor do pincel, pincelada com o botão esquerdo e Command por pincelada. Fica FORA
 * do `Viewport3D` (que só o cria/descarta): o botão esquerdo é consumido aqui (captura + `stopPropagation`), então a seleção e o
 * gizmo não o recebem; botão do meio/direito (pan/órbita) seguem intactos. Toda assinatura devolve disposer (AIS-48b).
 */

export interface SculptBrushState {
  tool: SculptTool;
  radius: number;
  strength: number;
  falloff: BrushFalloff;
  targetHeight: number;
  paintLayer: PaintLayer;
}

export interface TerrainSculptHost {
  canvas: HTMLCanvasElement;
  getCamera(): THREE.Camera;
  /** Mesh do nó alvo (relido a cada evento: a malha pode ser refeita pelo sync). */
  getTerrainMesh(): THREE.Mesh | null;
  nodeId: string;
  getNodeName(): string;
  getBrush(): SculptBrushState;
  setRadius(radius: number): void;
}

const RING_SEGMENTS = 64;
const toolLabel = (t: SculptTool) => SCULPT_TOOLS.find((x) => x.id === t)?.label ?? t;

export class TerrainSculptController {
  private readonly raycaster = new THREE.Raycaster();
  private ring: THREE.Mesh | null = null;
  private ringRadius = -1;
  private ringParent: THREE.Object3D | null = null;
  private stroke: { startHeights: Float32Array; startWeights: Float32Array | null; rect: DirtyRect | null; last: number; seed: number; tool: SculptTool; invert: boolean } | null = null;
  private session: TerrainEditSession | null = null;
  private shift = false;
  private readonly disposers: (() => void)[] = [];

  constructor(private readonly host: TerrainSculptHost) {}

  attach(): () => void {
    const { canvas } = this.host;
    const on = <K extends keyof HTMLElementEventMap>(target: HTMLElement, type: K, fn: (e: HTMLElementEventMap[K]) => void, capture = false) => {
      target.addEventListener(type, fn as EventListener, { capture });
      this.disposers.push(() => target.removeEventListener(type, fn as EventListener, { capture }));
    };
    const onWin = <K extends keyof WindowEventMap>(type: K, fn: (e: WindowEventMap[K]) => void) => {
      window.addEventListener(type, fn as EventListener);
      this.disposers.push(() => window.removeEventListener(type, fn as EventListener));
    };
    on(canvas, 'mousemove', (e) => this.onMove(e), true);
    on(canvas, 'mousedown', (e) => this.onDown(e), true);
    on(canvas, 'mouseleave', () => this.hideRing());
    onWin('mouseup', (e) => this.onUp(e));
    onWin('keydown', (e) => this.onKey(e, true));
    onWin('keyup', (e) => this.onKey(e, false));
    return () => this.dispose();
  }

  dispose(): void {
    if (this.stroke) this.finishStroke(); // a pincelada em andamento não se perde ao sair do modo
    for (const off of this.disposers.splice(0)) off();
    this.disposeRing();
  }

  // ── raycast ────────────────────────────────────────────────────────────────────────────────

  /** Ponto do terreno sob o mouse, em coordenadas LOCAIS do mesh; `null` fora do terreno. */
  private hitAt(e: MouseEvent): { x: number; z: number; mesh: THREE.Mesh } | null {
    const mesh = this.host.getTerrainMesh();
    if (!mesh) return null;
    const rect = this.host.canvas.getBoundingClientRect();
    const ndc = new THREE.Vector2(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
    this.raycaster.setFromCamera(ndc, this.host.getCamera());
    mesh.updateWorldMatrix(true, false);
    const hit = this.raycaster.intersectObject(mesh, false)[0];
    if (!hit) return null;
    const local = mesh.worldToLocal(hit.point.clone());
    return { x: local.x, z: local.z, mesh };
  }

  // ── eventos ────────────────────────────────────────────────────────────────────────────────

  private onMove(e: MouseEvent): void {
    const hit = this.hitAt(e);
    if (!hit) {
      this.hideRing();
      return;
    }
    this.placeRing(hit.mesh, hit.x, hit.z);
    if (this.stroke && (e.buttons & 1) !== 0) this.applyAt(hit.mesh, hit.x, hit.z);
  }

  private onDown(e: MouseEvent): void {
    if (e.button !== 0) return; // meio/direito: pan e órbita da câmera
    e.stopPropagation(); // o botão esquerdo é do pincel: nem seleção nem gizmo o recebem
    e.preventDefault();
    const hit = this.hitAt(e);
    if (!hit) return;
    const brush = this.host.getBrush();
    const data = terrainDataOf(hit.mesh);
    if (!data) return;
    const session = beginTerrainEdit(this.host.nodeId, hit.mesh, true);
    if (!session) return;
    this.session = session;
    if (brush.tool === 'paint') ensureSessionWeights(session, (h, cfg) => terrainAutoWeights(h, cfg)); // antes do snapshot "antes"
    this.stroke = {
      startHeights: new Float32Array(session.heights),
      startWeights: session.weights ? new Float32Array(session.weights) : null,
      rect: null,
      last: performance.now() - 1000 / 30,
      seed: Math.floor(Math.random() * 1e9),
      tool: brush.tool,
      invert: e.shiftKey,
    };
    this.applyAt(hit.mesh, hit.x, hit.z);
  }

  private onUp(e: MouseEvent): void {
    if (e.button === 0 && this.stroke) this.finishStroke();
  }

  private onKey(e: KeyboardEvent, down: boolean): void {
    if (e.key === 'Shift') this.shift = down;
    if (!down || (e.target as HTMLElement | null)?.tagName === 'INPUT' || (e.target as HTMLElement | null)?.tagName === 'TEXTAREA') return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === '[' || e.key === ']') {
      e.preventDefault(); // decisão 11: só quando tratado
      const radius = this.host.getBrush().radius;
      this.host.setRadius(e.key === '[' ? radius / 1.2 : radius * 1.2);
    }
  }

  // ── pincelada ──────────────────────────────────────────────────────────────────────────────

  private applyAt(mesh: THREE.Mesh, x: number, z: number): void {
    const stroke = this.stroke;
    const session = this.session;
    if (!stroke || !session) return;
    const brush = this.host.getBrush();
    const { segmentsW, segmentsH, width, depth, maxHeight } = session.config;
    const cols = segmentsW + 1;
    const now = performance.now();
    const dt = Math.min(0.1, Math.max(0.001, (now - stroke.last) / 1000));
    stroke.last = now;
    let rect: DirtyRect | null = null;
    if (stroke.tool === 'paint') {
      const weights = ensureSessionWeights(session, (h, cfg) => terrainAutoWeights(h, cfg));
      const res = applyPaintBrush(weights, segmentsW, segmentsH, width, depth, x, z, brush.paintLayer, brush.radius, brush.strength, brush.falloff, dt, stroke.invert);
      if (res.rect) {
        writeRect(weights, cols, res.rect, extractRect(res.weights, cols, res.rect, 3), 3);
        rect = res.rect;
      }
    } else {
      const tool = stroke.invert ? (stroke.tool === 'raise' ? 'lower' : stroke.tool === 'lower' ? 'raise' : stroke.tool) : stroke.tool; // Smooth/Flatten/Noise não invertem
      const res = applyBrush(session.heights, segmentsW, segmentsH, width, depth, maxHeight, x, z, {
        tool: tool as Exclude<SculptTool, 'paint'>,
        radius: brush.radius,
        strength: brush.strength,
        falloff: brush.falloff,
        targetHeight: brush.targetHeight,
        dt,
        seed: stroke.seed,
      });
      if (res.rect) {
        writeRect(session.heights, cols, res.rect, extractRect(res.heights, cols, res.rect));
        rect = res.rect;
      }
    }
    if (!rect) return;
    stroke.rect = unionRect(stroke.rect, rect);
    updateMeshRegion(mesh, session, rect);
    this.placeRing(mesh, x, z);
  }

  private finishStroke(): void {
    const stroke = this.stroke;
    this.stroke = null;
    if (!stroke?.rect) return;
    const verb = stroke.tool === 'paint' ? `Pintar terreno (${stroke.invert ? 'apagar ' : ''}${this.host.getBrush().paintLayer})` : `Esculpir terreno (${toolLabel(stroke.invert && (stroke.tool === 'raise' || stroke.tool === 'lower') ? (stroke.tool === 'raise' ? 'lower' : 'raise') : stroke.tool)})`;
    commitStroke({ nodeId: this.host.nodeId, nodeName: this.host.getNodeName(), startHeights: stroke.startHeights, startWeights: stroke.startWeights, rect: stroke.rect, label: verb });
    const mesh = this.host.getTerrainMesh();
    if (mesh) mesh.geometry.computeVertexNormals(); // normais exatas ao fim da pincelada (durante ela, só a região)
  }

  // ── cursor do pincel ───────────────────────────────────────────────────────────────────────

  private disposeRing(): void {
    if (!this.ring) return;
    this.ring.removeFromParent();
    this.ring.geometry.dispose();
    (this.ring.material as THREE.Material).dispose();
    this.ring = null;
    this.ringParent = null;
    this.ringRadius = -1;
  }

  private hideRing(): void {
    if (this.ring) this.ring.visible = false;
  }

  /** Anel branco semitransparente cujos vértices SEGUEM o relevo (cada vértice com `sampleHeight`). */
  private placeRing(mesh: THREE.Mesh, x: number, z: number): void {
    const radius = this.host.getBrush().radius;
    if (!this.ring || this.ringRadius !== radius || this.ringParent !== mesh) {
      this.disposeRing();
      const geometry = new THREE.RingGeometry(radius * 0.94, radius, RING_SEGMENTS, 1);
      geometry.rotateX(-Math.PI / 2); // deitado em XZ
      const material = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthTest: false, depthWrite: false });
      this.ring = new THREE.Mesh(geometry, material);
      this.ring.renderOrder = 999;
      this.ring.frustumCulled = false;
      this.ring.raycast = () => undefined; // o cursor nunca é alvo do raycast do pincel
      mesh.add(this.ring);
      this.ringParent = mesh;
      this.ringRadius = radius;
    }
    const data = terrainDataOf(mesh);
    if (!data) return;
    const { segmentsW, segmentsH, width, depth } = data.config;
    const position = this.ring.geometry.getAttribute('position') as THREE.BufferAttribute;
    const base = this.ring.userData.base as Float32Array | undefined;
    const source = base ?? new Float32Array(position.array as Float32Array);
    if (!base) this.ring.userData.base = source;
    for (let i = 0; i < position.count; i++) {
      const px = x + source[i * 3];
      const pz = z + source[i * 3 + 2];
      position.setXYZ(i, px, sampleHeight(data.heights, segmentsW, segmentsH, width, depth, px, pz) + 0.06, pz);
    }
    position.needsUpdate = true;
    this.ring.visible = true;
  }
}
