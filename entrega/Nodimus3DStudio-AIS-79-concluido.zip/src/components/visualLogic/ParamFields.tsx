import React, { useContext, useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { LogicRegistry } from '../../logic/registry';
import type { ConditionRef, LogicParamDescriptor } from '../../logic/types';
import { filesFor, isConditionallyHidden, keyLabel, type ParamIssue } from '../../logic/paramForm';
import { VariableOwnerContext, useLogicFormEnvironment } from './useLogicFormContext';

const INPUT = 'bg-[#0d1017] text-[11px] font-mono text-white px-1.5 py-0.5 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none';

/**
 * Campo de texto/número que só grava ao confirmar (Enter ou sair do campo): UMA edição = UM Command (Undo), nunca um por tecla.
 * Esc volta ao valor atual. Número inválido é descartado (volta ao valor atual).
 */
export const CommitInput: React.FC<{
  value: string | number;
  numeric?: boolean;
  onCommit: (value: string | number) => void;
  className?: string;
  placeholder?: string;
  'aria-label'?: string;
}> = ({ value, numeric, onCommit, className = '', placeholder, ...rest }) => {
  const [draft, setDraft] = useState<string | null>(null);
  useEffect(() => setDraft(null), [value]);
  const commit = () => {
    if (draft === null) return;
    const next = numeric ? Number(draft) : draft;
    setDraft(null);
    if (numeric && (draft.trim() === '' || !Number.isFinite(next as number))) return;
    if (next !== value) onCommit(next);
  };
  return (
    <input
      type="text"
      inputMode={numeric ? 'decimal' : undefined}
      value={draft ?? String(value)}
      placeholder={placeholder}
      aria-label={rest['aria-label']}
      spellCheck={false}
      onFocus={(e) => e.currentTarget.select()}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        e.stopPropagation();
        if (e.key === 'Enter') {
          e.preventDefault();
          commit();
          e.currentTarget.blur();
        } else if (e.key === 'Escape') {
          setDraft(null);
          e.currentTarget.blur();
        }
      }}
      className={`${INPUT} ${className}`}
    />
  );
};

/** Valor atual do parâmetro: o gravado, senão o padrão da pasta. */
export const paramValue = (params: Record<string, any>, p: LogicParamDescriptor): unknown => (p.key in params ? params[p.key] : p.default);

/** Captura a próxima tecla pressionada (o `code` físico: `Space`, `KeyW`, `ArrowUp`…); Esc cancela a captura. */
const KeyField: React.FC<{ value: unknown; onChange: (v: string) => void; label: string }> = ({ value, onChange, label }) => {
  const [capturing, setCapturing] = useState(false);
  useEffect(() => {
    if (!capturing) return;
    const onKey = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setCapturing(false);
      if (e.code !== 'Escape') onChange(e.code);
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [capturing, onChange]);
  const text = typeof value === 'string' ? value : '';
  return (
    <span className="flex items-center gap-1">
      <button
        type="button"
        onClick={() => setCapturing((c) => !c)}
        aria-label={`${label}: ${capturing ? 'aguardando uma tecla…' : keyLabel(value)}`}
        data-testid="key-capture"
        className={`${INPUT} min-w-[88px] text-center ${capturing ? '!border-amber-400 text-amber-300' : ''}`}
        title="Clique e pressione a tecla (Esc cancela)"
      >
        {capturing ? 'Pressione uma tecla…' : keyLabel(value)}
      </button>
      {text && !capturing && (
        <button type="button" onClick={() => onChange('')} className="text-[#68768e] hover:text-rose-400" aria-label={`Limpar ${label}`} title="Limpar">
          <X className="w-3 h-3" />
        </button>
      )}
    </span>
  );
};

/** Formulário genérico por tipo de parâmetro, montado do descritor da pasta (nó e arquivo usam a cena e o projeto reais). */
export const ParamField: React.FC<{ descriptor: LogicParamDescriptor; value: unknown; onChange: (value: unknown) => void; invalid?: boolean; siblings?: Record<string, unknown> }> = ({ descriptor: p, value, onChange, invalid, siblings }) => {
  const env = useLogicFormEnvironment();
  const owner = useContext(VariableOwnerContext);
  const label = `${p.label}`;
  const border = invalid ? '!border-rose-500' : '';
  if (p.variable) {
    // AIS-43: o Visual Logic só ESCOLHE variáveis já declaradas (global: Project Settings; local: Inspector do objeto)
    const scope = p.variableScope ?? (siblings?.scope === 'local' ? 'local' : 'global'); // AIS-71: Behavior de ator = Locais do nó dono
    const declared = env.variablesOf(scope, scope === 'local' ? String(siblings?.target ?? '') : '', owner) ?? [];
    const current = typeof value === 'string' ? value : '';
    const known = current === '' || declared.includes(current);
    return (
      <select value={current} onChange={(e) => onChange(e.target.value)} aria-label={label} data-testid="variable-select" disabled={declared.length === 0 && known} title={declared.length === 0 ? (scope === 'global' ? 'Nenhuma variável global. Crie em Project Settings → Variables.' : 'Nenhuma variável local neste objeto. Crie em Variables, no Inspector.') : undefined} className={`${INPUT} max-w-[180px] ${border}`}>
        <option value="">{declared.length === 0 ? '(nenhuma declarada)' : '(escolha)'}</option>
        {!known && <option value={current}>{current} (não declarada)</option>}
        {declared.map((n) => (
          <option key={n} value={n}>
            {n}
          </option>
        ))}
      </select>
    );
  }
  switch (p.type) {
    case 'number':
      return <CommitInput numeric value={Number(value ?? 0)} onCommit={onChange} className={`w-20 text-right ${border}`} aria-label={label} />;
    case 'boolean':
      return <input type="checkbox" checked={Boolean(value)} onChange={(e) => onChange(e.target.checked)} aria-label={label} />;
    case 'enum': {
      // AIS-58: ações vêm do Input Map do projeto (a lista fixa do descritor é só o padrão)
      // AIS-60b: animações vêm do objeto animado do nó alvo (irmão `target`/`animationTarget`; vazio = o dono do Behavior)
      const choices = p.optionsFrom === 'inputActions' ? env.inputActions : p.optionsFrom === 'animations' ? (env.animationsOf(String(siblings?.[siblings && 'animationTarget' in siblings ? 'animationTarget' : 'target'] ?? ''), owner) ?? []) : (p.options ?? []);
      return (
        <select value={String(value ?? '')} onChange={(e) => onChange(e.target.value)} aria-label={label} className={`${INPUT} ${border}`}>
          {!choices.includes(String(value ?? '')) && <option value={String(value ?? '')}>{String(value ?? '') ? `${String(value)}${p.optionsFrom === 'inputActions' ? ' (não existe no Input Map)' : p.optionsFrom === 'animations' ? ' (não existe neste objeto)' : ''}` : '(escolha)'}</option>}
          {choices.map((o) => (
            <option key={o} value={o}>
              {o}
            </option>
          ))}
        </select>
      );
    }
    case 'node': {
      const current = typeof value === 'string' ? value : '';
      const candidates = p.nodeTypes ? env.nodes.filter((n) => p.nodeTypes!.includes(n.type)) : env.nodes; // AIS-72: ex.: só nós Path
      const known = current === '' || candidates.some((n) => n.id === current || n.name === current);
      return (
        <select value={current} onChange={(e) => onChange(e.target.value)} aria-label={label} data-testid="node-select" className={`${INPUT} max-w-[180px] ${border}`}>
          <option value="">{p.emptyLabel ?? '(este nó)'}</option>
          {!known && <option value={current}>{current} ({p.nodeTypes ? 'não encontrado ou tipo inválido' : 'não encontrado'})</option>}
          {candidates.map((n) => (
            <option key={n.id} value={n.id}>
              {n.name} · {n.type}
            </option>
          ))}
        </select>
      );
    }
    case 'file': {
      const current = typeof value === 'string' ? value : '';
      const options = filesFor(p, env.files);
      const known = current === '' || options.includes(current);
      return (
        <select value={current} onChange={(e) => onChange(e.target.value)} aria-label={label} data-testid="file-select" className={`${INPUT} max-w-[220px] ${border}`} title={p.accept?.length ? `Aceita: ${p.accept.join(', ')}${p.root ? ` em ${p.root}` : ''}` : undefined}>
          <option value="">(nenhum)</option>
          {!known && <option value={current}>{current} (fora do filtro ou ausente)</option>}
          {options.map((path) => (
            <option key={path} value={path}>
              {path.replace('res://', '')}
            </option>
          ))}
        </select>
      );
    }
    case 'key':
      return <KeyField value={value} onChange={onChange} label={label} />;
    case 'condition': {
      // Condition aninhada (ex.: `not`): escolhe o TIPO pelo registro; ID que o registro não conhece continua visível e é preservado.
      // Os parâmetros da aninhada ficam com os padrões.
      const ref = (value && typeof value === 'object' ? value : { type: 'always', parameters: {} }) as ConditionRef;
      const known = LogicRegistry.isKnownCondition(ref.type);
      return (
        <select value={ref.type} onChange={(e) => onChange({ type: e.target.value, parameters: {} })} aria-label={label} className={INPUT}>
          {!known && <option value={ref.type}>{ref.type} (não resolvida)</option>}
          {LogicRegistry.listConditions().map((c) => (
            <option key={c.id} value={c.id}>
              {c.label}
            </option>
          ))}
        </select>
      );
    }
    case 'vector3': {
      const v = (value && typeof value === 'object' ? value : { x: 0, y: 0, z: 0 }) as Record<'x' | 'y' | 'z', number>;
      return (
        <span className="flex items-center gap-1">
          {(['x', 'y', 'z'] as const).map((axis) => (
            <CommitInput key={axis} numeric value={Number(v[axis] ?? 0)} onCommit={(n) => onChange({ ...v, [axis]: n })} className={`w-14 text-right ${border}`} aria-label={`${label} ${axis}`} />
          ))}
        </span>
      );
    }
    default:
      return <CommitInput value={String(value ?? '')} onCommit={onChange} className={`w-44 ${border}`} aria-label={label} />;
  }
};

/**
 * Formulário de um conjunto de parâmetros (Action, Trigger ou Condition): um campo por descritor, `*` nos obrigatórios e a
 * mensagem de validação logo abaixo do campo (erro em vermelho, aviso em âmbar). Campos `hideForUi` somem para alvo de UI.
 */
export const ParamForm: React.FC<{
  params: readonly LogicParamDescriptor[];
  values: Record<string, any>;
  onChange: (key: string, value: unknown) => void;
  issues?: readonly ParamIssue[];
  uiTarget?: boolean;
}> = ({ params, values, onChange, issues = [], uiTarget = false }) => (
  <div className="space-y-2">
    {params
      .filter((p) => !(uiTarget && p.hideForUi) && !isConditionallyHidden(p, values))
      .map((p) => {
        const issue = issues.find((i) => i.key === p.key);
        return (
          <div key={p.key} data-testid={`param-${p.key}`}>
            <label className="flex items-center justify-between gap-2 text-[11px] text-[#8b97a8]">
              <span className="font-mono">
                {p.label}
                {p.required && (
                  <span className="text-rose-400" title="Obrigatório" aria-hidden="true">
                    {' '}
                    *
                  </span>
                )}
              </span>
              <ParamField descriptor={p} value={paramValue(values, p)} onChange={(v) => onChange(p.key, v)} invalid={issue?.severity === 'error'} siblings={values} />
            </label>
            {issue && (
              <p role={issue.severity === 'error' ? 'alert' : 'status'} data-testid={`param-issue-${p.key}`} className={`mt-0.5 text-right text-[10px] ${issue.severity === 'error' ? 'text-rose-400' : 'text-amber-300'}`}>
                {issue.message}
              </p>
            )}
          </div>
        );
      })}
  </div>
);
