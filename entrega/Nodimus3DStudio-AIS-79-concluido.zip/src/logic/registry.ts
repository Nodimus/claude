/**
 * LogicRegistry — fonte única do catálogo nativo de Visual Logic (v4.7.0 · AIS-05r)
 *
 * Descobre, EM TEMPO DE BUILD, uma pasta por item:
 *   src/logic/{triggers,conditions,actions,behaviors}/<id>/index.ts
 *
 * Regras:
 * - O `id` da definição deve ser igual ao nome da pasta; snake_case.
 * - IDs não se repetem dentro do mesmo tipo.
 * - Item inválido não derruba o editor: é ignorado e reportado em `diagnostics`
 *   (e uma única linha de console.error, pois é erro de desenvolvimento).
 * - ID desconhecido encontrado numa cena NÃO é apagado: `isKnown*()` só informa.
 *
 * Não é sistema de extensões: não há carga dinâmica, `res://addons/`, manifesto,
 * hot-reload nem execução de código de terceiros. UI, serialização e (a partir
 * do AIS-44) o runtime consomem este mesmo registry — nunca listas paralelas.
 */
import type {
  ActionDefinition,
  BehaviorDefinition,
  ConditionDefinition,
  LogicDefinition,
  LogicKind,
  TriggerDefinition,
} from './types';

type Modules<T> = Record<string, { default?: T }>;

const triggerModules = import.meta.glob<{ default?: TriggerDefinition }>('./triggers/*/index.ts', { eager: true });
const conditionModules = import.meta.glob<{ default?: ConditionDefinition }>('./conditions/*/index.ts', { eager: true });
const actionModules = import.meta.glob<{ default?: ActionDefinition }>('./actions/*/index.ts', { eager: true });
const behaviorModules = import.meta.glob<{ default?: BehaviorDefinition }>('./behaviors/*/index.ts', { eager: true });

const ID_PATTERN = /^[a-z][a-z0-9_]*$/;

export interface LogicRegistryDiagnostic {
  kind: LogicKind;
  path: string;
  message: string;
}

const diagnostics: LogicRegistryDiagnostic[] = [];

/** Função pura: monta o mapa de um tipo a partir dos módulos das pastas. */
export function collectLogicDefinitions<T extends LogicDefinition>(
  modules: Modules<T>,
  kind: LogicKind,
  out: LogicRegistryDiagnostic[]
): ReadonlyMap<string, T> {
  const map = new Map<string, T>();
  for (const path of Object.keys(modules).sort()) {
    const folder = path.split('/').slice(-2, -1)[0] ?? '';
    const def = modules[path]?.default;
    if (!def) {
      out.push({ kind, path, message: 'index.ts sem export default da definição' });
      continue;
    }
    if (def.kind !== kind) {
      out.push({ kind, path, message: `kind "${def.kind}" na pasta de "${kind}"` });
      continue;
    }
    if (!ID_PATTERN.test(def.id)) {
      out.push({ kind, path, message: `id "${def.id}" não é snake_case` });
      continue;
    }
    if (def.id !== folder) {
      out.push({ kind, path, message: `id "${def.id}" difere do nome da pasta "${folder}"` });
      continue;
    }
    if (map.has(def.id)) {
      out.push({ kind, path, message: `id "${def.id}" duplicado` });
      continue;
    }
    map.set(def.id, Object.freeze(def) as T);
  }
  return map;
}

const triggers = collectLogicDefinitions(triggerModules, 'trigger', diagnostics);
const conditions = collectLogicDefinitions(conditionModules, 'condition', diagnostics);
const actions = collectLogicDefinitions(actionModules, 'action', diagnostics);
const behaviors = collectLogicDefinitions(behaviorModules, 'behavior', diagnostics);

if (diagnostics.length > 0) {
  console.error('[LogicRegistry] definições inválidas ignoradas:', diagnostics);
}

const byLabel = <T extends LogicDefinition>(a: T, b: T) => a.label.localeCompare(b.label);

export const LogicRegistry = {
  diagnostics: diagnostics as readonly LogicRegistryDiagnostic[],

  getTrigger: (id: string) => triggers.get(id),
  getCondition: (id: string) => conditions.get(id),
  getAction: (id: string) => actions.get(id),
  getBehavior: (id: string) => behaviors.get(id),

  listTriggers: (): TriggerDefinition[] => [...triggers.values()].sort(byLabel),
  listConditions: (): ConditionDefinition[] => [...conditions.values()].sort(byLabel),
  listActions: (): ActionDefinition[] => [...actions.values()].sort(byLabel),
  listBehaviors: (): BehaviorDefinition[] => [...behaviors.values()].sort(byLabel),

  /** Actions com botão de adição rápida, na ordem declarada. */
  listQuickAddActions: (): ActionDefinition[] =>
    [...actions.values()].filter((a) => a.quickAdd).sort((a, b) => a.quickAdd!.order - b.quickAdd!.order),

  /** Behaviors com botão de preset, na ordem declarada. */
  listBehaviorPresets: (): BehaviorDefinition[] =>
    [...behaviors.values()].filter((b) => b.preset).sort((a, b) => a.preset!.order - b.preset!.order),

  isKnownTrigger: (id: string) => triggers.has(id),
  isKnownCondition: (id: string) => conditions.has(id),
  isKnownAction: (id: string) => actions.has(id),
  isKnownBehavior: (id: string) => behaviors.has(id),
  /** AIS-47c: o Behavior pode ser anexado a um nó deste tipo? (`allowedNodeTypes` ausente = qualquer nó; ID desconhecido = sim, dado preservado). */
  behaviorAllowsNodeType: (id: string, nodeType: string): boolean => {
    const allowed = behaviors.get(id)?.allowedNodeTypes;
    return !allowed || allowed.includes(nodeType);
  },
} as const;

/**
 * Teste de enumeração (Definição de pronto do catálogo): falha se algum item
 * nativo esperado sumir ou se houver pasta inválida. Função pura
 * (coberto por `src/logic/registry.test.ts` via Vitest).
 */
export const EXPECTED_NATIVE_LOGIC: Record<LogicKind, string[]> = {
  trigger: [
    'on_click',
    'on_collision_enter',
    'on_collision_exit',
    'on_hover',
    'on_input_action',
    'on_key_down',
    'on_key_press',
    'on_key_up',
    'on_mouse_down',
    'on_signal',
    'on_start',
    'on_timeout',
    'on_trigger_enter',
    'on_trigger_exit',
    'on_update',
    'on_variable_changed',
    'on_hotspot_click',
    'on_hotspot_enter',
    'on_hotspot_exit',
    'on_actor_die',
    'on_actor_hit',
    'on_ai_attack',
    'on_ai_state_changed',
    'on_weapon_empty',
    'on_weapon_impact',
    'on_weapon_reload',
    'on_weapon_shoot',
    'on_sprite_animation_finished',
  ],
  condition: [
    'always',
    'distance_between',
    'key_down',
    'key_pressed',
    'node_exists',
    'node_visible',
    'not',
    'property_compare',
    'property_equals',
    'property_greater',
    'random_chance',
    'timer_elapsed',
    'variable_compare',
  ],
  action: [
    'add_force',
    'apply_damage',
    'add_impulse',
    'add_to_variable',
    'apply_torque',
    'attach_to_bone',
    'change_scene',
    'change_text',
    'change_texture',
    'destroy_node',
    'detach_from_bone',
    'emit_particles',
    'explode_area',
    'fire_projectile',
    'emit_signal',
    'look_at',
    'move_by',
    'move_velocity',
    'pause_animation',
    'play_animation',
    'play_sound',
    'play_sprite_animation',
    'set_sprite_frame',
    'print_log',
    'quit_game',
    'restart_scene',
    'rotate_by',
    'rotate_continuous',
    'run_script',
    'set_angular_velocity',
    'set_emissive_color',
    'set_linear_velocity',
    'set_physics_enabled',
    'set_physics_material',
    'shoot',
    'set_position',
    'set_sound_properties',
    'set_variable',
    'set_visible',
    'stop_animation',
    'stop_sound',
    'subtract_from_variable',
    'teleport_physics_body',
    'toggle_visible',
    'tween_to',
  ],
  behavior: [
    'ai_state_machine',
    'camera_first_person',
    'camera_free_flying',
    'camera_model_viewer',
    'camera_panorama',
    'camera_rts',
    'camera_third_person',
    'click_detector',
    'continuous_rotation',
    'custom_rules',
    'first_person_movement',
    'follow_a_path',
    'game_actor_with_health',
    'follow_cursor',
    'hotspot_events',
    'object_moved_by_physics',
    'third_person_movement',
    'platformer_2d_movement',
    'top_down_2d_movement',
    'weapon_controller',
    'timer_trigger',
    'aircraft_controller',
    'vehicle_controller',
    'vehicle_wheel',
  ],
};

/** As 8 Actions de física do catálogo (AIS-41): sempre `Physics` e sempre validando o `bodyMode` do alvo. */
export const PHYSICS_ACTION_IDS: readonly string[] = [
  'add_force',
  'add_impulse',
  'set_linear_velocity',
  'set_angular_velocity',
  'teleport_physics_body',
  'set_physics_enabled',
  'set_physics_material',
  'apply_torque',
];

export function verifyLogicRegistry(): { allPassed: boolean; results: { label: string; passed: boolean; detail?: string }[] } {
  const known: Record<LogicKind, (id: string) => boolean> = {
    trigger: LogicRegistry.isKnownTrigger,
    condition: LogicRegistry.isKnownCondition,
    action: LogicRegistry.isKnownAction,
    behavior: LogicRegistry.isKnownBehavior,
  };
  const results = (Object.keys(EXPECTED_NATIVE_LOGIC) as LogicKind[]).map((kind) => {
    const missing = EXPECTED_NATIVE_LOGIC[kind].filter((id) => !known[kind](id));
    return {
      label: `AIS-05r-L: todos os ${kind}s nativos esperados têm pasta registrada`,
      passed: missing.length === 0,
      detail: missing.length ? `ausentes: ${missing.join(', ')}` : undefined,
    };
  });
  // AIS-40c: toda Condition traz schema de parâmetros e avaliador puro (a UI e o runtime dependem disso)
  const incomplete = LogicRegistry.listConditions().filter((c) => typeof c.evaluate !== 'function' || !c.paramsSchema).map((c) => c.id);
  results.push({
    label: 'AIS-40c-L: toda Condition tem paramsSchema e evaluate',
    passed: incomplete.length === 0,
    detail: incomplete.length ? `incompletas: ${incomplete.join(', ')}` : undefined,
  });
  // AIS-41: toda Action traz schema; as de física têm categoria Physics e validam o bodyMode
  const noSchema = LogicRegistry.listActions().filter((a) => !a.paramsSchema).map((a) => a.id);
  results.push({
    label: 'AIS-41-L: toda Action tem paramsSchema',
    passed: noSchema.length === 0,
    detail: noSchema.length ? `sem schema: ${noSchema.join(', ')}` : undefined,
  });
  const physicsBad = PHYSICS_ACTION_IDS.filter((id) => LogicRegistry.getAction(id)?.category !== 'Physics' || !LogicRegistry.getAction(id)?.validate);
  results.push({
    label: 'AIS-41-L: as 8 Actions de física são Physics e validam o corpo',
    passed: physicsBad.length === 0,
    detail: physicsBad.length ? `problema: ${physicsBad.join(', ')}` : undefined,
  });
  results.push({
    label: 'AIS-05r-L: nenhuma pasta de lógica inválida',
    passed: diagnostics.length === 0,
    detail: diagnostics.length ? JSON.stringify(diagnostics) : undefined,
  });
  // A casca fixa só a ORDEM INICIAL; itens novos podem vir depois sem quebrar o teste.
  const startsWith = (actual: string[], expected: string[]) => expected.every((id, i) => actual[i] === id);
  const presets = LogicRegistry.listBehaviorPresets().map((b) => b.id);
  results.push({
    label: 'AIS-05r-L: presets do Visual Logic começam na ordem da casca',
    passed: startsWith(presets, ['continuous_rotation', 'click_detector']),
    detail: presets.join(','),
  });
  const quick = LogicRegistry.listQuickAddActions().map((a) => a.id);
  results.push({
    label: 'AIS-05r-L: adição rápida de Actions começa na ordem da casca',
    passed: startsWith(quick, ['print_log', 'move_by', 'rotate_by']),
    detail: quick.join(','),
  });
  return { allPassed: results.every((r) => r.passed), results };
}
