import type { BehaviorRuntime, BehaviorRuntimeModule } from '../../types';
import { PhysicsBridgeError } from '../../../core/physics/PhysicsBridge';
import { initialPlatformerState, planeAxes, readPlatformer2DParams, resolvePlane, stepPlatformer, type PlatformerState } from '../../../runtime/controllers/controller2d';
import { controllerPreflight, publishLocomotion } from '../../controllerRuntime';

const INDEX = { x: 0, y: 1, z: 2 } as const;

/**
 * Platformer 2D (AIS-75): só INTENÇÃO horizontal + pulo/gravidade extra pela `PhysicsBridge` (corpo `character`). Chão = `isGrounded` da ponte
 * (o mesmo detector do controlador de personagem, que também gera o snap ao chão); nada de Rapier direto. O eixo normal ao plano fica
 * congelado na pose autoral. Plano: `physics.constrainToPlane` (`xy`/`yz`; qualquer outro valor usa `xy`).
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let state: PlatformerState = initialPlatformerState();
    let warnedPhysics = false;
    let warnedPlane = false;
    return {
      attach() {
        state = initialPlatformerState();
      },
      onUpdate(ctx, dt) {
        if (!warnedPhysics && controllerPreflight(ctx, 'Platformer 2D Movement')) warnedPhysics = true;
        const p = readPlatformer2DParams(ctx.state.properties);
        const raw = ctx.node.properties?.physics?.constrainToPlane;
        const { plane, explicit } = resolvePlane(raw, 'xy', ['xy', 'yz']);
        if (!explicit && !warnedPlane && raw && raw !== 'none') {
          warnedPlane = true;
          ctx.log('warn', `Platformer 2D Movement: o plano "${raw}" não serve a uma plataforma (precisa de Y); usando XY. Ajuste "Constrain To Plane" na Colisão.`);
        }
        const axes = planeAxes(plane);
        const bridge = ctx.physics;
        const id = ctx.node.persistentNodeId;
        const hasBody = !!bridge && bridge.modeOf(id) === 'character';
        const grounded = hasBody ? bridge!.isGrounded(id) : true;
        let vy = 0;
        if (hasBody) {
          try {
            vy = bridge!.getPose(id)?.linearVelocity.y ?? 0;
          } catch {
            vy = 0;
          }
        }
        const step = stepPlatformer(
          state,
          p,
          {
            move: ctx.input.getAxis('MoveLeft', 'MoveRight'),
            jumpPressed: ctx.input.isActionJustPressed('Jump'),
            jumpHeld: ctx.input.isActionPressed('Jump'),
            grounded,
            vy,
            gravity: bridge?.gravityMagnitude ?? 9.8,
          },
          dt
        );
        state = step.state;
        const pos: [number, number, number] = [...ctx.node.transform.position];
        pos[INDEX[axes.right]] += step.dx;
        pos[INDEX[axes.normal]] = ctx.initialTransform.position[INDEX[axes.normal]]; // o plano não se abandona
        ctx.node.transform.position = pos;
        ctx.applyTransform(ctx.node);
        if (step.setVy !== null && hasBody) {
          try {
            bridge!.setLinearVelocity(id, { x: 0, y: step.setVy, z: 0 });
          } catch (error) {
            if (error instanceof PhysicsBridgeError) ctx.log('error', error.message);
            else throw error;
          }
        }
        publishLocomotion(ctx, { moving: step.moving, sprinting: false, speed: step.speed });
      },
      detach(ctx) {
        ctx.setLocomotion(null);
      },
    };
  },
};
export default mod;
