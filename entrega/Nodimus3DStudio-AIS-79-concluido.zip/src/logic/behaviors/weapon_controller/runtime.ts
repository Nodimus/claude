import type { BehaviorRuntime, BehaviorRuntimeContext, BehaviorRuntimeModule } from '../../types';
import { readWeaponParams, type WeaponParams } from '../../../runtime/weapons/params';
import { afterShot, canReload, evaluateShot, finishReloadIfDue, hasAmmoSystem, newClock, reloadTarget, shotRequested, startReload, type AmmoConfig, type WeaponClock } from '../../../runtime/weapons/ammo';

/**
 * Weapon Controller (AIS-69): só CADÊNCIA, MUNIÇÃO e RECARGA. Lê as ações lógicas (`Fire`, `Reload`) do `InputManager`, decide pela máquina de
 * estados pura (`ammo.ts`) e chama o núcleo de armas da sessão (`ctx.weapons.fire`), o MESMO da Action `fire_projectile` e da IA.
 * A munição é uma variável LOCAL do atirador (AIS-43), nunca criada automaticamente. Estado (relógio, recuo, avisos) é da instância em
 * execução: Stop, restart e remoção do nó o descartam; nada vai ao authoring.
 *
 * `replacesRules` fica falso: as regras deste Behavior são os HOOKS (On Weapon Shoot / Impact / Empty / Reload).
 */

const ammoConfig = (p: WeaponParams): AmmoConfig => ({ magazine: p.magazine, maxAmmo: p.maxAmmo, shootDelayMs: p.shootDelay, reloadDelayMs: p.reloadDelay, autoReload: p.autoReload, shootOnce: p.shootOnce });

const mod: BehaviorRuntimeModule = {
  create(): BehaviorRuntime {
    let clock: WeaponClock = newClock();
    let kick = { yaw: 0, pitch: 0 };
    let shots = 0;
    const warned = new Set<string>();

    const warnOnce = (ctx: BehaviorRuntimeContext, key: string, message: string, code: string) => {
      if (warned.has(key)) return;
      warned.add(key);
      ctx.log('warn', message, { code });
    };

    /** Munição atual: `null` = sistema desligado (infinita) ou variável indisponível (aviso, sem tiro). */
    const readAmmo = (ctx: BehaviorRuntimeContext, p: WeaponParams): { ok: true; value: number | null } | { ok: false } => {
      if (!hasAmmoSystem(ammoConfig(p))) return { ok: true, value: null };
      const v = ctx.variables?.getVariable('local', p.ammo, ctx.node.persistentNodeId);
      if (typeof v === 'number' && Number.isFinite(v)) return { ok: true, value: v };
      warnOnce(ctx, `ammo:${p.ammo}`, `${p.gunName}: a variável Local numérica "${p.ammo}" não existe neste nó (crie-a em Variables, no Inspector do objeto); a arma não atira enquanto o carregador (Magazine) estiver ligado.`, 'weapon.ammo_variable_missing');
      return { ok: false };
    };
    const writeAmmo = (ctx: BehaviorRuntimeContext, p: WeaponParams, value: number) => void ctx.variables?.setVariable('local', p.ammo, value, ctx.node.persistentNodeId);

    const beginReload = (ctx: BehaviorRuntimeContext, p: WeaponParams, now: number) => {
      startReload(clock, ammoConfig(p), now);
      ctx.engine.weapons.hook(ctx.node.persistentNodeId, ctx.behavior.id, 'on_weapon_reload', `${p.gunName}: recarregando`);
    };

    return {
      attach() {
        clock = newClock();
        kick = { yaw: 0, pitch: 0 };
        shots = 0;
        warned.clear();
      },
      onUpdate(ctx, dt) {
        const weapons = ctx.engine.weapons;
        if (!weapons.available()) return;
        const p = readWeaponParams(ctx.state.properties);
        const cfg = ammoConfig(p);
        const now = ctx.sceneTime;
        const id = ctx.node.persistentNodeId;

        // o recuo é deslocamento de MIRA (não move a câmera) e relaxa com o tempo
        const relax = Math.exp(-8 * Math.max(0, dt));
        kick = { yaw: kick.yaw * relax, pitch: kick.pitch * relax };

        if (finishReloadIfDue(clock, now)) {
          const refill = reloadTarget(cfg);
          if (hasAmmoSystem(cfg) && refill > 0) writeAmmo(ctx, p, refill);
        }

        const ammo = readAmmo(ctx, p);
        if (!ammo.ok) return;

        if (ctx.input.isActionJustPressed(p.reloadAction) && canReload(clock, cfg, ammo.value)) beginReload(ctx, p, now);

        const wants = shotRequested(cfg, { pressed: ctx.input.isActionPressed(p.fireAction), justPressed: ctx.input.isActionJustPressed(p.fireAction) });
        if (!wants) return;

        const decision = evaluateShot(clock, cfg, now, ammo.value);
        if (decision === 'empty') {
          // um aviso por tentativa: a próxima só depois da cadência (segurar o botão não repete o hook a cada quadro)
          clock.nextShotAt = now + Math.max(p.shootDelay, 250) / 1000;
          weapons.hook(id, ctx.behavior.id, 'on_weapon_empty', `${p.gunName}: carregador vazio`);
          if (p.autoReload && canReload(clock, cfg, ammo.value)) beginReload(ctx, p, now);
          return;
        }
        if (decision !== 'shoot') return;

        const view = p.aimFromCamera ? ctx.engine.camera.view() : null;
        const result = weapons.fire({
          sourceId: id,
          behaviorId: ctx.behavior.id,
          mode: p.fireMode,
          firepoint: p.firepoint,
          aimTarget: p.aimTarget,
          bullet: p.bullet,
          impactEffect: p.impactEffect,
          speed: p.bulletSpeed,
          damage: p.bulletDamage,
          damageVariable: p.damageVariable,
          range: p.bulletRange,
          rangeMode: p.rangeMode,
          lifetimeMs: p.bulletLifetimeMs,
          facesMotion: p.bulletFacesMotion,
          collisionDestroyDelayMs: p.collisionDestroyDelayMs,
          ignoreTags: p.ignoreTags,
          onlyTags: p.onlyTags,
          aimView: view ? { yaw: view.yaw, pitch: p.aimWithPitch ? view.pitch : 0 } : undefined,
          kick: p.recoil ? kick : undefined,
        });
        if (!result.ok) {
          // falha de configuração/ambiente: avisa UMA vez por motivo e não gasta munição nem cadência
          warnOnce(ctx, `fire:${result.code}`, `${p.gunName}: ${result.message}`, result.code);
          return;
        }
        const remaining = afterShot(clock, cfg, now, ammo.value);
        if (remaining !== null) writeAmmo(ctx, p, remaining);
        shots++;
        if (p.recoil) kick = { yaw: kick.yaw + (shots % 2 === 0 ? 1 : -1) * p.recoilHorizontal, pitch: kick.pitch + p.recoilVertical };
        weapons.hook(id, ctx.behavior.id, 'on_weapon_shoot', `${p.gunName}: tiro${remaining !== null ? ` (restam ${remaining})` : ''}`);
        if (remaining === 0 && p.autoReload && canReload(clock, cfg, remaining)) beginReload(ctx, p, now);
      },
      detach() {
        clock = newClock();
        kick = { yaw: 0, pitch: 0 };
      },
    };
  },
};
export default mod;
