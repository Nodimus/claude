import type { BehaviorRuntime, BehaviorRuntimeModule } from '../../types';
import { freeFlyPose, initialFreeFlyState, readCameraFreeFlyingParams, stepFreeFly, type FreeFlyState } from '../../../runtime/cameraRig';
import { pointerLookActive } from '../../controllerRuntime';
import { cameraNodeActive } from '../../cameraRuntime';

/**
 * Free Flying Camera (AIS-47d, decisão 28): a ÚNICA câmera que se move sozinha. Voo livre: sem gravidade, sem colisão, sem ator e
 * sem alvo. Lê só ações lógicas (`Move*`, `Jump` sobe, `Crouch` desce) e o ponteiro capturado para olhar. A posição é estado do
 * RIG (runtime): o nó `Camera` autoral nunca é movido pelo Play. Só publica com o nó `active`.
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let state: FreeFlyState = initialFreeFlyState({ x: 0, y: 0, z: 0 });
    return {
      attach(ctx) {
        // recomeça da pose AUTORAL da câmera (Restart Behavior volta ao ponto inicial)
        const [x, y, z] = ctx.initialTransform.position;
        state = initialFreeFlyState({ x, y, z }, ctx.initialTransform.rotation[1], ctx.initialTransform.rotation[0]);
      },
      onPlayStart(ctx) {
        if (cameraNodeActive(ctx) && readCameraFreeFlyingParams(ctx.state.properties).pointerLock) ctx.log('info', 'Free Flying Camera: clique na viewport para capturar o mouse (Esc libera).');
      },
      onLateUpdate(ctx, dt) {
        if (!cameraNodeActive(ctx)) {
          ctx.setGameCamera(null);
          return;
        }
        const p = readCameraFreeFlyingParams(ctx.state.properties);
        const pointer = ctx.input.pointer;
        const look = pointerLookActive() ? { dx: pointer?.dx ?? 0, dy: pointer?.dy ?? 0 } : { dx: 0, dy: 0 };
        state = stepFreeFly(
          state,
          { moveSpeed: p.moveSpeed, rotateSpeed: p.rotateSpeed, smoothMoving: p.smoothMoving },
          { forward: ctx.input.getAxis('MoveBackward', 'MoveForward'), strafe: ctx.input.getAxis('MoveLeft', 'MoveRight'), up: ctx.input.getAxis('Crouch', 'Jump'), lookDx: look.dx, lookDy: look.dy },
          dt
        );
        const pose = freeFlyPose(state);
        ctx.setGameCamera({ position: pose.position, quaternion: pose.quaternion, fov: p.fov, pointerLock: p.pointerLock, view: { yaw: state.yaw, pitch: state.pitch }, kind: 'camera' });
      },
      detach(ctx) {
        ctx.setGameCamera(null);
      },
    };
  },
};
export default mod;
