import type { BehaviorRuntime, BehaviorRuntimeContext, BehaviorRuntimeModule } from '../../types';
import { readActorParams } from '../../../runtime/ai/params';
import { playActorClip } from '../../../runtime/ai/clips';

/**
 * Game Actor with Health (AIS-71, sobre a EngineApi 1.4 no AIS-78d): vitais. O Behavior liga o próprio nó ao sinal `damage_taken` do núcleo de
 * armas (AIS-69) por `engine.signals.connect` (filtrado pela origem = este nó; o dono da inscrição é o Behavior): a cada dano na variável de
 * vida dispara `on_actor_hit` (`engine.hooks.fire`); ao chegar a 0, `on_actor_die` UMA vez, toca `dieAnimation` e marca o ator como morto
 * (`engine.ai.markDead`: o `ai_state_machine` do nó para). Nada é destruído automaticamente. A vida é uma variável Local DECLARADA no authoring
 * (ao adicionar o Behavior); o runtime só a lê — nunca a cria. A inscrição é solta no `detach`/`dispose` (Stop, restart, remoção do nó).
 */

interface DamagePayload {
  sourceId: string;
  targetId: string;
  amount: number;
  remaining: number;
  variable: string;
}

const isDamagePayload = (v: unknown): v is DamagePayload => {
  const p = v as Partial<DamagePayload> | null;
  return !!p && typeof p.targetId === 'string' && typeof p.remaining === 'number' && typeof p.variable === 'string';
};

const mod: BehaviorRuntimeModule = {
  create(): BehaviorRuntime {
    let off: (() => void) | null = null;
    const unsubscribe = () => {
      off?.();
      off = null;
    };

    const onDamage = (ctx: BehaviorRuntimeContext, healthVariable: string, dieAnimation: string, args: readonly unknown[]) => {
      const id = ctx.node.persistentNodeId;
      const payload = args[0];
      if (!isDamagePayload(payload) || payload.targetId !== id) return;
      if (payload.variable !== healthVariable) return; // dano em outra variável não é a vida deste ator
      if (ctx.engine.ai.isDead(id)) return; // morto: nada de on_actor_hit nem de segundo on_actor_die
      const name = ctx.node.name || id;
      ctx.engine.hooks.fire('on_actor_hit', `${name} sofreu ${payload.amount} de dano (restam ${payload.remaining})`);
      if (payload.remaining > 0) return;
      ctx.engine.ai.markDead();
      ctx.engine.hooks.fire('on_actor_die', `${name} morreu`);
      ctx.engine.signals.emit('actor_died', [{ sourceId: payload.sourceId }], id);
      if (dieAnimation) playActorClip(ctx.engine, id, ctx.node, dieAnimation);
    };

    return {
      attach(ctx) {
        unsubscribe(); // idempotente: Restart Behavior nunca deixa uma segunda inscrição
        const id = ctx.node.persistentNodeId;
        const params = readActorParams(ctx.state.properties);
        ctx.engine.ai.registerActor(); // entra (ou volta a entrar) como ator VIVO
        off = ctx.engine.signals.connect('damage_taken', (_name, args) => onDamage(ctx, params.healthVariable, params.dieAnimation, args), { source: id });
      },
      onPlayStart(ctx) {
        const id = ctx.node.persistentNodeId;
        const { healthVariable } = readActorParams(ctx.state.properties);
        const value = ctx.variables?.getVariable('local', healthVariable, id);
        if (typeof value !== 'number') {
          ctx.engine.diagnostics.warnOnce(`${id}:${healthVariable}`, 'warning', 'ai.actor_no_health', `Game Actor with Health: "${ctx.node.name}" não tem a variável Local numérica "${healthVariable}" (declare-a em Variables, no Inspector do objeto); o runtime não a cria e o dano não terá efeito.`, id);
        }
      },
      detach: unsubscribe,
      dispose: unsubscribe,
    };
  },
};
export default mod;
