import type { BehaviorRuntime, BehaviorRuntimeModule } from '../../types';
import { initialPlanarMoveState, readFirstPersonMovementParams, stepPlanarMove, type PlanarMoveState } from '../../../runtime/cameraRig';
import { yawKeepingAuthoredTilt, yawOfEulerXYZ } from '../../../runtime/controllers/controllerMath';
import { controllerPreflight, publishLocomotion, tryJump } from '../../controllerRuntime';

/**
 * First Person Movement (AIS-47c, decisão 28): SÓ locomoção do ator. Lê ações lógicas, emite INTENÇÃO de deslocamento (a
 * `PhysicsBridge` resolve gravidade, colisão e chão) e pula pela ponte. A orientação de referência é o `ctx.view` da câmera ativa
 * (publicado no quadro ANTERIOR: atraso de até 1 quadro); sem câmera ativa vale o yaw do próprio nó (fallback determinístico).
 * NUNCA publica pose de câmera, captura o ponteiro nem esconde o corpo: isso é do Behavior de câmera.
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let move: PlanarMoveState = initialPlanarMoveState();
    let warnedPhysics = false;
    let warnedNoView = false;
    return {
      attach(ctx) {
        move = initialPlanarMoveState();
        ctx.node.transform.rotation = [...ctx.initialTransform.rotation]; // Restart Behavior recomeça da pose autoral
      },
      onUpdate(ctx, dt) {
        if (!warnedPhysics && controllerPreflight(ctx, 'First Person Movement')) warnedPhysics = true;
        const p = readFirstPersonMovementParams(ctx.state.properties);
        const view = ctx.engine.camera.view();
        if (!view && !warnedNoView) {
          warnedNoView = true;
          ctx.log('info', 'Sem câmera ativa: o movimento é relativo ao yaw do próprio nó. Adicione um nó Camera com "First Person Camera" apontando para este nó.');
        }
        const sprinting = p.sprintMultiplier > 1 && ctx.input.isActionPressed('Sprint');
        const yaw = view ? view.yaw : yawOfEulerXYZ(ctx.node.transform.rotation);
        const next = stepPlanarMove(
          move,
          { moveSpeed: p.moveSpeed, smoothing: p.smoothing, speedMultiplier: sprinting ? p.sprintMultiplier : 1 },
          { forward: ctx.input.getAxis('MoveBackward', 'MoveForward'), strafe: ctx.input.getAxis('MoveLeft', 'MoveRight') },
          yaw,
          dt
        );
        move = next.state;
        const [x, y, z] = ctx.node.transform.position;
        ctx.node.transform.position = [x + next.delta.x, y, z + next.delta.z];
        if (p.bodyFollowsView && view) {
          ctx.node.transform.rotation = yawKeepingAuthoredTilt(ctx.initialTransform.rotation, view.yaw);
        }
        ctx.applyTransform(ctx.node);
        if (ctx.input.isActionJustPressed('Jump')) tryJump(ctx, p.jumpSpeed);
        publishLocomotion(ctx, { moving: next.moving, sprinting, speed: next.speed });
      },
      detach(ctx) {
        ctx.setLocomotion(null);
      },
    };
  },
};
export default mod;
