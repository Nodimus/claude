import type { BehaviorRuntime, BehaviorRuntimeContext, BehaviorRuntimeModule } from '../../types';
import { readPhysics } from '../../../core/physics/physicsConfig';
import { yawKeepingAuthoredTilt } from '../../../runtime/controllers/controllerMath';
import { moveNodeToward, nodeWorldPosition, type WorldPoint } from '../../../runtime/motion/moveToward';
import { distanceBetween, gatherCandidates } from '../../../runtime/ai/perception';
import { playActorClip } from '../../../runtime/ai/clips';
import { nextState, selectTarget } from '../../../runtime/ai/fsm';
import { nextWaypoint, randomPatrolPoint } from '../../../runtime/ai/patrol';
import { readAiParams, type AiParams } from '../../../runtime/ai/params';
import { newBrain, type AiBrain, type AiState } from '../../../runtime/ai/types';
import followPath from '../follow_a_path/runtime';

/**
 * AI State Machine (AIS-71): decisão e movimento do NPC. Este executor só ALIMENTA a lógica pura (`nextState`, `selectTarget`) com o que mediu
 * e age conforme o estado; todo o resto vem de contratos já existentes:
 *  - percepção: `PhysicsBridge.overlapSphere` (nunca Rapier direto nem `THREE.Raycaster`), por intervalo — jamais por quadro;
 *  - movimento: SÓ `moveNodeToward` (AIS-72); `dynamic` é incompatível e gera diagnóstico;
 *  - rota de patrulha: `resolveRoute` (AIS-72b); caminho de patrulha: o Behavior `follow_a_path` (AIS-72), composto — sem spline nem movimento próprios;
 *  - animação: `engine.animation` (decisão 30); estado sem clipe configurado = nenhuma troca.
 * AIS-78d: este executor só fala com a EngineApi (`engine.ai/hooks/routes/diagnostics/random/signals/weapons`). O estado transitório (estado atual,
 * timers, alvo, patrulha) vive em `state.memory.brain` do PRÓPRIO Behavior; nada vai ao authoring. Tempo = relógio da sessão.
 */

const FLEE_STEP = 6; // metros à frente na direção oposta ao alvo, a cada quadro de Flee (o alvo de movimento é sempre recalculado)

type Plane = 'none' | 'xy' | 'xz' | 'yz' | undefined;

/** Destino de movimento: sem `canFly` o nó fica na própria altura; o plano 2D do bloco de física (decisão 26) trava o eixo correspondente. */
function planarGoal(here: WorldPoint, goal: WorldPoint, canFly: boolean, plane: Plane): WorldPoint {
  const out = { ...goal };
  if (!canFly) out.y = here.y;
  if (plane === 'xy') out.z = here.z;
  else if (plane === 'xz') out.y = here.y;
  else if (plane === 'yz') out.x = here.x;
  return out;
}

/** Yaw (graus) que aponta o -Z do nó para `to` (convenção do projeto: yaw 0 olha para -Z). */
const yawToward = (from: WorldPoint, to: WorldPoint): number | null => {
  const dx = to.x - from.x;
  const dz = to.z - from.z;
  return Math.hypot(dx, dz) < 1e-6 ? null : (Math.atan2(-dx, -dz) * 180) / Math.PI;
};

const CLIP_OF: Record<AiState, 'idleAnimation' | 'walkAnimation' | 'attackAnimation'> = {
  Idle: 'idleAnimation',
  Patrol: 'walkAnimation',
  Chase: 'walkAnimation',
  Flee: 'walkAnimation',
  Attack: 'attackAnimation',
};

const mod: BehaviorRuntimeModule = {
  create(): BehaviorRuntime {
    /** `follow_a_path` composto (um novo a cada entrada em Patrol com fonte `path`). */
    let pathRuntime: BehaviorRuntime | null = null;

    const fail = (ctx: BehaviorRuntimeContext, key: string, code: string, message: string) => ctx.engine.diagnostics.warnOnce(`${ctx.node.persistentNodeId}:${key}`, 'error', code, message, ctx.node.persistentNodeId);

    /** Estado do cérebro: vive no `state.memory` do Behavior (recriado por Restart Behavior; zera no Stop/restart/troca de cena). */
    const brainOf = (ctx: BehaviorRuntimeContext): AiBrain => (ctx.state.memory.brain ??= newBrain()) as AiBrain;

    /** Move e encara; `false` = corpo incompatível (diagnóstico já emitido, o ator não age). */
    const step = (ctx: BehaviorRuntimeContext, p: AiParams, goal: WorldPoint, dt: number, faceAway = false): 'moving' | 'arrived' | 'incompatible' => {
      const id = ctx.node.persistentNodeId;
      const here = nodeWorldPosition(ctx.node);
      if (!here) return 'incompatible';
      const target = planarGoal(here, goal, p.canFly, readPhysics(ctx.node.properties)?.constrainToPlane);
      const yaw = yawToward(here, faceAway ? { x: 2 * here.x - target.x, y: here.y, z: 2 * here.z - target.z } : target);
      if (yaw !== null) ctx.node.transform.rotation = yawKeepingAuthoredTilt(ctx.initialTransform.rotation, yaw);
      const result = moveNodeToward(ctx, id, target, p.movementSpeed, dt);
      if (result.status === 'incompatible') {
        fail(ctx, result.code ?? 'motion', result.code ?? 'ai.motion_incompatible', `AI State Machine: ${result.message ?? 'o nó não pode ser movido'}`);
        return 'incompatible';
      }
      return result.status;
    };

    const enter = (ctx: BehaviorRuntimeContext, p: AiParams, brain: AiBrain, to: AiState, now: number) => {
      const id = ctx.node.persistentNodeId;
      const from = brain.state;
      brain.state = to;
      brain.enteredAt = now;
      if (to === 'Flee') brain.fleeUntil = now + p.fleeDurationMs / 1000;
      else brain.fleeUntil = null;
      if (to === 'Attack') brain.nextAttackAt = now; // o primeiro ataque sai ao entrar; os seguintes a cada attackCooldownMs
      if (to === 'Patrol') {
        brain.waitUntil = null;
        brain.patrolPoint = null;
        pathRuntime = null; // a patrulha por Path recomeça limpa
      }
      ctx.engine.hooks.fire('on_ai_state_changed', `${from} → ${to}`, { state: to });
      ctx.engine.signals.emit('ai_state_changed', [{ from, to }], id);
    };

    const patrol = (ctx: BehaviorRuntimeContext, p: AiParams, brain: AiBrain, now: number, dt: number): void => {
      if (p.patrolSource === 'random_area') {
        if (brain.waitUntil !== null) {
          if (now < brain.waitUntil) return;
          brain.waitUntil = null;
          brain.patrolPoint = null;
        }
        brain.patrolCenter ??= nodeWorldPosition(ctx.node);
        if (!brain.patrolPoint && brain.patrolCenter) brain.patrolPoint = randomPatrolPoint(brain.patrolCenter, p.patrolRadius, () => ctx.engine.random.next());
        if (brain.patrolPoint && step(ctx, p, brain.patrolPoint, dt) === 'arrived') brain.waitUntil = now + p.patrolWaitMs / 1000;
        return;
      }
      if (p.patrolSource === 'waypoints') {
        if (!p.patrolRoute) return fail(ctx, 'route', 'ai.route_missing', 'AI State Machine: a fonte de patrulha "waypoints" precisa de uma rota (escolha o contêiner dos Waypoints em Patrol Route).');
        const route = ctx.engine.routes.resolve(p.patrolRoute);
        if (!route.ok) return fail(ctx, `route:${route.code}`, route.code, `AI State Machine: ${route.message}`);
        if (brain.waitUntil !== null) {
          if (now < brain.waitUntil) return;
          brain.waitUntil = null;
        }
        const points = route.points;
        const index = Math.min(brain.waypointIndex, points.length - 1);
        const point = points[index];
        if (step(ctx, p, point.position, dt) === 'arrived') {
          const next = nextWaypoint(index, brain.waypointDir, points.length, p.patrolLoop);
          brain.waypointIndex = next.index;
          brain.waypointDir = next.dir;
          brain.waitUntil = now + point.waitMs / 1000; // espera em cada ponto = `waitMs` do Waypoint
        }
        return;
      }
      if (p.patrolSource === 'path') {
        if (!p.patrolPath) return fail(ctx, 'path', 'ai.path_missing', 'AI State Machine: a fonte de patrulha "path" precisa de um nó Path (escolha em Patrol Path).');
        // compõe o Behavior `follow_a_path` (AIS-72): a spline e o movimento são dele; aqui só se define o Path e a velocidade
        const composed: BehaviorRuntimeContext = { ...ctx, state: { properties: { pathId: p.patrolPath, speed: p.movementSpeed, loopMode: 'loop' }, memory: {} } };
        if (!pathRuntime) {
          pathRuntime = followPath.create();
          pathRuntime.onPlayStart?.(composed);
        }
        pathRuntime.onUpdate?.(composed, dt);
        return;
      }
    };

    return {
      attach(ctx) {
        ctx.state.memory.brain = newBrain(); // cérebro novo: timers e alvo zerados
        ctx.engine.ai.setTarget(null);
        pathRuntime = null;
      },
      onUpdate(ctx, dt) {
        const id = ctx.node.persistentNodeId;
        const now = ctx.sceneTime;
        if (ctx.engine.ai.isDead(id)) return; // morto (Game Actor): a IA para
        const p = readAiParams(ctx.state.properties);
        if (!readPhysics(ctx.node.properties)?.enabled) {
          fail(ctx, 'collider', 'ai.no_collider', 'AI State Machine: o nó precisa de Colisão ligada (Inspector → Colisão, corpo "character" ou "kinematic"); a IA não age.');
          return;
        }
        const brain = brainOf(ctx);
        if (brain.enteredAt < 0) brain.enteredAt = now;
        brain.patrolCenter ??= nodeWorldPosition(ctx.node);

        // vida (variável Local comum, declarada no authoring; o runtime só lê). Sem ela, `fleeBelowHealth` fica inativo.
        const raw = ctx.variables?.getVariable('local', p.healthVariable, id);
        const health = typeof raw === 'number' && Number.isFinite(raw) ? raw : null;
        if (health === null && p.fleeBelowHealth > 0) {
          ctx.engine.diagnostics.warnOnce(`${id}:${p.healthVariable}`, 'warning', 'ai.no_health', `AI State Machine: "${ctx.node.name}" não tem a variável Local numérica "${p.healthVariable}"; "Flee Below Health" fica inativo (adicione o Behavior Game Actor with Health ou declare a variável).`, id);
        }

        // percepção por intervalo (nunca por quadro)
        if (now >= brain.nextPerceptionAt) {
          brain.nextPerceptionAt = now + p.perceptionIntervalMs / 1000;
          try {
            const candidates = gatherCandidates({ physics: () => ctx.engine.physics(), instance: (other) => ctx.getNode(other) }, ctx.node, { radius: p.loseRadius, targetTags: p.targetTags, isProjectile: (other) => ctx.engine.weapons.isProjectile(other), isDead: (other) => ctx.engine.ai.isDead(other) });
            brain.targetId = selectTarget(candidates, { currentId: brain.targetId, perceptionRadius: p.perceptionRadius, loseRadius: p.loseRadius });
          } catch (error) {
            ctx.engine.diagnostics.warnOnce(`${id}:perception`, 'error', 'ai.perception_failed', `AI State Machine: a consulta de percepção falhou: ${error instanceof Error ? error.message : String(error)}`, id);
            brain.targetId = null;
          }
        }
        // o alvo pode sumir (excluído/morto) ou se afastar entre as consultas: perde-o sem erro
        let target = brain.targetId ? ctx.getNode(brain.targetId) : undefined;
        if (!target || target.disposed || (brain.targetId !== null && ctx.engine.ai.isDead(brain.targetId))) {
          brain.targetId = null;
          target = undefined;
        }
        const distance = distanceBetween(ctx.node, target);
        if (target && distance > p.loseRadius) {
          brain.targetId = null;
          target = undefined;
        }
        ctx.engine.ai.setTarget(brain.targetId);

        const decided = nextState(brain.state, {
          hasTarget: !!target,
          targetDistance: target ? distance : Infinity,
          attackRange: p.attackRange,
          health,
          fleeBelowHealth: p.fleeBelowHealth,
          timeInState: now - brain.enteredAt,
          idleTimeMs: p.idleTimeMs,
          fleeDurationMs: p.fleeDurationMs,
          patrolEnabled: p.patrolSource !== 'none',
        });
        if (decided !== brain.state) enter(ctx, p, brain, decided, now);

        // animação do estado (só troca quando o clipe muda; vazio = nenhuma troca)
        const clip = p[CLIP_OF[brain.state]];
        if (clip && clip !== brain.lastClip) {
          brain.lastClip = clip;
          playActorClip(ctx.engine, id, ctx.node, clip);
        }

        const targetPosition = target ? nodeWorldPosition(target) : null;
        switch (brain.state) {
          case 'Idle':
            return;
          case 'Attack': {
            const here = nodeWorldPosition(ctx.node);
            const yaw = here && targetPosition ? yawToward(here, targetPosition) : null;
            if (yaw !== null) {
              ctx.node.transform.rotation = yawKeepingAuthoredTilt(ctx.initialTransform.rotation, yaw); // para e encara o alvo
              ctx.applyTransform(ctx.node);
            }
            if (now >= brain.nextAttackAt) {
              brain.nextAttackAt = now + p.attackCooldownMs / 1000;
              ctx.engine.hooks.fire('on_ai_attack', `ataque em "${target?.name ?? ''}"`);
            }
            return;
          }
          case 'Chase':
            if (targetPosition) step(ctx, p, targetPosition, dt);
            return;
          case 'Flee': {
            const here = nodeWorldPosition(ctx.node);
            if (!here || !targetPosition) return;
            const dx = here.x - targetPosition.x;
            const dy = here.y - targetPosition.y;
            const dz = here.z - targetPosition.z;
            const len = Math.hypot(dx, dy, dz) || 1;
            step(ctx, p, { x: here.x + (dx / len) * FLEE_STEP, y: here.y + (dy / len) * FLEE_STEP, z: here.z + (dz / len) * FLEE_STEP }, dt, true);
            return;
          }
          case 'Patrol':
            patrol(ctx, p, brain, now, dt);
            return;
        }
      },
      detach(ctx) {
        pathRuntime?.detach?.(ctx);
        pathRuntime = null;
        ctx.engine.ai.setTarget(null);
        delete ctx.state.memory.brain;
      },
    };
  },
};
export default mod;
