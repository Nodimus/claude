import type { BehaviorRuntime, BehaviorRuntimeContext, BehaviorRuntimeModule } from '../../types';
import { PhysicsBridgeError } from '../../../core/physics/PhysicsBridge';
import { readActionStrength } from '../../../runtime/input/InputManager';
import { forwardOf, leanOf, leanTarget, leanTorque, limitsOf, balanceWheelSpecs, buildWheelSpec, driveWheels, groundAlignmentTorque, initialDriveState, readDriveParams, stabilityOf, upOf, type VehicleDriveWheel } from '../../../runtime/vehicle/vehicleDrive';

/**
 * Vehicle Controller (AIS-73, decisão 28): veículo terrestre ARCADE sobre o `DynamicRayCastVehicleController` do Rapier, SEMPRE pela
 * `PhysicsBridge` (nunca `RigidBody` direto). Lê as ações `Accelerate/Brake/SteerLeft/SteerRight/Handbrake` do Input Map, registra as
 * rodas filhas (`vehicle_wheel`) e comanda motor, freio e esterçamento por roda; o alinhamento ao chão é um torque arcade.
 *
 * NÃO possui câmera: não importa `cameraRig`, não chama `setGameCamera` e não tem parâmetro de câmera. A câmera de perseguição é um nó
 * `Camera` separado com `camera_third_person`; adicionar ou remover a câmera não altera a dinâmica do veículo.
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let drive = initialDriveState();
    /** roda → assinatura da última configuração enviada à ponte (re-registra só quando muda). */
    const registered = new Map<string, string>();
    /** posição LOCAL autoral de cada roda, capturada antes de o visual de runtime mexer no transform. */
    const authored = new Map<string, [number, number, number]>();
    const warned = new Set<string>();
    const warnOnce = (ctx: BehaviorRuntimeContext, key: string, level: 'warn' | 'error', message: string) => {
      if (warned.has(key)) return;
      warned.add(key);
      ctx.log(level, message);
    };

    return {
      attach() {
        drive = initialDriveState();
        registered.clear();
        authored.clear();
        warned.clear();
      },
      onUpdate(ctx, dt) {
        const bridge = ctx.physics;
        const id = ctx.node.persistentNodeId;
        if (!bridge) {
          // o Rapier carrega em segundo plano: 1 s de tolerância antes de avisar
          if (ctx.sceneTime >= 1) warnOnce(ctx, 'no-physics', 'warn', 'Vehicle Controller: a cena não tem mundo físico; ative "Colisão" como "Físico" (dynamic) neste nó.');
          return;
        }
        const mode = bridge.modeOf(id);
        if (mode !== 'dynamic') {
          warnOnce(ctx, 'mode', 'warn', mode ? `Vehicle Controller: o corpo deste nó é "${mode}"; use "Físico" (dynamic) na Colisão.` : 'Vehicle Controller: o nó não tem corpo físico; ative "Colisão" como "Físico" (dynamic).');
          return;
        }

        const p = readDriveParams(ctx.state.properties);
        const scale = ctx.node.transform.scale;
        const wheels: VehicleDriveWheel[] = [];
        const specs: ReturnType<typeof buildWheelSpec>[] = [];
        for (const child of ctx.node.children) {
          if (child.disposed) continue;
          const props = ctx.engine.nodes.behaviorProperties(child.persistentNodeId, 'vehicle_wheel');
          if (!props) continue;
          if (!authored.has(child.persistentNodeId)) authored.set(child.persistentNodeId, [...child.transform.position]);
          const spec = buildWheelSpec(child.persistentNodeId, props, p, authored.get(child.persistentNodeId)!, scale);
          const signature = JSON.stringify(spec);
          if (registered.get(spec.id) !== signature) {
            try {
              bridge.addVehicleWheel(id, spec);
            } catch (error) {
              if (!(error instanceof PhysicsBridgeError)) throw error;
              warnOnce(ctx, `wheel:${spec.id}`, 'error', `Vehicle Controller: ${error.message}`);
              continue;
            }
            registered.set(spec.id, signature);
          }
          wheels.push({ id: spec.id, steering: spec.steering, motorized: spec.motorized });
          specs.push(spec);
        }
        if (wheels.length === 0) {
          warnOnce(ctx, 'no-wheels', 'warn', 'Vehicle Controller: o nó não tem rodas. Crie pelo botão "Configure Vehicle…" ou anexe "Vehicle Wheel" a malhas filhas.');
          return;
        }

        // moto (uma linha de rodas): estabilizadores virtuais arcade; sem eles o corpo deita
        for (const spec of balanceWheelSpecs(id, specs)) {
          const signature = JSON.stringify(spec);
          if (registered.get(spec.id) === signature) continue;
          try {
            bridge.addVehicleWheel(id, spec);
            registered.set(spec.id, signature);
          } catch (error) {
            if (!(error instanceof PhysicsBridgeError)) throw error;
            warnOnce(ctx, `balance:${spec.id}`, 'error', `Vehicle Controller: ${error.message}`);
          }
        }

        const input = ctx.input;
        const speed = bridge.forwardSpeed(id) ?? 0;
        const result = driveWheels(
          drive,
          { ...p, ...limitsOf(stabilityOf(specs), bridge.massOf(id) ?? p.mass) },
          { throttle: readActionStrength(input, 'Accelerate'), brake: readActionStrength(input, 'Brake'), handbrake: input.isActionPressed('Handbrake'), steer: input.getAxis('SteerRight', 'SteerLeft') },
          speed,
          wheels,
          dt
        );
        drive = result.state;
        try {
          for (const w of wheels) bridge.setVehicleWheelControl(id, w.id, result.controls[w.id]);
          // moto (uma linha de rodas): INCLINA para dentro da curva, mais deitada quanto mais rápida (controle de torque sobre o corpo)
          const leaning = balanceWheelSpecs(id, specs).length > 0;
          if (leaning) {
            const pose = bridge.getPose(id);
            const angular = bridge.angularVelocity(id);
            if (pose && angular) {
              const f = forwardOf(pose.rotation);
              const target = leanTarget(speed, drive.steer, stabilityOf(specs).wheelbase);
              const torque = leanTorque(leanOf(pose.rotation), angular.x * f.x + angular.y * f.y + angular.z * f.z, target, bridge.massOf(id) ?? p.mass);
              bridge.applyTorque(id, { x: f.x * torque, y: f.y * torque, z: f.z * torque });
            }
          }
          // alinhamento arcade ao chão: normal média das rodas em contato (estado do passo anterior); a moto inclina de propósito, não alinha
          if (p.groundAlignmentSpeed > 0 && !leaning) {
            let n = 0;
            const sum = { x: 0, y: 0, z: 0 };
            for (const w of wheels) {
              const s = bridge.vehicleWheelState(id, w.id);
              if (!s?.inContact || !s.contactNormal) continue;
              sum.x += s.contactNormal.x;
              sum.y += s.contactNormal.y;
              sum.z += s.contactNormal.z;
              n++;
            }
            const pose = bridge.getPose(id);
            const len = Math.hypot(sum.x, sum.y, sum.z);
            if (n >= 2 && len > 1e-6 && pose) {
              const torque = groundAlignmentTorque(upOf(pose.rotation), { x: sum.x / len, y: sum.y / len, z: sum.z / len }, p.groundAlignmentSpeed, bridge.massOf(id) ?? p.mass);
              bridge.applyTorque(id, torque);
            }
          }
        } catch (error) {
          if (!(error instanceof PhysicsBridgeError)) throw error;
          warnOnce(ctx, `bridge:${error.code}`, 'error', `Vehicle Controller: ${error.message}`);
        }
      },
    };
  },
};
export default mod;
