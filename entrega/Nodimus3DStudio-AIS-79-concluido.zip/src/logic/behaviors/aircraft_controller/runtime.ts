import type { BehaviorRuntime, BehaviorRuntimeContext, BehaviorRuntimeModule } from '../../types';
import { PhysicsBridgeError } from '../../../core/physics/PhysicsBridge';
import { readActionStrength } from '../../../runtime/input/InputManager';
import { flightStep, readAircraftParams } from '../../../runtime/aircraft/aircraftFlight';

/**
 * Aircraft Controller (AIS-73b, decisão 28): voo ARCADE (não é aerodinâmica real), SEMPRE pela `PhysicsBridge` (força contínua e velocidade
 * angular; nunca `RigidBody` direto). Lê \`Throttle\`, \`PitchUp/PitchDown\`, \`RollLeft/RollRight\` e \`YawLeft/YawRight\` do Input Map e aplica o que
 * \`flightStep\` (puro) calcula: empuxo, arrasto, sustentação (cheia a partir de \`minSpeedToFly\`; abaixo dela some e a aeronave cai) e rotação.
 *
 * NÃO possui câmera: não importa \`cameraRig\`, não chama \`setGameCamera\` e não tem parâmetro de câmera. A câmera de perseguição é um nó
 * \`Camera\` separado com \`camera_third_person\` (\`followTargetRotation: 'full'\`); adicionar ou remover a câmera não altera a dinâmica.
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    const warned = new Set<string>();
    const warnOnce = (ctx: BehaviorRuntimeContext, key: string, level: 'warn' | 'error', message: string) => {
      if (warned.has(key)) return;
      warned.add(key);
      ctx.log(level, message);
    };
    return {
      attach() {
        warned.clear();
      },
      onUpdate(ctx, dt) {
        const bridge = ctx.physics;
        const id = ctx.node.persistentNodeId;
        if (!bridge) {
          // o Rapier carrega em segundo plano: 1 s de tolerância antes de avisar
          if (ctx.sceneTime >= 1) warnOnce(ctx, 'no-physics', 'warn', 'Aircraft Controller: a cena não tem mundo físico; ative "Colisão" como "Físico" (dynamic) neste nó.');
          return;
        }
        const mode = bridge.modeOf(id);
        if (mode !== 'dynamic') {
          warnOnce(ctx, 'mode', 'warn', mode ? `Aircraft Controller: o corpo deste nó é "${mode}"; use "Físico" (dynamic) na Colisão.` : 'Aircraft Controller: o nó não tem corpo físico; ative "Colisão" como "Físico" (dynamic).');
          return;
        }
        const pose = bridge.getPose(id);
        const angular = bridge.angularVelocity(id);
        if (!pose || !angular) return;
        const input = ctx.input;
        const result = flightStep(
          readAircraftParams(ctx.state.properties),
          {
            throttle: readActionStrength(input, 'Throttle'),
            pitch: input.getAxis('PitchDown', 'PitchUp'),
            yaw: input.getAxis('YawRight', 'YawLeft'),
            roll: input.getAxis('RollRight', 'RollLeft'),
          },
          { rotation: pose.rotation, linearVelocity: pose.linearVelocity, angularVelocity: angular, mass: bridge.massOf(id) ?? 1 },
          dt
        );
        try {
          bridge.addForce(id, result.force);
          bridge.setAngularVelocity(id, result.angularVelocity);
        } catch (error) {
          if (!(error instanceof PhysicsBridgeError)) throw error;
          warnOnce(ctx, `bridge:${error.code}`, 'error', `Aircraft Controller: ${error.message}`);
        }
      },
    };
  },
};
export default mod;
