/**
 * AIS-42 — lógica PURA do editor de parâmetros (Action, Trigger e Condition): filtro dos seletores de arquivo, validação inline
 * e o preview textual do comportamento. Tudo é derivado do `LogicRegistry` (descritores e schemas das pastas); nenhuma lista
 * própria da UI. Sem React nem DOM: testável em Node.
 */
import { LogicRegistry } from './registry';
import type { LogicDefinition, LogicParamDescriptor } from './types';

export interface FormContext {
  /** O nó (ID ou nome) existe na cena? */
  nodeExists(ref: string): boolean;
  /** Nome do nó para exibição (`undefined` = não resolve). */
  nodeName(ref: string): string | undefined;
  /** O arquivo (`res://…`) existe no projeto? */
  fileExists(path: string): boolean;
  /**
   * AIS-43: nomes de variável DECLARADOS no escopo (global = Project Settings; local = variáveis do nó alvo, vazio = nó dono).
   * `undefined` = não dá para verificar (sem sistema de variáveis ou nó não resolve): nada é acusado.
   */
  variablesOf?(scope: 'global' | 'local', targetRef: string, ownerNodeId?: string): string[] | undefined;
  /** AIS-58: ações do Input Map do projeto (`undefined` = não dá para verificar: nada é acusado). */
  inputActions?(): string[] | undefined;
  /** AIS-60b: animações do objeto animado do alvo (`targetRef` vazio = o dono; cai no primeiro descendente animado). `undefined` = não dá para verificar. */
  animationsOf?(targetRef: string, ownerNodeId?: string): string[] | undefined;
}

/** Chave do parâmetro irmão que escolhe o nó das animações (`animationTarget` nos Behaviors; `target` nas Actions). */
export const animationTargetKey = (params: readonly { key: string }[]): string => (params.some((p) => p.key === 'animationTarget') ? 'animationTarget' : 'target');

const isEmpty = (v: unknown): boolean => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');

// ── Arquivos ─────────────────────────────────────────────────────────────────────────────────────────────

/** O caminho atende ao `accept` (extensões, inclusive compostas como `.scene.json`) e à pasta `root` do descritor? */
export function fileMatches(path: string, descriptor: Pick<LogicParamDescriptor, 'accept' | 'root'>): boolean {
  const lower = path.toLowerCase();
  if (descriptor.root && !lower.startsWith(descriptor.root.toLowerCase())) return false;
  if (descriptor.accept && descriptor.accept.length > 0) return descriptor.accept.some((ext) => lower.endsWith(ext.toLowerCase()));
  return true;
}

/** Arquivos que o seletor de um parâmetro `file` lista: só os que casam com `accept`/`root`, em ordem alfabética. */
export function filesFor(descriptor: Pick<LogicParamDescriptor, 'accept' | 'root'>, allPaths: readonly string[]): string[] {
  return allPaths.filter((p) => !p.endsWith('/') && p.startsWith('res://') && fileMatches(p, descriptor)).sort((a, b) => a.localeCompare(b));
}

// ── Valores legíveis ─────────────────────────────────────────────────────────────────────────────────────

const KEY_NAMES: Record<string, string> = {
  space: 'Espaço',
  escape: 'Esc',
  esc: 'Esc',
  enter: 'Enter',
  tab: 'Tab',
  shiftleft: 'Shift',
  shiftright: 'Shift',
  shift: 'Shift',
  controlleft: 'Ctrl',
  controlright: 'Ctrl',
  ctrl: 'Ctrl',
  control: 'Ctrl',
  altleft: 'Alt',
  altright: 'Alt',
  alt: 'Alt',
  arrowup: '↑',
  arrowdown: '↓',
  arrowleft: '←',
  arrowright: '→',
  up: '↑',
  down: '↓',
  left: '←',
  right: '→',
};

/** Nome legível de uma tecla (`Space`/`space`/`KeyW`/`w`/`Digit5`/`ArrowUp` → `Espaço`/`W`/`5`/`↑`). Vazio = `(nenhuma)`. */
export function keyLabel(value: unknown): string {
  if (typeof value !== 'string' || !value.trim()) return '(nenhuma)';
  const raw = value.trim();
  const named = KEY_NAMES[raw.toLowerCase()];
  if (named) return named;
  const key = /^Key([A-Z])$/.exec(raw);
  if (key) return key[1];
  const digit = /^Digit(\d)$/.exec(raw);
  if (digit) return digit[1];
  return raw.length === 1 ? raw.toUpperCase() : raw;
}

const basename = (p: string) => p.split('/').pop() || p;

/** Valor de um parâmetro como texto curto, para o preview (`[0, 5, 0]`, `[Jogador]`, `explosion.wav`, `[Espaço]`). */
export function formatParam(descriptor: LogicParamDescriptor, value: unknown, ctx: Pick<FormContext, 'nodeName'>): string {
  switch (descriptor.type) {
    case 'vector3': {
      const v = (value && typeof value === 'object' ? value : {}) as Record<string, unknown>;
      return `[${['x', 'y', 'z'].map((k) => Number(v[k] ?? 0)).join(', ')}]`;
    }
    case 'node': {
      if (isEmpty(value)) return '[este nó]';
      const name = ctx.nodeName(String(value));
      return name ? `[${name}]` : `[${String(value)} — não encontrado]`;
    }
    case 'file':
      return isEmpty(value) ? '(nenhum arquivo)' : basename(String(value));
    case 'boolean':
      return value ? 'sim' : 'não';
    case 'key':
      return isEmpty(value) ? '(nenhuma tecla)' : `[${keyLabel(value)}]`;
    case 'condition': {
      const ref = (value && typeof value === 'object' ? value : {}) as { type?: string };
      return `[${LogicRegistry.getCondition(ref.type ?? '')?.label ?? ref.type ?? 'sempre'}]`;
    }
    case 'number':
      return String(Number(value ?? 0));
    case 'enum':
      return String(value ?? '');
    default:
      return isEmpty(value) ? '(vazio)' : `"${String(value)}"`;
  }
}

const valueOf = (params: Record<string, unknown>, p: LogicParamDescriptor): unknown => (p.key in params ? params[p.key] : p.default);
/** O parâmetro depende de um irmão (`visibleWhen`) que não tem o valor esperado? Então o formulário o esconde e não o valida. */
export const isConditionallyHidden = (p: Pick<LogicParamDescriptor, 'visibleWhen'>, values: Record<string, unknown>): boolean =>
  !!p.visibleWhen && !(p.visibleWhen.oneOf ? p.visibleWhen.oneOf.includes(values[p.visibleWhen.key] as string | number | boolean) : values[p.visibleWhen.key] === p.visibleWhen.equals);
const sameAsDefault = (params: Record<string, unknown>, p: LogicParamDescriptor): boolean => JSON.stringify(valueOf(params, p)) === JSON.stringify(p.default);

// ── Preview textual ──────────────────────────────────────────────────────────────────────────────────────

/** Gatilho em português: `Ao pressionar [Espaço]`, `A cada [2] s`… (tipos sem frase própria usam o rótulo do registro). */
export function describeTrigger(eventType: string, params: Record<string, unknown>, ctx: FormContext): string {
  const def = LogicRegistry.getTrigger(eventType);
  const p = (key: string): LogicParamDescriptor | undefined => def?.params.find((x) => x.key === key);
  const v = (key: string) => (p(key) ? formatParam(p(key)!, valueOf(params, p(key)!), ctx) : '');
  switch (eventType) {
    case 'on_key_down':
    case 'on_key_press':
      return `Ao pressionar ${v('key')}`;
    case 'on_key_up':
      return `Ao soltar ${v('key')}`;
    case 'on_mouse_down':
      return `Ao pressionar o botão [${String(valueOf(params, p('button')!))}] do mouse`;
    case 'on_click':
      return `Ao clicar com o mouse (botão [${String(valueOf(params, p('button')!))}])`;
    case 'on_start':
      return 'Ao iniciar a cena';
    case 'on_update':
      return 'A cada frame';
    case 'on_timeout':
      return `A cada [${Number(valueOf(params, p('interval')!))}] s`;
    case 'on_collision_enter':
      return 'Ao começar a colidir';
    case 'on_collision_exit':
      return 'Ao parar de colidir';
    case 'on_signal':
      return `Ao receber o sinal ${v('signal')}`;
    case 'on_input_action':
      return `Quando a ação [${String(valueOf(params, p('action')!))}] for [${String(valueOf(params, p('phase')!))}]`;
    case 'on_variable_changed':
      return `Quando a variável ${v('variable')} mudar`;
    default:
      return def ? `Quando [${def.label}]` : `Quando [${eventType} — não resolvido]`;
  }
}

/** Texto genérico de um item (Action ou Condition): rótulo, valor principal, secundários que mudaram e o nó alvo. */
function describeItem(def: LogicDefinition | undefined, fallbackId: string, params: Record<string, unknown>, ctx: FormContext): string {
  if (!def) return `${fallbackId} [não resolvida]`;
  const targetKeys = new Set(['target', 'targetNodeId']);
  const target = def.params.find((p) => targetKeys.has(p.key));
  const rest = def.params.filter((p) => !targetKeys.has(p.key));
  const [primary, ...secondary] = rest;
  const parts = [def.label];
  if (primary) parts.push(formatParam(primary, valueOf(params, primary), ctx));
  const changed = secondary.filter((p) => !sameAsDefault(params, p)).map((p) => `${p.label}: ${formatParam(p, valueOf(params, p), ctx)}`);
  if (changed.length > 0) parts.push(`(${changed.join(', ')})`);
  if (target && !isConditionallyHidden(target, params)) parts.push(`no nó ${formatParam(target, valueOf(params, target), ctx)}`);
  return parts.join(' ');
}

export const describeAction = (type: string, params: Record<string, unknown>, ctx: FormContext): string => describeItem(LogicRegistry.getAction(type), type, params, ctx);
export const describeCondition = (type: string, params: Record<string, unknown>, ctx: FormContext): string => describeItem(LogicRegistry.getCondition(type), type, params, ctx);

export interface RuleLike {
  eventType: string;
  parameters: Record<string, unknown>;
  conditions: { type: string; parameters: Record<string, unknown> }[];
}

/** `Ao pressionar [Espaço], se Key Pressed [Jump]` — o Trigger e as Conditions da regra (sem a Action). */
export function describeWhen(rule: RuleLike, ctx: FormContext): string {
  const when = describeTrigger(rule.eventType, rule.parameters, ctx);
  const conditions = rule.conditions.filter((c) => c.type !== 'always').map((c) => describeCondition(c.type, c.parameters, ctx));
  return `${when}${conditions.length > 0 ? `, se ${conditions.join(' e ')}` : ''}`;
}

/** `Ao pressionar [Espaço], se Key Pressed [Jump] → Add Impulse [0, 5, 0] no nó [Jogador]`. */
export function describeStep(rule: RuleLike, action: { type: string; parameters: Record<string, unknown> }, ctx: FormContext): string {
  return `${describeWhen(rule, ctx)} → ${describeAction(action.type, action.parameters, ctx)}`;
}

// ── Validação inline ─────────────────────────────────────────────────────────────────────────────────────

export interface ParamIssue {
  key: string;
  message: string;
  /** `error` bloqueia "Aplicar"; `warning` avisa (ex.: arquivo/nó que não existe) e deixa aplicar — o dado nunca é apagado. */
  severity: 'error' | 'warning';
}

/**
 * Valida os valores contra o descritor (obrigatório, número, opção, extensão/pasta do arquivo, existência de nó e arquivo) e
 * depois contra o `paramsSchema` da pasta. Um problema por campo (o primeiro).
 */
export function validateParams(def: Pick<LogicDefinition, 'params'> & { paramsSchema?: { safeParse(v: unknown): { success: boolean; error?: { issues: { path: PropertyKey[]; message: string }[] } } } }, values: Record<string, unknown>, ctx: FormContext, options: { hiddenKeys?: ReadonlySet<string>; ownerNodeId?: string } = {}): ParamIssue[] {
  const issues = new Map<string, ParamIssue>();
  const add = (issue: ParamIssue) => {
    if (!issues.has(issue.key)) issues.set(issue.key, issue);
  };
  for (const p of def.params) {
    if (options.hiddenKeys?.has(p.key) || isConditionallyHidden(p, values)) continue;
    const value = valueOf(values, p);
    if (p.required && (isEmpty(value) || (p.type === 'condition' && !(value as { type?: string })?.type))) {
      add({ key: p.key, message: 'Campo obrigatório.', severity: 'error' });
      continue;
    }
    if (p.variable && !isEmpty(value)) {
      // o Visual Logic só USA variáveis: global nasce no Project Settings, local no Inspector do objeto
      const scope = p.variableScope ?? (values.scope === 'local' ? 'local' : 'global'); // AIS-71: Behavior de ator = Locais do nó dono
      const declared = ctx.variablesOf?.(scope, scope === 'local' ? String(values.target ?? '') : '', options.ownerNodeId);
      if (declared && !declared.includes(String(value))) {
        add({ key: p.key, message: scope === 'global' ? 'Variável global não declarada. Crie em Project Settings → Variables.' : 'Variável local não declarada neste objeto. Crie em Variables, no Inspector do objeto.', severity: 'error' });
        continue;
      }
    }
    if (p.type === 'number' && !Number.isFinite(Number(value))) add({ key: p.key, message: 'Digite um número válido.', severity: 'error' });
    else if (p.type === 'vector3') {
      const v = (value && typeof value === 'object' ? value : {}) as Record<string, unknown>;
      if (['x', 'y', 'z'].some((k) => !Number.isFinite(Number(v[k] ?? 0)))) add({ key: p.key, message: 'X, Y e Z precisam ser números.', severity: 'error' });
    } else if (p.type === 'enum' && p.optionsFrom === 'inputActions') {
      // AIS-58: a ação precisa existir no Input Map do projeto; renomear/excluir deixa a referência não resolvida (aviso, não bloqueia)
      const known = ctx.inputActions?.();
      if (known && !isEmpty(value) && !known.includes(String(value))) add({ key: p.key, message: `A ação "${String(value)}" não existe no Input Map do projeto (referência não resolvida).`, severity: 'warning' });
    } else if (p.type === 'enum' && p.optionsFrom === 'animations') {
      // AIS-60b: a animação precisa existir no objeto animado alvo (aviso, não bloqueia)
      const known = ctx.animationsOf?.(String(values[animationTargetKey(def.params)] ?? ''), options.ownerNodeId);
      if (known && !isEmpty(value) && !known.includes(String(value))) add({ key: p.key, message: `A animação "${String(value)}" não existe neste objeto (referência não resolvida).`, severity: 'warning' });
    } else if (p.type === 'enum' && p.options && !isEmpty(value) && !p.options.includes(String(value))) add({ key: p.key, message: `Opção inválida (use ${p.options.join(', ')}).`, severity: 'error' });
    else if (p.type === 'file' && !isEmpty(value)) {
      const path = String(value);
      if (!fileMatches(path, p)) add({ key: p.key, message: `${p.root ? `Precisa estar em ${p.root} e ` : ''}ser ${p.accept?.length ? p.accept.join(' ou ') : 'um arquivo válido'}.`, severity: 'error' });
      else if (!ctx.fileExists(path)) add({ key: p.key, message: 'Arquivo não encontrado no projeto (a referência será mantida).', severity: 'warning' });
    } else if ((p.type === 'node') && !isEmpty(value) && !ctx.nodeExists(String(value))) add({ key: p.key, message: 'Nó não encontrado na cena (a referência será mantida).', severity: 'warning' });
  }
  const schema = def.paramsSchema?.safeParse(Object.fromEntries(def.params.map((p) => [p.key, valueOf(values, p)])));
  if (schema && !schema.success) {
    for (const issue of schema.error?.issues ?? []) {
      const key = String(issue.path[0] ?? '');
      if (key && !options.hiddenKeys?.has(key)) add({ key, message: issue.message, severity: 'error' });
    }
  }
  return [...issues.values()];
}

export const hasBlockingIssue = (issues: readonly ParamIssue[]): boolean => issues.some((i) => i.severity === 'error');
