import type { RuntimeInstance } from '../runtime/RuntimeScene';
import type { TargetSpace } from '../runtime/cameraRig';
import { readBool } from '../runtime/cameraRig';
import { targetPoseOf as computeTargetPose, nodePosition, type TargetPose } from '../runtime/cameraRig/targetPose';
import type { BehaviorRuntimeContext } from './types';

/**
 * AIS-47c — helpers dos Behaviors de CÂMERA (`behaviors/camera_*`/`runtime.ts`). Ficam FORA das pastas varridas pelo registry.
 * Câmera nunca move o alvo: só LÊ a pose dele, no espaço escolhido em `targetSpace` (`world` compõe a hierarquia de pais; `local`
 * lê o transform local do nó, como nos controladores do AIS-47).
 */

/** O nó `Camera` está ativo? (`active` da instância viva; ausente = ativo, como o default do registry). */
export const cameraNodeActive = (ctx: BehaviorRuntimeContext): boolean => readBool(ctx.node.properties.active, true);

/** Estado do aviso de alvo não resolvido (um por Behavior e por alvo). */
export interface TargetWarning {
  warned: string | null;
}

/**
 * Resolve o alvo por ID estável. ID vazio = câmera sem alvo (`undefined`, sem aviso). ID que não resolve = diagnóstico
 * `camera.target_unresolved` (uma vez) e `undefined`: NUNCA escolhe outro nó.
 */
export function resolveCameraTarget(ctx: BehaviorRuntimeContext, id: string, state: TargetWarning): RuntimeInstance | undefined {
  if (!id) return undefined;
  const target = ctx.getNode(id);
  if (target && !target.disposed) return target;
  if (state.warned !== id) {
    state.warned = id;
    ctx.log('warn', `alvo "${id}" não existe na cena: a câmera fica na pose autoral.`, { code: 'camera.target_unresolved' });
  }
  return undefined;
}

export { nodePosition };
export type { TargetPose };

/** Pose do alvo no espaço pedido (o cálculo mora em `runtime/cameraRig/targetPose`; `world` compõe a hierarquia de pais, `local` lê o transform do nó). */
export const targetPoseOf = (target: RuntimeInstance, space: TargetSpace): TargetPose => computeTargetPose(target, space);

/** Esconde o alvo só no Play (guarda o estado anterior para restaurar); nunca grava no authoring. */
export interface HiddenTarget {
  instance: RuntimeInstance;
  visible: boolean;
  objectVisible: boolean | null;
}

export function hideTarget(target: RuntimeInstance): HiddenTarget {
  const hidden: HiddenTarget = { instance: target, visible: target.visible, objectVisible: target.object ? target.object.visible : null };
  target.visible = false;
  if (target.object) target.object.visible = false;
  return hidden;
}

export function restoreTarget(hidden: HiddenTarget | null): void {
  if (!hidden || hidden.instance.disposed) return;
  hidden.instance.visible = hidden.visible;
  if (hidden.instance.object && hidden.objectVisible !== null) hidden.instance.object.visible = hidden.objectVisible;
}
