/**
 * AIS-44 — helpers dos executores de Action (`actions/<id>/runtime.ts`). Ficam FORA das pastas varridas pelo registry.
 */
import { isOverlayNodeType } from '../runtime/overlay';
import type { RuntimeInstance } from '../runtime/RuntimeScene';
import type { ActionRuntimeContext } from './types';
import { PhysicsBridgeError, type PhysicsBridge } from '../core/physics/PhysicsBridge';

/** Nós de UI (Overlay2D e controles): posição = offsets do layout, não `transform`. */
export const isUiInstance = (instance: RuntimeInstance): boolean => isOverlayNodeType(instance.type);

/** Alvo da Action (`target` vazio = o nó dono). Inexistente → erro explícito no log e `undefined`. */
export function resolveTarget(label: string, ref: unknown, ctx: ActionRuntimeContext): RuntimeInstance | undefined {
  const text = typeof ref === 'string' ? ref.trim() : '';
  const found = ctx.resolve(text);
  if (!found) ctx.log('error', `${label}: o nó alvo "${text}" não existe na cena.`);
  return found;
}

/**
 * AIS-60b — o objeto animado de um alvo: o próprio MeshInstance (`properties.animated`) ou, se o alvo não for animado, o primeiro
 * descendente animado (modelo + peças). Sem objeto animado → erro explícito no log e `undefined`.
 */
export function resolveAnimatedObject(label: string, ref: unknown, ctx: ActionRuntimeContext): RuntimeInstance | undefined {
  const target = resolveTarget(label, ref, ctx);
  if (!target) return undefined;
  const found = findAnimated(target);
  if (!found) ctx.log('error', `${label}: "${target.name}" não é um objeto animado (ligue "Animado" no Inspector ou importe o modelo como Animado).`, { code: 'animation.not_animated' });
  return found;
}

function findAnimated(node: RuntimeInstance): RuntimeInstance | undefined {
  if (!node.disposed && node.type === 'MeshInstance' && node.properties.animated === true) return node;
  for (const child of node.children) {
    const hit = findAnimated(child);
    if (hit) return hit;
  }
  return undefined;
}

/**
 * AIS-76b — alvo das Actions de sprite: um `Billboard` com `spriteProject`. Qualquer outra coisa → erro explícito no log (diagnóstico
 * `sprite.invalid_target`) e `undefined`: a Action é ignorada, sem exceção.
 */
export function resolveSpriteTarget(label: string, ref: unknown, ctx: ActionRuntimeContext): RuntimeInstance | undefined {
  const target = resolveTarget(label, ref, ctx);
  if (!target) return undefined;
  if (target.type !== 'Billboard') {
    ctx.log('error', `${label}: "${target.name}" é um nó ${target.type}; use um Billboard com Sprite Project.`, { code: 'sprite.invalid_target' });
    return undefined;
  }
  const sp = target.properties.spriteProject;
  if (!sp || sp === '') {
    ctx.log('error', `${label}: o Billboard "${target.name}" não tem Sprite Project.`, { code: 'sprite.invalid_target' });
    return undefined;
  }
  return target;
}

/** AIS-78c: falha de serviço da EngineApi → log explícito com o código ESTÁVEL da própria falha (`audio.unavailable`, `tween.failed`…). */
export function logServiceFailure(label: string, ctx: ActionRuntimeContext, failure: { message: string; code: string }): void {
  ctx.log('error', `${label}: ${failure.message}`, { code: failure.code });
}

export const num = (value: unknown, fallback = 0): number => (typeof value === 'number' && Number.isFinite(value) ? value : fallback);

/**
 * AIS-45 — esqueleto das Actions de física: resolve o alvo, exige a ponte física da sessão e traduz `PhysicsBridgeError` em log
 * explícito (corpo ausente, modo incompatível, corpo desligado…). Nunca toca `RigidBody` do Rapier; nunca ignora em silêncio.
 */
export function runPhysics(label: string, target: unknown, ctx: ActionRuntimeContext, fn: (bridge: PhysicsBridge, nodeId: string, instance: RuntimeInstance) => void): void {
  const instance = resolveTarget(label, target, ctx);
  if (!instance) return;
  const bridge = ctx.physics;
  if (!bridge) return ctx.log('error', `${label}: não há mundo físico nesta cena (nenhum nó com "Colisão" ligada, ou o motor ainda está carregando).`, { code: 'physics.no_world' });
  try {
    fn(bridge, instance.persistentNodeId, instance);
  } catch (error) {
    if (error instanceof PhysicsBridgeError) return ctx.log('error', error.message, { code: error.code });
    throw error;
  }
}
