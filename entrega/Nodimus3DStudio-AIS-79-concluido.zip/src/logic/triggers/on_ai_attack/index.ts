import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_ai_attack',
  label: 'On AI Attack',
  description: 'Disparado pelo AI State Machine deste nó a cada Attack Cooldown enquanto está no estado Attack. É aqui que se liga a Action Shoot (ou Apply Damage). Só funciona nas regras de um Behavior AI State Machine.',
  category: 'AI',
  params: [],
});
