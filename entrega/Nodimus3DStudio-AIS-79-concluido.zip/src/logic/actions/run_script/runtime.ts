import type { ActionExecutor } from '../../types';
import { logServiceFailure } from '../../actionRuntimeHelpers';

/**
 * Run Script (AIS-79): chama `engine.scripts.run`, o ÚNICO caminho de execução de código do usuário (Web Worker isolado + EngineApi restrita +
 * Command Buffer validado pelo host). O script roda com o nó dono da regra; o efeito de suas escritas chega no quadro seguinte. Falha vira log
 * com código estável (`script.not_found`, `script.ts_not_supported`, `script.worker_unavailable`…), nunca silêncio.
 */
const run: ActionExecutor<{ scriptRef: string }> = ({ scriptRef }, ctx) => {
  if (!scriptRef) return ctx.log('error', 'Run Script: escolha um script .js de res://scripts/.', { code: 'script.no_script' });
  const result = ctx.engine.scripts.run(scriptRef);
  if (!result.ok) logServiceFailure('Run Script', ctx, result);
};
export default run;
