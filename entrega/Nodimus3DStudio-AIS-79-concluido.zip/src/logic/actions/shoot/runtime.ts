import type { ActionExecutor } from '../../types';
import { distanceBetween } from '../../../runtime/ai/perception';

/**
 * Shoot (AIS-71): atira em UM alvo pelo NÚCLEO de armas da sessão — com Bullet, `weapons.fire` físico; com `hitscan`, `weapons.fire` por raycast;
 * sem Bullet, dano direto por `weapons.damage`. A MESMA porta de `fire_projectile`/`apply_damage`/`weapon_controller`. Sem alvo (nem explícito nem
 * o atual da IA do mesmo nó) ou sem núcleo → falha EXPLÍCITA com código (Actions nunca ignoram em silêncio).
 */

/** Velocidade do projétil da IA (m/s); o alcance acompanha a distância ao alvo. */
const SHOT_SPEED = 30;
const MIN_RANGE = 10;

const run: ActionExecutor<{
  bullet: string;
  damage: number;
  damageVariable: string;
  shootPositionDisplacement: { x: number; y: number; z: number };
  fireMode: 'physical' | 'hitscan';
  target: string;
}> = (p, ctx) => {
  const weapons = ctx.engine.weapons;
  if (!weapons.available()) return ctx.log('error', 'Shoot: o núcleo de armas não está disponível nesta sessão.', { code: 'weapon.unavailable' });
  const shooter = ctx.self;

  const explicit = p.target.trim();
  const target = explicit ? ctx.resolve(explicit) : (() => {
    const id = ctx.engine.ai.currentTarget(shooter.persistentNodeId);
    return id ? ctx.resolve(id) : undefined;
  })();
  if (!target) {
    return ctx.log('error', explicit ? `Shoot: o alvo "${explicit}" não existe na cena.` : `Shoot: "${shooter.name}" não tem alvo (nenhum alvo explícito e o AI State Machine deste nó não tem alvo atual).`, { code: 'shoot.no_target' });
  }

  const damageVariable = p.damageVariable.trim() || 'health';
  if (p.fireMode === 'physical' && !p.bullet.trim()) {
    // sem projétil: só dano direto, pelo mesmo contrato de dano
    weapons.damage({ sourceId: shooter.persistentNodeId, targetId: target.persistentNodeId, amount: p.damage, variable: damageVariable });
    return;
  }
  const distance = distanceBetween(shooter, target);
  const result = weapons.fire({
    sourceId: shooter.persistentNodeId,
    mode: p.fireMode,
    aimTarget: target.persistentNodeId,
    originOffset: p.shootPositionDisplacement,
    bullet: p.bullet,
    speed: SHOT_SPEED,
    damage: p.damage,
    damageVariable,
    range: Number.isFinite(distance) ? Math.max(MIN_RANGE, distance * 2) : MIN_RANGE * 5,
    rangeMode: 'distance',
    lifetimeMs: 3000,
    facesMotion: true,
    collisionDestroyDelayMs: 0,
  });
  if (!result.ok) ctx.log('error', result.message, { code: result.code });
};
export default run;
