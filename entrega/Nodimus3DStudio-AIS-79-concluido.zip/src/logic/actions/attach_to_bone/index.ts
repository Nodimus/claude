import { z } from 'zod';
import { defineAction } from '../../types';
import { fail, OK, vec3Schema } from '../../actionHelpers';

export default defineAction({
  id: 'attach_to_bone',
  label: 'Attach To Bone',
  description: 'Prende o nó a um osso do esqueleto de um modelo 3D (arma na mão). Só durante o Play; a posição passa a ser local ao osso.',
  category: 'Visual',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'holder', label: 'Model (holder)', type: 'node', default: '' },
    { key: 'bone', label: 'Bone', type: 'string', default: '', required: true },
    { key: 'offset', label: 'Local Offset', type: 'vector3', default: { x: 0, y: 0, z: 0 } },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    holder: z.string().default(''),
    bone: z.string().default(''),
    offset: vec3Schema(0, 0, 0),
  }),
  validate: (params) => (params.bone.trim() ? OK : fail('attachment.no_bone', 'Attach To Bone: informe o nome do osso.')),
});
