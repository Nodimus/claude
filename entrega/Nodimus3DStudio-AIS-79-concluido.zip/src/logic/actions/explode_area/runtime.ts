import type { ActionExecutor } from '../../types';
import { parseTagList } from '../../../runtime/weapons/tags';

/** Explosão pelo núcleo único (`WeaponService.explode` → `explodeArea`): overlap + dano + impulso, uma vez por alvo. */
const run: ActionExecutor<{ center: string; radius: number; damage: number; damageVariable: string; impulse: number; ignoreTags: string; onlyTags: string }> = (p, ctx) => {
  const result = ctx.engine.weapons.explode({
    sourceId: ctx.self.persistentNodeId,
    center: p.center,
    radius: p.radius,
    damage: p.damage,
    damageVariable: p.damageVariable,
    impulse: p.impulse,
    ignoreTags: parseTagList(p.ignoreTags),
    onlyTags: parseTagList(p.onlyTags),
  });
  if ('ok' in result && result.ok === false) ctx.log('error', `Explode Area: ${result.message}`, { code: result.code });
};
export default run;
