import { z } from 'zod';
import { GameNodeV1Schema } from './v1/node.schema';
import { PostProcessingSettingsV1Schema, SceneFogSettingsV1Schema } from './v1/scene.schema';
import { CURRENT_SCENE_SCHEMA_VERSION } from '../core/persistenceVersions';

/**
 * Zod schema for canonical ResourceRef
 * Serves as the cross-document contract preserving identity independent of path.
 */
export const ResourceRefSchema = z
  .object({
    id: z.string().min(1, 'ResourceRef ID is required'),
    type: z.string().optional(),
    path: z.string().optional(),
    label: z.string().optional(),
    unresolved: z.boolean().optional(),
  })
  .passthrough();

/**
 * v4.7.0 — the project-addon system was removed. Legacy files may still carry
 * `source: 'addon'`; it is read as `'custom'` and any legacy extra field
 * (e.g. `addonId`) is kept untouched by `.passthrough()` — never discarded.
 */
const legacyAddonSource = (v: unknown) => (v === 'addon' ? 'custom' : v);

/**
 * Zod schema for persisted behavior instance:
 * { id, contributionId, source, properties }
 * `contributionId` = folder name in `src/logic/behaviors/<id>/`.
 * Preserves unknown/legacy data without discarding (.passthrough()).
 */
export const PersistedBehaviorInstanceSchema = z
  .object({
    id: z.string().min(1, 'Behavior occurrence ID is required'),
    contributionId: z.string().min(1, 'Behavior contributionId is required'),
    source: z.preprocess(legacyAddonSource, z.enum(['builtin', 'custom', 'script'])).default('builtin'),
    properties: z.record(z.string(), z.unknown()).default({}),
  })
  .passthrough();

/**
 * Zod schema for persisted action instance
 */
export const PersistedActionInstanceSchema = z
  .object({
    id: z.string().min(1, 'Action occurrence ID is required'),
    contributionId: z.string().min(1, 'Action contributionId is required'),
    source: z.preprocess(legacyAddonSource, z.enum(['builtin', 'custom'])).default('builtin'),
    parameters: z.record(z.string(), z.unknown()).default({}),
  })
  .passthrough();

/**
 * Scene settings within *.scene.json
 */
export const SceneSettingsFileSchema = z
  .object({
    environment: z
      .object({
        ambientColor: z.string().default('#334155'),
        ambientIntensity: z.number().default(0.45),
        backgroundColor: z.string().default('#141822'),
        realtimeShadows: z.boolean().default(true),
        gravity: z.object({ x: z.number(), y: z.number(), z: z.number() }).default({ x: 0, y: -9.8, z: 0 }),
        wind: z.object({ x: z.number(), y: z.number(), z: z.number() }).default({ x: 0, y: 0, z: 0 }),
      })
      .optional(),
    cameraSettings: z
      .object({
        fov: z.number().default(65),
        near: z.number().default(0.1),
        far: z.number().default(1000),
        position: z.object({ x: z.number(), y: z.number(), z: z.number() }).default({ x: 0, y: 3, z: 8 }),
        target: z.object({ x: z.number(), y: z.number(), z: z.number() }).default({ x: 0, y: 0, z: 0 }),
        // AIS-74: Travar View da câmera de edição, por cena
        viewLock: z.object({ locked: z.boolean(), theta: z.number(), phi: z.number() }).optional(),
      })
      .optional(),
    postProcessing: PostProcessingSettingsV1Schema.optional(),
    fog: SceneFogSettingsV1Schema.optional(),
  })
  .passthrough();

/**
 * Schema for *.scene.json
 *
 * Enforces:
 * 1. Root node must exist in `nodes`.
 * 2. Hierarchy is strictly rootNodeId + nodes + parentId (NO parallel collections layers/instances).
 * 3. Preserves unknown/legacy properties without discarding.
 */
export const SceneFileSchema = z
  .object({
    schemaVersion: z.number().int().min(1, 'schemaVersion must be an integer >= 1').default(CURRENT_SCENE_SCHEMA_VERSION),
    sceneId: z.string().min(1, 'sceneId is required and must be a stable UUID'),
    name: z.string().min(1, 'Scene name is required'),
    rootNodeId: z.string().min(1, 'rootNodeId is required'),
    environmentNodeId: z.string().nullable().optional(),
    nodes: z
      .record(z.string(), GameNodeV1Schema)
      .refine((nodes) => Object.keys(nodes).length > 0, {
        message: 'Scene must contain at least one node (the root node)',
      }),
    sceneSettings: SceneSettingsFileSchema.optional(),
    metadata: z.record(z.string(), z.unknown()).optional().default({}),
    createdAt: z.string().optional().default(() => new Date().toISOString()),
    updatedAt: z.string().optional().default(() => new Date().toISOString()),
  })
  .superRefine((data, ctx) => {
    // Structural integrity: root node must be present in nodes table
    if (!data.nodes[data.rootNodeId]) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: `rootNodeId "${data.rootNodeId}" does not exist in the nodes table`,
        path: ['rootNodeId'],
      });
    }

    // Structural integrity: Environment node (if specified) must exist in nodes table
    if (data.environmentNodeId && !data.nodes[data.environmentNodeId]) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: `environmentNodeId "${data.environmentNodeId}" does not exist in the nodes table`,
        path: ['environmentNodeId'],
      });
    }

    // Verify parent references
    for (const [id, node] of Object.entries(data.nodes)) {
      if (node.parentId !== null && !data.nodes[node.parentId]) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Node "${id}" references non-existent parentId "${node.parentId}"`,
          path: ['nodes', id, 'parentId'],
        });
      }
    }
  })
  .passthrough();

export type SceneFileValidated = z.infer<typeof SceneFileSchema>;
export type ResourceRefValidated = z.infer<typeof ResourceRefSchema>;
export type PersistedBehaviorInstanceValidated = z.infer<typeof PersistedBehaviorInstanceSchema>;
export type PersistedActionInstanceValidated = z.infer<typeof PersistedActionInstanceSchema>;
