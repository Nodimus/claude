import { z } from 'zod';
import { ResourceRefSchema } from '../sceneSchema';
import { ColorV1Schema } from './node.schema';

/**
 * AIS-35 — `ModelMaterialManifest` (`res://textures/<asset>_material.json`, Zod v1; decisão 3). Descreve o que foi extraído do
 * arquivo 3D no import: um item por material (chave = nome no arquivo), com os canais PBR, os filtros e as texturas como
 * `ResourceRef` (PNG em `res://textures/<asset>/`), NUNCA base64. Não substitui o material autoral `.mat.json` do AIS-25.
 */
export const MaterialFiltersSchema = z.object({
  brightness: z.number().default(1),
  contrast: z.number().default(1),
  saturation: z.number().default(1),
  hueShift: z.number().default(0),
});

export const ManifestMapsSchema = z.object({
  albedo: ResourceRefSchema.optional(),
  normal: ResourceRefSchema.optional(),
  roughness: ResourceRefSchema.optional(),
  metalness: ResourceRefSchema.optional(),
  emissive: ResourceRefSchema.optional(),
  /** Máscara de opacidade (atlas de folhagem/sprites da biblioteca). */
  opacity: ResourceRefSchema.optional(),
});

const NEUTRAL_COLOR = { r: 1, g: 1, b: 1, a: 1 };
const BLACK = { r: 0, g: 0, b: 0, a: 1 };

export const ManifestMaterialSchema = z.object({
  name: z.string(),
  source: z.enum(['embedded', 'procedural', 'file']).default('embedded'),
  color: ColorV1Schema.default(NEUTRAL_COLOR),
  roughness: z.number().default(1),
  metalness: z.number().default(0),
  emissiveColor: ColorV1Schema.default(BLACK),
  emissiveIntensity: z.number().default(0),
  uvTiling: z.tuple([z.number(), z.number()]).default([1, 1]),
  filters: MaterialFiltersSchema.default({ brightness: 1, contrast: 1, saturation: 1, hueShift: 0 }),
  maps: ManifestMapsSchema.default({}),
  /** Atlas (biblioteca): retângulos UV [u0, v0, u1, v1] de cada folha/elemento. */
  atlas: z.object({ cells: z.array(z.tuple([z.number(), z.number(), z.number(), z.number()])).default([]) }).optional(),
});

export const ModelMaterialManifestSchema = z.object({
  schemaVersion: z.literal(1).default(1),
  asset: ResourceRefSchema,
  materials: z.array(ManifestMaterialSchema).default([]),
});

export type ModelMaterialManifest = z.infer<typeof ModelMaterialManifestSchema>;
export type ManifestMaterial = z.infer<typeof ManifestMaterialSchema>;
export type MaterialFilters = z.infer<typeof MaterialFiltersSchema>;

export type ManifestParseResult =
  | { ok: true; manifest: ModelMaterialManifest; legacy: boolean; dropped: number }
  | { ok: false; error: string };

/**
 * Leitura tolerante: material inválido é descartado (e contado em `dropped`), o resto é mantido; manifesto sem
 * `schemaVersion` (formato antigo, ad-hoc) é aceito como `legacy` quando traz `asset` e `materials`. Nunca lança.
 */
export function parseModelMaterialManifest(raw: unknown): ManifestParseResult {
  let value: unknown = raw;
  if (typeof raw === 'string') {
    try {
      value = JSON.parse(raw);
    } catch {
      return { ok: false, error: 'JSON inválido' };
    }
  }
  if (!value || typeof value !== 'object' || Array.isArray(value)) return { ok: false, error: 'o manifesto precisa ser um objeto' };
  const source = value as Record<string, unknown>;
  const legacy = source.schemaVersion === undefined;
  const asset = ResourceRefSchema.safeParse(source.asset);
  if (!asset.success) return { ok: false, error: 'o manifesto não referencia o modelo (asset)' };
  const list = Array.isArray(source.materials) ? source.materials : [];
  const materials: ManifestMaterial[] = [];
  let dropped = 0;
  for (const item of list) {
    const parsed = ManifestMaterialSchema.safeParse(item);
    if (parsed.success) materials.push(parsed.data);
    else dropped++;
  }
  return { ok: true, manifest: { schemaVersion: 1, asset: asset.data, materials }, legacy, dropped };
}
