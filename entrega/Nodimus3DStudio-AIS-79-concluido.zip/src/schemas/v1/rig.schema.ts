import { z } from 'zod';
import { ResourceRefSchema } from '../sceneSchema';

/**
 * AIS-36 — `RigConfig` (`res://materials/<asset>_rig.json`, Zod v1; decisão 1). Guarda só o MAPEAMENTO dos ossos do arquivo para o
 * esqueleto padrão de 19 ossos (Mixamo/Godot Humanoid) — nunca keyframes (decisão 27). `clips` é preenchido pelo AIS-37 com
 * referências. Os 19 ossos canônicos vivem aqui (única lista); `src/runtime/skeletalAnimation.ts` os reexporta.
 */
export const CANONICAL_BONES = [
  'Hips',
  'Spine',
  'Chest',
  'Neck',
  'Head',
  'LeftShoulder',
  'LeftArm',
  'LeftForeArm',
  'LeftHand',
  'RightShoulder',
  'RightArm',
  'RightForeArm',
  'RightHand',
  'LeftUpLeg',
  'LeftLeg',
  'LeftFoot',
  'RightUpLeg',
  'RightLeg',
  'RightFoot',
] as const;

export type CanonicalBone = (typeof CANONICAL_BONES)[number];

export type BoneMap = Record<CanonicalBone, string | null>;

/** Mapa vazio (nenhum osso encontrado). */
export const emptyBoneMap = (): BoneMap => Object.fromEntries(CANONICAL_BONES.map((b) => [b, null])) as BoneMap;

const BoneMapSchema = z.object(Object.fromEntries(CANONICAL_BONES.map((b) => [b, z.string().nullable().default(null)])) as Record<CanonicalBone, z.ZodDefault<z.ZodNullable<z.ZodString>>>);

/** Clipe da biblioteca (preenchido pelo AIS-37): referência, nunca keyframes. Campos extras preservados. */
export const RigClipSchema = z
  .object({
    name: z.string(),
    /** Arquivo de origem (o modelo, para clipes embutidos; ou um arquivo só de animação em `res://models/`). */
    source: ResourceRefSchema.optional(),
    /** Nome do clipe dentro do arquivo de origem. */
    sourceClip: z.string().optional(),
    loop: z.boolean().optional(),
    inPlace: z.boolean().optional(),
  })
  .passthrough();

export const RigConfigSchema = z.object({
  schemaVersion: z.literal(1).default(1),
  asset: ResourceRefSchema,
  standard: z.literal('humanoid19').default('humanoid19'),
  bones: BoneMapSchema,
  clips: z.array(RigClipSchema).default([]),
});

export type RigConfig = z.infer<typeof RigConfigSchema>;
export type RigClip = z.infer<typeof RigClipSchema>;

export type RigParseResult = { ok: true; rig: RigConfig; legacy: boolean } | { ok: false; error: string };

/**
 * Leitura tolerante: osso desconhecido/ilegível volta a `null` (nunca lança); chaves extras são ignoradas; `schemaVersion`
 * ausente = formato antigo (`legacy`). Sem `asset` não há como ligar o rig ao modelo: erro tipado.
 */
export function parseRigConfig(raw: unknown): RigParseResult {
  let value: unknown = raw;
  if (typeof raw === 'string') {
    try {
      value = JSON.parse(raw);
    } catch {
      return { ok: false, error: 'JSON inválido' };
    }
  }
  if (!value || typeof value !== 'object' || Array.isArray(value)) return { ok: false, error: 'o rig precisa ser um objeto' };
  const source = value as Record<string, unknown>;
  const asset = ResourceRefSchema.safeParse(source.asset);
  if (!asset.success) return { ok: false, error: 'o rig não referencia o modelo (asset)' };
  const bones = emptyBoneMap();
  const rawBones = source.bones && typeof source.bones === 'object' && !Array.isArray(source.bones) ? (source.bones as Record<string, unknown>) : {};
  for (const bone of CANONICAL_BONES) if (typeof rawBones[bone] === 'string' && rawBones[bone]) bones[bone] = rawBones[bone] as string;
  const clips = (Array.isArray(source.clips) ? source.clips : []).flatMap((c) => {
    const parsed = RigClipSchema.safeParse(c);
    return parsed.success ? [parsed.data] : [];
  });
  return { ok: true, legacy: source.schemaVersion === undefined, rig: { schemaVersion: 1, asset: asset.data, standard: 'humanoid19', bones, clips } };
}
