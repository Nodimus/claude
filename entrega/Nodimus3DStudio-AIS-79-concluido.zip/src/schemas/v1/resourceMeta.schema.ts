import { z } from 'zod';

/**
 * AIS-30c (decisão 29) — `<arquivo>.meta`: metadados de UM recurso do projeto em disco (estilo Godot/Unity). Guarda o que hoje vive em
 * `VirtualFile` além do conteúdo: identidade persistente (`resourceId`, que acompanha o arquivo ao mover/renomear), o importador e as
 * configurações de import. Conteúdo do arquivo nunca entra aqui. Zod v1, leitura tolerante: chaves desconhecidas são preservadas.
 */
export const ResourceMetaSchema = z
  .object({
    schemaVersion: z.literal(1).default(1),
    resourceId: z.string().min(1),
    importerId: z.string().optional(),
    importerVersion: z.number().optional(),
    importSettings: z.record(z.string(), z.unknown()).optional(),
    contentHash: z.string().optional(),
  })
  .passthrough();

export type ResourceMeta = z.infer<typeof ResourceMetaSchema>;

export type ResourceMetaParse = { ok: true; meta: ResourceMeta } | { ok: false; error: string };

/** Lê o texto do `.meta`. Nunca lança: `ok:false` diz por quê (JSON ilegível, sem `resourceId`…). */
export function parseResourceMeta(text: string): ResourceMetaParse {
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch (e) {
    return { ok: false, error: `JSON ilegível (${(e as Error).message})` };
  }
  const parsed = ResourceMetaSchema.safeParse(raw);
  if (!parsed.success) return { ok: false, error: parsed.error.issues.map((i) => `${i.path.join('.') || 'raiz'}: ${i.message}`).join('; ') };
  return { ok: true, meta: parsed.data };
}

export const RESOURCE_META_SUFFIX = '.meta';

/** Texto do `.meta` (formato estável, 2 espaços). */
export function serializeResourceMeta(meta: ResourceMeta): string {
  return JSON.stringify({ ...meta, schemaVersion: 1 }, null, 2) + '\n';
}
