import { z } from 'zod';

/**
 * AIS-68 — preset de água em `res://materials/<nome>_water.json` (Zod v1, sem base64). É um recurso de APARÊNCIA reutilizável: o nó
 * `WaterPlane` guarda seus próprios campos (fonte da verdade) e "Aplicar preset" apenas os preenche (um Command). Leitura tolerante.
 */
const channel = z.number().min(0).max(1);

export const WaterPresetFileSchema = z.object({
  schemaVersion: z.literal(1).default(1),
  type: z.literal('water').default('water'),
  name: z.string().default(''),
  params: z.object({
    color: z.object({ r: channel, g: channel, b: channel, a: channel.optional() }),
    transparency: channel,
    waveScale: z.number().min(0.05).max(20),
    waveSpeed: z.number().min(0).max(10),
    waveStrength: z.number().min(0).max(10),
    flowDirection: z.number(),
    reflectionMode: z.enum(['planar', 'environment', 'off']),
    reflectionIntensity: channel,
    reflectionResolution: z.union([z.literal(256), z.literal(512), z.literal(1024)]),
  }),
});

export type WaterPresetFile = z.infer<typeof WaterPresetFileSchema>;

export type WaterPresetParse = { ok: true; preset: WaterPresetFile } | { ok: false; error: string };

export function parseWaterPreset(text: string): WaterPresetParse {
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch (error) {
    return { ok: false, error: `JSON inválido (${error instanceof Error ? error.message : String(error)})` };
  }
  const parsed = WaterPresetFileSchema.safeParse(raw);
  return parsed.success ? { ok: true, preset: parsed.data } : { ok: false, error: parsed.error.issues[0] ? `${parsed.error.issues[0].path.join('.')}: ${parsed.error.issues[0].message}` : 'formato inválido' };
}

export const serializeWaterPreset = (preset: WaterPresetFile): string => JSON.stringify(preset, null, 2);
