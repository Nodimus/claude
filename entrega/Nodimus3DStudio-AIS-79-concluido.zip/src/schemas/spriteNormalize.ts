import type { ResourceRef } from '../types/node';
import type { LoopMode, SpriteAnimation, SpriteFrame, SpriteProject } from '../types/sprite';
import { CURRENT_SPRITE_SCHEMA_VERSION } from '../core/persistenceVersions';
import { createEmptySpriteProject } from '../utils/spritePresets';
import { SpriteProjectV1Schema } from './v1/sprite.schema';

/**
 * AIS-76 (decisão 24, §3.3) — leitura/gravação do `*.sprite.json`. Lê os TRÊS formatos legados e o v1, sempre devolvendo um `SpriteProject`
 * v1 sem perder dados; grava só o v1 (sem `imageUrl`/`customDataUrl`: base64 nunca vai para JSON). Puro (sem DOM): roda em Node.
 *
 *  1. `full`   — `SpriteProject` completo da casca (com `imageUrl`/`customDataUrl` embutidos): os data URLs viram ESTADO DE SESSÃO (`session`)
 *                e o chamador os grava no atlas PNG; o JSON seguinte nasce sem base64.
 *  2. `sample` — amostra do `defaultProject` (`texturePath`, `frameWidth/Height`, `frameCount`, `fps`, `loop`, `animations` como mapa).
 *  3. `stub`   — o "Novo Sprite" antigo (sem `id`, `frames`, `settings3D`, `imageUrl`): completado com os padrões do projeto vazio.
 *  4. `v1`     — o formato canônico. Versão MAIOR que a atual: preservada e SOMENTE LEITURA (nunca rebaixada).
 */

export type SpriteSourceFormat = 'v1' | 'full' | 'sample' | 'stub';

/** Estado de sessão extraído de um formato legado (data URLs que devem ir para o atlas PNG, nunca para o JSON). */
export interface SpriteSessionImages {
  atlas?: string;
  /** `frame.id` → data URL dos pixels editados. */
  frames: Record<string, string>;
}

export type SpriteLoadResult =
  | { ok: true; project: SpriteProject; format: SpriteSourceFormat; readOnly: boolean; warnings: string[]; session: SpriteSessionImages }
  | { ok: false; error: string };

const isRecord = (v: unknown): v is Record<string, any> => !!v && typeof v === 'object' && !Array.isArray(v);
const num = (v: unknown, fallback: number): number => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);
const posInt = (v: unknown, fallback: number): number => Math.max(1, Math.floor(num(v, fallback)));
const isDataUrl = (v: unknown): v is string => typeof v === 'string' && v.startsWith('data:');
const loopOf = (v: unknown): LoopMode => (v === 'once' || v === 'ping-pong' || v === 'loop' ? v : 'loop');

/** `ResourceRef` estável por caminho para uma textura (o editor troca por `refForUri` quando o recurso existe no registry). */
export const textureRefForPath = (path: string): ResourceRef => ({ id: `res:${path}`, type: 'texture', path, label: path.split('/').pop() || path });

/** Regiões do atlas em grade (linha por linha), como o `Convert to Frames` do Godot. */
export function gridFrames(columns: number, rows: number, fw: number, fh: number, spacing = 0, margin = 0, count = columns * rows): SpriteFrame[] {
  const frames: SpriteFrame[] = [];
  for (let i = 0; i < Math.min(count, columns * rows); i++) {
    const c = i % columns;
    const r = Math.floor(i / columns);
    frames.push({ id: `frame_${i}`, index: i, x: margin + c * (fw + spacing), y: margin + r * (fh + spacing), width: fw, height: fh });
  }
  return frames;
}

function describeIssues(error: { issues: { path: PropertyKey[]; message: string }[] }): string {
  return error.issues
    .slice(0, 4)
    .map((i) => `${i.path.map(String).join('.') || 'raiz'}: ${i.message}`)
    .join('; ');
}

/** Completa/ordena um projeto já em forma v1: animação ativa válida, ao menos uma animação, índices dentro dos frames. */
function finalize(project: SpriteProject, warnings: string[]): SpriteProject {
  const out: SpriteProject = { ...project, schemaVersion: CURRENT_SPRITE_SCHEMA_VERSION };
  if (out.animations.length === 0 && out.frames.length > 0) {
    out.animations = [{ id: 'anim_default', name: 'default', frameIndices: out.frames.map((_, i) => i), fps: 8, loopMode: 'loop' }];
    warnings.push('O sprite não tinha animações: foi criada "default" com todos os frames.');
  }
  if (!out.animations.some((a) => a.id === out.activeAnimationId)) out.activeAnimationId = out.animations[0]?.id ?? '';
  const total = out.frames.length;
  if (total > 0 && out.animations.some((a) => a.frameIndices.some((i) => i >= total))) warnings.push('Alguma animação aponta para um frame que não existe (preservado; ajuste na timeline).');
  return out;
}

function fromAnimationsMap(map: unknown, fps: number, loop: boolean, frameCount: number): SpriteAnimation[] {
  const list: SpriteAnimation[] = [];
  if (isRecord(map)) {
    for (const [name, def] of Object.entries(map)) {
      if (!isRecord(def)) continue;
      const start = Math.max(0, Math.floor(num(def.startFrame, 0)));
      const end = Math.max(start, Math.floor(num(def.endFrame, frameCount - 1)));
      const indices: number[] = [];
      for (let i = start; i <= end; i++) indices.push(i);
      list.push({ id: `anim_${name}`, name, frameIndices: indices, fps: Math.max(0.1, num(def.fps, fps)), loopMode: def.loop === false ? 'once' : def.loop === true ? 'loop' : loopOf(def.loopMode ?? (loop ? 'loop' : 'once')) });
    }
  }
  return list;
}

function normalizeSample(raw: Record<string, any>, warnings: string[]): SpriteProject {
  const fw = posInt(raw.frameWidth, 32);
  const fh = posInt(raw.frameHeight, 32);
  const count = posInt(raw.frameCount, 1);
  const name = typeof raw.name === 'string' && raw.name ? raw.name : 'Sprite';
  const base = createEmptySpriteProject(name, fw);
  const fps = Math.max(0.1, num(raw.fps, 8));
  const loop = raw.loop !== false;
  // o layout real do atlas só se conhece ao carregar a imagem: até lá assume uma linha (o editor reajusta com `imageWidth = 0`)
  const frames = gridFrames(count, 1, fw, fh);
  let animations = fromAnimationsMap(raw.animations, fps, loop, count);
  if (animations.length === 0) animations = [{ id: 'anim_default', name: 'default', frameIndices: frames.map((_, i) => i), fps, loopMode: loop ? 'loop' : 'once' }];
  warnings.push('Formato de amostra convertido: o atlas é lido como uma linha de frames até a imagem ser carregada.');
  return {
    ...base,
    name,
    sheetConfig: {
      ...base.sheetConfig,
      name,
      ...(typeof raw.texturePath === 'string' && raw.texturePath ? { texture: textureRefForPath(raw.texturePath) } : {}),
      imageWidth: 0,
      imageHeight: 0,
      frameWidth: fw,
      frameHeight: fh,
      columns: count,
      rows: 1,
      totalFrames: count,
    },
    frames,
    animations,
    activeAnimationId: animations[0].id,
  };
}

function normalizeStub(raw: Record<string, any>, warnings: string[]): SpriteProject {
  const name = typeof raw.name === 'string' && raw.name ? raw.name : 'Sprite';
  const cfg = isRecord(raw.sheetConfig) ? raw.sheetConfig : {};
  const fw = posInt(cfg.frameWidth, 32);
  const fh = posInt(cfg.frameHeight, 32);
  const columns = posInt(cfg.columns, 1);
  const rows = posInt(cfg.rows, 1);
  const base = createEmptySpriteProject(name, fw);
  const frames = gridFrames(columns, rows, fw, fh, num(cfg.spacing, 0), num(cfg.margin, 0));
  const animations: SpriteAnimation[] = Array.isArray(raw.animations)
    ? raw.animations
        .filter((a: any) => isRecord(a) && Array.isArray(a.frameIndices))
        .map((a: any, i: number) => ({
          id: typeof a.id === 'string' && a.id ? a.id : `anim_${i}`,
          name: typeof a.name === 'string' && a.name ? a.name : `anim_${i}`,
          frameIndices: a.frameIndices.filter((n: unknown) => Number.isInteger(n) && (n as number) >= 0),
          fps: Math.max(0.1, num(a.fps, 8)),
          loopMode: loopOf(a.loopMode),
        }))
    : [];
  warnings.push('Stub de "Novo Sprite" completado com os padrões do projeto vazio.');
  return {
    ...base,
    name,
    sheetConfig: { ...base.sheetConfig, name, frameWidth: fw, frameHeight: fh, columns, rows, imageWidth: columns * fw, imageHeight: rows * fh, totalFrames: frames.length },
    frames,
    animations: animations.length ? animations : base.animations,
    activeAnimationId: animations[0]?.id ?? base.activeAnimationId,
  };
}

/** Formato `SpriteProject` completo da casca: separa os data URLs (sessão) do que é persistível. */
function normalizeFull(raw: Record<string, any>, session: SpriteSessionImages, warnings: string[]): SpriteProject | string {
  const name = typeof raw.name === 'string' && raw.name ? raw.name : 'Sprite';
  const base = createEmptySpriteProject(name, posInt(raw.sheetConfig?.frameWidth, 32));
  const cfgIn = isRecord(raw.sheetConfig) ? raw.sheetConfig : {};
  const { imageUrl, ...cfgRest } = cfgIn;
  if (isDataUrl(imageUrl)) session.atlas = imageUrl;
  const frames: SpriteFrame[] = (Array.isArray(raw.frames) ? raw.frames : []).map((f: any, i: number) => {
    const { customDataUrl, ...rest } = isRecord(f) ? f : ({} as Record<string, any>);
    const id = typeof rest.id === 'string' && rest.id ? rest.id : `frame_${i}`;
    if (isDataUrl(customDataUrl)) session.frames[id] = customDataUrl;
    return { id, index: Math.max(0, Math.floor(num(rest.index, i))), x: num(rest.x, 0), y: num(rest.y, 0), width: posInt(rest.width, base.sheetConfig.frameWidth), height: posInt(rest.height, base.sheetConfig.frameHeight), ...(typeof rest.durationMs === 'number' ? { durationMs: rest.durationMs } : {}) };
  });
  const candidate = {
    ...raw,
    schemaVersion: CURRENT_SPRITE_SCHEMA_VERSION,
    id: typeof raw.id === 'string' && raw.id ? raw.id : base.id,
    name,
    sheetConfig: { ...base.sheetConfig, ...cfgRest, imageWidth: num(cfgRest.imageWidth, 0), imageHeight: num(cfgRest.imageHeight, 0) },
    frames,
    animations: Array.isArray(raw.animations) ? raw.animations : [],
  };
  delete (candidate.sheetConfig as any).imageUrl;
  const parsed = SpriteProjectV1Schema.safeParse(candidate);
  if (!parsed.success) return describeIssues(parsed.error);
  if (Object.keys(session.frames).length || session.atlas) warnings.push('Imagens embutidas (base64) foram separadas do JSON: serão gravadas no atlas PNG ao salvar.');
  return parsed.data as unknown as SpriteProject;
}

export function normalizeSprite(raw: unknown): SpriteLoadResult {
  if (!isRecord(raw)) return { ok: false, error: 'O arquivo de sprite não é um objeto JSON.' };
  const warnings: string[] = [];
  const session: SpriteSessionImages = { frames: {} };

  const version = raw.schemaVersion;
  if (typeof version === 'number' && version >= 1) {
    if (version > CURRENT_SPRITE_SCHEMA_VERSION) {
      const parsed = SpriteProjectV1Schema.safeParse({ ...raw, schemaVersion: CURRENT_SPRITE_SCHEMA_VERSION });
      if (!parsed.success) return { ok: false, error: `Sprite de versão futura (${version}) ilegível: ${describeIssues(parsed.error)}` };
      return { ok: true, project: { ...(parsed.data as unknown as SpriteProject), schemaVersion: version }, format: 'v1', readOnly: true, warnings: [`Sprite criado por uma versão mais nova do editor (schema ${version} > ${CURRENT_SPRITE_SCHEMA_VERSION}): aberto somente para leitura, nada será regravado.`], session };
    }
    const parsed = SpriteProjectV1Schema.safeParse(raw);
    if (!parsed.success) return { ok: false, error: `Sprite inválido: ${describeIssues(parsed.error)}` };
    return { ok: true, project: finalize(parsed.data as unknown as SpriteProject, warnings), format: 'v1', readOnly: false, warnings, session };
  }

  let project: SpriteProject | string;
  let format: SpriteSourceFormat;
  if (isRecord(raw.sheetConfig) && Array.isArray(raw.frames)) {
    format = 'full';
    project = normalizeFull(raw, session, warnings);
  } else if (isRecord(raw.sheetConfig)) {
    format = 'stub';
    project = normalizeStub(raw, warnings);
  } else if (typeof raw.texturePath === 'string' || (raw.frameWidth !== undefined && (raw.frameCount !== undefined || raw.animations !== undefined))) {
    format = 'sample';
    project = normalizeSample(raw, warnings);
  } else {
    return { ok: false, error: 'Formato de sprite não reconhecido (esperado SpriteProject v1, SpriteProject completo, amostra com "texturePath" ou stub com "sheetConfig").' };
  }
  if (typeof project === 'string') return { ok: false, error: `Sprite inválido: ${project}` };
  return { ok: true, project: finalize(project, warnings), format, readOnly: false, warnings, session };
}

/** Texto → `SpriteLoadResult`. JSON ilegível devolve erro (o arquivo nunca é tocado). */
export function parseSpriteJson(text: string): SpriteLoadResult {
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch (error) {
    return { ok: false, error: `JSON inválido (${error instanceof Error ? error.message : String(error)})` };
  }
  return normalizeSprite(raw);
}

/** Forma PERSISTIDA do projeto: v1 sem `imageUrl`/`customDataUrl`. Lança se o projeto da sessão estiver inconsistente. */
export function toPersistedSprite(project: SpriteProject): Record<string, unknown> {
  const parsed = SpriteProjectV1Schema.safeParse({ ...project, schemaVersion: CURRENT_SPRITE_SCHEMA_VERSION });
  if (!parsed.success) throw new Error(`Sprite inválido: ${describeIssues(parsed.error)}`);
  return parsed.data as unknown as Record<string, unknown>;
}

export const serializeSprite = (project: SpriteProject): string => JSON.stringify(toPersistedSprite(project), null, 2);
