import { ProjectSettings, InputAction, RendererType } from './project';
import { DEFAULT_DEADZONE, defaultProjectActions } from '../core/inputMap';
import { CURRENT_PROJECT_SCHEMA_VERSION } from '../core/persistenceVersions';

/**
 * Scene reference inside project.json
 */
export interface ProjectSceneEntry {
  /** Stable UUID/nanoid for the scene — survives file rename/move */
  id: string;
  /** Human-readable display name */
  name: string;
  /** Normalized project-relative path, e.g. "res://scenes/Main.scene.json" */
  path: string;
  /** Optional flag indicating whether this is the initial scene */
  isStartScene?: boolean;
}

/**
 * Global variable registered at project level
 */
export interface ProjectGlobalVariable {
  /** Stable UUID for the global variable */
  id: string;
  /** Variable identifier in scripts and visual logic */
  name: string;
  /** Type identifier */
  type: 'string' | 'number' | 'boolean' | 'vector2' | 'vector3' | 'color' | 'any';
  /** Default value */
  value: any;
  /** Optional description */
  description?: string;
}

/**
 * Canonical contract for `project.json`
 * All paths MUST be normalized relative to the project root (using "res://" or relative path).
 * Absolute operating system paths (e.g. "C:\...", "/home/...") are prohibited.
 */
export interface ProjectFile {
  /** Integer schema version (always 1 for V1) */
  schemaVersion: number;
  /** Globally unique, stable project UUID */
  projectId: string;
  /** Project display name */
  name: string;
  /** Application bundle identifier (e.g. "com.studio.mygame") */
  appId: string;
  /** Engine version that authored this file */
  engineVersion: string;
  /** Stable ID of the scene launched at game start */
  startSceneId: string;
  /** List of scene references in the project */
  scenes: ProjectSceneEntry[];
  /** Global variables accessible across scenes */
  globalVariables: ProjectGlobalVariable[];
  /** Input action mapping */
  inputMap: Record<string, InputAction> | InputAction[];
  /** Project-wide runtime & display configuration */
  settings: ProjectSettings;
  /** Optional metadata and tags */
  metadata?: Record<string, unknown>;
  /** Timestamp when project was created */
  createdAt?: string;
  /** Timestamp of last update */
  updatedAt?: string;
}

/**
 * Helper to build a clean default ProjectFile
 */
export function createDefaultProjectFile(name = 'New Nodimus Project', startSceneId = 'scene_main'): ProjectFile {
  return {
    schemaVersion: CURRENT_PROJECT_SCHEMA_VERSION,
    projectId: 'proj_' + Math.random().toString(36).substring(2, 10),
    name,
    appId: 'com.nodimus.' + name.toLowerCase().replace(/[^a-z0-9]/g, ''),
    engineVersion: '1.0.0',
    startSceneId,
    scenes: [
      {
        id: startSceneId,
        name: 'Main',
        path: 'res://scenes/Main.scene.json',
        isStartScene: true,
      },
    ],
    globalVariables: [],
    inputMap: [],
    settings: {
      general: {
        projectName: name,
        version: '1.0.0',
        description: '',
        mainScene: 'res://scenes/Main.scene.json',
        author: 'Developer',
      },
      display: {
        width: 1280,
        height: 720,
        resizable: true,
        fullscreen: false,
        windowMode: 'windowed',
        orientation: 'landscape',
      },
      rendering: {
        renderer: 'Three.js (WebGL)' as RendererType,
        clearColor: '#141822',
        vsync: true,
        msaa: '2x',
        shadowsEnabled: true,
        shadowQuality: 'medium',
        hdr: false,
      },
      physics: {
        gravity3D: { x: 0, y: -9.8, z: 0 },
        defaultLinearDamp: 0.1,
      },
      input: {
        actions: defaultProjectActions(),
        deadzone: DEFAULT_DEADZONE,
      },
      audio: {
        masterVolume: 1.0,
        musicVolume: 0.8,
        sfxVolume: 0.9,
      },
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}
