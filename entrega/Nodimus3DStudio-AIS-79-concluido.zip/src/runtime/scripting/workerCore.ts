import type { HostToWorker, ScriptCommand, ScriptSnapshot, ScriptValue, WorkerToHost } from './protocol';
import { SCRIPT_FUNCTIONS } from './protocol';

/**
 * AIS-79 — núcleo do Worker de scripts, SEM globais do Worker (testável em Node): recebe mensagens, carrega o módulo do usuário por um `importModule`
 * injetado (no Worker real: `import(blobUrl)`; nunca `eval` nem `new Function`) e chama `run`/`onReady`/`onUpdate` com o objeto `engine` abaixo.
 *
 * `engine` é a EngineApi 1.x RESTRITA ao subconjunto `SCRIPT_API_OPERATIONS`: leituras saem do snapshot (somente leitura, congelado), escritas viram
 * comandos no buffer da chamada (o host os valida; efeito no quadro seguinte). Não existe `window`, `document`, `fetch`, filesystem nem `TauriBridge`
 * neste objeto. O que o script ESCREVER NÃO é visível na MESMA chamada (lê o snapshot da chamada).
 */

export interface ScriptEngine {
  readonly version: { readonly major: number; readonly minor: number };
  /** ID estável do nó dono (script anexado ou dono da regra de `run_script`); `null` sem dono. */
  readonly self: string | null;
  time(): number;
  nodes: {
    resolve(ref: string): { id: string } | undefined;
    get(id: string): ScriptSnapshot['nodes'][string] | undefined;
  };
  transform: {
    get(id: string): ScriptSnapshot['nodes'][string]['transform'] | undefined;
    set(id: string, patch: { position?: number[]; rotation?: number[]; scale?: number[] }): void;
  };
  variables: {
    get(scope: 'global' | 'local', name: string, nodeId?: string): ScriptValue | undefined;
    set(scope: 'global' | 'local', name: string, value: ScriptValue, nodeId?: string): void;
  };
  signals: { emit(name: string, args?: unknown[]): void };
  input: {
    isPressed(action: string): boolean;
    justPressed(action: string): boolean;
    justReleased(action: string): boolean;
    axis(negative: string, positive: string): number;
  };
  log(level: 'info' | 'warn' | 'error', message: string): void;
}

export const SCRIPT_ENGINE_VERSION = { major: 1, minor: 0 } as const;

const deepFreeze = <T>(value: T): T => {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const v of Object.values(value as Record<string, unknown>)) deepFreeze(v);
  }
  return value;
};

/** Monta o `engine` de UMA chamada: lê o snapshot (congelado) e empilha comandos em `buffer`. */
export function createScriptEngine(snapshot: ScriptSnapshot, ownerId: string | null, buffer: ScriptCommand[]): ScriptEngine {
  const snap = deepFreeze(snapshot);
  const push = (command: ScriptCommand) => void buffer.push(command);
  const state = (action: string) => snap.input[action];
  return Object.freeze({
    version: SCRIPT_ENGINE_VERSION,
    self: ownerId,
    time: () => snap.time,
    nodes: Object.freeze({
      resolve: (ref: string) => {
        if (snap.nodes[ref]) return { id: ref };
        for (const n of Object.values(snap.nodes)) if (n.name === ref) return { id: n.id };
        return undefined;
      },
      get: (id: string) => snap.nodes[id],
    }),
    transform: Object.freeze({
      get: (id: string) => snap.nodes[id]?.transform,
      set: (id: string, patch: { position?: number[]; rotation?: number[]; scale?: number[] }) => push({ op: 'transform.set', id, patch } as ScriptCommand),
    }),
    variables: Object.freeze({
      get: (scope: 'global' | 'local', name: string, nodeId?: string) => (scope === 'global' ? snap.variables.global[name] : snap.variables.local[nodeId ?? ownerId ?? '']?.[name]),
      set: (scope: 'global' | 'local', name: string, value: ScriptValue, nodeId?: string) => push({ op: 'variables.set', scope, name, value, ...(scope === 'local' ? { nodeId: nodeId ?? ownerId ?? undefined } : {}) } as ScriptCommand),
    }),
    signals: Object.freeze({ emit: (name: string, args?: unknown[]) => push({ op: 'signals.emit', name, ...(args ? { args } : {}) } as ScriptCommand) }),
    input: Object.freeze({
      isPressed: (action: string) => state(action)?.pressed ?? false,
      justPressed: (action: string) => state(action)?.justPressed ?? false,
      justReleased: (action: string) => state(action)?.justReleased ?? false,
      axis: (negative: string, positive: string) => (state(positive)?.strength ?? 0) - (state(negative)?.strength ?? 0),
    }),
    log: (level: 'info' | 'warn' | 'error', message: string) => push({ op: 'log', level, message: String(message) }),
  }) as ScriptEngine;
}

export interface ScriptWorkerCoreOptions {
  post(message: WorkerToHost): void;
  /** Carrega o módulo do usuário (Worker real: `(url) => import(url)`). */
  importModule(url: string): Promise<Record<string, unknown>>;
  /** Relógio em ms (padrão `performance.now`). */
  now?: () => number;
}

/** Cria o tratador de mensagens do Worker. */
export function createScriptWorkerCore(options: ScriptWorkerCoreOptions): (message: HostToWorker) => Promise<void> {
  const now = options.now ?? (() => (typeof performance !== 'undefined' ? performance.now() : Date.now()));
  let mod: Record<string, unknown> | null = null;
  let ownerId: string | null = null;

  const errorText = (e: unknown) => (e instanceof Error ? `${e.name}: ${e.message}` : String(e));

  return async (message) => {
    if (message.t === 'load') {
      ownerId = message.ownerId;
      try {
        mod = await options.importModule(message.url);
      } catch (e) {
        options.post({ t: 'error', code: 'script.load_failed', message: `Falha ao carregar o script: ${errorText(e)}` });
        return;
      }
      const exports = SCRIPT_FUNCTIONS.filter((fn) => typeof mod![fn] === 'function');
      if (exports.length === 0) {
        options.post({ t: 'error', code: 'script.no_entry', message: 'O script não exporta nenhuma função de entrada (run, onReady ou onUpdate).' });
        return;
      }
      options.post({ t: 'ready', exports: [...exports] });
      return;
    }
    if (message.t === 'call') {
      const fn = mod?.[message.fn];
      if (typeof fn !== 'function') {
        options.post({ t: 'error', id: message.id, code: 'script.no_entry', message: `O script não exporta "${message.fn}".` });
        return;
      }
      const buffer: ScriptCommand[] = [];
      const engine = createScriptEngine(message.snapshot, ownerId, buffer);
      const t0 = now();
      try {
        const result = message.fn === 'run' ? fn(engine, message.args) : message.fn === 'onUpdate' ? fn(engine, message.dt ?? 0) : fn(engine);
        if (result && typeof (result as Promise<unknown>).then === 'function') await result;
      } catch (e) {
        options.post({ t: 'error', id: message.id, code: 'script.exception', message: `${message.fn}: ${errorText(e)}` });
        return;
      }
      try {
        options.post({ t: 'done', id: message.id, commands: buffer, ms: now() - t0 });
      } catch (e) {
        // o buffer não cruza a fronteira (função, símbolo, ciclo em args…): erro do script, nunca exceção solta no Worker
        options.post({ t: 'error', id: message.id, code: 'script.invalid_result', message: `${message.fn}: os comandos não são dados serializáveis (${errorText(e)})` });
      }
    }
  };
}
