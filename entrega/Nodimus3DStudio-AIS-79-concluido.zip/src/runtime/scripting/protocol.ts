import { ENGINE_OPERATIONS, type EngineOperation } from '../engineApi';
import type { ScriptLimits } from './limits';

/**
 * AIS-79 — protocolo host ↔ Worker e Command Buffer. TUDO que cruza a fronteira é dado estruturado (clone estruturado); o host trata o que vem do
 * Worker como NÃO CONFIÁVEL (um script malicioso pode forjar mensagens): cada comando é validado aqui antes de tocar a `EngineApi`.
 */

// ── superfície de API (v1, a mais restrita: diretriz 4.1) ──────────────────────────────────────────────────────────────────────────────

/**
 * Operações da `EngineApi` que o script enxerga. É um SUBCONJUNTO de `ENGINE_OPERATIONS` (só marshaláveis e seguras em Play); leituras vêm do
 * snapshot, escritas viram comandos validados pelo host. Sem física, áudio, tweens, animação, cena, armas, IA nem `scripts` (um script não chama script).
 */
export const SCRIPT_API_OPERATIONS = [
  'nodes.resolve',
  'nodes.get',
  'transform.get',
  'transform.set',
  'variables.get',
  'variables.set',
  'signals.emit',
  'input.isPressed',
  'input.justPressed',
  'input.justReleased',
  'input.axis',
  'log.write',
  'time.sceneTime',
] as const;
export type ScriptApiOperation = (typeof SCRIPT_API_OPERATIONS)[number];

/** Cada operação do script existe no catálogo, é marshalável e segura em Play (testado). */
export function scriptOperations(): EngineOperation[] {
  return SCRIPT_API_OPERATIONS.map((id) => ENGINE_OPERATIONS.find((o) => o.id === id)).filter((o): o is EngineOperation => !!o);
}

// ── snapshot (somente leitura, enviado ao Worker) ──────────────────────────────────────────────────────────────────────────────────────

export type ScriptValue = number | string | boolean;

export interface ScriptNodeSnapshot {
  id: string;
  name: string;
  type: string;
  tags: string[];
  visible: boolean;
  parentId: string | null;
  transform: { position: [number, number, number]; rotation: [number, number, number]; scale: [number, number, number] };
}

export interface ScriptInputState {
  pressed: boolean;
  justPressed: boolean;
  justReleased: boolean;
  /** 0..1 (analógico) quando o leitor oferece; senão 0/1. */
  strength: number;
}

export interface ScriptSnapshot {
  /** Segundos de jogo. */
  time: number;
  /** Número do quadro do host (cresce a cada tick). */
  frame: number;
  nodes: Record<string, ScriptNodeSnapshot>;
  variables: { global: Record<string, ScriptValue>; local: Record<string, Record<string, ScriptValue>> };
  input: Record<string, ScriptInputState>;
}

// ── comandos (Worker → host) ───────────────────────────────────────────────────────────────────────────────────────────────────────────

export type ScriptCommand =
  | { op: 'transform.set'; id: string; patch: { position?: [number, number, number]; rotation?: [number, number, number]; scale?: [number, number, number] } }
  | { op: 'variables.set'; scope: 'global' | 'local'; name: string; value: ScriptValue; nodeId?: string }
  | { op: 'signals.emit'; name: string; args?: unknown[] }
  | { op: 'log'; level: 'info' | 'warn' | 'error'; message: string };

export interface RejectedCommand {
  index: number;
  reason: string;
}

export interface ValidatedCommands {
  commands: ScriptCommand[];
  rejected: RejectedCommand[];
  /** Quantos passaram do teto `maxCommandsPerFrame` (descartados). */
  overflow: number;
}

const isString = (v: unknown, max: number): v is string => typeof v === 'string' && v.length > 0 && v.length <= max;
const isFiniteNumber = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
const isTriple = (v: unknown): v is [number, number, number] => Array.isArray(v) && v.length === 3 && v.every(isFiniteNumber);
const isScriptValue = (v: unknown, maxText: number): v is ScriptValue => isFiniteNumber(v) || typeof v === 'boolean' || (typeof v === 'string' && v.length <= maxText);

/** Verdadeiro se `v` é JSON puro e curto (sem funções, ciclos, undefined, classes). */
function isShortPlainJson(v: unknown, maxChars: number): boolean {
  try {
    const text = JSON.stringify(v);
    return typeof text === 'string' && text.length <= maxChars;
  } catch {
    return false;
  }
}

/**
 * Valida o Command Buffer vindo do Worker (NÃO CONFIÁVEL): formato, tamanhos, números finitos; descarta o excesso do teto. Pura: não toca a
 * `EngineApi`. Um comando inválido é rejeitado COM motivo (vira diagnóstico), nunca aplicado pela metade.
 */
export function validateCommands(raw: unknown, limits: Pick<ScriptLimits, 'maxCommandsPerFrame' | 'maxTextChars' | 'maxSignalArgsChars'>): ValidatedCommands {
  const out: ValidatedCommands = { commands: [], rejected: [], overflow: 0 };
  if (!Array.isArray(raw)) {
    out.rejected.push({ index: -1, reason: 'o buffer de comandos não é uma lista' });
    return out;
  }
  raw.forEach((item, index) => {
    if (out.commands.length >= limits.maxCommandsPerFrame) {
      out.overflow++;
      return;
    }
    const reject = (reason: string) => void out.rejected.push({ index, reason });
    if (!item || typeof item !== 'object') return reject('comando não é um objeto');
    const c = item as Record<string, unknown>;
    switch (c.op) {
      case 'transform.set': {
        if (!isString(c.id, 128)) return reject('transform.set: id inválido');
        const p = c.patch as Record<string, unknown> | null;
        if (!p || typeof p !== 'object' || Array.isArray(p)) return reject('transform.set: patch inválido');
        const patch: { position?: [number, number, number]; rotation?: [number, number, number]; scale?: [number, number, number] } = {};
        for (const key of ['position', 'rotation', 'scale'] as const) {
          if (p[key] === undefined) continue;
          if (!isTriple(p[key])) return reject(`transform.set: "${key}" precisa de 3 números finitos`);
          patch[key] = [...(p[key] as [number, number, number])];
        }
        if (Object.keys(patch).length === 0) return reject('transform.set: patch vazio');
        out.commands.push({ op: 'transform.set', id: c.id, patch });
        return;
      }
      case 'variables.set': {
        if (c.scope !== 'global' && c.scope !== 'local') return reject('variables.set: escopo inválido');
        if (!isString(c.name, 128)) return reject('variables.set: nome inválido');
        if (!isScriptValue(c.value, limits.maxTextChars)) return reject('variables.set: valor precisa ser número finito, texto curto ou booleano');
        if (c.nodeId !== undefined && !isString(c.nodeId, 128)) return reject('variables.set: nodeId inválido');
        out.commands.push({ op: 'variables.set', scope: c.scope, name: c.name, value: c.value, ...(c.nodeId ? { nodeId: c.nodeId as string } : {}) });
        return;
      }
      case 'signals.emit': {
        if (!isString(c.name, 128)) return reject('signals.emit: nome inválido');
        if (c.args !== undefined && (!Array.isArray(c.args) || !isShortPlainJson(c.args, limits.maxSignalArgsChars))) return reject('signals.emit: args precisam ser uma lista JSON curta');
        out.commands.push({ op: 'signals.emit', name: c.name, ...(c.args ? { args: JSON.parse(JSON.stringify(c.args)) as unknown[] } : {}) });
        return;
      }
      case 'log': {
        if (c.level !== 'info' && c.level !== 'warn' && c.level !== 'error') return reject('log: nível inválido');
        if (typeof c.message !== 'string' || c.message.length === 0) return reject('log: mensagem inválida');
        out.commands.push({ op: 'log', level: c.level, message: c.message.slice(0, limits.maxTextChars) });
        return;
      }
      default:
        return reject(`operação desconhecida ou fora da superfície do script: ${String(c.op).slice(0, 40)}`);
    }
  });
  return out;
}

// ── mensagens ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

export type HostToWorker =
  | { t: 'load'; url: string; ownerId: string | null; limits: Pick<ScriptLimits, 'frameBudgetMs' | 'maxTextChars'> }
  | { t: 'call'; id: number; fn: 'onReady' | 'onUpdate' | 'run'; dt?: number; args?: unknown; snapshot: ScriptSnapshot };

export type WorkerToHost =
  | { t: 'ready'; exports: string[] }
  | { t: 'done'; id: number; commands: unknown; ms: number }
  | { t: 'error'; id?: number; code: string; message: string };

export const SCRIPT_FUNCTIONS = ['onReady', 'onUpdate', 'run'] as const;
