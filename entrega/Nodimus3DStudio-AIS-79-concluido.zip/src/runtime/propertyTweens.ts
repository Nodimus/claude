/**
 * @file propertyTweens.ts
 * @module runtime
 *
 * AIS-59 — adaptador entre o `Tweener` (puro) e as propriedades de um nó EM EXECUÇÃO: posição, rotação (graus), escala, cor e
 * opacidade. Lê e escreve só a instância viva e o objeto Three dela (nunca o authoring, nunca o CommandManager): Stop/Restart
 * descartam tudo. Nós de UI (Overlay2D) usam os offsets do layout (`posX/posY`), `color`/`textColor` e `alpha`.
 *
 * Corpo FÍSICO dinâmico: a física é dona da pose, então cada quadro do tween é empurrado para o corpo (`host.applyTransform` →
 * `PhysicsHost.syncFromInstance`, velocidades preservadas) — AIS-59b D6. Corpo `character`: a pose sai do controlador, então tween de
 * posição/rotação nele é recusado com erro explícito, em vez de "funcionar" por um quadro e ser desfeito.
 */

import * as THREE from 'three';
import { Tweener, type TweenSpec, type TweenValue } from '../animation/tweener';
import { normalizeEasing, type EasingName } from '../animation/easing';
import type { LoopMode } from '../animation/tweener';
import { readPhysics } from '../core/physics/physicsConfig';
import { isOverlayNodeType } from './overlay';
import type { RuntimeInstance } from './RuntimeScene';

export const TWEEN_PROPERTIES = ['position', 'rotation', 'scale', 'color', 'opacity'] as const;
export type TweenProperty = (typeof TWEEN_PROPERTIES)[number];

export interface PropertyTweenRequest {
  property: TweenProperty;
  /** `position`/`rotation`/`scale`: vetor; `color`: cor CSS (`#rrggbb`); `opacity`: número 0–1. */
  to: { x?: number; y?: number; z?: number } | string | number;
  /** Soma ao valor atual em vez de ser o valor final (posição/rotação/escala/opacidade). */
  relative?: boolean;
  duration: number;
  delay?: number;
  easing?: EasingName | string;
  loop?: LoopMode;
  repeat?: number;
  owner?: unknown;
  onComplete?(): void;
}

export interface PropertyTweenHost {
  applyTransform(instance: RuntimeInstance): void;
  markUiDirty(): void;
}

export type PropertyTweenResult = { ok: true; spec: TweenSpec } | { ok: false; error: string };

const isUi = (instance: RuntimeInstance): boolean => isOverlayNodeType(instance.type);
const finite = (v: unknown, fallback: number): number => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);
const clamp01 = (v: number): number => Math.min(1, Math.max(0, v));

function lightsOf(object: THREE.Object3D | null): THREE.Light[] {
  const out: THREE.Light[] = [];
  object?.traverse((child) => {
    if ((child as THREE.Light).isLight) out.push(child as THREE.Light);
  });
  return out;
}

function materialsOf(object: THREE.Object3D | null): THREE.Material[] {
  const out: THREE.Material[] = [];
  object?.traverse((child) => {
    const m = (child as THREE.Mesh).material;
    for (const material of Array.isArray(m) ? m : m ? [m] : []) if (!out.includes(material)) out.push(material);
  });
  return out;
}

/** Monta o `TweenSpec` de uma propriedade do nó; `ok: false` com a mensagem de erro para o log quando não dá. */
export function createPropertyTween(instance: RuntimeInstance, request: PropertyTweenRequest, host: PropertyTweenHost): PropertyTweenResult {
  const ui = isUi(instance);
  const base = {
    duration: finite(request.duration, 0),
    delay: finite(request.delay, 0),
    easing: normalizeEasing(request.easing),
    loop: request.loop ?? 'once',
    repeat: request.repeat,
    owner: request.owner ?? instance,
    onComplete: request.onComplete,
    label: `${instance.name}.${request.property}`,
  };
  switch (request.property) {
    case 'position':
    case 'rotation':
    case 'scale': {
      if (ui) {
        if (request.property !== 'position') return { ok: false, error: `"${instance.name}" é um nó de UI: só a posição (offsets do layout) pode ser animada.` };
        const get = (): number[] => [finite(instance.properties.posX, 0), finite(instance.properties.posY, 0)];
        const current = get();
        const t = (typeof request.to === 'object' ? request.to : {}) as { x?: number; y?: number };
        const target = request.relative ? [current[0] + finite(t.x, 0), current[1] + finite(t.y, 0)] : [finite(t.x, current[0]), finite(t.y, current[1])];
        return { ok: true, spec: { ...base, get, to: target, set: (v: TweenValue) => { const a = v as number[]; instance.properties.posX = a[0]; instance.properties.posY = a[1]; host.markUiDirty(); } } };
      }
      const physics = readPhysics(instance.properties);
      if (request.property !== 'scale' && physics?.enabled && physics.bodyMode === 'character') {
        return { ok: false, error: `"${instance.name}" tem corpo físico (character): a pose dele sai do controlador de personagem a cada quadro. Use "Teleport Physics Body"/o movimento do personagem, ou mude o corpo para "Movido pela lógica".` };
      }
      const key = request.property;
      const get = (): number[] => [...instance.transform[key]];
      const current = get();
      const t = (typeof request.to === 'object' ? request.to : {}) as { x?: number; y?: number; z?: number };
      const pick = (v: number | undefined, i: number) => (request.relative ? current[i] + finite(v, 0) : finite(v, current[i]));
      return { ok: true, spec: { ...base, get, to: [pick(t.x, 0), pick(t.y, 1), pick(t.z, 2)], set: (v: TweenValue) => { instance.transform[key] = [...(v as number[])] as [number, number, number]; host.applyTransform(instance); } } };
    }

    case 'color': {
      const hex = typeof request.to === 'string' ? request.to : '';
      const parsed = new THREE.Color();
      try {
        parsed.set(hex || '#ffffff');
      } catch {
        return { ok: false, error: `cor inválida "${hex}".` };
      }
      if (!hex) return { ok: false, error: 'informe a cor final (ex.: #ff8800).' };
      const target = [parsed.r, parsed.g, parsed.b];
      if (ui) {
        const key = instance.type === 'TextOverlay2D' ? 'textColor' : 'color';
        const read = () => (instance.properties[key] ?? { r: 1, g: 1, b: 1, a: 1 }) as { r: number; g: number; b: number; a?: number };
        return { ok: true, spec: { ...base, get: () => { const c = read(); return [c.r, c.g, c.b]; }, to: target, set: (v: TweenValue) => { const a = v as number[]; instance.properties[key] = { r: a[0], g: a[1], b: a[2], a: read().a ?? 1 }; host.markUiDirty(); } } };
      }
      const lights = lightsOf(instance.object);
      const mats = materialsOf(instance.object).filter((m) => (m as THREE.MeshBasicMaterial).color);
      if (lights.length === 0 && mats.length === 0) return { ok: false, error: `"${instance.name}" (${instance.type}) não tem cor para animar (sem material ou luz).` };
      const first = (lights[0]?.color ?? (mats[0] as THREE.MeshBasicMaterial).color) as THREE.Color;
      return { ok: true, spec: { ...base, get: () => [first.r, first.g, first.b], to: target, set: (v: TweenValue) => { const a = v as number[]; for (const l of lights) l.color.setRGB(a[0], a[1], a[2]); for (const m of mats) (m as THREE.MeshBasicMaterial).color.setRGB(a[0], a[1], a[2]); } } };
    }

    case 'opacity': {
      const raw = typeof request.to === 'number' ? request.to : Number.NaN;
      if (!Number.isFinite(raw)) return { ok: false, error: 'informe a opacidade final (0 a 1).' };
      if (ui) {
        const get = () => clamp01(finite(instance.properties.alpha, 1));
        const target = clamp01(request.relative ? get() + raw : raw);
        return { ok: true, spec: { ...base, get, to: target, set: (v: TweenValue) => { instance.properties.alpha = clamp01(v as number); host.markUiDirty(); } } };
      }
      const mats = materialsOf(instance.object);
      if (mats.length === 0) return { ok: false, error: `"${instance.name}" (${instance.type}) não tem material para animar a opacidade.` };
      const get = () => mats[0].opacity;
      return { ok: true, spec: { ...base, get, to: clamp01(request.relative ? get() + raw : raw), set: (v: TweenValue) => { for (const m of mats) { m.transparent = true; m.opacity = clamp01(v as number); m.needsUpdate = false; } } } };
    }
  }
}

/** O que a Action `tween_to` enxerga (via `ActionRuntimeContext.tweens`): iniciar e parar tweens de propriedade de um nó. */
export interface TweenControl {
  /** Inicia o tween; um novo tween da MESMA propriedade do mesmo nó substitui o anterior. `null` = iniciou; senão a mensagem de erro. */
  start(instance: RuntimeInstance, request: PropertyTweenRequest): string | null;
  /** Para os tweens do nó (só a propriedade indicada, se vier); devolve quantos parou. */
  stop(instance: RuntimeInstance, property?: TweenProperty): number;
}

const ownerKey = (instance: RuntimeInstance, property: TweenProperty): string => `${instance.id}:${property}`;

/** Liga o `Tweener` da sessão às propriedades dos nós vivos. Um por runtime de cena; some com ele. */
export function createTweenControl(tweener: Tweener, host: PropertyTweenHost): TweenControl {
  return {
    start(instance, request) {
      if (instance.disposed) return `"${instance.name}" já foi destruído.`;
      const result = createPropertyTween(instance, { ...request, owner: ownerKey(instance, request.property) }, host);
      if (!result.ok) return result.error;
      tweener.kill(ownerKey(instance, request.property)); // substitui o tween anterior da mesma propriedade
      tweener.add(result.spec);
      return null;
    },
    stop(instance, property) {
      return property
        ? tweener.kill(ownerKey(instance, property))
        : TWEEN_PROPERTIES.reduce((n, p) => n + tweener.kill(ownerKey(instance, p)), 0);
    },
  };
}
