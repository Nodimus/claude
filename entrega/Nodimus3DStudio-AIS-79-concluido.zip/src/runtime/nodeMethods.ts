/**
 * @file nodeMethods.ts
 * @module runtime
 *
 * AIS-57 — métodos que uma conexão de sinal pode chamar no nó alvo, como no Godot: o alvo tem MÉTODOS NATIVOS do seu tipo
 * (`show`, `hide`, `queue_free`, `play`…) e, quando os scripts existirem (AIS-78c/79), métodos de script que
 * SOBRESCREVEM os nativos de mesmo nome. Os nativos reutilizam os executores das Actions (nunca uma segunda implementação).
 *
 * Resolução (`resolveMethod`): script do nó › nativo do tipo › inexistente (a sessão reporta `signal.method_not_found`,
 * como o erro de runtime do Godot: o jogo segue). Aridade: argumentos emitidos + vinculados precisam caber nos parâmetros
 * (falta de obrigatórios = `signal.bad_arguments`; excesso também, nos métodos de SCRIPT). Nos NATIVOS os argumentos
 * a mais são ignorados (como um `Callable.unbind`), para `body_entered(outro)` poder chamar `hide()` direto.
 */

import type { NodeType } from '../types/node';
import type { RuntimeInstance } from './RuntimeScene';
import type { SoundHost } from './audioRuntime';
import type { TimerControl } from './nodeSignalSources';

export interface MethodParam {
  name: string;
  type: 'string' | 'number' | 'boolean';
  optional?: boolean;
}

/** O que um método nativo pode pedir à sessão (sem conhecer o runner nem o barramento por dentro). */
export interface MethodHost {
  /** Executa o executor de uma Action nativa com `self` = o alvo. */
  invokeAction(actionId: string, params: Record<string, unknown>, self: RuntimeInstance): void;
  /** Emite um sinal DO nó (`emit_signal` do Godot). */
  emitFrom(nodeId: string, signal: string, args: readonly unknown[]): void;
  sound(): SoundHost | null;
  /** Controle dos `Timer` da cena (`start`/`stop`); `null` fora de uma cena viva. */
  timers(): TimerControl | null;
}

export interface NativeMethod {
  name: string;
  description: string;
  params: readonly MethodParam[];
  /** Tipos de nó em que existe; ausente = todos. */
  appliesTo?: (type: NodeType) => boolean;
  call(target: RuntimeInstance, args: readonly unknown[], host: MethodHost): void;
}

const isAudio = (type: NodeType) => type === 'AudioPlayer' || type === 'AudioPlayer3D';
const isTimer = (type: NodeType) => type === 'Timer';

export const NATIVE_METHODS: readonly NativeMethod[] = [
  {
    name: 'show',
    description: 'Torna o nó visível.',
    params: [],
    call: (t, _a, h) => h.invokeAction('set_visible', { visible: true }, t),
  },
  {
    name: 'hide',
    description: 'Esconde o nó.',
    params: [],
    call: (t, _a, h) => h.invokeAction('set_visible', { visible: false }, t),
  },
  {
    name: 'set_visible',
    description: 'Mostra ou esconde o nó.',
    params: [{ name: 'visible', type: 'boolean' }],
    call: (t, a, h) => h.invokeAction('set_visible', { visible: a[0] === true }, t),
  },
  {
    name: 'queue_free',
    description: 'Remove o nó (e a subárvore) da cena em execução.',
    params: [],
    call: (t, _a, h) => h.invokeAction('destroy_node', { target: '' }, t),
  },
  {
    name: 'emit_signal',
    description: 'Emite um sinal deste nó (os argumentos seguintes vão ao sinal).',
    params: [{ name: 'signal', type: 'string' }],
    call: (t, a, h) => h.emitFrom(t.persistentNodeId, String(a[0] ?? ''), a.slice(1)),
  },
  {
    name: 'start',
    description: 'Inicia (ou reinicia) o Timer; o argumento opcional troca o tempo de espera desta contagem.',
    params: [{ name: 'time_sec', type: 'number', optional: true }],
    appliesTo: isTimer,
    call: (t, a, h) => h.timers()?.start(t.persistentNodeId, typeof a[0] === 'number' ? a[0] : undefined),
  },
  {
    name: 'stop',
    description: 'Para o Timer (sem emitir `timeout`).',
    params: [],
    appliesTo: isTimer,
    call: (t, _a, h) => h.timers()?.stop(t.persistentNodeId),
  },
  {
    name: 'play',
    description: 'Toca o áudio do nó (`stream`).',
    params: [],
    appliesTo: isAudio,
    call: (t, _a, h) => {
      const stream = typeof t.properties.stream === 'string' ? t.properties.stream : '';
      const error = h.sound()?.play({ emitterId: t.persistentNodeId, path: stream, spatial: t.type === 'AudioPlayer3D' });
      if (error) throw new Error(error);
    },
  },
  {
    name: 'stop',
    description: 'Para o áudio do nó.',
    params: [],
    appliesTo: isAudio,
    call: (t, _a, h) => {
      h.sound()?.stop(t.persistentNodeId);
    },
  },
];

export type ScriptMethod = (target: RuntimeInstance, args: readonly unknown[]) => void;

export type ResolvedMethod =
  | { kind: 'script'; params: readonly MethodParam[] | undefined; call: (target: RuntimeInstance, args: readonly unknown[], host: MethodHost) => void }
  | { kind: 'native'; params: readonly MethodParam[]; call: (target: RuntimeInstance, args: readonly unknown[], host: MethodHost) => void };

/**
 * Métodos de script por nó. Quem registra (scripts do AIS-79, Behaviors) recebe o disposer; o registro pertence à sessão e
 * morre com ela. Sem scripts hoje, o registro nasce vazio: só os nativos respondem.
 */
export class MethodRegistry {
  private readonly scripts = new Map<string, Map<string, { fn: ScriptMethod; params?: readonly MethodParam[] }>>();

  registerScriptMethod(nodeId: string, name: string, fn: ScriptMethod, params?: readonly MethodParam[]): () => void {
    let byName = this.scripts.get(nodeId);
    if (!byName) {
      byName = new Map();
      this.scripts.set(nodeId, byName);
    }
    const entry = { fn, params };
    byName.set(name, entry);
    return () => {
      const current = this.scripts.get(nodeId);
      if (current?.get(name) === entry) current.delete(name);
    };
  }

  /** Script do nó › nativo do tipo › `undefined`. */
  resolveMethod(target: { persistentNodeId: string; type: NodeType }, name: string): ResolvedMethod | undefined {
    const script = this.scripts.get(target.persistentNodeId)?.get(name);
    if (script) return { kind: 'script', params: script.params, call: (t, a) => script.fn(t, a) };
    const native = NATIVE_METHODS.find((m) => m.name === name && (!m.appliesTo || m.appliesTo(target.type)));
    return native ? { kind: 'native', params: native.params, call: (t, a, h) => native.call(t, a, h) } : undefined;
  }

  clear(): void {
    this.scripts.clear();
  }
}

/** Aridade como no Godot: nem argumentos demais, nem obrigatórios faltando. `null` = ok. */
export function checkArity(name: string, params: readonly MethodParam[] | undefined, argc: number, options: { lenientExtra?: boolean } = {}): string | null {
  if (!params) return null; // método de script sem assinatura declarada: sem checagem
  const required = params.filter((p) => !p.optional).length;
  if (argc > params.length && !options.lenientExtra) return `"${name}" aceita ${params.length} argumento(s), mas a conexão passa ${argc}.`;
  if (argc < required) return `"${name}" exige ${required} argumento(s), mas a conexão passa ${argc}.`;
  return null;
}
