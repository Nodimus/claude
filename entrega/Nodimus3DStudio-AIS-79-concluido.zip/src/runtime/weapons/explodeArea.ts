import { applyDamage } from './damage';
import { isSelfOrDescendantOf, worldPoseOf } from './fireWeapon';
import { passesTagFilter } from './tags';
import type { ExplosionOutcome, ExplosionParams, WeaponCoreContext } from './types';

/**
 * AIS-69 (ARM-07) — explosão em raio: `PhysicsBridge.overlapSphere` + `applyDamage` + `addImpulse`. Cada alvo é atingido NO MÁXIMO UMA
 * vez por explosão (um dano, um impulso); o atirador (e a subárvore dele) e outros projéteis ficam de fora; `IgnoreTags`/`OnlyTags` decidem
 * quem recebe dano E impulso. O impulso só vale em corpo `dynamic` e cai linearmente do centro (máximo) até a borda (zero).
 */
export function explodeArea(ctx: WeaponCoreContext, p: ExplosionParams): ExplosionOutcome {
  const { host } = ctx;
  const out: ExplosionOutcome = { hit: [], damaged: [], pushed: [] };
  const source = host.instance(p.sourceId);
  const center = p.center?.trim() ? host.resolve(p.center.trim(), p.sourceId) : source;
  if (!center || center.disposed) {
    ctx.warnOnce(`explode-center:${p.sourceId}`, 'weapon.explosion_center_missing', `Explosão: o centro "${p.center ?? p.sourceId}" não existe na cena viva; nada foi atingido.`, p.sourceId);
    return out;
  }
  if (!(p.radius > 0)) {
    ctx.warnOnce(`explode-radius:${p.sourceId}`, 'weapon.bad_params', 'Explosão: o raio precisa ser maior que zero; nada foi atingido.', p.sourceId);
    return out;
  }
  const bridge = host.physics();
  if (!bridge) {
    ctx.warnOnce(`explode-physics:${p.sourceId}`, 'weapon.no_physics', 'Explosão: a cena não tem mundo físico (ative "Colisão" nos alvos); nada foi atingido.', p.sourceId);
    return out;
  }
  const pose = worldPoseOf(center);
  if (!pose) return out;
  const variable = p.damageVariable?.trim() || 'health';
  const seen = new Set<string>();
  for (const hit of bridge.overlapSphere(pose.position, p.radius)) {
    if (seen.has(hit.nodeId)) continue;
    seen.add(hit.nodeId);
    const target = host.instance(hit.nodeId);
    if (!target || target.disposed || ctx.isProjectile(hit.nodeId)) continue;
    if (!p.hitSource && source && isSelfOrDescendantOf(target, source.persistentNodeId)) continue;
    if (!passesTagFilter(target.tags, p.ignoreTags, p.onlyTags)) continue;
    out.hit.push(hit.nodeId);
    if (p.damage > 0) {
      const r = applyDamage(ctx, { sourceId: p.sourceId, targetId: hit.nodeId, amount: p.damage, variable });
      if (r.status === 'applied') out.damaged.push(hit.nodeId);
    }
    if (p.impulse > 0 && bridge.modeOf(hit.nodeId) === 'dynamic' && bridge.isEnabled(hit.nodeId)) {
      const body = bridge.getPose(hit.nodeId);
      if (!body) continue;
      let d = { x: body.position.x - pose.position.x, y: body.position.y - pose.position.y, z: body.position.z - pose.position.z };
      const len = Math.hypot(d.x, d.y, d.z);
      d = len > 1e-6 ? { x: d.x / len, y: d.y / len, z: d.z / len } : { x: 0, y: 1, z: 0 };
      const magnitude = p.impulse * Math.max(0, 1 - hit.distance / p.radius);
      if (magnitude > 0) {
        bridge.addImpulse(hit.nodeId, { x: d.x * magnitude, y: d.y * magnitude, z: d.z * magnitude });
        out.pushed.push(hit.nodeId);
      }
    }
  }
  return out;
}
