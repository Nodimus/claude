import * as THREE from 'three';
import type { Vec3 } from '../../core/physics/bounds';
import type { RuntimeInstance } from '../RuntimeScene';
import { SpawnError } from '../spawnHost';
import { applyDamage } from './damage';
import { applyKick, constrainDirection, directionBetween, eulerDegreesFacing, forwardFromView, forwardOf } from './aim';
import { readPhysics } from '../../core/physics/physicsConfig';
import type { FireOutcome, FireParams, ProjectileState, WeaponCoreContext } from './types';

/**
 * AIS-69 (ARM-01/02/04) — a ÚNICA implementação do disparo. Cadência e munição ficam no Behavior; aqui só nasce o tiro:
 *
 *  - `physical`: o projétil é criado SÓ por `spawnPrefab` (AIS-29g) no Firepoint, apontando para `AimTarget` (ou para a frente do
 *    Firepoint) e com velocidade inicial `speed`; o impacto chega pelo evento físico (`WeaponService.onPhysicsEvent`), nunca por polling.
 *  - `hitscan`: UM `PhysicsBridge.raycast` por disparo (proibido `THREE.Raycaster`); dano ao primeiro nó atingido dentro de `range`.
 *
 * Nunca lança: falha vira `{ ok: false, code, message }` (o chamador loga; o Play segue).
 */

const _p = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _s = new THREE.Vector3();

export function worldPoseOf(instance: RuntimeInstance): { position: Vec3; quaternion: { x: number; y: number; z: number; w: number } } | null {
  const object = instance.object;
  if (!object) return null;
  object.updateWorldMatrix(true, false);
  object.matrixWorld.decompose(_p, _q, _s);
  return { position: { x: _p.x, y: _p.y, z: _p.z }, quaternion: { x: _q.x, y: _q.y, z: _q.z, w: _q.w } };
}

/** `instance` é `ancestorId` ou está dentro da subárvore dele? */
export function isSelfOrDescendantOf(instance: RuntimeInstance, ancestorId: string): boolean {
  for (let n: RuntimeInstance | null = instance; n; n = n.parent) if (n.persistentNodeId === ancestorId) return true;
  return false;
}

/** IDs do nó e de toda a subárvore. */
export function subtreeIds(instance: RuntimeInstance): string[] {
  const out: string[] = [];
  const walk = (n: RuntimeInstance) => {
    out.push(n.persistentNodeId);
    for (const c of n.children) if (!c.disposed) walk(c);
  };
  walk(instance);
  return out;
}

/** `base` + `offset` (local) girado pela rotação mundial do Firepoint. */
function offsetBy(base: Vec3, q: { x: number; y: number; z: number; w: number }, offset: Vec3): Vec3 {
  const v = new THREE.Vector3(offset.x, offset.y, offset.z).applyQuaternion(new THREE.Quaternion(q.x, q.y, q.z, q.w));
  return { x: base.x + v.x, y: base.y + v.y, z: base.z + v.z };
}

const fail = (code: Extract<FireOutcome, { ok: false }>['code'], message: string): FireOutcome => ({ ok: false, code, message });

/** Efeito de impacto (prefab opcional) no ponto, com a frente apontando para a normal. Falha vira aviso único; nunca lança. */
export function spawnImpactEffect(ctx: WeaponCoreContext, path: string | undefined, lifetimeMs: number, point: Vec3, normal: Vec3 | null, sourceId: string): void {
  if (!path?.trim()) return;
  const { host } = ctx;
  const ref = host.resolvePrefab(path.trim());
  if (!ref) {
    ctx.warnOnce(`effect:${path}`, 'weapon.impact_effect_unresolved', `Efeito de impacto: "${path}" não é um prefab do projeto (res://prefabs/*.prefab.json).`, sourceId);
    return;
  }
  try {
    host.spawn(ref, { position: [point.x, point.y, point.z], rotation: normal ? eulerDegreesFacing(normal) : [0, 0, 0], ownerId: sourceId, lifetimeMs: lifetimeMs > 0 ? lifetimeMs : undefined });
  } catch (error) {
    ctx.warnOnce(`effect:${path}`, 'weapon.impact_effect_failed', `Efeito de impacto "${path}" não foi criado: ${error instanceof Error ? error.message : String(error)}`, sourceId);
  }
}

/** Impacto resolvido (projétil ou hitscan): dano, efeito e hook `OnImpact`. Devolve `false` se o alvo não conta (atirador, outro projétil). */
export function resolveImpact(
  ctx: WeaponCoreContext,
  hit: { sourceId: string; behaviorId?: string; targetId: string; point: Vec3; normal: Vec3 | null },
  rules: { damage: number; damageVariable: string; ignoreTags: readonly string[]; onlyTags: readonly string[]; impactEffect?: string; impactEffectLifetimeMs: number }
): boolean {
  const { host } = ctx;
  const target = host.instance(hit.targetId);
  const source = host.instance(hit.sourceId);
  if (!target || target.disposed) return false;
  if (ctx.isProjectile(hit.targetId)) return false;
  if (source && isSelfOrDescendantOf(target, source.persistentNodeId)) return false;
  applyDamage(ctx, { sourceId: hit.sourceId, targetId: hit.targetId, amount: rules.damage, variable: rules.damageVariable, ignoreTags: rules.ignoreTags, onlyTags: rules.onlyTags });
  spawnImpactEffect(ctx, rules.impactEffect, rules.impactEffectLifetimeMs, hit.point, hit.normal, hit.sourceId);
  if (hit.behaviorId) host.fireHook(hit.sourceId, hit.behaviorId, 'on_weapon_impact', `impacto em "${target.name}"`);
  return true;
}

export function fireWeapon(ctx: WeaponCoreContext, p: FireParams): FireOutcome {
  const { host } = ctx;
  const source = host.instance(p.sourceId);
  if (!source || source.disposed) return fail('weapon.source_missing', `Disparo: o atirador "${p.sourceId}" não existe na cena viva.`);
  const firepoint = p.firepoint?.trim() ? host.resolve(p.firepoint.trim(), p.sourceId) : source;
  if (!firepoint) return fail('weapon.firepoint_missing', `Disparo: o Firepoint "${p.firepoint}" não existe na cena.`);
  const aimNode = p.aimTarget?.trim() ? host.resolve(p.aimTarget.trim(), p.sourceId) : undefined;
  if (p.aimTarget?.trim() && !aimNode) return fail('weapon.aim_target_missing', `Disparo: o AimTarget "${p.aimTarget}" não existe na cena.`);
  const pose = worldPoseOf(firepoint);
  if (!pose) return fail('weapon.firepoint_missing', `Disparo: "${firepoint.name}" não tem objeto vivo para servir de Firepoint.`);

  // origem do disparo: o Firepoint, mais o deslocamento local opcional (AIS-71)
  const origin: Vec3 = p.originOffset ? offsetBy(pose.position, pose.quaternion, p.originOffset) : pose.position;

  let dir: Vec3 | null = null;
  if (aimNode) {
    const aimPose = worldPoseOf(aimNode);
    dir = aimPose ? directionBetween(origin, aimPose.position) : null;
  } else if (p.aimView) dir = forwardFromView(p.aimView);
  dir = applyKick(dir ?? forwardOf(pose.quaternion), p.kick);
  dir = constrainDirection(dir, readPhysics(source.properties)?.constrainToPlane); // 2D: o plano do ATIRADOR (decisões 6 e 26)

  if (!(p.range > 0)) return fail('weapon.bad_params', 'Disparo: BulletRange precisa ser maior que zero.');
  const ownerId = source.persistentNodeId;
  const damageVariable = p.damageVariable?.trim() || 'health';
  const ignoreTags = p.ignoreTags ?? [];
  const onlyTags = p.onlyTags ?? [];
  const impactLifetime = p.impactEffectLifetimeMs ?? 2000;

  if (p.mode === 'hitscan') {
    const bridge = host.physics();
    if (!bridge) return fail('weapon.no_physics', 'Disparo hitscan: a cena não tem mundo físico (ative "Colisão" nos alvos); nada foi atingido.');
    const ignore = [...subtreeIds(source), ...ctx.projectileIds()];
    const hit = bridge.raycast(origin, dir, { maxDistance: p.range, ignoreNodeIds: ignore });
    if (!hit) return { ok: true, mode: 'hitscan', hit: null };
    resolveImpact(ctx, { sourceId: ownerId, behaviorId: p.behaviorId, targetId: hit.nodeId, point: hit.point, normal: hit.normal }, { damage: p.damage, damageVariable, ignoreTags, onlyTags, impactEffect: p.impactEffect, impactEffectLifetimeMs: impactLifetime });
    return { ok: true, mode: 'hitscan', hit: { nodeId: hit.nodeId, point: hit.point, normal: hit.normal, distance: hit.distance } };
  }

  if (!p.bullet?.trim()) return fail('weapon.bullet_missing', 'Disparo físico: escolha o prefab do projétil (Bullet).');
  if (!(p.speed > 0)) return fail('weapon.bad_params', 'Disparo físico: BulletSpeed precisa ser maior que zero.');
  const ref = host.resolvePrefab(p.bullet.trim());
  if (!ref) return fail('weapon.prefab_unresolved', `Disparo físico: "${p.bullet}" não é um prefab do projeto (res://prefabs/*.prefab.json).`);
  try {
    const handle = host.spawn(ref, {
      position: [origin.x, origin.y, origin.z],
      rotation: p.facesMotion ? eulerDegreesFacing(dir) : [0, 0, 0],
      initialVelocity: { x: dir.x * p.speed, y: dir.y * p.speed, z: dir.z * p.speed },
      ownerId,
    });
    // 2D: o plano do PROJÉTIL também vale — o Rapier não bloqueia uma velocidade escrita por fora nos eixos travados
    const spawned = host.instance(handle.rootId);
    const flight = constrainDirection(dir, readPhysics(spawned?.properties)?.constrainToPlane);
    if (flight !== dir) {
      try {
        host.physics()?.setLinearVelocity(handle.rootId, { x: flight.x * p.speed, y: flight.y * p.speed, z: flight.z * p.speed });
      } catch {
        /* corpo ainda não criado: o passo seguinte do serviço aplica a mesma velocidade */
      }
    }
    const state: ProjectileState = {
      id: handle.rootId,
      ownerId,
      behaviorId: p.behaviorId,
      damage: p.damage,
      damageVariable,
      ignoreTags,
      onlyTags,
      impactEffect: p.impactEffect,
      impactEffectLifetimeMs: impactLifetime,
      direction: flight,
      speed: p.speed,
      start: { ...origin },
      spawnedAt: host.now(),
      rangeMode: p.rangeMode,
      range: p.range,
      lifetimeMs: p.lifetimeMs,
      collisionDestroyDelayMs: Math.max(0, p.collisionDestroyDelayMs),
      hitIds: new Set(),
      impacted: false,
    };
    ctx.track(state);
    return { ok: true, mode: 'physical', projectileId: handle.rootId };
  } catch (error) {
    // `SpawnHost` já publicou o diagnóstico; o disparo só informa o motivo ao chamador
    return fail('weapon.spawn_failed', `Disparo físico: ${error instanceof SpawnError ? error.message : String(error)}`);
  }
}
