import type { DamageOutcome, DamageParams, WeaponCoreContext } from './types';
import { passesTagFilter } from './tags';

/**
 * AIS-69 (ARM-06/ARM-08) — contrato de dano. UMA função aplica dano no jogo (Behavior, Actions e, no AIS-71, `Shoot`).
 *
 *  1. Alvo por ID estável; variável LOCAL do alvo (`health` por padrão), nunca criada automaticamente.
 *  2. Falhas explícitas (alvo inexistente, variável ausente ou não numérica, quantidade inválida): diagnóstico UMA vez por par
 *     alvo+variável e sessão e NENHUMA mudança. Nunca lança.
 *  3. `novo = max(0, atual − amount)`; chegar a 0 não destrói o nó (isso é lógica do jogo: `damage_taken` ou condição de variável).
 *  4. Emite `damage_taken` pelo `SignalBus` (origem = o alvo) com `{ sourceId, targetId, amount, remaining, variable }`, uma vez por
 *     aplicação efetiva.
 *  5. Filtros: `IgnoreTags`/`OnlyTags` decidem quem recebe (sem diagnóstico: é escolha do autor).
 */
export function applyDamage(ctx: WeaponCoreContext, params: DamageParams): DamageOutcome {
  const { host } = ctx;
  const variable = params.variable?.trim() || 'health';
  const target = host.instance(params.targetId);
  if (!target || target.disposed) {
    ctx.warnOnce(`target:${params.targetId}:${variable}`, 'weapon.damage_target_missing', `Dano: o alvo "${params.targetId}" não existe na cena viva; nada foi alterado.`, params.sourceId);
    return { status: 'failed', code: 'weapon.damage_target_missing' };
  }
  if (!Number.isFinite(params.amount) || params.amount <= 0) {
    ctx.warnOnce(`amount:${params.sourceId}:${params.amount}`, 'weapon.damage_invalid_amount', `Dano: a quantidade ${String(params.amount)} é inválida (use um número finito maior que zero); nada foi alterado.`, params.sourceId);
    return { status: 'failed', code: 'weapon.damage_invalid_amount' };
  }
  if (!passesTagFilter(target.tags, params.ignoreTags, params.onlyTags)) return { status: 'ignored', reason: 'tag' };

  const variables = host.variables();
  const id = target.persistentNodeId;
  const current = variables?.getVariable('local', variable, id);
  if (current === undefined) {
    ctx.warnOnce(`${id}:${variable}`, 'weapon.damage_variable_missing', `Dano: "${target.name}" não tem a variável Local "${variable}" (crie-a em Variables, no Inspector do objeto); o impacto físico acontece, mas a vida não muda.`, id);
    return { status: 'failed', code: 'weapon.damage_variable_missing' };
  }
  if (typeof current !== 'number' || !Number.isFinite(current)) {
    ctx.warnOnce(`${id}:${variable}`, 'weapon.damage_variable_not_number', `Dano: a variável Local "${variable}" de "${target.name}" não é numérica; nada foi alterado.`, id);
    return { status: 'failed', code: 'weapon.damage_variable_not_number' };
  }
  const remaining = Math.max(0, current - params.amount);
  variables!.setVariable('local', variable, remaining, id);
  host.emitSignal('damage_taken', { source: id, args: [{ sourceId: params.sourceId, targetId: id, amount: params.amount, remaining, variable }] });
  return { status: 'applied', remaining };
}
