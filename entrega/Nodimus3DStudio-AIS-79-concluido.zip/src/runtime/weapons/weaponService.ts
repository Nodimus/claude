import type { PhysicsEvent } from '../../core/physics/PhysicsBridge';
import type { ResourceRef } from '../../types/node';
import type { AuthoringSceneSnapshot } from '../../types/runtime';
import { applyDamage } from './damage';
import { explodeArea } from './explodeArea';
import { fireWeapon, isSelfOrDescendantOf, resolveImpact, worldPoseOf } from './fireWeapon';
import { collectWeaponPrefabPaths } from './prefabPaths';
import type { DamageOutcome, DamageParams, ExplosionOutcome, ExplosionParams, FireOutcome, FireParams, ProjectileState, WeaponCoreContext, WeaponHookTrigger, WeaponHost } from './types';

/**
 * AIS-69 — serviço de armas da `RuntimeSession` (um por runtime de cena; Stop, restart, troca de cena e remoção do nó o descartam):
 * é quem possui o ESTADO TRANSITÓRIO (projéteis vivos, `hitIds`, avisos já dados) e liga o núcleo (`fireWeapon`, `applyDamage`,
 * `explodeArea`) ao mundo: impacto = evento físico `collisionEnter`/`triggerEnter` (AIS-48), voo em linha reta e alcance a cada quadro.
 * Nada daqui vai ao authoring.
 *
 * As três portas de entrada — Behavior `weapon_controller`, Actions `fire_projectile`/`apply_damage`/`explode_area` e a `Shoot` da IA
 * (AIS-71) — chamam ESTES métodos: não existe segundo caminho de disparo, impacto ou dano.
 */
export class WeaponService {
  private readonly projectiles = new Map<string, ProjectileState>();
  private readonly warned = new Set<string>();
  private readonly ctx: WeaponCoreContext;
  private unsubscribe: (() => void) | null = null;
  private disposed = false;

  constructor(
    private readonly host: WeaponHost,
    /** Assina os eventos físicos da sessão (devolve o disposer). */
    private readonly subscribePhysics: (cb: (e: PhysicsEvent) => void) => () => void
  ) {
    this.ctx = {
      host,
      warnOnce: (key, code, message, nodeId) => {
        if (this.warned.has(`${code}:${key}`)) return;
        this.warned.add(`${code}:${key}`);
        host.report('warning', code, message, nodeId);
      },
      isProjectile: (id) => this.projectiles.has(id),
      projectileIds: () => [...this.projectiles.keys()],
      track: (p) => {
        this.projectiles.set(p.id, p);
        this.unsubscribe ??= this.subscribePhysics((e) => this.onPhysicsEvent(e)); // inscrição só enquanto há projétil vivo (AIS-48b: sem assinante ocioso)
      },
    };
  }

  /** `id` é um projétil vivo deste núcleo? (a IA nunca o toma por alvo) */
  isProjectile(id: string): boolean {
    return this.projectiles.has(id);
  }

  /** Projéteis vivos (para testes e diagnóstico). */
  get liveProjectiles(): number {
    return this.projectiles.size;
  }

  // ── portas de entrada (as MESMAS para Behavior, Actions e IA) ───────────────────────────────

  fire(params: FireParams): FireOutcome {
    if (this.disposed) return { ok: false, code: 'weapon.source_missing', message: 'Disparo: a sessão já terminou.' };
    return fireWeapon(this.ctx, params);
  }

  damage(params: DamageParams): DamageOutcome {
    return applyDamage(this.ctx, params);
  }

  explode(params: ExplosionParams): ExplosionOutcome {
    return explodeArea(this.ctx, params);
  }

  /** Hook `on_weapon_*` do Behavior (regras do próprio Behavior). */
  fireHook(ownerId: string, behaviorId: string, trigger: WeaponHookTrigger, detail: string): void {
    if (!this.disposed) this.host.fireHook(ownerId, behaviorId, trigger, detail);
  }

  /** Prefabs referenciados pelas armas da cena: carregados na abertura (o spawn exige prefab carregado). */
  preloadFor(snapshot: AuthoringSceneSnapshot): Promise<unknown> {
    const refs: ResourceRef[] = [];
    for (const path of collectWeaponPrefabPaths(snapshot)) {
      const ref = this.host.resolvePrefab(path);
      if (ref) refs.push(ref);
    }
    return refs.length > 0 ? this.host.preload(refs) : Promise.resolve([]);
  }

  // ── impacto e voo ───────────────────────────────────────────────────────────────────────────

  private onPhysicsEvent(e: PhysicsEvent): void {
    if (this.disposed || (e.name !== 'collisionEnter' && e.name !== 'triggerEnter')) return;
    const projectile = this.projectiles.get(e.selfId);
    if (!projectile || projectile.impacted) return;
    const other = this.host.instance(e.otherId);
    if (!other || other.disposed || this.projectiles.has(e.otherId)) return;
    const owner = this.host.instance(projectile.ownerId);
    if (owner && isSelfOrDescendantOf(other, owner.persistentNodeId)) return; // o atirador nunca é atingido pelo próprio tiro
    if (projectile.hitIds.has(e.otherId)) return;
    projectile.hitIds.add(e.otherId);
    projectile.impacted = true; // a partir daqui: nenhum dano novo, mesmo com mais contatos no intervalo
    const now = this.host.now();
    projectile.destroyAt = now + projectile.collisionDestroyDelayMs / 1000;
    this.stop(projectile);
    const self = this.host.instance(projectile.id);
    const point = e.contact?.point ?? (self ? worldPoseOf(self)?.position : undefined) ?? projectile.start;
    resolveImpact(
      this.ctx,
      { sourceId: projectile.ownerId, behaviorId: projectile.behaviorId, targetId: e.otherId, point, normal: e.contact ? { x: -e.contact.normal.x, y: -e.contact.normal.y, z: -e.contact.normal.z } : null },
      { damage: projectile.damage, damageVariable: projectile.damageVariable, ignoreTags: projectile.ignoreTags, onlyTags: projectile.onlyTags, impactEffect: projectile.impactEffect, impactEffectLifetimeMs: projectile.impactEffectLifetimeMs }
    );
    if (projectile.collisionDestroyDelayMs <= 0) this.remove(projectile);
  }

  /** Para o corpo do projétil que já acertou (não quica nem continua empurrando). */
  private stop(p: ProjectileState): void {
    try {
      this.host.physics()?.setLinearVelocity(p.id, { x: 0, y: 0, z: 0 });
    } catch {
      /* corpo não dinâmico/ausente: nada a parar */
    }
  }

  private remove(p: ProjectileState): void {
    this.projectiles.delete(p.id);
    this.host.despawn(p.id);
    this.releaseIfIdle();
  }

  private releaseIfIdle(): void {
    if (this.projectiles.size > 0) return;
    this.unsubscribe?.();
    this.unsubscribe = null;
  }

  /** Depois do passo da física: mantém a linha reta (sem gravidade própria), aplica alcance/vida útil e remove os que já acertaram. */
  step(): void {
    if (this.disposed || this.projectiles.size === 0) return;
    const now = this.host.now();
    const bridge = this.host.physics();
    for (const p of [...this.projectiles.values()]) {
      const instance = this.host.instance(p.id);
      if (!instance || instance.disposed) {
        this.projectiles.delete(p.id);
        this.releaseIfIdle();
        continue;
      }
      // o atirador foi removido da cena: o projétil dele não fica órfão
      const owner = this.host.instance(p.ownerId);
      if (!owner) {
        this.remove(p);
        continue;
      }
      if (p.impacted) {
        if (p.destroyAt !== undefined && now >= p.destroyAt) this.remove(p);
        continue;
      }
      try {
        bridge?.setLinearVelocity(p.id, { x: p.direction.x * p.speed, y: p.direction.y * p.speed, z: p.direction.z * p.speed });
      } catch {
        /* sem corpo dinâmico: o projétil não anda por física; segue só o alcance */
      }
      if (p.rangeMode === 'time') {
        if (now - p.spawnedAt >= p.lifetimeMs / 1000) this.remove(p);
      } else {
        const pos = bridge?.getPose(p.id)?.position ?? worldPoseOf(instance)?.position;
        if (pos && Math.hypot(pos.x - p.start.x, pos.y - p.start.y, pos.z - p.start.z) >= p.range) this.remove(p);
      }
    }
  }

  /** Remove todos os projéteis vivos e solta a assinatura (Stop, restart, troca de cena). Idempotente. */
  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.unsubscribe?.();
    this.unsubscribe = null;
    for (const p of this.projectiles.values()) this.host.despawn(p.id);
    this.projectiles.clear();
    this.warned.clear();
  }
}
