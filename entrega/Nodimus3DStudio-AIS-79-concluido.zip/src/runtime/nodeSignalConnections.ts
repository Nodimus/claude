/**
 * @file nodeSignalConnections.ts
 * @module runtime
 *
 * AIS-57 — executa as conexões de sinal gravadas em `GameNode.signals` (AIS-27) sobre o `SignalBus` da sessão, com a semântica
 * do Godot:
 *  - a conexão é do nó de ORIGEM (`source`) e chama `targetMethod` no nó alvo;
 *  - argumentos da chamada = argumentos do sinal + argumentos vinculados da conexão (`binds`), nessa ordem;
 *  - alvo destruído durante o jogo: a conexão se desfaz sozinha, sem erro (nó liberado);
 *  - método inexistente / argumentos que faltam: erro explícito de runtime (diagnóstico), o jogo segue;
 *  - `oneShot` e `deferred` por conexão (flags do Godot).
 * `tree_entered` e `ready` são emitidos no início do runtime, só para nós que têm conexão nesses sinais (nada de inundar o
 * histórico com o ciclo de vida de cada nó).
 */

import type { GameNode } from '../types/node';
import type { NodeSignalConnection } from '../types/signal';
import type { SignalBus } from '../core/signalBus';
import type { RuntimeInstance } from './RuntimeScene';
import { checkArity, type MethodHost, type MethodRegistry } from './nodeMethods';

export interface WireDeps {
  bus: SignalBus;
  nodes: Readonly<Record<string, GameNode>>;
  /** Instância viva do nó (por id autoral ou handle); `undefined` = não existe/foi destruída. */
  instanceOf(nodeId: string): RuntimeInstance | undefined;
  methods: MethodRegistry;
  host: MethodHost;
  report(code: 'signal.target_missing' | 'signal.method_not_found' | 'signal.bad_arguments' | 'signal.listener_failed', message: string, nodeId?: string): void;
  /** Registra o disposer de cada conexão no dono (cena): Stop/restart/troca de cena soltam tudo (AIS-48b). */
  track(dispose: () => void): void;
}

/** Valor de um argumento vinculado: `node` guarda o id autoral (identidade estável). */
export const bindValue = (arg: NonNullable<NodeSignalConnection['arguments']>[number]): unknown => arg.value;

export function wireNodeSignalConnections(deps: WireDeps): { emitLifecycle(): void; connectionCount: number } {
  let connectionCount = 0;
  const lifecycle: Array<{ nodeId: string; signal: 'tree_entered' | 'ready' }> = [];

  for (const node of Object.values(deps.nodes)) {
    for (const conn of node.signals ?? []) {
      const target = deps.instanceOf(conn.targetNodeId);
      if (!target) {
        deps.report('signal.target_missing', `Conexão "${conn.signalName}" de "${node.name}" → ${conn.targetNodeId}.${conn.targetMethod}: o nó alvo não existe na cena em execução.`, node.id);
        continue;
      }
      const binds = (conn.arguments ?? []).map(bindValue);
      const disconnect = deps.bus.connect({
        signal: conn.signalName,
        source: node.id,
        oneShot: conn.oneShot === true,
        deferred: conn.deferred === true,
        label: `${target.name}.${conn.targetMethod}`,
        listener: (emission) => {
          const live = deps.instanceOf(conn.targetNodeId);
          if (!live || live.disposed) {
            disconnect(); // Godot: o alvo liberado leva a conexão junto, sem erro
            return;
          }
          const method = deps.methods.resolveMethod(live, conn.targetMethod);
          if (!method) {
            deps.report('signal.method_not_found', `Sinal "${conn.signalName}" de "${node.name}": o método "${conn.targetMethod}" não existe em "${live.name}" (${live.type}).`, live.persistentNodeId);
            return;
          }
          const args = [...emission.args, ...binds];
          const arity = checkArity(conn.targetMethod, method.params, args.length, { lenientExtra: method.kind === 'native' });
          if (arity) {
            deps.report('signal.bad_arguments', `Sinal "${conn.signalName}" de "${node.name}" → ${live.name}.${arity}`, live.persistentNodeId);
            return;
          }
          method.call(live, args, deps.host);
        },
      });
      deps.track(disconnect);
      connectionCount++;
      if (conn.signalName === 'tree_entered' || conn.signalName === 'ready') lifecycle.push({ nodeId: node.id, signal: conn.signalName });
    }
  }

  return {
    connectionCount,
    emitLifecycle() {
      // Godot: `tree_entered` (pai antes do filho) e depois `ready` (filho antes do pai); aqui na ordem de declaração dos nós
      const seen = new Set<string>();
      for (const { nodeId, signal } of lifecycle) {
        if (signal !== 'tree_entered' || seen.has(nodeId)) continue;
        seen.add(nodeId);
        deps.bus.emit('tree_entered', { source: nodeId, origin: 'lifecycle' });
      }
      seen.clear();
      for (const { nodeId, signal } of [...lifecycle].reverse()) {
        if (signal !== 'ready' || seen.has(nodeId)) continue;
        seen.add(nodeId);
        deps.bus.emit('ready', { source: nodeId, origin: 'lifecycle' });
      }
    },
  };
}
