import type {
  AuthoringSceneSnapshot,
  RuntimeSessionContract,
  RuntimeSessionMode,
  RuntimeSessionStatus,
} from '../types/runtime';
import { getActiveSoundHost } from './audioRuntime';
import { SignalBus, signalMonitor, type ConnectOptions, type EmitOptions, type SignalEmission } from '../core/signalBus';
import { MethodRegistry, type MethodParam, type ScriptMethod } from './nodeMethods';
import { wireNodeSignalConnections } from './nodeSignalConnections';
import { NodeSignalSources } from './nodeSignalSources';
import { Tweener } from '../animation/tweener';
import type { DiagnosticInput } from '../core/diagnostics/DiagnosticService';
import type { PhysicsBridge, PhysicsEvent, PhysicsEventName } from '../core/physics/PhysicsBridge';
import type { HeightfieldData, PhysicsIssue } from '../core/physics/physicsDescriptor';
import { ensureRapier, getRapierIfReady, type RapierModule } from '../core/physics/rapierInit';
import { PhysicsHost, sceneHasPhysics } from './physicsHost';
import { WeaponService } from './weapons/weaponService';
import type { WeaponHost } from './weapons/types';
import { ActorRegistry } from './ai/actorRegistry';
import { resolveRoute } from '../core/waypoints/resolveRoute';
import type { VariableManager, VariableSource } from '../core/variableManager';
import type { ResourceRef } from '../types/node';
import { SpawnHost, type SpawnedHandle, type SpawnOptions } from './spawnHost';
import { ParticleBurstQueue, type ParticleBurst, type ParticleHost } from './particleRuntime';
import { AnimationHost } from './animationRuntime';
import { SpriteHost } from './spriteHost';
import { AttachmentHost } from './attachmentRuntime';
import { BehaviorRuntimeCatalog, type BehaviorRuntimeLookup } from '../logic/behaviorRuntime';
import { BehaviorLifecycleHost } from './behaviorLifecycle';
import type { GameCameraPose } from './controllers/gameCamera';
import { nodeOps } from './nodeOps';
import { ScriptHost, isRunnableScriptPath, type WorkerLike } from './scripting/ScriptHost';
import { buildScriptSnapshot } from './scripting/snapshot';
import { createScriptWorker } from './scripting/createWorker';
import type { ScriptLimits } from './scripting/limits';
import { countCameraPoses, selectGameCamera, viewBasisOf, type LocomotionState, type ViewBasis } from './cameraRig';
import { BehaviorRuntimeStates } from './behaviorRuntimeState';
import type { RawInputReader } from './input/inputTriggers';
import { LogicRunner, type LogicLogEntry, type LogicLogMeta } from './logicRunner';
import { SubscriptionRegistry, type SubscriptionOwner, type SubscriptionOwnerKind } from './subscriptions';
import { buildEngineApi, type EngineApi, type EngineHost } from './engineApi';
import type { RuntimeScene } from './RuntimeScene';
import { RuntimeSceneManager, type RuntimeSceneEvent } from './RuntimeSceneManager';
import type { RuntimeInstance } from './RuntimeScene';

/**
 * AIS-44b — RuntimeSession: a AUTORIDADE ÚNICA do Play.
 *
 *   Authoring State → snapshot → RuntimeSession → Stop = dispose
 *
 * Dona de tudo o que é transitório: a cena viva (`RuntimeSceneManager` próprio), as variáveis da sessão, o `LogicRunner`
 * (regras), o lifecycle dos Behaviors (estado por nó × Behavior), as assinaturas/teardowns de sistemas (física, workers…)
 * e os diagnósticos efêmeros (`sessionId`). Nunca escreve no AuthoringModel, no EditorContext nem no CommandManager
 * (invariantes 4–5 de `types/runtime.ts`): parar a sessão descarta tudo e o autoral está intacto, sem Undo.
 *
 * Troca de cena (ordem fixa): abortar cadeias → dispose dos Behaviors → unsubscribe (runner) → teardowns (Workers, mundo
 * físico…) → limpar variáveis locais → PRESERVAR globais → carregar a nova RuntimeScene → iniciar o lifecycle.
 * `Restart Scene` é o mesmo caminho sobre o MESMO snapshot (locais restauradas, globais preservadas);
 * `Restart Behavior` recomeça só aquele (nó × Behavior).
 */

/** AIS-48: sinal emitido por um nó em runtime (`body_entered`/`body_exited`). As conexões executam no `signalBus` da sessão (AIS-57), que também recebe estas emissões. */
export interface NodeSignalEvent {
  sourceNodeId: string;
  signal: 'body_entered' | 'body_exited' | 'fell_out_of_world';
  /** Argumentos do sinal: `[otherId]`; em `fell_out_of_world` (Kill Floor, AIS-49) `[y]` (altura mundial do corpo). */
  args: [string] | [number];
}

export interface RuntimeSessionDiagnostics {
  report(input: DiagnosticInput, options?: { announce?: boolean }): unknown;
  clearSession(sessionId: string): number;
}

export interface RuntimeSessionOptions {
  snapshot: AuthoringSceneSnapshot;
  mode?: RuntimeSessionMode;
  /** Globais iniciais (copiadas: o projeto autoral nunca é tocado). */
  globals?: readonly VariableSource[];
  input: RawInputReader;
  /** Serviço único de diagnósticos (`globalDiagnosticService` no editor). Sem ele, a sessão não publica diagnósticos. */
  diagnostics?: RuntimeSessionDiagnostics;
  /** Resolve o destino de `Change Scene` (caminho `res://…`) em snapshot; nunca toca o autoral. */
  resolveScene?: (scenePath: string) => AuthoringSceneSnapshot | Promise<AuthoringSceneSnapshot>;
  onLog?: (entry: LogicLogEntry) => void;
  onQuitGame?: () => void;
  onUiChanged?: () => void;
  random?: () => number;
  verbose?: boolean;
  /** Catálogo de executores de Behavior (padrão: as pastas de `src/logic/behaviors/`). */
  behaviorCatalog?: BehaviorRuntimeLookup;
  /** AIS-45: `settings.physics.defaultLinearDamp` do projeto (amortecimento linear padrão dos corpos `dynamic`). */
  defaultLinearDamp?: number;
  /** AIS-45: fornece o Rapier já carregado (padrão: `getRapierIfReady`); `null` = ainda carregando — o mundo entra assim que terminar. */
  getRapier?: () => RapierModule | null;
  /** AIS-45: buffer de alturas do terreno de uma instância (decisão 23; o AIS-50 fornece). */
  heightfieldOf?: (instance: RuntimeInstance) => HeightfieldData | null;
  /** AIS-29g: lê o JSON bruto de um prefab (`ResourceRegistry`); alimenta `preloadPrefabs`. Sem ele só `registerPrefab` carrega prefabs. */
  readPrefab?: (ref: ResourceRef) => Promise<unknown>;
  /** AIS-69: caminho `res://…prefab.json` → referência de recurso (as armas nomeiam o prefab por caminho). Sem isso, armas com prefab avisam. */
  resolvePrefab?: (path: string) => ResourceRef | undefined;
  /** AIS-29g: teto de objetos criados em jogo ao mesmo tempo (padrão 512). */
  maxSpawns?: number;
  /** AIS-79: código-fonte de um script de `res://scripts/` (o projeto aberto); `null` = não existe. Sem isso, nenhum script executa (diagnóstico `script.not_found`). */
  readScript?: (path: string) => string | null;
  /** AIS-79: fábrica do Web Worker de scripts (padrão: o Worker real; os testes injetam um dublê). */
  createScriptWorker?: () => WorkerLike;
  /** AIS-79: limites do sandbox (padrão `DEFAULT_SCRIPT_LIMITS`). */
  scriptLimits?: Partial<ScriptLimits>;
}

let sessionCounter = 0;

export class RuntimeSession implements RuntimeSessionContract {
  public readonly id: string;
  public readonly mode: RuntimeSessionMode;
  /** Cena viva e variáveis DESTA sessão (nunca um singleton do app). */
  public readonly sceneManager = new RuntimeSceneManager();

  /**
   * AIS-57 — barramento de sinais da sessão (Godot Signals + entrega enfileirada do Defold). Nasce com a sessão, atravessa
   * restart/troca de cena (o histórico fica) e é descartado no Stop. Um só: nunca um barramento paralelo.
   */
  public readonly signalBus: SignalBus;
  /** AIS-57 — métodos que as conexões chamam: nativos do tipo + os de script (AIS-78c/79). */
  public readonly methods = new MethodRegistry();
  /**
   * AIS-29g — criação/destruição DINÂMICA de GameNodes em Play (prefabs). Um por sessão; o AIS-69 (armas) e o AIS-71 (IA) criam
   * projéteis e efeitos só por aqui. Nunca escreve no authoring.
   */
  public readonly spawns: SpawnHost;
  /**
   * AIS-59c — rajadas de partículas pedidas pela Action `emit_particles`. O estado das partículas vive no apresentador da viewport
   * (motor único); ele consome esta fila a cada quadro (`takeParticleBursts`). Descartável: restart, troca de cena e Stop a esvaziam.
   */
  private readonly particleBursts = new ParticleBurstQueue();
  /**
   * AIS-60 — estado de reprodução dos objetos animados (um `createClipMixer` por objeto, o do AIS-37). Descartável com a cena. O
   * apresentador da viewport registra os clipes carregados e aplica `animation.layersOf()` ao esqueleto a cada quadro.
   */
  /** AIS-61 §4: attachments a ossos feitos em jogo (`attach_to_bone`); descartável com a cena. A viewport faz o reparent. */
  public readonly attachments = new AttachmentHost();
  /**
   * AIS-76 — reprodução dos `Billboard` animados (clipes de `SpriteProject`, tempo de `clipFrameIndexAtTime`). Descartável com a cena; o apresentador da
   * viewport (`viewportSprites.ts`) registra os clipes e lê o frame ativo. Emite `frame_changed`/`animation_looped`/`animation_finished` no `SignalBus`.
   */
  public readonly sprites = new SpriteHost();
  public readonly animation = new AnimationHost((code, message, playerId) => this.publish('warning', code, message, playerId));
  private readonly particleHost: ParticleHost = {
    burst: (nodeId, count) => {
      const instance = this.sceneManager.current?.getInstance(nodeId);
      if (!instance || instance.disposed) return `o nó "${nodeId}" não existe mais na cena em execução.`;
      if (instance.type !== 'ParticleSystem') return `"${instance.name}" não é um ParticleSystem.`;
      this.particleBursts.request(instance.persistentNodeId, count);
      return null;
    },
  };

  private _status: RuntimeSessionStatus = 'idle';
  private _snapshot: AuthoringSceneSnapshot;
  private _elapsed = 0;
  private _runner: LogicRunner | null = null;
  private _behaviors: BehaviorLifecycleHost | null = null;
  private _weapons: WeaponService | null = null;
  private _ai: ActorRegistry | null = null;
  /** AIS-79: sandbox de scripts (Web Workers) desta sessão; descartado com a cena. */
  private _scripts: ScriptHost | null = null;
  private scriptFrame = 0;
  /** AIS-78d: chaves de `engine.diagnostics.warnOnce` já publicadas nesta sessão (limpas no descarte da cena). */
  private readonly onceKeys = new Set<string>();
  private _physics: PhysicsHost | null = null;
  /** AIS-57: emissores por tempo/estado da cena atual (`timeout`, `visibility_changed`, `environment_changed`). */
  private _sources: NodeSignalSources | null = null;
  /** AIS-59: interpolador de propriedades da cena viva (Action `tween_to`); atualizado a cada quadro, descartado com a cena. */
  private _tweener: Tweener | null = null;
  /** AIS-47: câmera de jogo por nó (controladores de personagem); a última entregue é a ativa. Descartável. */
  private readonly gameCameras = new Map<string, GameCameraPose>();
  /** AIS-47c: estado de locomoção por nó (Behaviors de movimento); descartável como a pose. */
  private readonly locomotion = new Map<string, LocomotionState>();
  /** AIS-47c: câmeras ativas já avisadas por `camera.multiple_active` (um aviso por câmera e por sessão). */
  private readonly warnedMultipleCameras = new Set<string>();
  /**
   * AIS-48b — ÚNICA contabilidade de inscrições do runtime (frame, input, física, sinais, cena), por owner. Os `Set`s abaixo só
   * despacham; quem cancela é o registry. Stop/Restart/troca de cena descartam o que é da cena; `dispose` descarta tudo.
   */
  private readonly subscriptionRegistry = new SubscriptionRegistry();
  private physicsListeners = new Set<{ name: PhysicsEventName | '*'; cb: (e: PhysicsEvent) => void }>();
  private nodeSignalListeners = new Set<(s: NodeSignalEvent) => void>();
  private frameListeners = new Set<(dt: number) => void>();
  private inputListeners = new Set<(input: RawInputReader) => void>();
  private signalListeners = new Set<{ name: string; cb: (name: string) => void }>();
  /** Cada runtime (início, restart, troca de cena) tem um número; a carga assíncrona do Rapier só anexa ao runtime que a pediu. */
  private runtimeEpoch = 0;
  private changing = false;
  private disposed = false;
  private teardowns = new Set<() => void>();
  private sceneListeners = new Set<(e: RuntimeSceneEvent) => void>();
  private readonly options: RuntimeSessionOptions;

  constructor(options: RuntimeSessionOptions) {
    this.options = options;
    this.id = `rsess_${Date.now().toString(36)}_${(++sessionCounter).toString(36)}`;
    this.mode = options.mode ?? 'scene';
    this._snapshot = options.snapshot;
    this.spawns = new SpawnHost({
      scene: () => this.sceneManager.current,
      physics: () => this._physics,
      attachPhysics: () => this.attachPhysics(),
      behaviors: () => this._behaviors,
      runner: () => this._runner,
      variables: () => this.sceneManager.variables,
      now: () => this._elapsed,
      publish: (severity, code, message, nodeId) => this.publish(severity, code, message, nodeId),
      readPrefab: options.readPrefab,
      maxSpawns: options.maxSpawns,
    });
    this.signalBus = new SignalBus({
      sceneTime: () => this._runner?.sceneTime ?? 0,
      onProblem: (p) => this.publish('error', p.code, p.message),
      // sinal global emitido por código (EngineApi/scripts/Behaviors) também dispara regras `on_signal`; o eco da própria lógica é ignorado
      onEmit: (e) => {
        if (e.source === undefined && e.origin !== 'logic') this._runner?.dispatchSignal(e.signal);
      },
    });
  }

  // ── contrato ──────────────────────────────────────────────────────────────────────────────────

  public get status(): RuntimeSessionStatus {
    return this._status;
  }
  public get snapshot(): AuthoringSceneSnapshot {
    return this._snapshot;
  }
  public get elapsedTime(): number {
    return this._elapsed;
  }
  /** Cena viva atual; lança se a sessão já foi descartada (use `currentScene` para consulta tolerante). */
  public get scene(): RuntimeScene {
    const scene = this.sceneManager.current;
    if (!scene) throw new Error('RuntimeSession sem cena viva (ainda não iniciada ou já descartada).');
    return scene;
  }
  public get currentScene(): RuntimeScene | null {
    return this.sceneManager.current;
  }
  public get runner(): LogicRunner | null {
    return this._runner;
  }
  /** Ponte física do runtime atual (`null` = cena sem corpos, motor ainda carregando ou sessão encerrada). */
  public get physics(): PhysicsBridge | null {
    return this._physics?.bridge ?? null;
  }
  /**
   * AIS-48 — `onPhysicsEvent(name, cb) → unsubscribe`: ÚNICA porta de eventos físicos para Behaviors, Actions e scripts (o
   * `EngineApi` do AIS-78c a repassa). Sobrevive ao mundo físico carregar tarde, mas NÃO sobrevive à cena: Stop, Restart, troca de
   * cena e `dispose` cancelam todas as inscrições.
   */
  public onPhysicsEvent(name: PhysicsEventName | '*', cb: (e: PhysicsEvent) => void, owner: SubscriptionOwner = this.sceneOwner()): () => void {
    const listener = { name, cb };
    this.physicsListeners.add(listener);
    return this.subscriptionRegistry.add(owner, () => this.physicsListeners.delete(listener));
  }

  /** AIS-48: sinais de nó (`body_entered`/`body_exited`, com o `otherId`) — também entregue ao `signalBus` (AIS-57). */
  public onNodeSignal(cb: (s: NodeSignalEvent) => void, owner: SubscriptionOwner = this.sceneOwner()): () => void {
    this.nodeSignalListeners.add(cb);
    return this.subscriptionRegistry.add(owner, () => this.nodeSignalListeners.delete(cb));
  }

  /**
   * AIS-57: conecta um ouvinte ao barramento (`signal` `'*'` = todos; `source` = só um nó). Devolve o `unsubscribe`; Stop,
   * Restart e troca de cena o soltam (`owner` padrão = a cena), como toda inscrição do runtime (AIS-48b).
   */
  public connectSignal(options: ConnectOptions, owner: SubscriptionOwner = this.sceneOwner()): () => void {
    return this.subscriptionRegistry.add(owner, this.signalBus.connect(options));
  }

  /** AIS-57: emite um sinal (global ou de um nó) — a porta de scripts, Behaviors e do `EngineApi` (AIS-78c). */
  public emitSignal(signal: string, options: EmitOptions = {}): SignalEmission {
    return this.signalBus.emit(signal, options);
  }

  /**
   * AIS-78c (decisão 32) — a `EngineApi` v1 desta sessão: a superfície estável de scripts (AIS-79) e a base de que os contextos de Action e de Behavior
   * derivam. As assinaturas feitas por ela pertencem a `owner` (padrão: a cena) e morrem com ele. Só dados serializáveis e a `PhysicsBridge`: nunca
   * Three, Rapier, DOM, stores nem Tauri.
   */
  public engineApi(owner?: SubscriptionOwner): EngineApi {
    return buildEngineApi(this.engineHost(), owner ?? this.sceneOwner());
  }

  private engineHost(): EngineHost {
    return {
      instanceById: (ref) => this.sceneManager.current?.getInstance(ref),
      instanceByName: (name) => this.sceneManager.current?.getAllInstances().find((i) => i.name === name),
      variables: () => this.variables,
      input: () => this.options.input,
      physics: () => this.physics,
      sceneTime: () => this._runner?.sceneTime ?? 0,
      emitSignal: (name, args, source) => void this.signalBus.emit(name, { source, args, origin: 'engine' }),
      connectSignal: (name, listener, owner, source) => this.connectSignal({ signal: name, source, listener: (e) => listener(e.signal, e.args) }, owner ?? this.sceneOwner()),
      onPhysicsEvent: (name, cb, owner) => this.onPhysicsEvent(name, cb, owner ?? this.sceneOwner()),
      log: (level, message, node, o) => this.handleLog({ time: this._runner?.sceneTime ?? 0, level, message, nodeName: node?.name, nodeId: node?.persistentNodeId, instanceId: node?.id, toOutput: o?.toOutput ?? level !== 'info', code: o?.code, behaviorId: o?.behaviorId, logicId: o?.logicId }),
      commitTransform: (instance) => this.sceneManager.current?.applyInstanceTransform(instance),
      audio: getActiveSoundHost,
      particles: () => this.particleHost,
      animation: () => this.animation,
      sprites: () => this.sprites,
      tweens: () => this._runner?.getTweenControl() ?? null,
      after: (seconds, fn) => this._runner?.schedule(seconds, fn),
      destroy: (instance) => this._runner?.destroyInstance(instance),
      setWorldPosition: (instance, position) => this._runner?.setWorldPosition(instance, position),
      sceneRequest: (request) => this._runner?.requestScene(request),
      weapons: () => this._weapons,
      actors: () => this._ai,
      scripts: () => this._scripts,
      fireHook: (ownerId, behaviorId, trigger, detail, params) => this._runner?.dispatchHook(ownerId, behaviorId, trigger, detail, params),
      reportOnce: (key, severity, code, message, nodeId) => {
        if (this.onceKeys.has(`${code}:${key}`)) return;
        this.onceKeys.add(`${code}:${key}`);
        this.publish(severity, code, message, nodeId);
      },
      resolveRoute: (containerId) => resolveRoute(this._snapshot, containerId), // lê o snapshot autoral; nunca grava pose
      random: () => (this.options.random ?? Math.random)(),
      attachments: () => this.attachments,
      view: () => this.viewBasis,
      behaviorProperties: (nodeId, behaviorType) => this._behaviors?.propertiesOf(nodeId, behaviorType),
      nodeOps: () => nodeOps,
      onFrame: (cb, owner) => this.onFrame(cb, owner ?? this.sceneOwner()),
      onInput: (cb, owner) => this.onInput(cb, owner ?? this.sceneOwner()),
      setGameCamera: (nodeId, pose) => this.publishGameCamera(nodeId, pose),
      setLocomotion: (nodeId, state) => this.publishLocomotion(nodeId, state),
      interpolate: (text, selfNodeId) => this._runner?.interpolateText(text, selfNodeId) ?? text,
      markUiDirty: () => this._runner?.markUiDirty(),
      setContinuousRotation: (instance, axis, dps) => this._runner?.setContinuousRotation(instance, axis, dps),
      setContinuousVelocity: (instance, velocity, space) => this._runner?.setContinuousVelocity(instance, velocity, space),
    };
  }

  /** AIS-47/78c: a câmera de jogo do nó (a EngineApi.camera.publish); `null` a retira. Estado de sessão, nunca do authoring. */
  private publishGameCamera(nodeId: string, pose: Omit<GameCameraPose, 'nodeId'> | null): void {
    if (pose) {
      this.gameCameras.set(nodeId, { ...pose, nodeId });
      this.warnIfMultipleCameras(nodeId, pose.kind);
    } else this.gameCameras.delete(nodeId);
  }

  /** AIS-47c/78c: o estado de locomoção do nó (a EngineApi.locomotion.set); `null` o retira. */
  private publishLocomotion(nodeId: string, state: LocomotionState | null): void {
    if (state) this.locomotion.set(nodeId, state);
    else this.locomotion.delete(nodeId);
  }

  /** AIS-57: registra um método de script chamável por conexões (AIS-79). Devolve o disposer; some com a cena. */
  public registerMethod(nodeId: string, name: string, fn: ScriptMethod, params?: readonly MethodParam[], owner: SubscriptionOwner = this.sceneOwner()): () => void {
    return this.subscriptionRegistry.add(owner, this.methods.registerScriptMethod(nodeId, name, fn, params));
  }

  /** AIS-48b: callback por quadro, DEPOIS da física (`step`/`stepFrame`). Devolve o `unsubscribe` (idempotente). */
  public onFrame(cb: (dt: number) => void, owner: SubscriptionOwner = this.sceneOwner()): () => void {
    this.frameListeners.add(cb);
    return this.subscriptionRegistry.add(owner, () => this.frameListeners.delete(cb));
  }

  /** AIS-48b: callback por quadro com o leitor de entrada, ANTES dos Behaviors. Devolve o `unsubscribe` (idempotente). */
  public onInput(cb: (input: RawInputReader) => void, owner: SubscriptionOwner = this.sceneOwner()): () => void {
    this.inputListeners.add(cb);
    return this.subscriptionRegistry.add(owner, () => this.inputListeners.delete(cb));
  }

  /** AIS-48b: assina um sinal emitido na cena (`emit_signal`). Devolve o `unsubscribe` (idempotente). */
  public onSignal(name: string, cb: (name: string) => void, owner: SubscriptionOwner = this.sceneOwner()): () => void {
    const listener = { name, cb };
    this.signalListeners.add(listener);
    return this.subscriptionRegistry.add(owner, () => this.signalListeners.delete(listener));
  }

  /** AIS-48b: inscrições ativas (total, de um tipo de dono ou de um dono). Só leitura: testes e depuração. */
  public subscriptionCount(filter: { owner?: SubscriptionOwner; kind?: SubscriptionOwnerKind } = {}): number {
    return this.subscriptionRegistry.count(filter);
  }

  /** AIS-48b: remove UM Behavior em execução e cancela só as inscrições dele (as dos outros donos seguem). */
  public removeBehavior(nodeId: string, behaviorId: string): boolean {
    return this._behaviors?.removeBehavior(nodeId, behaviorId) ?? false;
  }

  private sceneOwner(): SubscriptionOwner {
    return { kind: 'scene', id: 'scene' };
  }

  private emit<T>(set: Iterable<T>, call: (item: T) => void, what: string): void {
    for (const item of [...set]) {
      try {
        call(item);
      } catch (error) {
        this.publish('error', 'runtime.listener_failed', `Assinante de ${what} falhou: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
  }

  /** Um quadro, na ordem do tick; compartilhado por `step` e `stepFrame`. */
  private tick(dt: number): void {
    this.emit(this.inputListeners, (cb) => cb(this.options.input), 'entrada');
    // ordem do tick (skill nodimus-play-mode): comportamentos por propriedade, depois regras (Triggers/Actions)
    this._scripts?.tick(dt); // AIS-79: aplica o que os Workers devolveram (validado) e dispara a próxima rodada; efeito com 1 quadro de latência
    this._behaviors?.update(dt);
    this._runner?.step(dt);
    this.stepAnimation(dt);
    this.stepSprites(dt);
    this._tweener?.update(dt); // AIS-59: tweens avançam com o tempo de JOGO (pausa = não passa por aqui)
    // intenção (Behaviors/regras) → física (passo fixo; corpo é o dono da pose) → instâncias → espelho no canvas
    this._physics?.step(dt);
    this._weapons?.step(); // AIS-69: voo em linha reta, alcance e remoção dos projéteis que acertaram (antes do flush dos despawns)
    this.spawns.flush(); // AIS-29g: fim de passo — despawn pedido e lifetimeMs vencido (nunca dentro de callback físico)
    this._behaviors?.lateUpdate(dt);
    this.emit(this.frameListeners, (cb) => cb(dt), 'quadro');
    this._sources?.update((handle) => this.sceneManager.current?.getInstance(handle), dt);
    this.signalBus.flushDeferred(); // fim do quadro: chamadas `deferred` das conexões (Godot CONNECT_DEFERRED)
  }

  private deliverPhysicsEvent(e: PhysicsEvent): void {
    for (const l of [...this.physicsListeners]) {
      if (l.name !== '*' && l.name !== e.name) continue;
      try {
        l.cb(e);
      } catch (error) {
        this.publish('error', 'physics.listener_failed', `Assinante de evento físico falhou: ${error instanceof Error ? error.message : String(error)}`, e.selfId, 'physics');
      }
    }
    const killFloor = e.name === 'killFloor';
    const signal = killFloor ? 'fell_out_of_world' : e.name === 'collisionEnter' || e.name === 'triggerEnter' ? 'body_entered' : 'body_exited';
    this.signalBus.emit(signal, { source: e.selfId, args: killFloor ? [e.position?.y ?? 0] : [e.otherId], origin: 'physics' });
    for (const cb of [...this.nodeSignalListeners]) {
      try {
        cb({ sourceNodeId: e.selfId, signal, args: killFloor ? [e.position?.y ?? 0] : [e.otherId] });
      } catch (error) {
        this.publish('error', 'physics.listener_failed', `Assinante de sinal falhou: ${error instanceof Error ? error.message : String(error)}`, e.selfId, 'physics');
      }
    }
  }

  /** AIS-47: câmera de jogo ativa (`null` = nenhum controlador: a viewport segue a câmera orbital do editor). */
  public get gameCamera(): GameCameraPose | null {
    return selectGameCamera([...this.gameCameras.values()]); // regra e ordem documentadas em `cameraRig/select.ts` (AIS-47b)
  }
  /** AIS-47b (decisão 28): orientação de visão da câmera de jogo ativa — leitura de quem se move relativo à câmera. Descartável como a pose. */
  public get viewBasis(): ViewBasis | null {
    return viewBasisOf(this.gameCamera);
  }
  /** AIS-47c: estado de locomoção do nó (`undefined` = sem Behavior de movimento publicando). Leitura; consumido pelos Behaviors de movimento para escolher animações (AIS-60b). */
  public getLocomotion(nodeId: string): LocomotionState | undefined {
    return this.locomotion.get(nodeId);
  }
  /** Regra de seleção com mais de uma câmera ativa: vale a primeira; as demais são avisadas uma vez (nunca silenciosas). */
  private warnIfMultipleCameras(nodeId: string, kind: GameCameraPose['kind']): void {
    if (kind !== 'camera') return;
    const poses = [...this.gameCameras.values()];
    if (countCameraPoses(poses) < 2 || this.warnedMultipleCameras.has(nodeId)) return;
    const first = selectGameCamera(poses);
    if (!first || first.nodeId === nodeId) return;
    this.warnedMultipleCameras.add(nodeId);
    this.publish('warning', 'camera.multiple_active', `Mais de uma câmera ativa com Behavior de câmera: vale a primeira da cena e esta é ignorada.`, nodeId);
  }
  public get variables(): VariableManager | null {
    return this.sceneManager.variables;
  }
  /** Sessão ainda viva (nem parada nem descartada): relido depois de cada `await`. */
  private get isLive(): boolean {
    return !this.disposed && this._status !== 'stopped';
  }
  public get isDisposed(): boolean {
    return this.disposed;
  }

  public start(): void {
    if (this.disposed || this._status !== 'idle') return;
    signalMonitor.set(this.signalBus); // o Monitor de Sinais lê o barramento da sessão mais recente
    this.sceneManager.beginSession(this.options.globals ?? []);
    this.sceneManager.load(this._snapshot);
    this.beginRuntime();
    this._status = 'running';
  }

  public pause(): void {
    if (this._status === 'running') this._status = 'paused';
  }

  public resume(): void {
    if (this._status === 'paused') this._status = 'running';
  }

  /** AIS-60: avança os mixers com o tempo de JOGO e publica `animation_started/changed/finished` no `SignalBus` (origem = o objeto animado). */
  private stepAnimation(dt: number): void {
    this.animation.step(dt);
    for (const e of this.animation.drainEvents()) void this.signalBus.emit(e.name, { source: e.playerId, args: [e.clip], origin: 'animation' });
  }

  /** AIS-76: avança os sprites animados e publica os sinais do Billboard (origem = o nó). */
  private stepSprites(dt: number): void {
    this.sprites.step(dt);
    for (const e of this.sprites.drainEvents()) {
      void this.signalBus.emit(e.name, { source: e.nodeId, args: e.name === 'frame_changed' ? [e.frame] : [e.clip], origin: 'animation' });
      if (e.name === 'animation_finished') this._runner?.dispatchSpriteFinished(e.nodeId, e.clip); // AIS-76b: Trigger On Sprite Animation Finished
    }
  }

  /** AIS-69: núcleo de armas da cena viva (`null` fora de uma cena). */
  public get weapons(): WeaponService | null {
    return this._weapons;
  }

  /** AIS-71/78d: registro de atores da cena viva — mortos e alvos (`null` fora de uma cena). */
  public get ai(): ActorRegistry | null {
    return this._ai;
  }

  /**
   * AIS-79: o sandbox de scripts da sessão. Scripts anexados a nós (`GameNode.script`) e a Action `run_script` usam este MESMO host: um Worker por
   * (nó dono × arquivo), EngineApi restrita, Command Buffer validado. As escritas voltam por `engineApi()` (o mesmo caminho dos Behaviors).
   */
  private createScripts(): ScriptHost {
    const host = new ScriptHost({
      createWorker: this.options.createScriptWorker ?? createScriptWorker,
      readSource: (path) => this.options.readScript?.(path) ?? null,
      createUrl: (source) => URL.createObjectURL(new Blob([source], { type: 'text/javascript' })),
      revokeUrl: (url) => URL.revokeObjectURL(url),
      report: (severity, code, message, nodeId) => this.publish(severity, code, message, nodeId, 'script'),
      limits: this.options.scriptLimits,
      buildSnapshot: (frame) => {
        const { snapshot, truncated } = buildScriptSnapshot(
          { time: this._runner?.sceneTime ?? 0, frame, instances: this.sceneManager.current?.getAllInstances() ?? [], variables: this.variables, input: this.options.input as never, actionNames: [] },
          { maxSnapshotNodes: this.options.scriptLimits?.maxSnapshotNodes ?? 2000 }
        );
        if (truncated) this.publishOnce('script.snapshot_truncated', 'O snapshot dos scripts foi cortado (muitos nós): scripts só enxergam parte da cena.');
        return snapshot;
      },
      sink: {
        transformSet: (_owner, id, patch) => this.engineApi().transform.set(id, patch),
        variablesSet: (owner, scope, name, value, nodeId) => this.engineApi().variables.set(scope, name, value, nodeId ?? (scope === 'local' ? (owner ?? undefined) : undefined)),
        emit: (owner, name, args) => this.engineApi().signals.emit(name, args, owner ?? undefined),
        log: (owner, level, message) => this.engineHost().log(level, message, owner ? this.sceneManager.current?.getInstance(owner) : undefined, { code: 'script.log', toOutput: level !== 'info' }),
      },
    });
    // scripts anexados a nós: carregam já (o `onReady` roda quando o Worker responder; `onUpdate` a cada quadro)
    for (const node of Object.values(this._snapshot.nodes)) {
      const path = (node as { script?: unknown }).script;
      if (typeof path !== 'string' || path.trim() === '') continue;
      if (!isRunnableScriptPath(path)) {
        this.publish('warning', 'script.invalid_path', `O script do nó "${(node as { name?: string }).name ?? node.id}" não é um .js de res://scripts/ (${String(path).slice(0, 60)}): não executa (.ts: em breve).`, node.id, 'script');
        continue;
      }
      const result = host.attach(node.id, path);
      if (!result.ok) this.publish('error', result.code, result.message, node.id, 'script');
    }
    return host;
  }

  private publishOnce(code: string, message: string): void {
    if (this.onceKeys.has(code)) return;
    this.onceKeys.add(code);
    this.publish('warning', code, message, undefined, 'script');
  }

  private createAi(): ActorRegistry {
    return new ActorRegistry((id) => {
      const i = this.sceneManager.current?.getInstance(id);
      return i && !i.disposed ? i : undefined;
    });
  }

  private createWeapons(): WeaponService {
    const host: WeaponHost = {
      now: () => this._elapsed,
      physics: () => this._physics?.bridge ?? null,
      variables: () => this.sceneManager.variables,
      instance: (id) => {
        const i = this.sceneManager.current?.getInstance(id);
        return i && !i.disposed ? i : undefined;
      },
      resolve: (ref, selfId) => {
        const scene = this.sceneManager.current;
        if (!scene) return undefined;
        const found = ref ? (scene.getInstance(ref) ?? scene.getAllInstances().find((i) => !i.disposed && i.name === ref)) : scene.getInstance(selfId);
        return found && !found.disposed ? found : undefined;
      },
      resolvePrefab: (path) => this.options.resolvePrefab?.(path),
      spawn: (ref, options) => this.spawnPrefab(ref, options),
      despawn: (rootId) => this.despawn(rootId),
      preload: (refs) => this.preloadPrefabs(refs),
      emitSignal: (signal, o) => void this.signalBus.emit(signal, { source: o.source, args: o.args, origin: 'weapon' }),
      report: (severity, code, message, nodeId) => this.publish(severity, code, message, nodeId),
      fireHook: (ownerId, behaviorId, trigger, detail) => this._runner?.dispatchHook(ownerId, behaviorId, trigger, detail),
    };
    return new WeaponService(host, (cb) => this.onPhysicsEvent('*', cb));
  }

  /** AIS-60: problema do player (clipe/rig/modelo não resolvido…) vira diagnóstico efêmero da sessão, nunca exceção. */
  public reportRuntimeProblem(severity: 'error' | 'warning', code: string, message: string, nodeId?: string): void {
    this.publish(severity, code, message, nodeId);
  }

  /** AIS-59c: rajadas de partículas pedidas desde a última chamada (o apresentador as entrega ao motor e a fila esvazia). */
  public takeParticleBursts(): ParticleBurst[] {
    return this.particleBursts.take();
  }

  /** AIS-29g: carrega prefabs que o jogo vai criar (antes de `spawnPrefab`). Devolve os que ficaram disponíveis. */
  public preloadPrefabs(refs: readonly ResourceRef[]): Promise<ResourceRef[]> {
    return this.spawns.preloadPrefabs(refs);
  }

  /** AIS-29g: registra um prefab já lido (validado por `PrefabV1Schema`). */
  public registerPrefab(ref: ResourceRef, raw: unknown): boolean {
    return this.spawns.registerPrefab(ref, raw);
  }

  /** AIS-29g: cria uma cópia do prefab na cena viva. Lança `SpawnError` (com diagnóstico) em qualquer falha; nunca deixa spawn parcial. */
  public spawnPrefab(ref: ResourceRef, options?: SpawnOptions): SpawnedHandle {
    return this.spawns.spawn(ref, options);
  }

  /** AIS-29g: destrói um objeto criado em jogo (e a subárvore) no fim do quadro. Idempotente. */
  public despawn(rootId: string): void {
    this.spawns.despawn(rootId);
  }

  /** Um quadro de simulação. Em pausa (ou durante uma troca de cena) nada avança. */
  public step(deltaTime: number): void {
    if (this._status !== 'running' || this.changing) return;
    const dt = Number.isFinite(deltaTime) && deltaTime > 0 ? deltaTime : 0;
    this._elapsed += dt;
    this.tick(dt);
  }

  /**
   * AIS-46 — "Avançar 1 Quadro": roda EXATAMENTE um quadro de simulação (`deltaTime`, padrão 1/60 s = um passo fixo da física) e
   * continua pausada. Só vale em pausa; fora dela (ou durante uma troca de cena) não faz nada e devolve `false`.
   */
  public stepFrame(deltaTime = 1 / 60): boolean {
    if (this._status !== 'paused' || this.changing) return false;
    const dt = Number.isFinite(deltaTime) && deltaTime > 0 ? deltaTime : 1 / 60;
    this._elapsed += dt;
    this.tick(dt);
    return true;
  }

  /** Para a sessão: tudo o que ela possuía é liberado; o estado autoral nunca foi tocado. Idempotente. */
  public stop(): void {
    if (this._status === 'stopped' || this.disposed) return;
    this._status = 'stopped';
    this.endRuntime();
    this.subscriptionRegistry.disposeAll(); // AIS-48b: Stop zera TODAS as inscrições (inclusive as de dono `session`)
    this.signalBus.dispose(); // conexões e fila soltas; o histórico segue legível no Monitor até o próximo Play
    this.methods.clear();
    this.spawns.dispose();
    this.sceneManager.unload();
    this.sceneManager.endSession();
  }

  /** `stop()` + descarte dos diagnósticos efêmeros (DEPOIS das assinaturas). Idempotente. */
  public dispose(): void {
    if (this.disposed) return;
    this.stop();
    this.disposed = true;
    this.sceneListeners.clear();
    this.subscriptionRegistry.disposeAll();
    this.options.diagnostics?.clearSession(this.id);
  }

  // ── cena: restart, troca, Behaviors ───────────────────────────────────────────────────────────

  /** Restart Scene: estado inicial da cena (locais restauradas do snapshot), globais PRESERVADAS. */
  public restartScene(): boolean {
    if (this.disposed || this._status === 'stopped' || !this.sceneManager.current) return false;
    this.endRuntime();
    this.sceneManager.restart();
    this.beginRuntime();
    return true;
  }

  /** Restart Behavior: recomeça só o par (nó × Behavior); a cena e os demais Behaviors/regras seguem como estão. */
  public restartBehavior(nodeId: string, behaviorId: string): boolean {
    if (this.disposed || this._status === 'stopped') return false;
    const restarted = this._behaviors?.restart(nodeId, behaviorId) ?? false;
    this._runner?.resetBehavior(nodeId, behaviorId);
    return restarted || (this._runner?.hasBehavior(nodeId, behaviorId) ?? false);
  }

  /**
   * Troca de cena. O destino é obtido ANTES de abortar (falha ao resolver = a cena atual continua intacta); depois:
   * abortar cadeias → dispose Behaviors → teardowns → limpar locais → globais preservadas → nova cena → lifecycle.
   */
  public async changeScene(target: string | AuthoringSceneSnapshot): Promise<{ committed: boolean; reason?: string }> {
    if (this.disposed || this._status === 'stopped') return { committed: false, reason: 'sessão encerrada' };
    if (this.changing) return { committed: false, reason: 'troca de cena já em andamento' };
    this.changing = true;
    try {
      let snapshot: AuthoringSceneSnapshot;
      if (typeof target === 'string') {
        if (!this.options.resolveScene) return this.failChange(`não há como carregar a cena "${target}" nesta sessão.`);
        try {
          snapshot = await this.options.resolveScene(target);
        } catch (error) {
          return this.failChange(`falha ao carregar "${target}": ${error instanceof Error ? error.message : String(error)}`);
        }
      } else {
        snapshot = target;
      }
      if (!this.isLive) return { committed: false, reason: 'sessão encerrada durante a troca' };

      this._runner?.abortChains();
      this.endRuntime();
      const result = await this.sceneManager.change(snapshot);
      if (result.committed) this._snapshot = snapshot;
      // sucesso OU falha ao construir (a cena antiga permanece): a sessão sempre volta a ter lifecycle e regras
      if (this.isLive) this.beginRuntime();
      return result.committed ? { committed: true } : { committed: false, reason: result.reason };
    } finally {
      this.changing = false;
    }
  }

  /**
   * Registra a limpeza de um sistema da cena (mundo físico, Workers, assinaturas): roda na troca/restart de cena e no
   * Stop. Devolve o disposer (cancela o registro sem executar).
   */
  public registerTeardown(fn: () => void): () => void {
    this.teardowns.add(fn);
    return () => {
      this.teardowns.delete(fn);
    };
  }

  /** Observa o ciclo da cena viva (loaded/unloaded/restarted…); devolve o disposer. */
  public onSceneEvent(listener: (e: RuntimeSceneEvent) => void): () => void {
    const off = this.sceneManager.subscribe(listener);
    this.sceneListeners.add(listener);
    return () => {
      off();
      this.sceneListeners.delete(listener);
    };
  }

  // ── pose simulada ─────────────────────────────────────────────────────────────────────────────

  /** Pose do RUNTIME (não a do authoring): é o que os consumidores veem durante o Play. `undefined` = sem instância viva. */
  public getSimulatedTransform(idOrNodeId: string): { position: [number, number, number]; rotation: [number, number, number]; scale: [number, number, number] } | undefined {
    const instance = this.sceneManager.current?.getInstance(idOrNodeId);
    if (!instance) return undefined;
    const t = instance.transform;
    return { position: [...t.position], rotation: [...t.rotation], scale: [...t.scale] };
  }

  // ── internos ──────────────────────────────────────────────────────────────────────────────────

  private failChange(reason: string): { committed: false; reason: string } {
    this.publish('error', 'logic.change_scene_failed', `Change Scene: ${reason}`);
    this.options.onLog?.({ time: this._runner?.sceneTime ?? 0, level: 'error', message: `Change Scene: ${reason}`, toOutput: true });
    return { committed: false, reason };
  }

  /** Cria o lifecycle dos Behaviors e o runner da cena viva ATUAL e inicia ambos. */
  private beginRuntime(): void {
    const scene = this.sceneManager.current;
    if (!scene) return;
    this.runtimeEpoch++;
    scene.destroyListeners.add(this.spawns.onInstanceDestroyed); // AIS-29g: corpo físico e variáveis saem com TODA instância destruída
    const states = new BehaviorRuntimeStates();
    const input = this.options.input;
    const variables = this.sceneManager.variables;
    const log = (level: 'info' | 'warn' | 'error', message: string, node?: { name: string; persistentNodeId: string; id?: string }, meta?: LogicLogMeta) =>
      this.handleLog({ time: this._runner?.sceneTime ?? 0, level, message, nodeName: node?.name, nodeId: node?.persistentNodeId, instanceId: node?.id, toOutput: level !== 'info', ...meta });
    const registry = this.subscriptionRegistry;
    this._weapons = this.createWeapons();
    this._ai = this.createAi();
    this._scripts = this.createScripts();
    const behaviors = new BehaviorLifecycleHost({
      scene,
      snapshot: this._snapshot,
      states,
      input,
      variables,
      sceneTime: () => this._runner?.sceneTime ?? 0,
      log,
      catalog: this.options.behaviorCatalog ?? BehaviorRuntimeCatalog,
      physics: () => this._physics?.bridge ?? null,
      subscriptions: {
        onPhysicsEvent: (owner, name, cb) => this.onPhysicsEvent(name, cb, owner),
        onFrame: (owner, cb) => this.onFrame(cb, owner),
        onInput: (owner, cb) => this.onInput(cb, owner),
        onSignal: (owner, name, cb) => this.onSignal(name, cb, owner),
        disposeOwner: (owner) => registry.disposeOwner(owner),
      },
      setGameCamera: (nodeId, pose) => this.publishGameCamera(nodeId, pose),
      view: () => this.viewBasis,
      engine: () => this.engineHost(),
      animation: () => this.animation,
      weapons: () => this._weapons,
      setLocomotion: (nodeId, state) => this.publishLocomotion(nodeId, state),
    });
    this._behaviors = behaviors;
    this._tweener = new Tweener({
      // erro num callback/`set` de tween: diagnóstico efêmero da sessão (o tween morre, o jogo segue)
      onError: (error, where, tween) => this.publish('error', 'tween.failed', `Tween "${tween.label ?? tween.id}" falhou em ${where}: ${error instanceof Error ? error.message : String(error)}`),
    });
    this._runner = new LogicRunner({
      scene,
      snapshot: this._snapshot,
      variables,
      input,
      random: this.options.random,
      verbose: this.options.verbose,
      behaviorStates: states,
      skipRules: (b) => behaviors.replacesRules(b),
      physics: () => this._physics?.bridge ?? null,
      audio: getActiveSoundHost,
      particles: () => this.particleHost,
      animation: () => this.animation,
      sprites: () => this.sprites,
      weapons: () => this._weapons,
      ai: () => this._ai,
      scripts: () => this._scripts,
      attachments: () => this.attachments,
      onPoseWritten: (instance) => void this._physics?.syncFromInstance(instance),
      tweener: () => this._tweener,
      host: {
        onLog: (entry) => this.handleLog(entry),
        onSignalEmitted: (name) => {
          this.signalBus.emit(name, { origin: 'logic' });
          this.emit(this.signalListeners, (l) => (l.name === '*' || l.name === name) && l.cb(name), `sinal "${name}"`);
        },
        onNodeSignal: (nodeId, signal, args) => void this.signalBus.emit(signal, { source: nodeId, args, origin: 'interaction' }),
        onUiChanged: this.options.onUiChanged,
        onQuitGame: () => queueMicrotask(() => this.options.onQuitGame?.()),
        onRestartScene: () => queueMicrotask(() => this.restartScene()),
        onChangeScene: (path) => void this.changeScene(path),
      },
    });
    behaviors.attach();
    behaviors.playStart();
    void this._weapons?.preloadFor(this._snapshot); // AIS-69: prefabs de projétil/efeito carregados na abertura (o spawn é síncrono)
    this.attachPhysics();
    this.wireSignals(scene);
  }

  /**
   * AIS-57: liga as conexões de sinal da cena ao barramento (tudo com dono `scene`: Stop/restart/troca soltam) e emite
   * `tree_entered`/`ready`.
   */
  private wireSignals(scene: RuntimeScene): void {
    const owner = this.sceneOwner();
    const bus = this.signalBus;
    const wiring = wireNodeSignalConnections({
      bus,
      nodes: this._snapshot.nodes,
      instanceOf: (id) => {
        const instance = scene.getInstance(id);
        return instance && !instance.disposed ? instance : undefined;
      },
      methods: this.methods,
      host: {
        invokeAction: (actionId, params, self) => {
          if (!this._runner) throw new Error('sem runner ativo.');
          this._runner.invokeAction(actionId, params, self);
        },
        emitFrom: (nodeId, signal, args) => void bus.emit(signal, { source: nodeId, args, origin: 'method' }),
        sound: getActiveSoundHost,
        timers: () => this._sources,
      },
      report: (code, message, nodeId) => this.publish(code === 'signal.target_missing' ? 'warning' : 'error', code, message, nodeId),
      track: (dispose) => void this.subscriptionRegistry.add(owner, dispose),
    });
    // AIS-57: emissores por tempo/estado (Timer, visibilidade, ambiente) e `tree_exited` das destruições durante o jogo
    this._sources = new NodeSignalSources(bus, scene.getAllInstances());
    scene.onInstanceDestroyed = (instance) => {
      if (bus.listenerCount('tree_exited') > 0) bus.emit('tree_exited', { source: instance.persistentNodeId, origin: 'lifecycle' });
    };
    wiring.emitLifecycle();
  }

  /** Cria o mundo físico da cena viva (só se houver corpos). Se o Rapier ainda está carregando, entra quando terminar. */
  private attachPhysics(afterLoad = false): void {
    const scene = this.sceneManager.current;
    if (!scene || this._physics || !sceneHasPhysics(scene)) return;
    const R = (this.options.getRapier ?? getRapierIfReady)();
    if (!R && afterLoad) {
      this.publish('error', 'physics.engine_unavailable', 'O motor de física não ficou disponível; a cena segue sem corpos.', undefined, 'physics');
      return;
    }
    if (!R) {
      const epoch = this.runtimeEpoch;
      void ensureRapier().then(() => {
        if (epoch === this.runtimeEpoch && this.isLive) this.attachPhysics(true);
      }).catch((error) => this.publish('error', 'physics.engine_unavailable', `O motor de física não carregou: ${error instanceof Error ? error.message : String(error)}`, undefined, 'physics'));
      return;
    }
    const host = new PhysicsHost({
      R,
      scene,
      snapshot: this._snapshot,
      defaultLinearDamp: this.options.defaultLinearDamp,
      heightfieldOf: this.options.heightfieldOf,
      report: (issue, instance) => this.publishPhysicsIssue(issue, instance),
    });
    this._physics = host;
    this.spawns.onPhysicsReady();
    // contatos e gatilhos → Triggers da lógica (um evento por participante; o gatilho usa os mesmos Triggers de colisão)
    host.bridge.onPhysicsEvent('*', (e) => {
      if (e.name !== 'killFloor') {
        const type = e.name === 'collisionEnter' ? 'on_collision_enter' : e.name === 'collisionExit' ? 'on_collision_exit' : e.name === 'triggerEnter' ? 'on_trigger_enter' : 'on_trigger_exit';
        this._runner?.dispatchContact(type, e.selfId, e.otherId, e.force);
      }
      this.deliverPhysicsEvent(e);
    });
  }

  private publishPhysicsIssue(issue: PhysicsIssue, instance: RuntimeInstance): void {
    this.options.onLog?.({ time: this._runner?.sceneTime ?? 0, level: issue.severity === 'error' ? 'error' : 'warn', message: `[${issue.code}] ${issue.message}`, nodeName: instance.name, nodeId: instance.persistentNodeId, toOutput: true });
    this.publish(issue.severity === 'error' ? 'error' : 'warning', issue.code, issue.message, instance.persistentNodeId, 'physics');
  }

  /** Descarta o runtime da cena atual: runner (assinaturas, timers, fila), Behaviors e sistemas registrados. */
  private endRuntime(): void {
    this.emitTreeExitedForTeardown();
    this._sources = null;
    this._tweener?.clear();
    this._tweener = null;
    this.particleBursts.clear();
    this.animation.clear();
    this.sprites.clear();
    this.attachments.clear();
    this._runner?.abortChains();
    this._behaviors?.dispose();
    this._behaviors = null;
    this._weapons?.dispose(); // AIS-69: projéteis, assinatura e avisos
    this._weapons = null;
    this._ai?.dispose(); // AIS-71/78d: alvos e mortos
    this._ai = null;
    this._scripts?.dispose(); // AIS-79: encerra todos os Workers e revoga as URLs de módulo
    this._scripts = null;
    this.onceKeys.clear();
    this.gameCameras.clear();
    this.locomotion.clear();
    this.warnedMultipleCameras.clear();
    this.spawns.resetScene();
    // AIS-48b: nenhuma inscrição da CENA sobrevive a ela (Stop/restart/troca); as de dono `session` seguem até o Stop
    this.subscriptionRegistry.disposeAll(['session']);
    this._runner?.dispose();
    this._runner = null;
    // mundo físico destruído DEPOIS das cadeias/assinaturas (ordem de troca de cena, AIS-44b): world.free()
    this.runtimeEpoch++;
    this._physics?.dispose();
    this._physics = null;
    const teardowns = [...this.teardowns];
    this.teardowns.clear();
    for (const fn of teardowns) {
      try {
        fn();
      } catch (error) {
        this.publish('error', 'logic.teardown_failed', `Erro ao liberar um sistema da cena: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
  }

  /** Godot: ao sair da cena (Stop, restart, troca) todo nó vivo sai da árvore, filhos primeiro. Só com ouvintes de `tree_exited`. */
  private emitTreeExitedForTeardown(): void {
    const scene = this.sceneManager.current;
    if (!scene || this.signalBus.isDisposed || this.signalBus.listenerCount('tree_exited') === 0) return;
    scene.onInstanceDestroyed = null; // sem duplicar na destruição em cadeia
    for (const instance of [...scene.getAllInstances()].reverse()) {
      this.signalBus.emit('tree_exited', { source: instance.persistentNodeId, origin: 'lifecycle' });
    }
  }

  private handleLog(entry: LogicLogEntry): void {
    this.options.onLog?.(entry);
    if (entry.level === 'info') return;
    const code = entry.code ?? (entry.level === 'error' ? 'logic.error' : 'logic.warning');
    this.publish(entry.level === 'error' ? 'error' : 'warning', code, entry.message, entry.nodeId, 'runtime', {
      phase: code.startsWith('physics.') ? 'physics' : 'runtime',
      instanceId: entry.instanceId,
      behaviorId: entry.behaviorId,
      logicId: entry.logicId,
    });
  }

  /**
   * Diagnóstico EFÊMERO (com `sessionId`): some no Stop; é o MESMO registro do `globalDiagnosticService` (AIS-32c), nunca um tipo ou
   * canal paralelo. O contexto de runtime (`instanceId`, `behaviorId`, `logicId`) vai no próprio registro.
   */
  private publish(severity: 'error' | 'warning', code: string, message: string, nodeId?: string, source: 'runtime' | 'physics' | 'script' = 'runtime', context: { phase?: 'runtime' | 'physics' | 'script'; instanceId?: string; behaviorId?: string; logicId?: string } = {}): void {
    const { phase = source, ...ids } = context;
    this.options.diagnostics?.report({ source, sourceId: this.id, severity, phase, code, message, nodeId, ...ids, sessionId: this.id }, { announce: false });
  }
}

// ── sessão ativa do editor ────────────────────────────────────────────────────────────────────────
// Um Play por vez: criar a próxima descarta a anterior (nunca duas sessões vivas, nunca dois loops).

let active: RuntimeSession | null = null;

export const getActiveRuntimeSession = (): RuntimeSession | null => active;

export function activateRuntimeSession(session: RuntimeSession | null): void {
  const previous = active;
  active = session;
  if (previous && previous !== session) previous.dispose();
}

/** Pose do runtime do nó na sessão ativa (consumidores de Play leem daqui; corpos físicos não escrevem no authoring). */
export const getSimulatedTransform = (idOrNodeId: string) => active?.getSimulatedTransform(idOrNodeId);
