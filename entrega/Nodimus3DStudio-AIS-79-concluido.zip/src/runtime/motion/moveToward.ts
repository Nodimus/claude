import * as THREE from 'three';
import type { PhysicsBridge } from '../../core/physics/PhysicsBridge';
import type { RuntimeInstance } from '../RuntimeScene';

/**
 * AIS-72 (v6.4) — `moveNodeToward`: a ÚNICA função que desloca um nó em direção a um ponto MUNDIAL, conforme o tipo de corpo. Usada pelo
 * Behavior `follow_a_path` e, depois, pela patrulha do AIS-71; nenhum outro código reimplementa movimento por tipo de corpo.
 *
 *  - `character`  → a pose pedida é a INTENÇÃO do controlador de personagem da `PhysicsBridge` (colisão, degraus e gravidade resolvidos
 *    por ele no passo seguinte); o nó anda no máximo `speed·dt` por quadro. Nunca Rapier direto.
 *  - `kinematic`/`trigger` → a pose do runtime é a autoridade do corpo cinemático (a ponte a segue).
 *  - sem corpo (ou corpo desligado) → transformação direta da instância (só estado de runtime; nada vai ao authoring).
 *  - `dynamic`/`static` → INCOMPATÍVEL: a simulação (ou a imobilidade) é dona da pose. Nada é movido; o resultado traz o código e a
 *    mensagem do diagnóstico para o chamador reportar (nunca ignora em silêncio).
 */

export type MoveStatus = 'moving' | 'arrived' | 'incompatible';

export interface MoveResult {
  status: MoveStatus;
  /** Distância percorrida neste quadro (m). */
  moved: number;
  /** Distância que ainda falta até o alvo, depois do movimento (m). */
  remaining: number;
  /** Só em `incompatible`: código estável do diagnóstico. */
  code?: 'motion.dynamic_body' | 'motion.static_body' | 'motion.no_object';
  message?: string;
}

/** O mínimo do contexto de um Behavior de que o movimento precisa (o AIS-71 passa o dele). */
export interface MotionContext {
  physics: PhysicsBridge | null;
  getNode(id: string): RuntimeInstance | undefined;
  applyTransform(instance: RuntimeInstance): void;
}

export interface WorldPoint {
  x: number;
  y: number;
  z: number;
}

/** Distância (m) abaixo da qual o nó conta como "chegou" (evita oscilar em torno do alvo). */
export const ARRIVE_EPSILON = 1e-4;

const worldPositionOf = (instance: RuntimeInstance): THREE.Vector3 | null => {
  const object = instance.object;
  if (!object) return null;
  object.updateWorldMatrix(true, false);
  return object.getWorldPosition(new THREE.Vector3());
};

/** Posição mundial atual do nó vivo (`null` sem objeto). */
export function nodeWorldPosition(instance: RuntimeInstance): WorldPoint | null {
  const p = worldPositionOf(instance);
  return p ? { x: p.x, y: p.y, z: p.z } : null;
}

export function moveNodeToward(ctx: MotionContext, nodeId: string, target: WorldPoint, speed: number, dt: number): MoveResult {
  const instance = ctx.getNode(nodeId);
  const here = instance ? worldPositionOf(instance) : null;
  if (!instance || !here) {
    return { status: 'incompatible', moved: 0, remaining: 0, code: 'motion.no_object', message: `o nó "${nodeId}" não tem objeto vivo na cena` };
  }

  const bridge = ctx.physics && !ctx.physics.isDisposed ? ctx.physics : null;
  const id = instance.persistentNodeId;
  const mode = bridge && bridge.has(id) && bridge.isEnabled(id) ? bridge.modeOf(id) : undefined;
  if (mode === 'dynamic') {
    return { status: 'incompatible', moved: 0, remaining: here.distanceTo(new THREE.Vector3(target.x, target.y, target.z)), code: 'motion.dynamic_body', message: `o nó "${instance.name}" tem corpo dinâmico: a física é dona da pose. Use corpo "kinematic" ou "character" (ou sem colisão) para seguir um caminho` };
  }
  if (mode === 'static') {
    return { status: 'incompatible', moved: 0, remaining: here.distanceTo(new THREE.Vector3(target.x, target.y, target.z)), code: 'motion.static_body', message: `o nó "${instance.name}" tem corpo estático: ele não pode ser movido. Use corpo "kinematic" ou "character" (ou sem colisão)` };
  }

  const goal = new THREE.Vector3(target.x, target.y, target.z);
  const delta = goal.clone().sub(here);
  const distance = delta.length();
  const maxStep = Math.max(0, speed) * Math.max(0, dt);
  if (distance <= ARRIVE_EPSILON) return { status: 'arrived', moved: 0, remaining: distance };

  const step = Math.min(distance, maxStep);
  const next = step >= distance ? goal : here.clone().addScaledVector(delta, step / distance);
  const parent = instance.object!.parent;
  parent?.updateWorldMatrix(true, false);
  const local = parent ? parent.worldToLocal(next.clone()) : next;
  instance.transform.position = [local.x, local.y, local.z];
  ctx.applyTransform(instance);

  const remaining = distance - step;
  return { status: remaining <= ARRIVE_EPSILON ? 'arrived' : 'moving', moved: step, remaining };
}
