import * as THREE from 'three';
import type { AuthoringSceneSnapshot } from '../types/runtime';
import { measureLocalBounds, type Vec3 } from '../core/physics/bounds';
import { PhysicsBridge, type PoseSource } from '../core/physics/PhysicsBridge';
import { readPhysics } from '../core/physics/physicsConfig';
import { readAttachment } from '../core/attachment/boneAttachment';
import { resolvePhysicsDescriptor, type HeightfieldData, type PhysicsIssue, type TriMesh } from '../core/physics/physicsDescriptor';
import type { RapierModule } from '../core/physics/rapierInit';
import type { RuntimeInstance, RuntimeScene } from './RuntimeScene';
import { terrainHeightfieldOf } from '../core/terrainObject';
import { vegetationDataOf } from '../core/vegetation/vegetationBuild';
import { readWater } from '../core/water/waterConfig';
import { computeBuoyancy, type WaterVolume } from '../core/water/buoyancy';

/**
 * AIS-45 — PhysicsHost: liga o mundo físico (`PhysicsBridge`) à cena VIVA de uma `RuntimeSession`.
 *
 *  - ao criar, resolve um descritor por instância com `properties.physics` (`resolvePhysicsDescriptor`, a camada B única) usando a
 *    geometria e a pose MUNDIAL dos objetos vivos — nada de corpo para nó sem bloco ou com `enabled:false`;
 *  - a cada quadro roda o passo fixo da ponte e copia a pose simulada dos corpos `dynamic`/`character` para a instância de runtime
 *    (convertendo mundo → local pela cadeia de pais). A pose simulada vive só na instância: NUNCA volta ao authoring;
 *  - `kinematic`/`trigger`/`character` recebem da instância a pose que a lógica pediu (a intenção).
 *
 * O mundo só existe durante a sessão: `dispose()` libera o `World` do Rapier. Sem React, sem DOM.
 */

export interface PhysicsHostOptions {
  R: RapierModule;
  scene: RuntimeScene;
  snapshot: AuthoringSceneSnapshot;
  /** `settings.physics.defaultLinearDamp` do projeto (corpos `dynamic`). */
  defaultLinearDamp?: number;
  /** Problemas ao criar corpos (escala não uniforme, malha sem geometria…): a sessão publica como diagnóstico efêmero. */
  report: (issue: PhysicsIssue, instance: RuntimeInstance) => void;
  /** Buffer de alturas do terreno de um nó (decisão 23; o AIS-50 fornece). Ausente = nó com `heightfield` fica sem corpo, com aviso. */
  heightfieldOf?: (instance: RuntimeInstance) => HeightfieldData | null;
}

const isVec = (g: any): g is Vec3 => !!g && Number.isFinite(g.x) && Number.isFinite(g.y) && Number.isFinite(g.z);

/** Gravidade da SCENE (decisão 17): `environmentSettings.gravity` do snapshot (plano ou aninhado em `environment`); padrão -9.8 em Y. */
export function gravityOf(snapshot: AuthoringSceneSnapshot): Vec3 {
  const settings = snapshot.sceneSettings as any;
  const g = settings?.gravity ?? settings?.environment?.gravity;
  return isVec(g) ? { x: g.x, y: g.y, z: g.z } : { x: 0, y: -9.8, z: 0 };
}

const _p = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _s = new THREE.Vector3();
const _m = new THREE.Matrix4();
const _inv = new THREE.Matrix4();

/**
 * Há algum nó com bloco de física ligado? (a sessão só carrega o Rapier/mundo se houver)
 *
 * AIS-59b (D2): um bloco PRESENTE e LIGADO conta mesmo inválido (mesma regra do `resolvePhysicsDescriptor`, que reporta o motivo e deixa o
 * nó sem corpo). Antes só o bloco válido contava: com um bloco inválido SOZINHO na cena o mundo nem era criado e o nó ficava sem colisão
 * em silêncio.
 */
export function sceneHasPhysics(scene: RuntimeScene): boolean {
  return scene.getAllInstances().some((i) => {
    const cfg = readPhysics(i.properties);
    if (cfg) return cfg.enabled;
    const raw = i.properties?.physics;
    return !!raw && typeof raw === 'object' && (raw as { enabled?: unknown }).enabled !== false;
  });
}

function trianglesOf(object: THREE.Object3D, worldScale: Vec3): TriMesh | null {
  object.updateWorldMatrix(true, true);
  const inverse = object.matrixWorld.clone().invert();
  const vertices: number[] = [];
  const indices: number[] = [];
  object.traverse((child) => {
    const mesh = child as THREE.Mesh;
    if (!mesh.isMesh || !mesh.geometry) return;
    const position = mesh.geometry.getAttribute('position');
    if (!position) return;
    const toNode = inverse.clone().multiply(mesh.matrixWorld);
    const base = vertices.length / 3;
    const v = new THREE.Vector3();
    for (let i = 0; i < position.count; i++) {
      v.fromBufferAttribute(position, i).applyMatrix4(toNode);
      vertices.push(v.x * worldScale.x, v.y * worldScale.y, v.z * worldScale.z); // o Rapier não escala colisores
    }
    const index = mesh.geometry.getIndex();
    if (index) for (let i = 0; i < index.count; i++) indices.push(base + index.getX(i));
    else for (let i = 0; i < position.count; i++) indices.push(base + i);
  });
  if (vertices.length < 9 || indices.length < 3) return null;
  return { vertices: new Float32Array(vertices), indices: new Uint32Array(indices) };
}

export class PhysicsHost {
  readonly bridge: PhysicsBridge;
  private readonly scene: RuntimeScene;
  private readonly byNode = new Map<string, RuntimeInstance>();
  /** AIS-68: altura (m, mundo) de cada corpo, medida ao criar: base do empuxo. */
  private readonly heights = new Map<string, number>();
  /** AIS-68: pares `água:corpo` que estavam dentro no passo anterior (Enter/Exit). */
  private readonly inWater = new Set<string>();

  private readonly options: PhysicsHostOptions;

  constructor(options: PhysicsHostOptions) {
    const { R, scene, snapshot } = options;
    this.options = options;
    this.scene = scene;
    this.bridge = new PhysicsBridge(R, { gravity: gravityOf(snapshot) });
    scene.rootObject.updateMatrixWorld(true);
    for (const instance of scene.getAllInstances()) this.createBody(instance);
  }

  /**
   * AIS-29g — corpo de UMA instância (criada depois do início do Play, ex.: `spawnPrefab`). Mesma resolução do construtor
   * (`resolvePhysicsDescriptor`): sem bloco `physics` ligado não há corpo. Devolve `true` se o nó ganhou corpo.
   */
  addInstance(instance: RuntimeInstance): boolean {
    this.scene.rootObject.updateMatrixWorld(true);
    return this.createBody(instance);
  }

  /**
   * AIS-29g — remove o corpo de uma instância destruída (`destroy_node`, spawn removido, filho de pai destruído). Antes só o Kill
   * Floor chamava `bridge.remove`: o collider de um nó destruído seguia vivo no mundo. Idempotente.
   */
  removeInstance(nodeId: string): void {
    this.byNode.delete(nodeId);
    this.heights.delete(nodeId);
    for (const key of [...this.inWater]) if (key.endsWith(`|${nodeId}`) || key.startsWith(`${nodeId}|`)) this.inWater.delete(key);
    if (!this.bridge.isDisposed) this.bridge.remove(nodeId);
  }

  private createBody(instance: RuntimeInstance): boolean {
    const options = this.options;
    const object = instance.object;
    if (!object) return false;
    object.updateWorldMatrix(true, false);
    object.matrixWorld.decompose(_p, _q, _s);
    const worldScale = { x: Math.abs(_s.x), y: Math.abs(_s.y), z: Math.abs(_s.z) };
    const config = readPhysics(instance.properties);
    // AIS-61 §4: nó preso a osso anda com a animação; um corpo físico ficaria parado na pose de autoria. Sem corpo, com motivo (nunca em silêncio).
    if (config?.enabled && readAttachment(instance.properties)) {
      options.report({ code: 'physics.attached_to_bone', severity: 'warning', nodeId: instance.persistentNodeId, message: `"${instance.name}" está preso a um osso: a colisão dele é ignorada em jogo (desligue "Colisão" ou solte o nó do osso).` }, instance);
      return false;
    }
    const wantsMesh = config?.enabled && (config.shape === 'mesh' || (config.shape === 'auto' && config.bodyMode === 'static' && instance.properties.meshType === 'TorusMesh'));
    const result = resolvePhysicsDescriptor({
      nodeId: instance.persistentNodeId,
      name: instance.name,
      nodeType: instance.type,
      properties: instance.properties,
      bounds: measureLocalBounds(object),
      worldScale,
      worldPosition: { x: _p.x, y: _p.y, z: _p.z },
      worldRotation: { x: _q.x, y: _q.y, z: _q.z, w: _q.w },
      triangles: wantsMesh ? trianglesOf(object, worldScale) : null,
      parts: vegetationDataOf(object)?.colliders,
      heightfield: (options.heightfieldOf ?? ((i: RuntimeInstance) => terrainHeightfieldOf(i.object)))(instance),
      defaultLinearDamp: options.defaultLinearDamp,
    });
    for (const issue of result.issues) options.report(issue, instance);
    if (!result.descriptor) return false;
    try {
      this.bridge.addBody(result.descriptor);
      this.byNode.set(instance.persistentNodeId, instance);
      if (config?.floats) this.heights.set(instance.persistentNodeId, Math.max(1e-3, (measureLocalBounds(object)?.size.y ?? 1) * worldScale.y));
      return true;
    } catch (error) {
      options.report({ code: 'physics.invalid_config', severity: 'error', nodeId: instance.persistentNodeId, message: `"${instance.name}": ${error instanceof Error ? error.message : String(error)}` }, instance);
      return false;
    }
  }

  /**
   * AIS-59b (D6) — a lógica escreveu a pose (`transform`) de uma instância: se o nó é um corpo DINÂMICO, a simulação é dona da pose e
   * sobrescreveria a escrita no quadro seguinte; então a pose MUNDIAL do objeto vivo é empurrada para o corpo (velocidades preservadas).
   * Outros modos seguem a pose da instância pelo `PoseSource`. Devolve `true` se empurrou.
   */
  syncFromInstance(instance: RuntimeInstance): boolean {
    const id = instance.persistentNodeId;
    const object = instance.object;
    if (!object || instance.disposed || this.bridge.isDisposed || this.bridge.modeOf(id) !== 'dynamic' || !this.bridge.isEnabled(id)) return false;
    object.updateWorldMatrix(true, false);
    object.matrixWorld.decompose(_p, _q, _s);
    this.bridge.setPose(id, { position: { x: _p.x, y: _p.y, z: _p.z }, rotation: { x: _q.x, y: _q.y, z: _q.z, w: _q.w } });
    return true;
  }

  /** Pose MUNDIAL que a lógica pediu para o nó (a da instância de runtime, já com a hierarquia). */
  private poseSource: PoseSource = (nodeId) => {
    const instance = this.byNode.get(nodeId);
    const object = instance?.object;
    if (!instance || instance.disposed || !object) return null;
    object.updateWorldMatrix(true, false);
    object.matrixWorld.decompose(_p, _q, _s);
    return { position: { x: _p.x, y: _p.y, z: _p.z }, rotation: { x: _q.x, y: _q.y, z: _q.z, w: _q.w } };
  };

  /** Quadro de simulação: passo fixo + cópia da pose simulada para as instâncias (só se algum passo rodou). */
  step(dt: number): void {
    if (this.bridge.isDisposed) return;
    this.applyWater(dt);
    const steps = this.bridge.step(dt, this.poseSource);
    if (steps === 0) return;
    // Kill Floor (AIS-49): o corpo já foi removido (depois do evento `killFloor`); a instância some junto
    for (const nodeId of this.bridge.takeDiscarded()) {
      const instance = this.byNode.get(nodeId);
      this.byNode.delete(nodeId);
      if (instance && !instance.disposed) this.scene.destroyInstance(instance.id);
    }
    this.bridge.forEachSimulated((nodeId, pose) => {
      const instance = this.byNode.get(nodeId);
      if (!instance || instance.disposed || !instance.object) return;
      this.writeWorldPose(instance, pose.position, pose.rotation);
    });
  }

  /** Volumes dos `WaterPlane` vivos (retângulo XZ + nível Y no MUNDO). */
  private waterVolumes(): { id: string; volume: WaterVolume }[] {
    const out: { id: string; volume: WaterVolume }[] = [];
    for (const instance of this.scene.getAllInstances()) {
      if (instance.type !== 'WaterPlane' || instance.disposed || !instance.object || !instance.visible) continue;
      instance.object.updateWorldMatrix(true, false);
      instance.object.matrixWorld.decompose(_p, _q, _s);
      const yaw = new THREE.Euler().setFromQuaternion(_q, 'YXZ').y;
      const w = readWater(instance.properties);
      out.push({ id: instance.persistentNodeId, volume: { cx: _p.x, cz: _p.z, halfW: (w.width * Math.abs(_s.x)) / 2, halfD: (w.depth * Math.abs(_s.z)) / 2, yaw, surfaceY: _p.y, buoyancy: w.buoyancy, drag: w.drag } });
    }
    return out;
  }

  /**
   * AIS-68 (Emenda v5.5) — flutuação: corpo `dynamic` com `floats` dentro do retângulo e abaixo da superfície recebe empuxo
   * proporcional à profundidade submersa + arrasto linear/angular; entrar/sair do retângulo publica `triggerEnter`/`triggerExit` (um evento por
   * participante, como nos gatilhos). Tudo pela `PhysicsBridge`; nada vai ao authoring. Personagem nadando continua fora do escopo.
   */
  private applyWater(dt: number): void {
    if (this.heights.size === 0) return;
    const waters = this.waterVolumes();
    if (waters.length === 0 && this.inWater.size === 0) return;
    const gravity = Math.abs(gravityOf(this.options.snapshot).y) || 9.8;
    const seen = new Set<string>();
    for (const [bodyId, height] of this.heights) {
      if (this.bridge.modeOf(bodyId) !== 'dynamic' || !this.bridge.isEnabled(bodyId)) continue;
      const pose = this.bridge.getPose(bodyId);
      const mass = this.bridge.massOf(bodyId);
      if (!pose || !mass) continue;
      for (const { id: waterId, volume } of waters) {
        const r = computeBuoyancy(volume, { x: pose.position.x, y: pose.position.y, z: pose.position.z, height, mass }, gravity, dt);
        const key = `${waterId}|${bodyId}`;
        const inside = r.submerged > 0;
        if (inside) seen.add(key);
        if (inside && !this.inWater.has(key)) {
          this.bridge.publish({ name: 'triggerEnter', selfId: waterId, otherId: bodyId });
          this.bridge.publish({ name: 'triggerEnter', selfId: bodyId, otherId: waterId });
        }
        if (r.force > 0) {
          this.bridge.addForce(bodyId, { x: 0, y: r.force, z: 0 });
          this.bridge.scaleVelocities(bodyId, r.linearFactor, r.angularFactor);
        }
      }
    }
    for (const key of [...this.inWater]) {
      if (seen.has(key)) continue;
      const [waterId, bodyId] = key.split("|");
      this.bridge.publish({ name: 'triggerExit', selfId: waterId, otherId: bodyId });
      this.bridge.publish({ name: 'triggerExit', selfId: bodyId, otherId: waterId });
    }
    this.inWater.clear();
    for (const key of seen) this.inWater.add(key);
  }

  /** Mundo → local pela cadeia de pais; nunca toca o authoring. Mantém a escala da instância. */
  writeWorldPose(instance: RuntimeInstance, position: Vec3, rotation: { x: number; y: number; z: number; w: number }): void {
    const object = instance.object;
    if (!object) return;
    object.parent?.updateWorldMatrix(true, false);
    const parentWorld = object.parent ? object.parent.matrixWorld : _m.identity();
    _inv.copy(parentWorld).invert();
    const world = new THREE.Matrix4().compose(new THREE.Vector3(position.x, position.y, position.z), new THREE.Quaternion(rotation.x, rotation.y, rotation.z, rotation.w), new THREE.Vector3(1, 1, 1));
    const local = _inv.multiply(world);
    local.decompose(_p, _q, _s);
    const euler = new THREE.Euler().setFromQuaternion(_q, 'XYZ');
    instance.transform.position = [_p.x, _p.y, _p.z];
    instance.transform.rotation = [THREE.MathUtils.radToDeg(euler.x), THREE.MathUtils.radToDeg(euler.y), THREE.MathUtils.radToDeg(euler.z)];
    this.scene.applyInstanceTransform(instance);
  }

  /** Mundo físico liberado (`world.free()`); idempotente. */
  dispose(): void {
    this.bridge.dispose();
    this.byNode.clear();
  }
}
