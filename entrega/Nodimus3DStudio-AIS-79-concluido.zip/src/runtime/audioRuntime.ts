/**
 * @file audioRuntime.ts
 * @module runtime
 *
 * AIS-52: áudio do Play. UM gerenciador de vozes (`SoundHost`) por Play: toca os nós `AudioPlayer`/`AudioPlayer3D` com
 * `autoplay` e executa as Actions `play_sound`/`stop_sound`/`set_sound_properties`. Aplica o mixer do projeto (master ×
 * música/efeitos × volume do nó), atenuação por distância (PannerNode), Doppler e a cadeia de efeitos do nó
 * (reverb, eco, passa-baixa, distorção). Estado descartável: `dispose()` (Stop) para todas as vozes; nada aqui escreve no
 * modelo autoral. O Publish consumirá o mesmo módulo (AIS-85).
 */

import * as THREE from 'three';
import type { GameNode } from '../types/node';
import type { ProjectSettings } from '../types/project';
import * as engine from '../core/sound/audioEngine';
import type { Voice, VoiceOptions } from '../core/sound/audioEngine';
import {
  dopplerRate, fxParams, normalizeAttenuation, normalizeChannel, normalizeFx, pannerParams, voiceGain,
} from '../core/sound/audioMath';
import type { SoundChannel } from '../core/sound/soundPresets';

/** Superfície do motor de áudio usada pelo host (injetável nos testes; o padrão é o Web Audio real). */
export interface SoundEngine {
  decodeAudio(source: string): Promise<AudioBuffer | null>;
  playVoice(options: VoiceOptions): Voice | null;
  resumeAudio(): Promise<unknown>;
  setListener(pos: { x: number; y: number; z: number }, forward: { x: number; y: number; z: number }): void;
}

export interface SoundHostArgs {
  nodes: Record<string, GameNode>;
  /** Objeto de cena do nó (posição de mundo do emissor). */
  objectOf(nodeId: string): THREE.Object3D | undefined;
  /** Fonte tocável (data URL) de um arquivo do projeto pelo caminho `res://…`. */
  sourceOf(path: string): string | undefined;
  /** Mixer do projeto, lido a cada quadro (mudar o volume durante o Play vale na hora). */
  getSettings(): ProjectSettings['audio'] | undefined;
  /** Ouvinte = câmera ativa. */
  getListener(): THREE.Camera | undefined;
  /** AIS-57: um som terminou sozinho (fim do arquivo; loop e `stop` não contam): vira o sinal `finished` do emissor. */
  onFinished?(emitterId: string, path: string): void;
  engine?: SoundEngine;
}

export interface PlaySoundSpec {
  /** ID autoral do nó emissor. */
  emitterId: string;
  /** Caminho `res://audio/...` do arquivo. */
  path: string;
  /** Multiplicador do volume do nó (1 = o do nó). */
  volume?: number;
  pitch?: number;
  /** `false` toca sem posição (2D). */
  spatial?: boolean;
}

interface ActiveVoice {
  voice: Voice;
  emitterId: string;
  path: string;
  channel: SoundChannel;
  volumeDb: number;
  /** Multiplicadores controlados pelas Actions (`set_sound_properties`). */
  userVolume: number;
  userPitch: number;
  basePitch: number;
  doppler: boolean;
  spatial: boolean;
  lastPos?: THREE.Vector3;
}

export interface SoundHost {
  /** Quadro de simulação (ouvinte, ganho do mixer, posição dos emissores, Doppler). */
  update(dt: number): void;
  /** Toca um som a partir de um emissor; devolve uma mensagem de erro (para o log) ou `null` se iniciou. */
  play(spec: PlaySoundSpec): string | null;
  /** Para os sons do emissor (só o arquivo indicado, se `path` vier); devolve quantas vozes parou. */
  stop(emitterId: string, path?: string): number;
  /** Ajusta volume/pitch das vozes do emissor; devolve quantas vozes afetou. */
  setProperties(emitterId: string, props: { volume?: number; pitch?: number }): number;
  dispose(): void;
}

// A sessão de Play tem no máximo um host ativo; as Actions o alcançam por aqui (como o `globalInputManager`).
let activeHost: SoundHost | null = null;
export const setActiveSoundHost = (host: SoundHost | null): void => {
  activeHost = host;
};
export const getActiveSoundHost = (): SoundHost | null => activeHost;

export function createSoundHost(args: SoundHostArgs): SoundHost {
  const eng: SoundEngine = args.engine ?? engine;
  const voices: ActiveVoice[] = [];
  let disposed = false;
  const prevListener = new THREE.Vector3();
  let hasPrevListener = false;
  const listenerPos = new THREE.Vector3();
  const listenerFwd = new THREE.Vector3();

  void eng.resumeAudio();

  const positionOf = (emitterId: string): THREE.Vector3 => {
    const obj = args.objectOf(emitterId);
    if (obj) return obj.getWorldPosition(new THREE.Vector3());
    const p = (args.nodes[emitterId]?.properties.position ?? { x: 0, y: 0, z: 0 }) as { x: number; y: number; z: number };
    return new THREE.Vector3(p.x, p.y, p.z);
  };

  /** Inicia uma voz a partir das propriedades do nó emissor (canal, atenuação, Doppler, efeito). */
  const start = (node: GameNode | undefined, emitterId: string, path: string, source: string, opts: { volume: number; pitch?: number; loop?: boolean; spatial: boolean }): void => {
    void eng.decodeAudio(source).then((buffer) => {
      if (!buffer || disposed) return;
      const p = node?.properties ?? {};
      const channel = normalizeChannel(p.channel ?? (node?.type === 'AudioPlayer' ? 'Music' : 'SFX'));
      const volumeDb = typeof p.volumeDb === 'number' ? p.volumeDb : 0;
      const basePitch = (typeof p.pitchScale === 'number' ? p.pitchScale : 1) * (opts.pitch ?? 1);
      const pos = opts.spatial ? positionOf(emitterId) : undefined;
      const fx = normalizeFx(p.soundFX);
      const voice = eng.playVoice({
        buffer,
        gain: voiceGain(channel, volumeDb, args.getSettings()) * opts.volume,
        pitch: basePitch,
        loop: opts.loop ?? p.loop === true,
        onEnded: () => {
          const i = voices.findIndex((v) => v.voice === voice);
          if (i >= 0) voices.splice(i, 1);
          if (!disposed) args.onFinished?.(emitterId, path);
        },
        fx: fx === 'none' ? undefined : fxParams(fx, typeof p.fxGain === 'number' ? p.fxGain : 40, typeof p.fxRoomSize === 'number' ? p.fxRoomSize : 65),
        spatial: pos ? { params: pannerParams({ unitSize: p.unitSize, maxDistance: p.maxDistance, attenuation: normalizeAttenuation(p.attenuation) }), position: pos } : undefined,
      });
      if (!voice) return;
      voices.push({
        voice, emitterId, path, channel, volumeDb,
        userVolume: opts.volume, userPitch: opts.pitch ?? 1, basePitch: typeof p.pitchScale === 'number' ? p.pitchScale : 1,
        doppler: opts.spatial && p.dopplerEffect === true,
        spatial: opts.spatial,
        lastPos: pos?.clone(),
      });
    });
  };

  // autoplay dos nós de áudio da cena
  for (const node of Object.values(args.nodes)) {
    if (node.type !== 'AudioPlayer' && node.type !== 'AudioPlayer3D') continue;
    const p = node.properties;
    if (p.autoplay !== true || p.paused === true) continue;
    const path = typeof p.stream === 'string' ? p.stream : '';
    const source = args.sourceOf(path);
    if (!source) continue;
    start(node, node.id, path, source, { volume: 1, loop: p.loop !== false, spatial: node.type === 'AudioPlayer3D' });
  }

  return {
    play(spec) {
      if (disposed) return 'o áudio do Play já foi encerrado.';
      if (!spec.path) return 'nenhum arquivo de som foi escolhido.';
      const source = args.sourceOf(spec.path);
      if (!source) return `o arquivo "${spec.path}" não foi encontrado no projeto.`;
      start(args.nodes[spec.emitterId], spec.emitterId, spec.path, source, {
        volume: Math.max(0, spec.volume ?? 1),
        pitch: Math.max(0.1, spec.pitch ?? 1),
        loop: false,
        spatial: spec.spatial !== false,
      });
      return null;
    },
    stop(emitterId, path) {
      let stopped = 0;
      for (let i = voices.length - 1; i >= 0; i--) {
        const v = voices[i];
        if (v.emitterId !== emitterId || (path && v.path !== path)) continue;
        v.voice.stop();
        voices.splice(i, 1);
        stopped++;
      }
      return stopped;
    },
    setProperties(emitterId, props) {
      let changed = 0;
      for (const v of voices) {
        if (v.emitterId !== emitterId) continue;
        if (typeof props.volume === 'number') v.userVolume = Math.max(0, props.volume);
        if (typeof props.pitch === 'number') {
          v.userPitch = Math.max(0.1, props.pitch);
          v.voice.setPitch(v.basePitch * v.userPitch);
        }
        changed++;
      }
      return changed;
    },
    update(dt) {
      if (disposed) return;
      const cam = args.getListener();
      let listenerVelocity: THREE.Vector3 | null = null;
      if (cam) {
        cam.getWorldPosition(listenerPos);
        cam.getWorldDirection(listenerFwd);
        eng.setListener(listenerPos, listenerFwd);
        if (hasPrevListener && dt > 0) listenerVelocity = listenerPos.clone().sub(prevListener).divideScalar(dt);
        prevListener.copy(listenerPos);
        hasPrevListener = true;
      }
      const settings = args.getSettings();
      for (const v of voices) {
        v.voice.setGain(voiceGain(v.channel, v.volumeDb, settings) * v.userVolume);
        if (!v.spatial) continue;
        const pos = positionOf(v.emitterId);
        v.voice.setPosition(pos.x, pos.y, pos.z);
        if (v.doppler && v.lastPos && dt > 0 && cam) {
          const sourceVelocity = pos.clone().sub(v.lastPos).divideScalar(dt);
          const toListener = listenerPos.clone().sub(pos).normalize();
          const closing = sourceVelocity.dot(toListener) - (listenerVelocity ? listenerVelocity.dot(toListener) : 0);
          v.voice.setPitch(dopplerRate(v.basePitch * v.userPitch, closing));
        }
        v.lastPos?.copy(pos);
      }
    },
    dispose() {
      disposed = true;
      for (const v of voices.splice(0)) v.voice.stop();
    },
  };
}
