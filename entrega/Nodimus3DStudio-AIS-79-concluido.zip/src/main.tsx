import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import './index.css';
import { themeService } from './core/theme/themeService';

// Inicialização síncrona do tema antes da montagem para evitar flash
themeService.initTheme();

const rootElement = document.getElementById('root')!;

/** Falha ao preparar o workspace em disco: mensagem explícita (nunca cai em silêncio no localStorage — decisão 14). */
function renderStorageError(error: unknown): void {
  const message = (error as { message?: string } | null)?.message ?? String(error);
  rootElement.innerHTML = '';
  const box = document.createElement('div');
  box.style.cssText = 'padding:24px;font:13px/1.5 system-ui,sans-serif;color:#dfe4ec;background:#12151d;height:100vh';
  const title = document.createElement('h2');
  title.textContent = 'Não foi possível abrir a pasta de projetos';
  const text = document.createElement('p');
  text.textContent = message;
  const hint = document.createElement('p');
  hint.textContent = 'Confira se a pasta existe e se o editor tem permissão para gravar nela. Para voltar à pasta padrão (Documentos/Nodimus3DStudio), use o botão abaixo.';
  const retry = document.createElement('button');
  retry.textContent = 'Tentar de novo';
  retry.onclick = () => location.reload();
  const reset = document.createElement('button');
  reset.textContent = 'Usar a pasta padrão';
  reset.style.marginLeft = '8px';
  reset.onclick = () => {
    try {
      localStorage.removeItem('nodimus_workspace_root');
    } catch {
      /* sem localStorage */
    }
    location.reload();
  };
  box.append(title, text, hint, retry, reset);
  rootElement.append(box);
}

// AIS-30c: o armazenamento (workspace em disco no desktop) precisa estar pronto ANTES de qualquer módulo que leia o projeto
// (o `AuthoringModel` global lê o projeto na criação), por isso App e ganchos de teste entram por import dinâmico.
async function bootstrap(): Promise<void> {
  try {
    const { ProjectStorage } = await import('./core/projectStorage');
    await ProjectStorage.initialize();
  } catch (error) {
    console.error('[bootstrap] falha ao preparar o armazenamento', error);
    renderStorageError(error);
    return;
  }
  const [{ default: App }, { installDevHooks }] = await Promise.all([import('./App.tsx'), import('./devHooks')]);
  installDevHooks(); // só em `vite dev`: gancho de teste e2e (window.__nodimus)
  createRoot(rootElement).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}

void bootstrap();
