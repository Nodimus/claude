> **v5.3:** relatório histórico (v4.x). Os `nº` citados no corpo foram atualizados para a ordem vigente de 120 posições (v5.4: posições ≥ 38 deslocadas em +1) (`docs/prompts/ORDEM-CANONICA-V4.md`).

> **v5.0.0 (Claude Code):** B2/testes resolvido com Vitest antecipado; R3 (sobras do template do AI Studio) resolvido; as menções a "Preview" e "System Instructions" abaixo são históricas (hoje: `npm run dev` no navegador e `CLAUDE.md`).

# Relatório de bloqueios — Nodimus Prompts v4.1 × SPECs × casca

Base: 104 prompts, 56 SPECs, `ORDEM-CANONICA-V4.md` e o zip `nodimus-studio---game-editor-ide` (59 arquivos em `src/`). Tudo abaixo foi conferido nos arquivos; onde não foi possível conferir (páginas externas), está marcado.

Legenda: **DECISÃO** = você precisa escolher antes de o agente prosseguir · **CORRIGIDO** = já aplicado nesta padronização · **NOTA** = ajuste aplicado como nota no prompt, reversível · **RISCO** = não bloqueia hoje, gera retrabalho.

---

## 0. Decisões tomadas (v4.2)

- **B1:** vocabulário da casca (`SceneData`, `GameNode`, `NodeType`, `CommandManager`); `Layer`/`Instance` e sufixos `…Node` removidos; UI = `Overlay2D`/`TextOverlay2D`/`ButtonOverlay2D`.
- **B2:** opção C (checklist reproduzível; `vitest` só na fase desktop, AIS-AP Parte B3).
- **B3:** `AIS-P0` e `AIS-AP` incluídos em `prompts/`.
- **AIS-44:** depende só de `RuntimeSessionContract`. **AIS-46/77/25b:** Play dentro da viewport (`RuntimeViewportHost`), sem `PlaySimulationModal`. **AIS-47:** `InputManager` do AIS-40b. **AIS-04, 36, 37:** notas aprovadas.

## 1. Decisões que travavam a implementação (histórico)

### B1 — Três vocabulários para o modelo de dados · RESOLVIDO (a casca manda)
| Fonte | Vocabulário |
|---|---|
| Casca (`src/types/node.ts`, `src/nodes/registry.ts`) | `GameNode` + `NodeType` (20 tipos: Spatial, MeshInstance, Camera, OmniLight, Billboard, Overlay2D, AudioPlayer3D…) |
| AIS-03 (histórico pré-B1) | Usava sufixos `…Node`; **corrigido** para `GameNode` + `NodeType` da casca, incluindo `OmniLight` |
| Skills embutidas (histórico pré-B1) | Vocabulário legado `Scene → Layer → Instance`; **não é contrato executável** e deve ser interpretado pelo vocabulário B1 (`SceneData`/`GameNode`/`NodeType`) |

Consequência: cada prompt pode criar um tipo diferente para o mesmo conceito, e o AIS-03b (schemas persistentes) grava o que o AIS-03 tipou. Também 26 prompts chamam de `CommandStack` o componente que a casca e o AIS-18 chamam `CommandManager`.

Opções (regra PARE E PERGUNTE):
- **A** — casca manda: `GameNode` é o modelo; as skills são reescritas para Node.
- **B (histórica, rejeitada por B1)** — migrar a casca para `Scene/Layer/Instance`. **NÃO EXECUTAR**; mantida apenas como registro da decisão.
- **C** — canônico `Instance`, com `GameNode` como alias/adapter até o AIS-03f; tabela de mapeamento no AIS-03.
Decisão final aplicada: **A / B1 — a casca manda**. `GameNode` + `NodeType` são canônicos; `Layer`/`Instance` não são tipos persistentes. As opções acima permanecem somente como histórico da auditoria.

### B2 — "Teste obrigatório" sem executor de testes · RESOLVIDO (opção C)
16 prompts exigem testes; nenhum declara runner, `package.json` não tem `vitest` nem script `test`, e a regra 5 do Preâmbulo diz "não há terminal; validação é o Preview".
Opções: **A** painel de auto-teste no Preview (funções puras + checklist); **B** adicionar `vitest` + script `test` agora; **C** manter só checklist reproduzível e adicionar `vitest` na fase desktop.
Recomendação: **C** (compatível com o AI Studio hoje). Enquanto isso, o `tsc --noEmit` do script `lint` cobre o único `tsconfig`; quando surgirem `src-tauri`/testes com `tsconfig` próprio, o gate deve passar a `tsc -b`.

### B3 — `AIS-AP` e `AIS-P0` não estão no pacote · RESOLVIDO (incluídos em `prompts/`)
`ORDEM` lista `AIS-AP` (nº 105) e `AIS-P0`; `AIS-30` remete a "Apêndice Tauri, seção AP-30". Nenhum dos dois está no zip. Até o AIS-85 nada quebra (AIS-85 diz não depender do apêndice), mas o AIS-30 fica com instruções desktop faltando.
Ação: incluir o apêndice no pacote ou mover a referência do AIS-30 para "integração futura".

---

## 2. Erros que já foram corrigidos

| # | Erro | Correção |
|---|---|---|
| C1 | "Estado real da casca" dizia "não referencia arquivos" em **70 de 86** prompts (os arquivos só apareciam no corpo). Sem a tabela, o agente não sabe o que estender e recria modais | Tabela EXISTE/CRIAR (com nº de linhas) gerada das SPECs e dos caminhos citados: 101 prompts com arquivos EXISTE, 18 com CRIAR |
| C2 | 12 prompts mandavam respeitar `casca-esperada.json`, arquivo que não existe (e o Preâmbulo diz que não há outros arquivos) | Referência trocada por "código atual da casca" |
| C3 | AIS-18: "limite configurável (máx. 100)" × decisão canônica 10 "sem limite" × casca `maxHistory = 50` | Linha corrigida; nota no prompt |
| C4 | 38 de 56 SPECs sem prompt dono ("Sequência canônica Nodimus v4"); 6 SPECs órfãs; 11 prompts sem SPEC | União SPEC ↔ prompt; vínculos inferidos listados no changelog; 0 SPEC órfã agora |
| C5 | `ORDEM` com números repetidos (12, depois 9, 10, 11…) | Renumerada 1..105, sem mudar a ordem |
| C6 | Índice de SPECs dizia 53; são 56 (faltavam `editor-store`, `state-architecture`, `zod-schemas`, sem bloco 0) | Índice e cabeçalhos corrigidos |
| C7 | Tabela de contratos transversais ignorava Zod, Authoring×Runtime, EditorStore e State Mutation Policy (a ORDEM os declara transversais) | 4 linhas adicionadas nos 104 preâmbulos |
| C8 | Heading "1. Preâmbulo fixo" repetia o número de "1. Estado real da casca" em 7 prompts | Renumerado para 0 |
| C9 | 11 prompts curtos sem Preâmbulo, casca, critérios com ID e SPECs | Reestruturados no padrão; critérios viraram `AIS-XX-Cnn` |

---

## 3. Notas de nivelamento aplicadas (reversíveis)

| Prompt | Problema | Nota |
|---|---|---|
| AIS-44 (nº 72) | Diz operar "sobre o RuntimeSession definido no AIS-44b" (nº 73, posterior) — a própria ORDEM proíbe tratar integração futura como existente | Depender só de `RuntimeSessionContract` (AIS-03c); resto é integração futura |
| AIS-46, 77, 25b | Mandam criar/usar `PlaySimulationModal.tsx` (não existe na casca), enquanto o AIS-44c (nº 74) proíbe o modal como caminho principal | Play canônico = host do AIS-44c; modal só como atalho de compatibilidade |
| AIS-47 (nº 77) | Depende do "input lógico do AIS-58" (nº 95, posterior) | Usar o `InputManager` core do AIS-40b (nº 66); AIS-58 só amplia |
| AIS-04 | Sem `preventDefault` em F5/Ctrl+S; no Preview web F5 recarrega a página | Nota obrigando `preventDefault()` |
| AIS-36, 37 | `AnimationPlayer` não existe em `NodeType` (0 ocorrências em `src/`) | ~~Marcado CRIAR~~ **Corrigido v5.6:** o tipo **existe** em `registry.ts` (com `rigConfig` defeituoso); AIS-36 estende, não recria |

---

## 4. Riscos a acompanhar

- **R1 (RESOLVIDO: afirmações sobre `PlaySimulationModal.tsx` removidas dos prompts) — `.docs/` da casca afirma o que o código não tem.** `02-auditoria-stubs` e `06/07/08` listam `PlaySimulationModal.tsx` como "Real" (não há o arquivo), dizem que o Inspector cobre `AnimationPlayer` (0 ocorrências) e certificam "100%". Recomendo não usar esses documentos como fonte de verdade; `.docs/Prompts-00-67-*` e `prompts-adaptacao-nodimus.md` são o conjunto antigo (68 prompts) e competem com o v4.1.
- **R2 — `src/core/tauriBridge.ts` usa a API do Tauri v1** (`window.__TAURI__.dialog.open`, `fs.readBinaryFile`) e detecta Tauri por `'__TAURI__' in window`. No Tauri v2 os diálogos e o filesystem vêm de plugins (`@tauri-apps/plugin-dialog`, `plugin-fs`) com permissões declaradas em capabilities, e o global só existe com `withGlobalTauri`. Isso é do meu conhecimento da documentação v2; **não consegui abrir as páginas oficiais nesta sessão** (o acesso direto foi recusado), então confirme em <https://v2.tauri.app/plugin/file-system/> antes de executar o AIS-30.
- **R3 — Sobras do template AI Studio** em `package.json` (`express`, `dotenv`, `@google/genai`, `tsx`, `esbuild`, script `clean` com `server.js`). Remoção das sobras de `package.json` só na fase final desktop.
- **R4 — Arquivos da casca sem SPEC:** `src/main.tsx`, `materialBuilder.ts`, `textureGenerator.ts`, `videoTextureHelper.ts`, `spritePresets.ts`.
- **R5 — Monólitos da casca:** `EditorContext.tsx` (1044 linhas) e `Viewport3D.tsx` (1690) são tratados pelos AIS-03f (nº 9) e AIS-06b (nº 14), que a ordem já coloca cedo — basta não pular. `AssetImportModal.tsx` (2364) e `TreeEditorModal.tsx` (1576) não têm prompt de divisão; qualquer edição neles deve ser incremental.
- **R6 — Versões:** `bun.lock` confirma `typescript 7.0.2`, `vite 8.3.0`, `three 0.186.0`, `@dnd-kit/sortable 10.0.0` como resolvidas. Não consegui consultar o registro npm (403), então não validei versões de `zod`, `zustand`, `@pmndrs/uikit`, `@dimforge/rapier3d-compat` e `acorn` que os prompts pedem para instalar.

---

## 5. Onde cada implementação fica pronta

Ver `MATRIZ-PROMPT-SPEC-CASCA.md`: para cada SPEC, o arquivo da casca, os prompts donos em ordem, o prompt após o qual ela está concluída e os contratos que ainda não existem quando o primeiro dono executa (nesses casos só adapter mínimo).

## 6. Resolução v4.4 e v4.5
Ver `CHANGELOG-PADRONIZACAO.md` (seções v4.4 e v4.5). Resolvidos na v4.5: regra de log (agora log obrigatório por prompt em `docs/logs/`), item de Biblioteca de Assets removido e tema claro criado pelo Configurador de Temas. Em aberto: colisão "Prompt 62–67" no AIS-AP.
