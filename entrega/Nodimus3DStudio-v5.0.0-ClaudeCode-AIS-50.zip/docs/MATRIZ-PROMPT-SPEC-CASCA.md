> **v5.3:** a coluna de posições `AIS-X (N)` foi regravada a partir de `docs/prompts/ORDEM-CANONICA-V4.md` (vigente = 120 posições; AIS-18d na 29 e AIS-76b na 106). Esta matriz volta a ser consistente com a ordem.

> **v5.1.3:** posições da matriz continuam históricas; vigente = 117 posições em `docs/prompts/ORDEM-CANONICA-V4.md` (AIS-18c na posição 28, partículas).

> **v5.1.1:** a coluna de posições desta matriz é histórica (v4.7.0, 105) e não é autoridade; a ordem vigente (115 posições) está em `docs/prompts/ORDEM-CANONICA-V4.md`. Árvores agora são AIS-51, AIS-51a, AIS-51b, AIS-51c, AIS-51d.

> **v4.7.0:** posições renumeradas (AIS-05r inserido em 12; AIS-78 e AIS-78b removidos; total 105). `extension.spec.md` removida; `logic-registry.spec.md` adicionada.

# Matriz Prompt × SPEC × Casca

> Gerada na padronização v4.1 a partir de: `ORDEM-CANONICA-V4.md`, campo *Prompts/etapas relacionados* das SPECs, links *SPECs relacionadas* dos prompts e arquivos reais do editor (`nodimus-studio---game-editor-ide`). "Contratos ausentes" = contratos transversais cujo prompt criador vem **depois** do primeiro prompt dono — nesses casos o prompt deve usar apenas adapter mínimo (regra da tabela de Contratos do Preâmbulo).

## 1. O que cada SPEC precisa para ser concluída

| SPEC | Casca (linhas) | Crit. | Prompts donos (ordem de execução) | 1º dono (nº) | Concluída após (nº) | Contratos ausentes no 1º dono |
|---|---|---|---|---|---|---|
| `componentes/editor-layout.spec.md` | `src/App.tsx` (124) | MÉDIA | AIS-01, AIS-25b, AIS-44c, AIS-83 | AIS-01 (1) | AIS-83 (118) | IDs persistentes + schemaVersion, Zod (validação nas fronteiras), Authoring × Runtime, EditorStore (Zustand), State Mutation Policy, CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `paineis/top-bar.spec.md` | `src/components/layout/TopBar.tsx` (624) | ALTA | AIS-01, AIS-44c, AIS-61b | AIS-01 (1) | AIS-61b (99) | IDs persistentes + schemaVersion, Zod (validação nas fronteiras), Authoring × Runtime, EditorStore (Zustand), State Mutation Policy, CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/editor-context.spec.md` | `src/core/EditorContext.tsx` (1044) | CRÍTICA | AIS-02, AIS-03c, AIS-03f, AIS-18b, AIS-44b | AIS-02 (2) | AIS-44b (73) | IDs persistentes + schemaVersion, Zod (validação nas fronteiras), Authoring × Runtime, EditorStore (Zustand), State Mutation Policy, CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/state-architecture.spec.md` | política — sem arquivo único (ver AIS-03e) | CRÍTICA | AIS-02b, AIS-03c, AIS-03d, AIS-03e | AIS-02b (3) | AIS-03e (8) | IDs persistentes + schemaVersion, Authoring × Runtime, EditorStore (Zustand), State Mutation Policy, CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/zod-schemas.spec.md` | a criar no AIS-02b (`src/schemas/`) | ALTA | AIS-02b | AIS-02b (3) | AIS-02b (3) | IDs persistentes + schemaVersion, Authoring × Runtime, EditorStore (Zustand), State Mutation Policy, CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/node.spec.md` | `src/types/node.ts` (109) | CRÍTICA | AIS-03, AIS-04, AIS-15, AIS-26, AIS-29d, AIS-32c, AIS-41b, AIS-45, AIS-48, AIS-48b, AIS-49, AIS-56, AIS-68, AIS-69, AIS-70, AIS-71, AIS-72, AIS-73, AIS-74, AIS-75, AIS-80 | AIS-03 (4) | AIS-80 (114) | IDs persistentes + schemaVersion, Authoring × Runtime, EditorStore (Zustand), State Mutation Policy, CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/scene.spec.md` | `src/types/scene.ts` (103) | CRÍTICA | AIS-03, AIS-03c, AIS-04, AIS-29, AIS-29b, AIS-29d, AIS-31, AIS-32c, AIS-44b, AIS-48b, AIS-56, AIS-68, AIS-69, AIS-71, AIS-72, AIS-73, AIS-75, AIS-80, AIS-81, AIS-81b | AIS-03 (4) | AIS-81b (116) | IDs persistentes + schemaVersion, Authoring × Runtime, EditorStore (Zustand), State Mutation Policy, CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/project-storage.spec.md` | `src/core/projectStorage.ts` (118) | ALTA | AIS-03b, AIS-03c, AIS-05, AIS-28, AIS-28c, AIS-29, AIS-29b, AIS-31, AIS-32, AIS-61b | AIS-03b (5) | AIS-61b (99) | Authoring × Runtime, EditorStore (Zustand), State Mutation Policy, CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/project.spec.md` | `src/types/project.ts` (68) | ALTA | AIS-03b, AIS-03c, AIS-05, AIS-28c, AIS-29c, AIS-32 | AIS-03b (5) | AIS-32 (53) | Authoring × Runtime, EditorStore (Zustand), State Mutation Policy, CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `paineis/inspector-panel.spec.md` | `src/components/inspector/InspectorPanel.tsx` (189) | ALTA | AIS-03c, AIS-19, AIS-21, AIS-23, AIS-24, AIS-26, AIS-50b | AIS-03c (6) | AIS-26 (39) | EditorStore (Zustand), State Mutation Policy, CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/editor-store.spec.md` | a criar no AIS-03d (`src/core/editorStore.ts` ou equivalente) | ALTA | AIS-03d, AIS-03f, AIS-03e | AIS-03d (7) | AIS-03e (8) | State Mutation Policy, CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/default-project.spec.md` | `src/core/defaultProject.ts` (656) | MÉDIA | AIS-05 | AIS-05 (11) | AIS-05 (11) | CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `telas/viewport-3d.spec.md` | `src/components/viewports/Viewport3D.tsx` (1690) | CRÍTICA | AIS-06, AIS-06b, AIS-07, AIS-08, AIS-09, AIS-10, AIS-11, AIS-12, AIS-19, AIS-25b, AIS-44c, AIS-46, AIS-47, AIS-58, AIS-61b, AIS-70, AIS-77 | AIS-06 (13) | AIS-77 (111) | CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `componentes/node-icon.spec.md` | `src/components/common/NodeIcon.tsx` (69) | BAIXA | AIS-13 | AIS-13 (21) | AIS-13 (21) | CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `componentes/scene-tree-node.spec.md` | `src/components/sceneTree/SceneTreeNode.tsx` (263) | BAIXA | AIS-13, AIS-14, AIS-16, AIS-17 | AIS-13 (21) | AIS-17 (25) | CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `paineis/scene-tree-panel.spec.md` | `src/components/sceneTree/SceneTreePanel.tsx` (227) | ALTA | AIS-13, AIS-14, AIS-16, AIS-17, AIS-19, AIS-29d | AIS-13 (21) | AIS-29d (48) | CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `modais/create-node-modal.spec.md` | `src/components/modals/CreateNodeModal.tsx` (268) | BAIXA | AIS-15 | AIS-15 (23) | AIS-15 (23) | CommandManager, DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/command-manager.spec.md` | `src/core/commandManager.ts` (87) | CRÍTICA | AIS-18, AIS-18b, AIS-19, AIS-20, AIS-22 | AIS-18 (26) | AIS-22 (33) | DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/commands.spec.md` | `src/types/commands.ts` (6) | CRÍTICA | AIS-18, AIS-19, AIS-20, AIS-22 | AIS-18 (26) | AIS-22 (33) | DocumentManager/SelectionService, ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `componentes/property-field.spec.md` | `src/components/inspector/PropertyField.tsx` (209) | BAIXA | AIS-21, AIS-23, AIS-24 | AIS-21 (32) | AIS-24 (35) | ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `componentes/mesh-material-section.spec.md` | `src/components/inspector/MeshMaterialSection.tsx` (194) | BAIXA | AIS-25 | AIS-25 (36) | AIS-25 (36) | ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/material.spec.md` | `src/types/material.ts` (477) | MÉDIA | AIS-25 | AIS-25 (36) | AIS-25 (36) | ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `componentes/node-signals-tab.spec.md` | `src/components/inspector/NodeSignalsTab.tsx` (150) | BAIXA | AIS-27, AIS-57 | AIS-27 (41) | AIS-57 (94) | ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/signal.spec.md` | `src/types/signal.ts` (14) | ALTA | AIS-27, AIS-45, AIS-48, AIS-49, AIS-57, AIS-74 | AIS-27 (41) | AIS-74 (107) | ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `paineis/file-system-panel.spec.md` | `src/components/fileSystem/FileSystemPanel.tsx` (642) | ALTA | AIS-28, AIS-28c, AIS-29c, AIS-31, AIS-61b | AIS-28 (42) | AIS-61b (99) | ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `componentes/code-mirror-editor.spec.md` | `src/components/codeEditor/CodeMirrorEditor.tsx` (490) | BAIXA | AIS-28b, AIS-79 | AIS-28b (43) | AIS-79 (113) | ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `modais/script-editor-modal.spec.md` | `src/components/modals/ScriptEditorModal.tsx` (182) | BAIXA | AIS-28b, AIS-79 | AIS-28b (43) | AIS-79 (113) | ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `telas/code-editor-workspace.spec.md` | `src/components/viewports/CodeEditorWorkspace.tsx` (411) | MÉDIA | AIS-28b, AIS-79 | AIS-28b (43) | AIS-79 (113) | ResourceRegistry/AssetPipeline, Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/registry.spec.md` | `src/nodes/registry.ts` (708) | ALTA | AIS-28c, AIS-29c, AIS-81, AIS-81b | AIS-28c (44) | AIS-81b (116) | Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `modais/asset-import-modal.spec.md` | `src/components/modals/AssetImportModal.tsx` (2375) | ALTA | AIS-28c, AIS-29c, AIS-33a, AIS-33, AIS-34, AIS-35, AIS-36, AIS-37, AIS-38, AIS-38c | AIS-28c (44) | AIS-37 (61) | Serializador de cenas, DependencyGraph, DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/tauri-bridge.spec.md` | `src/core/tauriBridge.ts` (139) | ALTA | AIS-30, AIS-78c, AIS-85, AIS-85b | AIS-30 (51) | AIS-85b (121) | DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `modais/project-manager-modal.spec.md` | `src/components/modals/ProjectManagerModal.tsx` (340) | BAIXA | AIS-32 | AIS-32 (53) | AIS-32 (53) | DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `componentes/texture-preview-canvas.spec.md` | `src/components/modals/TexturePreviewCanvas.tsx` (655) | BAIXA | AIS-35 | AIS-35 (59) | AIS-35 (59) | DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `modais/texture-preview-modal.spec.md` | `src/components/modals/TexturePreviewModal.tsx` (869) | BAIXA | AIS-35 | AIS-35 (59) | AIS-35 (59) | DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `paineis/bottom-panel.spec.md` | `src/components/bottomPanel/BottomPanel.tsx` (187) | MÉDIA | AIS-38, AIS-46, AIS-47, AIS-58, AIS-77 | AIS-38 (62) | AIS-77 (111) | DiagnosticService, InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `dominios/visual-logic.spec.md` | `src/types/visualLogic.ts` (62) | CRÍTICA | AIS-39, AIS-40, AIS-40b, AIS-41, AIS-41b, AIS-42, AIS-43, AIS-44, AIS-44b | AIS-39 (64) | AIS-44b (73) | InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `telas/visual-logic-editor.spec.md` | `src/components/viewports/VisualLogicEditor.tsx` (581) | ALTA | AIS-39, AIS-40, AIS-41, AIS-41b, AIS-42, AIS-43, AIS-44, AIS-44b, AIS-61b | AIS-39 (64) | AIS-61b (99) | InputManager core, RuntimeSession, PhysicsBridge, Assinaturas/disposers, CapabilityRegistry |
| `modais/terrain-editor-modal.spec.md` | `src/components/modals/TerrainEditorModal.tsx` (949) | BAIXA | AIS-50, AIS-50b | AIS-50 (82) | AIS-50 (82) | CapabilityRegistry |
| `componentes/terrain-sculpt-section.spec.md` | `src/components/inspector/TerrainSculptSection.tsx` (a criar) | BAIXA | AIS-50b | AIS-50b (83) | AIS-50b (83) | — |
| `modais/tree-editor-modal.spec.md` | `src/components/modals/TreeEditorModal.tsx` (1576) | MÉDIA | AIS-51, AIS-51a, AIS-51b, AIS-51c, AIS-51d | AIS-51 (84) | AIS-51 (84) | CapabilityRegistry |
| `modais/sound-modal.spec.md` | `src/components/modals/SoundModal.tsx` (1212) | BAIXA | AIS-52 | AIS-52 (89) | AIS-52 (89) | CapabilityRegistry |
| `modais/particle-modal.spec.md` | `src/components/modals/ParticleModal.tsx` (1319) | BAIXA | AIS-18c, AIS-53 | AIS-18c (28) | AIS-53 (90) | CapabilityRegistry |
| `dominios/particle-system.spec.md` | `src/core/particles/` + `src/nodes/registry.ts` (a criar) | MÉDIA | AIS-18c, AIS-23, AIS-41, AIS-49b, AIS-53, AIS-56 | AIS-18c (28) | AIS-53 (90) | CommandManager, RendererCore |
| `modais/fog-modal.spec.md` | `src/components/modals/FogModal.tsx` (1046) | BAIXA | AIS-54 | AIS-54 (91) | AIS-54 (91) | CapabilityRegistry |
| `modais/post-processing-modal.spec.md` | `src/components/modals/PostProcessingModal.tsx` (632) | BAIXA | AIS-55 | AIS-55 (92) | AIS-55 (92) | CapabilityRegistry |
| `dominios/animation.spec.md` | `src/types/animation.ts` (20) | MÉDIA | AIS-59, AIS-60, AIS-61 | AIS-59 (96) | AIS-61 (98) | CapabilityRegistry |
| `componentes/sprite-canvas-editor.spec.md` | `src/components/modals/sprite/SpriteCanvasEditor.tsx` (678) | BAIXA | AIS-76 | AIS-76 (109) | AIS-76 (109) | CapabilityRegistry |
| `componentes/sprite-sheet-atlas-view.spec.md` | `src/components/modals/sprite/SpriteSheetAtlasView.tsx` (256) | BAIXA | AIS-76 | AIS-76 (109) | AIS-76 (109) | CapabilityRegistry |
| `componentes/sprite-timeline.spec.md` | `src/components/modals/sprite/SpriteTimeline.tsx` (435) | BAIXA | AIS-76 | AIS-76 (109) | AIS-76 (109) | CapabilityRegistry |
| `componentes/sprite-visualizer-3d.spec.md` | `src/components/modals/sprite/SpriteVisualizer3D.tsx` (458) | BAIXA | AIS-76 | AIS-76 (109) | AIS-76 (109) | CapabilityRegistry |
| `dominios/sprite.spec.md` | `src/types/sprite.ts` (86) | MÉDIA | AIS-76 | AIS-76 (109) | AIS-76 (109) | CapabilityRegistry |
| `modais/sprite-editor-modal.spec.md` | `src/components/modals/SpriteEditorModal.tsx` (1007) | BAIXA | AIS-76 | AIS-76 (109) | AIS-76 (109) | CapabilityRegistry |
| `dominios/logic-registry.spec.md` | `src/logic/registry.ts` (179) + `src/logic/<tipo>/<id>/` | ALTA | AIS-05r, AIS-39, AIS-40, AIS-41, AIS-41b, AIS-42, AIS-44, AIS-78c, AIS-85b | AIS-05r (12) | AIS-85b (121) | CapabilityRegistry |
| `paineis/extensions-panel.spec.md` | `src/components/modals/ExtensionsPanel.tsx` (80, stub) | BAIXA | AIS-05r | AIS-05r (12) | AIS-05r (12) | — |
| `modais/project-settings-modal.spec.md` | `src/components/modals/ProjectSettingsModal.tsx` (343) | BAIXA | AIS-82 | AIS-82 (117) | AIS-82 (117) | — |
| `componentes/video-preview-canvas.spec.md` | `src/components/modals/VideoPreviewCanvas.tsx` (525) | BAIXA | AIS-84 | AIS-84 (119) | AIS-84 (119) | — |
| `dominios/video.spec.md` | `src/types/video.ts` (79) | MÉDIA | AIS-84 | AIS-84 (119) | AIS-84 (119) | — |
| `modais/video-editor-modal.spec.md` | `src/components/modals/VideoEditorModal.tsx` (1260) | BAIXA | AIS-84 | AIS-84 (119) | AIS-84 (119) | — |

## 2. Prompts: fase, formato e arquivos da casca

| Prompt | Nº | Fase | Formato original | EXISTE | CRIAR | SPECs |
|---|---|---|---|---|---|---|
| AIS-01 | 1 | Fase A | padrão v3 | 2 | 0 | 2 |
| AIS-02 | 2 | Fase A | padrão v3 | 1 | 0 | 1 |
| AIS-02b | 3 | Fase A | curto v4/v4.1 | 0 | 1 | 2 |
| AIS-03 | 4 | Fase A | padrão v3 | 2 | 0 | 2 |
| AIS-03b | 5 | Fase A | complemento v4 | 3 | 5 | 2 |
| AIS-03c | 6 | Fase A | curto v4/v4.1 | 5 | 0 | 6 |
| AIS-03d | 7 | Fase A | curto v4/v4.1 | 0 | 1 | 2 |
| AIS-03f | 9 | Fase A | curto v4/v4.1 | 1 | 0 | 2 |
| AIS-03e | 8 | Fase A | curto v4/v4.1 | 0 | 0 | 2 |
| AIS-04 | 10 | Fase A | padrão v3 | 2 | 1 | 2 |
| AIS-05 | 11 | Fase A | padrão v3 | 3 | 0 | 3 |
| AIS-05r | 12 | Fase A | revisão v4.7.0 | 4 | 0 | 4 |
| AIS-06 | 13 | Fase B | padrão v3 | 1 | 0 | 1 |
| AIS-06b | 14 | Fase B | curto v4/v4.1 | 1 | 0 | 1 |
| AIS-07 | 15 | Fase B | padrão v3 | 1 | 0 | 1 |
| AIS-08 | 16 | Fase B | padrão v3 | 1 | 0 | 1 |
| AIS-09 | 17 | Fase B | padrão v3 | 1 | 0 | 1 |
| AIS-10 | 18 | Fase B | padrão v3 | 1 | 0 | 1 |
| AIS-11 | 19 | Fase B | padrão v3 | 1 | 0 | 1 |
| AIS-12 | 20 | Fase B | padrão v3 | 1 | 0 | 1 |
| AIS-13 | 21 | Fase B | padrão v3 | 3 | 0 | 3 |
| AIS-14 | 22 | Fase B | padrão v3 | 2 | 0 | 2 |
| AIS-15 | 23 | Fase B | padrão v3 | 2 | 0 | 2 |
| AIS-16 | 24 | Fase B | padrão v3 | 2 | 0 | 2 |
| AIS-17 | 25 | Fase B | padrão v3 | 2 | 0 | 2 |
| AIS-18 | 26 | Fase C | padrão v3 | 2 | 0 | 2 |
| AIS-18b | 27 | Fase C | complemento v4 | 3 | 0 | 2 |
| AIS-18c | 28 | Fase C | novo v5.1.3 | 4 | 0 | 4 |
| AIS-19 | 28 | Fase C | padrão v3 | 5 | 1 | 5 |
| AIS-20 | 29 | Fase C | padrão v3 | 2 | 1 | 2 |
| AIS-21 | 30 | Fase C | padrão v3 | 2 | 1 | 2 |
| AIS-22 | 31 | Fase C | padrão v3 | 2 | 1 | 2 |
| AIS-23 | 32 | Fase C | padrão v3 | 2 | 0 | 2 |
| AIS-24 | 33 | Fase C | padrão v3 | 2 | 0 | 2 |
| AIS-25 | 34 | Fase C | padrão v3 | 2 | 0 | 2 |
| AIS-25b | 35 | Fase C | padrão v3 | 5 | 5 | 2 |
| AIS-26 | 36 | Fase C | padrão v3 | 2 | 0 | 2 |
| AIS-27 | 37 | Fase C | padrão v3 | 2 | 0 | 2 |
| AIS-28 | 38 | Fase D | padrão v3 | 2 | 0 | 2 |
| AIS-28b | 39 | Fase D | padrão v3 | 3 | 0 | 3 |
| AIS-28c | 40 | Fase D | complemento v4 | 6 | 0 | 5 |
| AIS-29 | 41 | Fase D | padrão v3 | 2 | 0 | 2 |
| AIS-29b | 42 | Fase D | complemento v4 | 3 | 0 | 2 |
| AIS-29c | 43 | Fase D | complemento v4 | 5 | 0 | 4 |
| AIS-29d | 44 | Fase D | curto v4/v4.1 | 3 | 0 | 3 |
| AIS-30 | 45 | Fase D | padrão v3 | 1 | 0 | 1 |
| AIS-31 | 46 | Fase D | padrão v3 | 3 | 0 | 3 |
| AIS-32 | 47 | Fase D | padrão v3 | 3 | 0 | 3 |
| AIS-33 | 48 | Fase D | padrão v3 | 1 | 0 | 1 |
| AIS-34 | 49 | Fase D | padrão v3 | 1 | 0 | 1 |
| AIS-35 | 50 | Fase D | padrão v3 | 3 | 0 | 3 |
| AIS-36 | 51 | Fase D | padrão v3 | 1 | 0 | 1 |
| AIS-37 | 52 | Fase D | padrão v3 | 1 | 0 | 1 |
| AIS-38 | 53 | Fase D | padrão v3 | 1 | 0 | 1 |
| AIS-32c | 55 | Fase D | complemento v4 | 3 | 0 | 2 |
| AIS-39 | 55 | Fase E | padrão v3 | 2 | 0 | 2 |
| AIS-40 | 56 | Fase E | padrão v3 | 2 | 0 | 2 |
| AIS-40b | 57 | Fase E | curto v4/v4.1 | 1 | 0 | 1 |
| AIS-41 | 58 | Fase E | padrão v3 | 2 | 1 | 2 |
| AIS-41b | 59 | Fase E | curto v4/v4.1 | 3 | 0 | 3 |
| AIS-42 | 60 | Fase E | padrão v3 | 2 | 0 | 2 |
| AIS-43 | 61 | Fase E | padrão v3 | 2 | 1 | 2 |
| AIS-44 | 62 | Fase E | padrão v3 | 2 | 1 | 2 |
| AIS-44b | 63 | Fase E | complemento v4 | 5 | 0 | 4 |
| AIS-44c | 64 | Fase E | curto v4/v4.1 | 3 | 0 | 3 |
| AIS-45 | 65 | Fase E | padrão v3 | 3 | 0 | 2 |
| AIS-46 | 66 | Fase E | padrão v3 | 2 | 1 | 2 |
| AIS-47 | 67 | Fase E | padrão v3 | 2 | 0 | 2 |
| AIS-48 | 68 | Fase E | padrão v3 | 2 | 1 | 2 |
| AIS-48b | 69 | Fase E | complemento v4 | 3 | 0 | 2 |
| AIS-49 | 70 | Fase E | padrão v3 | 2 | 0 | 2 |
| AIS-50 | 71 | Fase F | padrão v3 | 1 | 0 | 1 |
| AIS-50b | 77 | Fase F | novo v5.1.2 | 3 | 0 | 3 |
| AIS-51 | 73 (histórica: 72) | Fase F | padrão v3 | 1 | 0 | 1 |
| AIS-52 | 73 | Fase F | padrão v3 | 1 | 0 | 1 |
| AIS-53 | 74 | Fase F | padrão v3 | 1 | 0 | 1 |
| AIS-54 | 75 | Fase F | padrão v3 | 1 | 0 | 1 |
| AIS-55 | 76 | Fase F | padrão v3 | 1 | 0 | 1 |
| AIS-56 | 77 | Fase F | padrão v3 | 2 | 0 | 2 |
| AIS-57 | 78 | Fase F | padrão v3 | 2 | 1 | 2 |
| AIS-58 | 79 | Fase F | padrão v3 | 2 | 1 | 2 |
| AIS-59 | 80 | Fase F | padrão v3 | 1 | 1 | 1 |
| AIS-60 | 81 | Fase F | padrão v3 | 1 | 0 | 1 |
| AIS-61 | 82 | Fase F | padrão v3 | 1 | 0 | 1 |
| AIS-61b | 83 | Fase F | curto v4/v4.1 | 5 | 0 | 5 |
| AIS-68 | 84 | Fase G | padrão v3 | 3 | 0 | 2 |
| AIS-69 | 85 | Fase G | padrão v3 | 2 | 0 | 2 |
| AIS-70 | 86 | Fase G | padrão v3 | 2 | 0 | 2 |
| AIS-71 | 87 | Fase G | padrão v3 | 2 | 0 | 2 |
| AIS-72 | 88 | Fase G | padrão v3 | 2 | 0 | 2 |
| AIS-73 | 89 | Fase G | padrão v3 | 2 | 0 | 2 |
| AIS-74 | 90 | Fase G | padrão v3 | 3 | 0 | 2 |
| AIS-75 | 91 | Fase G | padrão v3 | 2 | 0 | 2 |
| AIS-76 | 92 | Fase G | padrão v3 | 6 | 0 | 6 |
| AIS-77 | 93 | Fase G | padrão v3 | 2 | 0 | 2 |
| AIS-78c | 94 | Fase H | complemento v4 | 3 | 0 | 3 |
| AIS-79 | 95 | Fase H | padrão v3 | 3 | 0 | 3 |
| AIS-80 | 96 | Fase H | padrão v3 | 2 | 0 | 2 |
| AIS-81 | 97 | Fase H | padrão v3 | 2 | 0 | 2 |
| AIS-81b | 98 | Fase H | complemento v4 | 3 | 0 | 2 |
| AIS-82 | 99 | Fase H | padrão v3 | 1 | 0 | 1 |
| AIS-83 | 100 | Fase H | padrão v3 | 1 | 0 | 1 |
| AIS-84 | 101 | Fase H | padrão v3 | 3 | 0 | 3 |
| AIS-85 | 102 | Fase H | padrão v3 | 2 | 1 | 2 |
| AIS-85b | 103 | Fase H | complemento v4 | 2 | 0 | 2 |

## 3. Arquivos da casca sem SPEC

`src/main.tsx`, `src/utils/materialBuilder.ts`, `src/utils/textureGenerator.ts`, `src/utils/videoTextureHelper.ts`, `src/utils/spritePresets.ts` — existem no editor e são consumidos pelos prompts de material/textura/vídeo/sprite, mas nenhuma SPEC os documenta.
