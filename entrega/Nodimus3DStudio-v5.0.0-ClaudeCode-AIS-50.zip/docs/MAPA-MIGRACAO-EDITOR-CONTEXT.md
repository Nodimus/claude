# MAPA DE MIGRAÇÃO: EditorContext → Autoridades Canônicas

> **AIS-03f** · Migração do EditorContext / Fachada de compatibilidade  
> **Status:** Ativo / Transição v4.1  
> **Diretriz:** O `EditorContext` deixa de ser armazenamento de estado monolítico e passa a ser uma **fachada temporária delegadora** (adapter). Nenhuma sincronização bidirecional frágil é permitida. A autoridade de dados persistentes é estritamente o `AuthoringModel`; o estado reativo da IDE pertence estritamente ao Zustand `EditorStore`; o histórico pertence ao `CommandManager`.

---

## 1. Matriz de Mapeamento de Campos e Métodos

A tabela abaixo documenta o destino de cada membro do `EditorContextType` (86 membros auditados):

| Membro no EditorContext | Tipo/Papel | Nova Autoridade Canônica | Mecanismo de Acesso Recomendado | Status de Migração |
|---|---|---|---|---|
| `project` | Dados persistentes | **AuthoringModel** | `globalAuthoringModel.getProject()` | Projeção somente-leitura na fachada |
| `activeScene` | Dados persistentes | **AuthoringModel** | `globalAuthoringModel.getScene()` | Projeção somente-leitura na fachada |
| `selectedNodeId` | Estado UI reativo | **EditorStore** (Zustand) | `useEditorStore(s => s.selectedNodeId)` | Delegado ao Zustand |
| `selectedNode` | Estado derivado | **AuthoringModel** + **EditorStore** | Derivado de `authoringModel.getNode(selectedNodeId)` | Computado na fachada |
| `multiSelectedNodeIds` | Seleção múltipla UI | **EditorStore** (Zustand) | `useEditorStore(s => s.multiSelectedNodeIds)` | Delegado ao Zustand |
| `setMultiSelectedNodeIds` | Ação de seleção | **EditorStore** (Zustand) | `useEditorStore(s => s.setMultiSelectedNodeIds)` | Delegado ao Zustand |
| `toggleMultiSelectNode` | Ação de seleção | **EditorStore** (Zustand) | `useEditorStore(s => s.toggleMultiSelectNode)` | Delegado ao Zustand |
| `selectNode` | Ação de seleção | **EditorStore** (Zustand) | `useEditorStore(s => s.selectNode)` | Delegado ao Zustand |
| `workspaceMode` | Layout / Viewport | **EditorStore** (Zustand) | `useEditorStore(s => s.workspaceMode)` | Delegado ao Zustand |
| `setWorkspaceMode` | Ação de layout | **EditorStore** (Zustand) | `useEditorStore(s => s.setWorkspaceMode)` | Delegado ao Zustand |
| `manipulationMode` | Ferramenta Gizmo | **EditorStore** (Zustand) | `useEditorStore(s => s.manipulationMode)` | Delegado ao Zustand |
| `setManipulationMode` | Ação de gizmo | **EditorStore** (Zustand) | `useEditorStore(s => s.setManipulationMode)` | Delegado ao Zustand |
| `isPlaying` | Espelho de simulação | **EditorStore** (Zustand) | `useEditorStore(s => s.isPlaying)` | Delegado ao Zustand |
| `isPaused` | Espelho de simulação | **EditorStore** (Zustand) | `useEditorStore(s => s.isPaused)` | Delegado ao Zustand |
| `playMode` | Espelho de simulação | **EditorStore** (Zustand) | `useEditorStore(s => s.playMode)` | Delegado ao Zustand |
| `playProject` | Controle simulação | **AuthoringModel** (snapshot) + **EditorStore** | Snapshot + `setPlayState(true, ...)` | Encaminha às autoridades |
| `playScene` | Controle simulação | **AuthoringModel** (snapshot) + **EditorStore** | Snapshot + `setPlayState(true, ...)` | Encaminha às autoridades |
| `pauseGame` | Controle simulação | **EditorStore** | `setPlayState(..., !isPaused, ...)` | Encaminha ao Zustand |
| `stopGame` | Controle simulação | **EditorStore** + **AuthoringModel** | `setPlayState(false, ...)` + restore scene | Encaminha às autoridades |
| `bottomTab` | Dock inferior | **EditorStore** (Zustand) | `useEditorStore(s => s.bottomTab)` | Delegado ao Zustand |
| `setBottomTab` | Ação dock | **EditorStore** (Zustand) | `useEditorStore(s => s.setBottomTab)` | Delegado ao Zustand |
| `isBottomOpen` | Dock inferior | **EditorStore** (Zustand) | `useEditorStore(s => s.isBottomOpen)` | Delegado ao Zustand |
| `setIsBottomOpen` | Ação dock | **EditorStore** (Zustand) | `useEditorStore(s => s.setIsBottomOpen)` | Delegado ao Zustand |
| `activeScriptPath` | Code Editor | **EditorStore** (Zustand) | `useEditorStore(s => s.activeScriptPath)` | Delegado ao Zustand |
| `openScriptTabs` | Code Editor | **EditorStore** (Zustand) | `useEditorStore(s => s.openScriptTabs)` | Delegado ao Zustand |
| `openFileInScriptEditor` | Ação Code Editor | **EditorStore** (Zustand) | `openScriptTab` + `setWorkspaceMode` | Delegado ao Zustand |
| `closeScriptTab` | Ação Code Editor | **EditorStore** (Zustand) | `useEditorStore(s => s.closeScriptTab)` | Delegado ao Zustand |
| `setActiveScriptPath` | Ação Code Editor | **EditorStore** (Zustand) | `useEditorStore(s => s.setActiveScriptPath)` | Delegado ao Zustand |
| `isScriptEditorModalOpen`| Modal | **EditorStore** (Zustand) | `useEditorStore(s => s.isScriptEditorModalOpen)` | Delegado ao Zustand |
| `setIsScriptEditorModalOpen`| Ação modal | **EditorStore** (Zustand) | `useEditorStore(s => s.setIsScriptEditorModalOpen)`| Delegado ao Zustand |
| 14 Modais flags (`is...Open` / `setIs...Open`)| Modais de diálogo | **EditorStore** (Zustand) | `useEditorStore(s => s.is...Open)` / `setIs...Open` | Delegado ao Zustand |
| `canUndo` / `canRedo` | Histórico | **CommandManager** | `globalCommandManager.canUndo() / canRedo()` | Sincronizado via subscriber |
| `undo` / `redo` | Ações de histórico | **CommandManager** | `globalCommandManager.undo() / redo()` | Encaminha ao CommandManager |
| `applyEditorMutation` | Mutação autoral | **CommandManager** | `globalCommandManager.execute(cmd)` | Encaminha ao CommandManager |
| `applyRuntimeMutation` | Mutação runtime | **RuntimeSession** (Play) | Exclusivo de simulação | Encaminha ao runtime |
| `updateNodeProperties` | Mutação autoral | **CommandManager** + **AuthoringModel** | Command → `authoringModel.updateNodeProperties` | Encaminha às autoridades |
| `addNode` | Mutação autoral | **CommandManager** + **AuthoringModel** | Command → `authoringModel.addNode` | Encaminha às autoridades |
| `deleteNode` | Mutação autoral | **CommandManager** + **AuthoringModel** | Command → `authoringModel.deleteNode` | Encaminha às autoridades |
| `deleteMultipleNodes` | Mutação autoral | **CommandManager** + **AuthoringModel** | Command → `authoringModel.deleteMultipleNodes` | Encaminha às autoridades |
| `duplicateNode` | Mutação autoral | **CommandManager** + **AuthoringModel** | Command → `authoringModel.addNode` | Encaminha às autoridades |
| `renameNode` | Mutação autoral | **CommandManager** + **AuthoringModel** | Command → `authoringModel.renameNode` | Encaminha às autoridades |
| `reparentOrReorderNode`| Mutação autoral | **CommandManager** + **AuthoringModel** | Command → `authoringModel.reparentNode` | Encaminha às autoridades |
| `toggleNodeVisibility` | Mutação autoral | **CommandManager** + **AuthoringModel** | Command → `authoringModel.toggleNodeVisibility`| Encaminha às autoridades |
| `toggleNodeLock` | Mutação autoral | **CommandManager** + **AuthoringModel** | Command → `authoringModel.toggleNodeLock` | Encaminha às autoridades |
| `saveCurrentScene` | Persistência | **AuthoringModel** + **ProjectStorage** | `authoringModel.setProject(...)` + storage | Encaminha às autoridades |
| `loadScene` | Carregamento | **Zod** + **AuthoringModel** | `validateScene()` + `authoringModel.loadScene()` | Valida e carrega no modelo |
| `createNewScene` | Criação | **AuthoringModel** + **ProjectStorage** | `authoringModel.loadScene()` + storage | Encaminha às autoridades |
| `saveSceneAs` | Persistência | **AuthoringModel** + **ProjectStorage** | `authoringModel.loadScene()` + storage | Encaminha às autoridades |
| `createFolder` | Arquivos virtuais | **AuthoringModel** + **ProjectStorage** | `authoringModel.setProject(...)` | Encaminha ao AuthoringModel |
| `createFile` / `updateFileContent` | Arquivos virtuais | **AuthoringModel** + **ProjectStorage** | `authoringModel.setProject(...)` | Encaminha ao AuthoringModel |
| `deleteFile` / `renameFile` | Arquivos virtuais | **AuthoringModel** + **ProjectStorage** | `authoringModel.setProject(...)` | Encaminha ao AuthoringModel |
| `importFileContent` | Arquivos virtuais | **AuthoringModel** + **ProjectStorage** | `authoringModel.setProject(...)` | Encaminha ao AuthoringModel |
| `updateScenePostProcessing` | Configuração de cena | **AuthoringModel** | `authoringModel.setScene(...)` | Encaminha ao AuthoringModel |
| `updateSceneFog` | Configuração de cena | **AuthoringModel** | `authoringModel.setScene(...)` | Encaminha ao AuthoringModel |
| `updateSceneEnvironment` | Configuração de cena | **AuthoringModel** | `authoringModel.setScene(...)` | Encaminha ao AuthoringModel |
| `updateSceneCameraSettings` | Configuração de cena | **AuthoringModel** | `authoringModel.setScene(...)` | Encaminha ao AuthoringModel |
| `updateProjectSettings` | Configuração do projeto | **AuthoringModel** + **ProjectStorage** | `authoringModel.setProject(...)` | Encaminha ao AuthoringModel |
| `switchProject` | Troca de projeto | **AuthoringModel** + **ProjectStorage** | `authoringModel.loadProject(...)` | Encaminha ao AuthoringModel |
| `logs` / `addLog` / `clearLogs` | Logs de sistema | **LogService** (futuro AIS-18) | Transitório na fachada até AIS-18 | Mantido temporariamente |
| `behaviors` (global) | Comportamentos | **AuthoringModel** (inline no nó) | Migração canônica no AIS-41b | Mantido temporariamente |

---

## 2. Princípios de Não-Regressão e Eliminação de Fragilidades

1. **Fim dos "Bridge Effects" Bidirecionais:**  
   Não existem mais `useEffect` ouvindo state local do React para copiar valores para o Zustand `EditorStore`. O `EditorStore` é a **fonte primária** do estado da UI. O `EditorProvider` simplesmente lê do Zustand e expõe as mesmas referências.
2. **Projeção Unidirecional de Dados Persistentes:**  
   O `AuthoringModel` é a autoridade de `ProjectData` e `SceneData`. O `EditorProvider` subscreve (`globalAuthoringModel.subscribe`) exclusivamente para atualizar seu estado de projeção no React e acionar re-render das telas legadas. Toda e qualquer mutação autoral passa pelo `CommandManager` ou diretamente pelo `AuthoringModel`.
3. **Consumidores Críticos Migrados:**  
   Componentes estruturais de alta frequência (`BottomPanel`, `TopBar`, `SceneTreePanel`, `FogModal`) consomem diretamente os seletores atômicos do `useEditorStore` para propriedades de layout, modais e seleção, eliminando re-renders desnecessários.
4. **Retrocompatibilidade 100% Garantida:**  
   Qualquer componente que ainda faça `useEditor()` continua funcionando sem alteração de API, mas por baixo dos panos estará operando sobre o `EditorStore` e o `AuthoringModel`.
