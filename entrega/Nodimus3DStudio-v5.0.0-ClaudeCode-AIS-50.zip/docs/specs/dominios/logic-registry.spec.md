# logicRegistry

## 0. Alinhamento arquitetural Nodimus v4.7.0
- **Status desta SPEC:** baseline observado (casca v4.7.0) + contrato de evolução.
- **Criticidade arquitetural:** ALTA
- **Prompts/etapas relacionados:** AIS-05r (criador), AIS-39, AIS-40, AIS-41, AIS-41b, AIS-42, AIS-44, AIS-44b, AIS-78c, AIS-85, AIS-85b
- **Papel no produto:** catálogo nativo de Triggers, Conditions, Actions e Behaviors, organizado **uma pasta por item** dentro do código do editor.
- **Fronteira obrigatória:** não é sistema de extensões/plugins. Nada é carregado em runtime nem lido de `res://`. UI, validação e runtime consomem o mesmo registry; nenhum componente mantém lista própria.
- **Critério mínimo de aceite:** typecheck/build sem regressão + `verifyLogicRegistry()` com `allPassed: true`.

## 1. Identificação
- **Nome:** LogicRegistry
- **Tipo:** Domínio / serviço de núcleo (build-time)
- **Localização no código:** `src/logic/registry.ts` (179 linhas), `src/logic/types.ts` (118), `src/logic/README.md`, pastas `src/logic/{triggers,conditions,actions,behaviors}/<id>/index.ts`

## 2. Finalidade
Descobrir, validar e expor as definições nativas de Visual Logic. O ID de cada item é o nome da sua pasta e é o valor gravado nas cenas (`type`, `eventType`, `behaviorType`, `contributionId`).

## 3. Estrutura
- `types.ts`: `LogicKind`, `LogicCategory`, `LogicParamType`, `LogicParamDescriptor` (com `inline` opcional), `TriggerDefinition`, `ConditionDefinition`, `ActionDefinition` (`quickAdd?`), `BehaviorDefinition` (`preset?`, `create(ctx)`), helpers `defineTrigger/defineCondition/defineAction/defineBehavior`, `newLogicId`.
- `registry.ts`: `collectLogicDefinitions` (pura), `LogicRegistry` (`get*`, `list*`, `listQuickAddActions`, `listBehaviorPresets`, `isKnown*`, `diagnostics`), `EXPECTED_NATIVE_LOGIC`, `verifyLogicRegistry()`.
- Descoberta: `import.meta.glob('./<tipo>/*/index.ts', { eager: true })`.

## 4. Itens nativos na casca v4.7.0
| Tipo | IDs (pastas) |
|---|---|
| triggers (7) | `on_start`, `on_update`, `on_click`, `on_collision_enter`, `on_key_press`, `on_timeout`, `on_signal` |
| conditions (5) | `always`, `property_equals`, `property_greater`, `key_down`, `node_exists` |
| actions (9) | `move_by`, `set_position`, `rotate_by`, `set_visible`, `play_sound`, `emit_signal`, `change_scene`, `print_log`, `destroy_node` |
| behaviors (6) | `simple_wasd_movement` (preset), `continuous_rotation` (preset), `click_detector` (preset), `follow_cursor`, `timer_trigger`, `custom_rules` |

## 5. Regras
- `id` === nome da pasta, snake_case, único por tipo; inválido é ignorado e reportado em `diagnostics` (um `console.error` de desenvolvimento), sem derrubar o editor.
- ID desconhecido lido de cena é preservado (schemas validam só o formato via `LogicIdV1Schema`).
- Nunca renomear pasta existente (quebra referência em cena).
- Item sem execução: `status: 'disabled'` → desabilitado com tooltip "em breve".
- Evolução: `runtime.ts` por pasta (AIS-44), `requires` de capability por item (AIS-78c/85b), `editor.tsx` opcional quando um prompt pedir UI específica.

## 6. Dependências
- `src/types/visualLogic.ts` (tipo `Behavior` usado por `BehaviorDefinition.create`).
- Consumidores atuais: `src/components/viewports/VisualLogicEditor.tsx`.
