# node

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** CRÍTICA
- **Prompts/etapas relacionados:** AIS-03, AIS-04, AIS-15, AIS-26, AIS-29d, AIS-32c, AIS-41b, AIS-45, AIS-48, AIS-48b, AIS-49, AIS-56, AIS-68, AIS-69, AIS-70, AIS-71, AIS-72, AIS-73, AIS-74, AIS-75, AIS-80
- **Papel no produto:** Definição autoral de nó/instância na cena.
- **Fronteira obrigatória:** Node autoral não é THREE.Object3D nem RuntimeInstance; adapters fazem a materialização.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

> **Atualização v5.3 (AIS-18d):** `NodeType` deriva de `NODE_DEFINITIONS` (`src/nodes/registry.ts`); `NodeTypeMetadata<T>` ganhou `createCategory` (e `creatable?` no AIS-18d). Tipo desconhecido lido de cena vira `Missing` e é regravado intacto.

## 1. Identificação
- **Nome:** node
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/types/node.ts`
- **Linhas (auditado v4.4):** 109

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `node`.

## 3. Estrutura
- Declarações exportadas: `NodeCategory`, `NodeType`, `Vector2Data`, `Vector3Data`, `ColorData`, `PropertyFieldType`, `PropertyDescriptor`, `NodeTypeMetadata`, `GameNode`

## 4. Campos
### `Vector2Data`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `x` | `number` | Não definido na interface | obrigatório |
| `y` | `number` | Não definido na interface | obrigatório |
### `Vector3Data`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `x` | `number` | Não definido na interface | obrigatório |
| `y` | `number` | Não definido na interface | obrigatório |
| `z` | `number` | Não definido na interface | obrigatório |
### `ColorData`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `r` | `number` | Não definido na interface | obrigatório |
| `g` | `number` | Não definido na interface | obrigatório |
| `b` | `number` | Não definido na interface | obrigatório |
| `a` | `number` | Não definido na interface | obrigatório |
### `PropertyDescriptor`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `key` | `string` | Não definido na interface | obrigatório |
| `label` | `string` | Não definido na interface | obrigatório |
| `type` | `PropertyFieldType` | Não definido na interface | obrigatório |
| `category` | `string` | Não definido na interface | obrigatório |
| `defaultValue` | `any` | Não definido na interface | obrigatório |
| `options` | `{ label: string` | Não definido na interface | opcional |
### `NodeTypeMetadata`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `type` | `NodeType` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `category` | `NodeCategory` | Não definido na interface | obrigatório |
| `is2D` | `boolean` | Não definido na interface | obrigatório |
| `is3D` | `boolean` | Não definido na interface | obrigatório |
| `isUI` | `boolean` | Não definido na interface | obrigatório |
| `description` | `string` | Não definido na interface | obrigatório |
| `icon` | `string` | Não definido na interface | obrigatório |
| `defaultProperties` | `Record<string, any>` | Não definido na interface | obrigatório |
| `propertyDescriptors` | `PropertyDescriptor[]` | Não definido na interface | obrigatório |
| `availableSignals` | `string[]` | Não definido na interface | obrigatório |
### `GameNode`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `type` | `NodeType` | Não definido na interface | obrigatório |
| `parentId` | `string \| null` | Não definido na interface | obrigatório |
| `childrenIds` | `string[]` | Não definido na interface | obrigatório |
| `visible` | `boolean` | Não definido na interface | obrigatório |
| `locked` | `boolean` | Não definido na interface | obrigatório |
| `collapsed` | `boolean` | Não definido na interface | opcional |
| `properties` | `Record<string, any>` | Não definido na interface | obrigatório |
| `script` | `string` | Não definido na interface | opcional |
| `behaviors` | `string[]` | Não definido na interface | opcional |
| `signals` | `{` | Não definido na interface | opcional |
| `id` | `string` | Não definido na interface | obrigatório |
| `signalName` | `string` | Não definido na interface | obrigatório |
| `targetNodeId` | `string` | Não definido na interface | obrigatório |
| `targetMethod` | `string` | Não definido na interface | obrigatório |

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: Nenhuma importação explícita.


## Emenda v5.1.3 — Partículas
- `ParticleEmitter` removido de `NodeType`; `ParticleSystem` é o único tipo de partículas (AIS-18c). Ver `particle-system.spec.md`.


## Emenda v5.5 — Colisão do objeto (decisão 26)
- `GameNode.physics` de primeiro nível **não existe**. Física e colisão vivem em `GameNode.properties.physics` (`PhysicsConfig`: `enabled`, `bodyMode`, `shape`, `size?`, `offset?`, `friction?`, `bounce?`, `mass?`, `layer?`, `mask?`, `constrainToPlane?`, `forwardAxis?`, `floats?`), validado por `PhysicsConfigSchema`. Ausência do bloco = sem corpo.
- `StaticBody`, `RigidBody`, `KinematicBody`, `Area` e `CollisionShape` foram eliminados de `NodeType`; cenas antigas são migradas ao abrir (`convertLegacyPhysics`) e o que não converte vira Missing Node.

## Emenda v5.7 (AIS-33a) — MeshInstance com modelo 3D
`MeshInstance` ganhou `model` (`ResourceRef`, descriptor `type: resource`, visível só quando existe) e `modelOffset` (`Vector3`); **não** existe `NodeType` novo. Com `model`, o nó desenha o modelo real (`res://models/`) e `meshType` fica guardado, sem efeito (fallback/Undo). O objeto é criado por `createModelObject` (`src/core/models/`), a mesma fábrica do editor, do Play e do preview.
