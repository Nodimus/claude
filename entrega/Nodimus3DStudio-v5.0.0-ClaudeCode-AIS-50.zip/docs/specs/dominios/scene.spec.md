# scene

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** CRÍTICA
- **Prompts/etapas relacionados:** AIS-03, AIS-03c, AIS-04, AIS-29, AIS-29b, AIS-29d, AIS-31, AIS-32c, AIS-44b, AIS-48b, AIS-56, AIS-68, AIS-69, AIS-71, AIS-72, AIS-73, AIS-75, AIS-80, AIS-81, AIS-81b
- **Papel no produto:** Definição autoral de cena.
- **Fronteira obrigatória:** Scene autoral não é RuntimeScene; Play cria instância descartável.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

## 1. Identificação
- **Nome:** scene
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/types/scene.ts`
- **Linhas (auditado v4.4):** 103

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `scene`.

## 3. Estrutura
- Declarações exportadas: `BloomSettings`, `BlurSettings`, `ColorizeSettings`, `VignetteSettings`, `PostProcessingSettings`, `DEFAULT_POST_PROCESSING`, `FogMode`, `SceneFogSettings`, `DEFAULT_SCENE_FOG`, `SceneData`

## 4. Campos
### `BloomSettings`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `enabled` | `boolean` | Não definido na interface | obrigatório |
| `blurIterations` | `number` | Não definido na interface | obrigatório |
| `threshold` | `number` | Não definido na interface | obrigatório |
### `BlurSettings`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `enabled` | `boolean` | Não definido na interface | obrigatório |
| `iterations` | `number` | Não definido na interface | obrigatório |
### `ColorizeSettings`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `enabled` | `boolean` | Não definido na interface | obrigatório |
| `color` | `string` | Não definido na interface | obrigatório |
### `VignetteSettings`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `enabled` | `boolean` | Não definido na interface | obrigatório |
| `intensity` | `number` | Não definido na interface | obrigatório |
| `radiusA` | `number` | Não definido na interface | obrigatório |
| `radiusB` | `number` | Não definido na interface | obrigatório |
### `PostProcessingSettings`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `bloom` | `BloomSettings` | Não definido na interface | obrigatório |
| `blackAndWhite` | `{ enabled: boolean` | Não definido na interface | obrigatório |
### `SceneFogSettings`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `enabled` | `boolean` | Não definido na interface | obrigatório |
| `mode` | `FogMode` | Não definido na interface | obrigatório |
| `color` | `string` | Não definido na interface | obrigatório |
| `density` | `number` | Não definido na interface | obrigatório |
| `near` | `number` | Não definido na interface | obrigatório |
| `far` | `number` | Não definido na interface | obrigatório |
| `height` | `number` | Não definido na interface | obrigatório |
| `heightFalloff` | `number` | Não definido na interface | obrigatório |
| `affectSkybox` | `boolean` | Não definido na interface | obrigatório |
| `windDrift` | `boolean` | Não definido na interface | obrigatório |
| `windSpeed` | `number` | Não definido na interface | obrigatório |
### `SceneData`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `path` | `string` | Não definido na interface | obrigatório |
| `rootNodeId` | `string` | Não definido na interface | obrigatório |
| `nodes` | `Record<string, GameNode>` | Não definido na interface | obrigatório |
| `postProcessing` | `PostProcessingSettings` | Não definido na interface | opcional |
| `fog` | `SceneFogSettings` | Não definido na interface | opcional |
| `createdAt` | `string` | Não definido na interface | obrigatório |
| `updatedAt` | `string` | Não definido na interface | obrigatório |

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: `./node`


## Emenda v5.5 — AIS-29 (serialização de cenas)
- `*.scene.json` é gravado no formato canônico `SceneFile` por `serializeSceneToJson` (`src/core/serialization/sceneSerializer.ts`): `schemaVersion`, `sceneId`, `rootNodeId`, nós em ordem de hierarquia, campos em ordem fixa, vetores `[x,y,z]`, valores iguais ao padrão do tipo omitidos, `sceneSettings` (ambiente, câmera, pós-processamento, fog). `SceneData.path` não é gravado (vem de onde o arquivo mora).
- A leitura (`deserializeScene`/`parseSceneJson`) aceita o formato canônico e o antigo (`SceneData` direto), recusa `schemaVersion` mais novo, repara pai/filhos/órfãos/ciclos e transforma nó corrompido em `Missing` (dados originais regravados intactos). IDs nunca são inventados: o id do nó é o da chave; o da cena, se faltar, deriva do caminho.
- `GameNodeV1Schema` é `passthrough`: campos extras (`visualLogic`, dados de versões futuras, Behaviors/Actions de ID desconhecido) são preservados.

## Emenda v5.5 — AIS-29b (migrações)
- `CURRENT_SCENE_SCHEMA_VERSION = 2`: v1 = `SceneData` gravado direto; v2 = formato canônico `SceneFile`. Migração pura `migrateSceneV1ToV2` (`src/migrations/sceneMigrations.ts`), registrada em `src/migrations/index.ts`; documento sem `schemaVersion` vale v1.
- Pipeline de leitura: `migrateStepwise` (um salto por vez, sem mutar a entrada; versão inválida/mais nova/salto ausente/falha de passo = erro sem dado parcial) → validação por nó → varredura de contribuições (`collectUnresolvedContributions`, só leitura). `UnresolvedContribution` guarda `contributionId`, `source`, `properties`/`parameters`, extras (inclusive `addonId` legado) e o bloco cru; Salvar nunca apaga o bloco.
- Escrita protegida: arquivo ilegível nunca é sobrescrito (`writeGuard`; "Salvar como" segue permitido) e o original de um arquivo migrado é copiado uma vez (`migrationBackup`, chave `nodimus_backup_<projeto>_<hash do caminho>_v<versão>`) antes da primeira regravação.
- `validateScene` (schema do formato v1) não aplica a migração v1→v2; arquivos são lidos por `parseSceneJson`.

## Emenda v5.5 — AIS-29d (runtime de cenas)
- `src/runtime/`: `RuntimeSceneManager` (load/unload/change com ponto de aborto/restart), `RuntimeScene` (árvore viva descartável construída de um `AuthoringSceneSnapshot`), `RuntimeInstance` (liga o id autoral `persistentNodeId` a um handle de runtime com estado PRÓPRIO: transform, propriedades, tags e variáveis são cópias profundas) e `RuntimeObjectFactory` (único ponto de criação/destruição de `THREE.Object3D` de runtime; libera geometria, material e textura).
- O runtime só lê o snapshot: não importa EditorContext, AuthoringModel nem CommandManager e nunca gera Undo. Nós `Missing` não têm instância (filhos sobem para o pai mais próximo). Até o `RuntimeSession` (AIS-44b), `playScene`/`playProject` carregam a cena viva e `stopGame` a descarta (`globalRuntimeSceneManager`); o Viewport do editor segue dono dos objetos de edição.

## Emenda v5.5 — AIS-29f (cenas do projeto)
- `src/core/sceneManager.ts` (puro): `addScene`, `duplicateScene`, `renameScene`, `setInitialScene`, `planSceneDeletion`, `listScenes`. A cena INICIAL é `settings.general.mainScene` (o `project.json` deriva `startSceneId`/`isStartScene` dela; abrir outra cena não a troca) e o `id` de cada cena no `project.json` é o `sceneId` estável do arquivo, que renomear nunca altera. Excluir o arquivo passa por `deleteResource` (AIS-29e); cena única não se exclui e a inicial exige escolher outra.
- `SceneSelector` (barra da viewport) reúne Add, Duplicar, Renomear, Excluir, Definir como inicial e Settings.
