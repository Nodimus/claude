# tauriBridge

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** ALTA
- **Prompts/etapas relacionados:** AIS-30, AIS-78c, AIS-85, AIS-85b
- **Papel no produto:** Fronteira de capacidades nativas do editor.
- **Fronteira obrigatória:** Tauri do Editor ≠ empacotamento/runtime publicado; chamadas nativas passam por capabilities/bridge.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

## 1. Identificação
- **Nome:** tauriBridge
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/core/tauriBridge.ts`
- **Linhas (auditado v4.4):** 139

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `tauriBridge`.

## 3. Estrutura
- Declarações exportadas: `PlatformCapabilities`, `TauriBridge`

## 4. Campos
### `PlatformCapabilities`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `isTauri` | `boolean` | Não definido na interface | obrigatório |
| `isDesktopOnly` | `boolean` | Não definido na interface | obrigatório |
| `isMobile` | `boolean` | Não definido na interface | obrigatório |
| `hasNativeFS` | `boolean` | Não definido na interface | obrigatório |
| `hasNativeDialog` | `boolean` | Não definido na interface | obrigatório |

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: Nenhuma importação explícita.

## 8. Auditoria da casca (v4.4)
Conferido em `src/core/tauriBridge.ts`. Detecta Tauri por `'__TAURI__' in window` e chama `__TAURI__.dialog.open/save` e `__TAURI__.fs.readBinaryFile/writeTextFile` (**API do Tauri v1**). Fallback web: `<input type=file>` (lê **como texto**, sem ArrayBuffer) e download por Blob. Não há API de listar/ler/gravar diretório. A migração para Tauri v2 (plugins `dialog`/`fs`) pertence ao AIS-30/AIS-AP; no modo web (`npm run dev`, antes do AIS-AP) continua só o fallback web.

## 9. Emenda v5.6 (AIS-30)
`TauriBridge` migrado para **Tauri v2**: detecção por `__TAURI_INTERNALS__`; `@tauri-apps/api`, `plugin-dialog` e `plugin-fs` instalados e importados **dinamicamente** só dentro do Tauri. A API v1 (`__TAURI__.fs/dialog`) foi removida. Novo: `readTextFile`, `readBinaryFile`, `writeTextFile`/`writeBinaryFile` (atômicas: temporário + `rename`), `exists`, `listDirectory`, `createDirectory`, `deleteFile`, `moveFile` (só via `deleteResource`/`moveResource`), `openProjectFolderDialog`, `exportProjectDialog`; helpers puros `joinPath`, `atomicTempPath`. No web, o FS nativo lança `NativeFsUnavailableError` (sem simulação) e `openProjectFolderDialog` devolve `null`; `openFileDialog`/`saveFile` mantêm o fallback do navegador. Testes: `src/core/tauriBridge.test.ts`.
