# video

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** MÉDIA
- **Prompts/etapas relacionados:** AIS-84
- **Papel no produto:** Contrato do elemento documentado, preservando o estado observado no código.
- **Fronteira obrigatória:** Não duplicar serviços centrais; integrar por contratos públicos e manter separação Editor/Authoring/Runtime quando aplicável.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

## 1. Identificação
- **Nome:** video
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/types/video.ts`
- **Linhas (auditado v4.4):** 79

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `video`.

## 3. Estrutura
- Declarações exportadas: `VideoScreenShape`, `VideoFilter`, `VideoClipSettings`, `DEFAULT_VIDEO_SETTINGS`

## 4. Campos
### `VideoClipSettings`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `url` | `string` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `duration` | `number` | Não definido na interface | obrigatório |
| `currentTime` | `number` | Não definido na interface | obrigatório |
| `trimStart` | `number` | Não definido na interface | obrigatório |
| `trimEnd` | `number` | Não definido na interface | obrigatório |
| `playbackRate` | `number` | Não definido na interface | obrigatório |
| `loop` | `boolean` | Não definido na interface | obrigatório |
| `muted` | `boolean` | Não definido na interface | obrigatório |
| `volume` | `number` | Não definido na interface | obrigatório |
| `aspectRatio` | `'16:9' \| '4:3' \| '21:9' \| '1:1' \| '9:16'` | Não definido na interface | obrigatório |
| `emissiveIntensity` | `number` | Não definido na interface | obrigatório |
| `roughness` | `number` | Não definido na interface | obrigatório |
| `metalness` | `number` | Não definido na interface | obrigatório |
| `shape` | `VideoScreenShape` | Não definido na interface | obrigatório |
| `filters` | `VideoFilter` | Não definido na interface | obrigatório |
| `chromaKey` | `{` | Não definido na interface | obrigatório |
| `enabled` | `boolean` | Não definido na interface | obrigatório |
| `color` | `string` | Não definido na interface | obrigatório |
| `similarity` | `number` | Não definido na interface | obrigatório |
| `smoothness` | `number` | Não definido na interface | obrigatório |

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: Nenhuma importação explícita.
