# registry

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** ALTA
- **Prompts/etapas relacionados:** AIS-28c, AIS-29c, AIS-81, AIS-81b
- **Papel no produto:** Registro canônico de tipos/recursos.
- **Fronteira obrigatória:** Evitar registries paralelos; identidade persistente deve ser resolvida por ID.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

> **Atualização v5.3 (AIS-18d):** `src/nodes/registry.ts` é a fonte única dos tipos de nó (`NODE_DEFINITIONS`, `defineNodeTypes` exige `type` = chave). Schema Zod e `CreateNodeModal` derivam dele; `Missing` preserva tipos desconhecidos.

## 1. Identificação
- **Nome:** registry
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/nodes/registry.ts`
- **Linhas (auditado v4.4):** 708

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `registry`.

## 3. Estrutura
- Declarações exportadas: `NODE_REGISTRY`, `getNodeMetadata`, `createDefaultNode`

## 4. Campos
O arquivo não declara interfaces com campos diretamente extraíveis.

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: `../types/node`


## Emenda v5.1.3 — Partículas
- Um só registro `ParticleSystem` (propriedades em `particle-system.spec.md`: `emitting`, `emitterRadius`, `emitterBoxSize`, `texture`, `presetId`, `seed`); `ParticleEmitter` removido (AIS-18c).


## Emenda v5.5 — AIS-28c (ResourceRegistry ≠ NODE_DEFINITIONS)
- `ResourceRegistry` (`src/core/resources/`) é o registro de RECURSOS do projeto (arquivos de `res://` com identidade, tipo, importador e dependências); não tem relação com `NODE_DEFINITIONS` (tipos de nó). Instâncias únicas: `globalResourceRegistry` e `globalAssetPipeline` (`src/core/resources/global.ts`), ligadas ao `AuthoringModel`.

## Emenda v5.5 — AIS-29c (DependencyGraph)
- `DependencyGraph` (`src/core/resources/DependencyGraph.ts`) é o ÚNICO grafo de dependências; vive em `globalResourceRegistry.graph` e é atualizado de forma incremental a cada sincronização do registry (só quem teve o conteúdo alterado é re-extraído). `extractDependencies` (`dependencyExtractor.ts`) é o único lugar que conhece os formatos (cena, prefab, material, sprite, animação, scripts…).
- Nós = `resourceId` estável (mais ids sintéticos `logic:<tipo>/<id>` para pastas de `src/logic/`). Arestas tipadas: `runtime`, `optional`, `editor`, `external` (URL) e `unresolved` (alvo inexistente: preservada e reparável, com a força original em `intended`). Mudança de URI não muda identidade nem arestas; referência escrita por caminho que ficou velha aparece em `getStaleReferences()` (o AIS-29e a reescreve).
- Consultas: `getDirect`, `getReverse`, `getReachable` (Publish: `getReachable(cenaPrincipal)`; Prefab: `subgraph(prefab)`), `invalidate`, `findCycles`/`wouldCreateCycle`, `getMissing`/`resolveMissing`, `getRemovalReport` (excluir/mover/substituir consultam antes). `AssetPipeline.import` devolve `dependents`.
