# commandManager

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** CRÍTICA
- **Prompts/etapas relacionados:** AIS-18, AIS-18b, AIS-19, AIS-20, AIS-22
- **Papel no produto:** Única trilha de mutações autorais reversíveis.
- **Fronteira obrigatória:** Transformações e edições persistentes devem produzir Commands com undo/redo; runtime não entra no histórico.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.


### 0.1 Revisão v4.1 — relação com Zustand/Zod
- CommandManager **não é state manager** e não é substituído por Zustand.
- Comandos alteram o Authoring Model; Zustand apenas reflete/publica o resultado para a UI.
- Seleção, abertura de painel e outros estados editoriais não persistentes não precisam virar Commands.
- Runtime não entra no histórico. Zod valida fronteiras, não executa Commands.
- **Prompts adicionais:** AIS-03d, AIS-03f.

## 1. Identificação
- **Nome:** commandManager
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/core/commandManager.ts`
- **Linhas (auditado v4.4):** 87

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `commandManager`.

## 3. Estrutura
- Declarações exportadas: `CommandManager`, `globalCommandManager`

## 4. Campos
O arquivo não declara interfaces com campos diretamente extraíveis.

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: `../types/commands`

## 8. Auditoria da casca (v4.4)
Conferido em `src/core/commandManager.ts` (87 linhas) e `src/types/commands.ts` (6 linhas).
- `ICommand { name; execute; undo; redo? }` — o campo hoje é **`name`**; o canônico é `label` (decisão 10: `name` aceito por compatibilidade, `description` alias, `timestamp` atribuído pelo manager).
- `CommandManager`: `execute/undo/redo/canUndo/canRedo/getUndoActionName/getRedoActionName/clear/subscribe`; `maxHistory = 50` com `shift()` — **diverge** da decisão 10 (sem limite numérico).
- Singleton `globalCommandManager` usado por `EditorContext`. Não existe `MacroCommand`, mescla de gesto, `ChangePropertyCommand`, `SetTransformCommand` nem `SceneTreeCommands` (criar em `src/core/commands/`, conforme AIS-18 a AIS-22).
