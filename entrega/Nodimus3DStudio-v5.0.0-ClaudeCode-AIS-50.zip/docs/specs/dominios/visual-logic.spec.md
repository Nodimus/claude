# visualLogic

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** CRÍTICA
- **Prompts/etapas relacionados:** AIS-05r, AIS-39, AIS-40, AIS-40b, AIS-41, AIS-41b, AIS-42, AIS-43, AIS-44, AIS-44b
- **Papel no produto:** Contrato persistente de Behaviors, Triggers, Conditions e Actions.
- **Fronteira obrigatória:** Separar Definition de Instance; execução pertence ao runtime/dispatcher, não ao modelo autoral.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

## 1. Identificação
- **Nome:** visualLogic
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/types/visualLogic.ts`
- **Linhas (v4.7.0):** 48
- **v4.7.0:** `LogicEventType`, `LogicConditionType`, `LogicActionType` e `BehaviorType` passaram a ser `string` (ID = nome da pasta em `src/logic/<tipo>/<id>/`); as uniões fechadas saíram deste arquivo. Catálogo: `logic-registry.spec.md`.

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `visualLogic`.

## 3. Estrutura
- Declarações exportadas: `LogicEventType`, `LogicConditionType`, `LogicActionType`, `BehaviorType`, `LogicCondition`, `LogicAction`, `LogicEventRule`, `Behavior`

## 4. Campos
### `LogicCondition`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `type` | `LogicConditionType` | Não definido na interface | obrigatório |
| `parameters` | `Record<string, any>` | Não definido na interface | obrigatório |
### `LogicAction`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `type` | `LogicActionType` | Não definido na interface | obrigatório |
| `parameters` | `Record<string, any>` | Não definido na interface | obrigatório |
### `LogicEventRule`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `eventType` | `LogicEventType` | Não definido na interface | obrigatório |
| `parameters` | `Record<string, any>` | Não definido na interface | obrigatório |
| `conditions` | `LogicCondition[]` | Não definido na interface | obrigatório |
| `actions` | `LogicAction[]` | Não definido na interface | obrigatório |
### `Behavior`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `targetNodeId` | `string` | Não definido na interface | obrigatório |
| `behaviorType` | `BehaviorType` (`string`) | Não definido na interface | obrigatório |
| `enabled` | `boolean` | Não definido na interface | obrigatório |
| `properties` | `Record<string, any>` | Não definido na interface | obrigatório |
| `rules` | `LogicEventRule[]` | Não definido na interface | obrigatório |

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- IDs não são mais uniões fechadas; a validade de um ID é consultada no `LogicRegistry`. ID desconhecido é preservado.

## 7. Dependências
- Importações diretas: Nenhuma importação explícita.
