# State Architecture v4.1

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** contrato de evolução v4.1 (não há baseline no código analisado); descreve o alvo que os prompts devem criar.
- **Criticidade arquitetural:** CRÍTICA
- **Prompts/etapas relacionados:** AIS-02b, AIS-03c, AIS-03d, AIS-03f
- **Papel no produto:** Matriz de autoridade de estado (Zod, Authoring, CommandManager, Zustand, RuntimeSession).
- **Fronteira obrigatória:** Um único dono por tipo de dado; nenhum store/undo/schema paralelo.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

## 1. Identificação
- **Nome:** State Architecture v4.1
- **Tipo:** Domínio / política transversal
- **Localização no código:** política — sem arquivo único (ver AIS-03f)

## 0. Contrato canônico
Zod valida fronteiras; Authoring Model é autoridade persistente; CommandManager executa mutações reversíveis; Zustand EditorStore mantém/projeta estado reativo da IDE; RuntimeSession contém estado transitório do jogo.

## Regras
- `setState` direto não edita dados persistentes da cena.
- Runtime não vive no EditorStore.
- THREE/Rapier/renderers/loops não são estado serializável do store.
- EditorContext é somente compatibilidade temporária durante migração.
- Uma responsabilidade = uma fonte de verdade.

## Fluxos
Edição reversível: UI -> CommandManager -> Authoring Model -> notificação/projeção -> EditorStore -> UI.
Load: bytes/JSON -> Zod Vn -> migrations quando necessárias -> Authoring Model.
Play: Authoring Model -> snapshot/materialização -> RuntimeSession.

- Estado de UI transitório do pincel de terreno (`activeSculptTool`, `brushRadius`, `brushStrength`, `brushFalloff`, `flattenTargetHeight`, `paintLayer`; AIS-50b) vive no `EditorStore`, é registrado em `stateMutationPolicy` como **não autoral**: sem Command, sem persistência no `.scene`.

## Prompts
AIS-02b, AIS-03b, AIS-03c, AIS-03d, AIS-03e, AIS-03f, AIS-50b (campos de UI do pincel).
