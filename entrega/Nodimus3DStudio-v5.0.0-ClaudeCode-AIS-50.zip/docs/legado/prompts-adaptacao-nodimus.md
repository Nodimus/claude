# Prompts de Adaptação Canônica — Nodimus 3D Studio (Prompts 00 a 67)

> **Documento Canônico de Especificação de Prompts & Adaptação para Criação Desktop Real**  
> **Diretrizes Oficiais Aplicadas:** Resolução do Quiz Consolidado
> - **Item 1: Opção A** — Unificação e retargeting automatizado com esqueleto padrão humanoid (Mixamo/Godot Humanoid de 19 ossos), com merge de trilhas de animação (.anim / clipes) para `AnimationPlayer`.
> - **Item 2: Opção C** — Este é um editor estritamente desktop (Tauri v2), otimizado para mouse de precisão, docked layout, teclado e sem concessões mobile.
> - **Item 3: Opção A** — Extração e salvamento automático das texturas procedurais e importadas como arquivos independentes em `res://textures/`, referenciados pelos materiais.

Consulte o documento completo com todos os 68 prompts formatados para uso direto em `.docs/Prompts-00-67-Nodimus-consolidado.md`.

---

## 1. Princípios Globais de Execução dos Prompts

1. **Verdade Visual:** O protótipo visual do AI Studio (layout Godot 3.x, docked panels, tema escuro, alta densidade, Viewport 3D Three.js e mini-editor `AssetImportModal`) é a referência soberana de interface e ergonomia.
2. **Verdade Funcional / Plataforma:** **Editor Estritamente Desktop (Opção C)** empacotado em Tauri v2, com zero resquícios de Electron, atalhos de teclado de precisão (`Ctrl/Cmd+Z`, `Ctrl/Cmd+S`, `F5`, `F6`, `W`, `E`, `R`, `F`), manipuladores precisos de mouse e compatibilidade isomórfica no preview web.
3. **Tratamento de Assets Tridimensionais:**
   - **Retargeting & Animações (Opção A):** 19 ossos padrão humanoid Mixamo; unificação de trilhas de animações em lote para nós `AnimationPlayer` com descritores em `res://materials/<asset>_rig.json`.
   - **Texturas e Materiais (Opção A):** Extração obrigatória para `res://textures/<asset>_material.json` e arquivos independentes, permitindo reuso em múltiplos nós e materiais.

---

## 2. Resumo Estruturado dos Módulos (Prompts 00 a 67)

### Módulo 1: Setup e Infraestrutura Desktop Tauri v2 (Prompts 00 a 05)
- **Prompt 00:** Bootstrap da aplicação desktop nativa Tauri v2 com Vite, React 19 e TypeScript (Zero Electron).
- **Prompt 01:** Shell visual docked inspirado no Godot 3.x com TopBar, SceneTree, FileSystem, Viewport 3D e Inspector.
- **Prompt 02:** Estado central `EditorContext` com suporte a histórico, nós e modais.
- **Prompt 03:** Tipagem estrita TypeScript do grafo de nós 3D (`types/scene.ts`, `types/node.ts`).
- **Prompt 04:** Listener global de atalhos de teclado desktop (`F5`, `F6`, `F8`, `Ctrl+S`, `Ctrl+Z`, `Ctrl+Y`, `W`, `E`, `R`, `F`).
- **Prompt 05:** Inicialização e persistência do projeto inicial com árvore de pastas virtual `res://` e `projectStorage.ts`.

### Módulo 2: Viewport 3D, Câmera Orbital, Gizmos RGB e Snapping (Prompts 06 a 12)
- **Prompt 06:** Canvas WebGL Three.js com PCFSoftShadowMap, iluminação e tone mapping.
- **Prompt 07:** Câmera orbital com botões de mouse desktop e modos perspectiva/ortográfico.
- **Prompt 08:** Gizmo de transformação interativo RGB (TransformControls) com eixos X=Vermelho, Y=Verde, Z=Azul.
- **Prompt 09:** Snapping configurável de grid (0.1m a 2.0m), rotação (15° a 90°) e superfície.
- **Prompt 10:** Seleção de objetos via Raycast com mouse desktop e bounding box destacada.
- **Prompt 11:** Camada 2D overlay com indicador de eixos mundiais e réguas métricas.
- **Prompt 12:** Enquadramento suave de câmera (Frame Selected — Tecla F).

### Módulo 3: Grafo de Cena, Hierarquia de Nós e SceneTree (Prompts 13 a 17)
- **Prompt 13:** Painel da árvore de nós (`SceneTreePanel.tsx`) com ícones técnicos e controles de visibilidade/trava.
- **Prompt 14:** Reordenação e reparenting de nós com drag-and-drop.
- **Prompt 15:** Diálogo modal de criação de nós (`CreateNodeModal.tsx`) com busca e categorias.
- **Prompt 16:** Menu de contexto com botão direito na árvore (adicionar, renomear, duplicar, deletar).
- **Prompt 17:** Seleção múltipla de nós (Shift/Ctrl + Clique) com ações em lote.

### Módulo 4: Command Manager, Histórico Undo/Redo e Transações (Prompts 18 a 22)
- **Prompt 18:** Arquitetura do `CommandManager` com filas `undoStack` e `redoStack`.
- **Prompt 19:** Comandos de transformação (posição, rotação, escala) com registro atômico.
- **Prompt 20:** Comandos de árvore (adicionar, deletar, reparentar com preservação de pose mundial).
- **Prompt 21:** Comandos de alteração de propriedades no inspetor.
- **Prompt 22:** MacroCommand para agrupar operações compostas em transações atômicas de 1 clique.

### Módulo 5: Inspetor Dinâmico e Propriedades de Nós (Prompts 23 a 27)
- **Prompt 23:** `InspectorPanel.tsx` com renderização dinâmica conforme o tipo do nó ativo.
- **Prompt 24:** Controles numéricos arrastáveis (drag numbers) com sensibilidade ajustável e eixos coloridos RGB.
- **Prompt 25:** Inspetor de materiais PBR com seletor referenciando arquivos em `res://textures/`.
- **Prompt 26:** Inspetor de física, corpos rígidos (Static, Kinematic, Dynamic, Character) e formas de colisão.
- **Prompt 27:** Aba de sinais do nó (`NodeSignalsTab.tsx`) para conexão visual de eventos.

### Módulo 6: Sistema de Arquivos Virtual `res://` e Serialização (Prompts 28 a 32)
- **Prompt 28:** Navegador de arquivos (`FileSystemPanel.tsx`) com criação de pastas e atalho de import 3D.
- **Prompt 29:** Serializador e parser de cenas para formato `.scene.json`.
- **Prompt 30:** Conexão com sistema de arquivos nativo do SO via Tauri v2 com fallback isomorfo web.
- **Prompt 31:** Drag-and-drop de arquivos do navegador diretamente para a cena e viewport 3D.
- **Prompt 32:** Gerenciador de projetos locais (`ProjectManagerModal.tsx`) estilo Godot.

### Módulo 7: Ingestão 3D, Mini-Editor, Régua SketchUp, Retargeting Mixamo (Item 1 Opção A) e Texturas `res://textures/` (Item 3 Opção A) (Prompts 33 a 38)
- **Prompt 33:** Mini-editor integrado `AssetImportModal.tsx` com 5 abas integradas.
- **Prompt 34:** Botões de auto-alinhamento, centralização XZ, snap ao chão e manequim de 1.80m estilo SketchUp com poste métrico graduado.
- **Prompt 35:** Editor procedural de texturas e **extração automática de arquivos para `res://textures/<asset>_material.json`** (*Item 3: Opção A*).
- **Prompt 36:** Retargeting automatizado para **esqueleto bípede de 19 ossos padrão humanoid Mixamo** (*Item 1: Opção A*).
- **Prompt 37:** Unificação e mesclagem de múltiplas trilhas de animação (.anim) para nó `AnimationPlayer` com player e timeline integrados.
- **Prompt 38:** Quiz diagnóstico de importação com detecção de escala, rotação e auto-correção em 1 clique.

### Módulo 8: Lógica Visual estilo CopperCube (@dnd-kit) e Behaviors/Triggers (Prompts 39 a 44)
- **Prompt 39:** `VisualLogicEditor.tsx` com interface docked para comportamentos sem código.
- **Prompt 40:** Catálogo de gatilhos (OnSceneStart, OnKeyDown desktop, OnCollision, OnTimer, OnVariableChanged).
- **Prompt 41:** Mais de 30 ações pré-programadas de movimentação, física, áudio, partículas e troca de cena.
- **Prompt 42:** Modal de configuração tipada de parâmetros de ações.
- **Prompt 43:** Gerenciador de variáveis globais e locais (`variableManager.ts`).
- **Prompt 44:** Executor e interpretador de lógica visual no runtime de simulação.

### Módulo 9: Simulação Física, Colisões e Sandbox Isolado (Prompts 45 a 49)
- **Prompt 45:** Formas de colisão 3D (Box, Sphere, Capsule, Trimesh) com wireframes de depuração.
- **Prompt 46:** Sandbox isolado de simulação (`PlaySimulationModal.tsx`), clonando a cena e preservando a pose do editor ao parar.
- **Prompt 47:** Controladores de personagem em 1ª e 3ª pessoa com WASD e Mouse Look.
- **Prompt 48:** Despacho de sinais de colisão e sensores volumétricos.
- **Prompt 49:** Otimização de corpos em repouso (sleeping bodies) e descarte em limite inferior.

### Módulo 10: Modais Procedurais (Terreno, Árvores, Áudio, Partículas, Pós-Processamento, Nevoeiro) (Prompts 50 a 56)
- **Prompt 50:** `TerrainEditorModal.tsx` com escultura e pintura de relevo 3D por heightmap.
- **Prompt 51:** `TreeEditorModal.tsx` com modelagem botânica paramétrica e sementes aleatórias.
- **Prompt 52:** `SoundModal.tsx` com sintetizador sonoro e atenuação espacial 3D.
- **Prompt 53:** `ParticleModal.tsx` com emissores de partículas configuráveis (fogo, fumaça, chuva, explosões).
- **Prompt 54:** `FogModal.tsx` com névoa linear, exponencial e neblina de solo.
- **Prompt 55:** `PostProcessingModal.tsx` com Bloom, SSAO, Vinheta e Tone Mapping.
- **Prompt 56:** Sincronização uniforme de nós procedurais com a SceneTree e CommandManager.

### Módulo 11: Barramento de Sinais, Entrada Desktop e Animações (Prompts 57 a 61)
- **Prompt 58:** Mapeamento de entradas desktop personalizável (`inputMap.ts`).
- **Prompt 59:** Interpolador procedural de propriedades (`tweener.ts`).
- **Prompt 60:** Nó `AnimationPlayerNode` com crossfading e suporte às trilhas unificadas Mixamo.
- **Prompt 61:** Timeline e editor de pistas no painel inferior.

### Módulo 12: Otimização de Performance, Empacotamento Nativo Tauri v2 Desktop (Item 2 Opção C) e Certificação Final (Prompts 62 a 67)
- **Prompt 62:** Auditoria de dependências com verificação anti-Electron e tipagem limpa.
- **Prompt 63:** Configuração nativa Rust em `src-tauri/` para empacotamento desktop (Windows .msi/.exe, macOS .dmg, Linux .AppImage).
- **Prompt 64:** Otimização de chunks Three.js e inicialização ultra-rápida.
- **Prompt 65:** Testes isomórficos web/desktop.
- **Prompt 66:** Validação do checklist das decisões canônicas (Retargeting Mixamo, Desktop Estrito, Texturas `res://textures/`).
- **Prompt 67:** Certificação final de prontidão para distribuição nativa desktop.
