/// <reference types="vitest/config" />
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname, '.'),
      },
    },
    test: {
      // Testes unitários de funções puras (fixtures, registries, políticas).
      // Rodam em Node; testes que precisarem de DOM declaram `// @vitest-environment jsdom`.
      environment: 'node',
      include: ['src/**/*.test.ts', 'src/**/*.test.tsx'],
      // Testes que importam o EditorContext inteiro (dynamic import) levam ~3 s sozinhos e estouram os 5 s padrão com a suíte
      // toda em paralelo: o limite maior estabiliza o gate sem enfraquecer nenhuma asserção.
      testTimeout: 20000,
    },
  };
});
