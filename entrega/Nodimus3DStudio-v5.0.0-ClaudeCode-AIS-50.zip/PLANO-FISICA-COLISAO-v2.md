# Plano de Mudança v2 — Física e Colisão simplificadas

> **Base:** Nodimus3DStudio v5.0.0 (análise estática do código e dos prompts; `npm run check` não foi executado).
> **Status:** proposta. Substitui o plano v1 ("Física e Colisão como Propriedade do Objeto"). Nenhum arquivo do projeto foi alterado.
> **Público do editor:** iniciantes e intermediários. O objetivo é **colisão que funciona sem configurar**, não um simulador.

---

## 0. A ideia em cinco regras

1. **Colisão é uma seção do objeto**, chamada **Colisão**, com um interruptor. Ligou = o objeto colide. Desligou = não colide (a configuração fica guardada).
2. **Um objeto, um colisor, uma forma.** A forma e o tamanho são calculados sozinhos (**Auto**). O autor só mexe se quiser.
3. **Nada colide sem o autor pedir**, mas os editores do Nodimus já criam objetos com a colisão ligada: primitivas, terreno, árvores e modelos importados.
4. **O bloco diz *o que* o objeto é; os Behaviors dizem *como* ele se move.** Velocidade, pulo e controles ficam nos Behaviors de movimento. O tipo de corpo e a forma ficam na Colisão.
5. **Um motor (Rapier), uma função de resolução, um desenho de colisor**, usados no editor, no Play e no jogo publicado.

---

## 1. Motor de física: análise das alternativas

O editor precisa de: chão e paredes sólidos, personagem que anda e sobe rampas, objetos que caem e rolam, áreas-gatilho, **terreno** (heightfield), **muitas árvores** (vários colisores estáticos), **água** (flutuação simples), funcionamento offline no Tauri e um único motor (decisão 9).

| Motor | Situação | Terreno | Personagem | Água | Avaliação para o Nodimus |
|---|---|---|---|---|---|
| **Rapier** (`@dimforge/rapier3d-compat`, WASM) | Mantido ativamente; a última versão no changelog é a 0.19.3 (nov/2025); os bindings migraram para o repositório principal do Rapier | `heightfield` nativo | `KinematicCharacterController` nativo (rampas, degraus, encaixe no chão, plataformas móveis) | Não tem nativo; flutuação simples com uma força por passo (seção 5.6) | **Recomendado.** Já é a decisão canônica 9, e o contrato do terreno (decisão 23) já usa `Rapier.heightfield`. O build `-compat` embute o WASM, então funciona no Vite e no Tauri sem configuração. API pequena. |
| **Jolt** (`jolt-physics`, WASM) | Mantido; versão 1.1.0 (Jolt 5.6) | `HeightFieldShape` | `CharacterVirtual` | Tem flutuação nativa | Tecnicamente excelente, mas a API é verbosa, exige liberar memória à mão (`Jolt.destroy`), é maior e trocaria a decisão canônica 9 sem ganho para o público-alvo. Fica como plano B, se um dia faltar algo no Rapier. |
| **cannon-es** (JS puro) | Sem manutenção (última versão 0.20.0) | Heightfield | Não tem | Não tem | Descartado: sem manutenção e sem controlador de personagem. |
| **Ammo.js** (Bullet) | Sem manutenção | Sim | Rudimentar | Não | Descartado. |
| **phy** (lo-th) | Mantido | Depende do motor | Depende do motor | — | É uma camada sobre outros motores (Rapier, Jolt…). Acrescenta uma dependência sem tirar trabalho. Descartado. |
| **three-mesh-bvh** (sem motor) | Mantido | Só raycast/colisão de personagem | Exemplo de "character movement" | Não | Bom só para personagem contra cenário. Não faz objetos caírem nem gatilhos. Seria um **segundo** mecanismo de colisão. Descartado. |
| Addons `RapierPhysics`/`JoltPhysics` do Three.js | Exemplos oficiais | `addHeightfield` | Não | Não | **Não usar como dependência**, porque o `RapierPhysics` importa o Rapier de uma CDN e o editor precisa funcionar offline. **Usar como modelo de simplicidade** da nossa `PhysicsBridge` (`addMesh`, `addHeightfield`, `setVelocity`, `applyImpulse`, `remove`). |

**Conclusão:** manter o Rapier. A simplificação vem do **modelo de dados e da interface**, não da troca de motor.

---

## 2. O que muda em relação ao plano v1

| Item do v1 | v2 | Motivo |
|---|---|---|
| Campo `node.physics` de primeiro nível | **`properties.physics`** | O `ChangePropertyCommand` só escreve em `properties`. O `materialOverride` já segue esse padrão. O `GameNodeV1Schema` não descarta o campo e as sobrescritas de prefab funcionam por caminho. |
| Lista `colliders[]` com nome, rotação e partes | **Um colisor por objeto** (forma + tamanho opcional + deslocamento) | Para um objeto composto, usa-se nós filhos, cada um com a sua Colisão (já é "um corpo por GameNode"). |
| `mode: 'auto' \| 'manual'` + elegibilidade por animação | **Auto = `size` ausente.** Editar o tamanho grava `size`; "Ajustar à malha" apaga `size`. Medido ao criar o corpo (início do Play). | Sem flag, sem cache, sem gravação fora do Undo. Funciona em modelo animado (mede a pose de repouso; o Inspector avisa que o colisor não acompanha a animação). |
| Formas Convexa e Trimesh; Trimesh no terreno | **Caixa, Esfera, Cápsula, Cilindro, Malha exata** (malha exata só para "Sólido parado"); terreno usa **heightfield** | O v1 contrariava o contrato `terrainGeometry` do `CLAUDE.md` (heightfield). A forma convexa sai: é pouco intuitiva e a caixa ou esfera atende objetos físicos. |
| Arquivo `res://physics/<asset>_physics.json` + emendas AIS-28c/29c/29e | **Removido** | Reutilizar um objeto com colisão = **prefab** (decisão 18). Nenhum tipo novo de recurso. |
| AIS-33b (aba Collision avançada, árvore de partes, vários colisores) | **Emenda pequena do AIS-33** (interruptor + tipo + forma) | O cálculo é feito no Play, então o importador **não** precisa carregar a geometria real para oferecer colisão. |
| AIS-45b (sessão física no preview, teste de queda) | **Removido** | O teste é o Play da viewport + "Mostrar colisores". |
| Botão "Converter para Physics do objeto" + diagnóstico de duplicidade | **Conversão automática ao abrir a cena** e tipos legados eliminados | Uma só fonte de física; nada para o usuário entender. |
| Eventos Enter/Stay/Exit | **Enter/Exit** | Stay é raramente necessário e caro. |
| Filtro Layer/Mask emulando a Godot | **Semântica nativa do Rapier** (os dois lados precisam aceitar), escondido em "Avançado" | Sem *physics hooks*; o padrão (tudo colide com tudo) atende iniciantes. |

---

## 3. Modelo de dados

### 3.1 Local e tipo

`GameNode.properties.physics` (opcional). Mudança aditiva: sem nova `schemaVersion`. Schema Zod próprio (`PhysicsConfigSchema`) aplicado na leitura da seção e no resolvedor.

```ts
export type PhysicsBodyMode = 'static' | 'dynamic' | 'kinematic' | 'character' | 'trigger';
export type PhysicsShape = 'auto' | 'box' | 'sphere' | 'capsule' | 'cylinder' | 'mesh';

export interface PhysicsConfig {
  enabled: boolean;              // interruptor "Colisão"
  bodyMode: PhysicsBodyMode;
  shape: PhysicsShape;           // 'auto' = o editor escolhe a forma (tabela 3.3)
  size?: Vector3Data;            // AUSENTE = tamanho automático. Tamanho TOTAL (não metade), no espaço local
  offset?: Vector3Data;          // deslocamento do centro; ausente = centro da malha
  // Avançado (ausente = padrão)
  friction?: number;             // 0..1, padrão 0.5
  bounce?: number;               // 0..1, padrão 0
  mass?: number;                 // ausente = automática pelo volume
  layer?: number;                // 8 bits, padrão 1
  mask?: number;                 // 8 bits, padrão 255
  constrainToPlane?: 'none' | 'xy' | 'xz' | 'yz';   // ex-propriedade do Behavior físico (decisão 6)
  forwardAxis?: 'x' | 'z';
  floats?: boolean;              // flutua na água (só 'dynamic')
}
```

- **Tamanho total, não metade:** mais fácil para iniciantes. Caixa: largura/altura/profundidade. Esfera: `size.x` = diâmetro. Cápsula e cilindro: `x` = diâmetro, `y` = altura total. (O AIS-26 usava *extents* da Godot; o conversor de legados divide/multiplica.)
- **Estados inválidos não existem:** escolher "Malha exata" só é possível em "Sólido parado"; trocar o tipo de corpo de uma malha exata para outro troca a forma para `auto` **no mesmo Command**. Personagem força a cápsula.

### 3.2 Nomes na interface

| `bodyMode` | Rótulo | Para quê |
|---|---|---|
| `static` | **Sólido parado** | chão, paredes, cenário, árvores, terreno |
| `dynamic` | **Físico** | caixa que cai, bola que rola, objeto empurrável |
| `kinematic` | **Movido pela lógica** | porta, elevador, plataforma |
| `character` | **Personagem** | jogador e NPCs (nunca `dynamic`, decisão 9) |
| `trigger` | **Área (gatilho)** | detectar entrada/saída; não bloqueia |

### 3.3 Forma `auto`: uma função pura

`resolveCollider(config, ctx) → ColliderSpec | null` em `src/core/physics/resolveCollider.ts`. `ctx` = tipo do nó, `properties`, AABB local medido (`measureLocalBounds`, já existe) e escala global. É a **única** função que decide forma e tamanho: usada pelo wireframe do editor, pelo Play e pelo jogo publicado (que usa o mesmo runtime Three.js, decisão 20).

| Origem / nó | `auto` resolve para |
|---|---|
| `bodyMode: 'character'` | cápsula com diâmetro e altura do AABB |
| `Terrain` (AIS-50) | **heightfield** com o mesmo `Float32Array` (contrato `terrainGeometry`) |
| Árvore procedural | cilindro no tronco (`trunkRadius*`, `trunkHeight`); a copa não colide |
| `MeshInstance` `SphereMesh` | esfera |
| `CylinderMesh` | cilindro |
| `PlaneMesh` | caixa fina (altura 0,05) |
| `TorusMesh` | malha exata se `static`; senão caixa |
| Demais (cubo, modelo importado) | caixa do AABB |

Escala: o Rapier não escala colisores, então `resolveCollider` aplica a escala global ao tamanho. Escala não uniforme em esfera/cápsula usa o maior eixo (um aviso, não um por quadro).

---

## 4. Interface

### 4.1 Seção "Colisão" no Inspector (nós 3D)

```
▾ Colisão                                   [● ligado]
  Tipo     [Sólido parado ▾]
  Forma    [Auto (caixa) ▾]      Tamanho  2,0 × 1,0 × 2,0   [Ajustar à malha]
  ▸ Avançado   (atrito, quique, massa, camadas, travar no plano, flutua)
  [Remover colisão]
```

- Objeto sem colisão: a seção mostra só **[+ Adicionar colisão]**.
- Tamanho mostra o valor calculado em cinza quando automático; editar grava `size`.
- Toda escrita via `ChangePropertyCommand`/`MacroCommand` sobre `physics.*`; um gesto = um Undo.
- Aviso único em modelo animado: "O colisor usa a pose inicial e não acompanha a animação."

### 4.2 Outros pontos de interface

- **"Mostrar colisores"** (botão na toolbar da viewport, preferência do editor): wireframe por `resolveCollider` + `buildColliderWireframe`; cor por tipo; tracejado quando desligado. Vale na edição e no Play.
- **"Adicionar com colisão"** (caixa nos modais de criação: `CreateNodeModal`, `TerrainEditorModal`, `TreeEditorModal` e importador; preferência do editor, padrão ligado) → `{ enabled: true, bodyMode: 'static', shape: 'auto' }`. Nunca cria `dynamic`.
- Importador: mesma caixa, rotulada **"Importar com colisão"**, + Tipo e Forma. Modelo animado (quando o importador souber): desligado por padrão.

---

## 5. Por fonte de conteúdo

### 5.1 Primitivas
`CreateNodeModal`: `MeshInstance` nasce com colisão (estática, auto) no **mesmo Command** de criação.

### 5.2 Modelos importados / arrastados do FileSystem
Mesmo bloco. Cenários e casas: "Sólido parado" + "Malha exata" dá colisão perfeita sem configurar.

### 5.3 Terreno (AIS-50/50b)
- O nó `Terrain` nasce com colisão ligada; `auto` = heightfield.
- **A propriedade `enableCollider` do AIS-50 é substituída por `physics.enabled`** (um interruptor só em todo o editor).
- Escultura (AIS-50b) reconstrói o heightfield no fim da pincelada, como o prompt já prevê.

### 5.4 Árvores (AIS-51 / AIS-51d)
- Árvore individual: cilindro no tronco, estático.
- Floresta por `InstancedMesh` (AIS-51d): **um corpo estático no nó da vegetação com N cilindros**, um por instância, a partir das mesmas transformações e da mesma seed. Sem um nó por árvore.

### 5.5 Personagem (AIS-47)
`bodyMode: 'character'` → `KinematicCharacterController` + cápsula automática. Velocidade, pulo e gravidade do personagem ficam no Behavior de movimento.

### 5.6 Água (AIS-68) — flutuação simples
O `WaterPlane` é uma superfície plana com retângulo XZ e altura Y conhecidos. Sem simular fluido:
- A cada passo, para cada corpo `dynamic` com `floats: true` dentro do retângulo e abaixo da superfície: **força para cima proporcional à profundidade submersa** (limitada à altura do objeto) + amortecimento linear e angular extra.
- Entrar e sair da água dispara os eventos de área (o `WaterPlane` funciona como área-gatilho).
- Personagem nadando fica fora do escopo (futuro).

### 5.7 2D sobre plano (AIS-74/75)
`constrainToPlane`/`forwardAxis` lidos do bloco e mapeados para `enabledTranslations`/`enabledRotations` do Rapier, como o AIS-74 já prevê.

---

## 6. Nós legados

- `StaticBody`, `RigidBody`, `KinematicBody`, `Area` e `CollisionShape` são **eliminados** (registry, ícones, tipos, modal de criação). Cenas antigas são migradas ao abrir; o que não converter vira Missing Node (decisão 19), preservado e regravado intacto.
- **Ao abrir uma cena**, `convertLegacyPhysics(scene)` (função pura, com teste) transforma o caso simples `Body + CollisionShape filho` no bloco do nó do corpo (extents × 2 → `size`). Restos que não convertem viram Missing Node (preservados e regravados intactos) com diagnóstico "sem efeito no Play".
- O botão "Criar CollisionShape" do AIS-26 é substituído pela seção Colisão.
- `viewportPlaySimulation.ts` passa a reconhecer o jogador por `physics.bodyMode === 'character'` (hoje usa `KinematicBody` ou o nome "player"; o nome continua como alternativa até o AIS-47).

---

## 7. Plano por prompt

> Só um prompt novo. O resto são emendas curtas. Posições: o AIS-26b entra no nº 40 (antes do AIS-27); posições ≥ 40 +1; total 121. Rodar `npm run ais:docs` depois de renumerar.

| # | Prompt | Tipo | Escopo |
|---|---|---|---|
| 1 | **AIS-26b** — Colisão do objeto | NOVO (nº 40) | Tipo + schema; `resolveCollider`; seção Colisão; "Mostrar colisores"; "Adicionar com colisão" no `CreateNodeModal`; legados não criáveis + `convertLegacyPhysics`; detecção do jogador. Rapier só como dependência + harness headless (instalado aqui, usado no Play pelo AIS-45). |
| 2 | AIS-31 | emenda | Arrastar modelo cria o nó com colisão conforme a preferência. |
| 3 | AIS-33 | emenda | "Importar com colisão" + Tipo + Forma no importador. |
| 4 | AIS-32c | emenda | Códigos: `physics.legacy_unconverted`, `physics.nonuniform_scale`, `physics.mesh_missing_geometry`. |
| 5 | **AIS-45** | emenda grande | Reescrever a skill `nodimus-fisica-rapier`: fonte única `properties.physics`; remover D1 (implícito), D2 (Behavior vence Inspector), §6a (sugestão do importador) e `bodyMode: 'none'`; heightfield; filtro nativo do Rapier; API da `PhysicsBridge` no estilo do addon do Three.js; harness headless. |
| 6 | AIS-46 / 47 / 48 | emendas | Lêem o bloco; personagem = KCC + cápsula; eventos Enter/Exit com `otherId`; `on_collision_enter` passa a executar. |
| 7 | AIS-49 | emenda | Estresse: terreno heightfield grande + floresta com N cilindros. |
| 8 | AIS-50 / 50b | emenda | `enableCollider` → `physics.enabled`; colisão nasce ligada. |
| 9 | AIS-51 / 51d | emenda | Cilindro no tronco; floresta = um corpo, N cilindros. |
| 10 | AIS-68 | emenda | Flutuação simples sai de "Fora de escopo" e entra (seção 5.6). |
| 11 | AIS-74 / 75 | emenda | `constrainToPlane`/`forwardAxis` vêm do bloco. |
| 12 | AIS-77 | emenda | Overlay de debug reusa `buildColliderWireframe`. |
| 13 | Cópias da skill | emenda | Remover D1 e `0xffff` de **AIS-26, 45, 48, 49, 69, 72, 73, 74**; fechar "política a revisar" em **AIS-07 e AIS-47**. |
| 14 | `CLAUDE.md` | emenda | Nova decisão canônica 26 (seção 9); ajustar decisão 6 e o contrato do terreno (`enableCollider` → `physics.enabled`). |

Prefabs (AIS-81) e nomes de camadas (AIS-82): **sem mudança**. O bloco já vive em `properties`, então as sobrescritas por caminho e a grade de camadas funcionam como estão.

### 7.1 Critérios do AIS-26b

- [ ] **C01** Nó sem `physics` salva e carrega igual; nó com `physics` faz round-trip idêntico.
- [ ] **C02** Ligar/desligar preserva a configuração; "Remover colisão" apaga o bloco; ambos com Undo.
- [ ] **C03** `resolveCollider` cobre todas as linhas da tabela 3.3 (testes Vitest).
- [ ] **C04** Tamanho automático acompanha a mudança de `meshType`/escala no wireframe; editar o tamanho grava `size`; "Ajustar à malha" volta ao automático.
- [ ] **C05** "Malha exata" só em "Sólido parado"; trocar o tipo ajusta a forma no mesmo Undo; personagem força a cápsula.
- [ ] **C06** "Mostrar colisores" funciona na edição e no Play e não altera dados.
- [ ] **C07** "Adicionar com colisão" cria nó + bloco em um só Undo; desmarcado cria só o nó.
- [ ] **C08** `convertLegacyPhysics` converte `Body + CollisionShape` simples e preserva o resto com diagnóstico; os tipos legados foram eliminados do registry, dos tipos e do `CreateNodeModal`.
- [ ] **C09** `npm run check` verde; zero erros de console; sem regressão do AIS-26; log `docs/logs/AIS-26b.md`.

---

## 8. Definição de pronto global

- [ ] Uma malha sem bloco não cria corpo (regressão dedicada).
- [ ] Terreno, árvores, primitivas e modelos importados nascem colidindo, sem configurar.
- [ ] Personagem anda, sobe rampas e não atravessa paredes no Play.
- [ ] Objeto "Físico" com "Flutua" boia no `WaterPlane`.
- [ ] O mesmo desenho de colisor no editor, no Play e no overlay de debug.
- [ ] `character` nunca é `dynamic`; um corpo por `GameNode`.

---

## 9. Texto proposto para a decisão canônica 26

> **26. Colisão é propriedade do objeto.** Física e colisão vivem em `GameNode.properties.physics` (um colisor por objeto: tipo de corpo, forma, tamanho opcional). Forma `auto` e tamanho ausente são resolvidos por uma função única, `resolveCollider`, usada por editor, Play e publicação. Nenhuma malha colide sem o bloco; os editores internos e o importador criam o bloco ligado por padrão (estático). Motor: Rapier (decisão 9); terreno = heightfield do mesmo buffer (decisão 23). Os nós `StaticBody`/`RigidBody`/`KinematicBody`/`Area`/`CollisionShape` são **eliminados**: cenas antigas são migradas ao abrir (`convertLegacyPhysics`) e o que não converter vira Missing Node (decisão 19).

---

## 10. Pontos a confirmar antes de redigir os prompts

1. **Decisão 6:** `ConstrainToPlane`/`ForwardAxis` saem do Behavior físico e passam ao bloco (o princípio "2D sem modo especial" continua).
2. **Simplificações que revertem decisões do v1:** Auto sem elegibilidade por animação (D5), sem seleção de partes (D8), sem vários colisores (D9), sem arquivo de física por asset (D10) e sem teste de queda no preview (D11).
3. **Legados:** conversão automática ao abrir a cena + tipos não criáveis.
4. **Água:** flutuação simples entra no escopo do AIS-68.

---

## Anexo — bugs encontrados durante a análise (fora do escopo deste plano)

- `TerrainEditorModal` cria `meshType: 'Plane'`, mas o Viewport só reconhece `'PlaneMesh'`: o terreno aparece como cubo 1×1×1. Resolvido pelo AIS-50 (nó `Terrain`).
- `TreeEditorModal` cria `meshType: 'cylinder'`, que também não é reconhecido: a árvore aparece como cubo. Resolvido pelos AIS-51/51a.

## Fontes

- [Three.js manual — Physics](https://threejs.org/manual/en/physics.html)
- [Three.js docs — RapierPhysics](https://threejs.org/docs/pages/RapierPhysics.html)
- [rapier.js CHANGELOG](https://github.com/dimforge/rapier.js/blob/master/CHANGELOG.md)
- [JoltPhysics.js releases](https://github.com/jrouwe/JoltPhysics.js/releases)
- [cannon-es releases](https://github.com/pmndrs/cannon-es/releases)
- [three-mesh-bvh — Character Movement](https://gkjohnson.github.io/three-mesh-bvh/example/bundle/characterMovement.html)
- [lo-th/phy](https://github.com/lo-th/phy)
