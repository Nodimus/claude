#!/usr/bin/env node
/**
 * Status da sequência de prompts (Claude Code · v5.0.0).
 * Lê docs/prompts/ORDEM-CANONICA-V4.md e docs/logs/ e informa o que já foi
 * executado e qual é o próximo prompt pendente.
 *
 *   node scripts/ais-status.mjs           → resumo + próximo pendente
 *   node scripts/ais-status.mjs --all     → lista completa
 *   node scripts/ais-status.mjs --next    → só o ID do próximo pendente
 *   node scripts/ais-status.mjs AIS-06    → caminho do prompt + status desse ID
 *
 * Pendente = sem docs/logs/<ID>.md, ou cujo último "**Resultado:**" contém "bloqueado".
 */
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const promptsDir = join(root, 'docs', 'prompts');
const logsDir = join(root, 'docs', 'logs');

const ordem = readFileSync(join(promptsDir, 'ORDEM-CANONICA-V4.md'), 'utf8');
const ids = ['AIS-P0'];
for (const line of ordem.split('\n')) {
  const m = line.match(/^\d+\.\s.*?(AIS-(?:AP|\d+[a-z]?))\b/);
  if (m && !ids.includes(m[1])) ids.push(m[1]);
}

const promptFiles = readdirSync(promptsDir).filter((f) => /^AIS-.*\.md$/.test(f));
const fileFor = (id) => promptFiles.find((f) => f.startsWith(id + '-'));

const statusOf = (id) => {
  const p = join(logsDir, `${id}.md`);
  if (!existsSync(p)) return 'pendente';
  const results = [...readFileSync(p, 'utf8').matchAll(/\*\*Resultado:\*\*\s*([^\n]*)/g)];
  const last = results.length ? results[results.length - 1][1].toLowerCase() : '';
  if (last.includes('bloqueado')) return 'bloqueado';
  if (last.includes('pendênc') || last.includes('pendenc')) return 'concluído c/ pendências';
  return 'concluído';
};

const rows = ids.map((id, i) => ({ n: id === 'AIS-P0' ? 'P0' : String(i), id, status: statusOf(id), file: fileFor(id) }));
const next = rows.find((r) => r.status === 'pendente' || r.status === 'bloqueado');
const arg = process.argv[2];

if (arg === '--next') {
  console.log(next ? next.id : 'nenhum');
} else if (arg && arg.toUpperCase().startsWith('AIS-')) {
  const id = arg.replace(/^ais-/i, 'AIS-');
  const r = rows.find((x) => x.id.toLowerCase() === id.toLowerCase());
  if (!r) {
    console.log(`ID desconhecido: ${arg}`);
    process.exitCode = 1;
  } else {
    console.log(`${r.id} · nº ${r.n} · ${r.status} · docs/prompts/${r.file ?? '(arquivo não encontrado)'}`);
  }
} else {
  const done = rows.filter((r) => r.status.startsWith('concluído')).length;
  console.log(`Prompts: ${done}/${rows.length} com log.`);
  const list = arg === '--all' ? rows : rows.filter((r) => r.status !== 'concluído' || r === next).slice(0, 8);
  for (const r of list) console.log(`${r.n.padStart(3)}  ${r.id.padEnd(8)} ${r.status.padEnd(24)} ${r.file ?? '(arquivo não encontrado)'}`);
  console.log(`Próximo pendente: ${next ? `${next.id} (docs/prompts/${next.file})` : 'nenhum'}`);
  const missing = rows.filter((r) => !r.file);
  if (missing.length) console.log(`AVISO: prompts da ordem sem arquivo: ${missing.map((r) => r.id).join(', ')}`);
}
