#!/usr/bin/env node
/**
 * Consistência da documentação (v5.3).
 *
 *   node scripts/ais-check-docs.mjs
 *
 * Confere, a partir de docs/prompts/ORDEM-CANONICA-V4.md (única fonte da ordem):
 *  1. a numeração da ordem é contínua e sem IDs repetidos;
 *  2. todo ID da ordem tem arquivo docs/prompts/<ID>-*.md, e todo prompt está na ordem;
 *  3. o cabeçalho "Posição canônica" de cada prompt (fase, nº, total, anterior, próximo) bate com a ordem;
 *  4. nenhuma referência "AIS-NN" aponta para ID inexistente (exceto IDs removidos, listados abaixo);
 *  5. links relativos de .md existem.
 * Sai com código 1 se houver divergência.
 */
import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs';
import { join, dirname, normalize, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const promptsDir = join(root, 'docs', 'prompts');
const REMOVED = new Set(['AIS-78', 'AIS-78b', 'AIS-38b']); // citados só para dizer que foram removidos (v4.7.0) ou renomeados (AIS-38b → AIS-32c, v5.7)

const ordem = readFileSync(join(promptsDir, 'ORDEM-CANONICA-V4.md'), 'utf8').split(/\r?\n/);
const items = [];
let phase = null;
for (const ln of ordem) {
  const ph = ln.match(/^## (Fase [A-H] — .+)$/);
  if (ph) { phase = ph[1].trim(); continue; }
  const m = ln.match(/^(\d+)\.\s.*?(AIS-(?:AP|\d+[a-z]?))\b/);
  if (m) items.push({ n: Number(m[1]), id: m[2], phase });
}
const errors = [];
const total = items.length;
items.forEach((it, i) => { if (it.n !== i + 1) errors.push(`ordem: numeração quebrada em "${it.id}" (esperado ${i + 1}, achou ${it.n})`); });
const seen = new Set();
for (const it of items) { if (seen.has(it.id)) errors.push(`ordem: ID repetido ${it.id}`); seen.add(it.id); }

const files = readdirSync(promptsDir).filter((f) => /^AIS-.*\.md$/.test(f));
const fileFor = (id) => files.find((f) => f.startsWith(id + '-'));
for (const it of items) if (!fileFor(it.id)) errors.push(`ordem: ${it.id} sem arquivo em docs/prompts/`);
for (const f of files) {
  const id = f.match(/^(AIS-(?:AP|P0|\d+[a-z]?))-/)?.[1];
  if (id !== 'AIS-P0' && !seen.has(id)) errors.push(`prompt fora da ordem: ${f}`);
}

const headerRe = /^> \*\*Posição canônica:\*\* (?:(.*?) · )?nº (\d+)(?: de (\d+))? · anterior: (.*?) · próximo: (.*)$/m;
items.forEach((it, i) => {
  const f = fileFor(it.id);
  if (!f) return;
  const m = readFileSync(join(promptsDir, f), 'utf8').match(headerRe);
  if (!m) { errors.push(`${it.id}: sem linha "Posição canônica"`); return; }
  const prev = i > 0 ? items[i - 1].id : '—';
  const next = i + 1 < total ? items[i + 1].id : '—';
  const want = `${it.phase} · nº ${it.n} de ${total} · anterior: ${prev} · próximo: ${next}`;
  const got = `${m[1]} · nº ${m[2]} de ${m[3]} · anterior: ${m[4]} · próximo: ${m[5]}`;
  if (want !== got) errors.push(`${it.id}: cabeçalho diverge\n    esperado: ${want}\n    atual:    ${got}`);
});

// IDs e links
const mdFiles = [];
const walk = (dir) => {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    const rel = p.slice(root.length + 1).split(sep).join('/');
    if (name === 'node_modules' || name === 'dist' || name === '.git' || rel === 'docs/logs' || rel === 'docs/legado') continue;
    if (statSync(p).isDirectory()) walk(p);
    else if (name.endsWith('.md')) mdFiles.push(p);
  }
};
walk(join(root, 'docs'));
for (const extra of ['README.md', 'CLAUDE.md']) mdFiles.push(join(root, extra));
const known = new Set([...seen, 'AIS-P0']);
for (const f of mdFiles) {
  const rel = f.slice(root.length + 1).split(sep).join('/');
  const text = readFileSync(f, 'utf8');
  if (rel !== 'docs/CHANGELOG-PADRONIZACAO.md') {
    for (const m of text.matchAll(/AIS-(?:AP|P0|\d+[a-z]?)\b/g)) {
      if (!known.has(m[0]) && !REMOVED.has(m[0])) errors.push(`${rel}: referência a ID inexistente ${m[0]}`);
    }
  }
  for (const m of text.matchAll(/\]\(((?!https?:|#|mailto:)[^)\s]+?)(?:#[^)]*)?\)/g)) {
    const target = normalize(join(dirname(f), m[1]));
    if (!existsSync(target)) errors.push(`${rel}: link quebrado ${m[1]}`);
  }
}

if (errors.length) {
  console.error(`✗ ${errors.length} divergência(s):\n- ` + errors.slice(0, 40).join('\n- '));
  process.exit(1);
}
console.log(`✓ documentação consistente: ${total} posições, ${files.length} prompts, ${mdFiles.length} documentos.`);
