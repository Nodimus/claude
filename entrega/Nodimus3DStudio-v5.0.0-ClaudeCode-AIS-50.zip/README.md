# Nodimus 3D Studio

Editor de jogos 3D (IDE) estritamente desktop, com layout inspirado no Godot 3.x e lógica por
Behaviors/Actions inspirada no CopperCube. Stack: React 19 + TypeScript + Three.js r186 +
Tailwind CSS v4 + @dnd-kit + Motion + Lucide + CodeMirror + Zod + Zustand. O destino final é
Tauri v2 (fase AIS-AP); até lá o editor roda como aplicação web local.

## Requisitos

- Node.js 20.11 ou superior (npm incluso)
- Para a fase AIS-AP (Tauri): Rust estável e os pré-requisitos do Tauri v2 do seu sistema

## Comandos

| Comando | O que faz |
|---|---|
| `npm install` | instala dependências |
| `npm run dev` | editor em `http://localhost:3000` |
| `npm run typecheck` | `tsc --noEmit` |
| `npm test` | testes Vitest (`src/**/*.test.ts`) |
| `npm run check` | typecheck + testes + build — **gate obrigatório de todo prompt** |
| `npm run build` | build de produção em `dist/` |
| `npm run ais:docs` | confere numeração, IDs e links da documentação (`docs/prompts/ORDEM-CANONICA-V4.md` é a fonte) |

## Desenvolvimento com o Claude Desktop (Claude Code)

Este repositório é conduzido por uma sequência de prompts (AIS-P0 … AIS-AP) executados pelo
Claude Code, na aba **Code** do app Claude Desktop, com esta pasta aberta.

- `CLAUDE.md` — regras permanentes (decisões canônicas, contratos, regras de execução). O Claude
  Code carrega este arquivo automaticamente; não é preciso colar nada.
- `docs/prompts/` — os prompts, a ordem canônica (`ORDEM-CANONICA-V4.md`) e o README do pacote.
- `docs/specs/` — SPECs de cada módulo; `docs/logs/` — um log por prompt executado.
- Comandos do projeto (em `.claude/skills/`):
  - `/ais AIS-06` — executa um prompt específico.
  - `/ais-proximo` — descobre o próximo prompt pendente pela ordem canônica e o executa.
  - `/ais-verificar` — roda o gate (`npm run check`) e a verificação no navegador, sem alterar código.

Recomendado: versionar com git (`git init` na primeira vez) para revisar cada prompt com `git diff`.

## Estrutura

```
src/            código do editor (src/logic/ = catálogo de lógica em pastas)
docs/prompts/   prompts AIS-* e ordem canônica
docs/specs/     SPECs por módulo
docs/logs/      logs de execução por prompt
.claude/        skills/comandos e permissões do Claude Code
CLAUDE.md       regras do projeto para o Claude
```
