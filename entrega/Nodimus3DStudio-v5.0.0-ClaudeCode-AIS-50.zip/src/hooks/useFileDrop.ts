import { useCallback } from 'react';
import { useEditor } from '../core/EditorContext';
import { useEditorStore } from '../core/editorStore';
import { applyTerrainChanges } from '../core/generators/terrainGenerator';
import { canChangeGeometry, heightmapChanges } from '../core/terrainOps';
import { globalResourceRegistry } from '../core/resources/global';
import { textureRefFromPath } from '../core/material/nodeMaterial';
import { buildVideoScreenSpec } from '../core/fileSystem/videoScreen';
import {
  FS_DRAG_MIME,
  materialDropOverride,
  nodeNameFromPath,
  resolveDropAction,
  spriteProjectRef,
  textureDropOverride,
  videoDropSettings,
} from '../core/fileSystem/dropActions';

/** O arrasto em andamento vem do FileSystemPanel (o `types` é legível no dragover; o valor só no drop). */
export const isFileSystemDrag = (e: { dataTransfer: DataTransfer | null }): boolean =>
  !!e.dataTransfer && Array.from(e.dataTransfer.types).includes(FS_DRAG_MIME);

/**
 * AIS-31 — executa o que soltar um arquivo do FileSystemPanel significa na cena. A decisão é de
 * `resolveDropAction` (que consome `resolveFileAction`); aqui só há efeitos, todos por Command ou modal existente.
 *
 * - `targetNodeId`: nó sob o cursor (viewport, por raycast) ou a linha da árvore; `null` = nenhum.
 * - `parentId`: pai dos nós criados (`undefined` = o padrão do `addNode`: nó selecionado ou raiz).
 */
export function useFileDrop() {
  const { project, activeScene, changeNodeProperty, addNode, addLog } = useEditor();
  const openAssetImportWithSource = useEditorStore((s) => s.openAssetImportWithSource);

  return useCallback(
    (path: string, targetNodeId: string | null, parentId?: string | null) => {
      const file = project.files[path];
      if (!file || file.isDirectory) {
        addLog('warn', `Arraste ignorado: '${path}' não existe mais no projeto.`);
        return;
      }
      const target = targetNodeId ? activeScene.nodes[targetNodeId] : undefined;
      const mesh = target && target.type === 'MeshInstance' ? target : undefined;
      const terrain = target && target.type === 'Terrain' ? target : undefined;
      const action = resolveDropAction({ path, extension: file.extension }, !!mesh, !!terrain);

      switch (action.kind) {
        case 'importModel':
          openAssetImportWithSource({ path, name: file.name });
          addLog('log', `'${file.name}' aberto no mini-editor de importação.`);
          break;
        case 'applyTexture': {
          if (!mesh) return;
          const ref = globalResourceRegistry.refForUri(path) ?? textureRefFromPath(path);
          changeNodeProperty(mesh.id, 'materialOverride', textureDropOverride(mesh.properties, ref));
          addLog('log', `Textura '${file.name}' aplicada em '${mesh.name}'.`);
          break;
        }
        case 'setHeightmap': {
          if (!terrain) return;
          const geometry = canChangeGeometry(terrain.properties);
          if (!geometry.ok) {
            addLog('warn', geometry.reason);
            return;
          }
          const ref = globalResourceRegistry.refForUri(path) ?? textureRefFromPath(path);
          applyTerrainChanges(terrain.id, heightmapChanges(ref), 'Definir Heightmap'); // UM Command (propriedades + marca de origem)
          addLog('log', `Heightmap '${file.name}' aplicado em '${terrain.name}'.`);
          break;
        }
        case 'applyMaterial': {
          if (!mesh) return;
          const result = materialDropOverride(file.content);
          if (!result.ok) {
            addLog('warn', `Material '${file.name}' não aplicado: ${result.error}.`);
            return;
          }
          changeNodeProperty(mesh.id, 'materialOverride', result.override);
          addLog('log', `Material '${file.name}' aplicado em '${mesh.name}'.`);
          break;
        }
        case 'createBillboard': {
          const ref = spriteProjectRef(path, globalResourceRegistry.refForUri(path));
          addNode('Billboard', parentId, nodeNameFromPath(path), { spriteProject: ref });
          break;
        }
        case 'createVideoScreen': {
          const result = videoDropSettings(file.content);
          if (!result.ok) {
            addLog('warn', `Vídeo '${file.name}' não instanciado: ${result.error}.`);
            return;
          }
          const spec = buildVideoScreenSpec(result.settings);
          addNode('MeshInstance', parentId, spec.name, spec.properties);
          break;
        }
        case 'reject':
          addLog('warn', `'${file.name}': ${action.reason}.`);
          break;
        default:
          break;
      }
    },
    [project.files, activeScene, changeNodeProperty, addNode, addLog, openAssetImportWithSource]
  );
}
