/**
 * @file useDesktopShortcuts.ts
 * @module hooks/useDesktopShortcuts
 *
 * AIS-04 — Sistema de Atalhos de Teclado Globais do Desktop
 * Conforme Decisão Canônica Item 2: Opção C (Editor Estritamente Desktop).
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * ATALHOS SUPORTADOS:
 *  • F5: Play Project (execução isolada).
 *  • F6: Play Current Scene.
 *  • F8: Stop Simulation.
 *  • F7: Alternar entre o workspace Script (editor de código) e a cena 3D (AIS-28b).
 *  • Ctrl+S / Cmd+S: Salvar cena atual.
 *  • Ctrl+Z / Cmd+Z: Desfazer comando.
 *  • Ctrl+Y / Cmd+Y ou Ctrl+Shift+Z: Refazer comando.
 *  • W: Ativar Gizmo de Translação (Translate mode).
 *  • E: Ativar Gizmo de Rotação (Rotate mode).
 *  • R: Ativar Gizmo de Escala (Scale mode).
 *  • F: Focar câmera no nó selecionado (Frame Selected).
 *  • Delete / Backspace: Excluir nó(s) selecionado(s).
 *  • Ctrl+D / Cmd+D: Duplicar nó selecionado na hierarquia.
 *  • Escape: Desmarcar seleção ou parar simulação.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * REGRAS DE EXECUÇÃO:
 *  1. Todo atalho interceptado DEVE chamar event.preventDefault() para evitar
 *     que o navegador recarregue (F5), abra "salvar página" (Ctrl+S) ou abra
 *     favoritos (Ctrl+D).
 *  2. Atalhos de uma tecla (W, E, R, F, Delete, Backspace) NÃO disparam quando
 *     o foco está em campos de texto (input, textarea, select, contenteditable,
 *     editor CodeMirror).
 *  3. F5/F6/F8 acionam a infraestrutura canônica de simulação sem criar
 *     runtimes ou estados concorrentes.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { useEffect, useCallback } from 'react';
import { useEditor } from '../core/EditorContext';
import { useEditorStore } from '../core/editorStore';

/**
 * Definition of a desktop keyboard shortcut for documentation and UI display.
 */
export interface DesktopShortcutDefinition {
  id: string;
  keyCombo: string;
  description: string;
  category: 'Simulation' | 'File' | 'History' | 'Viewport' | 'Hierarchy';
}

/** Canonical list of desktop shortcuts defined in AIS-04 and Item 2 Option C */
export const DESKTOP_SHORTCUTS: readonly DesktopShortcutDefinition[] = [
  { id: 'play_project', keyCombo: 'F5', description: 'Play Project (execução isolada)', category: 'Simulation' },
  { id: 'play_scene', keyCombo: 'F6', description: 'Play Current Scene', category: 'Simulation' },
  { id: 'stop_simulation', keyCombo: 'F8', description: 'Stop Simulation', category: 'Simulation' },
  { id: 'toggle_script_workspace', keyCombo: 'F7', description: 'Alternar workspace Script (editor de código) e cena 3D', category: 'Viewport' },
  { id: 'save_scene', keyCombo: 'Ctrl+S / Cmd+S', description: 'Salvar cena atual', category: 'File' },
  { id: 'undo', keyCombo: 'Ctrl+Z / Cmd+Z', description: 'Desfazer comando', category: 'History' },
  { id: 'redo', keyCombo: 'Ctrl+Y / Cmd+Shift+Z', description: 'Refazer comando', category: 'History' },
  { id: 'duplicate_node', keyCombo: 'Ctrl+D / Cmd+D', description: 'Duplicar nó selecionado', category: 'Hierarchy' },
  { id: 'delete_node', keyCombo: 'Delete / Backspace', description: 'Excluir nó selecionado', category: 'Hierarchy' },
  { id: 'gizmo_translate', keyCombo: 'W', description: 'Ativar Gizmo de Translação', category: 'Viewport' },
  { id: 'gizmo_rotate', keyCombo: 'E', description: 'Ativar Gizmo de Rotação', category: 'Viewport' },
  { id: 'gizmo_scale', keyCombo: 'R', description: 'Ativar Gizmo de Escala', category: 'Viewport' },
  { id: 'frame_selected', keyCombo: 'F', description: 'Focar câmera no nó selecionado (Frame Selected)', category: 'Viewport' },
  { id: 'escape', keyCombo: 'Escape', description: 'Desmarcar seleção ou parar simulação', category: 'Hierarchy' },
] as const;

/**
 * Flags de modais/diálogos de edição do `EditorStore`. Com qualquer um aberto, o teclado pertence
 * ao modal: atalhos que mutam a cena por trás dele (Undo/Redo, Delete, Duplicar, gizmo) não disparam.
 */
export const MODAL_OPEN_FLAGS = [
  'isProjectSettingsOpen',
  'isProjectManagerOpen',
  'isCreateNodeModalOpen',
  'isPostProcessingOpen',
  'isTerrainEditorOpen',
  'isTreeEditorOpen',
  'isFogModalOpen',
  'isSoundModalOpen',
  'isParticleModalOpen',
  'isAssetImportModalOpen',
  'isTexturePreviewOpen',
  'isVideoEditorOpen',
  'isSpriteEditorOpen',
  'isScriptEditorModalOpen',
] as const;

export function isAnyEditorModalOpen(state: Partial<Record<(typeof MODAL_OPEN_FLAGS)[number], boolean>>): boolean {
  return MODAL_OPEN_FLAGS.some((flag) => state[flag] === true);
}

/**
 * Helper to determine if an event was dispatched from an editable element
 * (input, textarea, select, contenteditable, or CodeMirror editor).
 */
export function isEditableElement(target: EventTarget | null): boolean {
  if (!target) return false;
  if (typeof HTMLElement !== 'undefined' && !(target instanceof HTMLElement)) return false;

  const candidate = target as {
    tagName?: string;
    isContentEditable?: boolean;
    closest?: (selector: string) => Element | null;
  };

  const tagName = candidate.tagName?.toUpperCase() || '';
  if (['INPUT', 'TEXTAREA', 'SELECT'].includes(tagName)) return true;
  if (Boolean(candidate.isContentEditable)) return true;
  if (typeof candidate.closest === 'function') {
    if (candidate.closest('.cm-content, .cm-editor, [contenteditable="true"]')) return true;
  }
  return false;
}

/**
 * Campo em que o usuário DIGITA texto (input de texto/número, textarea, contenteditable, CodeMirror).
 * `select`, checkbox, radio, range, cor e botões não digitam: Ctrl+Z/Ctrl+Y valem para a cena mesmo
 * com o foco neles (ex.: logo depois de escolher um preset num dropdown).
 */
export function isTextEntryElement(target: EventTarget | null): boolean {
  if (!isEditableElement(target)) return false;
  const candidate = target as { tagName?: string; type?: string };
  const tag = candidate.tagName?.toUpperCase() || '';
  if (tag === 'SELECT') return false;
  if (tag === 'INPUT' && ['checkbox', 'radio', 'range', 'color', 'button', 'submit', 'reset', 'file'].includes((candidate.type || '').toLowerCase())) {
    return false;
  }
  return true;
}

/**
 * Action callbacks interface passed to the pure shortcut dispatcher.
 */
export interface ShortcutActionHandlers {
  onPlayProject?: () => void;
  onPlayScene?: () => void;
  onStopSimulation?: () => void;
  onToggleScriptWorkspace?: () => void;
  onSaveScene?: () => void;
  onUndo?: () => void;
  onRedo?: () => void;
  onDuplicateSelected?: (nodeId: string) => void;
  onDeleteSelected?: (nodeId: string, multiIds?: string[]) => void;
  onTranslateGizmo?: () => void;
  onRotateGizmo?: () => void;
  onScaleGizmo?: () => void;
  onFrameSelected?: (nodeId: string) => void;
  onEscape?: () => void;
  selectedNodeId?: string | null;
  multiSelectedNodeIds?: string[];
  isPlaying?: boolean;
  /** Um modal de edição está aberto: atalhos que mutam a cena ficam desligados (Escape/Ctrl+S/F5–F8 seguem). */
  modalOpen?: boolean;
}

/**
 * Pure dispatcher that evaluates a keyboard event against desktop shortcut rules.
 * Returns the shortcut ID handled, or null if unhandled.
 * Useful for automated deterministic unit testing without a browser environment.
 */
export function dispatchDesktopShortcut(
  e: KeyboardEvent,
  handlers: ShortcutActionHandlers
): string | null {
  const isMac = typeof navigator !== 'undefined' && /Mac|iPod|iPhone|iPad/.test(navigator.platform);
  const modifier = isMac ? e.metaKey : e.ctrlKey;
  const isEditable = isEditableElement(e.target);

  // ── 1. Simulation controls (F5, F6, F8) — Always prevent default ───────────
  if (e.key === 'F5') {
    e.preventDefault();
    handlers.onPlayProject?.();
    return 'play_project';
  }

  if (e.key === 'F6') {
    e.preventDefault();
    handlers.onPlayScene?.();
    return 'play_scene';
  }

  if (e.key === 'F8') {
    e.preventDefault();
    handlers.onStopSimulation?.();
    return 'stop_simulation';
  }

  // AIS-28b: F7 alterna o workspace Script (vale também com o foco no editor de código)
  if (e.key === 'F7') {
    e.preventDefault();
    handlers.onToggleScriptWorkspace?.();
    return 'toggle_script_workspace';
  }

  // ── 2. Save Scene (Ctrl+S / Cmd+S) — Always prevent default ────────────────
  if (modifier && !e.shiftKey && !e.altKey && (e.key === 's' || e.key === 'S')) {
    e.preventDefault();
    handlers.onSaveScene?.();
    return 'save_scene';
  }

  // ── 3. Undo (Ctrl+Z / Cmd+Z) & Redo (Ctrl+Y / Cmd+Y / Ctrl+Shift+Z) ───────
  // Note: Inside text inputs, let native input/CodeMirror handle text undo/redo.
  // Foco num select/checkbox/range/cor (não digita texto): só Undo/Redo valem; o resto segue bloqueado.
  if (isEditable && !isTextEntryElement(e.target) && !handlers.modalOpen) {
    if (modifier && !e.shiftKey && !e.altKey && (e.key === 'z' || e.key === 'Z')) {
      e.preventDefault();
      handlers.onUndo?.();
      return 'undo';
    }
    if (
      (modifier && !e.shiftKey && !e.altKey && (e.key === 'y' || e.key === 'Y')) ||
      (modifier && e.shiftKey && !e.altKey && (e.key === 'z' || e.key === 'Z'))
    ) {
      e.preventDefault();
      handlers.onRedo?.();
      return 'redo';
    }
  }

  if (!isEditable && !handlers.modalOpen) {
    if (modifier && !e.shiftKey && !e.altKey && (e.key === 'z' || e.key === 'Z')) {
      e.preventDefault();
      handlers.onUndo?.();
      return 'undo';
    }

    const isRedoKey =
      (modifier && !e.shiftKey && !e.altKey && (e.key === 'y' || e.key === 'Y')) ||
      (modifier && e.shiftKey && !e.altKey && (e.key === 'z' || e.key === 'Z'));

    if (isRedoKey) {
      e.preventDefault();
      handlers.onRedo?.();
      return 'redo';
    }

    // ── 4. Duplicate (Ctrl+D / Cmd+D) ────────────────────────────────────────
    if (modifier && !e.shiftKey && !e.altKey && (e.key === 'd' || e.key === 'D')) {
      e.preventDefault();
      if (handlers.selectedNodeId) {
        handlers.onDuplicateSelected?.(handlers.selectedNodeId);
        return 'duplicate_node';
      }
      return null;
    }

    // ── 5. Delete (Delete / Backspace) ───────────────────────────────────────
    // AIS-40b: em Play o runtime nunca escreve no authoring e as teclas são do JOGO (GameInput)
    if ((e.key === 'Delete' || e.key === 'Backspace') && !handlers.isPlaying) {
      e.preventDefault();
      if (handlers.selectedNodeId) {
        handlers.onDeleteSelected?.(handlers.selectedNodeId, handlers.multiSelectedNodeIds);
        return 'delete_node';
      }
      return null;
    }

    // ── 6. Single-key Viewport shortcuts (W, E, R, F) ────────────────────────
    // Must NOT be accompanied by Ctrl, Alt, or Meta modifiers
    // AIS-40b: em Play W/E/R/F pertencem ao jogo (W = MoveForward); nunca viram atalho do editor
    if (!handlers.isPlaying && !e.ctrlKey && !e.metaKey && !e.altKey) {
      const lower = e.key.toLowerCase();
      if (lower === 'w') {
        e.preventDefault();
        handlers.onTranslateGizmo?.();
        return 'gizmo_translate';
      }
      if (lower === 'e') {
        e.preventDefault();
        handlers.onRotateGizmo?.();
        return 'gizmo_rotate';
      }
      if (lower === 'r') {
        e.preventDefault();
        handlers.onScaleGizmo?.();
        return 'gizmo_scale';
      }
      if (lower === 'f') {
        e.preventDefault();
        if (handlers.selectedNodeId) {
          handlers.onFrameSelected?.(handlers.selectedNodeId);
          return 'frame_selected';
        }
        return null;
      }
    }
  }

  // ── 7. Escape (Cancel / Deselect / Stop) ────────────────────────────────────
  if (e.key === 'Escape') {
    if (isEditable && e.target instanceof HTMLElement) {
      e.target.blur();
    }
    e.preventDefault();
    handlers.onEscape?.();
    return 'escape';
  }

  return null;
}

/**
 * Options for configuring `useDesktopShortcuts`.
 */
export interface UseDesktopShortcutsOptions {
  enabled?: boolean;
}

/**
 * React hook that registers global desktop shortcuts on `window`.
 * Automatically connects to EditorContext, AuthoringModel, and EditorStore.
 */
export function useDesktopShortcuts(options: UseDesktopShortcutsOptions = {}): void {
  const { enabled = true } = options;

  const {
    saveCurrentScene,
    playProject,
    playScene,
    stopGame,
    undo,
    redo,
    deleteNode,
    deleteMultipleNodes,
    duplicateNode,
    selectNode,
    addLog,
  } = useEditor();

  const selectedNodeId = useEditorStore((s) => s.selectedNodeId);
  const multiSelectedNodeIds = useEditorStore((s) => s.multiSelectedNodeIds);
  const isPlaying = useEditorStore((s) => s.isPlaying);
  const modalOpen = useEditorStore((s) => isAnyEditorModalOpen(s));
  const setManipulationMode = useEditorStore((s) => s.setManipulationMode);
  const setWorkspaceMode = useEditorStore((s) => s.setWorkspaceMode);

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (!enabled) return;

      dispatchDesktopShortcut(e, {
        selectedNodeId,
        multiSelectedNodeIds,
        isPlaying,
        modalOpen,

        onPlayProject: () => {
          playProject();
          addLog('log', '[Shortcut F5] Play Project started');
        },

        onPlayScene: () => {
          playScene();
          addLog('log', '[Shortcut F6] Play Scene started');
        },

        onStopSimulation: () => {
          stopGame();
          addLog('log', '[Shortcut F8] Simulation stopped');
        },

        onToggleScriptWorkspace: () => {
          const current = useEditorStore.getState().workspaceMode;
          setWorkspaceMode(current === 'Script' ? '3D' : 'Script');
        },

        onSaveScene: () => {
          saveCurrentScene();
          addLog('log', '[Shortcut Ctrl+S] Scene saved');
        },

        onUndo: () => {
          undo();
        },

        onRedo: () => {
          redo();
        },

        onDuplicateSelected: (id) => {
          duplicateNode(id);
          addLog('log', `[Shortcut Ctrl+D] Duplicated node`);
        },

        onDeleteSelected: (id, multiIds) => {
          // AIS-17: seleção completa = nó primário + adicionais (antes só os adicionais eram excluídos)
          const all = [...new Set([id, ...(multiIds ?? [])])];
          if (all.length > 1) {
            deleteMultipleNodes(all);
          } else {
            deleteNode(id);
          }
        },

        onTranslateGizmo: () => {
          setManipulationMode('translate');
          addLog('log', '[Shortcut W] Gizmo mode: Translate');
        },

        onRotateGizmo: () => {
          setManipulationMode('rotate');
          addLog('log', '[Shortcut E] Gizmo mode: Rotate');
        },

        onScaleGizmo: () => {
          setManipulationMode('scale');
          addLog('log', '[Shortcut R] Gizmo mode: Scale');
        },

        onFrameSelected: (id) => {
          window.dispatchEvent(
            new CustomEvent('nodimus:frame-selected', {
              detail: { nodeId: id, nodeIds: [...new Set([id, ...multiSelectedNodeIds])] },
            })
          );
          addLog('log', `[Shortcut F] Frame selected on node: ${id}`);
        },

        onEscape: () => {
          if (isPlaying) {
            stopGame();
          } else {
            selectNode(null);
          }
        },
      });
    },
    [
      enabled,
      selectedNodeId,
      multiSelectedNodeIds,
      isPlaying,
      playProject,
      playScene,
      stopGame,
      saveCurrentScene,
      undo,
      redo,
      deleteNode,
      deleteMultipleNodes,
      duplicateNode,
      selectNode,
      setManipulationMode,
      setWorkspaceMode,
      addLog,
    ]
  );

  useEffect(() => {
    if (!enabled) return;
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [enabled, handleKeyDown]);
}
