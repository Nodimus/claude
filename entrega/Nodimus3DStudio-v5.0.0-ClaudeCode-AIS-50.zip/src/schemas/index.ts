export * from './diagnostics';
export * from './v1/node.schema';
export * from './v1/visualLogic.schema';
export * from './v1/scene.schema';
export * from './v1/prefab.schema';
export * from './v1/project.schema';
export * from './projectSchema';
export * from './sceneSchema';

import { validateWithDiagnostics, ValidationResult } from './diagnostics';
import { ProjectV1Schema, ProjectV1 } from './v1/project.schema';
import { SceneV1Schema, SceneV1 } from './v1/scene.schema';
import { GameNodeV1Schema, GameNodeV1 } from './v1/node.schema';
import { BehaviorV1Schema, BehaviorV1, LogicActionV1Schema, LogicActionV1 } from './v1/visualLogic.schema';
import { PrefabV1Schema, PrefabV1 } from './v1/prefab.schema';
import { ProjectFileSchema, ProjectFileValidated } from './projectSchema';
import { SceneFileSchema, SceneFileValidated } from './sceneSchema';
import { applyMigrations } from '../migrations';
import { normalizeUnknownNodes } from './missingNodes';

export * from './missingNodes';

/**
 * Validates a Project data object at external/storage boundary.
 * Applies any version migrations before schema validation.
 */
export function validateProject(data: unknown): ValidationResult<ProjectV1> {
  const { data: migrated } = applyMigrations('project', data);
  return validateWithDiagnostics(ProjectV1Schema, migrated, 'Project');
}

/**
 * Validates a Scene data object at load/import boundary.
 * Applies any version migrations before schema validation.
 */
export function validateScene(data: unknown): ValidationResult<SceneV1> {
  // `SceneV1Schema` descreve o documento no formato v1 (SceneData direto): não aplica a migração v1→v2 (AIS-29b),
  // que muda o formato. A leitura de arquivos usa `parseSceneJson` (sceneSerializer), que migra e valida por nó.
  const { data: migrated } = applyMigrations('scene', data, 1);
  return validateWithDiagnostics(SceneV1Schema, normalizeUnknownNodes(migrated), 'Scene');
}

/**
 * Validates a GameNode object.
 */
export function validateNode(data: unknown): ValidationResult<GameNodeV1> {
  const { data: migrated } = applyMigrations('node', data);
  return validateWithDiagnostics(GameNodeV1Schema, migrated, 'GameNode');
}

/**
 * Validates a Behavior object.
 */
export function validateBehavior(data: unknown): ValidationResult<BehaviorV1> {
  const { data: migrated } = applyMigrations('behavior', data);
  return validateWithDiagnostics(BehaviorV1Schema, migrated, 'Behavior');
}

/**
 * Validates a Visual Logic Action object.
 */
export function validateAction(data: unknown): ValidationResult<LogicActionV1> {
  return validateWithDiagnostics(LogicActionV1Schema, data, 'LogicAction');
}

/**
 * Validates a Prefab object at load/import boundary.
 */
export function validatePrefab(data: unknown): ValidationResult<PrefabV1> {
  const { data: migrated } = applyMigrations('prefab', data);
  return validateWithDiagnostics(PrefabV1Schema, normalizeUnknownNodes(migrated), 'Prefab');
}

// Direct parse helpers (throw with formatted diagnostic if invalid)
export function parseProject(data: unknown): ProjectV1 {
  const res = validateProject(data);
  if (!res.success) {
    throw new Error(res.formattedError);
  }
  return res.data!;
}

export function parseScene(data: unknown): SceneV1 {
  const res = validateScene(data);
  if (!res.success) {
    throw new Error(res.formattedError);
  }
  return res.data!;
}

export function parseNode(data: unknown): GameNodeV1 {
  const res = validateNode(data);
  if (!res.success) {
    throw new Error(res.formattedError);
  }
  return res.data!;
}

export function parseBehavior(data: unknown): BehaviorV1 {
  const res = validateBehavior(data);
  if (!res.success) {
    throw new Error(res.formattedError);
  }
  return res.data!;
}

export function parseAction(data: unknown): LogicActionV1 {
  const res = validateAction(data);
  if (!res.success) {
    throw new Error(res.formattedError);
  }
  return res.data!;
}

export function parsePrefab(data: unknown): PrefabV1 {
  const res = validatePrefab(data);
  if (!res.success) {
    throw new Error(res.formattedError);
  }
  return res.data!;
}

/**
 * Validates a project.json document against the canonical ProjectFile schema.
 */
export function validateProjectFile(data: unknown): ValidationResult<ProjectFileValidated> {
  const { data: migrated } = applyMigrations('project', data);
  return validateWithDiagnostics(ProjectFileSchema, migrated, 'ProjectFile');
}

/**
 * Validates a *.scene.json document against the canonical SceneFile schema.
 */
export function validateSceneFile(data: unknown): ValidationResult<SceneFileValidated> {
  const { data: migrated } = applyMigrations('scene', data);
  return validateWithDiagnostics(SceneFileSchema, normalizeUnknownNodes(migrated), 'SceneFile');
}

export function parseProjectFile(data: unknown): ProjectFileValidated {
  const res = validateProjectFile(data);
  if (!res.success) {
    throw new Error(res.formattedError);
  }
  return res.data!;
}

export function parseSceneFile(data: unknown): SceneFileValidated {
  const res = validateSceneFile(data);
  if (!res.success) {
    throw new Error(res.formattedError);
  }
  return res.data!;
}
