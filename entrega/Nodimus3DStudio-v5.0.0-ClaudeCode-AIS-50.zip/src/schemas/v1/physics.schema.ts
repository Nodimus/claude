import { z } from 'zod';
import { Vector3V1Schema } from './node.schema';

/**
 * AIS-26b (decisão 26): bloco `GameNode.properties.physics`. Aditivo — sem nova `schemaVersion`; aplicado na leitura
 * da seção e no resolvedor (`GameNodeV1Schema.properties` continua um `record` aberto).
 */
const bits8 = z.number().int().min(0).max(255);

export const PhysicsConfigSchema = z.object({
  enabled: z.boolean(),
  bodyMode: z.enum(['static', 'dynamic', 'kinematic', 'character', 'trigger']),
  shape: z.enum(['auto', 'box', 'sphere', 'capsule', 'cylinder', 'mesh']),
  size: Vector3V1Schema.optional(),
  offset: Vector3V1Schema.optional(),
  friction: z.number().min(0).max(1).optional(),
  bounce: z.number().min(0).max(1).optional(),
  mass: z.number().positive().optional(),
  layer: bits8.optional(),
  mask: bits8.optional(),
  constrainToPlane: z.enum(['none', 'xy', 'xz', 'yz']).optional(),
  forwardAxis: z.enum(['x', 'z']).optional(),
  floats: z.boolean().optional(),
}).superRefine((c, ctx) => {
  if (c.shape === 'mesh' && c.bodyMode !== 'static') {
    ctx.addIssue({ code: 'custom', path: ['shape'], message: 'Malha exata só é válida em "Sólido parado".' });
  }
});

export type PhysicsConfigV1 = z.infer<typeof PhysicsConfigSchema>;
