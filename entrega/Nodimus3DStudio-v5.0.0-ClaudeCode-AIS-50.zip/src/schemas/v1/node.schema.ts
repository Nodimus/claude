import { z } from 'zod';
import { NODE_DEFINITIONS } from '../../nodes/registry';
import type { NodeType } from '../../types/node';

/** Derivado do registry (fonte única, decisão 19): nunca listar tipos aqui. */
const NODE_TYPE_KEYS = Object.keys(NODE_DEFINITIONS) as [NodeType, ...NodeType[]];
export const NodeTypeV1Schema = z.enum(NODE_TYPE_KEYS);

export const Vector2V1Schema = z.object({
  x: z.number(),
  y: z.number(),
});

export const Vector3V1Schema = z.object({
  x: z.number(),
  y: z.number(),
  z: z.number(),
});

const Vector3TupleV1Schema = z.tuple([z.number(), z.number(), z.number()]);
const QuaternionV1Schema = z.object({ x: z.number(), y: z.number(), z: z.number(), w: z.number() });
const QuaternionTupleV1Schema = z.tuple([z.number(), z.number(), z.number(), z.number()]);

/** Espelha `Transform3D` (`src/types/node.ts`): objeto ou tupla; rotação também em quaternion. */
export const Transform3DV1Schema = z.object({
  position: z.union([Vector3V1Schema, Vector3TupleV1Schema]),
  rotation: z.union([QuaternionV1Schema, Vector3V1Schema, QuaternionTupleV1Schema, Vector3TupleV1Schema]),
  scale: z.union([Vector3V1Schema, Vector3TupleV1Schema]),
});

export const ColorV1Schema = z.object({
  r: z.number(),
  g: z.number(),
  b: z.number(),
  a: z.number().default(1),
});

export const SignalArgumentV1Schema = z.object({
  type: z.enum(['string', 'number', 'boolean', 'node']),
  value: z.union([z.string(), z.number(), z.boolean(), z.null()]),
});

export const SignalConnectionV1Schema = z.object({
  id: z.string().min(1),
  signalName: z.string().min(1),
  targetNodeId: z.string().min(1),
  targetMethod: z.string().min(1),
  arguments: z.array(SignalArgumentV1Schema).optional(),
});

export const GameNodeV1Schema = z.object({
  schemaVersion: z.literal(1).optional().default(1),
  id: z.string().min(1, 'Node ID is required'),
  name: z.string().min(1, 'Node name is required'),
  type: NodeTypeV1Schema,
  parentId: z.string().nullable(),
  childrenIds: z.array(z.string()).default([]),
  visible: z.boolean().default(true),
  locked: z.boolean().default(false),
  collapsed: z.boolean().optional(),
  transform: Transform3DV1Schema.optional(),
  properties: z.record(z.string(), z.any()).default({}),
  script: z.string().optional(),
  // AIS-41b: instâncias inline (formato de arquivo com `contributionId`); a conversão e a preservação de campos desconhecidos são de `core/serialization/behaviorFile.ts`
  behaviors: z.array(z.unknown()).optional(),
  signals: z.array(SignalConnectionV1Schema).optional(),
  // AIS-49b: `GeneratorSource` ({ generatorId, version, params, seed? }); lido com `parseGeneratorSource` — dado malformado ou de gerador desconhecido é preservado como veio
  generatorSource: z.unknown().optional(),
  tags: z.array(z.string()).optional(),
  variables: z.record(z.string(), z.any()).optional(),
  // AIS-29: campos extras do nó (visualLogic, dados de versões futuras) são preservados, nunca descartados
  visualLogic: z.any().optional(),
}).passthrough();

export type GameNodeV1 = z.infer<typeof GameNodeV1Schema>;
export type NodeTypeV1 = z.infer<typeof NodeTypeV1Schema>;
