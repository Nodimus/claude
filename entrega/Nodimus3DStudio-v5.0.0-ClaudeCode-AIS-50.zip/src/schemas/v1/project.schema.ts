import { z } from 'zod';

export const RendererTypeV1Schema = z.enum([
  'Three.js (WebGL)',
  'Three.js (WebGL 2.0)',
]);

export const InputActionBindingV1Schema = z.object({
  type: z.enum(['key', 'mouse', 'gamepad']),
  code: z.string().min(1),
});

export const InputActionV1Schema = z.object({
  name: z.string().min(1),
  bindings: z.array(InputActionBindingV1Schema).default([]),
});

const NUM = { error: 'Informe um número válido.' };

/** Aceita o campo legado `display.fullscreen` na leitura: `fullscreen: true` sem `windowMode` vira `'fullscreen'` (AIS-32b). */
const legacyFullscreen = (raw: unknown): unknown => {
  if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
    const d = raw as Record<string, unknown>;
    if (d.windowMode === undefined && d.fullscreen === true) return { ...d, windowMode: 'fullscreen' };
  }
  return raw;
};

export const WindowModeV1Schema = z.enum(['windowed', 'fullscreen', 'borderless']);
export const ShadowQualityV1Schema = z.enum(['low', 'medium', 'high']);

/**
 * Settings do projeto. Campos novos (AIS-32b: `description`, `windowMode`, `shadowQuality`, `hdr`) são aditivos com
 * `.default()`: sem bump de `schemaVersion`; projetos antigos continuam válidos. Os padrões do modal vêm daqui.
 */
export const ProjectSettingsV1Schema = z.object({
  general: z.object({
    projectName: z.string().trim().min(1, 'O nome não pode ficar vazio.').max(120, 'O nome pode ter no máximo 120 caracteres.').default('Nodimus Project'),
    version: z.string().regex(/^\d+\.\d+\.\d+$/, 'Use o formato x.y.z (ex.: 1.0.0).').default('1.0.0'),
    description: z.string().default(''),
    mainScene: z.string().default('res://scenes/Main.scene.json'),
    author: z.string().default('Developer'),
  }),
  display: z.preprocess(
    legacyFullscreen,
    z.object({
      width: z.number(NUM).int('Use um número inteiro.').min(1, 'Mínimo 1.').max(16384, 'Máximo 16384.').default(1280),
      height: z.number(NUM).int('Use um número inteiro.').min(1, 'Mínimo 1.').max(16384, 'Máximo 16384.').default(720),
      resizable: z.boolean().default(true),
      /** Legado: espelha `windowMode === 'fullscreen'` ao salvar (nenhum consumidor de runtime hoje). */
      fullscreen: z.boolean().default(false),
      windowMode: WindowModeV1Schema.default('windowed'),
      orientation: z.enum(['landscape', 'portrait', 'auto']).default('landscape'),
    })
  ),
  rendering: z.object({
    renderer: RendererTypeV1Schema.default('Three.js (WebGL)'),
    clearColor: z.string().regex(/^#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})$/, 'Use uma cor hexadecimal (ex.: #141822).').default('#141822'),
    vsync: z.boolean().default(true),
    msaa: z.enum(['disabled', '2x', '4x', '8x']).default('2x'),
    shadowsEnabled: z.boolean().default(true),
    shadowQuality: ShadowQualityV1Schema.default('medium'),
    hdr: z.boolean().default(false),
  }),
  physics: z.object({
    /** Padrão de `Scene.gravity` para cenas NOVAS (a gravidade efetiva é da Scene, decisão 17). */
    gravity3D: z.object({
      x: z.number(NUM).default(0),
      y: z.number(NUM).default(-9.8),
      z: z.number(NUM).default(0),
    }),
    defaultLinearDamp: z.number(NUM).min(0, 'O amortecimento não pode ser negativo.').default(0.1),
  }),
  input: z.object({
    actions: z.array(InputActionV1Schema).default([]),
  }),
  audio: z.object({
    masterVolume: z.number(NUM).min(0, 'Use um valor de 0 a 1.').max(1, 'Use um valor de 0 a 1.').default(1),
    musicVolume: z.number(NUM).min(0, 'Use um valor de 0 a 1.').max(1, 'Use um valor de 0 a 1.').default(0.8),
    sfxVolume: z.number(NUM).min(0, 'Use um valor de 0 a 1.').max(1, 'Use um valor de 0 a 1.').default(0.9),
  }),
});

export const VirtualFileV1Schema = z.object({
  path: z.string().min(1, 'VirtualFile path is required'),
  name: z.string().min(1, 'VirtualFile name is required'),
  isDirectory: z.boolean().default(false),
  extension: z.string().optional(),
  content: z.string().optional(),
  size: z.number().optional(),
  updatedAt: z.string().optional().default(() => new Date().toISOString()),
  // AIS-28c: identidade e configuração de importação do recurso (preservadas ao validar)
  resourceId: z.string().optional(),
  importerId: z.string().optional(),
  importerVersion: z.number().optional(),
  importSettings: z.record(z.string(), z.unknown()).optional(),
  contentHash: z.string().optional(),
});

export const ProjectV1Schema = z.object({
  schemaVersion: z.literal(1).optional().default(1),
  id: z.string().min(1, 'Project ID is required'),
  name: z.string().min(1, 'Project name is required'),
  location: z.string().default('~/Projects/Nodimus'),
  renderer: RendererTypeV1Schema.default('Three.js (WebGL)'),
  lastOpenedScene: z.string().default('res://scenes/Main.scene.json'),
  createdAt: z.string().optional().default(() => new Date().toISOString()),
  updatedAt: z.string().optional().default(() => new Date().toISOString()),
  settings: ProjectSettingsV1Schema,
  files: z.record(z.string(), VirtualFileV1Schema).default({}),
  globalVariables: z.array(z.any()).optional(),
});

export type ProjectV1 = z.infer<typeof ProjectV1Schema>;
export type ProjectSettingsV1 = z.infer<typeof ProjectSettingsV1Schema>;
export type VirtualFileV1 = z.infer<typeof VirtualFileV1Schema>;
