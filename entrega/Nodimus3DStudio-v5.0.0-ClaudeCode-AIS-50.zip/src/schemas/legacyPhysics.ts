/**
 * AIS-26b (decisão 26) — migração dos nós de física legados (`StaticBody`, `RigidBody`, `KinematicBody`, `Area`,
 * `CollisionShape`), que deixaram de existir no registry. Roda ao abrir cena/prefab, ANTES de o tipo ser tratado como
 * desconhecido (`normalizeUnknownNodes`, AIS-18d). Opera sobre JSON cru: nenhum desses tipos existe mais em TypeScript.
 *
 * Converte só o caso simples — corpo + UM `CollisionShape` filho sem rotação/escala — e `Area` (gatilho). O corpo vira
 * `Spatial` com `properties.physics`; o `CollisionShape` convertido é removido. O resto fica intacto e cai em
 * Missing Node (preservado e regravado sem perda), com diagnóstico `physics.legacy_unconverted`.
 */

type AnyRecord = Record<string, any>;
const isRecord = (v: unknown): v is AnyRecord => typeof v === 'object' && v !== null && !Array.isArray(v);

export const LEGACY_PHYSICS_TYPES = ['StaticBody', 'RigidBody', 'KinematicBody', 'Area', 'CollisionShape'] as const;
const BODY_TYPES = ['StaticBody', 'RigidBody', 'KinematicBody', 'Area'];
const isLegacy = (type: unknown): boolean => typeof type === 'string' && (LEGACY_PHYSICS_TYPES as readonly string[]).includes(type);

export interface LegacyPhysicsReport {
  converted: number;
  /** IDs de nós legados que não puderam ser convertidos (viram Missing Node). */
  unconverted: string[];
}

const num = (v: unknown, fallback: number) => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);
const vec = (v: any, fallback = { x: 0, y: 0, z: 0 }) => ({ x: num(v?.x, fallback.x), y: num(v?.y, fallback.y), z: num(v?.z, fallback.z) });
const isZero = (v: any) => !v || (num(v.x, 0) === 0 && num(v.y, 0) === 0 && num(v.z, 0) === 0);
const isUnit = (v: any) => !v || (num(v.x, 1) === 1 && num(v.y, 1) === 1 && num(v.z, 1) === 1);

/** Forma de um `CollisionShape` legado → `shape` + `size` TOTAL (extents × 2; Capsule: altura = trecho + 2×raio). */
function shapeToPhysics(props: AnyRecord): { shape: string; size: AnyRecord } {
  const radius = Math.max(0.001, num(props.radius, 0.5));
  const height = Math.max(0, num(props.height, 1.5));
  switch (props.shapeType) {
    case 'SphereShape':
      return { shape: 'sphere', size: { x: radius * 2, y: radius * 2, z: radius * 2 } };
    case 'CapsuleShape':
      return { shape: 'capsule', size: { x: radius * 2, y: height + radius * 2, z: radius * 2 } };
    case 'CylinderShape':
      return { shape: 'cylinder', size: { x: radius * 2, y: height, z: radius * 2 } };
    default: {
      const e = vec(props.extents, { x: 1, y: 1, z: 1 });
      return { shape: 'box', size: { x: e.x * 2, y: e.y * 2, z: e.z * 2 } };
    }
  }
}

function physicsFromBody(body: AnyRecord, shapeNode: AnyRecord | null): AnyRecord {
  const p = isRecord(body.properties) ? body.properties : {};
  const bodyMode =
    body.type === 'Area' ? 'trigger'
    : body.type === 'StaticBody' ? 'static'
    : body.type === 'KinematicBody' ? 'kinematic'
    : ['dynamic', 'static', 'kinematic', 'character'].includes(p.bodyMode) ? p.bodyMode : 'dynamic';
  const physics: AnyRecord = { enabled: true, bodyMode };
  if (shapeNode) {
    const shape = shapeToPhysics(isRecord(shapeNode.properties) ? shapeNode.properties : {});
    physics.shape = shape.shape;
    physics.size = shape.size;
    const offset = vec(shapeNode.properties?.position);
    if (!isZero(offset)) physics.offset = offset;
  } else {
    // Area sem CollisionShape: o antigo "Trigger Radius" vira uma esfera
    const r = Math.max(0.001, num(p.radius, 2));
    physics.shape = 'sphere';
    physics.size = { x: r * 2, y: r * 2, z: r * 2 };
  }
  if (bodyMode === 'character') physics.shape = 'capsule';
  if (typeof p.friction === 'number') physics.friction = Math.min(1, Math.max(0, p.friction));
  if (typeof p.restitution === 'number') physics.bounce = Math.min(1, Math.max(0, p.restitution));
  if (typeof p.mass === 'number' && p.mass > 0 && bodyMode !== 'static') physics.mass = p.mass;
  if (Number.isInteger(p.collisionLayer)) physics.layer = Math.min(255, Math.max(0, p.collisionLayer));
  if (Number.isInteger(p.collisionMask)) physics.mask = Math.min(255, Math.max(0, p.collisionMask));
  return physics;
}

/** Propriedades herdadas do corpo legado que continuam valendo no `Spatial` (a pose). */
function spatialProperties(body: AnyRecord, physics: AnyRecord): AnyRecord {
  const p = isRecord(body.properties) ? body.properties : {};
  const out: AnyRecord = {};
  for (const key of ['position', 'rotation', 'scale']) if (p[key] !== undefined) out[key] = p[key];
  out.physics = physics;
  return out;
}

/** `nodes` = mapa id → nó cru (cena ou prefab). Devolve a mesma referência se nada mudou. */
export function convertLegacyPhysicsNodes(nodes: Record<string, any>): { nodes: Record<string, any>; report: LegacyPhysicsReport } {
  const report: LegacyPhysicsReport = { converted: 0, unconverted: [] };
  if (!isRecord(nodes) || !Object.values(nodes).some((n) => isRecord(n) && isLegacy(n.type))) return { nodes, report };

  const out: AnyRecord = { ...nodes };

  for (const [id, body] of Object.entries(nodes)) {
    if (!isRecord(body) || !BODY_TYPES.includes(body.type)) continue;
    const childIds: string[] = Array.isArray(body.childrenIds) ? body.childrenIds : [];
    const shapeIds = childIds.filter((cid) => isRecord(nodes[cid]) && nodes[cid].type === 'CollisionShape');
    const shapeNode = shapeIds.length === 1 ? nodes[shapeIds[0]] : null;
    const simple =
      shapeIds.length === 0
        ? body.type === 'Area'
        : shapeIds.length === 1 &&
          isZero(shapeNode?.properties?.rotation) &&
          isUnit(shapeNode?.properties?.scale) &&
          !(Array.isArray(shapeNode?.childrenIds) && shapeNode.childrenIds.length > 0);
    if (!simple) continue;

    const physics = physicsFromBody(body, shapeNode);
    out[id] = {
      ...body,
      type: 'Spatial',
      properties: spatialProperties(body, physics),
      childrenIds: childIds.filter((cid) => cid !== shapeIds[0]),
    };
    if (shapeNode) delete out[shapeIds[0]];
    report.converted++;
  }

  for (const [id, node] of Object.entries(out)) {
    if (isRecord(node) && isLegacy(node.type)) report.unconverted.push(id);
  }
  return { nodes: out, report };
}

/** Cena/prefab inteiro (`{ nodes }`): passo de migração ao abrir, anterior ao Missing Node. */
export function convertLegacyPhysics<T>(data: T): T {
  if (!isRecord(data) || !isRecord((data as AnyRecord).nodes)) return data;
  const { nodes } = convertLegacyPhysicsNodes((data as AnyRecord).nodes);
  return nodes === (data as AnyRecord).nodes ? data : ({ ...(data as AnyRecord), nodes } as T);
}

/** Mensagem única por cena (código `physics.legacy_unconverted`, AIS-32c); `null` se não sobrou legado. */
export function legacyPhysicsWarning(nodes: Record<string, { type: string; properties?: Record<string, any> }> | undefined): string | null {
  // antes de ler a cena o nó ainda tem o tipo legado; DEPOIS de lida ele é um Missing Node (`properties.__missing.originalType`)
  const left = Object.values(nodes ?? {}).filter((n) => isLegacy(n?.type) || (n?.type === 'Missing' && isLegacy(n.properties?.__missing?.originalType))).length;
  return left
    ? `physics.legacy_unconverted: ${left} nó(s) de física legado(s) sem conversão simples; preservado(s) como Missing Node, sem efeito no Play`
    : null;
}
