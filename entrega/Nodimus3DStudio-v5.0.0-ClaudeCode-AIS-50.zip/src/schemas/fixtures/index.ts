// Módulos usados pelos verificadores (antes via require(); ESM puro para Vitest — v5.0.0)
import * as __editorStoreModule from '../../core/editorStore';
import * as __commandManagerModule from '../../core/commandManager';
import * as __desktopShortcutsModule from '../../hooks/useDesktopShortcuts';
import * as __defaultProjectModule from '../../core/defaultProject';
import * as __projectStorageModule from '../../core/projectStorage';
import * as __schemasIndexModule from '../index';
import * as __persistenceVersionsModule from '../../core/persistenceVersions';
import {
  validateProject,
  validateScene,
  validateNode,
  validateBehavior,
  validateAction,
  validatePrefab,
  validateProjectFile,
  validateSceneFile,
  PersistedBehaviorInstanceSchema,
  ResourceRefSchema,
  ProjectV1,
  SceneV1,
  GameNodeV1,
  BehaviorV1,
  LogicActionV1,
  PrefabV1,
} from '../index';
import { AuthoringModel, createRuntimeSnapshot, materializeRuntimeScene } from '../../core/authoring';
import { ProjectStorage } from '../../core/projectStorage';
// AIS-03d: pure-function selectors from EditorStore (no React/Zustand runtime needed)
import {
  EditorStoreState,
  selectSelectedNodeId,
  selectMultiSelectedNodeIds,
  selectHasSelection,
  selectAllSelectedNodeIds,
  selectActiveSceneName,
  selectActiveScenePath,
  selectWorkspaceMode,
  selectManipulationMode,
  selectIsPlaying,
  selectNoDialogOpen,
} from '../../core/editorStore';
// AIS-03e: State Mutation Policy programmatic checklist
export { verifyStateMutationPolicy } from '../../core/stateMutationPolicy';


export const VALID_NODE_FIXTURE: GameNodeV1 = {
  schemaVersion: 1,
  id: 'node_test_01',
  name: 'TestMeshNode',
  type: 'MeshInstance',
  parentId: null,
  childrenIds: [],
  visible: true,
  locked: false,
  properties: {
    position: { x: 0, y: 1, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    scale: { x: 1, y: 1, z: 1 },
  },
};

export const INVALID_NODE_FIXTURE = {
  schemaVersion: 1,
  id: '', // Empty ID should fail
  name: '', // Empty name should fail
  type: 'MeshInstance', // tipo desconhecido não é mais inválido: carrega como Missing (AIS-18d)
  parentId: null,
  childrenIds: 'not_an_array', // Invalid type should fail
};

export const VALID_ACTION_FIXTURE: LogicActionV1 = {
  id: 'action_01',
  type: 'move_by',
  parameters: { x: 0, y: 2, z: 0, duration: 1.0 },
};

export const INVALID_ACTION_FIXTURE = {
  id: '', // Empty ID
  type: 'unsupported_action_type', // Invalid action type
};

export const VALID_BEHAVIOR_FIXTURE: BehaviorV1 = {
  schemaVersion: 1,
  id: 'beh_01',
  name: 'WasdMovement',
  targetNodeId: 'node_test_01',
  behaviorType: 'simple_wasd_movement',
  enabled: true,
  properties: { speed: 5.0 },
  rules: [
    {
      id: 'rule_01',
      eventType: 'on_update',
      parameters: {},
      conditions: [],
      actions: [VALID_ACTION_FIXTURE],
    },
  ],
};

export const INVALID_BEHAVIOR_FIXTURE = {
  schemaVersion: 1,
  id: '',
  name: '',
  behaviorType: 'invalid_behavior_type',
};

export const VALID_SCENE_FIXTURE: SceneV1 = {
  schemaVersion: 1,
  id: 'scene_test_01',
  name: 'TestScene',
  path: 'res://scenes/TestScene.scene.json',
  rootNodeId: 'node_test_01',
  nodes: {
    node_test_01: VALID_NODE_FIXTURE,
  },
  postProcessing: {
    bloom: { enabled: false, blurIterations: 3, threshold: 0.8 },
    blackAndWhite: { enabled: false },
    invert: { enabled: false },
    blur: { enabled: false, iterations: 2 },
    colorize: { enabled: false, color: '#ff6600' },
    vignette: { enabled: false, intensity: 0.6, radiusA: 0.4, radiusB: 0.8 },
  },
  fog: {
    enabled: false,
    mode: 'exponential2',
    color: '#8fa4b8',
    density: 0.008,
    near: 15,
    far: 180,
    height: 12,
    heightFalloff: 0.6,
    affectSkybox: false,
    windDrift: true,
    windSpeed: 0.5,
  },
  createdAt: '2026-09-30T12:00:00.000Z',
  updatedAt: '2026-09-30T12:00:00.000Z',
};

export const INVALID_SCENE_FIXTURE = {
  schemaVersion: 1,
  id: '',
  name: '',
  path: '',
  rootNodeId: '',
  nodes: {}, // Empty nodes should fail refine
};

export const VALID_PREFAB_FIXTURE: PrefabV1 = {
  schemaVersion: 1,
  id: 'prefab_test_01',
  name: 'CoinPrefab',
  rootNodeId: 'node_test_01',
  nodes: {
    node_test_01: VALID_NODE_FIXTURE,
  },
  sourcePath: 'res://prefabs/Coin.prefab.json',
  createdAt: '2026-09-30T12:00:00.000Z',
  updatedAt: '2026-09-30T12:00:00.000Z',
};

export const INVALID_PREFAB_FIXTURE = {
  schemaVersion: 1,
  id: '',
  name: '',
  rootNodeId: '',
  nodes: {}, // Empty nodes should fail
};

export const VALID_PROJECT_FIXTURE: ProjectV1 = {
  schemaVersion: 1,
  id: 'proj_test_01',
  name: 'TestProject',
  location: '~/Projects/TestProject',
  renderer: 'Three.js (WebGL)',
  lastOpenedScene: 'res://scenes/TestScene.scene.json',
  createdAt: '2026-09-30T12:00:00.000Z',
  updatedAt: '2026-09-30T12:00:00.000Z',
  settings: {
    general: {
      projectName: 'TestProject',
      version: '1.0.0',
      description: '',
      mainScene: 'res://scenes/TestScene.scene.json',
      author: 'Tester',
    },
    display: {
      width: 1280,
      height: 720,
      resizable: true,
      fullscreen: false,
      windowMode: 'windowed',
      orientation: 'landscape',
    },
    rendering: {
      renderer: 'Three.js (WebGL)',
      clearColor: '#141822',
      vsync: true,
      msaa: '2x',
      shadowsEnabled: true,
      shadowQuality: 'medium',
      hdr: false,
    },
    physics: {
      gravity3D: { x: 0, y: -9.8, z: 0 },
      defaultLinearDamp: 0.1,
    },
    input: {
      actions: [
        {
          name: 'jump',
          bindings: [{ type: 'key', code: 'Space' }],
        },
      ],
    },
    audio: {
      masterVolume: 1,
      musicVolume: 0.8,
      sfxVolume: 0.9,
    },
  },
  files: {
    'res://scenes/TestScene.scene.json': {
      path: 'res://scenes/TestScene.scene.json',
      name: 'TestScene.scene.json',
      isDirectory: false,
      extension: 'json',
      content: JSON.stringify(VALID_SCENE_FIXTURE),
      updatedAt: '2026-09-30T12:00:00.000Z',
    },
  },
};

export const INVALID_PROJECT_FIXTURE = {
  schemaVersion: 1,
  id: '',
  name: '',
  settings: {
    // Missing required sections
  },
};

// ==========================================
// AIS-03b: Canonical File Fixtures (v4.7.0: sem addons)
// ==========================================

export const VALID_PROJECT_FILE_FIXTURE = {
  schemaVersion: 1,
  projectId: 'proj_canon_001',
  name: 'Canonical Project Test',
  appId: 'com.nodimus.testapp',
  engineVersion: '1.0.0',
  startSceneId: 'scene_main_01',
  scenes: [
    {
      id: 'scene_main_01',
      name: 'Main',
      path: 'res://scenes/Main.scene.json',
      isStartScene: true,
    },
  ],
  globalVariables: [
    { id: 'var_score', name: 'playerScore', type: 'number' as const, value: 0 },
  ],
  inputMap: [],
  settings: {
    general: {
      projectName: 'Canonical Project Test',
      version: '1.0.0',
      description: '',
      mainScene: 'res://scenes/Main.scene.json',
      author: 'Tester',
    },
    display: {
      width: 1280,
      height: 720,
      resizable: true,
      fullscreen: false,
      orientation: 'landscape' as const,
    },
    rendering: {
      renderer: 'Three.js (WebGL)' as const,
      clearColor: '#141822',
      vsync: true,
      msaa: '2x' as const,
      shadowsEnabled: true,
    },
    physics: {
      gravity3D: { x: 0, y: -9.8, z: 0 },
      defaultLinearDamp: 0.1,
    },
    input: { actions: [] },
    audio: { masterVolume: 1, musicVolume: 0.8, sfxVolume: 0.9 },
  },
};

export const INVALID_PROJECT_FILE_ABSOLUTE_PATH_FIXTURE = {
  ...VALID_PROJECT_FILE_FIXTURE,
  scenes: [
    {
      id: 'scene_main_01',
      name: 'Main',
      path: 'C:\\Users\\Developer\\Desktop\\Main.scene.json', // Prohibited absolute OS path
    },
  ],
};

export const VALID_SCENE_FILE_FIXTURE = {
  schemaVersion: 1,
  sceneId: 'scene_main_01',
  name: 'Main Level',
  rootNodeId: 'node_root_01',
  environmentNodeId: 'node_env_01',
  nodes: {
    node_root_01: {
      schemaVersion: 1,
      id: 'node_root_01',
      name: 'WorldRoot',
      type: 'Spatial' as const,
      parentId: null,
      childrenIds: ['node_env_01'],
      visible: true,
      locked: false,
      properties: {
        position: { x: 0, y: 0, z: 0 },
        rotation: { x: 0, y: 0, z: 0 },
        scale: { x: 1, y: 1, z: 1 },
      },
    },
    node_env_01: {
      schemaVersion: 1,
      id: 'node_env_01',
      name: 'WorldEnvironment',
      type: 'Environment' as const,
      parentId: 'node_root_01',
      childrenIds: [],
      visible: true,
      locked: false,
      properties: {
        ambientIntensity: 0.5,
        backgroundColor: { r: 0.1, g: 0.1, b: 0.15, a: 1 },
      },
    },
  },
  sceneSettings: {
    environment: {
      ambientColor: '#334155',
      ambientIntensity: 0.5,
      backgroundColor: '#141822',
      realtimeShadows: true,
      gravity: { x: 0, y: -9.8, z: 0 },
      wind: { x: 0, y: 0, z: 0 },
    },
  },
};

export const INVALID_SCENE_FILE_MISSING_ROOT_FIXTURE = {
  ...VALID_SCENE_FILE_FIXTURE,
  rootNodeId: 'missing_root_id_not_in_nodes',
};

/**
 * v4.7.0 — legacy behavior instance written by an older build (when project
 * addons existed). Its contributionId is unknown to the current registry.
 * The parser must: read `source: 'addon'` as `'custom'`, and preserve every
 * unknown/legacy field (including `addonId`) without discarding.
 */
export const LEGACY_UNKNOWN_BEHAVIOR_FIXTURE = {
  id: 'beh_instance_01',
  contributionId: 'custom_ai_patrol',
  source: 'addon',
  addonId: 'addon_dialogue',
  addonVersion: '1.2.0',
  properties: { patrolSpeed: 3.5, waypoints: ['wp1', 'wp2'] },
  // Unknown properties that MUST be preserved by parser:
  experimentalAiGraph: { nodes: 12, mode: 'astar' },
  customCompilerFlag: true,
};

/**
 * Runs a deterministic verification test of all V1 and AIS-03b schemas against valid and invalid fixtures.
 * Returns a detailed pass/fail report with diagnostics.
 */
export function verifyZodSchemas(): {
  allPassed: boolean;
  results: { entity: string; validPasses: boolean; invalidCatchesErrors: boolean; diagnostics?: string }[];
} {
  // Test unknown/legacy behavior preservation (v4.7.0)
  const parsedBehavior = PersistedBehaviorInstanceSchema.parse(LEGACY_UNKNOWN_BEHAVIOR_FIXTURE);
  const unknownBehaviorPreserved =
    parsedBehavior.source === 'custom' &&
    parsedBehavior.contributionId === 'custom_ai_patrol' &&
    (parsedBehavior as any).addonId === 'addon_dialogue' &&
    (parsedBehavior as any).experimentalAiGraph !== undefined &&
    (parsedBehavior as any).customCompilerFlag === true;

  // Test ID stability across rename
  const sceneBeforeRename = JSON.parse(JSON.stringify(VALID_SCENE_FILE_FIXTURE));
  const originalSceneId = sceneBeforeRename.sceneId;
  const originalNodeId = sceneBeforeRename.nodes.node_root_01.id;

  sceneBeforeRename.name = 'Renamed Scene Level';
  sceneBeforeRename.nodes.node_root_01.name = 'Renamed World Root';
  const idPreservedAcrossRename =
    sceneBeforeRename.sceneId === originalSceneId &&
    sceneBeforeRename.nodes.node_root_01.id === originalNodeId;

  // AIS-03c Tests:
  // Test 1: Editing transform of a node is authoring
  const authModel = new AuthoringModel();
  const testNodeId = authModel.getRootNode()?.id || Object.keys(authModel.getScene().nodes)[0];
  authModel.setNodeTransform(testNodeId, { position: [15, 25, 35] });
  const updatedT = authModel.getNode(testNodeId)?.transform?.position;
  const authoringTransformPass = Array.isArray(updatedT)
    ? (updatedT[0] === 15 && updatedT[1] === 25 && updatedT[2] === 35)
    : ((updatedT as any)?.x === 15 && (updatedT as any)?.y === 25 && (updatedT as any)?.z === 35);

  // Test 2: Snapshot immutability & runtime decoupling
  const snapshot = authModel.createSceneSnapshot();
  const rtScene = materializeRuntimeScene(snapshot);
  const inst = rtScene.getInstance(testNodeId);
  if (inst) {
    inst.transform.position = [9999, 8888, 7777];
  }
  const authoringSceneAfterRtMutate = authModel.getNode(testNodeId)?.transform?.position;
  const authUntouched = Array.isArray(authoringSceneAfterRtMutate)
    ? (authoringSceneAfterRtMutate[0] === 15)
    : ((authoringSceneAfterRtMutate as any)?.x === 15);
  const snapNodeT = snapshot.nodes[testNodeId].transform?.position as any;
  const snapUntouched = Array.isArray(snapNodeT)
    ? (snapNodeT[0] === 15)
    : (snapNodeT?.x === 15);
  const snapshotImmutabilityPass = authUntouched && snapUntouched;

  // Test 3: Scene serialization compatibility
  const sceneFileForAuth = ProjectStorage.toSceneFile(authModel.getScene());
  const sceneFileValid = validateSceneFile(sceneFileForAuth).success === true;

  // Test 4: Single authoring authority & notification
  let notificationFired = false;
  const unsub = authModel.subscribe(() => { notificationFired = true; });
  authModel.renameNode(testNodeId, 'RenamedByAuthoringModel');
  unsub();
  const singleAuthorityPass = notificationFired && authModel.getNode(testNodeId)?.name === 'RenamedByAuthoringModel';

  const tests = [
    {
      entity: 'Node',
      validRes: validateNode(VALID_NODE_FIXTURE),
      invalidRes: validateNode(INVALID_NODE_FIXTURE),
    },
    {
      entity: 'Action',
      validRes: validateAction(VALID_ACTION_FIXTURE),
      invalidRes: validateAction(INVALID_ACTION_FIXTURE),
    },
    {
      entity: 'Behavior',
      validRes: validateBehavior(VALID_BEHAVIOR_FIXTURE),
      invalidRes: validateBehavior(INVALID_BEHAVIOR_FIXTURE),
    },
    {
      entity: 'Scene',
      validRes: validateScene(VALID_SCENE_FIXTURE),
      invalidRes: validateScene(INVALID_SCENE_FIXTURE),
    },
    {
      entity: 'Prefab',
      validRes: validatePrefab(VALID_PREFAB_FIXTURE),
      invalidRes: validatePrefab(INVALID_PREFAB_FIXTURE),
    },
    {
      entity: 'Project',
      validRes: validateProject(VALID_PROJECT_FIXTURE),
      invalidRes: validateProject(INVALID_PROJECT_FIXTURE),
    },
    {
      entity: 'ProjectFile (project.json)',
      validRes: validateProjectFile(VALID_PROJECT_FILE_FIXTURE),
      invalidRes: validateProjectFile(INVALID_PROJECT_FILE_ABSOLUTE_PATH_FIXTURE),
    },
    {
      entity: 'SceneFile (*.scene.json)',
      validRes: validateSceneFile(VALID_SCENE_FILE_FIXTURE),
      invalidRes: validateSceneFile(INVALID_SCENE_FILE_MISSING_ROOT_FIXTURE),
    },
    {
      entity: 'UnknownBehaviorPreservation',
      validRes: { success: unknownBehaviorPreserved } as any,
      invalidRes: { success: false, errors: ['dummy'] } as any,
    },
    {
      entity: 'IdStabilityAcrossRename',
      validRes: { success: idPreservedAcrossRename } as any,
      invalidRes: { success: false, errors: ['dummy'] } as any,
    },
    {
      entity: 'AIS-03c-C01: AuthoringModelTransformEdit',
      validRes: { success: authoringTransformPass } as any,
      invalidRes: { success: false, errors: ['dummy'] } as any,
    },
    {
      entity: 'AIS-03c-C02: SnapshotImmutabilityAndRuntimeDecoupling',
      validRes: { success: snapshotImmutabilityPass } as any,
      invalidRes: { success: false, errors: ['dummy'] } as any,
    },
    {
      entity: 'AIS-03c-C03: SceneSerializationCompatibility',
      validRes: { success: sceneFileValid } as any,
      invalidRes: { success: false, errors: ['dummy'] } as any,
    },
    {
      entity: 'AIS-03c-C04: SingleAuthoringAuthority',
      validRes: { success: singleAuthorityPass } as any,
      invalidRes: { success: false, errors: ['dummy'] } as any,
    },
  ];

  const results = tests.map((t) => {
    const validPasses = t.validRes.success === true;
    const invalidCatchesErrors = t.invalidRes.success === false;
    return {
      entity: t.entity,
      validPasses,
      invalidCatchesErrors,
      diagnostics: t.invalidRes.formattedError,
    };
  });

  const allPassed = results.every((r) => r.validPasses && r.invalidCatchesErrors);
  return { allPassed, results };
}

// ============================================================================
// AIS-03d: EditorStore pure-function selector / action tests
// Executed against plain state objects — no React, no Zustand store, no THREE.
// ============================================================================

/** Build a minimal EditorStoreState for testing. */
function makeState(overrides: Partial<EditorStoreState> = {}): EditorStoreState {
  return {
    selectedNodeId: null,
    multiSelectedNodeIds: [],
    activeSceneRef: null,
    activeProjectRef: null,
    workspaceMode: '3D',
    manipulationMode: 'select',
    viewportSnap: __editorStoreModule.DEFAULT_VIEWPORT_SNAP,
    showColliders: false,
    addWithCollision: true,
    isPlaying: false,
    isPaused: false,
    playMode: null,
    bottomTab: 'output',
    isBottomOpen: false,
    activeScriptPath: null,
    openScriptTabs: [],
    isProjectSettingsOpen: false,
    isProjectManagerOpen: false,
    isCreateNodeModalOpen: false,
    isPostProcessingOpen: false,
    isTerrainEditorOpen: false,
    isTreeEditorOpen: false,
    isFogModalOpen: false,
    isSoundModalOpen: false,
    isParticleModalOpen: false,
    particleModalTargetNodeId: null,
    isAssetImportModalOpen: false,
    assetImportSource: null,
    fileSystemReveal: null,
    isTexturePreviewOpen: false,
    isVideoEditorOpen: false,
    isSpriteEditorOpen: false,
    isExtensionsPanelOpen: false,
    isScriptEditorModalOpen: false,
    generatorEdit: null,
    ...overrides,
  };
}

export interface AIS03dTestResult {
  allPassed: boolean;
  results: { label: string; passed: boolean; detail?: string }[];
}

/**
 * Runs the AIS-03d EditorStore selector/action suite.
 * Pure functions only — no React hooks, no Zustand store, no THREE.
 */
export function verifyEditorStoreSelectors(): AIS03dTestResult {
  const checks: { label: string; passed: boolean; detail?: string }[] = [];

  // ── C01: selectSelectedNodeId ──────────────────────────────────────────────
  {
    const s = makeState({ selectedNodeId: 'node_abc' });
    const v = selectSelectedNodeId(s);
    checks.push({ label: 'AIS-03d-S01: selectSelectedNodeId returns correct id', passed: v === 'node_abc' });
  }
  {
    const s = makeState({ selectedNodeId: null });
    checks.push({ label: 'AIS-03d-S02: selectSelectedNodeId returns null when empty', passed: selectSelectedNodeId(s) === null });
  }

  // ── C02: selectMultiSelectedNodeIds ────────────────────────────────────────
  {
    const ids = ['n1', 'n2', 'n3'];
    const s = makeState({ multiSelectedNodeIds: ids });
    const v = selectMultiSelectedNodeIds(s);
    checks.push({ label: 'AIS-03d-S03: selectMultiSelectedNodeIds returns full set', passed: v.length === 3 && v[0] === 'n1' });
  }

  // ── C03: selectHasSelection ────────────────────────────────────────────────
  {
    checks.push({ label: 'AIS-03d-S04: selectHasSelection false when nothing selected', passed: !selectHasSelection(makeState()) });
    checks.push({ label: 'AIS-03d-S05: selectHasSelection true with primary selection', passed: selectHasSelection(makeState({ selectedNodeId: 'n1' })) });
    checks.push({ label: 'AIS-03d-S06: selectHasSelection true with multi-selection only', passed: selectHasSelection(makeState({ multiSelectedNodeIds: ['n2'] })) });
  }

  // ── C04: selectAllSelectedNodeIds — deduplication ─────────────────────────
  {
    const s = makeState({ selectedNodeId: 'n1', multiSelectedNodeIds: ['n1', 'n2'] });
    const all = selectAllSelectedNodeIds(s);
    checks.push({ label: 'AIS-03d-S07: selectAllSelectedNodeIds deduplicates primary+multi', passed: all.length === 2 && all.includes('n1') && all.includes('n2') });
  }

  // ── C05: Active scene ref selectors ───────────────────────────────────────
  {
    const s = makeState({ activeSceneRef: { path: 'res://scenes/Main.scene.json', name: 'Main' } });
    checks.push({ label: 'AIS-03d-S08: selectActiveSceneName returns name', passed: selectActiveSceneName(s) === 'Main' });
    checks.push({ label: 'AIS-03d-S09: selectActiveScenePath returns path', passed: selectActiveScenePath(s) === 'res://scenes/Main.scene.json' });
    checks.push({ label: 'AIS-03d-S10: selectActiveSceneName null when no scene', passed: selectActiveSceneName(makeState()) === null });
  }

  // ── C06: Workspace / manipulation mode ───────────────────────────────────
  {
    checks.push({ label: 'AIS-03d-S11: selectWorkspaceMode default is 3D', passed: selectWorkspaceMode(makeState()) === '3D' });
    checks.push({ label: 'AIS-03d-S12: selectWorkspaceMode returns override', passed: selectWorkspaceMode(makeState({ workspaceMode: 'Script' })) === 'Script' });
    checks.push({ label: 'AIS-03d-S13: selectManipulationMode default is select', passed: selectManipulationMode(makeState()) === 'select' });
    checks.push({ label: 'AIS-03d-S14: selectManipulationMode returns override', passed: selectManipulationMode(makeState({ manipulationMode: 'translate' })) === 'translate' });
  }

  // ── C07: Play state ───────────────────────────────────────────────────────
  {
    checks.push({ label: 'AIS-03d-S15: selectIsPlaying false by default', passed: !selectIsPlaying(makeState()) });
    checks.push({ label: 'AIS-03d-S16: selectIsPlaying true when playing', passed: selectIsPlaying(makeState({ isPlaying: true })) });
  }

  // ── C08: No runtime/THREE in state — structural boundary check ───────────
  {
    const s = makeState();
    const keys = Object.keys(s);
    const forbidden = ['threescene', 'renderer', 'rapierworld', 'audiocontext', 'undostack', 'redostack', 'scenedata', 'gamenodes', 'object3d', 'webgl'];
    const hasRuntimeKey = forbidden.some((f) => keys.some((k) => k.toLowerCase() === f || (k.toLowerCase().includes(f) && k !== 'activeSceneRef')));
    checks.push({ label: 'AIS-03d-S17: store state contains no runtime/THREE keys', passed: !hasRuntimeKey });
  }

  // ── C09: selectNoDialogOpen ───────────────────────────────────────────────
  {
    checks.push({ label: 'AIS-03d-S18: selectNoDialogOpen true when all closed', passed: selectNoDialogOpen(makeState()) });
    checks.push({ label: 'AIS-03d-S19: selectNoDialogOpen false when a dialog is open', passed: !selectNoDialogOpen(makeState({ isFogModalOpen: true })) });
  }

  const allPassed = checks.every((c) => c.passed);
  return { allPassed, results: checks };
}

// ============================================================================
// AIS-03f: EditorContext Facade & Delegation Tests
// Pure deterministic test suite validating that EditorContext delegates to
// AuthoringModel, EditorStore, and CommandManager without dual-authority.
// ============================================================================

export interface AIS03fTestResult {
  allPassed: boolean;
  results: { label: string; passed: boolean; detail?: string }[];
}

export function verifyEditorContextFacade(): AIS03fTestResult {
  const checks: { label: string; passed: boolean; detail?: string }[] = [];

  // F01: AuthoringModel is single authority for persistent scene
  {
    const model = new AuthoringModel();
    const scene = model.getScene();
    checks.push({
      label: 'AIS-03f-F01: AuthoringModel provides persistent scene data',
      passed: typeof scene.id === 'string' && typeof scene.nodes === 'object',
    });
  }

  // F02: AuthoringModel notifies listeners upon project mutations
  {
    const model = new AuthoringModel();
    let notified = false;
    const unsub = model.subscribe(() => { notified = true; });
    const currentProj = model.getProject();
    model.setProject({ ...currentProj, name: 'FacadeTestProject' });
    unsub();
    checks.push({
      label: 'AIS-03f-F02: AuthoringModel notifies subscriber on project mutations',
      passed: notified && model.getProject().name === 'FacadeTestProject',
    });
  }

  // F03: EditorStore state controls selection independently of React local state
  {
    const { useEditorStore: store } = __editorStoreModule;
    store.getState().selectNode('test_node_facade');
    const sel = store.getState().selectedNodeId;
    store.getState().selectNode(null);
    checks.push({
      label: 'AIS-03f-F03: EditorStore is sole authority for selectedNodeId',
      passed: sel === 'test_node_facade' && store.getState().selectedNodeId === null,
    });
  }

  // F04: EditorStore is sole authority for modal dialog flags
  {
    const { useEditorStore: store } = __editorStoreModule;
    store.getState().setIsFogModalOpen(true);
    const wasOpen = store.getState().isFogModalOpen;
    store.getState().setIsFogModalOpen(false);
    checks.push({
      label: 'AIS-03f-F04: EditorStore is sole authority for modal visibility',
      passed: wasOpen === true && store.getState().isFogModalOpen === false,
    });
  }

  // F05: EditorStore is sole authority for workspaceMode
  {
    const { useEditorStore: store } = __editorStoreModule;
    store.getState().setWorkspaceMode('Script');
    const wasScript = store.getState().workspaceMode;
    store.getState().setWorkspaceMode('3D');
    checks.push({
      label: 'AIS-03f-F05: EditorStore is sole authority for workspaceMode',
      passed: wasScript === 'Script' && store.getState().workspaceMode === '3D',
    });
  }

  // F06: CommandManager manages reversible operations without parallel undo stack
  {
    const { globalCommandManager: mgr } = __commandManagerModule;
    let val = 10;
    mgr.execute({
      name: 'FacadeUndoTest',
      execute: () => { val = 20; },
      undo: () => { val = 10; },
    });
    const afterExec = val;
    mgr.undo();
    const afterUndo = val;
    checks.push({
      label: 'AIS-03f-F06: CommandManager handles undo/redo stack without dual store',
      passed: afterExec === 20 && afterUndo === 10,
    });
  }

  // F07: Simulation play state is mirrored in EditorStore
  {
    const { useEditorStore: store } = __editorStoreModule;
    store.getState().setPlayState(true, false, 'project');
    const isPlaying = store.getState().isPlaying;
    const mode = store.getState().playMode;
    store.getState().setPlayState(false, false, null);
    checks.push({
      label: 'AIS-03f-F07: Simulation play state is projected in EditorStore',
      passed: isPlaying === true && mode === 'project' && store.getState().isPlaying === false,
    });
  }

  // F08: EditorStore contains zero persistent scene graphs
  {
    const { useEditorStore: store } = __editorStoreModule;
    const state = store.getState();
    const hasSceneGraph = 'nodes' in state || 'rootNodeId' in state;
    checks.push({
      label: 'AIS-03f-F08: EditorStore does not store persistent SceneData graph',
      passed: !hasSceneGraph,
    });
  }

  const allPassed = checks.every((c) => c.passed);
  return { allPassed, results: checks };
}

// ============================================================================
// AIS-04: Desktop Keyboard Shortcuts Test Suite
// Pure deterministic test suite validating dispatchDesktopShortcut behavior
// against all canonical shortcuts (Item 2 Option C).
// ============================================================================

export interface AIS04TestResult {
  allPassed: boolean;
  results: { label: string; passed: boolean; detail?: string }[];
}

export function verifyDesktopShortcuts(): AIS04TestResult {
  const { dispatchDesktopShortcut, DESKTOP_SHORTCUTS } = __desktopShortcutsModule;
  const checks: { label: string; passed: boolean; detail?: string }[] = [];

  function makeKeyEvent(options: {
    key: string;
    ctrlKey?: boolean;
    metaKey?: boolean;
    shiftKey?: boolean;
    altKey?: boolean;
    isEditable?: boolean;
  }): { event: any; prevented: boolean } {
    let prevented = false;
    const dummyTarget = options.isEditable
      ? { tagName: 'INPUT', isContentEditable: false, closest: () => null }
      : { tagName: 'DIV', isContentEditable: false, closest: () => null };

    const event = {
      key: options.key,
      ctrlKey: options.ctrlKey ?? false,
      metaKey: options.metaKey ?? false,
      shiftKey: options.shiftKey ?? false,
      altKey: options.altKey ?? false,
      target: dummyTarget,
      preventDefault: () => { prevented = true; },
    };
    return { event, prevented: false };
  }

  // K01: F5 -> play_project
  {
    let called = false;
    const { event } = makeKeyEvent({ key: 'F5' });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, { onPlayProject: () => { called = true; } });
    checks.push({
      label: 'AIS-04-K01: F5 triggers play_project with preventDefault',
      passed: res === 'play_project' && called && prevented,
    });
  }

  // K02: F6 -> play_scene
  {
    let called = false;
    const { event } = makeKeyEvent({ key: 'F6' });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, { onPlayScene: () => { called = true; } });
    checks.push({
      label: 'AIS-04-K02: F6 triggers play_scene with preventDefault',
      passed: res === 'play_scene' && called && prevented,
    });
  }

  // K03: F8 -> stop_simulation
  {
    let called = false;
    const { event } = makeKeyEvent({ key: 'F8' });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, { onStopSimulation: () => { called = true; } });
    checks.push({
      label: 'AIS-04-K03: F8 triggers stop_simulation with preventDefault',
      passed: res === 'stop_simulation' && called && prevented,
    });
  }

  // K04: Ctrl+S -> save_scene
  {
    let called = false;
    const { event } = makeKeyEvent({ key: 's', ctrlKey: true });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, { onSaveScene: () => { called = true; } });
    checks.push({
      label: 'AIS-04-K04: Ctrl+S triggers save_scene with preventDefault',
      passed: res === 'save_scene' && called && prevented,
    });
  }

  // K05: Ctrl+Z -> undo
  {
    let called = false;
    const { event } = makeKeyEvent({ key: 'z', ctrlKey: true });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, { onUndo: () => { called = true; } });
    checks.push({
      label: 'AIS-04-K05: Ctrl+Z triggers undo with preventDefault',
      passed: res === 'undo' && called && prevented,
    });
  }

  // K06: Ctrl+Y -> redo
  {
    let called = false;
    const { event } = makeKeyEvent({ key: 'y', ctrlKey: true });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, { onRedo: () => { called = true; } });
    checks.push({
      label: 'AIS-04-K06: Ctrl+Y triggers redo with preventDefault',
      passed: res === 'redo' && called && prevented,
    });
  }

  // K07: Ctrl+Shift+Z -> redo
  {
    let called = false;
    const { event } = makeKeyEvent({ key: 'z', ctrlKey: true, shiftKey: true });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, { onRedo: () => { called = true; } });
    checks.push({
      label: 'AIS-04-K07: Ctrl+Shift+Z triggers redo with preventDefault',
      passed: res === 'redo' && called && prevented,
    });
  }

  // K08: W -> gizmo_translate
  {
    let called = false;
    const { event } = makeKeyEvent({ key: 'w' });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, { onTranslateGizmo: () => { called = true; } });
    checks.push({
      label: 'AIS-04-K08: W activates translate gizmo',
      passed: res === 'gizmo_translate' && called && prevented,
    });
  }

  // K09: E -> gizmo_rotate
  {
    let called = false;
    const { event } = makeKeyEvent({ key: 'e' });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, { onRotateGizmo: () => { called = true; } });
    checks.push({
      label: 'AIS-04-K09: E activates rotate gizmo',
      passed: res === 'gizmo_rotate' && called && prevented,
    });
  }

  // K10: R -> gizmo_scale
  {
    let called = false;
    const { event } = makeKeyEvent({ key: 'r' });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, { onScaleGizmo: () => { called = true; } });
    checks.push({
      label: 'AIS-04-K10: R activates scale gizmo',
      passed: res === 'gizmo_scale' && called && prevented,
    });
  }

  // K11: F -> frame_selected
  {
    let framedId: string | null = null;
    const { event } = makeKeyEvent({ key: 'f' });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, {
      selectedNodeId: 'node_player',
      onFrameSelected: (id: string) => { framedId = id; },
    });
    checks.push({
      label: 'AIS-04-K11: F frames selected node',
      passed: res === 'frame_selected' && framedId === 'node_player' && prevented,
    });
  }

  // K12: Delete -> delete_node
  {
    let deletedId: string | null = null;
    const { event } = makeKeyEvent({ key: 'Delete' });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, {
      selectedNodeId: 'node_to_delete',
      onDeleteSelected: (id: string) => { deletedId = id; },
    });
    checks.push({
      label: 'AIS-04-K12: Delete deletes selected node',
      passed: res === 'delete_node' && deletedId === 'node_to_delete' && prevented,
    });
  }

  // K13: Ctrl+D -> duplicate_node
  {
    let dupId: string | null = null;
    const { event } = makeKeyEvent({ key: 'd', ctrlKey: true });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    const res = dispatchDesktopShortcut(event, {
      selectedNodeId: 'node_to_duplicate',
      onDuplicateSelected: (id: string) => { dupId = id; },
    });
    checks.push({
      label: 'AIS-04-K13: Ctrl+D duplicates selected node with preventDefault',
      passed: res === 'duplicate_node' && dupId === 'node_to_duplicate' && prevented,
    });
  }

  // K14: Inside editable text inputs, single-key shortcuts are ignored
  {
    const { event } = makeKeyEvent({ key: 'w', isEditable: true });
    let prevented = false;
    event.preventDefault = () => { prevented = true; };
    let called = false;
    const res = dispatchDesktopShortcut(event, { onTranslateGizmo: () => { called = true; } });
    checks.push({
      label: 'AIS-04-K14: Single-key shortcuts ignored when typing in editable elements',
      passed: res === null && !called && !prevented,
    });
  }

  // K15: DESKTOP_SHORTCUTS list contains 13 canonical bindings
  {
    checks.push({
      label: 'AIS-04-K15: DESKTOP_SHORTCUTS contains 14 desktop definitions (13 canônicas + F7 do AIS-28b)',
      passed: Array.isArray(DESKTOP_SHORTCUTS) && DESKTOP_SHORTCUTS.length === 14,
    });
  }

  const allPassed = checks.every((c) => c.passed);
  return { allPassed, results: checks };
}

// ============================================================================
// AIS-05: Default Project Initialization and Persistence Test Suite
// Validates canonical res:// virtual directory tree, Main.scene contents,
// JSON integrity protection, and .nodimus native export/import.
// ============================================================================

export interface AIS05TestResult {
  allPassed: boolean;
  results: { label: string; passed: boolean; detail?: string }[];
}

export function verifyDefaultProjectAndStorage(): AIS05TestResult {
  const { createNewProject, createDefault3DStarterScene, ensureStarterFiles, removeLegacyAddonSample } = __defaultProjectModule;
  const { ProjectStorage } = __projectStorageModule;
  const { validateProjectFile, validateSceneFile } = __schemasIndexModule;
  const { CURRENT_PROJECT_SCHEMA_VERSION, CURRENT_SCENE_SCHEMA_VERSION } = __persistenceVersionsModule;

  const checks: { label: string; passed: boolean; detail?: string }[] = [];

  // T01: createNewProject creates full canonical res:// directory tree
  const proj = createNewProject('Test Adventure', '~/Projects/TestAdventure', '3d');
  const requiredDirs = [
    'res://',
    'res://scenes/',
    'res://sprites/',
    'res://textures/',
    'res://materials/',
    'res://audio/',
    'res://scripts/',
    'res://prefabs/',
  ];
  const allDirsPresent = requiredDirs.every((dir: string) => proj.files[dir] && proj.files[dir].isDirectory);
  checks.push({
    label: 'AIS-05-T01: createNewProject creates full canonical res:// virtual directory tree',
    passed: allDirsPresent,
    detail: allDirsPresent ? undefined : `Missing directories: ${requiredDirs.filter((d: string) => !proj.files[d]).join(', ')}`,
  });

  // T02: res://project.json generated in canonical ProjectFile format and validates with Zod
  const projectJsonFile = proj.files['res://project.json'];
  let projValidationPassed = false;
  if (projectJsonFile && projectJsonFile.content) {
    try {
      const parsedProjFile = JSON.parse(projectJsonFile.content);
      const v = validateProjectFile(parsedProjFile);
      projValidationPassed = v.success && parsedProjFile.schemaVersion === CURRENT_PROJECT_SCHEMA_VERSION;
    } catch {
      projValidationPassed = false;
    }
  }
  checks.push({
    label: 'AIS-05-T02: res://project.json generated in canonical format with schemaVersion: 1',
    passed: projValidationPassed,
  });

  // T03: Main.scene default contains Spatial root node
  const scene = createDefault3DStarterScene();
  const rootNode = scene.nodes[scene.rootNodeId];
  checks.push({
    label: 'AIS-05-T03: Main.scene default contains Spatial root node',
    passed: !!rootNode && rootNode.type === 'Spatial',
  });

  // T04: Main.scene default contains exactly one Environment default of the Scene
  const envNodes: any[] = Object.values(scene.nodes).filter((n: any) => n.type === 'Environment');
  const envMatchesId = envNodes.length === 1 && scene.environmentNodeId === (envNodes[0] as any)?.id;
  checks.push({
    label: 'AIS-05-T04: Main.scene default contains exactly one Environment node matching environmentNodeId',
    passed: envMatchesId,
  });

  // T05: Main.scene default contains DirectionalLight default
  const sunNodes: any[] = Object.values(scene.nodes).filter((n: any) => n.type === 'DirectionalLight');
  checks.push({
    label: 'AIS-05-T05: Main.scene default contains default DirectionalLight',
    passed: sunNodes.length >= 1,
  });

  // T06: Main.scene default contains simple Camera GameNode with active: true
  const cameraNodes: any[] = Object.values(scene.nodes).filter((n: any) => n.type === 'Camera');
  const activeCamera = cameraNodes.find((c: any) => c.properties?.active === true);
  checks.push({
    label: 'AIS-05-T06: Main.scene default contains Camera GameNode with active: true destined for game/runtime',
    passed: cameraNodes.length >= 1 && !!activeCamera,
  });

  // T07: Main.scene default contains demonstrative Ground/Grid plane
  const floorNode = Object.values(scene.nodes).find(
    (n: any) => n.type === 'MeshInstance' && n.properties?.meshType === 'PlaneMesh'
  );
  checks.push({
    label: 'AIS-05-T07: Main.scene default contains demonstrative Ground PlaneMesh',
    passed: !!floorNode,
  });

  // T08: Editor orbital camera is NOT persisted in Scene nodes
  const orbitCamInNodes = Object.values(scene.nodes).some(
    (n: any) => (n.name?.toLowerCase().includes('orbit') || n.name?.toLowerCase().includes('editorcam'))
  );
  checks.push({
    label: 'AIS-05-T08: Editor orbital navigation camera is NOT persisted in SceneData/GameNode',
    passed: !orbitCamInNodes,
  });

  // T09: Main.scene validates against canonical SceneFile Zod schema
  const sceneFile = ProjectStorage.toSceneFile(scene);
  const sceneValidation = validateSceneFile(sceneFile);
  checks.push({
    label: 'AIS-05-T09: Main.scene validates 100% against canonical SceneFile schema',
    passed: sceneValidation.success,
    detail: sceneValidation.formattedError,
  });

  // T10: ProjectStorage.saveProject and loadProject preserve schemaVersion and project integrity
  const testProject = createNewProject('Persistence Test', '~/Projects/Persist', '3d');
  testProject.id = 'proj_persist_test';
  ProjectStorage.saveProject(testProject);
  const loaded = ProjectStorage.loadProject(testProject.id);
  const persistOk = loaded !== null && loaded.id === testProject.id && loaded.schemaVersion === CURRENT_PROJECT_SCHEMA_VERSION;
  checks.push({
    label: 'AIS-05-T10: ProjectStorage.saveProject and loadProject preserve schemaVersion and project integrity',
    passed: persistOk,
  });

  // T11: JSON integrity protection: loadProject handles malformed JSON without crashing or corrupting
  const corruptedId = 'proj_corrupted_test';
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem(`nodimus_proj_${corruptedId}`, '{ broken json ::: missing quotes');
  }
  const corruptedLoaded = ProjectStorage.loadProject(corruptedId);
  checks.push({
    label: 'AIS-05-T11: JSON integrity protection: loadProject gracefully returns null on malformed JSON without crash',
    passed: corruptedLoaded === null,
  });

  // T12: JSON integrity protection: importProjectFromNodimus rejects malformed JSON with descriptive error
  let importRejected = false;
  try {
    ProjectStorage.importProjectFromNodimus('{ invalid json truncated');
  } catch (e: any) {
    importRejected = e?.message?.includes('JSON integrity failure') || false;
  }
  checks.push({
    label: 'AIS-05-T12: JSON integrity protection: importProjectFromNodimus rejects malformed JSON with explicit error',
    passed: importRejected,
  });

  // T13: Native .nodimus export and import cycle
  const exportPayload = ProjectStorage.exportProjectAsNodimus(testProject);
  let roundtripOk = false;
  try {
    const reimported = ProjectStorage.importProjectFromNodimus(exportPayload);
    roundtripOk = reimported.name === testProject.name && !!reimported.files['res://project.json'];
  } catch {
    roundtripOk = false;
  }
  checks.push({
    label: 'AIS-05-T13: Native .nodimus export and re-import cycle executes successfully',
    passed: roundtripOk,
  });

  // T14: ensureStarterFiles repairs missing canonical directories without destructive overwrite
  const incompleteProj = {
    schemaVersion: 1,
    id: 'proj_incomplete',
    name: 'Incomplete',
    location: '~/Projects/Incomplete',
    renderer: 'Three.js (WebGL)' as const,
    lastOpenedScene: 'res://scenes/Main.scene.json',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    settings: testProject.settings,
    files: {
      'res://': { path: 'res://', name: 'res://', isDirectory: true, updatedAt: '' },
    },
  };
  const repaired = ensureStarterFiles(incompleteProj);
  const repairedDirs = requiredDirs.every((d: string) => repaired.files[d]);
  const hasProjectJson = !!repaired.files['res://project.json'];
  checks.push({
    label: 'AIS-05-T14: ensureStarterFiles repairs missing canonical directories and project.json',
    passed: repairedDirs && hasProjectJson,
  });

  // T15 (v4.7.0): res://addons/ does not exist and project.json has no `addons`
  const addonPaths = Object.keys(proj.files).filter((k) => k.startsWith('res://addons/'));
  let projectJsonHasAddons = true;
  try {
    projectJsonHasAddons = 'addons' in JSON.parse(proj.files['res://project.json']?.content || '{}');
  } catch {
    projectJsonHasAddons = true;
  }
  checks.push({
    label: 'AIS-05r-T15: new project has no res://addons/ and project.json has no `addons` field',
    passed: addonPaths.length === 0 && !projectJsonHasAddons,
  });

  // T16 (v4.7.0): legacy editor-generated addon sample is removed; user files are preserved
  const legacyFiles: Record<string, any> = {
    'res://addons/': { path: 'res://addons/', name: 'addons', isDirectory: true },
    'res://addons/zylann.hterrain/': { path: 'res://addons/zylann.hterrain/', name: 'zylann.hterrain', isDirectory: true },
    'res://addons/zylann.hterrain/plugin.cfg': { path: 'res://addons/zylann.hterrain/plugin.cfg', name: 'plugin.cfg', isDirectory: false },
    'res://addons/zylann.hterrain/terrain_plugin.ts': { path: 'res://addons/zylann.hterrain/terrain_plugin.ts', name: 'terrain_plugin.ts', isDirectory: false },
    'res://project.json': {
      path: 'res://project.json',
      name: 'project.json',
      isDirectory: false,
      content: JSON.stringify({ name: 'Legacy', addons: [{ id: 'zylann.hterrain', path: 'res://addons/zylann.hterrain/' }] }),
    },
  };
  removeLegacyAddonSample(legacyFiles);
  const sampleGone =
    Object.keys(legacyFiles).filter((k) => k.startsWith('res://addons/')).length === 0 &&
    !('addons' in JSON.parse(legacyFiles['res://project.json'].content));
  const userFiles: Record<string, any> = {
    'res://addons/': { path: 'res://addons/', name: 'addons', isDirectory: true },
    'res://addons/meu_codigo.ts': { path: 'res://addons/meu_codigo.ts', name: 'meu_codigo.ts', isDirectory: false },
  };
  const originalWarn = console.warn;
  console.warn = () => {};
  removeLegacyAddonSample(userFiles);
  console.warn = originalWarn;
  const userPreserved = !!userFiles['res://addons/meu_codigo.ts'];
  checks.push({
    label: 'AIS-05r-T16: legacy addon sample removed; user files in res://addons/ preserved',
    passed: sampleGone && userPreserved,
  });

  const allPassed = checks.every((c) => c.passed);
  return { allPassed, results: checks };
}

