import type {
  AuthoringSceneSnapshot,
  RuntimeSessionContract,
  RuntimeSessionMode,
  RuntimeSessionStatus,
} from '../types/runtime';
import type { DiagnosticInput } from '../core/diagnostics/DiagnosticService';
import type { PhysicsBridge, PhysicsEvent, PhysicsEventName } from '../core/physics/PhysicsBridge';
import type { HeightfieldData, PhysicsIssue } from '../core/physics/physicsDescriptor';
import { ensureRapier, getRapierIfReady, type RapierModule } from '../core/physics/rapierInit';
import { PhysicsHost, sceneHasPhysics } from './physicsHost';
import type { VariableManager, VariableSource } from '../core/variableManager';
import { BehaviorRuntimeCatalog, type BehaviorRuntimeLookup } from '../logic/behaviorRuntime';
import { BehaviorLifecycleHost } from './behaviorLifecycle';
import type { GameCameraPose } from './controllers/gameCamera';
import { BehaviorRuntimeStates } from './behaviorRuntimeState';
import type { RawInputReader } from './input/inputTriggers';
import { LogicRunner, type LogicLogEntry, type LogicLogMeta } from './logicRunner';
import { SubscriptionRegistry, type SubscriptionOwner, type SubscriptionOwnerKind } from './subscriptions';
import type { RuntimeScene } from './RuntimeScene';
import { RuntimeSceneManager, type RuntimeSceneEvent } from './RuntimeSceneManager';
import type { RuntimeInstance } from './RuntimeScene';

/**
 * AIS-44b — RuntimeSession: a AUTORIDADE ÚNICA do Play.
 *
 *   Authoring State → snapshot → RuntimeSession → Stop = dispose
 *
 * Dona de tudo o que é transitório: a cena viva (`RuntimeSceneManager` próprio), as variáveis da sessão, o `LogicRunner`
 * (regras), o lifecycle dos Behaviors (estado por nó × Behavior), as assinaturas/teardowns de sistemas (física, workers…)
 * e os diagnósticos efêmeros (`sessionId`). Nunca escreve no AuthoringModel, no EditorContext nem no CommandManager
 * (invariantes 4–5 de `types/runtime.ts`): parar a sessão descarta tudo e o autoral está intacto, sem Undo.
 *
 * Troca de cena (ordem fixa): abortar cadeias → dispose dos Behaviors → unsubscribe (runner) → teardowns (Workers, mundo
 * físico…) → limpar variáveis locais → PRESERVAR globais → carregar a nova RuntimeScene → iniciar o lifecycle.
 * `Restart Scene` é o mesmo caminho sobre o MESMO snapshot (locais restauradas, globais preservadas);
 * `Restart Behavior` recomeça só aquele (nó × Behavior).
 */

/** AIS-48: sinal emitido por um nó em runtime (`body_entered`/`body_exited`). A execução das conexões é do AIS-57; o barramento é este. */
export interface NodeSignalEvent {
  sourceNodeId: string;
  signal: 'body_entered' | 'body_exited' | 'fell_out_of_world';
  /** Argumentos do sinal: `[otherId]`; em `fell_out_of_world` (Kill Floor, AIS-49) `[y]` (altura mundial do corpo). */
  args: [string] | [number];
}

export interface RuntimeSessionDiagnostics {
  report(input: DiagnosticInput, options?: { announce?: boolean }): unknown;
  clearSession(sessionId: string): number;
}

export interface RuntimeSessionOptions {
  snapshot: AuthoringSceneSnapshot;
  mode?: RuntimeSessionMode;
  /** Globais iniciais (copiadas: o projeto autoral nunca é tocado). */
  globals?: readonly VariableSource[];
  input: RawInputReader;
  /** Serviço único de diagnósticos (`globalDiagnosticService` no editor). Sem ele, a sessão não publica diagnósticos. */
  diagnostics?: RuntimeSessionDiagnostics;
  /** Resolve o destino de `Change Scene` (caminho `res://…`) em snapshot; nunca toca o autoral. */
  resolveScene?: (scenePath: string) => AuthoringSceneSnapshot | Promise<AuthoringSceneSnapshot>;
  onLog?: (entry: LogicLogEntry) => void;
  onQuitGame?: () => void;
  onUiChanged?: () => void;
  random?: () => number;
  verbose?: boolean;
  /** Catálogo de executores de Behavior (padrão: as pastas de `src/logic/behaviors/`). */
  behaviorCatalog?: BehaviorRuntimeLookup;
  /** AIS-45: `settings.physics.defaultLinearDamp` do projeto (amortecimento linear padrão dos corpos `dynamic`). */
  defaultLinearDamp?: number;
  /** AIS-45: fornece o Rapier já carregado (padrão: `getRapierIfReady`); `null` = ainda carregando — o mundo entra assim que terminar. */
  getRapier?: () => RapierModule | null;
  /** AIS-45: buffer de alturas do terreno de uma instância (decisão 23; o AIS-50 fornece). */
  heightfieldOf?: (instance: RuntimeInstance) => HeightfieldData | null;
}

let sessionCounter = 0;

export class RuntimeSession implements RuntimeSessionContract {
  public readonly id: string;
  public readonly mode: RuntimeSessionMode;
  /** Cena viva e variáveis DESTA sessão (nunca um singleton do app). */
  public readonly sceneManager = new RuntimeSceneManager();

  private _status: RuntimeSessionStatus = 'idle';
  private _snapshot: AuthoringSceneSnapshot;
  private _elapsed = 0;
  private _runner: LogicRunner | null = null;
  private _behaviors: BehaviorLifecycleHost | null = null;
  private _physics: PhysicsHost | null = null;
  /** AIS-47: câmera de jogo por nó (controladores de personagem); a última entregue é a ativa. Descartável. */
  private readonly gameCameras = new Map<string, GameCameraPose>();
  /**
   * AIS-48b — ÚNICA contabilidade de inscrições do runtime (frame, input, física, sinais, cena), por owner. Os `Set`s abaixo só
   * despacham; quem cancela é o registry. Stop/Restart/troca de cena descartam o que é da cena; `dispose` descarta tudo.
   */
  private readonly subscriptionRegistry = new SubscriptionRegistry();
  private physicsListeners = new Set<{ name: PhysicsEventName | '*'; cb: (e: PhysicsEvent) => void }>();
  private nodeSignalListeners = new Set<(s: NodeSignalEvent) => void>();
  private frameListeners = new Set<(dt: number) => void>();
  private inputListeners = new Set<(input: RawInputReader) => void>();
  private signalListeners = new Set<{ name: string; cb: (name: string) => void }>();
  /** Cada runtime (início, restart, troca de cena) tem um número; a carga assíncrona do Rapier só anexa ao runtime que a pediu. */
  private runtimeEpoch = 0;
  private changing = false;
  private disposed = false;
  private teardowns = new Set<() => void>();
  private sceneListeners = new Set<(e: RuntimeSceneEvent) => void>();
  private readonly options: RuntimeSessionOptions;

  constructor(options: RuntimeSessionOptions) {
    this.options = options;
    this.id = `rsess_${Date.now().toString(36)}_${(++sessionCounter).toString(36)}`;
    this.mode = options.mode ?? 'scene';
    this._snapshot = options.snapshot;
  }

  // ── contrato ──────────────────────────────────────────────────────────────────────────────────

  public get status(): RuntimeSessionStatus {
    return this._status;
  }
  public get snapshot(): AuthoringSceneSnapshot {
    return this._snapshot;
  }
  public get elapsedTime(): number {
    return this._elapsed;
  }
  /** Cena viva atual; lança se a sessão já foi descartada (use `currentScene` para consulta tolerante). */
  public get scene(): RuntimeScene {
    const scene = this.sceneManager.current;
    if (!scene) throw new Error('RuntimeSession sem cena viva (ainda não iniciada ou já descartada).');
    return scene;
  }
  public get currentScene(): RuntimeScene | null {
    return this.sceneManager.current;
  }
  public get runner(): LogicRunner | null {
    return this._runner;
  }
  /** Ponte física do runtime atual (`null` = cena sem corpos, motor ainda carregando ou sessão encerrada). */
  public get physics(): PhysicsBridge | null {
    return this._physics?.bridge ?? null;
  }
  /**
   * AIS-48 — `onPhysicsEvent(name, cb) → unsubscribe`: ÚNICA porta de eventos físicos para Behaviors, Actions e scripts (o
   * `EngineApi` do AIS-78c a repassa). Sobrevive ao mundo físico carregar tarde, mas NÃO sobrevive à cena: Stop, Restart, troca de
   * cena e `dispose` cancelam todas as inscrições.
   */
  public onPhysicsEvent(name: PhysicsEventName | '*', cb: (e: PhysicsEvent) => void, owner: SubscriptionOwner = this.sceneOwner()): () => void {
    const listener = { name, cb };
    this.physicsListeners.add(listener);
    return this.subscriptionRegistry.add(owner, () => this.physicsListeners.delete(listener));
  }

  /** AIS-48: sinais de nó (`body_entered`/`body_exited`, com o `otherId`) — o barramento que o AIS-57 consome. */
  public onNodeSignal(cb: (s: NodeSignalEvent) => void, owner: SubscriptionOwner = this.sceneOwner()): () => void {
    this.nodeSignalListeners.add(cb);
    return this.subscriptionRegistry.add(owner, () => this.nodeSignalListeners.delete(cb));
  }

  /** AIS-48b: callback por quadro, DEPOIS da física (`step`/`stepFrame`). Devolve o `unsubscribe` (idempotente). */
  public onFrame(cb: (dt: number) => void, owner: SubscriptionOwner = this.sceneOwner()): () => void {
    this.frameListeners.add(cb);
    return this.subscriptionRegistry.add(owner, () => this.frameListeners.delete(cb));
  }

  /** AIS-48b: callback por quadro com o leitor de entrada, ANTES dos Behaviors. Devolve o `unsubscribe` (idempotente). */
  public onInput(cb: (input: RawInputReader) => void, owner: SubscriptionOwner = this.sceneOwner()): () => void {
    this.inputListeners.add(cb);
    return this.subscriptionRegistry.add(owner, () => this.inputListeners.delete(cb));
  }

  /** AIS-48b: assina um sinal emitido na cena (`emit_signal`). Devolve o `unsubscribe` (idempotente). */
  public onSignal(name: string, cb: (name: string) => void, owner: SubscriptionOwner = this.sceneOwner()): () => void {
    const listener = { name, cb };
    this.signalListeners.add(listener);
    return this.subscriptionRegistry.add(owner, () => this.signalListeners.delete(listener));
  }

  /** AIS-48b: inscrições ativas (total, de um tipo de dono ou de um dono). Só leitura: testes e depuração. */
  public subscriptionCount(filter: { owner?: SubscriptionOwner; kind?: SubscriptionOwnerKind } = {}): number {
    return this.subscriptionRegistry.count(filter);
  }

  /** AIS-48b: remove UM Behavior em execução e cancela só as inscrições dele (as dos outros donos seguem). */
  public removeBehavior(nodeId: string, behaviorId: string): boolean {
    return this._behaviors?.removeBehavior(nodeId, behaviorId) ?? false;
  }

  private sceneOwner(): SubscriptionOwner {
    return { kind: 'scene', id: 'scene' };
  }

  private emit<T>(set: Iterable<T>, call: (item: T) => void, what: string): void {
    for (const item of [...set]) {
      try {
        call(item);
      } catch (error) {
        this.publish('error', 'runtime.listener_failed', `Assinante de ${what} falhou: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
  }

  /** Um quadro, na ordem do tick; compartilhado por `step` e `stepFrame`. */
  private tick(dt: number): void {
    this.emit(this.inputListeners, (cb) => cb(this.options.input), 'entrada');
    // ordem do tick (skill nodimus-play-mode): comportamentos por propriedade, depois regras (Triggers/Actions)
    this._behaviors?.update(dt);
    this._runner?.step(dt);
    // intenção (Behaviors/regras) → física (passo fixo; corpo é o dono da pose) → instâncias → espelho no canvas
    this._physics?.step(dt);
    this._behaviors?.lateUpdate(dt);
    this.emit(this.frameListeners, (cb) => cb(dt), 'quadro');
  }

  private deliverPhysicsEvent(e: PhysicsEvent): void {
    for (const l of [...this.physicsListeners]) {
      if (l.name !== '*' && l.name !== e.name) continue;
      try {
        l.cb(e);
      } catch (error) {
        this.publish('error', 'physics.listener_failed', `Assinante de evento físico falhou: ${error instanceof Error ? error.message : String(error)}`, e.selfId, 'physics');
      }
    }
    const killFloor = e.name === 'killFloor';
    const signal = killFloor ? 'fell_out_of_world' : e.name === 'collisionEnter' || e.name === 'triggerEnter' ? 'body_entered' : 'body_exited';
    for (const cb of [...this.nodeSignalListeners]) {
      try {
        cb({ sourceNodeId: e.selfId, signal, args: killFloor ? [e.position?.y ?? 0] : [e.otherId] });
      } catch (error) {
        this.publish('error', 'physics.listener_failed', `Assinante de sinal falhou: ${error instanceof Error ? error.message : String(error)}`, e.selfId, 'physics');
      }
    }
  }

  /** AIS-47: câmera de jogo ativa (`null` = nenhum controlador: a viewport segue a câmera orbital do editor). */
  public get gameCamera(): GameCameraPose | null {
    let last: GameCameraPose | null = null;
    for (const pose of this.gameCameras.values()) last = pose;
    return last;
  }
  public get variables(): VariableManager | null {
    return this.sceneManager.variables;
  }
  /** Sessão ainda viva (nem parada nem descartada): relido depois de cada `await`. */
  private get isLive(): boolean {
    return !this.disposed && this._status !== 'stopped';
  }
  public get isDisposed(): boolean {
    return this.disposed;
  }

  public start(): void {
    if (this.disposed || this._status !== 'idle') return;
    this.sceneManager.beginSession(this.options.globals ?? []);
    this.sceneManager.load(this._snapshot);
    this.beginRuntime();
    this._status = 'running';
  }

  public pause(): void {
    if (this._status === 'running') this._status = 'paused';
  }

  public resume(): void {
    if (this._status === 'paused') this._status = 'running';
  }

  /** Um quadro de simulação. Em pausa (ou durante uma troca de cena) nada avança. */
  public step(deltaTime: number): void {
    if (this._status !== 'running' || this.changing) return;
    const dt = Number.isFinite(deltaTime) && deltaTime > 0 ? deltaTime : 0;
    this._elapsed += dt;
    this.tick(dt);
  }

  /**
   * AIS-46 — "Avançar 1 Quadro": roda EXATAMENTE um quadro de simulação (`deltaTime`, padrão 1/60 s = um passo fixo da física) e
   * continua pausada. Só vale em pausa; fora dela (ou durante uma troca de cena) não faz nada e devolve `false`.
   */
  public stepFrame(deltaTime = 1 / 60): boolean {
    if (this._status !== 'paused' || this.changing) return false;
    const dt = Number.isFinite(deltaTime) && deltaTime > 0 ? deltaTime : 1 / 60;
    this._elapsed += dt;
    this.tick(dt);
    return true;
  }

  /** Para a sessão: tudo o que ela possuía é liberado; o estado autoral nunca foi tocado. Idempotente. */
  public stop(): void {
    if (this._status === 'stopped' || this.disposed) return;
    this._status = 'stopped';
    this.endRuntime();
    this.subscriptionRegistry.disposeAll(); // AIS-48b: Stop zera TODAS as inscrições (inclusive as de dono `session`)
    this.sceneManager.unload();
    this.sceneManager.endSession();
  }

  /** `stop()` + descarte dos diagnósticos efêmeros (DEPOIS das assinaturas). Idempotente. */
  public dispose(): void {
    if (this.disposed) return;
    this.stop();
    this.disposed = true;
    this.sceneListeners.clear();
    this.subscriptionRegistry.disposeAll();
    this.options.diagnostics?.clearSession(this.id);
  }

  // ── cena: restart, troca, Behaviors ───────────────────────────────────────────────────────────

  /** Restart Scene: estado inicial da cena (locais restauradas do snapshot), globais PRESERVADAS. */
  public restartScene(): boolean {
    if (this.disposed || this._status === 'stopped' || !this.sceneManager.current) return false;
    this.endRuntime();
    this.sceneManager.restart();
    this.beginRuntime();
    return true;
  }

  /** Restart Behavior: recomeça só o par (nó × Behavior); a cena e os demais Behaviors/regras seguem como estão. */
  public restartBehavior(nodeId: string, behaviorId: string): boolean {
    if (this.disposed || this._status === 'stopped') return false;
    const restarted = this._behaviors?.restart(nodeId, behaviorId) ?? false;
    this._runner?.resetBehavior(nodeId, behaviorId);
    return restarted || (this._runner?.hasBehavior(nodeId, behaviorId) ?? false);
  }

  /**
   * Troca de cena. O destino é obtido ANTES de abortar (falha ao resolver = a cena atual continua intacta); depois:
   * abortar cadeias → dispose Behaviors → teardowns → limpar locais → globais preservadas → nova cena → lifecycle.
   */
  public async changeScene(target: string | AuthoringSceneSnapshot): Promise<{ committed: boolean; reason?: string }> {
    if (this.disposed || this._status === 'stopped') return { committed: false, reason: 'sessão encerrada' };
    if (this.changing) return { committed: false, reason: 'troca de cena já em andamento' };
    this.changing = true;
    try {
      let snapshot: AuthoringSceneSnapshot;
      if (typeof target === 'string') {
        if (!this.options.resolveScene) return this.failChange(`não há como carregar a cena "${target}" nesta sessão.`);
        try {
          snapshot = await this.options.resolveScene(target);
        } catch (error) {
          return this.failChange(`falha ao carregar "${target}": ${error instanceof Error ? error.message : String(error)}`);
        }
      } else {
        snapshot = target;
      }
      if (!this.isLive) return { committed: false, reason: 'sessão encerrada durante a troca' };

      this._runner?.abortChains();
      this.endRuntime();
      const result = await this.sceneManager.change(snapshot);
      if (result.committed) this._snapshot = snapshot;
      // sucesso OU falha ao construir (a cena antiga permanece): a sessão sempre volta a ter lifecycle e regras
      if (this.isLive) this.beginRuntime();
      return result.committed ? { committed: true } : { committed: false, reason: result.reason };
    } finally {
      this.changing = false;
    }
  }

  /**
   * Registra a limpeza de um sistema da cena (mundo físico, Workers, assinaturas): roda na troca/restart de cena e no
   * Stop. Devolve o disposer (cancela o registro sem executar).
   */
  public registerTeardown(fn: () => void): () => void {
    this.teardowns.add(fn);
    return () => {
      this.teardowns.delete(fn);
    };
  }

  /** Observa o ciclo da cena viva (loaded/unloaded/restarted…); devolve o disposer. */
  public onSceneEvent(listener: (e: RuntimeSceneEvent) => void): () => void {
    const off = this.sceneManager.subscribe(listener);
    this.sceneListeners.add(listener);
    return () => {
      off();
      this.sceneListeners.delete(listener);
    };
  }

  // ── pose simulada ─────────────────────────────────────────────────────────────────────────────

  /** Pose do RUNTIME (não a do authoring): é o que os consumidores veem durante o Play. `undefined` = sem instância viva. */
  public getSimulatedTransform(idOrNodeId: string): { position: [number, number, number]; rotation: [number, number, number]; scale: [number, number, number] } | undefined {
    const instance = this.sceneManager.current?.getInstance(idOrNodeId);
    if (!instance) return undefined;
    const t = instance.transform;
    return { position: [...t.position], rotation: [...t.rotation], scale: [...t.scale] };
  }

  // ── internos ──────────────────────────────────────────────────────────────────────────────────

  private failChange(reason: string): { committed: false; reason: string } {
    this.publish('error', 'logic.change_scene_failed', `Change Scene: ${reason}`);
    this.options.onLog?.({ time: this._runner?.sceneTime ?? 0, level: 'error', message: `Change Scene: ${reason}`, toOutput: true });
    return { committed: false, reason };
  }

  /** Cria o lifecycle dos Behaviors e o runner da cena viva ATUAL e inicia ambos. */
  private beginRuntime(): void {
    const scene = this.sceneManager.current;
    if (!scene) return;
    this.runtimeEpoch++;
    const states = new BehaviorRuntimeStates();
    const input = this.options.input;
    const variables = this.sceneManager.variables;
    const log = (level: 'info' | 'warn' | 'error', message: string, node?: { name: string; persistentNodeId: string; id?: string }, meta?: LogicLogMeta) =>
      this.handleLog({ time: this._runner?.sceneTime ?? 0, level, message, nodeName: node?.name, nodeId: node?.persistentNodeId, instanceId: node?.id, toOutput: level !== 'info', ...meta });
    const registry = this.subscriptionRegistry;
    const behaviors = new BehaviorLifecycleHost({
      scene,
      snapshot: this._snapshot,
      states,
      input,
      variables,
      sceneTime: () => this._runner?.sceneTime ?? 0,
      log,
      catalog: this.options.behaviorCatalog ?? BehaviorRuntimeCatalog,
      physics: () => this._physics?.bridge ?? null,
      subscriptions: {
        onPhysicsEvent: (owner, name, cb) => this.onPhysicsEvent(name, cb, owner),
        onFrame: (owner, cb) => this.onFrame(cb, owner),
        onInput: (owner, cb) => this.onInput(cb, owner),
        onSignal: (owner, name, cb) => this.onSignal(name, cb, owner),
        disposeOwner: (owner) => registry.disposeOwner(owner),
      },
      setGameCamera: (nodeId, pose) => {
        if (pose) this.gameCameras.set(nodeId, { ...pose, nodeId });
        else this.gameCameras.delete(nodeId);
      },
    });
    this._behaviors = behaviors;
    this._runner = new LogicRunner({
      scene,
      snapshot: this._snapshot,
      variables,
      input,
      random: this.options.random,
      verbose: this.options.verbose,
      behaviorStates: states,
      skipRules: (b) => behaviors.replacesRules(b),
      physics: () => this._physics?.bridge ?? null,
      host: {
        onLog: (entry) => this.handleLog(entry),
        onSignalEmitted: (name) => this.emit(this.signalListeners, (l) => (l.name === '*' || l.name === name) && l.cb(name), `sinal "${name}"`),
        onUiChanged: this.options.onUiChanged,
        onQuitGame: () => queueMicrotask(() => this.options.onQuitGame?.()),
        onRestartScene: () => queueMicrotask(() => this.restartScene()),
        onChangeScene: (path) => void this.changeScene(path),
      },
    });
    behaviors.attach();
    behaviors.playStart();
    this.attachPhysics();
  }

  /** Cria o mundo físico da cena viva (só se houver corpos). Se o Rapier ainda está carregando, entra quando terminar. */
  private attachPhysics(afterLoad = false): void {
    const scene = this.sceneManager.current;
    if (!scene || this._physics || !sceneHasPhysics(scene)) return;
    const R = (this.options.getRapier ?? getRapierIfReady)();
    if (!R && afterLoad) {
      this.publish('error', 'physics.engine_unavailable', 'O motor de física não ficou disponível; a cena segue sem corpos.', undefined, 'physics');
      return;
    }
    if (!R) {
      const epoch = this.runtimeEpoch;
      void ensureRapier().then(() => {
        if (epoch === this.runtimeEpoch && this.isLive) this.attachPhysics(true);
      }).catch((error) => this.publish('error', 'physics.engine_unavailable', `O motor de física não carregou: ${error instanceof Error ? error.message : String(error)}`, undefined, 'physics'));
      return;
    }
    const host = new PhysicsHost({
      R,
      scene,
      snapshot: this._snapshot,
      defaultLinearDamp: this.options.defaultLinearDamp,
      heightfieldOf: this.options.heightfieldOf,
      report: (issue, instance) => this.publishPhysicsIssue(issue, instance),
    });
    this._physics = host;
    // contatos e gatilhos → Triggers da lógica (um evento por participante; o gatilho usa os mesmos Triggers de colisão)
    host.bridge.onPhysicsEvent('*', (e) => {
      if (e.name !== 'killFloor') {
        const type = e.name === 'collisionEnter' ? 'on_collision_enter' : e.name === 'collisionExit' ? 'on_collision_exit' : e.name === 'triggerEnter' ? 'on_trigger_enter' : 'on_trigger_exit';
        this._runner?.dispatchContact(type, e.selfId, e.otherId, e.force);
      }
      this.deliverPhysicsEvent(e);
    });
  }

  private publishPhysicsIssue(issue: PhysicsIssue, instance: RuntimeInstance): void {
    this.options.onLog?.({ time: this._runner?.sceneTime ?? 0, level: issue.severity === 'error' ? 'error' : 'warn', message: `[${issue.code}] ${issue.message}`, nodeName: instance.name, nodeId: instance.persistentNodeId, toOutput: true });
    this.publish(issue.severity === 'error' ? 'error' : 'warning', issue.code, issue.message, instance.persistentNodeId, 'physics');
  }

  /** Descarta o runtime da cena atual: runner (assinaturas, timers, fila), Behaviors e sistemas registrados. */
  private endRuntime(): void {
    this._runner?.abortChains();
    this._behaviors?.dispose();
    this._behaviors = null;
    this.gameCameras.clear();
    // AIS-48b: nenhuma inscrição da CENA sobrevive a ela (Stop/restart/troca); as de dono `session` seguem até o Stop
    this.subscriptionRegistry.disposeAll(['session']);
    this._runner?.dispose();
    this._runner = null;
    // mundo físico destruído DEPOIS das cadeias/assinaturas (ordem de troca de cena, AIS-44b): world.free()
    this.runtimeEpoch++;
    this._physics?.dispose();
    this._physics = null;
    const teardowns = [...this.teardowns];
    this.teardowns.clear();
    for (const fn of teardowns) {
      try {
        fn();
      } catch (error) {
        this.publish('error', 'logic.teardown_failed', `Erro ao liberar um sistema da cena: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
  }

  private handleLog(entry: LogicLogEntry): void {
    this.options.onLog?.(entry);
    if (entry.level === 'info') return;
    const code = entry.code ?? (entry.level === 'error' ? 'logic.error' : 'logic.warning');
    this.publish(entry.level === 'error' ? 'error' : 'warning', code, entry.message, entry.nodeId, 'runtime', {
      phase: code.startsWith('physics.') ? 'physics' : 'runtime',
      instanceId: entry.instanceId,
      behaviorId: entry.behaviorId,
      logicId: entry.logicId,
    });
  }

  /**
   * Diagnóstico EFÊMERO (com `sessionId`): some no Stop; é o MESMO registro do `globalDiagnosticService` (AIS-32c), nunca um tipo ou
   * canal paralelo. O contexto de runtime (`instanceId`, `behaviorId`, `logicId`) vai no próprio registro.
   */
  private publish(severity: 'error' | 'warning', code: string, message: string, nodeId?: string, source: 'runtime' | 'physics' = 'runtime', context: { phase?: 'runtime' | 'physics'; instanceId?: string; behaviorId?: string; logicId?: string } = {}): void {
    const { phase = source, ...ids } = context;
    this.options.diagnostics?.report({ source, sourceId: this.id, severity, phase, code, message, nodeId, ...ids, sessionId: this.id }, { announce: false });
  }
}

// ── sessão ativa do editor ────────────────────────────────────────────────────────────────────────
// Um Play por vez: criar a próxima descarta a anterior (nunca duas sessões vivas, nunca dois loops).

let active: RuntimeSession | null = null;

export const getActiveRuntimeSession = (): RuntimeSession | null => active;

export function activateRuntimeSession(session: RuntimeSession | null): void {
  const previous = active;
  active = session;
  if (previous && previous !== session) previous.dispose();
}

/** Pose do runtime do nó na sessão ativa (consumidores de Play leem daqui; corpos físicos não escrevem no authoring). */
export const getSimulatedTransform = (idOrNodeId: string) => active?.getSimulatedTransform(idOrNodeId);
