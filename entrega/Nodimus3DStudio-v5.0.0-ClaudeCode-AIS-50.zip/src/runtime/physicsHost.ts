import * as THREE from 'three';
import type { AuthoringSceneSnapshot } from '../types/runtime';
import { measureLocalBounds, type Vec3 } from '../core/physics/bounds';
import { PhysicsBridge, type PoseSource } from '../core/physics/PhysicsBridge';
import { readPhysics } from '../core/physics/physicsConfig';
import { resolvePhysicsDescriptor, type HeightfieldData, type PhysicsIssue, type TriMesh } from '../core/physics/physicsDescriptor';
import type { RapierModule } from '../core/physics/rapierInit';
import type { RuntimeInstance, RuntimeScene } from './RuntimeScene';
import { terrainHeightfieldOf } from '../core/terrainObject';

/**
 * AIS-45 — PhysicsHost: liga o mundo físico (`PhysicsBridge`) à cena VIVA de uma `RuntimeSession`.
 *
 *  - ao criar, resolve um descritor por instância com `properties.physics` (`resolvePhysicsDescriptor`, a camada B única) usando a
 *    geometria e a pose MUNDIAL dos objetos vivos — nada de corpo para nó sem bloco ou com `enabled:false`;
 *  - a cada quadro roda o passo fixo da ponte e copia a pose simulada dos corpos `dynamic`/`character` para a instância de runtime
 *    (convertendo mundo → local pela cadeia de pais). A pose simulada vive só na instância: NUNCA volta ao authoring;
 *  - `kinematic`/`trigger`/`character` recebem da instância a pose que a lógica pediu (a intenção).
 *
 * O mundo só existe durante a sessão: `dispose()` libera o `World` do Rapier. Sem React, sem DOM.
 */

export interface PhysicsHostOptions {
  R: RapierModule;
  scene: RuntimeScene;
  snapshot: AuthoringSceneSnapshot;
  /** `settings.physics.defaultLinearDamp` do projeto (corpos `dynamic`). */
  defaultLinearDamp?: number;
  /** Problemas ao criar corpos (escala não uniforme, malha sem geometria…): a sessão publica como diagnóstico efêmero. */
  report: (issue: PhysicsIssue, instance: RuntimeInstance) => void;
  /** Buffer de alturas do terreno de um nó (decisão 23; o AIS-50 fornece). Ausente = nó com `heightfield` fica sem corpo, com aviso. */
  heightfieldOf?: (instance: RuntimeInstance) => HeightfieldData | null;
}

const isVec = (g: any): g is Vec3 => !!g && Number.isFinite(g.x) && Number.isFinite(g.y) && Number.isFinite(g.z);

/** Gravidade da SCENE (decisão 17): `environmentSettings.gravity` do snapshot (plano ou aninhado em `environment`); padrão -9.8 em Y. */
export function gravityOf(snapshot: AuthoringSceneSnapshot): Vec3 {
  const settings = snapshot.sceneSettings as any;
  const g = settings?.gravity ?? settings?.environment?.gravity;
  return isVec(g) ? { x: g.x, y: g.y, z: g.z } : { x: 0, y: -9.8, z: 0 };
}

const _p = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _s = new THREE.Vector3();
const _m = new THREE.Matrix4();
const _inv = new THREE.Matrix4();

/** Há algum nó com bloco de física ligado? (a sessão só carrega o Rapier/mundo se houver) */
export function sceneHasPhysics(scene: RuntimeScene): boolean {
  return scene.getAllInstances().some((i) => {
    const cfg = readPhysics(i.properties);
    return !!cfg && cfg.enabled;
  });
}

function trianglesOf(object: THREE.Object3D, worldScale: Vec3): TriMesh | null {
  object.updateWorldMatrix(true, true);
  const inverse = object.matrixWorld.clone().invert();
  const vertices: number[] = [];
  const indices: number[] = [];
  object.traverse((child) => {
    const mesh = child as THREE.Mesh;
    if (!mesh.isMesh || !mesh.geometry) return;
    const position = mesh.geometry.getAttribute('position');
    if (!position) return;
    const toNode = inverse.clone().multiply(mesh.matrixWorld);
    const base = vertices.length / 3;
    const v = new THREE.Vector3();
    for (let i = 0; i < position.count; i++) {
      v.fromBufferAttribute(position, i).applyMatrix4(toNode);
      vertices.push(v.x * worldScale.x, v.y * worldScale.y, v.z * worldScale.z); // o Rapier não escala colisores
    }
    const index = mesh.geometry.getIndex();
    if (index) for (let i = 0; i < index.count; i++) indices.push(base + index.getX(i));
    else for (let i = 0; i < position.count; i++) indices.push(base + i);
  });
  if (vertices.length < 9 || indices.length < 3) return null;
  return { vertices: new Float32Array(vertices), indices: new Uint32Array(indices) };
}

export class PhysicsHost {
  readonly bridge: PhysicsBridge;
  private readonly scene: RuntimeScene;
  private readonly byNode = new Map<string, RuntimeInstance>();

  constructor(options: PhysicsHostOptions) {
    const { R, scene, snapshot } = options;
    this.scene = scene;
    this.bridge = new PhysicsBridge(R, { gravity: gravityOf(snapshot) });
    scene.rootObject.updateMatrixWorld(true);

    for (const instance of scene.getAllInstances()) {
      const object = instance.object;
      if (!object) continue;
      object.updateWorldMatrix(true, false);
      object.matrixWorld.decompose(_p, _q, _s);
      const worldScale = { x: Math.abs(_s.x), y: Math.abs(_s.y), z: Math.abs(_s.z) };
      const config = readPhysics(instance.properties);
      const wantsMesh = config?.enabled && (config.shape === 'mesh' || (config.shape === 'auto' && config.bodyMode === 'static' && instance.properties.meshType === 'TorusMesh'));
      const result = resolvePhysicsDescriptor({
        nodeId: instance.persistentNodeId,
        name: instance.name,
        nodeType: instance.type,
        properties: instance.properties,
        bounds: measureLocalBounds(object),
        worldScale,
        worldPosition: { x: _p.x, y: _p.y, z: _p.z },
        worldRotation: { x: _q.x, y: _q.y, z: _q.z, w: _q.w },
        triangles: wantsMesh ? trianglesOf(object, worldScale) : null,
        heightfield: (options.heightfieldOf ?? ((i: RuntimeInstance) => terrainHeightfieldOf(i.object)))(instance),
        defaultLinearDamp: options.defaultLinearDamp,
      });
      for (const issue of result.issues) options.report(issue, instance);
      if (!result.descriptor) continue;
      try {
        this.bridge.addBody(result.descriptor);
        this.byNode.set(instance.persistentNodeId, instance);
      } catch (error) {
        options.report({ code: 'physics.invalid_config', severity: 'error', nodeId: instance.persistentNodeId, message: `"${instance.name}": ${error instanceof Error ? error.message : String(error)}` }, instance);
      }
    }
  }

  /** Pose MUNDIAL que a lógica pediu para o nó (a da instância de runtime, já com a hierarquia). */
  private poseSource: PoseSource = (nodeId) => {
    const instance = this.byNode.get(nodeId);
    const object = instance?.object;
    if (!instance || instance.disposed || !object) return null;
    object.updateWorldMatrix(true, false);
    object.matrixWorld.decompose(_p, _q, _s);
    return { position: { x: _p.x, y: _p.y, z: _p.z }, rotation: { x: _q.x, y: _q.y, z: _q.z, w: _q.w } };
  };

  /** Quadro de simulação: passo fixo + cópia da pose simulada para as instâncias (só se algum passo rodou). */
  step(dt: number): void {
    if (this.bridge.isDisposed) return;
    const steps = this.bridge.step(dt, this.poseSource);
    if (steps === 0) return;
    // Kill Floor (AIS-49): o corpo já foi removido (depois do evento `killFloor`); a instância some junto
    for (const nodeId of this.bridge.takeDiscarded()) {
      const instance = this.byNode.get(nodeId);
      this.byNode.delete(nodeId);
      if (instance && !instance.disposed) this.scene.destroyInstance(instance.id);
    }
    this.bridge.forEachSimulated((nodeId, pose) => {
      const instance = this.byNode.get(nodeId);
      if (!instance || instance.disposed || !instance.object) return;
      this.writeWorldPose(instance, pose.position, pose.rotation);
    });
  }

  /** Mundo → local pela cadeia de pais; nunca toca o authoring. Mantém a escala da instância. */
  writeWorldPose(instance: RuntimeInstance, position: Vec3, rotation: { x: number; y: number; z: number; w: number }): void {
    const object = instance.object;
    if (!object) return;
    object.parent?.updateWorldMatrix(true, false);
    const parentWorld = object.parent ? object.parent.matrixWorld : _m.identity();
    _inv.copy(parentWorld).invert();
    const world = new THREE.Matrix4().compose(new THREE.Vector3(position.x, position.y, position.z), new THREE.Quaternion(rotation.x, rotation.y, rotation.z, rotation.w), new THREE.Vector3(1, 1, 1));
    const local = _inv.multiply(world);
    local.decompose(_p, _q, _s);
    const euler = new THREE.Euler().setFromQuaternion(_q, 'XYZ');
    instance.transform.position = [_p.x, _p.y, _p.z];
    instance.transform.rotation = [THREE.MathUtils.radToDeg(euler.x), THREE.MathUtils.radToDeg(euler.y), THREE.MathUtils.radToDeg(euler.z)];
    this.scene.applyInstanceTransform(instance);
  }

  /** Mundo físico liberado (`world.free()`); idempotente. */
  dispose(): void {
    this.bridge.dispose();
    this.byNode.clear();
  }
}
