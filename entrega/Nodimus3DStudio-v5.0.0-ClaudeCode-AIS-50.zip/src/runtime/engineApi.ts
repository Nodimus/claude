import type { PhysicsEvent, PhysicsEventName } from '../core/physics/PhysicsBridge';
import type { RuntimeSession } from './RuntimeSession';

/**
 * AIS-48 — adaptador MÍNIMO e provisório do `EngineApi` (o contrato completo, com `CapabilityRegistry` e handles estáveis, é do
 * AIS-78c e AMPLIA esta interface; nada aqui o contradiz). Hoje expõe só o que o AIS-48 pede: `onPhysicsEvent(name, cb) → unsubscribe`.
 *
 * Toda inscrição é da SESSÃO: Stop, Restart, troca de cena e `dispose` cancelam todas (nenhuma sobrevive à cena). Eventos são
 * Enter/Exit com `selfId`/`otherId` (`collisionEnter` traz ponto, normal e `force`; gatilhos não); não existe "Stay".
 */
export interface EngineApi {
  onPhysicsEvent(name: PhysicsEventName | '*', cb: (event: PhysicsEvent) => void): () => void;
}

export function createEngineApi(session: RuntimeSession): EngineApi {
  return {
    onPhysicsEvent: (name, cb) => session.onPhysicsEvent(name, cb),
  };
}
