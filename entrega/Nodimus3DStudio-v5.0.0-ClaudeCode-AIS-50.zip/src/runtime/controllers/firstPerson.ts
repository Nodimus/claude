import { clamp, finite, normalizeAxes, planarBasis, quatFromYawPitch, smoothingFactor, type Quat, type V3 } from './controllerMath';

/**
 * AIS-47 — FirstPersonController (puro): olhar com mouse + movimento WASD relativo ao olhar. Só calcula INTENÇÃO (deslocamento
 * horizontal e ângulos); gravidade, colisão e chão são do `PhysicsBridge` (`character` = `KinematicCharacterController`), nunca daqui.
 */

export interface FirstPersonParams {
  /** m/s */
  moveSpeed: number;
  /** graus por pixel do mouse */
  rotateSpeed: number;
  /** m/s na saída do chão */
  jumpSpeed: number;
  /** limite do olhar para cima/baixo, em graus */
  maxVerticalAngle: number;
  /** altura dos olhos acima da origem do nó */
  eyeHeight: number;
  /** 0 = resposta imediata; maior = aceleração mais suave (1/s) */
  smoothing: number;
  fov: number;
}

export const FIRST_PERSON_DEFAULTS: FirstPersonParams = { moveSpeed: 5, rotateSpeed: 0.15, jumpSpeed: 6, maxVerticalAngle: 85, eyeHeight: 1.6, smoothing: 0, fov: 70 };

export function readFirstPersonParams(raw: Record<string, any> | undefined): FirstPersonParams {
  const d = FIRST_PERSON_DEFAULTS;
  return {
    moveSpeed: Math.max(0, finite(raw?.moveSpeed, d.moveSpeed)),
    rotateSpeed: Math.max(0, finite(raw?.rotateSpeed, d.rotateSpeed)),
    jumpSpeed: Math.max(0, finite(raw?.jumpSpeed, d.jumpSpeed)),
    maxVerticalAngle: clamp(finite(raw?.maxVerticalAngle, d.maxVerticalAngle), 1, 89.9),
    eyeHeight: finite(raw?.eyeHeight, d.eyeHeight),
    smoothing: Math.max(0, finite(raw?.smoothing, d.smoothing)),
    fov: clamp(finite(raw?.fov, d.fov), 10, 150),
  };
}

export interface FirstPersonState {
  yaw: number;
  pitch: number;
  vx: number;
  vz: number;
}

export const initialFirstPersonState = (yawDeg = 0): FirstPersonState => ({ yaw: yawDeg, pitch: 0, vx: 0, vz: 0 });

export interface FirstPersonInput {
  /** +1 = para frente (MoveForward), -1 = para trás. */
  forward: number;
  /** +1 = para a direita (MoveRight), -1 = esquerda. */
  strafe: number;
  /** Deslocamento do mouse neste quadro, em pixels. */
  lookDx: number;
  lookDy: number;
}

/** Um quadro: devolve o novo estado e o deslocamento MUNDIAL horizontal a pedir à física. */
export function stepFirstPerson(state: FirstPersonState, params: FirstPersonParams, input: FirstPersonInput, dt: number): { state: FirstPersonState; delta: V3 } {
  const yaw = state.yaw - input.lookDx * params.rotateSpeed; // mouse para a direita = virar para a direita
  const pitch = clamp(state.pitch - input.lookDy * params.rotateSpeed, -params.maxVerticalAngle, params.maxVerticalAngle); // mouse para baixo = olhar para baixo
  const axes = normalizeAxes(clamp(input.forward, -1, 1), clamp(input.strafe, -1, 1));
  const { forward, right } = planarBasis(yaw);
  const wantX = (forward.x * axes.forward + right.x * axes.strafe) * params.moveSpeed;
  const wantZ = (forward.z * axes.forward + right.z * axes.strafe) * params.moveSpeed;
  const k = params.smoothing > 0 ? smoothingFactor(params.smoothing, dt) : 1;
  const vx = state.vx + (wantX - state.vx) * k;
  const vz = state.vz + (wantZ - state.vz) * k;
  return { state: { yaw, pitch, vx, vz }, delta: { x: vx * dt, y: 0, z: vz * dt } };
}

/** Pose da câmera: olhos na altura `eyeHeight` acima da origem do personagem, orientação yaw/pitch. */
export function firstPersonCamera(position: V3, state: FirstPersonState, params: FirstPersonParams): { position: V3; quaternion: Quat } {
  return { position: { x: position.x, y: position.y + params.eyeHeight, z: position.z }, quaternion: quatFromYawPitch(state.yaw, state.pitch) };
}
