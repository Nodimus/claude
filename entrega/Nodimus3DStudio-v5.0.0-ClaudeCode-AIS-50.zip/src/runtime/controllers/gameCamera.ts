import type { Quat, V3 } from './controllerMath';

/**
 * AIS-47 — pose da CÂMERA DE JOGO que um controlador (Behavior de personagem) entrega à `RuntimeSession`. A viewport a aplica
 * por cima da câmera orbital do editor SÓ no Play e SÓ quando existe um controlador (cenas sem controlador seguem como antes).
 * É estado de runtime descartável: nunca vai ao authoring.
 */
export interface GameCameraPose {
  /** Pose MUNDIAL da câmera. */
  position: V3;
  quaternion: Quat;
  /** Campo de visão vertical em graus (ausente = o da câmera do editor). */
  fov?: number;
  /** O controlador usa olhar com mouse (PointerLock): a viewport captura o ponteiro no primeiro clique do Play. */
  pointerLock: boolean;
  /** Nó dono (diagnóstico e depuração). */
  nodeId: string;
}
