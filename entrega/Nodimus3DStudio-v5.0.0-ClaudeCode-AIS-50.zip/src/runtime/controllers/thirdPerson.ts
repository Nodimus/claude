import { clamp, finite, lerpAngleDeg, lookAngles, normalizeAxes, planarBasis, quatFromYawPitch, smoothingFactor, DEG, RAD, type Quat, type V3 } from './controllerMath';

/**
 * AIS-47 — ThirdPersonController (puro): câmera orbital que segue o personagem com suavização elástica (lerp) e personagem que se
 * volta para a direção do movimento. O movimento é relativo à câmera. Só INTENÇÃO: gravidade/colisão são do `PhysicsBridge`.
 * (Oclusão da câmera por parede — `CollidesWithWorld` — exige shape cast e NÃO é executada aqui: fica "em breve".)
 */

export interface ThirdPersonParams {
  moveSpeed: number;
  jumpSpeed: number;
  /** graus por pixel do mouse (órbita com o botão direito) */
  rotateSpeed: number;
  /** distância da câmera ao alvo */
  distance: number;
  /** altura do ponto olhado acima da origem do personagem */
  targetHeight: number;
  /** velocidade do seguimento elástico (1/s); 0 = a câmera não segue */
  followSmoothingSpeed: number;
  /** velocidade com que o personagem vira para a direção do movimento (1/s) */
  turnSpeed: number;
  minPitch: number;
  maxPitch: number;
  fov: number;
}

export const THIRD_PERSON_DEFAULTS: ThirdPersonParams = {
  moveSpeed: 5,
  jumpSpeed: 6,
  rotateSpeed: 0.3,
  distance: 6,
  targetHeight: 1.4,
  followSmoothingSpeed: 6,
  turnSpeed: 12,
  minPitch: -10,
  maxPitch: 80,
  fov: 60,
};

export function readThirdPersonParams(raw: Record<string, any> | undefined): ThirdPersonParams {
  const d = THIRD_PERSON_DEFAULTS;
  const minPitch = clamp(finite(raw?.minPitch, d.minPitch), -89, 89);
  return {
    moveSpeed: Math.max(0, finite(raw?.moveSpeed, d.moveSpeed)),
    jumpSpeed: Math.max(0, finite(raw?.jumpSpeed, d.jumpSpeed)),
    rotateSpeed: Math.max(0, finite(raw?.rotateSpeed, d.rotateSpeed)),
    distance: Math.max(0.5, finite(raw?.distance, d.distance)),
    targetHeight: finite(raw?.targetHeight, d.targetHeight),
    followSmoothingSpeed: Math.max(0, finite(raw?.followSmoothingSpeed, d.followSmoothingSpeed)),
    turnSpeed: Math.max(0, finite(raw?.turnSpeed, d.turnSpeed)),
    minPitch,
    maxPitch: clamp(finite(raw?.maxPitch, d.maxPitch), minPitch, 89),
    fov: clamp(finite(raw?.fov, d.fov), 10, 150),
  };
}

export interface ThirdPersonState {
  /** Órbita (graus): yaw em torno do personagem e elevação da câmera. */
  orbitYaw: number;
  orbitPitch: number;
  /** Para onde o personagem está virado (yaw, graus). */
  faceYaw: number;
  /** Posição suavizada da câmera; `null` até o primeiro quadro (a câmera nasce no ponto ideal, sem "voar" até ele). */
  camera: V3 | null;
}

export const initialThirdPersonState = (yawDeg = 0): ThirdPersonState => ({ orbitYaw: yawDeg, orbitPitch: 20, faceYaw: yawDeg, camera: null });

export interface ThirdPersonInput {
  forward: number;
  strafe: number;
  /** Mouse neste quadro; só orbita com `orbiting` (botão direito segurado). */
  lookDx: number;
  lookDy: number;
  orbiting: boolean;
}

/** Deslocamento MUNDIAL horizontal pedido à física, a rotação do personagem e a órbita atualizada. */
export function stepThirdPerson(state: ThirdPersonState, params: ThirdPersonParams, input: ThirdPersonInput, dt: number): { state: ThirdPersonState; delta: V3; moving: boolean } {
  let { orbitYaw, orbitPitch } = state;
  if (input.orbiting) {
    orbitYaw -= input.lookDx * params.rotateSpeed;
    orbitPitch = clamp(orbitPitch + input.lookDy * params.rotateSpeed, params.minPitch, params.maxPitch);
  }
  const axes = normalizeAxes(clamp(input.forward, -1, 1), clamp(input.strafe, -1, 1));
  const { forward, right } = planarBasis(orbitYaw); // relativo à CÂMERA, não ao personagem
  const dirX = forward.x * axes.forward + right.x * axes.strafe;
  const dirZ = forward.z * axes.forward + right.z * axes.strafe;
  const moving = Math.hypot(dirX, dirZ) > 1e-6;
  let faceYaw = state.faceYaw;
  if (moving) {
    const target = Math.atan2(-dirX, -dirZ) * RAD; // o personagem olha para onde anda
    faceYaw = lerpAngleDeg(faceYaw, target, smoothingFactor(params.turnSpeed, dt));
  }
  return {
    state: { orbitYaw, orbitPitch, faceYaw, camera: state.camera },
    delta: { x: dirX * params.moveSpeed * dt, y: 0, z: dirZ * params.moveSpeed * dt },
    moving,
  };
}

/** Câmera orbital: ponto ideal atrás do alvo, aproximação elástica (independente da taxa de quadros) e olhar para o alvo. */
export function thirdPersonCamera(position: V3, state: ThirdPersonState, params: ThirdPersonParams, dt: number): { state: ThirdPersonState; position: V3; quaternion: Quat } {
  const target: V3 = { x: position.x, y: position.y + params.targetHeight, z: position.z };
  const yaw = state.orbitYaw * DEG;
  const pitch = state.orbitPitch * DEG;
  const ideal: V3 = {
    x: target.x + params.distance * Math.sin(yaw) * Math.cos(pitch),
    y: target.y + params.distance * Math.sin(pitch),
    z: target.z + params.distance * Math.cos(yaw) * Math.cos(pitch),
  };
  const prev = state.camera;
  const k = smoothingFactor(params.followSmoothingSpeed, dt);
  const cam: V3 = prev ? { x: prev.x + (ideal.x - prev.x) * k, y: prev.y + (ideal.y - prev.y) * k, z: prev.z + (ideal.z - prev.z) * k } : ideal;
  const look = lookAngles(cam, target);
  return { state: { ...state, camera: cam }, position: cam, quaternion: quatFromYawPitch(look.yaw, look.pitch) };
}
