import { describe, expect, it } from 'vitest';
import { clamp, lerpAngleDeg, lookAngles, normalizeAxes, planarBasis, quatFromYawPitch, rotateByQuat, smoothingFactor, wrapDeg } from './controllerMath';
import { FIRST_PERSON_DEFAULTS, firstPersonCamera, initialFirstPersonState, readFirstPersonParams, stepFirstPerson } from './firstPerson';
import { THIRD_PERSON_DEFAULTS, initialThirdPersonState, readThirdPersonParams, stepThirdPerson, thirdPersonCamera } from './thirdPerson';

/** AIS-47 — matemática pura dos controladores (sem Three/Rapier/DOM). */

describe('controllerMath', () => {
  it('wrapDeg e lerpAngleDeg usam o caminho mais curto', () => {
    expect(wrapDeg(190)).toBeCloseTo(-170);
    expect(wrapDeg(-190)).toBeCloseTo(170);
    expect(wrapDeg(540)).toBe(180);
    expect(lerpAngleDeg(350, 10, 0.5)).toBeCloseTo(360); // passa por 0°, não por 180°
    expect(lerpAngleDeg(10, 350, 0.5)).toBeCloseTo(0);
    expect(lerpAngleDeg(0, 90, 1)).toBeCloseTo(90);
    expect(lerpAngleDeg(0, 90, 0)).toBe(0);
  });

  it('smoothingFactor é independente da taxa de quadros (dois quadros de dt/2 = um de dt)', () => {
    const one = smoothingFactor(6, 1 / 30);
    const half = smoothingFactor(6, 1 / 60);
    expect(1 - (1 - half) * (1 - half)).toBeCloseTo(one, 10);
    expect(smoothingFactor(0, 1)).toBe(0);
    expect(smoothingFactor(5, 0)).toBe(0);
  });

  it('planarBasis: yaw 0 olha para -Z; yaw 90 olha para -X; right é perpendicular', () => {
    const a = planarBasis(0);
    expect(a.forward.z).toBeCloseTo(-1);
    expect(a.right.x).toBeCloseTo(1);
    const b = planarBasis(90);
    expect(b.forward.x).toBeCloseTo(-1);
    expect(b.forward.x * b.right.x + b.forward.z * b.right.z).toBeCloseTo(0);
  });

  it('quatFromYawPitch aponta o -Z da câmera para onde o yaw/pitch dizem', () => {
    const f0 = rotateByQuat({ x: 0, y: 0, z: -1 }, quatFromYawPitch(0, 0));
    expect(f0.z).toBeCloseTo(-1);
    const f90 = rotateByQuat({ x: 0, y: 0, z: -1 }, quatFromYawPitch(90, 0));
    expect(f90.x).toBeCloseTo(-1);
    const up = rotateByQuat({ x: 0, y: 0, z: -1 }, quatFromYawPitch(0, 45));
    expect(up.y).toBeCloseTo(Math.SQRT1_2);
    expect(up.z).toBeCloseTo(-Math.SQRT1_2);
  });

  it('lookAngles é o inverso do quaternion (olhar de A para B)', () => {
    const { yaw, pitch } = lookAngles({ x: 0, y: 0, z: 0 }, { x: -3, y: 3, z: -3 });
    const dir = rotateByQuat({ x: 0, y: 0, z: -1 }, quatFromYawPitch(yaw, pitch));
    const len = Math.hypot(3, 3, 3);
    expect(dir.x).toBeCloseTo(-3 / len);
    expect(dir.y).toBeCloseTo(3 / len);
    expect(dir.z).toBeCloseTo(-3 / len);
  });

  it('normalizeAxes: a diagonal não é mais rápida', () => {
    expect(normalizeAxes(1, 1).forward).toBeCloseTo(Math.SQRT1_2);
    expect(normalizeAxes(0.5, 0)).toEqual({ forward: 0.5, strafe: 0 });
    expect(clamp(5, 0, 1)).toBe(1);
  });
});

describe('FirstPersonController (puro)', () => {
  const idle = { forward: 0, strafe: 0, lookDx: 0, lookDy: 0 };

  it('WASD é relativo ao olhar: para frente em yaw 0 vai a -Z; depois de virar 90°, vai a -X', () => {
    const p = readFirstPersonParams({ moveSpeed: 4 });
    const a = stepFirstPerson(initialFirstPersonState(0), p, { ...idle, forward: 1 }, 0.5);
    expect(a.delta.z).toBeCloseTo(-2);
    expect(a.delta.x).toBeCloseTo(0);
    const b = stepFirstPerson(initialFirstPersonState(90), p, { ...idle, forward: 1 }, 0.5);
    expect(b.delta.x).toBeCloseTo(-2);
    expect(b.delta.z).toBeCloseTo(0, 6);
    const strafe = stepFirstPerson(initialFirstPersonState(0), p, { ...idle, strafe: 1 }, 0.5);
    expect(strafe.delta.x).toBeCloseTo(2); // direita
    const diag = stepFirstPerson(initialFirstPersonState(0), p, { ...idle, forward: 1, strafe: 1 }, 1);
    expect(Math.hypot(diag.delta.x, diag.delta.z)).toBeCloseTo(4); // não passa de moveSpeed
  });

  it('mouse: direita gira para a direita (yaw cai), baixo olha para baixo; o pitch é limitado', () => {
    const p = readFirstPersonParams({ rotateSpeed: 0.1, maxVerticalAngle: 80 });
    const r = stepFirstPerson(initialFirstPersonState(0), p, { ...idle, lookDx: 100 }, 0.016);
    expect(r.state.yaw).toBeCloseTo(-10);
    const d = stepFirstPerson(initialFirstPersonState(0), p, { ...idle, lookDy: 100 }, 0.016);
    expect(d.state.pitch).toBeCloseTo(-10);
    const clamped = stepFirstPerson(initialFirstPersonState(0), p, { ...idle, lookDy: -100000 }, 0.016);
    expect(clamped.state.pitch).toBe(80);
    const clampedDown = stepFirstPerson(initialFirstPersonState(0), p, { ...idle, lookDy: 100000 }, 0.016);
    expect(clampedDown.state.pitch).toBe(-80);
  });

  it('smoothing acelera gradualmente; sem smoothing é imediato', () => {
    const smooth = readFirstPersonParams({ moveSpeed: 10, smoothing: 8 });
    const first = stepFirstPerson(initialFirstPersonState(0), smooth, { ...idle, forward: 1 }, 1 / 60);
    expect(Math.abs(first.state.vz)).toBeGreaterThan(0);
    expect(Math.abs(first.state.vz)).toBeLessThan(10);
    const instant = stepFirstPerson(initialFirstPersonState(0), readFirstPersonParams({ moveSpeed: 10 }), { ...idle, forward: 1 }, 1 / 60);
    expect(instant.state.vz).toBeCloseTo(-10);
  });

  it('a câmera fica na altura dos olhos e olha na direção do yaw/pitch', () => {
    const p = readFirstPersonParams({ eyeHeight: 1.7 });
    const cam = firstPersonCamera({ x: 1, y: 2, z: 3 }, { yaw: 90, pitch: 0, vx: 0, vz: 0 }, p);
    expect(cam.position).toEqual({ x: 1, y: 3.7, z: 3 });
    expect(rotateByQuat({ x: 0, y: 0, z: -1 }, cam.quaternion).x).toBeCloseTo(-1);
  });

  it('parâmetros inválidos/ausentes viram os padrões e nunca NaN', () => {
    const p = readFirstPersonParams({ moveSpeed: 'x', rotateSpeed: NaN, maxVerticalAngle: 500, fov: -3 });
    expect(p.moveSpeed).toBe(FIRST_PERSON_DEFAULTS.moveSpeed);
    expect(p.rotateSpeed).toBe(FIRST_PERSON_DEFAULTS.rotateSpeed);
    expect(p.maxVerticalAngle).toBeLessThan(90);
    expect(p.fov).toBe(10);
    expect(readFirstPersonParams(undefined)).toEqual(FIRST_PERSON_DEFAULTS);
  });
});

describe('ThirdPersonController (puro)', () => {
  const idle = { forward: 0, strafe: 0, lookDx: 0, lookDy: 0, orbiting: false };

  it('o movimento é relativo à CÂMERA e o personagem se volta para a direção do movimento (com suavização)', () => {
    const p = readThirdPersonParams({ moveSpeed: 4, turnSpeed: 10 });
    // câmera atrás do personagem (orbitYaw 0): "para frente" = -Z
    let s = initialThirdPersonState(0);
    s = { ...s, faceYaw: 90 }; // virado para o lado
    const a = stepThirdPerson(s, p, { ...idle, forward: 1 }, 1 / 60);
    expect(a.delta.z).toBeLessThan(0);
    expect(a.moving).toBe(true);
    expect(a.state.faceYaw).toBeLessThan(90); // começou a virar para 0° (olhando -Z)
    expect(a.state.faceYaw).toBeGreaterThan(0); // mas SEM saltar (lerp)
    // depois de muitos quadros converge
    let t = a.state;
    for (let i = 0; i < 120; i++) t = stepThirdPerson(t, p, { ...idle, forward: 1 }, 1 / 60).state;
    expect(t.faceYaw).toBeCloseTo(0, 1);
    // órbita a 90°: "para frente" passa a ser -X
    const side = stepThirdPerson({ ...initialThirdPersonState(0), orbitYaw: 90 }, p, { ...idle, forward: 1 }, 0.5);
    expect(side.delta.x).toBeCloseTo(-2);
  });

  it('sem entrada o personagem não gira nem anda', () => {
    const p = readThirdPersonParams({});
    const r = stepThirdPerson({ ...initialThirdPersonState(0), faceYaw: 33 }, p, idle, 0.1);
    expect(r.moving).toBe(false);
    expect(r.state.faceYaw).toBe(33);
    expect(Math.hypot(r.delta.x, r.delta.y, r.delta.z)).toBe(0);
  });

  it('a órbita só responde ao mouse com o botão direito e o pitch é limitado', () => {
    const p = readThirdPersonParams({ rotateSpeed: 0.5, minPitch: -5, maxPitch: 60 });
    const none = stepThirdPerson(initialThirdPersonState(0), p, { ...idle, lookDx: 100, lookDy: 100 }, 0.016);
    expect(none.state.orbitYaw).toBe(0);
    const drag = stepThirdPerson(initialThirdPersonState(0), p, { ...idle, lookDx: 100, lookDy: 10, orbiting: true }, 0.016);
    expect(drag.state.orbitYaw).toBeCloseTo(-50);
    expect(drag.state.orbitPitch).toBeCloseTo(25);
    expect(stepThirdPerson(initialThirdPersonState(0), p, { ...idle, lookDy: 1e6, orbiting: true }, 0.016).state.orbitPitch).toBe(60);
    expect(stepThirdPerson(initialThirdPersonState(0), p, { ...idle, lookDy: -1e6, orbiting: true }, 0.016).state.orbitPitch).toBe(-5);
  });

  it('a câmera nasce no ponto ideal (sem voar), segue com atraso elástico e converge; olha para o alvo', () => {
    const p = readThirdPersonParams({ distance: 6, targetHeight: 1, followSmoothingSpeed: 5 });
    const s0 = { ...initialThirdPersonState(0), orbitPitch: 0 };
    const c0 = thirdPersonCamera({ x: 0, y: 0, z: 0 }, s0, p, 1 / 60);
    expect(c0.position.z).toBeCloseTo(6); // atrás de quem olha para -Z
    expect(c0.position.y).toBeCloseTo(1);
    // o personagem se afasta 10 m: a câmera segue com atraso, mas se aproxima a cada quadro
    let st = c0.state;
    const target = { x: 10, y: 0, z: 0 };
    let last = Infinity;
    const lags: number[] = [];
    for (let i = 0; i < 90; i++) {
      const c = thirdPersonCamera(target, st, p, 1 / 60);
      st = c.state;
      const ideal = 10;
      lags.push(Math.abs(ideal - c.position.x));
      expect(lags[i]).toBeLessThanOrEqual(last + 1e-9);
      last = lags[i];
    }
    expect(lags[0]).toBeGreaterThan(5); // elástico: no 1º quadro ainda está longe
    expect(lags[lags.length - 1]).toBeLessThan(0.2); // converge
    const final = thirdPersonCamera(target, st, p, 1 / 60);
    const dir = rotateByQuat({ x: 0, y: 0, z: -1 }, final.quaternion);
    const to = { x: target.x - final.position.x, y: target.y + 1 - final.position.y, z: target.z - final.position.z };
    const len = Math.hypot(to.x, to.y, to.z);
    expect(dir.x).toBeCloseTo(to.x / len, 2);
    expect(dir.y).toBeCloseTo(to.y / len, 2);
    expect(dir.z).toBeCloseTo(to.z / len, 2);
  });

  it('followSmoothingSpeed 0 = a câmera não segue; parâmetros inválidos viram padrões', () => {
    const p = readThirdPersonParams({ followSmoothingSpeed: 0, distance: 6, targetHeight: 0 });
    const c0 = thirdPersonCamera({ x: 0, y: 0, z: 0 }, { ...initialThirdPersonState(0), orbitPitch: 0 }, p, 1 / 60);
    const c1 = thirdPersonCamera({ x: 50, y: 0, z: 0 }, c0.state, p, 1 / 60);
    expect(c1.position.x).toBeCloseTo(c0.position.x);
    expect(readThirdPersonParams({ distance: -1, maxPitch: 'x' }).distance).toBeGreaterThanOrEqual(0.5);
    expect(readThirdPersonParams(undefined)).toEqual(THIRD_PERSON_DEFAULTS);
  });
});
