import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { AuthoringModel } from '../core/authoring/AuthoringModel';
import { CommandManager } from '../core/commandManager';
import { DiagnosticService } from '../core/diagnostics/DiagnosticService';
import { InputManager } from './input/InputManager';
import { RuntimeSession, activateRuntimeSession } from './RuntimeSession';
import { stepRuntimeViewportHost, mirrorSessionToObjects, type OrbitCameraRig } from './runtimeViewportHost';
import { playBlockLines } from './playGate';

/** Input do jogo com as teclas dadas já pressionadas (a simulação lê AÇÕES, nunca KeyboardEvent.code). */
const inputWith = (...codes: string[]) => {
  const m = new InputManager();
  m.setEnabled(true);
  codes.forEach((c) => m.handleKey(c, true));
  return m;
};

const node = (id: string, name: string, extra: Partial<GameNode> = {}): GameNode =>
  ({ id, name, type: 'MeshInstance', parentId: null, childrenIds: [], visible: true, locked: false, properties: {}, ...extra }) as unknown as GameNode;

const behavior = (behaviorType: string, properties: Record<string, any>): BehaviorInstance => ({ id: `${behaviorType}_b`, name: behaviorType, behaviorType, enabled: true, properties, rules: [] });

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes = { ...scene.nodes };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  nodes[root.id] = { ...root, childrenIds: [...root.childrenIds, ...extra.map((n) => n.id)] };
  // o starter já tem um "PlayerMesh": os testes usam ids próprios e removem o implícito para isolar o comportamento
  // isola: os nós do starter não trazem Behaviors nem nome de jogador (o implícito/explícito vem só dos nós do teste)
  for (const [id, n] of Object.entries(nodes)) if (!extra.some((e) => e.id === id)) nodes[id] = { ...n, name: n.name.toLowerCase().includes('player') ? `Hero_${id}` : n.name, behaviors: [] };
  return { ...scene, nodes };
}

function start(scene: SceneData, input: InputManager) {
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input });
  session.start();
  const objects = new Map<string, THREE.Object3D>();
  for (const n of Object.values(scene.nodes)) objects.set(n.id, new THREE.Object3D());
  const rig: OrbitCameraRig = { camera: new THREE.PerspectiveCamera(), target: new THREE.Vector3(0, 1, 0), spherical: { radius: 14, theta: 0.8, phi: 1.1 } };
  return { session, objects, rig };
}

describe('RuntimeViewportHost: o estado vivo aparece nos objetos do mesmo canvas (AIS-44c-C01/C02)', () => {
  it('as ações MoveForward/MoveLeft… (WASD é só o mapa padrão) movem o alvo proporcional a dt e a câmera segue', () => {
    const input = inputWith('KeyW');
    const { session, objects, rig } = start(sceneWith(node('p', 'Hero', { behaviors: [behavior('simple_wasd_movement', { speed: 4 })] })), input);
    const before = rig.camera.position.clone();
    stepRuntimeViewportHost({ dt: 0.5, input, session, objects, rig });
    expect(objects.get('p')!.position.z).toBeCloseTo(-2);
    expect(rig.camera.position.equals(before)).toBe(false);
  });

  it('rotação contínua usa graus por segundo', () => {
    const input = inputWith();
    const { session, objects, rig } = start(sceneWith(node('orb', 'MagicOrb', { behaviors: [behavior('continuous_rotation', { rotationSpeed: 90 })] })), input);
    stepRuntimeViewportHost({ dt: 1, input, session, objects, rig });
    expect(objects.get('orb')!.rotation.y).toBeCloseTo(Math.PI / 2);
  });

  it('sem behavior de movimento, o nó "player" usa o fallback; dt=0 não move', () => {
    const input = inputWith('KeyD');
    const { session, objects, rig } = start(sceneWith(node('p', 'PlayerMesh')), input);
    stepRuntimeViewportHost({ dt: 0, input, session, objects, rig });
    expect(objects.get('p')!.position.x).toBe(0);
    stepRuntimeViewportHost({ dt: 0.1, input, session, objects, rig });
    expect(objects.get('p')!.position.x).toBeCloseTo(0.6);
  });

  it('AIS-40b: o Behavior consulta a AÇÃO — remapear MoveForward troca a tecla sem editar o Behavior', () => {
    const input = inputWith();
    input.rebind('MoveForward', ['KeyI']);
    input.handleKey('KeyI', true);
    const { session, objects, rig } = start(sceneWith(node('p', 'Hero', { behaviors: [behavior('simple_wasd_movement', { speed: 4 })] })), input);
    stepRuntimeViewportHost({ dt: 0.5, input, session, objects, rig });
    expect(objects.get('p')!.position.z).toBeCloseTo(-2);

    const old = inputWith();
    old.rebind('MoveForward', ['KeyI']);
    old.handleKey('KeyW', true);
    const other = start(sceneWith(node('p', 'Hero', { behaviors: [behavior('simple_wasd_movement', { speed: 4 })] })), old);
    stepRuntimeViewportHost({ dt: 0.5, input: old, session: other.session, objects: other.objects, rig: other.rig });
    expect(other.objects.get('p')!.position.z).toBe(0);
  });

  it('mover objeto por gameplay NÃO altera o authoring nem o histórico (Stop restaura a pose do autoral)', () => {
    const scene = sceneWith(node('hero', 'Hero', { behaviors: [behavior('simple_wasd_movement', { speed: 4 })] }));
    const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene);
    const commands = new CommandManager();
    const before = JSON.parse(JSON.stringify(model.getScene()));
    const input = inputWith('KeyW');
    const session = new RuntimeSession({ snapshot: model.createSceneSnapshot(), input });
    session.start();
    const objects = new Map([['hero', new THREE.Object3D()]]);
    const rig: OrbitCameraRig = { camera: new THREE.PerspectiveCamera(), target: new THREE.Vector3(), spherical: { radius: 14, theta: 0.8, phi: 1.1 } };
    stepRuntimeViewportHost({ dt: 1, input, session, objects, rig });
    expect(objects.get('hero')!.position.z).toBeCloseTo(-4);
    session.dispose();
    expect(model.getScene()).toEqual(before);
    expect(commands.getHistory().length).toBe(0);
  });

  it('pausa: sem chamar o host nada se move; objeto destruído no jogo some e os helpers (sem instância) ficam intactos', () => {
    const { session, objects } = start(sceneWith(node('a', 'A'), node('b', 'B')), inputWith());
    const helper = new THREE.Object3D();
    objects.set('helper_only', helper);
    session.scene.destroyInstance('a');
    session.scene.getInstance('b')!.visible = false;
    mirrorSessionToObjects(session.scene, objects);
    expect(objects.get('a')!.visible).toBe(false);
    expect(objects.get('b')!.visible).toBe(false);
    expect(helper.visible).toBe(true);
  });
});

describe('RuntimeViewportHost: 5 ciclos Play/Stop não acumulam sessões nem listeners (AIS-44c-C04)', () => {
  it('cada ciclo cria UMA sessão, devolve o input ao estado inicial e deixa só a sessão ativa descartada', () => {
    const input = new InputManager();
    const base = input.listenerCount;
    for (let i = 0; i < 5; i++) {
      const { session, objects, rig } = start(sceneWith(node('p', 'Hero', { behaviors: [behavior('simple_wasd_movement', {})] })), input);
      activateRuntimeSession(session);
      const detach = input.attach({ keyTarget: { addEventListener() {}, removeEventListener() {} } });
      stepRuntimeViewportHost({ dt: 0.1, input, session, objects, rig });
      detach();
      activateRuntimeSession(null);
      expect(session.isDisposed).toBe(true);
      expect(input.listenerCount).toBe(base);
    }
  });
});

describe('bloqueio do Play por diagnóstico (AIS-44c-C11/C12)', () => {
  const scenePath = 'res://scenes/Main.scene.json';

  it('diagnóstico `blocking` da cena impede o Play e devolve `[código] mensagem`; corrigido, o Play inicia', () => {
    const d = new DiagnosticService();
    d.report({ source: 'scene', sourceId: scenePath, severity: 'blocking', phase: 'validation', code: 'resource.required_missing', message: 'textura obrigatória ausente', uri: scenePath });
    expect(playBlockLines(d, scenePath)).toEqual(['[resource.required_missing] textura obrigatória ausente']);
    d.clear({ code: 'resource.required_missing' });
    expect(playBlockLines(d, scenePath)).toEqual([]);
  });

  it('só `warning` (ex.: scene.missing_nodes) não bloqueia', () => {
    const d = new DiagnosticService();
    d.report({ source: 'scene', sourceId: scenePath, severity: 'warning', phase: 'serialization', code: 'scene.missing_nodes', message: 'x', uri: scenePath });
    d.report({ source: 'scene', sourceId: scenePath, severity: 'error', phase: 'validation', code: 'scene.node_corrupted', message: 'y' });
    expect(playBlockLines(d, scenePath)).toEqual([]);
  });

  it('bloqueio de OUTRA cena não impede esta; bloqueio de outra fase (import) também não', () => {
    const d = new DiagnosticService();
    d.report({ source: 'scene', sourceId: 'res://scenes/Other.scene.json', severity: 'blocking', phase: 'validation', code: 'a.b', message: 'outra cena' });
    d.report({ source: 'assetImport', severity: 'blocking', phase: 'import', code: 'c.d', message: 'import' });
    expect(playBlockLines(d, scenePath)).toEqual([]);
  });

  it('diagnóstico efêmero da sessão anterior (já limpo no Stop) não bloqueia o próximo Play', () => {
    const d = new DiagnosticService();
    const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(sceneWith(node('x', 'X'))), input: inputWith(), diagnostics: d });
    session.start();
    session.dispose();
    expect(playBlockLines(d, scenePath)).toEqual([]);
  });
});
