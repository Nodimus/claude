import * as THREE from 'three';
import type { AuthoringSceneSnapshot, RuntimeInstanceHandle, RuntimeSceneContract } from '../types/runtime';
import type { NodeType } from '../types/node';
import { extractNodeTransform } from '../core/authoring/snapshot';
import { RuntimeObjectFactory } from './RuntimeObjectFactory';

/**
 * AIS-29d — RuntimeScene e RuntimeInstance.
 *
 * `RuntimeScene` é a cena VIVA, descartável, construída de um `AuthoringSceneSnapshot` (nunca da cena autoral): uma
 * árvore de `RuntimeInstance` com os seus `THREE.Object3D`, separada da árvore do editor. Uma `RuntimeInstance` liga o
 * id autoral (`persistentNodeId`) a um handle de runtime (`id`) e tem estado PRÓPRIO — transform, propriedades, tags e
 * variáveis são cópias profundas do snapshot: nenhuma mutação de runtime volta para o autoral nem para o snapshot, e
 * duas instâncias nunca compartilham referência mutável.
 *
 * Esta camada não conhece EditorContext, AuthoringModel nem CommandManager: só lê o snapshot.
 */

type Transform = RuntimeInstanceHandle['transform'];

const clone = <T>(value: T): T => (value === undefined ? value : JSON.parse(JSON.stringify(value)));

let instanceCounter = 0;
const newHandleId = (nodeId: string): string => `inst_${nodeId}_${(++instanceCounter).toString(36)}`;

/** Tipos sem representação executável: dado autoral preservado, mas sem instância viva. */
const NON_EXECUTABLE_TYPES: ReadonlySet<string> = new Set(['Missing']);

export class RuntimeInstance implements RuntimeInstanceHandle {
  public readonly id: string;
  public readonly persistentNodeId: string;
  public readonly name: string;
  public readonly type: NodeType;
  public transform: Transform;
  public properties: Record<string, any>;
  public tags: string[];
  public variables: Record<string, any>;
  public visible: boolean;
  public disposed = false;
  /** Objeto vivo do jogo (criado e destruído SÓ pela `RuntimeObjectFactory`). */
  public object: THREE.Object3D | null = null;
  public parent: RuntimeInstance | null = null;
  public readonly children: RuntimeInstance[] = [];

  constructor(snapshotNode: AuthoringSceneSnapshot['nodes'][string]) {
    const t = extractNodeTransform(snapshotNode as never);
    this.id = newHandleId(snapshotNode.id);
    this.persistentNodeId = snapshotNode.id;
    this.name = snapshotNode.name;
    this.type = snapshotNode.type;
    this.transform = { position: [...t.position], rotation: [...t.rotation], scale: [...t.scale] };
    this.properties = clone(snapshotNode.properties ?? {});
    this.tags = [...(snapshotNode.tags ?? [])];
    this.variables = clone(snapshotNode.variables ?? {});
    this.visible = snapshotNode.visible !== false;
  }
}

export class RuntimeScene implements RuntimeSceneContract {
  public readonly sceneId: string;
  public readonly name: string;
  public readonly rootNodeId: string;
  /** Raiz da árvore de objetos de runtime (nunca é filha da cena do editor). */
  public readonly rootObject = new THREE.Group();
  public readonly snapshotId: string;

  private readonly byHandle = new Map<string, RuntimeInstance>();
  private readonly byNode = new Map<string, RuntimeInstance>();
  private readonly list: RuntimeInstance[] = [];
  private _disposed = false;

  constructor(snapshot: AuthoringSceneSnapshot, private readonly factory: RuntimeObjectFactory) {
    this.sceneId = snapshot.sceneId;
    this.name = snapshot.name;
    this.rootNodeId = snapshot.rootNodeId;
    this.snapshotId = snapshot.snapshotId;
    this.rootObject.name = `runtime:${snapshot.name}`;

    // 1) uma instância por nó executável
    for (const node of Object.values(snapshot.nodes)) {
      if (NON_EXECUTABLE_TYPES.has(node.type)) continue;
      const instance = new RuntimeInstance(node);
      this.byHandle.set(instance.id, instance);
      this.byNode.set(instance.persistentNodeId, instance);
      this.list.push(instance);
    }
    // 2) hierarquia (ordem dos irmãos = childrenIds) e objetos vivos
    const attach = (nodeId: string, parentObject: THREE.Object3D, parent: RuntimeInstance | null) => {
      const instance = this.byNode.get(nodeId);
      const node = snapshot.nodes[nodeId];
      if (!node) return;
      if (!instance) {
        // nó não executável (ex.: Missing): seus filhos sobem para o pai mais próximo
        for (const child of node.childrenIds ?? []) attach(child, parentObject, parent);
        return;
      }
      instance.object = this.factory.create(instance);
      this.factory.applyTransform(instance.object, instance.transform);
      instance.object.visible = instance.visible;
      parentObject.add(instance.object);
      instance.parent = parent;
      parent?.children.push(instance);
      for (const child of node.childrenIds ?? []) attach(child, instance.object, instance);
    };
    attach(snapshot.rootNodeId, this.rootObject, null);
  }

  public get disposed(): boolean {
    return this._disposed;
  }

  public getInstance(idOrNodeId: string): RuntimeInstance | undefined {
    const found = this.byHandle.get(idOrNodeId) ?? this.byNode.get(idOrNodeId);
    return found && !found.disposed ? found : undefined;
  }

  /** `true` se o nó teve instância e ela foi destruída durante o jogo. */
  public wasDestroyed(nodeId: string): boolean {
    return this.byNode.get(nodeId)?.disposed === true;
  }

  public getAllInstances(): RuntimeInstance[] {
    return this.list.filter((i) => !i.disposed);
  }

  public findInstancesByTag(tag: string): RuntimeInstance[] {
    return this.list.filter((i) => !i.disposed && i.tags.includes(tag));
  }

  public findInstancesByType(type: NodeType): RuntimeInstance[] {
    return this.list.filter((i) => !i.disposed && i.type === type);
  }

  /** Escreve o `transform` da instância no objeto vivo (executores de Action nunca falam com a fábrica). */
  public applyInstanceTransform(instance: RuntimeInstance): void {
    if (instance.object) this.factory.applyTransform(instance.object, instance.transform);
  }

  /** Destrói uma instância (e a subárvore dela) durante o jogo: objetos liberados, handles marcados `disposed`. */
  public destroyInstance(idOrNodeId: string): void {
    const instance = this.getInstance(idOrNodeId);
    if (!instance) return;
    for (const child of [...instance.children]) this.destroyInstance(child.id);
    if (instance.object) this.factory.destroy(instance.object);
    instance.object = null;
    instance.disposed = true;
    if (instance.parent) instance.parent.children.splice(instance.parent.children.indexOf(instance), 1);
  }

  /** Descarta a cena inteira (idempotente). Não toca em nada autoral. */
  public dispose(): void {
    if (this._disposed) return;
    this._disposed = true;
    for (const instance of this.list) {
      if (instance.object) this.factory.destroy(instance.object);
      instance.object = null;
      instance.disposed = true;
      instance.children.length = 0;
      instance.parent = null;
    }
    this.factory.destroy(this.rootObject);
  }
}
