import type { AuthoringSceneSnapshot, RuntimeSessionMode } from '../types/runtime';
import type { VariableSource } from '../core/variableManager';
import { globalDiagnosticService } from '../core/diagnostics/global';
import { activateRuntimeSession, getActiveRuntimeSession, RuntimeSession } from './RuntimeSession';
import type { LogicLogEntry, LogicRunner } from './logicRunner';
import { globalInputManager } from './input/global';
import { ensureRapier } from '../core/physics/rapierInit';

/**
 * Cola do EDITOR com a `RuntimeSession` (AIS-44b): cria/descarta a sessão do Play, guarda o buffer de log de execução que o
 * Debugger lê e os ganchos do host (Output, Quit Game, resolução de cenas). A lógica de sessão em si mora em `RuntimeSession`.
 */

// AIS-45: o Rapier (WASM) carrega uma vez, em segundo plano, assim que o editor abre; o Play nunca espera por ele
void ensureRapier().catch(() => undefined);

const MAX_ENTRIES = 500;

let entries: LogicLogEntry[] = [];
const listeners = new Set<() => void>();
const notify = () => listeners.forEach((l) => l());

export interface LogicSessionHooks {
  /** Entradas de log destinadas ao painel Output (`print_log`, avisos e erros). */
  output?(level: 'log' | 'warn' | 'error', message: string): void;
  quitGame?(): void;
  /** `Change Scene`: caminho `res://…` → snapshot da cena de destino (lê o projeto, nunca escreve nele). */
  resolveScene?(scenePath: string): AuthoringSceneSnapshot | Promise<AuthoringSceneSnapshot>;
}
let hooks: LogicSessionHooks = {};
export const setLogicSessionHooks = (next: LogicSessionHooks): void => {
  hooks = next;
};

/** Log de execução para o Debugger (buffer circular; `subscribe` devolve o disposer). */
export const logicExecutionLog = {
  getEntries: (): readonly LogicLogEntry[] => entries,
  clear: (): void => {
    entries = [];
    notify();
  },
  subscribe: (listener: () => void): (() => void) => {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  },
};

function push(entry: LogicLogEntry): void {
  entries = entries.length >= MAX_ENTRIES ? [...entries.slice(entries.length - MAX_ENTRIES + 1), entry] : [...entries, entry];
  if (entry.toOutput) hooks.output?.(entry.level === 'info' ? 'log' : entry.level, entry.nodeName ? `[${entry.nodeName}] ${entry.message}` : entry.message);
  notify();
}

export interface PlaySessionOptions {
  snapshot: AuthoringSceneSnapshot;
  mode: RuntimeSessionMode;
  /** Valores iniciais das variáveis globais do projeto. */
  globals: readonly VariableSource[];
  /** `settings.physics.defaultLinearDamp` do projeto (AIS-45). */
  defaultLinearDamp?: number;
}

/** Inicia o Play: UMA sessão por vez (a anterior, se houver, é descartada por inteiro). */
export function startPlaySession(options: PlaySessionOptions): RuntimeSession {
  clearStepFrameRequests();
  entries = [];
  const session = new RuntimeSession({
    snapshot: options.snapshot,
    mode: options.mode,
    globals: options.globals,
    defaultLinearDamp: options.defaultLinearDamp,
    input: globalInputManager,
    diagnostics: globalDiagnosticService,
    resolveScene: (path) => {
      if (!hooks.resolveScene) throw new Error('o editor não forneceu a leitura de cenas');
      return hooks.resolveScene(path);
    },
    onLog: push,
    onUiChanged: notify,
    onQuitGame: () => hooks.quitGame?.(),
  });
  activateRuntimeSession(session);
  session.start();
  notify();
  return session;
}

/** Fim do Play: a sessão é descartada (runner, Behaviors, assinaturas, cena viva, variáveis e diagnósticos efêmeros). */
export function stopPlaySession(): void {
  clearStepFrameRequests();
  const session = getActiveRuntimeSession();
  activateRuntimeSession(null);
  session?.dispose();
}

export const pausePlaySession = (paused: boolean): void => {
  const session = getActiveRuntimeSession();
  if (paused) session?.pause();
  else session?.resume();
};

/** AIS-46 — pedidos de "Avançar 1 Quadro" (a barra do Play incrementa; o loop da viewport consome um por quadro, só em pausa). */
let stepFrameRequests = 0;
export const requestStepFrame = (): void => {
  if (getActiveRuntimeSession()?.status === 'paused') stepFrameRequests++;
};
/** `true` e consome UM pedido pendente. */
export const takeStepFrameRequest = (): boolean => {
  if (stepFrameRequests <= 0) return false;
  stepFrameRequests--;
  return true;
};
/** Stop/novo Play: pedidos pendentes não sobrevivem à sessão. */
const clearStepFrameRequests = (): void => {
  stepFrameRequests = 0;
};

export const getLogicRunner = (): LogicRunner | null => getActiveRuntimeSession()?.runner ?? null;

/** Um quadro de simulação (o host chama com o `dt` real, e NÃO chama em pausa). */
export const stepLogicRunner = (dt: number): void => getActiveRuntimeSession()?.step(dt);
