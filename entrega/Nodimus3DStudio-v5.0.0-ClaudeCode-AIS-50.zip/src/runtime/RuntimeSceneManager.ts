import type { AuthoringSceneSnapshot } from '../types/runtime';
import { RuntimeObjectFactory } from './RuntimeObjectFactory';
import { RuntimeScene } from './RuntimeScene';
import { VariableManager, type VariableSource } from '../core/variableManager';

/**
 * AIS-29d — RuntimeSceneManager: ciclo de vida da cena viva (load / unload / change / restart).
 *
 * - `load` constrói a `RuntimeScene` de um snapshot; `unload` a descarta; `restart` reconstrói do MESMO snapshot
 *   (estado inicial equivalente); `change` troca de cena com ponto de ABORTO: a nova cena só substitui a atual depois de
 *   pronta e não abortada — abortar descarta a parcial e mantém a atual.
 * - Nenhuma dependência de EditorContext/AuthoringModel/CommandManager: o runtime lê o snapshot e nunca escreve no autoral.
 * - Cada cena tem a sua `RuntimeObjectFactory`: descartar a cena libera TODOS os objetos dela.
 */

export type RuntimeSceneStatus = 'empty' | 'loaded' | 'changing';

export type RuntimeSceneEvent =
  | { type: 'loaded'; sceneId: string; instanceCount: number }
  | { type: 'unloaded'; sceneId: string }
  | { type: 'change_started'; fromSceneId: string | null }
  | { type: 'change_aborted'; fromSceneId: string | null; reason: string }
  | { type: 'restarted'; sceneId: string };

export type SnapshotSource = AuthoringSceneSnapshot | (() => AuthoringSceneSnapshot | Promise<AuthoringSceneSnapshot>);

export interface ChangeOptions {
  /** Ponto de aborto: se sinalizado antes da troca, a cena atual permanece e a parcial é descartada. */
  signal?: AbortSignal;
}

export type ChangeResult = { committed: true; scene: RuntimeScene } | { committed: false; reason: string };

export class RuntimeSceneManager {
  private _current: RuntimeScene | null = null;
  private _factory: RuntimeObjectFactory | null = null;
  private _snapshot: AuthoringSceneSnapshot | null = null;
  private _status: RuntimeSceneStatus = 'empty';
  private listeners = new Set<(e: RuntimeSceneEvent) => void>();
  /** AIS-43: variáveis da SESSÃO de Play. Globais sobrevivem a `change`/`restart`; locais são as da instância viva. */
  private _variables: VariableManager | null = null;

  public get variables(): VariableManager | null {
    return this._variables;
  }

  /** Começa uma sessão: as globais nascem do valor inicial do projeto (cópia; o autoral nunca é tocado). */
  public beginSession(globals: readonly VariableSource[]): VariableManager {
    this._variables?.dispose();
    this._variables = new VariableManager(globals);
    return this._variables;
  }

  public endSession(): void {
    this._variables?.dispose();
    this._variables = null;
  }

  private bindLocals(scene: RuntimeScene): void {
    for (const instance of scene.getAllInstances()) this._variables?.registerLocals(instance.persistentNodeId, instance.variables);
  }

  private unbindLocals(scene: RuntimeScene | null): void {
    if (scene) for (const instance of scene.getAllInstances()) this._variables?.unregisterLocals(instance.persistentNodeId);
  }

  public get current(): RuntimeScene | null {
    return this._current;
  }

  public get status(): RuntimeSceneStatus {
    return this._status;
  }

  /** Objetos vivos da cena atual (0 sem cena): prova de que nada vazou. */
  public get liveObjectCount(): number {
    return this._factory?.liveCount ?? 0;
  }

  public subscribe(listener: (e: RuntimeSceneEvent) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private emit(event: RuntimeSceneEvent): void {
    for (const l of this.listeners) {
      try {
        l(event);
      } catch (error) {
        console.error('Error in RuntimeSceneManager subscriber:', error);
      }
    }
  }

  private build(snapshot: AuthoringSceneSnapshot): { scene: RuntimeScene; factory: RuntimeObjectFactory } {
    const factory = new RuntimeObjectFactory();
    return { scene: new RuntimeScene(snapshot, factory), factory };
  }

  private commit(snapshot: AuthoringSceneSnapshot, built: { scene: RuntimeScene; factory: RuntimeObjectFactory }): RuntimeScene {
    this._current = built.scene;
    this._factory = built.factory;
    this._snapshot = snapshot;
    this._status = 'loaded';
    this.bindLocals(built.scene);
    this.emit({ type: 'loaded', sceneId: snapshot.sceneId, instanceCount: built.scene.getAllInstances().length });
    return built.scene;
  }

  /** Carrega a cena do snapshot. Já havendo uma cena, ela é descartada primeiro (nunca duas vivas ao mesmo tempo). */
  public load(snapshot: AuthoringSceneSnapshot): RuntimeScene {
    this.unload();
    return this.commit(snapshot, this.build(snapshot));
  }

  /** Descarta a cena atual e libera todos os objetos dela (idempotente). */
  public unload(): void {
    const scene = this._current;
    if (!scene) return;
    const sceneId = scene.sceneId;
    this.unbindLocals(scene);
    scene.dispose();
    this._factory?.dispose();
    this._current = null;
    this._factory = null;
    this._snapshot = null;
    this._status = 'empty';
    this.emit({ type: 'unloaded', sceneId });
  }

  /** Reconstrói a cena do MESMO snapshot: estado inicial equivalente, nada do estado de jogo sobrevive. */
  public restart(): RuntimeScene | null {
    const snapshot = this._snapshot;
    if (!snapshot) return null;
    this.unload();
    const scene = this.commit(snapshot, this.build(snapshot));
    this.emit({ type: 'restarted', sceneId: snapshot.sceneId });
    return scene;
  }

  /**
   * Troca de cena. A nova é obtida (snapshot ou função, possivelmente assíncrona) e construída ANTES de a atual ser
   * descartada; `signal` é verificado depois de cada etapa e, se abortado, a parcial é descartada e a atual continua.
   */
  public async change(source: SnapshotSource, options: ChangeOptions = {}): Promise<ChangeResult> {
    const from = this._current?.sceneId ?? null;
    const previousStatus = this._status;
    this._status = 'changing';
    this.emit({ type: 'change_started', fromSceneId: from });
    const abort = (reason: string): ChangeResult => {
      this._status = previousStatus;
      this.emit({ type: 'change_aborted', fromSceneId: from, reason });
      return { committed: false, reason };
    };
    try {
      if (options.signal?.aborted) return abort('abortado antes de obter a cena');
      const snapshot = typeof source === 'function' ? await source() : source;
      if (options.signal?.aborted) return abort('abortado depois de obter a cena');
      const built = this.build(snapshot);
      if (options.signal?.aborted) {
        built.scene.dispose();
        built.factory.dispose();
        return abort('abortado depois de construir a cena');
      }
      const old = { scene: this._current, factory: this._factory };
      this._current = null;
      this._factory = null;
      this.unbindLocals(old.scene);
      old.scene?.dispose();
      old.factory?.dispose();
      if (old.scene) this.emit({ type: 'unloaded', sceneId: old.scene.sceneId });
      return { committed: true, scene: this.commit(snapshot, built) };
    } catch (error) {
      return abort(`falha ao carregar: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /** Teardown total do manager (fim da sessão). */
  public dispose(): void {
    this.unload();
    this.endSession();
    this.listeners.clear();
  }
}

