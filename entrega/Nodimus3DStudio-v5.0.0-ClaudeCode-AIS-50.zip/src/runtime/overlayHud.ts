import * as THREE from 'three';
import { Container, Image as UIImage, Text as UIText, TTFLoader, reversePainterSortStable } from '@pmndrs/uikit';
import type { FrameInfo, OverlayPass } from '../core/rendering/RendererCore';
import {
  collectUiTree,
  computeOverlayScreenRect,
  isOverlayNodeType,
  readOverlayControl,
  type OverlayNodeType,
  type Rect,
  type UiTreeEntry,
} from './overlay';
import { childFlex, containerFlexProps, containerKindOf, gridRows, parseSizeFlag, type ContainerKind } from './containerLayout';

/**
 * AIS-25b/25c — Motor único de UI (HUD) com `@pmndrs/uikit` (vanilla): `uiScene` + câmera ortográfica em
 * pixels, desenhada depois da cena 3D (`RendererCore.setOverlayPass`). Editor e Play usam este mesmo motor.
 *
 * Geometria:
 *  - nó de UI de topo (ou filho de um nó que NÃO organiza filhos): retângulo = `computeOverlayScreenRect`
 *    (âncoras + offsets do Layout Preset), posicionado de forma absoluta dentro do pai;
 *  - filho de Container (HBox/VBox/Grid/Margin/Center/Scroll/Container): entra no fluxo do Yoga/Flexbox do
 *    UIKit dentro de um "slot" (como o Godot): size flags, `minSize` e `stretchRatio` (ver `containerLayout.ts`);
 *    as âncoras/offsets do filho são ignoradas.
 * Os retângulos de tela de TODOS os nós (editor: handles/seleção; Play: hit-test) são lidos do layout calculado
 * pelo próprio UIKit — não existe um segundo motor de layout.
 */

// ── Fonte: atlas MSDF com charset pt-BR ──────────────────────────────────────────────────────────
// As fontes MSDF embutidas no UIKit têm só ASCII (104 glifos): "ç", "ã", "é", "ü" viram quadrados. Geramos o
// atlas (uma vez por sessão, em Web Worker/WASM do próprio UIKit) a partir da Inter (SIL OFL 1.1,
// `public/fonts/OFL-Inter.txt`) com ASCII + Latin-1 (acentos pt-BR) + pontuação tipográfica.

const range = (from: number, to: number) => Array.from({ length: to - from + 1 }, (_, i) => String.fromCharCode(from + i)).join('');
export const OVERLAY_FONT_CHARSET = `${range(0x20, 0x7e)}${range(0xa0, 0xff)}“”‘’–—…•€`;
export const OVERLAY_FONT_FAMILY = 'ui';

type FontFamilies = Record<string, Record<string, unknown>>;
let overlayFontsPromise: Promise<FontFamilies> | null = null;

/** Carrega (uma vez) as fontes do HUD; falha não é fatal: o HUD segue com a fonte padrão (ASCII). */
export function loadOverlayFonts(baseUrl: string = `${import.meta.env?.BASE_URL ?? '/'}fonts/`): Promise<FontFamilies> {
  overlayFontsPromise ??= (async () => {
    const generated = await new TTFLoader().loadAsync(
      ['Inter-Medium.ttf', 'Inter-SemiBold.ttf'].map((file) => ({
        url: `${baseUrl}${file}`,
        charset: OVERLAY_FONT_CHARSET,
        fontSize: 48,
        textureSize: [1024, 1024] as [number, number],
        fieldRange: 4,
      }))
    );
    // junta todas as famílias geradas numa só ("ui"), indexada por peso; 400 e 500 usam a Medium
    const byWeight: Record<string, unknown> = {};
    for (const weights of Object.values(generated as Record<string, Record<string, unknown>>)) {
      for (const [weight, info] of Object.entries(weights)) byWeight[weight] = info;
    }
    const medium = byWeight['500'] ?? Object.values(byWeight)[0];
    return { [OVERLAY_FONT_FAMILY]: { ...byWeight, 400: medium, 500: medium } };
  })();
  return overlayFontsPromise;
}

export interface HudNode {
  id: string;
  name: string;
  type: string;
  parentId: string | null;
  childrenIds?: string[];
  visible?: boolean;
  properties?: Record<string, any>;
}

type Rgba = { r?: number; g?: number; b?: number; a?: number } | undefined;

const channel = (v: unknown, fallback: number) => Math.round(Math.max(0, Math.min(1, typeof v === 'number' ? v : fallback)) * 255);
const scratch = new THREE.Color();

/**
 * Cor autoral {r,g,b,a} (componentes sRGB 0..1, como no Inspector) → número 0xRRGGBB (texto) e tupla
 * RGBA em espaço de trabalho (linear) para fundos/bordas com alfa. Mesma conversão do restante da casca.
 */
function colorOf(c: Rgba, fallback: { r: number; g: number; b: number; a: number }) {
  const r = channel(c?.r, fallback.r);
  const g = channel(c?.g, fallback.g);
  const b = channel(c?.b, fallback.b);
  const opacity = typeof c?.a === 'number' ? Math.max(0, Math.min(1, c.a)) : fallback.a;
  scratch.setRGB(r / 255, g / 255, b / 255, THREE.SRGBColorSpace);
  return { hex: (r << 16) | (g << 8) | b, opacity, rgba: [scratch.r, scratch.g, scratch.b, opacity] as [number, number, number, number] };
}
const rgbaOf = (r: number, g: number, b: number, a: number) => colorOf({ r, g, b, a }, { r, g, b, a }).rgba;

const num = (v: unknown, fallback: number) => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);
const pct = (value: number, min: number, max: number) => (max > min ? Math.max(0, Math.min(1, (value - min) / (max - min))) : 0);

type Props = Record<string, any>;

interface Entry {
  type: OverlayNodeType;
  /** Espaço reservado quando o pai organiza os filhos (o "slot" do Godot). */
  slot?: Container;
  /** O controle. */
  box: Container;
  /** Partes visuais do controle (rótulo, imagem, marca, preenchimento…). */
  parts: Record<string, any>;
  /** Grid: contêineres de linha. */
  rows?: Container[];
  /** Imagem de textura corrente (para recriar só quando muda). */
  imageSrc?: string;
}

/** Resolve `texture` (ex.: `res://textures/a.png`) para uma URL exibível (data URL) ou `null`. */
export type OverlayTextureResolver = (path: string) => string | null;

export interface OverlayHudOptions {
  /** `false` nos testes headless (sem rede/Worker): usa a fonte padrão do UIKit. */
  loadFonts?: boolean;
}

/** Largura da borda desenhada por tipo (precisa casar com `applyVisual`). */
function borderWidthOf(node: HudNode): number {
  const p = node.properties ?? {};
  switch (node.type) {
    case 'Panel':
      return num(p.borderWidth, 1);
    case 'Overlay2D':
      return num(p.borderWidth, 2);
    case 'ButtonOverlay2D':
    case 'CheckBox':
    case 'TextInput':
    case 'ProgressBar':
      return 1;
    default:
      return 0;
  }
}

export class OverlayHud implements OverlayPass {
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.OrthographicCamera(0, 1, 1, 0, -1000, 1000);

  private readonly root: Container;
  private readonly entries = new Map<string, Entry>();
  private nodes: Record<string, HudNode> = {};
  private resolveTexture: OverlayTextureResolver = () => null;
  private width = 0;
  private height = 0;
  private dirty = true;
  private rects = new Map<string, Rect>();
  private listener: ((rects: ReadonlyMap<string, Rect>) => void) | null = null;
  private readonly size = new THREE.Vector2();

  constructor(options: OverlayHudOptions = {}) {
    this.root = new Container({
      pixelSize: 1,
      anchorX: 'left',
      anchorY: 'top',
      width: 1,
      height: 1,
      flexDirection: 'column',
    });
    this.scene.add(this.root);

    if (options.loadFonts !== false) {
      // fonte com acentos: assim que o atlas ficar pronto, o texto é redesenhado
      loadOverlayFonts()
        .then((families) => {
          this.root.setProperties({ fontFamilies: families as never, fontFamily: OVERLAY_FONT_FAMILY });
          this.dirty = true;
        })
        .catch((error) => console.warn('[OverlayHud] fonte pt-BR indisponível; usando a fonte padrão (ASCII).', error));
    }
  }

  /** Nós da cena (qualquer nó; só os de UI são desenhados). */
  setNodes(nodes: Record<string, HudNode>): void {
    this.nodes = nodes;
    this.dirty = true;
  }

  setTextureResolver(resolver: OverlayTextureResolver): void {
    this.resolveTexture = resolver;
    this.dirty = true;
  }

  /** Avisa quando os retângulos de tela mudam (editor: handles; Play: hit-test). */
  setRectsListener(listener: ((rects: ReadonlyMap<string, Rect>) => void) | null): void {
    this.listener = listener;
  }

  /** Retângulos de tela de cada nó de UI (lidos do layout calculado pelo UIKit). */
  getRects(): ReadonlyMap<string, Rect> {
    return this.rects;
  }

  /**
   * Layout síncrono para testes headless e verificações: define o tamanho da viewport, aplica os nós e devolve os
   * retângulos. O Yoga do UIKit carrega de forma assíncrona: chame depois de `await hud.ready()`.
   */
  layoutNow(width: number, height: number): ReadonlyMap<string, Rect> {
    this.resize(width, height);
    this.sync();
    return this.rects;
  }

  /** Espera o Yoga do UIKit ficar disponível (primeiro layout válido). */
  async ready(timeoutMs = 3000): Promise<void> {
    const start = Date.now();
    const probe = new Container({ width: 10, height: 10 });
    this.root.add(probe);
    while (Date.now() - start < timeoutMs) {
      this.root.update(16);
      if (probe.size.value) break;
      await new Promise((r) => setTimeout(r, 10));
    }
    probe.removeFromParent();
  }

  render(renderer: THREE.WebGLRenderer, frame: FrameInfo): void {
    renderer.getSize(this.size);
    this.resize(Math.max(1, Math.floor(this.size.x)), Math.max(1, Math.floor(this.size.y)));
    if (this.dirty) this.sync();
    if (this.entries.size === 0) return;

    this.root.update(frame.dt * 1000);
    // o texto/fonte mede depois de carregar: se a geometria mudou, reavalia no quadro seguinte
    if (this.measure()) this.dirty = true;

    renderer.localClippingEnabled = true;
    renderer.setTransparentSort(reversePainterSortStable);
    try {
      renderer.render(this.scene, this.camera);
    } finally {
      renderer.setTransparentSort(null); // a cena 3D volta à ordenação padrão
    }
  }

  dispose(): void {
    for (const entry of this.entries.values()) (entry.slot ?? entry.box).removeFromParent();
    this.entries.clear();
    this.root.removeFromParent();
  }

  // ── interno ─────────────────────────────────────────────────────────────────────────────────

  private resize(w: number, h: number): void {
    if (w === this.width && h === this.height) return;
    this.width = w;
    this.height = h;
    this.camera.left = 0;
    this.camera.right = w;
    this.camera.top = h;
    this.camera.bottom = 0;
    this.camera.updateProjectionMatrix();
    this.root.position.set(0, h, 0);
    this.root.setProperties({ width: w, height: h });
    this.dirty = true;
  }

  /** Sincroniza a árvore UIKit com os nós; repete até a geometria dos pais estabilizar (filhos absolutos dependem dela). */
  private sync(): void {
    this.dirty = false;
    const uiNodes: Record<string, HudNode> = {};
    for (const [id, node] of Object.entries(this.nodes)) if (isOverlayNodeType(node.type)) uiNodes[id] = node;
    const tree = collectUiTree(uiNodes);
    const visible = new Set(tree.map((t) => t.id));

    for (const [id, entry] of [...this.entries]) {
      if (!visible.has(id) || entry.type !== uiNodes[id]?.type) {
        (entry.slot ?? entry.box).removeFromParent();
        this.entries.delete(id);
      }
    }
    for (const { id } of tree) {
      if (!this.entries.has(id)) {
        const node = uiNodes[id];
        this.entries.set(id, { type: node.type as OverlayNodeType, box: new Container(), parts: {} });
      }
    }

    // até 4 passadas: aplica props (posição absoluta usa o tamanho MEDIDO do pai) → layout → mede
    let measured = new Map<string, { w: number; h: number }>();
    for (let pass = 0; pass < 4; pass++) {
      const used = new Map<string, { w: number; h: number }>(); // tamanho do pai usado por cada nó
      for (const { id, parentId } of tree) {
        const parentSize = parentId ? measured.get(parentId) ?? this.measuredSize(parentId) ?? this.estimatedSize(uiNodes[parentId]) : { w: this.width, h: this.height };
        used.set(id, parentSize);
        this.applyNode(id, uiNodes, parentId, parentSize);
      }
      this.attach(tree, uiNodes);
      this.root.update(0);
      this.measure();

      measured = new Map();
      for (const { id } of tree) {
        const m = this.measuredSize(id);
        if (m) measured.set(id, m);
      }
      // estável quando o tamanho do pai usado por cada filho é o que o pai mede agora
      const stable = tree.every(({ id, parentId }) => {
        if (!parentId) return true;
        const m = measured.get(parentId);
        const u = used.get(id)!;
        return !!m && Math.abs(u.w - m.w) <= 0.5 && Math.abs(u.h - m.h) <= 0.5;
      });
      if (stable) break;
    }
  }

  private estimatedSize(node: HudNode | undefined): { w: number; h: number } {
    if (!node) return { w: this.width, h: this.height };
    const c = readOverlayControl(node.type, node.properties);
    return { w: c.width, h: c.height };
  }

  private measuredSize(id: string): { w: number; h: number } | null {
    const entry = this.entries.get(id);
    const size = entry?.box.size.value;
    return size ? { w: size[0], h: size[1] } : null;
  }

  /** Retângulo de tela de um componente pelo layout do UIKit (centro relativo ao centro do pai; Y do UIKit é para cima). */
  private rectOf(component: Container): Rect | null {
    if (component === this.root) return { left: 0, top: 0, width: this.width, height: this.height };
    const parent = component.parent;
    const parentRect = parent && parent instanceof Container ? this.rectOf(parent as unknown as Container) : null;
    const size = component.size.value;
    const rc = component.relativeCenter.value;
    if (!parentRect || !size || !rc) return null;
    const cx = parentRect.left + parentRect.width / 2 + rc[0];
    const cy = parentRect.top + parentRect.height / 2 - rc[1];
    return { left: cx - size[0] / 2, top: cy - size[1] / 2, width: size[0], height: size[1] };
  }

  /** Recalcula os retângulos de tela; devolve `true` se mudaram (e avisa o ouvinte). */
  private measure(): boolean {
    const next = new Map<string, Rect>();
    for (const [id, entry] of this.entries) {
      const rect = this.rectOf(entry.box);
      if (rect) next.set(id, rect);
    }
    const same =
      next.size === this.rects.size &&
      [...next].every(([id, r]) => {
        const o = this.rects.get(id);
        return o && Math.abs(o.left - r.left) < 0.01 && Math.abs(o.top - r.top) < 0.01 && Math.abs(o.width - r.width) < 0.01 && Math.abs(o.height - r.height) < 0.01;
      });
    if (same) return false;
    this.rects = next;
    this.listener?.(next);
    return true;
  }

  /** Liga cada nó ao pai certo do UIKit, na ordem dos filhos (Containers organizam por essa ordem). */
  private attach(tree: UiTreeEntry[], uiNodes: Record<string, HudNode>): void {
    const childrenOf = new Map<string | null, string[]>();
    for (const t of tree) childrenOf.set(t.parentId, [...(childrenOf.get(t.parentId) ?? []), t.id]);

    for (const id of childrenOf.get(null) ?? []) this.addTo(this.root, this.entries.get(id)!);

    for (const { id } of tree) {
      const kids = childrenOf.get(id) ?? [];
      const entry = this.entries.get(id)!;
      const kind = containerKindOf(uiNodes[id].type);
      const placed = (cid: string) => this.entries.get(cid)!.slot ?? this.entries.get(cid)!.box;

      if (kind === 'grid') {
        const columns = Math.max(1, Math.floor(num(uiNodes[id].properties?.columns, 2)));
        const rows = gridRows(kids, columns);
        entry.rows ??= [];
        // linhas de largura igual (colunas iguais); a última é completada com células vazias
        while (entry.rows.length > rows.length) entry.rows.pop()!.removeFromParent();
        while (entry.rows.length < rows.length) entry.rows.push(new Container());
        rows.forEach((row, r) => {
          const rowBox = entry.rows![r];
          rowBox.resetProperties({
            flexDirection: 'row',
            gap: Math.max(0, num(uiNodes[id].properties?.hSeparation, 8)),
            alignItems: 'stretch',
          } as never);
          const wanted: Container[] = row.map((cid) => (cid ? placed(cid) : new Container({ flexGrow: 1, flexBasis: 0 })));
          const real = wanted.filter((c) => kids.some((k) => placed(k) === c));
          const current = [...(rowBox.children as THREE.Object3D[])];
          const unchanged = current.length === wanted.length && current.every((c, i) => c === wanted[i]);
          if (!unchanged) {
            for (const c of current) (c as Container).removeFromParent();
            for (const c of wanted) rowBox.add(c);
          }
          void real;
        });
        for (const rowBox of entry.rows) entry.box.add(rowBox); // mantém a ordem das linhas
        continue;
      }
      if (kind) {
        const wanted = kids.map(placed);
        const own = Object.values(entry.parts) as THREE.Object3D[];
        const current = (entry.box.children as THREE.Object3D[]).filter((c) => !own.includes(c));
        const unchanged = current.length === wanted.length && current.every((c, i) => c === wanted[i]);
        if (!unchanged) {
          for (const c of wanted) c.removeFromParent();
          for (const c of wanted) entry.box.add(c);
        }
      } else {
        for (const cid of kids) this.addTo(entry.box, this.entries.get(cid)!);
      }
    }
  }

  private addTo(parent: Container, entry: Entry): void {
    const node = entry.slot ?? entry.box;
    if (node.parent !== parent) parent.add(node);
  }

  /** Propriedades de um nó: livre (absoluto, preset + offsets) ou em fluxo (slot + controle de um Container). */
  private applyNode(id: string, uiNodes: Record<string, HudNode>, parentId: string | null, parentSize: { w: number; h: number }): void {
    const node = uiNodes[id];
    const entry = this.entries.get(id)!;
    const p = node.properties ?? {};
    const parentKind: ContainerKind | null = parentId ? containerKindOf(uiNodes[parentId].type) : null;

    let box: Props;
    if (parentKind) {
      let flex = childFlex(parentKind, p);
      if (parentKind === 'grid') {
        // colunas de largura igual: o slot divide o espaço; `fill` (padrão) preenche a célula
        const flagged = { ...p, sizeFlagsH: parseSizeFlag(p.sizeFlagsH) === 'fill' ? 'expand-fill' : p.sizeFlagsH };
        const gridFlex = childFlex('row', flagged);
        flex = { slot: { ...gridFlex.slot, flexGrow: 1, flexBasis: 0 }, inner: gridFlex.inner };
      }
      if (!entry.slot) {
        entry.slot = new Container();
        entry.slot.add(entry.box);
      }
      entry.slot.resetProperties({ ...flex.slot, positionType: 'relative' } as never);
      box = { ...flex.inner, positionType: 'relative', flexShrink: 0 };
    } else {
      if (entry.slot) {
        entry.box.removeFromParent();
        entry.slot.removeFromParent();
        entry.slot = undefined;
      }
      const rect = computeOverlayScreenRect(readOverlayControl(node.type, p), { left: 0, top: 0, width: parentSize.w, height: parentSize.h });
      // o Yoga posiciona o absoluto a partir da borda INTERNA do pai: compensa a borda para o preset valer sobre o retângulo todo
      const inset = parentId ? borderWidthOf(uiNodes[parentId]) : 0;
      box = { positionType: 'absolute', positionLeft: rect.left - inset, positionTop: rect.top - inset, width: rect.width, height: rect.height };
    }

    this.applyVisual(entry, node, box);
  }

  /** Aparência e partes de cada tipo (o `box` já traz posição/tamanho). */
  private applyVisual(entry: Entry, node: HudNode, box: Props): void {
    const p = node.properties ?? {};
    const parts = entry.parts;

    switch (entry.type) {
      case 'Overlay2D':
      case 'Panel': {
        const isPanel = entry.type === 'Panel';
        const bg = colorOf(p.color, isPanel ? { r: 0.1, g: 0.13, b: 0.19, a: 0.9 } : { r: 0.15, g: 0.2, b: 0.28, a: 0.85 });
        const border = colorOf(p.borderColor, { r: 0.29, g: 0.51, b: 0.92, a: 1 });
        entry.box.resetProperties({
          ...box,
          backgroundColor: bg.rgba,
          borderWidth: num(p.borderWidth, isPanel ? 1 : 2),
          borderColor: border.rgba,
          borderRadius: isPanel ? num(p.cornerRadius, 6) : 4,
          alignItems: 'center',
          justifyContent: 'center',
          overflow: 'hidden',
        } as never);
        if (isPanel) break;
        // imagem opcional (`texture` → arquivo do projeto); sem imagem, o nome do nó como rótulo
        const src = typeof p.texture === 'string' && p.texture ? this.resolveTexture(p.texture) : null;
        if (src) {
          if (entry.imageSrc !== src) {
            parts.image?.removeFromParent();
            parts.image = new UIImage({ src, positionType: 'absolute', positionLeft: 0, positionTop: 0, width: '100%', height: '100%', objectFit: 'cover' });
            entry.box.add(parts.image);
            entry.imageSrc = src;
          }
          parts.label?.removeFromParent();
          parts.label = undefined;
        } else {
          if (parts.image) {
            parts.image.removeFromParent();
            parts.image = undefined;
            entry.imageSrc = undefined;
          }
          if (!parts.label) {
            parts.label = new UIText({ text: node.name, fontSize: 10, color: 0xdfe4ec });
            entry.box.add(parts.label);
          }
          parts.label.setProperties({ text: node.name });
        }
        break;
      }

      case 'TextOverlay2D': {
        const tc = colorOf(p.textColor, { r: 1, g: 1, b: 1, a: 1 });
        entry.box.resetProperties({ ...box, padding: 4, alignItems: 'flex-start', justifyContent: 'flex-start' } as never);
        if (!parts.label) {
          parts.label = new UIText({ text: '' });
          entry.box.add(parts.label);
        }
        parts.label.setProperties({
          // absoluto: a largura do texto não é limitada pela caixa (antes: `white-space: nowrap`)
          positionType: 'absolute',
          positionLeft: 4,
          positionTop: 4,
          text: typeof p.text === 'string' ? p.text : 'Text',
          fontSize: num(p.fontSize, 14),
          color: tc.hex,
          opacity: tc.opacity,
          fontWeight: 'semi-bold',
          whiteSpace: 'pre',
        });
        break;
      }

      case 'ButtonOverlay2D': {
        const bc = colorOf(p.buttonColor, { r: 0.16, g: 0.42, b: 0.85, a: 1 });
        const tc = colorOf(p.textColor, { r: 1, g: 1, b: 1, a: 1 });
        entry.box.resetProperties({
          ...box,
          backgroundColor: bc.rgba,
          borderWidth: 1,
          borderColor: [1, 1, 1, 0.2],
          borderRadius: 6,
          alignItems: 'center',
          justifyContent: 'center',
        } as never);
        if (!parts.label) {
          parts.label = new UIText({ text: '' });
          entry.box.add(parts.label);
        }
        parts.label.setProperties({ text: typeof p.text === 'string' ? p.text : 'Button', fontSize: num(p.fontSize, 13), color: tc.hex, fontWeight: 'medium' });
        break;
      }

      case 'CheckBox': {
        const tc = colorOf(p.textColor, { r: 1, g: 1, b: 1, a: 1 });
        entry.box.resetProperties({ ...box, flexDirection: 'row', alignItems: 'center', gap: 6 } as never);
        if (!parts.mark) {
          parts.mark = new Container();
          parts.tick = new Container();
          parts.mark.add(parts.tick);
          parts.label = new UIText({ text: '' });
          entry.box.add(parts.mark);
          entry.box.add(parts.label);
        }
        parts.mark.resetProperties({
          width: 16,
          height: 16,
          flexShrink: 0,
          borderWidth: 1,
          borderColor: [0.8, 0.85, 0.95, 0.7],
          borderRadius: 3,
          backgroundColor: rgbaOf(0.07, 0.09, 0.12, 1),
          alignItems: 'center',
          justifyContent: 'center',
        } as never);
        parts.tick.resetProperties({ width: 8, height: 8, borderRadius: 2, backgroundColor: p.checked ? rgbaOf(0.3, 0.87, 0.4, 1) : rgbaOf(0, 0, 0, 0) } as never);
        parts.label.setProperties({ text: typeof p.text === 'string' ? p.text : 'CheckBox', fontSize: num(p.fontSize, 13), color: tc.hex, opacity: tc.opacity });
        break;
      }

      case 'Slider':
      case 'ProgressBar': {
        const isSlider = entry.type === 'Slider';
        const t = pct(num(p.value, 50), num(p.min, 0), num(p.max, 100));
        entry.box.resetProperties({ ...box, justifyContent: 'center', alignItems: 'center' } as never);
        if (!parts.track) {
          parts.track = new Container();
          parts.fill = new Container();
          parts.track.add(parts.fill);
          entry.box.add(parts.track);
          if (isSlider) {
            parts.knob = new Container();
            entry.box.add(parts.knob);
          } else {
            parts.label = new UIText({ text: '' });
            entry.box.add(parts.label);
          }
        }
        parts.track.resetProperties({
          width: '100%',
          height: isSlider ? 4 : '100%',
          borderRadius: isSlider ? 2 : 4,
          backgroundColor: rgbaOf(0.1, 0.13, 0.19, 1),
          borderWidth: isSlider ? 0 : 1,
          borderColor: [1, 1, 1, 0.15],
          overflow: 'hidden',
        } as never);
        parts.fill.resetProperties({
          positionType: 'absolute',
          positionLeft: 0,
          positionTop: 0,
          width: `${t * 100}%`,
          height: '100%',
          backgroundColor: rgbaOf(0.29, 0.51, 0.92, 1),
        } as never);
        if (isSlider) {
          parts.knob.resetProperties({
            positionType: 'absolute',
            positionLeft: `${t * 100}%`,
            marginLeft: -7,
            width: 14,
            height: 14,
            borderRadius: 7,
            backgroundColor: rgbaOf(1, 1, 1, 1),
          } as never);
        } else {
          parts.label.setProperties({
            positionType: 'absolute',
            text: p.showPercent === false ? '' : `${Math.round(t * 100)}%`,
            fontSize: 11,
            color: 0xffffff,
          });
        }
        break;
      }

      case 'TextInput': {
        const tc = colorOf(p.textColor, { r: 1, g: 1, b: 1, a: 1 });
        const text = typeof p.text === 'string' ? p.text : '';
        entry.box.resetProperties({
          ...box,
          backgroundColor: rgbaOf(0.07, 0.09, 0.12, 1),
          borderWidth: 1,
          borderColor: rgbaOf(0.17, 0.2, 0.27, 1),
          borderRadius: 4,
          paddingLeft: 6,
          paddingRight: 6,
          alignItems: 'center',
          justifyContent: 'flex-start',
          overflow: 'hidden',
        } as never);
        if (!parts.label) {
          parts.label = new UIText({ text: '' });
          entry.box.add(parts.label);
        }
        parts.label.setProperties({
          text: text || (typeof p.placeholder === 'string' ? p.placeholder : ''),
          fontSize: num(p.fontSize, 13),
          color: text ? tc.hex : 0x7b8798,
        });
        break;
      }

      default: {
        // Containers: organizam os filhos (Yoga/Flexbox); sem fundo próprio
        entry.box.resetProperties({ ...box, ...containerFlexProps(node.type, p) } as never);
      }
    }
  }
}
