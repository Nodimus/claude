/**
 * AIS-40b — InputManager (runtime): UMA camada de input do JOGO, separada dos atalhos do editor (`useDesktopShortcuts`).
 *
 *   dispositivo físico (teclado/mouse) → InputManager → ação lógica ("MoveForward", "Jump", "Interact"…)
 *
 * Behaviors e Triggers leem AÇÕES (`isActionPressed`, `getAxis`…), nunca `KeyboardEvent.code`. O mapa ação → bindings é
 * dado (`InputMap`); trocar a tecla de uma ação muda todos os consumidores sem editar nenhum deles. O AIS-58 amplia e
 * remapeia ESTE contrato (gamepad, toque, mapa no projeto); não cria outro InputManager.
 *
 * Núcleo puro (sem DOM): recebe eventos por `handleKey`/`handleMouseButton`/`handlePointerMove`. Só `attach` toca o DOM, e
 * devolve SEMPRE um disposer (AIS-48b): Play/Stop repetido não acumula listeners, e fora de Play o manager fica desligado e
 * ignora qualquer evento (atalhos do editor nunca viram gameplay).
 */

/** `KeyboardEvent.code` (`KeyW`, `Space`, `ArrowUp`…) ou botão do mouse (`Mouse0` esquerdo, `Mouse1` meio, `Mouse2` direito). */
export type InputBinding = string;

/** Ação lógica → bindings que a ativam (qualquer um basta). */
export type InputMap = Record<string, readonly InputBinding[]>;

/** Mapa padrão (WASD e setas continuam funcionando). */
export const DEFAULT_INPUT_MAP: InputMap = {
  MoveForward: ['KeyW', 'ArrowUp'],
  MoveBackward: ['KeyS', 'ArrowDown'],
  MoveLeft: ['KeyA', 'ArrowLeft'],
  MoveRight: ['KeyD', 'ArrowRight'],
  Jump: ['Space'],
  Interact: ['KeyE'],
  Sprint: ['ShiftLeft', 'ShiftRight'],
  Crouch: ['ControlLeft', 'KeyC'],
  Fire: ['Mouse0'],
  AltFire: ['Mouse2'],
};

export const DEFAULT_INPUT_ACTIONS: readonly string[] = Object.keys(DEFAULT_INPUT_MAP);

export const MOUSE_BINDINGS: Record<'left' | 'middle' | 'right', InputBinding> = { left: 'Mouse0', middle: 'Mouse1', right: 'Mouse2' };
export const mouseBinding = (button: number): InputBinding => `Mouse${button}`;

/** Leitura de ações: o que Behaviors, Triggers e a simulação enxergam (nunca o dispositivo). */
export interface InputReader {
  isActionPressed(action: string): boolean;
  isActionJustPressed(action: string): boolean;
  isActionJustReleased(action: string): boolean;
  /** `-1`, `0` ou `+1`: `pos` pressionada menos `neg` pressionada. */
  getAxis(negative: string, positive: string): number;
}

export type InputPhase = 'pressed' | 'released';
export interface InputActionEvent {
  action: string;
  phase: InputPhase;
}

export interface PointerState {
  x: number;
  y: number;
  /** Deslocamento acumulado desde o último `endFrame`. */
  dx: number;
  dy: number;
}

/** Alvo de eventos mínimo (Window/HTMLElement; nos testes, um espião que conta add/remove). */
export interface InputEventTarget {
  addEventListener(type: string, listener: (event: any) => void, options?: unknown): void;
  removeEventListener(type: string, listener: (event: any) => void, options?: unknown): void;
}

export interface AttachTargets {
  /** Recebe teclado e `blur` (normalmente `window`). */
  keyTarget: InputEventTarget;
  /** Recebe mouse (normalmente o canvas/contêiner da viewport). */
  pointerTarget?: InputEventTarget;
  /** Foco em campo de texto: o jogo não rouba a digitação. Padrão: `input`/`textarea`/`select`/`contenteditable`. */
  isTextEntry?: (target: EventTarget | null) => boolean;
}

const defaultIsTextEntry = (target: EventTarget | null): boolean => {
  const t = target as { tagName?: string; isContentEditable?: boolean } | null;
  const tag = t?.tagName?.toUpperCase();
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || !!t?.isContentEditable;
};

export class InputManager implements InputReader {
  private map: Record<string, readonly InputBinding[]>;
  private down = new Set<InputBinding>();
  private justDown = new Set<InputBinding>();
  private justUp = new Set<InputBinding>();
  private actionJustPressed = new Set<string>();
  private actionJustReleased = new Set<string>();
  private listeners = new Set<(event: InputActionEvent) => void>();
  private detach: (() => void) | null = null;
  private active = false;
  private readonly pointerState: PointerState = { x: 0, y: 0, dx: 0, dy: 0 };

  constructor(map: InputMap = DEFAULT_INPUT_MAP) {
    this.map = this.copyMap(map);
  }

  // ── Mapa ────────────────────────────────────────────────────────────────────
  private copyMap(map: InputMap): Record<string, readonly InputBinding[]> {
    return Object.fromEntries(Object.entries(map).map(([action, bindings]) => [action, [...bindings]]));
  }

  getMap(): InputMap {
    return this.copyMap(this.map);
  }

  /** Troca o mapa inteiro (estado de entrada zerado: um binding antigo não fica "preso"). */
  setMap(map: InputMap): void {
    this.map = this.copyMap(map);
    this.releaseAll();
  }

  /** Remapeia UMA ação (ex.: `rebind('Jump', ['KeyJ'])`). */
  rebind(action: string, bindings: readonly InputBinding[]): void {
    this.map = { ...this.map, [action]: [...bindings] };
    this.releaseAll();
  }

  bindingsOf(action: string): readonly InputBinding[] {
    return this.map[action] ?? [];
  }

  /** Alguma ação usa este binding? (o DOM só impede o comportamento padrão — rolagem — de teclas do jogo). */
  isBound(binding: InputBinding): boolean {
    return Object.values(this.map).some((bindings) => bindings.includes(binding));
  }

  actions(): string[] {
    return Object.keys(this.map);
  }

  // ── Estado de ligado/desligado ──────────────────────────────────────────────
  /** Desligado = todo evento é ignorado e o estado fica zerado (fora de Play o jogo não "vê" teclas do editor). */
  get enabled(): boolean {
    return this.active;
  }

  setEnabled(enabled: boolean): void {
    this.active = enabled;
    if (!enabled) this.releaseAll();
  }

  // ── Entrada (alimentada por `attach` ou pelos testes) ───────────────────────
  private actionsUsing(binding: InputBinding): string[] {
    return Object.entries(this.map)
      .filter(([, bindings]) => bindings.includes(binding))
      .map(([action]) => action);
  }

  handleBinding(binding: InputBinding, isDown: boolean): void {
    if (!this.active) return;
    const wasDown = this.down.has(binding);
    if (isDown === wasDown) return; // repetição automática do teclado: nada muda
    const affected = this.actionsUsing(binding);
    const before = new Map(affected.map((action) => [action, this.isActionPressed(action)]));
    if (isDown) {
      this.down.add(binding);
      this.justDown.add(binding);
    } else {
      this.down.delete(binding);
      this.justUp.add(binding);
    }
    for (const action of affected) {
      const was = before.get(action) ?? false;
      const now = this.isActionPressed(action);
      if (was === now) continue; // outro binding da mesma ação continua pressionado
      (now ? this.actionJustPressed : this.actionJustReleased).add(action);
      this.emit({ action, phase: now ? 'pressed' : 'released' });
    }
  }

  handleKey(code: string, isDown: boolean): void {
    this.handleBinding(code, isDown);
  }

  handleMouseButton(button: number, isDown: boolean): void {
    this.handleBinding(mouseBinding(button), isDown);
  }

  handlePointerMove(x: number, y: number): void {
    if (!this.active) return;
    this.pointerState.dx += x - this.pointerState.x;
    this.pointerState.dy += y - this.pointerState.y;
    this.pointerState.x = x;
    this.pointerState.y = y;
  }

  /** AIS-47: deslocamento RELATIVO do ponteiro (PointerLock: `movementX/Y`; a posição fica parada). Soma ao deslocamento do quadro. */
  handlePointerDelta(dx: number, dy: number): void {
    if (!this.active) return;
    this.pointerState.dx += dx;
    this.pointerState.dy += dy;
  }

  /** Perda de foco da janela: solta tudo (senão a tecla soltada fora ficaria presa). */
  releaseAll(): void {
    if (this.active) {
      for (const binding of [...this.down]) this.handleBinding(binding, false);
    }
    this.down.clear();
    this.justDown.clear();
    this.justUp.clear();
    this.actionJustPressed.clear();
    this.actionJustReleased.clear();
    this.pointerState.dx = 0;
    this.pointerState.dy = 0;
  }

  /** Fim do quadro: `justPressed`/`justReleased` valem por UM quadro. Chamar uma vez por frame de simulação. */
  endFrame(): void {
    this.justDown.clear();
    this.justUp.clear();
    this.actionJustPressed.clear();
    this.actionJustReleased.clear();
    this.pointerState.dx = 0;
    this.pointerState.dy = 0;
  }

  // ── Leitura por ação ────────────────────────────────────────────────────────
  isActionPressed(action: string): boolean {
    return this.bindingsOf(action).some((binding) => this.down.has(binding));
  }

  isActionJustPressed(action: string): boolean {
    return this.actionJustPressed.has(action);
  }

  isActionJustReleased(action: string): boolean {
    return this.actionJustReleased.has(action);
  }

  getAxis(negative: string, positive: string): number {
    return (this.isActionPressed(positive) ? 1 : 0) - (this.isActionPressed(negative) ? 1 : 0);
  }

  // ── Leitura bruta (só Triggers de tecla/mouse; Behaviors usam ações) ────────
  isBindingPressed(binding: InputBinding): boolean {
    return this.down.has(binding);
  }
  isBindingJustPressed(binding: InputBinding): boolean {
    return this.justDown.has(binding);
  }
  isBindingJustReleased(binding: InputBinding): boolean {
    return this.justUp.has(binding);
  }

  get pointer(): Readonly<PointerState> {
    return this.pointerState;
  }

  // ── Assinaturas (sempre com disposer) ───────────────────────────────────────
  subscribe(listener: (event: InputActionEvent) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private emit(event: InputActionEvent): void {
    for (const listener of [...this.listeners]) listener(event);
  }

  get listenerCount(): number {
    return this.listeners.size;
  }

  // ── DOM ─────────────────────────────────────────────────────────────────────
  /**
   * Liga o manager aos eventos do DOM e o ATIVA. Devolve o disposer (remove TODOS os listeners e desliga). Chamar `attach` de
   * novo sem dispor antes descarta a ligação anterior: nunca há dois conjuntos de listeners (Play/Stop repetido, StrictMode).
   */
  attach(targets: AttachTargets): () => void {
    this.detach?.();
    const isTextEntry = targets.isTextEntry ?? defaultIsTextEntry;
    const cleanups: (() => void)[] = [];
    const on = (target: InputEventTarget | undefined, type: string, listener: (event: any) => void) => {
      if (!target) return;
      target.addEventListener(type, listener);
      cleanups.push(() => target.removeEventListener(type, listener));
    };

    on(targets.keyTarget, 'keydown', (e: KeyboardEvent) => {
      if (e.repeat || isTextEntry(e.target)) return;
      this.handleKey(e.code, true);
      if (this.isBound(e.code)) e.preventDefault(); // espaço/setas não rolam a página durante o jogo
    });
    on(targets.keyTarget, 'keyup', (e: KeyboardEvent) => this.handleKey(e.code, false));
    on(targets.keyTarget, 'blur', () => this.releaseAll());
    on(targets.pointerTarget, 'mousedown', (e: MouseEvent) => this.handleMouseButton(e.button, true));
    on(targets.pointerTarget, 'mouseup', (e: MouseEvent) => this.handleMouseButton(e.button, false));
    // com o ponteiro CAPTURADO (PointerLock) `clientX/Y` não muda: o olhar usa o deslocamento relativo (`movementX/Y`)
    on(targets.pointerTarget, 'mousemove', (e: MouseEvent) => {
      if (typeof document !== 'undefined' && document.pointerLockElement) this.handlePointerDelta(e.movementX ?? 0, e.movementY ?? 0);
      else this.handlePointerMove(e.clientX, e.clientY);
    });
    // soltar o botão fora do canvas também solta a ação
    on(targets.keyTarget, 'mouseup', (e: MouseEvent) => this.handleMouseButton(e.button, false));

    this.setEnabled(true);
    const dispose = () => {
      if (this.detach !== dispose) return; // já descartado (idempotente)
      this.detach = null;
      for (const cleanup of cleanups.splice(0)) cleanup();
      this.setEnabled(false);
    };
    this.detach = dispose;
    return dispose;
  }

  get attached(): boolean {
    return this.detach !== null;
  }
}
