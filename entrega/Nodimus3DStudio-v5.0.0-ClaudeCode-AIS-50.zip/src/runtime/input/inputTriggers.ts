/**
 * AIS-40b — Triggers de input avaliados SOBRE o InputManager (funções puras). O runtime (AIS-44/44b) chama
 * `evaluateInputTrigger` a cada quadro; nenhum Trigger lê `KeyboardEvent` nem registra listener próprio.
 *
 *  - `on_input_action` consulta uma AÇÃO (`Jump`, `Interact`…): é o caminho preferido (o remapeamento vale para todos).
 *  - `on_key_down` / `on_key_up` / `on_key_press` consultam uma tecla fixa pelo nome neutro do parâmetro `key`.
 *  - `on_mouse_down` consulta o botão; com `target: 'object'` o acerto no objeto (raycast) é do runtime (`needsPick`).
 */
import { MOUSE_BINDINGS, type InputBinding, type InputPhase, type InputReader } from './InputManager';

/** Leitura bruta por binding (o `InputManager` implementa; separada de `InputReader` para Behaviors não a usarem). */
export interface RawInputReader extends InputReader {
  isBindingPressed(binding: InputBinding): boolean;
  isBindingJustPressed(binding: InputBinding): boolean;
  isBindingJustReleased(binding: InputBinding): boolean;
  /** AIS-47: ponteiro (posição e deslocamento deste quadro em pixels) — olhar com mouse/PointerLock. Opcional (testes/leitores simples). */
  readonly pointer?: Readonly<{ x: number; y: number; dx: number; dy: number }>;
}

const NAMED_KEYS: Record<string, readonly string[]> = {
  space: ['Space'],
  esc: ['Escape'],
  escape: ['Escape'],
  enter: ['Enter'],
  tab: ['Tab'],
  shift: ['ShiftLeft', 'ShiftRight'],
  ctrl: ['ControlLeft', 'ControlRight'],
  control: ['ControlLeft', 'ControlRight'],
  alt: ['AltLeft', 'AltRight'],
  up: ['ArrowUp'],
  down: ['ArrowDown'],
  left: ['ArrowLeft'],
  right: ['ArrowRight'],
};

/** Nome amigável do parâmetro `key` (`w`, `W`, `Space`, `Shift`, `5`, `KeyW`) → `KeyboardEvent.code`(s). Vazio/ilegível = nenhum. */
export function keyCodesOf(key: unknown): readonly string[] {
  if (typeof key !== 'string') return [];
  const raw = key.trim();
  if (!raw) return [];
  if (/^[a-z]$/i.test(raw)) return [`Key${raw.toUpperCase()}`];
  if (/^\d$/.test(raw)) return [`Digit${raw}`];
  const named = NAMED_KEYS[raw.toLowerCase()];
  if (named) return named;
  return [raw]; // já é um `code` (KeyW, ArrowUp, F1…)
}

const BUTTONS = ['left', 'middle', 'right'] as const;

export interface InputTriggerResult {
  /** `false` = não é um Trigger de input (`on_start`, `on_update`…): o runtime avalia por outro caminho. */
  handled: boolean;
  fired: boolean;
  /** O botão disparou, mas só vale se o raycast acertar o objeto (`target: 'object'`). */
  needsPick?: boolean;
}

export const INPUT_TRIGGER_IDS: readonly string[] = ['on_input_action', 'on_key_down', 'on_key_up', 'on_key_press', 'on_mouse_down'];

export function evaluateInputTrigger(input: RawInputReader, eventType: string, params: Record<string, any> = {}): InputTriggerResult {
  const anyOf = (codes: readonly string[], test: (code: string) => boolean) => codes.some(test);
  switch (eventType) {
    case 'on_input_action': {
      const action = typeof params.action === 'string' ? params.action : '';
      const phase = (params.phase as InputPhase | 'held' | undefined) ?? 'pressed';
      const fired = !action ? false : phase === 'held' ? input.isActionPressed(action) : phase === 'released' ? input.isActionJustReleased(action) : input.isActionJustPressed(action);
      return { handled: true, fired };
    }
    case 'on_key_down':
    case 'on_key_press':
      return { handled: true, fired: anyOf(keyCodesOf(params.key), (c) => input.isBindingJustPressed(c)) };
    case 'on_key_up':
      return { handled: true, fired: anyOf(keyCodesOf(params.key), (c) => input.isBindingJustReleased(c)) };
    case 'on_mouse_down': {
      const button = BUTTONS.includes(params.button) ? (params.button as (typeof BUTTONS)[number]) : 'left';
      const fired = input.isBindingJustPressed(MOUSE_BINDINGS[button]);
      return { handled: true, fired, needsPick: fired && (params.target ?? 'object') === 'object' };
    }
    default:
      return { handled: false, fired: false };
  }
}
