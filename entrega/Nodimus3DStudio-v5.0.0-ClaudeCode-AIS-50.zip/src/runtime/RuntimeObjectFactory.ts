import * as THREE from 'three';
import type { RuntimeInstanceHandle } from '../types/runtime';
import { readNodeMaterial } from '../core/material/nodeMaterial';
import { createThreeMaterial } from '../utils/materialBuilder';
import { createModelObject, type ModelObjectHandle } from '../core/models/createModelObject';
import { getTerrainContext, syncTerrainMesh } from '../core/terrainObject';

/**
 * AIS-29d — ÚNICO ponto de criação e destruição de `THREE.Object3D` de runtime. O Viewport do editor continua dono dos
 * objetos de EDIÇÃO; o Play (AIS-44b/44c) e o jogo publicado usam esta fábrica para os objetos VIVOS do jogo, sem
 * compartilhar nenhum com o editor.
 *
 * Contabiliza o que criou: `destroy`/`dispose` liberam geometria, material e textura (nada de vazamento ao trocar de
 * cena) e `liveCount` permite provar que nada ficou para trás.
 */

type NodeLike = Pick<RuntimeInstanceHandle, 'type' | 'name' | 'properties'> & { persistentNodeId: string };

const num = (v: unknown, fallback: number) => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);

function geometryFor(meshType: string): THREE.BufferGeometry {
  switch (meshType) {
    case 'SphereMesh':
      return new THREE.SphereGeometry(0.7, 32, 24);
    case 'CylinderMesh':
      return new THREE.CylinderGeometry(0.6, 0.6, 1.6, 24);
    case 'PlaneMesh': {
      const g = new THREE.PlaneGeometry(1, 1);
      g.rotateX(-Math.PI / 2);
      return g;
    }
    case 'TorusMesh':
      return new THREE.TorusGeometry(0.6, 0.25, 16, 32);
    default:
      return new THREE.BoxGeometry(1, 1, 1);
  }
}

function lightColor(props: Record<string, any>): THREE.Color {
  const c = props.lightColor;
  return c && typeof c.r === 'number' ? new THREE.Color(c.r, c.g, c.b) : new THREE.Color(0xffffff);
}

export class RuntimeObjectFactory {
  private live = new Set<THREE.Object3D>();

  /** Objetos criados e ainda não destruídos (inclui filhos criados pela fábrica). */
  public get liveCount(): number {
    return this.live.size;
  }

  /** Cria o objeto de runtime de uma instância. Sem malha/luz/câmera própria, devolve um `Group` (container). */
  public create(node: NodeLike): THREE.Object3D {
    const props = node.properties ?? {};
    let object: THREE.Object3D;
    switch (node.type) {
      case 'MeshInstance': {
        // AIS-33a: nó com `model` = a MESMA `createModelObject` do editor (marcador → modelo); sem segunda construção no Play
        if (props.model && typeof props.model.id === 'string') {
          const o = props.modelOffset;
          object = createModelObject(props.model, {
            offset: { x: num(o?.x, 0), y: num(o?.y, 0), z: num(o?.z, 0) },
            castShadow: props.castShadow !== false,
            receiveShadow: props.receiveShadow !== false,
            materialProps: props, // AIS-35: o Play usa os mesmos slots/override do nó
          }).object;
          break;
        }
        const material = createThreeMaterial(readNodeMaterial(props, node.name));
        const mesh = new THREE.Mesh(geometryFor(String(props.meshType ?? 'CubeMesh')), material);
        mesh.castShadow = props.castShadow !== false;
        mesh.receiveShadow = props.receiveShadow !== false;
        object = mesh;
        break;
      }
      case 'Terrain': {
        // AIS-50: a MESMA fábrica de geometria do Viewport; o buffer de alturas vive em `userData.terrain` e alimenta o collider
        object = syncTerrainMesh(undefined, props, getTerrainContext()).mesh;
        break;
      }
      case 'DirectionalLight': {
        object = new THREE.DirectionalLight(lightColor(props), num(props.energy, 1));
        break;
      }
      case 'OmniLight': {
        object = new THREE.PointLight(lightColor(props), num(props.energy, 1), num(props.range, 0));
        break;
      }
      case 'SpotLight': {
        object = new THREE.SpotLight(lightColor(props), num(props.energy, 1), num(props.range, 0), THREE.MathUtils.degToRad(num(props.spotAngle, 45)));
        break;
      }
      case 'Camera': {
        object = new THREE.PerspectiveCamera(num(props.fov, 65), 16 / 9, num(props.near, 0.1), num(props.far, 1000));
        break;
      }
      default:
        object = new THREE.Group();
    }
    object.name = node.name;
    object.userData.runtimeNodeId = node.persistentNodeId;
    this.live.add(object);
    return object;
  }

  /** Aplica o transform da instância ao objeto (rotação em graus, como no autoral). */
  public applyTransform(object: THREE.Object3D, transform: RuntimeInstanceHandle['transform']): void {
    object.position.set(...transform.position);
    object.rotation.set(THREE.MathUtils.degToRad(transform.rotation[0]), THREE.MathUtils.degToRad(transform.rotation[1]), THREE.MathUtils.degToRad(transform.rotation[2]));
    object.scale.set(...transform.scale);
  }

  /** Destrói o objeto e libera geometria/material/textura. Filhos criados por esta fábrica saem da contagem. */
  public destroy(object: THREE.Object3D): void {
    object.removeFromParent();
    // AIS-33a: geometria/material de um modelo são do cache compartilhado — soltar a concessão, nunca descartar aqui
    const modelHolders: THREE.Object3D[] = [];
    object.traverse((child) => {
      if ((child.userData?.modelHandle as ModelObjectHandle | undefined) !== undefined) modelHolders.push(child);
    });
    const shared = new Set<THREE.Object3D>();
    for (const holder of modelHolders) {
      (holder.userData.modelHandle as ModelObjectHandle).release();
      holder.traverse((c) => shared.add(c));
    }
    object.traverse((child) => {
      if (shared.has(child)) {
        this.live.delete(child);
        return;
      }
      const mesh = child as THREE.Mesh;
      mesh.geometry?.dispose?.();
      const materials = Array.isArray(mesh.material) ? mesh.material : mesh.material ? [mesh.material] : [];
      for (const m of materials) {
        for (const value of Object.values(m)) if (value instanceof THREE.Texture) value.dispose();
        m.dispose();
      }
      (child as THREE.Light).dispose?.();
      this.live.delete(child);
    });
    this.live.delete(object);
  }

  /** Destrói tudo o que a fábrica ainda tem vivo (teardown de sessão/cena). */
  public dispose(): void {
    for (const object of [...this.live]) this.destroy(object);
    this.live.clear();
  }
}
