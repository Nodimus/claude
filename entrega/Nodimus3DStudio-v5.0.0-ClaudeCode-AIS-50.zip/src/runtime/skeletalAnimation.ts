/**
 * AIS-36 — retargeting para o esqueleto humanoide padrão de 19 ossos (decisão 1). FUNÇÃO CANÔNICA, usada pelo modal de import,
 * pelo Play e pelo Publish (mesmo padrão da decisão 24): nenhum consumidor reimplementa o mapeamento nem o renomear de trilhas.
 * Tudo aqui é puro (sem React/Three/DOM): os testes usam nomes de ossos e clipes sintéticos.
 *
 * Escopo v1 declarado: o retarget RENOMEIA trilhas pelos nomes canônicos e escala a translação do `Hips` pela razão de altura do
 * quadril. NÃO recalcula a diferença de pose de repouso (T-pose × A-pose): quando as poses de repouso são conhecidas e
 * divergem, devolve `anim.rest_pose_mismatch` em vez de fingir que resolveu.
 */
import { CANONICAL_BONES, emptyBoneMap, type BoneMap, type CanonicalBone } from '../schemas/v1/rig.schema';

export { CANONICAL_BONES, emptyBoneMap };
export type { BoneMap, CanonicalBone };

/** Obrigatórios para considerar o modelo humanoide: tronco, cabeça, ambos os braços e ambas as pernas. */
export const REQUIRED_BONES: readonly CanonicalBone[] = ['Hips', 'Spine', 'Head', 'LeftArm', 'RightArm', 'LeftUpLeg', 'LeftLeg', 'RightUpLeg', 'RightLeg'];

export type BoneSide = 'left' | 'right' | null;

// ── Nomes ──────────────────────────────────────────────────────────────────────────────────────────────

/** Prefixos de exportadores/rigs removidos antes de comparar (a ordem importa: o mais longo primeiro). */
const PREFIXES = [/^mixamorig[:_]?/i, /^armature[|_:.]?/i, /^def[-_]/i, /^org[-_]/i, /^mch[-_]/i, /^bip\d*[_ ]/i, /^j_bip_[lcr]_/i];

/** Parte do nome depois do último `|` ou `:` (namespaces de FBX/Collada). */
function stripNamespace(name: string): string {
  const cut = Math.max(name.lastIndexOf('|'), name.lastIndexOf(':'));
  return cut >= 0 ? name.slice(cut + 1) : name;
}

/** Lateralidade e nome-base de um osso (`mixamorig:LeftHand`, `DEF-hand.L`, `upperarm_r` → left/right + base normalizada). */
export function parseBoneName(name: string): { side: BoneSide; base: string } {
  let n = name.trim();
  let prefixSide: BoneSide = null;
  const bipedSide = /^j_bip_([lcr])_/i.exec(n); // VRM
  if (bipedSide) prefixSide = bipedSide[1].toLowerCase() === 'l' ? 'left' : bipedSide[1].toLowerCase() === 'r' ? 'right' : null;
  for (const re of PREFIXES) n = n.replace(re, '');
  n = stripNamespace(n);

  let side: BoneSide = prefixSide;
  const take = (re: RegExp, value: Exclude<BoneSide, null>) => {
    if (side === null && re.test(n)) {
      side = value;
      n = n.replace(re, '');
      return true;
    }
    return false;
  };
  // sufixos `.L` `_L` `-L` ` L` e `.L.001` (Rigify); prefixos `L_`, `Left`
  if (!take(/[._\- ]l(?=[._\-]\d+$|$)/i, 'left')) take(/[._\- ]r(?=[._\-]\d+$|$)/i, 'right');
  // lado COLADO no fim do nome depois que o three tirou o ponto (`DEF-hand.L` → `handL`, `upper_arm.R.001` → `upper_armR001`):
  // só `L`/`R` MAIÚSCULO depois de minúscula/`_` e antes de dígitos finais (não confunde `Hips`, `Chest`, `Head`, `Spine1`)
  if (side === null) {
    if (!take(/(?<=[a-z_])L(?=\d*$)/, 'left')) take(/(?<=[a-z_])R(?=\d*$)/, 'right');
  }
  if (side === null) {
    if (!take(/^left[._\- ]?/i, 'left')) take(/^right[._\- ]?/i, 'right');
  }
  if (side === null) {
    if (!take(/^l[._\-]/i, 'left')) take(/^r[._\-]/i, 'right');
  }
  if (side === null) {
    if (!take(/(?<=[a-z])[._\-]?left$/i, 'left')) take(/(?<=[a-z])[._\-]?right$/i, 'right');
  }
  const base = n.toLowerCase().replace(/[^a-z0-9]/g, '');
  return { side, base };
}

/** Nome normalizado para comparação: lateralidade (`left`/`right`) + base, sem prefixos, separadores nem caixa. */
export function normalizeBoneName(name: string): string {
  const { side, base } = parseBoneName(name);
  return `${side ?? ''}${base}`;
}

// ── Tabelas por convenção (nomes-base, sem lateralidade) ───────────────────────────────────────────────

/** Mixamo, Unity Humanoid, Godot Humanoid, VRM e variações comuns. */
const GENERIC: Record<string, readonly string[]> = {
  Hips: ['hips', 'hip', 'pelvis'],
  Spine: ['spine', 'spine0', 'abdomen'],
  Chest: ['chest', 'spine1'],
  Neck: ['neck', 'neck1'],
  Head: ['head'],
  Shoulder: ['shoulder', 'clavicle', 'collar'],
  Arm: ['arm', 'upperarm', 'uparm'],
  ForeArm: ['forearm', 'lowerarm', 'loarm'],
  Hand: ['hand', 'wrist'],
  UpLeg: ['upleg', 'upperleg', 'thigh', 'upleg0'],
  Leg: ['leg', 'lowerleg', 'calf', 'shin'],
  Foot: ['foot', 'ankle'],
};

/** Blender Rigify (ossos `DEF-*`): a coluna é `spine`, `spine.001`… e os membros usam `upper_arm`, `thigh`, `shin`. */
const RIGIFY: Record<string, readonly string[]> = {
  Hips: ['spine', 'pelvis'],
  Spine: ['spine001'],
  Chest: ['spine002'],
  Neck: ['spine004', 'spine005', 'neck'],
  Head: ['spine006', 'head'],
  Shoulder: ['shoulder'],
  Arm: ['upperarm'],
  ForeArm: ['forearm'],
  Hand: ['hand'],
  UpLeg: ['thigh'],
  Leg: ['shin'],
  Foot: ['foot'],
};

export type RigConvention = 'rigify' | 'generic';

/** Rigify é reconhecido pelo prefixo `DEF-`/`DEF_` dos ossos de deformação. */
export function detectConvention(boneNames: readonly string[]): RigConvention {
  return boneNames.some((n) => /^def[-_]/i.test(n.trim())) ? 'rigify' : 'generic';
}

function canonicalFor(table: Record<string, readonly string[]>, side: BoneSide, base: string): CanonicalBone | null {
  for (const [key, bases] of Object.entries(table)) {
    if (!bases.includes(base)) continue;
    const central = key === 'Hips' || key === 'Spine' || key === 'Chest' || key === 'Neck' || key === 'Head';
    if (central) return side === null ? (key as CanonicalBone) : null;
    if (side === null) return null;
    return `${side === 'left' ? 'Left' : 'Right'}${key}` as CanonicalBone;
  }
  return null;
}

export interface BoneMapping {
  map: BoneMap;
  /** Fração dos 19 ossos encontrados (0..1, 2 casas). */
  confidence: number;
  /** Canônicos sem osso (inclui opcionais como `Chest`). */
  missing: CanonicalBone[];
  convention: RigConvention;
}

/**
 * Mapeia os ossos do arquivo para os 19 canônicos. Dedos e dedos do pé não fazem parte dos 19 (ignorados). `Root/Hips` é UM osso:
 * `Root` só vale como `Hips` quando não há um osso de quadril de verdade. Empate: vale o primeiro osso na ordem do esqueleto.
 */
export function autoMapBones(boneNames: readonly string[]): BoneMapping {
  const convention = detectConvention(boneNames);
  const table = convention === 'rigify' ? RIGIFY : GENERIC;
  const map = emptyBoneMap();
  const rank = new Map<CanonicalBone, number>();
  boneNames.forEach((name) => {
    const { side, base } = parseBoneName(name);
    const bone = canonicalFor(table, side, base);
    if (!bone) return;
    // prioridade dentro da lista de sinônimos: o primeiro sinônimo (nome mais "oficial") vence
    const key = bone.replace(/^(Left|Right)/, '');
    const priority = table[key].indexOf(base);
    const current = rank.get(bone);
    if (current === undefined || priority < current) {
      map[bone] = name;
      rank.set(bone, priority);
    }
  });
  if (!map.Hips) {
    const root = boneNames.find((n) => parseBoneName(n).side === null && parseBoneName(n).base === 'root');
    if (root) map.Hips = root;
  }
  const missing = CANONICAL_BONES.filter((b) => !map[b]);
  const found = CANONICAL_BONES.length - missing.length;
  return { map, confidence: Math.round((found / CANONICAL_BONES.length) * 100) / 100, missing, convention };
}

/**
 * Segmentos do overlay do esqueleto: cada osso mapeado liga ao ancestral mapeado mais próximo (dedos e ossos de torção, que não
 * fazem parte dos 19, não poluem o desenho). `parentOf` = osso → pai (`null`/ausente = raiz).
 */
export function overlaySegments(parentOf: ReadonlyMap<string, string | null>, mapped: ReadonlySet<string>): [parent: string, child: string][] {
  const out: [string, string][] = [];
  for (const bone of mapped) {
    if (!parentOf.has(bone)) continue;
    let p = parentOf.get(bone) ?? null;
    const seen = new Set<string>([bone]);
    while (p && !mapped.has(p) && !seen.has(p)) {
      seen.add(p);
      p = parentOf.get(p) ?? null;
    }
    if (p && mapped.has(p) && p !== bone) out.push([p, bone]);
  }
  return out;
}

export interface RigValidation {
  /** Todos os obrigatórios presentes. */
  humanoid: boolean;
  missingRequired: CanonicalBone[];
  /** Opcionais ausentes (ex.: `Chest`, `Neck`, ombros). */
  missingOptional: CanonicalBone[];
  /** Mesmo osso do arquivo usado por mais de um canônico (erro de mapeamento manual). */
  duplicates: string[];
}

export function validateBoneMap(map: BoneMap): RigValidation {
  const missingRequired = REQUIRED_BONES.filter((b) => !map[b]);
  const missingOptional = CANONICAL_BONES.filter((b) => !map[b] && !REQUIRED_BONES.includes(b));
  const seen = new Map<string, number>();
  for (const b of CANONICAL_BONES) if (map[b]) seen.set(map[b]!, (seen.get(map[b]!) ?? 0) + 1);
  return { humanoid: missingRequired.length === 0, missingRequired, missingOptional, duplicates: [...seen].filter(([, n]) => n > 1).map(([name]) => name) };
}

/** Códigos de diagnóstico do rig (severidade na coluna): `rig.not_humanoid` info, `rig.missing_bones` warning. */
export function rigDiagnostics(boneNames: readonly string[], map: BoneMap): { code: 'rig.not_humanoid' | 'rig.missing_bones'; severity: 'info' | 'warning'; message: string }[] {
  if (boneNames.length === 0) return [{ code: 'rig.not_humanoid', severity: 'info', message: 'O modelo não tem esqueleto: nenhum rig foi gravado.' }];
  const v = validateBoneMap(map);
  if (v.humanoid) return v.duplicates.length ? [{ code: 'rig.missing_bones', severity: 'warning', message: `O mesmo osso foi usado em mais de um lugar: ${v.duplicates.join(', ')}.` }] : [];
  const found = CANONICAL_BONES.length - CANONICAL_BONES.filter((b) => !map[b]).length;
  // quase nenhum osso reconhecido = não humanoide; alguns reconhecidos mas faltando obrigatórios = ossos faltando
  if (found < 4) return [{ code: 'rig.not_humanoid', severity: 'info', message: 'O esqueleto não parece humanoide: nenhum rig foi gravado.' }];
  return [{ code: 'rig.missing_bones', severity: 'warning', message: `Ossos obrigatórios faltando: ${v.missingRequired.join(', ')}.` }];
}

// ── Retarget ───────────────────────────────────────────────────────────────────────────────────────────

export interface TrackLike {
  /** `<osso>.position | quaternion | scale`. */
  name: string;
  times: ArrayLike<number>;
  values: ArrayLike<number>;
}

export interface ClipLike {
  name: string;
  duration: number;
  tracks: TrackLike[];
}

export type Quat = readonly [number, number, number, number];

export interface RetargetOptions {
  /** Altura do quadril (m) nos dois esqueletos: a translação do `Hips` é escalada por `target / source`. */
  sourceHipHeight?: number;
  targetHipHeight?: number;
  /** Rotação local de repouso por osso canônico, quando conhecida (ex.: lida do `THREE.Skeleton`). */
  sourceRestPose?: Partial<Record<CanonicalBone, Quat>>;
  targetRestPose?: Partial<Record<CanonicalBone, Quat>>;
  /** Diferença angular (graus) a partir da qual as poses de repouso "divergem". Padrão 10°. */
  restToleranceDeg?: number;
  /**
   * Ossos que existem no esqueleto de DESTINO. Trilha cujo osso não existe lá (ex.: dedos de outro rig) é descartada em vez de
   * copiada: o three avisa `No target node found` para cada trilha sem alvo.
   */
  targetBones?: ReadonlySet<string>;
}

export interface RetargetWarning {
  code: 'anim.rest_pose_mismatch' | 'anim.target_bone_missing';
  message: string;
  bones: CanonicalBone[];
}

export interface RetargetResult {
  clip: ClipLike;
  warnings: RetargetWarning[];
  /** Trilhas descartadas (osso mapeado na origem, mas sem osso no alvo). */
  dropped: string[];
  /** Trilhas de ossos fora dos 19 (dedos…), copiadas sem renomear (só as que existem no destino, se `targetBones` foi dado). */
  passthrough: string[];
  /** Trilhas descartadas por não haver o osso no esqueleto de destino (`targetBones`). */
  unmatched: string[];
}

const splitTrack = (name: string): { bone: string; prop: string } => {
  const cut = name.lastIndexOf('.');
  return cut < 0 ? { bone: name, prop: '' } : { bone: name.slice(0, cut), prop: name.slice(cut + 1) };
};

/** Ângulo (graus) entre duas rotações em quaternion. */
export function quaternionAngleDeg(a: Quat, b: Quat): number {
  const dot = Math.abs(a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]);
  return (2 * Math.acos(Math.min(1, dot)) * 180) / Math.PI;
}

/** Ossos canônicos cujas poses de repouso divergem além da tolerância (só onde as duas poses são conhecidas). */
export function restPoseMismatches(source: RetargetOptions['sourceRestPose'], target: RetargetOptions['targetRestPose'], toleranceDeg = 10): CanonicalBone[] {
  if (!source || !target) return [];
  return CANONICAL_BONES.filter((b) => {
    const s = source[b];
    const t = target[b];
    return !!s && !!t && quaternionAngleDeg(s, t) > toleranceDeg;
  });
}

/**
 * Renomeia as trilhas de `clip` do esqueleto de origem para os ossos do alvo, passando pelos nomes canônicos. Não muta o clipe de
 * entrada (as trilhas devolvidas têm cópias dos arrays). Ver o cabeçalho para os limites da v1.
 */
export function retargetClip(clip: ClipLike, sourceMap: BoneMap, targetMap: BoneMap, options: RetargetOptions = {}): RetargetResult {
  const canonicalOfSource = new Map<string, CanonicalBone>();
  for (const bone of CANONICAL_BONES) if (sourceMap[bone]) canonicalOfSource.set(sourceMap[bone]!, bone);

  const hipRatio =
    options.sourceHipHeight && options.targetHipHeight && options.sourceHipHeight > 0 && options.targetHipHeight > 0 ? options.targetHipHeight / options.sourceHipHeight : 1;

  const tracks: TrackLike[] = [];
  const dropped: string[] = [];
  const passthrough: string[] = [];
  const unmatched: string[] = [];
  const missingTarget = new Set<CanonicalBone>();

  for (const track of clip.tracks) {
    const { bone, prop } = splitTrack(track.name);
    const canonical = canonicalOfSource.get(bone);
    const copy = (name: string, values: ArrayLike<number> = track.values): TrackLike => ({ name, times: Array.from(track.times), values: Array.from(values) });
    if (!canonical) {
      if (options.targetBones && !options.targetBones.has(bone)) {
        unmatched.push(track.name);
        continue;
      }
      passthrough.push(track.name);
      tracks.push(copy(track.name));
      continue;
    }
    const targetBone = targetMap[canonical];
    if (!targetBone) {
      dropped.push(track.name);
      missingTarget.add(canonical);
      continue;
    }
    const scaleHips = canonical === 'Hips' && prop === 'position' && hipRatio !== 1;
    tracks.push(copy(`${targetBone}.${prop}`, scaleHips ? Array.from(track.values, (v) => v * hipRatio) : track.values));
  }

  const warnings: RetargetWarning[] = [];
  if (missingTarget.size > 0) {
    const bones = [...missingTarget];
    warnings.push({ code: 'anim.target_bone_missing', message: `O alvo não tem estes ossos; as trilhas foram descartadas: ${bones.join(', ')}.`, bones });
  }
  const mismatched = restPoseMismatches(options.sourceRestPose, options.targetRestPose, options.restToleranceDeg);
  if (mismatched.length > 0) {
    warnings.push({
      code: 'anim.rest_pose_mismatch',
      message: `As poses de repouso diferem (ex.: T-pose × A-pose) em ${mismatched.join(', ')}; o retarget v1 não corrige a pose, só renomeia as trilhas.`,
      bones: mismatched,
    });
  }
  return { clip: { name: clip.name, duration: clip.duration, tracks }, warnings, dropped, passthrough, unmatched };
}

/**
 * Descarta as trilhas cujo osso não existe no esqueleto do modelo (sem renomear nada): clipe de arquivo extra num modelo não
 * humanoide, onde não há retarget. Não muta a entrada.
 */
export function filterTracksToBones(clip: ClipLike, bones: ReadonlySet<string>): { clip: ClipLike; unmatched: string[] } {
  const unmatched: string[] = [];
  const tracks: TrackLike[] = [];
  for (const t of clip.tracks) {
    const cut = t.name.lastIndexOf('.');
    const bone = cut < 0 ? t.name : t.name.slice(0, cut);
    if (bones.has(bone)) tracks.push({ name: t.name, times: Array.from(t.times), values: Array.from(t.values) });
    else unmatched.push(t.name);
  }
  return { clip: { name: clip.name, duration: clip.duration, tracks }, unmatched };
}

// ── Amostragem (tempo → pose) e estado do mixer (AIS-37) ───────────────────────────────────────────────

export const PREVIEW_FPS = 30;
export const MIN_SPEED = 0.25;
export const MAX_SPEED = 2;

/** Quadros exibidos para uma duração (mínimo 1). */
export const frameCount = (duration: number, fps = PREVIEW_FPS): number => Math.max(1, Math.round(duration * fps) + 1);
export const frameToTime = (frame: number, fps = PREVIEW_FPS): number => frame / fps;
export const timeToFrame = (time: number, fps = PREVIEW_FPS): number => Math.round(time * fps);

/** Tempo dentro do clipe: com `loop` dá a volta (módulo); sem `loop` prende em [0, duration]. */
export function wrapClipTime(time: number, duration: number, loop: boolean): number {
  if (!(duration > 0)) return 0;
  if (loop) return ((time % duration) + duration) % duration;
  return Math.min(duration, Math.max(0, time));
}

function slerp(a: ArrayLike<number>, ia: number, b: ArrayLike<number>, ib: number, t: number): number[] {
  let [bx, by, bz, bw] = [b[ib], b[ib + 1], b[ib + 2], b[ib + 3]];
  let dot = a[ia] * bx + a[ia + 1] * by + a[ia + 2] * bz + a[ia + 3] * bw;
  if (dot < 0) {
    bx = -bx;
    by = -by;
    bz = -bz;
    bw = -bw;
    dot = -dot;
  }
  let s0 = 1 - t;
  let s1 = t;
  if (dot < 0.9995) {
    const theta = Math.acos(dot);
    const sin = Math.sin(theta);
    s0 = Math.sin((1 - t) * theta) / sin;
    s1 = Math.sin(t * theta) / sin;
  }
  const out = [a[ia] * s0 + bx * s1, a[ia + 1] * s0 + by * s1, a[ia + 2] * s0 + bz * s1, a[ia + 3] * s0 + bw * s1];
  const len = Math.hypot(out[0], out[1], out[2], out[3]) || 1;
  return out.map((v) => v / len);
}

/**
 * Pose de um clipe num instante: `{ '<osso>.<propriedade>': valor }`. Posição e escala interpolam linearmente; `quaternion`,
 * por slerp. Função canônica (modal, Play e Publish): o Play (AIS-60) a consome.
 */
export function sampleClipAt(clip: ClipLike, time: number, options: { loop?: boolean } = {}): Record<string, number[]> {
  const t = wrapClipTime(time, clip.duration, options.loop ?? true);
  const pose: Record<string, number[]> = {};
  for (const track of clip.tracks) {
    const n = track.times.length;
    if (n === 0) continue;
    const stride = Math.round(track.values.length / n);
    const isQuat = track.name.endsWith('.quaternion');
    if (stride !== (isQuat ? 4 : 3) || n * stride !== track.values.length) continue; // trilha malformada: ignorada, nunca inventada
    let i = 0;
    while (i < n - 1 && track.times[i + 1] <= t) i++;
    if (i >= n - 1 || t <= track.times[0]) {
      const k = (t <= track.times[0] ? 0 : n - 1) * stride;
      pose[track.name] = Array.from({ length: stride }, (_, c) => track.values[k + c]);
      continue;
    }
    const span = track.times[i + 1] - track.times[i];
    const f = span > 0 ? (t - track.times[i]) / span : 0;
    const a = i * stride;
    const b = (i + 1) * stride;
    pose[track.name] = isQuat ? slerp(track.values, a, track.values, b, f) : Array.from({ length: stride }, (_, c) => track.values[a + c] * (1 - f) + track.values[b + c] * f);
  }
  return pose;
}

export interface MixerClipInfo {
  name: string;
  duration: number;
}

export interface MixerLayer {
  clip: string;
  time: number;
  weight: number;
}

export interface ClipMixerState {
  clip: string | null;
  time: number;
  speed: number;
  loop: boolean;
  playing: boolean;
  /** Crossfade em curso: o clipe anterior continua até o peso chegar a 0 (tempos em segundos). */
  fade: { from: string; fromTime: number; seconds: number; elapsed: number } | null;
}

export interface ClipMixer {
  state(): Readonly<ClipMixerState>;
  /** Camadas a aplicar (1 sem crossfade; 2 durante): `time` já dentro do clipe e `weight` somando 1. */
  layers(): MixerLayer[];
  select(name: string): void;
  play(): void;
  pause(): void;
  toggle(): void;
  setSpeed(speed: number): void;
  setLoop(loop: boolean): void;
  seek(time: number): void;
  /** Anda `delta` quadros (negativo volta), em `fps` (padrão 30) e pausa. */
  stepFrame(delta: number, fps?: number): void;
  /** Avança `dt` segundos reais (a velocidade só escala a reprodução, não o crossfade). */
  step(dt: number): void;
  /** Crossfade para outro clipe em `seconds` (≥ 0; 0 = troca seca), com peso 1 e velocidade explícitos. */
  crossFadeTo(name: string, seconds: number): void;
}

/**
 * Estado puro do player do modal (play/pausa, scrub por quadro, velocidade 0,25×–2×, loop, crossfade). Nada de Three aqui:
 * a ponte (`core/models/clipPlayer.ts`) aplica `layers()` ao `THREE.AnimationMixer`.
 */
export function createClipMixer(clips: readonly MixerClipInfo[]): ClipMixer {
  const durations = new Map(clips.map((c) => [c.name, c.duration]));
  const s: ClipMixerState = { clip: clips[0]?.name ?? null, time: 0, speed: 1, loop: true, playing: false, fade: null };
  const dur = (name: string | null) => (name ? durations.get(name) ?? 0 : 0);

  const mixer: ClipMixer = {
    state: () => ({ ...s, fade: s.fade ? { ...s.fade } : null }),
    layers() {
      if (!s.clip) return [];
      if (!s.fade) return [{ clip: s.clip, time: s.time, weight: 1 }];
      const w = s.fade.seconds > 0 ? Math.min(1, s.fade.elapsed / s.fade.seconds) : 1;
      return [
        { clip: s.fade.from, time: s.fade.fromTime, weight: 1 - w },
        { clip: s.clip, time: s.time, weight: w },
      ];
    },
    select(name) {
      if (!durations.has(name)) return;
      s.clip = name;
      s.time = 0;
      s.fade = null;
    },
    play() {
      if (!s.clip) return;
      if (!s.loop && s.time >= dur(s.clip)) s.time = 0; // recomeça um clipe que já terminou
      s.playing = true;
    },
    pause() {
      s.playing = false;
    },
    toggle() {
      if (s.playing) mixer.pause();
      else mixer.play();
    },
    setSpeed(speed) {
      s.speed = Math.min(MAX_SPEED, Math.max(MIN_SPEED, Number.isFinite(speed) ? speed : 1));
    },
    setLoop(loop) {
      s.loop = loop;
      s.time = wrapClipTime(s.time, dur(s.clip), loop);
    },
    seek(time) {
      s.time = Math.min(dur(s.clip), Math.max(0, Number.isFinite(time) ? time : 0));
    },
    stepFrame(delta, fps = PREVIEW_FPS) {
      s.playing = false;
      s.fade = null;
      const frame = Math.min(frameCount(dur(s.clip), fps) - 1, Math.max(0, timeToFrame(s.time, fps) + delta));
      s.time = Math.min(dur(s.clip), frameToTime(frame, fps));
    },
    step(dt) {
      if (!(dt > 0)) return;
      if (s.fade) {
        s.fade.elapsed += dt;
        s.fade.fromTime = wrapClipTime(s.fade.fromTime + dt * s.speed, dur(s.fade.from), true);
        if (s.fade.elapsed >= s.fade.seconds) s.fade = null;
      }
      if (!s.playing || !s.clip) return;
      const next = s.time + dt * s.speed;
      const d = dur(s.clip);
      if (s.loop) s.time = wrapClipTime(next, d, true);
      else if (next >= d) {
        s.time = d;
        s.playing = false;
      } else s.time = next;
    },
    crossFadeTo(name, seconds) {
      if (!durations.has(name) || name === s.clip) return;
      const secs = Number.isFinite(seconds) ? Math.max(0, seconds) : 0;
      s.fade = s.clip && secs > 0 ? { from: s.clip, fromTime: s.time, seconds: secs, elapsed: 0 } : null;
      s.clip = name;
      s.time = 0;
      s.playing = true;
    },
  };
  return mixer;
}

export type Vec3Tuple = readonly [number, number, number];

/**
 * Eixo VERTICAL (0 = X, 1 = Y, 2 = Z) no espaço local do osso raiz, pela posição de bind: a componente de maior valor absoluto é a
 * altura do quadril. O Mixamo exportado em glTF/FBX traz o `Hips` com a altura em -Z e o avanço em Y (pré-rotação de Z-up);
 * outros rigs têm a altura em Y. Sem posição conhecida, assume Y.
 */
export function verticalAxisOf(bindPosition: Vec3Tuple | null | undefined): 0 | 1 | 2 {
  if (!bindPosition) return 1;
  const [x, y, z] = bindPosition.map(Math.abs);
  if (x === 0 && y === 0 && z === 0) return 1;
  return y >= x && y >= z ? 1 : z >= x ? 2 : 0;
}

/**
 * Remove o deslocamento HORIZONTAL do osso raiz: o clipe vira IN-PLACE (padrão com física, para não duplicar o deslocamento).
 * Congela, no primeiro quadro, as duas componentes que não são a altura (`verticalAxis`, padrão Y) e mantém a altura e todas as
 * outras trilhas. Não muta a entrada.
 */
export function stripRootMotion(clip: ClipLike, rootBone: string | null, verticalAxis: 0 | 1 | 2 = 1): ClipLike {
  return {
    name: clip.name,
    duration: clip.duration,
    tracks: clip.tracks.map((t) => {
      const values = Array.from(t.values);
      if (rootBone && t.name === `${rootBone}.position` && values.length >= 3 && values.length % 3 === 0) {
        const first = [values[0], values[1], values[2]];
        for (let i = 0; i < values.length; i += 3) {
          for (let axis = 0; axis < 3; axis++) if (axis !== verticalAxis) values[i + axis] = first[axis];
        }
      }
      return { name: t.name, times: Array.from(t.times), values };
    }),
  };
}
