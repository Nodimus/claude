import { beforeAll, describe, expect, it } from 'vitest';
import type { GameNode } from '../types/node';
import type { SceneData } from '../types/scene';
import type { BehaviorInstance } from '../types/visualLogic';
import { createDefault3DStarterScene } from '../core/defaultProject';
import { createRuntimeSnapshot } from '../core/authoring/snapshot';
import { ensureRapier } from '../core/physics/rapierInit';
import { LogicRegistry } from '../logic/registry';
import { BehaviorRuntimeCatalog } from '../logic/behaviorRuntime';
import { InputManager } from './input/InputManager';
import { RuntimeSession } from './RuntimeSession';
import type { LogicLogEntry } from './logicRunner';
import { rotateByQuat } from './controllers/controllerMath';

/**
 * AIS-47 — controladores de 1ª e 3ª pessoa DENTRO da `RuntimeSession`, com a física real (`PhysicsBridge`) e o `InputManager` real:
 * o Behavior só emite intenção; gravidade, colisão e chão são do `character` (KinematicCharacterController); o pulo é pela ponte;
 * a câmera de jogo sai depois do passo da física.
 */

beforeAll(async () => {
  await ensureRapier();
});

let seq = 0;
const controller = (type: 'first_person_controller' | 'third_person_controller', properties: Record<string, any> = {}): BehaviorInstance => ({
  id: `b${++seq}`,
  name: type,
  behaviorType: type,
  enabled: true,
  properties,
  rules: [],
});

const node = (id: string, at: [number, number, number], extra: Record<string, any> = {}, nodeExtra: Record<string, any> = {}): GameNode =>
  ({
    id,
    name: id,
    type: 'MeshInstance',
    parentId: null,
    childrenIds: [],
    visible: true,
    locked: false,
    properties: { meshType: 'CubeMesh', position: { x: at[0], y: at[1], z: at[2] }, ...extra },
    ...nodeExtra,
  }) as unknown as GameNode;

function sceneWith(...extra: GameNode[]): SceneData {
  const scene = createDefault3DStarterScene();
  const root = scene.nodes[scene.rootNodeId];
  const nodes: Record<string, GameNode> = { [root.id]: { ...root, childrenIds: extra.map((n) => n.id) } as GameNode };
  for (const n of extra) nodes[n.id] = { ...n, parentId: root.id } as GameNode;
  return { ...scene, nodes };
}

const FLOOR = node('floor', [0, -0.5, 0], { scale: { x: 80, y: 1, z: 80 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } });
const CHARACTER = { enabled: true, bodyMode: 'character', shape: 'capsule' };

const hero = (type: 'first_person_controller' | 'third_person_controller', props: Record<string, any> = {}, extra: Record<string, any> = {}) =>
  node('hero', [0, 2, 0], { scale: { x: 1, y: 1.8, z: 1 }, physics: CHARACTER, ...extra }, { behaviors: [controller(type, props)] });

function open(scene: SceneData) {
  const input = new InputManager();
  input.setEnabled(true);
  const logs: LogicLogEntry[] = [];
  const session = new RuntimeSession({ snapshot: createRuntimeSnapshot(scene), input, onLog: (e) => logs.push(e) });
  session.start();
  const frame = (n = 1) => {
    for (let i = 0; i < n; i++) {
      session.step(1 / 60);
      input.endFrame(); // como o loop da viewport
    }
  };
  const pos = () => session.getSimulatedTransform('hero')!.position;
  return { session, input, logs, frame, pos };
}

describe('registro e presets (decisão 21)', () => {
  it('os dois Behaviors existem no LogicRegistry com preset e executor próprio', () => {
    for (const id of ['first_person_controller', 'third_person_controller']) {
      expect(LogicRegistry.isKnownBehavior(id)).toBe(true);
      expect(BehaviorRuntimeCatalog.get(id)?.replacesRules).toBe(true);
      const def = LogicRegistry.getBehavior(id)!;
      expect(def.preset).toBeDefined();
      const created = def.create({ targetNodeId: 'hero' });
      expect(created.rules).toEqual([]);
      // todos os parâmetros declarados têm valor inicial coerente com o `default`
      for (const p of def.params) expect(created.properties[p.key]).toBe(p.default);
    }
    expect(LogicRegistry.listBehaviorPresets().map((b) => b.id)).toEqual(expect.arrayContaining(['first_person_controller', 'third_person_controller']));
  });

  it('não há parâmetros sem execução (CanFly/CollidesWithWorld/EnableInclination não existem)', () => {
    const keys = ['first_person_controller', 'third_person_controller'].flatMap((id) => LogicRegistry.getBehavior(id)!.params.map((p) => p.key));
    for (const forbidden of ['canFly', 'collidesWithWorld', 'enableInclination']) expect(keys).not.toContain(forbidden);
  });
});

describe('FirstPersonController na sessão (AIS-47)', () => {
  it('cai pela gravidade da física, pousa e FICA no chão (sem gravidade dupla nem chão fixo em y = 0)', () => {
    const { session, frame, pos } = open(sceneWith(FLOOR, hero('first_person_controller')));
    expect(session.physics?.modeOf('hero')).toBe('character'); // nunca dynamic
    frame(120);
    expect(session.physics!.isGrounded('hero')).toBe(true);
    const y = pos()[1];
    expect(y).toBeGreaterThan(0.85);
    expect(y).toBeLessThan(1.1);
    frame(60);
    expect(Math.abs(pos()[1] - y)).toBeLessThan(0.005); // parado: sem afundar nem tremer
  });

  it('WASD anda relativo ao olhar; o mouse (PointerLock) vira e o pitch é limitado', () => {
    const { input, frame, pos } = open(sceneWith(FLOOR, hero('first_person_controller', { moveSpeed: 5, rotateSpeed: 0.15, maxVerticalAngle: 80 })));
    frame(90);
    const z0 = pos()[2];
    input.handleKey('KeyW', true);
    frame(60);
    input.handleKey('KeyW', false);
    expect(z0 - pos()[2]).toBeGreaterThan(4); // ≈ 5 m para -Z em 1 s
    expect(Math.abs(pos()[0])).toBeLessThan(0.1);

    // vira 90° para a esquerda (mouse -600 px × 0.15°) e anda: agora vai para -X
    input.handlePointerDelta(-600, 0);
    frame(1);
    const x0 = pos()[0];
    input.handleKey('KeyW', true);
    frame(60);
    input.handleKey('KeyW', false);
    expect(x0 - pos()[0]).toBeGreaterThan(4);

    input.handlePointerDelta(0, -100000); // olhar para cima ao máximo
    frame(1);
  });

  it('a câmera de jogo fica nos olhos (pose simulada, depois da física) e olha na direção do yaw/pitch', () => {
    const { session, input, frame, pos } = open(sceneWith(FLOOR, hero('first_person_controller', { eyeHeight: 1.6, fov: 75, maxVerticalAngle: 70 })));
    frame(120);
    const cam = session.gameCamera!;
    expect(cam).not.toBeNull();
    expect(cam.pointerLock).toBe(true);
    expect(cam.fov).toBe(75);
    expect(cam.position.y).toBeCloseTo(pos()[1] + 1.6, 3);
    expect(cam.position.x).toBeCloseTo(pos()[0], 3);
    expect(rotateByQuat({ x: 0, y: 0, z: -1 }, cam.quaternion).z).toBeCloseTo(-1, 3);
    input.handlePointerDelta(0, -100000);
    frame(1);
    const up = rotateByQuat({ x: 0, y: 0, z: -1 }, session.gameCamera!.quaternion);
    expect(up.y).toBeCloseTo(Math.sin((70 * Math.PI) / 180), 2); // pitch preso em 70°
  });

  it('o corpo do personagem some da própria câmera (visible=false só na instância de runtime)', () => {
    const { session } = open(sceneWith(FLOOR, hero('first_person_controller')));
    expect(session.scene.getInstance('hero')!.visible).toBe(false);
    expect(session.snapshot.nodes.hero.visible).toBe(true); // o clone/authoring não muda
  });

  it('pulo: só no chão, por setLinearVelocity da ponte; sobe, desce e não pula de novo no ar', () => {
    const { session, input, frame, pos } = open(sceneWith(FLOOR, hero('first_person_controller', { jumpSpeed: 6 })));
    frame(120);
    const ground = pos()[1];
    input.handleKey('Space', true);
    frame(1);
    input.handleKey('Space', false);
    let peak = ground;
    for (let i = 0; i < 40; i++) {
      frame(1);
      peak = Math.max(peak, pos()[1]);
    }
    expect(peak - ground).toBeGreaterThan(0.8); // v²/2g ≈ 1.8 m
    expect(peak - ground).toBeLessThan(2.2);
    // no ar: outro pulo é ignorado
    const airborne = pos()[1] > ground + 0.2;
    if (airborne) {
      input.handleKey('Space', true);
      frame(1);
      input.handleKey('Space', false);
    }
    frame(240);
    expect(session.physics!.isGrounded('hero')).toBe(true);
    expect(Math.abs(pos()[1] - ground)).toBeLessThan(0.02); // voltou ao mesmo chão
  });

  it('Jump é uma AÇÃO: remapear a tecla muda o pulo sem editar o Behavior', () => {
    const { session, input, frame, pos } = open(sceneWith(FLOOR, hero('first_person_controller')));
    input.rebind('Jump', ['KeyJ']);
    frame(120);
    const ground = pos()[1];
    input.handleKey('Space', true); // tecla antiga: não pula
    frame(5);
    input.handleKey('Space', false);
    expect(pos()[1]).toBeLessThan(ground + 0.05);
    input.handleKey('KeyJ', true);
    frame(5);
    input.handleKey('KeyJ', false);
    expect(pos()[1]).toBeGreaterThan(ground + 0.1);
    expect(session.status).toBe('running');
  });

  it('não atravessa a parede (colisão do KinematicCharacterController)', () => {
    const wall = node('wall', [3, 2, 0], { scale: { x: 1, y: 4, z: 20 }, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } });
    const { input, frame, pos } = open(sceneWith(FLOOR, wall, hero('first_person_controller', { moveSpeed: 6 })));
    frame(90);
    input.handleKey('KeyD', true); // direita = +X, em direção à parede em x = 2.5
    frame(120);
    expect(pos()[0]).toBeLessThan(2.1);
    expect(pos()[0]).toBeGreaterThan(1.5);
  });

  it('sem corpo "character": avisa UMA vez com o motivo e não quebra (anda, sem gravidade)', () => {
    const { logs, frame } = open(sceneWith(FLOOR, node('hero', [0, 2, 0], {}, { behaviors: [controller('first_person_controller')] })));
    frame(150);
    const warns = logs.filter((l) => l.level === 'warn' && /First Person Controller/.test(l.message));
    expect(warns).toHaveLength(1);
    expect(warns[0].message).toContain('character');
  });

  it('corpo "dynamic" no lugar de "character": avisa e diz qual modo é', () => {
    const { logs, frame } = open(sceneWith(FLOOR, hero('first_person_controller', {}, { physics: { enabled: true, bodyMode: 'dynamic', shape: 'capsule' } })));
    frame(30);
    expect(logs.some((l) => l.level === 'warn' && l.message.includes('"dynamic"'))).toBe(true);
  });
});

describe('ThirdPersonController na sessão (AIS-47)', () => {
  it('anda relativo à câmera, o personagem se volta para onde anda e a câmera segue com suavização elástica', () => {
    const { session, input, frame, pos } = open(sceneWith(FLOOR, hero('third_person_controller', { moveSpeed: 5, followSmoothingSpeed: 4, distance: 6, targetHeight: 1 })));
    frame(120);
    const ground = pos()[1];
    expect(session.gameCamera!.pointerLock).toBe(false);
    input.handleKey('KeyD', true); // direita (+X) em relação à câmera (atrás, olhando -Z)
    frame(60);
    expect(pos()[0]).toBeGreaterThan(3.5);
    expect(Math.abs(pos()[1] - ground)).toBeLessThan(0.02); // sem gravidade dupla: segue no chão
    // o personagem olha para +X: yaw ≈ -90°
    const yaw = session.getSimulatedTransform('hero')!.rotation[1];
    expect(yaw).toBeLessThan(-60);
    // a câmera ficou ATRASADA em relação ao ponto ideal (seguimento elástico) e depois alcança
    const lag = () => Math.abs(session.gameCamera!.position.x - pos()[0]);
    const lagMoving = lag();
    input.handleKey('KeyD', false);
    frame(240);
    expect(lag()).toBeLessThan(lagMoving);
    expect(lag()).toBeLessThan(0.3);
    expect(session.gameCamera!.position.y).toBeGreaterThan(pos()[1]); // acima, olhando para o alvo
  });

  it('a órbita só gira com o botão direito (AltFire) e muda a direção "para frente"', () => {
    const { session, input, frame, pos } = open(sceneWith(FLOOR, hero('third_person_controller', { rotateSpeed: 0.3, moveSpeed: 5 })));
    frame(120);
    const camX0 = session.gameCamera!.position.x;
    input.handlePointerDelta(300, 0); // mouse solto: nada gira
    frame(1);
    expect(session.gameCamera!.position.x).toBeCloseTo(camX0, 2);

    input.handleMouseButton(2, true); // botão direito
    input.handlePointerDelta(-300, 0); // -300 × 0.3° = +90° de yaw da órbita
    frame(1);
    input.handleMouseButton(2, false);
    frame(120);
    expect(Math.abs(session.gameCamera!.position.x - pos()[0])).toBeGreaterThan(4); // a câmera foi para o lado (órbita 90°)
    const x0 = pos()[0];
    input.handleKey('KeyW', true); // "para frente" agora é -X
    frame(60);
    expect(x0 - pos()[0]).toBeGreaterThan(3.5);
  });

  it('pulo e Pause: pausar congela o controlador; avançar 1 quadro move exatamente um passo', () => {
    const { session, input, frame, pos } = open(sceneWith(FLOOR, hero('third_person_controller')));
    frame(120);
    input.handleKey('KeyW', true);
    frame(10);
    session.pause();
    const p0 = pos().slice();
    const cam0 = { ...session.gameCamera!.position };
    frame(30);
    expect(pos()).toEqual(p0);
    expect(session.gameCamera!.position).toEqual(cam0);
    session.stepFrame();
    expect(pos()[2]).toBeLessThan(p0[2]); // um quadro de movimento
    expect(p0[2] - pos()[2]).toBeLessThan(0.2); // só um quadro
  });
});

describe('ciclo de vida e isolamento', () => {
  it('sem controlador na cena não há câmera de jogo (a viewport segue a orbital do editor)', () => {
    const { session, frame } = open(sceneWith(FLOOR, node('crate', [0, 3, 0], { physics: { enabled: true, bodyMode: 'dynamic', shape: 'auto' } })));
    frame(30);
    expect(session.gameCamera).toBeNull();
  });

  it('Stop/dispose descarta a câmera de jogo e o Behavior; o authoring não muda', () => {
    const scene = sceneWith(FLOOR, hero('first_person_controller'));
    const before = JSON.stringify(scene);
    const { session, frame } = open(scene);
    frame(60);
    expect(session.gameCamera).not.toBeNull();
    session.dispose();
    expect(session.gameCamera).toBeNull();
    expect(JSON.stringify(scene)).toBe(before);
  });

  it('Restart Behavior recomeça só o controlador (yaw/pitch zerados) e Restart Scene devolve o personagem ao início', () => {
    const { session, input, frame, pos } = open(sceneWith(FLOOR, hero('first_person_controller', { rotateSpeed: 0.15 })));
    frame(120);
    input.handlePointerDelta(-600, 0); // 90° à esquerda
    frame(1);
    const turned = rotateByQuat({ x: 0, y: 0, z: -1 }, session.gameCamera!.quaternion);
    expect(turned.x).toBeLessThan(-0.9);
    expect(session.restartBehavior('hero', session.snapshot.nodes.hero.behaviors![0].id)).toBe(true);
    frame(1);
    const reset = rotateByQuat({ x: 0, y: 0, z: -1 }, session.gameCamera!.quaternion);
    expect(reset.z).toBeLessThan(-0.9); // voltou a olhar para -Z
    input.handleKey('KeyW', true);
    frame(60);
    input.handleKey('KeyW', false);
    expect(session.restartScene()).toBe(true);
    frame(1);
    expect(pos()[0]).toBeCloseTo(0, 1);
    expect(pos()[2]).toBeCloseTo(0, 1); // de volta ao ponto inicial
  });

  it('5 ciclos Play/Stop com controlador: câmera e mundo liberados todas as vezes', () => {
    const bridges = [];
    for (let i = 0; i < 5; i++) {
      const { session, frame } = open(sceneWith(FLOOR, hero('third_person_controller')));
      frame(30);
      expect(session.gameCamera).not.toBeNull();
      bridges.push(session.physics!);
      session.dispose();
      expect(session.gameCamera).toBeNull();
    }
    expect(bridges.every((b) => b.isDisposed)).toBe(true);
  });
});
