import * as THREE from 'three';
import type { AuthoringSceneSnapshot } from '../types/runtime';
import type { BehaviorInstance, LogicEventRule } from '../types/visualLogic';
import type { ActionRuntimeContext, ConditionNode } from '../logic/types';
import { ActionRuntime } from '../logic/actionRuntime';
import { evaluateConditionOrNull, type ConditionWorld } from '../logic/evaluateCondition';
import { validateAction } from '../logic/validateAction';
import { LogicRegistry } from '../logic/registry';
import { evaluateInputTrigger, type RawInputReader } from './input/inputTriggers';
import { BehaviorRuntimeStates } from './behaviorRuntimeState';
import type { RuntimeInstance, RuntimeScene } from './RuntimeScene';
import type { VariableChange, VariableManager } from '../core/variableManager';
import type { PhysicsBridge } from '../core/physics/PhysicsBridge';

/**
 * AIS-44 — LogicRunner: interpretador determinístico de Visual Logic (Behaviors → regras Trigger → Condition → Action).
 *
 * Opera sobre a cena VIVA (`RuntimeScene`, construída de um snapshot): lê as regras do snapshot e escreve só em
 * `RuntimeInstance`/variáveis da sessão — nunca no authoring nem no CommandManager (invariantes 4 e 5 de `types/runtime.ts`).
 * É independente de React/DOM/relógio: o tempo vem de `step(dt)` (pausar = não chamar `step`), o input vem de um
 * `RawInputReader` e os eventos de ponteiro/colisão/sinal chegam por `notify*`/`dispatch*`. O `RuntimeSession` (AIS-44b)
 * passa a ser quem o cria e chama `step`; até lá, `logicRunnerSession.ts` faz essa ponte.
 *
 * Política de execução (skill nodimus-play-mode / emenda 3.1):
 *  - Actions rodam em ORDEM, de forma síncrona; efeito assíncrono (Promise) é fire-and-continue e nunca bloqueia o quadro.
 *  - Operação estrutural destrutiva (`'stop'`: destruir o próprio nó, reiniciar, sair) aborta o resto da cadeia.
 *  - Action inválida/desabilitada/sem executor NUNCA é ignorada em silêncio: vira entrada de log (`error`/`warn`/`info`).
 *  - `run_script` fica desabilitada até o AIS-79 (sandbox): é ignorada sem erro, com uma linha informativa.
 */

export type LogicLogLevel = 'info' | 'warn' | 'error';

/** AIS-48b — contexto de um log/diagnóstico: o MESMO registro do `globalDiagnosticService` o carrega (nunca um tipo paralelo). */
export interface LogicLogMeta {
  code?: string;
  behaviorId?: string;
  logicId?: string;
}

export interface LogicLogEntry extends LogicLogMeta {
  /** ID da instância viva (`RuntimeInstance.id`) dona do log. */
  instanceId?: string;
  /** Segundos de jogo (`sceneTime`) em que a entrada foi emitida. */
  time: number;
  level: LogicLogLevel;
  message: string;
  nodeName?: string;
  /** ID autoral do nó dono (diagnósticos contextuais da sessão). */
  nodeId?: string;
  /** Escreve também no painel Output (Actions de log do usuário, avisos e erros). */
  toOutput: boolean;
}

export interface LogicRunnerHost {
  onLog?(entry: LogicLogEntry): void;
  /** AIS-48b: um sinal foi processado (`emit_signal`/`dispatchSignal`): a sessão repassa aos assinantes (`onSignal`). */
  onSignalEmitted?(name: string): void;
  /** Pedidos de ciclo de vida: chamados DEPOIS da cadeia atual, no fim do `step`. */
  onRestartScene?(): void;
  onQuitGame?(): void;
  /** AIS-44b: pedido de troca de cena (caminho `res://…`); a sessão aborta as cadeias, descarta e carrega a nova. */
  onChangeScene?(scenePath: string): void;
  /** Propriedades de UI mudaram (HUD precisa redesenhar; a cena 3D não). */
  onUiChanged?(): void;
}

export interface LogicRunnerOptions {
  scene: RuntimeScene;
  snapshot: AuthoringSceneSnapshot;
  variables: VariableManager | null;
  input: RawInputReader;
  host?: LogicRunnerHost;
  /** Injetado nos testes; padrão `Math.random`. */
  random?: () => number;
  /** `true` loga também cada disparo de `on_update`/inputs contínuos (padrão: só erros nesses). */
  verbose?: boolean;
  /** AIS-44b: Behaviors cujo executor por propriedades (`behaviors/<id>/runtime.ts`) substitui as `rules` de preset. */
  skipRules?: (behavior: BehaviorInstance) => boolean;
  /** AIS-44b: estados por (nó × Behavior) compartilhados com o lifecycle dos Behaviors (da sessão). */
  behaviorStates?: BehaviorRuntimeStates;
  /** AIS-45: ponte física atual da sessão (pode surgir depois da criação do runner, quando o Rapier termina de carregar). */
  physics?: () => PhysicsBridge | null;
}

interface CompiledRule {
  nodeId: string;
  behavior: BehaviorInstance;
  rule: LogicEventRule;
  /** Acumuladores próprios da regra (temporizador). */
  elapsed: number;
  done: boolean;
}

type RunnerEvent =
  | { kind: 'signal'; name: string }
  | { kind: 'click'; nodeId: string; button: string }
  | { kind: 'hover'; nodeId: string; phase: 'enter' | 'exit' }
  | { kind: 'collision'; type: ContactTrigger; nodeId: string; otherId: string; force?: number }
  | { kind: 'variable'; change: VariableChange };

interface Scheduled {
  at: number;
  fn: () => void;
}

const BUTTONS = ['left', 'middle', 'right'];
/** AIS-48: os quatro Triggers físicos (Enter/Exit; nunca Stay). */
export type ContactTrigger = 'on_collision_enter' | 'on_collision_exit' | 'on_trigger_enter' | 'on_trigger_exit';
/** Teto de lotes de eventos por quadro: um laço de sinais/variáveis não trava o quadro (o resto segue no próximo). */
const MAX_EVENT_PASSES = 32;
/**
 * Triggers que podem disparar todo quadro: só aparecem no log em modo verbose (senão o Debugger vira ruído). `on_key_*` e
 * `on_mouse_down` NÃO entram: disparam uma vez por aperto/soltura, então cada disparo é um evento que vale registrar.
 */
const CONTINUOUS_TRIGGERS: ReadonlySet<string> = new Set(['on_update', 'on_input_action']);

export class LogicRunner {
  private readonly scene: RuntimeScene;
  private readonly input: RawInputReader;
  private readonly variables: VariableManager | null;
  private readonly host: LogicRunnerHost;
  private readonly random: () => number;
  private readonly verbose: boolean;
  private readonly rules: CompiledRule[] = [];
  /** Estado mutável por (nó × Behavior): nunca no authoring. */
  public readonly behaviorStates: BehaviorRuntimeStates;

  private time = 0;
  private started = false;
  private disposed = false;
  private queue: RunnerEvent[] = [];
  private scheduled: Scheduled[] = [];
  private rotations = new Map<string, { instance: RuntimeInstance; axis: 'x' | 'y' | 'z'; dps: number }>();
  private velocities = new Map<string, { instance: RuntimeInstance; v: { x: number; y: number; z: number }; space: 'world' | 'local' }>();
  private readonly physicsOf: () => PhysicsBridge | null;
  private pointerHit: string | null = null;
  private pendingRestart = false;
  private pendingQuit = false;
  private pendingChange: string | null = null;
  /** AIS-44b: troca/restart/abort invalida cadeias em andamento (nunca continuam sobre cena destruída). */
  private generation = 0;
  private readonly skipRules: (behavior: BehaviorInstance) => boolean;
  private readonly reported = new Set<string>();
  private readonly disposers: (() => void)[] = [];
  private _uiRevision = 0;
  private _executions = 0;

  constructor(options: LogicRunnerOptions) {
    this.scene = options.scene;
    this.input = options.input;
    this.variables = options.variables;
    this.host = options.host ?? {};
    this.random = options.random ?? Math.random;
    this.verbose = options.verbose ?? false;
    this.skipRules = options.skipRules ?? (() => false);
    this.physicsOf = options.physics ?? (() => null);
    this.behaviorStates = options.behaviorStates ?? new BehaviorRuntimeStates();
    this.compile(options.snapshot);
    if (this.variables) this.disposers.push(this.variables.onVariableChanged((change) => this.queue.push({ kind: 'variable', change })));
  }

  /** Incrementa a cada mudança de propriedade de UI feita por Actions (o host redesenha o HUD quando muda). */
  public get uiRevision(): number {
    return this._uiRevision;
  }
  public get sceneTime(): number {
    return this.time;
  }
  /** Quantas regras já executaram (todas as Actions de uma regra contam uma vez). */
  public get executions(): number {
    return this._executions;
  }
  public get ruleCount(): number {
    return this.rules.length;
  }
  public get isDisposed(): boolean {
    return this.disposed;
  }

  private compile(snapshot: AuthoringSceneSnapshot): void {
    for (const node of Object.values(snapshot.nodes)) {
      if (!this.scene.getInstance(node.id)) continue;
      for (const behavior of node.behaviors ?? []) {
        if (this.skipRules(behavior)) continue;
        for (const rule of behavior.rules ?? []) {
          this.rules.push({ nodeId: node.id, behavior, rule, elapsed: 0, done: false });
          if (!LogicRegistry.isKnownTrigger(rule.eventType)) {
            this.report(`unknown-trigger:${rule.id}`, 'warn', `Trigger "${rule.eventType}" desconhecido neste editor: a regra de "${node.name}" foi preservada, mas não executa.`, undefined, { code: 'trigger.unknown', behaviorId: behavior.id, logicId: rule.eventType });
          }
        }
      }
    }
  }

  // ── entrada de eventos (host) ─────────────────────────────────────────────────────────────────

  /** Clique do mouse sobre um objeto 3D (raycast) ou controle de UI, já resolvido para o ID do nó. */
  public notifyClick(nodeId: string, button: 'left' | 'middle' | 'right' = 'left'): void {
    if (!this.disposed) this.queue.push({ kind: 'click', nodeId, button });
  }

  /** Nó sob o ponteiro neste quadro (`null` = nenhum): rastreia entrada/saída e alimenta `on_mouse_down` com alvo. */
  public setPointerTarget(nodeId: string | null): void {
    if (this.disposed || nodeId === this.pointerHit) return;
    const previous = this.pointerHit;
    this.pointerHit = nodeId;
    if (previous) this.queue.push({ kind: 'hover', nodeId: previous, phase: 'exit' });
    if (nodeId) this.queue.push({ kind: 'hover', nodeId, phase: 'enter' });
  }

  public dispatchSignal(name: string): void {
    if (!this.disposed) this.queue.push({ kind: 'signal', name });
  }

  /** Contato físico (a ponte física do AIS-45 chama): dispara a regra dos DOIS corpos. */
  /** Contato físico de UM lado (a ponte física entrega um evento por participante): dispara só as regras do `selfId`. */
  public dispatchContact(type: ContactTrigger, selfId: string, otherId: string, force?: number): void {
    if (!this.disposed) this.queue.push({ kind: 'collision', type, nodeId: selfId, otherId, force });
  }

  public dispatchCollision(type: ContactTrigger, aId: string, bId: string): void {
    if (this.disposed) return;
    this.queue.push({ kind: 'collision', type, nodeId: aId, otherId: bId }, { kind: 'collision', type, nodeId: bId, otherId: aId });
  }

  /** Agenda `fn` daqui a `seconds` segundos de jogo (não bloqueia; só avança com `step`). */
  public schedule(seconds: number, fn: () => void): void {
    if (this.disposed) return;
    this.scheduled.push({ at: this.time + Math.max(0, seconds), fn });
  }

  // ── quadro ────────────────────────────────────────────────────────────────────────────────────

  public step(dt: number): void {
    if (this.disposed) return;
    const delta = Number.isFinite(dt) && dt > 0 ? dt : 0;
    this.time += delta;

    this.runDueTimers();
    if (!this.started) {
      this.started = true;
      for (const c of this.rules) if (c.rule.eventType === 'on_start') this.fire(c, 'on_start');
    }
    this.applyRotations(delta);
    this.applyVelocities(delta);

    for (const c of this.rules) {
      if (this.disposed) return;
      this.evaluatePolling(c, delta);
    }
    this.drainEvents();
    this.finishFrame();
  }

  private runDueTimers(): void {
    if (this.scheduled.length === 0) return;
    const due = this.scheduled.filter((s) => s.at <= this.time).sort((a, b) => a.at - b.at);
    this.scheduled = this.scheduled.filter((s) => s.at > this.time);
    for (const s of due) {
      try {
        s.fn();
      } catch (error) {
        this.report(`timer:${String(error)}`, 'error', `Erro em ação agendada: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
  }

  /** Movimento contínuo de nós sem corpo dinâmico (kinematic/trigger seguem esta pose pela ponte física). */
  private applyVelocities(dt: number): void {
    for (const [id, m] of this.velocities) {
      if (m.instance.disposed) {
        this.velocities.delete(id);
        continue;
      }
      let { x, y, z } = m.v;
      if (m.space === 'local') {
        const [rx, ry, rz] = m.instance.transform.rotation.map((d) => (d * Math.PI) / 180);
        const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz, 'XYZ'));
        const r = new THREE.Vector3(x, y, z).applyQuaternion(q);
        ({ x, y, z } = r);
      }
      const p = m.instance.transform.position;
      m.instance.transform.position = [p[0] + x * dt, p[1] + y * dt, p[2] + z * dt];
      this.scene.applyInstanceTransform(m.instance);
    }
  }

  private applyRotations(dt: number): void {
    for (const [id, r] of this.rotations) {
      if (r.instance.disposed) {
        this.rotations.delete(id);
        continue;
      }
      const index = r.axis === 'x' ? 0 : r.axis === 'y' ? 1 : 2;
      const next: [number, number, number] = [...r.instance.transform.rotation];
      next[index] += r.dps * dt;
      r.instance.transform.rotation = next;
      this.scene.applyInstanceTransform(r.instance);
    }
  }

  /** Triggers avaliados por quadro (tempo e input). Os demais chegam pela fila de eventos. */
  private evaluatePolling(c: CompiledRule, dt: number): void {
    const type = c.rule.eventType;
    if (type === 'on_update') return void this.fire(c, type);
    if (type === 'on_timeout') {
      if (c.done) return;
      const interval = Math.max(0.01, Number(c.rule.parameters.interval) || 1);
      const repeat = c.rule.parameters.repeat !== false;
      c.elapsed += dt;
      while (c.elapsed >= interval && !c.done && !this.disposed) {
        c.elapsed -= interval;
        if (!repeat) c.done = true;
        this.fire(c, type);
      }
      return;
    }
    const result = evaluateInputTrigger(this.input, type, c.rule.parameters);
    if (!result.handled || !result.fired) return;
    if (result.needsPick && !(this.pointerHit && this.isSelfOrDescendant(this.pointerHit, c.nodeId))) return;
    this.fire(c, type);
  }

  private drainEvents(): void {
    for (let pass = 0; pass < MAX_EVENT_PASSES && this.queue.length > 0 && !this.disposed; pass++) {
      const batch = this.queue;
      this.queue = [];
      for (const event of batch) this.dispatch(event);
    }
    if (this.queue.length > 0) {
      this.report('event-loop', 'warn', `Mais de ${MAX_EVENT_PASSES} lotes de eventos no mesmo quadro (sinal/variável em laço?): o restante segue no próximo quadro.`);
    }
  }

  private dispatch(event: RunnerEvent): void {
    switch (event.kind) {
      case 'signal':
        try {
          this.host.onSignalEmitted?.(event.name);
        } catch (error) {
          this.report(`signal-listener:${event.name}`, 'error', `Assinante do sinal "${event.name}" falhou: ${error instanceof Error ? error.message : String(error)}`, undefined, { code: 'runtime.listener_failed' });
        }
        for (const c of this.rules) if (c.rule.eventType === 'on_signal' && c.rule.parameters.signal === event.name) this.fire(c, 'on_signal', `sinal "${event.name}"`);
        return;
      case 'click': {
        const owner = this.bubbleTo(event.nodeId, 'on_click');
        if (!owner) return;
        for (const c of this.rulesOf(owner, 'on_click')) {
          const wanted = BUTTONS.includes(c.rule.parameters.button) ? c.rule.parameters.button : 'left';
          if (wanted === event.button) this.fire(c, 'on_click', `clique ${event.button}`);
        }
        return;
      }
      case 'hover': {
        const owner = this.bubbleTo(event.nodeId, 'on_hover');
        if (!owner) return;
        for (const c of this.rulesOf(owner, 'on_hover')) {
          if ((c.rule.parameters.phase === 'exit' ? 'exit' : 'enter') === event.phase) this.fire(c, 'on_hover', `ponteiro ${event.phase === 'enter' ? 'entrou' : 'saiu'}`);
        }
        return;
      }
      case 'collision':
        for (const c of this.rulesOf(event.nodeId, event.type)) {
          if (event.type === 'on_collision_enter' && !this.impactAllowed(c, event.force ?? 0)) continue; // força mínima + debounce (legado do Behavior de impacto)
          const other = this.scene.getInstance(event.otherId)?.name ?? event.otherId;
          this.fire(c, event.type, `${event.type.startsWith('on_trigger') ? 'gatilho' : 'contato'} com "${other}"${event.force !== undefined && event.type === 'on_collision_enter' ? ` (força ${event.force.toFixed(1)} N)` : ''}`);
        }
        return;
      case 'variable': {
        const { change } = event;
        for (const c of this.rules) {
          if (c.rule.eventType !== 'on_variable_changed') continue;
          const p = c.rule.parameters;
          if ((p.scope === 'local' ? 'local' : 'global') !== change.scope || p.variable !== change.name) continue;
          if (change.scope === 'local') {
            const owner = this.scene.getInstance(typeof p.target === 'string' && p.target.trim() ? p.target.trim() : c.nodeId) ?? this.findByName(String(p.target));
            if (owner?.persistentNodeId !== change.nodeId) continue;
          }
          this.fire(c, 'on_variable_changed', `${change.name}: ${String(change.oldValue)} → ${String(change.newValue)}`);
        }
        return;
      }
    }
  }

  // ── execução de uma regra ─────────────────────────────────────────────────────────────────────

  /** Contexto da regra/Action em execução (vira `behaviorId`/`logicId` do diagnóstico). */
  private current: { behaviorId?: string; logicId?: string } = {};

  private fire(c: CompiledRule, trigger: string, detail?: string): void {
    const previous = this.current;
    this.current = { behaviorId: c.behavior.id };
    try {
      this.fireRule(c, trigger, detail);
    } finally {
      this.current = previous;
    }
  }

  private fireRule(c: CompiledRule, trigger: string, detail?: string): void {
    if (this.disposed || this.structuralPending()) return;
    const self = this.scene.getInstance(c.nodeId);
    if (!self || self.disposed || !c.behavior.enabled) return;
    const ruleLabel = `${self.name} › ${c.behavior.name}`;

    const world = this.conditionWorld(self);
    for (const condition of c.rule.conditions) {
      const verdict = evaluateConditionOrNull({ type: condition.type, parameters: condition.parameters }, world);
      if (verdict === null) {
        this.report(`cond:${c.rule.id}:${condition.id}`, 'warn', `${ruleLabel}: a Condition "${condition.type}" não pôde ser avaliada (desconhecida ou com parâmetros inválidos); a regra não executa.`, self, { code: 'condition.unresolved', logicId: condition.type });
        return;
      }
      if (!verdict) return;
    }

    this._executions++;
    const noisy = CONTINUOUS_TRIGGERS.has(trigger) && !this.verbose;
    if (!noisy) this.log('info', `▶ ${ruleLabel} · ${trigger}${detail ? ` (${detail})` : ''} → ${c.rule.actions.length} action(s)`, self);

    const ctx = this.actionContext(self);
    const generation = this.generation;
    for (let i = 0; i < c.rule.actions.length; i++) {
      if (this.disposed || self.disposed || generation !== this.generation || this.structuralPending()) {
        if (!noisy && i < c.rule.actions.length) this.log('info', `■ cadeia de ${ruleLabel} abortada (nó ou cena destruído, ou troca/restart de cena).`, self);
        return;
      }
      const action = c.rule.actions[i];
      const stop = this.runAction(action, ctx, self, `${ruleLabel} #${i + 1}`, noisy);
      if (stop) {
        if (!noisy) this.log('info', `■ cadeia de ${ruleLabel} encerrada após "${action.type}".`, self);
        return;
      }
    }
  }

  /** `true` = a cadeia deve parar. */
  private runAction(action: { id: string; type: string; parameters: Record<string, any> }, ctx: ActionRuntimeContext, self: RuntimeInstance, where: string, noisy: boolean): boolean {
    const refParam = typeof action.parameters?.target === 'string' ? action.parameters.target.trim() : '';
    const target = this.scene.getInstance(refParam) ?? (refParam ? this.findByName(refParam) : self);
    const validated = validateAction({ type: action.type, parameters: action.parameters }, { target: target ? this.toConditionNode(target) : undefined });
    if (!validated.ok) {
      const key = `act:${action.id}:${validated.code}`;
      const meta = { code: validated.code, logicId: action.type };
      if (validated.code === 'action.disabled') this.report(key, 'info', `${where}: ${validated.message}`, self, meta);
      else this.report(key, 'error', `${where}: ${validated.message}`, self, meta);
      return false;
    }
    const executor = ActionRuntime.get(action.type);
    if (!executor) {
      this.report(`noexec:${action.type}`, 'warn', `${where}: a Action "${action.type}" ainda não tem executor no runtime (depende de um sistema posterior); não foi executada.`, self, { code: 'action.no_executor', logicId: action.type });
      return false;
    }
    const previousCurrent = this.current;
    this.current = { ...previousCurrent, logicId: action.type };
    const meta = { code: 'action.failed', logicId: action.type, behaviorId: previousCurrent.behaviorId };
    try {
      const outcome = executor(validated.params, ctx);
      if (outcome && typeof (outcome as Promise<unknown>).then === 'function') {
        // fire-and-continue: a próxima Action não espera; falha tardia vira log, nunca derruba o Play
        (outcome as Promise<unknown>).catch((error) => this.log('error', `${where}: ${error instanceof Error ? error.message : String(error)}`, self, true, meta));
        return false;
      }
      if (outcome === 'stop') return true;
      if (!noisy && this.verbose) this.log('info', `  ✓ ${action.type}`, self);
    } catch (error) {
      // erro de Action é logado e não derruba o Play Mode nem as outras regras
      this.log('error', `${where}: erro em "${action.type}": ${error instanceof Error ? error.message : String(error)}`, self, true, meta);
    } finally {
      this.current = previousCurrent;
    }
    return false;
  }

  private actionContext(self: RuntimeInstance): ActionRuntimeContext {
    return {
      self,
      resolve: (ref) => (ref ? (this.scene.getInstance(ref) ?? this.findByName(ref)) : self),
      variables: this.variables,
      sceneTime: this.time,
      applyTransform: (instance) => this.scene.applyInstanceTransform(instance),
      markUiDirty: () => {
        this._uiRevision++;
        this.host.onUiChanged?.();
      },
      interpolate: (text) =>
        this.variables ? this.variables.interpolate(text, { selfNodeId: self.persistentNodeId, resolveNodeId: (n) => this.scene.getInstance(n)?.persistentNodeId ?? this.findByName(n)?.persistentNodeId }) : text,
      log: (level, message, options) => this.log(level, message, self, options?.toOutput ?? level !== 'info', options?.code ? { code: options.code } : undefined),
      destroy: (instance) => this.scene.destroyInstance(instance.id),
      emitSignal: (name) => this.dispatchSignal(name),
      setContinuousRotation: (instance, axis, dps) => {
        if (dps === 0) this.rotations.delete(instance.id);
        else this.rotations.set(instance.id, { instance, axis, dps });
      },
      setContinuousVelocity: (instance, velocity, space) => {
        if (velocity.x === 0 && velocity.y === 0 && velocity.z === 0) this.velocities.delete(instance.id);
        else this.velocities.set(instance.id, { instance, v: velocity, space });
      },
      setWorldPosition: (instance, position) => {
        const object = instance.object;
        if (!object) return;
        object.parent?.updateWorldMatrix(true, false);
        const local = object.parent ? object.parent.worldToLocal(new THREE.Vector3(position.x, position.y, position.z)) : new THREE.Vector3(position.x, position.y, position.z);
        instance.transform.position = [local.x, local.y, local.z];
        this.scene.applyInstanceTransform(instance);
      },
      physics: this.physicsOf(),
      after: (seconds, fn) => this.schedule(seconds, fn),
      host: {
        restartScene: () => {
          this.pendingRestart = true;
        },
        quitGame: () => {
          this.pendingQuit = true;
        },
        changeScene: (scenePath) => {
          this.pendingChange = scenePath;
        },
      },
    };
  }

  private finishFrame(): void {
    if (this.disposed) return;
    // pedidos estruturais só depois de a cadeia e o quadro terminarem (a cena nunca é destruída no meio de uma cadeia)
    if (this.pendingQuit) {
      this.pendingQuit = false;
      this.pendingRestart = false;
      this.pendingChange = null;
      this.log('info', '■ Quit Game solicitado: encerrando o Play.');
      this.host.onQuitGame?.();
    } else if (this.pendingChange !== null) {
      const path = this.pendingChange;
      this.pendingChange = null;
      this.pendingRestart = false;
      this.log('info', `■ Change Scene solicitado: ${path}`);
      this.host.onChangeScene?.(path);
    } else if (this.pendingRestart) {
      this.pendingRestart = false;
      this.log('info', '■ Restart Scene solicitado: reiniciando a cena.');
      this.host.onRestartScene?.();
    }
  }

  // ── consulta ──────────────────────────────────────────────────────────────────────────────────

  private conditionWorld(self: RuntimeInstance): ConditionWorld {
    const lookup = (ref: string) => this.scene.getInstance(ref) ?? this.findByName(ref);
    return {
      selfNodeId: self.persistentNodeId,
      getNode: (ref) => {
        const found = lookup(ref);
        return found ? this.toConditionNode(found) : undefined;
      },
      getWorldPosition: (ref) => {
        const found = lookup(ref);
        if (!found?.object) return undefined;
        found.object.updateWorldMatrix(true, false);
        const v = found.object.getWorldPosition(new THREE.Vector3());
        return { x: v.x, y: v.y, z: v.z };
      },
      input: this.input,
      sceneTime: this.time,
      random: this.random,
      getVariable: this.variables ? (scope, name, nodeId) => this.variables!.getVariable(scope, name, nodeId) : undefined,
    };
  }

  private toConditionNode(i: RuntimeInstance): ConditionNode {
    return { id: i.persistentNodeId, name: i.name, type: i.type, visible: i.visible, properties: i.properties };
  }

  private findByName(name: string): RuntimeInstance | undefined {
    return this.scene.getAllInstances().find((i) => i.name === name);
  }

  private rulesOf(nodeId: string, type: string): CompiledRule[] {
    return this.rules.filter((c) => c.nodeId === nodeId && c.rule.eventType === type);
  }

  /** Sobe pela hierarquia viva até o primeiro nó (ele mesmo incluso) que tem regra do tipo. */
  private bubbleTo(nodeId: string, type: string): string | null {
    for (let cursor = this.scene.getInstance(nodeId); cursor; cursor = cursor.parent ?? undefined) {
      if (this.rulesOf(cursor.persistentNodeId, type).length > 0) return cursor.persistentNodeId;
    }
    return null;
  }

  private isSelfOrDescendant(nodeId: string, ownerId: string): boolean {
    for (let cursor = this.scene.getInstance(nodeId); cursor; cursor = cursor.parent ?? undefined) if (cursor.persistentNodeId === ownerId) return true;
    return false;
  }

  // ── log ───────────────────────────────────────────────────────────────────────────────────────

  private log(level: LogicLogLevel, message: string, node?: RuntimeInstance | string, toOutput = level !== 'info', meta?: LogicLogMeta): void {
    const nodeName = typeof node === 'string' ? node : node?.name;
    const nodeId = typeof node === 'string' ? undefined : node?.persistentNodeId;
    const instanceId = typeof node === 'string' ? undefined : node?.id;
    this.host.onLog?.({ time: this.time, level, message, nodeName, nodeId, instanceId, toOutput, ...this.current, ...meta });
  }

  /** Aviso de configuração: uma vez por chave (não inunda o log a cada quadro). */
  private report(key: string, level: LogicLogLevel, message: string, node?: RuntimeInstance | string, meta?: LogicLogMeta): void {
    if (this.reported.has(key)) return;
    this.reported.add(key);
    this.log(level, message, node, level !== 'info', meta);
  }

  private readonly lastImpact = new Map<string, number>();
  /** `minimalForce` (N) e `maxEveryMs` (debounce, tempo de JOGO) de um On Collision Enter; sem parâmetros dispara sempre. */
  private impactAllowed(c: CompiledRule, force: number): boolean {
    const min = Number(c.rule.parameters.minimalForce) || 0;
    if (force < min) return false;
    const every = (Number(c.rule.parameters.maxEveryMs) || 0) / 1000;
    if (every > 0) {
      const last = this.lastImpact.get(c.rule.id);
      if (last !== undefined && this.time - last < every) return false;
      this.lastImpact.set(c.rule.id, this.time);
    }
    return true;
  }

  private structuralPending(): boolean {
    return this.pendingQuit || this.pendingRestart || this.pendingChange !== null;
  }

  /**
   * AIS-44b — aborta TODAS as cadeias e timers desta cena (primeiro passo da troca/restart de cena): o que estiver em andamento
   * para na próxima Action, e callbacks agendados deixam de existir. O runner segue utilizável até o `dispose`.
   */
  public abortChains(): void {
    this.generation++;
    this.scheduled = [];
    this.queue = [];
    this.rotations.clear();
    this.velocities.clear();
  }

  /** Este (nó × Behavior) tem regras neste runner? */
  public hasBehavior(nodeId: string, behaviorId: string): boolean {
    return this.rules.some((c) => c.nodeId === nodeId && c.behavior.id === behaviorId);
  }

  /** "Restart Behavior": zera só os acumuladores das regras deste Behavior (a cena e os demais Behaviors não mudam). */
  public resetBehavior(nodeId: string, behaviorId: string): void {
    for (const c of this.rules) {
      if (c.nodeId === nodeId && c.behavior.id === behaviorId) {
        c.elapsed = 0;
        c.done = false;
      }
    }
    this.behaviorStates.reset(nodeId, behaviorId);
  }

  /** Fim da sessão: nada de timer, assinatura ou fila sobrevive (idempotente). */
  public dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    for (const d of this.disposers.splice(0)) d();
    this.queue = [];
    this.scheduled = [];
    this.rotations.clear();
    this.velocities.clear();
    this.lastImpact.clear();
    this.rules.length = 0;
    this.behaviorStates.dispose();
  }
}
