import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { themeService } from './core/theme/themeService';

// Inicialização síncrona do tema antes da montagem para evitar flash
themeService.initTheme();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
