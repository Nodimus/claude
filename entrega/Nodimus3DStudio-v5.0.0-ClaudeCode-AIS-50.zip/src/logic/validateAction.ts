/**
 * AIS-41 — validação de Actions antes de executar (pura). O runtime (AIS-44: `RuntimeSession`/`EngineApi`) chama
 * `validateAction` e SÓ executa com `ok: true`; qualquer outra resposta vira erro explícito (diagnóstico/log), nunca uma
 * transformação ignorada em silêncio. A UI usa a mesma função para avisar de incompatibilidade.
 *
 * Códigos estáveis: `action.unknown` (ID fora do registro: preservado nos dados, não executa), `action.disabled` ("em breve"),
 * `action.invalid_params`, `action.no_target`, `action.incompatible_node_type`, `physics.no_body`, `physics.body_disabled`,
 * `physics.incompatible_body_mode`.
 */
import { LogicRegistry } from './registry';
import type { ActionContext, ActionValidation } from './types';

export interface ActionRef {
  type: string;
  parameters?: Record<string, unknown>;
}

export type ValidatedAction = { ok: true; params: Record<string, any> } | { ok: false; code: string; message: string };

export function validateAction(ref: ActionRef, context: ActionContext = {}): ValidatedAction {
  const definition = LogicRegistry.getAction(ref.type);
  if (!definition) return { ok: false, code: 'action.unknown', message: `A Action "${ref.type}" não existe neste editor (os dados foram preservados).` };
  if (definition.status === 'disabled') return { ok: false, code: 'action.disabled', message: `${definition.label}: em breve (ainda não executa).` };
  const parsed = definition.paramsSchema.safeParse(ref.parameters ?? {});
  if (!parsed.success) {
    return { ok: false, code: 'action.invalid_params', message: `${definition.label}: ${parsed.error.issues[0]?.path.join('.') || 'parâmetro'} inválido (${parsed.error.issues[0]?.message ?? 'erro'}).` };
  }
  const verdict: ActionValidation = definition.validate ? definition.validate(parsed.data, context) : { ok: true };
  return verdict.ok ? { ok: true, params: parsed.data } : verdict;
}
