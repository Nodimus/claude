/**
 * Nodimus 3D Studio — contratos das definições de Visual Logic (v4.7.0 · AIS-05r)
 *
 * Cada Trigger, Condition, Action e Behavior nativo vive na SUA PRÓPRIA PASTA:
 *
 *   src/logic/triggers/<id>/index.ts
 *   src/logic/conditions/<id>/index.ts
 *   src/logic/actions/<id>/index.ts
 *   src/logic/behaviors/<id>/index.ts
 *
 * O nome da pasta É o ID estável (snake_case) gravado nas cenas. O registry
 * (`src/logic/registry.ts`) descobre as pastas em tempo de build via
 * `import.meta.glob`. Isto NÃO é sistema de extensões/plugins: nada é carregado
 * em runtime, nada vem de `res://`, e o código só muda com o código do editor.
 *
 * Estas definições são o CATÁLOGO (Definition). Instâncias vivem inline no
 * GameNode/cena; estado mutável vive no runtime (AIS-41b / AIS-44b).
 */
import type { z } from 'zod';
import type { Behavior, BehaviorInstance } from '../types/visualLogic';
import type { RawInputReader } from '../runtime/input/inputTriggers';
import type { RuntimeInstance } from '../runtime/RuntimeScene';
import type { VariableManager } from '../core/variableManager';
import type { PhysicsBridge } from '../core/physics/PhysicsBridge';
import type { GameCameraPose } from '../runtime/controllers/gameCamera';
import type { PhysicsEvent, PhysicsEventName } from '../core/physics/PhysicsBridge';
import type { PhysicsConfig } from '../types/node';

export type LogicKind = 'trigger' | 'condition' | 'action' | 'behavior';

/** Categorias canônicas (metadado visual; valor fora da lista não é permitido). */
export type LogicCategory =
  | 'Movement'
  | 'Physics'
  | 'Interaction'
  | 'AI'
  | 'Camera'
  | 'Utility'
  | 'Logic'
  | 'Audio'
  | 'Scene'
  | 'Visual'
  | 'Debug';

export type LogicParamType = 'number' | 'string' | 'boolean' | 'vector3' | 'node' | 'file' | 'enum' | 'key' | 'condition';

/** Largura do campo inline no editor de lógica (mapeada para classes da casca). */
export type LogicInlineWidth = 'xs' | 'sm' | 'lg';

export interface LogicParamDescriptor {
  /** Chave gravada em `parameters`/`properties` (estável; nunca traduzida). */
  key: string;
  label: string;
  type: LogicParamType;
  /** Valor exibido quando o parâmetro não existe na instância. */
  default: unknown;
  /** Para `enum`. */
  options?: string[];
  /** Para `file`: extensões aceitas (ex.: ['.js', '.ts']). */
  accept?: string[];
  /** O formulário esconde este campo quando o nó alvo é de UI (ex.: o Z de `set_position` num Overlay2D; AIS-25b/41). */
  hideForUi?: boolean;
  /** O formulário só mostra (e valida) este campo quando o parâmetro irmão `key` vale `equals` (ex.: `target` só para escopo `local`). */
  visibleWhen?: { key: string; equals: string | number | boolean };
  /** AIS-42: campo obrigatório — vazio é erro inline e o diálogo não aplica. */
  required?: boolean;
  /** AIS-42, para `file`: só lista/aceita arquivos desta pasta (ex.: `res://scripts/`). */
  root?: string;
  /** AIS-43: este parâmetro NOMEIA uma variável (consumidores, exclusão com aviso e renomeação de referências leem isto). */
  variable?: boolean;
  /**
   * Edição rápida na linha da Action dentro do Visual Logic Editor.
   * Ausente = o parâmetro não aparece inline (continua preservado nos dados).
   */
  inline?: { prefix?: string; width: LogicInlineWidth; placeholder?: string };
}

interface LogicDefinitionBase {
  /** ID estável = nome da pasta. Validado pelo registry. */
  id: string;
  kind: LogicKind;
  label: string;
  description: string;
  category: LogicCategory;
  /** Nome de ícone Lucide (opcional; fallback do consumidor). */
  icon?: string;
  /**
   * `disabled` = aparece desabilitado com tooltip "em breve" (decisão canônica 14).
   * Nunca simular execução de um item desabilitado.
   */
  status?: 'available' | 'disabled';
  params: LogicParamDescriptor[];
}

export interface TriggerDefinition extends LogicDefinitionBase {
  kind: 'trigger';
}

/** Nó como a avaliação de Conditions o enxerga (só leitura; o runtime monta isto a partir da cena viva). */
export interface ConditionNode {
  id: string;
  name: string;
  type: string;
  visible?: boolean;
  properties: Record<string, any>;
}

/** Referência a uma Condition (usada pela Condition `not`): ID estável + parâmetros. */
export interface ConditionRef {
  type: string;
  parameters?: Record<string, unknown>;
}

/**
 * Contexto de avaliação de Conditions (AIS-40c). Tudo o que uma Condition pode ler vem daqui — nada de DOM, relógio ou
 * `Math.random` diretos: a avaliação é função PURA (testável em Node) e o runtime (AIS-44) injeta o mundo.
 */
export interface ConditionContext {
  /** Nó dono da regra: alvo padrão quando `target` fica vazio. */
  selfNodeId?: string;
  /** Nó por ID ou por nome; `undefined` = não existe (mais na cena). */
  getNode(ref: string): ConditionNode | undefined;
  /** Posição no mundo do nó (a hierarquia é do runtime). */
  getWorldPosition(ref: string): { x: number; y: number; z: number } | undefined;
  /** Input do jogo (AIS-40b): ações e leitura bruta. */
  input: RawInputReader;
  /** Segundos desde o início da cena em Play. */
  sceneTime: number;
  /** Sorteio em [0, 1) injetado (determinístico nos testes). */
  random(): number;
  /** AIS-43: valor de uma variável (Global, ou Local do nó `nodeId`); `undefined` = não existe. Ausente = sem sistema de variáveis. */
  getVariable?(scope: 'global' | 'local', name: string, nodeId?: string): number | string | boolean | undefined;
  /** Avalia uma Condition aninhada; `null` = não resolvida ou com parâmetros inválidos. */
  evaluate(ref: ConditionRef): boolean | null;
}

export interface ConditionDefinition extends LogicDefinitionBase {
  kind: 'condition';
  /** Schema Zod dos parâmetros (valida e aplica os padrões antes de avaliar). */
  paramsSchema: z.ZodType<any>;
  /** Avaliação pura: mesma entrada, mesma saída, sem efeitos colaterais. */
  evaluate: (params: any, context: ConditionContext) => boolean;
}

/** Contexto de VALIDAÇÃO de uma Action (AIS-41): só o nó alvo já resolvido (vazio = o nó dono da regra). */
export interface ActionContext {
  target?: ConditionNode;
}

/** Resultado de validar uma Action antes de executar: nunca ignora em silêncio, sempre diz por quê. */
export type ActionValidation = { ok: true } | { ok: false; code: string; message: string };

export interface ActionDefinition extends LogicDefinitionBase {
  kind: 'action';
  /** Botão de adição rápida no Visual Logic Editor (ordem e parâmetros iniciais). */
  quickAdd?: { label: string; order: number; parameters: Record<string, unknown> };
  /** Schema Zod dos parâmetros (valida e aplica os padrões antes de validar/executar). */
  paramsSchema: z.ZodType<any>;
  /**
   * Validação de contexto, pura e SEM efeito colateral (tipo de corpo, tipo de nó…). Ausente = vale para qualquer alvo.
   * A execução (AIS-44: `runtime.ts` na mesma pasta) só roda depois de `ok: true`.
   */
  validate?: (params: any, context: ActionContext) => ActionValidation;
}

/**
 * AIS-44 — contexto de EXECUÇÃO de uma Action (runtime). O `LogicRunner` monta um por disparo; o executor da pasta
 * (`src/logic/actions/<id>/runtime.ts`) só fala com o runtime por aqui: nunca toca no authoring nem no CommandManager.
 */
export interface ActionRuntimeContext {
  /** Instância viva do nó dono da regra. */
  self: RuntimeInstance;
  /** Resolve uma referência (ID ou nome); vazio = o nó dono. `undefined` = não existe (mais na cena). */
  resolve(ref: string): RuntimeInstance | undefined;
  /** Variáveis da sessão (`null` fora de uma sessão de Play). */
  variables: VariableManager | null;
  /** Segundos desde o início da cena. */
  sceneTime: number;
  /** Escreve o `transform` da instância no objeto vivo. */
  applyTransform(instance: RuntimeInstance): void;
  /** Avisa que propriedades de UI (texto, textura, posição de overlay) mudaram: o HUD é redesenhado, a cena 3D não. */
  markUiDirty(): void;
  /** Substitui `$variavel$`/`$no.atributo$` do texto pelos valores vivos. */
  interpolate(text: string): string;
  /** Log de execução (Debugger; `warn`/`error` também vão ao Output). */
  log(level: 'info' | 'warn' | 'error', message: string, options?: { toOutput?: boolean; /** AIS-48b: código do diagnóstico (ex.: `physics.no_body`). */ code?: string }): void;
  /** Destrói a instância (e a subárvore) da cena viva; regras dela deixam de disparar. */
  destroy(instance: RuntimeInstance): void;
  /** Emite um sinal (dispara `on_signal`; processado no mesmo quadro). */
  emitSignal(name: string): void;
  /** Rotação contínua do nó (aplicada a cada quadro pelo runner); `degreesPerSecond: 0` a para. */
  setContinuousRotation(instance: RuntimeInstance, axis: 'x' | 'y' | 'z', degreesPerSecond: number): void;
  /** Velocidade contínua (m/s) de um nó SEM corpo dinâmico, aplicada a cada quadro; vetor zero a para. */
  setContinuousVelocity(instance: RuntimeInstance, velocity: { x: number; y: number; z: number }, space: 'world' | 'local'): void;
  /** Posiciona a instância numa pose MUNDIAL (converte para local pela hierarquia; só estado de runtime). */
  setWorldPosition(instance: RuntimeInstance, position: { x: number; y: number; z: number }): void;
  /**
   * Ponte física da sessão (AIS-45): a ÚNICA porta para o mundo físico — nunca `RigidBody`/`Collider` do Rapier. `null` = a cena
   * não tem corpos ou o motor ainda está carregando; operações físicas então falham com mensagem explícita.
   */
  physics: PhysicsBridge | null;
  /** Agenda `fn` daqui a `seconds` segundos de JOGO (pausa e Stop respeitados; não bloqueia o quadro). */
  after(seconds: number, fn: () => void): void;
  /** Pedidos de ciclo de vida do jogo, executados depois da cadeia atual. */
  host: { restartScene(): void; quitGame(): void; changeScene(scenePath: string): void };
}

/** `'stop'` encerra a cadeia atual (operação estrutural destrutiva); uma Promise segue a política fire-and-continue. */
export type ActionOutcome = void | 'stop';
export type ActionExecutor<P = any> = (params: P, context: ActionRuntimeContext) => ActionOutcome | Promise<ActionOutcome>;

/**
 * AIS-44b — lifecycle de um Behavior EM EXECUÇÃO. O estado mutável é do par (nó × BehaviorInstance): cada instância recebe o
 * seu `BehaviorRuntime` (`create()`) e o seu `state`; nada mora no singleton do tipo registrado. Ordem: `attach` → `onPlayStart`
 * → `onUpdate`* → `onPlayStop` → `detach` → `dispose`. Todos opcionais; erros são logados e nunca derrubam a sessão.
 */
export interface BehaviorRuntimeContext {
  /** Instância viva do nó dono. */
  node: RuntimeInstance;
  behavior: BehaviorInstance;
  /** Cópia de trabalho de `properties` + memória do executor (`BehaviorRuntimeStates`); `Restart Behavior` a recria. */
  state: { properties: Record<string, any>; memory: Record<string, unknown> };
  input: RawInputReader;
  variables: VariableManager | null;
  sceneTime: number;
  applyTransform(instance: RuntimeInstance): void;
  log(level: 'info' | 'warn' | 'error', message: string, options?: { code?: string }): void;
  /** AIS-47: pose AUTORAL inicial do nó (do snapshot): "Restart Behavior" recomeça daqui, não da pose atual da instância. */
  initialTransform: { position: [number, number, number]; rotation: [number, number, number]; scale: [number, number, number] };
  /** AIS-47: ponte física da sessão (`null` = sem corpos ou o motor ainda carrega). Nunca `RigidBody` do Rapier. */
  physics: PhysicsBridge | null;
  /** AIS-48: assina eventos físicos (Enter/Exit; sem Stay). A inscrição é cancelada sozinha no `detach` do Behavior; devolve o `unsubscribe`. */
  onPhysicsEvent(name: PhysicsEventName | '*', cb: (event: PhysicsEvent) => void): () => void;
  /** AIS-48b: callback por quadro (depois da física). Devolve o `unsubscribe`; o dono é este Behavior (cancelado no `detach`/remoção). */
  onFrame(cb: (dt: number) => void): () => void;
  /** AIS-48b: callback por quadro com o leitor de entrada (antes dos Behaviors). Mesmo contrato de dono/`unsubscribe`. */
  onInput(cb: (input: RawInputReader) => void): () => void;
  /** AIS-48b: assina um sinal emitido na cena (`emit_signal`). Mesmo contrato de dono/`unsubscribe`. */
  onSignal(name: string, cb: (name: string) => void): () => void;
  /** AIS-47: entrega (ou retira, com `null`) a câmera de jogo deste Behavior; só vale no Play e some no Stop. */
  setGameCamera(pose: Omit<GameCameraPose, 'nodeId'> | null): void;
}

export interface BehaviorRuntime {
  attach?(ctx: BehaviorRuntimeContext): void;
  onPlayStart?(ctx: BehaviorRuntimeContext): void;
  onUpdate?(ctx: BehaviorRuntimeContext, dt: number): void;
  /** AIS-47: depois do passo da física (a pose simulada já está na instância): ideal para câmeras que seguem o corpo. */
  onLateUpdate?(ctx: BehaviorRuntimeContext, dt: number): void;
  onPlayStop?(ctx: BehaviorRuntimeContext): void;
  detach?(ctx: BehaviorRuntimeContext): void;
  dispose?(): void;
}

/** `src/logic/behaviors/<id>/runtime.ts` (export default). */
export interface BehaviorRuntimeModule {
  /** Uma instância NOVA por (nó × Behavior). */
  create(): BehaviorRuntime;
  /** `true` = o executor por propriedades substitui as `rules` de preset do Behavior (elas não rodam no `LogicRunner`). */
  replacesRules?: boolean;
}

export interface BehaviorCreateContext {
  /** Nó alvo (nome exibido; hoje a casca usa o nome como alvo). */
  targetNodeId: string;
}

export interface BehaviorDefinition extends LogicDefinitionBase {
  kind: 'behavior';
  /** Botão de preset no Visual Logic Editor. `wide` ocupa as duas colunas. */
  preset?: { label: string; order: number; wide?: boolean };
  /** AIS-48: ao adicionar pelo preset, aplica este patch ao bloco `properties.physics` do nó (um Command com Undo; decisão 26). */
  presetPhysics?: Partial<PhysicsConfig>;
  /** Cria uma nova instância autoral com IDs novos. */
  create: (ctx: BehaviorCreateContext) => Behavior;
}

export type LogicDefinition =
  | TriggerDefinition
  | ConditionDefinition
  | ActionDefinition
  | BehaviorDefinition;

/* Helpers de declaração — só tipam; não registram nada (o registry descobre as pastas). */
export const defineTrigger = (d: Omit<TriggerDefinition, 'kind'>): TriggerDefinition => ({ ...d, kind: 'trigger' });
/** Tipa `evaluate` com os parâmetros JÁ validados pelo `paramsSchema`. */
export const defineCondition = <S extends z.ZodType<any>>(
  d: Omit<ConditionDefinition, 'kind' | 'paramsSchema' | 'evaluate'> & { paramsSchema: S; evaluate: (params: z.infer<S>, context: ConditionContext) => boolean }
): ConditionDefinition => ({ ...d, kind: 'condition' });
/** Tipa `validate` com os parâmetros JÁ validados pelo `paramsSchema`. */
export const defineAction = <S extends z.ZodType<any>>(
  d: Omit<ActionDefinition, 'kind' | 'paramsSchema' | 'validate'> & { paramsSchema: S; validate?: (params: z.infer<S>, context: ActionContext) => ActionValidation }
): ActionDefinition => ({ ...d, kind: 'action' });
export const defineBehavior = (d: Omit<BehaviorDefinition, 'kind'>): BehaviorDefinition => ({ ...d, kind: 'behavior' });

/** Gera IDs de ocorrência no mesmo formato já usado pela casca. */
export const newLogicId = (prefix: string, length = 7): string =>
  prefix + Math.random().toString(36).substring(2, 2 + length);
