import { describe, expect, it } from 'vitest';
import { CommandManager } from '../core/commandManager';
import { createBehaviorOps, type BehaviorStore } from '../core/commands/BehaviorCommands';
import type { Behavior } from '../types/visualLogic';
import { LogicRegistry } from './registry';
import {
  describeAction,
  describeCondition,
  describeStep,
  describeTrigger,
  describeWhen,
  fileMatches,
  filesFor,
  formatParam,
  hasBlockingIssue,
  keyLabel,
  validateParams,
  type FormContext,
} from './paramForm';

const NODES: Record<string, string> = { n_player: 'Jogador', n_orb: 'Orbe' };
const FILES = new Set(['res://scripts/boss.js', 'res://scripts/ai/boss.ts', 'res://audio/explosion.wav', 'res://scenes/Main.scene.json', 'res://textures/a.png']);
const ctx: FormContext = {
  nodeExists: (ref) => ref in NODES || Object.values(NODES).includes(ref),
  nodeName: (ref) => NODES[ref] ?? (Object.values(NODES).includes(ref) ? ref : undefined),
  fileExists: (p) => FILES.has(p),
};
const def = (kind: 'action' | 'trigger' | 'condition', id: string) => (kind === 'action' ? LogicRegistry.getAction(id) : kind === 'trigger' ? LogicRegistry.getTrigger(id) : LogicRegistry.getCondition(id))!;

describe('AIS-42 — seletor de arquivo filtra por extensão e pasta (C01)', () => {
  const ALL = [
    'res://scripts/boss.js',
    'res://scripts/ai/boss.ts',
    'res://scripts/data.json',
    'res://scripts/notes.txt',
    'res://scripts/',
    'res://other/outside.js',
    'res://scenes/Main.scene.json',
    'res://audio/explosion.wav',
  ];
  const scriptRef = LogicRegistry.getAction('run_script')!.params.find((p) => p.key === 'scriptRef')!;

  it('scriptRef lista apenas .js/.ts de res://scripts/', () => {
    expect(scriptRef.accept).toEqual(['.js', '.ts']);
    expect(scriptRef.root).toBe('res://scripts/');
    expect(filesFor(scriptRef, ALL)).toEqual(['res://scripts/ai/boss.ts', 'res://scripts/boss.js']);
  });

  it('extensão composta (.scene.json) e áudio funcionam; sem accept lista todos os arquivos', () => {
    const scene = LogicRegistry.getAction('change_scene')!.params[0];
    expect(filesFor(scene, ALL)).toEqual(['res://scenes/Main.scene.json']);
    const sound = LogicRegistry.getAction('play_sound')!.params.find((p) => p.key === 'sound')!;
    expect(filesFor(sound, ALL)).toEqual(['res://audio/explosion.wav']);
    expect(filesFor({}, ALL)).toHaveLength(ALL.length - 1); // só a pasta (termina com /) fica de fora
  });

  it('a comparação ignora maiúsculas e nunca aceita fora da pasta', () => {
    expect(fileMatches('res://scripts/Boss.JS', scriptRef)).toBe(true);
    expect(fileMatches('res://other/boss.js', scriptRef)).toBe(false);
    expect(fileMatches('res://scripts/boss.json', scriptRef)).toBe(false);
  });
});

describe('AIS-42 — valores legíveis', () => {
  it('nomes de tecla amigáveis', () => {
    expect(keyLabel('Space')).toBe('Espaço');
    expect(keyLabel('space')).toBe('Espaço');
    expect(keyLabel('KeyW')).toBe('W');
    expect(keyLabel('w')).toBe('W');
    expect(keyLabel('Digit5')).toBe('5');
    expect(keyLabel('ArrowUp')).toBe('↑');
    expect(keyLabel('ShiftRight')).toBe('Shift');
    expect(keyLabel('Escape')).toBe('Esc');
    expect(keyLabel('F5')).toBe('F5');
    expect(keyLabel('')).toBe('(nenhuma)');
    expect(keyLabel(undefined)).toBe('(nenhuma)');
  });

  it('formatParam por tipo: vetor, nó (id ou nome, ausente), arquivo, booleano, tecla, texto', () => {
    const p = (type: string) => ({ key: 'k', label: 'K', type, default: '' }) as never;
    expect(formatParam(p('vector3'), { x: 0, y: 5, z: 0 }, ctx)).toBe('[0, 5, 0]');
    expect(formatParam(p('node'), 'n_player', ctx)).toBe('[Jogador]');
    expect(formatParam(p('node'), 'Orbe', ctx)).toBe('[Orbe]');
    expect(formatParam(p('node'), '', ctx)).toBe('[este nó]');
    expect(formatParam(p('node'), 'sumiu', ctx)).toBe('[sumiu — não encontrado]');
    expect(formatParam(p('file'), 'res://audio/explosion.wav', ctx)).toBe('explosion.wav');
    expect(formatParam(p('file'), '', ctx)).toBe('(nenhum arquivo)');
    expect(formatParam(p('boolean'), true, ctx)).toBe('sim');
    expect(formatParam(p('key'), 'Space', ctx)).toBe('[Espaço]');
    expect(formatParam(p('key'), '', ctx)).toBe('(nenhuma tecla)');
    expect(describeTrigger('on_key_down', {}, ctx)).toBe('Ao pressionar (nenhuma tecla)');
    expect(formatParam(p('string'), 'oi', ctx)).toBe('"oi"');
    expect(formatParam(p('string'), '', ctx)).toBe('(vazio)');
  });
});

describe('AIS-42 — preview textual do comportamento', () => {
  it('exemplo da especificação: pressionar Espaço → impulso [0, 5, 0] no nó Jogador', () => {
    const rule = { eventType: 'on_key_down', parameters: { key: 'Space' }, conditions: [{ type: 'always', parameters: {} }] };
    const action = { type: 'add_impulse', parameters: { target: 'n_player', impulse: { x: 0, y: 5, z: 0 } } };
    expect(describeStep(rule, action, ctx)).toBe('Ao pressionar [Espaço] → Add Impulse [0, 5, 0] no nó [Jogador]');
  });

  it('parâmetros secundários só aparecem quando mudaram do padrão', () => {
    expect(describeAction('add_force', { force: { x: 0, y: 10, z: 0 }, space: 'local', target: 'n_orb' }, ctx)).toBe('Add Force [0, 10, 0] (Space: local) no nó [Orbe]');
    expect(describeAction('add_force', { force: { x: 0, y: 10, z: 0 } }, ctx)).toBe('Add Force [0, 10, 0] no nó [este nó]');
    expect(describeAction('play_sound', { sound: 'res://audio/explosion.wav' }, ctx)).toBe('Play Sound 3D explosion.wav no nó [este nó]');
    expect(describeAction('play_sound', { sound: 'res://audio/explosion.wav', volume: 0.5, spatial: false }, ctx)).toBe('Play Sound 3D explosion.wav (Volume: 0.5, Spatial (3D): não) no nó [este nó]');
  });

  it('o texto vem do registro: Action desconhecida é sinalizada, não escondida', () => {
    expect(describeAction('acao_de_outra_versao', {}, ctx)).toBe('acao_de_outra_versao [não resolvida]');
    expect(describeCondition('condicao_nova', {}, ctx)).toBe('condicao_nova [não resolvida]');
    expect(describeTrigger('gatilho_novo', {}, ctx)).toBe('Quando [gatilho_novo — não resolvido]');
  });

  it('cada Trigger tem frase própria com seus parâmetros', () => {
    expect(describeTrigger('on_key_up', { key: 'KeyW' }, ctx)).toBe('Ao soltar [W]');
    expect(describeTrigger('on_start', {}, ctx)).toBe('Ao iniciar a cena');
    expect(describeTrigger('on_update', {}, ctx)).toBe('A cada frame');
    expect(describeTrigger('on_timeout', { interval: 2.5 }, ctx)).toBe('A cada [2.5] s');
    expect(describeTrigger('on_timeout', {}, ctx)).toBe('A cada [1] s'); // padrão da pasta
    expect(describeTrigger('on_input_action', { action: 'Jump', phase: 'held' }, ctx)).toBe('Quando a ação [Jump] for [held]');
    expect(describeTrigger('on_mouse_down', { button: 'right' }, ctx)).toBe('Ao pressionar o botão [right] do mouse');
    expect(describeTrigger('on_collision_enter', {}, ctx)).toBe('Ao começar a colidir');
    expect(describeTrigger('on_signal', { signal: 'hit' }, ctx)).toBe('Ao receber o sinal "hit"');
  });

  it('Conditions entram no preview (menos "always")', () => {
    const rule = { eventType: 'on_update', parameters: {}, conditions: [{ type: 'always', parameters: {} }, { type: 'key_pressed', parameters: { action: 'Sprint' } }] };
    expect(describeWhen(rule, ctx)).toBe('A cada frame, se Key Pressed Sprint');
  });
});

describe('AIS-42 — validação inline', () => {
  const issuesOf = (kind: 'action' | 'trigger' | 'condition', id: string, values: Record<string, unknown>, hidden?: string[]) =>
    validateParams(def(kind, id) as never, values, ctx, { hiddenKeys: hidden ? new Set(hidden) : undefined });
  const byKey = (list: ReturnType<typeof issuesOf>, key: string) => list.find((i) => i.key === key);

  it('campo obrigatório vazio é erro e bloqueia; preenchido libera', () => {
    const empty = issuesOf('action', 'play_sound', {});
    expect(byKey(empty, 'sound')).toMatchObject({ severity: 'error', message: 'Campo obrigatório.' });
    expect(hasBlockingIssue(empty)).toBe(true);
    const ok = issuesOf('action', 'play_sound', { sound: 'res://audio/explosion.wav' });
    expect(hasBlockingIssue(ok)).toBe(false);
    expect(issuesOf('trigger', 'on_key_down', { key: '' })).toHaveLength(1);
    expect(issuesOf('trigger', 'on_key_down', { key: 'Space' })).toEqual([]);
  });

  it('campos opcionais vazios não geram nada (alvo vazio = o próprio nó)', () => {
    expect(issuesOf('action', 'add_force', {})).toEqual([]);
    expect(issuesOf('condition', 'node_visible', {})).toEqual([]);
  });

  it('Target de variável só existe para escopo local: global o ignora (sem aviso de nó) e some do preview', () => {
    expect(byKey(issuesOf('action', 'set_variable', { scope: 'global', target: 'sumiu', variable: 'x' }), 'target')).toBeUndefined();
    expect(byKey(issuesOf('action', 'set_variable', { scope: 'local', target: 'sumiu', variable: 'x' }), 'target')).toMatchObject({ severity: 'warning' });
    expect(describeAction('set_variable', { scope: 'global', target: 'n_player', variable: 'pontos', value: '1' }, ctx)).not.toMatch(/no nó/);
  });

  it('arquivo: extensão/pasta erradas bloqueiam; ausente do projeto só avisa e a referência é mantida', () => {
    const wrongExt = issuesOf('action', 'run_script', { scriptRef: 'res://scripts/data.json' });
    expect(byKey(wrongExt, 'scriptRef')).toMatchObject({ severity: 'error' });
    const wrongDir = issuesOf('action', 'run_script', { scriptRef: 'res://other/boss.js' });
    expect(hasBlockingIssue(wrongDir)).toBe(true);
    const good = issuesOf('action', 'run_script', { scriptRef: 'res://scripts/boss.js' });
    expect(good).toEqual([]);
    const missing = issuesOf('action', 'run_script', { scriptRef: 'res://scripts/sumiu.js' });
    expect(byKey(missing, 'scriptRef')).toMatchObject({ severity: 'warning' });
    expect(hasBlockingIssue(missing)).toBe(false);
  });

  it('nó inexistente avisa (não apaga); nó existente por ID ou nome é aceito', () => {
    expect(byKey(issuesOf('action', 'add_force', { target: 'sumiu' }), 'target')).toMatchObject({ severity: 'warning' });
    expect(issuesOf('action', 'add_force', { target: 'n_player' })).toEqual([]);
    expect(issuesOf('action', 'add_force', { target: 'Orbe' })).toEqual([]);
  });

  it('número, vetor e opção inválidos bloqueiam', () => {
    expect(byKey(issuesOf('action', 'rotate_by', { degrees: 'abc' }), 'degrees')).toMatchObject({ severity: 'error' });
    expect(byKey(issuesOf('action', 'add_force', { force: { x: 'a', y: 0, z: 0 } }), 'force')).toMatchObject({ severity: 'error' });
    expect(byKey(issuesOf('action', 'add_force', { space: 'galaxy' }), 'space')).toMatchObject({ severity: 'error' });
  });

  it('o schema da pasta também vale (cor hexadecimal, contagem inteira)', () => {
    expect(byKey(issuesOf('action', 'set_emissive_color', { color: 'laranja' }), 'color')).toMatchObject({ severity: 'error' });
    expect(issuesOf('action', 'set_emissive_color', { color: '#ff8800' })).toEqual([]);
    expect(hasBlockingIssue(issuesOf('action', 'emit_particles', { targetNodeId: 'n_orb', count: 2.5 }))).toBe(true);
  });

  it('campos escondidos (Z para alvo de UI) não são validados', () => {
    expect(issuesOf('action', 'set_position', { x: 1, y: 2, z: 'lixo' }, ['z'])).toEqual([]);
  });

  it('Conditions: propriedade obrigatória no Property Compare', () => {
    expect(byKey(issuesOf('condition', 'property_compare', { property: '' }), 'property')).toMatchObject({ severity: 'error' });
    expect(issuesOf('condition', 'property_compare', { property: 'health', operator: '<', value: 5 })).toEqual([]);
  });
});

describe('AIS-42 — coerência dos descritores', () => {
  it('todo campo obrigatório começa vazio (senão "obrigatório" nunca dispararia) e todo root é de um parâmetro file', () => {
    for (const list of [LogicRegistry.listActions(), LogicRegistry.listTriggers(), LogicRegistry.listConditions()]) {
      for (const d of list) {
        for (const p of d.params) {
          if (p.required) expect(p.default === '' || p.default === undefined, `${d.id}.${p.key}`).toBe(true);
          if (p.root) expect(p.type, `${d.id}.${p.key}`).toBe('file');
        }
      }
    }
  });

  it('os campos obrigatórios esperados estão marcados', () => {
    const required = (kind: 'action' | 'trigger' | 'condition', id: string) => def(kind, id).params.filter((p) => p.required).map((p) => p.key);
    expect(required('action', 'run_script')).toEqual(['scriptRef']);
    expect(required('action', 'play_sound')).toEqual(['sound']);
    expect(required('action', 'change_scene')).toEqual(['scenePath']);
    expect(required('trigger', 'on_key_down')).toEqual(['key']);
    expect(required('trigger', 'on_signal')).toEqual(['signal']);
    expect(required('condition', 'property_compare')).toEqual(['property']);
  });

  it('os padrões declarados de todo item são aceitos pela validação (exceto os obrigatórios vazios)', () => {
    for (const list of [LogicRegistry.listActions(), LogicRegistry.listTriggers(), LogicRegistry.listConditions()]) {
      for (const d of list) {
        const issues = validateParams(d as never, {}, ctx).filter((i) => !d.params.find((p) => p.key === i.key)?.required && i.severity === 'error');
        expect(issues, d.id).toEqual([]);
      }
    }
  });
});

describe('AIS-42 — aplicar em um único Command (Undo)', () => {
  const make = (): Behavior => ({
    id: 'b',
    name: 'B',
    targetNodeId: 'n_player',
    behaviorType: 'custom_rules',
    enabled: true,
    properties: {},
    rules: [
      {
        id: 'r',
        eventType: 'on_key_down',
        parameters: { key: 'KeyW', extraDesconhecido: { x: 1 } },
        conditions: [{ id: 'c', type: 'property_compare', parameters: { property: 'health', segredo: 7 } }],
        actions: [{ id: 'a', type: 'add_impulse', parameters: { impulse: { x: 0, y: 1, z: 0 }, campoFuturo: 'x' } }],
      },
    ],
  });
  function setup() {
    let list: Behavior[] = [make()];
    const store: BehaviorStore = { get: () => list, set: (n) => void (list = n) };
    const manager = new CommandManager();
    return { ops: createBehaviorOps(store, (c) => manager.execute(c)), manager, get: () => list[0].rules[0] };
  }

  it('vários parâmetros de uma Action = UM Undo; chaves desconhecidas ficam intactas', () => {
    const { ops, manager, get } = setup();
    const before = structuredClone(get());
    ops.setActionParams('b', 'r', 'a', { impulse: { x: 0, y: 5, z: 0 }, space: 'local', target: 'n_player' });
    expect(get().actions[0].parameters).toEqual({ impulse: { x: 0, y: 5, z: 0 }, space: 'local', target: 'n_player', campoFuturo: 'x' });
    manager.undo();
    expect(get()).toEqual(before);
    expect(manager.canUndo()).toBe(false); // era UMA entrada
    manager.redo();
    expect(get().actions[0].parameters.space).toBe('local');
  });

  it('parâmetros do Trigger (rule.parameters) e da Condition, cada um com um Undo', () => {
    const { ops, manager, get } = setup();
    ops.setTriggerParams('b', 'r', { key: 'Space' });
    expect(get().parameters).toEqual({ key: 'Space', extraDesconhecido: { x: 1 } });
    ops.setConditionParams('b', 'r', 'c', { property: 'mana', value: 3 });
    expect(get().conditions[0].parameters).toEqual({ property: 'mana', segredo: 7, value: 3 });
    manager.undo();
    manager.undo();
    expect(get().parameters.key).toBe('KeyW');
    expect(get().conditions[0].parameters).toEqual({ property: 'health', segredo: 7 });
  });

  it('patch sem mudança não registra nada; undefined remove a chave', () => {
    const { ops, manager, get } = setup();
    ops.setActionParams('b', 'r', 'a', { impulse: { x: 0, y: 1, z: 0 }, campoFuturo: 'x' });
    ops.setActionParams('b', 'r', 'a', { naoExiste: undefined });
    ops.setActionParams('b', 'r', 'nao_existe', { a: 1 });
    expect(manager.canUndo()).toBe(false);
    ops.setActionParams('b', 'r', 'a', { campoFuturo: undefined });
    expect(get().actions[0].parameters).toEqual({ impulse: { x: 0, y: 1, z: 0 } });
    manager.undo();
    expect(get().actions[0].parameters.campoFuturo).toBe('x');
  });
});

describe('AIS-43 — Visual Logic só usa variáveis declaradas (nunca cria global)', () => {
  const declared: FormContext = {
    ...ctx,
    variablesOf: (scope, target, owner) => (scope === 'global' ? ['score'] : (target || owner) === 'n_player' ? ['ammo'] : (target || owner) ? [] : undefined),
  };
  const run = (id: string, values: Record<string, unknown>, owner?: string) => validateParams(def('action', id) as never, values, declared, { ownerNodeId: owner });
  const err = (issues: ReturnType<typeof run>, key: string) => issues.find((i) => i.key === key && i.severity === 'error')?.message;

  it('global: aceita a declarada no Project Settings e recusa nome novo', () => {
    expect(err(run('set_variable', { scope: 'global', variable: 'score' }), 'variable')).toBeUndefined();
    expect(err(run('set_variable', { scope: 'global', variable: 'inventada' }), 'variable')).toMatch(/Project Settings/);
  });

  it('local: confere as variáveis do nó alvo (vazio = nó dono)', () => {
    expect(err(run('add_to_variable', { scope: 'local', variable: 'ammo' }, 'n_player'), 'variable')).toBeUndefined();
    expect(err(run('add_to_variable', { scope: 'local', variable: 'ammo', target: 'n_player' }, 'n_orb'), 'variable')).toBeUndefined();
    expect(err(run('add_to_variable', { scope: 'local', variable: 'ammo' }, 'n_orb'), 'variable')).toMatch(/Inspector/);
  });

  it('Condition e Trigger seguem a mesma regra; sem como verificar, não acusa', () => {
    expect(validateParams(def('condition', 'variable_compare') as never, { scope: 'global', variableName: 'x', value: 1 }, declared).some((i) => i.key === 'variableName' && i.severity === 'error')).toBe(true);
    expect(validateParams(def('trigger', 'on_variable_changed') as never, { scope: 'global', variable: 'score' }, declared).some((i) => i.severity === 'error')).toBe(false);
    expect(run('set_variable', { scope: 'local', variable: 'qualquer' }).find((i) => i.key === 'variable')).toBeUndefined(); // dono desconhecido
    expect(validateParams(def('action', 'set_variable') as never, { scope: 'global', variable: 'x' }, ctx).some((i) => i.severity === 'error')).toBe(false); // sem variablesOf
  });
});
