/**
 * AIS-44 — helpers dos executores de Action (`actions/<id>/runtime.ts`). Ficam FORA das pastas varridas pelo registry.
 */
import { isOverlayNodeType } from '../runtime/overlay';
import type { RuntimeInstance } from '../runtime/RuntimeScene';
import type { ActionRuntimeContext } from './types';
import { PhysicsBridgeError, type PhysicsBridge } from '../core/physics/PhysicsBridge';

/** Nós de UI (Overlay2D e controles): posição = offsets do layout, não `transform`. */
export const isUiInstance = (instance: RuntimeInstance): boolean => isOverlayNodeType(instance.type);

/** Alvo da Action (`target` vazio = o nó dono). Inexistente → erro explícito no log e `undefined`. */
export function resolveTarget(label: string, ref: unknown, ctx: ActionRuntimeContext): RuntimeInstance | undefined {
  const text = typeof ref === 'string' ? ref.trim() : '';
  const found = ctx.resolve(text);
  if (!found) ctx.log('error', `${label}: o nó alvo "${text}" não existe na cena.`);
  return found;
}

export const num = (value: unknown, fallback = 0): number => (typeof value === 'number' && Number.isFinite(value) ? value : fallback);

/**
 * AIS-45 — esqueleto das Actions de física: resolve o alvo, exige a ponte física da sessão e traduz `PhysicsBridgeError` em log
 * explícito (corpo ausente, modo incompatível, corpo desligado…). Nunca toca `RigidBody` do Rapier; nunca ignora em silêncio.
 */
export function runPhysics(label: string, target: unknown, ctx: ActionRuntimeContext, fn: (bridge: PhysicsBridge, nodeId: string, instance: RuntimeInstance) => void): void {
  const instance = resolveTarget(label, target, ctx);
  if (!instance) return;
  const bridge = ctx.physics;
  if (!bridge) return ctx.log('error', `${label}: não há mundo físico nesta cena (nenhum nó com "Colisão" ligada, ou o motor ainda está carregando).`, { code: 'physics.no_world' });
  try {
    fn(bridge, instance.persistentNodeId, instance);
  } catch (error) {
    if (error instanceof PhysicsBridgeError) return ctx.log('error', error.message, { code: error.code });
    throw error;
  }
}
