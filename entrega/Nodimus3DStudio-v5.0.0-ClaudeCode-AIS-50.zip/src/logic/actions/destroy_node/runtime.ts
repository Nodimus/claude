import type { ActionExecutor } from '../../types';
import { isUiInstance, resolveTarget } from '../../actionRuntimeHelpers';

/** Destrói o nó (e a subárvore) só no Play. Destruir o próprio dono (ou um ancestral dele) encerra a cadeia. */
const run: ActionExecutor<{ target: string }> = ({ target }, ctx) => {
  const node = resolveTarget('Destroy Node', target, ctx);
  if (!node) return;
  let selfDestroyed = false;
  for (let cursor: typeof node | null = ctx.self; cursor; cursor = cursor.parent) if (cursor === node) selfDestroyed = true;
  const wasUi = isUiInstance(node);
  ctx.destroy(node);
  if (wasUi) ctx.markUiDirty();
  return selfDestroyed ? 'stop' : undefined;
};
export default run;
