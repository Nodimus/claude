import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'play_sound',
  label: 'Play Sound 3D',
  description: 'Toca um efeito sonoro, espacial (3D) a partir do nó emissor.',
  category: 'Audio',
  params: [
    { key: 'sound', label: 'Sound', type: 'file', default: '', accept: ['.wav', '.ogg', '.mp3'], required: true },
    { key: 'target', label: 'Emitter', type: 'node', default: '' },
    { key: 'volume', label: 'Volume', type: 'number', default: 1 },
    { key: 'pitch', label: 'Pitch', type: 'number', default: 1 },
    { key: 'spatial', label: 'Spatial (3D)', type: 'boolean', default: true },
  ],
  paramsSchema: z.object({
    sound: z.string().default(''),
    target: z.string().default(''),
    volume: z.coerce.number().default(1),
    pitch: z.coerce.number().default(1),
    spatial: z.boolean().default(true),
  }),
});
