import { z } from 'zod';
import { defineAction } from '../../types';
import { requirePhysicsBody, vec3Schema } from '../../actionHelpers';

export default defineAction({
  id: 'set_linear_velocity',
  label: 'Set Linear Velocity',
  description: 'Define a velocidade linear do corpo. Corpos "dynamic" ou "character".',
  category: 'Physics',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'velocity', label: 'Velocity (m/s)', type: 'vector3', default: { x: 0, y: 0, z: 0 } },
    { key: 'space', label: 'Space', type: 'enum', default: 'world', options: ['world', 'local'] },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    velocity: vec3Schema(0, 0, 0),
    space: z.enum(['world', 'local']).default('world'),
  }),
  validate: requirePhysicsBody('Set Linear Velocity', ['dynamic', 'character']),
});
