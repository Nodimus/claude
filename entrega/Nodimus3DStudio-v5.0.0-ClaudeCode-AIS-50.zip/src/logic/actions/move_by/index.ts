import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'move_by',
  label: 'Move By',
  description: 'Move o nó por um deslocamento relativo (Overlay2D: pelos offsets do layout).',
  category: 'Movement',
  params: [
    { key: 'dx', label: 'dx', type: 'number', default: 1, inline: { prefix: 'dx:', width: 'xs' } },
    { key: 'dy', label: 'dy', type: 'number', default: 0 },
    { key: 'dz', label: 'dz', type: 'number', default: 0, inline: { prefix: 'dz:', width: 'xs' }, hideForUi: true },
  ],
  quickAdd: { label: 'Move', order: 2, parameters: { dx: 1, dz: 0 } },
  paramsSchema: z.object({
    dx: z.coerce.number().default(1),
    dy: z.coerce.number().default(0),
    dz: z.coerce.number().default(0),
  }),
});
