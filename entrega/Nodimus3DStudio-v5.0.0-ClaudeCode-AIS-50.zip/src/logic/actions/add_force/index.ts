import { z } from 'zod';
import { defineAction } from '../../types';
import { requirePhysicsBody, vec3Schema } from '../../actionHelpers';

export default defineAction({
  id: 'add_force',
  label: 'Add Force',
  description: 'Aplica uma força contínua ao corpo (world ou local). Só corpos "dynamic".',
  category: 'Physics',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'force', label: 'Force (N)', type: 'vector3', default: { x: 0, y: 10, z: 0 } },
    { key: 'space', label: 'Space', type: 'enum', default: 'world', options: ['world', 'local'] },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    force: vec3Schema(0, 10, 0),
    space: z.enum(['world', 'local']).default('world'),
  }),
  validate: requirePhysicsBody('Add Force', ['dynamic']),
});
