import type { ActionExecutor } from '../../types';

const run: ActionExecutor<Record<string, never>> = (_p, ctx) => {
  ctx.host.quitGame();
  return 'stop';
};
export default run;
