import { z } from 'zod';
import { defineAction } from '../../types';
import { requirePhysicsBody, vec3Schema } from '../../actionHelpers';

export default defineAction({
  id: 'teleport_physics_body',
  label: 'Teleport Physics Body',
  description: 'Reposiciona o corpo físico; opcionalmente zera as velocidades.',
  category: 'Physics',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'position', label: 'Position', type: 'vector3', default: { x: 0, y: 0, z: 0 } },
    { key: 'clearVelocities', label: 'Clear velocities', type: 'boolean', default: true },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    position: vec3Schema(0, 0, 0),
    clearVelocities: z.boolean().default(true),
  }),
  validate: requirePhysicsBody('Teleport Physics Body', ['static', 'dynamic', 'kinematic', 'character', 'trigger']),
});
