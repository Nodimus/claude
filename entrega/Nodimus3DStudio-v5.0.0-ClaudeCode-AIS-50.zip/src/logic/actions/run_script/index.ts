import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'run_script',
  label: 'Run Script',
  description: 'Executa um script .js/.ts de res://scripts/ (sandbox em Web Worker, AIS-79).',
  category: 'Logic',
  // sem o sistema/serviço de que depende, aparece desabilitada com "em breve" (decisão 14); nunca executa
  status: 'disabled',
  params: [
    { key: 'scriptRef', label: 'Script', type: 'file', default: '', accept: ['.js', '.ts'], required: true, root: 'res://scripts/' },
  ],
  paramsSchema: z.object({
    scriptRef: z.string().default('').refine((v) => v === '' || /^res:\/\/scripts\/.+\.(js|ts)$/i.test(v), { message: 'O script precisa ser um .js ou .ts de res://scripts/' }),
  }),
});
