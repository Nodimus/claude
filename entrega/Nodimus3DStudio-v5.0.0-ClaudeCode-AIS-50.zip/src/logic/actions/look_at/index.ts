import { z } from 'zod';
import { defineAction } from '../../types';
import { require3dNode, vec3Schema } from '../../actionHelpers';

export default defineAction({
  id: 'look_at',
  label: 'Look At',
  description: 'Gira o nó para olhar um nó alvo (ou uma posição, se o nó ficar vazio).',
  category: 'Movement',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'lookAtNode', label: 'Look at node', type: 'node', default: '' },
    { key: 'position', label: 'Or position', type: 'vector3', default: { x: 0, y: 0, z: 0 } },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    lookAtNode: z.string().default(''),
    position: vec3Schema(0, 0, 0),
  }),
  validate: require3dNode('Look At'),
});
