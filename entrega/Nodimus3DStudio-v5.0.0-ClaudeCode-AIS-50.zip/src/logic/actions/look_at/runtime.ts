import * as THREE from 'three';
import type { ActionExecutor } from '../../types';
import { resolveTarget } from '../../actionRuntimeHelpers';

/** Vira o nó alvo para outro nó (se informado) ou para uma posição do mundo. */
const run: ActionExecutor<{ target: string; lookAtNode: string; position: { x: number; y: number; z: number } }> = ({ target, lookAtNode, position }, ctx) => {
  const subject = resolveTarget('Look At', target, ctx);
  if (!subject?.object) return;
  const point = new THREE.Vector3(position.x, position.y, position.z);
  if (lookAtNode.trim()) {
    const other = resolveTarget('Look At', lookAtNode, ctx);
    if (!other?.object) return;
    other.object.updateWorldMatrix(true, false);
    other.object.getWorldPosition(point);
  }
  subject.object.updateWorldMatrix(true, false);
  subject.object.lookAt(point);
  const e = subject.object.rotation;
  subject.transform.rotation = [THREE.MathUtils.radToDeg(e.x), THREE.MathUtils.radToDeg(e.y), THREE.MathUtils.radToDeg(e.z)];
};
export default run;
