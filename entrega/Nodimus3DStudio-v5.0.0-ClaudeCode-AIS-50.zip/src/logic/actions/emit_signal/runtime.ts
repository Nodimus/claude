import type { ActionExecutor } from '../../types';

const run: ActionExecutor<{ signal: string }> = ({ signal }, ctx) => {
  if (!signal.trim()) return ctx.log('error', 'Emit Signal: informe o nome do sinal.');
  ctx.emitSignal(signal.trim());
};
export default run;
