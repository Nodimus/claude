import { z } from 'zod';
import { defineAction } from '../../types';
import { requirePhysicsBody, vec3Schema } from '../../actionHelpers';

export default defineAction({
  id: 'add_impulse',
  label: 'Add Impulse',
  description: 'Aplica um impulso instantâneo ao corpo (world ou local). Só corpos "dynamic".',
  category: 'Physics',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'impulse', label: 'Impulse (N·s)', type: 'vector3', default: { x: 0, y: 5, z: 0 } },
    { key: 'space', label: 'Space', type: 'enum', default: 'world', options: ['world', 'local'] },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    impulse: vec3Schema(0, 5, 0),
    space: z.enum(['world', 'local']).default('world'),
  }),
  validate: requirePhysicsBody('Add Impulse', ['dynamic']),
});
