import { z } from 'zod';
import { defineAction } from '../../types';
import { requireNodeType } from '../../actionHelpers';

export default defineAction({
  id: 'switch_pose',
  label: 'Switch Pose',
  description: 'Troca para uma pose da biblioteca (Idle, Walk, Run) com crossfade.',
  category: 'Visual',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'pose', label: 'Pose', type: 'enum', default: 'idle', options: ['idle', 'walk', 'run'] },
    { key: 'crossfade', label: 'Crossfade (s)', type: 'number', default: 0.2 },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    pose: z.enum(['idle', 'walk', 'run']).default('idle'),
    crossfade: z.coerce.number().default(0.2),
  }),
  validate: requireNodeType('Switch Pose', ['AnimationPlayer', 'MeshInstance']),
});
