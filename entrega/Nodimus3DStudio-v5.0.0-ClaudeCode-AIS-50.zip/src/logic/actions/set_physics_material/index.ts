import { z } from 'zod';
import { defineAction } from '../../types';
import { requirePhysicsBody } from '../../actionHelpers';

export default defineAction({
  id: 'set_physics_material',
  label: 'Set Physics Material',
  description: 'Muda atrito e restituição (bounce) do corpo em tempo de execução.',
  category: 'Physics',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'friction', label: 'Friction (0–1)', type: 'number', default: 0.5 },
    { key: 'bounce', label: 'Restitution (0–1)', type: 'number', default: 0 },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    friction: z.coerce.number().default(0.5).transform((v) => Math.min(1, Math.max(0, v))),
    bounce: z.coerce.number().default(0).transform((v) => Math.min(1, Math.max(0, v))),
  }),
  validate: requirePhysicsBody('Set Physics Material', ['static', 'dynamic', 'kinematic', 'character']),
});
