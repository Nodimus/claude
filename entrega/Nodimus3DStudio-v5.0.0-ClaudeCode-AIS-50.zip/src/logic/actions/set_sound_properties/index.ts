import { z } from 'zod';
import { defineAction } from '../../types';

export default defineAction({
  id: 'set_sound_properties',
  label: 'Set Sound Volume / Pitch',
  description: 'Altera volume e pitch de um som em execução.',
  category: 'Audio',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'volume', label: 'Volume', type: 'number', default: 1 },
    { key: 'pitch', label: 'Pitch', type: 'number', default: 1 },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    volume: z.coerce.number().default(1),
    pitch: z.coerce.number().default(1),
  }),
});
