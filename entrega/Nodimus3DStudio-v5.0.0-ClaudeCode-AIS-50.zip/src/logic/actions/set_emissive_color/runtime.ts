import * as THREE from 'three';
import type { ActionExecutor } from '../../types';
import { resolveTarget } from '../../actionRuntimeHelpers';

/** Cor emissiva dos materiais do nó (só no objeto vivo do Play). */
const run: ActionExecutor<{ target: string; color: string; intensity: number }> = ({ target, color, intensity }, ctx) => {
  const node = resolveTarget('Set Emissive Color', target, ctx);
  if (!node?.object) return;
  let applied = 0;
  node.object.traverse((child) => {
    const materials = (child as THREE.Mesh).material;
    for (const m of Array.isArray(materials) ? materials : materials ? [materials] : []) {
      const std = m as THREE.MeshStandardMaterial;
      if (std.emissive) {
        std.emissive.set(color);
        std.emissiveIntensity = intensity;
        applied++;
      }
    }
  });
  if (applied === 0) ctx.log('warn', `Set Emissive Color: "${node.name}" não tem material com emissão.`);
};
export default run;
