import { z } from 'zod';
import { defineAction } from '../../types';
import { requireNodeType } from '../../actionHelpers';

export default defineAction({
  id: 'play_animation',
  label: 'Play Animation',
  description: 'Executa um clipe de animação com crossfade.',
  category: 'Visual',
  params: [
    { key: 'target', label: 'Target', type: 'node', default: '' },
    { key: 'clip', label: 'Clip', type: 'string', default: '', required: true },
    { key: 'crossfade', label: 'Crossfade (s)', type: 'number', default: 0.2 },
    { key: 'loop', label: 'Loop', type: 'boolean', default: true },
    { key: 'speed', label: 'Speed', type: 'number', default: 1 },
  ],
  paramsSchema: z.object({
    target: z.string().default(''),
    clip: z.string().default(''),
    crossfade: z.coerce.number().default(0.2),
    loop: z.boolean().default(true),
    speed: z.coerce.number().default(1),
  }),
  validate: requireNodeType('Play Animation', ['AnimationPlayer', 'MeshInstance']),
});
