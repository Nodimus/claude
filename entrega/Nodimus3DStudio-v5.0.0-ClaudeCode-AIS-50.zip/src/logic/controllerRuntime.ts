import { PhysicsBridgeError } from '../core/physics/PhysicsBridge';
import type { BehaviorRuntimeContext } from './types';

/**
 * AIS-47 — helpers dos controladores de personagem (`behaviors/<id>/runtime.ts`). Ficam FORA das pastas varridas pelo registry.
 * Nunca implementam gravidade nem chão: isso é do `PhysicsBridge` (character = `KinematicCharacterController`).
 */

/**
 * Avisa UMA vez (por Behavior) o que a configuração não entrega: o nó precisa de um corpo `character` na física para ter gravidade
 * e colisão. Devolve `true` quando já avisou/está tudo certo (não precisa checar de novo).
 */
export function controllerPreflight(ctx: BehaviorRuntimeContext, label: string): boolean {
  const bridge = ctx.physics;
  if (!bridge) {
    // o Rapier carrega em segundo plano: dá 1 s de tolerância antes de avisar que a cena não tem corpo físico
    if (ctx.sceneTime < 1) return false;
    ctx.log('warn', `${label}: a cena não tem mundo físico; ative "Colisão" como "Personagem" (character) neste nó. Sem corpo ele só desliza, sem gravidade nem colisão.`);
    return true;
  }
  const mode = bridge.modeOf(ctx.node.persistentNodeId);
  if (mode === 'character') return true;
  ctx.log('warn', mode ? `${label}: o corpo deste nó é "${mode}"; use "Personagem" (character) na Colisão para ter gravidade e colisão.` : `${label}: o nó não tem corpo físico; ative "Colisão" como "Personagem" (character). Sem corpo ele só desliza, sem gravidade nem colisão.`);
  return true;
}

/** Pulo: só no chão, só por `setLinearVelocity` da ponte (nada de segunda gravidade). Erro de física vira log, não exceção. */
export function tryJump(ctx: BehaviorRuntimeContext, jumpSpeed: number): boolean {
  const bridge = ctx.physics;
  const id = ctx.node.persistentNodeId;
  if (!bridge || bridge.modeOf(id) !== 'character' || !bridge.isGrounded(id) || !(jumpSpeed > 0)) return false;
  try {
    bridge.setLinearVelocity(id, { x: 0, y: jumpSpeed, z: 0 });
    return true;
  } catch (error) {
    if (error instanceof PhysicsBridgeError) ctx.log('error', error.message);
    else throw error;
    return false;
  }
}

/** Olhar com mouse só enquanto o ponteiro está capturado (PointerLock); fora do navegador (testes) vale sempre. */
export function pointerLookActive(): boolean {
  return typeof document === 'undefined' || !!document.pointerLockElement;
}
