import { defineBehavior, newLogicId } from '../../types';

export default defineBehavior({
  id: 'simple_wasd_movement',
  label: '3D Movement Controller',
  description: 'Controlador de movimento 3D por teclado.',
  category: 'Movement',
  params: [
    { key: 'speed', label: 'Speed', type: 'number', default: 6.0 },
    { key: 'jumpForce', label: 'Jump Force', type: 'number', default: 8.0 },
  ],
  preset: { label: '3D Controller', order: 1 },
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `3D Movement Controller (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'simple_wasd_movement',
    enabled: true,
    properties: { speed: 6.0, jumpForce: 8.0 },
    rules: [
      {
        id: newLogicId('r_', 5),
        eventType: 'on_update',
        parameters: {},
        conditions: [{ id: 'c1', type: 'always', parameters: {} }],
        actions: [
          { id: newLogicId('act_', 5), type: 'move_by', parameters: { dx: 1, dz: 0 } },
        ],
      },
    ],
  }),
});
