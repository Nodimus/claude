import * as THREE from 'three';
import type { BehaviorRuntimeModule } from '../../types';

/** Move o nó dono pelas ações MoveLeft/Right/Forward/Backward (nunca teclas) a `speed` unidades/s e o vira para o movimento. */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create: () => ({
    onUpdate(ctx, dt) {
      const p = ctx.state.properties;
      const speed = (typeof p.speed === 'number' && p.speed ? p.speed : 6) * dt;
      const dx = ctx.input.getAxis('MoveLeft', 'MoveRight') * speed;
      const dz = ctx.input.getAxis('MoveForward', 'MoveBackward') * speed;
      if (dx === 0 && dz === 0) return;
      const [x, y, z] = ctx.node.transform.position;
      ctx.node.transform.position = [x + dx, y, z + dz];
      const [rx, , rz] = ctx.node.transform.rotation;
      ctx.node.transform.rotation = [rx, THREE.MathUtils.radToDeg(Math.atan2(dx, dz)), rz];
      ctx.applyTransform(ctx.node);
    },
  }),
};
export default mod;
