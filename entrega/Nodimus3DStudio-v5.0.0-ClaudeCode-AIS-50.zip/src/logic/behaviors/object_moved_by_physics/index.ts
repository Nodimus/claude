import { defineBehavior, newLogicId } from '../../types';

export default defineBehavior({
  id: 'object_moved_by_physics',
  label: 'Object Moved By Physics Engine',
  description:
    'Preset "Físico" (dynamic) do mecanismo único de física: o objeto é movido pela simulação. Forma, tamanho, massa, atrito e quique ficam no bloco de Colisão do objeto, nunca aqui. A regra de impacto (On Collision Enter) executa as Actions quando a força passa de "Minimal Force", no máximo uma vez a cada "Max Every (ms)".',
  category: 'Physics',
  params: [],
  preset: { label: 'Physics Object', order: 6 },
  /** Ao adicionar pelo preset, a Colisão do nó vira "Físico" (dynamic), um Command com Undo (decisão 26). */
  presetPhysics: { bodyMode: 'dynamic' },
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Object Moved By Physics (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'object_moved_by_physics',
    enabled: true,
    properties: {},
    rules: [
      {
        id: newLogicId('r_', 5),
        // legado: DoActionOnImpact + Action + MinimalForceToTrigger + TriggerMaximalEveryMs = esta regra e seus parâmetros
        eventType: 'on_collision_enter',
        parameters: { minimalForce: 0, maxEveryMs: 0 },
        conditions: [{ id: newLogicId('c_', 5), type: 'always', parameters: {} }],
        actions: [],
      },
    ],
  }),
});
