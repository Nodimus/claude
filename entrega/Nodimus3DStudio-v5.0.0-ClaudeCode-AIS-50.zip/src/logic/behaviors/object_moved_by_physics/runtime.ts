import type { BehaviorRuntimeModule } from '../../types';

/**
 * Object Moved By Physics Engine (AIS-48): as regras (On Collision Enter com força mínima/debounce) rodam no `LogicRunner`; este
 * executor só confere que o corpo do nó é `dynamic` (um só mecanismo: o Behavior nunca cria corpo nem define forma) e avisa uma vez.
 */
const mod: BehaviorRuntimeModule = {
  create: () => {
    let checked = false;
    return {
      onUpdate(ctx) {
        if (checked) return;
        const bridge = ctx.physics;
        if (!bridge) {
          if (ctx.sceneTime >= 1) {
            checked = true;
            ctx.log('warn', 'Object Moved By Physics: a cena não tem mundo físico; ative "Colisão" neste nó como "Físico" (dynamic).');
          }
          return;
        }
        checked = true;
        const mode = bridge.modeOf(ctx.node.persistentNodeId);
        if (mode !== 'dynamic') ctx.log('warn', mode ? `Object Moved By Physics: o corpo deste nó é "${mode}"; use "Físico" (dynamic) na Colisão para ser movido pela física.` : 'Object Moved By Physics: o nó não tem corpo físico; ative "Colisão" como "Físico" (dynamic).');
      },
    };
  },
};
export default mod;
