import { defineBehavior, newLogicId } from '../../types';

export default defineBehavior({
  id: 'third_person_controller',
  label: 'Third Person Controller',
  description:
    'Controlador em terceira pessoa: câmera orbital (botão direito + arrastar) que segue o personagem com suavização elástica; WASD relativo à câmera; o personagem se volta para a direção do movimento; pulo com a ação Jump. Exige o bloco de Colisão do nó como "Personagem" (character).',
  category: 'Movement',
  params: [
    { key: 'moveSpeed', label: 'Move Speed (m/s)', type: 'number', default: 5 },
    { key: 'jumpSpeed', label: 'Jump Speed (m/s)', type: 'number', default: 6 },
    { key: 'rotateSpeed', label: 'Orbit Sensitivity (°/px)', type: 'number', default: 0.3 },
    { key: 'distance', label: 'Camera Distance (m)', type: 'number', default: 6 },
    { key: 'targetHeight', label: 'Target Height (m)', type: 'number', default: 1.4 },
    { key: 'followSmoothingSpeed', label: 'Follow Smoothing (1/s)', type: 'number', default: 6 },
    { key: 'turnSpeed', label: 'Turn Speed (1/s)', type: 'number', default: 12 },
    { key: 'minPitch', label: 'Min Camera Angle (°)', type: 'number', default: -10 },
    { key: 'maxPitch', label: 'Max Camera Angle (°)', type: 'number', default: 80 },
    { key: 'fov', label: 'Field of View (°)', type: 'number', default: 60 },
  ],
  preset: { label: 'Third Person', order: 5 },
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Third Person Controller (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'third_person_controller',
    enabled: true,
    properties: { moveSpeed: 5, jumpSpeed: 6, rotateSpeed: 0.3, distance: 6, targetHeight: 1.4, followSmoothingSpeed: 6, turnSpeed: 12, minPitch: -10, maxPitch: 80, fov: 60 },
    rules: [],
  }),
});
