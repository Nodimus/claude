import type { BehaviorRuntime, BehaviorRuntimeContext, BehaviorRuntimeModule } from '../../types';
import { initialThirdPersonState, readThirdPersonParams, stepThirdPerson, thirdPersonCamera, type ThirdPersonState } from '../../../runtime/controllers/thirdPerson';
import { controllerPreflight, tryJump } from '../../controllerRuntime';

/**
 * Third Person Controller (AIS-47): intenção de movimento relativa à câmera orbital; o personagem vira para onde anda; a câmera segue
 * a pose SIMULADA (depois da física) com suavização elástica. Gravidade/colisão/pulo = `PhysicsBridge` (character).
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let state: ThirdPersonState = initialThirdPersonState();
    let warnedPhysics = false;
    const params = (ctx: BehaviorRuntimeContext) => readThirdPersonParams(ctx.state.properties);

    return {
      attach(ctx) {
        // a câmera nasce atrás de onde o personagem está virado
        state = initialThirdPersonState(ctx.initialTransform.rotation[1]);
        const [rx, , rz] = ctx.node.transform.rotation;
        ctx.node.transform.rotation = [rx, state.faceYaw, rz];
      },
      onPlayStart(ctx) {
        ctx.log('info', 'Third Person: botão direito + arrastar orbita a câmera.');
      },
      onUpdate(ctx, dt) {
        if (!warnedPhysics && controllerPreflight(ctx, 'Third Person Controller')) warnedPhysics = true;
        const p = params(ctx);
        const pointer = ctx.input.pointer;
        const next = stepThirdPerson(
          state,
          p,
          {
            forward: ctx.input.getAxis('MoveBackward', 'MoveForward'),
            strafe: ctx.input.getAxis('MoveLeft', 'MoveRight'),
            lookDx: pointer?.dx ?? 0,
            lookDy: pointer?.dy ?? 0,
            orbiting: ctx.input.isActionPressed('AltFire'), // botão direito do mouse
          },
          dt
        );
        state = next.state;
        const [x, y, z] = ctx.node.transform.position;
        ctx.node.transform.position = [x + next.delta.x, y, z + next.delta.z];
        const [rx, , rz] = ctx.node.transform.rotation;
        ctx.node.transform.rotation = [rx, state.faceYaw, rz];
        ctx.applyTransform(ctx.node);
        if (ctx.input.isActionJustPressed('Jump')) tryJump(ctx, p.jumpSpeed);
      },
      onLateUpdate(ctx, dt) {
        const p = params(ctx);
        const [x, y, z] = ctx.node.transform.position;
        const cam = thirdPersonCamera({ x, y, z }, state, p, dt);
        state = cam.state;
        ctx.setGameCamera({ position: cam.position, quaternion: cam.quaternion, fov: p.fov, pointerLock: false });
      },
      detach(ctx) {
        ctx.setGameCamera(null);
      },
    };
  },
};
export default mod;
