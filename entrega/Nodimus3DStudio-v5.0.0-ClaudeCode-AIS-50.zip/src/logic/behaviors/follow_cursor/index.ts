import { defineBehavior, newLogicId } from '../../types';

export default defineBehavior({
  id: 'follow_cursor',
  label: 'Follow Cursor',
  description: 'Faz o objeto seguir o cursor.',
  category: 'Movement',
  params: [],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Follow Cursor (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'follow_cursor',
    enabled: true,
    properties: {},
    rules: [],
  }),
});
