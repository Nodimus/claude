import { defineBehavior, newLogicId } from '../../types';

export default defineBehavior({
  id: 'timer_trigger',
  label: 'Timer Trigger',
  description: 'Executa ações a cada intervalo de tempo.',
  category: 'Interaction',
  params: [
    { key: 'interval', label: 'Interval (s)', type: 'number', default: 1 },
  ],
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `Timer Trigger (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'timer_trigger',
    enabled: true,
    properties: { interval: 1 },
    rules: [],
  }),
});
