import type { BehaviorRuntime, BehaviorRuntimeContext, BehaviorRuntimeModule } from '../../types';
import { firstPersonCamera, initialFirstPersonState, readFirstPersonParams, stepFirstPerson, type FirstPersonState } from '../../../runtime/controllers/firstPerson';
import { controllerPreflight, tryJump, pointerLookActive } from '../../controllerRuntime';

/**
 * First Person Controller (AIS-47): o Behavior só emite INTENÇÃO — move a pose da instância e a `PhysicsBridge` (character =
 * `KinematicCharacterController`) resolve gravidade, colisão e chão. Pulo = `setLinearVelocity` pela ponte, só no chão. A câmera de
 * jogo sai DEPOIS do passo da física (olhos na pose simulada). Estado por (nó × Behavior): nada de singleton.
 */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create(): BehaviorRuntime {
    let state: FirstPersonState = initialFirstPersonState();
    let warnedPhysics = false;
    const params = (ctx: BehaviorRuntimeContext) => readFirstPersonParams(ctx.state.properties);

    return {
      attach(ctx) {
        // recomeça da pose AUTORAL (Restart Behavior zera o olhar), não da rotação que o jogo já aplicou
        state = initialFirstPersonState(ctx.initialTransform.rotation[1]);
        const [rx, , rz] = ctx.node.transform.rotation;
        ctx.node.transform.rotation = [rx, state.yaw, rz];
      },
      onPlayStart(ctx) {
        // o corpo do personagem não aparece na própria câmera
        ctx.node.visible = false;
        if (ctx.node.object) ctx.node.object.visible = false;
        ctx.log('info', 'First Person: clique na viewport para capturar o mouse (Esc libera).');
      },
      onUpdate(ctx, dt) {
        if (!warnedPhysics && controllerPreflight(ctx, 'First Person Controller')) warnedPhysics = true;
        const p = params(ctx);
        const pointer = ctx.input.pointer;
        const look = pointerLookActive() ? { dx: pointer?.dx ?? 0, dy: pointer?.dy ?? 0 } : { dx: 0, dy: 0 };
        const next = stepFirstPerson(
          state,
          p,
          { forward: ctx.input.getAxis('MoveBackward', 'MoveForward'), strafe: ctx.input.getAxis('MoveLeft', 'MoveRight'), lookDx: look.dx, lookDy: look.dy },
          dt
        );
        state = next.state;
        const [x, y, z] = ctx.node.transform.position;
        ctx.node.transform.position = [x + next.delta.x, y, z + next.delta.z];
        const [rx, , rz] = ctx.node.transform.rotation;
        ctx.node.transform.rotation = [rx, state.yaw, rz];
        ctx.applyTransform(ctx.node);
        if (ctx.input.isActionJustPressed('Jump')) tryJump(ctx, p.jumpSpeed);
      },
      onLateUpdate(ctx) {
        const p = params(ctx);
        const [x, y, z] = ctx.node.transform.position;
        const cam = firstPersonCamera({ x, y, z }, state, p);
        ctx.setGameCamera({ position: cam.position, quaternion: cam.quaternion, fov: p.fov, pointerLock: true });
      },
      detach(ctx) {
        ctx.setGameCamera(null);
      },
    };
  },
};
export default mod;
