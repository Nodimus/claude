import { defineBehavior, newLogicId } from '../../types';

export default defineBehavior({
  id: 'first_person_controller',
  label: 'First Person Controller',
  description:
    'Controlador em primeira pessoa: WASD relativo ao olhar, pulo com a ação Jump e olhar com o mouse (PointerLock: clique na viewport). Exige o bloco de Colisão do nó como "Personagem" (character): a gravidade e a colisão são da física, não do Behavior.',
  category: 'Movement',
  params: [
    { key: 'moveSpeed', label: 'Move Speed (m/s)', type: 'number', default: 5 },
    { key: 'rotateSpeed', label: 'Mouse Sensitivity (°/px)', type: 'number', default: 0.15 },
    { key: 'jumpSpeed', label: 'Jump Speed (m/s)', type: 'number', default: 6 },
    { key: 'maxVerticalAngle', label: 'Max Vertical Angle (°)', type: 'number', default: 85 },
    { key: 'eyeHeight', label: 'Eye Height (m)', type: 'number', default: 1.6 },
    { key: 'smoothing', label: 'Smooth Moving (1/s, 0 = off)', type: 'number', default: 0 },
    { key: 'fov', label: 'Field of View (°)', type: 'number', default: 70 },
  ],
  preset: { label: 'First Person', order: 4 },
  create: ({ targetNodeId }) => ({
    id: newLogicId('beh_'),
    name: `First Person Controller (${targetNodeId})`,
    targetNodeId,
    behaviorType: 'first_person_controller',
    enabled: true,
    properties: { moveSpeed: 5, rotateSpeed: 0.15, jumpSpeed: 6, maxVerticalAngle: 85, eyeHeight: 1.6, smoothing: 0, fov: 70 },
    rules: [],
  }),
});
