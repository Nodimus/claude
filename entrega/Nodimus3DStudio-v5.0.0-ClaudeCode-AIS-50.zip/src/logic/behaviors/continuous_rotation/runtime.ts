import type { BehaviorRuntimeModule } from '../../types';

/** Gira o nó dono em `rotationSpeed` graus/s no eixo `axis`. Estado (propriedades de trabalho) por instância. */
const mod: BehaviorRuntimeModule = {
  replacesRules: true,
  create: () => ({
    onUpdate(ctx, dt) {
      const p = ctx.state.properties;
      const speed = typeof p.rotationSpeed === 'number' ? p.rotationSpeed : 60;
      const index = p.axis === 'x' ? 0 : p.axis === 'z' ? 2 : 1;
      const next: [number, number, number] = [...ctx.node.transform.rotation];
      next[index] += speed * dt;
      ctx.node.transform.rotation = next;
      ctx.applyTransform(ctx.node);
    },
  }),
};
export default mod;
