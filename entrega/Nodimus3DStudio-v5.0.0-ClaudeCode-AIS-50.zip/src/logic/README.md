# `src/logic/` — Behaviors, Actions, Triggers e Conditions em pastas

> v4.7.0 · AIS-05r. **Não é sistema de extensões nem de plugins.** É a organização interna do
> código do editor para facilitar a expansão por programação futura. Tudo aqui é compilado
> junto com o editor; nada é carregado em runtime e nada vem de `res://`.

> Manual completo de uso/desenvolvimento, skill e SPEC atualizados: [`manual/`](../../manual/README.md).

## Estrutura

```
src/logic/
├── types.ts          contratos (TriggerDefinition, ActionDefinition, …) e helpers define*
├── registry.ts       LogicRegistry — descobre as pastas via import.meta.glob (build)
├── triggers/<id>/index.ts
├── conditions/<id>/index.ts
├── actions/<id>/index.ts
└── behaviors/<id>/index.ts
```

- **O nome da pasta é o ID estável** (snake_case) gravado nas cenas. Nunca renomeie uma pasta
  existente: cenas antigas passariam a apontar para um ID desconhecido (que é preservado, mas
  deixa de ser resolvido).
- Cada `index.ts` faz `export default defineAction({...})` (ou `defineTrigger`, `defineCondition`,
  `defineBehavior`) com `id` igual ao nome da pasta.
- O registry ignora e reporta (`LogicRegistry.diagnostics`) pasta sem export default, `id` diferente
  da pasta, `id` fora de snake_case ou duplicado.

## Adicionar um item novo

1. Criar `src/logic/actions/<novo_id>/index.ts` (ou o tipo correspondente).
2. Declarar `label`, `description`, `category`, `params` (e `quickAdd`/`preset` se deve aparecer
   como botão rápido no Visual Logic Editor).
3. Se for um item nativo obrigatório, incluir o ID em `EXPECTED_NATIVE_LOGIC` (`registry.ts`) — o
   teste de enumeração `verifyLogicRegistry()` passa a falhar se a pasta sumir.
4. Item ainda sem execução: `status: 'disabled'` → aparece desabilitado com tooltip "em breve"
   (decisão canônica 14).

Nenhum outro arquivo precisa ser editado: UI, validação e (a partir do AIS-44) o executor consomem
o mesmo `LogicRegistry`.

## Evolução prevista por prompt

| Prompt | O que entra na pasta de cada item |
|---|---|
| AIS-40 / AIS-41 | novas pastas de Triggers/Actions do catálogo (ex.: `actions/add_force/`, `actions/run_script/` desabilitada) |
| AIS-41b | separação Definition × Instance (a definição continua aqui) |
| AIS-42 | `params` completos alimentam o editor de parâmetros (PropertyDescriptor) |
| AIS-44 / AIS-44b | `runtime.ts` com o executor do item, chamado pela `RuntimeSession` |
| AIS-85b | requisitos de capability por item (`runtimeWeb`, `requiresPhysics`, …) |

## Catálogo de Triggers (AIS-40)

| Nome da especificação | Pasta (ID estável) |
|---|---|
| OnSceneStart | `on_start` |
| OnKeyDown / OnKeyUp | `on_key_down` / `on_key_up` (`on_key_press` fica por compatibilidade) |
| OnMouseDown | `on_mouse_down` (parâmetros `button` e `target`) |
| OnMouseClick | `on_click` (clique no objeto por raycast) |
| OnCollisionEnter / OnCollisionExit | `on_collision_enter` / `on_collision_exit` |
| OnTimerInterval | `on_timeout` (`interval` e `repeat`) |
| OnVariableChanged | `on_variable_changed` (desabilitado "em breve" até o AIS-43) |

Triggers são só **definições**: quem os dispara é o runtime do AIS-44/44b (assinaturas com disposer). O picker não cria listeners.

## Catálogo de Actions (AIS-41)

Cada Action é uma pasta com `paramsSchema` (Zod) e, quando o alvo importa, `validate` (puro): `validateAction` (`src/logic/validateAction.ts`) é o que o runtime do AIS-44 chama antes de executar — Action incompatível **falha com erro explícito**, nunca é ignorada.

| Família | Pastas |
|---|---|
| Movimento | `move_by`, `move_velocity`, `rotate_by`, `rotate_continuous`, `set_position` (Teleport), `look_at` |
| Física (`Physics`, valida `bodyMode`) | `add_force`, `add_impulse`, `set_linear_velocity`, `set_angular_velocity`, `teleport_physics_body`, `set_physics_enabled`, `set_physics_material`, `apply_torque` |
| Áudio | `play_sound`, `stop_sound`, `set_sound_properties` |
| Animação | `play_animation`, `pause_animation`, `switch_pose` |
| Cena | `change_scene`, `restart_scene`, `quit_game` |
| Variáveis (desabilitadas até o AIS-43) | `add_to_variable`, `subtract_from_variable`, `set_variable` |
| Visual / UI | `set_visible`, `toggle_visible`, `emit_particles`, `set_emissive_color`, `change_text`, `change_texture` |
| Outras | `destroy_node`, `emit_signal`, `print_log`, `run_script` (desabilitada até o AIS-79) |

`Set Collision Filter` não existe: depende de layers/masks com schema persistido (AIS-26). Parâmetros marcados `hideForUi` (o Z de `set_position`, o `dz` de `move_by`) somem do formulário quando o alvo é um nó de UI.

## Definition × Instance (AIS-41b)

- **Definition** = a pasta em `src/logic/<tipo>/<id>/` (tipo, schema, executor). Nunca guarda estado de cena nem de Play.
- **BehaviorInstance / ActionInstance** = a configuração concreta anexada a UM `GameNode` (`GameNode.behaviors`, única fonte da verdade). No arquivo `*.scene.json` v3 o tipo é `contributionId`; em memória, `behaviorType` (conversão em `core/serialization/behaviorFile.ts`). Campos e IDs desconhecidos passam intactos (`extra`).
- **Estado mutável do Play** pertence ao par nó × instância (`runtime/behaviorRuntimeState.ts`), nunca ao authoring.
- A UI e os Commands usam a visão achatada `Behavior` (instância + `targetNodeId` = ID do nó), derivada de `core/authoring/behaviors.ts`.
- Cenas v2 (lista global / IDs `beh_*` / `visualLogic.behaviors`) migram na leitura; o que não acha dono vai para `metadata.legacyBehaviors`.

## Execução no Play (AIS-44)

- O executor é `src/runtime/logicRunner.ts` (`LogicRunner`); o "como executar" de cada Action mora em `src/logic/actions/<id>/runtime.ts` (descoberto por `ActionRuntime`, `src/logic/actionRuntime.ts`). Definição (UI/schema/validação) e executor ficam na mesma pasta; Action sem `runtime.ts` não executa e o runner avisa no log (nunca ignora em silêncio).
- Actions rodam em ordem e de forma síncrona; uma Promise é fire-and-continue; `'stop'` (destruir o próprio nó, `restart_scene`, `quit_game`) aborta o resto da cadeia.
- **Delays:** nenhuma Action do catálogo suspende a cadeia. O runner oferece `schedule()`/`ctx.after()` (tempo de jogo; pausa congela, Stop cancela) para executores que precisem de espera sem bloquear o quadro. Uma Action "Wait" seria item de catálogo (AIS-41) e contradiz o fire-and-continue da emenda 3.1 do AIS-44; fica como decisão futura do usuário.
- Triggers `on_key_*` e `on_mouse_down` são eventos (logam cada disparo); só `on_update` e `on_input_action` são "contínuos" e exigem `verbose` para aparecer no log.
- Sugestões para o usuário decidir (não aplicadas aos prompts): `change_scene` ligado à `RuntimeSession` (AIS-44b) e `move_velocity` à `PhysicsBridge` (AIS-45).
- Ambiente: com o painel do navegador oculto o `requestAnimationFrame` é suspenso e o Play não avança; para testar manualmente, mantenha o painel visível.

## RuntimeSession e lifecycle de Behavior (AIS-44b)

- `src/runtime/RuntimeSession.ts` é a autoridade única do Play: dona da cena viva (`RuntimeSceneManager` próprio), variáveis, `LogicRunner`, lifecycle dos Behaviors, teardowns (`registerTeardown`, para física/Workers) e diagnósticos efêmeros (`sessionId`; `dispose` chama `clearSession`). Troca de cena: abortar cadeias → dispose Behaviors → teardowns → limpar locais → globais preservadas → nova cena → lifecycle. `restartScene()` preserva globais e restaura locais; `restartBehavior(nodeId, behaviorId)` recomeça só aquele par.
- Behavior com executor por propriedades: `src/logic/behaviors/<id>/runtime.ts` (`export default { create(): BehaviorRuntime, replacesRules? }`), descoberto por `BehaviorRuntimeCatalog`. Contrato: `attach → onPlayStart → onUpdate* → onPlayStop → detach → dispose`; uma instância e um estado por (nó × Behavior). `replacesRules: true` faz o `LogicRunner` pular as regras de preset desse Behavior (hoje: `continuous_rotation`, `simple_wasd_movement`).
- `change_scene` ganhou executor (`actions/change_scene/runtime.ts`): pede a troca à sessão e aborta o resto da cadeia; o destino é lido do projeto (nunca grava no autoral).

## Física no Play (AIS-45)

- Camadas do núcleo (`src/core/physics/`): **dados** `properties.physics` → **resolução** `resolvePhysicsDescriptor` (pura; forma/tamanho vêm de `resolveCollider`, o mesmo do wireframe) → **aplicação** `createPhysicsBody` (única factory de corpo/collider) → **controle/integração** `PhysicsBridge` (única fachada de runtime). Behaviors, Actions e scripts **nunca** recebem `RigidBody`/`Collider` do Rapier.
- A `RuntimeSession` cria o mundo (`PhysicsHost`, `src/runtime/physicsHost.ts`) com a cena viva, só se houver corpos; o Rapier carrega uma vez em segundo plano (`ensureRapier`). Ordem do quadro: Behaviors → regras (intenção) → física (passo fixo 1/60) → pose simulada copiada para a **instância de runtime** (mundo → local) → espelho no canvas. A pose simulada nunca vai ao authoring.
- Contrato por `bodyMode`: `dynamic` (Rapier dono da pose), `kinematic`/`trigger` (seguem a pose pedida pela lógica), `character` (nunca dynamic: `KinematicCharacterController`; a intenção é o deslocamento pedido; gravidade e colisão resolvidas pela ponte), `static` (fixo). Malha exata só em `static`; terreno = `addHeightfield` com o mesmo `Float32Array` (o nó `Terrain` chega no AIS-50: `heightfieldOf` é o ponto de ligação).
- Actions com executor: `add_force`, `add_impulse`, `set_linear_velocity`, `set_angular_velocity`, `apply_torque`, `teleport_physics_body`, `set_physics_enabled`, `set_physics_material`, `move_velocity`. Incompatível com o corpo (ex.: `Add Force` em `static`) = erro explícito no log, a sessão segue.
- Eventos: `bridge.onPhysicsEvent('collisionEnter'|'collisionExit'|'triggerEnter'|'triggerExit', cb)` (um evento por participante; `collisionEnter` traz `force`). Contatos **e** gatilhos alimentam os Triggers `on_collision_enter/exit`.
- Diagnósticos de física são efêmeros (`source: 'physics'`, `sessionId`): `physics.nonuniform_scale`, `physics.mesh_missing_geometry`, `physics.mesh_not_static`, `physics.heightfield_missing_data`, `physics.invalid_config`, `physics.engine_unavailable`. `physics.legacy_unconverted` é autoral, por cena.
- `settings.physics.defaultLinearDamp` é lido aqui (amortecimento dos `dynamic`); `physics.gravity3D` continua só alimentando `Scene.gravity` de cenas novas (a gravidade do Play é a da Scene).

## Controladores de personagem (AIS-47)

- Dois Behaviors, no próprio nó do personagem: `first_person_controller` (WASD relativo ao olhar, olhar com mouse por PointerLock — o primeiro clique do Play captura o ponteiro, Esc libera —, pulo na ação `Jump`) e `third_person_controller` (câmera orbital com botão direito + arrastar, seguimento elástico, WASD relativo à câmera, o personagem vira para onde anda). Presets "First Person" / "Third Person" no Visual Logic Editor.
- O nó precisa do bloco de Colisão como **Personagem** (`character`): os Behaviors só emitem INTENÇÃO (deslocamento da pose da instância); gravidade, colisão, chão e o pulo (`setLinearVelocity` pela `PhysicsBridge`, só no chão) são da física. Sem o corpo o Behavior avisa uma vez no log e o nó apenas desliza.
- A matemática é pura e testada em `src/runtime/controllers/` (`controllerMath`, `firstPerson`, `thirdPerson`); os executores em `behaviors/<id>/runtime.ts` + `src/logic/controllerRuntime.ts`.
- Câmera de jogo: o Behavior a entrega depois do passo da física (`onLateUpdate`, `ctx.setGameCamera`); a viewport a aplica por cima da câmera orbital do editor **só no Play e só quando há um controlador** (cenas sem controlador ficam idênticas). `session.gameCamera` é estado descartável.
- Parâmetros que ainda não têm execução (`CanFly`, `CollidesWithWorld`/oclusão da 3ª pessoa por shape cast, `EnableInclination`) NÃO existem nos Behaviors; entram quando houver caminho de execução e teste.
- Input: `Jump`, `MoveForward/Backward/Left/Right` e `AltFire` são AÇÕES do `InputManager` (remapear a tecla no mapa muda o Behavior sem editá-lo); o olhar com ponteiro capturado usa `movementX/Y` (`InputManager.handlePointerDelta`).

## Eventos físicos e sinais (AIS-48)

- **Quatro Triggers**, cada um uma pasta: `on_collision_enter` / `on_collision_exit` (contato sólido) e `on_trigger_enter` / `on_trigger_exit` (corpo "Área"/`trigger`: detecta a passagem sem resistência sólida). **Não existe Stay**: nenhum evento por passo enquanto os corpos permanecem em contato/dentro.
- `on_collision_enter` aceita `minimalForce` (N) e `maxEveryMs` (debounce em tempo de JOGO): é onde moram os campos legados `MinimalForceToTrigger`/`TriggerMaximalEveryMs`; as Actions da regra são a antiga `Action`/`DoActionOnImpact`.
- **Payload** (`PhysicsEvent`): `selfId`, `otherId`; `collisionEnter` traz também `force` e `contact` (ponto mundial e normal unitária de `self` PARA `other`; o evento do outro lado traz a normal oposta); `collisionExit` e os `trigger*` não têm força nem contato.
- **`onPhysicsEvent(name, cb) → unsubscribe`**: `RuntimeSession.onPhysicsEvent` (e `ctx.onPhysicsEvent` nos Behaviors, cancelado sozinho no `detach`). O adaptador mínimo `createEngineApi(session)` (`src/runtime/engineApi.ts`) é a semente do `EngineApi` do AIS-78c, que o amplia. Stop, Restart Scene, troca de cena e `dispose` cancelam todas as inscrições.
- **Sinais de nó** `body_entered` / `body_exited` (com o `otherId`): pertencem ao nó que tem `properties.physics` (qualquer tipo); aparecem na aba de Sinais só nesses nós (`core/signals/emittedSignals`). O barramento é `RuntimeSession.onNodeSignal`; **executar as conexões é do AIS-57**.
- **Behavior `object_moved_by_physics`** (preset "Physics Object"): ao adicionar pelo preset a Colisão do nó vira "Físico" (`presetPhysics`, Command próprio com Undo) e entra uma regra `On Collision Enter` pronta para receber Actions. Forma/tamanho/massa/atrito/quique continuam no bloco de Colisão.

## Assinaturas de runtime e diagnóstico (AIS-48b)

- **Todo callback registrado em runtime devolve um `unsubscribe` idempotente** e é contabilizado em `SubscriptionRegistry` (`src/runtime/subscriptions.ts`) por dono: `session`, `scene`, `instance`, `behavior` (`<nodeId>::<behaviorId>`) e `script-worker` (AIS-79). Nenhum consumidor mantém `Set` próprio de listeners ativos sem passar por ele.
- **Portas da `RuntimeSession`:** `onFrame(cb)` (depois da física), `onInput(cb)` (antes dos Behaviors), `onSignal(name, cb)`, `onPhysicsEvent(name, cb)`, `onNodeSignal(cb)`, `onSceneEvent(cb)`. Os Behaviors usam as mesmas no `ctx` (`ctx.onFrame/onInput/onSignal/onPhysicsEvent`), sempre com dono `behavior`: o `detach`, o restart e `removeBehavior(nodeId, behaviorId)` cancelam só o que era dele. Instância destruída no jogo morre junto com os Behaviors dela (reaper no começo do quadro).
- **Ciclo de vida:** Restart Scene/troca de cena descartam o que é da cena (mantêm donos `session`); Stop e `dispose` zeram tudo. `Play → Stop` repetido nunca multiplica callbacks. `subscriptionCount({ owner?, kind? })` é só leitura (testes/depuração).
- **Diagnóstico:** nada de tipo novo. Erros de Action/Behavior/física/assinante vão para o `globalDiagnosticService` (AIS-32c) com `sessionId`, efêmeros (somem ao descartar a sessão) e com contexto no próprio registro: `nodeId`, `instanceId`, `behaviorId`, `logicId`. `ctx.log(level, msg, { code })` das Actions carrega o código (ex.: `physics.incompatible_body_mode`, `physics.no_body`); `phase` é `physics` para `physics.*`, senão `runtime`.
- **Sem Stay:** só Enter/Exit; sem assinante nem regra de contato nada extra é processado por passo.

## Sono e Kill Floor (AIS-49)

- **Sono:** o `canSleep` do Rapier é o padrão do corpo (sem campo novo em `properties.physics`). Corpo `dynamic` em repouso dorme no `world.step()`; força, impulso, velocidade, torque, teleporte ou contato de outro corpo o acordam sozinhos. `PhysicsBridge.isSleeping(id)`, `activeBodyCount` e `sleepingBodyCount` expõem o custo real do loop (só leitura).
- **Kill Floor:** `dynamic`/`character` abaixo de `DEFAULT_KILL_FLOOR_Y` (-50 m; `killFloorY` na ponte; `-Infinity` desliga) emitem o evento `killFloor` (`position`) e o sinal de nó `fell_out_of_world` (`args: [y]`, mesmo barramento `onNodeSignal` do AIS-48) com o corpo AINDA no mundo. Se um assinante não o resgatar (ex.: `teleport`), o corpo é removido e o `PhysicsHost` destrói a instância. `static`/`kinematic`/`trigger` nunca são descartados. O aviso não é Trigger de contato.
- **Armadilha:** `ctx.physics` é `null` em `attach`/`onPlayStart` (o mundo entra depois); guarde a ponte a partir do primeiro `onUpdate`.
