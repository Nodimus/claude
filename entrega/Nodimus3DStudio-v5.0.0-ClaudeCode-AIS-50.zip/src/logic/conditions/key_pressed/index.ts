import { z } from 'zod';
import { defineCondition } from '../../types';
import { DEFAULT_INPUT_ACTIONS } from '../../../runtime/input/InputManager';

export default defineCondition({
  id: 'key_pressed',
  label: 'Key Pressed',
  description: 'Verdadeira enquanto a ação lógica do Input Map (Jump, MoveForward…) está pressionada; segue o remapeamento.',
  category: 'Interaction',
  params: [
    { key: 'action', label: 'Action', type: 'enum', default: 'Jump', options: [...DEFAULT_INPUT_ACTIONS] },
  ],
  paramsSchema: z.object({ action: z.string().default('Jump') }),
  // consome o InputManager (AIS-40b): nunca lê o dispositivo
  evaluate: ({ action }, ctx) => !!action && ctx.input.isActionPressed(action),
});
