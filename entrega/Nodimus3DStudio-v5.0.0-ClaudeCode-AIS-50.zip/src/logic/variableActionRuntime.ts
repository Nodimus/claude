/** AIS-44 — esqueleto comum das Actions de variável (resolve o alvo local, aplica e diz POR QUE falhou). */
import type { VariableManager, VariableScope } from '../core/variableManager';
import type { ActionRuntimeContext } from './types';

export function runVariableAction(
  label: string,
  p: { scope: VariableScope; target: string; variable: string },
  ctx: ActionRuntimeContext,
  apply: (vars: VariableManager, scope: VariableScope, name: string, nodeId?: string) => boolean
): void {
  const vars = ctx.variables;
  if (!vars) return ctx.log('error', `${label}: não há sessão de variáveis (só existem durante o Play).`);
  if (!p.variable) return ctx.log('error', `${label}: informe o nome da variável.`);
  let nodeId: string | undefined;
  if (p.scope === 'local') {
    const owner = ctx.resolve(p.target.trim());
    if (!owner) return ctx.log('error', `${label}: o nó "${p.target}" da variável local não existe na cena.`);
    nodeId = owner.persistentNodeId;
  }
  if (!apply(vars, p.scope, p.variable, nodeId)) {
    ctx.log('error', `${label}: a variável ${p.scope === 'local' ? 'local' : 'global'} "${p.variable}" não existe, não é numérica ou o valor não cabe no tipo.`);
  }
}
