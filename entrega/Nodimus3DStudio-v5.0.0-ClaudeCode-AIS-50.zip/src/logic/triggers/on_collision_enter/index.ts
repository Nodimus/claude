import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_collision_enter',
  label: 'On Collision Enter',
  description:
    'Disparado quando o nó começa a colidir com outro objeto (contato sólido). Opcional: só dispara com força de impacto ≥ "Minimal Force" e no máximo uma vez a cada "Max Every (ms)". Não existe "Stay".',
  category: 'Physics',
  params: [
    { key: 'minimalForce', label: 'Minimal Force (N)', type: 'number', default: 0 },
    { key: 'maxEveryMs', label: 'Max Every (ms)', type: 'number', default: 0 },
  ],
});
