import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_collision_exit',
  label: 'On Collision Exit',
  description: 'Disparado quando o nó deixa de colidir com outro objeto.',
  category: 'Physics',
  params: [],
});
