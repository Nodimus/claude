import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_start',
  label: 'On Scene Start',
  description: 'Disparado quando a simulação ou o jogo é iniciado (primeiro frame da cena em Play).',
  category: 'Interaction',
  params: [],
});
