import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_mouse_down',
  label: 'On Mouse Down',
  description: 'Disparado ao pressionar um botão do mouse, sobre o objeto (raycast) ou em qualquer lugar da viewport.',
  category: 'Interaction',
  params: [
    { key: 'button', label: 'Button', type: 'enum', default: 'left', options: ['left', 'middle', 'right'] },
    { key: 'target', label: 'Target', type: 'enum', default: 'object', options: ['object', 'anywhere'] },
  ],
});
