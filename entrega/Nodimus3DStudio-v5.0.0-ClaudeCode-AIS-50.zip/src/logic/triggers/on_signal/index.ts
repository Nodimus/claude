import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_signal',
  label: 'On Signal',
  description: 'Disparado quando um sinal é emitido.',
  category: 'Logic',
  params: [
    { key: 'signal', label: 'Signal', type: 'string', default: '', required: true },
  ],
});
