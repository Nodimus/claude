import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_key_up',
  label: 'On Key Up',
  description: 'Disparado ao soltar uma tecla do teclado desktop.',
  category: 'Interaction',
  params: [{ key: 'key', label: 'Key', type: 'key', default: '', required: true }],
});
