import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_timeout',
  label: 'On Timer Interval',
  description: 'Disparado a cada X segundos, repetidamente.',
  category: 'Utility',
  params: [
    { key: 'interval', label: 'Interval (s)', type: 'number', default: 1 },
    { key: 'repeat', label: 'Repeat', type: 'boolean', default: true },
  ],
});
