import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_hover',
  label: 'On Mouse Hover',
  description: 'Disparado quando o ponteiro entra no objeto (3D, por raycast) ou no controle de UI, ou quando sai dele.',
  category: 'Interaction',
  params: [{ key: 'phase', label: 'Phase', type: 'enum', default: 'enter', options: ['enter', 'exit'] }],
});
