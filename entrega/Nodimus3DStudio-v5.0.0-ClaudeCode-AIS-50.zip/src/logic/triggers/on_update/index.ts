import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_update',
  label: 'On Update',
  description: 'Disparado a cada frame durante o Play.',
  category: 'Interaction',
  params: [],
});
