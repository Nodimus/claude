import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_trigger_exit',
  label: 'On Trigger Exit',
  description: 'Disparado quando outro objeto SAI de uma Área (corpo "Área/gatilho"). Não existe "Stay": nada dispara a cada passo enquanto o objeto permanece dentro.',
  category: 'Physics',
  params: [],
});
