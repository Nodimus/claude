import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_variable_changed',
  label: 'On Variable Changed',
  description: 'Disparado quando o valor de uma variável Global ou Local muda (barramento onVariableChanged).',
  category: 'Logic',
  params: [
    { key: 'scope', label: 'Scope', type: 'enum', default: 'global', options: ['global', 'local'] },
    { key: 'target', label: 'Target', type: 'node', default: '', visibleWhen: { key: 'scope', equals: 'local' } },
    { key: 'variable', label: 'Variable', type: 'string', default: '', required: true, variable: true },
  ],
});
