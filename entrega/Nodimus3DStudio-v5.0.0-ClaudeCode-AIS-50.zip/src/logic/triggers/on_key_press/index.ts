import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_key_press',
  label: 'On Key Press',
  description: 'Disparado quando uma tecla é pressionada. Mantido por compatibilidade com cenas antigas; prefira On Key Down.',
  category: 'Interaction',
  params: [
    { key: 'key', label: 'Key', type: 'key', default: '', required: true },
  ],
});
