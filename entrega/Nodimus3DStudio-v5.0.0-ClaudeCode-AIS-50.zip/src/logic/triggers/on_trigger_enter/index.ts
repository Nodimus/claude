import { defineTrigger } from '../../types';

export default defineTrigger({
  id: 'on_trigger_enter',
  label: 'On Trigger Enter',
  description: 'Disparado quando outro objeto ENTRA numa Área (corpo "Área/gatilho"): detecta a passagem sem resistência sólida. Sem dados de força.',
  category: 'Physics',
  params: [],
});
