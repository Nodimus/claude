import type * as THREE from 'three';

/**
 * Objetos Three.js por id de GameNode (somente leitura fora da Viewport). A Viewport3D é a dona e escreve aqui;
 * Inspector e ações de edição (ex.: tamanho automático do colisor, AIS-26b) só consultam para medir geometria — nunca mutam.
 */
export const nodeObjectRegistry: Map<string, THREE.Object3D> = new Map();
