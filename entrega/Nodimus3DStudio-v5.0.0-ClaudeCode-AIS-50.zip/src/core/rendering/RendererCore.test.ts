import { describe, expect, it, vi } from 'vitest';
import * as THREE from 'three';
import { RendererCore, RendererCoreEnv } from './RendererCore';

/** Ambiente falso: RAF manual, ResizeObserver e janela contáveis. Roda em Node, sem DOM/WebGL. */
function createHarness() {
  let nextId = 1;
  const frames = new Map<number, (t: number) => void>();
  const observers: Array<{ cb: () => void; observing: boolean }> = [];
  const windowListeners = new Set<() => void>();

  const env: RendererCoreEnv = {
    requestFrame: (cb) => {
      const id = nextId++;
      frames.set(id, cb);
      return id;
    },
    cancelFrame: (id) => {
      frames.delete(id);
    },
    createResizeObserver: (cb) => {
      const entry = { cb, observing: false };
      observers.push(entry);
      return {
        observe: () => {
          entry.observing = true;
        },
        disconnect: () => {
          entry.observing = false;
        },
      };
    },
    windowTarget: {
      addEventListener: (_type, listener) => windowListeners.add(listener),
      removeEventListener: (_type, listener) => windowListeners.delete(listener),
    },
    devicePixelRatio: 3,
  };

  const canvas = { parentNode: null as unknown };
  const renderer = {
    domElement: canvas,
    setSize: vi.fn(),
    setPixelRatio: vi.fn(),
    render: vi.fn(),
    clearDepth: vi.fn(),
    autoClear: true,
    dispose: vi.fn(),
  };

  const container = {
    clientWidth: 800,
    clientHeight: 400,
    appendChild(node: typeof canvas) {
      node.parentNode = container;
    },
    removeChild(node: typeof canvas) {
      node.parentNode = null;
    },
  };

  /** Executa os quadros pendentes (um "tick" do navegador). */
  const flushFrame = (timestamp: number) => {
    const pending = [...frames.entries()];
    frames.clear();
    for (const [, cb] of pending) cb(timestamp);
  };

  const core = new RendererCore({
    env,
    createRenderer: () => renderer as unknown as THREE.WebGLRenderer,
  });

  return {
    core,
    renderer,
    canvas,
    container: container as unknown as HTMLElement,
    rawContainer: container,
    pendingFrames: () => frames.size,
    activeObservers: () => observers.filter((o) => o.observing).length,
    triggerObservers: () => observers.filter((o) => o.observing).forEach((o) => o.cb()),
    windowListenerCount: () => windowListeners.size,
    triggerWindowResize: () => windowListeners.forEach((l) => l()),
    flushFrame,
  };
}

const makeView = () => ({
  scene: new THREE.Scene(),
  camera: new THREE.PerspectiveCamera(60, 1, 0.1, 1000),
});

describe('RendererCore (AIS-06b)', () => {
  it('mount anexa o canvas, limita o pixel ratio e inicia um único loop', () => {
    const h = createHarness();
    h.core.mount(h.container);
    expect(h.canvas.parentNode).toBe(h.rawContainer);
    expect(h.renderer.setPixelRatio).toHaveBeenCalledWith(2);
    expect(h.core.isRunning).toBe(true);
    expect(h.pendingFrames()).toBe(1);
    h.flushFrame(16);
    expect(h.pendingFrames()).toBe(1); // reagenda exatamente um quadro
  });

  it('C02: resize ajusta renderer e aspecto da câmera recebida explicitamente', () => {
    const h = createHarness();
    const view = makeView();
    h.core.setView(view);
    h.core.mount(h.container);
    expect(h.renderer.setSize).toHaveBeenLastCalledWith(800, 400);
    expect(view.camera.aspect).toBe(2);

    h.rawContainer.clientWidth = 300;
    h.rawContainer.clientHeight = 300;
    h.triggerObservers();
    expect(h.renderer.setSize).toHaveBeenLastCalledWith(300, 300);
    expect(view.camera.aspect).toBe(1);

    h.rawContainer.clientWidth = 600;
    h.triggerWindowResize();
    expect(view.camera.aspect).toBe(2);
  });

  it('resize ignora host com dimensão zero (painel colapsado)', () => {
    const h = createHarness();
    h.core.mount(h.container);
    h.renderer.setSize.mockClear();
    h.rawContainer.clientHeight = 0;
    expect(h.core.resize()).toBeNull();
    expect(h.renderer.setSize).not.toHaveBeenCalled();
  });

  it('C03: montar/desmontar repetidamente não duplica RAF nem listeners', () => {
    const h = createHarness();
    for (let i = 0; i < 5; i++) {
      h.core.mount(h.container);
      h.core.mount(h.container); // idempotente para o mesmo host
      expect(h.pendingFrames()).toBe(1);
      expect(h.activeObservers()).toBe(1);
      expect(h.windowListenerCount()).toBe(1);
      h.core.unmount();
      expect(h.pendingFrames()).toBe(0);
      expect(h.activeObservers()).toBe(0);
      expect(h.windowListenerCount()).toBe(0);
      expect(h.canvas.parentNode).toBeNull();
    }
  });

  it('C03: dispose encerra loop, listeners, callbacks e o renderer', () => {
    const h = createHarness();
    h.core.onFrame(() => {});
    h.core.mount(h.container);
    h.core.dispose();
    expect(h.core.isRunning).toBe(false);
    expect(h.pendingFrames()).toBe(0);
    expect(h.windowListenerCount()).toBe(0);
    expect(h.core.frameCallbackCount).toBe(0);
    expect(h.renderer.dispose).toHaveBeenCalledTimes(1);
    h.core.dispose();
    expect(h.renderer.dispose).toHaveBeenCalledTimes(1);
    expect(() => h.core.mount(h.container)).toThrow();
  });

  it('C04: o loop é do core — callbacks rodam antes do render, fora de qualquer árvore React', () => {
    const h = createHarness();
    const view = makeView();
    const order: string[] = [];
    h.renderer.render.mockImplementation(() => order.push('render'));
    const off = h.core.onFrame(({ dt }) => {
      order.push('frame');
      expect(dt).toBeGreaterThanOrEqual(0);
      expect(dt).toBeLessThanOrEqual(0.1);
    });
    h.core.setView(view);
    h.core.mount(h.container);
    h.flushFrame(16);
    h.flushFrame(5000); // salto grande: dt limitado a maxDelta
    expect(order).toEqual(['frame', 'render', 'frame', 'render']);
    expect(h.renderer.render).toHaveBeenLastCalledWith(view.scene, view.camera);

    off();
    expect(h.core.frameCallbackCount).toBe(0);
  });

  it('setView troca a cena renderizada no mesmo canvas (editor ⇄ runtime)', () => {
    const h = createHarness();
    const editorView = makeView();
    const runtimeView = makeView();
    h.core.mount(h.container);
    h.flushFrame(16);
    expect(h.renderer.render).not.toHaveBeenCalled(); // sem view, nada a renderizar
    h.core.setView(editorView);
    h.flushFrame(32);
    expect(h.renderer.render).toHaveBeenLastCalledWith(editorView.scene, editorView.camera);
    h.core.setView(runtimeView);
    h.flushFrame(48);
    expect(h.renderer.render).toHaveBeenLastCalledWith(runtimeView.scene, runtimeView.camera);
    expect(runtimeView.camera.aspect).toBe(2);
  });

  it('uma exceção num callback não congela o loop', () => {
    const h = createHarness();
    h.core.onFrame(() => {
      throw new Error('boom');
    });
    h.core.mount(h.container);
    expect(() => h.flushFrame(16)).toThrow('boom');
    expect(h.pendingFrames()).toBe(1);
  });

  it('AIS-25b: a passada de HUD roda depois da cena, só limpa a profundidade e restaura o autoClear', () => {
    const h = createHarness();
    const order: string[] = [];
    h.renderer.render.mockImplementation(() => order.push('cena'));
    h.renderer.clearDepth.mockImplementation(() => order.push('clearDepth'));
    h.core.setView(makeView());
    const seen: boolean[] = [];
    h.core.setOverlayPass({
      render: () => {
        order.push('hud');
        seen.push(h.renderer.autoClear);
      },
    });
    h.core.mount(h.container);
    h.flushFrame(16);
    expect(order).toEqual(['cena', 'clearDepth', 'hud']);
    expect(seen).toEqual([false]); // desligado durante a passada
    expect(h.renderer.autoClear).toBe(true); // restaurado
  });

  it('AIS-25b: sem passada de HUD nada muda; remover a passada (null) volta ao render simples; erro na passada restaura o autoClear', () => {
    const h = createHarness();
    h.core.setView(makeView());
    h.core.mount(h.container);
    h.flushFrame(16);
    expect(h.renderer.clearDepth).not.toHaveBeenCalled();

    h.core.setOverlayPass({ render: () => { throw new Error('hud falhou'); } });
    expect(() => h.flushFrame(32)).toThrow('hud falhou');
    expect(h.renderer.autoClear).toBe(true);

    h.core.setOverlayPass(null);
    h.renderer.clearDepth.mockClear();
    h.flushFrame(48);
    expect(h.renderer.clearDepth).not.toHaveBeenCalled();
  });
});
