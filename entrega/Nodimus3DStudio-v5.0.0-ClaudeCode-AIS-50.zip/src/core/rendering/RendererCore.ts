import * as THREE from 'three';

/**
 * AIS-06b — Renderer Core independente do React.
 *
 * Dono único do `WebGLRenderer`, do loop de quadros (um só `requestAnimationFrame`)
 * e do relógio de quadro. Não conhece React, `EditorContext`, `SceneData`,
 * `AuthoringModel`, `Environment` nem `RuntimeSession`: recebe explicitamente a
 * cena/câmera já materializadas (`setView`) e quem precisa agir a cada quadro
 * registra um callback (`onFrame`), que devolve o próprio disposer.
 *
 * O mesmo core hospeda a cena do editor e, no futuro, a cena de runtime do Play
 * ou do jogo publicado: basta trocar a `RenderView` no mesmo canvas.
 */

/** Cena + câmera materializadas que o core renderiza. */
export interface RenderView {
  scene: THREE.Scene;
  camera: THREE.Camera;
}

export interface FrameInfo {
  /** Segundos desde o quadro anterior, em [0, `maxDelta`]. */
  dt: number;
  /** Segundos desde o último `resetClock()`/criação. */
  elapsed: number;
}

export type FrameCallback = (frame: FrameInfo) => void;

/**
 * AIS-25b — passada de HUD em espaço de tela, depois da cena principal: o core limpa só a profundidade
 * (`autoClear` desligado durante a passada) e entrega o renderer; quem implementa desenha a `uiScene`.
 */
export interface OverlayPass {
  render(renderer: THREE.WebGLRenderer, frame: FrameInfo): void;
}

interface ResizeObserverLike {
  observe(target: Element): void;
  disconnect(): void;
}

interface EventTargetLike {
  addEventListener(type: string, listener: () => void): void;
  removeEventListener(type: string, listener: () => void): void;
}

/** Superfícies do ambiente usadas pelo core (injetáveis para testes em Node). */
export interface RendererCoreEnv {
  requestFrame(cb: (timestamp: number) => void): number;
  cancelFrame(id: number): void;
  createResizeObserver(cb: () => void): ResizeObserverLike | null;
  /** Alvo do evento `resize` de janela (redimensionamento do SO). */
  windowTarget: EventTargetLike | null;
  devicePixelRatio: number;
}

export interface RendererCoreOptions {
  /** Fábrica do renderer; o padrão aplica o pipeline do AIS-06. */
  createRenderer?: () => THREE.WebGLRenderer;
  env?: Partial<RendererCoreEnv>;
  maxPixelRatio?: number;
  /** Limite do `dt` entregue aos callbacks (evita saltos após abas em segundo plano). */
  maxDelta?: number;
}

/** Pipeline de renderização homologado no AIS-06. */
export function createDefaultRenderer(options: { antialias?: boolean } = {}): THREE.WebGLRenderer {
  // AIS-44d (opção C do msaa): o `antialias` só vale na criação do contexto WebGL; o chamador lê `rendering.msaa` ao abrir.
  const renderer = new THREE.WebGLRenderer({ antialias: options.antialias ?? true, alpha: false });
  renderer.shadowMap.enabled = true;
  // three r186 removeu PCFSoftShadowMap (cai em PCFShadowMap com aviso); o PCF atual já filtra suave.
  renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  return renderer;
}

function defaultEnv(): RendererCoreEnv {
  const hasWindow = typeof window !== 'undefined';
  return {
    requestFrame: (cb) => requestAnimationFrame(cb),
    cancelFrame: (id) => cancelAnimationFrame(id),
    createResizeObserver: (cb) => (typeof ResizeObserver !== 'undefined' ? new ResizeObserver(() => cb()) : null),
    windowTarget: hasWindow ? window : null,
    devicePixelRatio: hasWindow ? window.devicePixelRatio : 1,
  };
}

export class RendererCore {
  readonly renderer: THREE.WebGLRenderer;

  private readonly env: RendererCoreEnv;
  private readonly maxPixelRatio: number;
  private readonly maxDelta: number;
  private readonly timer = new THREE.Timer();
  private readonly frameCallbacks = new Set<FrameCallback>();

  private view: RenderView | null = null;
  private overlayPass: OverlayPass | null = null;
  private container: HTMLElement | null = null;
  private rafId: number | null = null;
  private mountDisposers: Array<() => void> = [];
  private disposed = false;

  constructor(options: RendererCoreOptions = {}) {
    this.env = { ...defaultEnv(), ...options.env };
    this.maxPixelRatio = options.maxPixelRatio ?? 2;
    this.maxDelta = options.maxDelta ?? 0.1;
    this.renderer = (options.createRenderer ?? createDefaultRenderer)();
  }

  /** Anexa o canvas ao host, começa a observar resize e inicia o loop. */
  mount(container: HTMLElement): void {
    if (this.disposed) throw new Error('RendererCore: mount() após dispose()');
    if (this.container === container) return;
    if (this.container) this.unmount();

    this.container = container;
    container.appendChild(this.renderer.domElement);
    this.renderer.setPixelRatio(Math.min(this.env.devicePixelRatio, this.maxPixelRatio));
    this.resize();

    const onResize = () => this.resize();
    const observer = this.env.createResizeObserver(onResize);
    if (observer) {
      observer.observe(container);
      this.mountDisposers.push(() => observer.disconnect());
    }
    const win = this.env.windowTarget;
    if (win) {
      win.addEventListener('resize', onResize);
      this.mountDisposers.push(() => win.removeEventListener('resize', onResize));
    }

    this.startLoop();
  }

  /** Para o loop, solta os listeners e retira o canvas do host. O core pode ser remontado. */
  unmount(): void {
    this.stopLoop();
    for (const dispose of this.mountDisposers.splice(0)) dispose();
    const canvas = this.renderer.domElement;
    if (this.container && canvas.parentNode === this.container) {
      this.container.removeChild(canvas);
    }
    this.container = null;
  }

  /** Libera o renderer e todos os callbacks. Irreversível. */
  dispose(): void {
    if (this.disposed) return;
    this.unmount();
    this.frameCallbacks.clear();
    this.overlayPass = null;
    this.view = null;
    this.timer.dispose();
    this.renderer.dispose();
    this.disposed = true;
  }

  /** Troca a cena/câmera renderizada (ex.: EditorViewportScene ⇄ RuntimeScene). */
  setView(view: RenderView | null): void {
    this.view = view;
    if (this.container) this.resize();
  }

  getView(): RenderView | null {
    return this.view;
  }

  /** Registra (ou remove, com `null`) a passada de HUD desenhada depois da cena principal. */
  setOverlayPass(pass: OverlayPass | null): void {
    this.overlayPass = pass;
  }

  /** Registra trabalho por quadro, executado antes do render. Retorna o disposer. */
  onFrame(callback: FrameCallback): () => void {
    this.frameCallbacks.add(callback);
    return () => {
      this.frameCallbacks.delete(callback);
    };
  }

  /** Zera o relógio de quadro (ex.: início do Play). */
  resetClock(): void {
    this.timer.reset();
  }

  /** Ajusta o renderer e o aspecto da câmera ao tamanho atual do host. */
  resize(): { width: number; height: number } | null {
    const container = this.container;
    if (!container) return null;
    const width = container.clientWidth;
    const height = container.clientHeight;
    if (width === 0 || height === 0) return null;

    const camera = this.view?.camera;
    if (camera instanceof THREE.PerspectiveCamera) {
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    }
    this.renderer.setSize(width, height);
    return { width, height };
  }

  /** Um quadro: avança o relógio, roda os callbacks e renderiza a view atual. */
  renderFrame(timestamp?: number): void {
    this.timer.update(timestamp);
    // O Timer mede a partir de performance.now() (criação/reset), mas o timestamp do RAF é o
    // início do quadro e pode ser anterior: o 1º delta após criar/resetar pode sair negativo.
    const frame: FrameInfo = {
      dt: Math.min(Math.max(this.timer.getDelta(), 0), this.maxDelta),
      elapsed: Math.max(this.timer.getElapsed(), 0),
    };
    for (const callback of this.frameCallbacks) callback(frame);
    if (this.view) this.renderer.render(this.view.scene, this.view.camera);
    if (this.overlayPass) {
      // HUD por cima da cena: só a profundidade é limpa; o 3D permanece no framebuffer
      const previousAutoClear = this.renderer.autoClear;
      this.renderer.autoClear = false;
      this.renderer.clearDepth();
      try {
        this.overlayPass.render(this.renderer, frame);
      } finally {
        this.renderer.autoClear = previousAutoClear;
      }
    }
  }

  get isRunning(): boolean {
    return this.rafId !== null;
  }

  get isDisposed(): boolean {
    return this.disposed;
  }

  get frameCallbackCount(): number {
    return this.frameCallbacks.size;
  }

  private startLoop(): void {
    if (this.rafId !== null) return;
    const tick = (timestamp: number) => {
      // Agenda antes de trabalhar: uma exceção num callback não congela a viewport.
      this.rafId = this.env.requestFrame(tick);
      this.renderFrame(timestamp);
    };
    this.rafId = this.env.requestFrame(tick);
  }

  private stopLoop(): void {
    if (this.rafId === null) return;
    this.env.cancelFrame(this.rafId);
    this.rafId = null;
  }
}
