/**
 * AIS-43 — sistema de variáveis (globais do projeto e locais por GameNode).
 *
 * Duas camadas, ambas SEM DOM, relógio ou store autoral:
 *  1. Funções puras de AUTORIA (criar/renomear/mudar tipo ou valor/excluir, unicidade, consumidores, renomear referências).
 *     Os Commands (`VariableCommands.ts`) só aplicam o resultado, então Undo/Redo são exatos.
 *  2. `VariableManager`: o estado de uma SESSÃO de jogo. Globais nascem do valor inicial do projeto e sobrevivem à troca de
 *     Scene; locais vivem no registro da instância de runtime do nó e somem com ele. Uma só API
 *     (`getVariable/setVariable/addToVariable`), uma só resolução de `#nome.atributo` e `$var$`, um só barramento
 *     (`onVariableChanged`). Nada aqui escreve no Authoring Model: o Play opera em cópia descartável (AIS-03c).
 *
 * Forma em disco (sem migração): globais = `ProjectFile.globalVariables` (`{ id, name, type, value }`); locais =
 * `GameNode.variables` (registro `nome → valor`, o formato que a casca já grava). O TIPO de uma local é o do próprio valor
 * (`number | string | boolean`), então não existe segundo cadastro que possa divergir.
 */
import type { Behavior, LogicEventRule } from '../types/visualLogic';
import type { ProjectGlobalVariable } from '../types/projectFile';
import { LogicRegistry } from '../logic/registry';
import type { LogicParamDescriptor } from '../logic/types';

export type VariableType = 'number' | 'string' | 'boolean';
export type VariableScope = 'global' | 'local';
export type VariableValue = number | string | boolean;
export const VARIABLE_TYPES: readonly VariableType[] = ['number', 'string', 'boolean'];

export const defaultValueOf = (type: VariableType): VariableValue => (type === 'number' ? 0 : type === 'boolean' ? false : '');

/** Tipo de um valor existente; qualquer coisa que não seja número/booleano é texto. */
export const inferVariableType = (value: unknown): VariableType => (typeof value === 'number' ? 'number' : typeof value === 'boolean' ? 'boolean' : 'string');

/** Tipos que o editor de variáveis sabe editar (os demais — `vector3`, `color`… — ficam preservados, só leitura). */
export const isEditableType = (type: unknown): type is VariableType => type === 'number' || type === 'string' || type === 'boolean';

/** Converte o que o usuário digitou (ou um valor antigo) para o tipo. `null` = não representável nesse tipo. */
export function coerceVariableValue(type: VariableType, raw: unknown): VariableValue | null {
  if (type === 'number') {
    if (typeof raw === 'number') return Number.isFinite(raw) ? raw : null;
    if (typeof raw === 'boolean') return raw ? 1 : 0;
    if (typeof raw === 'string' && raw.trim() !== '') {
      const n = Number(raw);
      return Number.isFinite(n) ? n : null;
    }
    return null;
  }
  if (type === 'boolean') {
    if (typeof raw === 'boolean') return raw;
    if (typeof raw === 'number') return raw !== 0;
    if (typeof raw === 'string') {
      const t = raw.trim().toLowerCase();
      if (t === 'true' || t === '1') return true;
      if (t === 'false' || t === '0' || t === '') return false;
    }
    return null;
  }
  return typeof raw === 'string' ? raw : typeof raw === 'number' || typeof raw === 'boolean' ? String(raw) : null;
}

/** Valor resultante de MUDAR o tipo: converte o que for possível, senão volta ao padrão do novo tipo. */
export const convertToType = (value: unknown, type: VariableType): VariableValue => coerceVariableValue(type, value) ?? defaultValueOf(type);

// ── Nomes ────────────────────────────────────────────────────────────────────────────────────────

const NAME_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;

/** Mensagem de erro inline, ou `null` se o nome vale. `taken` = nomes já usados NO MESMO escopo (sem o próprio). */
export function validateVariableName(name: string, taken: readonly string[]): string | null {
  const n = name.trim();
  if (!n) return 'Informe um nome.';
  if (!NAME_RE.test(n)) return 'Use letras, números e _ (sem espaços; não começa com número).';
  if (n === 'system') return '"system" é reservado.';
  if (taken.includes(n)) return `Já existe uma variável "${n}".`;
  return null;
}

/** Primeiro `nova_variavel`, `nova_variavel_2`… livre. */
export function uniqueVariableName(taken: readonly string[], base = 'nova_variavel'): string {
  if (!taken.includes(base)) return base;
  for (let i = 2; ; i++) if (!taken.includes(`${base}_${i}`)) return `${base}_${i}`;
}

export type EditResult<T> = { ok: true; value: T } | { ok: false; error: string };
const fail = <T>(error: string): EditResult<T> => ({ ok: false, error });

// ── Autoria: globais (lista) ─────────────────────────────────────────────────────────────────────

export const globalNames = (list: readonly ProjectGlobalVariable[], except?: string): string[] => list.map((v) => v.name).filter((n) => n !== except);

export function addGlobal(list: readonly ProjectGlobalVariable[], input: { id: string; name: string; type: VariableType; value?: unknown }): EditResult<ProjectGlobalVariable[]> {
  const error = validateVariableName(input.name, globalNames(list));
  if (error) return fail(error);
  const value = input.value === undefined ? defaultValueOf(input.type) : coerceVariableValue(input.type, input.value);
  if (value === null) return fail(`O valor inicial não é ${input.type}.`);
  return { ok: true, value: [...list, { id: input.id, name: input.name.trim(), type: input.type, value }] };
}

export function renameGlobal(list: readonly ProjectGlobalVariable[], id: string, name: string): EditResult<ProjectGlobalVariable[]> {
  const current = list.find((v) => v.id === id);
  if (!current) return fail('Variável não encontrada.');
  const error = validateVariableName(name, globalNames(list, current.name));
  if (error) return fail(error);
  if (name.trim() === current.name) return { ok: true, value: list as ProjectGlobalVariable[] };
  return { ok: true, value: list.map((v) => (v.id === id ? { ...v, name: name.trim() } : v)) };
}

/** Muda tipo e/ou valor inicial (o valor é convertido ao tipo; inválido → erro, nunca valor silencioso). */
export function updateGlobal(list: readonly ProjectGlobalVariable[], id: string, patch: { type?: VariableType; value?: unknown }): EditResult<ProjectGlobalVariable[]> {
  const current = list.find((v) => v.id === id);
  if (!current) return fail('Variável não encontrada.');
  const type = patch.type ?? (isEditableType(current.type) ? current.type : inferVariableType(current.value));
  const raw = 'value' in patch ? patch.value : current.value;
  const value = 'value' in patch ? coerceVariableValue(type, raw) : convertToType(raw, type);
  if (value === null) return fail(`O valor inicial não é ${type}.`);
  if (type === current.type && value === current.value) return { ok: true, value: list as ProjectGlobalVariable[] };
  return { ok: true, value: list.map((v) => (v.id === id ? { ...v, type, value } : v)) };
}

export const removeGlobal = (list: readonly ProjectGlobalVariable[], id: string): ProjectGlobalVariable[] => list.filter((v) => v.id !== id);

// ── Autoria: locais (registro `nome → valor`) ────────────────────────────────────────────────────

export interface LocalVariable {
  name: string;
  type: VariableType;
  value: VariableValue;
}

export const localEntries = (record: Readonly<Record<string, unknown>> | undefined): LocalVariable[] =>
  Object.entries(record ?? {}).map(([name, value]) => {
    const type = inferVariableType(value);
    return { name, type, value: (type === 'string' && typeof value !== 'string' ? String(value ?? '') : value) as VariableValue };
  });

export function addLocal(record: Readonly<Record<string, any>> | undefined, input: { name: string; type: VariableType; value?: unknown }): EditResult<Record<string, any>> {
  const current = record ?? {};
  const error = validateVariableName(input.name, Object.keys(current));
  if (error) return fail(error);
  const value = input.value === undefined ? defaultValueOf(input.type) : coerceVariableValue(input.type, input.value);
  if (value === null) return fail(`O valor inicial não é ${input.type}.`);
  return { ok: true, value: { ...current, [input.name.trim()]: value } };
}

/** Renomeia preservando a ORDEM das entradas. */
export function renameLocal(record: Readonly<Record<string, any>> | undefined, from: string, to: string): EditResult<Record<string, any>> {
  const current = record ?? {};
  if (!(from in current)) return fail('Variável não encontrada.');
  const error = validateVariableName(to, Object.keys(current).filter((k) => k !== from));
  if (error) return fail(error);
  if (to.trim() === from) return { ok: true, value: current as Record<string, any> };
  return { ok: true, value: Object.fromEntries(Object.entries(current).map(([k, v]) => [k === from ? to.trim() : k, v])) };
}

export function updateLocal(record: Readonly<Record<string, any>> | undefined, name: string, patch: { type?: VariableType; value?: unknown }): EditResult<Record<string, any>> {
  const current = record ?? {};
  if (!(name in current)) return fail('Variável não encontrada.');
  const type = patch.type ?? inferVariableType(current[name]);
  const value = 'value' in patch ? coerceVariableValue(type, patch.value) : convertToType(current[name], type);
  if (value === null) return fail(`O valor inicial não é ${type}.`);
  if (value === current[name]) return { ok: true, value: current as Record<string, any> };
  return { ok: true, value: { ...current, [name]: value } };
}

export function removeLocal(record: Readonly<Record<string, any>> | undefined, name: string): Record<string, any> {
  const { [name]: _gone, ...rest } = record ?? {};
  return rest;
}

// ── Consumidores e renomeação de referências ─────────────────────────────────────────────────────

export interface VariableConsumer {
  behaviorId: string;
  behaviorName: string;
  ruleId: string;
  /** 'trigger' | 'condition' | 'action' */
  part: 'trigger' | 'condition' | 'action';
  /** ID do tipo (`set_variable`, `variable_compare`…). */
  typeId: string;
  label: string;
}

interface RefSite {
  part: VariableConsumer['part'];
  typeId: string;
  label: string;
  parameters: Record<string, any>;
  variableKeys: string[];
}

/** Parâmetros que NOMEIAM uma variável (`variable: true` no descritor da pasta) — o catálogo é a fonte, sem lista paralela. */
const variableKeysOf = (params: readonly LogicParamDescriptor[]): string[] => params.filter((p) => p.variable).map((p) => p.key);

function sitesOf(rule: LogicEventRule): RefSite[] {
  const sites: RefSite[] = [];
  const trigger = LogicRegistry.getTrigger(rule.eventType);
  if (trigger) sites.push({ part: 'trigger', typeId: trigger.id, label: trigger.label, parameters: rule.parameters ?? {}, variableKeys: variableKeysOf(trigger.params) });
  for (const c of rule.conditions) {
    const def = LogicRegistry.getCondition(c.type);
    if (def) sites.push({ part: 'condition', typeId: def.id, label: def.label, parameters: c.parameters ?? {}, variableKeys: variableKeysOf(def.params) });
  }
  for (const a of rule.actions) {
    const def = LogicRegistry.getAction(a.type);
    if (def) sites.push({ part: 'action', typeId: def.id, label: def.label, parameters: a.parameters ?? {}, variableKeys: variableKeysOf(def.params) });
  }
  return sites;
}

/** O item usa a variável `(scope, name)`? Local: o alvo (vazio = nó dono) precisa ser o nó do escopo. */
function refersTo(parameters: Record<string, any>, key: string, scope: VariableScope, name: string, scopeNodeId: string | undefined, ownerNodeId: string | undefined, resolveNode?: (ref: string) => string | undefined): boolean {
  if (String(parameters[key] ?? '') !== name) return false;
  const itemScope: VariableScope = parameters.scope === 'local' ? 'local' : 'global';
  if (itemScope !== scope) return false;
  if (scope === 'global') return true;
  const target = String(parameters.target ?? '').trim();
  const nodeId = target ? resolveNode?.(target) ?? target : ownerNodeId;
  return nodeId === scopeNodeId;
}

/** Quem usa a variável (Actions, Conditions, Triggers). `scopeNodeId` só vale para `local`. */
export function findVariableConsumers(behaviors: readonly Behavior[], scope: VariableScope, name: string, scopeNodeId?: string, resolveNode?: (ref: string) => string | undefined): VariableConsumer[] {
  const out: VariableConsumer[] = [];
  for (const b of behaviors) {
    for (const rule of b.rules) {
      for (const site of sitesOf(rule)) {
        if (site.variableKeys.some((k) => refersTo(site.parameters, k, scope, name, scopeNodeId, b.targetNodeId, resolveNode))) {
          out.push({ behaviorId: b.id, behaviorName: b.name, ruleId: rule.id, part: site.part, typeId: site.typeId, label: site.label });
        }
      }
    }
  }
  return out;
}

/** Texto curto de um consumidor para a lista do aviso de exclusão. */
export const describeConsumer = (c: VariableConsumer): string => `${c.behaviorName} → ${c.part === 'trigger' ? 'Trigger' : c.part === 'condition' ? 'Condition' : 'Action'} ${c.label}`;

/** Troca o nome nas referências (imutável; itens sem referência mantêm a MESMA referência de objeto). */
export function renameVariableReferences(behaviors: readonly Behavior[], scope: VariableScope, from: string, to: string, scopeNodeId?: string, resolveNode?: (ref: string) => string | undefined): Behavior[] {
  const rewrite = <T extends { parameters: Record<string, any> }>(item: T, keys: string[], owner: string): T => {
    const hit = keys.filter((k) => refersTo(item.parameters ?? {}, k, scope, from, scopeNodeId, owner, resolveNode));
    if (hit.length === 0) return item;
    return { ...item, parameters: { ...item.parameters, ...Object.fromEntries(hit.map((k) => [k, to])) } };
  };
  return behaviors.map((b) => {
    let changed = false;
    const rules = b.rules.map((rule) => {
      const triggerKeys = variableKeysOf(LogicRegistry.getTrigger(rule.eventType)?.params ?? []);
      const asItem = rewrite({ parameters: rule.parameters ?? {} }, triggerKeys, b.targetNodeId);
      const conditions = rule.conditions.map((c) => rewrite(c, variableKeysOf(LogicRegistry.getCondition(c.type)?.params ?? []), b.targetNodeId));
      const actions = rule.actions.map((a) => rewrite(a, variableKeysOf(LogicRegistry.getAction(a.type)?.params ?? []), b.targetNodeId));
      const same = asItem.parameters === (rule.parameters ?? {}) && conditions.every((c, i) => c === rule.conditions[i]) && actions.every((a, i) => a === rule.actions[i]);
      if (same) return rule;
      changed = true;
      return { ...rule, parameters: asItem.parameters, conditions, actions };
    });
    return changed ? { ...b, rules } : b;
  });
}

// ── Runtime: sessão de variáveis ─────────────────────────────────────────────────────────────────

export interface VariableChange {
  scope: VariableScope;
  name: string;
  /** ID do nó dono (só `local`). */
  nodeId?: string;
  oldValue: VariableValue | undefined;
  newValue: VariableValue;
}
export type VariableListener = (change: VariableChange) => void;
export type Disposer = () => void;

export interface VariableSource {
  name: string;
  type?: unknown;
  value?: unknown;
}

/** Contexto de resolução de referências por NOME de nó (o runtime injeta). */
export interface VariableLookup {
  /** Nó dono da regra (alvo padrão de `$var$` local). */
  selfNodeId?: string;
  /** ID do nó por nome (ou ID). `undefined` = não existe. */
  resolveNodeId?(nameOrId: string): string | undefined;
}

export class VariableManager {
  private readonly globals = new Map<string, { type: VariableType; value: VariableValue }>();
  private readonly locals = new Map<string, Record<string, any>>();
  private readonly listeners = new Set<VariableListener>();

  /** `initial` = as globais do projeto: o valor inicial é copiado (o projeto autoral nunca é tocado). */
  constructor(initial: readonly VariableSource[] = []) {
    for (const v of initial) {
      if (!v?.name) continue;
      const type = isEditableType(v.type) ? v.type : inferVariableType(v.value);
      this.globals.set(v.name, { type, value: convertToType(v.value, type) });
    }
  }

  // — locais: o registro vivo é o da instância de runtime (`RuntimeInstance.variables`) —
  registerLocals(nodeId: string, record: Record<string, any>): void {
    this.locals.set(nodeId, record);
  }
  unregisterLocals(nodeId: string): void {
    this.locals.delete(nodeId);
  }

  // — API única —
  getVariable(scope: VariableScope, name: string, nodeId?: string): VariableValue | undefined {
    if (scope === 'global') return this.globals.get(name)?.value;
    const record = nodeId ? this.locals.get(nodeId) : undefined;
    if (!record || !(name in record)) return undefined;
    return record[name] as VariableValue;
  }

  /** `true` se gravou (ou se o valor já era esse); `false` se a variável não existe ou o valor não cabe no tipo. */
  setVariable(scope: VariableScope, name: string, value: unknown, nodeId?: string): boolean {
    if (scope === 'global') {
      const entry = this.globals.get(name);
      if (!entry) return false;
      const next = coerceVariableValue(entry.type, value);
      if (next === null) return false;
      if (next !== entry.value) {
        const oldValue = entry.value;
        entry.value = next;
        this.emit({ scope, name, oldValue, newValue: next });
      }
      return true;
    }
    const record = nodeId ? this.locals.get(nodeId) : undefined;
    if (!record || !(name in record)) return false;
    const next = coerceVariableValue(inferVariableType(record[name]), value);
    if (next === null) return false;
    if (next !== record[name]) {
      const oldValue = record[name] as VariableValue;
      record[name] = next;
      this.emit({ scope, name, nodeId, oldValue, newValue: next });
    }
    return true;
  }

  /** Soma (negativo subtrai). Só variáveis `number`; devolve o novo valor ou `undefined` se não aplicou. */
  addToVariable(scope: VariableScope, name: string, amount: number, nodeId?: string): number | undefined {
    const current = this.getVariable(scope, name, nodeId);
    if (typeof current !== 'number' || !Number.isFinite(amount)) return undefined;
    return this.setVariable(scope, name, current + amount, nodeId) ? current + amount : undefined;
  }

  // — barramento —
  onVariableChanged(listener: VariableListener): Disposer {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }
  private emit(change: VariableChange): void {
    for (const l of [...this.listeners]) {
      try {
        l(change);
      } catch {
        // um ouvinte com defeito não derruba os demais nem a mutação
      }
    }
  }

  // — leitura para painéis (Inspector/Debugger) —
  listGlobals(): LocalVariable[] {
    return [...this.globals].map(([name, v]) => ({ name, type: v.type, value: v.value }));
  }
  listLocals(nodeId: string): LocalVariable[] {
    return localEntries(this.locals.get(nodeId));
  }

  // — referências e texto —
  /** `#nome.atributo` → valor da Local `atributo` do nó chamado `nome`. `#system.*` é reservado (indefinido). */
  resolveReference(ref: string, lookup: VariableLookup = {}): VariableValue | undefined {
    const parsed = parseReference(ref);
    if (!parsed || parsed.node === 'system') return undefined;
    const nodeId = lookup.resolveNodeId ? lookup.resolveNodeId(parsed.node) : parsed.node;
    return nodeId ? this.getVariable('local', parsed.attribute, nodeId) : undefined;
  }

  /**
   * Substitui `$nome$` (Global, senão Local do nó dono) e `#nome.atributo` por seus valores. O que não resolve fica
   * como veio — nunca some em silêncio.
   */
  interpolate(text: string, lookup: VariableLookup = {}): string {
    const withVars = text.replace(/\$([A-Za-z_][A-Za-z0-9_]*)\$/g, (whole, name: string) => {
      const value = this.getVariable('global', name) ?? (lookup.selfNodeId ? this.getVariable('local', name, lookup.selfNodeId) : undefined);
      return value === undefined ? whole : String(value);
    });
    return withVars.replace(/#([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)/g, (whole) => {
      const value = this.resolveReference(whole, lookup);
      return value === undefined ? whole : String(value);
    });
  }

  dispose(): void {
    this.listeners.clear();
    this.locals.clear();
    this.globals.clear();
  }
}

/** `#enemy1.ammo` → `{ node: 'enemy1', attribute: 'ammo' }`. */
export function parseReference(ref: string): { node: string; attribute: string } | null {
  const m = /^#([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)$/.exec(ref.trim());
  return m ? { node: m[1], attribute: m[2] } : null;
}
