import { describe, expect, it } from 'vitest';
import { AuthoringModel } from '../authoring/AuthoringModel';
import { createEmptyScene } from '../defaultProject';
import { CommandManager } from '../commandManager';
import { createChangePropertyCommand } from './ChangePropertyCommand';
import { createSetTransformCommand, toSetTransformItem, type NodeTransform } from './SetTransformCommand';
import type { GameNode } from '../../types/node';
import type { ICommand } from '../../types/commands';

const node = (id: string, parentId: string | null, props: Record<string, any>): GameNode =>
  ({ id, name: id, type: 'MeshInstance', parentId, childrenIds: [], visible: true, locked: false, properties: props }) as GameNode;

function setup() {
  const scene = createEmptyScene();
  const root = scene.rootNodeId;
  scene.nodes = {
    [root]: { ...node(root, null, {}), type: 'Spatial', childrenIds: ['a', 'b'] } as GameNode,
    a: node('a', root, { roughness: 0.1, position: { x: 0, y: 0, z: 0 } }),
    b: node('b', root, { roughness: 0.5 }),
  };
  const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene);
  return { model, manager: new CommandManager() };
}
const rough = (m: AuthoringModel, id = 'a') => m.getScene().nodes[id].properties.roughness;

/** Simula um arrasto: N movimentos, cada um empurrando um Command de edição. */
function drag(model: AuthoringModel, manager: CommandManager, values: number[], id = 'a') {
  manager.beginGesture();
  for (const v of values) {
    const cmd = createChangePropertyCommand({ target: model, nodeId: id, changes: { roughness: v } });
    if (cmd) manager.pushCommand(cmd);
  }
  manager.endGesture();
}

describe('mescla por gesto (AIS-24)', () => {
  it('um arrasto com muitos movimentos = UMA entrada; Ctrl+Z volta ao valor inicial; Redo ao final', () => {
    const { model, manager } = setup();
    drag(model, manager, [0.2, 0.3, 0.4, 0.5, 0.6, 0.7]);
    expect(rough(model)).toBe(0.7); // prévia ao vivo: cada passo foi aplicado
    expect(manager.getHistory().length).toBe(1);
    manager.undo();
    expect(rough(model)).toBe(0.1);
    expect(manager.canUndo()).toBe(false);
    manager.redo();
    expect(rough(model)).toBe(0.7);
  });

  it('sem gesto aberto, cada edição continua sendo uma entrada (digitar + Enter)', () => {
    const { model, manager } = setup();
    for (const v of [0.2, 0.3]) manager.pushCommand(createChangePropertyCommand({ target: model, nodeId: 'a', changes: { roughness: v } })!);
    expect(manager.getHistory().length).toBe(2);
  });

  it('dois arrastos seguidos = duas entradas (cada gesto fecha a sua)', () => {
    const { model, manager } = setup();
    drag(model, manager, [0.2, 0.3]);
    drag(model, manager, [0.4, 0.5]);
    expect(manager.getHistory().length).toBe(2);
    manager.undo();
    expect(rough(model)).toBe(0.3);
    manager.undo();
    expect(rough(model)).toBe(0.1);
  });

  it('Commands com chaves diferentes (outro nó/propriedade) não se fundem dentro do mesmo gesto', () => {
    const { model, manager } = setup();
    manager.beginGesture();
    manager.pushCommand(createChangePropertyCommand({ target: model, nodeId: 'a', changes: { roughness: 0.2 } })!);
    manager.pushCommand(createChangePropertyCommand({ target: model, nodeId: 'b', changes: { roughness: 0.9 } })!);
    manager.endGesture();
    expect(manager.getHistory().length).toBe(2);
  });

  it('arrasto que termina no valor inicial ainda deixa uma entrada reversível (sem entrada vazia por movimento)', () => {
    const { model, manager } = setup();
    drag(model, manager, [0.4, 0.1]);
    expect(manager.getHistory().length).toBe(1);
    manager.undo();
    expect(rough(model)).toBe(0.1);
  });

  it('a mescla muda o checkpoint (dirty) e notifica a UI', () => {
    const { model, manager } = setup();
    let notified = 0;
    manager.subscribe(() => notified++);
    manager.beginGesture();
    manager.pushCommand(createChangePropertyCommand({ target: model, nodeId: 'a', changes: { roughness: 0.2 } })!);
    const t1 = manager.getCheckpointToken();
    manager.pushCommand(createChangePropertyCommand({ target: model, nodeId: 'a', changes: { roughness: 0.3 } })!);
    manager.endGesture();
    expect(manager.getCheckpointToken()).not.toBe(t1);
    expect(notified).toBeGreaterThanOrEqual(2);
  });

  it('Undo no meio do gesto fecha o gesto (não funde nada depois)', () => {
    const { model, manager } = setup();
    manager.beginGesture();
    manager.pushCommand(createChangePropertyCommand({ target: model, nodeId: 'a', changes: { roughness: 0.2 } })!);
    manager.undo();
    expect(manager.isInGesture()).toBe(false);
    manager.pushCommand(createChangePropertyCommand({ target: model, nodeId: 'a', changes: { roughness: 0.3 } })!);
    manager.pushCommand(createChangePropertyCommand({ target: model, nodeId: 'a', changes: { roughness: 0.4 } })!);
    expect(manager.getHistory().length).toBe(2);
  });

  it('o primeiro Command não é fundido com um Command anterior fora do gesto', () => {
    const { model, manager } = setup();
    manager.pushCommand(createChangePropertyCommand({ target: model, nodeId: 'a', changes: { roughness: 0.2 } })!);
    drag(model, manager, [0.3, 0.4]);
    expect(manager.getHistory().length).toBe(2);
    manager.undo();
    expect(rough(model)).toBe(0.2);
  });

  it('SetTransformCommand: arrastar um campo de Transform = uma entrada; Undo restaura a pose inicial', () => {
    const store: Record<string, NodeTransform> = {};
    const T = (x: number): NodeTransform => ({ position: { x, y: 0, z: 0 }, rotation: { x: 0, y: 0, z: 0 }, scale: { x: 1, y: 1, z: 1 } });
    store.a = T(0);
    const apply = (id: string, t: NodeTransform) => void (store[id] = t);
    const manager = new CommandManager();
    manager.beginGesture();
    let prev = 0;
    for (const x of [1, 2, 3, 4, 5]) {
      const cmd = createSetTransformCommand({ mode: 'translate', items: [toSetTransformItem('a', T(prev), T(x))], apply })!;
      manager.pushCommand(cmd);
      prev = x;
    }
    manager.endGesture();
    expect(store.a.position.x).toBe(5);
    expect(manager.getHistory().length).toBe(1);
    manager.undo();
    expect(store.a.position.x).toBe(0);
    manager.redo();
    expect(store.a.position.x).toBe(5);
  });

  it('modos diferentes (mover × girar) não se fundem', () => {
    const store: Record<string, NodeTransform> = { a: { position: { x: 0, y: 0, z: 0 }, rotation: { x: 0, y: 0, z: 0 }, scale: { x: 1, y: 1, z: 1 } } };
    const apply = (id: string, t: NodeTransform) => void (store[id] = t);
    const manager = new CommandManager();
    manager.beginGesture();
    const t0 = store.a;
    const moved: NodeTransform = { ...t0, position: { x: 1, y: 0, z: 0 } };
    const rotated: NodeTransform = { ...moved, rotation: { x: 0, y: 30, z: 0 } };
    manager.pushCommand(createSetTransformCommand({ mode: 'translate', items: [toSetTransformItem('a', t0, moved)], apply })!);
    manager.pushCommand(createSetTransformCommand({ mode: 'rotate', items: [toSetTransformItem('a', moved, rotated)], apply })!);
    manager.endGesture();
    expect(manager.getHistory().length).toBe(2);
  });

  it('campos diferentes mudando em cada movimento do gesto (arrastar overlay) continuam uma entrada; Undo restaura todos', () => {
    const { model, manager } = setup();
    model.updateNodeProperties('a', { posX: 20, posY: 20, width: 140, height: 48 });
    const before = structuredClone(model.getScene().nodes.a.properties);
    const push = (c: Record<string, number>) => manager.pushCommand(createChangePropertyCommand({ target: model, nodeId: 'a', changes: c })!);
    manager.beginGesture();
    push({ posX: 30, posY: 20, width: 140, height: 48 }); // só posX muda
    push({ posX: 40, posY: 25, width: 140, height: 48 }); // posX e posY
    push({ posX: 40, posY: 25, width: 160, height: 60 }); // agora width/height
    manager.endGesture();
    expect(manager.getHistory().length).toBe(1);
    expect(model.getScene().nodes.a.properties).toMatchObject({ posX: 40, posY: 25, width: 160, height: 60 });
    manager.undo();
    expect(model.getScene().nodes.a.properties).toEqual(before);
    manager.redo();
    expect(model.getScene().nodes.a.properties).toMatchObject({ posX: 40, posY: 25, width: 160, height: 60 });
  });
});
