import { describe, expect, it } from 'vitest';
import { AuthoringModel } from '../authoring/AuthoringModel';
import { createEmptyScene } from '../defaultProject';
import { CommandManager } from '../commandManager';
import {
  createChangePropertyCommand,
  deepEqual,
  getAtPath,
  setAtPath,
  unsetAtPath,
} from './ChangePropertyCommand';
import type { GameNode } from '../../types/node';

const makeNode = (id: string, parentId: string | null, type: string, properties: Record<string, any>): GameNode =>
  ({ id, name: `N_${id}`, type, parentId, childrenIds: [], visible: true, locked: false, properties }) as GameNode;

function setup() {
  const scene = createEmptyScene();
  const root = scene.rootNodeId;
  scene.nodes = {
    [root]: { ...makeNode(root, null, 'Spatial', {}), childrenIds: ['mesh', 'env'] },
    mesh: makeNode('mesh', root, 'MeshInstance', {
      materialColor: { r: 1, g: 0, b: 0, a: 1 },
      roughness: 0.4,
      physics: { mass: 2, shape: { kind: 'box', size: [1, 2, 3] } },
    }),
    env: makeNode('env', root, 'Environment', { ambientIntensity: 0.45, fogEnabled: false }),
  };
  scene.environmentNodeId = 'env';
  const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene);
  return { model, manager: new CommandManager() };
}
const props = (m: AuthoringModel, id: string) => m.getScene().nodes[id].properties;

describe('caminho de propriedade (puro)', () => {
  const obj = { a: 1, b: { c: [10, { d: 'x' }], e: null } };

  it('getAtPath distingue ausente de null/undefined/0', () => {
    expect(getAtPath(obj, 'a')).toEqual({ found: true, value: 1 });
    expect(getAtPath(obj, 'b.c.1.d')).toEqual({ found: true, value: 'x' });
    expect(getAtPath(obj, 'b.e')).toEqual({ found: true, value: null });
    expect(getAtPath(obj, 'b.z').found).toBe(false);
    expect(getAtPath(obj, 'a.b').found).toBe(false);
    expect(getAtPath(obj, '').found).toBe(false);
  });

  it('setAtPath é imutável e cria intermediários', () => {
    const next = setAtPath(obj, 'b.c.1.d', 'y');
    expect(getAtPath(next, 'b.c.1.d').value).toBe('y');
    expect(obj.b.c[1]).toEqual({ d: 'x' }); // original intacto
    expect(next.a).toBe(1);
    expect(setAtPath({}, 'physics.mass', 5)).toEqual({ physics: { mass: 5 } });
    expect(setAtPath({}, 'list.0', 'a')).toEqual({ list: ['a'] });
  });

  it('unsetAtPath remove só a chave pedida', () => {
    expect(unsetAtPath(obj, 'b.e')).toEqual({ a: 1, b: { c: [10, { d: 'x' }] } });
    expect(unsetAtPath(obj, 'a')).toEqual({ b: obj.b });
    expect(unsetAtPath(obj, 'nada.aqui')).toEqual(obj);
    expect(obj.b.e).toBeNull();
  });

  it('deepEqual compara estruturas', () => {
    expect(deepEqual({ a: [1, { b: 2 }] }, { a: [1, { b: 2 }] })).toBe(true);
    expect(deepEqual({ a: 1 }, { a: 1, b: undefined })).toBe(false);
    expect(deepEqual([1, 2], [1, 3])).toBe(false);
    expect(deepEqual(0, '0')).toBe(false);
  });
});

describe('ChangePropertyCommand', () => {
  it('propriedade plana: aplica, Undo restaura o valor prévio, Redo reaplica', () => {
    const { model, manager } = setup();
    manager.execute(createChangePropertyCommand({ target: model, nodeId: 'mesh', changes: { roughness: 0.9 } })!);
    expect(props(model, 'mesh').roughness).toBe(0.9);
    manager.undo();
    expect(props(model, 'mesh').roughness).toBe(0.4);
    manager.redo();
    expect(props(model, 'mesh').roughness).toBe(0.9);
  });

  it('caminho aninhado ("physics.mass"): muda só esse campo; os vizinhos não mudam', () => {
    const { model, manager } = setup();
    const before = structuredClone(props(model, 'mesh'));
    manager.execute(createChangePropertyCommand({ target: model, nodeId: 'mesh', changes: { 'physics.mass': 10 } })!);
    expect(props(model, 'mesh').physics).toEqual({ mass: 10, shape: before.physics.shape });
    expect(props(model, 'mesh').materialColor).toEqual(before.materialColor);
    manager.undo();
    expect(props(model, 'mesh')).toEqual(before);
  });

  it('cor (objeto) e índice de array por caminho', () => {
    const { model, manager } = setup();
    const before = structuredClone(props(model, 'mesh'));
    manager.execute(createChangePropertyCommand({ target: model, nodeId: 'mesh', changes: { materialColor: { r: 0, g: 1, b: 0, a: 1 } } })!);
    manager.execute(createChangePropertyCommand({ target: model, nodeId: 'mesh', changes: { 'physics.shape.size.1': 7 } })!);
    expect(props(model, 'mesh').physics.shape.size).toEqual([1, 7, 3]);
    manager.undo();
    manager.undo();
    expect(props(model, 'mesh')).toEqual(before);
  });

  it('propriedade que não existia: Undo a REMOVE (não deixa undefined nem valor padrão)', () => {
    const { model, manager } = setup();
    const before = structuredClone(props(model, 'mesh'));
    manager.execute(createChangePropertyCommand({ target: model, nodeId: 'mesh', changes: { castShadow: true, 'light.intensity': 3 } })!);
    expect(props(model, 'mesh').castShadow).toBe(true);
    expect(props(model, 'mesh').light).toEqual({ intensity: 3 });
    manager.undo();
    expect(Object.keys(props(model, 'mesh')).sort()).toEqual(Object.keys(before).sort());
    expect('castShadow' in props(model, 'mesh')).toBe(false);
    expect('light' in props(model, 'mesh')).toBe(false);
    manager.redo();
    expect(props(model, 'mesh').light).toEqual({ intensity: 3 });
  });

  it('várias propriedades = um Command (um Ctrl+Z)', () => {
    const { model, manager } = setup();
    const cmd = createChangePropertyCommand({ target: model, nodeId: 'mesh', changes: { roughness: 1, 'physics.mass': 4 } })!;
    expect((cmd as any).label).toBe('Change Properties (2)');
    manager.execute(cmd);
    expect(manager.getHistory().length).toBe(1);
    manager.undo();
    expect(props(model, 'mesh').roughness).toBe(0.4);
    expect(props(model, 'mesh').physics.mass).toBe(2);
  });

  it('valor igual ao atual, nó inexistente ou caminho vazio não geram Command', () => {
    const { model } = setup();
    expect(createChangePropertyCommand({ target: model, nodeId: 'mesh', changes: { roughness: 0.4 } })).toBeNull();
    expect(createChangePropertyCommand({ target: model, nodeId: 'mesh', changes: { 'physics.shape.size': [1, 2, 3] } })).toBeNull();
    expect(createChangePropertyCommand({ target: model, nodeId: 'nope', changes: { a: 1 } })).toBeNull();
    expect(createChangePropertyCommand({ target: model, nodeId: 'mesh', changes: { '': 1 } })).toBeNull();
  });

  it('o rótulo traz o caminho e os hooks de re-renderização rodam em execute e undo', () => {
    const { model } = setup();
    const calls: string[] = [];
    const cmd = createChangePropertyCommand({
      target: model,
      nodeId: 'mesh',
      changes: { 'physics.mass': 9 },
      afterExecute: () => calls.push('exec'),
      afterUndo: () => calls.push('undo'),
    })!;
    expect((cmd as any).label).toBe('Change physics.mass');
    cmd.execute();
    cmd.undo();
    cmd.execute();
    expect(calls).toEqual(['exec', 'undo', 'exec']);
  });

  it('Command não é afetado por mutações posteriores dos valores passados', () => {
    const { model, manager } = setup();
    const color = { r: 0, g: 0, b: 1, a: 1 };
    manager.execute(createChangePropertyCommand({ target: model, nodeId: 'mesh', changes: { materialColor: color } })!);
    color.b = 0; // mutação posterior no chamador
    manager.undo();
    manager.redo();
    expect(props(model, 'mesh').materialColor).toEqual({ r: 0, g: 0, b: 1, a: 1 });
  });

  it('Environment: Undo/Redo também sincronizam environment/fog derivados', () => {
    const { model, manager } = setup();
    manager.execute(createChangePropertyCommand({ target: model, nodeId: 'env', changes: { ambientIntensity: 0.9 } })!);
    expect(model.getScene().environment?.ambientIntensity).toBe(0.9);
    manager.undo();
    expect(model.getScene().environment?.ambientIntensity).toBe(0.45);
    manager.redo();
    expect(model.getScene().environment?.ambientIntensity).toBe(0.9);
  });
});
