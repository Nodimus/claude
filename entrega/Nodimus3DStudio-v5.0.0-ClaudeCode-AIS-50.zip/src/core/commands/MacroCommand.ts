import { getCommandLabel, type ICommand } from '../../types/commands';

/**
 * AIS-22 — MacroCommand (CompoundCommand): vários Commands numa única unidade atômica.
 *
 * - Execução sequencial; o histórico enxerga UMA entrada: um Ctrl+Z desfaz todos os micro-passos
 *   (em ordem inversa) e um Ctrl+Y os reaplica (em ordem).
 * - Consistência de estado: se um passo falhar, os passos já aplicados são desfeitos e o erro
 *   original é relançado — o macro nunca deixa o estado pela metade (vale para execute, undo e redo).
 * - Sem React/Zustand/Three; cada filho continua dono da sua própria mutação.
 */

type Phase = 'execute' | 'undo' | 'redo';

const labelOf = (c: ICommand) => getCommandLabel(c) || 'Command';

/** Aplica `phase` em cada filho; em falha desfaz o que já foi aplicado e relança o erro. */
function runAtomic(commands: readonly ICommand[], phase: Phase): void {
  const order = phase === 'undo' ? [...commands].reverse() : [...commands];
  const done: ICommand[] = [];
  for (const command of order) {
    try {
      if (phase === 'undo') command.undo();
      else if (phase === 'redo') (command.redo ?? command.execute)();
      else command.execute();
    } catch (error) {
      // reverte os passos já aplicados desta fase, no sentido contrário, ignorando falhas de rollback
      for (const applied of done.reverse()) {
        try {
          if (phase === 'undo') (applied.redo ?? applied.execute)();
          else applied.undo();
        } catch {
          /* o erro original é o que importa */
        }
      }
      throw error;
    }
    done.push(command);
  }
}

export class MacroCommand {
  public readonly label: string;
  public readonly commands: readonly ICommand[];
  public timestamp?: number;

  constructor(label: string, commands: readonly ICommand[]) {
    this.label = label;
    this.commands = [...commands];
  }

  execute = (): void => runAtomic(this.commands, 'execute');
  undo = (): void => runAtomic(this.commands, 'undo');
  redo = (): void => runAtomic(this.commands, 'redo');
}

/**
 * Agrupa Commands (ignora `null`/`undefined`, como os `create*Command` que devolvem `null` quando
 * nada muda). `null` quando não sobra nenhum — nada entra no histórico.
 */
export function createMacroCommand(label: string, commands: ReadonlyArray<ICommand | null | undefined>): MacroCommand | null {
  const list = commands.filter((c): c is ICommand => Boolean(c));
  return list.length === 0 ? null : new MacroCommand(label, list);
}

/** Descrição curta dos passos (depuração/UI): "Move Node → Scale Node". */
export function describeMacro(macro: MacroCommand): string {
  return macro.commands.map(labelOf).join(' → ');
}
