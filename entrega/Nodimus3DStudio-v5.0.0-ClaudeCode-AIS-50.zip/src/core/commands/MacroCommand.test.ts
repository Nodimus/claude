import { describe, expect, it } from 'vitest';
import { CommandManager } from '../commandManager';
import { createMacroCommand, describeMacro, MacroCommand } from './MacroCommand';
import { createSetTransformCommand, toSetTransformItem, type NodeTransform } from './SetTransformCommand';
import type { ICommand } from '../../types/commands';

/** Passo de teste: registra a ordem das chamadas num log compartilhado. */
const step = (name: string, log: string[], opts: { failOn?: 'execute' | 'undo' | 'redo' } = {}): ICommand => ({
  label: name,
  execute: () => {
    if (opts.failOn === 'execute') throw new Error(`${name} falhou`);
    log.push(`+${name}`);
  },
  undo: () => {
    if (opts.failOn === 'undo') throw new Error(`${name} falhou`);
    log.push(`-${name}`);
  },
  redo: () => {
    if (opts.failOn === 'redo') throw new Error(`${name} falhou`);
    log.push(`~${name}`);
  },
});

describe('MacroCommand', () => {
  it('executa em ordem; undo em ordem inversa; redo em ordem (usa o redo de cada filho)', () => {
    const log: string[] = [];
    const macro = new MacroCommand('Alinhar + Centralizar + Escalar', [step('A', log), step('B', log), step('C', log)]);
    macro.execute();
    expect(log).toEqual(['+A', '+B', '+C']);
    log.length = 0;
    macro.undo();
    expect(log).toEqual(['-C', '-B', '-A']);
    log.length = 0;
    macro.redo();
    expect(log).toEqual(['~A', '~B', '~C']);
  });

  it('um passo falha no execute: os anteriores são desfeitos e o erro original é relançado', () => {
    const log: string[] = [];
    const macro = new MacroCommand('M', [step('A', log), step('B', log), step('C', log, { failOn: 'execute' }), step('D', log)]);
    expect(() => macro.execute()).toThrow('C falhou');
    expect(log).toEqual(['+A', '+B', '-B', '-A']); // D nunca roda; estado volta ao início
  });

  it('falha no undo: os passos já desfeitos são reaplicados (estado consistente)', () => {
    const log: string[] = [];
    const macro = new MacroCommand('M', [step('A', log, { failOn: 'undo' }), step('B', log), step('C', log)]);
    macro.execute();
    log.length = 0;
    expect(() => macro.undo()).toThrow('A falhou');
    // C e B foram desfeitos, A falhou → B e C reaplicados na ordem original
    expect(log).toEqual(['-C', '-B', '~B', '~C']);
  });

  it('falha no redo: os já reaplicados são desfeitos', () => {
    const log: string[] = [];
    const macro = new MacroCommand('M', [step('A', log), step('B', log, { failOn: 'redo' })]);
    macro.execute();
    macro.undo();
    log.length = 0;
    expect(() => macro.redo()).toThrow('B falhou');
    expect(log).toEqual(['~A', '-A']);
  });

  it('createMacroCommand ignora null/undefined; vazio devolve null', () => {
    const log: string[] = [];
    expect(createMacroCommand('M', [null, undefined])).toBeNull();
    expect(createMacroCommand('M', [])).toBeNull();
    const macro = createMacroCommand('M', [step('A', log), null, step('B', log)])!;
    expect(macro.commands.length).toBe(2);
    expect(describeMacro(macro)).toBe('A → B');
  });

  it('um Ctrl+Z no CommandManager desfaz todos os micro-passos; Ctrl+Y reaplica', () => {
    const manager = new CommandManager();
    const state = { x: 0, y: 0, z: 0 };
    const set = (k: 'x' | 'y' | 'z', v: number): ICommand => {
      const prev = state[k];
      return { label: `Set ${k}`, execute: () => void (state[k] = v), undo: () => void (state[k] = prev) };
    };
    // os filhos capturam o valor anterior ao serem criados em sequência no execute do macro
    const macro = new MacroCommand('Compor', [set('x', 1), set('y', 2), set('z', 3)]);
    manager.execute(macro);
    expect(state).toEqual({ x: 1, y: 2, z: 3 });
    expect(manager.getHistory().length).toBe(1);
    expect(manager.getUndoLabel()).toBe('Compor');
    manager.undo();
    expect(state).toEqual({ x: 0, y: 0, z: 0 });
    manager.redo();
    expect(state).toEqual({ x: 1, y: 2, z: 3 });
  });

  it('compõe Commands reais do editor (SetTransform de vários nós + outro passo) em uma entrada', () => {
    const store: Record<string, NodeTransform> = {};
    const T = (x: number, s = 1): NodeTransform => ({
      position: { x, y: 0, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      scale: { x: s, y: s, z: s },
    });
    store.a = T(0);
    store.b = T(5);
    const apply = (id: string, t: NodeTransform) => void (store[id] = t);
    const align = createSetTransformCommand({ mode: 'translate', items: [toSetTransformItem('a', T(0), T(2)), toSetTransformItem('b', T(5), T(2))], apply });
    const scale = createSetTransformCommand({ mode: 'scale', items: [toSetTransformItem('a', T(2), T(2, 3))], apply });
    const none = createSetTransformCommand({ mode: 'scale', items: [toSetTransformItem('b', T(2), T(2))], apply }); // sem mudança: null
    // o segundo passo parte do estado produzido pelo primeiro
    const manager = new CommandManager();
    const macro = createMacroCommand('Alinhar e escalar', [align, scale, none])!;
    manager.execute(macro);
    expect(store.a.position.x).toBe(2);
    expect(store.a.scale.x).toBe(3);
    expect(store.b.position.x).toBe(2);
    manager.undo();
    expect(store.a).toEqual(T(0));
    expect(store.b).toEqual(T(5));
  });
});

describe('CommandManager — transações (AIS-22)', () => {
  const counterCmd = (label: string, state: { n: number }): ICommand => ({
    label,
    execute: () => void state.n++,
    undo: () => void state.n--,
  });

  it('tudo dentro de transaction() vira UMA entrada; Ctrl+Z desfaz o gesto composto inteiro', () => {
    const m = new CommandManager();
    const state = { n: 0 };
    m.transaction('Gerar terreno', () => {
      for (let i = 0; i < 9; i++) m.pushCommand(counterCmd(`Add ${i}`, state));
    });
    expect(state.n).toBe(9);
    expect(m.getHistory().map((h) => h.label)).toEqual(['Gerar terreno']);
    m.undo();
    expect(state.n).toBe(0);
    m.redo();
    expect(state.n).toBe(9);
  });

  it('Commands aplicam imediatamente dentro da transação, mas o histórico só muda no commit', () => {
    const m = new CommandManager();
    const state = { n: 0 };
    m.beginTransaction('T');
    m.pushCommand(counterCmd('A', state));
    expect(state.n).toBe(1);
    expect(m.canUndo()).toBe(false);
    expect(m.isInTransaction()).toBe(true);
    m.undo(); // histórico congelado durante a transação
    expect(state.n).toBe(1);
    m.commitTransaction();
    expect(m.getHistory().length).toBe(1);
    expect(m.isInTransaction()).toBe(false);
  });

  it('erro dentro da transação reverte o que foi aplicado e não registra nada', () => {
    const m = new CommandManager();
    const state = { n: 0 };
    expect(() =>
      m.transaction('T', () => {
        m.pushCommand(counterCmd('A', state));
        m.pushCommand(counterCmd('B', state));
        throw new Error('quebrou');
      })
    ).toThrow('quebrou');
    expect(state.n).toBe(0);
    expect(m.canUndo()).toBe(false);
    expect(m.isInTransaction()).toBe(false);
  });

  it('rollbackTransaction desfaz em ordem inversa e não registra', () => {
    const m = new CommandManager();
    const log: string[] = [];
    m.beginTransaction('T');
    m.pushCommand(step('A', log));
    m.pushCommand(step('B', log));
    m.rollbackTransaction();
    expect(log).toEqual(['+A', '+B', '-B', '-A']);
    expect(m.canUndo()).toBe(false);
  });

  it('transação vazia não entra no histórico; transações aninhadas viram uma só entrada', () => {
    const m = new CommandManager();
    const state = { n: 0 };
    m.transaction('Vazia', () => undefined);
    expect(m.canUndo()).toBe(false);

    m.transaction('Externa', () => {
      m.pushCommand(counterCmd('A', state));
      m.transaction('Interna', () => {
        m.pushCommand(counterCmd('B', state));
        m.pushCommand(counterCmd('C', state));
      });
      m.pushCommand(counterCmd('D', state));
    });
    expect(state.n).toBe(4);
    expect(m.getHistory().map((h) => h.label)).toEqual(['Externa']);
    m.undo();
    expect(state.n).toBe(0);
  });

  it('transaction devolve o resultado de fn e o checkpoint (dirty) muda uma vez', () => {
    const m = new CommandManager();
    const state = { n: 0 };
    const before = m.getCheckpointToken();
    const result = m.transaction('T', () => {
      m.pushCommand(counterCmd('A', state));
      m.pushCommand(counterCmd('B', state));
      return 42;
    });
    expect(result).toBe(42);
    const after = m.getCheckpointToken();
    expect(after).not.toBe(before);
    m.undo();
    expect(m.getCheckpointToken()).toBe(before); // volta ao checkpoint limpo
  });

  it('assinantes são notificados só no commit (não a cada micro-passo)', () => {
    const m = new CommandManager();
    const state = { n: 0 };
    let notified = 0;
    m.subscribe(() => notified++);
    m.transaction('T', () => {
      m.pushCommand(counterCmd('A', state));
      m.pushCommand(counterCmd('B', state));
    });
    expect(notified).toBe(1);
  });
});
