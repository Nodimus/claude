import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import { AuthoringModel } from '../authoring/AuthoringModel';
import { createEmptyScene } from '../defaultProject';
import { CommandManager } from '../commandManager';
import { getWorldMatrix, readLocalTransform } from '../authoring/reparentMath';
import { createAddNodeCommand, createDeleteNodeCommand, createReparentNodeCommand } from './SceneTreeCommands';
import type { GameNode } from '../../types/node';

const node = (id: string, parentId: string | null, childrenIds: string[] = [], props: Record<string, any> = {}, type = 'Spatial'): GameNode =>
  ({ id, name: `N_${id}`, type, parentId, childrenIds, visible: true, locked: false, properties: props }) as GameNode;
const P = (x: number, y = 0, z = 0) => ({ x, y, z });

function setup() {
  const scene = createEmptyScene();
  const root = scene.rootNodeId;
  scene.nodes = {
    [root]: node(root, null, ['a', 'b', 'c']),
    a: node('a', root, [], { position: P(1, 2, 3) }),
    b: node('b', root, ['b1', 'b2'], { position: P(10), scale: P(2, 2, 2), rotation: P(0, 90, 0) }),
    b1: node('b1', 'b', [], { position: P(1), custom: { deep: [1, 2] } }),
    b2: node('b2', 'b', ['b2x'], { position: P(0, 5) }),
    b2x: node('b2x', 'b2', [], {}),
    c: node('c', root, []),
  };
  const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene);
  return { model, root, manager: new CommandManager() };
}
const snap = (m: AuthoringModel) => structuredClone(m.getScene().nodes);
/** Estrutura + transform local normalizado (chave ausente == padrão): compara a pose, não o formato. */
const shape = (m: AuthoringModel) =>
  Object.fromEntries(
    Object.entries(m.getScene().nodes).map(([id, n]) => [
      id,
      { parentId: n.parentId, childrenIds: n.childrenIds, local: readLocalTransform(n.properties) },
    ])
  );

describe('AddNodeCommand', () => {
  it('adiciona na hierarquia; Undo remove; Redo reinsere o MESMO id', () => {
    const { model, root, manager } = setup();
    const added = node('new1', null, [], { x: 1 }, 'Node');
    manager.execute(createAddNodeCommand({ target: model, node: added, parentId: 'a' }));
    expect(model.getScene().nodes.new1.parentId).toBe('a');
    expect(model.getScene().nodes.a.childrenIds).toEqual(['new1']);

    manager.undo();
    expect(model.getScene().nodes.new1).toBeUndefined();
    expect(model.getScene().nodes.a.childrenIds).toEqual([]);

    manager.redo();
    expect(Object.keys(model.getScene().nodes)).toContain('new1');
    expect(model.getScene().nodes.new1.properties).toEqual({ x: 1 });
    expect(model.getScene().nodes[root].childrenIds).toEqual(['a', 'b', 'c']);
  });

  it('o rótulo e os hooks de UI são chamados na ordem certa', () => {
    const { model } = setup();
    const calls: string[] = [];
    const cmd = createAddNodeCommand({
      target: model,
      node: node('n', null),
      parentId: 'c',
      afterExecute: () => calls.push('exec'),
      afterUndo: () => calls.push('undo'),
    });
    expect((cmd as any).label).toBe('Add Node N_n');
    cmd.execute();
    cmd.undo();
    expect(calls).toEqual(['exec', 'undo']);
  });
});

describe('DeleteNodeCommand', () => {
  it('remove a subárvore; Undo restaura ids, filhos, propriedades e posição entre irmãos', () => {
    const { model, manager } = setup();
    const before = snap(model);
    manager.execute(createDeleteNodeCommand({ target: model, nodeIds: ['b'] })!);
    for (const id of ['b', 'b1', 'b2', 'b2x']) expect(model.getScene().nodes[id]).toBeUndefined();

    manager.undo();
    expect(snap(model)).toEqual(before); // mesmos ids, ordem de irmãos e dados
    expect(model.getScene().nodes.b1.properties.custom).toEqual({ deep: [1, 2] });
  });

  it('Redo apaga de novo; Undo/Redo repetidos são estáveis', () => {
    const { model, manager } = setup();
    const before = snap(model);
    manager.execute(createDeleteNodeCommand({ target: model, nodeIds: ['b'] })!);
    const afterDelete = snap(model);
    manager.undo();
    manager.redo();
    expect(snap(model)).toEqual(afterDelete);
    manager.undo();
    expect(snap(model)).toEqual(before);
  });

  it('seleção múltipla = um único Command; aninhados saem com o ancestral; raiz nunca', () => {
    const { model, root, manager } = setup();
    const before = snap(model);
    const cmd = createDeleteNodeCommand({ target: model, nodeIds: ['a', 'b', 'b1', root, 'c'] })!;
    expect((cmd as any).label).toBe('Delete Nodes (3)');
    manager.execute(cmd);
    expect(Object.keys(model.getScene().nodes)).toEqual([root]);
    expect(manager.getHistory().length).toBe(1);
    manager.undo();
    expect(snap(model)).toEqual(before);
  });

  it('nada excluível (só a raiz / ids inexistentes) retorna null', () => {
    const { model, root } = setup();
    expect(createDeleteNodeCommand({ target: model, nodeIds: [root] })).toBeNull();
    expect(createDeleteNodeCommand({ target: model, nodeIds: ['nope'] })).toBeNull();
  });

  it('o backup não é afetado por mutações posteriores do estado', () => {
    const { model, manager } = setup();
    manager.execute(createDeleteNodeCommand({ target: model, nodeIds: ['b1'] })!);
    model.updateNodeProperties('a', { position: P(99) });
    manager.undo();
    expect(model.getScene().nodes.b1.properties.position).toEqual(P(1));
    expect(model.getScene().nodes.a.properties.position).toEqual(P(99));
  });

  it('Environment: Undo restaura o environmentNodeId', () => {
    const { model, root, manager } = setup();
    model.addNode(node('env', null, [], {}, 'Environment'), root);
    expect(model.getScene().environmentNodeId).toBe('env');
    manager.execute(createDeleteNodeCommand({ target: model, nodeIds: ['env'] })!);
    expect(model.getScene().environmentNodeId).toBeNull();
    manager.undo();
    expect(model.getScene().environmentNodeId).toBe('env');
  });
});

describe('ReparentNodeCommand', () => {
  const worldPos = (m: AuthoringModel, id: string) =>
    new THREE.Vector3().setFromMatrixPosition(getWorldMatrix(m.getScene(), id));

  it('muda o parentId preservando a pose mundial; Undo restaura pai, índice e transform local', () => {
    const { model, manager } = setup();
    const worldBefore = getWorldMatrix(model.getScene(), 'b1').clone();
    const before = shape(model);

    manager.execute(createReparentNodeCommand({ target: model, nodeId: 'b1', newParentId: 'a' })!);
    const moved = model.getScene().nodes;
    expect(moved.b1.parentId).toBe('a');
    expect(moved.a.childrenIds).toEqual(['b1']);
    expect(moved.b.childrenIds).toEqual(['b2']);
    // pose mundial preservada
    const worldAfter = getWorldMatrix(model.getScene(), 'b1');
    worldAfter.elements.forEach((v, i) => expect(v).toBeCloseTo(worldBefore.elements[i], 5));

    manager.undo();
    expect(shape(model)).toEqual(before);
    manager.redo();
    expect(model.getScene().nodes.b1.parentId).toBe('a');
    expect(worldPos(model, 'b1').x).toBeCloseTo(worldBefore.elements[12], 5);
  });

  it('reordenar entre irmãos não altera o transform; Undo volta a ordem', () => {
    const { model, root, manager } = setup();
    const before = snap(model);
    manager.execute(createReparentNodeCommand({ target: model, nodeId: 'c', newParentId: root, targetIndex: 0 })!);
    expect(model.getScene().nodes[root].childrenIds).toEqual(['c', 'a', 'b']);
    expect(model.getScene().nodes.c.properties).toEqual(before.c.properties);
    manager.undo();
    expect(snap(model)).toEqual(before);
  });

  it('movimentos inválidos retornam null (ciclo, raiz, no-op, nó inexistente)', () => {
    const { model, root } = setup();
    expect(createReparentNodeCommand({ target: model, nodeId: 'b', newParentId: 'b2x' })).toBeNull(); // ciclo
    expect(createReparentNodeCommand({ target: model, nodeId: 'b', newParentId: 'b' })).toBeNull();
    expect(createReparentNodeCommand({ target: model, nodeId: root, newParentId: 'a' })).toBeNull();
    expect(createReparentNodeCommand({ target: model, nodeId: 'c', newParentId: root })).toBeNull(); // já é o último
    expect(createReparentNodeCommand({ target: model, nodeId: 'nope', newParentId: 'a' })).toBeNull();
  });
});

describe('ReparentNodeCommand — nós de UI (AIS-25c)', () => {
  it('mover um controle entre Containers não escreve pose 3D e mantém as props de layout; Undo/Redo restauram pai e índice', () => {
    const scene = createEmptyScene();
    const root = scene.rootNodeId;
    const layout = { sizeFlagsH: 'expand-fill', sizeFlagsV: 'shrink-center', stretchRatio: 3, minSize: { x: 10, y: 20 } };
    scene.nodes = {
      [root]: node(root, null, ['hb', 'vb']),
      hb: node('hb', root, ['btn', 'lbl'], { separation: 4 }, 'HBox'),
      btn: node('btn', 'hb', [], { text: 'OK', ...layout }, 'ButtonOverlay2D'),
      lbl: node('lbl', 'hb', [], { text: 'x' }, 'TextOverlay2D'),
      vb: node('vb', root, [], { separation: 8 }, 'VBox'),
    };
    const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene);
    const manager = new CommandManager();
    const before = structuredClone(model.getScene().nodes);

    manager.execute(createReparentNodeCommand({ target: model, nodeId: 'btn', newParentId: 'vb' })!);
    const moved = model.getScene().nodes;
    expect(moved.btn.parentId).toBe('vb');
    expect(moved.vb.childrenIds).toEqual(['btn']);
    expect(moved.hb.childrenIds).toEqual(['lbl']);
    expect(moved.btn.properties).toEqual(before.btn.properties); // sem position/rotation/scale, layout intacto
    expect(moved.btn.properties.position).toBeUndefined();

    manager.undo();
    expect(model.getScene().nodes).toEqual(before);
    manager.redo();
    expect(model.getScene().nodes.btn.parentId).toBe('vb');
    expect(model.getScene().nodes.btn.properties).toEqual(before.btn.properties);
  });

  it('reordenar dentro do mesmo Container muda a ordem (e portanto o layout)', () => {
    const scene = createEmptyScene();
    const root = scene.rootNodeId;
    scene.nodes = {
      [root]: node(root, null, ['hb']),
      hb: node('hb', root, ['a', 'b'], {}, 'HBox'),
      a: node('a', 'hb', [], {}, 'Overlay2D'),
      b: node('b', 'hb', [], {}, 'Overlay2D'),
    };
    const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene);
    const manager = new CommandManager();
    manager.execute(createReparentNodeCommand({ target: model, nodeId: 'b', newParentId: 'hb', targetIndex: 0 })!);
    expect(model.getScene().nodes.hb.childrenIds).toEqual(['b', 'a']);
    manager.undo();
    expect(model.getScene().nodes.hb.childrenIds).toEqual(['a', 'b']);
  });
});
