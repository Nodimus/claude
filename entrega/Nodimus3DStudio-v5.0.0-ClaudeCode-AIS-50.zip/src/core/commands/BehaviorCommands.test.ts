import { describe, expect, it } from 'vitest';
import { CommandManager } from '../commandManager';
import { LogicRegistry } from '../../logic/registry';
import type { Behavior } from '../../types/visualLogic';
import { cloneBehavior, createBehaviorOps, defaultParameters, type BehaviorStore } from './BehaviorCommands';

const make = (id: string, over: Partial<Behavior> = {}): Behavior => ({
  id,
  name: `B_${id}`,
  targetNodeId: 'PlayerMesh',
  behaviorType: 'custom_rules',
  enabled: true,
  properties: { speed: 2 },
  rules: [
    {
      id: `r_${id}`,
      eventType: 'on_update',
      parameters: { k: 1 },
      conditions: [{ id: 'c1', type: 'always', parameters: {} }],
      actions: [
        { id: 'a1', type: 'print_log', parameters: { text: 'um' } },
        { id: 'a2', type: 'move_by', parameters: { dx: 1, dz: 0 } },
        { id: 'a3', type: 'rotate_by', parameters: { degrees: 5 } },
      ],
    },
  ],
  ...over,
});

function setup(initial: Behavior[] = [make('x'), make('y')]) {
  let list: Behavior[] = initial;
  const store: BehaviorStore = { get: () => list, set: (next) => void (list = next) };
  const manager = new CommandManager();
  const ops = createBehaviorOps(store, (c) => manager.execute(c));
  return { store, manager, ops, get: () => list, snapshot: () => structuredClone(list) };
}
const actionIds = (b: Behavior) => b.rules[0].actions.map((a) => a.id);

describe('AIS-39 — CRUD de Behavior com Undo (C06, C07, C10)', () => {
  it('adicionar insere o Behavior e Undo o remove; Redo reinsere', () => {
    const t = setup();
    const created = LogicRegistry.getBehavior('click_detector')!.create({ targetNodeId: 'Cube' });
    t.ops.add(created);
    expect(t.get().map((b) => b.id)).toEqual(['x', 'y', created.id]);
    t.manager.undo();
    expect(t.get().map((b) => b.id)).toEqual(['x', 'y']);
    t.manager.redo();
    expect(t.get().at(-1)).toEqual(created);
  });

  it('adicionar o mesmo ID duas vezes não duplica nem suja o histórico', () => {
    const t = setup();
    t.ops.add(make('x'));
    expect(t.get()).toHaveLength(2);
    expect(t.manager.canUndo()).toBe(false);
  });

  it('remover e Undo restauram o Behavior na MESMA posição, com parâmetros e Actions', () => {
    const t = setup([make('a'), make('b'), make('c')]);
    const before = t.snapshot();
    t.ops.remove('b');
    expect(t.get().map((b) => b.id)).toEqual(['a', 'c']);
    t.manager.undo();
    expect(t.get()).toEqual(before);
    t.manager.redo();
    expect(t.get().map((b) => b.id)).toEqual(['a', 'c']);
  });

  it('renomear é Command (Undo devolve o nome); renomear para o mesmo nome não registra nada', () => {
    const t = setup();
    t.ops.rename('x', 'Novo nome');
    expect(t.get()[0].name).toBe('Novo nome');
    t.manager.undo();
    expect(t.get()[0].name).toBe('B_x');
    t.ops.rename('x', 'B_x');
    expect(t.manager.canUndo()).toBe(false);
  });

  it('duplicar cria cópia ao lado com IDs novos em tudo e os mesmos parâmetros; Undo remove só a cópia', () => {
    const t = setup([make('a'), make('b')]);
    const copyId = t.ops.duplicate('a')!;
    const [orig, copy, other] = t.get();
    expect(t.get().map((b) => b.id)).toEqual(['a', copyId, 'b']);
    expect(copy.name).toBe('B_a (cópia)');
    expect(copy.properties).toEqual(orig.properties);
    expect(copy.rules[0].id).not.toBe(orig.rules[0].id);
    expect(copy.rules[0].actions.map((a) => a.id).some((id) => orig.rules[0].actions.some((o) => o.id === id))).toBe(false);
    expect(copy.rules[0].actions.map((a) => [a.type, a.parameters])).toEqual(orig.rules[0].actions.map((a) => [a.type, a.parameters]));
    expect(other.id).toBe('b');
    // a cópia é profunda: editar a cópia não mexe no original
    t.ops.setActionParam(copyId, copy.rules[0].id, copy.rules[0].actions[0].id, 'text', 'mudou');
    expect(t.get()[0].rules[0].actions[0].parameters.text).toBe('um');
    t.manager.undo();
    t.manager.undo();
    expect(t.get().map((b) => b.id)).toEqual(['a', 'b']);
  });

  it('ativar/desativar e propriedades do Behavior têm Undo', () => {
    const t = setup();
    t.ops.setEnabled('x', false);
    t.ops.setProperty('x', 'speed', 9);
    expect(t.get()[0]).toMatchObject({ enabled: false, properties: { speed: 9 } });
    t.manager.undo();
    t.manager.undo();
    expect(t.get()[0]).toMatchObject({ enabled: true, properties: { speed: 2 } });
  });
});

describe('AIS-39 — Trigger e Conditions (C08, C09)', () => {
  it('trocar o trigger guarda o ID novo e Undo restaura o anterior; trigger desconhecido é aceito como veio', () => {
    const t = setup();
    t.ops.setTrigger('x', 'r_x', 'on_click');
    expect(t.get()[0].rules[0].eventType).toBe('on_click');
    expect(t.get()[0].rules[0].parameters).toEqual({ k: 1 });
    t.manager.undo();
    expect(t.get()[0].rules[0].eventType).toBe('on_update');
    t.ops.setTrigger('x', 'r_x', 'on_update'); // mesmo trigger: nada
    expect(t.manager.canUndo()).toBe(false);
  });

  it('adicionar condition (parâmetros padrão da pasta) e remover; Undo para ambos', () => {
    const t = setup();
    t.ops.addCondition('x', 'r_x', 'key_down');
    const conds = t.get()[0].rules[0].conditions;
    expect(conds.map((c) => c.type)).toEqual(['always', 'key_down']);
    expect(conds[1].id).not.toBe('c1');
    t.ops.removeCondition('x', 'r_x', conds[1].id);
    expect(t.get()[0].rules[0].conditions.map((c) => c.type)).toEqual(['always']);
    t.manager.undo();
    expect(t.get()[0].rules[0].conditions.map((c) => c.type)).toEqual(['always', 'key_down']);
    t.manager.undo();
    expect(t.get()[0].rules[0].conditions.map((c) => c.type)).toEqual(['always']);
  });

  it('remover uma condition que não existe não registra nada', () => {
    const t = setup();
    t.ops.removeCondition('x', 'r_x', 'nao_existe');
    expect(t.manager.canUndo()).toBe(false);
  });
});

describe('AIS-39 — lista de Actions (reordenar, remover, editar)', () => {
  it('reordenar move a Action; Undo e Redo repetem; índices inválidos ou iguais não registram', () => {
    const t = setup();
    t.ops.reorderActions('x', 'r_x', 0, 2);
    expect(actionIds(t.get()[0])).toEqual(['a2', 'a3', 'a1']);
    t.manager.undo();
    expect(actionIds(t.get()[0])).toEqual(['a1', 'a2', 'a3']);
    t.manager.redo();
    expect(actionIds(t.get()[0])).toEqual(['a2', 'a3', 'a1']);
    const depth = [t.manager.canUndo()];
    t.ops.reorderActions('x', 'r_x', 1, 1);
    t.ops.reorderActions('x', 'r_x', 0, 9);
    t.ops.reorderActions('x', 'r_x', -1, 0);
    expect(depth).toEqual([true]);
    t.manager.undo();
    t.manager.undo();
    expect(t.manager.canUndo()).toBe(false); // só havia uma entrada
  });

  it('remover Action e Undo devolvem na mesma posição', () => {
    const t = setup();
    t.ops.removeAction('x', 'r_x', 'a2');
    expect(actionIds(t.get()[0])).toEqual(['a1', 'a3']);
    t.manager.undo();
    expect(actionIds(t.get()[0])).toEqual(['a1', 'a2', 'a3']);
  });

  it('adicionar Action usa o quickAdd/padrões da pasta; ID desconhecido entra sem parâmetros inventados', () => {
    const t = setup();
    t.ops.addAction('x', 'r_x', 'move_by');
    const added = t.get()[0].rules[0].actions.at(-1)!;
    expect(added).toMatchObject({ type: 'move_by', parameters: { dx: 1, dz: 0 } });
    t.ops.addAction('x', 'r_x', 'acao_de_outra_versao');
    expect(t.get()[0].rules[0].actions.at(-1)).toMatchObject({ type: 'acao_de_outra_versao', parameters: {} });
    t.manager.undo();
    t.manager.undo();
    expect(actionIds(t.get()[0])).toEqual(['a1', 'a2', 'a3']);
  });

  it('editar parâmetro: Undo restaura; mesmo valor não registra; Action desconhecida mantém seus parâmetros ao reordenar', () => {
    const odd = make('z');
    odd.rules[0].actions.push({ id: 'a_odd', type: 'acao_desconhecida', parameters: { segredo: [1, { a: 2 }] } });
    const t = setup([odd]);
    t.ops.setActionParam('z', 'r_z', 'a1', 'text', 'dois');
    expect(t.get()[0].rules[0].actions[0].parameters.text).toBe('dois');
    t.manager.undo();
    expect(t.get()[0].rules[0].actions[0].parameters.text).toBe('um');
    t.ops.setActionParam('z', 'r_z', 'a1', 'text', 'um');
    expect(t.manager.canUndo()).toBe(false);
    t.ops.reorderActions('z', 'r_z', 3, 0);
    expect(t.get()[0].rules[0].actions[0]).toEqual({ id: 'a_odd', type: 'acao_desconhecida', parameters: { segredo: [1, { a: 2 }] } });
  });

  it('uma sequência longa de operações é desfeita inteira, na ordem inversa, até o estado inicial', () => {
    const t = setup();
    const start = t.snapshot();
    t.ops.rename('x', 'Z');
    t.ops.addAction('x', 'r_x', 'play_sound');
    t.ops.reorderActions('x', 'r_x', 3, 0);
    t.ops.removeAction('x', 'r_x', 'a1');
    t.ops.setTrigger('x', 'r_x', 'on_click');
    t.ops.addCondition('x', 'r_x', 'node_exists');
    t.ops.duplicate('x');
    t.ops.remove('y');
    while (t.manager.canUndo()) t.manager.undo();
    expect(t.get()).toEqual(start);
  });
});

describe('AIS-39 — suporte', () => {
  it('defaultParameters usa o quickAdd quando existe, senão os padrões não vazios', () => {
    expect(defaultParameters([{ key: 'a', label: 'a', type: 'number', default: 3 }, { key: 'b', label: 'b', type: 'string', default: '' }])).toEqual({ a: 3 });
    expect(defaultParameters([], { x: 1 })).toEqual({ x: 1 });
  });
  it('cloneBehavior nunca repete IDs de regra, condição ou ação', () => {
    const src = make('s');
    const copy = cloneBehavior(src);
    const ids = (b: Behavior) => [b.id, ...b.rules.flatMap((r) => [r.id, ...r.conditions.map((c) => c.id), ...r.actions.map((a) => a.id)])];
    expect(ids(copy).filter((id) => ids(src).includes(id))).toEqual([]);
  });
});
