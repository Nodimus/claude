/**
 * AIS-39 — Commands do Visual Logic: adicionar/remover/renomear/duplicar Behavior, trocar Trigger, adicionar/remover
 * Condition e adicionar/remover/reordenar/editar Action. Toda mutação autoral do editor de lógica passa por aqui (com Undo);
 * o Visual Logic Editor e os cards do Inspector chamam as MESMAS operações (`createBehaviorOps`) — nenhuma lógica de CRUD paralela.
 *
 * Os Behaviors ainda vivem na lista global do `EditorContext` (a migração para `GameNode.behaviors` é o AIS-41b): por isso os
 * Commands falam com uma PORTA (`BehaviorStore`) em vez de um modelo concreto; o AIS-41b troca só o adaptador. Estado imutável:
 * cada Command guarda a lista anterior e a nova (referências), então Undo/Redo são exatos mesmo para uma cadeia longa.
 * ID desconhecido (trigger/condition/action fora do `LogicRegistry`) é preservado como veio.
 */
import type { ICommand } from '../../types/commands';
import type { Behavior, LogicAction, LogicCondition, LogicEventRule } from '../../types/visualLogic';
import { LogicRegistry } from '../../logic/registry';
import { newLogicId, type LogicParamDescriptor } from '../../logic/types';

/** Porta de armazenamento da lista de Behaviors (hoje o estado do EditorContext). */
export interface BehaviorStore {
  get(): readonly Behavior[];
  set(next: Behavior[]): void;
}

type Mutator = (list: readonly Behavior[]) => Behavior[];

/** Command por substituição da lista (imutável): `null` se a operação não muda nada (nenhuma entrada vazia no histórico). */
function listCommand(store: BehaviorStore, label: string, mutate: Mutator, extra: Partial<Pick<ICommand, 'mergeKey'>> = {}): ICommand | null {
  const prev = store.get();
  const next = mutate(prev);
  if (next === prev || (next.length === prev.length && next.every((b, i) => b === prev[i]))) return null;
  return {
    label,
    ...extra,
    execute: () => store.set(next),
    undo: () => store.set([...prev]),
    redo: () => store.set(next),
  } as ICommand;
}

const replaceBehavior = (list: readonly Behavior[], id: string, fn: (b: Behavior) => Behavior): Behavior[] => {
  const index = list.findIndex((b) => b.id === id);
  if (index < 0) return list as Behavior[];
  const next = fn(list[index]);
  if (next === list[index]) return list as Behavior[];
  const out = [...list];
  out[index] = next;
  return out;
};

const replaceRule = (b: Behavior, ruleId: string, fn: (r: LogicEventRule) => LogicEventRule): Behavior => {
  const index = b.rules.findIndex((r) => r.id === ruleId);
  if (index < 0) return b;
  const next = fn(b.rules[index]);
  if (next === b.rules[index]) return b;
  const rules = [...b.rules];
  rules[index] = next;
  return { ...b, rules };
};

/** Parâmetros iniciais de um item novo: o `quickAdd` da pasta (se houver) ou o `default` de cada parâmetro. */
export function defaultParameters(params: readonly LogicParamDescriptor[], quick?: Record<string, unknown>): Record<string, any> {
  if (quick) return { ...quick };
  const out: Record<string, any> = {};
  for (const p of params) if (p.default !== undefined && p.default !== '') out[p.key] = p.default;
  return out;
}

/** Cópia com IDs novos (Behavior, regras, condições e ações), mantendo parâmetros e IDs de tipo. */
export function cloneBehavior(source: Behavior, name = `${source.name} (cópia)`): Behavior {
  return {
    ...structuredClone(source),
    id: newLogicId('beh_'),
    name,
    rules: source.rules.map((rule) => ({
      ...structuredClone(rule),
      id: newLogicId('r_', 5),
      conditions: rule.conditions.map((c) => ({ ...structuredClone(c), id: newLogicId('c_', 5) })),
      actions: rule.actions.map((a) => ({ ...structuredClone(a), id: newLogicId('act_', 5) })),
    })),
  };
}

// ── Behaviors ────────────────────────────────────────────────────────────────────────────────────────────

export const createAddBehaviorCommand = (store: BehaviorStore, behavior: Behavior): ICommand | null =>
  store.get().some((b) => b.id === behavior.id) ? null : listCommand(store, `Adicionar Behavior "${behavior.name}"`, (list) => [...list, behavior]);

export function createRemoveBehaviorCommand(store: BehaviorStore, id: string): ICommand | null {
  const found = store.get().find((b) => b.id === id);
  // Undo reinsere na MESMA posição, com todos os parâmetros e Actions (a lista anterior é restaurada inteira)
  return found ? listCommand(store, `Remover Behavior "${found.name}"`, (list) => list.filter((b) => b.id !== id)) : null;
}

export function createDuplicateBehaviorCommand(store: BehaviorStore, id: string): { command: ICommand; newId: string } | null {
  const source = store.get().find((b) => b.id === id);
  if (!source) return null;
  const copy = cloneBehavior(source);
  const command = listCommand(store, `Duplicar Behavior "${source.name}"`, (list) => {
    const at = list.findIndex((b) => b.id === id);
    return [...list.slice(0, at + 1), copy, ...list.slice(at + 1)];
  });
  return command ? { command, newId: copy.id } : null;
}

export const createRenameBehaviorCommand = (store: BehaviorStore, id: string, name: string): ICommand | null =>
  listCommand(store, 'Renomear Behavior', (list) => replaceBehavior(list, id, (b) => (b.name === name ? b : { ...b, name })));

export const createSetBehaviorEnabledCommand = (store: BehaviorStore, id: string, enabled: boolean): ICommand | null =>
  listCommand(store, enabled ? 'Ativar Behavior' : 'Desativar Behavior', (list) => replaceBehavior(list, id, (b) => (b.enabled === enabled ? b : { ...b, enabled })));

export const createSetBehaviorPropertyCommand = (store: BehaviorStore, id: string, key: string, value: unknown): ICommand | null =>
  listCommand(store, `Alterar ${key}`, (list) =>
    replaceBehavior(list, id, (b) => (Object.is(b.properties[key], value) ? b : { ...b, properties: { ...b.properties, [key]: value } }))
  );

// ── Trigger e Conditions ─────────────────────────────────────────────────────────────────────────────────

export const createSetBehaviorTriggerCommand = (store: BehaviorStore, id: string, ruleId: string, triggerId: string): ICommand | null =>
  listCommand(store, 'Trocar Trigger', (list) =>
    replaceBehavior(list, id, (b) => replaceRule(b, ruleId, (r) => (r.eventType === triggerId ? r : { ...r, eventType: triggerId })))
  );

export function createAddConditionCommand(store: BehaviorStore, id: string, ruleId: string, conditionType: string): ICommand | null {
  const definition = LogicRegistry.getCondition(conditionType);
  const condition: LogicCondition = { id: newLogicId('c_', 5), type: conditionType, parameters: defaultParameters(definition?.params ?? []) };
  return listCommand(store, 'Adicionar Condition', (list) => replaceBehavior(list, id, (b) => replaceRule(b, ruleId, (r) => ({ ...r, conditions: [...r.conditions, condition] }))));
}

export const createRemoveConditionCommand = (store: BehaviorStore, id: string, ruleId: string, conditionId: string): ICommand | null =>
  listCommand(store, 'Remover Condition', (list) =>
    replaceBehavior(list, id, (b) =>
      replaceRule(b, ruleId, (r) => (r.conditions.some((c) => c.id === conditionId) ? { ...r, conditions: r.conditions.filter((c) => c.id !== conditionId) } : r))
    )
  );

export const createSetConditionParamCommand = (store: BehaviorStore, id: string, ruleId: string, conditionId: string, key: string, value: unknown): ICommand | null =>
  listCommand(store, `Alterar ${key}`, (list) =>
    replaceBehavior(list, id, (b) =>
      replaceRule(b, ruleId, (r) => {
        const target = r.conditions.find((c) => c.id === conditionId);
        if (!target || Object.is(target.parameters[key], value)) return r; // nada mudou: sem entrada no histórico
        return { ...r, conditions: r.conditions.map((c) => (c === target ? { ...c, parameters: { ...c.parameters, [key]: value } } : c)) };
      })
    )
  );

// ── Actions ──────────────────────────────────────────────────────────────────────────────────────────────

export function createAddActionCommand(store: BehaviorStore, id: string, ruleId: string, actionType: string): ICommand | null {
  const definition = LogicRegistry.getAction(actionType);
  const action: LogicAction = { id: newLogicId('act_', 5), type: actionType, parameters: defaultParameters(definition?.params ?? [], definition?.quickAdd?.parameters) };
  return listCommand(store, `Adicionar Action "${definition?.label ?? actionType}"`, (list) =>
    replaceBehavior(list, id, (b) => replaceRule(b, ruleId, (r) => ({ ...r, actions: [...r.actions, action] })))
  );
}

export const createRemoveActionCommand = (store: BehaviorStore, id: string, ruleId: string, actionId: string): ICommand | null =>
  listCommand(store, 'Remover Action', (list) =>
    replaceBehavior(list, id, (b) =>
      replaceRule(b, ruleId, (r) => (r.actions.some((a) => a.id === actionId) ? { ...r, actions: r.actions.filter((a) => a.id !== actionId) } : r))
    )
  );

/** Move a Action de `from` para `to` (mesma regra do `arrayMove`); só a próxima execução do evento usa a nova ordem. */
export const createReorderActionsCommand = (store: BehaviorStore, id: string, ruleId: string, from: number, to: number): ICommand | null =>
  listCommand(store, 'Reordenar Actions', (list) =>
    replaceBehavior(list, id, (b) =>
      replaceRule(b, ruleId, (r) => {
        const n = r.actions.length;
        if (from === to || from < 0 || to < 0 || from >= n || to >= n) return r;
        const actions = [...r.actions];
        const [moved] = actions.splice(from, 1);
        actions.splice(to, 0, moved);
        return { ...r, actions };
      })
    )
  );

export const createSetActionParamCommand = (store: BehaviorStore, id: string, ruleId: string, actionId: string, key: string, value: unknown): ICommand | null =>
  listCommand(store, `Alterar ${key}`, (list) =>
    replaceBehavior(list, id, (b) =>
      replaceRule(b, ruleId, (r) => {
        const target = r.actions.find((a) => a.id === actionId);
        if (!target || Object.is(target.parameters[key], value)) return r; // nada mudou: sem entrada no histórico
        return { ...r, actions: r.actions.map((a) => (a === target ? { ...a, parameters: { ...a.parameters, [key]: value } } : a)) };
      })
    )
  );

// ── Vários parâmetros de uma vez (diálogo de parâmetros, AIS-42): UM Command = UM Undo ──────────────────────

/** Aplica o patch (`undefined` remove a chave); devolve o MESMO objeto se nada mudou. */
function patchedParams(current: Record<string, any>, patch: Record<string, unknown>): Record<string, any> {
  let next = current;
  for (const [key, value] of Object.entries(patch)) {
    const had = Object.prototype.hasOwnProperty.call(next, key);
    if (value === undefined ? !had : had && JSON.stringify(next[key]) === JSON.stringify(value)) continue;
    if (next === current) next = { ...current };
    if (value === undefined) delete next[key];
    else next[key] = value;
  }
  return next;
}

export const createSetActionParamsCommand = (store: BehaviorStore, id: string, ruleId: string, actionId: string, patch: Record<string, unknown>): ICommand | null =>
  listCommand(store, 'Editar parâmetros da Action', (list) =>
    replaceBehavior(list, id, (b) =>
      replaceRule(b, ruleId, (r) => {
        const target = r.actions.find((a) => a.id === actionId);
        const next = target && patchedParams(target.parameters, patch);
        if (!target || next === target.parameters) return r;
        return { ...r, actions: r.actions.map((a) => (a === target ? { ...a, parameters: next! } : a)) };
      })
    )
  );

export const createSetConditionParamsCommand = (store: BehaviorStore, id: string, ruleId: string, conditionId: string, patch: Record<string, unknown>): ICommand | null =>
  listCommand(store, 'Editar parâmetros da Condition', (list) =>
    replaceBehavior(list, id, (b) =>
      replaceRule(b, ruleId, (r) => {
        const target = r.conditions.find((c) => c.id === conditionId);
        const next = target && patchedParams(target.parameters, patch);
        if (!target || next === target.parameters) return r;
        return { ...r, conditions: r.conditions.map((c) => (c === target ? { ...c, parameters: next! } : c)) };
      })
    )
  );

/** Parâmetros do Trigger moram em `rule.parameters`. */
export const createSetTriggerParamsCommand = (store: BehaviorStore, id: string, ruleId: string, patch: Record<string, unknown>): ICommand | null =>
  listCommand(store, 'Editar parâmetros do Trigger', (list) =>
    replaceBehavior(list, id, (b) =>
      replaceRule(b, ruleId, (r) => {
        const next = patchedParams(r.parameters, patch);
        return next === r.parameters ? r : { ...r, parameters: next };
      })
    )
  );

// ── Operações (a API única que a UI chama) ───────────────────────────────────────────────────────────────

export interface BehaviorOps {
  add(behavior: Behavior): void;
  remove(id: string): void;
  /** Devolve o ID da cópia, ou `null`. */
  duplicate(id: string): string | null;
  rename(id: string, name: string): void;
  setEnabled(id: string, enabled: boolean): void;
  setProperty(id: string, key: string, value: unknown): void;
  setTrigger(id: string, ruleId: string, triggerId: string): void;
  addCondition(id: string, ruleId: string, conditionType: string): void;
  removeCondition(id: string, ruleId: string, conditionId: string): void;
  setConditionParam(id: string, ruleId: string, conditionId: string, key: string, value: unknown): void;
  addAction(id: string, ruleId: string, actionType: string): void;
  removeAction(id: string, ruleId: string, actionId: string): void;
  reorderActions(id: string, ruleId: string, from: number, to: number): void;
  setActionParam(id: string, ruleId: string, actionId: string, key: string, value: unknown): void;
  /** AIS-42: vários parâmetros num só Command (um Undo). `undefined` remove a chave. */
  setActionParams(id: string, ruleId: string, actionId: string, patch: Record<string, unknown>): void;
  setConditionParams(id: string, ruleId: string, conditionId: string, patch: Record<string, unknown>): void;
  setTriggerParams(id: string, ruleId: string, patch: Record<string, unknown>): void;
}

/** `execute` é o `globalCommandManager.execute` (ou um espião nos testes). */
export function createBehaviorOps(store: BehaviorStore, execute: (command: ICommand) => void): BehaviorOps {
  const run = (command: ICommand | null) => {
    if (command) execute(command);
  };
  return {
    add: (behavior) => run(createAddBehaviorCommand(store, behavior)),
    remove: (id) => run(createRemoveBehaviorCommand(store, id)),
    duplicate: (id) => {
      const made = createDuplicateBehaviorCommand(store, id);
      if (!made) return null;
      execute(made.command);
      return made.newId;
    },
    rename: (id, name) => run(createRenameBehaviorCommand(store, id, name)),
    setEnabled: (id, enabled) => run(createSetBehaviorEnabledCommand(store, id, enabled)),
    setProperty: (id, key, value) => run(createSetBehaviorPropertyCommand(store, id, key, value)),
    setTrigger: (id, ruleId, triggerId) => run(createSetBehaviorTriggerCommand(store, id, ruleId, triggerId)),
    addCondition: (id, ruleId, type) => run(createAddConditionCommand(store, id, ruleId, type)),
    removeCondition: (id, ruleId, conditionId) => run(createRemoveConditionCommand(store, id, ruleId, conditionId)),
    setConditionParam: (id, ruleId, conditionId, key, value) => run(createSetConditionParamCommand(store, id, ruleId, conditionId, key, value)),
    addAction: (id, ruleId, type) => run(createAddActionCommand(store, id, ruleId, type)),
    removeAction: (id, ruleId, actionId) => run(createRemoveActionCommand(store, id, ruleId, actionId)),
    reorderActions: (id, ruleId, from, to) => run(createReorderActionsCommand(store, id, ruleId, from, to)),
    setActionParam: (id, ruleId, actionId, key, value) => run(createSetActionParamCommand(store, id, ruleId, actionId, key, value)),
    setActionParams: (id, ruleId, actionId, patch) => run(createSetActionParamsCommand(store, id, ruleId, actionId, patch)),
    setConditionParams: (id, ruleId, conditionId, patch) => run(createSetConditionParamsCommand(store, id, ruleId, conditionId, patch)),
    setTriggerParams: (id, ruleId, patch) => run(createSetTriggerParamsCommand(store, id, ruleId, patch)),
  };
}
