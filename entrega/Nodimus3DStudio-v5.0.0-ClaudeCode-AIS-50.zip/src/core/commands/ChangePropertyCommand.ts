import type { ICommand } from '../../types/commands';

/**
 * AIS-21 — ChangePropertyCommand: modificação granular de campos do nó.
 *
 * Registra `nodeId`, `propertyPath` (ex.: "materialColor", "physics.mass", "light.intensity"),
 * valor anterior e novo valor. Undo restaura o valor prévio (inclusive "não existia") e dispara
 * o evento de re-renderização (`afterUndo`/`afterExecute`) do Inspector e da Viewport 3D.
 * Guarda só o delta; sem React/Zustand/Three — o alvo e os efeitos de UI são injetados.
 *
 * `propertyPath` navega `GameNode.properties` por segmentos separados por ponto; segmento
 * numérico indexa array ("colors.0"). Chave plana (sem ponto) é o caso comum.
 */

type Json = unknown;
type Bag = Record<string, any>;

// ── Caminho (puro, imutável) ──────────────────────────────────────────────────────────────────

export const splitPath = (path: string): string[] => path.split('.').filter((s) => s.length > 0);

const isObj = (v: unknown): v is Bag => typeof v === 'object' && v !== null;
const clone = <T>(v: T): T => (v === undefined ? v : JSON.parse(JSON.stringify(v)));

export function deepEqual(a: Json, b: Json): boolean {
  if (a === b) return true;
  if (!isObj(a) || !isObj(b)) return Number.isNaN(a) && Number.isNaN(b);
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  const ka = Object.keys(a);
  const kb = Object.keys(b);
  return ka.length === kb.length && ka.every((k) => Object.prototype.hasOwnProperty.call(b, k) && deepEqual(a[k], b[k]));
}

/** Lê o valor no caminho; `found=false` quando algum segmento não existe. */
export function getAtPath(obj: Bag | undefined, path: string): { found: boolean; value: any } {
  let cur: any = obj;
  for (const seg of splitPath(path)) {
    if (!isObj(cur) || !Object.prototype.hasOwnProperty.call(cur, seg)) return { found: false, value: undefined };
    cur = cur[seg];
  }
  return { found: splitPath(path).length > 0, value: cur };
}

/** Cópia de `obj` com `value` no caminho (cria objetos intermediários; só clona o que muda). */
export function setAtPath(obj: Bag, path: string, value: any): Bag {
  const segs = splitPath(path);
  if (segs.length === 0) return obj;
  const set = (node: any, i: number): any => {
    const seg = segs[i];
    const base: any = Array.isArray(node) ? [...node] : isObj(node) ? { ...node } : /^\d+$/.test(seg) ? [] : {};
    base[seg] = i === segs.length - 1 ? value : set(isObj(node) ? node[seg] : undefined, i + 1);
    return base;
  };
  return set(obj, 0);
}

/** Cópia de `obj` sem a chave do caminho (os pais permanecem, mesmo vazios). */
export function unsetAtPath(obj: Bag, path: string): Bag {
  const segs = splitPath(path);
  if (segs.length === 0) return obj;
  const unset = (node: any, i: number): any => {
    if (!isObj(node) || !Object.prototype.hasOwnProperty.call(node, segs[i])) return node;
    if (Array.isArray(node)) {
      const copy = [...node];
      if (i === segs.length - 1) copy.splice(Number(segs[i]), 1);
      else copy[Number(segs[i])] = unset(node[Number(segs[i])], i + 1);
      return copy;
    }
    const { [segs[i]]: child, ...rest } = node;
    return i === segs.length - 1 ? rest : { ...rest, [segs[i]]: unset(child, i + 1) };
  };
  return unset(obj, 0);
}

// ── Command ───────────────────────────────────────────────────────────────────────────────────

/** Subconjunto do AuthoringModel usado pelo Command (facilita testar). */
export interface PropertyTarget {
  getNode(nodeId: string): { name?: string; properties: Bag } | undefined;
  updateNodeProperties(nodeId: string, updates: Bag): void;
  removeNodeProperties(nodeId: string, keys: string[]): void;
}

export interface PropertyChange {
  propertyPath: string;
  prev: Json;
  /** `false` = a propriedade não existia antes (Undo a remove). */
  hadPrev: boolean;
  /** Quando `!hadPrev`: o prefixo mais curto que não existia (Undo remove ele, sem deixar pais vazios criados pelo Command). */
  undoPath?: string;
  next: Json;
}

export interface ChangePropertyInput {
  target: PropertyTarget;
  nodeId: string;
  /** Um ou mais caminhos → novo valor, aplicados e desfeitos juntos (um Command). */
  changes: Readonly<Record<string, Json>>;
  /** Rótulo do histórico (padrão: "Change <caminho>"). */
  label?: string;
  /** Re-renderização do Inspector/Viewport depois de aplicar (execute/redo). */
  afterExecute?: () => void;
  /** Re-renderização do Inspector/Viewport depois de desfazer. */
  afterUndo?: () => void;
}

/** Prefixo mais curto do caminho que ainda não existe em `obj` (o que o Command vai criar). */
function firstMissingPrefix(obj: Bag, path: string): string {
  const segs = splitPath(path);
  for (let i = 1; i <= segs.length; i++) {
    const prefix = segs.slice(0, i).join('.');
    if (!getAtPath(obj, prefix).found) return prefix;
  }
  return path;
}

/** Aplica ao nó `side` ('prev' | 'next') de cada mudança, via os métodos do alvo. */
function applySide(target: PropertyTarget, nodeId: string, changes: readonly PropertyChange[], side: 'prev' | 'next') {
  const node = target.getNode(nodeId);
  if (!node) return;
  let working: Bag = node.properties;
  const touched = new Set<string>();
  for (const change of changes) {
    touched.add(splitPath(change.propertyPath)[0]);
    const remove = side === 'prev' && !change.hadPrev;
    working = remove
      ? unsetAtPath(working, change.undoPath ?? change.propertyPath)
      : setAtPath(working, change.propertyPath, clone(side === 'prev' ? change.prev : change.next));
  }
  const updates: Bag = {};
  const removals: string[] = [];
  for (const key of touched) {
    if (Object.prototype.hasOwnProperty.call(working, key)) updates[key] = working[key];
    else removals.push(key);
  }
  if (removals.length) target.removeNodeProperties(nodeId, removals);
  if (Object.keys(updates).length) target.updateNodeProperties(nodeId, updates);
}

/**
 * Command de edição de propriedade(s). Registra anterior/novo por caminho; `null` quando o nó
 * não existe ou nada muda (valor igual não entra no histórico).
 */
/** Mudanças de cada Command (para `merge`); o Command em si não expõe o estado interno. */
const changesOf = new WeakMap<object, PropertyChange[]>();

export function createChangePropertyCommand(input: ChangePropertyInput): ICommand | null {
  const { target, nodeId } = input;
  const node = target.getNode(nodeId);
  if (!node) return null;

  const changes: PropertyChange[] = [];
  for (const [propertyPath, next] of Object.entries(input.changes)) {
    if (splitPath(propertyPath).length === 0) continue;
    const { found, value } = getAtPath(node.properties, propertyPath);
    if (found && deepEqual(value, next)) continue;
    changes.push({ propertyPath, prev: clone(value), hadPrev: found, undoPath: found ? undefined : firstMissingPrefix(node.properties, propertyPath), next: clone(next) });
  }
  if (changes.length === 0) return null;

  // caminhos ordenados; a chave usa os caminhos PEDIDOS (não só os que mudaram nesta chamada): uma edição
  // contínua (ex.: arrastar um overlay: posX/posY/width/height) mantém a mesma chave mesmo quando, num
  // movimento, algum campo não muda
  changes.sort((a, b) => (a.propertyPath < b.propertyPath ? -1 : a.propertyPath > b.propertyPath ? 1 : 0));
  const requestedPaths = Object.keys(input.changes).filter((k) => splitPath(k).length > 0).sort();
  const mergeKey = `prop:${nodeId}:${requestedPaths.join('|')}`;

  const command: ICommand = {
    mergeKey,
    // AIS-24: absorve o Command seguinte do mesmo gesto — mantém `prev` (início) e leva `next` ao valor final
    merge: (other) => {
      const theirs = changesOf.get(other);
      if (!theirs || other.mergeKey !== mergeKey) return false;
      for (const incoming of theirs) {
        const mine = changes.find((c) => c.propertyPath === incoming.propertyPath);
        if (mine) {
          mine.next = clone(incoming.next); // mantém `prev` do início do gesto
        } else {
          // campo que não mudou no 1º movimento: o `prev` do Command seguinte é o valor original
          changes.push({ ...incoming, prev: clone(incoming.prev), next: clone(incoming.next) });
        }
      }
      return true;
    },
    label: input.label ?? (changes.length === 1 ? `Change ${changes[0].propertyPath}` : `Change Properties (${changes.length})`),
    execute: () => {
      applySide(target, nodeId, changes, 'next');
      input.afterExecute?.();
    },
    undo: () => {
      // ordem inversa: restaura exatamente o estado anterior
      applySide(target, nodeId, [...changes].reverse(), 'prev');
      input.afterUndo?.();
    },
  };
  changesOf.set(command, changes);
  return command;
}
