import type { ICommand } from '../../types/commands';
import type { GameNode } from '../../types/node';
import type { SceneData } from '../../types/scene';
import { pruneNestedSelection } from '../authoring/selectionUtils';
import { restoreDeletedSubtrees, type DeletedRoot, type SubtreeRestoreTarget } from '../authoring/restoreSubtree';
import { isOverlayNodeType } from '../../runtime/overlay';
import { computeLocalForNewParent, planMove, readLocalTransform } from '../authoring/reparentMath';

/**
 * AIS-20 — Commands estruturais da árvore de cena: Add, Delete e Reparent.
 *
 * Integridade do grafo (decisão do prompt): Undo/Redo preservam os IDs persistentes —
 * o mesmo nó volta com o mesmo `id`, na mesma posição entre os irmãos; nunca uma identidade
 * nova para a mesma entidade autoral. Sem React/Zustand/Three: o alvo da mutação
 * (`SceneTreeTarget`, hoje o AuthoringModel) e os efeitos de UI (`onChange`) são injetados.
 */

/** Subconjunto do AuthoringModel que os Commands de árvore usam (facilita testar). */
export interface SceneTreeTarget extends SubtreeRestoreTarget {
  getScene(): SceneData;
  deleteNode(nodeId: string): void;
  deleteMultipleNodes(nodeIds: string[]): void;
  updateNodeProperties(nodeId: string, updates: Record<string, any>): void;
}

/** Efeitos de UI depois de aplicar/desfazer (ex.: sincronizar a projeção e a seleção). */
export interface SceneTreeCommandHooks {
  /** Depois de `execute` (inclui o redo). */
  afterExecute?: () => void;
  /** Depois de `undo`. */
  afterUndo?: () => void;
}

const clone = <T>(value: T): T => JSON.parse(JSON.stringify(value));

// ── AddNodeCommand ────────────────────────────────────────────────────────────────────────────

export interface AddNodeInput extends SceneTreeCommandHooks {
  target: SceneTreeTarget;
  /** Nó já criado (com `id` definitivo): o redo reinsere ESTE nó, com o mesmo `id`. */
  node: GameNode;
  parentId: string | null;
}

/** Adiciona o nó na hierarquia; o Undo remove o nó (e o que tiver sido pendurado nele). */
export function createAddNodeCommand(input: AddNodeInput): ICommand {
  const { target, parentId, node } = input;
  // O nó NÃO é clonado: chamadores (ex.: TerrainEditorModal) completam `properties` do nó devolvido
  // por `addNode` logo depois; o Redo reinsere o mesmo objeto (mesmo id, com esses ajustes).
  return {
    label: `Add Node ${node.name}`,
    execute: () => {
      target.addNode(node, parentId);
      input.afterExecute?.();
    },
    undo: () => {
      target.deleteNode(node.id);
      input.afterUndo?.();
    },
  };
}

// ── DeleteNodeCommand ─────────────────────────────────────────────────────────────────────────

export interface DeleteNodeInput extends SceneTreeCommandHooks {
  target: SceneTreeTarget;
  nodeIds: readonly string[];
}

/** Subárvore em ordem pai → filhos (DFS), cópia profunda. */
function serializeSubtree(scene: SceneData, id: string): GameNode[] {
  const node = scene.nodes[id];
  if (!node) return [];
  return [clone(node), ...node.childrenIds.flatMap((childId) => serializeSubtree(scene, childId))];
}

/**
 * Remove os nós e guarda a subárvore de cada um serializada (IDs, filhos, propriedades e a
 * posição entre os irmãos) para a restauração íntegra no Undo. Seleção múltipla = UM Command.
 * Nós aninhados em outro selecionado saem com o ancestral; a raiz nunca é excluída.
 * `null` quando não há nada excluível.
 */
export function createDeleteNodeCommand(input: DeleteNodeInput): ICommand | null {
  const { target } = input;
  const scene = target.getScene();
  const ids = pruneNestedSelection(scene.nodes, [...new Set(input.nodeIds)], scene.rootNodeId);
  if (ids.length === 0) return null;

  const backups = ids.flatMap((id) => serializeSubtree(scene, id));
  const roots: DeletedRoot[] = ids.map((id) => {
    const parentId = scene.nodes[id].parentId;
    return { id, parentId, index: parentId ? (scene.nodes[parentId]?.childrenIds ?? []).indexOf(id) : -1 };
  });
  const label = ids.length === 1 ? `Delete Node ${scene.nodes[ids[0]].name}` : `Delete Nodes (${ids.length})`;

  return {
    label,
    execute: () => {
      if (ids.length === 1) target.deleteNode(ids[0]);
      else target.deleteMultipleNodes([...ids]);
      input.afterExecute?.();
    },
    undo: () => {
      // sem duplicar filhos e nas posições originais entre os irmãos
      restoreDeletedSubtrees(target, clone(backups), roots);
      input.afterUndo?.();
    },
  };
}

// ── ReparentNodeCommand ───────────────────────────────────────────────────────────────────────

export interface ReparentNodeInput extends SceneTreeCommandHooks {
  target: SceneTreeTarget;
  nodeId: string;
  /** `null` = raiz da cena. */
  newParentId: string | null;
  /** Posição desejada entre os irmãos do novo pai (ver `planMove`). */
  targetIndex?: number;
}

/**
 * Muda o `parentId` (ou só a ordem entre irmãos) recalculando o transform LOCAL para preservar a
 * pose mundial (a pose mundial é a composição da cadeia de pais). `null` para movimento inválido
 * (ciclo, raiz, no-op).
 */
export function createReparentNodeCommand(input: ReparentNodeInput): ICommand | null {
  const { target, nodeId } = input;
  const scene = target.getScene();
  const node = scene.nodes[nodeId];
  if (!node) return null;

  const plan = planMove(scene, nodeId, input.newParentId || scene.rootNodeId, input.targetIndex);
  if (!plan) return null;

  const oldParentId = node.parentId;
  const oldIndex = oldParentId ? (scene.nodes[oldParentId]?.childrenIds ?? []).indexOf(nodeId) : -1;
  const sameParent = oldParentId === plan.parentId;
  const oldLocal = clone(readLocalTransform(node.properties));
  // AIS-25c: nó de UI (Overlay2D, Panel, Containers, controles) não tem pose 3D: mover entre Containers só troca o
  // pai/índice e mantém as propriedades de layout (size flags, minSize, âncoras); nada de transform é escrito.
  const newLocal = sameParent || isOverlayNodeType(node.type) ? null : clone(computeLocalForNewParent(scene, nodeId, plan.parentId));

  return {
    label: sameParent ? `Reorder Node ${node.name}` : `Reparent Node ${node.name}`,
    execute: () => {
      target.reparentNode(nodeId, plan.parentId, plan.index);
      if (newLocal) target.updateNodeProperties(nodeId, clone(newLocal));
      input.afterExecute?.();
    },
    undo: () => {
      target.reparentNode(nodeId, oldParentId, oldIndex >= 0 ? oldIndex : undefined);
      if (newLocal) target.updateNodeProperties(nodeId, clone(oldLocal));
      input.afterUndo?.();
    },
  };
}
