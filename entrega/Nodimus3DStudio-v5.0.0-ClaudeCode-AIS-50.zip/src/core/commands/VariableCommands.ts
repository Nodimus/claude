/**
 * AIS-43 — Commands de variáveis. Criar, renomear, mudar tipo/valor e excluir (globais do projeto e locais do nó) passam
 * por UM Command de substituição: guarda a lista/registro anterior e o novo, então Undo/Redo são exatos. Renomear ou excluir
 * também carrega os Behaviors reescritos (referências atualizadas) no MESMO Command: um Ctrl+Z desfaz tudo junto.
 */
import type { ICommand } from '../../types/commands';
import type { Behavior } from '../../types/visualLogic';
import type { ProjectGlobalVariable } from '../../types/projectFile';
import type { BehaviorStore } from './BehaviorCommands';

export interface GlobalVariableStore {
  get(): readonly ProjectGlobalVariable[];
  set(next: ProjectGlobalVariable[]): void;
}

export interface LocalVariableStore {
  get(nodeId: string): Readonly<Record<string, any>> | undefined;
  set(nodeId: string, next: Record<string, any>): void;
}

export interface BehaviorRewrite {
  store: BehaviorStore;
  /** Lista de Behaviors JÁ reescrita (mesmas referências onde nada mudou). */
  next: Behavior[];
}

const sameList = <T>(a: readonly T[], b: readonly T[]) => a.length === b.length && a.every((x, i) => x === b[i]);

/** `null` quando nada muda (nenhuma entrada vazia no histórico). */
export function createSetGlobalVariablesCommand(input: { label: string; store: GlobalVariableStore; next: ProjectGlobalVariable[]; behaviors?: BehaviorRewrite }): ICommand | null {
  const prev = [...input.store.get()];
  const prevBehaviors = input.behaviors ? [...input.behaviors.store.get()] : undefined;
  const behaviorsChanged = !!input.behaviors && !!prevBehaviors && !sameList(prevBehaviors, input.behaviors.next);
  if (sameList(prev, input.next) && !behaviorsChanged) return null;
  const apply = () => {
    input.store.set([...input.next]);
    if (behaviorsChanged) input.behaviors!.store.set([...input.behaviors!.next]);
  };
  return {
    label: input.label,
    execute: apply,
    redo: apply,
    undo: () => {
      input.store.set([...prev]);
      if (behaviorsChanged) input.behaviors!.store.set([...prevBehaviors!]);
    },
  } as ICommand;
}

export function createSetLocalVariablesCommand(input: { label: string; store: LocalVariableStore; nodeId: string; next: Record<string, any>; behaviors?: BehaviorRewrite }): ICommand | null {
  const prev = { ...(input.store.get(input.nodeId) ?? {}) };
  const prevBehaviors = input.behaviors ? [...input.behaviors.store.get()] : undefined;
  const behaviorsChanged = !!input.behaviors && !!prevBehaviors && !sameList(prevBehaviors, input.behaviors.next);
  const sameVars = JSON.stringify(Object.entries(prev)) === JSON.stringify(Object.entries(input.next));
  if (sameVars && !behaviorsChanged) return null;
  const apply = () => {
    input.store.set(input.nodeId, { ...input.next });
    if (behaviorsChanged) input.behaviors!.store.set([...input.behaviors!.next]);
  };
  return {
    label: input.label,
    execute: apply,
    redo: apply,
    undo: () => {
      input.store.set(input.nodeId, { ...prev });
      if (behaviorsChanged) input.behaviors!.store.set([...prevBehaviors!]);
    },
  } as ICommand;
}
