import type { ICommand } from '../../types/commands';
/**
 * AIS-19 — SetTransformCommand: registro atômico de transformações (Move/Rotate/Scale).
 *
 * Um Command guarda só o delta (anterior → novo) de um ou mais nós; um gesto (arraste do
 * gizmo ou edição no Inspector) = um Command, um Ctrl+Z. Não contém estado React/Zustand
 * nem objetos Three: a gravação no authoring é injetada em `apply` (sem histórico próprio).
 */

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

/** Transform autoral de um GameNode: posição, rotação em graus e escala. */
export interface NodeTransform {
  position: Vec3;
  rotation: Vec3;
  scale: Vec3;
}

export type TransformMode = 'translate' | 'rotate' | 'scale';

/** Um nó do Command: transform anterior (prev*) e novo (new*). */
export interface SetTransformItem {
  nodeId: string;
  prevPosition: Vec3;
  prevRotation: Vec3;
  prevScale: Vec3;
  newPosition: Vec3;
  newRotation: Vec3;
  newScale: Vec3;
}

const vecEqual = (a: Vec3, b: Vec3) => a.x === b.x && a.y === b.y && a.z === b.z;

export function transformsEqual(a: NodeTransform, b: NodeTransform): boolean {
  return vecEqual(a.position, b.position) && vecEqual(a.rotation, b.rotation) && vecEqual(a.scale, b.scale);
}

/** Monta o item a partir de before/after (cópia profunda: o Command não compartilha referências). */
export function toSetTransformItem(nodeId: string, before: NodeTransform, after: NodeTransform): SetTransformItem {
  return {
    nodeId,
    prevPosition: { ...before.position },
    prevRotation: { ...before.rotation },
    prevScale: { ...before.scale },
    newPosition: { ...after.position },
    newRotation: { ...after.rotation },
    newScale: { ...after.scale },
  };
}

const prevOf = (i: SetTransformItem): NodeTransform => ({ position: i.prevPosition, rotation: i.prevRotation, scale: i.prevScale });
const newOf = (i: SetTransformItem): NodeTransform => ({ position: i.newPosition, rotation: i.newRotation, scale: i.newScale });

const VERB: Record<TransformMode, string> = { translate: 'Move', rotate: 'Rotate', scale: 'Scale' };

/** "Move Node" para um nó; "Move Nodes (N)" para grupo. */
export function transformCommandLabel(mode: TransformMode, count: number): string {
  return count === 1 ? `${VERB[mode]} Node` : `${VERB[mode]} Nodes (${count})`;
}

export class SetTransformCommand {
  public readonly label: string;
  public readonly items: readonly SetTransformItem[];

  constructor(
    public readonly mode: TransformMode,
    items: readonly SetTransformItem[],
    private readonly apply: (nodeId: string, transform: NodeTransform) => void
  ) {
    this.items = items;
    this.label = transformCommandLabel(mode, items.length);
    this.mergeKey = `transform:${mode}:${items.map((i) => i.nodeId).join(',')}`;
  }

  /** AIS-24: mesma edição contínua (mesmo modo e nós) dentro de um gesto vira uma entrada só. */
  public readonly mergeKey: string;

  /** Absorve o Command seguinte do gesto: mantém `prev*` (início) e leva `new*` ao valor final. */
  merge = (other: ICommand): boolean => {
    if (!(other instanceof SetTransformCommand) || other.mergeKey !== this.mergeKey) return false;
    this.items.forEach((item, i) => {
      const last = other.items[i];
      item.newPosition = { ...last.newPosition };
      item.newRotation = { ...last.newRotation };
      item.newScale = { ...last.newScale };
    });
    return true;
  };

  execute = (): void => {
    for (const item of this.items) this.apply(item.nodeId, structuredClone(newOf(item)));
  };

  undo = (): void => {
    // ordem inversa: restaura exatamente o estado anterior, mesmo se houver dependência entre itens
    for (let i = this.items.length - 1; i >= 0; i--) this.apply(this.items[i].nodeId, structuredClone(prevOf(this.items[i])));
  };
}

/**
 * Cria o Command de um gesto. Itens sem mudança são descartados; `null` se nada mudou
 * (clique sem arrastar não entra no histórico).
 */
export function createSetTransformCommand(input: {
  mode: TransformMode;
  items: readonly SetTransformItem[];
  apply: (nodeId: string, transform: NodeTransform) => void;
}): SetTransformCommand | null {
  const changed = input.items.filter((i) => !transformsEqual(prevOf(i), newOf(i)));
  return changed.length === 0 ? null : new SetTransformCommand(input.mode, changed, input.apply);
}
