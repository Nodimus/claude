import type { ICommand } from '../../types/commands';
import type { NodeSignalConnection } from '../../types/signal';

/**
 * AIS-27 — Commands de conexão de sinal: conectar, editar e desconectar. Cada um guarda o delta (a conexão antes/depois)
 * e troca `GameNode.signals` pelo alvo injetado (hoje o AuthoringModel). Undo/Redo preservam o `id` da conexão.
 * Nenhuma conexão é tocada antes da confirmação do usuário: os Commands só são criados pelo botão de confirmar.
 */

export interface SignalTarget {
  getNode(nodeId: string): { signals?: NodeSignalConnection[] } | undefined;
  setNodeSignals(nodeId: string, signals: NodeSignalConnection[]): void;
}

export interface SignalCommandHooks {
  afterExecute?: () => void;
  afterUndo?: () => void;
}

const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v));
const read = (target: SignalTarget, nodeId: string): NodeSignalConnection[] => clone(target.getNode(nodeId)?.signals ?? []);

export interface ConnectSignalInput extends SignalCommandHooks {
  target: SignalTarget;
  nodeId: string;
  connection: NodeSignalConnection;
}

/** `connectSignal(nodeId, conn)`: acrescenta a conexão ao fim da lista. */
export function createConnectSignalCommand(input: ConnectSignalInput): ICommand | null {
  const { target, nodeId } = input;
  if (!target.getNode(nodeId)) return null;
  const connection = clone(input.connection);
  return {
    label: `Connect Signal ${connection.signalName}`,
    execute: () => {
      target.setNodeSignals(nodeId, [...read(target, nodeId), clone(connection)]);
      input.afterExecute?.();
    },
    undo: () => {
      target.setNodeSignals(nodeId, read(target, nodeId).filter((c) => c.id !== connection.id));
      input.afterUndo?.();
    },
  };
}

export interface EditSignalInput extends SignalCommandHooks {
  target: SignalTarget;
  nodeId: string;
  /** Conexão atual (pelo `id`). */
  oldConn: NodeSignalConnection;
  /** Nova versão; mantém o mesmo `id`. */
  newConn: NodeSignalConnection;
}

/** `editSignalConnection(nodeId, signalName, oldConn, newConn)`: troca no mesmo lugar da lista. `null` se nada muda. */
export function createEditSignalConnectionCommand(input: EditSignalInput): ICommand | null {
  const { target, nodeId } = input;
  if (!target.getNode(nodeId)) return null;
  const oldConn = clone(input.oldConn);
  const newConn = clone({ ...input.newConn, id: oldConn.id });
  if (JSON.stringify(oldConn) === JSON.stringify(newConn)) return null;
  const swap = (from: NodeSignalConnection, to: NodeSignalConnection) => {
    const list = read(target, nodeId);
    const i = list.findIndex((c) => c.id === from.id);
    if (i < 0) list.push(clone(to));
    else list[i] = clone(to);
    target.setNodeSignals(nodeId, list);
  };
  return {
    label: `Edit Signal Connection ${newConn.signalName}`,
    execute: () => {
      swap(oldConn, newConn);
      input.afterExecute?.();
    },
    undo: () => {
      swap(newConn, oldConn);
      input.afterUndo?.();
    },
  };
}

export interface DisconnectSignalInput extends SignalCommandHooks {
  target: SignalTarget;
  nodeId: string;
  conn: NodeSignalConnection;
}

/** `removeSignalConnection(nodeId, signalName, conn)`: remove pelo `id`; o Undo reinsere na posição original. */
export function createDisconnectSignalCommand(input: DisconnectSignalInput): ICommand | null {
  const { target, nodeId } = input;
  const node = target.getNode(nodeId);
  if (!node) return null;
  const conn = clone(input.conn);
  const index = Math.max(0, (node.signals ?? []).findIndex((c) => c.id === conn.id));
  return {
    label: `Disconnect Signal ${conn.signalName}`,
    execute: () => {
      target.setNodeSignals(nodeId, read(target, nodeId).filter((c) => c.id !== conn.id));
      input.afterExecute?.();
    },
    undo: () => {
      const list = read(target, nodeId).filter((c) => c.id !== conn.id);
      list.splice(Math.min(index, list.length), 0, clone(conn));
      target.setNodeSignals(nodeId, list);
      input.afterUndo?.();
    },
  };
}
