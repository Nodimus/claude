/**
 * AIS-41b — Behaviors de exemplo do projeto inicial, como INSTÂNCIAS inline (uma por nó). Fonte única: o template
 * (`createDefault3DStarterScene`) os anexa aos nós e a migração v2→v3 os usa para resolver os IDs `beh_*` que cenas antigas
 * gravaram em `GameNode.behaviors` (a lista global de onde vinham só existia em memória, no `EditorContext`).
 */
import type { BehaviorInstance } from '../types/visualLogic';

export const STARTER_BEHAVIOR_IDS = {
  player: 'beh_player_wasd',
  orb: 'beh_spin_orb',
  inventoryButton: 'beh_hud_inventory',
} as const;

/** Nome do nó do starter a que cada Behavior pertencia na lista global antiga (`targetNodeId` por nome). */
export const STARTER_BEHAVIOR_TARGET_NAMES: Record<string, string> = {
  [STARTER_BEHAVIOR_IDS.player]: 'PlayerMesh',
  [STARTER_BEHAVIOR_IDS.orb]: 'MagicOrb',
  [STARTER_BEHAVIOR_IDS.inventoryButton]: 'HUD_InventoryButton',
};

/** Cópia nova a cada chamada (instâncias nunca são compartilhadas entre nós nem entre cenas). */
export function createStarterBehavior(id: string): BehaviorInstance | undefined {
  switch (id) {
    case STARTER_BEHAVIOR_IDS.player:
      return {
        id,
        name: 'Player 3D Controller',
        behaviorType: 'simple_wasd_movement',
        enabled: true,
        properties: { speed: 6.0, jumpForce: 8.0 },
        rules: [
          {
            id: 'rule_wasd',
            eventType: 'on_update',
            parameters: {},
            conditions: [{ id: 'c1', type: 'always', parameters: {} }],
            actions: [{ id: 'a1', type: 'move_by', parameters: { dx: 1, dz: 0 } }],
          },
        ],
      };
    case STARTER_BEHAVIOR_IDS.orb:
      return {
        id,
        name: 'Rotate Magic Orb',
        behaviorType: 'continuous_rotation',
        enabled: true,
        properties: { rotationSpeed: 45, axis: 'y' },
        rules: [
          {
            id: 'rule_spin',
            eventType: 'on_update',
            parameters: {},
            conditions: [{ id: 'c1', type: 'always', parameters: {} }],
            actions: [{ id: 'a2', type: 'rotate_by', parameters: { degrees: 1 } }],
          },
        ],
      };
    case STARTER_BEHAVIOR_IDS.inventoryButton:
      return {
        id,
        name: 'On Click Inventory Button',
        behaviorType: 'click_detector',
        enabled: true,
        properties: {},
        rules: [
          {
            id: 'rule_click_inv',
            eventType: 'on_click',
            parameters: {},
            conditions: [{ id: 'c1', type: 'always', parameters: {} }],
            actions: [{ id: 'a_log', type: 'print_log', parameters: { text: 'Inventory Button clicked!' } }],
          },
        ],
      };
    default:
      return undefined;
  }
}
