import type { ResourceRef } from '../types/node';
import type { ResourceRegistry } from './resources/ResourceRegistry';
import { baseNameOf, collectDeleteTargets, isFolderPath, planPathChange, remapPath } from './fileSystem/fileOps';
import {
  replaceRules,
  replaceUrisInText,
  rewriteJsonContent,
  unresolveRules,
  type JsonRewriteRules,
  type ResourceIdentity,
} from './resourceRewrite';

/**
 * AIS-29e — serviço ÚNICO de excluir e mover recursos de `res://` (`deleteResource` / `moveResource`). O
 * FileSystemPanel, menus de contexto e modais são só consumidores; ninguém chama `TauriBridge.deleteFile/moveFile` nem
 * mexe em `project.files` por conta própria.
 *
 * Regras:
 *  - nada é gravado sem `confirmed: true`; cancelar = não chamar (ou receber `needs_confirmation`): zero escrita;
 *  - excluir com dependências exige uma DECISÃO explícita: manter as referências como `unresolved` (preservadas, nunca
 *    apagadas em silêncio) ou substituir por outro recurso do mesmo tipo;
 *  - mover/renomear preserva o `resourceId` e atualiza as referências por caminho de forma ATÔMICA (um único commit);
 *  - excluir/mover não são Commands (afetam o sistema de arquivos, não entram no Undo).
 *
 * A lógica é pura sobre um contexto injetado (`ResourceOpsContext`): testável sem React nem armazenamento.
 */

export type FileLike = {
  path: string;
  name: string;
  isDirectory: boolean;
  extension?: string;
  content?: string;
  size?: number;
  updatedAt?: string;
  resourceId?: string;
  [key: string]: unknown;
};

export interface ResourceCommit {
  /** Arquivos criados/substituídos (a chave é o caminho final). */
  upsert: Record<string, FileLike>;
  /** Caminhos removidos. */
  remove: string[];
  /** Caminhos movidos: o projeto acompanha cena principal e última aberta. */
  moves?: [string, string][];
}

/** Porta de persistência: UM `commit` aplica tudo (atomicidade). */
export interface ResourceIO {
  files(): Record<string, FileLike>;
  commit(change: ResourceCommit): void;
}

export interface ResourceOpsContext {
  registry: ResourceRegistry;
  io: ResourceIO;
  /** Cena aberta no editor: arquivo dela não é regravado por baixo; mexer nele exige estar sem alterações. */
  activeScene?: () => { path: string; dirty: boolean } | null;
  now?: () => string;
}

/** Alvo: um `ResourceRef` (resolvido pelo registry) ou só um caminho (arquivo ou pasta terminada em `/`). */
export type ResourceTarget = ResourceRef | { path: string; id?: undefined };

export interface DeletionConsumer {
  /** Recurso excluído que está em uso. */
  resourceUri: string;
  /** Quem o referencia. */
  uri: string;
  kind: string;
  /** Onde, no documento de origem, a referência aparece. */
  via: string;
  editorOnly: boolean;
}

export interface DeletionPlan {
  /** Caminho pedido. */
  uri: string;
  /** Todos os caminhos que saem (a pasta e tudo abaixo dela). */
  paths: string[];
  /** Recursos (arquivos com identidade) que saem. */
  resources: { id: string; uri: string; kind: string }[];
  fileCount: number;
  folderCount: number;
  consumers: DeletionConsumer[];
  /** O recurso pode ser substituído por outro do mesmo tipo (material, textura…). */
  canReplace: boolean;
  replaceKind?: string;
  /** Operação recusada (ex.: a cena aberta). */
  blockedReason?: string;
}

export type DeleteDecision = { kind: 'unresolve' } | { kind: 'replace'; with: ResourceRef };

export interface DeleteOptions {
  confirmed?: boolean;
  /** Obrigatória quando há consumidores. */
  decision?: DeleteDecision;
}

export interface DeferredRewrite {
  /** Arquivo que NÃO foi regravado (é a cena aberta): o editor aplica a reescrita no estado em memória. */
  uri: string;
  rewrite: (content: string) => string;
}

export type DeleteResult =
  | { ok: true; removed: string[]; rewritten: string[]; deferred: DeferredRewrite[]; plan: DeletionPlan }
  | { ok: false; status: 'not_found' | 'blocked' | 'needs_confirmation' | 'needs_decision' | 'invalid_replacement'; message: string; plan?: DeletionPlan };

export interface MoveOptions {
  confirmed?: boolean;
}

export type MoveResult =
  | { ok: true; moves: [string, string][]; rewritten: string[]; deferred: DeferredRewrite[]; activeSceneMovedTo?: string }
  | { ok: false; status: 'not_found' | 'blocked' | 'conflict' | 'invalid' | 'needs_confirmation'; message: string; moves?: [string, string][] };

const REPLACEABLE_KINDS = new Set(['texture', 'material', 'audio', 'video', 'mesh', 'sprite']);

const nowOf = (ctx: ResourceOpsContext) => (ctx.now ?? (() => new Date().toISOString()))();

function resolveUri(ctx: ResourceOpsContext, target: ResourceTarget): string | null {
  if (typeof target.path === 'string' && !(target as ResourceRef).id) return target.path;
  const ref = target as ResourceRef;
  const resolved = ctx.registry.resolve(ref);
  if (resolved.status === 'resolved') return resolved.entry.uri;
  return typeof ref.path === 'string' && ctx.io.files()[ref.path] ? ref.path : null;
}

// ── Plano de exclusão ────────────────────────────────────────────────────────────────────────

/** O que a exclusão tocaria, SEM gravar nada: alimenta o diálogo (consumidores, contagem, substituição possível). */
export function planDeletion(ctx: ResourceOpsContext, uri: string): DeletionPlan {
  const files = ctx.io.files();
  const paths = collectDeleteTargets(files, uri);
  const resources: DeletionPlan['resources'] = [];
  for (const p of paths) {
    const entry = ctx.registry.getByUri(p);
    if (entry) resources.push({ id: entry.resourceId, uri: entry.uri, kind: entry.kind });
  }
  const graph = ctx.registry.graph;
  const report = graph.getRemovalReport(resources.map((r) => r.id));
  const toConsumer = (blockers: typeof report.blockers, editorOnly: boolean): DeletionConsumer[] =>
    blockers.flatMap((b) =>
      b.referrers.map((e) => ({
        resourceUri: b.uri,
        uri: graph.getNode(e.from)?.uri ?? e.from,
        kind: graph.getNode(e.from)?.kind ?? 'other',
        via: e.via,
        editorOnly,
      }))
    );
  const consumers = [...toConsumer(report.blockers, false), ...toConsumer(report.editorOnly, true)];
  const single = resources.length === 1 && !isFolderPath(uri) ? resources[0] : null;
  const active = ctx.activeScene?.();
  const plan: DeletionPlan = {
    uri,
    paths,
    resources,
    fileCount: paths.filter((p) => !files[p]?.isDirectory && !isFolderPath(p)).length,
    folderCount: paths.filter((p) => files[p]?.isDirectory || isFolderPath(p)).length,
    consumers,
    canReplace: !!single && REPLACEABLE_KINDS.has(single.kind),
    replaceKind: single?.kind,
  };
  if (active && paths.includes(active.path)) plan.blockedReason = 'A cena aberta não pode ser excluída. Abra outra cena antes.';
  return plan;
}

const identityOf = (r: { id: string; uri: string }): ResourceIdentity => ({ id: r.id, uri: r.uri });

function rewriteFile(file: FileLike, rules: JsonRewriteRules | null, textMoves: { from: string; to: string }[] | null): string | null {
  const content = file.content;
  if (typeof content !== 'string' || content.startsWith('data:')) return null;
  const isJson = file.path.toLowerCase().endsWith('.json');
  if (rules && isJson) {
    const r = rewriteJsonContent(content, file.path, rules);
    return r.changed ? r.content : null;
  }
  if (textMoves) {
    const r = replaceUrisInText(content, textMoves);
    return r.changed ? r.content : null;
  }
  return null;
}

// ── deleteResource ───────────────────────────────────────────────────────────────────────────

export async function deleteResourceWith(ctx: ResourceOpsContext, target: ResourceTarget, options: DeleteOptions = {}): Promise<DeleteResult> {
  const uri = resolveUri(ctx, target);
  const files = ctx.io.files();
  if (!uri || (!files[uri] && !Object.keys(files).some((p) => p.startsWith(uri) && isFolderPath(uri)))) {
    return { ok: false, status: 'not_found', message: 'O recurso não foi encontrado.' };
  }
  if (uri === 'res://') return { ok: false, status: 'blocked', message: 'A raiz res:// não pode ser excluída.' };
  const plan = planDeletion(ctx, uri);
  if (plan.blockedReason) return { ok: false, status: 'blocked', message: plan.blockedReason, plan };
  if (!options.confirmed) return { ok: false, status: 'needs_confirmation', message: 'A exclusão precisa de confirmação.', plan };
  if (plan.consumers.length > 0 && !options.decision) {
    return { ok: false, status: 'needs_decision', message: 'Este conteúdo está em uso: escolha manter as referências não resolvidas ou substituir por outro recurso.', plan };
  }

  // regras de reescrita dos consumidores
  let rules: JsonRewriteRules | null = null;
  let textMoves: { from: string; to: string }[] | null = null;
  if (plan.consumers.length > 0) {
    const decision = options.decision!;
    if (decision.kind === 'unresolve') {
      rules = unresolveRules(plan.resources.map(identityOf));
    } else {
      const replacement = ctx.registry.resolve(decision.with);
      const removed = new Set(plan.paths);
      if (!plan.canReplace) return { ok: false, status: 'invalid_replacement', message: 'Este tipo de recurso não pode ser substituído.', plan };
      if (replacement.status !== 'resolved' || removed.has(replacement.entry.uri)) {
        return { ok: false, status: 'invalid_replacement', message: 'O recurso escolhido para substituir não existe ou também está sendo excluído.', plan };
      }
      if (replacement.entry.kind !== plan.replaceKind) {
        return { ok: false, status: 'invalid_replacement', message: `A substituição precisa ser do mesmo tipo (${plan.replaceKind}).`, plan };
      }
      const old = plan.resources[0];
      rules = replaceRules(identityOf(old), { id: replacement.entry.resourceId, type: replacement.entry.kind, path: replacement.entry.uri, label: replacement.entry.uri.split('/').pop() });
      textMoves = [{ from: old.uri, to: replacement.entry.uri }];
    }
  }

  const removed = new Set(plan.paths);
  const active = ctx.activeScene?.();
  const upsert: Record<string, FileLike> = {};
  const deferred: DeferredRewrite[] = [];
  const consumerUris = [...new Set(plan.consumers.map((c) => c.uri))].filter((u) => !removed.has(u));
  const stamp = nowOf(ctx);
  for (const consumerUri of consumerUris) {
    const file = files[consumerUri];
    if (!file) continue;
    if (active && consumerUri === active.path) {
      // a cena aberta não é regravada por baixo: a reescrita vai para o estado em memória (fica "com alterações")
      deferred.push({ uri: consumerUri, rewrite: (content) => rewriteFile({ ...file, content }, rules, textMoves) ?? content });
      continue;
    }
    const next = rewriteFile(file, rules, textMoves);
    if (next !== null) upsert[consumerUri] = { ...file, content: next, size: next.length, updatedAt: stamp };
  }

  ctx.io.commit({ upsert, remove: plan.paths });
  return { ok: true, removed: plan.paths, rewritten: Object.keys(upsert), deferred, plan };
}

// ── moveResource ─────────────────────────────────────────────────────────────────────────────

/**
 * Move/renomeia `target` para o caminho `destination` (arquivo, ou pasta terminada em `/`). Preserva o `resourceId` de
 * todos os arquivos e reescreve, num único commit, as referências por caminho que apontavam para o que mudou.
 */
export async function moveResourceWith(ctx: ResourceOpsContext, target: ResourceTarget, destination: string, options: MoveOptions = {}): Promise<MoveResult> {
  const from = resolveUri(ctx, target);
  const files = ctx.io.files();
  if (!from) return { ok: false, status: 'not_found', message: 'O recurso não foi encontrado.' };
  const plan = planPathChange(files, from, destination);
  if (!plan.ok) {
    return { ok: false, status: plan.conflict ? 'conflict' : from === 'res://' ? 'blocked' : 'invalid', message: plan.error ?? 'Movimentação inválida.' };
  }
  const moves = plan.moves;
  const active = ctx.activeScene?.();
  const activeMoved = active ? moves.find(([a]) => a === active.path) : undefined;
  if (activeMoved && active!.dirty) {
    return { ok: false, status: 'blocked', message: 'A cena aberta tem alterações não salvas: salve antes de movê-la ou renomeá-la.' };
  }
  if (!options.confirmed) return { ok: false, status: 'needs_confirmation', message: 'A movimentação precisa de confirmação.', moves };

  const fileMoves = moves.filter(([a]) => !(files[a]?.isDirectory ?? isFolderPath(a)));
  const textMoves = fileMoves.map(([a, b]) => ({ from: a, to: b }));
  const movedSet = new Set(moves.map(([a]) => a));
  const graph = ctx.registry.graph;

  // quem referencia o que mudou (por id no grafo) + os próprios arquivos movidos (podem citar uns aos outros)
  const referrerUris = new Set<string>();
  for (const [a] of fileMoves) {
    const entry = ctx.registry.getByUri(a);
    if (!entry) continue;
    for (const e of graph.getReverse(entry.resourceId)) {
      const uri = graph.getNode(e.from)?.uri;
      if (uri) referrerUris.add(uri);
    }
  }
  for (const [a] of fileMoves) referrerUris.add(a);

  const stamp = nowOf(ctx);
  const upsert: Record<string, FileLike> = {};
  const deferred: DeferredRewrite[] = [];
  const rewritten: string[] = [];
  const contentFor = (file: FileLike): string | undefined => {
    const next = rewriteFile(file, null, textMoves);
    return next ?? undefined;
  };
  for (const uri of referrerUris) {
    const file = files[uri];
    if (!file || (active && uri === active.path && !movedSet.has(uri))) {
      if (file && active && uri === active.path) {
        deferred.push({ uri, rewrite: (content) => rewriteFile({ ...file, content }, null, textMoves) ?? content });
      }
      continue;
    }
    const next = contentFor(file);
    if (next === undefined) continue;
    const finalPath = remapPath(uri, moves);
    upsert[finalPath] = { ...file, path: finalPath, content: next, size: next.length, updatedAt: stamp };
    if (!movedSet.has(uri)) rewritten.push(uri);
  }
  // arquivos/pastas movidos: mesmo objeto (mesmo `resourceId`) em outro caminho
  for (const [a, b] of moves) {
    const file = files[a];
    const name = baseNameOf(b);
    if (!file) {
      upsert[b] = { path: b, name, isDirectory: true, updatedAt: stamp }; // pasta implícita
      continue;
    }
    const dot = name.lastIndexOf('.');
    const base = upsert[b] ?? file;
    upsert[b] = {
      ...base,
      path: b,
      name,
      ...(file.isDirectory ? {} : { extension: dot > 0 ? name.slice(dot + 1) : '' }),
      updatedAt: stamp,
    };
  }

  ctx.io.commit({ upsert, remove: moves.map(([a]) => a).filter((a) => !(a in upsert)), moves });
  return { ok: true, moves, rewritten, deferred, activeSceneMovedTo: activeMoved?.[1] };
}

// ── Pontos de entrada únicos (contexto real do editor) ───────────────────────────────────────

/** O que excluir tocaria (para o diálogo), sem gravar nada. */
export async function planResourceDeletion(target: ResourceTarget): Promise<DeletionPlan | null> {
  const g = await import('./resourceOpsGlobal');
  const ctx = g.defaultResourceContext();
  const uri = resolveUri(ctx, target);
  return uri ? planDeletion(ctx, uri) : null;
}

/** Exclui um recurso (ou pasta). Sem `confirmed`/`decision` devolve o plano e NÃO grava nada. */
export async function deleteResource(target: ResourceTarget, options: DeleteOptions = {}): Promise<DeleteResult> {
  const g = await import('./resourceOpsGlobal');
  const result = await deleteResourceWith(g.defaultResourceContext(), target, options);
  if (result.ok) g.applyActiveSceneEffects(result);
  return result;
}

/** Move/renomeia um recurso (ou pasta) para `destination`, preservando o `resourceId` e atualizando as referências. */
export async function moveResource(target: ResourceTarget, destination: string, options: MoveOptions = {}): Promise<MoveResult> {
  const g = await import('./resourceOpsGlobal');
  const result = await moveResourceWith(g.defaultResourceContext(), target, destination, options);
  if (result.ok) g.applyActiveSceneEffects(result);
  return result;
}
