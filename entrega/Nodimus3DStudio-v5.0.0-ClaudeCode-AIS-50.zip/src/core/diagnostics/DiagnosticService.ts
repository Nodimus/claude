/**
 * DiagnosticService (AIS-32c) — canal ÚNICO de diagnósticos do editor.
 *
 * Contrato `RuntimeDiagnostic`: dado puro e serializável (nunca referência viva a componente React/Three/Rapier).
 * Ownership e ciclo de vida:
 *  - **autoral** (sem `sessionId`): persiste enquanto a causa existir; é substituído ao revalidar o mesmo dono;
 *  - **efêmero** (com `sessionId`, ex.: `RuntimeSession`): `clearSession` o descarta no Stop, sem tocar nos autorais.
 * Identidade: `dono (source+sourceId) + code + alvo (recurso/uri/nó)`. Reportar de novo o mesmo problema atualiza o
 * existente (contador `occurrences`) em vez de empilhar cópias; revalidar um dono substitui o conjunto inteiro.
 * Painéis (Output, Asset Import, Play, Publish) consomem este serviço por **filtros**; nenhum mantém formato próprio.
 * Sem dependência de React/DOM. Assinaturas devolvem disposer (AIS-48b).
 */
import type { ResourceRef } from '../../types/node';

export type DiagnosticSeverity = 'info' | 'warning' | 'error' | 'blocking';

/** Fases conhecidas; outras são aceitas (extensível). */
export type KnownDiagnosticPhase = 'editor' | 'import' | 'serialization' | 'runtime' | 'physics' | 'script' | 'publish';
export type DiagnosticPhase = KnownDiagnosticPhase | (string & {});

const SEVERITY_RANK: Record<DiagnosticSeverity, number> = { info: 0, warning: 1, error: 2, blocking: 3 };
export const compareSeverity = (a: DiagnosticSeverity, b: DiagnosticSeverity): number => SEVERITY_RANK[a] - SEVERITY_RANK[b];

/** Correção opcional, só como DADO: o executor é registrado por `registerFixHandler(fixId, …)`. */
export interface DiagnosticFix {
  fixId: string;
  label: string;
  /** Só correções seguras (idempotentes, reversíveis quando autorais) podem ser oferecidas. */
  safe: true;
  params?: Record<string, unknown>;
}

export interface RuntimeDiagnostic {
  id: string;
  /** Quem publicou (`assetPipeline`, `scene`, `logicRegistry`, `assetImport`, `runtime`…). */
  source: string;
  sourceId?: string;
  severity: DiagnosticSeverity;
  phase: DiagnosticPhase;
  /** Código estável (`texture.invalid_data_url`, `scene.node_corrupted`…). */
  code: string;
  message: string;
  resourceRef?: ResourceRef;
  uri?: string;
  nodeId?: string;
  instanceId?: string;
  behaviorId?: string;
  /** ID da pasta em `src/logic/`. */
  logicId?: string;
  /** Presente ⇒ diagnóstico efêmero vinculado a uma `RuntimeSession`. */
  sessionId?: string;
  timestamp: number;
  /** Quantas vezes o mesmo problema foi reportado (sem duplicar o item). */
  occurrences: number;
  fix?: DiagnosticFix;
}

export type DiagnosticInput = Omit<RuntimeDiagnostic, 'id' | 'timestamp' | 'occurrences'> & { timestamp?: number };

export interface DiagnosticOwner {
  source: string;
  sourceId?: string;
}

export interface DiagnosticFilter {
  source?: string;
  sourceId?: string;
  phase?: DiagnosticPhase | readonly DiagnosticPhase[];
  /** Exatamente esta severidade. */
  severity?: DiagnosticSeverity;
  /** Esta severidade ou mais grave. */
  minSeverity?: DiagnosticSeverity;
  code?: string;
  sessionId?: string;
  /** `true` = só efêmeros; `false` = só autorais. */
  ephemeral?: boolean;
  resourceId?: string;
  uri?: string;
  nodeId?: string;
}

export type ReportStatus = 'created' | 'updated' | 'repeated';

export type DiagnosticEvent =
  | { kind: 'reported'; diagnostic: RuntimeDiagnostic; status: ReportStatus; announce: boolean }
  | { kind: 'cleared'; ids: string[] };

export interface BlockingResult {
  blocked: boolean;
  /** Motivo legível (primeiro bloqueio) ou `undefined`. */
  reason?: string;
  reasons: RuntimeDiagnostic[];
}

export type FixResult = { ok: true } | { ok: false; error: string };
export type FixHandler = (diagnostic: RuntimeDiagnostic) => void | Promise<void>;

const MAX_ENTRIES = 1000;

const targetOf = (d: Pick<RuntimeDiagnostic, 'resourceRef' | 'uri' | 'nodeId' | 'instanceId' | 'behaviorId' | 'logicId'>): string =>
  d.resourceRef?.id ?? d.uri ?? d.nodeId ?? d.instanceId ?? d.behaviorId ?? d.logicId ?? '';

/** Chave de identidade: dono + fase de sessão + código + alvo. */
export function diagnosticKey(d: Pick<DiagnosticInput, 'source' | 'sourceId' | 'sessionId' | 'code' | 'resourceRef' | 'uri' | 'nodeId' | 'instanceId' | 'behaviorId' | 'logicId'>): string {
  return [d.source, d.sourceId ?? '', d.sessionId ?? '', d.code, targetOf(d)].join('|');
}

const matches = (d: RuntimeDiagnostic, f: DiagnosticFilter): boolean => {
  if (f.source !== undefined && d.source !== f.source) return false;
  if (f.sourceId !== undefined && d.sourceId !== f.sourceId) return false;
  if (f.phase !== undefined) {
    const phases = Array.isArray(f.phase) ? (f.phase as readonly DiagnosticPhase[]) : [f.phase as DiagnosticPhase];
    if (!phases.includes(d.phase)) return false;
  }
  if (f.severity !== undefined && d.severity !== f.severity) return false;
  if (f.minSeverity !== undefined && compareSeverity(d.severity, f.minSeverity) < 0) return false;
  if (f.code !== undefined && d.code !== f.code) return false;
  if (f.sessionId !== undefined && d.sessionId !== f.sessionId) return false;
  if (f.ephemeral !== undefined && (d.sessionId !== undefined) !== f.ephemeral) return false;
  if (f.resourceId !== undefined && d.resourceRef?.id !== f.resourceId) return false;
  if (f.uri !== undefined && d.uri !== f.uri) return false;
  if (f.nodeId !== undefined && d.nodeId !== f.nodeId) return false;
  return true;
};

let idCounter = 0;
const newId = () => `diag_${Date.now().toString(36)}_${(++idCounter).toString(36)}`;

export class DiagnosticService {
  private byKey = new Map<string, RuntimeDiagnostic>();
  private handlers = new Map<string, FixHandler>();
  private listeners = new Set<() => void>();
  private eventListeners = new Set<(event: DiagnosticEvent) => void>();
  private version = 0;
  private cache: { version: number; list: readonly RuntimeDiagnostic[] } = { version: -1, list: [] };
  private now: () => number;

  constructor(now: () => number = Date.now) {
    this.now = now;
  }

  // ── Publicação ─────────────────────────────────────────────────────────────
  /**
   * Publica (ou atualiza) um diagnóstico. O mesmo problema (dono + código + alvo) NUNCA vira duas entradas:
   * `created` (novo), `updated` (mensagem/severidade mudou) ou `repeated` (equivalente; só soma `occurrences`).
   */
  report(input: DiagnosticInput, options: { announce?: boolean } = {}): RuntimeDiagnostic {
    const key = diagnosticKey(input);
    const previous = this.byKey.get(key);
    const timestamp = input.timestamp ?? this.now();
    let status: ReportStatus;
    let next: RuntimeDiagnostic;
    if (!previous) {
      next = { ...input, id: newId(), timestamp, occurrences: 1 };
      status = 'created';
    } else {
      const changed = previous.message !== input.message || previous.severity !== input.severity || previous.phase !== input.phase;
      next = { ...previous, ...input, id: previous.id, timestamp, occurrences: previous.occurrences + 1 };
      status = changed ? 'updated' : 'repeated';
    }
    this.byKey.set(key, next);
    this.trim();
    this.bump();
    this.emit({ kind: 'reported', diagnostic: next, status, announce: options.announce ?? true });
    return next;
  }

  /**
   * Revalidação de um dono: o conjunto novo SUBSTITUI o anterior do mesmo dono (o que deixou de valer some; o que
   * continua vale não duplica). `announce: 'changes'` (padrão) só avisa o que é novo ou mudou; `'all'` avisa tudo
   * (ação explícita do usuário, ex.: abrir a cena); `'none'` é silencioso.
   */
  replaceForOwner(owner: DiagnosticOwner, inputs: readonly DiagnosticInput[], options: { announce?: 'changes' | 'all' | 'none'; phase?: DiagnosticPhase | readonly DiagnosticPhase[] } = {}): RuntimeDiagnostic[] {
    const mode = options.announce ?? 'changes';
    const scope: DiagnosticFilter = { source: owner.source, sourceId: owner.sourceId, phase: options.phase, ephemeral: false };
    const keep = new Set(inputs.map((i) => diagnosticKey({ ...i, source: owner.source, sourceId: owner.sourceId })));
    const removed: string[] = [];
    for (const [key, d] of [...this.byKey]) {
      if (matches(d, scope) && !keep.has(key)) {
        this.byKey.delete(key);
        removed.push(d.id);
      }
    }
    if (removed.length) {
      this.bump();
      this.emit({ kind: 'cleared', ids: removed });
    }
    return inputs.map((i) => {
      const input = { ...i, source: owner.source, sourceId: owner.sourceId };
      const previous = this.byKey.get(diagnosticKey(input));
      const announce = mode === 'none' ? false : mode === 'all' ? true : !previous || previous.message !== input.message || previous.severity !== input.severity;
      return this.report(input, { announce });
    });
  }

  // ── Limpeza ────────────────────────────────────────────────────────────────
  clear(filter: DiagnosticFilter = {}): number {
    const ids: string[] = [];
    for (const [key, d] of [...this.byKey]) {
      if (matches(d, filter)) {
        this.byKey.delete(key);
        ids.push(d.id);
      }
    }
    if (ids.length) {
      this.bump();
      this.emit({ kind: 'cleared', ids });
    }
    return ids.length;
  }

  /** Stop da sessão: descarta os diagnósticos efêmeros dela e NÃO toca nos autorais (nem nos de outras sessões). */
  clearSession(sessionId: string): number {
    return this.clear({ sessionId });
  }

  // ── Consulta ───────────────────────────────────────────────────────────────
  /** Lista (referência estável enquanto nada muda), ordenada do mais grave ao mais leve e depois por tempo. */
  list(filter?: DiagnosticFilter): readonly RuntimeDiagnostic[] {
    if (this.cache.version !== this.version) {
      const all = [...this.byKey.values()].sort((a, b) => compareSeverity(b.severity, a.severity) || a.timestamp - b.timestamp);
      this.cache = { version: this.version, list: all };
    }
    if (!filter || Object.keys(filter).length === 0) return this.cache.list;
    return this.cache.list.filter((d) => matches(d, filter));
  }

  get(id: string): RuntimeDiagnostic | undefined {
    for (const d of this.byKey.values()) if (d.id === id) return d;
    return undefined;
  }

  count(filter?: DiagnosticFilter): number {
    return this.list(filter).length;
  }

  /**
   * "Isto impede o Play/Publish?": há diagnóstico `blocking` no escopo do filtro. Devolve o motivo identificável.
   * O bloqueio efetivo é ligado pelo Play (AIS-44c) e pelo Publish (AIS-85b); aqui só existe a consulta.
   */
  hasBlocking(filter: DiagnosticFilter = {}): BlockingResult {
    const reasons = this.list({ ...filter, severity: 'blocking' });
    return reasons.length
      ? { blocked: true, reason: `[${reasons[0].code}] ${reasons[0].message}`, reasons: [...reasons] }
      : { blocked: false, reasons: [] };
  }

  // ── Correções (dado + executor registrado) ────────────────────────────────
  /** Registra o executor de uma correção. O executor é responsável por passar pelo CommandManager e ser idempotente. */
  registerFixHandler(fixId: string, handler: FixHandler): () => void {
    this.handlers.set(fixId, handler);
    return () => {
      if (this.handlers.get(fixId) === handler) this.handlers.delete(fixId);
    };
  }

  async applyFix(id: string): Promise<FixResult> {
    const d = this.get(id);
    if (!d) return { ok: false, error: 'Diagnóstico não encontrado (já resolvido?).' };
    if (!d.fix) return { ok: false, error: 'Este diagnóstico não tem correção.' };
    const handler = this.handlers.get(d.fix.fixId);
    if (!handler) return { ok: false, error: `Sem executor para a correção "${d.fix.fixId}".` };
    try {
      await handler(d);
      return { ok: true };
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : String(error) };
    }
  }

  // ── Assinaturas (disposer) ────────────────────────────────────────────────
  /** Muda a lista (para `useSyncExternalStore`). */
  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  /** Eventos individuais (o console do editor imprime só o que é novo/mudou). */
  subscribeEvents(listener: (event: DiagnosticEvent) => void): () => void {
    this.eventListeners.add(listener);
    return () => {
      this.eventListeners.delete(listener);
    };
  }

  getVersion(): number {
    return this.version;
  }

  // ── Interno ────────────────────────────────────────────────────────────────
  private bump() {
    this.version++;
    for (const l of [...this.listeners]) l();
  }

  private emit(event: DiagnosticEvent) {
    for (const l of [...this.eventListeners]) l(event);
  }

  /** Teto de memória: descarta os mais antigos de severidade `info`, depois `warning`. */
  private trim() {
    if (this.byKey.size <= MAX_ENTRIES) return;
    for (const severity of ['info', 'warning'] as const) {
      const victims = [...this.byKey].filter(([, d]) => d.severity === severity).sort((a, b) => a[1].timestamp - b[1].timestamp);
      for (const [key] of victims) {
        if (this.byKey.size <= MAX_ENTRIES) return;
        this.byKey.delete(key);
      }
    }
  }
}
