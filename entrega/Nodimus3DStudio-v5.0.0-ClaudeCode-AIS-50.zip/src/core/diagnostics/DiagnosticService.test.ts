import { describe, expect, it, vi } from 'vitest';
import { DiagnosticService, diagnosticKey, type DiagnosticEvent, type DiagnosticInput } from './DiagnosticService';
import { consoleTypeOf, formatDiagnosticLine, fromLogicRegistryDiagnostics, fromResourceDiagnostic, fromSceneDiagnostics, missingNodesDiagnostic } from './adapters';

const input = (over: Partial<DiagnosticInput> = {}): DiagnosticInput => ({
  source: 'assetPipeline',
  severity: 'error',
  phase: 'import',
  code: 'texture.invalid_data_url',
  message: 'imagem inválida',
  uri: 'res://textures/a.png',
  ...over,
});

describe('representação única (AIS-32c-C01)', () => {
  it('o mesmo problema reportado várias vezes é UMA entrada, com contagem', () => {
    const s = new DiagnosticService();
    const a = s.report(input());
    const b = s.report(input());
    expect(s.list()).toHaveLength(1);
    expect(b.id).toBe(a.id);
    expect(b.occurrences).toBe(2);
  });
  it('alvos ou códigos diferentes são entradas diferentes', () => {
    const s = new DiagnosticService();
    s.report(input());
    s.report(input({ uri: 'res://textures/b.png' }));
    s.report(input({ code: 'texture.missing' }));
    expect(s.list()).toHaveLength(3);
  });
  it('é dado puro e serializável (sem referências vivas)', () => {
    const s = new DiagnosticService();
    s.report(input({ fix: { fixId: 'x', label: 'Corrigir', safe: true, params: { n: 1 } }, resourceRef: { id: 'r1', path: 'res://a' } }));
    const copy = JSON.parse(JSON.stringify(s.list()));
    expect(copy).toEqual(JSON.parse(JSON.stringify(s.list())));
    expect(typeof JSON.stringify(s.list()[0].fix)).toBe('string');
  });
  it('vários painéis leem o mesmo item por filtros', () => {
    const s = new DiagnosticService();
    s.report(input());
    s.report(input({ source: 'scene', sourceId: 'res://scenes/Main.scene.json', phase: 'serialization', severity: 'warning', code: 'scene.orphan_reattached', uri: undefined, nodeId: 'n1' }));
    s.report(input({ source: 'logicRegistry', phase: 'editor', code: 'logic.invalid_definition', uri: 'src/logic/x', logicId: 'x' }));
    expect(s.list({ phase: 'import' }).map((d) => d.code)).toEqual(['texture.invalid_data_url']);
    expect(s.list({ phase: ['import', 'serialization'] })).toHaveLength(2);
    expect(s.list({ source: 'scene', sourceId: 'res://scenes/Main.scene.json' })).toHaveLength(1);
    expect(s.list({ minSeverity: 'error' })).toHaveLength(2);
    expect(s.list({ nodeId: 'n1' })).toHaveLength(1);
    expect(s.list({ uri: 'res://textures/a.png' })).toHaveLength(1);
    expect(s.count({ code: 'logic.invalid_definition' })).toBe(1);
  });
  it('lista ordenada do mais grave ao mais leve, com referência estável sem mudanças', () => {
    const s = new DiagnosticService();
    s.report(input({ code: 'a', severity: 'info', uri: '1' }));
    s.report(input({ code: 'b', severity: 'blocking', uri: '2' }));
    s.report(input({ code: 'c', severity: 'warning', uri: '3' }));
    expect(s.list().map((d) => d.severity)).toEqual(['blocking', 'warning', 'info']);
    expect(s.list()).toBe(s.list());
  });
  it('a chave de identidade inclui dono, sessão, código e alvo', () => {
    expect(diagnosticKey(input())).not.toBe(diagnosticKey(input({ sessionId: 's1' })));
    expect(diagnosticKey(input())).toBe(diagnosticKey(input()));
  });
});

describe('sessão de runtime (AIS-32c-C02, com sessão simulada)', () => {
  it('Stop descarta só os efêmeros da sessão e mantém autorais e de outras sessões', () => {
    const s = new DiagnosticService();
    s.report(input({ source: 'assetPipeline' })); // autoral
    s.report(input({ source: 'runtime', phase: 'runtime', code: 'rt.a', sessionId: 'S1', uri: undefined }));
    s.report(input({ source: 'runtime', phase: 'runtime', code: 'rt.b', sessionId: 'S1', uri: undefined, instanceId: 'i1' }));
    s.report(input({ source: 'runtime', phase: 'runtime', code: 'rt.c', sessionId: 'S2', uri: undefined }));
    expect(s.list({ ephemeral: true })).toHaveLength(3);
    expect(s.clearSession('S1')).toBe(2);
    expect(s.list({ sessionId: 'S1' })).toHaveLength(0);
    expect(s.list({ ephemeral: true }).map((d) => d.code)).toEqual(['rt.c']);
    expect(s.list({ ephemeral: false })).toHaveLength(1);
  });
  it('revalidar um dono autoral não apaga os efêmeros', () => {
    const s = new DiagnosticService();
    s.report(input({ source: 'x', sessionId: 'S1', code: 'rt', uri: undefined }));
    s.replaceForOwner({ source: 'x' }, []);
    expect(s.list({ sessionId: 'S1' })).toHaveLength(1);
  });
});

describe('revalidação (AIS-32c-C03)', () => {
  it('substitui o conjunto do dono: o que continua não duplica e o que foi resolvido some', () => {
    const s = new DiagnosticService();
    const owner = { source: 'scene', sourceId: 'res://scenes/A.scene.json' };
    s.replaceForOwner(owner, [input({ ...owner, code: 'c1', uri: 'u1' }), input({ ...owner, code: 'c2', uri: 'u2' })]);
    expect(s.list()).toHaveLength(2);
    s.replaceForOwner(owner, [input({ ...owner, code: 'c1', uri: 'u1' })]);
    expect(s.list().map((d) => d.code)).toEqual(['c1']);
    s.replaceForOwner(owner, [input({ ...owner, code: 'c1', uri: 'u1' })]);
    s.replaceForOwner(owner, [input({ ...owner, code: 'c1', uri: 'u1' })]);
    expect(s.list()).toHaveLength(1);
  });
  it('não toca nos diagnósticos de outros donos', () => {
    const s = new DiagnosticService();
    s.report(input({ source: 'a', code: 'x' }));
    s.replaceForOwner({ source: 'b' }, [input({ source: 'b', code: 'y' })]);
    s.replaceForOwner({ source: 'b' }, []);
    expect(s.list().map((d) => d.source)).toEqual(['a']);
  });
  it('anuncia só o que é novo ou mudou (ou tudo/nada, conforme o modo)', () => {
    const s = new DiagnosticService();
    const events: DiagnosticEvent[] = [];
    s.subscribeEvents((e) => events.push(e));
    const owner = { source: 'o' };
    const set = [input({ source: 'o', code: 'k', uri: 'u' })];
    s.replaceForOwner(owner, set);
    s.replaceForOwner(owner, set);
    const announced = () => events.filter((e) => e.kind === 'reported' && e.announce).length;
    expect(announced()).toBe(1);
    s.replaceForOwner(owner, set, { announce: 'all' });
    expect(announced()).toBe(2);
    s.replaceForOwner(owner, [{ ...set[0], message: 'outra' }]);
    expect(announced()).toBe(3);
    s.replaceForOwner(owner, [{ ...set[0], message: 'silêncio' }], { announce: 'none' });
    expect(announced()).toBe(3);
  });
  it('report reporta o status created / updated / repeated', () => {
    const s = new DiagnosticService();
    const statuses: string[] = [];
    s.subscribeEvents((e) => e.kind === 'reported' && statuses.push(e.status));
    s.report(input());
    s.report(input());
    s.report(input({ message: 'nova mensagem' }));
    expect(statuses).toEqual(['created', 'repeated', 'updated']);
  });
});

describe('bloqueio (AIS-32c-C04, por consulta)', () => {
  it('hasBlocking devolve o motivo identificável e respeita o filtro', () => {
    const s = new DiagnosticService();
    expect(s.hasBlocking()).toEqual({ blocked: false, reasons: [] });
    s.report(input({ severity: 'error' }));
    expect(s.hasBlocking().blocked).toBe(false);
    s.report(input({ severity: 'blocking', phase: 'publish', source: 'publish', code: 'publish.missing_scene', message: 'Sem cena inicial', uri: undefined }));
    const r = s.hasBlocking();
    expect(r.blocked).toBe(true);
    expect(r.reason).toBe('[publish.missing_scene] Sem cena inicial');
    expect(s.hasBlocking({ phase: 'import' }).blocked).toBe(false);
    expect(s.hasBlocking({ phase: 'publish' }).blocked).toBe(true);
  });
  it('some quando o problema é resolvido', () => {
    const s = new DiagnosticService();
    s.report(input({ severity: 'blocking', source: 'p', code: 'b' }));
    s.clear({ source: 'p' });
    expect(s.hasBlocking().blocked).toBe(false);
  });
});

describe('correções (dado + executor registrado)', () => {
  it('aplica pelo executor registrado e informa falhas sem lançar', async () => {
    const s = new DiagnosticService();
    const d = s.report(input({ fix: { fixId: 'fx', label: 'Corrigir', safe: true } }));
    expect(await s.applyFix(d.id)).toEqual({ ok: false, error: 'Sem executor para a correção "fx".' });
    const handler = vi.fn();
    const off = s.registerFixHandler('fx', handler);
    expect(await s.applyFix(d.id)).toEqual({ ok: true });
    expect(handler).toHaveBeenCalledWith(expect.objectContaining({ id: d.id }));
    off();
    s.registerFixHandler('fx', () => {
      throw new Error('falhou');
    });
    expect(await s.applyFix(d.id)).toEqual({ ok: false, error: 'falhou' });
    expect(await s.applyFix('inexistente')).toMatchObject({ ok: false });
    const semFix = s.report(input({ code: 'sem.fix', uri: 'x' }));
    expect(await s.applyFix(semFix.id)).toMatchObject({ ok: false });
  });
});

describe('assinaturas com disposer (AIS-48b)', () => {
  it('subscribe/subscribeEvents devolvem disposer e a versão muda só quando algo muda', () => {
    const s = new DiagnosticService();
    const l = vi.fn();
    const e = vi.fn();
    const off = s.subscribe(l);
    const offE = s.subscribeEvents(e);
    s.report(input());
    expect(l).toHaveBeenCalledTimes(1);
    expect(e).toHaveBeenCalledTimes(1);
    const v = s.getVersion();
    s.clear({ source: 'inexistente' });
    expect(s.getVersion()).toBe(v);
    off();
    offE();
    s.report(input({ code: 'outro' }));
    expect(l).toHaveBeenCalledTimes(1);
    expect(e).toHaveBeenCalledTimes(1);
  });
});

describe('adapters', () => {
  it('ResourceDiagnostic → fase import com referência', () => {
    const d = fromResourceDiagnostic({ code: 'texture.missing', severity: 'warning', message: 'm', uri: 'res://textures/x.png', resourceId: 'r1' });
    expect(d).toMatchObject({ source: 'assetPipeline', phase: 'import', severity: 'warning', uri: 'res://textures/x.png', resourceRef: { id: 'r1' } });
  });
  it('cena: ignora info (como o console antigo) e inclui o aviso de Missing Node', () => {
    const list = fromSceneDiagnostics('res://scenes/A.scene.json', [
      { code: 'scene.migrated', severity: 'info', message: 'migrada' },
      { code: 'scene.node_corrupted', severity: 'warning', message: 'nó ruim', nodeId: 'n1' },
    ]);
    expect(list).toHaveLength(1);
    expect(list[0]).toMatchObject({ source: 'scene', sourceId: 'res://scenes/A.scene.json', phase: 'serialization', nodeId: 'n1' });
    expect(missingNodesDiagnostic('p', null)).toEqual([]);
    expect(missingNodesDiagnostic('p', '2 nó(s)')[0]).toMatchObject({ code: 'scene.missing_nodes', severity: 'warning' });
  });
  it('LogicRegistry → erro com logicId da pasta', () => {
    const [d] = fromLogicRegistryDiagnostics([{ kind: 'action', path: '/src/logic/actions/foo/index.ts', message: 'sem export default' }]);
    expect(d).toMatchObject({ source: 'logicRegistry', severity: 'error', code: 'logic.invalid_definition', logicId: 'foo' });
  });
  it('severidade → tipo de linha e formato [código] mensagem', () => {
    expect(consoleTypeOf('blocking')).toBe('error');
    expect(consoleTypeOf('error')).toBe('error');
    expect(consoleTypeOf('warning')).toBe('warn');
    expect(consoleTypeOf('info')).toBe('log');
    expect(formatDiagnosticLine({ code: 'a.b', message: 'm' })).toBe('[a.b] m');
  });
});
