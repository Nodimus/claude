/**
 * Conversões de formatos de origem para `RuntimeDiagnostic` (AIS-32c). Os publicadores (AssetPipeline, parser de
 * cenas, LogicRegistry…) não conhecem o serviço: só estas funções puras fazem a ponte. Nenhum formato paralelo.
 */
import type { LogicRegistryDiagnostic } from '../../logic/registry';
import type { SceneDiagnostic } from '../serialization/sceneSerializer';
import type { ResourceDiagnostic } from '../resources/ResourceRegistry';
import type { DiagnosticInput, DiagnosticSeverity } from './DiagnosticService';

/** Tipo de linha do console (`BottomPanel`) para uma severidade. */
export function consoleTypeOf(severity: DiagnosticSeverity): 'log' | 'warn' | 'error' {
  return severity === 'error' || severity === 'blocking' ? 'error' : severity === 'warning' ? 'warn' : 'log';
}

/** Linha do console: `[código] mensagem` (o mesmo formato que o console já usava). */
export const formatDiagnosticLine = (d: { code: string; message: string }): string => `[${d.code}] ${d.message}`;

/** Diagnóstico do `ResourceRegistry`/`AssetPipeline` (fase `import`). */
export function fromResourceDiagnostic(d: ResourceDiagnostic): DiagnosticInput {
  return {
    source: 'assetPipeline',
    severity: d.severity,
    phase: 'import',
    code: d.code,
    message: d.message,
    uri: d.uri,
    resourceRef: d.resourceId ? { id: d.resourceId, path: d.uri } : undefined,
  };
}

/** Diagnósticos do parser de cena (fase `serialization`); `info` (migração etc.) não é publicado, como no console antigo. */
export function fromSceneDiagnostics(scenePath: string, diagnostics: readonly SceneDiagnostic[]): DiagnosticInput[] {
  return diagnostics
    .filter((d) => d.severity !== 'info')
    .map((d) => ({
      source: 'scene',
      sourceId: scenePath,
      severity: d.severity,
      phase: 'serialization',
      code: d.code,
      message: d.message,
      uri: scenePath,
      nodeId: d.nodeId,
    }));
}

/** Nós de tipo desconhecido preservados como Missing Node (mensagem já montada por `missingNodesWarning`). */
export function missingNodesDiagnostic(scenePath: string, message: string | null): DiagnosticInput[] {
  return message
    ? [{ source: 'scene', sourceId: scenePath, severity: 'warning', phase: 'serialization', code: 'scene.missing_nodes', message, uri: scenePath }]
    : [];
}

/**
 * AIS-45 (`physics.legacy_unconverted`): restos de física legada que `convertLegacyPhysics` não converteu (preservados como Missing
 * Node, sem efeito no Play). Um item por cena; `[]` quando não sobrou legado. Publicado com `replaceForOwner` (reabrir a mesma
 * cena não duplica: o item é o mesmo e `occurrences` sobe).
 */
export function legacyPhysicsDiagnostic(scenePath: string, message: string | null): DiagnosticInput[] {
  if (!message) return [];
  return [{ source: 'physics', sourceId: scenePath, severity: 'warning', phase: 'serialization', code: 'physics.legacy_unconverted', message: message.replace(/^physics.legacy_unconverted:s*/, ''), uri: scenePath }];
}

/** Definição inválida do catálogo de lógica (`src/logic/`). */
export function fromLogicRegistryDiagnostics(items: readonly LogicRegistryDiagnostic[]): DiagnosticInput[] {
  return items.map((d) => ({
    source: 'logicRegistry',
    severity: 'error' as const,
    phase: 'editor',
    code: 'logic.invalid_definition',
    message: `${d.kind} inválido (${d.path}): ${d.message}`,
    uri: d.path,
    logicId: d.path.split('/').slice(-2, -1)[0],
  }));
}

