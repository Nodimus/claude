import { DiagnosticService, type DiagnosticFilter, type RuntimeDiagnostic } from './DiagnosticService';
import { fromLogicRegistryDiagnostics, fromResourceDiagnostic } from './adapters';
import { globalAssetPipeline } from '../resources/global';
import { LogicRegistry } from '../../logic/registry';

/** Instância única do editor (AIS-32c). Painéis consomem por filtro; ninguém mantém lista própria de erros. */
export const globalDiagnosticService = new DiagnosticService();

let wired = false;

/**
 * Liga os publicadores existentes ao serviço (idempotente): o adapter provisório do `AssetPipeline` (AIS-28c) passa a
 * delegar aqui, e as definições inválidas do `LogicRegistry` são publicadas. Chamado por `bindEditorServices`.
 */
export function wireDiagnosticPublishers(): () => void {
  if (wired) return () => {};
  wired = true;
  globalAssetPipeline.setDiagnosticSink((d) => {
    globalDiagnosticService.report(fromResourceDiagnostic(d));
  });
  globalDiagnosticService.replaceForOwner({ source: 'logicRegistry' }, fromLogicRegistryDiagnostics(LogicRegistry.diagnostics), { announce: 'all' });
  return () => {
    wired = false;
    globalAssetPipeline.setDiagnosticSink(null);
  };
}

export type { DiagnosticFilter, RuntimeDiagnostic };
