import { useMemo, useSyncExternalStore } from 'react';
import { globalDiagnosticService } from './global';
import type { DiagnosticFilter, RuntimeDiagnostic } from './DiagnosticService';

/** Hook para painéis (Output, Asset Import, Play, Publish): lê o serviço único por filtro. */
export function useDiagnostics(filter?: DiagnosticFilter): readonly RuntimeDiagnostic[] {
  const version = useSyncExternalStore(
    (listener) => globalDiagnosticService.subscribe(listener),
    () => globalDiagnosticService.getVersion(),
    () => 0
  );
  const key = filter ? JSON.stringify(filter) : '';
  // eslint-disable-next-line react-hooks/exhaustive-deps
  return useMemo(() => globalDiagnosticService.list(filter), [version, key]);
}
