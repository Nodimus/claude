import { missingNodesWarning } from '../../schemas';
import type { SceneDiagnostic } from '../serialization/sceneSerializer';
import { legacyPhysicsWarning } from '../../schemas/legacyPhysics';
import { fromSceneDiagnostics, legacyPhysicsDiagnostic, missingNodesDiagnostic } from './adapters';
import { globalDiagnosticService } from './global';

/**
 * Publica no serviço os achados de LER uma cena (parser + Missing Nodes). Reabrir/recarregar a mesma cena SUBSTITUI o
 * conjunto anterior desse dono (sem acumular). `announce: 'all'` = o usuário abriu a cena, o console reavisa;
 * `'none'` = silencioso (estado inicial).
 */
export function publishSceneDiagnostics(
  scenePath: string,
  diagnostics: readonly SceneDiagnostic[],
  nodes: Record<string, { type: string; properties?: Record<string, any> }> | undefined,
  announce: 'all' | 'none' = 'all'
): void {
  globalDiagnosticService.replaceForOwner(
    { source: 'scene', sourceId: scenePath },
    [...fromSceneDiagnostics(scenePath, diagnostics), ...missingNodesDiagnostic(scenePath, missingNodesWarning(nodes))],
    { announce }
  );
  // AIS-45: restos de física legada, como diagnóstico próprio da cena (fonte `physics`)
  globalDiagnosticService.replaceForOwner({ source: 'physics', sourceId: scenePath }, legacyPhysicsDiagnostic(scenePath, legacyPhysicsWarning(nodes)), { announce });
}
