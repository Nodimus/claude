import { z } from 'zod';

export type ThemeBase = 'dark' | 'light';

export interface EditorThemeDef {
  schemaVersion: 1;
  id: string;
  name: string;
  base: ThemeBase;
  builtin?: boolean;
  tokens: Record<string, string>;
}

export const EditorThemeDefSchema = z.object({
  schemaVersion: z.literal(1),
  id: z.string(),
  name: z.string(),
  base: z.enum(['dark', 'light']),
  builtin: z.boolean().optional(),
  tokens: z.record(z.string(), z.string()),
});

/**
 * Built-in Dark Theme tokens (Godot 3.x dark density palette)
 * These values are identical to the CSS :root values in index.css.
 */
export const DARK_TOKENS: Record<string, string> = {
  '--gl-bg': '#181c24',
  '--gl-panel': '#202531',
  '--gl-bg-strong': '#202531',
  '--gl-panel-alt': '#2d2d30',
  '--gl-border': '#2c3345',
  '--gl-border-subtle': '#2d2d30',
  '--gl-row-divider': '#252b38',
  '--gl-hover-bg': '#2a3140',
  '--gl-hover-border': '#3f4a62',
  '--gl-accent': '#4982ea',
  '--gl-accent-bg': '#323b4e',
  '--gl-accent-border': '#4982ea',
  '--gl-input-bg': '#2d2d30',
  '--gl-input-border': '#3a4459',
  '--gl-text': '#dfe4ec',
  '--gl-text-muted': '#8b97a8',
  '--gl-text-disabled': '#555555',
  '--gl-danger-bg': '#442727',
  '--gl-danger-border': '#6a3434',
  '--gl-danger-text': '#f08080',
  '--gl-tag-bg': '#223e2a',
  '--gl-overlay': 'rgba(0, 0, 0, 0.65)',
  '--gl-font-size-base': '13px',

  // Behavior category tokens
  '--gl-cat-movement': '#5eead4',
  '--gl-cat-movement-bg': '#123734',
  '--gl-cat-physics': '#fbbf24',
  '--gl-cat-physics-bg': '#3a2e11',
  '--gl-cat-interaction': '#c4b5fd',
  '--gl-cat-interaction-bg': '#2c2350',
  '--gl-cat-ai': '#f472b6',
  '--gl-cat-ai-bg': '#3a1a2b',
  '--gl-cat-camera': '#38bdf8',
  '--gl-cat-camera-bg': '#0f2e3d',
  '--gl-cat-utility': '#94a3b8',
  '--gl-cat-utility-bg': '#2a2f36',
  '--gl-cat-custom': '#9ca3af',
  '--gl-cat-custom-bg': '#2a2c30',
};

/**
 * Light Seed (NOT CSS):
 * Initial template copied when a user creates a new light theme in Preferences (AIS-82).
 */
export const LIGHT_SEED: Record<string, string> = {
  '--gl-bg': '#f0f0f0',
  '--gl-panel': '#f5f5f5',
  '--gl-bg-strong': '#e8e8e8',
  '--gl-panel-alt': '#e8e8e8',
  '--gl-border': '#a0a0a0',
  '--gl-border-subtle': '#d0d0d0',
  '--gl-row-divider': '#e0e0e0',
  '--gl-hover-bg': '#e0e0e0',
  '--gl-hover-border': '#b5b5b5',
  '--gl-accent': '#0078d7',
  '--gl-accent-bg': '#cce8ff',
  '--gl-accent-border': '#99d1ff',
  '--gl-input-bg': '#ffffff',
  '--gl-input-border': '#7f9db9',
  '--gl-text': '#202225',
  '--gl-text-muted': '#6b6f76',
  '--gl-text-disabled': '#a7abb2',
  '--gl-danger-bg': '#fdeaea',
  '--gl-danger-border': '#f0b7b7',
  '--gl-danger-text': '#b23a3a',
  '--gl-tag-bg': '#dcefe0',
  '--gl-overlay': 'rgba(20, 22, 26, 0.35)',
  '--gl-font-size-base': '13px',

  // Behavior category tokens
  '--gl-cat-movement': '#0f766e',
  '--gl-cat-movement-bg': '#e2f4f1',
  '--gl-cat-physics': '#b45309',
  '--gl-cat-physics-bg': '#faedd9',
  '--gl-cat-interaction': '#7c3aed',
  '--gl-cat-interaction-bg': '#efe6ff',
  '--gl-cat-ai': '#be185d',
  '--gl-cat-ai-bg': '#fbe3ee',
  '--gl-cat-camera': '#38bdf8',
  '--gl-cat-camera-bg': '#dff1ff',
  '--gl-cat-utility': '#475569',
  '--gl-cat-utility-bg': '#e7eaee',
  '--gl-cat-custom': '#6b7280',
  '--gl-cat-custom-bg': '#eceef0',
};
