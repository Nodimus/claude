import {
  EditorThemeDef,
  EditorThemeDefSchema,
  DARK_TOKENS,
} from './tokens';

const STORAGE_ACTIVE_THEME_KEY = 'nodimus_theme';
const STORAGE_THEMES_KEY = 'nodimus_themes';

/**
 * Reads token values directly from CSS :root computed styles,
 * falling back to the DARK_TOKENS dictionary.
 */
function readDarkTokensFromRoot(): Record<string, string> {
  const result: Record<string, string> = { ...DARK_TOKENS };
  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    const computed = window.getComputedStyle(document.documentElement);
    for (const key of Object.keys(DARK_TOKENS)) {
      const val = computed.getPropertyValue(key).trim();
      if (val) {
        result[key] = val;
      }
    }
  }
  return result;
}

export function createBuiltinDarkTheme(): EditorThemeDef {
  return {
    schemaVersion: 1,
    id: 'dark',
    name: 'Dark (Padrão)',
    base: 'dark',
    builtin: true,
    tokens: readDarkTokensFromRoot(),
  };
}

class ThemeService {
  private cachedUserThemes: EditorThemeDef[] | null = null;

  /**
   * Returns all available themes: the built-in dark theme first, followed by valid user themes.
   */
  listThemes(): EditorThemeDef[] {
    const builtinDark = createBuiltinDarkTheme();
    const userThemes = this.loadUserThemes();
    return [builtinDark, ...userThemes];
  }

  /**
   * Loads user themes from localStorage, validating each with Zod.
   * Discards invalid themes with a console warning.
   */
  private loadUserThemes(): EditorThemeDef[] {
    if (typeof window === 'undefined' || typeof localStorage === 'undefined') {
      return [];
    }

    try {
      const raw = localStorage.getItem(STORAGE_THEMES_KEY);
      if (!raw) return [];

      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) {
        console.warn('[ThemeService] Invalid nodimus_themes format in localStorage. Expected array.');
        return [];
      }

      const validThemes: EditorThemeDef[] = [];
      for (const item of parsed) {
        const result = EditorThemeDefSchema.safeParse(item);
        if (result.success) {
          // Built-in id cannot be used by user themes
          if (result.data.id !== 'dark') {
            validThemes.push(result.data);
          }
        } else {
          console.warn('[ThemeService] Discarding invalid user theme entry:', item, result.error);
        }
      }
      return validThemes;
    } catch (err) {
      console.warn('[ThemeService] Failed to load user themes from localStorage:', err);
      return [];
    }
  }

  /**
   * Gets the currently active theme ID, defaulting to 'dark'.
   */
  getActiveThemeId(): string {
    if (typeof window === 'undefined' || typeof localStorage === 'undefined') {
      return 'dark';
    }

    try {
      const id = localStorage.getItem(STORAGE_ACTIVE_THEME_KEY);
      if (!id) return 'dark';

      const all = this.listThemes();
      const exists = all.some((t) => t.id === id);
      return exists ? id : 'dark';
    } catch {
      return 'dark';
    }
  }

  /**
   * Gets the active EditorThemeDef object.
   */
  getActiveTheme(): EditorThemeDef {
    const activeId = this.getActiveThemeId();
    const themes = this.listThemes();
    return themes.find((t) => t.id === activeId) || themes[0];
  }

  /**
   * Sets the active theme by ID, saving to localStorage and applying it immediately.
   */
  setActiveTheme(id: string): void {
    if (typeof window === 'undefined' || typeof localStorage === 'undefined') return;

    const all = this.listThemes();
    const target = all.find((t) => t.id === id);
    const validId = target ? target.id : 'dark';

    try {
      localStorage.setItem(STORAGE_ACTIVE_THEME_KEY, validId);
    } catch (e) {
      console.warn('[ThemeService] Failed to save active theme ID:', e);
    }

    const themeToApply = target || all[0];
    this.applyTheme(themeToApply);
  }

  /**
   * Saves or updates a user-defined theme.
   */
  saveTheme(def: EditorThemeDef): void {
    const validated = EditorThemeDefSchema.parse(def);
    if (validated.id === 'dark') {
      throw new Error('Cannot overwrite the built-in dark theme.');
    }

    const userThemes = this.loadUserThemes();
    const existingIndex = userThemes.findIndex((t) => t.id === validated.id);

    if (existingIndex >= 0) {
      userThemes[existingIndex] = validated;
    } else {
      userThemes.push(validated);
    }

    try {
      localStorage.setItem(STORAGE_THEMES_KEY, JSON.stringify(userThemes));
    } catch (e) {
      console.warn('[ThemeService] Failed to save themes to localStorage:', e);
    }

    // If currently active theme was updated, reapply it
    if (this.getActiveThemeId() === validated.id) {
      this.applyTheme(validated);
    }
  }

  /**
   * Deletes a user theme. Cannot delete the built-in dark theme.
   */
  deleteTheme(id: string): boolean {
    if (id === 'dark') return false;

    const userThemes = this.loadUserThemes();
    const filtered = userThemes.filter((t) => t.id !== id);

    try {
      localStorage.setItem(STORAGE_THEMES_KEY, JSON.stringify(filtered));
    } catch (e) {
      console.warn('[ThemeService] Failed to persist deleted theme:', e);
    }

    // If the active theme was deleted, fallback to dark
    if (this.getActiveThemeId() === id) {
      this.setActiveTheme('dark');
    }

    return true;
  }

  /**
   * Applies the given theme to the document.
   * - Sets `data-theme` attribute to `def.base`
   * - For built-in dark: removes all inline CSS variables, returning full control to `:root` in CSS.
   * - For custom themes: sets CSS variables via `style.setProperty`.
   */
  applyTheme(def: EditorThemeDef): void {
    if (typeof document === 'undefined') return;

    const root = document.documentElement;
    root.setAttribute('data-theme', def.base);

    if (def.builtin && def.id === 'dark') {
      // Remove all inline overrides so pure :root CSS rules take effect
      for (const tokenKey of Object.keys(DARK_TOKENS)) {
        root.style.removeProperty(tokenKey);
      }
    } else {
      // Apply custom overrides
      for (const [key, value] of Object.entries(def.tokens)) {
        root.style.setProperty(key, value);
      }
    }
  }

  /**
   * Synchronously initializes theme on application boot.
   */
  initTheme(): void {
    const active = this.getActiveTheme();
    this.applyTheme(active);
  }
}

export const themeService = new ThemeService();
