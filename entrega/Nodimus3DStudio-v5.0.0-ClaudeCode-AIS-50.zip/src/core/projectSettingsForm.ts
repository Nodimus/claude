/**
 * AIS-32b — lógica pura do `ProjectSettingsModal` (sem React/DOM): rascunho em TEXTO, validação por campo com o
 * schema único (`ProjectSettingsV1Schema`), restaurar padrão por aba, dirty por valor e a aplicação ao projeto.
 *
 * Campos numéricos guardam o texto digitado e só viram número ao validar: nada de `parseInt(...) || 1280`. Apagar o
 * campo ou digitar `0` produz o erro/valor real, nunca um padrão silencioso.
 */
import type { ProjectData, ProjectSettings } from '../types/project';
import { ProjectSettingsV1Schema } from '../schemas/v1/project.schema';
import { applyProjectName, validateProjectName, type ProjectSummary } from './projectOps';

export type SettingsTab = 'general' | 'display' | 'rendering' | 'physics' | 'audio';

export interface SettingsDraft {
  general: { projectName: string; author: string; version: string; description: string; mainScene: string };
  display: { width: string; height: string; windowMode: ProjectSettings['display']['windowMode']; resizable: boolean; orientation: ProjectSettings['display']['orientation'] };
  rendering: {
    shadowsEnabled: boolean;
    shadowQuality: ProjectSettings['rendering']['shadowQuality'];
    msaa: ProjectSettings['rendering']['msaa'];
    hdr: boolean;
    vsync: boolean;
    clearColor: string;
  };
  physics: { gravity3D: { x: string; y: string; z: string }; defaultLinearDamp: string };
  audio: { masterVolume: string; musicVolume: string; sfxVolume: string };
}

/** Valores que o schema define como padrão (única fonte: nenhuma tabela duplicada). */
export function schemaDefaults(): ProjectSettings {
  return ProjectSettingsV1Schema.parse({ general: {}, display: {}, rendering: {}, physics: { gravity3D: {} }, input: {}, audio: {} }) as ProjectSettings;
}

/** Normaliza as settings persistidas (projeto antigo, campos ausentes, `fullscreen` legado) para o formato completo. */
export function normalizeSettings(raw: unknown): ProjectSettings {
  const parsed = ProjectSettingsV1Schema.safeParse(raw);
  if (parsed.success) return parsed.data as ProjectSettings;
  // inválido: completa o que der com os padrões, sem inventar valor para o que existe
  const defaults = schemaDefaults();
  const r = (raw ?? {}) as Partial<Record<keyof ProjectSettings, Record<string, unknown>>>;
  return {
    ...defaults,
    general: { ...defaults.general, ...(r.general as object) },
    display: { ...defaults.display, ...(r.display as object) },
    rendering: { ...defaults.rendering, ...(r.rendering as object) },
    physics: { ...defaults.physics, ...(r.physics as object), gravity3D: { ...defaults.physics.gravity3D, ...((r.physics?.gravity3D as object) ?? {}) } },
    input: { ...defaults.input, ...(r.input as object) },
    audio: { ...defaults.audio, ...(r.audio as object) },
  } as ProjectSettings;
}

const num = (n: number): string => String(n);

export function toDraft(settings: unknown): SettingsDraft {
  const s = normalizeSettings(settings);
  return {
    general: { projectName: s.general.projectName, author: s.general.author, version: s.general.version, description: s.general.description, mainScene: s.general.mainScene },
    display: { width: num(s.display.width), height: num(s.display.height), windowMode: s.display.windowMode, resizable: s.display.resizable, orientation: s.display.orientation },
    rendering: { shadowsEnabled: s.rendering.shadowsEnabled, shadowQuality: s.rendering.shadowQuality, msaa: s.rendering.msaa, hdr: s.rendering.hdr, vsync: s.rendering.vsync, clearColor: s.rendering.clearColor },
    physics: { gravity3D: { x: num(s.physics.gravity3D.x), y: num(s.physics.gravity3D.y), z: num(s.physics.gravity3D.z) }, defaultLinearDamp: num(s.physics.defaultLinearDamp) },
    audio: { masterVolume: num(s.audio.masterVolume), musicVolume: num(s.audio.musicVolume), sfxVolume: num(s.audio.sfxVolume) },
  };
}

/** Texto → número. Vazio ou não numérico vira `NaN` (o schema responde com o erro), nunca um padrão. Aceita vírgula decimal. */
export function parseNumberText(text: string): number {
  const t = text.trim().replace(',', '.');
  if (t === '' || !/^[-+]?(\d+\.?\d*|\.\d+)$/.test(t)) return NaN;
  return Number(t);
}

/** Candidato para o schema: o rascunho convertido + o que o modal não edita (`input.actions`, `renderer`) vindo da base. */
export function draftToCandidate(draft: SettingsDraft, base: unknown): unknown {
  const b = normalizeSettings(base);
  return {
    general: { ...draft.general },
    display: {
      width: parseNumberText(draft.display.width),
      height: parseNumberText(draft.display.height),
      resizable: draft.display.resizable,
      windowMode: draft.display.windowMode,
      // espelho legado: nenhum consumidor foi migrado nesta etapa (AIS-32b §3.4)
      fullscreen: draft.display.windowMode === 'fullscreen',
      orientation: draft.display.orientation,
    },
    rendering: { ...draft.rendering, renderer: b.rendering.renderer },
    physics: {
      gravity3D: { x: parseNumberText(draft.physics.gravity3D.x), y: parseNumberText(draft.physics.gravity3D.y), z: parseNumberText(draft.physics.gravity3D.z) },
      defaultLinearDamp: parseNumberText(draft.physics.defaultLinearDamp),
    },
    input: b.input,
    audio: {
      masterVolume: parseNumberText(draft.audio.masterVolume),
      musicVolume: parseNumberText(draft.audio.musicVolume),
      sfxVolume: parseNumberText(draft.audio.sfxVolume),
    },
  };
}

export interface ValidationContext {
  /** Cenas existentes em `res://scenes/` (a cena principal é um seletor, não texto livre). */
  scenePaths?: readonly string[];
  /** Projetos da lista (unicidade do nome) e o id do projeto editado. */
  projects?: readonly ProjectSummary[];
  projectId?: string;
}

export type FieldErrors = Record<string, string>;
export type DraftValidation = { ok: true; settings: ProjectSettings; errors: FieldErrors } | { ok: false; errors: FieldErrors };

/** Valida o rascunho; cada erro vira uma mensagem no caminho do campo (`display.width`, `physics.gravity3D.y`…). */
export function validateDraft(draft: SettingsDraft, base: unknown, ctx: ValidationContext = {}): DraftValidation {
  const errors: FieldErrors = {};
  const result = ProjectSettingsV1Schema.safeParse(draftToCandidate(draft, base));
  if (!result.success) {
    for (const issue of result.error.issues) {
      const key = issue.path.join('.');
      if (!errors[key]) errors[key] = issue.message;
    }
  }
  // unicidade só vale para um nome NOVO: manter o nome atual do projeto nunca é erro (a lista pode ter homônimos legados)
  const savedName = (base as { general?: { projectName?: unknown } } | null | undefined)?.general?.projectName;
  const nameUnchanged = typeof savedName === 'string' && savedName.trim().toLowerCase() === draft.general.projectName.trim().toLowerCase();
  if (!errors['general.projectName'] && ctx.projects && !nameUnchanged) {
    const nameError = validateProjectName(draft.general.projectName, ctx.projects, ctx.projectId);
    if (nameError) errors['general.projectName'] = nameError;
  }
  if (ctx.scenePaths && !ctx.scenePaths.includes(draft.general.mainScene)) {
    errors['general.mainScene'] = 'Escolha uma das cenas do projeto.';
  }
  if (Object.keys(errors).length > 0) return { ok: false, errors };
  return { ok: true, settings: (result as { data: ProjectSettings }).data, errors: {} };
}

/**
 * "Restaurar padrão" da aba ativa: repõe SÓ os campos dela, com os padrões do schema. A aba General não restaura
 * o nome do projeto nem a cena principal (identidade do projeto).
 */
export function resetTabToDefaults(draft: SettingsDraft, tab: SettingsTab): SettingsDraft {
  const fresh = toDraft(schemaDefaults());
  switch (tab) {
    case 'general':
      return { ...draft, general: { ...draft.general, author: fresh.general.author, version: fresh.general.version, description: fresh.general.description } };
    case 'display':
      return { ...draft, display: { ...fresh.display } };
    case 'rendering':
      return { ...draft, rendering: { ...fresh.rendering } };
    case 'physics':
      return { ...draft, physics: { gravity3D: { ...fresh.physics.gravity3D }, defaultLinearDamp: fresh.physics.defaultLinearDamp } };
    case 'audio':
      return { ...draft, audio: { ...fresh.audio } };
  }
}

/** Dirty POR VALOR: rascunho diferente do persistido (voltar ao valor original limpa). */
export function isDirty(draft: SettingsDraft, persisted: unknown): boolean {
  return JSON.stringify(draft) !== JSON.stringify(toDraft(persisted));
}

/** Aba em que cada caminho de erro mora (para sinalizar abas com erro). */
export function tabOfPath(path: string): SettingsTab | null {
  const head = path.split('.')[0];
  return head === 'general' || head === 'display' || head === 'rendering' || head === 'physics' || head === 'audio' ? head : null;
}

/**
 * Aplica as settings validadas ao projeto: `ProjectData.name` é canônico e `general.projectName` o espelha — as duas
 * pontas passam por `applyProjectName` (a mesma função do renomear do AIS-32). `res://project.json` e a lista de
 * projetos são regravados por `ProjectStorage.saveProject`.
 */
export function applySettingsToProject(project: ProjectData, settings: ProjectSettings): ProjectData {
  const withSettings: ProjectData = { ...project, settings: { ...settings, general: { ...settings.general } } };
  return applyProjectName(withSettings, settings.general.projectName);
}
