import { describe, expect, it, vi } from 'vitest';
import {
  VariableManager,
  addGlobal,
  addLocal,
  coerceVariableValue,
  describeConsumer,
  findVariableConsumers,
  localEntries,
  parseReference,
  removeGlobal,
  removeLocal,
  renameGlobal,
  renameLocal,
  renameVariableReferences,
  updateGlobal,
  updateLocal,
  validateVariableName,
} from './variableManager';
import { createSetGlobalVariablesCommand, createSetLocalVariablesCommand } from './commands/VariableCommands';
import { evaluateCondition, type ConditionWorld } from '../logic/evaluateCondition';
import { LogicRegistry, EXPECTED_NATIVE_LOGIC } from '../logic/registry';
import type { Behavior } from '../types/visualLogic';
import type { ProjectGlobalVariable } from '../types/projectFile';

const behavior = (over: Partial<Behavior> = {}): Behavior =>
  ({
    id: 'b1',
    name: 'Placar',
    behaviorType: 'custom',
    enabled: true,
    properties: {},
    targetNodeId: 'n1',
    rules: [
      {
        id: 'r1',
        eventType: 'on_update',
        parameters: {},
        conditions: [{ id: 'c1', type: 'variable_compare', parameters: { scope: 'global', variableName: 'score', operator: '>', value: 3 } }],
        actions: [
          { id: 'a1', type: 'add_to_variable', parameters: { scope: 'global', variable: 'score', amount: 1 } },
          { id: 'a2', type: 'set_variable', parameters: { scope: 'local', variable: 'ammo', value: 5 } },
          { id: 'a3', type: 'print_log', parameters: { text: 'score' } },
        ],
      },
    ],
    ...over,
  }) as unknown as Behavior;

describe('AIS-43 — nomes e valores', () => {
  it('valida o nome: vazio, formato, reservado e duplicado (erro inline)', () => {
    expect(validateVariableName('', [])).toMatch(/nome/);
    expect(validateVariableName('1abc', [])).toMatch(/letras/);
    expect(validateVariableName('a b', [])).toMatch(/letras/);
    expect(validateVariableName('system', [])).toMatch(/reservado/);
    expect(validateVariableName('score', ['score'])).toMatch(/Já existe/);
    expect(validateVariableName('score', ['vidas'])).toBeNull();
  });

  it('converte o valor ao tipo (nunca silencioso)', () => {
    expect(coerceVariableValue('number', '3.5')).toBe(3.5);
    expect(coerceVariableValue('number', 'abc')).toBeNull();
    expect(coerceVariableValue('boolean', 'true')).toBe(true);
    expect(coerceVariableValue('boolean', 'talvez')).toBeNull();
    expect(coerceVariableValue('string', 7)).toBe('7');
  });
});

describe('AIS-43 — CRUD de globais (C05–C08)', () => {
  const base = addGlobal([], { id: 'g1', name: 'score', type: 'number', value: 0 });

  it('cria com nome único e valor inicial; duplicado devolve erro e não altera', () => {
    expect(base.ok).toBe(true);
    if (!base.ok) return;
    expect(base.value).toEqual([{ id: 'g1', name: 'score', type: 'number', value: 0 }]);
    const dup = addGlobal(base.value, { id: 'g2', name: 'score', type: 'string' });
    expect(dup.ok).toBe(false);
    expect(addGlobal(base.value, { id: 'g2', name: 'x', type: 'number', value: 'oi' }).ok).toBe(false);
  });

  it('renomeia (único), muda tipo e valor, exclui', () => {
    if (!base.ok) return;
    const two = addGlobal(base.value, { id: 'g2', name: 'vidas', type: 'number', value: 3 });
    if (!two.ok) throw new Error('x');
    expect(renameGlobal(two.value, 'g2', 'score').ok).toBe(false);
    const renamed = renameGlobal(two.value, 'g2', 'hp');
    expect(renamed.ok && renamed.value.map((v) => v.name)).toEqual(['score', 'hp']);
    const retyped = updateGlobal(two.value, 'g2', { type: 'string' });
    expect(retyped.ok && retyped.value[1]).toMatchObject({ type: 'string', value: '3' });
    const valued = updateGlobal(two.value, 'g2', { value: '10' });
    expect(valued.ok && valued.value[1].value).toBe(10);
    expect(updateGlobal(two.value, 'g2', { value: 'abc' }).ok).toBe(false);
    expect(removeGlobal(two.value, 'g1').map((v) => v.id)).toEqual(['g2']);
  });
});

describe('AIS-43 — CRUD de locais (C09)', () => {
  it('cria, renomeia preservando a ordem, muda tipo/valor e exclui; o tipo vem do valor', () => {
    let r = addLocal({ a: 1 }, { name: 'ammo', type: 'number', value: 5 });
    if (!r.ok) throw new Error('x');
    expect(addLocal(r.value, { name: 'ammo', type: 'number' }).ok).toBe(false);
    const ren = renameLocal(r.value, 'a', 'z');
    expect(ren.ok && Object.keys(ren.value)).toEqual(['z', 'ammo']);
    expect(renameLocal(r.value, 'a', 'ammo').ok).toBe(false);
    const up = updateLocal(r.value, 'ammo', { type: 'boolean' });
    expect(up.ok && up.value.ammo).toBe(true);
    expect(localEntries({ x: 1, y: 'a', z: false })).toEqual([
      { name: 'x', type: 'number', value: 1 },
      { name: 'y', type: 'string', value: 'a' },
      { name: 'z', type: 'boolean', value: false },
    ]);
    expect(removeLocal(r.value, 'a')).toEqual({ ammo: 5 });
  });
});

describe('AIS-43 — consumidores e renomeação de referências', () => {
  it('acha quem usa a global (Condition e Action) e a local do nó dono', () => {
    const list = [behavior()];
    const globals = findVariableConsumers(list, 'global', 'score');
    expect(globals.map((c) => c.part)).toEqual(['condition', 'action']);
    expect(describeConsumer(globals[0])).toContain('Variable Compare');
    expect(findVariableConsumers(list, 'global', 'ninguem')).toEqual([]);
    expect(findVariableConsumers(list, 'local', 'ammo', 'n1')).toHaveLength(1);
    expect(findVariableConsumers(list, 'local', 'ammo', 'outro')).toEqual([]);
  });

  it('renomeia só o que referencia; o resto mantém a mesma referência de objeto', () => {
    const list = [behavior(), behavior({ id: 'b2', rules: [] })];
    const next = renameVariableReferences(list, 'global', 'score', 'pontos');
    expect(next[0].rules[0].conditions[0].parameters.variableName).toBe('pontos');
    expect(next[0].rules[0].actions[0].parameters.variable).toBe('pontos');
    expect(next[0].rules[0].actions[1].parameters.variable).toBe('ammo'); // local: intacta
    expect(next[0].rules[0].actions[2]).toBe(list[0].rules[0].actions[2]);
    expect(next[1]).toBe(list[1]);
    expect(renameVariableReferences(list, 'global', 'nada', 'x')[0]).toBe(list[0]);
  });
});

describe('AIS-43 — Commands com Undo (C06, C08)', () => {
  it('renomear: lista e referências mudam juntas e Undo restaura as duas', () => {
    let globals: ProjectGlobalVariable[] = [{ id: 'g1', name: 'score', type: 'number', value: 0 }];
    let behaviors = [behavior()];
    const original = behaviors;
    const cmd = createSetGlobalVariablesCommand({
      label: 'Rename',
      store: { get: () => globals, set: (n) => (globals = n) },
      next: [{ ...globals[0], name: 'pontos' }],
      behaviors: { store: { get: () => behaviors, set: (n) => (behaviors = n) }, next: renameVariableReferences(behaviors, 'global', 'score', 'pontos') },
    })!;
    cmd.execute();
    expect(globals[0].name).toBe('pontos');
    expect(behaviors[0].rules[0].actions[0].parameters.variable).toBe('pontos');
    cmd.undo();
    expect(globals[0].name).toBe('score');
    expect(behaviors).toEqual(original);
  });

  it('sem mudança não gera Command', () => {
    const globals = [{ id: 'g1', name: 'a', type: 'number' as const, value: 0 }];
    expect(createSetGlobalVariablesCommand({ label: 'x', store: { get: () => globals, set: () => {} }, next: globals })).toBeNull();
    expect(createSetLocalVariablesCommand({ label: 'x', store: { get: () => ({ a: 1 }), set: () => {} }, nodeId: 'n', next: { a: 1 } })).toBeNull();
  });

  it('local: Undo devolve o registro anterior', () => {
    let rec: Record<string, any> = { a: 1 };
    const cmd = createSetLocalVariablesCommand({ label: 'x', store: { get: () => rec, set: (_i, n) => (rec = n) }, nodeId: 'n', next: { a: 1, b: 2 } })!;
    cmd.execute();
    expect(rec).toEqual({ a: 1, b: 2 });
    cmd.undo();
    expect(rec).toEqual({ a: 1 });
  });
});

describe('AIS-43 — VariableManager (runtime)', () => {
  const make = () => {
    const vm = new VariableManager([{ name: 'score', type: 'number', value: 0 }, { name: 'nome', type: 'string', value: 'Ana' }]);
    const enemy = { ammo: 5, vivo: true };
    vm.registerLocals('e1', enemy);
    return { vm, enemy };
  };

  it('get/set/add para global e local, com tipo respeitado', () => {
    const { vm, enemy } = make();
    expect(vm.addToVariable('global', 'score', 2)).toBe(2);
    expect(vm.getVariable('global', 'score')).toBe(2);
    expect(vm.setVariable('global', 'score', 'abc')).toBe(false);
    expect(vm.setVariable('global', 'inexistente', 1)).toBe(false);
    expect(vm.setVariable('local', 'ammo', 9, 'e1')).toBe(true);
    expect(enemy.ammo).toBe(9);
    expect(vm.addToVariable('local', 'ammo', -4, 'e1')).toBe(5);
    expect(vm.addToVariable('global', 'nome', 1)).toBeUndefined(); // não é número
    expect(vm.getVariable('local', 'ammo', 'sem-no')).toBeUndefined();
  });

  it('a global sobrevive a trocar de Scene (descartar locais); o autoral nunca é tocado', () => {
    const authoring = [{ name: 'score', type: 'number', value: 0 }];
    const vm = new VariableManager(authoring);
    vm.setVariable('global', 'score', 7);
    vm.registerLocals('e1', { ammo: 1 });
    vm.unregisterLocals('e1'); // troca de cena
    expect(vm.getVariable('global', 'score')).toBe(7);
    expect(vm.getVariable('local', 'ammo', 'e1')).toBeUndefined();
    expect(authoring[0].value).toBe(0);
  });

  it('publica no barramento só quando muda e o disposer cancela', () => {
    const { vm } = make();
    const fn = vi.fn();
    const off = vm.onVariableChanged(fn);
    vm.setVariable('global', 'score', 1);
    vm.setVariable('global', 'score', 1); // igual: sem evento
    vm.setVariable('local', 'ammo', 6, 'e1');
    expect(fn).toHaveBeenCalledTimes(2);
    expect(fn.mock.calls[0][0]).toMatchObject({ scope: 'global', name: 'score', oldValue: 0, newValue: 1 });
    expect(fn.mock.calls[1][0]).toMatchObject({ scope: 'local', nodeId: 'e1', name: 'ammo', newValue: 6 });
    off();
    vm.setVariable('global', 'score', 2);
    expect(fn).toHaveBeenCalledTimes(2);
  });

  it('um ouvinte que lança não derruba a mutação nem os outros', () => {
    const { vm } = make();
    const ok = vi.fn();
    vm.onVariableChanged(() => {
      throw new Error('x');
    });
    vm.onVariableChanged(ok);
    expect(vm.setVariable('global', 'score', 3)).toBe(true);
    expect(ok).toHaveBeenCalled();
  });

  it('#nome.atributo lê a Local de outro nó; #system.* é reservado; $var$ interpola', () => {
    const { vm } = make();
    const ids: Record<string, string> = { enemy1: 'e1' };
    const lookup = { resolveNodeId: (n: string) => ids[n], selfNodeId: 'e1' };
    expect(parseReference('#enemy1.ammo')).toEqual({ node: 'enemy1', attribute: 'ammo' });
    expect(vm.resolveReference('#enemy1.ammo', lookup)).toBe(5);
    expect(vm.resolveReference('#system.fps', lookup)).toBeUndefined();
    expect(vm.resolveReference('#nada.ammo', lookup)).toBeUndefined();
    vm.setVariable('global', 'score', 12);
    expect(vm.interpolate('Score: $score$ de $nome$ | munição #enemy1.ammo | $ausente$', lookup)).toBe('Score: 12 de Ana | munição 5 | $ausente$');
    expect(vm.interpolate('vivo=$vivo$', lookup)).toBe('vivo=true'); // Local do nó dono
  });
});

describe('AIS-43 — Condition variable_compare (C10)', () => {
  const vm = new VariableManager([{ name: 'score', type: 'number', value: 10 }]);
  vm.registerLocals('e1', { ammo: 0, tag: 'boss' });
  const world: ConditionWorld = {
    selfNodeId: 'e1',
    getNode: (ref) => (ref === 'e1' || ref === 'Enemy' ? { id: 'e1', name: 'Enemy', type: 'Spatial', properties: {} } : undefined),
    getWorldPosition: () => undefined,
    input: { isBindingPressed: () => false } as never,
    sceneTime: 0,
    random: () => 0,
    getVariable: (scope, name, nodeId) => vm.getVariable(scope, name, nodeId),
  };
  const run = (parameters: Record<string, unknown>) => evaluateCondition({ type: 'variable_compare', parameters }, world);

  it('está no catálogo e na lista de nativos', () => {
    expect(LogicRegistry.isKnownCondition('variable_compare')).toBe(true);
    expect(EXPECTED_NATIVE_LOGIC.condition).toContain('variable_compare');
  });

  it('compara globais com todos os operadores', () => {
    expect(run({ variableName: 'score', operator: '>=', value: 10 })).toBe(true);
    expect(run({ variableName: 'score', operator: '>', value: 10 })).toBe(false);
    expect(run({ variableName: 'score', operator: '!=', value: 3 })).toBe(true);
    expect(run({ variableName: 'score', operator: '<=', value: '10' })).toBe(true);
    expect(run({ variableName: 'score', operator: '<', value: 11 })).toBe(true);
    expect(run({ variableName: 'score', operator: '=', value: 10 })).toBe(true);
  });

  it('local: nó dono por padrão ou Target; variável/nó inexistente = falsa', () => {
    expect(run({ scope: 'local', variableName: 'ammo', operator: '=', value: 0 })).toBe(true);
    expect(run({ scope: 'local', target: 'Enemy', variableName: 'tag', operator: '=', value: 'boss' })).toBe(true);
    expect(run({ scope: 'local', target: 'Fantasma', variableName: 'ammo', operator: '=', value: 0 })).toBe(false);
    expect(run({ variableName: 'nao_existe', operator: '=', value: 0 })).toBe(false);
    expect(run({ variableName: '', operator: '=', value: 0 })).toBe(false);
  });

  it('sem sistema de variáveis no contexto, é falsa (não lança)', () => {
    const { getVariable: _g, ...bare } = world;
    expect(evaluateCondition({ type: 'variable_compare', parameters: { variableName: 'score', value: 10 } }, bare)).toBe(false);
  });
});

describe('AIS-43 — o runtime nunca cria variável', () => {
  it('set/add em nome inexistente (global ou local) não cria nada', () => {
    const vm = new VariableManager([]);
    vm.registerLocals('e1', {});
    expect(vm.setVariable('global', 'nova', 1)).toBe(false);
    expect(vm.addToVariable('global', 'nova', 1)).toBeUndefined();
    expect(vm.setVariable('local', 'nova', 1, 'e1')).toBe(false);
    expect(vm.listGlobals()).toEqual([]);
    expect(vm.listLocals('e1')).toEqual([]);
  });
});
