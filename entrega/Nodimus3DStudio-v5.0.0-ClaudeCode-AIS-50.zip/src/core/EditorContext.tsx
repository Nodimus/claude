import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { ProjectData, ProjectSettings, VirtualFile } from '../types/project';
import { SceneData, PostProcessingSettings, DEFAULT_POST_PROCESSING, SceneFogSettings, DEFAULT_SCENE_FOG, SceneEnvironment, DEFAULT_SCENE_ENVIRONMENT, SceneCameraSettings, DEFAULT_SCENE_CAMERA } from '../types/scene';
import { GameNode, NodeType } from '../types/node';
import { Behavior } from '../types/visualLogic';
import { ProjectStorage } from './projectStorage';
import { createDefaultNode } from '../nodes/registry';
import { createDefault3DStarterScene, createEmptyScene, ensureStarterFiles } from './defaultProject';
import { globalCommandManager } from './commandManager';
import { createBehaviorOps, type BehaviorOps, type BehaviorStore } from './commands/BehaviorCommands';
import { createVariableOps, type VariableOps } from './variableOps';
import { applyBehaviorList, collectBehaviors } from './authoring/behaviors';
import { globalDiagnosticService } from './diagnostics/global';
import { publishSceneDiagnostics } from './diagnostics/publishers';
import { consoleTypeOf, formatDiagnosticLine } from './diagnostics/adapters';
import { missingNodesWarning } from '../schemas';
import { ProjectSettingsV1Schema } from '../schemas/v1/project.schema';
import { applySettingsToProject, normalizeSettings } from './projectSettingsForm';
import { globalAuthoringModel } from './authoring';
import { groupTransformTargets } from './authoring/selectionUtils';
import { createChangePropertyCommand } from './commands/ChangePropertyCommand';
import { createConnectSignalCommand, createDisconnectSignalCommand, createEditSignalConnectionCommand } from './commands/SignalCommands';
import type { NodeSignalConnection } from '../types/signal';
import { parseSceneJson, serializeSceneToJson } from './serialization/sceneSerializer';
import { flushPendingBackup, notePendingBackup } from './serialization/migrationBackup';
import { blockWrites, unblockWrites, writeBlockedReason } from './serialization/writeGuard';
import { isKnownLogicContribution } from './serialization/logicResolver';
import { pausePlaySession, setLogicSessionHooks, startPlaySession, stopPlaySession } from '../runtime/logicRunnerSession';
import { getActiveRuntimeSession } from '../runtime/RuntimeSession';
import { playBlockLines } from '../runtime/playGate';
import { createRuntimeSnapshot } from './authoring/snapshot';
import { addScene } from './sceneManager';
import { carryResourceMeta } from './resources/ids';
import { createAddNodeCommand, createDeleteNodeCommand, createReparentNodeCommand } from './commands/SceneTreeCommands';
import { deltaFromInspectorEdit, parentWorldMatrixOf, planGroupTransform } from './authoring/groupTransform';
import {
  createSetTransformCommand,
  toSetTransformItem,
  type NodeTransform,
  type TransformMode,
  type Vec3,
} from './commands/SetTransformCommand';
import { AuthoringSceneSnapshot } from '../types/runtime';
// AIS-03d: Zustand EditorStore — bridge import.
// EditorContext acts as the temporary façade and writes into the store
// so that components can gradually migrate to granular Zustand selectors.
import { useEditorStore } from './editorStore';
import {
  bindEditorServices,
  guardDiscardChanges,
  preserveHistoryOnNextSceneLoad,
  saveSceneDocument,
  setSceneDocumentHandlers,
} from './documents/sceneDocument';
import { setScriptDocumentHandlers } from './documents/scriptDocuments';

export type WorkspaceMode = '3D' | 'VisualLogic' | 'Script';

/**
 * The three transform-tool modes. Matches W/E/R shortcuts (canonical Item 2).
 * `select` is the neutral mode (Q key).
 */
export type ManipulationMode = 'select' | 'translate' | 'rotate' | 'scale';

export interface LogEntry {
  id: string;
  type: 'log' | 'warn' | 'error';
  message: string;
  timestamp: string;
}

export interface EditorContextType {
  /** @deprecated [AIS-03f] Read-only projection from AuthoringModel (`globalAuthoringModel.getProject()`). Do not mutate directly. */
  project: ProjectData;
  /** @deprecated [AIS-03f] Read-only projection from AuthoringModel (`globalAuthoringModel.getScene()`). Do not mutate directly. */
  activeScene: SceneData;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.selectedNodeId)`. */
  selectedNodeId: string | null;
  /** @deprecated [AIS-03f] Derived from AuthoringModel + EditorStore (`globalAuthoringModel.getNode(selectedNodeId)`). */
  selectedNode: GameNode | null;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.workspaceMode)`. */
  workspaceMode: WorkspaceMode;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isPlaying)`. */
  isPlaying: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.playMode)`. */
  playMode: 'project' | 'scene' | null;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isPaused)`. */
  isPaused: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.bottomTab)`. */
  bottomTab: 'output' | 'debugger';
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isBottomOpen)`. */
  isBottomOpen: boolean;
  /** @deprecated [AIS-03f] Transient log buffer (to be moved to LogService in AIS-18). */
  logs: LogEntry[];
  /** @deprecated [AIS-03f] Global behaviors list (to be migrated inline into GameNode in AIS-41b). */
  behaviors: Behavior[];
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isProjectSettingsOpen)`. */
  isProjectSettingsOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isPostProcessingOpen)`. */
  isPostProcessingOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isTerrainEditorOpen)`. */
  isTerrainEditorOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isTreeEditorOpen)`. */
  isTreeEditorOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isFogModalOpen)`. */
  isFogModalOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isSoundModalOpen)`. */
  isSoundModalOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isParticleModalOpen)`. */
  isParticleModalOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isAssetImportModalOpen)`. */
  isAssetImportModalOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isProjectManagerOpen)`. */
  isProjectManagerOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isCreateNodeModalOpen)`. */
  isCreateNodeModalOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isTexturePreviewOpen)`. */
  isTexturePreviewOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsTexturePreviewOpen)`. */
  setIsTexturePreviewOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isVideoEditorOpen)`. */
  isVideoEditorOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsVideoEditorOpen)`. */
  setIsVideoEditorOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isSpriteEditorOpen)`. */
  isSpriteEditorOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsSpriteEditorOpen)`. */
  setIsSpriteEditorOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isExtensionsPanelOpen)`. */
  isExtensionsPanelOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsExtensionsPanelOpen)`. */
  setIsExtensionsPanelOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Migrate to `globalCommandManager.canUndo()`. */
  canUndo: boolean;
  /** @deprecated [AIS-03f] Migrate to `globalCommandManager.canRedo()`. */
  canRedo: boolean;

  // ── AIS-02: Manipulation mode (Q/W/E/R) ──────────────────────────────────
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.manipulationMode)`. */
  manipulationMode: ManipulationMode;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setManipulationMode)`. */
  setManipulationMode: (mode: ManipulationMode) => void;

  // ── AIS-02: Multi-selection ───────────────────────────────────────────────
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.multiSelectedNodeIds)`. */
  multiSelectedNodeIds: string[];
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setMultiSelectedNodeIds)`. */
  setMultiSelectedNodeIds: (ids: string[]) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.toggleMultiSelectNode)`. */
  toggleMultiSelectNode: (id: string) => void;

  // ── AIS-02: Two named mutation vias ─────────────────────────────────────
  /** @deprecated [AIS-03f] Migrate to `globalCommandManager.execute(cmd)`. */
  applyEditorMutation: (command: import('../types/commands').ICommand) => void;
  /** @deprecated [AIS-03f] Exclusively for Play mode; mutate runtime session instances directly. */
  applyRuntimeMutation: (updater: (prev: SceneData) => SceneData) => void;

  // Code / Script Editor state
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.activeScriptPath)`. */
  activeScriptPath: string | null;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.openScriptTabs)`. */
  openScriptTabs: string[];
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.isScriptEditorModalOpen)`. */
  isScriptEditorModalOpen: boolean;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore` actions `openScriptTab` + `setWorkspaceMode`. */
  openFileInScriptEditor: (path: string, openAsModal?: boolean) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.closeScriptTab)`. */
  closeScriptTab: (path: string) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setActiveScriptPath)`. */
  setActiveScriptPath: (path: string | null) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsScriptEditorModalOpen)`. */
  setIsScriptEditorModalOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Mutate virtual file via AuthoringModel (`globalAuthoringModel.setProject(...)`). */
  updateFileContent: (path: string, content: string) => void;

  // Setters & Actions
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setWorkspaceMode)`. */
  setWorkspaceMode: (mode: WorkspaceMode) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.selectNode)`. */
  selectNode: (id: string | null) => void;
  /** @deprecated [AIS-03f] Execute via CommandManager targeting AuthoringModel. */
  updateNodeProperties: (nodeId: string, updates: Record<string, any>, recordHistory?: boolean) => void;
  /** AIS-19: edita position/rotation/scale pelo Inspector; com 2+ selecionados aplica o mesmo delta ao grupo (1 Command). */
  updateNodeTransform: (nodeId: string, key: 'position' | 'rotation' | 'scale', value: Vec3) => void;
  /** AIS-21: edita uma propriedade por caminho com pontos ("physics.mass"); um Command com Undo. */
  changeNodeProperty: (nodeId: string, propertyPath: string, value: any) => void;
  /** AIS-27: conectar / editar / desconectar sinal do nó; cada um é UM Command com Undo (`GameNode.signals`). */
  connectSignal: (nodeId: string, connection: NodeSignalConnection) => void;
  editSignalConnection: (nodeId: string, oldConn: NodeSignalConnection, newConn: NodeSignalConnection) => void;
  disconnectSignal: (nodeId: string, conn: NodeSignalConnection) => void;
  /** AIS-23: vários caminhos de uma vez, um Command com rótulo opcional (preenchimento por preset). */
  changeNodeProperties: (nodeId: string, changes: Record<string, any>, label?: string) => void;
  /** @deprecated [AIS-03f] Execute via CommandManager targeting AuthoringModel. */
  addNode: (
    type: NodeType,
    parentId?: string | null,
    customName?: string,
    initialProperties?: Record<string, any>
  ) => GameNode;
  /** @deprecated [AIS-03f] Execute via CommandManager targeting AuthoringModel. */
  deleteNode: (nodeId: string) => void;
  /** @deprecated [AIS-03f] Execute via CommandManager targeting AuthoringModel. */
  deleteMultipleNodes: (nodeIds: string[]) => void;
  /** @deprecated [AIS-03f] Execute via CommandManager targeting AuthoringModel. */
  duplicateNode: (nodeId: string) => void;
  /** @deprecated [AIS-03f] Execute via CommandManager targeting AuthoringModel. */
  renameNode: (nodeId: string, newName: string) => void;
  /** @deprecated [AIS-03f] Execute via CommandManager targeting AuthoringModel. */
  reparentOrReorderNode: (nodeId: string, newParentId: string | null, targetIndex?: number) => void;
  /** @deprecated [AIS-03f] Execute via CommandManager targeting AuthoringModel. */
  toggleNodeVisibility: (nodeId: string) => void;
  /** AIS-17: define a visibilidade de vários nós como UM Command. */
  setNodesVisibility: (nodeIds: string[], visible: boolean) => void;
  /** @deprecated [AIS-03f] Execute via CommandManager targeting AuthoringModel. */
  toggleNodeLock: (nodeId: string) => void;
  /** @deprecated [AIS-03f] Persist via AuthoringModel + ProjectStorage. */
  saveCurrentScene: () => void;
  /** @deprecated [AIS-03f] Validate via Zod then load into AuthoringModel. */
  loadScene: (path: string) => void;
  /** AIS-29f: abre outra cena (guarda de alterações pendentes) e executa `then` depois. */
  openSceneThen: (path: string, then: () => void) => void;
  /** @deprecated [AIS-03f] Create via AuthoringModel + ProjectStorage. */
  createNewScene: (type: '3D' | 'Empty') => void;
  /** @deprecated [AIS-03f] Save as via AuthoringModel + ProjectStorage. */
  saveSceneAs: (newPath: string) => void;

  // File operations
  /** @deprecated [AIS-03f] Mutate virtual files via AuthoringModel (`globalAuthoringModel.setProject(...)`). */
  createFolder: (path: string) => void;
  /** @deprecated [AIS-03f] Mutate virtual files via AuthoringModel (`globalAuthoringModel.setProject(...)`). */
  createFile: (path: string, content?: string) => void;
  // Excluir e mover arquivos: `deleteResource`/`moveResource` (src/core/resourceDeletion.ts, AIS-29e) — nunca por aqui.
  /** @deprecated [AIS-03f] Mutate virtual files via AuthoringModel (`globalAuthoringModel.setProject(...)`). */
  importFileContent: (path: string, content: string, name: string) => void;

  // Logs
  addLog: (type: 'log' | 'warn' | 'error', message: string) => void;
  clearLogs: () => void;

  // Playback
  /** @deprecated [AIS-03f] Snapshot from AuthoringModel + `setPlayState(true, ...)`. */
  playProject: () => void;
  /** @deprecated [AIS-03f] Snapshot from AuthoringModel + `setPlayState(true, ...)`. */
  playScene: () => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setPlayState)`. */
  pauseGame: () => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setPlayState(false, ...))`. */
  stopGame: () => void;

  // Bottom dock
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setBottomTab)`. */
  setBottomTab: (tab: 'output' | 'debugger') => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsBottomOpen)`. */
  setIsBottomOpen: (open: boolean) => void;

  // Visual Logic
  addBehavior: (behavior: Behavior) => void;
  removeBehavior: (id: string) => void;
  /** AIS-39: CRUD de Behaviors/Triggers/Conditions/Actions como Commands (Undo). Única API de edição de lógica da UI. */
  behaviorOps: BehaviorOps;
  /** AIS-43: CRUD de variáveis globais (projeto) e locais (nó) como Commands (Undo), com consumidores e renomeação de referências. */
  variableOps: VariableOps;

  // Dialogs
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsTerrainEditorOpen)`. */
  setIsTerrainEditorOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsTreeEditorOpen)`. */
  setIsTreeEditorOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsPostProcessingOpen)`. */
  setIsPostProcessingOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Mutate scene post processing via AuthoringModel (`globalAuthoringModel.setScene(...)`). */
  updateScenePostProcessing: (settings: Partial<PostProcessingSettings>) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsFogModalOpen)`. */
  setIsFogModalOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Mutate scene fog via AuthoringModel (`globalAuthoringModel.setScene(...)`). */
  updateSceneFog: (settings: Partial<SceneFogSettings>) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsSoundModalOpen)`. */
  setIsSoundModalOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsParticleModalOpen)`. */
  setIsParticleModalOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsAssetImportModalOpen)`. */
  setIsAssetImportModalOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsProjectSettingsOpen)`. */
  setIsProjectSettingsOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Mutate project settings via AuthoringModel (`globalAuthoringModel.setProject(...)`). */
  /** AIS-32b: valida com o schema, grava ANTES de aplicar e devolve o resultado (falha de gravação não é sucesso). */
  updateProjectSettings: (newSettings: ProjectSettings) => { ok: true } | { ok: false; error: string };
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsProjectManagerOpen)`. */
  setIsProjectManagerOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Migrate to `useEditorStore((s) => s.setIsCreateNodeModalOpen)`. */
  setIsCreateNodeModalOpen: (open: boolean) => void;
  /** @deprecated [AIS-03f] Switch project via AuthoringModel (`globalAuthoringModel.loadProject(...)`). */
  switchProject: (proj: ProjectData) => void;

  // ── AIS-02: Scene-level environment & camera settings ────────────────────
  /** @deprecated [AIS-03f] Mutate scene environment via AuthoringModel (`globalAuthoringModel.setScene(...)`). */
  updateSceneEnvironment: (settings: Partial<SceneEnvironment>) => void;
  /** @deprecated [AIS-03f] Mutate camera settings via AuthoringModel (`globalAuthoringModel.setScene(...)`). */
  updateSceneCameraSettings: (settings: Partial<SceneCameraSettings>) => void;

  // Undo / Redo
  /** @deprecated [AIS-03f] Migrate to `globalCommandManager.undo()`. */
  undo: () => void;
  /** @deprecated [AIS-03f] Migrate to `globalCommandManager.redo()`. */
  redo: () => void;
}

const EditorContext = createContext<EditorContextType | null>(null);

export const EditorProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // ── AIS-03f: Canonical Zustand UI State (Sole source of truth for IDE UI) ──
  const selectedNodeId            = useEditorStore((s) => s.selectedNodeId);
  const multiSelectedNodeIds      = useEditorStore((s) => s.multiSelectedNodeIds);
  const workspaceMode             = useEditorStore((s) => s.workspaceMode);
  const manipulationMode          = useEditorStore((s) => s.manipulationMode);
  const isPlaying                 = useEditorStore((s) => s.isPlaying);
  const isPaused                  = useEditorStore((s) => s.isPaused);
  const playMode                  = useEditorStore((s) => s.playMode);
  const bottomTab                 = useEditorStore((s) => s.bottomTab);
  const isBottomOpen              = useEditorStore((s) => s.isBottomOpen);
  const activeScriptPath          = useEditorStore((s) => s.activeScriptPath);
  const openScriptTabs            = useEditorStore((s) => s.openScriptTabs);
  const isProjectSettingsOpen     = useEditorStore((s) => s.isProjectSettingsOpen);
  const isProjectManagerOpen      = useEditorStore((s) => s.isProjectManagerOpen);
  const isCreateNodeModalOpen     = useEditorStore((s) => s.isCreateNodeModalOpen);
  const isPostProcessingOpen      = useEditorStore((s) => s.isPostProcessingOpen);
  const isTerrainEditorOpen       = useEditorStore((s) => s.isTerrainEditorOpen);
  const isTreeEditorOpen          = useEditorStore((s) => s.isTreeEditorOpen);
  const isFogModalOpen            = useEditorStore((s) => s.isFogModalOpen);
  const isSoundModalOpen          = useEditorStore((s) => s.isSoundModalOpen);
  const isParticleModalOpen       = useEditorStore((s) => s.isParticleModalOpen);
  const isAssetImportModalOpen    = useEditorStore((s) => s.isAssetImportModalOpen);
  const isTexturePreviewOpen      = useEditorStore((s) => s.isTexturePreviewOpen);
  const isVideoEditorOpen         = useEditorStore((s) => s.isVideoEditorOpen);
  const isSpriteEditorOpen        = useEditorStore((s) => s.isSpriteEditorOpen);
  const isExtensionsPanelOpen     = useEditorStore((s) => s.isExtensionsPanelOpen);
  const isScriptEditorModalOpen   = useEditorStore((s) => s.isScriptEditorModalOpen);

  // ── Canonical Zustand UI Actions ──────────────────────────────────────────
  const selectNode                = useEditorStore((s) => s.selectNode);
  const setMultiSelectedNodeIds   = useEditorStore((s) => s.setMultiSelectedNodeIds);
  const toggleMultiSelectNode     = useEditorStore((s) => s.toggleMultiSelectNode);
  const setWorkspaceMode          = useEditorStore((s) => s.setWorkspaceMode);
  const setManipulationMode       = useEditorStore((s) => s.setManipulationMode);
  const setPlayState              = useEditorStore((s) => s.setPlayState);
  const setBottomTab              = useEditorStore((s) => s.setBottomTab);
  const setIsBottomOpen           = useEditorStore((s) => s.setIsBottomOpen);
  const setIsProjectSettingsOpen  = useEditorStore((s) => s.setIsProjectSettingsOpen);
  const setIsProjectManagerOpen   = useEditorStore((s) => s.setIsProjectManagerOpen);
  const setIsCreateNodeModalOpen  = useEditorStore((s) => s.setIsCreateNodeModalOpen);
  const setIsPostProcessingOpen   = useEditorStore((s) => s.setIsPostProcessingOpen);
  const setIsTerrainEditorOpen    = useEditorStore((s) => s.setIsTerrainEditorOpen);
  const setIsTreeEditorOpen       = useEditorStore((s) => s.setIsTreeEditorOpen);
  const setIsFogModalOpen         = useEditorStore((s) => s.setIsFogModalOpen);
  const setIsSoundModalOpen       = useEditorStore((s) => s.setIsSoundModalOpen);
  const setIsParticleModalOpen    = useEditorStore((s) => s.setIsParticleModalOpen);
  const setIsAssetImportModalOpen = useEditorStore((s) => s.setIsAssetImportModalOpen);
  const setIsTexturePreviewOpen   = useEditorStore((s) => s.setIsTexturePreviewOpen);
  const setIsVideoEditorOpen      = useEditorStore((s) => s.setIsVideoEditorOpen);
  const setIsSpriteEditorOpen     = useEditorStore((s) => s.setIsSpriteEditorOpen);
  const setIsExtensionsPanelOpen  = useEditorStore((s) => s.setIsExtensionsPanelOpen);
  const setIsScriptEditorModalOpen= useEditorStore((s) => s.setIsScriptEditorModalOpen);
  const setActiveScriptPath       = useEditorStore((s) => s.setActiveScriptPath);
  const openScriptTab             = useEditorStore((s) => s.openScriptTab);
  const closeScriptTab            = useEditorStore((s) => s.closeScriptTab);

  // ── AIS-03c/f: Persistent Data Read-Only Projection from AuthoringModel ───
  // EditorContext maintains a read-only projection exclusively for legacy UI components.
  // The AuthoringModel is the single in-memory authority for persistent state.
  const [project, setProject] = useState<ProjectData>(() => globalAuthoringModel.getProject());
  const [activeScene, setActiveScene] = useState<SceneData>(() => globalAuthoringModel.getScene());

  // Subscribe to AuthoringModel notifications for UI projection and store identity sync
  useEffect(() => {
    const syncStore = () => {
      const p = globalAuthoringModel.getProject();
      const s = globalAuthoringModel.getScene();
      setProject(p);
      setActiveScene(s);
      useEditorStore.getState().syncActiveScene({ path: s.path, name: s.name });
      useEditorStore.getState().syncActiveProject({ id: p.id, name: p.name });
    };
    syncStore();
    const unsub = globalAuthoringModel.subscribe(syncStore);
    return unsub;
  }, []);

  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  const [logs, setLogs] = useState<LogEntry[]>(() => {
    const initial: LogEntry[] = [
      { id: '1', type: 'log', message: 'Nodimus 3D Studio initialized.', timestamp: new Date().toLocaleTimeString() },
      { id: '2', type: 'log', message: `Active Project: ${project.name} (Three.js WebGL Engine)`, timestamp: new Date().toLocaleTimeString() },
    ];
    publishSceneDiagnostics(globalAuthoringModel.getScene().path, [], globalAuthoringModel.getScene().nodes, 'none');
    const missingWarn = missingNodesWarning(globalAuthoringModel.getScene().nodes);
    if (missingWarn) initial.push({ id: '3', type: 'warn', message: missingWarn, timestamp: new Date().toLocaleTimeString() });
    return initial;
  });

  // AIS-41b: Behaviors são `GameNode.behaviors` (única fonte da verdade, salva com a cena); esta lista é uma VISÃO derivada
  // (instância + nó dono) com referências estáveis — não há mais lista global em estado.
  const behaviors = useMemo(() => collectBehaviors(activeScene), [activeScene.nodes]);

  // Sync undo/redo status
  useEffect(() => {
    const unsub = globalCommandManager.subscribe(() => {
      setCanUndo(globalCommandManager.canUndo());
      setCanRedo(globalCommandManager.canRedo());
    });
    return unsub;
  }, []);

  const addLog = useCallback((type: 'log' | 'warn' | 'error', message: string) => {
    setLogs((prev) => [
      ...prev.slice(-200),
      {
        id: Math.random().toString(36).substring(2, 9),
        type,
        message,
        timestamp: new Date().toLocaleTimeString(),
      },
    ]);
  }, []);

  // Falha de gravação (quota etc.) precisa ser visível: nunca só no console.
  useEffect(() => ProjectStorage.onSaveError((message) => addLog('error', message)), [addLog]);

  const clearLogs = useCallback(() => {
    setLogs([]);
  }, []);

  const selectedNode = useMemo(() => {
    if (!selectedNodeId) return null;
    return activeScene.nodes[selectedNodeId] || null;
  }, [selectedNodeId, activeScene.nodes]);


  // ── AIS-02: Two named mutation vias ─────────────────────────────────────
  /**
   * UI/Editor via — routes through CommandManager (Undo/Redo).
   * This is the ONLY legal path for user-initiated state mutations.
   */
  const applyEditorMutation = useCallback((command: import('../types/commands').ICommand) => {
    globalCommandManager.execute(command);
  }, []);

  /**
   * Runtime via — mutates the in-memory scene state WITHOUT recording a
   * Command. Must be used exclusively during Play mode for physics/game logic.
   * The authoring sceneStore is untouched; Play state lives in a copy.
   */
  const applyRuntimeMutation = useCallback((updater: (prev: SceneData) => SceneData) => {
    setActiveScene(updater);
  }, []);

  // AIS-21: ChangePropertyCommand — Undo restaura o valor prévio e re-renderiza Inspector e Viewport.
  // `updateNodeProperties`: chaves planas de `properties` (modais e demais chamadores);
  // `changeNodeProperty`: caminho com pontos ("physics.mass") usado pelo Inspector.
  const runPropertyChange = useCallback((nodeId: string, changes: Record<string, any>, label?: string) => {
    const command = createChangePropertyCommand({
      target: globalAuthoringModel,
      nodeId,
      changes,
      label,
      afterExecute: () => setActiveScene(globalAuthoringModel.getScene()),
      afterUndo: () => setActiveScene(globalAuthoringModel.getScene()),
    });
    if (command) globalCommandManager.execute(command);
  }, []);

  const updateNodeProperties = useCallback((nodeId: string, updates: Record<string, any>, recordHistory = true) => {
    const node = globalAuthoringModel.getNode(nodeId);
    if (!node) return;

    if (recordHistory) {
      // chaves planas: cada chave de `updates` é uma propriedade (nunca um caminho)
      runPropertyChange(nodeId, updates);
    } else {
      globalAuthoringModel.updateNodeProperties(nodeId, { ...node.properties, ...updates });
      setActiveScene(globalAuthoringModel.getScene());
    }
  }, [runPropertyChange]);

  const changeNodeProperty = useCallback((nodeId: string, propertyPath: string, value: any) => {
    runPropertyChange(nodeId, { [propertyPath]: value });
  }, [runPropertyChange]);

  // AIS-23: várias propriedades (ex.: preset de partículas) = UM Command com rótulo próprio
  const changeNodeProperties = useCallback((nodeId: string, changes: Record<string, any>, label?: string) => {
    runPropertyChange(nodeId, changes, label);
  }, [runPropertyChange]);

  // AIS-27: sinais do nó (Commands; nunca mutar `node.signals` direto)
  const signalHooks = {
    afterExecute: () => setActiveScene(globalAuthoringModel.getScene()),
    afterUndo: () => setActiveScene(globalAuthoringModel.getScene()),
  };
  const connectSignal = useCallback((nodeId: string, connection: NodeSignalConnection) => {
    const command = createConnectSignalCommand({ target: globalAuthoringModel, nodeId, connection, ...signalHooks });
    if (command) globalCommandManager.execute(command);
  }, []);
  const editSignalConnection = useCallback((nodeId: string, oldConn: NodeSignalConnection, newConn: NodeSignalConnection) => {
    const command = createEditSignalConnectionCommand({ target: globalAuthoringModel, nodeId, oldConn, newConn, ...signalHooks });
    if (command) globalCommandManager.execute(command);
  }, []);
  const disconnectSignal = useCallback((nodeId: string, conn: NodeSignalConnection) => {
    const command = createDisconnectSignalCommand({ target: globalAuthoringModel, nodeId, conn, ...signalHooks });
    if (command) globalCommandManager.execute(command);
  }, []);

  // AIS-19: transformação pelo Inspector = SetTransformCommand (um nó) ou de grupo (seleção múltipla)
  const updateNodeTransform = useCallback((nodeId: string, key: 'position' | 'rotation' | 'scale', value: Vec3) => {
    const scene = globalAuthoringModel.getScene();
    const node = scene.nodes[nodeId];
    if (!node) return;
    const mode: TransformMode = key === 'position' ? 'translate' : key === 'rotation' ? 'rotate' : 'scale';
    const read = (k: 'position' | 'rotation' | 'scale', fallback: number): Vec3 => {
      const v = node.properties?.[k];
      return {
        x: typeof v?.x === 'number' ? v.x : fallback,
        y: typeof v?.y === 'number' ? v.y : fallback,
        z: typeof v?.z === 'number' ? v.z : fallback,
      };
    };
    const before: NodeTransform = { position: read('position', 0), rotation: read('rotation', 0), scale: read('scale', 1) };

    const st = useEditorStore.getState();
    const selected = [...new Set([...(st.selectedNodeId ? [st.selectedNodeId] : []), ...st.multiSelectedNodeIds])];
    const targets = groupTransformTargets(scene.nodes, selected, scene.rootNodeId);

    let items;
    if (targets.length > 1 && targets.includes(nodeId)) {
      const delta = deltaFromInspectorEdit(mode, before[key], value, parentWorldMatrixOf(scene.nodes, nodeId));
      items = planGroupTransform(scene.nodes, targets, mode, delta).map((p) => toSetTransformItem(p.nodeId, p.before, p.after));
    } else {
      items = [toSetTransformItem(nodeId, before, { ...before, [key]: { ...value } })];
    }

    const command = createSetTransformCommand({
      mode,
      items,
      apply: (id, t) => {
        globalAuthoringModel.updateNodeProperties(id, { position: t.position, rotation: t.rotation, scale: t.scale });
        setActiveScene(globalAuthoringModel.getScene());
      },
    });
    if (command) globalCommandManager.execute(command);
  }, []);

  // Ensure the scene always follows the general rule of having an initial default 3D world node (World3D)
  useEffect(() => {
    const currentScene = globalAuthoringModel.getScene();
    if (!currentScene.rootNodeId || !currentScene.nodes[currentScene.rootNodeId]) {
      const root = createDefaultNode('Spatial', 'World3D', null);
      globalAuthoringModel.setScene((prev) => {
        const existingNodeIds = Object.keys(prev.nodes);
        const children = existingNodeIds.filter((id) => id !== root.id);
        const updatedNodes = { ...prev.nodes, [root.id]: { ...root, childrenIds: children } };
        children.forEach((childId) => {
          if (updatedNodes[childId] && !updatedNodes[childId].parentId) {
            updatedNodes[childId] = {
              ...updatedNodes[childId],
              parentId: root.id,
            };
          }
        });
        return {
          ...prev,
          rootNodeId: root.id,
          nodes: updatedNodes,
        };
      });
      setActiveScene(globalAuthoringModel.getScene());
      selectNode(root.id);
    }
  }, []);

  // Add new node to active scene via AuthoringModel
  const addNode = useCallback((
    type: NodeType,
    parentId?: string | null,
    customName?: string,
    initialProperties?: Record<string, any>
  ): GameNode => {
    const scene = globalAuthoringModel.getScene();
    // Enforce 0..1 Environment node per scene
    if (type === 'Environment') {
      const existingEnvNode = Object.values(scene.nodes).find((n) => n.type === 'Environment');
      if (existingEnvNode || scene.environmentNodeId) {
        const envNode = existingEnvNode || (scene.nodes[scene.environmentNodeId || ''] as GameNode);
        addLog('warn', `Scene already has an Environment node ("${envNode?.name}"). Exactly 0..1 Environment node is permitted per scene.`);
        if (envNode) selectNode(envNode.id);
        return envNode;
      }
    }

    const hasRoot = scene.rootNodeId && scene.nodes[scene.rootNodeId];
    const isFirstNode = !hasRoot;
    const effectiveType = isFirstNode ? 'Spatial' : type;
    const effectiveName = isFirstNode ? 'World3D' : customName;
    const pId = isFirstNode ? null : (parentId !== undefined ? parentId : (selectedNodeId || scene.rootNodeId));

    const newNode = createDefaultNode(effectiveType, effectiveName, pId, isFirstNode ? undefined : initialProperties);

    // AIS-20: AddNodeCommand — Undo remove o nó; Redo reinsere o mesmo nó (mesmo id)
    globalCommandManager.execute(
      createAddNodeCommand({
        target: globalAuthoringModel,
        node: newNode,
        parentId: pId,
        afterExecute: () => {
          setActiveScene(globalAuthoringModel.getScene());
          selectNode(newNode.id);
          addLog('log', `Created node ${newNode.name} (${newNode.type})`);
        },
        afterUndo: () => {
          setActiveScene(globalAuthoringModel.getScene());
          selectNode(pId);
        },
      })
    );

    return newNode;
  }, [selectedNodeId, addLog]);

  // AIS-20: DeleteNodeCommand (um nó ou seleção múltipla = UM Command; subárvore serializada para o Undo)
  const deleteNodes = useCallback((nodeIds: readonly string[]) => {
    const scene = globalAuthoringModel.getScene();
    const firstId = nodeIds.find((id) => id !== scene.rootNodeId && scene.nodes[id]);
    const fallbackId = (firstId && scene.nodes[firstId]?.parentId) || scene.rootNodeId;
    const selectedBefore = useEditorStore.getState();
    const selectionBefore = [...new Set([...(selectedBefore.selectedNodeId ? [selectedBefore.selectedNodeId] : []), ...selectedBefore.multiSelectedNodeIds])];
    const command = createDeleteNodeCommand({
      target: globalAuthoringModel,
      nodeIds,
      afterExecute: () => {
        setActiveScene(globalAuthoringModel.getScene());
        const alive = (id: string) => Boolean(globalAuthoringModel.getNode(id));
        // a invalidação automática da seleção já rodou: se algum selecionado foi excluído e não
        // sobrou primário, a seleção vai para o pai do nó excluído (ou a raiz)
        const lostSelection = selectionBefore.some((id) => !alive(id));
        const st = useEditorStore.getState();
        if (lostSelection && (!st.selectedNodeId || !alive(st.selectedNodeId))) selectNode(fallbackId);
        setMultiSelectedNodeIds(useEditorStore.getState().multiSelectedNodeIds.filter(alive));
        addLog('log', nodeIds.length > 1 ? `Deleted ${nodeIds.length} nodes` : 'Deleted node');
      },
      afterUndo: () => {
        setActiveScene(globalAuthoringModel.getScene());
        if (firstId) selectNode(firstId);
      },
    });
    if (!command) {
      if (nodeIds.includes(scene.rootNodeId)) addLog('warn', 'Cannot delete root node');
      return;
    }
    globalCommandManager.execute(command);
  }, [addLog]);

  const deleteNode = useCallback((nodeId: string) => deleteNodes([nodeId]), [deleteNodes]);

  // Duplicate node
  const duplicateNode = useCallback((nodeId: string) => {
    const source = activeScene.nodes[nodeId];
    if (!source) return;

    const clonedNode: GameNode = {
      ...JSON.parse(JSON.stringify(source)),
      id: `${source.type.toLowerCase()}_${Math.random().toString(36).substring(2, 9)}`,
      name: `${source.name}_copy`,
      childrenIds: [],
    };

    addNode(source.type, source.parentId, clonedNode.name);
  }, [activeScene.nodes, addNode]);

  /** AIS-02/20: exclusão em lote como UM Command — Ctrl+Z restaura todos os nós (raiz nunca é excluída). */
  const deleteMultipleNodes = useCallback((nodeIds: string[]) => deleteNodes(nodeIds), [deleteNodes]);

  // Rename node — wrapped in a Command so it is undoable (Ctrl+Z).
  const renameNode = useCallback((nodeId: string, newName: string) => {
    if (!newName.trim()) return;
    const scene = globalAuthoringModel.getScene();
    const node = scene.nodes[nodeId];
    if (!node) return;
    const oldName = node.name;
    const trimmedName = newName.trim();
    globalCommandManager.execute({
      name: `Rename node "${oldName}" → "${trimmedName}"`,
      execute: () => {
        globalAuthoringModel.renameNode(nodeId, trimmedName);
        setActiveScene(globalAuthoringModel.getScene());
      },
      undo: () => {
        globalAuthoringModel.renameNode(nodeId, oldName);
        setActiveScene(globalAuthoringModel.getScene());
      },
    });
  }, []);

  // AIS-20: ReparentNodeCommand — troca o pai (ou a ordem) preservando a pose mundial; Undo restaura tudo
  const reparentOrReorderNode = useCallback((nodeId: string, newParentId: string | null, targetIndex?: number) => {
    const command = createReparentNodeCommand({
      target: globalAuthoringModel,
      nodeId,
      newParentId,
      targetIndex,
      afterExecute: () => setActiveScene(globalAuthoringModel.getScene()),
      afterUndo: () => setActiveScene(globalAuthoringModel.getScene()),
    });
    if (command) globalCommandManager.execute(command);
  }, []);

  // Toggle visibility — wrapped in a Command so it is undoable.
  const toggleNodeVisibility = useCallback((nodeId: string) => {
    const scene = globalAuthoringModel.getScene();
    const node = scene.nodes[nodeId];
    if (!node) return;
    const wasVisible = node.visible;
    globalCommandManager.execute({
      name: `${wasVisible ? 'Hide' : 'Show'} node "${node.name}"`,
      execute: () => {
        globalAuthoringModel.toggleNodeVisibility(nodeId);
        setActiveScene(globalAuthoringModel.getScene());
      },
      undo: () => {
        globalAuthoringModel.toggleNodeVisibility(nodeId);
        setActiveScene(globalAuthoringModel.getScene());
      },
    });
  }, []);

  // AIS-17: batch visibility — one Command for the whole selection.
  const setNodesVisibility = useCallback((nodeIds: string[], visible: boolean) => {
    const scene = globalAuthoringModel.getScene();
    const changing = [...new Set(nodeIds)].filter((id) => scene.nodes[id] && scene.nodes[id].visible !== visible);
    if (changing.length === 0) return;
    const flip = () => {
      for (const id of changing) globalAuthoringModel.toggleNodeVisibility(id);
      setActiveScene(globalAuthoringModel.getScene());
    };
    globalCommandManager.execute({
      name: `${visible ? 'Show' : 'Hide'} ${changing.length} node${changing.length > 1 ? 's' : ''}`,
      execute: flip,
      undo: flip,
    });
  }, []);

  // Toggle lock — wrapped in a Command so it is undoable.
  const toggleNodeLock = useCallback((nodeId: string) => {
    const scene = globalAuthoringModel.getScene();
    const node = scene.nodes[nodeId];
    if (!node) return;
    const wasLocked = node.locked;
    globalCommandManager.execute({
      name: `${wasLocked ? 'Unlock' : 'Lock'} node "${node.name}"`,
      execute: () => {
        globalAuthoringModel.toggleNodeLock(nodeId);
        setActiveScene(globalAuthoringModel.getScene());
      },
      undo: () => {
        globalAuthoringModel.toggleNodeLock(nodeId);
        setActiveScene(globalAuthoringModel.getScene());
      },
    });
  }, []);

  // Persist the current scene into the project (raw write). Callers go through
  // `saveCurrentScene` (DocumentManager: checkpoint clean + external-change guard).
  const persistCurrentScene = useCallback(() => {
    const currentScene = globalAuthoringModel.getScene();
    // AIS-29b: arquivo que não pôde ser lido nunca é sobrescrito (use Salvar como)
    const blockedReason = writeBlockedReason(currentScene.path);
    if (blockedReason) {
      addLog('error', `Salvamento bloqueado: ${currentScene.path} não pôde ser lido (${blockedReason}). O arquivo original foi preservado; use "Salvar como" para gravar em outro caminho.`);
      return;
    }
    // AIS-29b: backup do arquivo original antes de regravar um arquivo migrado
    const backupKey = flushPendingBackup(globalAuthoringModel.getProject().id, currentScene.path, ProjectStorage.backupWriter);
    if (backupKey) addLog('log', `Backup do arquivo antes da migração: ${backupKey}`);
    const sceneToSave = {
      ...currentScene,
      schemaVersion: 1,
      updatedAt: new Date().toISOString(),
    };
    globalAuthoringModel.loadScene(sceneToSave);
    // AIS-29: formato canônico compacto (versionado, determinístico, Missing Nodes regravados intactos)
    const sceneJSON = serializeSceneToJson(sceneToSave);
    const proj = globalAuthoringModel.getProject();
    const updatedFiles = {
      ...proj.files,
      [sceneToSave.path]: {
        path: sceneToSave.path,
        name: sceneToSave.name + '.scene.json',
        isDirectory: false,
        extension: 'json',
        content: sceneJSON,
        size: sceneJSON.length,
        updatedAt: new Date().toISOString(),
      },
    };
    const updatedProject = {
      ...proj,
      lastOpenedScene: sceneToSave.path,
      updatedAt: new Date().toISOString(),
      files: updatedFiles,
    };
    globalAuthoringModel.setProject(updatedProject);
    // AIS-18b: só o arquivo da cena (não apaga alterações externas de outros arquivos)
    ProjectStorage.saveProjectFiles(updatedProject, [sceneToSave.path]);
    setProject(updatedProject);
    setActiveScene(sceneToSave);
    addLog('log', `Scene '${sceneToSave.name}' saved successfully (${sceneJSON.length} bytes).`);
  }, [addLog]);

  // AIS-18b: public save = DocumentManager (sync, so "save then switch scene" stays correct).
  const saveCurrentScene = useCallback(() => {
    saveSceneDocument();
  }, []);

  const loadSceneImmediate = useCallback((path: string) => {
    const proj = globalAuthoringModel.getProject();
    const file = proj.files[path];
    if (!file || !file.content) {
      addLog('error', `Could not open scene at ${path}`);
      return;
    }

    // AIS-29: leitura tolerante (formato canônico ou antigo); erro irrecuperável nunca abre a cena pela metade
    const result = parseSceneJson(file.content, path, { isKnownContribution: isKnownLogicContribution });
    if (!result.ok || !result.scene) {
      addLog('error', `Failed to open scene at ${path}: ${result.diagnostics.find((d) => d.severity === 'error')?.message ?? 'cena inválida'}`);
      return;
    }
    const loaded = result.scene;
    unblockWrites(path);
    if (result.migration?.migrated) notePendingBackup(path, result.migration.fromVersion, file.content);
    globalAuthoringModel.loadScene(loaded);
    setActiveScene(loaded);
    selectNode(loaded.rootNodeId);
    addLog('log', `Opened scene: ${loaded.name}`);
    publishSceneDiagnostics(path, result.diagnostics, loaded.nodes);
  }, [addLog]);

  const loadScene = useCallback((path: string) => {
    // AIS-18b: nunca descartar alterações não salvas em silêncio (diálogo do app)
    if (path === globalAuthoringModel.getScene().path) {
      loadSceneImmediate(path);
      return;
    }
    guardDiscardChanges(() => loadSceneImmediate(path));
  }, [loadSceneImmediate]);

  const createNewSceneImmediate = useCallback((type: '3D' | 'Empty') => {
    // AIS-29f: Add = função pura (nome padrão único em res://scenes/, sceneId novo, entrada no project.json)
    const added = addScene(globalAuthoringModel.getProject(), type);
    const parsed = parseSceneJson(added.project.files[added.path].content ?? '', added.path);
    if (!parsed.ok || !parsed.scene) {
      addLog('error', `Não foi possível criar a cena: ${parsed.diagnostics.find((d) => d.severity === 'error')?.message ?? 'inválida'}`);
      return;
    }
    const newScene = parsed.scene;
    globalAuthoringModel.setProject(added.project);
    globalAuthoringModel.loadScene(newScene);
    ProjectStorage.saveProject(added.project);
    setProject(added.project);
    setActiveScene(newScene);
    selectNode(newScene.rootNodeId);
    addLog('log', `Created new scene: ${newScene.name}`);
  }, [addLog]);

  /** AIS-29f: abre a cena `path` (com a confirmação do DocumentManager se a atual tiver alterações) e então executa `then`. */
  const openSceneThen = useCallback((path: string, then: () => void) => {
    if (path === globalAuthoringModel.getScene().path) {
      then();
      return;
    }
    guardDiscardChanges(() => {
      loadSceneImmediate(path);
      then();
    });
  }, [loadSceneImmediate]);

  const createNewScene = useCallback((type: '3D' | 'Empty') => {
    guardDiscardChanges(() => createNewSceneImmediate(type));
  }, [createNewSceneImmediate]);

  const saveSceneAs = useCallback((newPath: string) => {
    const currentScene = globalAuthoringModel.getScene();
    const name = newPath.split('/').pop()?.replace('.scene.json', '') || 'Scene';
    const updatedScene: SceneData = {
      ...currentScene,
      name,
      path: newPath,
      updatedAt: new Date().toISOString(),
    };
    const sceneJSON = serializeSceneToJson(updatedScene);
    const proj = globalAuthoringModel.getProject();
    const updatedProject = {
      ...proj,
      files: {
        ...proj.files,
        [newPath]: {
          path: newPath,
          name: name + '.scene.json',
          isDirectory: false,
          extension: 'json',
          content: sceneJSON,
          size: sceneJSON.length,
          updatedAt: new Date().toISOString(),
        },
      },
    };

    preserveHistoryOnNextSceneLoad();
    globalAuthoringModel.loadScene(updatedScene);
    globalAuthoringModel.setProject(updatedProject);
    ProjectStorage.saveProject(updatedProject);
    setProject(updatedProject);
    setActiveScene(updatedScene);
    addLog('log', `Saved scene as ${newPath}`);
  }, [addLog]);

  const updateScenePostProcessing = useCallback((settings: Partial<PostProcessingSettings>) => {
    globalAuthoringModel.setScene((prev) => {
      const currentPP = prev.postProcessing || DEFAULT_POST_PROCESSING;
      return {
        ...prev,
        postProcessing: {
          ...currentPP,
          ...settings,
        },
        updatedAt: new Date().toISOString(),
      };
    });
    setActiveScene(globalAuthoringModel.getScene());
    addLog('log', `Updated post processing effects for ${globalAuthoringModel.getScene().name}`);
  }, [addLog]);

  const updateSceneFog = useCallback((settings: Partial<SceneFogSettings>) => {
    globalAuthoringModel.setScene((prev) => {
      const currentFog = prev.fog || DEFAULT_SCENE_FOG;
      const updatedFog = {
        ...currentFog,
        ...settings,
      };

      // AIS-06: Canonical Environment GameNode is the authority
      const envNodeId = prev.environmentNodeId || Object.values(prev.nodes).find((n) => n.type === 'Environment')?.id;
      let updatedNodes = prev.nodes;
      if (envNodeId && prev.nodes[envNodeId]) {
        const envNode = prev.nodes[envNodeId];
        updatedNodes = {
          ...prev.nodes,
          [envNodeId]: {
            ...envNode,
            properties: {
              ...envNode.properties,
              ...(settings.enabled !== undefined ? { fogEnabled: settings.enabled } : {}),
              ...(settings.mode !== undefined ? { fogMode: settings.mode } : {}),
              ...(settings.color !== undefined ? { fogColor: settings.color } : {}),
              ...(settings.density !== undefined ? { fogDensity: settings.density } : {}),
              ...(settings.near !== undefined ? { fogNear: settings.near } : {}),
              ...(settings.far !== undefined ? { fogFar: settings.far } : {}),
            },
          },
        };
      }

      return {
        ...prev,
        nodes: updatedNodes,
        fog: updatedFog,
        updatedAt: new Date().toISOString(),
      };
    });
    setActiveScene(globalAuthoringModel.getScene());
    addLog('log', `Updated atmospheric fog settings for ${globalAuthoringModel.getScene().name}`);
  }, [addLog]);

  // ── AIS-02 / AIS-06: Scene environment (ambient, background, gravity, wind, shadows)
  const updateSceneEnvironment = useCallback((settings: Partial<SceneEnvironment>) => {
    globalAuthoringModel.setScene((prev) => {
      const currentEnv = prev.environment || DEFAULT_SCENE_ENVIRONMENT;
      const updatedEnv = { ...currentEnv, ...settings };

      // AIS-06: Canonical Environment GameNode is the authority
      const envNodeId = prev.environmentNodeId || Object.values(prev.nodes).find((n) => n.type === 'Environment')?.id;
      let updatedNodes = prev.nodes;
      if (envNodeId && prev.nodes[envNodeId]) {
        const envNode = prev.nodes[envNodeId];
        updatedNodes = {
          ...prev.nodes,
          [envNodeId]: {
            ...envNode,
            properties: {
              ...envNode.properties,
              ...(settings.ambientColor !== undefined ? { ambientColor: settings.ambientColor } : {}),
              ...(settings.ambientIntensity !== undefined ? { ambientIntensity: settings.ambientIntensity } : {}),
              ...(settings.backgroundColor !== undefined ? { backgroundColor: settings.backgroundColor } : {}),
              ...(settings.realtimeShadows !== undefined ? { realtimeShadows: settings.realtimeShadows } : {}),
            },
          },
        };
      }

      return {
        ...prev,
        nodes: updatedNodes,
        environment: updatedEnv,
        environmentSettings: updatedEnv,
        updatedAt: new Date().toISOString(),
      };
    });
    setActiveScene(globalAuthoringModel.getScene());
    addLog('log', `Updated scene environment for ${globalAuthoringModel.getScene().name}`);
  }, [addLog]);

  // ── AIS-02: Authoring camera settings (fov, near, far, position, target)
  const updateSceneCameraSettings = useCallback((settings: Partial<SceneCameraSettings>) => {
    globalAuthoringModel.setScene((prev) => ({
      ...prev,
      cameraSettings: {
        ...(prev.cameraSettings || DEFAULT_SCENE_CAMERA),
        ...settings,
      },
      updatedAt: new Date().toISOString(),
    }));
    setActiveScene(globalAuthoringModel.getScene());
  }, []);

  // File Operations (delegating exclusively to AuthoringModel + ProjectStorage)
  const createFolder = useCallback((path: string) => {
    const cleanPath = path.endsWith('/') ? path : path + '/';
    const name = cleanPath.split('/').filter(Boolean).pop() || 'folder';
    const proj = globalAuthoringModel.getProject();
    const updated = {
      ...proj,
      files: {
        ...proj.files,
        [cleanPath]: {
          path: cleanPath,
          name,
          isDirectory: true,
          updatedAt: new Date().toISOString(),
        },
      },
    };
    globalAuthoringModel.setProject(updated);
    ProjectStorage.saveProject(updated);
    addLog('log', `Created folder: ${cleanPath}`);
  }, [addLog]);

  const createFile = useCallback((path: string, content = '') => {
    const name = path.split('/').pop() || 'file';
    const ext = name.includes('.') ? name.split('.').pop() : '';
    const proj = globalAuthoringModel.getProject();
    const updated = {
      ...proj,
      files: {
        ...proj.files,
        // AIS-28c: sobrescrever o arquivo mantém `resourceId` e as configurações de importação
        [path]: carryResourceMeta(proj.files[path], {
          path,
          name,
          isDirectory: false,
          extension: ext,
          content,
          size: content.length,
          updatedAt: new Date().toISOString(),
        }),
      },
    };
    globalAuthoringModel.setProject(updated);
    // AIS-18b: só este arquivo (não apaga alterações externas de outros arquivos)
    ProjectStorage.saveProjectFiles(updated, [path]);
    addLog('log', `Saved file: ${path}`);
  }, [addLog]);

  // AIS-32c: o console do editor é UM consumidor do DiagnosticService (o que é novo ou mudou vira linha de log)
  useEffect(
    () =>
      globalDiagnosticService.subscribeEvents((event) => {
        if (event.kind === 'reported' && event.announce) addLog(consoleTypeOf(event.diagnostic.severity), formatDiagnosticLine(event.diagnostic));
      }),
    [addLog]
  );

  const importFileContent = useCallback((path: string, content: string, name: string) => {
    createFile(path, content);
    addLog('log', `Imported ${name}`);
  }, [createFile, addLog]);

  // Code / Script Editor actions (delegating to EditorStore)
  const openFileInScriptEditor = useCallback((path: string, openAsModal = false) => {
    openScriptTab(path);
    if (openAsModal) {
      setIsScriptEditorModalOpen(true);
    } else {
      setWorkspaceMode('Script');
    }
  }, [openScriptTab, setIsScriptEditorModalOpen, setWorkspaceMode]);

  const updateFileContent = useCallback((path: string, content: string) => {
    createFile(path, content);
  }, [createFile]);

  // Game Simulation controls (delegating to EditorStore + AuthoringModel snapshot)
  /** AIS-44c: diagnóstico `blocking` da cena impede o Play (fonte única: DiagnosticService); mostra `[código] mensagem` no Output. */
  const playBlocked = useCallback((): boolean => {
    const lines = playBlockLines(globalDiagnosticService, globalAuthoringModel.getScene().path);
    if (lines.length === 0) return false;
    addLog('error', 'Play bloqueado por diagnóstico:');
    for (const line of lines) addLog('error', line);
    return true;
  }, [addLog]);

  const playProject = useCallback(() => {
    if (playBlocked()) return;
    const snapshot = globalAuthoringModel.createSceneSnapshot();
    // AIS-44b: RuntimeSession = autoridade única do Play (cena viva, variáveis, regras, Behaviors, diagnósticos efêmeros)
    const session = startPlaySession({ snapshot, mode: 'project', globals: globalAuthoringModel.getProject().globalVariables ?? [], defaultLinearDamp: normalizeSettings(globalAuthoringModel.getProject().settings).physics.defaultLinearDamp });
    setPlayState(true, false, 'project');
    setWorkspaceMode('3D');
    addLog('log', `--- Simulation Started in Viewport (snapshot: ${snapshot.snapshotId.slice(0, 16)}...) ---`);
    addLog('log', `Runtime: ${session.scene.getAllInstances().length} instâncias, ${session.sceneManager.liveObjectCount} objetos vivos (separados do editor).`);
  }, [addLog, playBlocked, setPlayState, setWorkspaceMode]);

  const playScene = useCallback(() => {
    if (playBlocked()) return;
    const snapshot = globalAuthoringModel.createSceneSnapshot();
    const session = startPlaySession({ snapshot, mode: 'scene', globals: globalAuthoringModel.getProject().globalVariables ?? [], defaultLinearDamp: normalizeSettings(globalAuthoringModel.getProject().settings).physics.defaultLinearDamp });
    setPlayState(true, false, 'scene');
    addLog('log', `--- Simulation Started (${activeScene.name}, snapshot: ${snapshot.snapshotId.slice(0, 16)}...) ---`);
    addLog('log', `Runtime: ${session.scene.getAllInstances().length} instâncias, ${session.sceneManager.liveObjectCount} objetos vivos (separados do editor).`);
  }, [activeScene.name, addLog, playBlocked, setPlayState]);

  const pauseGame = useCallback(() => {
    pausePlaySession(!isPaused);
    setPlayState(isPlaying, !isPaused, playMode);
    addLog('log', isPaused ? 'Simulation resumed.' : 'Simulation paused.');
  }, [isPlaying, isPaused, playMode, setPlayState, addLog]);

  const stopGame = useCallback(() => {
    // AIS-44b: descarta a sessão inteira (runner, Behaviors, assinaturas, cena viva, variáveis, diagnósticos efêmeros); o autoral não é tocado
    const session = getActiveRuntimeSession();
    const hadRuntime = session?.currentScene != null;
    stopPlaySession();
    setPlayState(false, false, null);
    // Invariant: authoring scene remains intact; restore active scene from authoring model authority
    setActiveScene(globalAuthoringModel.getScene());
    addLog('log', '--- Simulation Stopped (Authoring State Intact) ---');
    if (hadRuntime) addLog('log', 'Runtime descartado (sessão encerrada; 0 objetos vivos).');
  }, [setPlayState, addLog]);

  // AIS-44: o executor de Visual Logic escreve no Output (print_log, avisos, erros) e pode pedir "Quit Game"
  useEffect(() => {
    setLogicSessionHooks({
      output: (level, message) => addLog(level, message),
      quitGame: stopGame,
      // AIS-44b: destino de Change Scene → snapshot (lê o projeto/cena aberta; nunca escreve no autoral)
      resolveScene: (path) => {
        const active = globalAuthoringModel.getScene();
        if (active.path === path) return createRuntimeSnapshot(active);
        const file = globalAuthoringModel.getProject().files[path];
        if (!file?.content) throw new Error(`a cena "${path}" não existe no projeto`);
        const parsed = parseSceneJson(file.content, path, { isKnownContribution: isKnownLogicContribution });
        if (!parsed.ok || !parsed.scene) throw new Error(parsed.diagnostics.find((d) => d.severity === 'error')?.message ?? 'cena inválida');
        return createRuntimeSnapshot(parsed.scene);
      },
    });
    return () => setLogicSessionHooks({});
  }, [addLog, stopGame]);

  // Visual Logic Behavior actions (AIS-39: toda edição vira Command). AIS-41b: a porta lê e grava `GameNode.behaviors` pelo
  // AuthoringModel (nunca um estado paralelo).
  const behaviorStore = useMemo<BehaviorStore>(
    () => ({
      get: () => collectBehaviors(globalAuthoringModel.getScene()),
      set: (next) => {
        const orphans = applyBehaviorList(globalAuthoringModel, next);
        setActiveScene(globalAuthoringModel.getScene());
        if (orphans.length > 0) console.warn(`[Behaviors] ${orphans.length} Behavior(s) com alvo inexistente não foram gravados: ${orphans.map((o) => o.name).join(", ")}`);
      },
    }),
    []
  );
  const behaviorOps = useMemo(() => createBehaviorOps(behaviorStore, (command) => globalCommandManager.execute(command)), [behaviorStore]);

  // AIS-43: variáveis. Globais = `ProjectData.globalVariables` (gravadas no projeto); locais = `GameNode.variables` (cena).
  const variableOps = useMemo(
    () =>
      createVariableOps({
        globals: {
          get: () => globalAuthoringModel.getProject().globalVariables ?? [],
          set: (next) => {
            const updated = { ...globalAuthoringModel.getProject(), globalVariables: next };
            ProjectStorage.saveProject(updated);
            globalAuthoringModel.setProject(updated);
          },
        },
        locals: {
          get: (nodeId) => globalAuthoringModel.getScene().nodes[nodeId]?.variables,
          set: (nodeId, next) => {
            globalAuthoringModel.setNodeVariables(nodeId, next);
            setActiveScene(globalAuthoringModel.getScene());
          },
        },
        behaviors: behaviorStore,
        execute: (command) => globalCommandManager.execute(command),
        resolveNodeId: (ref) => {
          const nodes = globalAuthoringModel.getScene().nodes;
          if (nodes[ref]) return ref;
          const byName = Object.values(nodes).filter((n) => n.name === ref);
          return byName.length === 1 ? byName[0].id : undefined;
        },
      }),
    [behaviorStore]
  );

  const addBehavior = useCallback((behavior: Behavior) => {
    behaviorOps.add(behavior);
    addLog('log', `Attached behavior: ${behavior.name}`);
  }, [behaviorOps, addLog]);

  const removeBehavior = useCallback((id: string) => {
    behaviorOps.remove(id);
    addLog('log', 'Removed behavior');
  }, [behaviorOps, addLog]);

  // Project settings (delegating to AuthoringModel + ProjectStorage)
  const updateProjectSettings = useCallback((newSettings: ProjectSettings): { ok: true } | { ok: false; error: string } => {
    const parsed = ProjectSettingsV1Schema.safeParse(newSettings);
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? 'Configurações inválidas.' };
    const proj = globalAuthoringModel.getProject();
    // `name` é canônico e `general.projectName` o espelha (mesma função do renomear do Gerenciador de Projetos)
    const updated = applySettingsToProject(proj, parsed.data as ProjectSettings);
    if (!ProjectStorage.saveProject(updated)) return { ok: false, error: 'Não foi possível gravar o projeto (armazenamento cheio?).' };
    globalAuthoringModel.setProject(updated);
    addLog('log', 'Project settings updated.');
    return { ok: true };
  }, [addLog]);

  const switchProjectImmediate = useCallback((newProj: ProjectData) => {
    globalAuthoringModel.loadProject(newProj);
    ProjectStorage.saveProject(newProj);
    // Load main scene
    const sceneFile = newProj.files[newProj.lastOpenedScene] || newProj.files[newProj.settings.general.mainScene];
    if (sceneFile && sceneFile.content) {
      const result = parseSceneJson(sceneFile.content, sceneFile.path, { isKnownContribution: isKnownLogicContribution });
      if (result.ok && result.scene) {
        const sc: SceneData = result.scene;
        unblockWrites(sceneFile.path);
        if (result.migration?.migrated) notePendingBackup(sceneFile.path, result.migration.fromVersion, sceneFile.content);
        globalAuthoringModel.loadScene(sc);
        selectNode(sc.rootNodeId);
        publishSceneDiagnostics(sceneFile.path, result.diagnostics, sc.nodes);
      } else {
        const reason = result.diagnostics.find((d) => d.severity === 'error')?.message ?? 'cena inválida';
        // a cena em memória NÃO é a deste arquivo: salvar por cima o destruiria
        blockWrites(sceneFile.path, reason);
        addLog('error', `Failed to load project scene: ${reason}`);
      }
    }
    addLog('log', `Switched to project: ${newProj.name}`);
  }, [addLog, selectNode]);

  const switchProject = useCallback((newProj: ProjectData) => {
    guardDiscardChanges(() => switchProjectImmediate(newProj), 'all');
  }, [switchProjectImmediate]);

  // AIS-18b: reload the persisted scene into the authoring state (conflict resolution "reload").
  const reloadSceneFromStorage = useCallback(() => {
    const current = globalAuthoringModel.getProject();
    const stored = ProjectStorage.loadProject(current.id);
    const path = globalAuthoringModel.getScene().path;
    const file = stored?.files[path];
    if (!stored || !file?.content) {
      addLog('error', `Could not reload scene from disk: ${path}`);
      return;
    }
    try {
      const result = parseSceneJson(file.content, path, { isKnownContribution: isKnownLogicContribution });
      if (!result.ok || !result.scene) throw new Error(result.diagnostics.find((d) => d.severity === 'error')?.message ?? 'invalid scene');
      const loaded = result.scene;
      if (result.migration?.migrated) notePendingBackup(path, result.migration.fromVersion, file.content);
      unblockWrites(path);
      globalAuthoringModel.setProject(stored);
      globalAuthoringModel.loadScene(loaded);
      globalCommandManager.clearHistory();
      setProject(stored);
      setActiveScene(loaded);
      selectNode(loaded.rootNodeId);
      addLog('log', `Scene reloaded from disk: ${loaded.name}`);
      publishSceneDiagnostics(path, result.diagnostics, loaded.nodes);
    } catch {
      addLog('error', `Failed to reload scene from disk: ${path}`);
    }
  }, [addLog, selectNode]);

  // AIS-18b: write a copy of the in-memory scene without touching the (externally changed) original.
  const saveSceneCopy = useCallback(() => {
    const scene = globalAuthoringModel.getScene();
    const copyPath = `${scene.path.replace(/.scene.json$/, '')}_copy.scene.json`;
    const copy: SceneData = { ...scene, name: `${scene.name}_copy`, path: copyPath, updatedAt: new Date().toISOString() };
    const json = serializeSceneToJson(copy);
    const entry = {
      path: copyPath,
      name: `${copy.name}.scene.json`,
      isDirectory: false,
      extension: 'json',
      content: json,
      size: json.length,
      updatedAt: copy.updatedAt,
    };
    const stored = ProjectStorage.loadProject(globalAuthoringModel.getProject().id) ?? globalAuthoringModel.getProject();
    ProjectStorage.saveProject({ ...stored, files: { ...stored.files, [copyPath]: entry }, updatedAt: copy.updatedAt });
    globalAuthoringModel.setProject((prev) => ({ ...prev, files: { ...prev.files, [copyPath]: entry } }));
    setProject(globalAuthoringModel.getProject());
    addLog('log', `Scene copy saved: ${copyPath}`);
  }, [addLog]);

  useEffect(() => {
    setSceneDocumentHandlers({ save: persistCurrentScene, reload: reloadSceneFromStorage, saveCopy: saveSceneCopy });
  }, [persistCurrentScene, reloadSceneFromStorage, saveSceneCopy]);

  // AIS-18b: persistência dos documentos de script/texto (rascunho vive em scriptDocuments).
  useEffect(() => {
    setScriptDocumentHandlers({
      readPersisted: (path) => ProjectStorage.loadProject(globalAuthoringModel.getProject().id)?.files[path]?.content ?? null,
      write: (path, content) => createFile(path, content),
      reload: (path) => {
        const stored = ProjectStorage.loadProject(globalAuthoringModel.getProject().id);
        const file = stored?.files[path];
        if (!stored || !file) return;
        globalAuthoringModel.setProject((prev) => ({ ...prev, files: { ...prev.files, [path]: file } }));
        setProject(globalAuthoringModel.getProject());
        addLog('log', `File reloaded from disk: ${path}`);
      },
      saveCopy: (path, content) => createFile(path, content),
    });
  }, [createFile, addLog]);

  useEffect(() => bindEditorServices(), []);

  // Undo / Redo triggers
  const undo = useCallback(() => {
    if (globalCommandManager.canUndo()) {
      globalCommandManager.undo();
      addLog('log', 'Undo performed');
    }
  }, [addLog]);

  const redo = useCallback(() => {
    if (globalCommandManager.canRedo()) {
      globalCommandManager.redo();
      addLog('log', 'Redo performed');
    }
  }, [addLog]);

  return (
    <EditorContext.Provider
      value={{
        project,
        activeScene,
        selectedNodeId,
        selectedNode,
        workspaceMode,
        isPlaying,
        playMode,
        isPaused,
        bottomTab,
        isBottomOpen,
        logs,
        behaviors,
        isProjectSettingsOpen,
        isProjectManagerOpen,
        isCreateNodeModalOpen,
        canUndo,
        canRedo,
        // ── AIS-02 ────────────────────────────────────────────────────────────
        manipulationMode,
        setManipulationMode,
        multiSelectedNodeIds,
        setMultiSelectedNodeIds,
        toggleMultiSelectNode,
        applyEditorMutation,
        applyRuntimeMutation,
        // ─────────────────────────────────────────────────────────────────────
        setWorkspaceMode,
        selectNode,
        updateNodeProperties,
        updateNodeTransform,
        changeNodeProperty,
        changeNodeProperties,
        connectSignal,
        editSignalConnection,
        disconnectSignal,
        addNode,
        deleteNode,
        deleteMultipleNodes,
        duplicateNode,
        renameNode,
        reparentOrReorderNode,
        toggleNodeVisibility,
        setNodesVisibility,
        toggleNodeLock,
        saveCurrentScene,
        loadScene,
        createNewScene,
        saveSceneAs,
        createFolder,
        createFile,
        importFileContent,
        addLog,
        clearLogs,
        openSceneThen,
        playProject,
        playScene,
        pauseGame,
        stopGame,
        setBottomTab,
        setIsBottomOpen,
        addBehavior,
        removeBehavior,
        behaviorOps,
        variableOps,
        setIsProjectSettingsOpen,
        updateProjectSettings,
        isPostProcessingOpen,
        setIsPostProcessingOpen,
        updateScenePostProcessing,
        isTerrainEditorOpen,
        setIsTerrainEditorOpen,
        isTreeEditorOpen,
        setIsTreeEditorOpen,
        isFogModalOpen,
        setIsFogModalOpen,
        updateSceneFog,
        isSoundModalOpen,
        setIsSoundModalOpen,
        isParticleModalOpen,
        setIsParticleModalOpen,
        isAssetImportModalOpen,
        setIsAssetImportModalOpen,
        setIsProjectManagerOpen,
        setIsCreateNodeModalOpen,
        isTexturePreviewOpen,
        setIsTexturePreviewOpen,
        isVideoEditorOpen,
        setIsVideoEditorOpen,
        isSpriteEditorOpen,
        setIsSpriteEditorOpen,
        isExtensionsPanelOpen,
        setIsExtensionsPanelOpen,
        switchProject,
        // ── AIS-02: scene environment & camera ────────────────────────────────
        updateSceneEnvironment,
        updateSceneCameraSettings,
        // ─────────────────────────────────────────────────────────────────────
        undo,
        redo,
        activeScriptPath,
        openScriptTabs,
        isScriptEditorModalOpen,
        openFileInScriptEditor,
        closeScriptTab,
        setActiveScriptPath,
        setIsScriptEditorModalOpen,
        updateFileContent,
      }}
    >
      {children}
    </EditorContext.Provider>
  );
};

export function useEditor() {
  const ctx = useContext(EditorContext);
  if (!ctx) {
    throw new Error('useEditor must be used within an EditorProvider');
  }
  return ctx;
}
