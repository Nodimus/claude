import { globalAuthoringModel } from '../authoring';
import { globalCommandManager } from '../commandManager';
import { useEditorStore } from '../editorStore';
import { globalResourceRegistry } from '../resources/global';
import { deleteResource } from '../resourceDeletion';
import { hasSculptedHeights, terrainGeneratorSource } from '../terrainOps';
import { createApplyGeneratorCommand } from './generatorCommands';
import { globalGeneratorRegistry } from './generatorRegistry';

/**
 * AIS-50 — o gerador `terrain` do contrato `generatorSource` (AIS-49b). O Terrain guarda só a marca de origem
 * (`params = { preset }` + `seed`); as `properties` do nó são a fonte de verdade (como o Particle, emenda v5.1.3), então
 * "Editar no gerador" reabre o `TerrainEditorModal` a partir das propriedades do nó.
 */

export const TERRAIN_GENERATOR_ID = 'terrain';

/** Registra o gerador (idempotente): "Editar no gerador" seleciona o nó e abre o modal sobre ele. */
export function registerTerrainGenerator(): () => void {
  return globalGeneratorRegistry.register({
    id: TERRAIN_GENERATOR_ID,
    label: 'Terrain',
    open: ({ nodeId }) => {
      const store = useEditorStore.getState();
      store.selectNode(nodeId);
      store.setIsTerrainEditorOpen(true);
    },
  });
}

/**
 * Grava mudanças de `properties` do Terrain e a marca de origem atualizada como UM `MacroCommand` (um Undo); `false` se o nó não
 * existe ou nada mudou. Único ponto de gravação do Terrain (Inspector, modal e drag-and-drop).
 */
export function applyTerrainChanges(nodeId: string, changes: Record<string, any>, label: string): boolean {
  const node = globalAuthoringModel.getNode(nodeId);
  if (!node || node.type !== 'Terrain') return false;
  const source = terrainGeneratorSource({ ...node.properties, ...changes });
  const command = createApplyGeneratorCommand({ target: globalAuthoringModel, nodeId, properties: changes, source, label });
  if (!command) return false;
  globalCommandManager.execute(command);
  return true;
}

/**
 * "Regenerar geometria" de um terreno esculpido: remove o vínculo do `.height` (junto com as demais mudanças, num só Command) e
 * depois apaga o arquivo por `deleteResource` (AIS-29e; nunca `TauriBridge` direto). O Undo restaura o vínculo; o arquivo
 * apagado só volta se estiver no histórico do sistema de arquivos.
 */
export async function regenerateTerrainGeometry(nodeId: string, changes: Record<string, any>): Promise<{ applied: boolean; deletedFile: string | null }> {
  const node = globalAuthoringModel.getNode(nodeId);
  if (!node || node.type !== 'Terrain') return { applied: false, deletedFile: null };
  const resolved = hasSculptedHeights(node.properties) ? globalResourceRegistry.resolve(node.properties.heightBufferRef) : null;
  const uri = resolved?.status === 'resolved' ? resolved.entry.uri : null;
  const applied = applyTerrainChanges(nodeId, changes, 'Regenerar geometria do terreno');
  if (!applied || !uri) return { applied, deletedFile: null };
  const result = await deleteResource({ path: uri }, { confirmed: true });
  return { applied, deletedFile: result.ok ? uri : null };
}
