import type { ICommand } from '../../types/commands';
import { cloneGeneratorSource, parseGeneratorSource, type GeneratorSource } from '../../types/generatorSource';
import { createMacroCommand, type MacroCommand } from '../commands/MacroCommand';
import { createChangePropertyCommand, deepEqual, type PropertyTarget } from '../commands/ChangePropertyCommand';

/**
 * AIS-49b — "Aplicar ao nó": atualiza um nó criado por um gerador IN-PLACE (propriedades + `generatorSource`) como UM `MacroCommand`
 * (uma entrada de Undo). Nunca cria nó novo (isso é "Inserir novo", que cada gerador já faz) e não conhece nenhum gerador específico.
 */

/** Porta do `AuthoringModel` usada pelos Commands deste arquivo (facilita testar sem React). */
export interface GeneratorTarget extends PropertyTarget {
  getNode(nodeId: string): { name?: string; properties: Record<string, any>; generatorSource?: unknown } | undefined;
  setNodeGeneratorSource(nodeId: string, source: GeneratorSource | undefined): void;
}

/** Command que troca o `generatorSource` do nó; `null` se o nó não existe ou nada muda. O dado bruto anterior volta intacto no Undo. */
export function createSetGeneratorSourceCommand(input: { target: GeneratorTarget; nodeId: string; source: GeneratorSource; label?: string }): ICommand | null {
  const { target, nodeId } = input;
  const node = target.getNode(nodeId);
  if (!node) return null;
  const prevRaw = node.generatorSource;
  const next = cloneGeneratorSource(input.source);
  if (prevRaw !== undefined && deepEqual(prevRaw as any, next as any)) return null;
  return {
    label: input.label ?? 'Set Generator Source',
    execute: () => target.setNodeGeneratorSource(nodeId, cloneGeneratorSource(next)),
    undo: () => target.setNodeGeneratorSource(nodeId, prevRaw as GeneratorSource | undefined),
    redo: () => target.setNodeGeneratorSource(nodeId, cloneGeneratorSource(next)),
  } as ICommand;
}

export interface ApplyGeneratorInput {
  target: GeneratorTarget;
  nodeId: string;
  /** Propriedades (chaves/caminhos de `properties`) que o gerador produziu; só as que mudam entram no histórico. */
  properties: Readonly<Record<string, any>>;
  /** Novos parâmetros do gerador (com a marca de origem). */
  source: GeneratorSource;
  label?: string;
}

/** `MacroCommand` de "Aplicar ao nó"; `null` se o nó não existe ou nada mudou (nenhuma entrada vazia no histórico). */
export function createApplyGeneratorCommand(input: ApplyGeneratorInput): MacroCommand | null {
  const { target, nodeId } = input;
  const node = target.getNode(nodeId);
  if (!node || !parseGeneratorSource(input.source)) return null;
  const label = input.label ?? 'Aplicar ao nó';
  return createMacroCommand(label, [
    createChangePropertyCommand({ target, nodeId, changes: input.properties, label: 'Update Generated Properties' }),
    createSetGeneratorSourceCommand({ target, nodeId, source: input.source }),
  ]);
}
