import { describe, expect, it, vi } from 'vitest';
import { AuthoringModel } from '../authoring/AuthoringModel';
import { CommandManager } from '../commandManager';
import { createDefaultNode } from '../../nodes/registry';
import { createDefault3DStarterScene } from '../defaultProject';
import { deserializeScene, serializeScene } from '../serialization/sceneSerializer';
import { cloneGeneratorSource, parseGeneratorSource, type GeneratorSource } from '../../types/generatorSource';
import { createApplyGeneratorCommand, createSetGeneratorSourceCommand } from './generatorCommands';
import { generatorButtonState, openGeneratorEditor, type GeneratorEditTarget } from './generatorEditor';
import { GeneratorRegistry } from './generatorRegistry';

const SRC: GeneratorSource = { generatorId: 'tree', version: 1, params: { height: 4, leaves: { count: 3 } }, seed: 7 };

/** Modelo real com um nó gerado (`MeshInstance` com `generatorSource`) na cena inicial. */
const NONE = Symbol('sem generatorSource');
function setup(source: unknown = SRC) {
  const model = new AuthoringModel();
  const scene = createDefault3DStarterScene();
  const node = { ...createDefaultNode('MeshInstance', 'Arvore', scene.rootNodeId), id: 'gen1' } as any;
  if (source !== NONE) node.generatorSource = source;
  node.properties.height = 4;
  const root = scene.nodes[scene.rootNodeId];
  model.loadScene({ ...scene, nodes: { ...scene.nodes, gen1: node, [scene.rootNodeId]: { ...root, childrenIds: [...root.childrenIds, 'gen1'] } } });
  return model;
}

describe('GeneratorSource (AIS-49b-C06)', () => {
  it('parse valida o contrato e rejeita dado malformado', () => {
    expect(parseGeneratorSource(SRC)).toEqual(SRC);
    expect(parseGeneratorSource({ generatorId: 'x', version: 1, params: {} })).toEqual({ generatorId: 'x', version: 1, params: {} });
    for (const bad of [null, 1, [], {}, { generatorId: '', version: 1, params: {} }, { generatorId: 'x', version: 'a', params: {} }, { generatorId: 'x', version: 1, params: [] }, { generatorId: 'x', version: 1, params: {}, seed: 'z' }]) {
      expect(parseGeneratorSource(bad)).toBeNull();
    }
  });
  it('clone é profundo', () => {
    const c = cloneGeneratorSource(SRC);
    expect(c).toEqual(SRC);
    (c.params.leaves as any).count = 99;
    expect((SRC.params.leaves as any).count).toBe(3);
  });
  it('ida e volta pelo serializador de cena (incl. gerador desconhecido e dado malformado preservados)', () => {
    const model = setup({ generatorId: 'gerador_do_futuro', version: 9, params: { a: [1, 2] }, seed: 3 });
    const scene = model.getScene();
    const back = deserializeScene(serializeScene(scene), scene.path);
    expect(back.ok).toBe(true);
    expect(back.scene!.nodes.gen1.generatorSource).toEqual({ generatorId: 'gerador_do_futuro', version: 9, params: { a: [1, 2] }, seed: 3 });
    const bad = { generatorId: 7, extra: true };
    const m2 = setup(bad);
    const s2 = m2.getScene();
    expect(deserializeScene(serializeScene(s2), s2.path).scene!.nodes.gen1.generatorSource).toEqual(bad);
  });
  it('nó sem generatorSource não ganha o campo', () => {
    const scene = setup(NONE).getScene();
    expect(serializeScene(scene).nodes.gen1).not.toHaveProperty('generatorSource');
  });
});

describe('"Aplicar ao nó" (AIS-49b-C03, C04, C07)', () => {
  const next: GeneratorSource = { generatorId: 'tree', version: 1, params: { height: 9 }, seed: 8 };

  it('um MacroCommand: atualiza o nó in-place, sem nó novo, e UM Undo restaura propriedades e generatorSource', () => {
    const model = setup();
    const manager = new CommandManager();
    const before = Object.keys(model.getScene().nodes);
    const macro = createApplyGeneratorCommand({ target: model, nodeId: 'gen1', properties: { height: 9 }, source: next });
    expect(macro).not.toBeNull();
    expect(macro!.commands.length).toBe(2);
    manager.execute(macro!);
    const node = model.getNode('gen1')!;
    expect(node.properties.height).toBe(9);
    expect(node.generatorSource).toEqual(next);
    expect(Object.keys(model.getScene().nodes)).toEqual(before); // C04
    expect(manager.getHistory().length).toBe(1); // uma entrada
    manager.undo();
    expect(model.getNode('gen1')!.properties.height).toBe(4);
    expect(model.getNode('gen1')!.generatorSource).toEqual(SRC);
    manager.redo();
    expect(model.getNode('gen1')!.generatorSource).toEqual(next);
  });
  it('nada mudou ou nó inexistente ou source inválido → null (sem entrada vazia no histórico)', () => {
    const model = setup();
    expect(createApplyGeneratorCommand({ target: model, nodeId: 'gen1', properties: { height: 4 }, source: SRC })).toBeNull();
    expect(createApplyGeneratorCommand({ target: model, nodeId: 'nope', properties: { height: 1 }, source: next })).toBeNull();
    expect(createApplyGeneratorCommand({ target: model, nodeId: 'gen1', properties: {}, source: { generatorId: '' } as any })).toBeNull();
  });
  it('só params mudam: ainda gera Command; Undo devolve o dado bruto anterior', () => {
    const model = setup();
    const cmd = createSetGeneratorSourceCommand({ target: model, nodeId: 'gen1', source: { ...SRC, params: { height: 5 } } })!;
    cmd.execute();
    expect((model.getNode('gen1')!.generatorSource as GeneratorSource).params.height).toBe(5);
    cmd.undo();
    expect(model.getNode('gen1')!.generatorSource).toEqual(SRC);
  });
  it('nó sem generatorSource anterior: Undo remove o campo', () => {
    const model = setup(NONE);
    const cmd = createSetGeneratorSourceCommand({ target: model, nodeId: 'gen1', source: SRC })!;
    cmd.execute();
    expect(model.getNode('gen1')!.generatorSource).toEqual(SRC);
    cmd.undo();
    expect(model.getNode('gen1')).not.toHaveProperty('generatorSource');
  });
});

describe('Editar no gerador (AIS-49b-C01, C02, C05)', () => {
  const store = () => {
    let target: GeneratorEditTarget | null = null;
    return { startGeneratorEdit: vi.fn((t: GeneratorEditTarget) => { target = t; }), endGeneratorEdit: vi.fn(() => { target = null; }), get: () => target };
  };
  const nodeOf = (model: AuthoringModel) => model.getNode('gen1')!;

  it('C01: botão só em nó com generatorSource válido', () => {
    const reg = new GeneratorRegistry();
    reg.register({ id: 'tree', label: 'Árvore', open: () => {} });
    expect(generatorButtonState(nodeOf(setup(NONE)), reg)).toEqual({ visible: false });
    expect(generatorButtonState(nodeOf(setup({ generatorId: 1 })), reg)).toEqual({ visible: false });
    expect(generatorButtonState(nodeOf(setup()), reg)).toMatchObject({ visible: true, enabled: true, generatorId: 'tree', label: 'Árvore' });
  });
  it('gerador sem registro: botão visível, desabilitado com "em breve"; dado intacto; abrir falha sem erro nem alvo', () => {
    const reg = new GeneratorRegistry();
    const model = setup();
    const s = generatorButtonState(nodeOf(model), reg);
    expect(s).toMatchObject({ visible: true, enabled: false });
    expect((s as any).tooltip).toContain('em breve');
    const st = store();
    expect(openGeneratorEditor(nodeOf(model), st, reg)).toMatchObject({ ok: false, reason: 'unknown_generator' });
    expect(st.startGeneratorEdit).not.toHaveBeenCalled();
    expect(nodeOf(model).generatorSource).toEqual(SRC);
  });
  it('C02: abre o gerador certo com os parâmetros salvos; C05: não altera o nó', () => {
    const reg = new GeneratorRegistry();
    const open = vi.fn();
    const otherOpen = vi.fn();
    reg.register({ id: 'tree', label: 'Árvore', open });
    reg.register({ id: 'terrain', label: 'Terreno', open: otherOpen });
    const model = setup();
    const st = store();
    const before = model.getScene();
    expect(openGeneratorEditor(nodeOf(model), st, reg)).toEqual({ ok: true });
    expect(open).toHaveBeenCalledWith({ nodeId: 'gen1', source: SRC });
    expect(otherOpen).not.toHaveBeenCalled();
    expect(st.get()).toEqual({ nodeId: 'gen1', generatorId: 'tree' });
    expect(model.getScene()).toBe(before); // abrir (e fechar sem aplicar) não toca na cena
  });
  it('falha ao abrir encerra o alvo e reporta open_failed', () => {
    const reg = new GeneratorRegistry();
    reg.register({ id: 'tree', label: 'Árvore', open: () => { throw new Error('boom'); } });
    const st = store();
    expect(openGeneratorEditor(nodeOf(setup()), st, reg)).toEqual({ ok: false, reason: 'open_failed', message: 'boom' });
    expect(st.get()).toBeNull();
  });
  it('registro: register devolve unregister idempotente que não remove um substituto', () => {
    const reg = new GeneratorRegistry();
    const a = { id: 'x', label: 'A', open: () => {} };
    const b = { id: 'x', label: 'B', open: () => {} };
    const offA = reg.register(a);
    reg.register(b);
    offA();
    expect(reg.get('x')).toBe(b);
  });
});

describe('EditorStore.generatorEdit (AIS-49b)', () => {
  it('start/end; trocar de cena encerra a edição pendente, a mesma cena não', async () => {
    const { useEditorStore } = await import('../editorStore');
    const st = useEditorStore.getState();
    st.syncActiveScene({ path: 'res://scenes/A.scene.json', name: 'A' });
    st.startGeneratorEdit({ nodeId: 'gen1', generatorId: 'tree' });
    expect(useEditorStore.getState().generatorEdit).toEqual({ nodeId: 'gen1', generatorId: 'tree' });
    st.syncActiveScene({ path: 'res://scenes/A.scene.json', name: 'A (renomeada)' });
    expect(useEditorStore.getState().generatorEdit).not.toBeNull();
    st.syncActiveScene({ path: 'res://scenes/B.scene.json', name: 'B' });
    expect(useEditorStore.getState().generatorEdit).toBeNull();
    st.startGeneratorEdit({ nodeId: 'gen1', generatorId: 'tree' });
    st.endGeneratorEdit();
    expect(useEditorStore.getState().generatorEdit).toBeNull();
  });
});
