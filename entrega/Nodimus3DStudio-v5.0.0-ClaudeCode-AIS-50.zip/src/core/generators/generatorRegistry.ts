import type { GeneratorSource } from '../../types/generatorSource';

/**
 * AIS-49b — registro dos geradores que sabem REABRIR um nó (`generatorSource.generatorId` → modal). Cada gerador (Terrain AIS-50, Tree
 * AIS-51a/c, Sound AIS-52, Particle AIS-53) se registra aqui com o seu `open`; este registro não conhece nenhum deles.
 *
 * Um `generatorId` sem registro NÃO é erro: o dado do nó é preservado e o Inspector mostra "Editar no gerador" desabilitado ("em breve",
 * decisão 14). Isto é organização interna do editor, não um sistema de extensões (decisão 22).
 */
export interface GeneratorEditRequest {
  nodeId: string;
  source: GeneratorSource;
}

export interface GeneratorDefinition {
  id: string;
  /** Nome exibido no Inspector. */
  label: string;
  /** Abre o modal do gerador PREENCHIDO com `request.source.params` (modo "Aplicar ao nó"). */
  open(request: GeneratorEditRequest): void;
}

export class GeneratorRegistry {
  private readonly defs = new Map<string, GeneratorDefinition>();

  /** Registra (ou substitui) um gerador; devolve o `unregister` (idempotente). */
  register(def: GeneratorDefinition): () => void {
    this.defs.set(def.id, def);
    return () => {
      if (this.defs.get(def.id) === def) this.defs.delete(def.id);
    };
  }
  get(id: string): GeneratorDefinition | undefined {
    return this.defs.get(id);
  }
  has(id: string): boolean {
    return this.defs.has(id);
  }
  list(): GeneratorDefinition[] {
    return [...this.defs.values()];
  }
}

export const globalGeneratorRegistry = new GeneratorRegistry();
