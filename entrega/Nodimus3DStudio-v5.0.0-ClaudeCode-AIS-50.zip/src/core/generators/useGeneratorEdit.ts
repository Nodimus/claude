import { useCallback, useMemo } from 'react';
import { globalAuthoringModel } from '../authoring';
import { globalCommandManager } from '../commandManager';
import { useEditorStore } from '../editorStore';
import { useEditor } from '../EditorContext';
import { parseGeneratorSource, type GeneratorSource } from '../../types/generatorSource';
import { createApplyGeneratorCommand } from './generatorCommands';

/**
 * AIS-49b — lado do MODAL de um gerador: diz se ele foi aberto a partir de um nó (`editing`), entrega os parâmetros salvos
 * (`source.params`) e aplica ao nó por `MacroCommand` (`apply`). Sem alvo do SEU `generatorId`, `editing` é `false` e o modal segue
 * em modo "Inserir novo". `apply` nunca cria nó; `cancel` (ou fechar o modal) não altera o nó.
 */
export function useGeneratorEdit(generatorId: string) {
  const target = useEditorStore((s) => s.generatorEdit);
  const endGeneratorEdit = useEditorStore((s) => s.endGeneratorEdit);
  const { activeScene } = useEditor(); // re-renderiza quando o nó muda

  const mine = target && target.generatorId === generatorId ? target : null;
  const node = mine ? activeScene.nodes[mine.nodeId] : undefined;
  const source = useMemo(() => parseGeneratorSource(node?.generatorSource), [node?.generatorSource]);

  const apply = useCallback(
    (properties: Record<string, any>, next: GeneratorSource): boolean => {
      if (!mine) return false;
      const command = createApplyGeneratorCommand({ target: globalAuthoringModel, nodeId: mine.nodeId, properties, source: next });
      if (command) globalCommandManager.execute(command);
      endGeneratorEdit();
      return true;
    },
    [mine, endGeneratorEdit]
  );

  return { editing: !!mine && !!node, nodeId: mine?.nodeId ?? null, nodeName: node?.name ?? null, source, apply, cancel: endGeneratorEdit };
}
