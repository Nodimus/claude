import { parseGeneratorSource } from '../../types/generatorSource';
import type { GameNode } from '../../types/node';
import { globalGeneratorRegistry, type GeneratorRegistry } from './generatorRegistry';

/**
 * AIS-49b — "Editar no gerador": abre o modal do gerador do nó com os parâmetros salvos. Marca o nó-alvo no `EditorStore`
 * (`generatorEdit`); o modal do gerador, ao ver o alvo do SEU `generatorId`, troca o botão principal para "Aplicar ao nó" (ver
 * `useGeneratorEdit`). Fechar sem aplicar não altera o nó.
 */

export interface GeneratorEditTarget {
  nodeId: string;
  generatorId: string;
}

/** Porta mínima do `EditorStore` (facilita testar). */
export interface GeneratorEditStore {
  startGeneratorEdit(target: GeneratorEditTarget): void;
  endGeneratorEdit(): void;
}

export type OpenGeneratorResult = { ok: true } | { ok: false; reason: 'no_node' | 'no_generator_source' | 'unknown_generator' | 'open_failed'; message: string };

/** Estado do botão do Inspector para um nó. */
export function generatorButtonState(node: Pick<GameNode, 'generatorSource'> | undefined, registry: GeneratorRegistry = globalGeneratorRegistry):
  | { visible: false }
  | { visible: true; enabled: boolean; generatorId: string; label: string; tooltip: string } {
  const source = parseGeneratorSource(node?.generatorSource);
  if (!source) return { visible: false };
  const def = registry.get(source.generatorId);
  return def
    ? { visible: true, enabled: true, generatorId: source.generatorId, label: def.label, tooltip: `Reabrir o gerador "${def.label}" com os parâmetros salvos` }
    : { visible: true, enabled: false, generatorId: source.generatorId, label: source.generatorId, tooltip: `Editar no gerador "${source.generatorId}": em breve` };
}

export function openGeneratorEditor(
  node: GameNode | undefined,
  store: GeneratorEditStore,
  registry: GeneratorRegistry = globalGeneratorRegistry
): OpenGeneratorResult {
  if (!node) return { ok: false, reason: 'no_node', message: 'O nó não existe.' };
  const source = parseGeneratorSource(node.generatorSource);
  if (!source) return { ok: false, reason: 'no_generator_source', message: `"${node.name}" não tem generatorSource.` };
  const def = registry.get(source.generatorId);
  if (!def) return { ok: false, reason: 'unknown_generator', message: `O gerador "${source.generatorId}" ainda não está disponível neste editor (em breve).` };
  store.startGeneratorEdit({ nodeId: node.id, generatorId: source.generatorId });
  try {
    def.open({ nodeId: node.id, source });
  } catch (error) {
    store.endGeneratorEdit();
    return { ok: false, reason: 'open_failed', message: error instanceof Error ? error.message : String(error) };
  }
  return { ok: true };
}
