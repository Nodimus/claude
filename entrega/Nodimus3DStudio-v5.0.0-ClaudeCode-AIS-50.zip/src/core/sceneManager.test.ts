import { describe, expect, it } from 'vitest';
import { createNewProject } from './defaultProject';
import { ProjectStorage } from './projectStorage';
import {
  addScene,
  duplicateScene,
  initialScenePath,
  listScenes,
  planSceneDeletion,
  renameScene,
  setInitialScene,
  uniqueSceneName,
  validateSceneName,
} from './sceneManager';
import { deleteResourceWith, type FileLike, type ResourceCommit, type ResourceOpsContext } from './resourceDeletion';
import { ResourceRegistry } from './resources/ResourceRegistry';
import { parseSceneJson } from './serialization/sceneSerializer';
import { validateProjectFile } from '../schemas';
import type { ProjectData } from '../types/project';

const NOW = () => '2026-10-03T00:00:00.000Z';
const ids = () => {
  let n = 0;
  return () => `scene_fix${++n}`;
};
const base = (): ProjectData => createNewProject('Cenas', '~/p', '3d');
/** project.json derivado do projeto (o que ficaria gravado). */
const pj = (project: ProjectData) => ProjectStorage.toProjectFile(project);
const entry = (project: ProjectData, path: string) => pj(project).scenes.find((s) => s.path === path);

describe('Add (AIS-29f-C01)', () => {
  it('cria o .scene.json em res://scenes/ e a entrada no project.json, com nome único e sceneId novo', () => {
    const p0 = base();
    const before = pj(p0).scenes.length;
    const r = addScene(p0, 'Empty', undefined, { now: NOW, newSceneId: ids() });
    expect(r.path).toBe('res://scenes/Scene.scene.json');
    expect(r.project.files[r.path]).toMatchObject({ name: 'Scene.scene.json', isDirectory: false });
    const file = pj(r.project);
    expect(file.scenes).toHaveLength(before + 1);
    expect(entry(r.project, r.path)).toMatchObject({ id: 'scene_fix1', name: 'Scene', path: r.path });
    expect(validateProjectFile(file).success).toBe(true);
    // segunda: nome continua único
    const r2 = addScene(r.project, 'Empty', undefined, { now: NOW, newSceneId: ids() });
    expect(r2.path).toBe('res://scenes/Scene_2.scene.json');
    expect(r2.project.lastOpenedScene).toBe(r2.path);
    // a original e a cena inicial não mudam
    expect(initialScenePath(r2.project)).toBe(initialScenePath(p0));
    expect(Object.keys(p0.files)).not.toContain(r.path); // entrada imutável
  });
  it('o arquivo é uma cena válida; 3D traz o conteúdo inicial; nome pedido é respeitado quando livre', () => {
    const r = addScene(base(), '3D', 'Fase1', { now: NOW, newSceneId: ids() });
    expect(r.name).toBe('Fase1');
    const parsed = parseSceneJson(r.project.files[r.path].content!, r.path);
    expect(parsed.ok).toBe(true);
    expect(parsed.scene!.id).toBe('scene_fix1');
    expect(Object.keys(parsed.scene!.nodes).length).toBeGreaterThan(1);
    expect(addScene(r.project, 'Empty', 'Fase1').name).not.toBe('Fase1'); // nome ocupado cai num nome único
  });
  it('reabrir (save + load) preserva a cena nova', () => {
    const r = addScene(base(), 'Empty', 'Nova', { now: NOW, newSceneId: ids() });
    ProjectStorage.saveProject(r.project);
    const loaded = ProjectStorage.loadProject(r.project.id)!;
    expect(loaded.files[r.path]).toBeDefined();
    expect(listScenes(loaded).map((s) => s.name)).toContain('Nova');
  });
});

describe('Renomear (AIS-29f-C02)', () => {
  const withTwo = () => {
    const a = addScene(base(), 'Empty', 'Fase', { now: NOW, newSceneId: ids() });
    const link = '{"action":"change_scene","scene":"res://scenes/Fase.scene.json"}';
    const project = { ...a.project, files: { ...a.project.files, 'res://scripts/cfg.json': { path: 'res://scripts/cfg.json', name: 'cfg.json', isDirectory: false, extension: 'json', content: link, updatedAt: NOW() } } };
    return { project, path: a.path };
  };
  it('muda nome e caminho no project.json e NÃO muda o sceneId', () => {
    const { project, path } = withTwo();
    const idBefore = entry(project, path)!.id;
    const r = renameScene(project, path, 'Fase_Final', { now: NOW });
    expect(r).toMatchObject({ ok: true, to: 'res://scenes/Fase_Final.scene.json' });
    if (!r.ok) return;
    expect(entry(r.project, r.to)).toMatchObject({ id: idBefore, name: 'Fase_Final', path: r.to });
    expect(entry(r.project, path)).toBeUndefined();
    expect(parseSceneJson(r.project.files[r.to].content!, r.to).scene).toMatchObject({ id: idBefore, name: 'Fase_Final' });
  });
  it('referências (change_scene), cena inicial e última aberta acompanham; o resourceId do arquivo é preservado', () => {
    const { project, path } = withTwo();
    const init = setInitialScene(project, path);
    if (!init.ok) throw new Error('falhou');
    const withId = { ...init.project, files: { ...init.project.files, [path]: { ...init.project.files[path], resourceId: 'res_cena1' } }, lastOpenedScene: path };
    const r = renameScene(withId, path, 'Outra', { now: NOW });
    if (!r.ok) throw new Error('falhou');
    expect(r.project.files['res://scripts/cfg.json'].content).toContain('res://scenes/Outra.scene.json');
    expect(r.project.files[r.to].resourceId).toBe('res_cena1');
    expect(initialScenePath(r.project)).toBe(r.to);
    expect(r.project.lastOpenedScene).toBe(r.to);
    expect(pj(r.project).scenes.find((s) => s.isStartScene)!.path).toBe(r.to);
  });
  it('nome inválido, repetido ou igual é recusado sem alterar nada', () => {
    const { project, path } = withTwo();
    for (const bad of ['', 'a/b', 'Scene.scene.json', ' x']) expect(renameScene(project, path, bad)).toMatchObject({ ok: false });
    const other = addScene(project, 'Empty', 'Outra', { newSceneId: ids() });
    expect(renameScene(other.project, path, 'Outra')).toMatchObject({ ok: false, error: expect.stringContaining('Já existe') });
    expect(renameScene(project, path, 'Fase')).toMatchObject({ ok: false });
    expect(renameScene(project, 'res://scenes/Nao.scene.json', 'X')).toMatchObject({ ok: false });
    expect(validateSceneName(project, 'Fase', undefined, path).ok).toBe(true); // a própria cena
  });
});

describe('Duplicar (AIS-29f-C03)', () => {
  it('gera cópia independente: novo sceneId, nome único `_copy`, arquivo próprio; a original não muda', () => {
    const gen = ids();
    const a = addScene(base(), '3D', 'Mapa', { now: NOW, newSceneId: gen });
    const originalContent = a.project.files[a.path].content;
    const r = duplicateScene(a.project, a.path, undefined, { now: NOW, newSceneId: gen });
    if ('error' in r) throw new Error(r.error);
    expect(r.name).toBe('Mapa_copy');
    expect(r.path).toBe('res://scenes/Mapa_copy.scene.json');
    expect(r.sceneId).not.toBe(a.sceneId);
    expect(entry(r.project, r.path)).toMatchObject({ id: r.sceneId, name: 'Mapa_copy' });
    expect(r.project.files[a.path].content).toBe(originalContent); // original intacta
    expect(r.project.files[r.path].resourceId).toBeUndefined(); // arquivo novo: o registry dará outra identidade
    const copy = parseSceneJson(r.project.files[r.path].content!, r.path).scene!;
    const orig = parseSceneJson(originalContent!, a.path).scene!;
    expect(Object.keys(copy.nodes).sort()).toEqual(Object.keys(orig.nodes).sort());
    // segunda cópia: nome continua único
    const r2 = duplicateScene(r.project, a.path, undefined, { newSceneId: gen });
    if ('error' in r2) throw new Error(r2.error);
    expect(r2.name).toBe('Mapa_copy_2');
  });
  it('copia o estado em memória quando informado (cena aberta com alterações)', () => {
    const a = addScene(base(), 'Empty', 'Aberta', { newSceneId: ids() });
    const scene = parseSceneJson(a.project.files[a.path].content!, a.path).scene!;
    const edited: typeof scene = { ...scene, nodes: { ...scene.nodes, extra: { ...scene.nodes[scene.rootNodeId], id: 'extra', name: 'Extra', parentId: scene.rootNodeId, childrenIds: [] } } };
    edited.nodes[scene.rootNodeId] = { ...edited.nodes[scene.rootNodeId], childrenIds: ['extra'] };
    const memory = JSON.stringify({ schemaVersion: 2, sceneId: scene.id, name: 'Aberta', rootNodeId: scene.rootNodeId, nodes: Object.fromEntries(Object.entries(edited.nodes).map(([k, v]) => [k, v])) });
    const r = duplicateScene(a.project, a.path, memory, { newSceneId: ids() });
    if ('error' in r) throw new Error(r.error);
    expect(Object.keys(parseSceneJson(r.project.files[r.path].content!, r.path).scene!.nodes)).toContain('extra');
  });
  it('origem inexistente ou ilegível vira erro, sem gravar', () => {
    expect(duplicateScene(base(), 'res://scenes/Nao.scene.json')).toMatchObject({ error: expect.any(String) });
    const a = addScene(base(), 'Empty', 'X');
    const broken = { ...a.project, files: { ...a.project.files, [a.path]: { ...a.project.files[a.path], content: '{ quebrado' } } };
    expect(duplicateScene(broken, a.path)).toMatchObject({ error: expect.stringContaining('não pôde ser lida') });
  });
});

describe('Cena inicial (AIS-29f-C07)', () => {
  it('Definir como inicial grava mainScene e o project.json marca startSceneId/isStartScene', () => {
    const a = addScene(base(), 'Empty', 'B', { newSceneId: ids() });
    const r = setInitialScene(a.project, a.path);
    if (!r.ok) throw new Error('falhou');
    const file = pj(r.project);
    expect(r.project.settings.general.mainScene).toBe(a.path);
    expect(file.scenes.filter((s) => s.isStartScene).map((s) => s.path)).toEqual([a.path]);
    expect(file.startSceneId).toBe(entry(r.project, a.path)!.id);
    expect(setInitialScene(a.project, 'res://scenes/Nao.scene.json')).toMatchObject({ ok: false });
    expect(setInitialScene(a.project, 'res://scripts/PlayerController.ts')).toMatchObject({ ok: false });
  });
  it('abrir outra cena (lastOpenedScene) NÃO troca a inicial', () => {
    const a = addScene(base(), 'Empty', 'B', { newSceneId: ids() });
    const initial = initialScenePath(a.project);
    expect(a.project.lastOpenedScene).toBe(a.path);
    expect(initialScenePath(a.project)).toBe(initial);
    expect(pj(a.project).scenes.find((s) => s.isStartScene)!.path).toBe(initial);
  });
  it('mainScene inexistente cai na última aberta e depois na primeira (sempre uma só inicial)', () => {
    const a = addScene(base(), 'Empty', 'B', { newSceneId: ids() });
    const broken = { ...a.project, settings: { ...a.project.settings, general: { ...a.project.settings.general, mainScene: 'res://scenes/Fantasma.scene.json' } } };
    expect(pj(broken).scenes.filter((s) => s.isStartScene)).toHaveLength(1);
    expect(initialScenePath(broken)).toBe(a.path);
  });
});

describe('Excluir: regras de cena e resultado no project.json (AIS-29f-C04/C05/C07)', () => {
  it('cena única é bloqueada com mensagem', () => {
    const p = base();
    const only = listScenes(p)[0];
    const plan = planSceneDeletion(p, only.path);
    expect(plan.blocked).toMatch(/única/);
  });
  it('a cena inicial exige escolher outra antes; a aberta é sinalizada; candidatos excluem a própria', () => {
    const a = addScene(base(), 'Empty', 'B', { newSceneId: ids() });
    const initial = initialScenePath(a.project);
    const plan = planSceneDeletion(a.project, initial, a.path);
    expect(plan).toMatchObject({ needsNewInitial: true, isActive: false });
    expect(plan.candidates.map((s) => s.path)).toEqual([a.path]);
    const nonInitial = planSceneDeletion(a.project, a.path, a.path);
    expect(nonInitial).toMatchObject({ needsNewInitial: false, isActive: true });
    expect(planSceneDeletion(a.project, 'res://scenes/Nao.scene.json').blocked).toBeDefined();
  });
  // exclusão do arquivo pelo serviço do AIS-29e, num contexto fake
  const ctxOf = (project: ProjectData, referrer?: string) => {
    const state = { files: { ...project.files } as Record<string, FileLike> };
    if (referrer) state.files['res://scripts/link.json'] = { path: 'res://scripts/link.json', name: 'link.json', isDirectory: false, extension: 'json', content: JSON.stringify({ action: 'change_scene', scene: referrer }), updatedAt: NOW() };
    const registry = new ResourceRegistry();
    registry.syncFromProject(state as never);
    const commits: ResourceCommit[] = [];
    const ctx: ResourceOpsContext = {
      registry,
      activeScene: () => null,
      io: {
        files: () => state.files,
        commit: (c) => {
          commits.push(c);
          for (const p of c.remove) delete state.files[p];
          for (const [p, f] of Object.entries(c.upsert)) state.files[p] = f;
          registry.syncFromProject(state as never);
        },
      },
    };
    return { state, ctx, commits };
  };
  it('excluir a cena inicial depois de escolher outra: o project.json passa a ter só a escolhida, como inicial', async () => {
    const a = addScene(base(), 'Empty', 'B', { newSceneId: ids() });
    const initial = initialScenePath(a.project);
    const chosen = setInitialScene(a.project, a.path);
    if (!chosen.ok) throw new Error('falhou');
    const { state, ctx } = ctxOf(chosen.project);
    const r = await deleteResourceWith(ctx, { path: initial }, { confirmed: true });
    expect(r.ok).toBe(true);
    const after: ProjectData = { ...chosen.project, files: state.files as never };
    expect(pj(after).scenes.map((s) => s.path)).toEqual([a.path]);
    expect(pj(after).scenes[0].isStartScene).toBe(true);
    expect(pj(after).startSceneId).toBe(pj(after).scenes[0].id);
  });
  it('cena com consumidores (change_scene): o serviço exige decisão e nada é apagado em silêncio', async () => {
    const a = addScene(base(), 'Empty', 'B', { newSceneId: ids() });
    const { state, ctx, commits } = ctxOf(a.project, a.path);
    const plan = await deleteResourceWith(ctx, { path: a.path }, { confirmed: true });
    expect(plan).toMatchObject({ ok: false, status: 'needs_decision' });
    expect((plan as { plan: { consumers: { uri: string }[] } }).plan.consumers.map((c) => c.uri)).toEqual(['res://scripts/link.json']);
    expect(commits).toHaveLength(0);
    expect(state.files[a.path]).toBeDefined();
    const done = await deleteResourceWith(ctx, { path: a.path }, { confirmed: true, decision: { kind: 'unresolve' } });
    expect(done.ok).toBe(true);
    expect(state.files[a.path]).toBeUndefined();
    expect(state.files['res://scripts/link.json'].content).toContain(a.path); // referência preservada
  });
});

describe('nomes de cena', () => {
  it('uniqueSceneName e validateSceneName', () => {
    const a = addScene(base(), 'Empty', 'Foo', { newSceneId: ids() });
    expect(uniqueSceneName(a.project, 'Foo')).toBe('Foo_2');
    expect(uniqueSceneName(a.project, 'foo')).toBe('foo_2'); // sem diferenciar maiúsculas
    expect(uniqueSceneName(a.project, 'Livre')).toBe('Livre');
    expect(validateSceneName(a.project, 'Foo').ok).toBe(false);
    expect(validateSceneName(a.project, 'Bar').ok).toBe(true);
  });
  it('o id da cena no project.json é o sceneId do arquivo, não o nome (renomear não o troca)', () => {
    const a = addScene(base(), 'Empty', 'Foo', { newSceneId: () => 'scene_estavel' });
    expect(entry(a.project, a.path)!.id).toBe('scene_estavel');
    const r = renameScene(a.project, a.path, 'Bar');
    if (!r.ok) throw new Error('falhou');
    expect(entry(r.project, r.to)!.id).toBe('scene_estavel');
  });
});
