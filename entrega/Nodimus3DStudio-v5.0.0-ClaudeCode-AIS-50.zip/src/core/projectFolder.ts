/**
 * AIS-32 — "Abrir Pasta…": importa uma pasta de projeto (com `project.json`) como projeto NOVO, por cópia para o
 * armazenamento do editor. Todo acesso a disco passa pelo `TauriBridge` (decisão 2); sem FS nativo não há o que ler.
 * A raiz da pasta vira `res://`. Nada é criado se o `project.json` faltar ou for inválido.
 */
import type { ProjectData, VirtualFile } from '../types/project';
import { validateProjectFile } from '../schemas';
import { createNewProject, ensureStarterFiles } from './defaultProject';
import { CURRENT_PROJECT_SCHEMA_VERSION } from './persistenceVersions';
import { joinPath, type DirectoryEntry } from './tauriBridge';

/** O que o importador precisa do bridge (permite mock nos testes). */
export interface FolderBridge {
  getCapabilities(): { hasNativeFS: boolean };
  readTextFile(path: string): Promise<string>;
  readBinaryFile(path: string): Promise<Uint8Array>;
  listDirectory(path: string): Promise<DirectoryEntry[]>;
}

const TEXT_EXT = new Set(['json', 'js', 'ts', 'jsx', 'tsx', 'xml', 'html', 'css', 'md', 'txt', 'glsl', 'shader', 'cfg', 'ini', 'svg']);
const MIME: Record<string, string> = {
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif',
  wav: 'audio/wav', ogg: 'audio/ogg', mp3: 'audio/mpeg',
  mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime', ogv: 'video/ogg',
};

function toDataUrl(bytes: Uint8Array, mime: string): string {
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return `data:${mime};base64,${btoa(bin)}`;
}

export type OpenFolderResult = { ok: true; project: ProjectData; skipped: string[] } | { ok: false; error: string };

async function walk(bridge: FolderBridge, root: string, rel: string, out: { dirs: string[]; files: string[] }): Promise<void> {
  const entries = await bridge.listDirectory(rel ? joinPath(root, rel) : root);
  for (const e of entries) {
    if (e.name.startsWith('.') || e.name === 'node_modules') continue;
    const childRel = rel ? `${rel}/${e.name}` : e.name;
    if (e.isDirectory) {
      out.dirs.push(childRel);
      await walk(bridge, root, childRel, out);
    } else if (e.isFile) out.files.push(childRel);
  }
}

export async function importProjectFromFolder(folder: string, bridge: FolderBridge): Promise<OpenFolderResult> {
  if (!bridge.getCapabilities().hasNativeFS) return { ok: false, error: 'Abrir Pasta requer o app desktop.' };

  let projectJson: unknown;
  try {
    projectJson = JSON.parse(await bridge.readTextFile(joinPath(folder, 'project.json')));
  } catch (e) {
    return { ok: false, error: `Esta pasta não tem um project.json válido (${(e as Error).message}).` };
  }
  const validation = validateProjectFile(projectJson);
  if (!validation.success || !validation.data) {
    return { ok: false, error: `project.json inválido: ${validation.formattedError ?? 'formato não reconhecido'}.` };
  }
  const pf = validation.data;

  const listing = { dirs: [] as string[], files: [] as string[] };
  try {
    await walk(bridge, folder, '', listing);
  } catch (e) {
    return { ok: false, error: `Não foi possível ler a pasta: ${(e as Error).message}.` };
  }

  const now = new Date().toISOString();
  const files: Record<string, VirtualFile> = {};
  for (const dir of listing.dirs) {
    const path = `res://${dir}/`;
    files[path] = { path, name: dir.split('/').pop() as string, isDirectory: true, updatedAt: now };
  }
  const skipped: string[] = [];
  for (const rel of listing.files) {
    if (rel === 'project.json') continue; // regravado a partir do projeto importado
    const name = rel.split('/').pop() as string;
    const dot = name.lastIndexOf('.');
    const ext = dot > 0 ? name.slice(dot + 1).toLowerCase() : '';
    const full = joinPath(folder, rel);
    try {
      let content: string;
      if (TEXT_EXT.has(ext)) content = await bridge.readTextFile(full);
      else if (MIME[ext]) content = toDataUrl(await bridge.readBinaryFile(full), MIME[ext]);
      else {
        skipped.push(rel);
        continue;
      }
      const path = `res://${rel}`;
      files[path] = { path, name, isDirectory: false, extension: ext, content, size: content.length, updatedAt: now };
    } catch {
      skipped.push(rel);
    }
  }

  const base = createNewProject(pf.name, folder, '3d');
  const project: ProjectData = {
    ...base,
    name: pf.name,
    location: folder,
    settings: pf.settings as unknown as ProjectData['settings'],
    globalVariables: (pf.globalVariables ?? []) as ProjectData['globalVariables'],
    files,
    createdAt: pf.createdAt ?? base.createdAt,
    schemaVersion: CURRENT_PROJECT_SCHEMA_VERSION,
  };
  const startScene = pf.scenes.find((s) => s.id === pf.startSceneId || s.isStartScene);
  if (startScene && files[startScene.path]) project.lastOpenedScene = startScene.path;
  else {
    const anyScene = Object.keys(files).find((p) => p.endsWith('.scene.json'));
    if (anyScene) project.lastOpenedScene = anyScene;
  }
  return { ok: true, project: ensureStarterFiles(project), skipped };
}
