import { describe, expect, it } from 'vitest';
import {
  buildTerrainGeometry,
  encodeHeightFile,
  generateHeightBuffer,
  heightmapImageToBuffer,
  parseHeightFile,
  readTerrainConfig,
  sampleHeight,
  snapSegments,
  terrainHeightfield,
  terrainLayerWeights,
  terrainVertexColors,
  TERRAIN_PRESETS,
  type TerrainPreset,
} from './terrainGeometry';

const stats = (h: Float32Array) => ({ min: Math.min(...h), max: Math.max(...h) });

describe('generateHeightBuffer (AIS-50-C05)', () => {
  it('tem (segW+1)·(segH+1) amostras, todas em [0, maxHeight]', () => {
    for (const { id } of TERRAIN_PRESETS) {
      const h = generateHeightBuffer(32, 16, id, 3, 24);
      expect(h.length).toBe(33 * 17);
      const s = stats(h);
      expect(s.min).toBeGreaterThanOrEqual(0);
      expect(s.max).toBeLessThanOrEqual(24 + 1e-4);
    }
  });
  it('é determinístico por semente e muda com a semente', () => {
    const a = generateHeightBuffer(32, 32, 'hills', 5, 20);
    const b = generateHeightBuffer(32, 32, 'hills', 5, 20);
    const c = generateHeightBuffer(32, 32, 'hills', 6, 20);
    expect(Array.from(a)).toEqual(Array.from(b));
    expect(Array.from(a)).not.toEqual(Array.from(c));
  });
  it('presets são distintos entre si e "flat" é quase plano', () => {
    const by = Object.fromEntries(TERRAIN_PRESETS.map((p) => [p.id, generateHeightBuffer(64, 64, p.id, 1, 24)])) as Record<TerrainPreset, Float32Array>;
    expect(stats(by.flat).max).toBeLessThanOrEqual(24 * 0.05 + 1e-4);
    expect(stats(by.mountains).max).toBeGreaterThan(stats(by.hills).max);
    const ids = TERRAIN_PRESETS.map((p) => p.id);
    for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) expect(Array.from(by[ids[i]])).not.toEqual(Array.from(by[ids[j]]));
  });
  it('montanhas: pico no centro mais alto que o canto; canyon: vale central mais baixo que a borda', () => {
    const m = generateHeightBuffer(64, 64, 'mountains', 2, 24);
    expect(m[32 * 65 + 32]).toBeGreaterThan(m[0]);
    const c = generateHeightBuffer(64, 64, 'canyon', 2, 24);
    expect(c[32 * 65 + 32]).toBeLessThan(c[0]);
  });
});

describe('heightmapImageToBuffer', () => {
  const img = (w: number, h: number, f: (x: number, y: number) => number) => {
    const data = new Uint8ClampedArray(w * h * 4);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) data.set([f(x, y), 0, 0, 255], (y * w + x) * 4);
    return { width: w, height: h, data };
  };
  it('usa o canal R: preto = 0, branco = maxHeight; invert troca', () => {
    const half = img(2, 2, (x) => (x === 0 ? 0 : 255)); // esquerda preta, direita branca
    const h = heightmapImageToBuffer(half, 4, 4, 10, false, false);
    expect(h[0]).toBeCloseTo(0);
    expect(h[4]).toBeCloseTo(10);
    const inv = heightmapImageToBuffer(half, 4, 4, 10, true, false);
    expect(inv[0]).toBeCloseTo(10);
    expect(inv[4]).toBeCloseTo(0);
  });
  it('reamostra para a resolução do terreno e suaviza (média 3×3) sem sair de [0, max]', () => {
    const noisy = img(8, 8, (x, y) => ((x + y) % 2 ? 255 : 0));
    const raw = heightmapImageToBuffer(noisy, 16, 16, 10, false, false);
    const smooth = heightmapImageToBuffer(noisy, 16, 16, 10, false, true);
    expect(raw.length).toBe(17 * 17);
    const range = (a: Float32Array) => stats(a).max - stats(a).min;
    expect(range(smooth)).toBeLessThan(range(raw));
    expect(stats(smooth).min).toBeGreaterThanOrEqual(0);
    expect(stats(smooth).max).toBeLessThanOrEqual(10 + 1e-4);
  });
  it('imagem vazia não lança', () => {
    expect(heightmapImageToBuffer({ width: 0, height: 0, data: [] }, 4, 4, 10, false, false).length).toBe(25);
  });
});

describe('buildTerrainGeometry (AIS-50-C05)', () => {
  it('dimensões, nº de vértices/triângulos e alturas aplicadas', () => {
    const segW = 8;
    const segH = 4;
    const heights = generateHeightBuffer(segW, segH, 'hills', 1, 10);
    const geo = buildTerrainGeometry(80, 40, segW, segH, heights);
    const pos = geo.getAttribute('position');
    expect(pos.count).toBe((segW + 1) * (segH + 1));
    expect(geo.index!.count / 3).toBe(segW * segH * 2);
    for (let i = 0; i < pos.count; i++) expect(pos.getY(i)).toBeCloseTo(heights[i], 5);
    geo.computeBoundingBox();
    expect(geo.boundingBox!.max.x - geo.boundingBox!.min.x).toBeCloseTo(80);
    expect(geo.boundingBox!.max.z - geo.boundingBox!.min.z).toBeCloseTo(40);
    expect(geo.getAttribute('normal').count).toBe(pos.count);
  });
  it('convenção: coluna 0 em x = −width/2, linha 0 em z = −depth/2; linhas crescem em +z', () => {
    const geo = buildTerrainGeometry(10, 20, 2, 2, new Float32Array(9));
    const pos = geo.getAttribute('position');
    expect(pos.getX(0)).toBeCloseTo(-5);
    expect(pos.getZ(0)).toBeCloseTo(-10);
    expect(pos.getX(2)).toBeCloseTo(5);
    expect(pos.getZ(6)).toBeCloseTo(10);
  });
  it('terreno plano tem normais para cima', () => {
    const geo = buildTerrainGeometry(10, 10, 4, 4, new Float32Array(25));
    const n = geo.getAttribute('normal');
    for (let i = 0; i < n.count; i++) expect(n.getY(i)).toBeCloseTo(1, 4);
  });
});

describe('sampleHeight (AIS-50-C06)', () => {
  it('no centro devolve a altura central; nos cantos, a do canto', () => {
    const segW = 4;
    const segH = 4;
    const h = new Float32Array(25);
    for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) h[r * 5 + c] = r * 10 + c;
    expect(sampleHeight(h, segW, segH, 100, 100, 0, 0)).toBeCloseTo(h[2 * 5 + 2]);
    expect(sampleHeight(h, segW, segH, 100, 100, -50, -50)).toBeCloseTo(h[0]);
    expect(sampleHeight(h, segW, segH, 100, 100, 50, 50)).toBeCloseTo(h[24]);
    expect(sampleHeight(h, segW, segH, 100, 100, 50, -50)).toBeCloseTo(h[4]);
  });
  it('interpola entre amostras e prende fora da área na borda', () => {
    const h = new Float32Array([0, 10, 0, 10, 0, 10, 0, 10, 0].slice(0, 9)); // 3×3
    // (x entre c0 e c1) metade do caminho → média das duas amostras
    const ramp = new Float32Array([0, 10, 20, 0, 10, 20, 0, 10, 20]);
    expect(sampleHeight(ramp, 2, 2, 20, 20, -5, 0)).toBeCloseTo(5);
    expect(sampleHeight(ramp, 2, 2, 20, 20, 999, 0)).toBeCloseTo(20);
    expect(sampleHeight(h, 2, 2, 20, 20, 0, 0)).toBeDefined();
  });
  it('é coerente com o buffer do preset (altura central do terreno gerado)', () => {
    const h = generateHeightBuffer(64, 64, 'mountains', 4, 30);
    expect(sampleHeight(h, 64, 64, 120, 120, 0, 0)).toBeCloseTo(h[32 * 65 + 32], 4);
  });
});

describe('config, splat e collider', () => {
  it('readTerrainConfig sanitiza e aplica padrões', () => {
    const c = readTerrainConfig({ width: -5, depth: 'x', segmentsW: 100, segmentsH: 999, terrainPreset: 'lava', maxHeight: NaN, blendSharpness: 7, textureTiling: 0 });
    expect(c.width).toBe(1);
    expect(c.depth).toBe(120);
    expect(c.segmentsW).toBe(128);
    expect(c.segmentsH).toBe(256);
    expect(c.preset).toBe('flat');
    expect(c.maxHeight).toBe(24);
    expect(c.blendSharpness).toBe(1);
    expect(c.textureTiling).toBe(1);
    expect(readTerrainConfig(undefined).segmentsW).toBe(128);
    expect(snapSegments(50)).toBe(64);
  });
  it('pesos das camadas somam 1: baixo = chão, meio = meio, topo = alto', () => {
    for (const t of [0, 0.2, 0.35, 0.5, 0.7, 0.9, 1]) for (const s of [0, 0.5, 1]) expect(terrainLayerWeights(t, s).reduce((a, b) => a + b)).toBeCloseTo(1, 6);
    expect(terrainLayerWeights(0.05, 0.5)[0]).toBeGreaterThan(0.99);
    expect(terrainLayerWeights(0.52, 0.5)[1]).toBeGreaterThan(0.99);
    expect(terrainLayerWeights(0.98, 0.5)[2]).toBeGreaterThan(0.99);
  });
  it('cores de vértice: 3 floats por vértice; baixo ≠ alto', () => {
    const colors = terrainVertexColors(new Float32Array([0, 24]), { maxHeight: 24, groundTexture: 'Grass_Green', midTexture: 'Rock_Cliff', highTexture: 'Snow_Mountain', blendSharpness: 0.5 });
    expect(colors.length).toBe(6);
    expect(Array.from(colors.slice(0, 3))).not.toEqual(Array.from(colors.slice(3, 6)));
  });
  it('collider usa o MESMO Float32Array (sem cópia)', () => {
    const h = generateHeightBuffer(32, 32, 'hills', 1, 10);
    const hf = terrainHeightfield(h, { segmentsW: 32, segmentsH: 32, width: 50, depth: 60 });
    expect(hf.heights).toBe(h);
    expect(hf).toMatchObject({ rows: 33, cols: 33, scale: { x: 50, y: 1, z: 60 } });
  });
});

describe('.height (contrato de carga)', () => {
  it('ida e volta', () => {
    const heights = new Float32Array([0, 1.5, 2.5, 3, 4, 5.25]);
    const r = parseHeightFile(encodeHeightFile({ rows: 2, cols: 3, scale: { x: 10, y: 1, z: 20 }, heights }));
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.file).toMatchObject({ version: 1, rows: 2, cols: 3, scale: { x: 10, y: 1, z: 20 } });
      expect(Array.from(r.file.heights)).toEqual(Array.from(heights));
    }
  });
  it('arquivo inválido devolve o motivo, nunca lança', () => {
    expect(parseHeightFile(new ArrayBuffer(4))).toMatchObject({ ok: false });
    expect(parseHeightFile(new ArrayBuffer(64))).toMatchObject({ ok: false, reason: expect.stringContaining('assinatura') });
    const ok = new Uint8Array(encodeHeightFile({ rows: 2, cols: 2, scale: { x: 1, y: 1, z: 1 }, heights: new Float32Array(4) }));
    expect(parseHeightFile(ok.slice(0, ok.length - 4).buffer)).toMatchObject({ ok: false, reason: expect.stringContaining('tamanho') });
    const newer = ok.slice();
    new DataView(newer.buffer).setUint32(4, 99, true);
    expect(parseHeightFile(newer.buffer)).toMatchObject({ ok: false, reason: expect.stringContaining('versão') });
  });
});
