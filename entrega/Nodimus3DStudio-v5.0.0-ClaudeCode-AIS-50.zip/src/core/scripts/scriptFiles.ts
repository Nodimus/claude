import { uniqueName, validateName } from '../fileSystem/fileOps';

/**
 * AIS-28b — criação de arquivos de código/texto: templates, pasta de destino e nome livre. Funções puras.
 * Logic Script não é arquivo (decisão 5): só existem `.js`/`.ts` (chamados pela ação Executar Script) e arquivos de
 * dados/texto; nunca `.logic`.
 */

export type NewFileType = 'ts' | 'js' | 'json' | 'xml' | 'txt';

export const NEW_FILE_TYPES: readonly NewFileType[] = ['ts', 'js', 'json', 'xml', 'txt'];

export const SCRIPTS_FOLDER = 'res://scripts/';

/** `.ts`/`.js` são scripts e vão para `res://scripts/`; dados e texto vão para a pasta escolhida (ou `res://`). */
export const isScriptType = (type: NewFileType): boolean => type === 'ts' || type === 'js';

/**
 * Pasta onde o novo arquivo nasce (decisão do usuário, AIS-28b): scripts em `res://scripts/` quando nada específico
 * foi selecionado; dados/texto na pasta selecionada, ou `res://` se a seleção é a raiz/inexistente.
 */
export function folderForNewFile(type: NewFileType, selectedFolder?: string | null): string {
  const folder = selectedFolder && selectedFolder.endsWith('/') ? selectedFolder : 'res://';
  if (isScriptType(type)) return folder === 'res://' ? SCRIPTS_FOLDER : folder;
  return folder;
}

/** Nome-base aceito: letras, dígitos, `_`, `-`, `.` e espaço interno viram `_`; vazio → `null`. */
export function sanitizeBaseName(raw: string): string | null {
  const cleaned = raw.trim().replace(/\.(ts|js|json|xml|txt)$/i, '').replace(/[\\/:*?"<>|\s]+/g, '_');
  if (!cleaned || !validateName(cleaned).ok) return null;
  return cleaned;
}

export function templateFor(type: NewFileType, baseName: string, now: Date = new Date()): string {
  const file = `${baseName}.${type}`;
  switch (type) {
    case 'ts':
      return `/**\n * ${file}\n * Script do Nodimus 3D Studio — chamado pela ação "Executar Script".\n */\nexport class CustomBehavior {\n  constructor(public nodeName = "Target") {}\n\n  public onReady(): void {\n    console.log("[Behavior] Ready:", this.nodeName);\n  }\n\n  public onProcess(delta: number): void {\n    // lógica por quadro\n  }\n}\n`;
    case 'js':
      return `/**\n * ${file}\n * Script do Nodimus 3D Studio — chamado pela ação "Executar Script".\n */\nexport function run(context) {\n  // lógica do script\n}\n`;
    case 'json':
      return `{\n  "name": "${baseName}",\n  "enabled": true,\n  "values": [\n    10,\n    20,\n    30\n  ]\n}\n`;
    case 'xml':
      return `<?xml version="1.0" encoding="UTF-8"?>\n<definition id="${baseName}">\n  <property name="active" value="true" />\n  <property name="rate" value="1.0" />\n</definition>\n`;
    case 'txt':
      return `=== ${file} ===\nNotas do projeto:\n- Data: ${now.toISOString().slice(0, 10)}\n`;
  }
}

export interface NewFilePlan {
  path: string;
  content: string;
  /** O nome pedido já existia: foi trocado por um livre (`Nome (2).ext`). */
  renamed: boolean;
}

/**
 * Plano de criação: caminho final (nunca sobrescreve um arquivo existente) e conteúdo do template.
 * `baseName` ausente/inválido gera um nome automático.
 */
export function planNewFile(
  type: NewFileType,
  files: Record<string, { isDirectory: boolean }>,
  options: { baseName?: string; selectedFolder?: string | null; random?: () => string } = {}
): NewFilePlan {
  const folder = folderForNewFile(type, options.selectedFolder);
  const random = options.random ?? (() => Math.random().toString(36).slice(2, 6));
  const base = (options.baseName && sanitizeBaseName(options.baseName)) || `New_${type.toUpperCase()}_${random()}`;
  const wanted = `${base}.${type}`;
  const name = uniqueName(files, folder, wanted, false);
  const finalBase = name.slice(0, name.length - type.length - 1);
  return { path: folder + name, content: templateFor(type, finalBase), renamed: name !== wanted };
}
