import { javascriptLanguage } from '@codemirror/lang-javascript';

/**
 * AIS-28b — checagem de sintaxe SEM executar nada. Usa o parser Lezer do CodeMirror (nós de erro) para JS/TS e
 * `JSON.parse` para JSON. Nunca `eval`/`new Function`: a execução de scripts é do sandbox do AIS-79.
 * Pura: roda em Node (testes) e no navegador.
 */

export interface SyntaxIssue {
  /** Deslocamento no texto (0-based). */
  from: number;
  to: number;
  message: string;
}

export const isCheckableExtension = (ext: string): boolean => ['js', 'jsx', 'mjs', 'cjs', 'ts', 'tsx', 'json'].includes(ext);

function jsDialect(ext: string): string {
  if (ext === 'ts') return 'ts';
  if (ext === 'tsx') return 'ts jsx';
  if (ext === 'jsx') return 'jsx';
  return '';
}

function checkJavaScript(source: string, ext: string): SyntaxIssue[] {
  const dialect = jsDialect(ext);
  const parser = dialect ? javascriptLanguage.parser.configure({ dialect }) : javascriptLanguage.parser;
  const tree = parser.parse(source);
  const issues: SyntaxIssue[] = [];
  tree.iterate({
    enter: (node) => {
      if (!node.type.isError) return;
      const from = node.from;
      const to = Math.max(node.to, Math.min(from + 1, source.length));
      issues.push({ from, to, message: 'Erro de sintaxe' });
      return false; // um aviso por trecho
    },
  });
  return issues.slice(0, 20);
}

function checkJson(source: string): SyntaxIssue[] {
  if (!source.trim()) return [];
  try {
    JSON.parse(source);
    return [];
  } catch (error) {
    const message = error instanceof Error ? error.message : 'JSON inválido';
    const position = /position (\d+)/.exec(message);
    const from = position ? Math.min(Number(position[1]), Math.max(0, source.length - 1)) : 0;
    return [{ from, to: Math.min(from + 1, source.length), message: `JSON inválido: ${message}` }];
  }
}

/** Erros de sintaxe do texto; lista vazia = sem erros detectados. Extensões não verificáveis devolvem `[]`. */
export function checkSyntax(source: string, ext: string): SyntaxIssue[] {
  const e = ext.toLowerCase();
  if (e === 'json') return checkJson(source);
  if (['js', 'jsx', 'mjs', 'cjs', 'ts', 'tsx'].includes(e)) return checkJavaScript(source, e);
  return [];
}

/** Linha (1-based) e coluna (1-based) de um deslocamento, para mensagens fora do editor. */
export function positionOf(source: string, offset: number): { line: number; column: number } {
  const before = source.slice(0, Math.max(0, offset));
  const line = before.split('\n').length;
  return { line, column: offset - (before.lastIndexOf('\n') + 1) + 1 };
}
