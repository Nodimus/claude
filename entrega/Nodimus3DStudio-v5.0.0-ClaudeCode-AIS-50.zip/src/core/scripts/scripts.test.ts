import { describe, expect, it } from 'vitest';
import { checkSyntax, isCheckableExtension, positionOf } from './syntaxCheck';
import { NEW_FILE_TYPES, folderForNewFile, planNewFile, sanitizeBaseName, templateFor } from './scriptFiles';
import { resolveFileAction } from '../fileSystem/fileActions';

describe('checkSyntax (AIS-28b) — sem executar nada', () => {
  it('JS válido e inválido', () => {
    expect(checkSyntax('export function run(c) { return c + 1; }', 'js')).toEqual([]);
    const bad = checkSyntax('function run( { return 1 }', 'js');
    expect(bad.length).toBeGreaterThan(0);
    expect(bad[0].message).toMatch(/sintaxe/i);
  });
  it('TypeScript: tipos são aceitos em .ts mas não em .js', () => {
    const src = 'export class A { constructor(public n: string) {} }';
    expect(checkSyntax(src, 'ts')).toEqual([]);
    expect(checkSyntax(src, 'js').length).toBeGreaterThan(0);
  });
  it('JSON válido, inválido e vazio', () => {
    expect(checkSyntax('{ "a": [1, 2] }', 'json')).toEqual([]);
    expect(checkSyntax('', 'json')).toEqual([]);
    const bad = checkSyntax('{ "a": 1, }', 'json');
    expect(bad).toHaveLength(1);
    expect(bad[0].message).toMatch(/JSON inválido/);
  });
  it('outras extensões não são verificadas aqui', () => {
    expect(checkSyntax('<a>', 'xml')).toEqual([]);
    expect(checkSyntax('x', 'txt')).toEqual([]);
    expect(isCheckableExtension('ts')).toBe(true);
    expect(isCheckableExtension('md')).toBe(false);
  });
  it('positionOf', () => {
    expect(positionOf('ab\ncd', 4)).toEqual({ line: 2, column: 2 });
    expect(positionOf('ab', 0)).toEqual({ line: 1, column: 1 });
  });
});

describe('novo arquivo (AIS-28b, decisões do usuário)', () => {
  it('scripts vão para res://scripts/ quando nada está selecionado; dados/texto vão para a pasta selecionada ou res://', () => {
    expect(folderForNewFile('ts', 'res://')).toBe('res://scripts/');
    expect(folderForNewFile('js', null)).toBe('res://scripts/');
    expect(folderForNewFile('json', 'res://')).toBe('res://');
    expect(folderForNewFile('xml', undefined)).toBe('res://');
    expect(folderForNewFile('txt', 'res://data/')).toBe('res://data/');
    expect(folderForNewFile('ts', 'res://game/')).toBe('res://game/');
  });
  it('nome: sanitiza, remove extensão repetida e gera automático se vazio', () => {
    expect(sanitizeBaseName(' Meu Script.ts ')).toBe('Meu_Script');
    expect(sanitizeBaseName('a/b')).toBe('a_b');
    expect(sanitizeBaseName('   ')).toBeNull();
    const plan = planNewFile('js', {}, { random: () => 'abcd' });
    expect(plan.path).toBe('res://scripts/New_JS_abcd.js');
  });
  it('nunca sobrescreve: nome existente vira "Nome (2).ext" e o template acompanha', () => {
    const files = { 'res://scripts/Hero.ts': { isDirectory: false } };
    const plan = planNewFile('ts', files, { baseName: 'Hero' });
    expect(plan.path).toBe('res://scripts/Hero (2).ts');
    expect(plan.renamed).toBe(true);
    expect(plan.content).toContain('Hero (2).ts');
  });
  it('templates: um por tipo, nunca .logic, e abrem no editor de código pelo roteador', () => {
    for (const type of NEW_FILE_TYPES) {
      const content = templateFor(type, 'X', new Date('2026-10-02T00:00:00Z'));
      expect(content.length).toBeGreaterThan(10);
      expect(content).not.toMatch(/\.logic/);
      const plan = planNewFile(type, {}, { baseName: 'X' });
      expect(plan.path.endsWith(`.${type}`)).toBe(true);
      expect(resolveFileAction({ path: plan.path }).kind).toBe('scriptEditor');
    }
    expect(templateFor('json', 'cfg')).toContain('"name": "cfg"');
    expect(checkSyntax(templateFor('json', 'cfg'), 'json')).toEqual([]);
    expect(checkSyntax(templateFor('ts', 'x'), 'ts')).toEqual([]);
    expect(checkSyntax(templateFor('js', 'x'), 'js')).toEqual([]);
  });
});

describe('atalho F7 (AIS-28b)', () => {
  it('F7 alterna o workspace Script, com preventDefault e mesmo com o foco no editor', async () => {
    const { dispatchDesktopShortcut, DESKTOP_SHORTCUTS } = await import('../../hooks/useDesktopShortcuts');
    let prevented = false;
    let toggled = 0;
    const event = { key: 'F7', ctrlKey: false, metaKey: false, shiftKey: false, altKey: false, target: null, preventDefault: () => { prevented = true; } } as unknown as KeyboardEvent;
    expect(dispatchDesktopShortcut(event, { onToggleScriptWorkspace: () => { toggled++; } })).toBe('toggle_script_workspace');
    expect(prevented).toBe(true);
    expect(toggled).toBe(1);
    expect(DESKTOP_SHORTCUTS.some((s) => s.keyCombo === 'F7')).toBe(true);
  });
});
