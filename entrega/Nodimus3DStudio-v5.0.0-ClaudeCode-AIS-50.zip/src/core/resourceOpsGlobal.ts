import { globalAuthoringModel } from './authoring';
import { ProjectStorage } from './projectStorage';
import { globalResourceRegistry } from './resources/global';
import { getSceneDocument, preserveHistoryOnNextSceneLoad } from './documents/sceneDocument';
import { globalDocumentManager } from './documents/DocumentManager';
import { parseSceneJson, serializeSceneToJson } from './serialization/sceneSerializer';
import { remapPath } from './fileSystem/fileOps';
import type { DeferredRewrite, FileLike, ResourceCommit, ResourceIO, ResourceOpsContext } from './resourceDeletion';

/**
 * AIS-29e — ligação do serviço de recursos ao editor: contexto real (registry, projeto, cena aberta) e os efeitos sobre
 * a cena aberta. Fica separado do serviço para que ele continue puro e testável.
 */

const io: ResourceIO = {
  files: () => globalAuthoringModel.getProject().files as unknown as Record<string, FileLike>,
  commit: (change: ResourceCommit) => {
    const project = globalAuthoringModel.getProject();
    const files: Record<string, unknown> = { ...project.files };
    for (const path of change.remove) delete files[path];
    for (const [path, file] of Object.entries(change.upsert)) files[path] = file;
    const moves = change.moves ?? [];
    const settings = project.settings?.general
      ? { ...project.settings, general: { ...project.settings.general, mainScene: remapPath(project.settings.general.mainScene, moves) } }
      : project.settings;
    const updated = { ...project, files: files as typeof project.files, settings, lastOpenedScene: remapPath(project.lastOpenedScene, moves) };
    // UM commit: atualiza o modelo autoral e grava o projeto uma vez só
    globalAuthoringModel.setProject(updated);
    ProjectStorage.saveProject(updated);
  },
};

export function defaultResourceContext(): ResourceOpsContext {
  return {
    registry: globalResourceRegistry,
    io,
    activeScene: () => {
      const scene = globalAuthoringModel.getScene();
      if (!scene?.path) return null;
      return { path: scene.path, dirty: !!getSceneDocument()?.dirty };
    },
  };
}

/**
 * Efeitos sobre a cena ABERTA depois de um commit: reescreve as referências no estado em memória (a cena fica com
 * alterações não salvas, o arquivo em disco só muda quando o usuário salva) e, se a própria cena foi movida,
 * continua a mesma edição no novo caminho (mesma lógica do "Salvar como": o Undo é preservado).
 */
export function applyActiveSceneEffects(result: { deferred: DeferredRewrite[]; activeSceneMovedTo?: string }): void {
  let scene = globalAuthoringModel.getScene();
  let changed = false;
  for (const d of result.deferred) {
    if (d.uri !== scene.path) continue;
    const before = serializeSceneToJson(scene);
    const after = d.rewrite(before);
    if (after === before) continue;
    const parsed = parseSceneJson(after, scene.path);
    if (parsed.ok && parsed.scene) {
      scene = parsed.scene;
      changed = true;
    }
  }
  if (result.activeSceneMovedTo) {
    scene = { ...scene, path: result.activeSceneMovedTo, name: result.activeSceneMovedTo.split('/').pop()!.replace(/\.scene\.json$/, '') };
    preserveHistoryOnNextSceneLoad();
    globalAuthoringModel.loadScene(scene);
    return;
  }
  if (changed) {
    preserveHistoryOnNextSceneLoad();
    globalAuthoringModel.loadScene(scene);
    const doc = getSceneDocument();
    if (doc) globalDocumentManager.markDirty(doc.documentId);
  }
}
