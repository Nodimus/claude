import type { ImageDataLike } from './terrainGeometry';

/**
 * AIS-50 — decodificação do heightmap (PNG/JPG em `res://textures/`, guardado como data URL no projeto) → `ImageData`.
 * A decodificação é assíncrona (`Image` + canvas); o resultado fica em cache por conteúdo e os assinantes são avisados para
 * que o Viewport/preview reconstruam o terreno. Navegador/Tauri apenas: em Node (testes) nada é decodificado.
 */

const decoded = new Map<string, ImageDataLike>();
const pending = new Set<string>();
const failed = new Set<string>();
const listeners = new Set<() => void>();

/** Avisa quando uma imagem termina de decodificar; devolve o disposer (AIS-48b). */
export function subscribeHeightmapDecoded(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

/** Imagem já decodificada, ou `null` (e inicia a decodificação em segundo plano na primeira chamada). */
export function getDecodedHeightmap(dataUrl: string): ImageDataLike | null {
  const hit = decoded.get(dataUrl);
  if (hit) return hit;
  if (pending.has(dataUrl) || failed.has(dataUrl)) return null;
  if (typeof Image === 'undefined' || typeof document === 'undefined') return null;
  pending.add(dataUrl);
  const img = new Image();
  img.onload = () => {
    pending.delete(dataUrl);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) throw new Error('sem contexto 2D');
      ctx.drawImage(img, 0, 0);
      const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
      decoded.set(dataUrl, { width: data.width, height: data.height, data: data.data });
    } catch {
      failed.add(dataUrl);
    }
    for (const l of [...listeners]) l();
  };
  img.onerror = () => {
    pending.delete(dataUrl);
    failed.add(dataUrl);
    for (const l of [...listeners]) l();
  };
  img.src = dataUrl;
  return null;
}

/** A imagem falhou ao decodificar (arquivo corrompido/não suportado). */
export function heightmapDecodeFailed(dataUrl: string): boolean {
  return failed.has(dataUrl);
}

/** Apenas para testes. */
export function __primeHeightmapCache(dataUrl: string, image: ImageDataLike): void {
  decoded.set(dataUrl, image);
}
