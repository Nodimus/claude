import { describe, expect, it } from 'vitest';
import { AuthoringModel } from '../authoring/AuthoringModel';
import { applyBehaviorList, collectBehaviors, groupBehaviorsByNode } from '../authoring/behaviors';
import { CommandManager } from '../commandManager';
import { createBehaviorOps, type BehaviorStore } from '../commands/BehaviorCommands';
import { createDefault3DStarterScene, createEmptyScene } from '../defaultProject';
import { createStarterBehavior, STARTER_BEHAVIOR_IDS } from '../starterBehaviors';
import { BehaviorRuntimeStates } from '../../runtime/behaviorRuntimeState';
import { LogicRegistry } from '../../logic/registry';
import { CURRENT_SCENE_SCHEMA_VERSION } from '../persistenceVersions';
import { migrateSceneV2ToV3 } from '../../migrations/sceneMigrations';
import { migrateStepwise } from '../../migrations';
import { isKnownLogicContribution } from './logicResolver';
import { behaviorFromFile, behaviorToFile, behaviorsFromFile } from './behaviorFile';
import { deserializeScene, parseSceneJson, serializeScene, serializeSceneToJson } from './sceneSerializer';
import type { GameNode } from '../../types/node';
import type { BehaviorInstance } from '../../types/visualLogic';

const PATH = 'res://scenes/Teste.scene.json';
const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v));

const node = (id: string, name: string, over: Partial<GameNode> = {}): GameNode =>
  ({ id, name, type: 'MeshInstance', parentId: 'root', childrenIds: [], visible: true, locked: false, properties: {}, ...over }) as GameNode;

const behavior = (id: string, over: Partial<BehaviorInstance> = {}): BehaviorInstance => ({
  id,
  name: `B_${id}`,
  behaviorType: 'simple_wasd_movement',
  enabled: true,
  properties: { speed: 6, nested: { list: [1, { deep: true }] } },
  rules: [
    {
      id: `r_${id}`,
      eventType: 'on_update',
      parameters: { k: 1 },
      conditions: [{ id: 'c1', type: 'always', parameters: {} }],
      actions: [
        { id: 'a1', type: 'move_by', parameters: { dx: 1, dz: 0 } },
        { id: 'a2', type: 'print_log', parameters: { text: 'oi' } },
        { id: 'a3', type: 'rotate_by', parameters: { degrees: 5 } },
      ],
    },
  ],
  ...over,
});

/** Cena v3 mínima com dois nós, cada um com uma instância da MESMA definição. */
function sceneWith(behaviorsA: BehaviorInstance[], behaviorsB: BehaviorInstance[] = []) {
  const scene = createEmptyScene();
  scene.nodes = {
    [scene.rootNodeId]: node(scene.rootNodeId, 'World', { parentId: null, childrenIds: ['a', 'b'] }),
    a: node('a', 'Alfa', { parentId: scene.rootNodeId, behaviors: behaviorsA }),
    b: node('b', 'Beta', { parentId: scene.rootNodeId, behaviors: behaviorsB }),
  };
  return scene;
}

function authoring(scene = sceneWith([behavior('x')], [behavior('y')])) {
  const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene);
  const store: BehaviorStore = {
    get: () => collectBehaviors(model.getScene()),
    set: (next) => void applyBehaviorList(model, next),
  };
  const manager = new CommandManager();
  const ops = createBehaviorOps(store, (c) => manager.execute(c));
  return { model, manager, ops, store };
}

describe('AIS-41b — instâncias independentes (C01)', () => {
  it('duas instâncias da mesma definição em nós distintos têm parâmetros independentes', () => {
    const { model, ops } = authoring(sceneWith([behavior('x')], [behavior('y')]));
    ops.setProperty('x', 'speed', 99);
    const nodes = model.getScene().nodes;
    expect(nodes.a.behaviors![0].properties.speed).toBe(99);
    expect(nodes.b.behaviors![0].properties.speed).toBe(6);
    expect(nodes.a.behaviors![0].behaviorType).toBe(nodes.b.behaviors![0].behaviorType); // mesma Definition
  });

  it('editar Actions de uma instância não toca na outra (nem nos objetos compartilhados por engano)', () => {
    const shared = behavior('x');
    const { model, ops } = authoring(sceneWith([shared], [{ ...clone(shared), id: 'y' }]));
    ops.addAction('x', 'r_x', 'play_sound');
    ops.setActionParam('y', 'r_x', 'a2', 'text', 'só em Beta'); // a cópia profunda manteve o ID da regra
    const { a, b } = model.getScene().nodes;
    expect(a.behaviors![0].rules[0].actions).toHaveLength(4);
    expect(b.behaviors![0].rules[0].actions).toHaveLength(3);
    expect(a.behaviors![0].rules[0].actions[1].parameters.text).toBe('oi');
    expect(b.behaviors![0].rules[0].actions[1].parameters.text).toBe('só em Beta');
  });

  it('estado de runtime é por (nó × instância): independente, descartável e nunca escreve no authoring', () => {
    const scene = sceneWith([behavior('x')], [behavior('y', { id: 'x' })]); // mesmo ID de instância em nós distintos
    const authoringBefore = clone(scene.nodes);
    const states = new BehaviorRuntimeStates();
    const sa = states.ensure('a', scene.nodes.a.behaviors![0]);
    const sb = states.ensure('b', scene.nodes.b.behaviors![0]);
    expect(sa).not.toBe(sb);
    sa.properties.speed = 1000;
    sa.memory.timer = 3;
    expect(sb.properties.speed).toBe(6);
    expect(sb.memory).toEqual({});
    expect(states.ensure('a', scene.nodes.a.behaviors![0])).toBe(sa); // o mesmo par devolve o mesmo estado
    expect(scene.nodes).toEqual(authoringBefore); // o authoring não mudou
    states.reset('a', 'x');
    expect(states.ensure('a', scene.nodes.a.behaviors![0]).properties.speed).toBe(6); // "restart behaviors"
    states.dispose();
    expect(states.size).toBe(0);
  });

  it('o ID da instância é estável: renomear não muda ID; duplicar gera IDs novos para tudo', () => {
    const { model, ops } = authoring(sceneWith([behavior('x')]));
    ops.rename('x', 'Outro nome');
    expect(model.getScene().nodes.a.behaviors![0].id).toBe('x');
    const copyId = ops.duplicate('x')!;
    const [orig, copy] = model.getScene().nodes.a.behaviors!;
    expect(copy.id).toBe(copyId);
    expect(copy.id).not.toBe(orig.id);
    expect(copy.rules[0].actions.map((a) => a.id)).not.toEqual(orig.rules[0].actions.map((a) => a.id));
  });
});

describe('AIS-41b — reordenar não troca IDs (C02)', () => {
  it('cada Action mantém seu ID, tipo e parâmetros; só a ordem muda', () => {
    const { model, ops } = authoring();
    const byId = () => Object.fromEntries(model.getScene().nodes.a.behaviors![0].rules[0].actions.map((a) => [a.id, [a.type, a.parameters]]));
    const before = byId();
    ops.reorderActions('x', 'r_x', 0, 2);
    const after = model.getScene().nodes.a.behaviors![0].rules[0].actions;
    expect(after.map((a) => a.id)).toEqual(['a2', 'a3', 'a1']);
    expect(byId()).toEqual(before);
  });
});

describe('AIS-41b — salvar e reabrir preserva tudo (C03, C04)', () => {
  it('parâmetros, regras, condições e Actions sobrevivem a salvar → reabrir, e o texto é um ponto fixo', () => {
    const scene = sceneWith([behavior('x')], [behavior('y', { enabled: false, name: 'Desligado' })]);
    const text = serializeSceneToJson(scene);
    const reopened = parseSceneJson(text, PATH);
    expect(reopened.ok).toBe(true);
    expect(reopened.scene!.nodes.a.behaviors).toEqual(scene.nodes.a.behaviors);
    expect(reopened.scene!.nodes.b.behaviors).toEqual(scene.nodes.b.behaviors);
    expect(serializeSceneToJson(reopened.scene!)).toBe(text);
    expect(reopened.migration?.migrated).toBe(false);
    expect(reopened.scene!.schemaVersion).toBe(CURRENT_SCENE_SCHEMA_VERSION);
  });

  it('no arquivo o tipo vai como contributionId e em memória é behaviorType', () => {
    const scene = sceneWith([behavior('x')]);
    const file = serializeScene(scene).nodes.a as any;
    expect(file.behaviors[0]).toMatchObject({ id: 'x', contributionId: 'simple_wasd_movement', name: 'B_x' });
    expect(file.behaviors[0]).not.toHaveProperty('behaviorType');
    expect(file.behaviors[0]).not.toHaveProperty('targetNodeId');
    expect(parseSceneJson(serializeSceneToJson(scene), PATH).scene!.nodes.a.behaviors![0].behaviorType).toBe('simple_wasd_movement');
  });

  it('Action, Condition, Trigger e Behavior de ID desconhecido passam intactos, com campos extras', () => {
    const odd = behavior('odd', {
      behaviorType: 'comportamento_do_futuro',
      extra: { source: 'custom', addonId: 'pacote_legado', campo: { x: [1, 2] } },
      rules: [
        {
          id: 'r',
          eventType: 'gatilho_novo',
          parameters: { g: 1 },
          extra: { prioridade: 7 },
          conditions: [{ id: 'c', type: 'condicao_nova', parameters: { limite: [1, { fundo: true }] }, extra: { nota: 'x' } }],
          actions: [{ id: 'a', type: 'acao_futura', parameters: { segredo: { k: [1, 2, 3] } }, extra: { duracao: 2 } }],
        },
      ],
    });
    const scene = sceneWith([odd]);
    const text = serializeSceneToJson(scene);
    const back = parseSceneJson(text, PATH, { isKnownContribution: isKnownLogicContribution });
    expect(back.scene!.nodes.a.behaviors![0]).toEqual(odd);
    // a varredura sinaliza os quatro e não altera nada
    expect(back.unresolved.map((u) => `${u.kind}:${u.contributionId}`).sort()).toEqual(['action:acao_futura', 'behavior:comportamento_do_futuro', 'condition:condicao_nova', 'trigger:gatilho_novo']);
    expect(serializeSceneToJson(back.scene!)).toBe(text);
  });

  it('editar com o editor (Commands) uma Action ao lado de uma desconhecida não destrói a desconhecida', () => {
    const odd = behavior('x');
    odd.rules[0].actions.push({ id: 'a_odd', type: 'acao_futura', parameters: { segredo: [1, { a: 2 }] }, extra: { duracao: 2 } });
    const { model, ops, manager } = authoring(sceneWith([odd]));
    ops.addAction('x', 'r_x', 'play_sound');
    ops.reorderActions('x', 'r_x', 3, 0);
    ops.removeAction('x', 'r_x', 'a1');
    const saved = parseSceneJson(serializeSceneToJson(model.getScene()), PATH).scene!;
    const kept = saved.nodes.a.behaviors![0].rules[0].actions.find((a) => a.id === 'a_odd');
    expect(kept).toEqual({ id: 'a_odd', type: 'acao_futura', parameters: { segredo: [1, { a: 2 }] }, extra: { duracao: 2 } });
    while (manager.canUndo()) manager.undo();
    expect(model.getScene().nodes.a.behaviors![0]).toEqual(odd);
  });

  it('entrada de Behavior que não é um objeto com id é guardada em metadata.legacyBehaviors, com aviso, e regravada', () => {
    const file = serializeScene(sceneWith([behavior('x')])) as any;
    file.nodes.a.behaviors.push('beh_perdido', 42);
    const r = deserializeScene(clone(file), PATH);
    expect(r.ok).toBe(true);
    expect(r.scene!.nodes.a.behaviors).toHaveLength(1);
    expect(r.scene!.metadata!.legacyBehaviors).toEqual([
      { reason: 'invalid_entry', nodeId: 'a', behavior: 'beh_perdido' },
      { reason: 'invalid_entry', nodeId: 'a', behavior: 42 },
    ]);
    expect(r.diagnostics.filter((d) => d.code === 'scene.behavior_unattached')).toHaveLength(2);
    expect((serializeScene(r.scene!) as any).metadata.legacyBehaviors).toHaveLength(2);
  });

  it('conversão pura: behaviorFromFile devolve null sem id; behaviorsFromFile separa as rejeitadas', () => {
    expect(behaviorFromFile({ contributionId: 'x' })).toBeNull();
    expect(behaviorFromFile('texto')).toBeNull();
    const r = behaviorsFromFile([{ id: 'ok', contributionId: 'click_detector' }, 7]);
    expect(r.behaviors.map((b) => b.id)).toEqual(['ok']);
    expect(r.rejected).toEqual([7]);
    const b = behavior('z');
    expect(behaviorFromFile(behaviorToFile(b))).toEqual(b);
  });
});

describe('AIS-41b — migração da lista global para GameNode.behaviors (C10, C11, C12, C13)', () => {
  /** Cena v2 como o AIS-29b gravava: `behaviors` só com IDs (e a lista global, quando existia, em memória/na raiz). */
  const v2Scene = (extra: Record<string, unknown> = {}, nodes: Record<string, unknown> = {}) => ({
    schemaVersion: 2,
    sceneId: 'scene_t',
    name: 'T',
    rootNodeId: 'root',
    nodes: {
      root: { id: 'root', name: 'World', type: 'Spatial', parentId: null, childrenIds: ['player', 'orb', 'dup1', 'dup2'] },
      player: { id: 'player', name: 'PlayerMesh', type: 'MeshInstance', parentId: 'root', behaviors: [STARTER_BEHAVIOR_IDS.player] },
      orb: { id: 'orb', name: 'MagicOrb', type: 'MeshInstance', parentId: 'root' },
      dup1: { id: 'dup1', name: 'Gemeo', type: 'MeshInstance', parentId: 'root' },
      dup2: { id: 'dup2', name: 'Gemeo', type: 'MeshInstance', parentId: 'root' },
      ...nodes,
    },
    ...extra,
  });
  const globalEntry = (id: string, targetNodeId: string, over: Record<string, unknown> = {}) => ({ ...behavior(id), targetNodeId, ...over });

  it('lista global → cada Behavior aparece no GameNode referenciado (por ID ou por nome único)', () => {
    const doc = v2Scene({ behaviors: [globalEntry('g1', 'MagicOrb'), globalEntry('g2', 'player', { name: 'Controle' })] });
    const r = deserializeScene(clone(doc), PATH);
    expect(r.ok).toBe(true);
    const nodes = r.scene!.nodes;
    expect(nodes.orb.behaviors!.map((b) => b.id)).toEqual(['g1']);
    expect(nodes.orb.behaviors![0]).toEqual(expect.objectContaining({ behaviorType: 'simple_wasd_movement', properties: behavior('g1').properties, rules: behavior('g1').rules }));
    expect(nodes.player.behaviors!.map((b) => b.id)).toEqual([STARTER_BEHAVIOR_IDS.player, 'g2']); // o ID do starter + o da lista global
    expect(nodes.player.behaviors![1].name).toBe('Controle');
    expect(r.diagnostics.map((d) => d.code)).toContain('scene.migrated');
    expect(r.scene!.metadata?.legacyBehaviors).toBeUndefined();
  });

  it('IDs beh_* do projeto inicial viram as instâncias de exemplo no nó que os listava (nada fica sem definição)', () => {
    const r = deserializeScene(clone(v2Scene()), PATH);
    const b = r.scene!.nodes.player.behaviors!;
    expect(b).toEqual([createStarterBehavior(STARTER_BEHAVIOR_IDS.player)]);
  });

  it('nada é perdido: Behavior sem nó, nome ambíguo e ID sem definição vão intactos para metadata.legacyBehaviors, com aviso', () => {
    const doc = v2Scene(
      { behaviors: [globalEntry('g_sem_dono', 'NoQueNaoExiste'), globalEntry('g_ambiguo', 'Gemeo'), globalEntry('g_ok', 'orb')] },
      { orb: { id: 'orb', name: 'MagicOrb', type: 'MeshInstance', parentId: 'root', behaviors: ['id_sem_definicao'] } }
    );
    const r = deserializeScene(clone(doc), PATH);
    const legacy = r.scene!.metadata!.legacyBehaviors as any[];
    expect(legacy.map((e) => `${e.reason}:${e.id ?? e.behavior.id}`).sort()).toEqual(['unattached:g_ambiguo', 'unattached:g_sem_dono', 'unresolved_id:id_sem_definicao']);
    expect(legacy.find((e) => e.behavior?.id === 'g_sem_dono').behavior).toEqual((doc as any).behaviors[0]); // intacto, na forma original
    expect(r.scene!.nodes.orb.behaviors!.map((b) => b.id)).toEqual(['g_ok']);
    expect(r.scene!.nodes.dup1.behaviors ?? []).toEqual([]);
    expect(r.scene!.nodes.dup2.behaviors ?? []).toEqual([]); // nome ambíguo: nunca anexado a um nó "no chute"
    expect(r.diagnostics.filter((d) => d.code === 'scene.behavior_unattached')).toHaveLength(3);
    // e salvar regrava o bloco (nada some no próximo save)
    const saved = serializeScene(r.scene!) as any;
    expect(saved.metadata.legacyBehaviors).toHaveLength(3);
    expect(parseSceneJson(serializeSceneToJson(r.scene!), PATH).scene!.metadata!.legacyBehaviors).toHaveLength(3);
  });

  it('a lista global some do arquivo salvo (lida e migrada, nunca regravada) e a cena fica na versão corrente', () => {
    const doc = v2Scene({ behaviors: [globalEntry('g1', 'orb')] });
    const saved = serializeScene(deserializeScene(clone(doc), PATH).scene!) as any;
    expect(saved).not.toHaveProperty('behaviors');
    expect(saved.schemaVersion).toBe(CURRENT_SCENE_SCHEMA_VERSION);
    // nenhum nó guarda mais a lista de IDs antiga
    for (const n of Object.values(saved.nodes) as any[]) if (n.behaviors) for (const b of n.behaviors) expect(typeof b).toBe('object');
  });

  it('salvar → reabrir mantém todos os Behaviors migrados e é estável (ponto fixo)', () => {
    const doc = v2Scene({ behaviors: [globalEntry('g1', 'MagicOrb')] });
    const first = deserializeScene(clone(doc), PATH).scene!;
    const text = serializeSceneToJson(first);
    const again = parseSceneJson(text, PATH);
    expect(again.migration?.migrated).toBe(false);
    expect(again.scene!.nodes.orb.behaviors).toEqual(first.nodes.orb.behaviors);
    expect(again.scene!.nodes.player.behaviors).toEqual(first.nodes.player.behaviors);
    expect(serializeSceneToJson(again.scene!)).toBe(text);
  });

  it('dois nós que listavam o mesmo ID antigo ficam com instâncias independentes e IDs únicos na cena', () => {
    const doc = v2Scene({}, { orb: { id: 'orb', name: 'MagicOrb', type: 'MeshInstance', parentId: 'root', behaviors: [STARTER_BEHAVIOR_IDS.player] } });
    const nodes = deserializeScene(clone(doc), PATH).scene!.nodes;
    const a = nodes.player.behaviors![0];
    const b = nodes.orb.behaviors![0];
    expect(a.id).toBe(STARTER_BEHAVIOR_IDS.player);
    expect(b.id).not.toBe(a.id);
    expect(b.id.startsWith(STARTER_BEHAVIOR_IDS.player)).toBe(true);
    expect(b.rules).toEqual(a.rules); // mesmos dados, instâncias distintas
    expect(b).not.toBe(a);
    const ids = collectBehaviors({ nodes }).map((v) => v.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('a migração é pura (não muda a entrada) e idempotente na versão corrente', () => {
    const doc = v2Scene({ behaviors: [globalEntry('g1', 'orb')] });
    const input = clone(doc);
    const out = migrateSceneV2ToV3(input) as any;
    expect(input).toEqual(doc);
    expect(out).not.toBe(input);
    const stepwise = migrateStepwise('scene', doc);
    expect(stepwise.ok && stepwise.toVersion).toBe(CURRENT_SCENE_SCHEMA_VERSION);
    if (stepwise.ok) {
      const twice = migrateStepwise('scene', stepwise.data);
      expect(twice.ok && twice.migrated).toBe(false);
    }
  });

  it('migração do formato AIS-29 (IDs no nó + definições em visualLogic.behaviors) preserva cada campo', () => {
    const def = { id: 'b9', contributionId: 'comportamento_removido', source: 'custom', addonId: 'pacote_legado', properties: { speed: 3 }, label: 'Meu' };
    const doc = v2Scene({}, { orb: { id: 'orb', name: 'MagicOrb', type: 'MeshInstance', parentId: 'root', behaviors: ['b9'], visualLogic: { behaviors: [def], actions: [{ id: 'aa', contributionId: 'x', parameters: {} }] } } });
    const orb = deserializeScene(clone(doc), PATH).scene!.nodes.orb;
    expect(orb.behaviors).toHaveLength(1);
    expect(orb.behaviors![0]).toMatchObject({ id: 'b9', behaviorType: 'comportamento_removido', properties: { speed: 3 }, extra: { source: 'custom', addonId: 'pacote_legado', label: 'Meu' } });
    expect((orb as any).visualLogic).toEqual({ actions: [{ id: 'aa', contributionId: 'x', parameters: {} }] });
  });
});

describe('AIS-41b — projeto novo (template)', () => {
  it('o starter já nasce com as três instâncias inline, nos nós certos, e salvar → reabrir as mantém', () => {
    const scene = createDefault3DStarterScene();
    const byName = (name: string) => Object.values(scene.nodes).find((n) => n.name === name)!;
    expect(byName('PlayerMesh').behaviors!.map((b) => b.id)).toEqual([STARTER_BEHAVIOR_IDS.player]);
    expect(byName('MagicOrb').behaviors!.map((b) => b.id)).toEqual([STARTER_BEHAVIOR_IDS.orb]);
    expect(byName('HUD_InventoryButton').behaviors!.map((b) => b.id)).toEqual([STARTER_BEHAVIOR_IDS.inventoryButton]);
    const ids = collectBehaviors(scene).map((b) => b.id);
    expect(new Set(ids).size).toBe(ids.length);
    const text = serializeSceneToJson(scene);
    const back = parseSceneJson(text, PATH);
    expect(back.migration?.migrated).toBe(false);
    for (const name of ['PlayerMesh', 'MagicOrb', 'HUD_InventoryButton']) {
      const original = byName(name).behaviors;
      expect(Object.values(back.scene!.nodes).find((n) => n.name === name)!.behaviors).toEqual(original);
    }
  });
});

describe('AIS-41b — Behaviors na cena e a visão derivada', () => {
  it('collectBehaviors devolve a MESMA referência enquanto a instância não muda (React e Commands dependem disso)', () => {
    const scene = sceneWith([behavior('x')], [behavior('y')]);
    const first = collectBehaviors(scene);
    const second = collectBehaviors(scene);
    expect(first.map((v, i) => v === second[i])).toEqual([true, true]);
    expect(first.map((b) => b.targetNodeId)).toEqual(['a', 'b']);
  });

  it('o alvo é resolvido por ID, ou por nome quando for único; ambíguo/inexistente é órfão (nunca gravado)', () => {
    const scene = sceneWith([], []);
    scene.nodes.c = node('c', 'Alfa', { parentId: scene.rootNodeId });
    const views = [
      { ...behavior('1'), targetNodeId: 'a' },
      { ...behavior('2'), targetNodeId: 'Beta' },
      { ...behavior('3'), targetNodeId: 'Alfa' }, // ambíguo: Alfa é 'a' e 'c'
      { ...behavior('4'), targetNodeId: 'nada' },
    ];
    const { byNode, orphans } = groupBehaviorsByNode(views, scene);
    expect([...byNode.keys()].sort()).toEqual(['a', 'b']);
    expect(orphans.map((o) => o.id)).toEqual(['3', '4']);
  });

  it('escrever só toca nos nós que mudaram; Undo devolve exatamente as instâncias anteriores', () => {
    const { model, ops, manager } = authoring();
    const before = model.getScene().nodes;
    ops.setEnabled('x', false);
    const after = model.getScene().nodes;
    expect(after.b.behaviors).toBe(before.b.behaviors); // outro nó: a mesma lista
    expect(after.a.behaviors![0].enabled).toBe(false);
    manager.undo();
    expect(model.getScene().nodes.a.behaviors![0]).toEqual(before.a.behaviors![0]);
  });

  it('o catálogo do LogicRegistry é a Definition: toda instância de exemplo aponta para uma pasta existente', () => {
    for (const id of Object.values(STARTER_BEHAVIOR_IDS)) {
      const b = createStarterBehavior(id)!;
      expect(LogicRegistry.isKnownBehavior(b.behaviorType), b.behaviorType).toBe(true);
      for (const rule of b.rules) {
        expect(LogicRegistry.isKnownTrigger(rule.eventType)).toBe(true);
        rule.actions.forEach((a) => expect(LogicRegistry.isKnownAction(a.type)).toBe(true));
      }
    }
  });
});
