import { describe, expect, it } from 'vitest';
import type { GameNode } from '../../types/node';
import type { SceneData } from '../../types/scene';
import { createDefault3DStarterScene } from '../defaultProject';
import { createDefaultNode } from '../../nodes/registry';
import { CURRENT_SCENE_SCHEMA_VERSION } from '../persistenceVersions';
import {
  compactProperties,
  deepEqual,
  derivedSceneId,
  deserializeScene,
  expandProperties,
  parseSceneJson,
  serializeScene,
  serializeSceneToJson,
  stringifyCompact,
} from './sceneSerializer';

const PATH = 'res://scenes/Teste.scene.json';

function node(id: string, type: string, parentId: string | null, childrenIds: string[] = [], properties: Record<string, any> = {}, extra: Record<string, any> = {}): GameNode {
  return { id, name: id, type, parentId, childrenIds, visible: true, locked: false, properties, ...extra } as GameNode;
}

function smallScene(): SceneData {
  const mesh = createDefaultNode('MeshInstance', 'Cubo', 'root');
  mesh.id = 'mesh1';
  mesh.properties.position = { x: 1, y: 2.5, z: -3 };
  const light = createDefaultNode('OmniLight', 'Luz', 'root');
  light.id = 'light1';
  const root = node('root', 'Spatial', null, ['mesh1', 'light1']);
  return { id: 'scene_t', name: 'Teste', path: PATH, rootNodeId: 'root', environmentNodeId: null, nodes: { root, mesh1: mesh, light1: light }, createdAt: '2026-10-01T00:00:00.000Z', updatedAt: '2026-10-02T00:00:00.000Z' };
}

/** Cena como o parser a entrega (padrões do tipo preenchidos): a forma canônica em memória. */
const canonical = (scene: SceneData): SceneData => {
  const r = deserializeScene(serializeScene(scene), scene.path);
  if (!r.ok || !r.scene) throw new Error('falhou');
  return r.scene;
};

describe('serialização compacta (AIS-29)', () => {
  it('formato canônico: sceneId, schemaVersion, hierarquia por rootNodeId + parentId, sem path nem runtime', () => {
    const file = serializeScene(smallScene());
    expect(file).toMatchObject({ schemaVersion: CURRENT_SCENE_SCHEMA_VERSION, sceneId: 'scene_t', name: 'Teste', rootNodeId: 'root' });
    expect(file).not.toHaveProperty('path');
    expect(Object.keys(file.nodes)).toEqual(['root', 'mesh1', 'light1']);
    expect(file.nodes.mesh1).toMatchObject({ id: 'mesh1', type: 'MeshInstance', parentId: 'root' });
  });
  it('vetores viram [x,y,z] e valores iguais ao padrão do tipo são omitidos', () => {
    const file = serializeScene(smallScene());
    const props = (file.nodes.mesh1 as any).properties;
    expect(props.position).toEqual([1, 2.5, -3]);
    expect(props).not.toHaveProperty('scale'); // padrão (1,1,1)
    expect(props).not.toHaveProperty('meshType'); // padrão CubeMesh
    expect(file.nodes.mesh1).not.toHaveProperty('visible');
    expect(file.nodes.mesh1).not.toHaveProperty('locked');
    expect(file.nodes.mesh1).not.toHaveProperty('childrenIds');
  });
  it('o arquivo compacto é bem menor que o JSON direto da cena', () => {
    const scene = createDefault3DStarterScene();
    const compact = serializeSceneToJson(scene).length;
    const naive = JSON.stringify(scene, null, 2).length;
    expect(compact).toBeLessThan(naive * 0.7);
  });
  it('saída determinística: ordem estável, arrays curtos numa linha, termina com quebra de linha', () => {
    const scene = smallScene();
    const a = serializeSceneToJson(scene);
    const shuffled: SceneData = { ...scene, nodes: { light1: scene.nodes.light1, mesh1: scene.nodes.mesh1, root: scene.nodes.root } };
    expect(serializeSceneToJson(shuffled)).toBe(a);
    expect(a).toContain('"position": [1, 2.5, -3]');
    expect(a.endsWith('}\n')).toBe(true);
    expect(JSON.parse(a)).toEqual(JSON.parse(JSON.stringify(serializeScene(scene))));
  });
  it('stringifyCompact não reescreve o conteúdo de strings', () => {
    const tricky = { text: 'a [1,\n 2] b', list: [1, 2, 3], big: Array.from({ length: 60 }, (_, i) => i) };
    const out = stringifyCompact(tricky);
    expect(JSON.parse(out)).toEqual(tricky);
    expect(out).toContain('"list": [1, 2, 3]');
  });
});

describe('round-trip sem perda (AIS-29)', () => {
  it('parse(serialize(cena)) = cena na forma canônica; serializar de novo dá o mesmo texto', () => {
    const scene = canonical(smallScene());
    const again = canonical(scene);
    expect(deepEqual(again.nodes, scene.nodes)).toBe(true);
    expect(serializeSceneToJson(again)).toBe(serializeSceneToJson(scene));
    expect(scene.nodes.mesh1.properties.position).toEqual({ x: 1, y: 2.5, z: -3 });
    expect(scene.nodes.mesh1.properties.scale).toEqual({ x: 1, y: 1, z: 1 }); // padrão devolvido na leitura
  });
  it('a cena inicial do projeto atravessa o round-trip intacta (nós, ordem dos filhos, propriedades)', () => {
    const start = createDefault3DStarterScene();
    const back = canonical(start);
    expect(Object.keys(back.nodes).sort()).toEqual(Object.keys(start.nodes).sort());
    for (const id of Object.keys(start.nodes)) {
      expect(back.nodes[id].childrenIds).toEqual(start.nodes[id].childrenIds);
      expect(back.nodes[id].parentId).toBe(start.nodes[id].parentId);
      for (const [key, value] of Object.entries(start.nodes[id].properties)) expect(back.nodes[id].properties[key]).toEqual(value);
    }
    expect(back.environment ?? null).toEqual(start.environment ?? null);
    expect(back.fog ?? null).toEqual(start.fog ?? null);
    expect(back.postProcessing ?? null).toEqual(start.postProcessing ?? null);
  });
  it('configurações da cena (ambiente, câmera, pós-processamento, fog) sobrevivem', () => {
    const scene = { ...smallScene(), environment: { ambientColor: '#112233' } as any, cameraSettings: { fov: 50 } as any, fog: { enabled: true } as any };
    const back = canonical(scene);
    expect(back.environment).toEqual({ ambientColor: '#112233' });
    expect(back.cameraSettings).toEqual({ fov: 50 });
    expect(back.fog).toEqual({ enabled: true });
  });
  it('propriedades fora do registry e valores não-padrão são preservados; compact/expand são inversos', () => {
    const props = { position: { x: 0, y: 5, z: 0 }, customFlag: { a: [1, 2] }, castShadow: false };
    const compact = compactProperties('MeshInstance', props);
    expect(compact.position).toEqual([0, 5, 0]);
    expect(compact.customFlag).toEqual({ a: [1, 2] });
    const expanded = expandProperties('MeshInstance', compact);
    for (const [k, v] of Object.entries(props)) expect(expanded[k]).toEqual(v);
  });
  it('vetor com forma estranha (extra chave) fica como está, sem perda', () => {
    const odd = { x: 1, y: 2, z: 3, w: 4 };
    expect(compactProperties('MeshInstance', { position: odd }).position).toEqual(odd);
  });
});

describe('leitura tolerante e defensiva (AIS-29)', () => {
  const baseFile = () => JSON.parse(serializeSceneToJson(smallScene()));

  it('aceita o formato antigo (SceneData direto, com id/path e vetores em objeto)', () => {
    const legacy = JSON.parse(JSON.stringify(smallScene()));
    const r = deserializeScene(legacy, PATH);
    expect(r.ok).toBe(true);
    expect(r.scene!.id).toBe('scene_t');
    expect(r.scene!.nodes.mesh1.properties.position).toEqual({ x: 1, y: 2.5, z: -3 });
  });
  it('JSON inválido, não-objeto e sem nós viram diagnóstico, nunca exceção', () => {
    expect(parseSceneJson('{ quebrado', PATH).diagnostics[0].code).toBe('scene.json_invalid');
    expect(deserializeScene('texto', PATH).diagnostics[0].code).toBe('scene.not_object');
    expect(deserializeScene({ rootNodeId: 'a', nodes: {} }, PATH).diagnostics.map((d) => d.code)).toContain('scene.nodes_missing');
  });
  it('schemaVersion mais novo é recusado explicitamente, sem abrir pela metade', () => {
    const file = { ...baseFile(), schemaVersion: CURRENT_SCENE_SCHEMA_VERSION + 1 };
    const r = deserializeScene(file, PATH);
    expect(r.ok).toBe(false);
    expect(r.scene).toBeUndefined();
    expect(r.diagnostics.find((d) => d.code === 'scene.version_newer')).toMatchObject({ severity: 'error' });
  });
  it('raiz inexistente é erro irrecuperável', () => {
    const file = baseFile();
    file.rootNodeId = 'nao_existe';
    expect(deserializeScene(file, PATH).diagnostics.map((d) => d.code)).toContain('scene.root_missing');
  });
  it('nó corrompido vira Missing preservando o original; a cena abre e salvar devolve o dado intacto', () => {
    const file = baseFile();
    file.nodes.mesh1 = { id: 'mesh1', name: 'Quebrado', type: 'MeshInstance', parentId: 'root', childrenIds: 'não é lista', visible: 'talvez', properties: { position: [9, 9, 9] } };
    file.nodes.stranger = 'isso nem é um nó';
    file.nodes.root.childrenIds = ['mesh1', 'light1', 'stranger'];
    const r = deserializeScene(file, PATH);
    expect(r.ok).toBe(true);
    expect(r.diagnostics.filter((d) => d.code === 'scene.node_corrupted').map((d) => d.nodeId).sort()).toEqual(['mesh1', 'stranger']);
    expect(r.scene!.nodes.mesh1.type).toBe('Missing');
    expect(r.scene!.nodes.light1.type).toBe('OmniLight'); // o resto da cena abre normalmente
    const saved = serializeScene(r.scene!);
    // dados do nó intactos; só os campos ESTRUTURAIS inválidos são normalizados (lista de filhos reconstruída, visível)
    expect((saved.nodes.mesh1 as any)).toMatchObject({ type: 'MeshInstance', name: 'Quebrado', properties: { position: [9, 9, 9] } });
    expect(Array.isArray((saved.nodes.mesh1 as any).childrenIds) || (saved.nodes.mesh1 as any).childrenIds === undefined).toBe(true);
    expect(saved.nodes.stranger as unknown).toBe('isso nem é um nó');
  });
  it('tipo de nó desconhecido é preservado (Missing) e regravado com o tipo e os dados originais', () => {
    const file = baseFile();
    file.nodes.light1 = { id: 'light1', name: 'Futuro', type: 'HologramProjector', parentId: 'root', properties: { beam: [1, 2, 3], power: 9 }, visualLogic: { x: 1 } };
    const r = deserializeScene(file, PATH);
    expect(r.scene!.nodes.light1.type).toBe('Missing');
    expect(r.diagnostics.some((d) => d.code === 'scene.unknown_node_type')).toBe(true);
    const saved = serializeScene(r.scene!);
    expect((saved.nodes.light1 as any).type).toBe('HologramProjector');
    expect((saved.nodes.light1 as any).properties).toEqual({ beam: [1, 2, 3], power: 9 });
    expect((saved.nodes.light1 as any).visualLogic).toEqual({ x: 1 });
  });
  it('Behavior/Action de ID desconhecido e campos extras do nó são preservados', () => {
    const file = baseFile();
    file.schemaVersion = 2; // arquivo no formato anterior (IDs em `behaviors` + definições em `visualLogic.behaviors`)
    const logic = {
      behaviors: [{ id: 'b1', contributionId: 'comportamento_do_futuro', source: 'custom', properties: { speed: 3, extra: { deep: [1] } }, extraField: 'x' }],
      actions: [{ id: 'a1', contributionId: 'acao_inexistente', source: 'builtin', parameters: { n: 1 } }],
    };
    file.nodes.mesh1.visualLogic = logic;
    file.nodes.mesh1.behaviors = ['b1'];
    file.nodes.mesh1.campoFuturo = { qualquer: 'coisa' };
    const back = canonical(deserializeScene(file, PATH).scene!);
    const saved = serializeScene(back);
    // v3 (AIS-41b): a definição sai de `visualLogic.behaviors` para o nó (`behaviors`), com tudo o que tinha; as Actions soltas ficam
    expect((saved.nodes.mesh1 as any).visualLogic).toEqual({ actions: logic.actions });
    expect((saved.nodes.mesh1 as any).behaviors).toEqual([
      { id: 'b1', contributionId: 'comportamento_do_futuro', name: 'comportamento_do_futuro', properties: { speed: 3, extra: { deep: [1] } }, source: 'custom', extraField: 'x' },
    ]);
    expect((saved.nodes.mesh1 as any).campoFuturo).toEqual({ qualquer: 'coisa' });
  });
  it('repara a estrutura: pai inexistente, filho inexistente, lista de filhos incompleta, ciclo — sem perder nós', () => {
    const file = baseFile();
    file.nodes.mesh1.parentId = 'fantasma';
    file.nodes.root.childrenIds = ['light1', 'fantasma2'];
    file.nodes.a = { id: 'a', name: 'a', type: 'Spatial', parentId: 'b', childrenIds: ['b'] };
    file.nodes.b = { id: 'b', name: 'b', type: 'Spatial', parentId: 'a', childrenIds: ['a'] };
    const r = deserializeScene(file, PATH);
    expect(r.ok).toBe(true);
    const nodes = r.scene!.nodes;
    expect(Object.keys(nodes).sort()).toEqual(['a', 'b', 'light1', 'mesh1', 'root']);
    expect(nodes.mesh1.parentId).toBe('root');
    expect(nodes.root.childrenIds).toContain('mesh1');
    expect(nodes.root.childrenIds).not.toContain('fantasma2');
    const codes = r.diagnostics.map((d) => d.code);
    expect(codes).toContain('scene.parent_missing');
    expect(codes).toContain('scene.child_missing');
    expect(codes).toContain('scene.orphan_reattached');
    // toda a hierarquia fica alcançável
    const reach = new Set<string>();
    const walk = (id: string) => { if (!reach.has(id)) { reach.add(id); nodes[id].childrenIds.forEach(walk); } };
    walk('root');
    expect(reach.size).toBe(5);
  });
  it('IDs nunca são inventados: o id vem da chave; o id da cena deriva do caminho e é estável', () => {
    const file = baseFile();
    delete file.sceneId;
    delete file.nodes.mesh1.id;
    const a = deserializeScene(file, PATH);
    const b = deserializeScene(file, PATH);
    expect(a.scene!.nodes.mesh1.id).toBe('mesh1');
    expect(a.scene!.id).toBe(derivedSceneId(PATH));
    expect(a.scene!.id).toBe(b.scene!.id);
    expect(derivedSceneId('res://scenes/Outra.scene.json')).not.toBe(derivedSceneId(PATH));
  });
  it('environmentNodeId inexistente é ignorado com aviso', () => {
    const file = baseFile();
    file.environmentNodeId = 'nada';
    const r = deserializeScene(file, PATH);
    expect(r.scene!.environmentNodeId).toBeNull();
    expect(r.diagnostics.some((d) => d.code === 'scene.environment_missing')).toBe(true);
  });
  it('física legada (StaticBody + CollisionShape) é migrada ao ler a cena', () => {
    const file = baseFile();
    file.nodes.body = { id: 'body', name: 'Chão', type: 'StaticBody', parentId: 'root', childrenIds: ['shape'] };
    file.nodes.shape = { id: 'shape', name: 's', type: 'CollisionShape', parentId: 'body', properties: { shapeType: 'BoxShape', extents: { x: 1, y: 1, z: 1 } } };
    file.nodes.root.childrenIds.push('body');
    const r = deserializeScene(file, PATH);
    expect(r.scene!.nodes.body.type).toBe('Spatial');
    expect(r.scene!.nodes.body.properties.physics).toMatchObject({ bodyMode: 'static', shape: 'box' });
    expect(r.scene!.nodes.shape).toBeUndefined();
  });
});
