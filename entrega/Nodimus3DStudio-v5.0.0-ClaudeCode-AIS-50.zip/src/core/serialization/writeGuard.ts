/**
 * AIS-29b — guarda de escrita: um arquivo que NÃO pôde ser lido (JSON inválido, schema mais novo, migração com falha)
 * nunca é sobrescrito. Enquanto o caminho estiver bloqueado, salvar a cena nesse caminho é recusado com diagnóstico;
 * o usuário pode "Salvar como" em outro caminho, o que não toca no arquivo original.
 */

const blocked = new Map<string, string>();

export function blockWrites(path: string, reason: string): void {
  blocked.set(path, reason);
}

export function unblockWrites(path: string): void {
  blocked.delete(path);
}

/** Motivo do bloqueio, ou `null` se o caminho pode ser gravado. */
export function writeBlockedReason(path: string): string | null {
  return blocked.get(path) ?? null;
}

export function clearWriteBlocks(): void {
  blocked.clear();
}
