import type { GameNode } from '../../types/node';
import type { SceneData } from '../../types/scene';
import type { SceneFile, SceneSettingsFile } from '../../types/sceneFile';
import { NODE_DEFINITIONS } from '../../nodes/registry';
import { GameNodeV1Schema } from '../../schemas/v1/node.schema';
import { convertLegacyPhysics } from '../../schemas/legacyPhysics';
import { MISSING_KEY, MISSING_NODE_TYPE, normalizeUnknownNodes, restoreMissingNode } from '../../schemas/missingNodes';
import { hashContent } from '../documents/documentKinds';
import { CURRENT_SCENE_SCHEMA_VERSION } from '../persistenceVersions';
import { migrateStepwise, type MigrationStepReport } from '../../migrations';
import { collectUnresolvedContributions, type ContributionResolver, type UnresolvedContribution } from './contributions';
import { behaviorsFromFile, behaviorsToFile } from './behaviorFile';

/**
 * AIS-29 — serializador/parser de cenas (`*.scene.json`).
 *
 * Escrita (`serializeScene`): grafo → JSON canônico (`SceneFile`) compacto e DETERMINÍSTICO — nós em ordem de
 * hierarquia, campos em ordem fixa, vetores como `[x,y,z]` e valores iguais ao padrão do tipo omitidos.
 * Leitura (`deserializeScene`): tolerante e defensiva — aceita o formato canônico e o antigo (`SceneData` direto),
 * recusa schema mais novo que o suportado, repara a estrutura (pai/filhos/órfãos), e um nó corrompido vira
 * `Missing` com os dados originais preservados (nunca apagado). IDs nunca são inventados: o id do nó é o da chave
 * da tabela e o id da cena, quando falta, deriva do caminho (estável entre aberturas).
 * Behaviors/Actions de IDs desconhecidos, `visualLogic` e quaisquer campos extras do nó são preservados.
 */

export type SceneDiagnosticCode =
  | 'scene.json_invalid'
  | 'scene.not_object'
  | 'scene.version_newer'
  | 'scene.migration_failed'
  | 'scene.migrated'
  | 'logic.unresolved_contribution'
  | 'scene.behavior_unattached'
  | 'scene.nodes_missing'
  | 'scene.root_missing'
  | 'scene.node_corrupted'
  | 'scene.parent_missing'
  | 'scene.child_missing'
  | 'scene.orphan_reattached'
  | 'scene.environment_missing'
  | 'scene.unknown_node_type';

export interface SceneDiagnostic {
  code: SceneDiagnosticCode;
  severity: 'error' | 'warning' | 'info';
  message: string;
  nodeId?: string;
}

export interface ParseSceneResult {
  ok: boolean;
  scene?: SceneData;
  diagnostics: SceneDiagnostic[];
  /** Migração aplicada na leitura (AIS-29b): o chamador usa `migrated` para a política de backup. */
  migration?: { migrated: boolean; fromVersion: number; toVersion: number; steps: MigrationStepReport[] };
  /** Contribuições de Visual Logic de ID desconhecido: preservadas, só sinalizadas. */
  unresolved: UnresolvedContribution[];
}

export interface DeserializeOptions {
  /** Resolve `contributionId` contra o `LogicRegistry`; ausente = não varre contribuições. */
  isKnownContribution?: ContributionResolver;
}

type AnyRecord = Record<string, any>;
const isRecord = (v: unknown): v is AnyRecord => typeof v === 'object' && v !== null && !Array.isArray(v);
const clone = <T>(v: T): T => (v === undefined ? v : JSON.parse(JSON.stringify(v)));

export function deepEqual(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (typeof a !== 'object' || typeof b !== 'object' || a === null || b === null) return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  const ka = Object.keys(a as AnyRecord);
  const kb = Object.keys(b as AnyRecord);
  return ka.length === kb.length && ka.every((k) => Object.prototype.hasOwnProperty.call(b, k) && deepEqual((a as AnyRecord)[k], (b as AnyRecord)[k]));
}

// ── vetores e padrões por tipo ───────────────────────────────────────────────────────────────

function vectorKeys(type: string): { v3: Set<string>; v2: Set<string> } {
  const def = (NODE_DEFINITIONS as AnyRecord)[type];
  const v3 = new Set<string>();
  const v2 = new Set<string>();
  for (const d of def?.propertyDescriptors ?? []) {
    if (d.type === 'vector3') v3.add(d.key);
    else if (d.type === 'vector2') v2.add(d.key);
  }
  return { v3, v2 };
}

const isVec3 = (v: unknown): v is { x: number; y: number; z: number } =>
  isRecord(v) && Object.keys(v).length === 3 && typeof v.x === 'number' && typeof v.y === 'number' && typeof v.z === 'number';
const isVec2 = (v: unknown): v is { x: number; y: number } => isRecord(v) && Object.keys(v).length === 2 && typeof v.x === 'number' && typeof v.y === 'number';
const isNumArray = (v: unknown, n: number): v is number[] => Array.isArray(v) && v.length === n && v.every((x) => typeof x === 'number');

/** Propriedades de um nó prontas para gravar: padrões do tipo omitidos, vetores compactados. */
export function compactProperties(type: string, properties: AnyRecord): AnyRecord {
  const def = (NODE_DEFINITIONS as AnyRecord)[type];
  const defaults: AnyRecord = def?.defaultProperties ?? {};
  const { v3, v2 } = vectorKeys(type);
  const out: AnyRecord = {};
  for (const [key, value] of Object.entries(properties)) {
    if (key in defaults && deepEqual(value, defaults[key])) continue;
    if (v3.has(key) && isVec3(value)) out[key] = [value.x, value.y, value.z];
    else if (v2.has(key) && isVec2(value)) out[key] = [value.x, value.y];
    else out[key] = value;
  }
  return out;
}

/** Inverso de `compactProperties`: vetores voltam a objetos e os padrões do tipo preenchem o que falta. */
export function expandProperties(type: string, properties: AnyRecord): AnyRecord {
  const def = (NODE_DEFINITIONS as AnyRecord)[type];
  const defaults: AnyRecord = def?.defaultProperties ?? {};
  const { v3, v2 } = vectorKeys(type);
  const out: AnyRecord = {};
  for (const [key, value] of Object.entries(properties)) {
    if (v3.has(key) && isNumArray(value, 3)) out[key] = { x: value[0], y: value[1], z: value[2] };
    else if (v2.has(key) && isNumArray(value, 2)) out[key] = { x: value[0], y: value[1] };
    else out[key] = value;
  }
  for (const [key, value] of Object.entries(defaults)) if (!(key in out)) out[key] = clone(value);
  return out;
}

// ── escrita ──────────────────────────────────────────────────────────────────────────────────

/** Ordem fixa dos campos do nó (saída determinística e diffs limpos); extras vêm depois, em ordem alfabética. */
const NODE_KEY_ORDER = ['id', 'name', 'type', 'parentId', 'childrenIds', 'visible', 'locked', 'collapsed', 'transform', 'properties', 'script', 'behaviors', 'signals', 'tags', 'variables', 'generatorSource', 'visualLogic'];

function serializeNode(node: GameNode): AnyRecord {
  // entrada que não era um objeto no arquivo: volta exatamente como veio
  const rawMissing = node.type === MISSING_NODE_TYPE ? (node.properties as AnyRecord)?.[MISSING_KEY] : undefined;
  if (rawMissing && rawMissing.rawValue !== undefined) return { __corruptedRaw: rawMissing.rawValue };
  const restored = restoreMissingNode(node as AnyRecord);
  if (restored !== node) return restored as AnyRecord; // Missing Node: tipo e dados originais; a estrutura vale como editada
  const source = node as AnyRecord;
  const out: AnyRecord = {};
  const put = (key: string, value: unknown) => {
    if (value !== undefined) out[key] = value;
  };
  for (const key of NODE_KEY_ORDER) {
    const value = source[key];
    switch (key) {
      case 'schemaVersion':
        break;
      case 'childrenIds':
        if (Array.isArray(value) && value.length > 0) out[key] = value;
        break;
      case 'visible':
        if (value === false) out[key] = false;
        break;
      case 'locked':
        if (value === true) out[key] = true;
        break;
      case 'collapsed':
        if (value === true) out[key] = true;
        break;
      case 'properties': {
        const compact = compactProperties(source.type, isRecord(value) ? value : {});
        if (Object.keys(compact).length > 0) out[key] = compact;
        break;
      }
      case 'behaviors': {
        // AIS-41b: instâncias inline; em memória `behaviorType`, no arquivo `contributionId`
        const file = behaviorsToFile(Array.isArray(value) ? value : undefined);
        if (file.length > 0) out[key] = file;
        break;
      }
      case 'signals':
      case 'tags':
        if (Array.isArray(value) && value.length > 0) out[key] = value;
        break;
      case 'variables':
        if (isRecord(value) && Object.keys(value).length > 0) out[key] = value;
        break;
      default:
        put(key, value);
    }
  }
  for (const key of Object.keys(source).sort()) {
    if (NODE_KEY_ORDER.includes(key) || key === 'schemaVersion') continue;
    put(key, source[key]);
  }
  return out;
}

/** Nós em ordem de hierarquia (raiz, depois filhos na ordem de `childrenIds`); o que ficou fora vai no fim, por chave. */
function orderedNodeIds(scene: SceneData): string[] {
  const seen = new Set<string>();
  const order: string[] = [];
  const visit = (id: string) => {
    if (seen.has(id) || !scene.nodes[id]) return;
    seen.add(id);
    order.push(id);
    for (const child of scene.nodes[id].childrenIds ?? []) visit(child);
  };
  visit(scene.rootNodeId);
  for (const id of Object.keys(scene.nodes).sort()) visit(id);
  return order;
}

export function serializeScene(scene: SceneData): SceneFile {
  const nodes: Record<string, unknown> = {};
  for (const id of orderedNodeIds(scene)) {
    const serialized = serializeNode(scene.nodes[id]);
    // entrada que não era um objeto no arquivo original volta exatamente como veio
    nodes[id] = '__corruptedRaw' in serialized ? serialized.__corruptedRaw : serialized;
  }
  const settings: SceneSettingsFile = {};
  if (scene.environment) settings.environment = scene.environment;
  if (scene.cameraSettings) settings.cameraSettings = scene.cameraSettings;
  if (scene.postProcessing) settings.postProcessing = scene.postProcessing;
  if (scene.fog) settings.fog = scene.fog;
  const file: SceneFile = {
    schemaVersion: CURRENT_SCENE_SCHEMA_VERSION,
    sceneId: scene.id,
    name: scene.name,
    rootNodeId: scene.rootNodeId,
    ...(scene.environmentNodeId ? { environmentNodeId: scene.environmentNodeId } : {}),
    nodes: nodes as SceneFile['nodes'],
    ...(Object.keys(settings).length ? { sceneSettings: settings } : {}),
    // AIS-41b: `legacyBehaviors` (o que a migração não anexou a um nó) volta ao arquivo; metadata vazia não é gravada
    ...(scene.metadata && Object.keys(scene.metadata).length ? { metadata: scene.metadata } : {}),
    createdAt: scene.createdAt,
    updatedAt: scene.updatedAt,
  };
  return file;
}

/**
 * JSON com indentação de 2 espaços e arrays curtos de primitivos numa linha só (`[0, 1, 0]`). Escrita recursiva:
 * strings nunca são reescritas (nada de regex sobre o texto).
 */
export function stringifyCompact(value: unknown, indent = 0): string {
  const pad = (n: number) => '  '.repeat(n);
  if (Array.isArray(value)) {
    if (value.length === 0) return '[]';
    if (value.every((v) => v === null || typeof v !== 'object')) {
      const inline = `[${value.map((v) => JSON.stringify(v)).join(', ')}]`;
      if (inline.length <= 100) return inline;
    }
    return `[\n${value.map((v) => pad(indent + 1) + stringifyCompact(v, indent + 1)).join(',\n')}\n${pad(indent)}]`;
  }
  if (isRecord(value)) {
    const entries = Object.entries(value).filter(([, v]) => v !== undefined);
    if (entries.length === 0) return '{}';
    return `{\n${entries.map(([k, v]) => `${pad(indent + 1)}${JSON.stringify(k)}: ${stringifyCompact(v, indent + 1)}`).join(',\n')}\n${pad(indent)}}`;
  }
  return JSON.stringify(value) ?? 'null';
}

export function serializeSceneToJson(scene: SceneData): string {
  return stringifyCompact(serializeScene(scene)) + '\n';
}

// ── leitura ──────────────────────────────────────────────────────────────────────────────────

function missingFromCorrupted(key: string, raw: unknown, rootId: string, message: string): GameNode {
  const parentId = isRecord(raw) && typeof raw.parentId === 'string' ? raw.parentId : rootId;
  return {
    id: key,
    name: isRecord(raw) && typeof raw.name === 'string' && raw.name ? raw.name : key,
    type: MISSING_NODE_TYPE as GameNode['type'],
    parentId: key === rootId ? null : parentId,
    childrenIds: isRecord(raw) && Array.isArray(raw.childrenIds) ? raw.childrenIds.filter((c: unknown) => typeof c === 'string') : [],
    visible: true,
    locked: false,
    properties: {
      [MISSING_KEY]: isRecord(raw)
        ? { originalType: typeof raw.type === 'string' ? raw.type : '__corrupted__', originalNode: clone(raw), reason: message }
        : { originalType: '__corrupted__', rawValue: clone(raw), reason: message },
    },
  };
}

/** Id estável da cena quando o arquivo não traz um: derivado do caminho (igual a cada abertura; nunca aleatório). */
export function derivedSceneId(path: string): string {
  return `scene_${(hashContent(path) ?? 'x').replace(/[^a-z0-9]/gi, '')}`;
}

/**
 * Lê uma cena já decodificada (formato canônico ou antigo). `path` = onde o arquivo mora (não é gravado no arquivo).
 * Erros irrecuperáveis (`ok: false`): não é objeto, versão mais nova, sem `nodes`, raiz inexistente.
 */
export function deserializeScene(input: unknown, path: string, options: DeserializeOptions = {}): ParseSceneResult {
  const diagnostics: SceneDiagnostic[] = [];
  const fail = (code: SceneDiagnosticCode, message: string): ParseSceneResult => ({ ok: false, diagnostics: [...diagnostics, { code, severity: 'error', message }], unresolved: [] });
  if (!isRecord(input)) return fail('scene.not_object', 'O arquivo da cena não contém um objeto JSON.');

  // AIS-29b: migração versão a versão (nunca pulando); falha = nada é aberto nem gravado
  const migration = migrateStepwise<AnyRecord>('scene', input);
  if (!migration.ok) {
    return fail(migration.code === 'migration.version_newer' ? 'scene.version_newer' : 'scene.migration_failed', migration.message);
  }
  const raw = migration.data;
  const version = migration.toVersion;
  if (migration.migrated) {
    diagnostics.push({ code: 'scene.migrated', severity: 'info', message: `Cena migrada de v${migration.fromVersion} para v${migration.toVersion} (${migration.steps.map((s) => s.description).join('; ')}).` });
  }
  if (!isRecord(raw.nodes) || Object.keys(raw.nodes).length === 0) return fail('scene.nodes_missing', 'A cena não tem a tabela de nós.');

  const rootId = typeof raw.rootNodeId === 'string' ? raw.rootNodeId : '';
  if (!rootId || !(rootId in raw.nodes)) return fail('scene.root_missing', `O nó raiz "${rootId}" não existe na tabela de nós.`);

  // migração física legada + tipos desconhecidos → Missing (preservados), antes de validar cada nó
  const prepared = normalizeUnknownNodes(convertLegacyPhysics({ nodes: raw.nodes })).nodes as AnyRecord;

  const nodes: Record<string, GameNode> = {};
  const rejectedBehaviors: AnyRecord[] = [];
  for (const [key, entry] of Object.entries(prepared)) {
    if (isRecord(entry) && entry.type === MISSING_NODE_TYPE && isRecord(entry.properties?.[MISSING_KEY]) && entry.properties[MISSING_KEY].originalType) {
      const original = entry.properties[MISSING_KEY].originalType;
      if (!(original in NODE_DEFINITIONS)) diagnostics.push({ code: 'scene.unknown_node_type', severity: 'info', message: `Nó "${key}" de tipo desconhecido (${original}) preservado como Missing.`, nodeId: key });
    }
    if (!isRecord(entry)) {
      diagnostics.push({ code: 'scene.node_corrupted', severity: 'warning', message: `Nó "${key}" corrompido (não é um objeto); preservado como Missing.`, nodeId: key });
      nodes[key] = missingFromCorrupted(key, entry, rootId, 'não é um objeto');
      continue;
    }
    // o id vem da chave: nunca inventado nem sorteado
    const candidate = { ...entry, id: typeof entry.id === 'string' && entry.id ? entry.id : key, name: typeof entry.name === 'string' && entry.name ? entry.name : key };
    const parsed = GameNodeV1Schema.safeParse(candidate);
    if (!parsed.success) {
      const why = parsed.error.issues[0] ? `${parsed.error.issues[0].path.join('.') || '(nó)'}: ${parsed.error.issues[0].message}` : 'inválido';
      diagnostics.push({ code: 'scene.node_corrupted', severity: 'warning', message: `Nó "${key}" corrompido (${why}); preservado como Missing.`, nodeId: key });
      nodes[key] = missingFromCorrupted(key, entry, rootId, why);
      continue;
    }
    const node = parsed.data as AnyRecord;
    // `parentId`/`childrenIds`/`visible`… ausentes no arquivo compacto voltam ao padrão; Missing não ganha padrões de tipo
    const type = node.type as string;
    const properties = type === MISSING_NODE_TYPE ? node.properties : expandProperties(type, isRecord(node.properties) ? node.properties : {});
    const { schemaVersion: _sv, ...rest } = node;
    nodes[key] = { ...rest, properties } as GameNode;
    // AIS-41b: `behaviors` do arquivo (contributionId) → instâncias em memória (behaviorType); entrada inválida é guardada intacta
    if (Array.isArray(rest.behaviors)) {
      const converted = behaviorsFromFile(rest.behaviors);
      nodes[key].behaviors = converted.behaviors;
      for (const bad of converted.rejected) {
        rejectedBehaviors.push({ reason: 'invalid_entry', nodeId: key, behavior: bad });
        diagnostics.push({ code: 'scene.behavior_unattached', severity: 'warning', message: `Nó "${key}" tinha uma entrada de Behavior inválida; preservada em metadata.legacyBehaviors.`, nodeId: key });
      }
    }
  }

  // Reparo estrutural: a hierarquia é `parentId` (autoridade) + `childrenIds` (ordem dos irmãos)
  for (const [id, node] of Object.entries(nodes)) {
    if (id === rootId) {
      node.parentId = null;
      continue;
    }
    if (node.parentId === null || node.parentId === undefined || !nodes[node.parentId]) {
      diagnostics.push({ code: 'scene.parent_missing', severity: 'warning', message: `Nó "${id}" apontava para um pai inexistente (${String(node.parentId)}); reanexado à raiz.`, nodeId: id });
      node.parentId = rootId;
    }
  }
  for (const node of Object.values(nodes)) {
    const valid: string[] = [];
    for (const childId of node.childrenIds ?? []) {
      if (!nodes[childId]) diagnostics.push({ code: 'scene.child_missing', severity: 'warning', message: `Nó "${node.id}" listava o filho inexistente "${childId}"; removido da lista.`, nodeId: node.id });
      else if (nodes[childId].parentId === node.id && !valid.includes(childId)) valid.push(childId);
    }
    node.childrenIds = valid;
  }
  for (const node of Object.values(nodes)) {
    if (node.id === rootId || !node.parentId) continue;
    const parent = nodes[node.parentId];
    if (!parent.childrenIds.includes(node.id)) parent.childrenIds.push(node.id);
  }
  // ciclos / nós inalcançáveis a partir da raiz
  const reachable = new Set<string>();
  const walk = (id: string) => {
    if (reachable.has(id)) return;
    reachable.add(id);
    for (const c of nodes[id].childrenIds) walk(c);
  };
  walk(rootId);
  for (const id of Object.keys(nodes)) {
    if (reachable.has(id)) continue;
    const node = nodes[id];
    const oldParent = node.parentId && nodes[node.parentId];
    if (oldParent) oldParent.childrenIds = oldParent.childrenIds.filter((c) => c !== id);
    node.parentId = rootId;
    nodes[rootId].childrenIds.push(id);
    diagnostics.push({ code: 'scene.orphan_reattached', severity: 'warning', message: `Nó "${id}" estava fora da hierarquia (ciclo ou órfão); reanexado à raiz.`, nodeId: id });
    walk(id);
  }

  const settings: AnyRecord = isRecord(raw.sceneSettings) ? raw.sceneSettings : {};
  const pick = (key: string) => settings[key] ?? raw[key];
  let environmentNodeId: string | null = typeof raw.environmentNodeId === 'string' ? raw.environmentNodeId : null;
  if (environmentNodeId && !nodes[environmentNodeId]) {
    diagnostics.push({ code: 'scene.environment_missing', severity: 'warning', message: `environmentNodeId "${environmentNodeId}" não existe; ignorado.` });
    environmentNodeId = null;
  }
  const now = new Date().toISOString();
  const scene: SceneData = {
    schemaVersion: version,
    id: typeof raw.sceneId === 'string' && raw.sceneId ? raw.sceneId : typeof raw.id === 'string' && raw.id ? raw.id : derivedSceneId(path),
    name: typeof raw.name === 'string' && raw.name ? raw.name : (path.split('/').pop() ?? 'Scene').replace(/\.scene\.json$/, ''),
    path,
    rootNodeId: rootId,
    environmentNodeId,
    nodes,
    createdAt: typeof raw.createdAt === 'string' ? raw.createdAt : now,
    updatedAt: typeof raw.updatedAt === 'string' ? raw.updatedAt : now,
  };
  for (const key of ['environment', 'cameraSettings', 'postProcessing', 'fog'] as const) {
    const value = pick(key);
    if (value !== undefined) (scene as AnyRecord)[key] = value;
  }
  // AIS-41b: metadata da cena, com o que a migração (ou esta leitura) não conseguiu anexar a um nó — sempre preservado
  const metadata: AnyRecord = isRecord(raw.metadata) ? clone(raw.metadata) : {};
  if (rejectedBehaviors.length > 0) metadata.legacyBehaviors = [...(Array.isArray(metadata.legacyBehaviors) ? metadata.legacyBehaviors : []), ...rejectedBehaviors];
  if (Object.keys(metadata).length > 0) scene.metadata = metadata;
  for (const entry of Array.isArray(metadata.legacyBehaviors) ? metadata.legacyBehaviors : []) {
    if (!isRecord(entry) || rejectedBehaviors.includes(entry)) continue; // as rejeitadas desta leitura já foram avisadas acima
    const what = entry.reason === 'unresolved_id' ? `o ID de Behavior "${String(entry.id)}" listado no nó "${String(entry.nodeId)}" não tem definição` : entry.reason === 'invalid_entry' ? 'uma entrada de Behavior inválida' : `o Behavior "${String((entry.behavior as AnyRecord | undefined)?.name ?? (entry.behavior as AnyRecord | undefined)?.id ?? '?')}" não achou o nó "${String(entry.nodeId ?? '?')}"`;
    diagnostics.push({ code: 'scene.behavior_unattached', severity: 'warning', message: `Migração de Behaviors: ${what}; preservado em metadata.legacyBehaviors, sem anexar a nenhum nó.`, nodeId: typeof entry.nodeId === 'string' && nodes[entry.nodeId] ? entry.nodeId : undefined });
  }
  const unresolved = options.isKnownContribution ? collectUnresolvedContributions(scene, options.isKnownContribution) : [];
  for (const u of unresolved) {
    diagnostics.push({ code: 'logic.unresolved_contribution', severity: 'warning', message: `${u.kind} "${u.contributionId}" não existe nesta versão do editor; preservado sem alteração (nó "${u.nodeId}", ${u.path}).`, nodeId: u.nodeId });
  }
  return { ok: true, scene, diagnostics, unresolved, migration: { migrated: migration.migrated, fromVersion: migration.fromVersion, toVersion: migration.toVersion, steps: migration.steps } };
}

/** Texto → cena. JSON inválido vira diagnóstico, nunca exceção. */
export function parseSceneJson(text: string, path: string, options: DeserializeOptions = {}): ParseSceneResult {
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch (error) {
    return { ok: false, diagnostics: [{ code: 'scene.json_invalid', severity: 'error', message: `JSON inválido: ${error instanceof Error ? error.message : String(error)}` }], unresolved: [] };
  }
  return deserializeScene(raw, path, options);
}

/** Resumo para o log do editor (uma linha por severidade relevante). */
export function summarizeDiagnostics(diagnostics: readonly SceneDiagnostic[]): string[] {
  const warnings = diagnostics.filter((d) => d.severity !== 'info');
  return warnings.map((d) => `[${d.code}] ${d.message}`);
}
