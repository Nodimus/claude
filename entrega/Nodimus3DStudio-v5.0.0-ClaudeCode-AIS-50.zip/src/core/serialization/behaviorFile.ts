/**
 * AIS-41b — conversão da BehaviorInstance entre memória e arquivo (`*.scene.json` v3).
 *
 * Em memória (`GameNode.behaviors: BehaviorInstance[]`) o tipo se chama `behaviorType`; no arquivo ele é `contributionId`
 * (a convenção persistida do AIS-29: pasta em `src/logic/behaviors/<id>/`). Só esta função conhece as duas formas.
 *
 * Preservação: qualquer campo desconhecido do Behavior, da regra, da Condition ou da Action (versão futura, dado legado,
 * `source`, `addonId`…) vai para `extra` na leitura e volta ao arquivo na escrita; `type`, `eventType`, `contributionId` e os
 * `parameters`/`properties` de IDs que o `LogicRegistry` não conhece passam intactos. Nunca se inventa um ID existente.
 * Funções puras; sem DOM nem registry.
 */
import type { ActionInstance, BehaviorInstance, LogicCondition, LogicEventRule } from '../../types/visualLogic';

type AnyRecord = Record<string, any>;
const isRecord = (v: unknown): v is AnyRecord => typeof v === 'object' && v !== null && !Array.isArray(v);
const clone = <T>(v: T): T => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
const nonEmpty = (v: unknown): v is AnyRecord => isRecord(v) && Object.keys(v).length > 0;

// `label` (rótulo do AIS-29) NÃO é conhecido: fica em `extra` e volta ao arquivo; o `name` em memória só o usa como padrão
const BEHAVIOR_KNOWN = new Set(['id', 'contributionId', 'behaviorType', 'name', 'enabled', 'properties', 'rules', 'schemaVersion']);
const RULE_KNOWN = new Set(['id', 'eventType', 'parameters', 'conditions', 'actions']);
const ITEM_KNOWN = new Set(['id', 'type', 'parameters']);

function splitExtras(raw: AnyRecord, known: Set<string>): Record<string, unknown> | undefined {
  const extra: Record<string, unknown> = {};
  for (const key of Object.keys(raw)) if (!known.has(key)) extra[key] = clone(raw[key]);
  return Object.keys(extra).length > 0 ? extra : undefined;
}

const stringOr = (v: unknown, fallback: string): string => (typeof v === 'string' && v ? v : fallback);

function conditionFromFile(raw: unknown, fallbackId: string): LogicCondition | null {
  if (!isRecord(raw)) return null;
  const extra = splitExtras(raw, ITEM_KNOWN);
  return { id: stringOr(raw.id, fallbackId), type: stringOr(raw.type, ''), parameters: isRecord(raw.parameters) ? clone(raw.parameters) : {}, ...(extra ? { extra } : {}) };
}

function actionFromFile(raw: unknown, fallbackId: string): ActionInstance | null {
  const c = conditionFromFile(raw, fallbackId);
  return c ? { id: c.id, type: c.type, parameters: c.parameters, ...(c.extra ? { extra: c.extra } : {}) } : null;
}

function ruleFromFile(raw: unknown, fallbackId: string): LogicEventRule | null {
  if (!isRecord(raw)) return null;
  const id = stringOr(raw.id, fallbackId);
  const extra = splitExtras(raw, RULE_KNOWN);
  const list = <T>(value: unknown, map: (item: unknown, fallback: string) => T | null, prefix: string): T[] =>
    (Array.isArray(value) ? value : []).map((item, i) => map(item, `${id}_${prefix}${i}`)).filter((x): x is T => x !== null);
  return {
    id,
    eventType: stringOr(raw.eventType, ''),
    parameters: isRecord(raw.parameters) ? clone(raw.parameters) : {},
    conditions: list(raw.conditions, conditionFromFile, 'c'),
    actions: list(raw.actions, actionFromFile, 'a'),
    ...(extra ? { extra } : {}),
  };
}

/** Arquivo → memória. `null` quando a entrada não é um objeto com `id` (o chamador preserva o bruto em outro lugar). */
export function behaviorFromFile(raw: unknown): BehaviorInstance | null {
  if (!isRecord(raw) || typeof raw.id !== 'string' || !raw.id) return null;
  const behaviorType = stringOr(raw.contributionId, stringOr(raw.behaviorType, ''));
  const extra = splitExtras(raw, BEHAVIOR_KNOWN);
  const rules = (Array.isArray(raw.rules) ? raw.rules : []).map((r, i) => ruleFromFile(r, `${raw.id}_r${i}`)).filter((r): r is LogicEventRule => r !== null);
  return {
    id: raw.id,
    name: stringOr(raw.name, stringOr(raw.label, behaviorType || raw.id)),
    behaviorType,
    enabled: raw.enabled !== false,
    properties: isRecord(raw.properties) ? clone(raw.properties) : {},
    rules,
    ...(extra ? { extra } : {}),
  };
}

const itemToFile = (item: { id: string; type: string; parameters: AnyRecord; extra?: AnyRecord }): AnyRecord => ({
  id: item.id,
  type: item.type,
  ...(nonEmpty(item.parameters) ? { parameters: clone(item.parameters) } : {}),
  ...clone(item.extra ?? {}),
});

function ruleToFile(rule: LogicEventRule): AnyRecord {
  return {
    id: rule.id,
    eventType: rule.eventType,
    ...(nonEmpty(rule.parameters) ? { parameters: clone(rule.parameters) } : {}),
    ...(rule.conditions.length > 0 ? { conditions: rule.conditions.map(itemToFile) } : {}),
    ...(rule.actions.length > 0 ? { actions: rule.actions.map(itemToFile) } : {}),
    ...clone(rule.extra ?? {}),
  };
}

/** Memória → arquivo (ordem de campos fixa; vazios omitidos; extras no fim, na ordem em que vieram). */
export function behaviorToFile(b: BehaviorInstance): AnyRecord {
  return {
    id: b.id,
    contributionId: b.behaviorType,
    name: b.name,
    ...(b.enabled === false ? { enabled: false } : {}),
    ...(nonEmpty(b.properties) ? { properties: clone(b.properties) } : {}),
    ...(b.rules.length > 0 ? { rules: b.rules.map(ruleToFile) } : {}),
    ...clone(b.extra ?? {}),
  };
}

export interface BehaviorsFromFileResult {
  behaviors: BehaviorInstance[];
  /** Entradas que não são objetos com `id`: guardadas intactas (nunca descartadas) para o chamador preservar. */
  rejected: unknown[];
}

export function behaviorsFromFile(raw: unknown): BehaviorsFromFileResult {
  const behaviors: BehaviorInstance[] = [];
  const rejected: unknown[] = [];
  for (const entry of Array.isArray(raw) ? raw : []) {
    const converted = behaviorFromFile(entry);
    if (converted) behaviors.push(converted);
    else rejected.push(clone(entry));
  }
  return { behaviors, rejected };
}

export const behaviorsToFile = (behaviors: readonly BehaviorInstance[] | undefined): AnyRecord[] => (behaviors ?? []).map(behaviorToFile);
