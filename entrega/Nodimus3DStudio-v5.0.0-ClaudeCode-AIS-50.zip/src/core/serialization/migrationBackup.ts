import { hashContent } from '../documents/documentKinds';

/**
 * AIS-29b — política de backup antes de sobrescrever um arquivo migrado. Ao ABRIR um arquivo que precisou de migração,
 * o texto original fica "pendente"; no PRIMEIRO salvamento daquele caminho o original é gravado como backup (uma vez
 * por caminho e versão de origem; nunca sobrescreve um backup existente). Persistência atrás de um escritor injetado:
 * hoje `localStorage` via `ProjectStorage` (a mesma infraestrutura do projeto), no Tauri vira arquivo (AIS-AP).
 */

export interface PendingBackup {
  fromVersion: number;
  original: string;
}

const pending = new Map<string, PendingBackup>();

export function notePendingBackup(path: string, fromVersion: number, original: string): void {
  if (!pending.has(path)) pending.set(path, { fromVersion, original });
}

export function takePendingBackup(path: string): PendingBackup | null {
  const entry = pending.get(path) ?? null;
  pending.delete(path);
  return entry;
}

export function hasPendingBackup(path: string): boolean {
  return pending.has(path);
}

export function clearPendingBackups(): void {
  pending.clear();
}

/** Chave estável do backup: projeto + caminho (hash) + versão de origem. */
export function backupStorageKey(projectId: string, path: string, fromVersion: number): string {
  return `nodimus_backup_${projectId}_${(hashContent(path) ?? 'p').replace(/[^a-z0-9]/gi, '')}_v${fromVersion}`;
}

export interface BackupWriter {
  exists(key: string): boolean;
  write(key: string, content: string): void;
}

/** Grava o backup pendente do caminho (se houver e se ainda não existir). Devolve a chave gravada ou `null`. */
export function flushPendingBackup(projectId: string, path: string, writer: BackupWriter): string | null {
  const entry = takePendingBackup(path);
  if (!entry) return null;
  const key = backupStorageKey(projectId, path, entry.fromVersion);
  if (writer.exists(key)) return null;
  writer.write(key, entry.original);
  return key;
}
