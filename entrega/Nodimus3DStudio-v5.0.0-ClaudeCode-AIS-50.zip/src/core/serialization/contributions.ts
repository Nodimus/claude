import type { SceneData } from '../../types/scene';
import type { BehaviorInstance } from '../../types/visualLogic';
import { behaviorToFile } from './behaviorFile';

/**
 * AIS-29b — contribuições (Behavior/Action/Condition/Trigger) cujo `contributionId` o `LogicRegistry` atual não
 * conhece (pasta removida/renomeada, dado legado, versão futura). São PRESERVADAS como dado: o editor sinaliza,
 * mas Salvar nunca apaga o bloco. Esta varredura só LÊ a cena; não altera nada.
 */

export type ContributionKind = 'behavior' | 'action' | 'condition' | 'trigger';

/** Representação serializável de uma contribuição não resolvida (guarda tudo o que veio no arquivo). */
export interface UnresolvedContribution {
  kind: ContributionKind;
  contributionId: string;
  source?: string;
  /** Nó dono do bloco e caminho (ex.: `visualLogic.behaviors.0`) dentro dele. */
  nodeId: string;
  path: string;
  /** Propriedades (Behavior) ou parâmetros (Action) originais. */
  properties?: Record<string, unknown>;
  parameters?: Record<string, unknown>;
  /** Todos os outros campos do bloco (inclusive `addonId` legado). */
  extras: Record<string, unknown>;
  /** Cópia integral do bloco como veio. */
  raw: Record<string, unknown>;
}

/** O `LogicRegistry` informa se um ID existe (`LogicRegistry.isKnownBehavior` etc.). */
export type ContributionResolver = (kind: ContributionKind, contributionId: string) => boolean;

type AnyRecord = Record<string, any>;
const isRecord = (v: unknown): v is AnyRecord => typeof v === 'object' && v !== null && !Array.isArray(v);
const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v));

const KIND_BY_CONTAINER: Record<string, ContributionKind> = {
  behaviors: 'behavior',
  actions: 'action',
  conditions: 'condition',
  triggers: 'trigger',
  events: 'trigger',
};

function inferKind(item: AnyRecord, container: string | undefined): ContributionKind {
  if (container && KIND_BY_CONTAINER[container]) return KIND_BY_CONTAINER[container];
  if (typeof item.kind === 'string' && ['behavior', 'action', 'condition', 'trigger'].includes(item.kind)) return item.kind as ContributionKind;
  return 'parameters' in item && !('properties' in item) ? 'action' : 'behavior';
}

/** Resolve só `contributionId`s declarados em `visualLogic` e `properties` de cada nó. */
export function collectUnresolvedContributions(scene: Pick<SceneData, 'nodes'>, isKnown: ContributionResolver): UnresolvedContribution[] {
  const found: UnresolvedContribution[] = [];

  const walk = (value: unknown, nodeId: string, path: string, container: string | undefined) => {
    if (Array.isArray(value)) {
      value.forEach((item, i) => walk(item, nodeId, `${path}.${i}`, container));
      return;
    }
    if (!isRecord(value)) return;
    if (typeof value.contributionId === 'string' && value.contributionId) {
      const kind = inferKind(value, container);
      if (!isKnown(kind, value.contributionId)) {
        const { contributionId, source, properties, parameters, ...extras } = value;
        found.push({
          kind,
          contributionId,
          source: typeof source === 'string' ? source : undefined,
          nodeId,
          path,
          ...(isRecord(properties) ? { properties: clone(properties) } : {}),
          ...(isRecord(parameters) ? { parameters: clone(parameters) } : {}),
          extras: clone(extras),
          raw: clone(value),
        });
      }
    }
    for (const [key, child] of Object.entries(value)) walk(child, nodeId, `${path}.${key}`, key);
  };

  /** AIS-41b: instâncias inline em `node.behaviors` (memória: `behaviorType`, `eventType`, `type`) — Behavior, Trigger, Condition e Action. */
  const scanInstances = (behaviors: unknown, nodeId: string) => {
    if (!Array.isArray(behaviors)) return;
    const report = (kind: ContributionKind, contributionId: unknown, path: string, item: AnyRecord) => {
      if (typeof contributionId !== 'string' || !contributionId || isKnown(kind, contributionId)) return;
      const { contributionId: _cid, source, properties, parameters, ...extras } = item;
      found.push({
        kind,
        contributionId,
        ...(typeof source === 'string' ? { source } : {}),
        nodeId,
        path,
        ...(isRecord(properties) ? { properties: clone(properties) } : {}),
        ...(isRecord(parameters) ? { parameters: clone(parameters) } : {}),
        extras: clone(extras),
        raw: clone(item),
      });
    };
    behaviors.forEach((b, i) => {
      if (!isRecord(b)) return;
      const base = `behaviors.${i}`;
      report('behavior', b.behaviorType, base, behaviorToFile(b as BehaviorInstance)); // relatado na forma de arquivo (contributionId, source, extras)
      (Array.isArray(b.rules) ? b.rules : []).forEach((rule: unknown, r: number) => {
        if (!isRecord(rule)) return;
        report('trigger', rule.eventType, `${base}.rules.${r}`, rule);
        (Array.isArray(rule.conditions) ? rule.conditions : []).forEach((c: unknown, k: number) => isRecord(c) && report('condition', c.type, `${base}.rules.${r}.conditions.${k}`, c));
        (Array.isArray(rule.actions) ? rule.actions : []).forEach((a: unknown, k: number) => isRecord(a) && report('action', a.type, `${base}.rules.${r}.actions.${k}`, a));
      });
    });
  };

  for (const [nodeId, node] of Object.entries(scene.nodes ?? {})) {
    const n = node as AnyRecord;
    scanInstances(n.behaviors, nodeId);
    if (n.visualLogic !== undefined) walk(n.visualLogic, nodeId, 'visualLogic', undefined);
    if (isRecord(n.properties)) {
      for (const [key, value] of Object.entries(n.properties)) {
        if (key !== '__missing') walk(value, nodeId, `properties.${key}`, key);
      }
    }
  }
  return found;
}
