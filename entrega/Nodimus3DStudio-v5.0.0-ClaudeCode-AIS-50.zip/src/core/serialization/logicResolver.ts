import { LogicRegistry } from '../../logic/registry';
import type { ContributionKind } from './contributions';

/** Resolve um `contributionId` contra o `LogicRegistry` (fonte única do catálogo nativo, decisão 21). */
export function isKnownLogicContribution(kind: ContributionKind, contributionId: string): boolean {
  switch (kind) {
    case 'behavior':
      return LogicRegistry.isKnownBehavior(contributionId);
    case 'action':
      return LogicRegistry.isKnownAction(contributionId);
    case 'condition':
      return LogicRegistry.isKnownCondition(contributionId);
    case 'trigger':
      return LogicRegistry.isKnownTrigger(contributionId);
  }
}
