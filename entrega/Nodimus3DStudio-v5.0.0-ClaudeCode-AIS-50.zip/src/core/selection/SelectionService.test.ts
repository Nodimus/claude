import { describe, expect, it, vi } from 'vitest';
import { SelectionService } from './SelectionService';

describe('SelectionService (AIS-18b)', () => {
  it('replace/clear e primário', () => {
    const s = new SelectionService();
    s.replace('a');
    expect(s.getPrimary()).toBe('a');
    expect(s.getAll()).toEqual(['a']);
    s.clear();
    expect(s.getPrimary()).toBeNull();
    expect(s.getAll()).toEqual([]);
  });

  it('add mantém ordem e primário; sem primário o primeiro vira primário', () => {
    const s = new SelectionService();
    s.add('a');
    s.add('b');
    s.add('b');
    expect(s.getAll()).toEqual(['a', 'b']);
    expect(s.getPrimary()).toBe('a');
    expect(s.getAdditional()).toEqual(['b']);
  });

  it('toggle adiciona/remove; remover o primário promove o próximo', () => {
    const s = new SelectionService();
    s.set('a', ['b', 'c']);
    s.toggle('a');
    expect(s.getPrimary()).toBe('b');
    expect(s.getAll()).toEqual(['b', 'c']);
    s.toggle('c');
    s.toggle('b');
    expect(s.getPrimary()).toBeNull();
  });

  it('set normaliza duplicatas', () => {
    const s = new SelectionService();
    s.set('a', ['a', 'b', 'b']);
    expect(s.getAll()).toEqual(['a', 'b']);
  });

  it('invalida alvos que deixaram de existir e reatribui o primário', () => {
    const s = new SelectionService();
    s.set('a', ['b', 'c']);
    const removed = s.invalidate((id) => id !== 'a' && id !== 'c');
    expect(removed).toEqual(['a', 'c']);
    expect(s.getPrimary()).toBe('b');
    expect(s.getAll()).toEqual(['b']);
    expect(s.invalidate(() => true)).toEqual([]);
  });

  it('notifica só quando muda e permite unsubscribe', () => {
    const s = new SelectionService();
    const fn = vi.fn();
    const off = s.subscribe(fn);
    s.replace('a');
    s.replace('a');
    s.add('b');
    expect(fn).toHaveBeenCalledTimes(2);
    off();
    s.clear();
    expect(fn).toHaveBeenCalledTimes(2);
  });

  it('snapshot é imutável e estável entre leituras sem mudança', () => {
    const s = new SelectionService();
    s.set('a', ['b']);
    const snap = s.getSnapshot();
    expect(s.getSnapshot()).toBe(snap);
    expect(() => (snap.ids as string[]).push('x')).toThrow();
  });
});
