/**
 * SelectionService (AIS-18b) — fonte única da seleção autoral.
 *
 * Seleção por IDs estáveis (nunca objetos Three nem labels). SceneTree, Viewport,
 * Inspector e Visual Logic consomem este serviço; o `EditorStore` (Zustand) é só a
 * projeção reativa para React. A seleção NÃO é persistida na Scene e NÃO entra no
 * CommandManager. Sem dependência de React, DOM ou Three.js.
 *
 * Modelo: lista ordenada de IDs sem duplicatas + item ativo (primário). O primário
 * é sempre um dos IDs selecionados (ou null quando a seleção está vazia).
 */

export interface SelectionSnapshot {
  /** Item ativo/primário (null = nada selecionado). */
  readonly primaryId: string | null;
  /** Todos os selecionados, em ordem de seleção (inclui o primário). */
  readonly ids: readonly string[];
}

type Listener = (snapshot: SelectionSnapshot) => void;

const EMPTY: SelectionSnapshot = Object.freeze({ primaryId: null, ids: Object.freeze([]) as readonly string[] });

export class SelectionService {
  private snapshot: SelectionSnapshot = EMPTY;
  private listeners = new Set<Listener>();

  getSnapshot(): SelectionSnapshot {
    return this.snapshot;
  }

  getPrimary(): string | null {
    return this.snapshot.primaryId;
  }

  getAll(): readonly string[] {
    return this.snapshot.ids;
  }

  /** IDs selecionados exceto o primário (projeção "adicionais" do EditorStore). */
  getAdditional(): readonly string[] {
    const { primaryId, ids } = this.snapshot;
    return ids.filter((id) => id !== primaryId);
  }

  has(id: string): boolean {
    return this.snapshot.ids.includes(id);
  }

  clear(): void {
    this.commit(null, []);
  }

  /** Seleção simples: só `id` (ou limpa quando `id` é null). */
  replace(id: string | null): void {
    this.commit(id, id ? [id] : []);
  }

  /** Define primário + adicionais de uma vez (compatibilidade com a projeção do EditorStore). */
  set(primaryId: string | null, additionalIds: readonly string[] = []): void {
    this.commit(primaryId, primaryId ? [primaryId, ...additionalIds] : [...additionalIds]);
  }

  /** Acrescenta `id`; se não havia primário, ele passa a ser o primário. */
  add(id: string): void {
    if (this.has(id)) return;
    this.commit(this.snapshot.primaryId ?? id, [...this.snapshot.ids, id]);
  }

  /** Alterna `id` na seleção. Remover o primário promove o próximo da ordem. */
  toggle(id: string): void {
    if (this.has(id)) this.remove(id);
    else this.add(id);
  }

  remove(id: string): void {
    if (!this.has(id)) return;
    const ids = this.snapshot.ids.filter((x) => x !== id);
    const primary = this.snapshot.primaryId === id ? (ids[0] ?? null) : this.snapshot.primaryId;
    this.commit(primary, ids);
  }

  /**
   * Invalidação automática: remove os IDs cujo alvo deixou de existir.
   * `exists` é fornecido pelo dono dos dados (ex.: AuthoringModel). Retorna os IDs removidos.
   */
  invalidate(exists: (id: string) => boolean): string[] {
    const removed = this.snapshot.ids.filter((id) => !exists(id));
    if (removed.length === 0) return [];
    const ids = this.snapshot.ids.filter((id) => exists(id));
    const primary = this.snapshot.primaryId && exists(this.snapshot.primaryId) ? this.snapshot.primaryId : (ids[0] ?? null);
    this.commit(primary, ids);
    return removed;
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private commit(primaryId: string | null, rawIds: readonly string[]): void {
    const ids = [...new Set(rawIds)];
    const primary = primaryId && ids.includes(primaryId) ? primaryId : (ids[0] ?? null);
    const prev = this.snapshot;
    const same =
      prev.primaryId === primary && prev.ids.length === ids.length && prev.ids.every((id, i) => id === ids[i]);
    if (same) return;
    this.snapshot = Object.freeze({ primaryId: primary, ids: Object.freeze(ids) as readonly string[] });
    for (const listener of this.listeners) {
      try {
        listener(this.snapshot);
      } catch (error) {
        console.error('SelectionService listener error:', error);
      }
    }
  }
}

/** Instância única do editor. */
export const globalSelectionService = new SelectionService();
