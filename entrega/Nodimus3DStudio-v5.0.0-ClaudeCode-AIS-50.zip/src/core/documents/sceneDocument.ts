/**
 * Ligação do documento "scene" do editor ao DocumentManager (AIS-18b).
 *
 * - Cena ativa = documento `scene`, com dirty-state por checkpoint do `CommandManager`.
 * - Persistência atrás de adapter: grava via handler injetado (hoje `ProjectStorage`/web;
 *   Tauri no AIS-AP). O token de versão é um hash do conteúdo persistido da cena, o que
 *   permite detectar alteração externa (ex.: outra aba) e abrir o conflito.
 * - Play/RuntimeSession/física nunca tocam neste módulo: só Commands e `markDirty` sujam.
 * - Invalida a seleção quando o alvo deixa de existir (SelectionService).
 */
import { globalAuthoringModel } from '../authoring';
import { globalCommandManager } from '../commandManager';
import { ProjectStorage } from '../projectStorage';
import { globalSelectionService } from '../selection/SelectionService';
import { globalDocumentManager, type DocumentAdapter, type DocumentView } from './DocumentManager';

import { PROJECT_SETTINGS_KIND, SCENE_KIND, SCRIPT_KIND, hashContent } from './documentKinds';
import { SAVE_DISCARD_CANCEL, requestDecision } from './decisions';
import { resetScriptDocuments } from './scriptDocuments';
import { wireDiagnosticPublishers } from '../diagnostics/global';
import { wireModelSource } from '../models/global';

export { SCENE_KIND, SCRIPT_KIND, hashContent };

interface SceneHandlers {
  /** Persiste a cena atual (grava o projeto). */
  save: () => void;
  /** Recarrega a cena persistida para o estado autoral. */
  reload: () => void;
  /** Grava uma cópia da cena (resolução de conflito). */
  saveCopy?: () => void;
}

let handlers: SceneHandlers | null = null;
let sceneDocId: string | null = null;
let opening: Promise<void> | null = null;
let bound = false;
let preserveHistoryOnce = false;

/** "Salvar como": a mesma edição continua em outro caminho, então o Undo não deve ser descartado. */
export function preserveHistoryOnNextSceneLoad(): void {
  preserveHistoryOnce = true;
}

export function setSceneDocumentHandlers(next: SceneHandlers): void {
  handlers = next;
}

/** Token da versão da cena persistida (lê o que está em `ProjectStorage`, não a memória). */
function persistedSceneToken(path: string): string | null {
  const projectId = globalAuthoringModel.getProject().id;
  const persisted = ProjectStorage.loadProject(projectId);
  return hashContent(persisted?.files?.[path]?.content);
}

function makeAdapter(path: string): DocumentAdapter {
  return {
    readVersionToken: () => persistedSceneToken(path),
    save: () => {
      handlers?.save();
      return persistedSceneToken(path);
    },
    reload: () => handlers?.reload(),
    saveCopy: handlers?.saveCopy ? () => handlers?.saveCopy?.() : undefined,
  };
}

/** Garante que a cena ativa tenha seu documento aberto (fecha o da cena anterior). */
export function ensureSceneDocument(): Promise<void> {
  const scene = globalAuthoringModel.getScene();
  if (!scene?.path) return Promise.resolve();
  const ref = { id: scene.path, path: scene.path, type: 'scene', label: scene.name };
  const existing = globalDocumentManager.findByRef(SCENE_KIND, ref);
  if (existing) {
    sceneDocId = existing.documentId;
    globalDocumentManager.focus(existing.documentId);
    return Promise.resolve();
  }

  const previous = sceneDocId;
  opening = (async () => {
    // Troca de cena: o documento anterior já passou pela confirmação do usuário (guarda do editor).
    if (previous) await globalDocumentManager.close(previous, 'discard');
    // Histórico autoral é descartado ao trocar de Scene (skill nodimus-undo-redo-commandstack),
    // exceto em "Salvar como", em que a mesma edição segue em outro caminho.
    if (preserveHistoryOnce) preserveHistoryOnce = false;
    else globalCommandManager.clearHistory();
    const doc = await globalDocumentManager.open({
      kind: SCENE_KIND,
      resourceRef: ref,
      title: scene.name,
      adapter: makeAdapter(scene.path),
      history: globalCommandManager,
    });
    // Estado recém-carregado do disco: limpo.
    globalDocumentManager.markClean(doc.documentId);
    sceneDocId = doc.documentId;
  })();
  return opening;
}

export function getSceneDocument(): DocumentView | undefined {
  return sceneDocId ? globalDocumentManager.get(sceneDocId) : undefined;
}

/**
 * Ctrl+S / menu Save: salva via DocumentManager (checkpoint clean; conflito bloqueia o save).
 * Síncrono de propósito: chamadores fazem "salvar e logo trocar de cena".
 */
export function saveSceneDocument(): boolean {
  const doc = getSceneDocument();
  if (!doc) {
    handlers?.save();
    return true;
  }
  return globalDocumentManager.saveNow(doc.documentId).ok;
}

/**
 * Guarda de descarte (troca de cena/projeto): limpo ⇒ segue direto; sujo ⇒ o usuário decide
 * (salvar / descartar / cancelar) por um diálogo do app. `scope: 'all'` considera também
 * os demais documentos sujos (troca de projeto). Nada é descartado em silêncio.
 */
export function guardDiscardChanges(proceed: () => void, scope: 'scene' | 'all' = 'scene'): void {
  const scene = getSceneDocument();
  const dirty = scope === 'all' ? globalDocumentManager.getDirtyDocuments() : scene?.dirty ? [scene] : [];
  if (dirty.length === 0) {
    proceed();
    return;
  }
  const names = dirty.map((d) => `"${d.title}"`).join(', ');
  void requestDecision({
    title: 'Alterações não salvas',
    message:
      dirty.length === 1 ? `${names} tem alterações não salvas.` : `Há alterações não salvas em: ${names}.`,
    options: SAVE_DISCARD_CANCEL,
  }).then(async (choice) => {
    if (choice === 'save') {
      if (scope === 'all') {
        const results = await globalDocumentManager.saveAll();
        if ([...results.values()].some((r) => !r.ok)) return; // conflito/erro: não segue
      } else if (!saveSceneDocument()) {
        return;
      }
      proceed();
    } else if (choice === 'discard') {
      proceed();
    }
    // 'cancel' / fechado: permanece como está
  });
}

/** Liga os serviços ao AuthoringModel (idempotente). Retorna a função de limpeza. */
export function bindEditorServices(): () => void {
  if (bound) return () => {};
  bound = true;

  globalDocumentManager.registerKind(SCENE_KIND);
  globalDocumentManager.registerKind(SCRIPT_KIND);
  globalDocumentManager.registerKind(PROJECT_SETTINGS_KIND); // AIS-32b
  const offDiagnostics = wireDiagnosticPublishers(); // AIS-32c: AssetPipeline e LogicRegistry publicam no serviço único
  const offModels = wireModelSource(); // AIS-33a: `createModelObject` lê o projeto aberto

  const offAuthoring = globalAuthoringModel.subscribe((event) => {
    // Invalidação automática da seleção quando o alvo deixa de existir.
    if (event.type === 'node_deleted' || event.type === 'scene_loaded' || event.type === 'node_added') {
      const nodes = globalAuthoringModel.getScene().nodes;
      globalSelectionService.invalidate((id) => Boolean(nodes[id]));
    }
    if (event.type === 'scene_loaded') void ensureSceneDocument();
    // Troca de projeto: documentos de script do projeto anterior deixam de existir.
    if (event.type === 'project_loaded') void resetScriptDocuments();
  });

  // Alteração externa (web: outra aba gravou no storage) → conflito explícito.
  const onStorage = () => {
    void globalDocumentManager.checkExternalChanges();
  };
  if (typeof window !== 'undefined') window.addEventListener('storage', onStorage);

  // Fechar a janela com documento sujo exige decisão do usuário.
  const onBeforeUnload = (e: BeforeUnloadEvent) => {
    if (globalDocumentManager.getDirtyDocuments().length > 0) {
      e.preventDefault();
      e.returnValue = '';
    }
  };
  if (typeof window !== 'undefined') window.addEventListener('beforeunload', onBeforeUnload);

  void ensureSceneDocument();

  return () => {
    offAuthoring();
    offDiagnostics();
    offModels();
    if (typeof window !== 'undefined') {
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('beforeunload', onBeforeUnload);
    }
    bound = false;
  };
}
