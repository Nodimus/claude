/**
 * DocumentManager (AIS-18b) — ciclo único de documentos abertos do editor.
 *
 * Responsável por: registro de tipos (`kind`), instâncias abertas, documento ativo,
 * dirty-state por checkpoint do histórico, save/saveAll, fechamento sem descarte
 * silencioso e conflito por mudança externa (versionToken). Sem dependência de
 * React, DOM ou Three.js; persistência real passa por `DocumentAdapter`
 * (filesystem atrás do `TauriBridge`, ligado ao Tauri no AIS-AP).
 *
 * Nenhum editor especializado deve manter uma segunda lista global de documentos.
 */
import type { ResourceRef } from '../../types/node';

export type DocumentId = string;
export type DocumentLoadState = 'loading' | 'ready' | 'error' | 'conflict';
export type ConflictResolution = 'reload' | 'keepLocal' | 'saveCopy';
export type CloseDecision = 'save' | 'discard' | 'cancel';

/** Fonte de checkpoints do histórico autoral (ex.: `CommandManager`). */
export interface HistorySource {
  getCheckpointToken(): number;
  subscribe(listener: () => void): () => void;
}

export interface DocumentAdapter {
  /** Token da versão persistida agora (mtime/hash). `null` = ainda não existe em disco. */
  readVersionToken(): Promise<string | null> | string | null;
  /** Persiste o documento; devolve o novo token de versão. */
  save(): Promise<string | null> | string | null;
  /** Recarrega do disco para o estado autoral. */
  reload?(): Promise<void> | void;
  /** Grava uma cópia (resolução de conflito "salvar cópia"). */
  saveCopy?(): Promise<void> | void;
  /** Salva em outro destino (só quando o kind permite). */
  saveAs?(target: ResourceRef): Promise<string | null> | string | null;
}

export interface DocumentKindOptions {
  /** O mesmo ResourceRef pode ter várias views? (padrão: não — abrir de novo foca o existente). */
  multipleViews?: boolean;
  allowSaveAs?: boolean;
}

export interface OpenDocumentInput {
  kind: string;
  resourceRef: ResourceRef;
  title: string;
  adapter: DocumentAdapter;
  readOnly?: boolean;
  /** Se informado, o dirty-state é calculado por checkpoint do histórico. */
  history?: HistorySource;
  /** Token de versão já conhecido; se omitido é lido do adapter ao abrir. */
  versionToken?: string | null;
}

/** Visão pública (imutável por convenção) de um documento aberto. */
export interface DocumentView {
  readonly documentId: DocumentId;
  readonly resourceRef: ResourceRef;
  readonly kind: string;
  readonly title: string;
  readonly dirty: boolean;
  readonly readOnly: boolean;
  readonly loadState: DocumentLoadState;
  readonly versionToken: string | null;
}

export type SaveResult =
  | { ok: true }
  | { ok: false; reason: 'unknown' | 'readOnly' | 'conflict' | 'loading' | 'error'; error?: unknown };

export type CloseResult = { closed: true } | { closed: false; reason: 'unknown' | 'dirty' | 'cancelled' | 'saveFailed' };

interface DocumentRecord {
  documentId: DocumentId;
  resourceRef: ResourceRef;
  kind: string;
  title: string;
  readOnly: boolean;
  loadState: DocumentLoadState;
  versionToken: string | null;
  adapter: DocumentAdapter;
  history?: HistorySource;
  cleanToken: number;
  manualDirty: boolean;
  unsubscribeHistory?: () => void;
}

const refKey = (kind: string, ref: ResourceRef): string => `${kind}::${ref.id || ref.path || ''}`;

let idCounter = 0;
const newDocumentId = () => `doc_${Date.now().toString(36)}_${(++idCounter).toString(36)}`;

export class DocumentManager {
  private kinds = new Map<string, DocumentKindOptions>();
  private docs = new Map<DocumentId, DocumentRecord>();
  private activeId: DocumentId | null = null;
  private listeners = new Set<() => void>();
  private version = 0;
  private cache: { version: number; list: DocumentView[] } = { version: -1, list: [] };

  // ── Registro de tipos ──────────────────────────────────────────────────────
  registerKind(kind: string, options: DocumentKindOptions = {}): void {
    this.kinds.set(kind, options);
  }

  hasKind(kind: string): boolean {
    return this.kinds.has(kind);
  }

  // ── Consulta ───────────────────────────────────────────────────────────────
  get(id: DocumentId): DocumentView | undefined {
    const rec = this.docs.get(id);
    return rec ? this.view(rec) : undefined;
  }

  getActive(): DocumentView | undefined {
    return this.activeId ? this.get(this.activeId) : undefined;
  }

  /** Lista de documentos abertos (referência estável enquanto nada muda). */
  list(): readonly DocumentView[] {
    if (this.cache.version !== this.version) {
      this.cache = { version: this.version, list: [...this.docs.values()].map((r) => this.view(r)) };
    }
    return this.cache.list;
  }

  findByRef(kind: string, ref: ResourceRef): DocumentView | undefined {
    const key = refKey(kind, ref);
    for (const rec of this.docs.values()) if (refKey(rec.kind, rec.resourceRef) === key) return this.view(rec);
    return undefined;
  }

  isDirty(id: DocumentId): boolean {
    const rec = this.docs.get(id);
    return rec ? this.dirtyOf(rec) : false;
  }

  getDirtyDocuments(): DocumentView[] {
    return this.list().filter((d) => d.dirty);
  }

  // ── Abertura / foco ────────────────────────────────────────────────────────
  /** Abre o documento; reabrir o mesmo ResourceRef foca o existente (salvo `multipleViews`). */
  async open(input: OpenDocumentInput): Promise<DocumentView> {
    const options = this.kinds.get(input.kind);
    if (!options) throw new Error(`DocumentManager: tipo de documento não registrado: "${input.kind}"`);

    if (!options.multipleViews) {
      const existing = this.findByRef(input.kind, input.resourceRef);
      if (existing) {
        this.focus(existing.documentId);
        return this.get(existing.documentId) as DocumentView;
      }
    }

    const rec: DocumentRecord = {
      documentId: newDocumentId(),
      resourceRef: input.resourceRef,
      kind: input.kind,
      title: input.title,
      readOnly: input.readOnly ?? false,
      loadState: 'loading',
      versionToken: input.versionToken ?? null,
      adapter: input.adapter,
      history: input.history,
      cleanToken: input.history ? input.history.getCheckpointToken() : 0,
      manualDirty: false,
    };
    this.docs.set(rec.documentId, rec);
    this.activeId = rec.documentId;
    if (rec.history) rec.unsubscribeHistory = rec.history.subscribe(() => this.emit());
    this.emit();

    try {
      if (input.versionToken === undefined) rec.versionToken = (await input.adapter.readVersionToken()) ?? null;
      rec.loadState = 'ready';
    } catch {
      rec.loadState = 'error';
    }
    this.emit();
    return this.view(rec);
  }

  focus(id: DocumentId): boolean {
    if (!this.docs.has(id)) return false;
    if (this.activeId !== id) {
      this.activeId = id;
      this.emit();
    }
    return true;
  }

  // ── Dirty ──────────────────────────────────────────────────────────────────
  /** Marca como sujo (documentos sem histórico de Commands, ex.: editores de texto). */
  markDirty(id: DocumentId): void {
    const rec = this.docs.get(id);
    if (!rec || rec.manualDirty) return;
    rec.manualDirty = true;
    this.emit();
  }

  /** Reancora o checkpoint atual como "limpo" (ex.: depois de recarregar do disco). */
  markClean(id: DocumentId): void {
    const rec = this.docs.get(id);
    if (!rec) return;
    this.cleanCheckpoint(rec);
    this.emit();
  }

  // ── Save ───────────────────────────────────────────────────────────────────
  async save(id: DocumentId): Promise<SaveResult> {
    const rec = this.docs.get(id);
    if (!rec) return { ok: false, reason: 'unknown' };
    if (rec.readOnly) return { ok: false, reason: 'readOnly' };
    if (rec.loadState === 'loading') return { ok: false, reason: 'loading' };
    if (rec.loadState === 'conflict') return { ok: false, reason: 'conflict' };

    try {
      // Nunca sobrescrever arquivo modificado externamente sem confirmação.
      if (await this.detectConflict(rec)) {
        rec.loadState = 'conflict';
        this.emit();
        return { ok: false, reason: 'conflict' };
      }
      const token = await rec.adapter.save();
      rec.versionToken = token ?? (await rec.adapter.readVersionToken()) ?? null;
      this.cleanCheckpoint(rec);
      this.emit();
      return { ok: true };
    } catch (error) {
      return { ok: false, reason: 'error', error };
    }
  }

  /**
   * Save síncrono, para adapters síncronos (ex.: cena em ProjectStorage). Existe para
   * fluxos "salvar e logo trocar de cena", em que esperar uma microtask gravaria a cena
   * errada. Mesmas garantias de `save`: nunca sobrescreve arquivo alterado externamente.
   */
  saveNow(id: DocumentId): SaveResult {
    const rec = this.docs.get(id);
    if (!rec) return { ok: false, reason: 'unknown' };
    if (rec.readOnly) return { ok: false, reason: 'readOnly' };
    if (rec.loadState === 'loading') return { ok: false, reason: 'loading' };
    if (rec.loadState === 'conflict') return { ok: false, reason: 'conflict' };
    try {
      const current = rec.adapter.readVersionToken();
      if (current instanceof Promise) return { ok: false, reason: 'error', error: new Error('adapter assíncrono: use save()') };
      if (rec.versionToken !== null && (current ?? null) !== rec.versionToken) {
        rec.loadState = 'conflict';
        this.emit();
        return { ok: false, reason: 'conflict' };
      }
      const token = rec.adapter.save();
      if (token instanceof Promise) return { ok: false, reason: 'error', error: new Error('adapter assíncrono: use save()') };
      const after = rec.adapter.readVersionToken();
      rec.versionToken = token ?? (after instanceof Promise ? null : after) ?? null;
      this.cleanCheckpoint(rec);
      this.emit();
      return { ok: true };
    } catch (error) {
      return { ok: false, reason: 'error', error };
    }
  }

  async saveAll(): Promise<Map<DocumentId, SaveResult>> {
    const results = new Map<DocumentId, SaveResult>();
    for (const rec of [...this.docs.values()]) {
      if (this.dirtyOf(rec)) results.set(rec.documentId, await this.save(rec.documentId));
    }
    return results;
  }

  /** "Salvar como": só quando o kind permite e o adapter oferece. */
  async saveAs(id: DocumentId, target: ResourceRef): Promise<SaveResult> {
    const rec = this.docs.get(id);
    if (!rec) return { ok: false, reason: 'unknown' };
    if (!this.kinds.get(rec.kind)?.allowSaveAs || !rec.adapter.saveAs) return { ok: false, reason: 'readOnly' };
    try {
      const token = await rec.adapter.saveAs(target);
      rec.resourceRef = target;
      rec.versionToken = token ?? null;
      this.cleanCheckpoint(rec);
      this.emit();
      return { ok: true };
    } catch (error) {
      return { ok: false, reason: 'error', error };
    }
  }

  // ── Fechar ─────────────────────────────────────────────────────────────────
  /** Fechar documento dirty exige decisão explícita; sem `decision` ele permanece aberto. */
  async close(id: DocumentId, decision?: CloseDecision): Promise<CloseResult> {
    const rec = this.docs.get(id);
    if (!rec) return { closed: false, reason: 'unknown' };
    if (this.dirtyOf(rec)) {
      if (!decision) return { closed: false, reason: 'dirty' };
      if (decision === 'cancel') return { closed: false, reason: 'cancelled' };
      if (decision === 'save') {
        const result = await this.save(id);
        if (!result.ok) return { closed: false, reason: 'saveFailed' };
      }
    }
    this.remove(rec);
    return { closed: true };
  }

  /** Fecha todos; os sujos só fecham com `decision` explícita (senão permanecem abertos). */
  async closeAll(decision?: CloseDecision): Promise<CloseResult[]> {
    const results: CloseResult[] = [];
    for (const rec of [...this.docs.values()]) results.push(await this.close(rec.documentId, decision));
    return results;
  }

  // ── Mudança externa / conflito ─────────────────────────────────────────────
  /** Reavalia um documento (ou todos): versão persistida diferente da conhecida ⇒ conflito. */
  async checkExternalChanges(id?: DocumentId): Promise<DocumentView[]> {
    const targets = id ? [this.docs.get(id)].filter((r): r is DocumentRecord => Boolean(r)) : [...this.docs.values()];
    const conflicted: DocumentView[] = [];
    for (const rec of targets) {
      if (rec.loadState === 'loading') continue;
      try {
        if (rec.loadState === 'conflict' || (await this.detectConflict(rec))) {
          rec.loadState = 'conflict';
          conflicted.push(this.view(rec));
        }
      } catch {
        /* leitura falhou: não presume conflito */
      }
    }
    if (conflicted.length) this.emit();
    return conflicted;
  }

  /** Resolve o conflito: recarregar, manter a versão local ou salvar cópia. */
  async resolveConflict(id: DocumentId, resolution: ConflictResolution): Promise<SaveResult> {
    const rec = this.docs.get(id);
    if (!rec) return { ok: false, reason: 'unknown' };
    try {
      if (resolution === 'reload') {
        await rec.adapter.reload?.();
        rec.versionToken = (await rec.adapter.readVersionToken()) ?? null;
        this.cleanCheckpoint(rec);
      } else if (resolution === 'saveCopy') {
        if (!rec.adapter.saveCopy) return { ok: false, reason: 'error' };
        await rec.adapter.saveCopy();
        // continua em conflito: a decisão sobre o original ainda é do usuário
        return { ok: true };
      } else {
        // manter local: aceita a versão externa atual como base; o próximo save sobrescreve de forma consciente
        rec.versionToken = (await rec.adapter.readVersionToken()) ?? null;
      }
      rec.loadState = 'ready';
      this.emit();
      return { ok: true };
    } catch (error) {
      return { ok: false, reason: 'error', error };
    }
  }

  /** Recarrega do disco; documento sujo só com `force` (nunca descarta em silêncio). */
  async reloadFromDisk(id: DocumentId, force = false): Promise<SaveResult> {
    const rec = this.docs.get(id);
    if (!rec) return { ok: false, reason: 'unknown' };
    if (this.dirtyOf(rec) && !force) return { ok: false, reason: 'conflict' };
    return this.resolveConflict(id, 'reload');
  }

  // ── Observação (React via useSyncExternalStore) ────────────────────────────
  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  getVersion(): number {
    return this.version;
  }

  // ── Internos ───────────────────────────────────────────────────────────────
  private async detectConflict(rec: DocumentRecord): Promise<boolean> {
    const current = (await rec.adapter.readVersionToken()) ?? null;
    return rec.versionToken !== null && current !== rec.versionToken;
  }

  private cleanCheckpoint(rec: DocumentRecord): void {
    rec.manualDirty = false;
    if (rec.history) rec.cleanToken = rec.history.getCheckpointToken();
  }

  private dirtyOf(rec: DocumentRecord): boolean {
    return rec.manualDirty || (rec.history ? rec.history.getCheckpointToken() !== rec.cleanToken : false);
  }

  private view(rec: DocumentRecord): DocumentView {
    return {
      documentId: rec.documentId,
      resourceRef: rec.resourceRef,
      kind: rec.kind,
      title: rec.title,
      dirty: this.dirtyOf(rec),
      readOnly: rec.readOnly,
      loadState: rec.loadState,
      versionToken: rec.versionToken,
    };
  }

  private remove(rec: DocumentRecord): void {
    rec.unsubscribeHistory?.();
    this.docs.delete(rec.documentId);
    if (this.activeId === rec.documentId) {
      const rest = [...this.docs.keys()];
      this.activeId = rest.length ? rest[rest.length - 1] : null;
    }
    this.emit();
  }

  private emit(): void {
    this.version++;
    for (const listener of this.listeners) {
      try {
        listener();
      } catch (error) {
        console.error('DocumentManager listener error:', error);
      }
    }
  }
}

/** Instância única do editor. */
export const globalDocumentManager = new DocumentManager();
