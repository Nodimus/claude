/**
 * Decisões explícitas do usuário (AIS-18b).
 *
 * Fecha a pendência de `window.confirm`: pedidos de decisão (salvar / descartar /
 * cancelar) passam por um diálogo do próprio app, observável e testável, em vez de um
 * confirm nativo que bloqueia a página. Sem dependência de React: o diálogo
 * (`DecisionDialog`) assina este store.
 */
export interface DecisionOption {
  id: string;
  label: string;
  description?: string;
  variant?: 'primary' | 'danger' | 'neutral';
}

export interface DecisionRequest {
  title: string;
  message: string;
  options: DecisionOption[];
}

interface PendingDecision extends DecisionRequest {
  key: number;
  resolve: (optionId: string | null) => void;
}

let counter = 0;
let queue: PendingDecision[] = [];
const listeners = new Set<() => void>();

const emit = () => {
  for (const l of listeners) l();
};

/** Pede uma decisão ao usuário; resolve com o `id` da opção, ou `null` se fechado/cancelado. */
export function requestDecision(request: DecisionRequest): Promise<string | null> {
  return new Promise((resolve) => {
    queue = [...queue, { ...request, key: ++counter, resolve }];
    emit();
  });
}

/** Resolve a decisão do topo da fila. */
export function answerDecision(optionId: string | null): void {
  const [current, ...rest] = queue;
  if (!current) return;
  queue = rest;
  emit();
  current.resolve(optionId);
}

export function getPendingDecision(): PendingDecision | undefined {
  return queue[0];
}

export function subscribeDecisions(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export const SAVE_DISCARD_CANCEL: DecisionOption[] = [
  { id: 'save', label: 'Salvar', variant: 'primary' },
  { id: 'discard', label: 'Descartar', variant: 'danger' },
  { id: 'cancel', label: 'Cancelar', variant: 'neutral' },
];
