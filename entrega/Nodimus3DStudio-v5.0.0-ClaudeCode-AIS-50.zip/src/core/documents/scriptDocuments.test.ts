import { beforeEach, describe, expect, it } from 'vitest';
import { globalDocumentManager } from './DocumentManager';
import { SCRIPT_KIND } from './documentKinds';
import { answerDecision, getPendingDecision } from './decisions';
import {
  closeScriptWithDecision,
  ensureScriptDocument,
  getScriptDocument,
  getScriptDraft,
  resetScriptDocuments,
  saveScript,
  setScriptDocumentHandlers,
  setScriptDraft,
} from './scriptDocuments';

/** Disco simulado de arquivos `res://`. */
const disk = new Map<string, string>();
let reloads: string[] = [];
let copies: Record<string, string> = {};

const PATH = 'res://scripts/Player.ts';

beforeEach(async () => {
  await resetScriptDocuments();
  disk.clear();
  disk.set(PATH, 'v1');
  reloads = [];
  copies = {};
  globalDocumentManager.registerKind(SCRIPT_KIND);
  setScriptDocumentHandlers({
    readPersisted: (p) => disk.get(p) ?? null,
    write: (p, c) => void disk.set(p, c),
    reload: (p) => void reloads.push(p),
    saveCopy: (p, c) => void (copies[p] = c),
  });
});

describe('scriptDocuments (AIS-18b)', () => {
  it('reabrir o mesmo arquivo foca o documento existente (dedupe)', async () => {
    const a = await ensureScriptDocument(PATH);
    const b = await ensureScriptDocument(PATH);
    expect(b.documentId).toBe(a.documentId);
    expect(globalDocumentManager.list().filter((d) => d.kind === SCRIPT_KIND)).toHaveLength(1);
  });

  it('editar suja; voltar ao conteúdo salvo limpa; rascunho sobrevive', async () => {
    await ensureScriptDocument(PATH);
    setScriptDraft(PATH, 'v1 editado', 'v1');
    expect(getScriptDocument(PATH)?.dirty).toBe(true);
    expect(getScriptDraft(PATH)).toBe('v1 editado');
    setScriptDraft(PATH, 'v1', 'v1');
    expect(getScriptDocument(PATH)?.dirty).toBe(false);
    expect(getScriptDraft(PATH)).toBeUndefined();
  });

  it('salvar grava no disco, limpa o dirty e o rascunho', async () => {
    await ensureScriptDocument(PATH);
    setScriptDraft(PATH, 'v2', 'v1');
    expect(saveScript(PATH, 'v2')).toBe(true);
    expect(disk.get(PATH)).toBe('v2');
    expect(getScriptDocument(PATH)?.dirty).toBe(false);
    expect(getScriptDraft(PATH)).toBeUndefined();
  });

  it('alteração externa bloqueia o save e mantém o rascunho (nunca sobrescreve em silêncio)', async () => {
    await ensureScriptDocument(PATH);
    setScriptDraft(PATH, 'local', 'v1');
    disk.set(PATH, 'externo'); // outro processo alterou o arquivo
    expect(saveScript(PATH, 'local')).toBe(false);
    expect(disk.get(PATH)).toBe('externo');
    expect(getScriptDocument(PATH)?.loadState).toBe('conflict');
    expect(getScriptDraft(PATH)).toBe('local');

    const id = getScriptDocument(PATH)!.documentId;
    await globalDocumentManager.resolveConflict(id, 'saveCopy');
    expect(copies['res://scripts/Player_copy.ts']).toBe('local');
    await globalDocumentManager.resolveConflict(id, 'reload');
    expect(reloads).toEqual([PATH]);
    expect(getScriptDraft(PATH)).toBeUndefined();
    expect(getScriptDocument(PATH)?.dirty).toBe(false);
  });

  it('fechar a aba suja exige decisão: cancelar mantém; descartar fecha sem salvar; salvar grava', async () => {
    await ensureScriptDocument(PATH);
    setScriptDraft(PATH, 'v2', 'v1');
    const closed: string[] = [];

    let pending = closeScriptWithDecision(PATH, (p) => closed.push(p));
    expect(getPendingDecision()?.title).toBe('Alterações não salvas');
    answerDecision('cancel');
    expect(await pending).toBe(false);
    expect(closed).toEqual([]);
    expect(getScriptDocument(PATH)?.dirty).toBe(true);

    pending = closeScriptWithDecision(PATH, (p) => closed.push(p));
    answerDecision('discard');
    expect(await pending).toBe(true);
    expect(closed).toEqual([PATH]);
    expect(disk.get(PATH)).toBe('v1');

    await ensureScriptDocument(PATH);
    setScriptDraft(PATH, 'v3', 'v1');
    pending = closeScriptWithDecision(PATH, (p) => closed.push(p));
    answerDecision('save');
    expect(await pending).toBe(true);
    expect(disk.get(PATH)).toBe('v3');
  });

  it('fechar a aba limpa não pergunta nada', async () => {
    await ensureScriptDocument(PATH);
    const closed: string[] = [];
    expect(await closeScriptWithDecision(PATH, (p) => closed.push(p))).toBe(true);
    expect(getPendingDecision()).toBeUndefined();
    expect(closed).toEqual([PATH]);
  });

  it('Escape/fechar o diálogo (null) equivale a cancelar', async () => {
    await ensureScriptDocument(PATH);
    setScriptDraft(PATH, 'v2', 'v1');
    const pending = closeScriptWithDecision(PATH, () => {});
    answerDecision(null);
    expect(await pending).toBe(false);
    expect(getScriptDocument(PATH)?.dirty).toBe(true);
  });
});
