import { describe, expect, it, vi } from 'vitest';
import { CommandManager } from '../commandManager';
import { DocumentManager, type DocumentAdapter } from './DocumentManager';

/** Disco simulado: `disk.token` é a versão persistida. */
function makeAdapter(disk: { token: string | null; saves: number; reloads: number; copies: number }): DocumentAdapter {
  return {
    readVersionToken: () => disk.token,
    save: () => {
      disk.saves++;
      disk.token = `v${disk.saves}`;
      return disk.token;
    },
    reload: () => {
      disk.reloads++;
    },
    saveCopy: () => {
      disk.copies++;
    },
  };
}

const ref = (path: string) => ({ id: path, path, type: 'scene' });
const cmd = (label = 'edit') => ({ label, execute: () => {}, undo: () => {} });

const setup = () => {
  const dm = new DocumentManager();
  dm.registerKind('scene');
  dm.registerKind('viewable', { multipleViews: true });
  const history = new CommandManager();
  const disk = { token: 'v0' as string | null, saves: 0, reloads: 0, copies: 0 };
  return { dm, history, disk, adapter: makeAdapter(disk) };
};

describe('DocumentManager (AIS-18b)', () => {
  it('tipo não registrado é recusado', async () => {
    const dm = new DocumentManager();
    await expect(dm.open({ kind: 'x', resourceRef: ref('a'), title: 'a', adapter: makeAdapter({ token: null, saves: 0, reloads: 0, copies: 0 }) })).rejects.toThrow();
  });

  it('abrir o mesmo ResourceRef duas vezes foca o existente (C02)', async () => {
    const { dm, adapter } = setup();
    const a = await dm.open({ kind: 'scene', resourceRef: ref('res://a.scene.json'), title: 'A', adapter });
    const b = await dm.open({ kind: 'scene', resourceRef: ref('res://b.scene.json'), title: 'B', adapter });
    expect(dm.getActive()?.documentId).toBe(b.documentId);
    const again = await dm.open({ kind: 'scene', resourceRef: ref('res://a.scene.json'), title: 'A', adapter });
    expect(again.documentId).toBe(a.documentId);
    expect(dm.list()).toHaveLength(2);
    expect(dm.getActive()?.documentId).toBe(a.documentId);
  });

  it('kind com múltiplas views abre uma instância por vez', async () => {
    const { dm, adapter } = setup();
    const a = await dm.open({ kind: 'viewable', resourceRef: ref('x'), title: 'X', adapter });
    const b = await dm.open({ kind: 'viewable', resourceRef: ref('x'), title: 'X', adapter });
    expect(a.documentId).not.toBe(b.documentId);
  });

  it('dirty por checkpoint: salvar limpa; editar, undo e redo recalculam (C03)', async () => {
    const { dm, history, adapter } = setup();
    const doc = await dm.open({ kind: 'scene', resourceRef: ref('s'), title: 'S', adapter, history });
    const id = doc.documentId;
    expect(dm.isDirty(id)).toBe(false);

    history.pushCommand(cmd());
    expect(dm.isDirty(id)).toBe(true);
    history.undo();
    expect(dm.isDirty(id)).toBe(false);
    history.redo();
    expect(dm.isDirty(id)).toBe(true);

    expect(await dm.save(id)).toEqual({ ok: true });
    expect(dm.isDirty(id)).toBe(false);

    history.undo(); // desfaz algo já salvo ⇒ diverge do checkpoint
    expect(dm.isDirty(id)).toBe(true);
    history.redo();
    expect(dm.isDirty(id)).toBe(false);
  });

  it('clearHistory não "volta" a um checkpoint antigo (nunca fica limpo por engano)', async () => {
    const { dm, history, adapter } = setup();
    const { documentId } = await dm.open({ kind: 'scene', resourceRef: ref('s'), title: 'S', adapter, history });
    history.pushCommand(cmd());
    history.clearHistory();
    expect(dm.isDirty(documentId)).toBe(true);
  });

  it('documento dirty não fecha sem decisão explícita (C04)', async () => {
    const { dm, history, disk, adapter } = setup();
    const { documentId } = await dm.open({ kind: 'scene', resourceRef: ref('s'), title: 'S', adapter, history });
    history.pushCommand(cmd());
    expect(await dm.close(documentId)).toEqual({ closed: false, reason: 'dirty' });
    expect(await dm.close(documentId, 'cancel')).toEqual({ closed: false, reason: 'cancelled' });
    expect(dm.list()).toHaveLength(1);
    expect(await dm.close(documentId, 'save')).toEqual({ closed: true });
    expect(disk.saves).toBe(1);
    expect(dm.list()).toHaveLength(0);
  });

  it('discard fecha sem salvar; closeAll respeita os sujos', async () => {
    const { dm, history, disk, adapter } = setup();
    await dm.open({ kind: 'scene', resourceRef: ref('clean'), title: 'C', adapter });
    const dirty = await dm.open({ kind: 'scene', resourceRef: ref('dirty'), title: 'D', adapter, history });
    history.pushCommand(cmd());
    const results = await dm.closeAll();
    expect(results.filter((r) => r.closed)).toHaveLength(1);
    expect(dm.list().map((d) => d.documentId)).toEqual([dirty.documentId]);
    expect(await dm.close(dirty.documentId, 'discard')).toEqual({ closed: true });
    expect(disk.saves).toBe(0);
  });

  it('alteração externa gera conflito explícito e bloqueia o save (C05)', async () => {
    const { dm, history, disk, adapter } = setup();
    const { documentId } = await dm.open({ kind: 'scene', resourceRef: ref('s'), title: 'S', adapter, history });
    history.pushCommand(cmd());
    disk.token = 'externo'; // outro processo alterou o arquivo
    expect(await dm.save(documentId)).toEqual({ ok: false, reason: 'conflict' });
    expect(disk.saves).toBe(0);
    expect(dm.get(documentId)?.loadState).toBe('conflict');
    // continua bloqueado até o usuário decidir
    expect(await dm.save(documentId)).toEqual({ ok: false, reason: 'conflict' });
  });

  it('checkExternalChanges detecta o conflito sem precisar salvar', async () => {
    const { dm, disk, adapter } = setup();
    await dm.open({ kind: 'scene', resourceRef: ref('s'), title: 'S', adapter });
    expect(await dm.checkExternalChanges()).toHaveLength(0);
    disk.token = 'externo';
    const conflicted = await dm.checkExternalChanges();
    expect(conflicted).toHaveLength(1);
    expect(conflicted[0].loadState).toBe('conflict');
  });

  it('resolução do conflito: reload, manter local e salvar cópia', async () => {
    const { dm, history, disk, adapter } = setup();
    const { documentId } = await dm.open({ kind: 'scene', resourceRef: ref('s'), title: 'S', adapter, history });
    history.pushCommand(cmd());
    disk.token = 'externo';
    await dm.save(documentId);

    await dm.resolveConflict(documentId, 'saveCopy');
    expect(disk.copies).toBe(1);
    expect(dm.get(documentId)?.loadState).toBe('conflict');

    await dm.resolveConflict(documentId, 'keepLocal');
    expect(dm.get(documentId)?.loadState).toBe('ready');
    expect(dm.isDirty(documentId)).toBe(true); // mantém a versão local pendente
    expect(await dm.save(documentId)).toEqual({ ok: true });

    disk.token = 'externo2';
    await dm.checkExternalChanges(documentId);
    await dm.resolveConflict(documentId, 'reload');
    expect(disk.reloads).toBe(1);
    expect(dm.isDirty(documentId)).toBe(false);
    expect(dm.get(documentId)?.versionToken).toBe('externo2');
  });

  it('reloadFromDisk de documento sujo exige force', async () => {
    const { dm, history, disk, adapter } = setup();
    const { documentId } = await dm.open({ kind: 'scene', resourceRef: ref('s'), title: 'S', adapter, history });
    history.pushCommand(cmd());
    expect((await dm.reloadFromDisk(documentId)).ok).toBe(false);
    expect(disk.reloads).toBe(0);
    expect((await dm.reloadFromDisk(documentId, true)).ok).toBe(true);
    expect(disk.reloads).toBe(1);
  });

  it('markDirty manual (sem histórico) e saveAll só salva os sujos', async () => {
    const { dm, disk, adapter } = setup();
    const a = await dm.open({ kind: 'scene', resourceRef: ref('a'), title: 'A', adapter });
    await dm.open({ kind: 'scene', resourceRef: ref('b'), title: 'B', adapter });
    dm.markDirty(a.documentId);
    expect(dm.getDirtyDocuments()).toHaveLength(1);
    const results = await dm.saveAll();
    expect(results.size).toBe(1);
    expect(disk.saves).toBe(1);
    expect(dm.getDirtyDocuments()).toHaveLength(0);
  });

  it('readOnly não salva; Play/runtime não mexe no dirty (C06): só Commands e markDirty alteram', async () => {
    const { dm, adapter } = setup();
    const ro = await dm.open({ kind: 'scene', resourceRef: ref('ro'), title: 'RO', adapter, readOnly: true });
    expect(await dm.save(ro.documentId)).toEqual({ ok: false, reason: 'readOnly' });
    // nada no DocumentManager reage a flags de Play: o dirty depende só de checkpoint/markDirty
    expect(dm.isDirty(ro.documentId)).toBe(false);
  });

  it('saveNow é síncrono, limpa o dirty e também respeita o conflito', async () => {
    const { dm, history, disk, adapter } = setup();
    const { documentId } = await dm.open({ kind: 'scene', resourceRef: ref('s'), title: 'S', adapter, history });
    history.pushCommand(cmd());
    expect(dm.saveNow(documentId)).toEqual({ ok: true });
    expect(disk.saves).toBe(1); // já gravou, sem esperar microtask
    expect(dm.isDirty(documentId)).toBe(false);
    history.pushCommand(cmd());
    disk.token = 'externo';
    expect(dm.saveNow(documentId)).toEqual({ ok: false, reason: 'conflict' });
    expect(disk.saves).toBe(1);
    expect(dm.isDirty(documentId)).toBe(true);
  });

  it('notifica assinantes e a lista é estável sem mudanças', async () => {
    const { dm, history, adapter } = setup();
    const fn = vi.fn();
    dm.subscribe(fn);
    await dm.open({ kind: 'scene', resourceRef: ref('s'), title: 'S', adapter, history });
    const before = fn.mock.calls.length;
    const list = dm.list();
    expect(dm.list()).toBe(list);
    history.pushCommand(cmd());
    expect(fn.mock.calls.length).toBeGreaterThan(before);
    expect(dm.list()).not.toBe(list);
  });
});
