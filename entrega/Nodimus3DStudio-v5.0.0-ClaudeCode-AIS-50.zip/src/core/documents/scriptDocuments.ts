/**
 * Documentos de script/texto do editor (AIS-18b).
 *
 * Cada arquivo de `res://` aberto numa aba de código é um documento `script` do
 * DocumentManager: dirty-state, save, conflito por alteração externa e fechamento
 * sem descarte silencioso. O texto ainda não salvo vive em um rascunho compartilhado
 * (trocar de aba ou abrir o mesmo arquivo no modal não perde a edição).
 *
 * Módulo puro (sem React/DOM/ProjectStorage): a persistência chega por handlers.
 */
import { globalDocumentManager, type DocumentAdapter, type DocumentView } from './DocumentManager';
import { SAVE_DISCARD_CANCEL, requestDecision } from './decisions';
import { SCRIPT_KIND, hashContent } from './documentKinds';

export interface ScriptHandlers {
  /** Conteúdo persistido do arquivo (disco/ProjectStorage), `null` se não existe. */
  readPersisted(path: string): string | null;
  /** Grava o arquivo (persistência). */
  write(path: string, content: string): void;
  /** Recarrega o arquivo persistido para o estado em memória. */
  reload(path: string): void;
  /** Grava uma cópia do rascunho em outro arquivo (resolução de conflito). */
  saveCopy?(path: string, content: string): void;
}

let handlers: ScriptHandlers | null = null;
const drafts = new Map<string, string>();
const docIds = new Map<string, string>();
const pendingOpen = new Map<string, Promise<DocumentView>>();

export function setScriptDocumentHandlers(next: ScriptHandlers): void {
  handlers = next;
}

const refOf = (path: string) => ({ id: path, path, type: 'script', label: path.split('/').pop() ?? path });

function makeAdapter(path: string): DocumentAdapter {
  return {
    readVersionToken: () => hashContent(handlers?.readPersisted(path)),
    save: () => {
      const draft = drafts.get(path);
      if (draft !== undefined) handlers?.write(path, draft);
      drafts.delete(path);
      return hashContent(handlers?.readPersisted(path));
    },
    reload: () => {
      drafts.delete(path);
      handlers?.reload(path);
    },
    saveCopy: handlers?.saveCopy
      ? () => {
          const draft = drafts.get(path);
          const ext = path.includes('.') ? `.${path.split('.').pop()}` : '';
          const base = ext ? path.slice(0, -ext.length) : path;
          if (draft !== undefined) handlers?.saveCopy?.(`${base}_copy${ext}`, draft);
        }
      : undefined,
  };
}

/** Abre (ou foca) o documento do arquivo. Reabrir o mesmo caminho devolve o existente. */
export function ensureScriptDocument(path: string): Promise<DocumentView> {
  const existing = globalDocumentManager.findByRef(SCRIPT_KIND, refOf(path));
  if (existing) {
    docIds.set(path, existing.documentId);
    globalDocumentManager.focus(existing.documentId);
    return Promise.resolve(existing);
  }
  const inflight = pendingOpen.get(path);
  if (inflight) return inflight;
  const opening = globalDocumentManager
    .open({ kind: SCRIPT_KIND, resourceRef: refOf(path), title: refOf(path).label, adapter: makeAdapter(path) })
    .then((doc) => {
      docIds.set(path, doc.documentId);
      return doc;
    })
    .finally(() => pendingOpen.delete(path));
  pendingOpen.set(path, opening);
  return opening;
}

export function getScriptDocument(path: string): DocumentView | undefined {
  return globalDocumentManager.findByRef(SCRIPT_KIND, refOf(path));
}

export function getScriptDraft(path: string): string | undefined {
  return drafts.get(path);
}

/**
 * Registra o texto em edição. Igual ao conteúdo salvo ⇒ sem rascunho e documento limpo
 * (digitar e desfazer tudo não deixa o arquivo "sujo").
 */
export function setScriptDraft(path: string, content: string, savedContent: string): void {
  const doc = getScriptDocument(path);
  if (content === savedContent) {
    drafts.delete(path);
    if (doc) globalDocumentManager.markClean(doc.documentId);
    return;
  }
  drafts.set(path, content);
  if (doc) globalDocumentManager.markDirty(doc.documentId);
}

/** Salvar (Ctrl+S / botão): rascunho vira o conteúdo salvo; conflito externo bloqueia. */
export function saveScript(path: string, content: string): boolean {
  const doc = getScriptDocument(path);
  drafts.set(path, content);
  if (!doc) {
    handlers?.write(path, content);
    drafts.delete(path);
    return true;
  }
  globalDocumentManager.markDirty(doc.documentId);
  const result = globalDocumentManager.saveNow(doc.documentId);
  return result.ok;
}

/**
 * Fecha a aba do arquivo. Documento sujo exige decisão explícita (salvar / descartar /
 * cancelar); `closeTab` só roda quando o fechamento foi autorizado. Retorna se fechou.
 */
export async function closeScriptWithDecision(path: string, closeTab: (path: string) => void): Promise<boolean> {
  const doc = getScriptDocument(path);
  if (!doc) {
    closeTab(path);
    return true;
  }
  let decision: 'save' | 'discard' | 'cancel' | undefined;
  if (doc.dirty) {
    const answer = await requestDecision({
      title: 'Alterações não salvas',
      message: `O arquivo "${doc.title}" tem alterações não salvas.`,
      options: SAVE_DISCARD_CANCEL,
    });
    decision = answer === 'save' || answer === 'discard' ? answer : 'cancel';
    if (decision === 'cancel') return false;
  }
  const result = await globalDocumentManager.close(doc.documentId, decision);
  if (!result.closed) return false;
  drafts.delete(path);
  docIds.delete(path);
  closeTab(path);
  return true;
}

/** Descarta todos os documentos de script e rascunhos (troca de projeto). */
export async function resetScriptDocuments(): Promise<void> {
  for (const doc of globalDocumentManager.list().filter((d) => d.kind === SCRIPT_KIND)) {
    await globalDocumentManager.close(doc.documentId, 'discard');
  }
  drafts.clear();
  docIds.clear();
}
