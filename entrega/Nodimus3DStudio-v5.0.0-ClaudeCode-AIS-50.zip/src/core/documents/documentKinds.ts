/** Tipos de documento do editor e hash de versão (sem dependências pesadas; AIS-18b). */
export const SCENE_KIND = 'scene';
export const SCRIPT_KIND = 'script';
/** AIS-32b: o rascunho do `ProjectSettingsModal` (dirty por valor; sem lista de dirty paralela). */
export const PROJECT_SETTINGS_KIND = 'project-settings';

/** Hash simples (djb2) do conteúdo persistido — suficiente como versionToken. */
export function hashContent(content: string | null | undefined): string | null {
  if (content == null) return null;
  let h = 5381;
  for (let i = 0; i < content.length; i++) h = ((h << 5) + h + content.charCodeAt(i)) | 0;
  return `${content.length}:${(h >>> 0).toString(16)}`;
}
