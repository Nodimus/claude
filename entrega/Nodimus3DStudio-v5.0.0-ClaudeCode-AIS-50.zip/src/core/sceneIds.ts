import { derivedSceneId } from './serialization/sceneSerializer';

/**
 * AIS-29f — identidade estável de uma cena: o `sceneId` gravado no arquivo (formato canônico) ou `id` (formato antigo).
 * Se o arquivo não tem nenhum, deriva do caminho (estável entre aberturas; nunca aleatório).
 * É o `id` da cena no `project.json`: renomear o arquivo não o altera.
 */
export function sceneIdFromContent(content: string | undefined, path: string): string {
  if (typeof content === 'string') {
    try {
      const raw = JSON.parse(content) as { sceneId?: unknown; id?: unknown };
      if (typeof raw.sceneId === 'string' && raw.sceneId) return raw.sceneId;
      if (typeof raw.id === 'string' && raw.id) return raw.id;
    } catch {
      /* arquivo ilegível: cai no id derivado */
    }
  }
  return derivedSceneId(path);
}
