import * as THREE from 'three';
import type { HeightfieldData } from './physics/physicsDescriptor';

/**
 * AIS-50 (decisão 23) — geometria do nó `Terrain` calculada no CPU. Funções PURAS (sem DOM, sem React, sem Zustand): o editor
 * (Viewport3D), o Play (`RuntimeObjectFactory`), o preview do modal e o `PhysicsBridge` leem o MESMO `Float32Array` de alturas.
 * Nunca `displacementMap` (o deslocamento na GPU é ilegível para raycasting, colisão e `sampleHeight`).
 *
 * Convenção do buffer de alturas (a mesma do `HeightfieldData` do AIS-45): `rows = segmentsH + 1`, `cols = segmentsW + 1`,
 * `heights[r * cols + c]` em METROS (0..maxHeight). A coluna `c` anda no eixo X (de −width/2 a +width/2) e a linha `r` no
 * eixo Z (de −depth/2 a +depth/2), no espaço LOCAL do nó (o transform do nó posiciona o terreno no mundo).
 */

export type TerrainPreset = 'flat' | 'hills' | 'mountains' | 'desert' | 'canyon';

export const TERRAIN_PRESETS: readonly { id: TerrainPreset; label: string }[] = [
  { id: 'flat', label: 'Plano' },
  { id: 'hills', label: 'Colinas' },
  { id: 'mountains', label: 'Montanhas' },
  { id: 'desert', label: 'Deserto' },
  { id: 'canyon', label: 'Canyon' },
];

export const TERRAIN_SEGMENT_OPTIONS: readonly number[] = [32, 64, 128, 256];

/** Camadas por altitude relativa (`y / maxHeight`): `[0, 0.35)` chão · `[0.35, 0.7)` meio · `[0.7, 1]` alto. */
export const TERRAIN_LAYER_BOUNDS = { mid: 0.35, high: 0.7 } as const;

/**
 * Textura (nome do dropdown) → cor representativa. Não existe biblioteca de texturas no editor: o splatmap v1 mistura estas
 * cores por altitude nas cores de vértice (decisão do usuário, AIS-50). Texturas reais por `ResourceRef` ficam como evolução.
 */
export const TERRAIN_TEXTURE_COLORS: Readonly<Record<string, { label: string; color: string }>> = {
  Grass_Green: { label: 'Grass (Green Spring)', color: '#4f8a3a' },
  Sand_Desert: { label: 'Desert Sand', color: '#d2b074' },
  Dirt_Soil: { label: 'Dark Soil / Mud', color: '#5b4330' },
  Pebbles_Gravel: { label: 'River Pebbles', color: '#8d8a82' },
  Rock_Cliff: { label: 'Rock Cliff (Slate)', color: '#6b6f78' },
  Granite_Rough: { label: 'Rough Granite', color: '#8a8780' },
  Dry_Dirt: { label: 'Dry Rocky Dirt', color: '#8c6d4a' },
  Snow_Mountain: { label: 'Alpine Snow', color: '#f1f5f9' },
  Bare_Rock: { label: 'Dark Peak Stone', color: '#4b4d54' },
  Ice_Glacier: { label: 'Glacier Ice', color: '#bfe3f2' },
};

export const TERRAIN_GROUND_TEXTURES = ['Grass_Green', 'Sand_Desert', 'Dirt_Soil', 'Pebbles_Gravel'] as const;
export const TERRAIN_MID_TEXTURES = ['Rock_Cliff', 'Granite_Rough', 'Dry_Dirt'] as const;
export const TERRAIN_HIGH_TEXTURES = ['Snow_Mountain', 'Bare_Rock', 'Ice_Glacier'] as const;

// ── Configuração lida das `properties` do nó ────────────────────────────────────────────────────

export interface TerrainConfig {
  width: number;
  depth: number;
  segmentsW: number;
  segmentsH: number;
  maxHeight: number;
  invertHeightmap: boolean;
  smoothHeightmap: boolean;
  preset: TerrainPreset;
  presetSeed: number;
  groundTexture: string;
  midTexture: string;
  highTexture: string;
  textureTiling: number;
  blendSharpness: number;
}

export const TERRAIN_DEFAULTS: Readonly<TerrainConfig> = {
  width: 120,
  depth: 120,
  segmentsW: 128,
  segmentsH: 128,
  maxHeight: 24,
  invertHeightmap: false,
  smoothHeightmap: true,
  preset: 'flat',
  presetSeed: 0,
  groundTexture: 'Grass_Green',
  midTexture: 'Rock_Cliff',
  highTexture: 'Snow_Mountain',
  textureTiling: 16,
  blendSharpness: 0.5,
};

const finite = (v: unknown, fallback: number, min: number, max: number): number =>
  typeof v === 'number' && Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : fallback;

/** Quantidade de segmentos válida mais próxima (32/64/128/256). */
export function snapSegments(value: unknown, fallback = 128): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return fallback;
  return TERRAIN_SEGMENT_OPTIONS.reduce((best, o) => (Math.abs(o - value) < Math.abs(best - value) ? o : best));
}

/** Lê e sanitiza as `properties` de um nó `Terrain` (nunca lança; valor inválido volta ao padrão). */
export function readTerrainConfig(properties: Record<string, any> | undefined): TerrainConfig {
  const p = properties ?? {};
  const preset = TERRAIN_PRESETS.some((x) => x.id === p.terrainPreset) ? (p.terrainPreset as TerrainPreset) : TERRAIN_DEFAULTS.preset;
  const tex = (key: string, fallback: string) => (typeof p[key] === 'string' && p[key] ? (p[key] as string) : fallback);
  return {
    width: finite(p.width, TERRAIN_DEFAULTS.width, 1, 4000),
    depth: finite(p.depth, TERRAIN_DEFAULTS.depth, 1, 4000),
    segmentsW: snapSegments(p.segmentsW),
    segmentsH: snapSegments(p.segmentsH),
    maxHeight: finite(p.maxHeight, TERRAIN_DEFAULTS.maxHeight, 0.01, 1000),
    invertHeightmap: p.invertHeightmap === true,
    smoothHeightmap: p.smoothHeightmap !== false,
    preset,
    presetSeed: Math.trunc(finite(p.presetSeed, 0, -2147483648, 2147483647)),
    groundTexture: tex('groundTexture', TERRAIN_DEFAULTS.groundTexture),
    midTexture: tex('midTexture', TERRAIN_DEFAULTS.midTexture),
    highTexture: tex('highTexture', TERRAIN_DEFAULTS.highTexture),
    textureTiling: finite(p.textureTiling, TERRAIN_DEFAULTS.textureTiling, 1, 256),
    blendSharpness: finite(p.blendSharpness, TERRAIN_DEFAULTS.blendSharpness, 0, 1),
  };
}

// ── Ruído determinístico (por semente) ──────────────────────────────────────────────────────────

/** Hash inteiro 2D → [0, 1). */
function hash2(ix: number, iy: number, seed: number): number {
  let h = (Math.imul(ix, 374761393) + Math.imul(iy, 668265263) + Math.imul(seed | 0, 2147483647)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

const smooth = (t: number) => t * t * (3 - 2 * t);

/** Ruído de valor suave em [0, 1]. */
function valueNoise(x: number, y: number, seed: number): number {
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const fx = smooth(x - x0);
  const fy = smooth(y - y0);
  const a = hash2(x0, y0, seed);
  const b = hash2(x0 + 1, y0, seed);
  const c = hash2(x0, y0 + 1, seed);
  const d = hash2(x0 + 1, y0 + 1, seed);
  return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy;
}

/** Soma de oitavas, normalizada para [0, 1]. */
function fbm(x: number, y: number, seed: number, octaves: number): number {
  let sum = 0;
  let amp = 1;
  let norm = 0;
  let freq = 1;
  for (let o = 0; o < octaves; o++) {
    sum += amp * valueNoise(x * freq, y * freq, seed + o * 101);
    norm += amp;
    amp *= 0.5;
    freq *= 2;
  }
  return sum / norm;
}

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
const smoothstep = (a: number, b: number, v: number) => smooth(clamp01((v - a) / (b - a)));

/** Altura normalizada [0, 1] do preset no ponto (u, v) ∈ [0, 1]². */
function presetHeight(preset: TerrainPreset, u: number, v: number, seed: number): number {
  const nx = u * 2 - 1;
  const nz = v * 2 - 1;
  const dist = Math.min(1, Math.sqrt(nx * nx + nz * nz));
  switch (preset) {
    case 'flat':
      return 0.05 * fbm(u * 24, v * 24, seed, 2);
    case 'hills':
      return 0.4 * fbm(u * 5, v * 5, seed, 3);
    case 'mountains': {
      const peak = Math.pow(1 - dist, 1.4);
      const ridge = 1 - Math.abs(2 * fbm(u * 6, v * 6, seed, 3) - 1);
      return clamp01(0.55 * peak + 0.45 * ridge * (0.35 + 0.65 * (1 - dist)));
    }
    case 'desert': {
      const dunes = 0.5 + 0.5 * Math.sin((u * 7 + fbm(u * 3, v * 3, seed, 2) * 2.5) * Math.PI * 2);
      return clamp01(0.25 * fbm(u * 4, v * 4, seed, 2) + 0.15 * dunes);
    }
    case 'canyon': {
      const rim = smoothstep(0.35, 0.6, dist); // 0 no vale central, 1 no platô (máscara radial invertida)
      return clamp01(0.08 + 0.78 * rim + 0.14 * fbm(u * 8, v * 8, seed, 3) * (0.4 + rim));
    }
  }
}

/** Buffer de alturas (metros, `(segW+1)·(segH+1)`) de um preset procedural; determinístico por `seed`. */
export function generateHeightBuffer(segW: number, segH: number, preset: TerrainPreset, seed: number, maxHeight: number): Float32Array {
  const cols = segW + 1;
  const rows = segH + 1;
  const out = new Float32Array(cols * rows);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      out[r * cols + c] = clamp01(presetHeight(preset, c / segW, r / segH, seed)) * maxHeight;
    }
  }
  return out;
}

// ── Heightmap por imagem ────────────────────────────────────────────────────────────────────────

/** O que `heightmapImageToBuffer` precisa de um `ImageData` (testável em Node). Canal R = altura. */
export interface ImageDataLike {
  width: number;
  height: number;
  data: ArrayLike<number>;
}

/** Imagem grayscale (canal R) → buffer de alturas em metros; amostragem bilinear; `invert` troca preto/branco; `smooth` = média 3×3. */
export function heightmapImageToBuffer(image: ImageDataLike, segW: number, segH: number, maxHeight: number, invert: boolean, smoothing: boolean): Float32Array {
  const cols = segW + 1;
  const rows = segH + 1;
  const { width: iw, height: ih, data } = image;
  const out = new Float32Array(cols * rows);
  if (iw < 1 || ih < 1) return out;
  const at = (x: number, y: number) => (data[(Math.min(ih - 1, Math.max(0, y)) * iw + Math.min(iw - 1, Math.max(0, x))) * 4] ?? 0) / 255;
  for (let r = 0; r < rows; r++) {
    const fy = (r / segH) * (ih - 1);
    const y0 = Math.floor(fy);
    const ty = fy - y0;
    for (let c = 0; c < cols; c++) {
      const fx = (c / segW) * (iw - 1);
      const x0 = Math.floor(fx);
      const tx = fx - x0;
      const top = at(x0, y0) * (1 - tx) + at(x0 + 1, y0) * tx;
      const bottom = at(x0, y0 + 1) * (1 - tx) + at(x0 + 1, y0 + 1) * tx;
      const v = top * (1 - ty) + bottom * ty;
      out[r * cols + c] = (invert ? 1 - v : v) * maxHeight;
    }
  }
  return smoothing ? boxBlur3(out, cols, rows) : out;
}

function boxBlur3(src: Float32Array, cols: number, rows: number): Float32Array {
  const out = new Float32Array(src.length);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      let sum = 0;
      let n = 0;
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          const rr = r + dr;
          const cc = c + dc;
          if (rr < 0 || rr >= rows || cc < 0 || cc >= cols) continue;
          sum += src[rr * cols + cc];
          n++;
        }
      }
      out[r * cols + c] = sum / n;
    }
  }
  return out;
}

// ── Geometria, normais, cores e consulta de altura ─────────────────────────────────────────────

/** Gera a `BufferGeometry` (`PlaneGeometry` deitada + `position.setY` com as alturas). O chamador descarta a anterior. */
export function buildTerrainGeometry(width: number, depth: number, segW: number, segH: number, heights: Float32Array): THREE.BufferGeometry {
  const geo = new THREE.PlaneGeometry(width, depth, segW, segH);
  geo.rotateX(-Math.PI / 2); // linha 0 em z = −depth/2; coluna 0 em x = −width/2 (mesma convenção do buffer)
  const position = geo.getAttribute('position') as THREE.BufferAttribute;
  const count = Math.min(position.count, heights.length);
  for (let i = 0; i < count; i++) position.setY(i, heights[i]);
  position.needsUpdate = true;
  computeTerrainNormals(geo);
  geo.computeBoundingBox();
  geo.computeBoundingSphere();
  return geo;
}

/** Normais suaves (iluminação correta depois de qualquer mudança de altura). */
export function computeTerrainNormals(geo: THREE.BufferGeometry): void {
  geo.computeVertexNormals();
}

/** Altura (metros) na posição (x, z) do espaço LOCAL do terreno, com interpolação bilinear; fora da área, a borda mais próxima. */
export function sampleHeight(heights: Float32Array, segW: number, segH: number, width: number, depth: number, worldX: number, worldZ: number): number {
  const cols = segW + 1;
  const fx = clamp01(worldX / width + 0.5) * segW;
  const fz = clamp01(worldZ / depth + 0.5) * segH;
  const c0 = Math.min(segW - 1, Math.floor(fx));
  const r0 = Math.min(segH - 1, Math.floor(fz));
  const tx = fx - c0;
  const tz = fz - r0;
  const h00 = heights[r0 * cols + c0];
  const h10 = heights[r0 * cols + c0 + 1];
  const h01 = heights[(r0 + 1) * cols + c0];
  const h11 = heights[(r0 + 1) * cols + c0 + 1];
  return (h00 * (1 - tx) + h10 * tx) * (1 - tz) + (h01 * (1 - tx) + h11 * tx) * tz;
}

/** Pesos [chão, meio, alto] (somam 1) na altitude relativa `t` ∈ [0, 1]; `sharpness` 0 = transição larga, 1 = abrupta. */
export function terrainLayerWeights(t: number, sharpness: number): [number, number, number] {
  const half = 0.16 * (1 - clamp01(sharpness)) + 0.005;
  const toMid = smoothstep(TERRAIN_LAYER_BOUNDS.mid - half, TERRAIN_LAYER_BOUNDS.mid + half, t);
  const toHigh = smoothstep(TERRAIN_LAYER_BOUNDS.high - half, TERRAIN_LAYER_BOUNDS.high + half, t);
  return [1 - toMid, toMid * (1 - toHigh), toHigh];
}

const colorOf = (name: string): THREE.Color => new THREE.Color(TERRAIN_TEXTURE_COLORS[name]?.color ?? '#808080');

/** Cores de vértice (RGB, 3 floats por vértice) pela altitude relativa de cada vértice. */
export function terrainVertexColors(heights: Float32Array, cfg: Pick<TerrainConfig, 'maxHeight' | 'groundTexture' | 'midTexture' | 'highTexture' | 'blendSharpness'>): Float32Array {
  const ground = colorOf(cfg.groundTexture);
  const mid = colorOf(cfg.midTexture);
  const high = colorOf(cfg.highTexture);
  const out = new Float32Array(heights.length * 3);
  for (let i = 0; i < heights.length; i++) {
    const [wg, wm, wh] = terrainLayerWeights(cfg.maxHeight > 0 ? heights[i] / cfg.maxHeight : 0, cfg.blendSharpness);
    out[i * 3] = ground.r * wg + mid.r * wm + high.r * wh;
    out[i * 3 + 1] = ground.g * wg + mid.g * wm + high.g * wh;
    out[i * 3 + 2] = ground.b * wg + mid.b * wm + high.b * wh;
  }
  return out;
}

/** Dados do collider Rapier: o MESMO `Float32Array` do terreno (metros), escala X/Z = dimensões, Y = 1 (AIS-45, decisão 23). */
export function terrainHeightfield(heights: Float32Array, cfg: Pick<TerrainConfig, 'segmentsW' | 'segmentsH' | 'width' | 'depth'>): HeightfieldData {
  return { rows: cfg.segmentsH + 1, cols: cfg.segmentsW + 1, heights, scale: { x: cfg.width, y: 1, z: cfg.depth } };
}

// ── Arquivo `res://terrain/<nome>.height` (contrato de CARGA; a escrita é do AIS-50b) ──────────

/**
 * Binário little-endian: cabeçalho de 32 bytes — `magic 'NTH1'` (u32), `version` (u32), `rows` (u32), `cols` (u32),
 * `scaleX`, `scaleY`, `scaleZ` (f32), `format` (u32; 0 = float32 em metros) — seguido de `rows·cols` float32.
 */
export const HEIGHT_FILE_MAGIC = 0x3148544e; // 'N','T','H','1' em little-endian
export const HEIGHT_FILE_VERSION = 1;
export const HEIGHT_FILE_HEADER_BYTES = 32;

export interface TerrainHeightFile {
  version: number;
  rows: number;
  cols: number;
  scale: { x: number; y: number; z: number };
  heights: Float32Array;
}

export type HeightFileParse = { ok: true; file: TerrainHeightFile } | { ok: false; reason: string };

export function encodeHeightFile(file: Pick<TerrainHeightFile, 'rows' | 'cols' | 'scale' | 'heights'>): ArrayBuffer {
  const buffer = new ArrayBuffer(HEIGHT_FILE_HEADER_BYTES + file.heights.length * 4);
  const view = new DataView(buffer);
  view.setUint32(0, HEIGHT_FILE_MAGIC, true);
  view.setUint32(4, HEIGHT_FILE_VERSION, true);
  view.setUint32(8, file.rows, true);
  view.setUint32(12, file.cols, true);
  view.setFloat32(16, file.scale.x, true);
  view.setFloat32(20, file.scale.y, true);
  view.setFloat32(24, file.scale.z, true);
  view.setUint32(28, 0, true);
  for (let i = 0; i < file.heights.length; i++) view.setFloat32(HEIGHT_FILE_HEADER_BYTES + i * 4, file.heights[i], true);
  return buffer;
}

/** Valida e lê o `.height`; arquivo inválido NUNCA lança (devolve o motivo) e nunca é sobrescrito. */
export function parseHeightFile(bytes: ArrayBuffer): HeightFileParse {
  if (bytes.byteLength < HEIGHT_FILE_HEADER_BYTES) return { ok: false, reason: 'arquivo menor que o cabeçalho de 32 bytes' };
  const view = new DataView(bytes);
  if (view.getUint32(0, true) !== HEIGHT_FILE_MAGIC) return { ok: false, reason: 'assinatura inválida (não é um .height do Nodimus)' };
  const version = view.getUint32(4, true);
  if (version > HEIGHT_FILE_VERSION) return { ok: false, reason: `versão ${version} mais nova que a suportada (${HEIGHT_FILE_VERSION})` };
  const rows = view.getUint32(8, true);
  const cols = view.getUint32(12, true);
  if (rows < 2 || cols < 2) return { ok: false, reason: 'dimensões inválidas' };
  if (view.getUint32(28, true) !== 0) return { ok: false, reason: 'formato de amostra desconhecido' };
  if (bytes.byteLength !== HEIGHT_FILE_HEADER_BYTES + rows * cols * 4) return { ok: false, reason: 'tamanho do arquivo não bate com linhas × colunas' };
  const heights = new Float32Array(rows * cols);
  for (let i = 0; i < heights.length; i++) heights[i] = view.getFloat32(HEIGHT_FILE_HEADER_BYTES + i * 4, true);
  return { ok: true, file: { version, rows, cols, scale: { x: view.getFloat32(16, true), y: view.getFloat32(20, true), z: view.getFloat32(24, true) }, heights } };
}
