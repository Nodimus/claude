/**
 * AIS-33/34 — calibração do rascunho de importação (funções PURAS, sem React nem Three). O modal edita um rascunho; o
 * documento só muda no Command final. Calibração é METADADO: escala, rotação, pivô e `modelOffset` ficam em
 * `importSettings` + transform do nó; o arquivo-fonte nunca é alterado (decisão 27).
 *
 * Geometria (igual à do Three, `T · R · S` com Euler XYZ): um ponto `p` do modelo vai a `T + R · S · (p + o)`, onde `o` é o
 * `modelOffset` (espaço do modelo). Pivô e centragem são pedidos no espaço do NÓ (já girado/escalado); `modelOffsetFor`
 * converte para `o = S⁻¹ · Rᵀ · t`. A caixa delimitadora vem de `measureLocalBounds` (única fonte) e é recalculada depois
 * de girar e de escalar por eixo — por isso "Z-Up → Y-Up" e o pivô conversam entre si.
 *
 * Cada botão de 1 clique é `(draft[, bounds]) => draft` IDEMPOTENTE (aplicar duas vezes = aplicar uma).
 */
import type { LocalBounds } from '../physics/bounds';
import { ModelImportSettingsSchema, type ModelImportSettings } from '../../schemas/v1/modelImportSettings.schema';

export type PivotPreset = 'bottom' | 'center' | 'top' | 'custom';

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface ImportTransformDraft {
  /** Escala uniforme. */
  scale: number;
  /** Multiplicadores por eixo sobre `scale`; fora de (1,1,1) a escala é NÃO uniforme (aviso). */
  scaleAxes: Vec3;
  /** Rotação em graus (eixos X, Y, Z). */
  rotationDeg: Vec3;
  /** Translação do nó em metros. */
  position: Vec3;
  pivot: PivotPreset;
  /** Offset Y do pivô quando `pivot === 'custom'` (espaço do nó). */
  pivotOffsetY: number;
  /** Arquivo em Z-up (Blender/3ds Max): compensa com -90° em X. */
  zUpFlipped: boolean;
  /** "Auto Centralizar": centro da caixa em X=0, Z=0. */
  centerXZ: boolean;
}

export const DEFAULT_TRANSFORM_DRAFT: ImportTransformDraft = {
  scale: 1,
  scaleAxes: { x: 1, y: 1, z: 1 },
  rotationDeg: { x: 0, y: 0, z: 0 },
  position: { x: 0, y: 0, z: 0 },
  pivot: 'bottom',
  pivotOffsetY: 0,
  zUpFlipped: false,
  centerXZ: false,
};

export const HUMAN_REFERENCE_HEIGHT_M = 1.8;

const round = (n: number, digits: number) => Number(n.toFixed(digits));
const ZERO: Vec3 = { x: 0, y: 0, z: 0 };

// ── Matemática de rotação (sem Three) ─────────────────────────────────────────────────────────────────────────
type Mat3 = readonly [number, number, number, number, number, number, number, number, number]; // linha a linha

const rad = (deg: number) => (deg * Math.PI) / 180;

/** Matriz da rotação Euler XYZ do Three (`R = Rx · Ry · Rz`), em graus. */
export function rotationMatrixXYZ(rotationDeg: Vec3): Mat3 {
  const [a, b, c] = [rad(rotationDeg.x), rad(rotationDeg.y), rad(rotationDeg.z)];
  const [ca, sa, cb, sb, cc, sc] = [Math.cos(a), Math.sin(a), Math.cos(b), Math.sin(b), Math.cos(c), Math.sin(c)];
  return [
    cb * cc, -cb * sc, sb,
    ca * sc + sa * sb * cc, ca * cc - sa * sb * sc, -sa * cb,
    sa * sc - ca * sb * cc, sa * cc + ca * sb * sc, ca * cb,
  ];
}

const mulVec = (m: Mat3, v: Vec3): Vec3 => ({
  x: m[0] * v.x + m[1] * v.y + m[2] * v.z,
  y: m[3] * v.x + m[4] * v.y + m[5] * v.z,
  z: m[6] * v.x + m[7] * v.y + m[8] * v.z,
});

const transpose = (m: Mat3): Mat3 => [m[0], m[3], m[6], m[1], m[4], m[7], m[2], m[5], m[8]];

/** Rotação efetiva em graus (inclui o -90° em X do Z-up). */
export function effectiveRotationDeg(draft: ImportTransformDraft): Vec3 {
  return { x: draft.rotationDeg.x + (draft.zUpFlipped ? -90 : 0), y: draft.rotationDeg.y, z: draft.rotationDeg.z };
}

const safeAxis = (v: number) => (Number.isFinite(v) && Math.abs(v) > 1e-9 ? v : 1);

/** Escala efetiva por eixo (`scale` × `scaleAxes`). */
export function effectiveScale(draft: ImportTransformDraft): Vec3 {
  return { x: draft.scale * draft.scaleAxes.x, y: draft.scale * draft.scaleAxes.y, z: draft.scale * draft.scaleAxes.z };
}

/**
 * Caixa do modelo no espaço do NÓ, sem a escala uniforme: aplica `scaleAxes` e a rotação efetiva à AABB local do modelo
 * (`measureLocalBounds`) e devolve a AABB resultante. Multiplique por `scale` para metros.
 */
export function calibratedBounds(draft: ImportTransformDraft, bounds: LocalBounds | null): LocalBounds | null {
  if (!bounds) return null;
  const R = rotationMatrixXYZ(effectiveRotationDeg(draft));
  const half = { x: (bounds.size.x * draft.scaleAxes.x) / 2, y: (bounds.size.y * draft.scaleAxes.y) / 2, z: (bounds.size.z * draft.scaleAxes.z) / 2 };
  const center = { x: bounds.center.x * draft.scaleAxes.x, y: bounds.center.y * draft.scaleAxes.y, z: bounds.center.z * draft.scaleAxes.z };
  const min = { x: Infinity, y: Infinity, z: Infinity };
  const max = { x: -Infinity, y: -Infinity, z: -Infinity };
  for (const sx of [-1, 1]) {
    for (const sy of [-1, 1]) {
      for (const sz of [-1, 1]) {
        const p = mulVec(R, { x: center.x + sx * Math.abs(half.x), y: center.y + sy * Math.abs(half.y), z: center.z + sz * Math.abs(half.z) });
        min.x = Math.min(min.x, p.x);
        min.y = Math.min(min.y, p.y);
        min.z = Math.min(min.z, p.z);
        max.x = Math.max(max.x, p.x);
        max.y = Math.max(max.y, p.y);
        max.z = Math.max(max.z, p.z);
      }
    }
  }
  return {
    size: { x: max.x - min.x, y: max.y - min.y, z: max.z - min.z },
    center: { x: (min.x + max.x) / 2, y: (min.y + max.y) / 2, z: (min.z + max.z) / 2 },
  };
}

/** Altura (m) do modelo já calibrado (girado, escalado por eixo e pela escala uniforme). */
export function calibratedHeight(draft: ImportTransformDraft, bounds: LocalBounds | null): number {
  const b = calibratedBounds(draft, bounds);
  return b ? b.size.y * draft.scale : 0;
}

/** Translação (espaço do nó, sem a escala uniforme) que cumpre o pivô e a centragem pedidos. */
function desiredTranslation(draft: ImportTransformDraft, calibrated: LocalBounds | null): Vec3 {
  if (!calibrated) return { x: 0, y: draft.pivot === 'custom' ? draft.pivotOffsetY : 0, z: 0 };
  const { center, size } = calibrated;
  let y = 0;
  switch (draft.pivot) {
    case 'bottom':
      y = -(center.y - size.y / 2);
      break;
    case 'top':
      y = -(center.y + size.y / 2);
      break;
    case 'center':
      y = -center.y;
      break;
    case 'custom':
      y = draft.pivotOffsetY;
      break;
  }
  return { x: draft.centerXZ ? -center.x : 0, y, z: draft.centerXZ ? -center.z : 0 };
}

/**
 * `modelOffset` do nó (espaço do modelo): `o = S⁻¹ · Rᵀ · t`. Com rotação e escala por eixo já considerados, a caixa
 * calibrada fica com a base em Y=0 (pivô `bottom`) e o centro em X/Z=0 (`centerXZ`).
 */
export function modelOffsetFor(draft: ImportTransformDraft, bounds: LocalBounds | null): Vec3 {
  const t = desiredTranslation(draft, calibratedBounds(draft, bounds));
  const local = mulVec(transpose(rotationMatrixXYZ(effectiveRotationDeg(draft))), t);
  return { x: local.x / safeAxis(draft.scaleAxes.x), y: local.y / safeAxis(draft.scaleAxes.y), z: local.z / safeAxis(draft.scaleAxes.z) };
}

/** Compensação em Y do pivô no espaço do nó (sem rotação): compatível com o AIS-33; use `modelOffsetFor` para o nó. */
export function pivotCompensationY(bounds: LocalBounds | null, pivot: PivotPreset, customOffsetY = 0): number {
  if (pivot === 'custom') return customOffsetY;
  if (!bounds) return 0;
  const min = bounds.center.y - bounds.size.y / 2;
  const max = bounds.center.y + bounds.size.y / 2;
  if (pivot === 'bottom') return -min;
  if (pivot === 'top') return -max;
  return -bounds.center.y; // center
}

/** Altura nativa do modelo (metros, antes da escala). */
export const nativeHeight = (bounds: LocalBounds | null): number => bounds?.size.y ?? 0;

/** Escala que leva a altura nativa à altura-alvo (padrão: humano de 1,80 m). 1 se não houver altura. */
export function scaleToHeight(native: number, target = HUMAN_REFERENCE_HEIGHT_M): number {
  if (!Number.isFinite(native) || native <= 0) return 1;
  return round(target / native, 2);
}

// ── Botões de 1 clique (idempotentes) ────────────────────────────────────────────────────────────────────────

/** Auto Centralizar: centro da caixa em X=0, Z=0 (`modelOffset`), sem tocar em Y. */
export const autoCenter = (draft: ImportTransformDraft): ImportTransformDraft => ({ ...draft, centerXZ: true });

/** Snap ao Chão: base da caixa em Y=0. */
export const snapToFloor = (draft: ImportTransformDraft): ImportTransformDraft => ({ ...draft, pivot: 'bottom' });

/** Z-Up → Y-Up: rotação de −90° em X (`upAxis: 'z'`); a caixa é recalculada depois. */
export const zUpToYUp = (draft: ImportTransformDraft): ImportTransformDraft => ({ ...draft, zUpFlipped: true });

export interface HumanScaleResult {
  draft: ImportTransformDraft;
  /** Aviso (não erro) quando a proporção não parece humana; `null` caso contrário. */
  warning: string | null;
}

/** Proporção claramente não humana (muito largo/fundo para a altura) → texto do aviso. */
export function humanProportionWarning(calibrated: LocalBounds | null): string | null {
  if (!calibrated || calibrated.size.y <= 0) return 'Sem altura mensurável: não foi possível calibrar a escala humana.';
  const width = Math.max(calibrated.size.x, calibrated.size.z);
  return width / calibrated.size.y > 0.75 ? 'A proporção não parece humana (largo demais para a altura); a escala de 1.80 m foi aplicada mesmo assim.' : null;
}

/** Escala Humana Ideal: `scale = 1.80 / altura` da caixa JÁ calibrada (girada e escalada por eixo). */
export function humanScale(draft: ImportTransformDraft, bounds: LocalBounds | null): HumanScaleResult {
  const calibrated = calibratedBounds(draft, bounds);
  const warning = humanProportionWarning(calibrated);
  if (!calibrated || calibrated.size.y <= 0) return { draft, warning };
  return { draft: { ...draft, scale: round(HUMAN_REFERENCE_HEIGHT_M / calibrated.size.y, 4) }, warning };
}

export type LengthUnit = 'm' | 'cm' | 'mm' | 'in';
export const UNIT_TO_METERS: Record<LengthUnit, number> = { m: 1, cm: 0.01, mm: 0.001, in: 0.0254 };
export const UNIT_LABEL: Record<LengthUnit, string> = { m: 'Metros (1:1)', cm: 'cm → m (×0.01)', mm: 'mm → m (×0.001)', in: 'polegada → m (×0.0254)' };

/** Conversão de unidade: o modelo foi feito em `unit`; a escala passa a ser o fator para metros (absoluto → idempotente). */
export const convertUnit = (draft: ImportTransformDraft, unit: LengthUnit): ImportTransformDraft => ({ ...draft, scale: UNIT_TO_METERS[unit] });

/** +90° em um eixo, módulo 360. */
export function rotate90(draft: ImportTransformDraft, axis: 'x' | 'y' | 'z'): ImportTransformDraft {
  return { ...draft, rotationDeg: { ...draft.rotationDeg, [axis]: (draft.rotationDeg[axis] + 90) % 360 } };
}

/** "Centralizar origem" do preview: posição (0,0,0), centro em X/Z e base no chão. */
export function centerToOrigin(draft: ImportTransformDraft): ImportTransformDraft {
  return snapToFloor(autoCenter({ ...draft, position: { ...ZERO } }));
}

/** Resetar: volta ao rascunho inicial. */
export const resetDraft = (): ImportTransformDraft => ({ ...DEFAULT_TRANSFORM_DRAFT, scaleAxes: { ...DEFAULT_TRANSFORM_DRAFT.scaleAxes }, rotationDeg: { ...ZERO }, position: { ...ZERO } });

const sameVec = (a: Vec3, b: Vec3) => a.x === b.x && a.y === b.y && a.z === b.z;

/** Há alteração em relação ao padrão? (fechar o modal com rascunho alterado pergunta antes). */
export function isTransformDirty(draft: ImportTransformDraft): boolean {
  const d = DEFAULT_TRANSFORM_DRAFT;
  return (
    draft.scale !== d.scale ||
    !sameVec(draft.scaleAxes, d.scaleAxes) ||
    !sameVec(draft.rotationDeg, d.rotationDeg) ||
    !sameVec(draft.position, d.position) ||
    draft.pivot !== d.pivot ||
    draft.pivotOffsetY !== d.pivotOffsetY ||
    draft.zUpFlipped !== d.zUpFlipped ||
    draft.centerXZ !== d.centerXZ
  );
}

/** Escala não uniforme (permitida): gera o aviso `physics.nonuniform_scale` do AIS-32c. */
export const isNonUniformScale = (draft: ImportTransformDraft): boolean => !(draft.scaleAxes.x === draft.scaleAxes.y && draft.scaleAxes.y === draft.scaleAxes.z);

export interface CalibrationWarning {
  code: 'physics.nonuniform_scale';
  message: string;
}

export function calibrationWarnings(draft: ImportTransformDraft): CalibrationWarning[] {
  return isNonUniformScale(draft)
    ? [{ code: 'physics.nonuniform_scale', message: 'Escala não uniforme: colisores e física se comportam melhor com escala uniforme (o colisor automático avisa e usa a maior escala).' }]
    : [];
}

export interface NodeTransform {
  position: Vec3;
  rotation: Vec3;
  scale: Vec3;
  /** Compensação de pivô/centragem aplicada ao modelo DENTRO do nó (espaço do modelo). */
  modelOffset: Vec3;
}

/** Transform do nó criado: o que o preview mostra é exatamente o que o nó recebe. */
export function nodeTransformFor(draft: ImportTransformDraft, bounds: LocalBounds | null): NodeTransform {
  return {
    position: { ...draft.position },
    rotation: effectiveRotationDeg(draft),
    scale: effectiveScale(draft),
    modelOffset: modelOffsetFor(draft, bounds),
  };
}

/** `ModelImportSettings` (AIS-33a) a partir do rascunho; a validação final é do schema. Reedição (AIS-38c) lê estes mesmos valores. */
export function toModelImportSettings(draft: ImportTransformDraft, bounds: LocalBounds | null, extra: Partial<ModelImportSettings> = {}): ModelImportSettings {
  return ModelImportSettingsSchema.parse({
    schemaVersion: 1,
    upAxis: draft.zUpFlipped ? 'z' : 'y',
    rotationDeg: { ...draft.rotationDeg },
    scale: draft.scale > 0 ? draft.scale : 1,
    scaleAxes: { x: safeAxis(draft.scaleAxes.x), y: safeAxis(draft.scaleAxes.y), z: safeAxis(draft.scaleAxes.z) },
    pivot: draft.pivot,
    pivotOffset: modelOffsetFor(draft, bounds),
    centerXZ: draft.centerXZ,
    ...extra,
  });
}
