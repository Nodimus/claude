/**
 * AIS-38 — scanner automático do importador (funções PURAS, sem React nem Three). Avalia o modelo REAL carregado (caixa,
 * estatísticas, materiais, rig, clipes) contra o rascunho e devolve achados com correção opcional.
 *
 * O rascunho que as correções editam é o `ImportDraft` (calibração + colisão + materiais): nada disso é o documento, por
 * isso as correções não passam pelo `CommandManager`; entram no Command final do AIS-33 como qualquer outro ajuste.
 * Cada `fix` é `(draft) => draft` IDEMPOTENTE e REUTILIZA as funções do AIS-34 (`calibration.ts`); nenhuma duplica cálculo.
 * Detectores de material, rig e clipes são os do AIS-35/36/37 (`diagnoseMaterials`, `rigDiagnostics`, `libraryDiagnostics`).
 */
import type { LocalBounds } from '../physics/bounds';
import type { ColorData } from '../../types/node';
import type { ModelMaterialInfo } from '../models/types';
import { rigDiagnostics, type BoneMap } from '../../runtime/skeletalAnimation';
import { libraryDiagnostics, type LibraryClip } from './animationLibrary';
import {
  autoCenter,
  calibratedBounds,
  convertUnit,
  humanScale,
  snapToFloor,
  zUpToYUp,
  UNIT_TO_METERS,
  type ImportTransformDraft,
  type LengthUnit,
} from './calibration';
import { diagnoseMaterials, type MaterialEdit } from './materials';
import type { CollisionOptions } from './importPlan';

/** Limiares do scanner (constantes únicas; ajuste aqui, não nos detectores). */
export const SCAN_LIMITS = {
  /** Menor/maior dimensão aceitável de um objeto, em metros. */
  minSizeM: 0.1,
  maxSizeM: 50,
  /** Tolerância da base em relação a Y=0, como fração da altura. */
  pivotBaseTolerance: 0.02,
  /** Fração da maior extensão XZ tolerada entre a origem e a pegada do modelo. */
  pivotFootprintTolerance: 0.02,
  /** Extensão Z / extensão Y a partir da qual o objeto parece "deitado". */
  lyingAspect: 1.5,
  /** Triângulos acima dos quais "Malha exata" estoura o orçamento do colisor. */
  meshColliderTriangleBudget: 20000,
  /** Extensão abaixo da qual a caixa é degenerada. */
  degenerateExtent: 1e-4,
} as const;

/** PBR neutro aplicado a material cuja textura não chegou. */
export const NEUTRAL_PBR = { color: { r: 0.8, g: 0.8, b: 0.8, a: 1 } as ColorData, roughness: 0.7, metalness: 0 } as const;

/** Tudo o que o modal edita antes do Importar. */
export interface ImportDraft {
  transform: ImportTransformDraft;
  collision: CollisionOptions;
  materials: MaterialEdit[];
}

export type QuizGroup = 'scale' | 'pivot' | 'orientation' | 'material' | 'collision' | 'rig';

export const QUIZ_GROUPS: readonly { id: QuizGroup; label: string }[] = [
  { id: 'scale', label: 'Escala' },
  { id: 'pivot', label: 'Pivô' },
  { id: 'orientation', label: 'Orientação de eixo' },
  { id: 'material', label: 'Texturas e materiais' },
  { id: 'collision', label: 'Colisão' },
  { id: 'rig', label: 'Rig e animações' },
];

export interface ImportFix {
  label: string;
  /** Idempotente: aplicar duas vezes = aplicar uma. */
  apply: (draft: ImportDraft) => ImportDraft;
}

export interface ImportFinding {
  code: string;
  group: QuizGroup;
  severity: 'info' | 'warning';
  message: string;
  /** Alvo do achado (material ou clipe): separa achados de mesmo código no DiagnosticService. */
  target?: string;
  /** Ausente = só informa (decisão 14: nada de botão fictício). */
  fix?: ImportFix;
}

export interface ImportScanInput {
  bounds: LocalBounds | null;
  stats: { triangles: number };
  materials: readonly ModelMaterialInfo[];
  upAxisHint: 'y' | 'z';
  draft: ImportDraft;
  boneNames: readonly string[];
  rigMap: BoneMap;
  library: readonly LibraryClip[];
}

const onTransform = (fn: (t: ImportTransformDraft) => ImportTransformDraft) => (d: ImportDraft): ImportDraft => ({ ...d, transform: fn(d.transform) });

const fmt = (n: number): string => (n >= 100 ? n.toFixed(0) : n >= 1 ? n.toFixed(2) : n.toFixed(3));

// ── 1. Escala ────────────────────────────────────────────────────────────────────────────────────────────

/** Maior dimensão (m) do modelo JÁ calibrado (girado, escalado por eixo e pela escala uniforme). */
export function largestDimensionM(t: ImportTransformDraft, bounds: LocalBounds | null): number {
  const b = calibratedBounds(t, bounds);
  return b ? Math.max(b.size.x, b.size.y, b.size.z) * t.scale : 0;
}

/** Unidade (cm, depois mm) que leva a maior dimensão nativa para dentro do intervalo aceitável; `null` se nenhuma serve. */
export function suggestUnit(nativeLargest: number): LengthUnit | null {
  for (const unit of ['cm', 'mm'] as const) {
    const m = nativeLargest * UNIT_TO_METERS[unit];
    if (m >= SCAN_LIMITS.minSizeM && m <= SCAN_LIMITS.maxSizeM) return unit;
  }
  return null;
}

function detectScale(i: ImportScanInput): ImportFinding[] {
  const t = i.draft.transform;
  const largest = largestDimensionM(t, i.bounds);
  if (!(largest > 0) || (largest >= SCAN_LIMITS.minSizeM && largest <= SCAN_LIMITS.maxSizeM)) return [];
  const tooBig = largest > SCAN_LIMITS.maxSizeM;
  const native = largest / (t.scale > 0 ? t.scale : 1);
  const unit = tooBig ? suggestUnit(native) : null;
  const message = `A maior dimensão do modelo é ${fmt(largest)} m (aceitável: ${SCAN_LIMITS.minSizeM} m a ${SCAN_LIMITS.maxSizeM} m).`;
  const bounds = i.bounds;
  const fix: ImportFix = unit
    ? { label: `Converter de ${unit} para metros`, apply: onTransform((d) => convertUnit(d, unit)) }
    : { label: 'Escala humana (1,80 m)', apply: onTransform((d) => humanScale(d, bounds).draft) };
  return [{ code: 'import.scale_out_of_range', group: 'scale', severity: 'warning', message, fix }];
}

// ── 2. Pivô ──────────────────────────────────────────────────────────────────────────────────────────────

/** Altura (relativa à da caixa) da base depois do pivô pedido; 0 = base em Y=0. */
function placedBaseY(t: ImportTransformDraft, cal: LocalBounds): number {
  switch (t.pivot) {
    case 'bottom':
      return 0;
    case 'top':
      return -cal.size.y;
    case 'center':
      return -cal.size.y / 2;
    case 'custom':
      return cal.center.y - cal.size.y / 2 + t.pivotOffsetY;
  }
}

function detectPivot(i: ImportScanInput): ImportFinding[] {
  const t = i.draft.transform;
  const cal = calibratedBounds(t, i.bounds);
  if (!cal || cal.size.y <= 0) return [];
  const baseOff = Math.abs(placedBaseY(t, cal)) > cal.size.y * SCAN_LIMITS.pivotBaseTolerance;
  const footprint = Math.max(cal.size.x, cal.size.z);
  const tol = footprint * SCAN_LIMITS.pivotFootprintTolerance;
  const xzOff = !t.centerXZ && (Math.abs(cal.center.x) > cal.size.x / 2 + tol || Math.abs(cal.center.z) > cal.size.z / 2 + tol);
  if (!baseOff && !xzOff) return [];
  const parts = [baseOff && 'a base não está no chão (Y=0)', xzOff && 'a origem do modelo está longe da geometria (X/Z)'].filter(Boolean).join(' e ');
  return [
    {
      code: 'import.pivot_off_base',
      group: 'pivot',
      severity: 'warning',
      message: `Pivô fora do esperado: ${parts}.`,
      fix: {
        label: [baseOff && 'Snap ao Chão', xzOff && 'Auto Centralizar'].filter(Boolean).join(' + '),
        apply: onTransform((d) => (xzOff ? autoCenter(baseOff ? snapToFloor(d) : d) : snapToFloor(d))),
      },
    },
  ];
}

// ── 3. Orientação ────────────────────────────────────────────────────────────────────────────────────────

function detectOrientation(i: ImportScanInput): ImportFinding[] {
  const t = i.draft.transform;
  if (t.zUpFlipped || t.rotationDeg.x % 360 !== 0) return []; // já corrigido (botão ou rotação manual)
  const cal = calibratedBounds(t, i.bounds);
  const lying = !!cal && cal.size.z > cal.size.y * SCAN_LIMITS.lyingAspect && cal.size.z >= cal.size.x;
  if (i.upAxisHint !== 'z' && !lying) return [];
  return [
    {
      code: 'import.orientation_zup',
      group: 'orientation',
      severity: 'warning',
      message: i.upAxisHint === 'z' ? 'O arquivo parece usar Z como "para cima" (Blender/3ds Max): o modelo aparece deitado.' : 'A maior extensão está no eixo Z e o modelo parece deitado (Z-Up).',
      fix: { label: 'Z-Up → Y-Up', apply: onTransform(zUpToYUp) },
    },
  ];
}

// ── 4. Texturas e materiais ──────────────────────────────────────────────────────────────────────────────

const near = (a: number, b: number) => Math.abs(a - b) < 1e-4;
const isNeutralPbr = (e: MaterialEdit) =>
  near(e.color.r, NEUTRAL_PBR.color.r) && near(e.color.g, NEUTRAL_PBR.color.g) && near(e.color.b, NEUTRAL_PBR.color.b) && near(e.roughness, NEUTRAL_PBR.roughness) && near(e.metalness, NEUTRAL_PBR.metalness) && e.pattern === 'none';

const patchMaterialsNamed = (name: string, patch: Partial<MaterialEdit>) => (d: ImportDraft): ImportDraft => ({
  ...d,
  materials: d.materials.map((e) => (e.name === name ? { ...e, ...patch } : e)),
});

function detectMaterials(i: ImportScanInput): ImportFinding[] {
  const out: ImportFinding[] = [];
  for (const item of diagnoseMaterials(i.materials)) {
    const edit = i.draft.materials.find((e) => e.name === item.material);
    const base = { code: item.code, group: 'material' as const, severity: item.severity, message: item.message, target: item.material };
    if (item.code === 'texture.missing') {
      if (edit && isNeutralPbr(edit)) continue; // já corrigido no rascunho
      out.push({
        ...base,
        fix: { label: 'PBR neutro', apply: patchMaterialsNamed(item.material, { color: { ...NEUTRAL_PBR.color }, roughness: NEUTRAL_PBR.roughness, metalness: NEUTRAL_PBR.metalness, pattern: 'none' }) },
      });
    } else if (item.code === 'material.transparent_opaque') {
      if (edit?.transparent === false) continue;
      out.push({ ...base, fix: { label: 'Desligar transparência', apply: patchMaterialsNamed(item.material, { transparent: false }) } });
    } else {
      out.push(base); // nome repetido / sem nome: só informa
    }
  }
  return out;
}

// ── 5. Colisão ───────────────────────────────────────────────────────────────────────────────────────────

function detectCollision(i: ImportScanInput): ImportFinding[] {
  const c = i.draft.collision;
  if (!c.enabled) return [];
  const out: ImportFinding[] = [];
  const b = i.bounds;
  if (!b || Math.min(b.size.x, b.size.y, b.size.z) < SCAN_LIMITS.degenerateExtent) {
    out.push({ code: 'physics.degenerate_bounds', group: 'collision', severity: 'warning', message: 'A caixa do modelo tem extensão zero em algum eixo: o colisor automático pode ficar degenerado.' });
  }
  if (c.shape === 'mesh' && i.stats.triangles > SCAN_LIMITS.meshColliderTriangleBudget) {
    out.push({
      code: 'physics.mesh_triangle_budget',
      group: 'collision',
      severity: 'warning',
      message: `"Malha exata" com ${i.stats.triangles.toLocaleString('pt-BR')} triângulos estoura o orçamento do colisor (${SCAN_LIMITS.meshColliderTriangleBudget.toLocaleString('pt-BR')}).`,
      fix: { label: 'Forma automática', apply: (d) => ({ ...d, collision: { ...d.collision, shape: 'auto' } }) },
    });
  }
  return out;
}

// ── 6. Rig e animações ───────────────────────────────────────────────────────────────────────────────────

function detectRig(i: ImportScanInput): ImportFinding[] {
  const out: ImportFinding[] = [];
  if (i.boneNames.length > 0) {
    const hasClips = i.library.length > 0;
    for (const d of rigDiagnostics(i.boneNames, i.rigMap)) {
      const withClips = d.code === 'rig.not_humanoid' && hasClips;
      out.push({
        code: d.code,
        group: 'rig',
        severity: withClips ? 'warning' : d.severity,
        message: withClips ? `${d.message} Os ${i.library.length} clipe(s) do arquivo não serão retargetados.` : d.message,
      });
    }
  }
  for (const d of libraryDiagnostics(i.library)) out.push({ code: d.code, group: 'rig', severity: d.severity, message: d.message, target: d.clip });
  return out;
}

// ── API ──────────────────────────────────────────────────────────────────────────────────────────────────

/** Roda os 6 detectores sobre os dados reais do modelo. Ordem: por grupo. */
export function scanImport(input: ImportScanInput): ImportFinding[] {
  return [...detectScale(input), ...detectPivot(input), ...detectOrientation(input), ...detectMaterials(input), ...detectCollision(input), ...detectRig(input)];
}

/** Aplicar a orientação antes da escala e do pivô (a caixa que eles medem depende da rotação). */
const FIX_ORDER = ['import.orientation_zup', 'import.scale_out_of_range', 'import.pivot_off_base'];
const fixRank = (code: string) => {
  const i = FIX_ORDER.indexOf(code);
  return i < 0 ? FIX_ORDER.length : i;
};

/** "Corrigir todos": aplica as correções de todos os achados que têm uma, em ordem segura. */
export function applyAllFixes(findings: readonly ImportFinding[], draft: ImportDraft): ImportDraft {
  return findings
    .filter((f): f is ImportFinding & { fix: ImportFix } => !!f.fix)
    .sort((a, b) => fixRank(a.code) - fixRank(b.code))
    .reduce((d, f) => f.fix.apply(d), draft);
}

export const fixableCount = (findings: readonly ImportFinding[]): number => findings.filter((f) => f.fix).length;

/** Pergunta manual (§3.2): só para o que a máquina não decide. */
export interface ImportQuestion {
  id: 'human_scale';
  text: string;
  yesLabel: string;
  apply: (draft: ImportDraft) => ImportDraft;
}

/** "Este modelo representa uma pessoa de 1,80 m?" — só quando a escala está fora do intervalo. */
export function importQuestions(findings: readonly ImportFinding[], bounds: LocalBounds | null): ImportQuestion[] {
  if (!findings.some((f) => f.code === 'import.scale_out_of_range')) return [];
  return [{ id: 'human_scale', text: 'Este modelo representa uma pessoa de 1,80 m?', yesLabel: 'Sim, usar escala humana', apply: onTransform((d) => humanScale(d, bounds).draft) }];
}
