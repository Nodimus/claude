/**
 * AIS-35 — imagens dos materiais (DOM/Canvas): texturas embutidas do arquivo 3D e padrões procedurais viram PNG (data URL)
 * para o import gravar em `res://textures/<asset>/`, e o plano de pré-visualização da aba (mesmos pixels, tamanho menor).
 * O gerador de padrões é o único de `utils/textureGenerator.ts`; a lógica de filtros e slots é pura (`materials.ts`).
 */
import * as THREE from 'three';
import { DEFAULT_MATERIAL_PROPERTIES } from '../../types/material';
import { generateProceduralTexture } from '../../utils/textureGenerator';
import type { LoadedModel } from '../models/types';
import type { MaterialPlan } from '../models/modelMaterials';
import type { MaterialImageInput } from './importModelAsset';
import { albedoSourceOf, applyFiltersToPixels, isEditDirty, isNeutralFilters, materialSlotFromEdit, type MaterialEdit } from './materials';

const PREVIEW_SIZE = 512;
const MAP_KEYS = [
  ['albedo', 'map'],
  ['normal', 'normalMap'],
  ['roughness', 'roughnessMap'],
  ['metalness', 'metalnessMap'],
  ['emissive', 'emissiveMap'],
] as const;

type Drawable = CanvasImageSource & { width?: number; height?: number; naturalWidth?: number; naturalHeight?: number };

function sizeOf(image: Drawable): { w: number; h: number } {
  return { w: image.naturalWidth || (image.width as number) || 0, h: image.naturalHeight || (image.height as number) || 0 };
}

/** Desenha a imagem de uma textura num canvas (opcionalmente limitando o lado maior e aplicando filtros). Nulo se não for desenhável. */
function canvasOf(texture: THREE.Texture, maxSide: number, filters?: MaterialEdit['filters']): HTMLCanvasElement | null {
  const image = texture.image as Drawable | null | undefined;
  if (!image) return null;
  const { w, h } = sizeOf(image);
  if (!w || !h) return null;
  const k = Math.min(1, maxSide / Math.max(w, h));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(w * k));
  canvas.height = Math.max(1, Math.round(h * k));
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;
  try {
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    if (filters && !isNeutralFilters(filters)) {
      const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
      applyFiltersToPixels(data.data, filters);
      ctx.putImageData(data, 0, 0);
    }
  } catch {
    return null; // imagem comprimida/tainted: não extraível
  }
  return canvas;
}

function proceduralCanvases(edit: MaterialEdit, size: number): { albedo: string; normal?: string } {
  const gen = generateProceduralTexture(
    {
      ...DEFAULT_MATERIAL_PROPERTIES,
      textureType: edit.pattern,
      textureColorA: edit.patternColorA,
      textureColorB: edit.patternColorB,
      textureScale: edit.patternScale,
      enableNormalMap: true,
      normalScale: 1,
    },
    size
  );
  let albedo = gen.dataUrl;
  if (!isNeutralFilters(edit.filters)) {
    const canvas = document.createElement('canvas');
    canvas.width = gen.canvas.width;
    canvas.height = gen.canvas.height;
    const ctx = canvas.getContext('2d')!;
    ctx.drawImage(gen.canvas, 0, 0);
    const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
    applyFiltersToPixels(data.data, edit.filters);
    ctx.putImageData(data, 0, 0);
    albedo = canvas.toDataURL('image/png');
  }
  return { albedo, normal: gen.normalDataUrl };
}

/** Material Three do arquivo (a raiz do cache) pelo `uuid` guardado em `ModelMaterialInfo`. */
function threeMaterialOf(model: LoadedModel, uuid: string | undefined): THREE.Material | null {
  if (!uuid) return null;
  let found: THREE.Material | null = null;
  model.root.traverse((child) => {
    const mesh = child as THREE.Mesh;
    if (found || !mesh.isMesh) return;
    for (const m of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) if (m?.uuid === uuid) found = m;
  });
  return found;
}

/**
 * Imagens a gravar no import: TODAS as texturas embutidas (albedo com os filtros assados; os demais mapas como vieram) e os
 * padrões procedurais (albedo + normal). `apply` marca o albedo que o `materialSlots` do nó deve referenciar.
 */
export function renderMaterialImages(model: LoadedModel, edits: readonly MaterialEdit[]): MaterialImageInput[] {
  const out: MaterialImageInput[] = [];
  for (const edit of edits) {
    const info = model.materials.find((i) => i.name === edit.name);
    if (!info) continue;
    const source = albedoSourceOf(edit, info);
    if (source === 'procedural') {
      const gen = proceduralCanvases(edit, 512);
      out.push({ material: edit.name, map: 'albedo', source: 'procedural', dataUrl: gen.albedo, apply: true });
      if (gen.normal) out.push({ material: edit.name, map: 'normal', source: 'procedural', dataUrl: gen.normal, apply: true });
      continue;
    }
    const three = threeMaterialOf(model, info.uuid) as (THREE.Material & Record<string, THREE.Texture | null | undefined>) | null;
    if (!three) continue;
    for (const [map, key] of MAP_KEYS) {
      const texture = three[key];
      if (!texture) continue;
      const filtered = map === 'albedo' && !isNeutralFilters(edit.filters);
      const canvas = canvasOf(texture, 8192, filtered ? edit.filters : undefined);
      if (!canvas) continue;
      out.push({ material: edit.name, map, source: 'embedded', dataUrl: canvas.toDataURL('image/png'), apply: map === 'albedo' && filtered });
    }
  }
  return out;
}

/** Plano de pré-visualização do rascunho (mesma regra do nó): só materiais alterados entram. */
export function buildPreviewPlan(model: LoadedModel, edits: readonly MaterialEdit[]): MaterialPlan {
  const plan: MaterialPlan = {};
  for (const edit of edits) {
    const info = model.materials.find((i) => i.name === edit.name);
    if (!info || !isEditDirty(edit, info)) continue;
    const source = albedoSourceOf(edit, info);
    let albedoDataUrl: string | undefined;
    let normalDataUrl: string | undefined;
    if (source === 'procedural') {
      const gen = proceduralCanvases(edit, PREVIEW_SIZE);
      albedoDataUrl = gen.albedo;
      normalDataUrl = gen.normal;
    }
    else if (source === 'embedded' && !isNeutralFilters(edit.filters)) {
      const three = threeMaterialOf(model, info.uuid) as (THREE.Material & { map?: THREE.Texture | null }) | null;
      const canvas = three?.map ? canvasOf(three.map, PREVIEW_SIZE, edit.filters) : null;
      albedoDataUrl = canvas?.toDataURL('image/png');
    }
    const slot = materialSlotFromEdit(edit, info, albedoDataUrl ? { id: 'preview' } : null, normalDataUrl ? { id: 'preview-normal' } : null);
    if (slot) plan[edit.name] = { override: slot, albedoDataUrl, normalDataUrl };
  }
  return plan;
}
