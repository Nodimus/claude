import { describe, expect, it } from 'vitest';
import { DEFAULT_TRANSFORM_DRAFT, calibratedBounds, type ImportTransformDraft } from './calibration';
import { DEFAULT_COLLISION_OPTIONS } from './importPlan';
import { editFromInfo } from './materials';
import { emptyBoneMap } from '../../runtime/skeletalAnimation';
import type { ModelMaterialInfo } from '../models/types';
import type { LibraryClip } from './animationLibrary';
import {
  NEUTRAL_PBR,
  SCAN_LIMITS,
  applyAllFixes,
  importQuestions,
  largestDimensionM,
  scanImport,
  suggestUnit,
  type ImportDraft,
  type ImportScanInput,
} from './diagnostics';

const mat = (over: Partial<ModelMaterialInfo> = {}): ModelMaterialInfo => ({ name: 'Mat', type: 'MeshStandardMaterial', color: '#ffffff', hasMap: false, transparent: false, ...over });

const draftOf = (over: { transform?: Partial<ImportTransformDraft>; materials?: ModelMaterialInfo[]; collision?: Partial<ImportDraft['collision']> } = {}): ImportDraft => ({
  transform: { ...DEFAULT_TRANSFORM_DRAFT, ...over.transform },
  collision: { ...DEFAULT_COLLISION_OPTIONS, ...over.collision },
  materials: (over.materials ?? []).map(editFromInfo),
});

const input = (over: Partial<ImportScanInput> = {}): ImportScanInput => ({
  bounds: { size: { x: 0.6, y: 1.8, z: 0.4 }, center: { x: 0, y: 0.9, z: 0 } },
  stats: { triangles: 1000 },
  materials: [],
  upAxisHint: 'y',
  draft: draftOf(),
  boneNames: [],
  rigMap: emptyBoneMap(),
  library: [],
  ...over,
});

const codes = (i: ImportScanInput) => scanImport(i).map((f) => f.code);

/** Fixture do prompt: deitado (Z-Up), em cm, com o pivô no centro. */
const lyingCm = (): ImportScanInput =>
  input({
    bounds: { size: { x: 50, y: 30, z: 180 }, center: { x: 0, y: 0, z: 0 } },
    upAxisHint: 'z',
    draft: draftOf({ transform: { pivot: 'center' } }),
  });

describe('AIS-38 — detector de escala', () => {
  it('modelo humano em metros: sem achado', () => {
    expect(codes(input())).toEqual([]);
  });
  it('limiares: 0.1 m e 50 m são aceitos, fora deles alerta', () => {
    const at = (z: number) => input({ bounds: { size: { x: 0.01, y: z, z: 0.01 }, center: { x: 0, y: z / 2, z: 0 } } });
    expect(codes(at(SCAN_LIMITS.minSizeM))).not.toContain('import.scale_out_of_range');
    expect(codes(at(SCAN_LIMITS.maxSizeM))).not.toContain('import.scale_out_of_range');
    expect(codes(at(0.05))).toContain('import.scale_out_of_range');
    expect(codes(at(51))).toContain('import.scale_out_of_range');
  });
  it('maior dimensão leva em conta a escala uniforme', () => {
    const base = input();
    expect(largestDimensionM(base.draft.transform, base.bounds)).toBeCloseTo(1.8);
    expect(largestDimensionM({ ...base.draft.transform, scale: 100 }, base.bounds)).toBeCloseTo(180);
  });
  it('em cm sugere cm; em mm sugere mm; muito pequeno cai na escala humana', () => {
    expect(suggestUnit(180)).toBe('cm');
    expect(suggestUnit(18000)).toBe('mm');
    expect(suggestUnit(1e6)).toBeNull();
    const tiny = scanImport(input({ bounds: { size: { x: 0.01, y: 0.02, z: 0.01 }, center: { x: 0, y: 0.01, z: 0 } } })).find((f) => f.code === 'import.scale_out_of_range');
    expect(tiny?.fix?.label).toBe('Escala humana (1,80 m)');
    const fixed = tiny!.fix!.apply(draftOf());
    expect(fixed.transform.scale).toBeCloseTo(90);
  });
});

describe('AIS-38 — detector de pivô', () => {
  it('pivô na base (padrão): sem achado', () => {
    expect(codes(input())).not.toContain('import.pivot_off_base');
  });
  it('pivô no centro, no topo e custom fora da base alertam', () => {
    for (const pivot of ['center', 'top'] as const) expect(codes(input({ draft: draftOf({ transform: { pivot } }) }))).toContain('import.pivot_off_base');
    expect(codes(input({ draft: draftOf({ transform: { pivot: 'custom', pivotOffsetY: -0.5 } }) }))).toContain('import.pivot_off_base');
  });
  it('base dentro de ±2% da altura é tolerada', () => {
    // custom que deixa a base a 1% da altura (0.018 m de 1.8 m) está dentro
    const t = input({ draft: draftOf({ transform: { pivot: 'custom', pivotOffsetY: -0.018 } }) });
    expect(codes(t)).not.toContain('import.pivot_off_base');
  });
  it('origem longe da pegada (X/Z) alerta; com Auto Centralizar não', () => {
    const far = { bounds: { size: { x: 0.6, y: 1.8, z: 0.4 }, center: { x: 5, y: 0.9, z: 0 } } };
    expect(codes(input(far))).toContain('import.pivot_off_base');
    expect(codes(input({ ...far, draft: draftOf({ transform: { centerXZ: true } }) }))).not.toContain('import.pivot_off_base');
  });
});

describe('AIS-38 — detector de orientação', () => {
  it('Y-Up em pé: sem achado', () => {
    expect(codes(input())).not.toContain('import.orientation_zup');
  });
  it('dica Z-up ou caixa deitada alertam', () => {
    expect(codes(input({ upAxisHint: 'z' }))).toContain('import.orientation_zup');
    const lying = input({ bounds: { size: { x: 0.6, y: 0.4, z: 1.8 }, center: { x: 0, y: 0, z: 0 } } });
    expect(codes(lying)).toContain('import.orientation_zup');
  });
  it('já corrigido (botão ou rotação X manual) não alerta de novo', () => {
    expect(codes(input({ upAxisHint: 'z', draft: draftOf({ transform: { zUpFlipped: true } }) }))).not.toContain('import.orientation_zup');
    expect(codes(input({ upAxisHint: 'z', draft: draftOf({ transform: { rotationDeg: { x: 90, y: 0, z: 0 } } }) }))).not.toContain('import.orientation_zup');
  });
});

describe('AIS-38 — detector de texturas e materiais', () => {
  it('textura ausente e transparência incorreta têm correção; nome repetido só informa', () => {
    const materials = [mat({ name: 'A', hasMap: true, mapMissing: true }), mat({ name: 'B', transparent: true, opacity: 1 }), mat({ name: 'C' }), mat({ name: 'C' })];
    const found = scanImport(input({ materials, draft: draftOf({ materials }) }));
    const by = (c: string) => found.find((f) => f.code === c);
    expect(by('texture.missing')?.fix?.label).toBe('PBR neutro');
    expect(by('material.transparent_opaque')?.fix?.label).toBe('Desligar transparência');
    expect(by('material.duplicate_name')?.fix).toBeUndefined();
  });
  it('as correções saem do achado depois de aplicadas', () => {
    const materials = [mat({ name: 'A', hasMap: true, mapMissing: true }), mat({ name: 'B', transparent: true, opacity: 1 })];
    const i = input({ materials, draft: draftOf({ materials }) });
    const fixed = applyAllFixes(scanImport(i), i.draft);
    expect(fixed.materials.find((e) => e.name === 'A')!.color.r).toBeCloseTo(NEUTRAL_PBR.color.r);
    expect(fixed.materials.find((e) => e.name === 'B')!.transparent).toBe(false);
    expect(codes({ ...i, draft: fixed })).toEqual([]);
  });
});

describe('AIS-38 — detector de colisão', () => {
  const meshCollision = { collision: { enabled: true, bodyMode: 'static' as const, shape: 'mesh' as const } };
  it('"Malha exata" acima do orçamento alerta e a correção troca para automático', () => {
    const i = input({ stats: { triangles: SCAN_LIMITS.meshColliderTriangleBudget + 1 }, draft: draftOf(meshCollision) });
    const f = scanImport(i).find((x) => x.code === 'physics.mesh_triangle_budget');
    expect(f).toBeDefined();
    expect(f!.fix!.apply(i.draft).collision.shape).toBe('auto');
  });
  it('dentro do orçamento, ou forma diferente de malha, ou colisão desligada: sem achado', () => {
    expect(codes(input({ stats: { triangles: SCAN_LIMITS.meshColliderTriangleBudget }, draft: draftOf(meshCollision) }))).toEqual([]);
    expect(codes(input({ stats: { triangles: 1e6 } }))).toEqual([]);
    expect(codes(input({ stats: { triangles: 1e6 }, draft: draftOf({ collision: { ...meshCollision.collision, enabled: false } }) }))).toEqual([]);
  });
  it('caixa de extensão zero é degenerada (só informa)', () => {
    const f = scanImport(input({ bounds: { size: { x: 1, y: 0, z: 1 }, center: { x: 0, y: 0, z: 0 } } })).find((x) => x.code === 'physics.degenerate_bounds');
    expect(f).toBeDefined();
    expect(f!.fix).toBeUndefined();
  });
});

describe('AIS-38 — detector de rig e clipes', () => {
  const clip = (over: Partial<LibraryClip> = {}): LibraryClip => ({
    id: 'c', name: 'Walk', sourceKind: 'embedded', sourceClip: 'Walk', duration: 1, trackCount: 3, coverage: 1, compatible: true, accepted: true, loop: true, inPlace: false, ...over,
  });
  it('modelo sem esqueleto (prop estático): sem achado', () => {
    expect(codes(input())).toEqual([]);
  });
  it('esqueleto não humanoide com clipes vira warning e não tem correção', () => {
    const f = scanImport(input({ boneNames: ['a', 'b', 'c'], library: [clip()] })).find((x) => x.code === 'rig.not_humanoid');
    expect(f?.severity).toBe('warning');
    expect(f?.fix).toBeUndefined();
  });
  it('clipe incompatível só informa', () => {
    const f = scanImport(input({ library: [clip({ compatible: false, accepted: false, coverage: 0.2 })] })).find((x) => x.code === 'anim.incompatible_skeleton');
    expect(f).toBeDefined();
    expect(f!.fix).toBeUndefined();
  });
});

describe('AIS-38 — correções em lote', () => {
  it('fixture "deitado, em cm, pivô no centro" gera 3 achados e "Corrigir todos" resolve', () => {
    const i = lyingCm();
    expect(codes(i).sort()).toEqual(['import.orientation_zup', 'import.pivot_off_base', 'import.scale_out_of_range']);
    const fixed = applyAllFixes(scanImport(i), i.draft);
    expect(fixed.transform.zUpFlipped).toBe(true);
    expect(fixed.transform.scale).toBeCloseTo(0.01);
    expect(fixed.transform.pivot).toBe('bottom');
    expect(codes({ ...i, draft: fixed })).toEqual([]);
    // a caixa final tem altura humana (a maior extensão 180 cm virou o eixo Y)
    expect(calibratedBounds(fixed.transform, i.bounds)!.size.y * fixed.transform.scale).toBeCloseTo(1.8);
  });
  it('cada correção é idempotente e "Corrigir todos" também', () => {
    const i = lyingCm();
    const findings = scanImport(i);
    for (const f of findings) {
      const once = f.fix!.apply(i.draft);
      expect(f.fix!.apply(once)).toEqual(once);
    }
    const all = applyAllFixes(findings, i.draft);
    expect(applyAllFixes(findings, all)).toEqual(all);
  });
  it('a ordem das correções não depende da ordem dos achados', () => {
    const i = lyingCm();
    const findings = scanImport(i);
    expect(applyAllFixes([...findings].reverse(), i.draft)).toEqual(applyAllFixes(findings, i.draft));
  });
  it('correções não mutam o rascunho original (base do "Desfazer correções")', () => {
    const i = lyingCm();
    const snapshot = JSON.parse(JSON.stringify(i.draft));
    applyAllFixes(scanImport(i), i.draft);
    expect(i.draft).toEqual(snapshot);
  });
});

describe('AIS-38 — perguntas manuais', () => {
  it('só pergunta sobre pessoa de 1,80 m quando a escala está fora do intervalo', () => {
    expect(importQuestions(scanImport(input()), input().bounds)).toEqual([]);
    const i = lyingCm();
    const q = importQuestions(scanImport(i), i.bounds);
    expect(q).toHaveLength(1);
    expect(q[0].apply(i.draft).transform.scale).toBeGreaterThan(0);
  });
});

describe('AIS-38 — identidade dos achados no DiagnosticService', () => {
  it('achados de mesmo código em materiais diferentes têm alvos distintos (não colidem)', () => {
    const materials = [mat({ name: 'A', hasMap: true, mapMissing: true }), mat({ name: 'B', hasMap: true, mapMissing: true })];
    const found = scanImport(input({ materials, draft: draftOf({ materials }) })).filter((f) => f.code === 'texture.missing');
    expect(found.map((f) => f.target).sort()).toEqual(['A', 'B']);
  });
});
