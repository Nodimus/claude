/**
 * AIS-33 — "Importar & Adicionar à Cena". Grava o modelo em `res://models/` SEMPRE pelo `AssetPipeline` (AIS-28c) e só
 * depois cria o `MeshInstance` com `model: ResourceRef` num ÚNICO Command (Undo remove o nó e mantém o arquivo: arquivo
 * em `res://` não é Command). Qualquer falha antes do nó desfaz o que esta importação gravou: nenhum arquivo parcial
 * fica "esperando". As dependências entram por parâmetro: função testável em Node, sem React.
 */
import type { ResourceRef } from '../../types/node';
import type { MaterialOverride } from '../../types/material';
import { RigConfigSchema, type BoneMap, type RigClip } from '../../schemas/v1/rig.schema';
import { emptyBoneMap, validateBoneMap } from '../../runtime/skeletalAnimation';
import { acceptedClips, buildAnimationPlayerProperties, toRigClips, type LibraryClip } from './animationLibrary';
import type { ImportRequest, ImportResult } from '../resources/AssetPipeline';
import type { LocalBounds } from '../physics/bounds';
import { bytesToDataUrl } from '../models/modelBytes';
import { manifestMaterialFrom, collectMaterialSlots, type MaterialEdit } from './materials';
import type { ModelMaterialInfo } from '../models/types';
import type { ManifestMaterial, ModelMaterialManifest } from '../../schemas/v1/modelMaterialManifest.schema';
import { nodeTransformFor, toModelImportSettings, type ImportTransformDraft } from './calibration';
import {
  buildMeshInstanceProperties,
  buildPhysicsBlock,
  extOf,
  planModelDestination,
  sanitizeAssetName,
  uniqueStem,
  MODELS_DIR,
  stemOf,
  type CollisionOptions,
  type ImportFile,
} from './importPlan';

const TEXT_EXTS = new Set(['gltf', 'obj', 'dae']);

/** Formato de persistência do projeto: texto para os formatos textuais (o grafo de dependências lê o `.gltf`), data URL para o resto. */
export function contentForFile(fileName: string, bytes: ArrayBuffer): string {
  return TEXT_EXTS.has(extOf(fileName)) ? new TextDecoder('utf-8').decode(bytes) : bytesToDataUrl(bytes, mimeOf(fileName));
}

function mimeOf(fileName: string): string {
  switch (extOf(fileName)) {
    case 'glb':
      return 'model/gltf-binary';
    case 'png':
      return 'image/png';
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'webp':
      return 'image/webp';
    default:
      return 'application/octet-stream';
  }
}

/** Imagem de material a gravar em `res://textures/<asset>/` (PNG em data URL; nunca vai para o JSON). */
export interface MaterialImageInput {
  /** Nome do material no arquivo. */
  material: string;
  map: 'albedo' | 'normal' | 'roughness' | 'metalness' | 'emissive';
  source: 'embedded' | 'procedural';
  dataUrl: string;
  /** O `materialSlots` do nó usa esta imagem como albedo (ou normal) do slot. */
  apply: boolean;
}

/** Materiais do modelo no import (AIS-35): rascunho por material + as imagens a extrair. */
export interface MaterialImportInput {
  edits: MaterialEdit[];
  infos: ModelMaterialInfo[];
  images: MaterialImageInput[];
}

export const TEXTURES_DIR_URI = 'res://textures/';

/** Nome livre para a pasta `res://textures/<nome>/` e o manifesto `<nome>_material.json`. */
export function uniqueTextureStem(stem: string, existing: ReadonlySet<string>): string {
  const clash = (name: string) => {
    const folder = `${TEXTURES_DIR_URI}${name}/`.toLowerCase();
    const manifest = `${TEXTURES_DIR_URI}${name}_material.json`.toLowerCase();
    for (const uri of existing) {
      const l = uri.toLowerCase();
      if (l === manifest || l.startsWith(folder)) return true;
    }
    return false;
  };
  let name = stem;
  for (let i = 2; clash(name) && i < 10000; i++) name = `${stem}_${i}`;
  return name;
}

export interface ImportDeps {
  pipeline: { import(request: ImportRequest): Promise<ImportResult> };
  existingUris(): ReadonlySet<string>;
  refForUri(uri: string): ResourceRef | undefined;
  /** Conteúdo atual de um arquivo do projeto (reutilização de `res://models/`). */
  readContent(uri: string): string | undefined;
  /** Cria o nó (UM Command). */
  addNode(type: 'MeshInstance' | 'AnimationPlayer', parentId: string, name: string, properties: Record<string, any>): { id: string };
  /** Agrupa os `addNode` do import (modelo + `AnimationPlayer`) numa só entrada de Undo (AIS-37). Sem isto, executa direto. */
  transaction?<T>(label: string, fn: () => T): T;
  /** Desfaz um arquivo que esta importação acabou de gravar (rollback). */
  discard(uri: string): Promise<void>;
}

export interface ImportInput {
  fileName: string;
  bytes: ArrayBuffer;
  /** Dependências do `.gltf` (`.bin`, imagens), com caminho relativo ao modelo. */
  siblings: ImportFile[];
  /** Origem em `res://` (reutilização). */
  sourceUri?: string;
  draft: ImportTransformDraft;
  bounds: LocalBounds | null;
  collision: CollisionOptions;
  /** Materiais editados + imagens a extrair (AIS-35). Sem isto, nada é extraído e o nó não leva `materialSlots`. */
  materials?: MaterialImportInput;
  /** Mapeamento de ossos (AIS-36). Só é gravado se for humanoide (obrigatórios presentes): sem rig fictício (decisão 14). */
  rig?: { bones: BoneMap };
  /** Biblioteca de clipes (AIS-37) e os arquivos extras só de animação a gravar em `res://models/`. */
  animations?: { library: LibraryClip[]; files: { name: string; bytes: ArrayBuffer }[] };
  parentId: string;
  nodeName?: string;
}

export type ImportOutcome =
  | { ok: true; nodeId: string; playerId?: string; mainUri: string; written: string[]; reused: boolean }
  | { ok: false; code: string; error: string };

export async function importModelAsset(input: ImportInput, deps: ImportDeps): Promise<ImportOutcome> {
  const plan = planModelDestination({ fileName: input.fileName, siblings: input.siblings, sourceUri: input.sourceUri }, deps.existingUris());
  const written: string[] = [];

  const rollback = async () => {
    for (const uri of [...written].reverse()) {
      try {
        await deps.discard(uri);
      } catch {
        /* melhor esforço: o arquivo fica listado no erro */
      }
    }
  };
  const fail = async (code: string, error: string): Promise<ImportOutcome> => {
    await rollback();
    return { ok: false, code, error };
  };

  // 1) dependências primeiro (o `.gltf` as lê do projeto ao ser processado)
  const outputs: ResourceRef[] = [];
  for (const dep of plan.siblingUris) {
    const file = input.siblings.find((s) => s.rel === dep.rel);
    if (!file) continue;
    const result = await deps.pipeline.import({ uri: dep.uri, content: contentForFile(dep.rel, file.bytes) });
    if (!result.ok) return fail(result.diagnostics[0]?.code ?? 'import.process_failed', result.diagnostics[0]?.message ?? `Falha ao importar ${dep.uri}.`);
    written.push(dep.uri);
    const ref = deps.refForUri(dep.uri);
    if (ref) outputs.push(ref);
  }

  // 2) arquivo principal + ModelImportSettings (reutilizado: só atualiza as settings, sem duplicar)
  const content = plan.reuse ? deps.readContent(plan.mainUri) : contentForFile(input.fileName, input.bytes);
  if (content === undefined) return fail('model.unresolved', `${plan.mainUri} não tem conteúdo para importar.`);
  const settings = toModelImportSettings(input.draft, input.bounds, { outputs });
  const main = await deps.pipeline.import({ uri: plan.mainUri, content, settings: settings as unknown as Record<string, unknown> });
  if (!main.ok) return fail(main.diagnostics[0]?.code ?? 'import.process_failed', main.diagnostics[0]?.message ?? `Falha ao importar ${plan.mainUri}.`);
  if (!plan.reuse) written.push(plan.mainUri);

  const model = deps.refForUri(plan.mainUri);
  if (!model) return fail('model.unresolved', `${plan.mainUri} não foi registrado como recurso.`);

  // 2b) texturas extraídas/geradas → PNG em res://textures/<asset>/ + manifesto <asset>_material.json (AIS-35); falhou = rollback total
  let materialSlots: Record<string, MaterialOverride> | undefined;
  let currentSettings: ImportSettings = settings;
  if (input.materials && input.materials.infos.length > 0) {
    const extracted = await extractMaterials(input.materials, plan.mainUri, model, settings, content, deps, written, outputs);
    if (!extracted.ok) return fail(extracted.code, extracted.error);
    materialSlots = extracted.materialSlots;
    currentSettings = extracted.settings;
  }

  // 2c) rig → res://materials/<asset>_rig.json (AIS-36) + biblioteca de clipes por REFERÊNCIA (AIS-37). Grava o rig se o modelo é
  // humanoide OU se há clipes na biblioteca (não humanoide com clipes: o rig lista só os clipes, sem retarget). Falhou = rollback total.
  const library = input.animations?.library ?? [];
  const accepted = acceptedClips(library);
  const humanoid = !!input.rig && validateBoneMap(input.rig.bones).humanoid;
  let playerProps: Record<string, unknown> | null = null;
  if (humanoid || accepted.length > 0) {
    const fileRefs = new Map<string, ResourceRef>();
    if (accepted.some((c) => c.sourceKind === 'file')) {
      const wroteFiles = await writeAnimationFiles(input.animations!.files, accepted, deps, written, fileRefs);
      if (!wroteFiles.ok) return fail(wroteFiles.code, wroteFiles.error);
      currentSettings = { ...currentSettings, outputs: [...currentSettings.outputs, ...fileRefs.values()] };
    }
    const clips = toRigClips(library, { model, files: fileRefs });
    const bones = humanoid ? input.rig!.bones : emptyBoneMap();
    const rigged = await writeRig(bones, clips, plan.mainUri, plan.reuse, model, currentSettings, content, deps, written);
    if (!rigged.ok) return fail(rigged.code, rigged.error);
    playerProps = buildAnimationPlayerProperties(clips, rigged.ref);
  }

  // 3) o nó: UM Command; referência por identidade (nunca base64 nem caminho solto)
  const properties = buildMeshInstanceProperties({
    model,
    transform: nodeTransformFor(input.draft, input.bounds),
    physics: buildPhysicsBlock(input.collision),
    materialSlots,
  });
  const name = input.nodeName?.trim() || sanitizeAssetName(stemOf(input.fileName));
  // UM Undo remove o modelo e o `AnimationPlayer` filho juntos (arquivo em res:// não é Command)
  let nodeId = '';
  let playerId: string | undefined;
  const create = () => {
    nodeId = deps.addNode('MeshInstance', input.parentId, name, properties).id;
    if (playerProps) playerId = deps.addNode('AnimationPlayer', nodeId, 'AnimationPlayer', playerProps).id;
  };
  if (deps.transaction) deps.transaction(`Importar modelo ${name}`, create);
  else create();
  return { ok: true, nodeId, playerId, mainUri: plan.mainUri, written, reused: plan.reuse };
}

export type ImportSettings = ReturnType<typeof toModelImportSettings>;
export type ExtractOutcome = { ok: true; materialSlots: Record<string, MaterialOverride>; settings: ImportSettings } | { ok: false; code: string; error: string };

/**
 * Grava as imagens (`<n>.png`) e o manifesto e religa o `importSettings` do modelo (`materials` + `outputs`). Tudo o que
 * grava entra em `written` (rollback do chamador). Nenhum base64 no JSON: o manifesto guarda `ResourceRef`.
 */
export interface ExtractOptions {
  /** Reedição (AIS-38c): reutiliza a pasta e o manifesto do asset (mesmos `resourceId`s) em vez de criar um nome novo. */
  stem?: string;
  /** Numeração dos PNGs novos (continua depois dos existentes, sem sobrescrever os de materiais intactos). */
  firstIndex?: number;
  /** Materiais do manifesto atual que NÃO foram regenerados e continuam como estão. */
  keep?: ManifestMaterial[];
}

const dedupeRefs = (refs: readonly ResourceRef[]): ResourceRef[] => [...new Map(refs.map((r) => [r.id, r])).values()];

export async function extractMaterials(
  materials: MaterialImportInput,
  mainUri: string,
  model: ResourceRef,
  mainSettings: ImportSettings,
  mainContent: string,
  deps: ImportDeps,
  written: string[],
  outputs: ResourceRef[],
  options: ExtractOptions = {}
): Promise<ExtractOutcome> {
  const stem = options.stem ?? uniqueTextureStem(sanitizeAssetName(stemOf(mainUri)), deps.existingUris());
  const folder = `${TEXTURES_DIR_URI}${stem}/`;
  const mapsByMaterial = new Map<string, ManifestMaterial['maps']>();
  const albedoByName = new Map<string, ResourceRef>();
  const normalByName = new Map<string, ResourceRef>();
  const generated: ResourceRef[] = [];

  let n = (options.firstIndex ?? 1) - 1;
  for (const image of materials.images) {
    n += 1;
    const uri = `${folder}${n}.png`;
    const result = await deps.pipeline.import({ uri, content: image.dataUrl });
    if (!result.ok) return { ok: false, code: result.diagnostics[0]?.code ?? 'texture.import_failed', error: result.diagnostics[0]?.message ?? `Falha ao gravar ${uri}.` };
    written.push(uri);
    const ref = deps.refForUri(uri);
    if (!ref) return { ok: false, code: 'texture.unresolved', error: `${uri} não foi registrado como recurso.` };
    generated.push(ref);
    mapsByMaterial.set(image.material, { ...(mapsByMaterial.get(image.material) ?? {}), [image.map]: ref });
    if (image.map === 'albedo' && image.apply) albedoByName.set(image.material, ref);
    if (image.map === 'normal' && image.apply) normalByName.set(image.material, ref);
  }

  const manifest: ModelMaterialManifest = {
    schemaVersion: 1,
    asset: model,
    materials: [
      ...(options.keep ?? []).filter((k) => !materials.edits.some((e) => e.name === k.name)),
      ...materials.edits.map((edit) => {
        const source: ManifestMaterial['source'] = materials.images.some((i) => i.material === edit.name && i.source === 'procedural') ? 'procedural' : 'embedded';
        return manifestMaterialFrom(edit, source, mapsByMaterial.get(edit.name) ?? {});
      }),
    ],
  };
  const manifestUri = `${TEXTURES_DIR_URI}${stem}_material.json`;
  const wrote = await deps.pipeline.import({ uri: manifestUri, content: JSON.stringify(manifest, null, 2) });
  if (!wrote.ok) return { ok: false, code: wrote.diagnostics[0]?.code ?? 'material.manifest_failed', error: wrote.diagnostics[0]?.message ?? `Falha ao gravar ${manifestUri}.` };
  written.push(manifestUri);
  const manifestRef = deps.refForUri(manifestUri);
  if (!manifestRef) return { ok: false, code: 'material.unresolved', error: `${manifestUri} não foi registrado como recurso.` };

  // o modelo passa a apontar para o manifesto e para tudo o que o import gerou (exclusão em pacote, AIS-38c)
  const settings = { ...mainSettings, materials: manifestRef, outputs: dedupeRefs([...outputs, ...generated, manifestRef]) };
  const relink = await deps.pipeline.import({ uri: mainUri, content: mainContent, settings: settings as unknown as Record<string, unknown> });
  if (!relink.ok) return { ok: false, code: relink.diagnostics[0]?.code ?? 'import.process_failed', error: relink.diagnostics[0]?.message ?? `Falha ao atualizar ${mainUri}.` };

  return { ok: true, materialSlots: collectMaterialSlots(materials.edits, materials.infos, albedoByName, normalByName), settings };
}

export const MATERIALS_DIR_URI = 'res://materials/';

/** Nome livre para `res://materials/<nome>_rig.json`. */
export function uniqueRigStem(stem: string, existing: ReadonlySet<string>): string {
  const taken = (name: string) => [...existing].some((u) => u.toLowerCase() === `${MATERIALS_DIR_URI}${name}_rig.json`.toLowerCase());
  let name = stem;
  for (let i = 2; taken(name) && i < 10000; i++) name = `${stem}_${i}`;
  return name;
}

/**
 * Grava `res://materials/<asset>_rig.json` (`RigConfig`, Zod v1) pelo `AssetPipeline` e religa `ModelImportSettings.rig`/`outputs`.
 * Modelo reutilizado reaproveita o rig do mesmo asset (mesmo caminho, mesmo `resourceId`); modelo novo nunca sobrescreve outro rig.
 */
export async function writeRig(
  bones: BoneMap,
  clips: RigClip[],
  mainUri: string,
  reuse: boolean,
  model: ResourceRef,
  mainSettings: ImportSettings,
  mainContent: string,
  deps: ImportDeps,
  written: string[],
  /** Reedição (AIS-38c): regrava exatamente este arquivo (o rig pode ter sufixo `_2`), mantendo o `resourceId`. */
  uriOverride?: string
): Promise<{ ok: true; ref: ResourceRef } | { ok: false; code: string; error: string }> {
  const base = sanitizeAssetName(stemOf(mainUri));
  const stem = reuse ? base : uniqueRigStem(base, deps.existingUris());
  const uri = uriOverride ?? `${MATERIALS_DIR_URI}${stem}_rig.json`;
  const parsed = RigConfigSchema.safeParse({ schemaVersion: 1, asset: model, standard: 'humanoid19', bones, clips });
  if (!parsed.success) return { ok: false, code: 'rig.invalid', error: `O rig de ${uri} é inválido: ${parsed.error.issues[0]?.message ?? 'erro'}.` };
  const existed = deps.existingUris().has(uri);
  const wrote = await deps.pipeline.import({ uri, content: JSON.stringify(parsed.data, null, 2) });
  if (!wrote.ok) return { ok: false, code: wrote.diagnostics[0]?.code ?? 'rig.import_failed', error: wrote.diagnostics[0]?.message ?? `Falha ao gravar ${uri}.` };
  if (!existed) written.push(uri);
  const ref = deps.refForUri(uri);
  if (!ref) return { ok: false, code: 'rig.unresolved', error: `${uri} não foi registrado como recurso.` };
  const settings = { ...mainSettings, rig: ref, outputs: [...mainSettings.outputs.filter((o) => o.id !== ref.id), ref] };
  const relink = await deps.pipeline.import({ uri: mainUri, content: mainContent, settings: settings as unknown as Record<string, unknown> });
  if (!relink.ok) return { ok: false, code: relink.diagnostics[0]?.code ?? 'import.process_failed', error: relink.diagnostics[0]?.message ?? `Falha ao atualizar ${mainUri}.` };
  return { ok: true, ref };
}

/**
 * Grava os arquivos extras de SÓ animação em `res://models/` (a biblioteca guarda referência a eles, decisão 3.2) e devolve
 * a `ResourceRef` de cada um por nome. Só os arquivos usados por clipes aceitos; nomes livres (`Walk`, `Walk_2`).
 */
async function writeAnimationFiles(
  files: { name: string; bytes: ArrayBuffer }[],
  accepted: readonly LibraryClip[],
  deps: ImportDeps,
  written: string[],
  refs: Map<string, ResourceRef>
): Promise<{ ok: true } | { ok: false; code: string; error: string }> {
  const used = new Set(accepted.filter((c) => c.sourceKind === 'file').map((c) => c.fileName ?? ''));
  for (const file of files) {
    if (!used.has(file.name) || refs.has(file.name)) continue;
    const ext = extOf(file.name);
    const stem = uniqueStem(sanitizeAssetName(stemOf(file.name)), ext, deps.existingUris(), false);
    const uri = `${MODELS_DIR}${stem}.${ext}`;
    const result = await deps.pipeline.import({ uri, content: contentForFile(file.name, file.bytes) });
    if (!result.ok) return { ok: false, code: result.diagnostics[0]?.code ?? 'import.process_failed', error: result.diagnostics[0]?.message ?? `Falha ao importar ${uri}.` };
    written.push(uri);
    const ref = deps.refForUri(uri);
    if (!ref) return { ok: false, code: 'animation.unresolved', error: `${uri} não foi registrado como recurso.` };
    refs.set(file.name, ref);
  }
  return { ok: true };
}
