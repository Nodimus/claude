import { describe, expect, it } from 'vitest';
import { DEFAULT_TRANSFORM_DRAFT } from './calibration';
import { importModelAsset, uniqueRigStem, type ImportDeps } from './importModelAsset';
import { editFromInfo } from './materials';
import { CUBE, buildGlb } from '../models/modelFixtures';
import type { ModelMaterialInfo } from '../models/types';
import { ResourceRegistry } from '../resources/ResourceRegistry';
import { AssetPipeline, type PipelineIO } from '../resources/AssetPipeline';
import { BUILTIN_IMPORTERS, MODEL_SUPPORT_IMPORTERS } from '../resources/builtinImporters';
import { autoMapBones } from '../../runtime/skeletalAnimation';
import { parseRigConfig } from '../../schemas/v1/rig.schema';
import { NODE_DEFINITIONS } from '../../nodes/registry';
import * as THREE from 'three';

type F = Record<string, any>;
function setup() {
  const project = { files: {} as F };
  const io: PipelineIO = {
    files: () => project.files,
    write: (uri, content, meta) => {
      project.files[uri] = { ...(project.files[uri] ?? {}), path: uri, name: uri.split('/').pop(), isDirectory: false, content, size: content.length, updatedAt: 'x', ...meta };
    },
  };
  const registry = new ResourceRegistry();
  const pipeline = new AssetPipeline(registry, io);
  for (const importer of [...BUILTIN_IMPORTERS, ...MODEL_SUPPORT_IMPORTERS]) pipeline.registerImporter(importer);
  const added: Record<string, any>[] = [];
  const discarded: string[] = [];
  const deps: ImportDeps = {
    pipeline,
    existingUris: () => new Set(Object.keys(project.files)),
    refForUri: (uri) => registry.refForUri(uri),
    readContent: (uri) => project.files[uri]?.content,
    addNode: (_t, _p, _n, props) => {
      added.push(props);
      return { id: `node_${added.length}` };
    },
    discard: async (uri) => {
      discarded.push(uri);
      delete project.files[uri];
      registry.syncFromProject({ files: project.files } as never);
    },
  };
  return { project, registry, deps, added, discarded };
}

const MIXAMO = [
  'Hips', 'Spine', 'Spine1', 'Neck', 'Head', 'LeftShoulder', 'LeftArm', 'LeftForeArm', 'LeftHand', 'RightShoulder', 'RightArm', 'RightForeArm', 'RightHand',
  'LeftUpLeg', 'LeftLeg', 'LeftFoot', 'RightUpLeg', 'RightLeg', 'RightFoot',
].map((n) => `mixamorig:${n}`);

const base = () => ({
  fileName: 'Cube.glb',
  bytes: buildGlb(CUBE),
  siblings: [],
  draft: { ...DEFAULT_TRANSFORM_DRAFT },
  bounds: { size: { x: 1, y: 1, z: 1 }, center: { x: 0, y: 0, z: 0 } },
  collision: { enabled: true, bodyMode: 'static' as const, shape: 'auto' as const },
  parentId: 'root',
});

describe('importação grava o rig de 19 ossos (AIS-36-C03)', () => {
  it('humanoide: res://materials/<asset>_rig.json válido no Zod, registrado e referenciado por ModelImportSettings.rig', async () => {
    const { project, registry, deps } = setup();
    const r = await importModelAsset({ ...base(), rig: { bones: autoMapBones(MIXAMO).map } }, deps);
    expect(r.ok).toBe(true);
    const rigFile = project.files['res://materials/Cube_rig.json'];
    expect(rigFile?.resourceId).toBeTruthy();
    expect(registry.getByUri('res://materials/Cube_rig.json')?.kind).toBe('animation');
    const parsed = parseRigConfig(rigFile.content);
    expect(parsed.ok && parsed.legacy).toBe(false);
    if (!parsed.ok) return;
    expect(parsed.rig.bones.Hips).toBe('mixamorig:Hips');
    expect(parsed.rig.bones.RightFoot).toBe('mixamorig:RightFoot');
    expect(parsed.rig.asset.id).toBe(project.files['res://models/Cube.glb'].resourceId);
    expect(parsed.rig.clips).toEqual([]);
    expect(rigFile.content).not.toMatch(/times|values|keyframe|base64/);
    const settings = project.files['res://models/Cube.glb'].importSettings;
    expect(settings.rig.id).toBe(rigFile.resourceId);
    expect(settings.outputs.map((o: { id: string }) => o.id)).toContain(rigFile.resourceId);
  });

  it('não humanoide (obrigatórios faltando): nenhum rig é gravado e o settings fica sem `rig`', async () => {
    const { project, deps } = setup();
    const partial = MIXAMO.filter((n) => !/RightLeg/.test(n));
    const r = await importModelAsset({ ...base(), rig: { bones: autoMapBones(partial).map } }, deps);
    expect(r.ok).toBe(true);
    expect(Object.keys(project.files).filter((u) => u.includes('_rig.json'))).toEqual([]);
    expect(project.files['res://models/Cube.glb'].importSettings.rig).toBeUndefined();
  });

  it('sem `rig` na entrada: nada é gravado', async () => {
    const { project, deps } = setup();
    await importModelAsset(base(), deps);
    expect(Object.keys(project.files).filter((u) => u.includes('_rig.json'))).toEqual([]);
  });

  it('materiais + rig juntos: o modelo aponta para os dois e para tudo o que o import gerou', async () => {
    const { project, deps } = setup();
    const info: ModelMaterialInfo = { name: 'Casco', uuid: 'u', type: 'MeshStandardMaterial', color: '#808080', hasMap: false, transparent: false };
    const r = await importModelAsset({ ...base(), materials: { edits: [editFromInfo(info)], infos: [info], images: [] }, rig: { bones: autoMapBones(MIXAMO).map } }, deps);
    expect(r.ok).toBe(true);
    const s = project.files['res://models/Cube.glb'].importSettings;
    expect(s.materials.id).toBe(project.files['res://textures/Cube_material.json'].resourceId);
    expect(s.rig.id).toBe(project.files['res://materials/Cube_rig.json'].resourceId);
    expect(s.outputs.map((o: { id: string }) => o.id)).toEqual(expect.arrayContaining([s.materials.id, s.rig.id]));
  });

  it('um modelo novo com o mesmo nome não sobrescreve o rig anterior (Cube_2_rig.json)', async () => {
    const { project, deps } = setup();
    await importModelAsset({ ...base(), rig: { bones: autoMapBones(MIXAMO).map } }, deps);
    await importModelAsset({ ...base(), rig: { bones: autoMapBones(MIXAMO).map } }, deps);
    expect(project.files['res://materials/Cube_2_rig.json']).toBeTruthy();
    expect(uniqueRigStem('Cube', new Set(['res://materials/Cube_rig.json']))).toBe('Cube_2');
    expect(uniqueRigStem('Cube', new Set())).toBe('Cube');
  });

  it('o modelo reutilizado mantém o MESMO rig (mesmo caminho e resourceId) em vez de criar outro', async () => {
    const { project, deps } = setup();
    await importModelAsset({ ...base(), rig: { bones: autoMapBones(MIXAMO).map } }, deps);
    const id = project.files['res://materials/Cube_rig.json'].resourceId;
    await importModelAsset({ ...base(), sourceUri: 'res://models/Cube.glb', rig: { bones: autoMapBones(MIXAMO).map } }, deps);
    expect(project.files['res://materials/Cube_rig.json'].resourceId).toBe(id);
    expect(project.files['res://materials/Cube_2_rig.json']).toBeUndefined();
  });
});

describe('rig com os nomes que o loader entrega (sanitizados)', () => {
  it('Rigify sanitizado vira rig válido com os nomes do THREE.Skeleton', async () => {
    const { project, deps } = setup();
    const RIGIFY = [
      'DEF-spine', 'DEF-spine.001', 'DEF-spine.002', 'DEF-spine.004', 'DEF-spine.006', 'DEF-shoulder.L', 'DEF-upper_arm.L', 'DEF-forearm.L', 'DEF-hand.L',
      'DEF-shoulder.R', 'DEF-upper_arm.R', 'DEF-forearm.R', 'DEF-hand.R', 'DEF-thigh.L', 'DEF-shin.L', 'DEF-foot.L', 'DEF-thigh.R', 'DEF-shin.R', 'DEF-foot.R',
    ].map((n) => THREE.PropertyBinding.sanitizeNodeName(n));
    const r = await importModelAsset({ ...base(), rig: { bones: autoMapBones(RIGIFY).map } }, deps);
    expect(r.ok).toBe(true);
    const parsed = parseRigConfig(project.files['res://materials/Cube_rig.json'].content);
    expect(parsed.ok && parsed.rig.bones.LeftHand).toBe('DEF-handL');
    expect(parsed.ok && Object.values(parsed.rig.bones).every(Boolean)).toBe(true);
  });
});

describe('AnimationPlayer.rigConfig é ResourceRef (AIS-36-C05)', () => {
  it('padrão vazio e descriptor `resource`; a string legada continua legível como texto', () => {
    const def = NODE_DEFINITIONS.AnimationPlayer;
    expect(def.defaultProperties.rigConfig).toBeNull();
    const d = def.propertyDescriptors.find((p) => p.key === 'rigConfig')!;
    expect(d.type).toBe('resource');
    expect(d.defaultValue).toBeNull();
    // uma cena antiga guarda o caminho como string: o valor é preservado como veio (o Inspector exibe o caminho; nada é apagado)
    const legacy = { rigConfig: 'res://materials/rig.json' };
    expect(typeof legacy.rigConfig).toBe('string');
  });
});
