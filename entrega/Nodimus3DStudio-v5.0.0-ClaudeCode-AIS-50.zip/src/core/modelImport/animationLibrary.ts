/**
 * AIS-37 — biblioteca de clipes do import: funções PURAS (sem React/Three). A biblioteca é de REFERÊNCIAS (decisão 3.2): cada
 * clipe aponta para o arquivo de origem em `res://models/` + o nome do clipe lá dentro; nenhum keyframe é copiado e não existe
 * formato `.anim` novo. O Play/Publish montam o clipe com `loadModel` + `retargetClip` (AIS-36).
 */
import type { ResourceRef } from '../../types/node';
import type { BoneMap, RigClip } from '../../schemas/v1/rig.schema';
import { stemOf } from './importPlan';
import { autoMapBones, filterTracksToBones, retargetClip, stripRootMotion, verticalAxisOf, type ClipLike, type Vec3Tuple } from '../../runtime/skeletalAnimation';

/** Cobertura mínima de ossos para um clipe entrar na biblioteca sem aceite manual (80%). */
export const COVERAGE_THRESHOLD = 0.8;

export type ClipSourceKind = 'embedded' | 'file';

/** Clipe candidato lido do arquivo do modelo (`embedded`) ou de um arquivo extra só de animação (`file`). */
export interface ClipCandidate {
  sourceKind: ClipSourceKind;
  /** Nome do arquivo extra (`Walk.fbx`); vazio para clipes embutidos. */
  fileName?: string;
  clip: ClipLike;
}

export interface LibraryClip {
  /** Estável na sessão (origem + nome do clipe na origem). */
  id: string;
  /** Nome na biblioteca (único; duplicados ganham sufixo). */
  name: string;
  sourceKind: ClipSourceKind;
  fileName?: string;
  /** Nome do clipe dentro do arquivo de origem. */
  sourceClip: string;
  duration: number;
  trackCount: number;
  /** 0..1: fração dos ossos do alvo que o clipe anima. */
  coverage: number;
  compatible: boolean;
  /** Entra na biblioteca. Incompatível só com aceite explícito do usuário. */
  accepted: boolean;
  loop: boolean;
  inPlace: boolean;
  renamedFrom?: string;
}

/** Ossos distintos que o clipe anima (trilhas `<osso>.<propriedade>`). */
export function clipBoneNames(clip: Pick<ClipLike, 'tracks'>): string[] {
  const names = new Set<string>();
  for (const t of clip.tracks) {
    const cut = t.name.lastIndexOf('.');
    if (cut > 0) names.add(t.name.slice(0, cut));
  }
  return [...names];
}

/** Fração dos ossos do clipe que existem, com o MESMO nome, no esqueleto do modelo (clipe do próprio rig ou rig não humanoide). */
export function skeletonCoverage(clipBones: readonly string[], modelBones: readonly string[]): number {
  if (clipBones.length === 0) return 0;
  const model = new Set(modelBones);
  return clipBones.filter((b) => model.has(b)).length / clipBones.length;
}

/**
 * Fração dos ossos do rig do alvo (os canônicos mapeados) que o clipe anima, depois de mapear os ossos do clipe para os 19
 * (retarget por nomes canônicos).
 */
export function retargetCoverage(clipBones: readonly string[], targetMap: BoneMap): number {
  const targets = (Object.keys(targetMap) as (keyof BoneMap)[]).filter((b) => targetMap[b]);
  if (targets.length === 0) return 0;
  const clipMap = autoMapBones(clipBones).map;
  return targets.filter((b) => !!clipMap[b]).length / targets.length;
}

export interface CoverageContext {
  /** Nomes de osso do esqueleto do modelo (`LoadedModel.boneNames`). */
  modelBones: readonly string[];
  /** Mapa de 19 ossos do modelo quando humanoide; `null` = sem retarget. */
  humanoidMap: BoneMap | null;
}

/** Cobertura do clipe: vale a melhor das duas leituras (mesmo esqueleto × retarget humanoide). */
export function clipCoverage(clipBones: readonly string[], ctx: CoverageContext): number {
  const same = skeletonCoverage(clipBones, ctx.modelBones);
  const retarget = ctx.humanoidMap ? retargetCoverage(clipBones, ctx.humanoidMap) : 0;
  return Math.round(Math.max(same, retarget) * 100) / 100;
}

/** Nomes genéricos que os exportadores dão ao clipe (Mixamo: `mixamo.com`): o nome útil é o do arquivo. */
const GENERIC_CLIP_NAME = /^(mixamo\.com|take[ _]?0*\d+|default[ _]?take|clip[ _]?\d*|animation[ _]?\d*|armature(action)?[ _.]?\d*)$/i;

/** Nome de exibição do clipe: o do arquivo (`Walking.glb` → `Walking`) quando o clipe tem nome genérico; senão o do próprio clipe. */
export function displayClipName(clipName: string, fileName?: string): string {
  const name = clipName.trim();
  if (fileName && (!name || GENERIC_CLIP_NAME.test(name))) return stemOf(fileName);
  return name || 'Clip';
}

/** Nome livre na biblioteca: `Walk`, `Walk_2`, `Walk_3`… (comparação sem diferenciar maiúsculas). */
export function uniqueClipName(name: string, taken: ReadonlySet<string>): { name: string; renamed: boolean } {
  const lower = new Set([...taken].map((n) => n.toLowerCase()));
  const base = name.trim() || 'Clip';
  if (!lower.has(base.toLowerCase())) return { name: base, renamed: base !== name };
  for (let i = 2; i < 10000; i++) {
    const candidate = `${base}_${i}`;
    if (!lower.has(candidate.toLowerCase())) return { name: candidate, renamed: true };
  }
  return { name: `${base}_${Date.now()}`, renamed: true };
}

export interface LibraryOptions extends CoverageContext {
  threshold?: number;
  /** Clipes in-place por padrão (regra de root motion com física). */
  inPlace?: boolean;
}

/**
 * Monta a biblioteca: nomes únicos (embutidos primeiro, depois os arquivos extras na ordem), cobertura por clipe e a regra do
 * limiar (`anim.incompatible_skeleton`): abaixo dele o clipe fica FORA (`accepted: false`) até o usuário aceitar.
 */
export function buildLibrary(candidates: readonly ClipCandidate[], options: LibraryOptions): LibraryClip[] {
  const threshold = options.threshold ?? COVERAGE_THRESHOLD;
  const taken = new Set<string>();
  const out: LibraryClip[] = [];
  candidates.forEach((c, index) => {
    const sourceName = c.clip.name || `Clip_${index}`;
    const baseName = c.sourceKind === 'file' ? displayClipName(sourceName, c.fileName) : sourceName;
    const unique = uniqueClipName(baseName, taken);
    taken.add(unique.name);
    const coverage = clipCoverage(clipBoneNames(c.clip), options);
    const compatible = coverage >= threshold;
    out.push({
      id: `${c.sourceKind}:${c.fileName ?? ''}:${sourceName}:${index}`,
      name: unique.name,
      sourceKind: c.sourceKind,
      fileName: c.fileName,
      sourceClip: sourceName,
      duration: c.clip.duration,
      trackCount: c.clip.tracks.length,
      coverage,
      compatible,
      accepted: compatible,
      loop: true,
      inPlace: options.inPlace ?? true,
      renamedFrom: unique.name !== baseName ? baseName : undefined,
    });
  });
  return out;
}

/** Códigos de diagnóstico da biblioteca (warning): clipes fora do limiar e nomes renomeados. */
export function libraryDiagnostics(library: readonly LibraryClip[]): { code: 'anim.incompatible_skeleton' | 'anim.duplicate_name'; severity: 'warning'; clip: string; message: string }[] {
  const out: { code: 'anim.incompatible_skeleton' | 'anim.duplicate_name'; severity: 'warning'; clip: string; message: string }[] = [];
  for (const c of library) {
    if (!c.compatible) {
      out.push({
        code: 'anim.incompatible_skeleton',
        severity: 'warning',
        clip: c.name,
        message: `O clipe "${c.name}" anima só ${Math.round(c.coverage * 100)}% dos ossos do modelo (mínimo ${Math.round(COVERAGE_THRESHOLD * 100)}%)${c.accepted ? ' — aceito manualmente' : ' — fora da biblioteca até o aceite'}.`,
      });
    }
    if (c.renamedFrom) out.push({ code: 'anim.duplicate_name', severity: 'warning', clip: c.name, message: `Nome repetido: "${c.renamedFrom}" virou "${c.name}".` });
  }
  return out;
}

/** Clipes que entram de fato na biblioteca (aceitos). */
export const acceptedClips = (library: readonly LibraryClip[]): LibraryClip[] => library.filter((c) => c.accepted);

/**
 * `RigConfig.clips`: SÓ referências. `model` = ref do modelo (clipes embutidos); `files` = ref de cada arquivo extra por nome.
 * Clipe cuja origem não resolve é omitido (nunca inventa referência).
 */
export function toRigClips(library: readonly LibraryClip[], refs: { model: ResourceRef; files: ReadonlyMap<string, ResourceRef> }): RigClip[] {
  const out: RigClip[] = [];
  for (const c of acceptedClips(library)) {
    const source = c.sourceKind === 'embedded' ? refs.model : refs.files.get(c.fileName ?? '');
    if (!source) continue;
    out.push({ name: c.name, source, sourceClip: c.sourceClip, loop: c.loop, inPlace: c.inPlace });
  }
  return out;
}

/** Propriedades do nó `AnimationPlayer` criado no import (filho do `MeshInstance`). Primeiro clipe da biblioteca como atual. */
export function buildAnimationPlayerProperties(clips: readonly RigClip[], rig: ResourceRef): Record<string, unknown> | null {
  if (clips.length === 0) return null;
  const first = clips[0];
  return { rigConfig: rig, currentAnimation: first.name, loop: first.loop ?? true, autoplay: false };
}

// ── Preparar o clipe para o modelo (retarget com escala do quadril, filtro de trilhas e in-place) ─────────

export interface PrepareContext {
  /** O modelo é humanoide (rig mapeado)? Só então há retarget. */
  humanoid: boolean;
  rigMap: BoneMap;
  /** Nomes dos ossos do esqueleto do modelo. */
  modelBones: readonly string[];
  /**
   * Posição LOCAL de cada osso no bind (por nome). Está no mesmo espaço dos valores das trilhas `<osso>.position`: a razão
   * `|alvo| ÷ |origem|` do `Hips` converte unidades/escalas, e a componente de maior valor do `Hips` é o eixo vertical (in-place).
   */
  targetBonePositions: Readonly<Record<string, Vec3Tuple>>;
  /** Idem, do esqueleto do arquivo de onde o clipe veio (só para `sourceKind: 'file'`). */
  sourceBonePositions?: Readonly<Record<string, Vec3Tuple>>;
}

export interface PreparedClip {
  clip: ClipLike;
  /** Trilhas descartadas por não haver o osso no esqueleto do modelo. */
  unmatched: string[];
  /** Razão aplicada à translação do `Hips` (1 = nenhuma). */
  hipRatio: number;
}

/**
 * Clipe pronto para o preview/import: clipe de arquivo extra num modelo humanoide passa por `retargetClip` (com a escala do
 * `Hips` entre os dois esqueletos); sem retarget, só se descartam as trilhas sem osso no modelo; clipe embutido já é do
 * próprio esqueleto. Depois, in-place (zera o deslocamento X/Z do `Hips`).
 */
export function prepareClip(clip: ClipLike, kind: ClipSourceKind, inPlace: boolean, ctx: PrepareContext): PreparedClip {
  const bones = new Set(ctx.modelBones);
  let like = clip;
  let unmatched: string[] = [];
  let hipRatio = 1;
  let sourceHipsBind: Vec3Tuple | undefined;
  if (kind === 'file') {
    if (ctx.humanoid) {
      const sourceMap = autoMapBones(clipBoneNames(clip)).map;
      const lengthOf = (p: Vec3Tuple | undefined) => (p ? Math.hypot(p[0], p[1], p[2]) : undefined);
      const sourceHip = lengthOf(sourceMap.Hips ? ctx.sourceBonePositions?.[sourceMap.Hips] : undefined);
      const targetHip = lengthOf(ctx.rigMap.Hips ? ctx.targetBonePositions[ctx.rigMap.Hips] : undefined);
      sourceHipsBind = sourceMap.Hips ? ctx.sourceBonePositions?.[sourceMap.Hips] : undefined;
      if (sourceHip && targetHip && sourceHip > 0 && targetHip > 0) hipRatio = targetHip / sourceHip;
      const r = retargetClip(clip, sourceMap, ctx.rigMap, { sourceHipHeight: sourceHip, targetHipHeight: targetHip, targetBones: bones });
      like = r.clip;
      unmatched = r.unmatched;
    } else {
      const f = filterTracksToBones(clip, bones);
      like = f.clip;
      unmatched = f.unmatched;
    }
  }
  if (inPlace) {
    // o eixo vertical vem do bind do Hips do esqueleto de ONDE o clipe veio (o do arquivo extra, ou o do próprio modelo)
    const bind = kind === 'file' ? sourceHipsBind : ctx.rigMap.Hips ? ctx.targetBonePositions[ctx.rigMap.Hips] : undefined;
    like = stripRootMotion(like, ctx.humanoid ? ctx.rigMap.Hips : null, verticalAxisOf(bind));
  }
  return { clip: { ...like, name: clip.name }, unmatched, hipRatio };
}
