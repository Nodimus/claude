import { describe, expect, it } from 'vitest';
import { DEFAULT_TRANSFORM_DRAFT, modelOffsetFor, nodeTransformFor, toModelImportSettings, type ImportTransformDraft } from './calibration';
import { editFromInfo } from './materials';
import { contentForFile, importModelAsset, type ImportDeps, type MaterialImageInput } from './importModelAsset';
import { reeditModelAsset, type ReeditDeps, type ReeditInput } from './reeditModelAsset';
import { detectManualChanges, draftFromSettings, editFromManifestMaterial, importedNodeValues, isMaterialTouched, modelClosureUris, modelPackage } from './modelLifecycle';
import { parseModelImportSettings } from '../../schemas/v1/modelImportSettings.schema';
import { parseModelMaterialManifest } from '../../schemas/v1/modelMaterialManifest.schema';
import { RigConfigSchema, emptyBoneMap, CANONICAL_BONES } from '../../schemas/v1/rig.schema';
import { CUBE, buildGlb, buildGltfWithExternalBin, toBuffer } from '../models/modelFixtures';
import { ModelCache } from '../models/modelCache';
import { ResourceRegistry } from '../resources/ResourceRegistry';
import { AssetPipeline, type PipelineIO } from '../resources/AssetPipeline';
import { BUILTIN_IMPORTERS, MODEL_SUPPORT_IMPORTERS } from '../resources/builtinImporters';
import { extractDependencies } from '../resources/dependencyExtractor';
import { deleteResourceWith, moveResourceWith, type FileLike, type ResourceCommit, type ResourceOpsContext } from '../resourceDeletion';
import { scanDependencyUris } from '../resources/resourceKinds';
import { createChangePropertyCommand } from '../commands/ChangePropertyCommand';
import { CommandManager } from '../commandManager';
import type { ModelMaterialInfo } from '../models/types';

const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
const draft = (over: Partial<ImportTransformDraft> = {}): ImportTransformDraft => ({ ...DEFAULT_TRANSFORM_DRAFT, ...over });
const bounds = { size: { x: 2, y: 4, z: 2 }, center: { x: 0.5, y: 3, z: -1 } };
const info = (over: Partial<ModelMaterialInfo> = {}): ModelMaterialInfo => ({ name: 'Casco', type: 'MeshStandardMaterial', color: '#808080', hasMap: false, transparent: false, uuid: 'u1', ...over });

// ── ambiente: projeto em memória + registry + pipeline + serviço de recursos ────────────────────────────────
type F = Record<string, any>;
function env() {
  const project = { files: {} as F };
  const io: PipelineIO = {
    files: () => project.files,
    write: (uri, content, meta) => {
      project.files[uri] = { ...(project.files[uri] ?? {}), path: uri, name: uri.split('/').pop(), isDirectory: false, content, size: content.length, updatedAt: 'x', ...meta };
    },
  };
  const registry = new ResourceRegistry();
  const pipeline = new AssetPipeline(registry, io);
  for (const importer of [...BUILTIN_IMPORTERS, ...MODEL_SUPPORT_IMPORTERS]) pipeline.registerImporter(importer);
  const added: { name: string; props: Record<string, any> }[] = [];
  const discarded: string[] = [];
  const discard = async (uri: string) => {
    discarded.push(uri);
    delete project.files[uri];
    registry.syncFromProject({ files: project.files } as never);
  };
  const deps: ImportDeps = {
    pipeline,
    existingUris: () => new Set(Object.keys(project.files)),
    refForUri: (uri) => registry.refForUri(uri),
    readContent: (uri) => project.files[uri]?.content,
    addNode: (_t, _p, name, props) => {
      added.push({ name, props });
      return { id: `node_${added.length}` };
    },
    discard,
  };
  const commits: { nodeId: string; changes: Record<string, any>; label: string }[] = [];
  const reeditDeps: ReeditDeps = {
    pipeline,
    existingUris: deps.existingUris,
    refForUri: deps.refForUri,
    readContent: deps.readContent,
    discard,
    resolveRef: (ref) => {
      const r = registry.resolve(ref as never);
      return r.status === 'resolved' ? { uri: r.entry.uri, kind: r.entry.kind } : null;
    },
    changeNode: (nodeId, changes, label) => void commits.push({ nodeId, changes, label }),
  };
  return { project, registry, pipeline, deps, reeditDeps, added, discarded, commits };
}

const images: MaterialImageInput[] = [
  { material: 'Casco', map: 'albedo', source: 'procedural', dataUrl: PNG, apply: true },
  { material: 'Vidro', map: 'albedo', source: 'embedded', dataUrl: PNG, apply: false },
];
const infos = [info(), info({ name: 'Vidro', uuid: 'u2', hasMap: true })];
const humanoidMap = () => Object.fromEntries(CANONICAL_BONES.map((b) => [b, `mixamorig:${b}`])) as ReturnType<typeof emptyBoneMap>;

async function importFixture(e: ReturnType<typeof env>, over: Partial<Parameters<typeof importModelAsset>[0]> = {}) {
  const edits = infos.map((i) => ({ ...editFromInfo(i), ...(i.name === 'Casco' ? { roughness: 0.9, pattern: 'wood' as const } : {}) }));
  const result = await importModelAsset(
    {
      fileName: 'Cube.glb',
      bytes: buildGlb(CUBE),
      siblings: [],
      draft: draft({ scale: 2, rotationDeg: { x: 0, y: 30, z: 0 } }),
      bounds,
      collision: { enabled: true, bodyMode: 'static', shape: 'auto' },
      parentId: 'root',
      materials: { edits, infos, images },
      rig: { bones: humanoidMap() },
      ...over,
    },
    e.deps
  );
  if (!result.ok) throw new Error(result.error);
  const node = e.added[0];
  return { result, node, model: node.props.model as { id: string } };
}

const settingsOf = (e: ReturnType<typeof env>, uri = 'res://models/Cube.glb') => parseModelImportSettings(e.project.files[uri].importSettings);

describe('AIS-38c — pacote do asset', () => {
  it('lista manifesto, rig e saídas sem repetir e sem incluir o próprio modelo; ref ausente vai para `missing`', async () => {
    const e = env();
    const { model } = await importFixture(e);
    const settings = settingsOf(e);
    const resolve = e.reeditDeps.resolveRef;
    const pkg = modelPackage(settings, resolve, model.id);
    const uris = pkg.items.map((i) => i.uri);
    expect(uris[0]).toMatch(/^res:\/\/textures\/Cube_material\.json$/i);
    expect(uris).toContain('res://materials/Cube_rig.json');
    expect(uris.some((u) => /^res:\/\/textures\/Cube\/\d+\.png$/i.test(u))).toBe(true);
    expect(new Set(uris).size).toBe(uris.length);
    expect(uris).not.toContain('res://models/Cube.glb');
    expect(pkg.items.map((i) => i.role)[0]).toBe('manifest');
    expect(modelPackage({ ...settings, outputs: [...settings.outputs, { id: 'res_gone' }] }, resolve).missing.map((r) => r.id)).toEqual(['res_gone']);
  });

  it('fecho de dependências inclui modelo + pacote + .bin do .gltf (contrato para Prefab e Publish)', async () => {
    const e = env();
    const { gltf, bin, binName } = buildGltfWithExternalBin(CUBE, 'cube.bin');
    await importModelAsset(
      {
        fileName: 'Cube.gltf',
        bytes: toBuffer(gltf),
        siblings: [{ rel: binName, bytes: bin }],
        draft: draft(),
        bounds,
        collision: { enabled: true, bodyMode: 'static', shape: 'auto' },
        parentId: 'root',
      },
      e.deps
    );
    const uri = 'res://models/Cube/Cube.gltf';
    const entry = e.project.files[uri] ? uri : Object.keys(e.project.files).find((u) => u.endsWith('.gltf'))!;
    const settings = settingsOf(e, entry);
    const pkg = modelPackage(settings, e.reeditDeps.resolveRef, e.project.files[entry].resourceId);
    const closure = modelClosureUris(entry, pkg);
    expect(closure[0]).toBe(entry);
    expect(closure.some((u) => u.endsWith('cube.bin'))).toBe(true);
    // o nó/prefab que referencia o modelo aponta o modelo; o fecho acrescenta o pacote
    const nodeJson = JSON.stringify({ nodes: { n1: { properties: { model: e.registry.refForUri(entry) } } } });
    const scanned = scanDependencyUris(nodeJson);
    expect(scanned).toEqual([entry]); // a varredura do nó devolve o modelo; o pacote vem do fecho (modelPackage)
    expect([...new Set([...scanned, ...closure])]).toEqual(closure); // o fecho já contém tudo que o nó referencia
    const deps = extractDependencies('scene', 'res://scenes/Main.scene.json', JSON.stringify({ nodes: { n1: { properties: { model: { ...e.registry.refForUri(entry), path: entry } } } } }));
    expect(deps.some((d) => d.targetUri === entry)).toBe(true);
  });

  it('duplicar o nó compartilha a referência do modelo (não duplica arquivo)', async () => {
    const e = env();
    const { node } = await importFixture(e);
    const clone = JSON.parse(JSON.stringify(node.props));
    expect(clone.model).toEqual(node.props.model);
    expect(Object.keys(e.project.files).filter((u) => u.startsWith('res://models/') && u.endsWith('.glb'))).toHaveLength(1);
  });
});

describe('AIS-38c — restauração de ModelImportSettings', () => {
  it('draftFromSettings é o inverso de toModelImportSettings (transform do nó idêntico)', () => {
    const cases: ImportTransformDraft[] = [
      draft(),
      draft({ scale: 0.01, zUpFlipped: true, centerXZ: true }),
      draft({ scale: 2, scaleAxes: { x: 1, y: 2, z: 1 }, rotationDeg: { x: 10, y: 40, z: 5 }, pivot: 'center' }),
      draft({ pivot: 'custom', pivotOffsetY: -0.7, rotationDeg: { x: 0, y: 25, z: 0 }, zUpFlipped: true, scale: 1.5 }),
    ];
    for (const d of cases) {
      const settings = toModelImportSettings(d, bounds);
      const restored = draftFromSettings(settings, d.position);
      const a = nodeTransformFor(d, bounds);
      const b = nodeTransformFor(restored, bounds);
      for (const k of ['rotation', 'scale', 'modelOffset'] as const) {
        expect(b[k].x).toBeCloseTo(a[k].x, 6);
        expect(b[k].y).toBeCloseTo(a[k].y, 6);
        expect(b[k].z).toBeCloseTo(a[k].z, 6);
      }
      expect(restored.pivot).toBe(d.pivot);
      expect(restored.zUpFlipped).toBe(d.zUpFlipped);
      if (d.pivot === 'custom') expect(restored.pivotOffsetY).toBeCloseTo(d.pivotOffsetY, 6);
      expect(modelOffsetFor(restored, bounds).y).toBeCloseTo(modelOffsetFor(d, bounds).y, 6);
    }
  });

  it('o import grava settings legíveis e o manifesto restaura os materiais', async () => {
    const e = env();
    await importFixture(e);
    const settings = settingsOf(e);
    expect(settings.rotationDeg.y).toBe(30);
    const manifestUri = e.reeditDeps.resolveRef(settings.materials!)!.uri;
    const parsed = parseModelMaterialManifest(e.project.files[manifestUri].content);
    expect(parsed.ok).toBe(true);
    if (!parsed.ok) return;
    const casco = editFromManifestMaterial(parsed.manifest.materials.find((m) => m.name === 'Casco')!);
    expect(casco.roughness).toBeCloseTo(0.9);
    expect(isMaterialTouched(casco, casco)).toBe(false);
    expect(isMaterialTouched({ ...casco, roughness: 0.2 }, casco)).toBe(true);
    expect(isMaterialTouched({ ...casco, transparent: false }, casco)).toBe(true);
  });
});

describe('AIS-38c — ajustes manuais no Inspector (C03)', () => {
  const settings = toModelImportSettings(draft({ scale: 2, rotationDeg: { x: 0, y: 30, z: 0 } }), bounds);
  const nodeFrom = (over: Record<string, any> = {}) => ({ ...importedNodeValues(settings), ...over });

  it('nó como o import gravou: sem diferença', () => {
    expect(detectManualChanges(nodeFrom(), settings)).toEqual([]);
  });
  it('rotação, escala e pivô alterados à mão são listados com os dois valores', () => {
    const changes = detectManualChanges(nodeFrom({ rotation: { x: 0, y: 90, z: 0 }, scale: { x: 3, y: 3, z: 3 } }), settings);
    expect(changes.map((c) => c.field)).toEqual(['rotation', 'scale']);
    expect(changes[0].imported).toBe('(0, 30, 0)');
    expect(changes[0].current).toBe('(0, 90, 0)');
  });
  it('posição nunca conta (não é ajuste de importação) e slots só dos materiais pedidos', () => {
    expect(detectManualChanges({ ...nodeFrom(), position: { x: 9, y: 9, z: 9 } }, settings)).toEqual([]);
    const baseline = [editFromInfo(info())];
    const props = nodeFrom({ materialSlots: { Casco: { roughness: 0.1 } } });
    expect(detectManualChanges(props, settings, [], baseline)).toEqual([]);
    const c = detectManualChanges(props, settings, ['Casco'], baseline);
    expect(c.map((x) => x.field)).toEqual(['materialSlots.Casco.roughness']);
  });
});

describe('AIS-38c — Editar importação (C02)', () => {
  const reeditInput = async (e: ReturnType<typeof env>, over: Partial<ReeditInput> = {}): Promise<ReeditInput> => {
    const { node, model } = await importFixture(e);
    const settings = settingsOf(e);
    const manifestUri = e.reeditDeps.resolveRef(settings.materials!)!.uri;
    const parsed = parseModelMaterialManifest(e.project.files[manifestUri].content);
    const baseline = parsed.ok ? parsed.manifest.materials.map(editFromManifestMaterial) : [];
    return {
      nodeId: 'node_1',
      nodeName: 'Cube',
      nodeProps: node.props,
      modelUri: 'res://models/Cube.glb',
      model: model as never,
      settings,
      draft: draftFromSettings(settings, node.props.position),
      bounds,
      materials: { edits: baseline.map((b) => ({ ...b })), baseline, infos, images: [] },
      ...over,
    };
  };

  it('sem alterações: mantém os mesmos arquivos e resourceIds e muda o nó em UM Command', async () => {
    const e = env();
    const before = Object.fromEntries(Object.entries(e.project.files).map(([u, f]) => [u, f.resourceId]));
    const input = await reeditInput(e);
    const files = Object.fromEntries(Object.entries(e.project.files).map(([u, f]) => [u, f.resourceId]));
    const r = await reeditModelAsset(input, e.reeditDeps);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.touchedMaterials).toEqual([]);
    expect(r.written).toEqual([]);
    expect(r.rigRewritten).toBe(false);
    expect(e.commits).toHaveLength(1);
    expect(e.commits[0].changes).toMatchObject({ rotation: { x: 0, y: 30, z: 0 }, scale: { x: 2, y: 2, z: 2 } });
    expect(Object.keys(e.project.files).sort()).toEqual(Object.keys(files).sort());
    for (const [uri, id] of Object.entries(files)) expect(e.project.files[uri].resourceId).toBe(id);
    expect(before).toBeDefined();
  });

  it('muda a calibração: settings novas no mesmo recurso e transform novo no nó', async () => {
    const e = env();
    const input = await reeditInput(e);
    const id = e.project.files['res://models/Cube.glb'].resourceId;
    const r = await reeditModelAsset({ ...input, draft: { ...input.draft, scale: 4, rotationDeg: { x: 0, y: 90, z: 0 } } }, e.reeditDeps);
    expect(r.ok).toBe(true);
    expect(e.project.files['res://models/Cube.glb'].resourceId).toBe(id);
    expect(settingsOf(e)).toMatchObject({ scale: 4, rotationDeg: { y: 90 } });
    expect(settingsOf(e).outputs.length).toBeGreaterThan(0); // pacote preservado
    expect(e.commits[0].changes.scale).toEqual({ x: 4, y: 4, z: 4 });
  });

  it('só os materiais tocados são regenerados; o manifesto e os PNGs dos demais ficam', async () => {
    const e = env();
    const input = await reeditInput(e);
    const settings = settingsOf(e);
    const manifestUri = e.reeditDeps.resolveRef(settings.materials!)!.uri;
    const manifestId = e.project.files[manifestUri].resourceId;
    const pngsBefore = Object.keys(e.project.files).filter((u) => /\.png$/i.test(u)).sort();
    const edits = input.materials!.edits.map((x) => (x.name === 'Vidro' ? { ...x, roughness: 0.15 } : x));
    const r = await reeditModelAsset(
      { ...input, materials: { ...input.materials!, edits, images: [{ material: 'Vidro', map: 'albedo', source: 'embedded', dataUrl: PNG, apply: true }] } },
      e.reeditDeps
    );
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.touchedMaterials).toEqual(['Vidro']);
    expect(e.project.files[manifestUri].resourceId).toBe(manifestId); // mesmo manifesto, mesmo id
    const parsed = parseModelMaterialManifest(e.project.files[manifestUri].content);
    expect(parsed.ok && parsed.manifest.materials.map((m) => m.name).sort()).toEqual(['Casco', 'Vidro']);
    expect(parsed.ok && parsed.manifest.materials.find((m) => m.name === 'Vidro')!.roughness).toBeCloseTo(0.15);
    const pngsAfter = Object.keys(e.project.files).filter((u) => /\.png$/i.test(u)).sort();
    for (const p of pngsBefore) expect(pngsAfter).toContain(p); // nenhum PNG existente foi sobrescrito/apagado
    expect(pngsAfter.length).toBe(pngsBefore.length + 1);
    expect(settingsOf(e).outputs.length).toBe(settings.outputs.length + 1);
    // slot de Vidro novo; o de Casco (não tocado) permanece como estava
    expect(e.commits[0].changes.materialSlots.Casco).toEqual(input.nodeProps.materialSlots.Casco);
    expect(e.commits[0].changes.materialSlots.Vidro).toMatchObject({ roughness: 0.15 });
  });

  it('rig: só regrava quando o mapeamento muda, no mesmo arquivo, preservando os clipes', async () => {
    const e = env();
    const input = await reeditInput(e);
    const rigUri = 'res://materials/Cube_rig.json';
    const rigId = e.project.files[rigUri].resourceId;
    // clipe existente (referência) que a reedição não pode perder
    const rig = JSON.parse(e.project.files[rigUri].content);
    rig.clips = [{ name: 'Walk', sourceClip: 'mixamo.com', loop: true }];
    e.project.files[rigUri] = { ...e.project.files[rigUri], content: JSON.stringify(rig) };

    const same = await reeditModelAsset({ ...input, rig: { bones: humanoidMap() } }, e.reeditDeps);
    expect(same.ok && same.rigRewritten).toBe(false);

    const changed = { ...humanoidMap(), Head: 'OutroOsso' };
    const r = await reeditModelAsset({ ...input, rig: { bones: changed } }, e.reeditDeps);
    expect(r.ok && r.rigRewritten).toBe(true);
    expect(e.project.files[rigUri].resourceId).toBe(rigId);
    const parsed = RigConfigSchema.parse(JSON.parse(e.project.files[rigUri].content));
    expect(parsed.bones.Head).toBe('OutroOsso');
    expect(parsed.clips.map((c) => c.name)).toEqual(['Walk']);
    expect(Object.keys(e.project.files).filter((u) => u.endsWith('_rig.json'))).toEqual([rigUri]);
  });

  it('falha ao gravar desfaz só o que a reedição criou e NÃO muda o nó', async () => {
    const e = env();
    const input = await reeditInput(e);
    const failing: ReeditDeps = {
      ...e.reeditDeps,
      pipeline: {
        import: async (req) => (req.uri.endsWith('_material.json') ? { ok: false, uri: req.uri, diagnostics: [{ code: 'material.manifest_failed', severity: 'error', message: 'falhou' }] } : e.pipeline.import(req)),
      },
    };
    const edits = input.materials!.edits.map((x) => (x.name === 'Vidro' ? { ...x, roughness: 0.15 } : x));
    const r = await reeditModelAsset({ ...input, materials: { ...input.materials!, edits, images: [{ material: 'Vidro', map: 'albedo', source: 'embedded', dataUrl: PNG, apply: true }] } }, failing);
    expect(r.ok).toBe(false);
    expect(e.commits).toHaveLength(0);
    expect(e.discarded.some((u) => u.endsWith('.png'))).toBe(true);
    // o PNG novo saiu; os existentes ficaram
    expect(Object.keys(e.project.files).filter((u) => /\.png$/i.test(u)).length).toBeGreaterThan(0);
  });

  it('Undo/Redo do Command devolve e reaplica as propriedades do nó', () => {
    const props: Record<string, any> = { rotation: { x: 0, y: 30, z: 0 }, scale: { x: 2, y: 2, z: 2 }, modelOffset: { x: 0, y: 0, z: 0 } };
    const target = {
      getNode: () => ({ properties: props }),
      updateNodeProperties: (_id: string, next: Record<string, any>) => {
        for (const k of Object.keys(props)) delete props[k];
        Object.assign(props, next);
      },
    };
    const mgr = new CommandManager();
    const cmd = createChangePropertyCommand({ target: target as never, nodeId: 'n', changes: { scale: { x: 4, y: 4, z: 4 }, rotation: { x: 0, y: 90, z: 0 } }, label: 'Editar importação' });
    mgr.pushCommand(cmd!);
    expect(props.scale.x).toBe(4);
    mgr.undo();
    expect(props.scale.x).toBe(2);
    expect(props.rotation.y).toBe(30);
    mgr.redo();
    expect(props.scale.x).toBe(4);
  });
});

describe('AIS-38c — Reimportar e cache (C04)', () => {
  it('reimportar preserva o resourceId, mantém as settings e muda o hash quando o conteúdo muda', async () => {
    const e = env();
    const { model } = await importFixture(e);
    const entry = e.registry.getByUri('res://models/Cube.glb')!;
    const hashBefore = entry.contentHash;
    const r = await e.pipeline.reimport(model.id);
    expect(r.ok && r.resourceId).toBe(model.id);
    expect(settingsOf(e)).toMatchObject({ scale: 2 });
    const next = contentForFile('Cube.glb', buildGlb({ ...CUBE, positions: CUBE.positions.map((p) => p * 2) }));
    const r2 = await e.pipeline.reimport(model.id, { content: next });
    expect(r2.ok).toBe(true);
    expect(e.registry.getByUri('res://models/Cube.glb')!.contentHash).not.toBe(hashBefore);
    expect(e.registry.getByUri('res://models/Cube.glb')!.resourceId).toBe(model.id);
  });

  it('falha de reimport mantém a última versão válida e marca o recurso com diagnóstico', async () => {
    const e = env();
    const { model } = await importFixture(e);
    const good = e.project.files['res://models/Cube.glb'].content;
    const r = await e.pipeline.reimport(model.id, { content: 'data:model/gltf-binary;base64,AAAA' });
    expect(r.ok).toBe(false);
    expect(e.project.files['res://models/Cube.glb'].content).toBe(good);
    expect(e.registry.get(model.id)!.status).not.toBe('ok');
  });

  it('o cache serve o modelo até a invalidação; depois recarrega (viewport atualiza sem reabrir a cena)', async () => {
    const cache = new ModelCache();
    let loads = 0;
    const load = async () => {
      loads++;
      return { root: { traverse: () => undefined } } as never;
    };
    const a = cache.acquire('res_a', 'h1', load);
    cache.acquire('res_a', 'h1', load).release();
    expect(loads).toBe(1);
    cache.invalidate('res_a');
    const b = cache.acquire('res_a', 'h1', load);
    expect(loads).toBe(2);
    a.release();
    b.release();
  });
});

describe('AIS-38c — mover, renomear e excluir (C05, C06)', () => {
  function ops(e: ReturnType<typeof env>) {
    const project = e.project as { files: Record<string, FileLike> };
    const commits: ResourceCommit[] = [];
    const ctx: ResourceOpsContext = {
      registry: e.registry,
      now: () => 't',
      activeScene: () => null,
      io: {
        files: () => project.files,
        commit: (change) => {
          commits.push(change);
          const next = { ...project.files };
          for (const p of change.remove) delete next[p];
          for (const [p, f] of Object.entries(change.upsert)) next[p] = f;
          project.files = next;
          e.registry.syncFromProject(project as never);
        },
      },
    };
    return { ctx, commits };
  }

  it('renomear o .glb preserva o resourceId e o pacote continua resolvendo', async () => {
    const e = env();
    const { model } = await importFixture(e);
    const { ctx } = ops(e);
    const result = await moveResourceWith(ctx, { path: 'res://models/Cube.glb' }, 'res://models/Caixa.glb', { confirmed: true });
    expect(result.ok).toBe(true);
    expect(e.registry.getByUri('res://models/Caixa.glb')!.resourceId).toBe(model.id);
    const resolved = e.registry.resolve({ id: model.id, path: 'res://models/Cube.glb' } as never);
    expect(resolved.status).toBe('resolved');
    const settings = parseModelImportSettings(e.registry.getByUri('res://models/Caixa.glb')!.importSettings);
    const pkg = modelPackage(settings, e.reeditDeps.resolveRef, model.id);
    expect(pkg.missing).toEqual([]);
    expect(pkg.items.length).toBeGreaterThan(0);
  });

  it('mover a pasta res://models/ preserva ids; arquivo ausente vira unresolved sem exceção', async () => {
    const e = env();
    const { model } = await importFixture(e);
    const { ctx } = ops(e);
    const moved = await moveResourceWith(ctx, { path: 'res://models/' }, 'res://modelos/', { confirmed: true });
    expect(moved.ok).toBe(true);
    expect(e.registry.getByUri('res://modelos/Cube.glb')!.resourceId).toBe(model.id);
    // referência a um recurso que não existe
    expect(() => e.registry.resolve({ id: 'res_inexistente', path: 'res://models/nada.glb' } as never)).not.toThrow();
    expect(e.registry.resolve({ id: 'res_inexistente', path: 'res://models/nada.glb' } as never).status).toBe('unresolved');
  });

  it('excluir o modelo com o pacote: cada arquivo é listado e só some o que foi confirmado; excluir só o nó não apaga arquivos', async () => {
    const e = env();
    const { model } = await importFixture(e);
    const settings = settingsOf(e);
    const pkg = modelPackage(settings, e.reeditDeps.resolveRef, model.id);
    const { ctx } = ops(e);
    const before = Object.keys(e.project.files).sort();

    // 1) excluir só o modelo: o pacote fica (nada some em silêncio)
    const lone = await deleteResourceWith(ctx, { path: 'res://models/Cube.glb' }, { confirmed: true, decision: { kind: 'unresolve' } });
    expect(lone.ok).toBe(true);
    const after = Object.keys(e.project.files).sort();
    expect(after).toEqual(before.filter((u) => u !== 'res://models/Cube.glb'));
    for (const item of pkg.items) expect(e.project.files[item.uri]).toBeDefined();

    // 2) o usuário aceita o pacote: cada item é excluído por `deleteResource`
    for (const item of pkg.items) {
      const r = await deleteResourceWith(ctx, { path: item.uri }, { confirmed: true, decision: { kind: 'unresolve' } });
      expect(r.ok).toBe(true);
    }
    for (const item of pkg.items) expect(e.project.files[item.uri]).toBeUndefined();
  });
});

describe('AIS-38c — roteiro de integração 3.6 (C08)', () => {
  it('importar → salvar/reabrir (reconstruir do conteúdo persistido) → mover → editar importação → reimportar → excluir com pacote', async () => {
    // importar
    const e = env();
    const { node, model } = await importFixture(e);
    expect(node.props.model.id).toBe(model.id);

    // salvar + reabrir: um registry novo sobre os mesmos arquivos reconhece o modelo e o pacote pelos mesmos ids
    const reopened = new ResourceRegistry();
    reopened.syncFromProject({ files: e.project.files } as never);
    const entry = reopened.getByUri('res://models/Cube.glb')!;
    expect(entry.resourceId).toBe(model.id);
    expect(parseModelImportSettings(entry.importSettings).outputs.length).toBeGreaterThan(0);

    // mover/renomear
    const project = e.project as { files: Record<string, FileLike> };
    const ctx: ResourceOpsContext = {
      registry: e.registry,
      activeScene: () => null,
      io: {
        files: () => project.files,
        commit: (c) => {
          const next = { ...project.files };
          for (const p of c.remove) delete next[p];
          for (const [p, f] of Object.entries(c.upsert)) next[p] = f;
          project.files = next;
          e.registry.syncFromProject(project as never);
        },
      },
    };
    expect((await moveResourceWith(ctx, { path: 'res://models/Cube.glb' }, 'res://models/Cubo.glb', { confirmed: true })).ok).toBe(true);
    const uri = 'res://models/Cubo.glb';
    expect(e.registry.getByUri(uri)!.resourceId).toBe(model.id);

    // editar importação (calibração nova) → um Command no nó
    const settings = parseModelImportSettings(e.registry.getByUri(uri)!.importSettings);
    const r = await reeditModelAsset(
      { nodeId: 'node_1', nodeName: 'Cube', nodeProps: node.props, modelUri: uri, model: model as never, settings, draft: { ...draftFromSettings(settings), scale: 3 }, bounds },
      e.reeditDeps
    );
    expect(r.ok).toBe(true);
    expect(e.commits).toHaveLength(1);
    expect(e.commits[0].changes.scale).toEqual({ x: 3, y: 3, z: 3 });

    // reimportar
    expect((await e.pipeline.reimport(model.id)).ok).toBe(true);
    expect(parseModelImportSettings(e.registry.getByUri(uri)!.importSettings).scale).toBe(3);

    // excluir com pacote
    const pkg = modelPackage(parseModelImportSettings(e.registry.getByUri(uri)!.importSettings), e.reeditDeps.resolveRef, model.id);
    for (const path of [uri, ...pkg.items.map((i) => i.uri)]) {
      expect((await deleteResourceWith(ctx, { path }, { confirmed: true, decision: { kind: 'unresolve' } })).ok).toBe(true);
    }
    expect(Object.keys(e.project.files).filter((u) => /^res:\/\/(models|textures|materials)\//.test(u))).toEqual([]);
  });
});
