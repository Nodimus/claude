/**
 * AIS-38c — "Editar importação…": reaplica ajustes a um modelo JÁ importado. Arquivos gerados (settings do modelo, manifesto,
 * PNGs, rig) são regravados pelo `AssetPipeline` nos MESMOS caminhos (mesmos `resourceId`); o nó recebe as propriedades novas
 * num ÚNICO Command (`changeNode`). Arquivo em `res://` não é Command: o Undo desfaz o nó e mantém os arquivos (como no import).
 *
 * Política de materiais: só os materiais que o usuário mexeu na aba Texture ("tocados") são regenerados; os demais mantêm o
 * slot do nó e a entrada do manifesto como estão (o padrão procedural não é restaurável do manifesto).
 * Política de rig: só regrava se o mapeamento de ossos mudou; os clipes (`RigConfig.clips`) são PRESERVADOS (a biblioteca de
 * clipes não é reeditada aqui).
 */
import type { ResourceRef } from '../../types/node';
import type { LocalBounds } from '../physics/bounds';
import { ModelImportSettingsSchema, type ModelImportSettings } from '../../schemas/v1/modelImportSettings.schema';
import { parseModelMaterialManifest, type ManifestMaterial } from '../../schemas/v1/modelMaterialManifest.schema';
import { RigConfigSchema, type BoneMap } from '../../schemas/v1/rig.schema';
import { validateBoneMap } from '../../runtime/skeletalAnimation';
import { collectMaterialSlots, type MaterialEdit } from './materials';
import { nodeTransformFor, toModelImportSettings, type ImportTransformDraft } from './calibration';
import { extractMaterials, writeRig, TEXTURES_DIR_URI, type ImportDeps, type MaterialImageInput } from './importModelAsset';
import { isMaterialTouched, type ResolvedRef } from './modelLifecycle';

export interface ReeditDeps {
  pipeline: ImportDeps['pipeline'];
  existingUris: ImportDeps['existingUris'];
  refForUri: ImportDeps['refForUri'];
  readContent: ImportDeps['readContent'];
  discard: ImportDeps['discard'];
  resolveRef(ref: ResourceRef): ResolvedRef | null;
  /** UM Command com as propriedades do nó. */
  changeNode(nodeId: string, changes: Record<string, any>, label: string): void;
}

export interface ReeditInput {
  nodeId: string;
  nodeName: string;
  nodeProps: Record<string, any>;
  modelUri: string;
  model: ResourceRef;
  /** Settings gravadas no import (a base da reedição). */
  settings: ModelImportSettings;
  draft: ImportTransformDraft;
  bounds: LocalBounds | null;
  materials?: {
    /** Rascunho de TODOS os materiais do modal. */
    edits: MaterialEdit[];
    /** O que foi restaurado do manifesto (para saber o que foi tocado). */
    baseline: MaterialEdit[];
    infos: Parameters<typeof collectMaterialSlots>[1];
    /** Imagens a extrair, já só dos materiais tocados. */
    images: MaterialImageInput[];
  };
  /** Mapeamento de ossos do modal; só vale se humanoide. */
  rig?: { bones: BoneMap };
}

export type ReeditOutcome =
  | { ok: true; written: string[]; touchedMaterials: string[]; rigRewritten: boolean; nodeChanges: Record<string, any> }
  | { ok: false; code: string; error: string };

const nameOf = (uri: string) => uri.split('/').pop() ?? uri;

export async function reeditModelAsset(input: ReeditInput, deps: ReeditDeps): Promise<ReeditOutcome> {
  const written: string[] = [];
  const importDeps = deps as unknown as ImportDeps;
  const fail = async (code: string, error: string): Promise<ReeditOutcome> => {
    for (const uri of [...written].reverse()) {
      try {
        await deps.discard(uri);
      } catch {
        /* melhor esforço */
      }
    }
    return { ok: false, code, error };
  };

  const content = deps.readContent(input.modelUri);
  if (content === undefined) return fail('model.unresolved', `${input.modelUri} não tem conteúdo para reeditar.`);

  // 1) settings do modelo: calibração nova; manifesto, rig e pacote atuais preservados
  let settings = ModelImportSettingsSchema.parse({
    ...toModelImportSettings(input.draft, input.bounds, { outputs: input.settings.outputs, materials: input.settings.materials, rig: input.settings.rig }),
  });
  const main = await deps.pipeline.import({ uri: input.modelUri, content, settings: settings as unknown as Record<string, unknown> });
  if (!main.ok) return fail(main.diagnostics[0]?.code ?? 'import.process_failed', main.diagnostics[0]?.message ?? `Falha ao atualizar ${input.modelUri}.`);

  // 2) materiais tocados → PNGs novos (numeração depois dos existentes) + manifesto regravado no mesmo caminho
  let slots: Record<string, any> | undefined = input.nodeProps.materialSlots && typeof input.nodeProps.materialSlots === 'object' ? { ...input.nodeProps.materialSlots } : undefined;
  let slotsChanged = false;
  const touched = (input.materials?.edits ?? []).filter((e) => isMaterialTouched(e, input.materials!.baseline.find((b) => b.name === e.name)));
  if (input.materials && touched.length > 0) {
    const oldManifestRef = input.settings.materials;
    const oldManifestUri = oldManifestRef ? deps.resolveRef(oldManifestRef)?.uri : undefined;
    let keep: ManifestMaterial[] = [];
    let stem: string | undefined;
    let firstIndex = 1;
    if (oldManifestUri) {
      const parsed = parseModelMaterialManifest(deps.readContent(oldManifestUri) ?? '');
      if (parsed.ok) keep = parsed.manifest.materials;
      const m = new RegExp(`^${TEXTURES_DIR_URI}(.+)_material\\.json$`, 'i').exec(oldManifestUri);
      stem = m?.[1];
      if (stem) {
        const folder = `${TEXTURES_DIR_URI}${stem}/`.toLowerCase();
        let max = 0;
        for (const uri of deps.existingUris()) {
          const n = uri.toLowerCase().startsWith(folder) ? /\/(\d+)\.png$/i.exec(uri)?.[1] : undefined;
          if (n) max = Math.max(max, Number(n));
        }
        firstIndex = max + 1;
      }
    }
    const extracted = await extractMaterials({ edits: touched, infos: input.materials.infos as never, images: input.materials.images }, input.modelUri, input.model, settings, content, importDeps, written, input.settings.outputs, { stem, firstIndex, keep });
    if (!extracted.ok) return fail(extracted.code, extracted.error);
    settings = extracted.settings;
    slots = { ...(slots ?? {}) };
    for (const edit of touched) delete slots[edit.name];
    Object.assign(slots, extracted.materialSlots);
    slotsChanged = true;
  }

  // 3) rig: só regrava se o mapeamento de ossos mudou; os clipes existentes são preservados
  let rigRewritten = false;
  if (input.rig && validateBoneMap(input.rig.bones).humanoid) {
    const rigRef = input.settings.rig;
    const rigUri = rigRef ? deps.resolveRef(rigRef)?.uri : undefined;
    const old = rigUri ? RigConfigSchema.safeParse(safeJson(deps.readContent(rigUri))) : null;
    const same = old?.success && JSON.stringify(old.data.bones) === JSON.stringify(input.rig.bones);
    if (!same) {
      const clips = old?.success ? old.data.clips : [];
      const rigged = await writeRig(input.rig.bones, clips, input.modelUri, true, input.model, settings, content, importDeps, written, rigUri);
      if (!rigged.ok) return fail(rigged.code, rigged.error);
      rigRewritten = true;
    }
  }

  // 4) o nó: UM Command (posição, física e filhos não mudam)
  const t = nodeTransformFor(input.draft, input.bounds);
  const nodeChanges: Record<string, any> = { rotation: t.rotation, scale: t.scale, modelOffset: t.modelOffset };
  if (slotsChanged) nodeChanges.materialSlots = slots && Object.keys(slots).length > 0 ? slots : undefined;
  deps.changeNode(input.nodeId, nodeChanges, `Editar importação ${input.nodeName || nameOf(input.modelUri)}`);

  return { ok: true, written, touchedMaterials: touched.map((e) => e.name), rigRewritten, nodeChanges };
}

function safeJson(text: string | undefined): unknown {
  try {
    return text ? JSON.parse(text) : undefined;
  } catch {
    return undefined;
  }
}
