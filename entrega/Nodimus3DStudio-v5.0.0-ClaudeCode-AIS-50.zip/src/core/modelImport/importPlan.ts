/**
 * AIS-33 — planejamento puro da importação: destino em `res://models/`, pai do nó, bloco de colisão (decisão 26) e
 * propriedades do `MeshInstance`. Nada aqui grava: quem grava é `importModelAsset` (via `AssetPipeline`).
 */
import type { MaterialOverride } from '../../types/material';
import type { PhysicsBodyMode, PhysicsConfig, PhysicsShape, ResourceRef } from '../../types/node';
import { NODE_DEFINITIONS } from '../../nodes/registry';
import { applyPhysicsPatch, defaultPhysicsConfig } from '../physics/physicsConfig';
import { resolveRelativeUri } from '../models/modelBytes';
import { isModelExt, type ModelExt } from '../models/types';
import type { NodeTransform } from './calibration';

export const MODELS_DIR = 'res://models/';

export interface PickedFile {
  name: string;
  bytes: ArrayBuffer;
}

export interface ModelSelection {
  main: { name: string; ext: ModelExt; bytes: ArrayBuffer } | null;
  /** Só um `.gltf` leva dependências (`.bin`, imagens); nos outros formatos os demais arquivos são ignorados. */
  siblings: { rel: string; bytes: ArrayBuffer }[];
  ignored: string[];
}

/** Do que o usuário escolheu/soltou: o primeiro arquivo 3D é o modelo; com `.gltf`, os demais são as dependências dele. */
export function selectModelFiles(files: readonly PickedFile[]): ModelSelection {
  const mainFile = files.find((f) => isModelExt(extOf(f.name)));
  if (!mainFile) return { main: null, siblings: [], ignored: files.map((f) => f.name) };
  const ext = extOf(mainFile.name) as ModelExt;
  const others = files.filter((f) => f !== mainFile);
  if (ext !== 'gltf') return { main: { name: mainFile.name, ext, bytes: mainFile.bytes }, siblings: [], ignored: others.map((f) => f.name) };
  return {
    main: { name: mainFile.name, ext, bytes: mainFile.bytes },
    siblings: others.filter((f) => !isModelExt(extOf(f.name))).map((f) => ({ rel: f.name, bytes: f.bytes })),
    ignored: others.filter((f) => isModelExt(extOf(f.name))).map((f) => f.name),
  };
}

/** Nome sem extensão: `Hero.Final.glb` → `Hero.Final`. */
export const stemOf = (fileName: string): string => {
  const base = fileName.split(/[\\/]/).pop() ?? fileName;
  const dot = base.lastIndexOf('.');
  return dot > 0 ? base.slice(0, dot) : base;
};

export const extOf = (fileName: string): string => {
  const base = fileName.split(/[\\/]/).pop() ?? fileName;
  const dot = base.lastIndexOf('.');
  return dot > 0 ? base.slice(dot + 1).toLowerCase() : '';
};

/** Nome seguro para arquivo/pasta de `res://`: sem espaços nem caracteres de caminho. Nunca vazio. */
export function sanitizeAssetName(stem: string): string {
  const clean = stem.trim().replace(/[\\/:*?"<>|#%]+/g, '_').replace(/\s+/g, '_').replace(/^\.+/, '').slice(0, 80);
  return clean || 'model';
}

export interface ImportFile {
  /** Caminho relativo ao modelo (`hero.gltf`, `tex/a.png`). */
  rel: string;
  bytes: ArrayBuffer;
}

export interface DestinationPlan {
  /** O arquivo já está em `res://models/`: não é copiado de novo (só as `importSettings` são atualizadas). */
  reuse: boolean;
  mainUri: string;
  /** Dependências a gravar antes do arquivo principal (`.gltf`). */
  siblingUris: { rel: string; uri: string }[];
  /** Pasta própria do asset (`.gltf` com dependências); `null` para arquivo único. */
  folderUri: string | null;
}

const taken = (existing: ReadonlySet<string>, uri: string, prefixCheck = false): boolean => {
  const lower = uri.toLowerCase();
  for (const e of existing) {
    const l = e.toLowerCase();
    if (l === lower || (prefixCheck && l.startsWith(lower))) return true;
  }
  return false;
};

/** Nome livre: `hero`, `hero_2`, `hero_3`… */
export function uniqueStem(stem: string, ext: string, existing: ReadonlySet<string>, withFolder: boolean): string {
  const candidate = (s: string) => (withFolder ? `${MODELS_DIR}${s}/` : `${MODELS_DIR}${s}.${ext}`);
  let name = stem;
  for (let i = 2; taken(existing, candidate(name), withFolder) && i < 10000; i++) name = `${stem}_${i}`;
  return name;
}

/**
 * Onde o modelo vai ficar. Arquivo de `res://models/` é REUTILIZADO (sem duplicar). Arquivo único →
 * `res://models/<asset>.<ext>`; `.gltf` com dependências → pasta `res://models/<asset>/`.
 */
export function planModelDestination(input: { fileName: string; siblings: ImportFile[]; sourceUri?: string }, existingUris: ReadonlySet<string>): DestinationPlan {
  if (input.sourceUri && input.sourceUri.startsWith(MODELS_DIR) && existingUris.has(input.sourceUri)) {
    return { reuse: true, mainUri: input.sourceUri, siblingUris: [], folderUri: null };
  }
  const ext = extOf(input.fileName);
  const stem = sanitizeAssetName(stemOf(input.fileName));
  const withFolder = ext === 'gltf' && input.siblings.length > 0;
  const unique = uniqueStem(stem, ext, existingUris, withFolder);
  if (!withFolder) return { reuse: false, mainUri: `${MODELS_DIR}${unique}.${ext}`, siblingUris: [], folderUri: null };
  const folder = `${MODELS_DIR}${unique}/`;
  return {
    reuse: false,
    mainUri: `${folder}${unique}.${ext}`,
    folderUri: folder,
    // dependências mantêm o caminho relativo (sem sair da pasta do asset)
    siblingUris: input.siblings.map((s) => ({ rel: s.rel, uri: resolveRelativeUri(`${folder}${unique}.${ext}`, s.rel.replace(/^(\.\.\/)+/, '')) })),
  };
}

/** Pai do novo nó: o nó ativo se for 3D; senão a raiz da cena. */
export function chooseParentId(nodes: Record<string, { type: string }>, activeId: string | null | undefined, rootId: string): string {
  if (activeId && nodes[activeId]) {
    const meta = (NODE_DEFINITIONS as Record<string, { is3D: boolean }>)[nodes[activeId].type];
    if (meta?.is3D) return activeId;
  }
  return rootId;
}

export interface CollisionOptions {
  enabled: boolean;
  bodyMode: PhysicsBodyMode;
  shape: PhysicsShape;
}

export const DEFAULT_COLLISION_OPTIONS: CollisionOptions = { enabled: true, bodyMode: 'static', shape: 'auto' };

/** Bloco `physics` do nó importado, ou `undefined` (desmarcado = nenhum bloco). "Malha exata" só em estático; nunca `dynamic` por padrão. */
export function buildPhysicsBlock(options: CollisionOptions): PhysicsConfig | undefined {
  if (!options.enabled) return undefined;
  return applyPhysicsPatch(defaultPhysicsConfig(), { bodyMode: options.bodyMode, shape: options.shape });
}

/** Opções de forma válidas para o tipo de corpo ("Malha exata" só com "Sólido parado"). */
export function allowedShapes(bodyMode: PhysicsBodyMode): PhysicsShape[] {
  const all: PhysicsShape[] = ['auto', 'box', 'sphere', 'capsule', 'cylinder', 'mesh'];
  return bodyMode === 'static' ? all : all.filter((s) => s !== 'mesh');
}

/** Propriedades do `MeshInstance` criado: referência por identidade, nunca base64 nem caminho solto. */
export function buildMeshInstanceProperties(input: { model: ResourceRef; transform: NodeTransform; physics?: PhysicsConfig; materialSlots?: Record<string, MaterialOverride> }): Record<string, any> {
  const { transform, model, physics, materialSlots } = input;
  const props: Record<string, any> = {
    position: { ...transform.position },
    rotation: { ...transform.rotation },
    scale: { ...transform.scale },
    model,
    modelOffset: { ...transform.modelOffset },
  };
  if (physics) props.physics = physics;
  if (materialSlots && Object.keys(materialSlots).length > 0) props.materialSlots = materialSlots; // AIS-35 (decisão 3.2)
  return props;
}
