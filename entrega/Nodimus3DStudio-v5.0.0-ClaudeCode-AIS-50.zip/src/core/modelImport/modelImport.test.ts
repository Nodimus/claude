import { describe, expect, it, vi } from 'vitest';
import {
  DEFAULT_TRANSFORM_DRAFT,
  centerToOrigin,
  effectiveRotationDeg,
  isTransformDirty,
  nativeHeight,
  nodeTransformFor,
  pivotCompensationY,
  rotate90,
  scaleToHeight,
  toModelImportSettings,
  type ImportTransformDraft,
} from './calibration';
import {
  allowedShapes,
  buildMeshInstanceProperties,
  buildPhysicsBlock,
  chooseParentId,
  extOf,
  planModelDestination,
  sanitizeAssetName,
  stemOf,
  uniqueStem,
} from './importPlan';
import { IMPORT_WITH_COLLISION_KEY, readImportWithCollision, writeImportWithCollision } from './importPrefs';
import { contentForFile, importModelAsset, type ImportDeps } from './importModelAsset';
import { CUBE, buildGlb, buildGltfWithExternalBin, toBuffer } from '../models/modelFixtures';
import { ResourceRegistry } from '../resources/ResourceRegistry';
import { AssetPipeline, type PipelineIO } from '../resources/AssetPipeline';
import { BUILTIN_IMPORTERS, MODEL_SUPPORT_IMPORTERS } from '../resources/builtinImporters';
import { extractDependencies } from '../resources/dependencyExtractor';

const bounds = { size: { x: 2, y: 4, z: 2 }, center: { x: 0, y: 3, z: 0 } }; // base em y=1, topo em y=5
const draft = (over: Partial<ImportTransformDraft> = {}): ImportTransformDraft => ({ ...DEFAULT_TRANSFORM_DRAFT, ...over });

describe('calibração (pura)', () => {
  it('compensação de pivô: base, centro, topo e personalizado', () => {
    expect(pivotCompensationY(bounds, 'bottom')).toBe(-1);
    expect(pivotCompensationY(bounds, 'center')).toBe(-3);
    expect(pivotCompensationY(bounds, 'top')).toBe(-5);
    expect(pivotCompensationY(bounds, 'custom', 0.5)).toBe(0.5);
    expect(pivotCompensationY(null, 'bottom')).toBe(0);
  });
  it('escala para a altura humana de 1,80 m', () => {
    expect(nativeHeight(bounds)).toBe(4);
    expect(scaleToHeight(4)).toBe(0.45);
    expect(scaleToHeight(1.8)).toBe(1);
    expect(scaleToHeight(0)).toBe(1);
    expect(scaleToHeight(Number.NaN)).toBe(1);
  });
  it('rotações, Z-up e centralizar origem', () => {
    let d = rotate90(draft(), 'x');
    d = rotate90(rotate90(rotate90(d, 'x'), 'x'), 'x');
    expect(d.rotationDeg.x).toBe(0); // 4 × 90 = 360 → 0
    expect(effectiveRotationDeg(draft({ zUpFlipped: true }))).toEqual({ x: -90, y: 0, z: 0 });
    expect(effectiveRotationDeg(draft({ rotationDeg: { x: 90, y: 0, z: 0 }, zUpFlipped: true })).x).toBe(0);
    expect(centerToOrigin(draft({ position: { x: 1, y: 2, z: 3 }, pivot: 'top' }))).toMatchObject({ position: { x: 0, y: 0, z: 0 }, pivot: 'bottom' });
  });
  it('rascunho sujo só quando difere do padrão', () => {
    expect(isTransformDirty(draft())).toBe(false);
    expect(isTransformDirty(draft({ scale: 2 }))).toBe(true);
    expect(isTransformDirty(draft({ zUpFlipped: true }))).toBe(true);
    expect(isTransformDirty(draft({ position: { x: 0, y: 0, z: 1 } }))).toBe(true);
  });
  it('o transform do nó é o que o preview mostra; settings validadas pelo schema', () => {
    const t = nodeTransformFor(draft({ scale: 2, position: { x: 1, y: 0, z: 0 }, zUpFlipped: true }), bounds);
    expect(t).toMatchObject({ position: { x: 1, y: 0, z: 0 }, rotation: { x: -90, y: 0, z: 0 }, scale: { x: 2, y: 2, z: 2 } });
    // AIS-34: com Z-up a caixa é recalculada depois de girar (base em y'=-1) → o offset (espaço do modelo) vai para +Z
    expect(t.modelOffset.x).toBeCloseTo(0, 6);
    expect(t.modelOffset.y).toBeCloseTo(0, 6);
    expect(t.modelOffset.z).toBeCloseTo(1, 6);
    expect(nodeTransformFor(draft({ scale: 2 }), bounds).modelOffset).toEqual({ x: 0, y: -1, z: 0 }); // sem rotação: igual ao AIS-33
    const s = toModelImportSettings(draft({ scale: 2, pivot: 'center', zUpFlipped: true }), bounds);
    expect(s).toMatchObject({ schemaVersion: 1, upAxis: 'z', scale: 2, pivot: 'center', centerXZ: false, scaleAxes: { x: 1, y: 1, z: 1 }, outputs: [] });
    expect(s.pivotOffset.y).toBeCloseTo(0, 6);
    expect(toModelImportSettings(draft({ scale: -1 }), null).scale).toBe(1);
  });
});

describe('planejamento da importação', () => {
  it('nomes de arquivo', () => {
    expect(stemOf('Hero.Final.glb')).toBe('Hero.Final');
    expect(extOf('Hero.GLB')).toBe('glb');
    expect(stemOf('C:\\pasta\\a.obj')).toBe('a');
    expect(sanitizeAssetName(' Meu Herói: v2? ')).toBe('Meu_Herói__v2_');
    expect(sanitizeAssetName('   ')).toBe('model');
    expect(sanitizeAssetName('...')).toBe('model');
  });
  it('destino: arquivo único, nome livre, pasta para .gltf com dependências e reutilização', () => {
    const none = new Set<string>();
    expect(planModelDestination({ fileName: 'Hero.glb', siblings: [] }, none)).toEqual({ reuse: false, mainUri: 'res://models/Hero.glb', siblingUris: [], folderUri: null });
    const taken = new Set(['res://models/Hero.glb', 'res://models/Hero_2.glb']);
    expect(planModelDestination({ fileName: 'Hero.glb', siblings: [] }, taken).mainUri).toBe('res://models/Hero_3.glb');
    expect(uniqueStem('Hero', 'glb', taken, false)).toBe('Hero_3');

    const withDeps = planModelDestination({ fileName: 'hero.gltf', siblings: [{ rel: 'hero.bin', bytes: new ArrayBuffer(1) }, { rel: 'tex/a.png', bytes: new ArrayBuffer(1) }] }, none);
    expect(withDeps.folderUri).toBe('res://models/hero/');
    expect(withDeps.mainUri).toBe('res://models/hero/hero.gltf');
    expect(withDeps.siblingUris.map((s) => s.uri)).toEqual(['res://models/hero/hero.bin', 'res://models/hero/tex/a.png']);
    const folderTaken = planModelDestination({ fileName: 'hero.gltf', siblings: [{ rel: 'hero.bin', bytes: new ArrayBuffer(1) }] }, new Set(['res://models/hero/hero.gltf']));
    expect(folderTaken.folderUri).toBe('res://models/hero_2/');

    const reuse = planModelDestination({ fileName: 'Hero.glb', siblings: [], sourceUri: 'res://models/Hero.glb' }, new Set(['res://models/Hero.glb']));
    expect(reuse).toEqual({ reuse: true, mainUri: 'res://models/Hero.glb', siblingUris: [], folderUri: null });
    // origem fora de res://models/ não é reutilizada
    expect(planModelDestination({ fileName: 'x.glb', siblings: [], sourceUri: 'res://other/x.glb' }, new Set(['res://other/x.glb'])).reuse).toBe(false);
  });
  it('pai do nó: o ativo se for 3D, senão a raiz', () => {
    const nodes = { root: { type: 'Spatial' }, mesh: { type: 'MeshInstance' }, hud: { type: 'ButtonOverlay2D' }, timer: { type: 'Timer' } };
    expect(chooseParentId(nodes, 'mesh', 'root')).toBe('mesh');
    expect(chooseParentId(nodes, 'hud', 'root')).toBe('root');
    expect(chooseParentId(nodes, null, 'root')).toBe('root');
    expect(chooseParentId(nodes, 'inexistente', 'root')).toBe('root');
  });
  it('colisão: padrão estático/automático; desmarcado = sem bloco; malha exata só em estático', () => {
    expect(buildPhysicsBlock({ enabled: true, bodyMode: 'static', shape: 'auto' })).toEqual({ enabled: true, bodyMode: 'static', shape: 'auto' });
    expect(buildPhysicsBlock({ enabled: false, bodyMode: 'static', shape: 'auto' })).toBeUndefined();
    expect(buildPhysicsBlock({ enabled: true, bodyMode: 'static', shape: 'mesh' })?.shape).toBe('mesh');
    expect(buildPhysicsBlock({ enabled: true, bodyMode: 'dynamic', shape: 'mesh' })?.shape).not.toBe('mesh');
    expect(allowedShapes('static')).toContain('mesh');
    expect(allowedShapes('dynamic')).not.toContain('mesh');
  });
  it('propriedades do MeshInstance: referência, offset e (se houver) physics; nunca base64', () => {
    const props = buildMeshInstanceProperties({ model: { id: 'res_1', path: 'res://models/a.glb' }, transform: nodeTransformFor(draft(), bounds), physics: { enabled: true, bodyMode: 'static', shape: 'auto' } });
    expect(props.model).toEqual({ id: 'res_1', path: 'res://models/a.glb' });
    expect(props.physics).toBeDefined();
    expect(JSON.stringify(props)).not.toMatch(/base64/);
    expect(buildMeshInstanceProperties({ model: { id: 'r' }, transform: nodeTransformFor(draft(), null) }).physics).toBeUndefined();
  });
});

describe('preferência "Importar com colisão"', () => {
  it('padrão ligado, persiste e tolera storage quebrado', () => {
    const mem = new Map<string, string>();
    const storage = { getItem: (k: string) => mem.get(k) ?? null, setItem: (k: string, v: string) => void mem.set(k, v) };
    expect(readImportWithCollision(storage)).toBe(true);
    writeImportWithCollision(false, storage);
    expect(mem.get(IMPORT_WITH_COLLISION_KEY)).toBe('0');
    expect(readImportWithCollision(storage)).toBe(false);
    writeImportWithCollision(true, storage);
    expect(readImportWithCollision(storage)).toBe(true);
    const broken = { getItem: () => { throw new Error('x'); }, setItem: () => { throw new Error('x'); } };
    expect(readImportWithCollision(broken)).toBe(true);
    expect(() => writeImportWithCollision(false, broken)).not.toThrow();
  });
});

type F = Record<string, any>;
function setup(initial: F = {}) {
  const project = { files: { ...initial } as F };
  const io: PipelineIO = {
    files: () => project.files,
    write: (uri, content, meta) => {
      project.files[uri] = { ...(project.files[uri] ?? {}), path: uri, name: uri.split('/').pop(), isDirectory: false, content, size: content.length, updatedAt: 'x', ...meta };
    },
  };
  const registry = new ResourceRegistry();
  const pipeline = new AssetPipeline(registry, io);
  for (const importer of [...BUILTIN_IMPORTERS, ...MODEL_SUPPORT_IMPORTERS]) pipeline.registerImporter(importer);
  const added: { parentId: string; name: string; props: Record<string, any> }[] = [];
  const discarded: string[] = [];
  const deps: ImportDeps = {
    pipeline,
    existingUris: () => new Set(Object.keys(project.files)),
    refForUri: (uri) => registry.refForUri(uri),
    readContent: (uri) => project.files[uri]?.content,
    addNode: (_t, parentId, name, props) => {
      added.push({ parentId, name, props });
      return { id: `node_${added.length}` };
    },
    discard: async (uri) => {
      discarded.push(uri);
      delete project.files[uri];
      registry.syncFromProject({ files: project.files } as never);
    },
  };
  return { project, registry, deps, added, discarded };
}

const baseInput = () => ({
  fileName: 'Cube.glb',
  bytes: buildGlb(CUBE),
  siblings: [],
  draft: draft({ scale: 2 }),
  bounds: { size: { x: 1, y: 1, z: 1 }, center: { x: 0, y: 0, z: 0 } },
  collision: { enabled: true, bodyMode: 'static' as const, shape: 'auto' as const },
  parentId: 'root',
});

describe('importModelAsset (AIS-33-C04, C06, C07, C08)', () => {
  it('grava em res://models/ pelo pipeline e cria UM nó com model (ResourceRef), calibração e colisão', async () => {
    const { project, registry, deps, added } = setup();
    const r = await importModelAsset(baseInput(), deps);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.mainUri).toBe('res://models/Cube.glb');
    expect(project.files['res://models/Cube.glb'].importSettings).toMatchObject({ schemaVersion: 1, scale: 2, pivot: 'bottom' });
    expect(project.files['res://models/Cube.glb'].resourceId).toBeTruthy();
    expect(registry.getByUri('res://models/Cube.glb')?.resourceId).toBe(project.files['res://models/Cube.glb'].resourceId);
    expect(added).toHaveLength(1);
    expect(added[0].parentId).toBe('root');
    expect(added[0].name).toBe('Cube');
    expect(added[0].props.model.id).toBe(project.files['res://models/Cube.glb'].resourceId);
    expect(added[0].props.scale).toEqual({ x: 2, y: 2, z: 2 });
    expect(added[0].props.physics).toEqual({ enabled: true, bodyMode: 'static', shape: 'auto' });
    expect(JSON.stringify(added[0].props)).not.toMatch(/base64|data:/);
  });
  it('sem colisão não cria o bloco physics', async () => {
    const { deps, added } = setup();
    await importModelAsset({ ...baseInput(), collision: { enabled: false, bodyMode: 'static', shape: 'auto' } }, deps);
    expect(added[0].props.physics).toBeUndefined();
  });
  it('importar duas vezes não sobrescreve: o segundo ganha nome livre', async () => {
    const { project, deps } = setup();
    await importModelAsset(baseInput(), deps);
    const second = await importModelAsset(baseInput(), deps);
    expect(second.ok && second.mainUri).toBe('res://models/Cube_2.glb');
    expect(Object.keys(project.files).sort()).toEqual(['res://models/Cube.glb', 'res://models/Cube_2.glb']);
  });
  it('arquivo já em res://models/ é reutilizado: sem cópia, mesmo resourceId', async () => {
    const { project, deps, added } = setup();
    const first = await importModelAsset(baseInput(), deps);
    if (!first.ok) throw new Error('falhou');
    const id = project.files['res://models/Cube.glb'].resourceId;
    const again = await importModelAsset({ ...baseInput(), sourceUri: 'res://models/Cube.glb', draft: draft({ scale: 3 }) }, deps);
    expect(again.ok && again.reused).toBe(true);
    expect(Object.keys(project.files)).toEqual(['res://models/Cube.glb']);
    expect(project.files['res://models/Cube.glb'].resourceId).toBe(id);
    expect(project.files['res://models/Cube.glb'].importSettings.scale).toBe(3);
    expect(added).toHaveLength(2);
  });
  it('arquivo corrompido: erro tipado, nada gravado, nenhum nó', async () => {
    const { project, deps, added } = setup();
    const r = await importModelAsset({ ...baseInput(), fileName: 'ruim.glb', bytes: toBuffer('não é um glb') }, deps);
    expect(r).toMatchObject({ ok: false, code: 'model.parse_failed' });
    expect(Object.keys(project.files)).toEqual([]);
    expect(added).toEqual([]);
  });
  it('.gltf com .bin: pasta própria, dependência gravada antes, outputs nas settings e dependências no grafo', async () => {
    const { gltf, bin } = buildGltfWithExternalBin(CUBE, 'cube.bin');
    const { project, registry, deps, added } = setup();
    const r = await importModelAsset({ ...baseInput(), fileName: 'cube.gltf', bytes: toBuffer(gltf), siblings: [{ rel: 'cube.bin', bytes: bin }] }, deps);
    expect(r.ok).toBe(true);
    expect(Object.keys(project.files).sort()).toEqual(['res://models/cube/cube.bin', 'res://models/cube/cube.gltf']);
    const settings = project.files['res://models/cube/cube.gltf'].importSettings;
    expect(settings.outputs).toHaveLength(1);
    expect(settings.outputs[0].id).toBe(project.files['res://models/cube/cube.bin'].resourceId);
    expect(extractDependencies('mesh', 'res://models/cube/cube.gltf', project.files['res://models/cube/cube.gltf'].content).map((d) => d.targetUri)).toEqual(['res://models/cube/cube.bin']);
    expect(registry.getByUri('res://models/cube/cube.gltf')).toBeDefined();
    expect(added).toHaveLength(1);
  });
  it('falha depois de gravar dependências desfaz o que foi gravado (sem arquivo parcial)', async () => {
    const { bin } = buildGltfWithExternalBin(CUBE, 'cube.bin');
    const { project, deps, added, discarded } = setup();
    const r = await importModelAsset({ ...baseInput(), fileName: 'quebrado.gltf', bytes: toBuffer('{ json quebrado'), siblings: [{ rel: 'cube.bin', bytes: bin }] }, deps);
    expect(r.ok).toBe(false);
    expect(discarded).toEqual(['res://models/quebrado/cube.bin']);
    expect(Object.keys(project.files)).toEqual([]);
    expect(added).toEqual([]);
  });
  it('nó sem consumidor de aviso: addNode é chamado uma única vez por importação bem-sucedida', async () => {
    const { deps } = setup();
    const spy = vi.spyOn(deps, 'addNode');
    await importModelAsset(baseInput(), deps);
    expect(spy).toHaveBeenCalledTimes(1);
  });
});

describe('contentForFile', () => {
  it('texto para gltf/obj/dae e data URL para o resto', () => {
    expect(contentForFile('a.obj', toBuffer('v 0 0 0'))).toBe('v 0 0 0');
    expect(contentForFile('a.gltf', toBuffer('{}'))).toBe('{}');
    expect(contentForFile('a.glb', buildGlb(CUBE))).toMatch(/^data:model\/gltf-binary;base64,/);
    expect(contentForFile('a.fbx', new ArrayBuffer(3))).toMatch(/^data:application\/octet-stream;base64,/);
    expect(contentForFile('t.png', new ArrayBuffer(3))).toMatch(/^data:image\/png;base64,/);
  });
});
