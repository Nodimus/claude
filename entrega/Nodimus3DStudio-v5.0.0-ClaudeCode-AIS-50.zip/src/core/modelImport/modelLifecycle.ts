/**
 * AIS-38c — ciclo de vida do modelo 3D importado (funções PURAS, sem React nem Three): pacote do asset, restauração do
 * rascunho a partir de `ModelImportSettings`/manifesto, edições manuais feitas no Inspector depois do import e fecho de
 * dependências (modelo + pacote + dependências do `.gltf`) para Prefab/Publish.
 *
 * O `ModelImportSettings` é a única fonte do que o import gerou: `outputs` lista os arquivos gerados; `materials` e `rig`
 * apontam para o manifesto e o rig. Nada aqui lê o disco: o chamador injeta a resolução de `ResourceRef`.
 */
import type { ResourceRef } from '../../types/node';
import type { ModelImportSettings } from '../../schemas/v1/modelImportSettings.schema';
import type { ManifestMaterial } from '../../schemas/v1/modelMaterialManifest.schema';
import { DEFAULT_TRANSFORM_DRAFT, effectiveRotationDeg, effectiveScale, rotationMatrixXYZ, type ImportTransformDraft, type Vec3 } from './calibration';
import { NEUTRAL_FILTERS, PROCEDURAL_PATTERNS, type MaterialEdit } from './materials';

// ── Pacote do asset ──────────────────────────────────────────────────────────────────────────────────────

export type PackageRole = 'manifest' | 'rig' | 'output';

export interface PackageItem {
  ref: ResourceRef;
  uri: string;
  kind: string;
  role: PackageRole;
}

export interface ResolvedRef {
  uri: string;
  kind: string;
}

export interface ModelPackage {
  /** Arquivos gerados que ainda existem (sem repetição, manifesto e rig primeiro). */
  items: PackageItem[];
  /** Referências do pacote que não resolvem mais (arquivo já removido/movido sem registro). */
  missing: ResourceRef[];
}

/**
 * Pacote do asset = `materials` + `rig` + `outputs` de `ModelImportSettings`, deduplicado por identidade. O próprio modelo
 * NÃO faz parte do pacote (é o item principal da exclusão).
 */
export function modelPackage(settings: Pick<ModelImportSettings, 'materials' | 'rig' | 'outputs'>, resolve: (ref: ResourceRef) => ResolvedRef | null, selfId?: string): ModelPackage {
  const seen = new Set<string>(selfId ? [selfId] : []);
  const items: PackageItem[] = [];
  const missing: ResourceRef[] = [];
  const add = (ref: ResourceRef | undefined, role: PackageRole) => {
    if (!ref || seen.has(ref.id)) return;
    seen.add(ref.id);
    const resolved = resolve(ref);
    if (resolved) items.push({ ref, uri: resolved.uri, kind: resolved.kind, role });
    else missing.push(ref);
  };
  add(settings.materials, 'manifest');
  add(settings.rig, 'rig');
  for (const ref of settings.outputs) add(ref, 'output');
  return { items, missing };
}

/**
 * Fecho de dependências de um nó/prefab com `model`: o modelo, o pacote e as dependências do `.gltf` (que também ficam em
 * `outputs`). É o contrato que Prefab (AIS-81) e Publish (AIS-85) consomem; a lista vem do mesmo pacote da exclusão.
 */
export function modelClosureUris(modelUri: string, pkg: ModelPackage): string[] {
  return [...new Set([modelUri, ...pkg.items.map((i) => i.uri)])];
}

// ── Restauração do rascunho ──────────────────────────────────────────────────────────────────────────────

/**
 * Inverso de `toModelImportSettings`: o rascunho que gerou estas settings. `position` vem do nó (posição não é ajuste de
 * importação). Para o pivô `custom` o deslocamento Y é recuperado do `pivotOffset` (`t = R · S · o`, espaço do nó).
 */
export function draftFromSettings(settings: ModelImportSettings, position: Vec3 = { x: 0, y: 0, z: 0 }): ImportTransformDraft {
  const draft: ImportTransformDraft = {
    ...DEFAULT_TRANSFORM_DRAFT,
    scale: settings.scale,
    scaleAxes: { ...settings.scaleAxes },
    rotationDeg: { ...settings.rotationDeg },
    position: { ...position },
    pivot: settings.pivot,
    pivotOffsetY: 0,
    zUpFlipped: settings.upAxis === 'z',
    centerXZ: settings.centerXZ,
  };
  if (settings.pivot === 'custom') {
    const R = rotationMatrixXYZ(effectiveRotationDeg(draft));
    const o = settings.pivotOffset;
    const s = settings.scaleAxes;
    const v = { x: o.x * s.x, y: o.y * s.y, z: o.z * s.z };
    draft.pivotOffsetY = R[3] * v.x + R[4] * v.y + R[5] * v.z;
  }
  return draft;
}

/** Rascunho de um material a partir do manifesto (o que o import gravou). O padrão procedural não é restaurado. */
export function editFromManifestMaterial(m: ManifestMaterial): MaterialEdit {
  const pattern = PROCEDURAL_PATTERNS[0];
  return {
    name: m.name,
    color: { ...m.color },
    roughness: m.roughness,
    metalness: m.metalness,
    emissiveColor: { ...m.emissiveColor },
    emissiveIntensity: m.emissiveIntensity,
    uvTiling: { x: m.uvTiling[0], y: m.uvTiling[1] },
    filters: { ...NEUTRAL_FILTERS, ...m.filters },
    pattern: 'none',
    patternColorA: pattern.colorA,
    patternColorB: pattern.colorB,
    patternScale: pattern.scale,
  };
}

const near = (a: number, b: number, eps = 1e-4) => Math.abs(a - b) <= eps;
const nearColor = (a: MaterialEdit['color'], b: MaterialEdit['color']) => near(a.r, b.r, 1 / 512) && near(a.g, b.g, 1 / 512) && near(a.b, b.b, 1 / 512);

/** O usuário mexeu neste material na aba Texture em relação ao que foi restaurado do manifesto? */
export function isMaterialTouched(edit: MaterialEdit, baseline: MaterialEdit | undefined): boolean {
  if (!baseline) return true;
  return (
    !nearColor(edit.color, baseline.color) ||
    !near(edit.roughness, baseline.roughness) ||
    !near(edit.metalness, baseline.metalness) ||
    !nearColor(edit.emissiveColor, baseline.emissiveColor) ||
    !near(edit.emissiveIntensity, baseline.emissiveIntensity) ||
    !near(edit.uvTiling.x, baseline.uvTiling.x) ||
    !near(edit.uvTiling.y, baseline.uvTiling.y) ||
    edit.filters.brightness !== baseline.filters.brightness ||
    edit.filters.contrast !== baseline.filters.contrast ||
    edit.filters.saturation !== baseline.filters.saturation ||
    edit.filters.hueShift !== baseline.filters.hueShift ||
    edit.pattern !== baseline.pattern ||
    edit.transparent !== baseline.transparent
  );
}

// ── Edições manuais no Inspector depois do import ────────────────────────────────────────────────────────

export interface ManualChange {
  /** Campo do nó (`rotation`, `scale`, `modelOffset`) ou `materialSlots.<material>`. */
  field: string;
  label: string;
  /** Valor que o import gravou. */
  imported: string;
  /** Valor atual no Inspector. */
  current: string;
}

const fmtVec = (v: Vec3) => `(${[v.x, v.y, v.z].map((n) => Number(n.toFixed(3))).join(', ')})`;
const vecOf = (v: unknown, fallback: Vec3): Vec3 => {
  const o = (v ?? {}) as Partial<Vec3>;
  return { x: Number.isFinite(o.x) ? (o.x as number) : fallback.x, y: Number.isFinite(o.y) ? (o.y as number) : fallback.y, z: Number.isFinite(o.z) ? (o.z as number) : fallback.z };
};
const sameVec = (a: Vec3, b: Vec3) => near(a.x, b.x) && near(a.y, b.y) && near(a.z, b.z);

/**
 * O que o import gravou no nó (sem posição) a partir das settings: é a base para saber se o usuário ajustou algo à mão no
 * Inspector depois. `rotation`/`scale` são os efetivos (Z-Up, eixos); `modelOffset` é o `pivotOffset` gravado.
 */
export function importedNodeValues(settings: ModelImportSettings): { rotation: Vec3; scale: Vec3; modelOffset: Vec3 } {
  const draft = draftFromSettings(settings);
  return { rotation: effectiveRotationDeg(draft), scale: effectiveScale(draft), modelOffset: { ...settings.pivotOffset } };
}

/** Propriedades de slot que o import grava e que o Inspector edita; a cor fica de fora (filtros assam na cor). */
const SLOT_FIELDS = ['roughness', 'metalness', 'emissiveIntensity'] as const;

/**
 * Diferenças entre o nó atual e o que o import gravou: transform/pivô e, só dos materiais pedidos (`slotNames`), os campos de
 * slot editáveis. Lista vazia = nada foi ajustado à mão (reedição aplica sem perguntar).
 */
export function detectManualChanges(
  nodeProps: Record<string, any>,
  settings: ModelImportSettings,
  slotNames: readonly string[] = [],
  baselineEdits: readonly MaterialEdit[] = []
): ManualChange[] {
  const imported = importedNodeValues(settings);
  const out: ManualChange[] = [];
  const zero = { x: 0, y: 0, z: 0 };
  const checks: [string, string, Vec3, Vec3][] = [
    ['rotation', 'Rotação', vecOf(nodeProps.rotation, zero), imported.rotation],
    ['scale', 'Escala', vecOf(nodeProps.scale, { x: 1, y: 1, z: 1 }), imported.scale],
    ['modelOffset', 'Pivô (deslocamento do modelo)', vecOf(nodeProps.modelOffset, zero), imported.modelOffset],
  ];
  for (const [field, label, current, base] of checks) {
    if (!sameVec(current, base)) out.push({ field, label, imported: fmtVec(base), current: fmtVec(current) });
  }
  const slots = nodeProps.materialSlots && typeof nodeProps.materialSlots === 'object' ? (nodeProps.materialSlots as Record<string, Record<string, unknown>>) : {};
  for (const name of slotNames) {
    const slot = slots[name];
    const base = baselineEdits.find((e) => e.name === name);
    if (!slot || !base) continue;
    for (const key of SLOT_FIELDS) {
      const current = slot[key];
      if (typeof current === 'number' && !near(current, base[key])) {
        out.push({ field: `materialSlots.${name}.${key}`, label: `Material "${name}" · ${key}`, imported: String(Number(base[key].toFixed(3))), current: String(Number(current.toFixed(3))) });
      }
    }
  }
  return out;
}
