/**
 * AIS-33 — preferência "Importar com colisão" (padrão ligado). Preferência de UI do editor: `localStorage`, como tema e
 * idioma (decisão 13), nunca no projeto, até o Diálogo de Preferências (AIS-82). Falha de acesso ao storage = padrão.
 */
export const IMPORT_WITH_COLLISION_KEY = 'nodimus.prefs.importWithCollision';

export function readImportWithCollision(storage: Pick<Storage, 'getItem'> | undefined = safeStorage()): boolean {
  try {
    const raw = storage?.getItem(IMPORT_WITH_COLLISION_KEY);
    return raw === null || raw === undefined ? true : raw === '1';
  } catch {
    return true;
  }
}

export function writeImportWithCollision(value: boolean, storage: Pick<Storage, 'setItem'> | undefined = safeStorage()): void {
  try {
    storage?.setItem(IMPORT_WITH_COLLISION_KEY, value ? '1' : '0');
  } catch {
    /* sem storage: vale só nesta sessão */
  }
}

function safeStorage(): Storage | undefined {
  try {
    return typeof localStorage !== 'undefined' ? localStorage : undefined;
  } catch {
    return undefined;
  }
}
