import { describe, expect, it, vi } from 'vitest';
import * as THREE from 'three';
import {
  COVERAGE_THRESHOLD,
  acceptedClips,
  buildAnimationPlayerProperties,
  buildLibrary,
  clipBoneNames,
  clipCoverage,
  displayClipName,
  libraryDiagnostics,
  prepareClip,
  retargetCoverage,
  skeletonCoverage,
  toRigClips,
  uniqueClipName,
  type ClipCandidate,
} from './animationLibrary';
import { importModelAsset, type ImportDeps } from './importModelAsset';
import { DEFAULT_TRANSFORM_DRAFT } from './calibration';
import { ClipPlayer, boneLocalLengths, boneLocalPositions, clipFromLike, likeFromClip } from '../models/clipPlayer';
import { CUBE, buildAnimationOnlyGlb, buildGlb } from '../models/modelFixtures';
import { loadModel } from '../models/modelLoader';
import { ModelLoadError } from '../models/types';
import { ResourceRegistry } from '../resources/ResourceRegistry';
import { AssetPipeline, type PipelineIO } from '../resources/AssetPipeline';
import { BUILTIN_IMPORTERS, MODEL_SUPPORT_IMPORTERS } from '../resources/builtinImporters';
import { RigConfigSchema, parseRigConfig, emptyBoneMap } from '../../schemas/v1/rig.schema';
import {
  MAX_SPEED,
  MIN_SPEED,
  autoMapBones,
  createClipMixer,
  filterTracksToBones,
  frameCount,
  retargetClip,
  sampleClipAt,
  stripRootMotion,
  verticalAxisOf,
  wrapClipTime,
  type ClipLike,
} from '../../runtime/skeletalAnimation';

const MIXAMO = ['Hips', 'Spine', 'Spine1', 'Neck', 'Head', 'LeftShoulder', 'LeftArm', 'LeftForeArm', 'LeftHand', 'RightShoulder', 'RightArm', 'RightForeArm', 'RightHand', 'LeftUpLeg', 'LeftLeg', 'LeftFoot', 'RightUpLeg', 'RightLeg', 'RightFoot'].map((n) => `mixamorig${n}`);
const humanoidMap = autoMapBones(MIXAMO).map;

const clip = (name: string, bones: string[], duration = 1): ClipLike => ({
  name,
  duration,
  tracks: bones.map((b) => ({ name: `${b}.quaternion`, times: [0, duration], values: [0, 0, 0, 1, 0, 0, 0, 1] })),
});

describe('sampleClipAt (tempo → pose)', () => {
  const c: ClipLike = {
    name: 'A',
    duration: 2,
    tracks: [
      { name: 'Hips.position', times: [0, 1, 2], values: [0, 0, 0, 2, 4, 0, 2, 4, 6] },
      { name: 'Arm.quaternion', times: [0, 1], values: [0, 0, 0, 1, 0, 0, Math.sin(Math.PI / 4), Math.cos(Math.PI / 4)] },
      { name: 'Foot.scale', times: [0.5], values: [1, 2, 3] },
      { name: 'Quebrada.position', times: [0, 1], values: [1, 2, 3] },
    ],
  };
  it('posição interpola linearmente entre chaves', () => {
    expect(sampleClipAt(c, 0.5)['Hips.position']).toEqual([1, 2, 0]);
    expect(sampleClipAt(c, 1.5)['Hips.position']).toEqual([2, 4, 3]);
  });
  it('quaternion por slerp: o meio de 0° e 90° é 45°; normalizado', () => {
    const q = sampleClipAt(c, 0.5)['Arm.quaternion'];
    expect(q[2]).toBeCloseTo(Math.sin(Math.PI / 8), 5);
    expect(q[3]).toBeCloseTo(Math.cos(Math.PI / 8), 5);
    expect(Math.hypot(...q)).toBeCloseTo(1, 6);
  });
  it('antes da primeira e depois da última chave segura o valor; chave única vale sempre', () => {
    expect(sampleClipAt(c, 0, { loop: false })['Hips.position']).toEqual([0, 0, 0]);
    expect(sampleClipAt(c, 99, { loop: false })['Hips.position']).toEqual([2, 4, 6]);
    expect(sampleClipAt(c, 1.2)['Foot.scale']).toEqual([1, 2, 3]);
  });
  it('loop dá a volta; trilha malformada é ignorada (nunca inventada)', () => {
    expect(sampleClipAt(c, 2.5, { loop: true })['Hips.position']).toEqual([1, 2, 0]);
    expect(sampleClipAt(c, 0.5)['Quebrada.position']).toBeUndefined();
    expect(wrapClipTime(-0.25, 1, true)).toBeCloseTo(0.75);
    expect(wrapClipTime(5, 1, false)).toBe(1);
    expect(wrapClipTime(3, 0, true)).toBe(0);
  });
  it('não muta o clipe de entrada', () => {
    const snap = JSON.stringify(c);
    sampleClipAt(c, 0.7);
    expect(JSON.stringify(c)).toBe(snap);
  });
});

describe('createClipMixer (player do modal, estado puro)', () => {
  const mk = () => createClipMixer([{ name: 'Idle', duration: 2 }, { name: 'Walk', duration: 1 }]);

  it('começa no primeiro clipe, parado; play/pausa/toggle', () => {
    const m = mk();
    expect(m.state()).toMatchObject({ clip: 'Idle', time: 0, playing: false, speed: 1, loop: true });
    m.toggle();
    expect(m.state().playing).toBe(true);
    m.step(0.5);
    expect(m.state().time).toBeCloseTo(0.5);
    m.toggle();
    m.step(1);
    expect(m.state().time).toBeCloseTo(0.5);
  });
  it('velocidade presa em 0.25×–2.0× e escala a reprodução', () => {
    const m = mk();
    m.setSpeed(10);
    expect(m.state().speed).toBe(MAX_SPEED);
    m.setSpeed(0);
    expect(m.state().speed).toBe(MIN_SPEED);
    m.setSpeed(Number.NaN);
    expect(m.state().speed).toBe(1);
    m.setSpeed(0.25);
    m.play();
    m.step(1);
    expect(m.state().time).toBeCloseTo(0.25);
  });
  it('loop dá a volta; sem loop para no fim e recomeça no play seguinte', () => {
    const m = mk();
    m.play();
    m.step(2.5);
    expect(m.state().time).toBeCloseTo(0.5);
    m.setLoop(false);
    m.step(5);
    expect(m.state()).toMatchObject({ time: 2, playing: false });
    m.play();
    expect(m.state()).toMatchObject({ time: 0, playing: true });
  });
  it('scrub quadro a quadro a 30 fps: anda 1/30 s por quadro, pausa e respeita os limites', () => {
    const m = mk();
    m.play();
    m.stepFrame(1);
    expect(m.state().playing).toBe(false);
    expect(m.state().time).toBeCloseTo(1 / 30, 6);
    m.stepFrame(2);
    expect(m.state().time).toBeCloseTo(3 / 30, 6);
    m.stepFrame(-10);
    expect(m.state().time).toBe(0);
    m.stepFrame(1000);
    expect(m.state().time).toBeLessThanOrEqual(2);
    expect(frameCount(2)).toBe(61);
    m.seek(1.0);
    expect(m.state().time).toBe(1);
    m.seek(99);
    expect(m.state().time).toBe(2);
  });
  it('crossfade em segundos: pesos somam 1, o anterior some ao fim; select e clipe desconhecido', () => {
    const m = mk();
    m.seek(1);
    m.crossFadeTo('Walk', 0.5);
    expect(m.state()).toMatchObject({ clip: 'Walk', playing: true });
    let layers = m.layers();
    expect(layers.map((l) => l.clip)).toEqual(['Idle', 'Walk']);
    expect(layers[0].weight).toBeCloseTo(1);
    expect(layers[1].weight).toBeCloseTo(0);
    m.step(0.25);
    layers = m.layers();
    expect(layers[0].weight + layers[1].weight).toBeCloseTo(1);
    expect(layers[1].weight).toBeCloseTo(0.5);
    m.step(0.5);
    expect(m.layers()).toEqual([{ clip: 'Walk', time: expect.any(Number), weight: 1 }]);
    m.crossFadeTo('Fantasma', 1);
    expect(m.state().clip).toBe('Walk');
    m.crossFadeTo('Idle', 0); // troca seca
    expect(m.layers()).toHaveLength(1);
    m.select('Walk');
    expect(m.state()).toMatchObject({ clip: 'Walk', time: 0 });
  });
});

describe('stripRootMotion (in-place)', () => {
  it('zera o deslocamento X/Z do osso raiz e mantém a altura e as outras trilhas', () => {
    const c: ClipLike = {
      name: 'Walk',
      duration: 1,
      tracks: [
        { name: 'Hips.position', times: [0, 1], values: [1, 0.9, 2, 4, 1.1, 8] },
        { name: 'Hips.quaternion', times: [0], values: [0, 0, 0, 1] },
      ],
    };
    const snap = JSON.stringify(c);
    const out = stripRootMotion(c, 'Hips');
    expect(Array.from(out.tracks[0].values)).toEqual([1, 0.9, 2, 1, 1.1, 2]);
    expect(Array.from(out.tracks[1].values)).toEqual([0, 0, 0, 1]);
    expect(JSON.stringify(c)).toBe(snap);
    expect(Array.from(stripRootMotion(c, null).tracks[0].values)).toEqual([1, 0.9, 2, 4, 1.1, 8]);
  });
});

describe('biblioteca de clipes (AIS-37-C01, C02)', () => {
  const ctx = { modelBones: MIXAMO, humanoidMap };

  it('cobertura: mesmo esqueleto = 100%; esqueleto de outro rig humanoide pelo retarget; incompatível abaixo do limiar', () => {
    expect(skeletonCoverage(MIXAMO, MIXAMO)).toBe(1);
    expect(skeletonCoverage(['A', 'B'], ['A'])).toBe(0.5);
    expect(skeletonCoverage([], MIXAMO)).toBe(0);
    const unity = ['Hips', 'Spine', 'Chest', 'Neck', 'Head', 'LeftShoulder', 'LeftUpperArm', 'LeftLowerArm', 'LeftHand', 'RightShoulder', 'RightUpperArm', 'RightLowerArm', 'RightHand', 'LeftUpperLeg', 'LeftLowerLeg', 'LeftFoot', 'RightUpperLeg', 'RightLowerLeg', 'RightFoot'];
    expect(retargetCoverage(unity, humanoidMap)).toBe(1); // nomes diferentes, mesmo humanoide
    expect(clipCoverage(unity, ctx)).toBe(1);
    expect(clipCoverage(['Asa_1', 'Asa_2', 'Cauda'], ctx)).toBe(0);
    expect(clipBoneNames(clip('X', ['A', 'B']))).toEqual(['A', 'B']);
  });

  it('sem rig humanoide só vale o mesmo esqueleto (sem retarget)', () => {
    const wing = ['Asa_1', 'Asa_2'];
    expect(clipCoverage(wing, { modelBones: wing, humanoidMap: null })).toBe(1);
    expect(clipCoverage(['Hips'], { modelBones: wing, humanoidMap: null })).toBe(0);
  });

  it('nomes duplicados ganham sufixo (e aviso); embutidos primeiro, depois os arquivos', () => {
    expect(uniqueClipName('Walk', new Set())).toEqual({ name: 'Walk', renamed: false });
    expect(uniqueClipName('Walk', new Set(['walk']))).toEqual({ name: 'Walk_2', renamed: true });
    expect(uniqueClipName('Walk', new Set(['Walk', 'Walk_2']))).toEqual({ name: 'Walk_3', renamed: true });
    const lib = buildLibrary(
      [
        { sourceKind: 'embedded', clip: clip('Walk', MIXAMO) },
        { sourceKind: 'file', fileName: 'Walk.glb', clip: clip('Walk', MIXAMO) },
        { sourceKind: 'file', fileName: 'Run.glb', clip: clip('Run', MIXAMO) },
      ],
      ctx
    );
    expect(lib.map((c) => c.name)).toEqual(['Walk', 'Walk_2', 'Run']);
    expect(lib[1]).toMatchObject({ renamedFrom: 'Walk', sourceClip: 'Walk', fileName: 'Walk.glb' });
    expect(libraryDiagnostics(lib).map((d) => d.code)).toEqual(['anim.duplicate_name']);
  });

  it('esqueleto incompatível: anim.incompatible_skeleton, fora da biblioteca até o aceite', () => {
    const candidates: ClipCandidate[] = [
      { sourceKind: 'embedded', clip: clip('Idle', MIXAMO) },
      { sourceKind: 'file', fileName: 'Voo.glb', clip: clip('Voo', ['Asa_1', 'Asa_2', 'Cauda']) },
    ];
    const lib = buildLibrary(candidates, ctx);
    expect(lib[0]).toMatchObject({ compatible: true, accepted: true });
    expect(lib[1]).toMatchObject({ compatible: false, accepted: false, coverage: 0 });
    expect(acceptedClips(lib).map((c) => c.name)).toEqual(['Idle']);
    const d = libraryDiagnostics(lib);
    expect(d).toEqual([expect.objectContaining({ code: 'anim.incompatible_skeleton', severity: 'warning', clip: 'Voo' })]);
    expect(d[0].message).toContain('fora da biblioteca até o aceite');
    // aceite manual: entra, continua sinalizado
    const accepted = lib.map((c) => (c.name === 'Voo' ? { ...c, accepted: true } : c));
    expect(acceptedClips(accepted).map((c) => c.name)).toEqual(['Idle', 'Voo']);
    expect(libraryDiagnostics(accepted)[0].message).toContain('aceito manualmente');
    expect(COVERAGE_THRESHOLD).toBe(0.8);
  });

  it('limiar de 80%: 4 de 5 ossos passa; 3 de 5 não', () => {
    const model = ['a', 'b', 'c', 'd', 'e'];
    const c4 = buildLibrary([{ sourceKind: 'embedded', clip: clip('X', ['a', 'b', 'c', 'd']) }], { modelBones: model, humanoidMap: null });
    const c3 = buildLibrary([{ sourceKind: 'embedded', clip: clip('X', ['a', 'b', 'c', 'zz', 'yy']) }], { modelBones: model, humanoidMap: null });
    expect(c4[0].compatible).toBe(true);
    expect(c3[0].compatible).toBe(false);
  });

  it('padrão: loop e in-place ligados', () => {
    const [c] = buildLibrary([{ sourceKind: 'embedded', clip: clip('Idle', MIXAMO) }], ctx);
    expect(c).toMatchObject({ loop: true, inPlace: true });
  });
});

describe('serialização de RigConfig.clips (decisão 3.2: só referências)', () => {
  const model = { id: 'res_model', type: 'mesh', path: 'res://models/Hero.glb' };
  const walkFile = { id: 'res_walk', type: 'mesh', path: 'res://models/Walk.glb' };
  it('embutido aponta para o modelo; arquivo extra para o arquivo; clipe sem origem é omitido; nenhum keyframe', () => {
    const lib = buildLibrary(
      [
        { sourceKind: 'embedded', clip: clip('Idle', MIXAMO) },
        { sourceKind: 'file', fileName: 'Walk.glb', clip: clip('Walk', MIXAMO) },
        { sourceKind: 'file', fileName: 'Sumiu.glb', clip: clip('Sumiu', MIXAMO) },
      ],
      { modelBones: MIXAMO, humanoidMap }
    );
    const clips = toRigClips(lib, { model, files: new Map([['Walk.glb', walkFile]]) });
    expect(clips).toEqual([
      { name: 'Idle', source: model, sourceClip: 'Idle', loop: true, inPlace: true },
      { name: 'Walk', source: walkFile, sourceClip: 'Walk', loop: true, inPlace: true },
    ]);
    const rig = RigConfigSchema.parse({ asset: model, bones: humanoidMap, clips });
    const back = parseRigConfig(JSON.stringify(rig));
    expect(back.ok && back.rig).toEqual(rig);
    expect(JSON.stringify(rig)).not.toMatch(/"times"|"values"|keyframe|base64/);
  });
  it('propriedades do AnimationPlayer: primeiro clipe como atual; sem clipes = null', () => {
    const rig = { id: 'res_rig' };
    expect(buildAnimationPlayerProperties([], rig)).toBeNull();
    expect(buildAnimationPlayerProperties([{ name: 'Idle', loop: false }, { name: 'Walk' }], rig)).toEqual({ rigConfig: rig, currentAnimation: 'Idle', loop: false, autoplay: false });
  });
});

// ── Import: biblioteca + AnimationPlayer no mesmo Undo (AIS-37-C04, C05) ───────────────────────────────
type F = Record<string, any>;
function setup() {
  const project = { files: {} as F };
  const io: PipelineIO = {
    files: () => project.files,
    write: (uri, content, meta) => {
      project.files[uri] = { ...(project.files[uri] ?? {}), path: uri, name: uri.split('/').pop(), isDirectory: false, content, size: content.length, updatedAt: 'x', ...meta };
    },
  };
  const registry = new ResourceRegistry();
  const pipeline = new AssetPipeline(registry, io);
  for (const importer of [...BUILTIN_IMPORTERS, ...MODEL_SUPPORT_IMPORTERS]) pipeline.registerImporter(importer);
  const added: { type: string; parentId: string; name: string; props: Record<string, any> }[] = [];
  const discarded: string[] = [];
  const transactions: string[] = [];
  const deps: ImportDeps = {
    pipeline,
    existingUris: () => new Set(Object.keys(project.files)),
    refForUri: (uri) => registry.refForUri(uri),
    readContent: (uri) => project.files[uri]?.content,
    addNode: (type, parentId, name, props) => {
      added.push({ type, parentId, name, props });
      return { id: `node_${added.length}` };
    },
    transaction: (label, fn) => {
      transactions.push(label);
      return fn();
    },
    discard: async (uri) => {
      discarded.push(uri);
      delete project.files[uri];
      registry.syncFromProject({ files: project.files } as never);
    },
  };
  return { project, registry, deps, added, discarded, transactions };
}

const base = () => ({
  fileName: 'Cube.glb',
  bytes: buildGlb(CUBE),
  siblings: [],
  draft: { ...DEFAULT_TRANSFORM_DRAFT },
  bounds: { size: { x: 1, y: 1, z: 1 }, center: { x: 0, y: 0, z: 0 } },
  collision: { enabled: true, bodyMode: 'static' as const, shape: 'auto' as const },
  parentId: 'root',
});

const libFor = (candidates: ClipCandidate[], modelBones = MIXAMO, map: typeof humanoidMap | null = humanoidMap) => buildLibrary(candidates, { modelBones, humanoidMap: map });

describe('importModelAsset com biblioteca de clipes', () => {
  it('humanoide com clipes embutidos: rig com clips por referência e AnimationPlayer FILHO no mesmo Undo', async () => {
    const { project, deps, added, transactions } = setup();
    const library = libFor([{ sourceKind: 'embedded', clip: clip('Idle', MIXAMO) }, { sourceKind: 'embedded', clip: clip('Walk', MIXAMO) }]);
    const r = await importModelAsset({ ...base(), rig: { bones: humanoidMap }, animations: { library, files: [] } }, deps);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(transactions).toHaveLength(1); // as duas criações = UMA entrada de Undo
    expect(added.map((a) => a.type)).toEqual(['MeshInstance', 'AnimationPlayer']);
    expect(added[1].parentId).toBe(r.nodeId);
    expect(r.playerId).toBeTruthy();
    const parsed = parseRigConfig(project.files['res://materials/Cube_rig.json'].content);
    expect(parsed.ok && parsed.rig.clips.map((c) => [c.name, c.sourceClip, c.source?.id])).toEqual([
      ['Idle', 'Idle', project.files['res://models/Cube.glb'].resourceId],
      ['Walk', 'Walk', project.files['res://models/Cube.glb'].resourceId],
    ]);
    expect(added[1].props).toMatchObject({ rigConfig: { id: project.files['res://materials/Cube_rig.json'].resourceId }, currentAnimation: 'Idle', loop: true, autoplay: false });
    expect(project.files['res://materials/Cube_rig.json'].content).not.toMatch(/"times"|"values"/);
  });

  it('arquivos extras só de animação são gravados em res://models/ e referenciados (sem copiar keyframes)', async () => {
    const { project, registry, deps, added } = setup();
    const walkBones = MIXAMO;
    const library = libFor([
      { sourceKind: 'embedded', clip: clip('Idle', MIXAMO) },
      { sourceKind: 'file', fileName: 'Walk.glb', clip: clip('Walk', walkBones) },
    ]);
    const r = await importModelAsset({ ...base(), rig: { bones: humanoidMap }, animations: { library, files: [{ name: 'Walk.glb', bytes: buildAnimationOnlyGlb(['mixamorigHips'], 'Walk') }] } }, deps);
    expect(r.ok).toBe(true);
    expect(project.files['res://models/Walk.glb']?.resourceId).toBeTruthy();
    expect(registry.getByUri('res://models/Walk.glb')?.kind).toBe('mesh');
    const rig = parseRigConfig(project.files['res://materials/Cube_rig.json'].content);
    const walk = rig.ok ? rig.rig.clips.find((c) => c.name === 'Walk') : undefined;
    expect(walk?.source?.id).toBe(project.files['res://models/Walk.glb'].resourceId);
    expect(project.files['res://models/Cube.glb'].importSettings.outputs.map((o: { id: string }) => o.id)).toContain(project.files['res://models/Walk.glb'].resourceId);
    expect(added.map((a) => a.type)).toEqual(['MeshInstance', 'AnimationPlayer']);
  });

  it('só os arquivos usados por clipes aceitos são gravados (incompatível sem aceite fica de fora)', async () => {
    const { project, deps } = setup();
    const library = libFor([{ sourceKind: 'embedded', clip: clip('Idle', MIXAMO) }, { sourceKind: 'file', fileName: 'Voo.glb', clip: clip('Voo', ['Asa_1', 'Asa_2']) }]);
    const r = await importModelAsset({ ...base(), rig: { bones: humanoidMap }, animations: { library, files: [{ name: 'Voo.glb', bytes: buildAnimationOnlyGlb(['Asa_1'], 'Voo') }] } }, deps);
    expect(r.ok).toBe(true);
    expect(project.files['res://models/Voo.glb']).toBeUndefined();
    const rig = parseRigConfig(project.files['res://materials/Cube_rig.json'].content);
    expect(rig.ok && rig.rig.clips.map((c) => c.name)).toEqual(['Idle']);
  });

  it('modelo sem clipes não cria AnimationPlayer (nem rig, se não humanoide)', async () => {
    const { project, deps, added, transactions } = setup();
    const r = await importModelAsset({ ...base(), animations: { library: [], files: [] } }, deps);
    expect(r.ok).toBe(true);
    expect(added.map((a) => a.type)).toEqual(['MeshInstance']);
    expect(Object.keys(project.files).filter((u) => u.includes('_rig.json'))).toEqual([]);
    expect(transactions).toHaveLength(1);
  });

  it('humanoide sem clipes: grava o rig (AIS-36) mas não cria AnimationPlayer', async () => {
    const { project, deps, added } = setup();
    await importModelAsset({ ...base(), rig: { bones: humanoidMap }, animations: { library: [], files: [] } }, deps);
    expect(project.files['res://materials/Cube_rig.json']).toBeTruthy();
    expect(added.map((a) => a.type)).toEqual(['MeshInstance']);
  });

  it('não humanoide com clipes embutidos: o player aponta para um rig que lista só os clipes (sem retarget)', async () => {
    const { project, deps, added } = setup();
    const wing = ['Asa_1', 'Asa_2'];
    const library = libFor([{ sourceKind: 'embedded', clip: clip('Bater', wing) }], wing, null);
    const r = await importModelAsset({ ...base(), rig: { bones: emptyBoneMap() }, animations: { library, files: [] } }, deps);
    expect(r.ok).toBe(true);
    const rig = parseRigConfig(project.files['res://materials/Cube_rig.json'].content);
    expect(rig.ok && Object.values(rig.rig.bones).every((b) => b === null)).toBe(true);
    expect(rig.ok && rig.rig.clips.map((c) => c.name)).toEqual(['Bater']);
    expect(added.map((a) => a.type)).toEqual(['MeshInstance', 'AnimationPlayer']);
    expect(project.files['res://models/Cube.glb'].importSettings.rig.id).toBe(project.files['res://materials/Cube_rig.json'].resourceId);
  });

  it('falha ao gravar um arquivo extra: rollback total, nenhum nó', async () => {
    const { project, deps, added, discarded } = setup();
    const library = libFor([{ sourceKind: 'file', fileName: 'Ruim.glb', clip: clip('Ruim', MIXAMO) }]);
    const r = await importModelAsset({ ...base(), rig: { bones: humanoidMap }, animations: { library, files: [{ name: 'Ruim.glb', bytes: new TextEncoder().encode('não é glb').buffer as ArrayBuffer }] } }, deps);
    expect(r.ok).toBe(false);
    expect(added).toHaveLength(0);
    expect(discarded).toContain('res://models/Cube.glb');
    expect(Object.keys(project.files).filter((u) => u.startsWith('res://models/') || u.startsWith('res://materials/'))).toEqual([]);
  });

  it('sem `transaction` o import ainda cria os dois nós (compatibilidade)', async () => {
    const { deps, added } = setup();
    delete (deps as { transaction?: unknown }).transaction;
    const library = libFor([{ sourceKind: 'embedded', clip: clip('Idle', MIXAMO) }]);
    await importModelAsset({ ...base(), rig: { bones: humanoidMap }, animations: { library, files: [] } }, deps);
    expect(added.map((a) => a.type)).toEqual(['MeshInstance', 'AnimationPlayer']);
  });
});

describe('arquivo só de animação (loadModel)', () => {
  it('sem malha é erro (model.empty) por padrão e aceito com allowAnimationOnly', async () => {
    const bytes = buildAnimationOnlyGlb(['Hips', 'Spine'], 'Walk');
    let error: unknown;
    try {
      await loadModel({ bytes, ext: 'glb', name: 'Walk.glb' });
    } catch (e) {
      error = e;
    }
    expect(error).toBeInstanceOf(ModelLoadError);
    expect((error as ModelLoadError).code).toBe('model.empty');
    const m = await loadModel({ bytes, ext: 'glb', name: 'Walk.glb', allowAnimationOnly: true });
    expect(m.animations.map((a) => a.name)).toEqual(['Walk']);
    expect(m.stats.meshes).toBe(0);
    expect(m.bounds).toBeNull();
    expect(likeFromClip(m.animations[0]).tracks[0].name).toBe('Hips.position');
  });
});

describe('ponte com o three (ClipPlayer)', () => {
  const makeRoot = () => {
    const root = new THREE.Group();
    const hips = new THREE.Bone();
    hips.name = 'Hips';
    root.add(hips);
    return { root, hips };
  };
  const walk = (): ClipLike => ({ name: 'Walk', duration: 1, tracks: [{ name: 'Hips.position', times: [0, 1], values: [0, 0, 0, 2, 0, 0] }] });
  const idle = (): ClipLike => ({ name: 'Idle', duration: 1, tracks: [{ name: 'Hips.position', times: [0, 1], values: [0, 4, 0, 0, 4, 0] }] });

  it('ClipLike ↔ AnimationClip: ida e volta preserva trilhas e valores', () => {
    const c = clipFromLike({ name: 'A', duration: 1, tracks: [{ name: 'Hips.quaternion', times: [0, 1], values: [0, 0, 0, 1, 0, 0, 0, 1] }, { name: 'Hips.scale', times: [0], values: [1, 1, 1] }] });
    expect(c.tracks[0]).toBeInstanceOf(THREE.QuaternionKeyframeTrack);
    expect(c.tracks[1]).toBeInstanceOf(THREE.VectorKeyframeTrack);
    expect(likeFromClip(c)).toEqual({ name: 'A', duration: 1, tracks: [{ name: 'Hips.quaternion', times: [0, 1], values: [0, 0, 0, 1, 0, 0, 0, 1] }, { name: 'Hips.scale', times: [0], values: [1, 1, 1] }] });
  });

  it('o scrub aplica a pose do tempo pedido; o crossfade mistura as poses; dispose volta o esqueleto', () => {
    const { root, hips } = makeRoot();
    const player = new ClipPlayer(root, [clipFromLike(walk()), clipFromLike(idle())]);
    player.mixer.seek(0.5);
    player.apply();
    expect(hips.position.x).toBeCloseTo(1, 5);
    player.mixer.stepFrame(3); // 0.5 s = quadro 15 → quadro 18 = 0.6 s
    player.apply();
    expect(hips.position.x).toBeCloseTo(1.2, 5);
    // crossfade Walk→Idle: no meio, as duas poses pesam 0.5
    player.mixer.seek(0.5);
    player.mixer.crossFadeTo('Idle', 1);
    player.mixer.pause();
    player.mixer.step(0.5);
    player.apply();
    expect(hips.position.y).toBeCloseTo(2, 4); // metade de Idle (y=4) e metade de Walk (y=0)
    player.dispose();
    expect(() => player.apply()).not.toThrow();
  });

  it('snapshot e refresh avisam a UI', () => {
    const { root } = makeRoot();
    const tick = vi.fn();
    const player = new ClipPlayer(root, [clipFromLike(walk())], tick);
    player.mixer.seek(0.25);
    player.refresh();
    expect(tick).toHaveBeenCalled();
    expect(player.snapshot()).toMatchObject({ clip: 'Walk', time: 0.25, duration: 1, playing: false, speed: 1, loop: true });
    player.dispose();
  });
});

describe('clipe de outra unidade/esqueleto: escala do Hips e trilhas sem osso (pendências do AIS-37)', () => {
  // FBX do Mixamo costuma vir em cm; o modelo (glTF) em m. O FBXLoader do three NÃO converte a unidade.
  const cmBones = ['mixamorig:Hips', 'mixamorig:Spine', 'mixamorig:Head', 'mixamorig:LeftArm', 'mixamorig:LeftHandIndex1', 'mixamorig:LeftHandIndex2'];
  const cmClip = (): ClipLike => ({
    name: 'Walk',
    duration: 1,
    tracks: [
      { name: 'mixamorig:Hips.position', times: [0, 1], values: [10, 100, 20, 50, 104, 220] }, // cm
      { name: 'mixamorig:Hips.quaternion', times: [0], values: [0, 0, 0, 1] },
      { name: 'mixamorig:LeftArm.quaternion', times: [0], values: [0, 0, 0, 1] },
      { name: 'mixamorig:LeftHandIndex1.quaternion', times: [0], values: [0, 0, 0, 1] }, // dedo: o modelo não tem
      { name: 'mixamorig:LeftHandIndex2.quaternion', times: [0], values: [0, 0, 0, 1] },
    ],
  });
  // modelo em metros, mesmos 19 ossos, SEM dedos
  const ctx = (over: Partial<Parameters<typeof prepareClip>[3]> = {}) => ({
    humanoid: true,
    rigMap: humanoidMap,
    modelBones: MIXAMO,
    targetBonePositions: { mixamorigHips: [0, 1.0, 0] } as Record<string, [number, number, number]>,
    sourceBonePositions: { 'mixamorig:Hips': [0, 100, 0] } as Record<string, [number, number, number]>,
    ...over,
  });

  it('retargetClip: com targetBones descarta a trilha sem osso no destino (nada de "No target node found")', () => {
    const src = autoMapBones(cmBones).map;
    const r = retargetClip(cmClip(), src, humanoidMap, { targetBones: new Set(MIXAMO) });
    expect(r.unmatched).toEqual(['mixamorig:LeftHandIndex1.quaternion', 'mixamorig:LeftHandIndex2.quaternion']);
    expect(r.clip.tracks.map((t) => t.name)).toEqual(['mixamorigHips.position', 'mixamorigHips.quaternion', 'mixamorigLeftArm.quaternion']);
    // sem targetBones o comportamento v1 continua: copia sem renomear
    expect(retargetClip(cmClip(), src, humanoidMap).passthrough).toHaveLength(2);
  });

  it('filterTracksToBones: só ficam as trilhas de ossos que existem; não muta a entrada', () => {
    const c = cmClip();
    const snap = JSON.stringify(c);
    const f = filterTracksToBones(c, new Set(['mixamorig:Hips', 'mixamorig:LeftArm']));
    expect(f.clip.tracks.map((t) => t.name)).toEqual(['mixamorig:Hips.position', 'mixamorig:Hips.quaternion', 'mixamorig:LeftArm.quaternion']);
    expect(f.unmatched).toHaveLength(2);
    expect(JSON.stringify(c)).toBe(snap);
  });

  it('cm × m: a translação do Hips é escalada por alvo ÷ origem (1/100) e só ela', () => {
    const p = prepareClip(cmClip(), 'file', false, ctx());
    expect(p.hipRatio).toBeCloseTo(0.01);
    const hips = p.clip.tracks.find((t) => t.name === 'mixamorigHips.position')!;
    expect(Array.from(hips.values).map((v) => Math.round(v * 1e6) / 1e6)).toEqual([0.1, 1, 0.2, 0.5, 1.04, 2.2]);
    expect(Array.from(p.clip.tracks.find((t) => t.name === 'mixamorigHips.quaternion')!.values)).toEqual([0, 0, 0, 1]);
    expect(p.unmatched).toHaveLength(2);
    expect(p.clip.name).toBe('Walk');
  });

  it('in-place vale DEPOIS da escala (altura em metros, X/Z congelados no primeiro quadro)', () => {
    const p = prepareClip(cmClip(), 'file', true, ctx());
    const hips = p.clip.tracks.find((t) => t.name === 'mixamorigHips.position')!;
    expect(Array.from(hips.values).map((v) => Math.round(v * 1e6) / 1e6)).toEqual([0.1, 1, 0.2, 0.1, 1.04, 0.2]);
  });

  it('mesma unidade: razão 1; sem comprimentos conhecidos: não inventa escala', () => {
    expect(prepareClip(cmClip(), 'file', false, ctx({ sourceBonePositions: { 'mixamorig:Hips': [0, 1, 0] } })).hipRatio).toBe(1);
    const unknown = prepareClip(cmClip(), 'file', false, ctx({ sourceBonePositions: undefined, targetBonePositions: {} }));
    expect(unknown.hipRatio).toBe(1);
    expect(Array.from(unknown.clip.tracks[0].values)).toEqual([10, 100, 20, 50, 104, 220]);
  });

  it('clipe embutido não é tocado (já é do próprio esqueleto); sem humanoide só descarta trilhas sem osso', () => {
    const embedded = prepareClip(cmClip(), 'embedded', false, ctx());
    expect(embedded.clip.tracks).toHaveLength(5);
    expect(embedded.hipRatio).toBe(1);
    expect(embedded.unmatched).toEqual([]);
    const wing = prepareClip(cmClip(), 'file', false, { humanoid: false, rigMap: emptyBoneMap(), modelBones: ['mixamorig:Hips'], targetBonePositions: {} });
    expect(wing.clip.tracks.map((t) => t.name)).toEqual(['mixamorig:Hips.position', 'mixamorig:Hips.quaternion']);
    expect(wing.unmatched).toHaveLength(3);
  });

  it('boneLocalLengths lê a posição local do bind por nome (mesmo espaço das trilhas de posição)', () => {
    const armature = new THREE.Group();
    armature.name = 'Armature';
    armature.scale.setScalar(0.01); // FBX típico: o osso fica em cm sob uma raiz escalada
    const hips = new THREE.Bone();
    hips.name = 'mixamorigHips';
    hips.position.set(0, 100, 0);
    const spine = new THREE.Bone();
    spine.name = 'mixamorigSpine';
    spine.position.set(0, 10, 0);
    const origin = new THREE.Bone();
    origin.name = 'naOrigem';
    armature.add(hips);
    hips.add(spine, origin);
    const root = new THREE.Group();
    root.add(armature);
    expect(boneLocalLengths(root)).toEqual({ mixamorigHips: 100, mixamorigSpine: 10 });
  });
});

describe('nome dos clipes de arquivo (Mixamo: todos se chamam "mixamo.com")', () => {
  it('nome genérico vira o nome do arquivo; nome próprio é mantido; a referência guarda o nome ORIGINAL', () => {
    expect(displayClipName('mixamo.com', 'Catwalk Walking.glb')).toBe('Catwalk Walking');
    expect(displayClipName('', 'Walking.fbx')).toBe('Walking');
    expect(displayClipName('Take 001', 'Idle.glb')).toBe('Idle');
    expect(displayClipName('Idle', 'Qualquer.glb')).toBe('Idle');
    expect(displayClipName('mixamo.com')).toBe('mixamo.com'); // sem arquivo (embutido) não inventa nome
    const lib = buildLibrary(
      [
        { sourceKind: 'embedded', clip: clip('mixamo.com', MIXAMO) },
        { sourceKind: 'file', fileName: 'Walking.glb', clip: clip('mixamo.com', MIXAMO) },
        { sourceKind: 'file', fileName: 'Hip Hop Dancing.glb', clip: clip('mixamo.com', MIXAMO) },
      ],
      { modelBones: MIXAMO, humanoidMap }
    );
    expect(lib.map((c) => c.name)).toEqual(['mixamo.com', 'Walking', 'Hip Hop Dancing']);
    expect(lib.map((c) => c.sourceClip)).toEqual(['mixamo.com', 'mixamo.com', 'mixamo.com']);
    expect(lib.every((c) => !c.renamedFrom)).toBe(true);
    expect(libraryDiagnostics(lib)).toEqual([]);
  });
  it('dois arquivos com o mesmo nome de exibição ainda ganham sufixo', () => {
    const lib = buildLibrary([{ sourceKind: 'file', fileName: 'A/Walk.glb', clip: clip('mixamo.com', MIXAMO) }, { sourceKind: 'file', fileName: 'B/Walk.glb', clip: clip('mixamo.com', MIXAMO) }], { modelBones: MIXAMO, humanoidMap });
    expect(lib.map((c) => c.name)).toEqual(['Walk', 'Walk_2']);
    expect(lib[1].renamedFrom).toBe('Walk');
  });
});

// Dados REAIS (docs/arquivos_teste/mixamo, glb): o Hips vem com a altura em -Z e o avanço em Y (pré-rotação de Z-up);
// Big Vegas bind (0, 4.39, -96.23); Walking bind (0, 0, -100.4), trilha (0.93,-2.26,-89.44)→…→(3.7,187,-93); Catwalk bind (0,0,-35.08).
describe('Mixamo real: eixo vertical e escala do Hips', () => {
  it('verticalAxisOf escolhe a maior componente do bind do Hips (Mixamo glb = Z; rigs comuns = Y; desconhecido = Y)', () => {
    expect(verticalAxisOf([0, 4.39, -96.23])).toBe(2);
    expect(verticalAxisOf([0, 0, -100.4])).toBe(2);
    expect(verticalAxisOf([0, 1.0, 0])).toBe(1);
    expect(verticalAxisOf([0.9, 0.1, 0.2])).toBe(0);
    expect(verticalAxisOf(undefined)).toBe(1);
    expect(verticalAxisOf([0, 0, 0])).toBe(1);
  });
  it('in-place com altura em Z: congela X e Y (o avanço) e MANTÉM Z (a altura); o antigo zerava X/Z e deixava o personagem deslizar', () => {
    const walking: ClipLike = { name: 'Walking', duration: 1, tracks: [{ name: 'mixamorigHips.position', times: [0, 0.5, 1], values: [0.93, -2.26, -89.44, 3.7, 120.6, -93.15, 3.7, 187.4, -91.0] }] };
    const out = Array.from(stripRootMotion(walking, 'mixamorigHips', 2).tracks[0].values);
    expect(out).toEqual([0.93, -2.26, -89.44, 0.93, -2.26, -93.15, 0.93, -2.26, -91.0]);
    const old = Array.from(stripRootMotion(walking, 'mixamorigHips').tracks[0].values); // eixo padrão Y
    expect(old[4]).toBe(120.6); // com Y como "altura" o avanço ficaria: é o defeito que o eixo por bind corrige
  });
  it('prepareClip usa o bind do Hips do ARQUIVO de origem para o in-place e para a escala (Catwalk: 33 → ~90 de altura)', () => {
    const modelBones = ['mixamorigHips', 'mixamorigSpine', 'mixamorigHead', 'mixamorigLeftArm', 'mixamorigRightArm', 'mixamorigLeftUpLeg', 'mixamorigLeftLeg', 'mixamorigRightUpLeg', 'mixamorigRightLeg'];
    const rigMap = autoMapBones(modelBones).map;
    const catwalk: ClipLike = { name: 'Catwalk', duration: 1, tracks: [{ name: 'mixamorigHips.position', times: [0, 1], values: [0.85, -0.51, -32.54, -1.24, 27.6, -32.96] }] };
    const p = prepareClip(catwalk, 'file', true, {
      humanoid: true,
      rigMap,
      modelBones,
      targetBonePositions: { mixamorigHips: [0, 4.39, -96.23] },
      sourceBonePositions: { mixamorigHips: [0, 0, -35.08] },
    });
    expect(p.hipRatio).toBeCloseTo(96.33 / 35.08, 2);
    const v = Array.from(p.clip.tracks[0].values);
    expect(v[2]).toBeCloseTo(-32.54 * 2.7457, 1); // altura ~ -89 (do alvo), não -33
    expect(v[5]).toBeCloseTo(-32.96 * 2.7457, 1);
    expect(v[3]).toBeCloseTo(v[0], 6); // avanço (X) congelado
    expect(v[4]).toBeCloseTo(v[1], 6); // avanço (Y) congelado
  });
  it('boneLocalPositions devolve a posição local por nome (nós na origem ficam de fora)', () => {
    const hips = new THREE.Bone();
    hips.name = 'mixamorigHips';
    hips.position.set(0, 4.39, -96.23);
    const origin = new THREE.Bone();
    origin.name = 'naOrigem';
    hips.add(origin);
    const root = new THREE.Group();
    root.add(hips);
    expect(boneLocalPositions(root)).toEqual({ mixamorigHips: [0, 4.39, -96.23] });
  });
});
