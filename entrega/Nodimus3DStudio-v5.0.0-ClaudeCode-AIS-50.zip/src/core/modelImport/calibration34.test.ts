import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import {
  DEFAULT_TRANSFORM_DRAFT,
  UNIT_TO_METERS,
  autoCenter,
  calibratedBounds,
  calibratedHeight,
  calibrationWarnings,
  centerToOrigin,
  convertUnit,
  effectiveScale,
  humanScale,
  isNonUniformScale,
  isTransformDirty,
  modelOffsetFor,
  nodeTransformFor,
  resetDraft,
  rotationMatrixXYZ,
  snapToFloor,
  toModelImportSettings,
  zUpToYUp,
  type ImportTransformDraft,
} from './calibration';
import { loadModel } from '../models/modelLoader';
import { boxMesh, buildGlb } from '../models/modelFixtures';
import { ModelImportSettingsSchema, parseModelImportSettings } from '../../schemas/v1/modelImportSettings.schema';

const draft = (over: Partial<ImportTransformDraft> = {}): ImportTransformDraft => ({ ...resetDraft(), ...over });
const close = (a: number, b: number, digits = 5) => expect(a).toBeCloseTo(b, digits);

/** Caixa assimétrica e fora do centro: 1 (X) × 2 (Y) × 3 (Z), centro em (4, 5, 6). */
const BOX = { size: { x: 1, y: 2, z: 3 }, center: { x: 4, y: 5, z: 6 } };

/** Desenha o que o editor desenharia (T·R·S com o offset no modelo) e mede a caixa resultante com o Three. */
async function drawnBox(d: ImportTransformDraft) {
  const model = await loadModel({ bytes: buildGlb(boxMesh(1, 2, 3, { x: 4, y: 5, z: 6 })), ext: 'glb', name: 'b.glb' });
  const t = nodeTransformFor(d, model.bounds);
  const node = new THREE.Group();
  node.position.set(t.position.x, t.position.y, t.position.z);
  node.rotation.set(THREE.MathUtils.degToRad(t.rotation.x), THREE.MathUtils.degToRad(t.rotation.y), THREE.MathUtils.degToRad(t.rotation.z));
  node.scale.set(t.scale.x, t.scale.y, t.scale.z);
  const content = model.root.clone();
  content.position.set(t.modelOffset.x, t.modelOffset.y, t.modelOffset.z);
  node.add(content);
  node.updateMatrixWorld(true);
  return new THREE.Box3().setFromObject(node);
}

describe('matemática de rotação = a do Three (Euler XYZ)', () => {
  it('a matriz bate com Matrix4.makeRotationFromEuler', () => {
    for (const deg of [{ x: 0, y: 0, z: 0 }, { x: -90, y: 0, z: 0 }, { x: 30, y: 45, z: 60 }, { x: 90, y: 90, z: 0 }, { x: 10, y: -170, z: 250 }]) {
      const m = rotationMatrixXYZ(deg);
      const e = new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(THREE.MathUtils.degToRad(deg.x), THREE.MathUtils.degToRad(deg.y), THREE.MathUtils.degToRad(deg.z), 'XYZ')).elements;
      // `elements` é coluna-a-coluna; `m` é linha-a-linha
      const expected = [e[0], e[4], e[8], e[1], e[5], e[9], e[2], e[6], e[10]];
      m.forEach((v, i) => close(v, expected[i]));
    }
  });
  it('a caixa calibrada de um Z-up troca altura e profundidade', () => {
    const b = calibratedBounds(draft({ zUpFlipped: true }), BOX)!;
    close(b.size.x, 1);
    close(b.size.y, 3);
    close(b.size.z, 2);
    expect(calibratedBounds(draft(), null)).toBeNull();
    close(calibratedHeight(draft({ scale: 0.5 }), BOX), 1);
  });
});

describe('botões de 1 clique (AIS-34-C01): resultado e idempotência', () => {
  it('Snap ao Chão leva a base a Y=0 (mesmo com a caixa fora da origem)', async () => {
    const box = await drawnBox(snapToFloor(draft()));
    close(box.min.y, 0);
  });
  it('Auto Centralizar leva o centro a X=0, Z=0 sem tocar em Y', async () => {
    const before = await drawnBox(draft({ pivot: 'custom', pivotOffsetY: 0 }));
    const box = await drawnBox(autoCenter(draft({ pivot: 'custom', pivotOffsetY: 0 })));
    close((box.min.x + box.max.x) / 2, 0);
    close((box.min.z + box.max.z) / 2, 0);
    close(box.min.y, before.min.y); // Y intacto
  });
  it('Z-Up → Y-Up: gira −90° em X e a caixa é recalculada (altura passa a ser a antiga profundidade)', async () => {
    const d = zUpToYUp(draft());
    expect(d.zUpFlipped).toBe(true);
    const box = await drawnBox(snapToFloor(d));
    close(box.max.y - box.min.y, 3);
    close(box.min.y, 0);
  });
  it('Escala Humana: altura final = 1.80 m sobre a caixa já calibrada', async () => {
    const { draft: d } = humanScale(zUpToYUp(draft()), BOX);
    close(d.scale, 0.6); // 1.8 / 3 (altura depois do Z-up)
    const box = await drawnBox(snapToFloor(d));
    close(box.max.y - box.min.y, 1.8, 3);
    close(humanScale(draft(), BOX).draft.scale, 0.9); // 1.8 / 2
  });
  it('todos são idempotentes e compõem em qualquer ordem', () => {
    const base = draft({ position: { x: 1, y: 2, z: 3 } });
    for (const fn of [autoCenter, snapToFloor, zUpToYUp, centerToOrigin]) expect(fn(fn(base))).toEqual(fn(base));
    expect(humanScale(humanScale(base, BOX).draft, BOX).draft).toEqual(humanScale(base, BOX).draft);
    for (const unit of ['m', 'cm', 'mm', 'in'] as const) expect(convertUnit(convertUnit(base, unit), unit)).toEqual(convertUnit(base, unit));
    const ab = snapToFloor(autoCenter(zUpToYUp(base)));
    const ba = zUpToYUp(autoCenter(snapToFloor(base)));
    expect(ab).toEqual(ba);
  });
  it('Escala Humana avisa (não falha) quando a proporção não parece humana ou não há altura', () => {
    const slab = { size: { x: 4, y: 1, z: 4 }, center: { x: 0, y: 0, z: 0 } };
    const wide = humanScale(draft(), slab);
    expect(wide.warning).toMatch(/não parece humana/);
    expect(wide.draft.scale).toBeCloseTo(1.8, 3); // aplicou mesmo assim
    expect(humanScale(draft(), { size: { x: 0.5, y: 1.9, z: 0.4 }, center: { x: 0, y: 0, z: 0 } }).warning).toBeNull();
    const none = humanScale(draft({ scale: 2 }), null);
    expect(none.draft.scale).toBe(2);
    expect(none.warning).toMatch(/Sem altura/);
  });
});

describe('pivô e unidades (AIS-34-C02)', () => {
  it('os 4 modos de pivô movem a caixa em tempo real', async () => {
    const bottom = await drawnBox(draft({ pivot: 'bottom' }));
    const center = await drawnBox(draft({ pivot: 'center' }));
    const top = await drawnBox(draft({ pivot: 'top' }));
    const custom = await drawnBox(draft({ pivot: 'custom', pivotOffsetY: 0 }));
    close(bottom.min.y, 0);
    close((center.min.y + center.max.y) / 2, 0);
    close(top.max.y, 0);
    close(custom.min.y, 4); // caixa em y=[4,6] sem compensação
    const mid = await drawnBox(draft({ pivot: 'custom', pivotOffsetY: -5 }));
    close(mid.min.y, -1);
  });
  it('conversão de unidade é atalho de escala (absoluta)', () => {
    expect(UNIT_TO_METERS).toEqual({ m: 1, cm: 0.01, mm: 0.001, in: 0.0254 });
    expect(convertUnit(draft({ scale: 3 }), 'cm').scale).toBe(0.01);
    expect(convertUnit(draft(), 'mm').scale).toBe(0.001);
    expect(convertUnit(draft(), 'in').scale).toBe(0.0254);
    expect(convertUnit(draft({ scale: 0.01 }), 'm').scale).toBe(1);
  });
  it('rotação livre + escala + pivô: a base continua em Y=0 e o centro em X/Z=0', async () => {
    const d = snapToFloor(autoCenter(draft({ rotationDeg: { x: 30, y: 45, z: 20 }, scale: 0.7 })));
    const box = await drawnBox(d);
    close(box.min.y, 0, 4);
    close((box.min.x + box.max.x) / 2, 0, 4);
    close((box.min.z + box.max.z) / 2, 0, 4);
  });
});

describe('escala não uniforme (AIS-34-C06)', () => {
  it('é permitida, mantém pivô/centro corretos e gera o aviso physics.nonuniform_scale', async () => {
    const d = snapToFloor(autoCenter(draft({ scale: 2, scaleAxes: { x: 1, y: 0.5, z: 3 }, zUpFlipped: true })));
    expect(isNonUniformScale(d)).toBe(true);
    expect(calibrationWarnings(d)).toEqual([expect.objectContaining({ code: 'physics.nonuniform_scale' })]);
    expect(effectiveScale(d)).toEqual({ x: 2, y: 1, z: 6 });
    const box = await drawnBox(d);
    close(box.min.y, 0, 4);
    close((box.min.x + box.max.x) / 2, 0, 4);
    close((box.min.z + box.max.z) / 2, 0, 4);
    expect(calibrationWarnings(draft({ scale: 2 }))).toEqual([]);
  });
});

describe('Resetar e importSettings (AIS-34-C04/C05)', () => {
  it('resetDraft devolve o rascunho inicial (sem compartilhar objetos)', () => {
    const r = resetDraft();
    expect(r).toEqual(DEFAULT_TRANSFORM_DRAFT);
    expect(r.position).not.toBe(DEFAULT_TRANSFORM_DRAFT.position);
    expect(isTransformDirty(r)).toBe(false);
    expect(isTransformDirty(draft({ centerXZ: true }))).toBe(true);
    expect(isTransformDirty(draft({ scaleAxes: { x: 1, y: 2, z: 1 } }))).toBe(true);
  });
  it('os valores calibrados chegam ao importSettings e ao nó (mesmos números)', () => {
    const d = snapToFloor(autoCenter(zUpToYUp(draft({ scale: 0.6, scaleAxes: { x: 1, y: 1, z: 2 } }))));
    const node = nodeTransformFor(d, BOX);
    const s = toModelImportSettings(d, BOX);
    expect(s.upAxis).toBe('z');
    expect(s.centerXZ).toBe(true);
    expect(s.scaleAxes).toEqual({ x: 1, y: 1, z: 2 });
    expect(s.pivotOffset).toEqual(node.modelOffset);
    expect(node.scale).toEqual({ x: 0.6, y: 0.6, z: 1.2 });
    expect(node.rotation).toEqual({ x: -90, y: 0, z: 0 });
    // volta pelo schema (reedição, AIS-38c)
    expect(parseModelImportSettings(JSON.parse(JSON.stringify(s)))).toEqual(s);
    expect(ModelImportSettingsSchema.parse({})).toMatchObject({ scaleAxes: { x: 1, y: 1, z: 1 }, centerXZ: false });
  });
  it('o arquivo-fonte não é tocado: nada neste módulo recebe nem devolve bytes', () => {
    const before = JSON.stringify(BOX);
    modelOffsetFor(draft({ zUpFlipped: true }), BOX);
    expect(JSON.stringify(BOX)).toBe(before);
  });
});
