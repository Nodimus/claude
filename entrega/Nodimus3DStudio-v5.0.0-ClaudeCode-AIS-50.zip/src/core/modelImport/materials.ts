/**
 * AIS-35 — materiais de um modelo 3D no import: funções PURAS (sem React/Three/DOM) do editor da aba Texture & Material.
 *
 * - `MaterialEdit` = rascunho de um material do arquivo (cor/PBR/emissivo/UV, filtros e padrão procedural).
 * - Filtros (brilho, contraste, saturação, matiz) valem para a cor e, quando há imagem, são "assados" no PNG extraído.
 * - `materialSlots` (decisão 3.2): `properties.materialSlots[<nome do material no arquivo>] = MaterialOverride`.
 *   Regra de resolução (`resolveSlotMaterial`): slot com entrada → o slot; sem entrada → `materialOverride` do nó (padrão
 *   para os slots sem entrada); sem nenhum dos dois → material original do arquivo.
 * - O gerador de padrões é o ÚNICO `utils/textureGenerator.ts`; aqui só ficam os nomes/cores iniciais dos 6 padrões.
 */
import type { ColorData, ResourceRef } from '../../types/node';
import type { MaterialOverride, TexturePatternType } from '../../types/material';
import type { ManifestMaterial, MaterialFilters } from '../../schemas/v1/modelMaterialManifest.schema';
import { nodeMaterialOverride } from '../material/nodeMaterial';
import { NODE_DEFINITIONS } from '../../nodes/registry';
import type { ModelMaterialInfo } from '../models/types';

export type { MaterialFilters } from '../../schemas/v1/modelMaterialManifest.schema';

// ── Filtros ──────────────────────────────────────────────────────────────────────────────────────────────

export const NEUTRAL_FILTERS: MaterialFilters = { brightness: 1, contrast: 1, saturation: 1, hueShift: 0 };

export const isNeutralFilters = (f: MaterialFilters): boolean =>
  f.brightness === 1 && f.contrast === 1 && f.saturation === 1 && f.hueShift === 0;

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

/** Filtros sobre uma cor (componentes 0..1). Brilho multiplica, contraste gira em torno de 0.5, saturação interpola com a luminância, matiz gira (graus). */
export function applyFiltersRgb(c: { r: number; g: number; b: number }, f: MaterialFilters): { r: number; g: number; b: number } {
  let { r, g, b } = c;
  r *= f.brightness;
  g *= f.brightness;
  b *= f.brightness;
  r = (r - 0.5) * f.contrast + 0.5;
  g = (g - 0.5) * f.contrast + 0.5;
  b = (b - 0.5) * f.contrast + 0.5;
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  r = lum + (r - lum) * f.saturation;
  g = lum + (g - lum) * f.saturation;
  b = lum + (b - lum) * f.saturation;
  if (f.hueShift !== 0) {
    const a = (f.hueShift * Math.PI) / 180;
    const cos = Math.cos(a);
    const sin = Math.sin(a);
    // matriz de rotação de matiz (a mesma de `hue-rotate` do CSS)
    const nr = r * (0.213 + cos * 0.787 - sin * 0.213) + g * (0.715 - cos * 0.715 - sin * 0.715) + b * (0.072 - cos * 0.072 + sin * 0.928);
    const ng = r * (0.213 - cos * 0.213 + sin * 0.143) + g * (0.715 + cos * 0.285 + sin * 0.14) + b * (0.072 - cos * 0.072 - sin * 0.283);
    const nb = r * (0.213 - cos * 0.213 - sin * 0.787) + g * (0.715 - cos * 0.715 + sin * 0.715) + b * (0.072 + cos * 0.928 + sin * 0.072);
    r = nr;
    g = ng;
    b = nb;
  }
  return { r: clamp01(r), g: clamp01(g), b: clamp01(b) };
}

export function applyFiltersToColor(color: ColorData, f: MaterialFilters): ColorData {
  if (isNeutralFilters(f)) return { ...color };
  return { ...applyFiltersRgb(color, f), a: color.a };
}

/** Filtros sobre pixels RGBA (0..255), no lugar. Devolve o próprio buffer. */
export function applyFiltersToPixels<T extends { length: number; [index: number]: number }>(data: T, f: MaterialFilters): T {
  if (isNeutralFilters(f)) return data;
  for (let i = 0; i + 3 < data.length; i += 4) {
    const out = applyFiltersRgb({ r: data[i] / 255, g: data[i + 1] / 255, b: data[i + 2] / 255 }, f);
    data[i] = Math.round(out.r * 255);
    data[i + 1] = Math.round(out.g * 255);
    data[i + 2] = Math.round(out.b * 255);
  }
  return data;
}

// ── Padrões procedurais (gerador compartilhado: `utils/textureGenerator.ts`) ──────────────────────────────

export interface ProceduralPatternOption {
  id: Exclude<TexturePatternType, 'none' | 'custom_image'>;
  label: string;
  colorA: string;
  colorB: string;
  scale: number;
}

/** Os 6 padrões da aba, mapeados nos tipos do gerador único (nenhum gerador novo no modal). */
export const PROCEDURAL_PATTERNS: readonly ProceduralPatternOption[] = [
  { id: 'hex', label: 'Camuflagem Hexagonal', colorA: '#2d3b2a', colorB: '#6b7d4f', scale: 6 },
  { id: 'checkerboard', label: 'Fibra de Carbono', colorA: '#141618', colorB: '#282b30', scale: 16 },
  { id: 'cyberpunk', label: 'Circuitos Neon', colorA: '#0d131d', colorB: '#00f0ff', scale: 5 },
  { id: 'brushed', label: 'Metal Escovado', colorA: '#8d9299', colorB: '#5b6168', scale: 4 },
  { id: 'wood', label: 'Grão de Madeira', colorA: '#593214', colorB: '#995f32', scale: 4 },
  { id: 'fabric', label: 'Tecido', colorA: '#3b4a6b', colorB: '#8aa0cf', scale: 8 },
];

export const patternOption = (id: string): ProceduralPatternOption | undefined => PROCEDURAL_PATTERNS.find((p) => p.id === id);

// ── Rascunho de material ─────────────────────────────────────────────────────────────────────────────────

export interface MaterialEdit {
  /** Nome do material no arquivo (chave do slot). */
  name: string;
  color: ColorData;
  roughness: number;
  metalness: number;
  emissiveColor: ColorData;
  emissiveIntensity: number;
  uvTiling: { x: number; y: number };
  filters: MaterialFilters;
  /** `'none'` = mantém a textura do arquivo (ou só a cor). */
  pattern: TexturePatternType;
  patternColorA: string;
  patternColorB: string;
  patternScale: number;
  /** AIS-38: `undefined` = como no arquivo; `false` desliga a transparência (correção de `material.transparent_opaque`). */
  transparent?: boolean;
}

export const hexToColor = (hex: string | null | undefined, fallback: ColorData): ColorData => {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex ?? '');
  if (!m) return { ...fallback };
  const n = parseInt(m[1], 16);
  return { r: ((n >> 16) & 255) / 255, g: ((n >> 8) & 255) / 255, b: (n & 255) / 255, a: 1 };
};

const WHITE: ColorData = { r: 1, g: 1, b: 1, a: 1 };
const BLACK: ColorData = { r: 0, g: 0, b: 0, a: 1 };

/** Rascunho inicial = o material como veio no arquivo. */
export function editFromInfo(info: ModelMaterialInfo): MaterialEdit {
  return {
    name: info.name,
    color: hexToColor(info.color, WHITE),
    roughness: info.roughness ?? 1,
    metalness: info.metalness ?? 0,
    emissiveColor: hexToColor(info.emissive, BLACK),
    emissiveIntensity: info.emissiveIntensity ?? (info.emissive && info.emissive !== '#000000' ? 1 : 0),
    uvTiling: { x: 1, y: 1 },
    filters: { ...NEUTRAL_FILTERS },
    pattern: 'none',
    patternColorA: PROCEDURAL_PATTERNS[0].colorA,
    patternColorB: PROCEDURAL_PATTERNS[0].colorB,
    patternScale: PROCEDURAL_PATTERNS[0].scale,
  };
}

export const editsFromModel = (infos: readonly ModelMaterialInfo[]): MaterialEdit[] => infos.map(editFromInfo);

const sameColor = (a: ColorData, b: ColorData) => Math.abs(a.r - b.r) < 1 / 512 && Math.abs(a.g - b.g) < 1 / 512 && Math.abs(a.b - b.b) < 1 / 512;
const near = (a: number, b: number) => Math.abs(a - b) < 1e-4;

/** O rascunho mudou algo em relação ao arquivo? */
export function isEditDirty(edit: MaterialEdit, info: ModelMaterialInfo): boolean {
  const base = editFromInfo(info);
  return (
    !sameColor(edit.color, base.color) ||
    !near(edit.roughness, base.roughness) ||
    !near(edit.metalness, base.metalness) ||
    !sameColor(edit.emissiveColor, base.emissiveColor) ||
    !near(edit.emissiveIntensity, base.emissiveIntensity) ||
    !near(edit.uvTiling.x, 1) ||
    !near(edit.uvTiling.y, 1) ||
    !isNeutralFilters(edit.filters) ||
    edit.pattern !== 'none' ||
    (edit.transparent !== undefined && edit.transparent !== info.transparent)
  );
}

/** De onde vem a imagem do albedo que o import grava em `res://textures/`. */
export type AlbedoSource = 'procedural' | 'embedded' | null;

export function albedoSourceOf(edit: MaterialEdit, info: ModelMaterialInfo): AlbedoSource {
  if (edit.pattern !== 'none' && edit.pattern !== 'custom_image') return 'procedural';
  if (info.hasMap && !info.mapMissing) return 'embedded';
  return null;
}

/**
 * Entrada de `materialSlots` para o rascunho (ou `null` se nada mudou). Com imagem de albedo (padrão procedural ou textura
 * embutida filtrada) os filtros vão assados no PNG; sem imagem, vão na cor. `albedo` = `ResourceRef` do PNG gravado.
 */
export function materialSlotFromEdit(edit: MaterialEdit, info: ModelMaterialInfo, albedo?: ResourceRef | null, normal?: ResourceRef | null): MaterialOverride | null {
  if (!isEditDirty(edit, info)) return null;
  const base = editFromInfo(info);
  const baked = albedo != null || albedoSourceOf(edit, info) !== null;
  const color = baked ? edit.color : applyFiltersToColor(edit.color, edit.filters);
  const out: MaterialOverride = {};
  if (!sameColor(color, base.color)) out.color = color;
  if (!near(edit.roughness, base.roughness)) out.roughness = edit.roughness;
  if (!near(edit.metalness, base.metalness)) out.metalness = edit.metalness;
  if (!sameColor(edit.emissiveColor, base.emissiveColor)) out.emissiveColor = edit.emissiveColor;
  if (!near(edit.emissiveIntensity, base.emissiveIntensity)) out.emissiveIntensity = edit.emissiveIntensity;
  if (!near(edit.uvTiling.x, 1) || !near(edit.uvTiling.y, 1)) out.uvTiling = { ...edit.uvTiling };
  if (edit.transparent !== undefined && edit.transparent !== info.transparent) out.transparent = edit.transparent;
  if (albedo) out.albedoTexture = albedo;
  if (normal) out.normalTexture = normal;
  return Object.keys(out).length > 0 ? out : null;
}

/** Todas as entradas de `materialSlots` do rascunho (só dos materiais alterados). */
export function collectMaterialSlots(
  edits: readonly MaterialEdit[],
  infos: readonly ModelMaterialInfo[],
  albedoByName: ReadonlyMap<string, ResourceRef>,
  normalByName: ReadonlyMap<string, ResourceRef> = new Map()
): Record<string, MaterialOverride> {
  const slots: Record<string, MaterialOverride> = {};
  for (const edit of edits) {
    const info = infos.find((i) => i.name === edit.name);
    if (!info) continue;
    const slot = materialSlotFromEdit(edit, info, albedoByName.get(edit.name), normalByName.get(edit.name));
    if (slot) slots[edit.name] = slot;
  }
  return slots;
}

// ── materialSlots × materialOverride (decisão 3.2) ───────────────────────────────────────────────────────

export type SlotResolution = { kind: 'slot' | 'override'; override: MaterialOverride } | { kind: 'original'; override: null };

const isObj = (v: unknown): v is Record<string, any> => typeof v === 'object' && v !== null && !Array.isArray(v);

/**
 * O `materialOverride` que todo MeshInstance nasce com (azul do registry) NÃO é uma escolha do usuário: num nó com modelo ele
 * não vale como padrão (senão todo modelo ficaria azul). Só um override diferente do padrão conta.
 */
function isRegistryDefaultOverride(override: Record<string, any>): boolean {
  const def = (NODE_DEFINITIONS.MeshInstance.defaultProperties as Record<string, any> | undefined)?.materialOverride;
  return !!def && JSON.stringify(def) === JSON.stringify(override);
}

/** Material efetivo de UM slot (nome do material no arquivo) de um nó com `model`. */
export function resolveSlotMaterial(props: Record<string, any> | undefined, materialName: string): SlotResolution {
  const slot = isObj(props?.materialSlots) ? props!.materialSlots[materialName] : undefined;
  if (isObj(slot)) return { kind: 'slot', override: slot as MaterialOverride };
  const override = nodeMaterialOverride(props);
  if (Object.keys(override).length > 0 && !isRegistryDefaultOverride(override)) return { kind: 'override', override };
  return { kind: 'original', override: null };
}

/** Nomes de slot gravados no nó (sem entradas inválidas). */
export function slotNamesOf(props: Record<string, any> | undefined): string[] {
  return isObj(props?.materialSlots) ? Object.keys(props!.materialSlots).filter((k) => isObj(props!.materialSlots[k])) : [];
}

/** Novo `materialSlots` com `patch` aplicado a um slot; slot vazio some; `materialSlots` vazio vira `undefined`. */
export function patchMaterialSlot(props: Record<string, any> | undefined, materialName: string, patch: MaterialOverride | null): Record<string, MaterialOverride> | undefined {
  const next: Record<string, MaterialOverride> = {};
  for (const name of slotNamesOf(props)) next[name] = props!.materialSlots[name];
  if (patch === null || Object.keys(patch).length === 0) delete next[materialName];
  else next[materialName] = patch;
  return Object.keys(next).length > 0 ? next : undefined;
}

// ── Manifesto ────────────────────────────────────────────────────────────────────────────────────────────

export function manifestMaterialFrom(edit: MaterialEdit, source: ManifestMaterial['source'], maps: ManifestMaterial['maps']): ManifestMaterial {
  return {
    name: edit.name,
    source,
    color: { ...edit.color },
    roughness: edit.roughness,
    metalness: edit.metalness,
    emissiveColor: { ...edit.emissiveColor },
    emissiveIntensity: edit.emissiveIntensity,
    uvTiling: [edit.uvTiling.x, edit.uvTiling.y],
    filters: { ...edit.filters },
    maps,
  };
}

// ── Diagnósticos (alimentam o AIS-38) ────────────────────────────────────────────────────────────────────

export interface MaterialDiagnosticItem {
  code: 'texture.missing' | 'material.transparent_opaque' | 'material.duplicate_name' | 'material.unnamed';
  severity: 'warning';
  material: string;
  message: string;
}

export function diagnoseMaterials(infos: readonly ModelMaterialInfo[]): MaterialDiagnosticItem[] {
  const out: MaterialDiagnosticItem[] = [];
  const counts = new Map<string, number>();
  for (const i of infos) counts.set(i.name, (counts.get(i.name) ?? 0) + 1);
  const reportedDup = new Set<string>();
  for (const info of infos) {
    if (info.mapMissing) out.push({ code: 'texture.missing', severity: 'warning', material: info.name, message: `O material "${info.name}" referencia uma textura que não foi encontrada.` });
    if (info.transparent && (info.opacity === undefined || info.opacity >= 1)) {
      out.push({ code: 'material.transparent_opaque', severity: 'warning', material: info.name, message: `O material "${info.name}" está marcado como transparente, mas a opacidade é 1.` });
    }
    if (info.unnamed) out.push({ code: 'material.unnamed', severity: 'warning', material: info.name, message: `Um material do arquivo não tem nome (usando "${info.name}").` });
    if ((counts.get(info.name) ?? 0) > 1 && !reportedDup.has(info.name)) {
      reportedDup.add(info.name);
      out.push({ code: 'material.duplicate_name', severity: 'warning', material: info.name, message: `Há mais de um material chamado "${info.name}": os slots usam o nome como chave.` });
    }
  }
  return out;
}

/** `#rrggbb` de uma cor autoral (sRGB 0..1). */
export const colorToHex = (c: ColorData): string => {
  const h = (v: number) => Math.round(clamp01(v) * 255).toString(16).padStart(2, '0');
  return `#${h(c.r)}${h(c.g)}${h(c.b)}`;
};

// ── Linhas de slot do Inspector ─────────────────────────────────────────────────────────────────────────

export interface SlotValues {
  color: ColorData;
  roughness: number;
  metalness: number;
  emissiveColor: ColorData;
  emissiveIntensity: number;
  uvTiling: { x: number; y: number };
}

export interface SlotRow {
  name: string;
  kind: 'slot' | 'override' | 'original';
  values: SlotValues;
}

/**
 * Linhas do Inspector: um slot por material do arquivo (nomes do manifesto) mais os slots gravados no nó. Os valores
 * mostrados partem do manifesto (o que o import extraiu) e recebem por cima o slot (ou o `materialOverride` do nó).
 */
export function slotRows(props: Record<string, any> | undefined, base: readonly ManifestMaterial[]): SlotRow[] {
  const names = [...base.map((m) => m.name)];
  for (const n of slotNamesOf(props)) if (!names.includes(n)) names.push(n);
  return names.map((name) => {
    const m = base.find((b) => b.name === name);
    const resolved = resolveSlotMaterial(props, name);
    const o = resolved.override ?? {};
    return {
      name,
      kind: resolved.kind,
      values: {
        color: (o.color as ColorData | undefined) ?? m?.color ?? WHITE,
        roughness: typeof o.roughness === 'number' ? o.roughness : m?.roughness ?? 1,
        metalness: typeof o.metalness === 'number' ? o.metalness : m?.metalness ?? 0,
        emissiveColor: (o.emissiveColor as ColorData | undefined) ?? m?.emissiveColor ?? BLACK,
        emissiveIntensity: typeof o.emissiveIntensity === 'number' ? o.emissiveIntensity : m?.emissiveIntensity ?? 0,
        uvTiling: (o.uvTiling as { x: number; y: number } | undefined) ?? (m ? { x: m.uvTiling[0], y: m.uvTiling[1] } : { x: 1, y: 1 }),
      },
    };
  });
}
