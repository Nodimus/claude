import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import {
  NEUTRAL_FILTERS,
  PROCEDURAL_PATTERNS,
  albedoSourceOf,
  applyFiltersRgb,
  applyFiltersToColor,
  applyFiltersToPixels,
  collectMaterialSlots,
  diagnoseMaterials,
  editFromInfo,
  isEditDirty,
  materialSlotFromEdit,
  patchMaterialSlot,
  resolveSlotMaterial,
  slotRows,
} from './materials';
import { ModelMaterialManifestSchema, parseModelMaterialManifest } from '../../schemas/v1/modelMaterialManifest.schema';
import { ModelMaterialApplier, applyOverrideToMaterial, buildMaterialPlan } from '../models/modelMaterials';
import type { ModelMaterialInfo } from '../models/types';
import { DEFAULT_TRANSFORM_DRAFT } from './calibration';
import { NODE_DEFINITIONS } from '../../nodes/registry';
import { importModelAsset, uniqueTextureStem, type ImportDeps, type MaterialImageInput } from './importModelAsset';
import { CUBE, buildGlb } from '../models/modelFixtures';
import { ResourceRegistry } from '../resources/ResourceRegistry';
import { AssetPipeline, type PipelineIO } from '../resources/AssetPipeline';
import { BUILTIN_IMPORTERS, MODEL_SUPPORT_IMPORTERS } from '../resources/builtinImporters';
import { extractDependencies } from '../resources/dependencyExtractor';

const info = (over: Partial<ModelMaterialInfo> = {}): ModelMaterialInfo => ({
  name: 'Casco',
  uuid: 'u-casco',
  type: 'MeshStandardMaterial',
  color: '#808080',
  hasMap: false,
  transparent: false,
  roughness: 0.5,
  metalness: 0.2,
  emissive: '#000000',
  emissiveIntensity: 1,
  opacity: 1,
  ...over,
});

const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

describe('ModelMaterialManifest (Zod v1)', () => {
  const asset = { id: 'res_model', type: 'mesh', path: 'res://models/Hero.glb' };
  it('round-trip: o manifesto sobrevive a stringify/parse sem perder dados', () => {
    const manifest = ModelMaterialManifestSchema.parse({
      asset,
      materials: [{ name: 'Casco', source: 'procedural', color: { r: 0.1, g: 0.2, b: 0.3, a: 1 }, roughness: 0.4, metalness: 0.9, uvTiling: [2, 3], maps: { albedo: { id: 'res_png', path: 'res://textures/Hero/1.png' } } }],
    });
    const r = parseModelMaterialManifest(JSON.stringify(manifest));
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.legacy).toBe(false);
    expect(r.manifest).toEqual(manifest);
    expect(r.manifest.materials[0].maps.albedo?.id).toBe('res_png');
  });
  it('formato antigo (sem schemaVersion) é tolerado; material inválido é descartado; lixo não lança', () => {
    const legacy = parseModelMaterialManifest({ asset, materials: [{ name: 'A' }, { semNome: true }] });
    expect(legacy.ok && legacy.legacy).toBe(true);
    expect(legacy.ok && legacy.manifest.materials.map((m) => m.name)).toEqual(['A']);
    expect(legacy.ok && legacy.dropped).toBe(1);
    expect(parseModelMaterialManifest('{ quebrado').ok).toBe(false);
    expect(parseModelMaterialManifest(42).ok).toBe(false);
    expect(parseModelMaterialManifest({ materials: [] }).ok).toBe(false);
  });
});

describe('filtros (puros)', () => {
  it('neutro não muda nada', () => {
    expect(applyFiltersRgb({ r: 0.3, g: 0.6, b: 0.9 }, NEUTRAL_FILTERS)).toEqual({ r: 0.3, g: 0.6, b: 0.9 });
    const c = { r: 0.2, g: 0.4, b: 0.6, a: 0.5 };
    expect(applyFiltersToColor(c, NEUTRAL_FILTERS)).toEqual(c);
  });
  it('brilho multiplica e satura em 1; saturação 0 vira cinza; matiz 360° volta ao mesmo', () => {
    expect(applyFiltersRgb({ r: 0.4, g: 0.4, b: 0.4 }, { ...NEUTRAL_FILTERS, brightness: 2 })).toEqual({ r: 0.8, g: 0.8, b: 0.8 });
    expect(applyFiltersRgb({ r: 0.9, g: 0.9, b: 0.9 }, { ...NEUTRAL_FILTERS, brightness: 2 })).toEqual({ r: 1, g: 1, b: 1 });
    const gray = applyFiltersRgb({ r: 1, g: 0, b: 0 }, { ...NEUTRAL_FILTERS, saturation: 0 });
    expect(gray.r).toBeCloseTo(gray.g, 6);
    expect(gray.g).toBeCloseTo(gray.b, 6);
    const same = applyFiltersRgb({ r: 0.7, g: 0.2, b: 0.4 }, { ...NEUTRAL_FILTERS, hueShift: 360 });
    expect(same.r).toBeCloseTo(0.7, 4);
    expect(same.g).toBeCloseTo(0.2, 4);
    expect(same.b).toBeCloseTo(0.4, 4);
  });
  it('contraste 0 leva tudo ao cinza médio; matiz 120° leva vermelho para verde', () => {
    expect(applyFiltersRgb({ r: 0.1, g: 0.9, b: 0.5 }, { ...NEUTRAL_FILTERS, contrast: 0 })).toEqual({ r: 0.5, g: 0.5, b: 0.5 });
    const g = applyFiltersRgb({ r: 1, g: 0, b: 0 }, { ...NEUTRAL_FILTERS, hueShift: 120 });
    expect(g.g).toBeGreaterThan(g.r);
    expect(g.g).toBeGreaterThan(g.b);
  });
  it('pixels RGBA: altera RGB e preserva alfa; neutro devolve o mesmo buffer sem mexer', () => {
    const px = new Uint8ClampedArray([100, 100, 100, 200, 10, 20, 30, 255]);
    const out = applyFiltersToPixels(px, { ...NEUTRAL_FILTERS, brightness: 2 });
    expect(out).toBe(px);
    expect([...px]).toEqual([200, 200, 200, 200, 20, 40, 60, 255]);
    const untouched = new Uint8ClampedArray([1, 2, 3, 4]);
    applyFiltersToPixels(untouched, NEUTRAL_FILTERS);
    expect([...untouched]).toEqual([1, 2, 3, 4]);
  });
});

describe('padrões procedurais', () => {
  it('são 6, com os nomes da aba, todos nos tipos do gerador único', () => {
    expect(PROCEDURAL_PATTERNS.map((p) => p.label)).toEqual(['Camuflagem Hexagonal', 'Fibra de Carbono', 'Circuitos Neon', 'Metal Escovado', 'Grão de Madeira', 'Tecido']);
    expect(new Set(PROCEDURAL_PATTERNS.map((p) => p.id)).size).toBe(6);
  });
});

describe('detecção de problemas (AIS-35 → AIS-38)', () => {
  it('texture.missing, transparente com opacidade 1, sem nome e nome duplicado', () => {
    const list = [
      info({ name: 'A', mapMissing: true, hasMap: true }),
      info({ name: 'B', transparent: true, opacity: 1 }),
      info({ name: 'Material_2', unnamed: true }),
      info({ name: 'Dup' }),
      info({ name: 'Dup' }),
      info({ name: 'Vidro', transparent: true, opacity: 0.4 }),
    ];
    const d = diagnoseMaterials(list);
    expect(d.map((x) => `${x.code}:${x.material}`).sort()).toEqual(['material.duplicate_name:Dup', 'material.transparent_opaque:B', 'material.unnamed:Material_2', 'texture.missing:A']);
    expect(diagnoseMaterials([info()])).toEqual([]);
  });
});

describe('materialSlots × materialOverride (decisão 3.2)', () => {
  const slotBlue = { color: { r: 0, g: 0, b: 1, a: 1 } };
  it('slot ausente → material original; override do nó vale como padrão; slot com entrada vence', () => {
    expect(resolveSlotMaterial({}, 'Casco').kind).toBe('original');
    expect(resolveSlotMaterial({ materialSlots: { Outro: slotBlue } }, 'Casco').kind).toBe('original');
    const withOverride = { materialOverride: { roughness: 0.9 }, materialSlots: { Casco: slotBlue } };
    expect(resolveSlotMaterial(withOverride, 'Casco')).toEqual({ kind: 'slot', override: slotBlue });
    const other = resolveSlotMaterial(withOverride, 'Vidro');
    expect(other.kind).toBe('override');
    expect(other.override).toMatchObject({ roughness: 0.9 });
  });
  it('o materialOverride padrão do registry (azul) não vale como padrão de um modelo', () => {
    const def = (NODE_DEFINITIONS.MeshInstance.defaultProperties as Record<string, any>).materialOverride;
    expect(resolveSlotMaterial({ materialOverride: def }, 'Casco').kind).toBe('original');
    expect(resolveSlotMaterial({ materialOverride: { ...def, roughness: 0.9 } }, 'Casco').kind).toBe('override');
    const plan = buildMaterialPlan({ materialOverride: def }, [{ name: 'Casco' }], () => undefined);
    expect(plan).toEqual({});
  });
  it('patchMaterialSlot: grava, mescla, remove e some quando vazio', () => {
    const one = patchMaterialSlot({}, 'Casco', slotBlue)!;
    expect(one.Casco).toEqual(slotBlue);
    const two = patchMaterialSlot({ materialSlots: one }, 'Vidro', { roughness: 0.1 })!;
    expect(Object.keys(two)).toEqual(['Casco', 'Vidro']);
    expect(patchMaterialSlot({ materialSlots: two }, 'Casco', null)).toEqual({ Vidro: { roughness: 0.1 } });
    expect(patchMaterialSlot({ materialSlots: one }, 'Casco', {})).toBeUndefined();
  });
  it('slotRows lista os materiais do manifesto mais os slots; mostra o valor efetivo', () => {
    const base = ModelMaterialManifestSchema.parse({ asset: { id: 'm' }, materials: [{ name: 'Casco', roughness: 0.3 }, { name: 'Vidro' }] }).materials;
    const rows = slotRows({ materialSlots: { Casco: { roughness: 0.8 }, Fantasma: { metalness: 1 } } }, base);
    expect(rows.map((r) => [r.name, r.kind])).toEqual([['Casco', 'slot'], ['Vidro', 'original'], ['Fantasma', 'slot']]);
    expect(rows[0].values.roughness).toBe(0.8);
    expect(rows[1].values.roughness).toBe(1);
  });
});

describe('edição → slot', () => {
  it('sem alteração não gera slot; só o que mudou entra; filtros sem imagem vão na cor', () => {
    const i = info();
    const e = editFromInfo(i);
    expect(isEditDirty(e, i)).toBe(false);
    expect(materialSlotFromEdit(e, i)).toBeNull();
    expect(materialSlotFromEdit({ ...e, roughness: 0.9 }, i)).toEqual({ roughness: 0.9 });
    const filtered = materialSlotFromEdit({ ...e, filters: { ...NEUTRAL_FILTERS, brightness: 2 } }, i)!;
    expect(filtered.color!.r).toBeCloseTo(Math.min(1, (0x80 / 255) * 2), 2);
  });
  it('padrão procedural exige imagem; textura embutida só quando há mapa e ele chegou', () => {
    const i = info();
    expect(albedoSourceOf({ ...editFromInfo(i), pattern: 'wood' }, i)).toBe('procedural');
    expect(albedoSourceOf(editFromInfo(i), i)).toBeNull();
    const mapped = info({ hasMap: true });
    expect(albedoSourceOf(editFromInfo(mapped), mapped)).toBe('embedded');
    const missing = info({ hasMap: true, mapMissing: true });
    expect(albedoSourceOf(editFromInfo(missing), missing)).toBeNull();
  });
  it('com albedo extraído o slot referencia o PNG (ResourceRef) e não filtra a cor', () => {
    const i = info();
    const e = { ...editFromInfo(i), pattern: 'hex' as const, filters: { ...NEUTRAL_FILTERS, brightness: 2 } };
    const ref = { id: 'res_png', path: 'res://textures/a/1.png' };
    const slot = materialSlotFromEdit(e, i, ref)!;
    expect(slot.albedoTexture).toEqual(ref);
    expect(slot.color).toBeUndefined();
    const slots = collectMaterialSlots([e, editFromInfo(info({ name: 'Intacto' }))], [i, info({ name: 'Intacto' })], new Map([['Casco', ref]]));
    expect(Object.keys(slots)).toEqual(['Casco']);
  });
});

describe('aplicação no Three (sem tocar no cache)', () => {
  const makeModel = () => {
    const original = new THREE.MeshStandardMaterial({ color: 0x808080, roughness: 0.5, metalness: 0.2 });
    original.name = 'Casco';
    const other = new THREE.MeshStandardMaterial({ color: 0x00ff00 });
    other.name = 'Vidro';
    const root = new THREE.Group();
    const a = new THREE.Mesh(new THREE.BoxGeometry(), original);
    const b = new THREE.Mesh(new THREE.BoxGeometry(), other);
    root.add(a, b);
    return { root, a, b, original, other, infos: [info({ uuid: original.uuid }), info({ name: 'Vidro', uuid: other.uuid })] };
  };

  it('applyOverrideToMaterial muda só os canais do override', () => {
    const m = new THREE.MeshStandardMaterial({ roughness: 0.5, metalness: 0.2 });
    applyOverrideToMaterial(m, { roughness: 0.9, emissiveColor: { r: 1, g: 0, b: 0, a: 1 }, emissiveIntensity: 2 });
    expect(m.roughness).toBe(0.9);
    expect(m.metalness).toBe(0.2);
    expect(m.emissive.r).toBeGreaterThan(0.9);
    expect(m.emissiveIntensity).toBe(2);
  });

  it('o applier clona só os materiais do plano; o original do cache fica intacto; dispose devolve tudo', () => {
    const { root, a, b, original, other, infos } = makeModel();
    const applier = new ModelMaterialApplier(root, infos, () => new THREE.Texture());
    applier.apply({ Casco: { override: { roughness: 0.9, color: { r: 1, g: 0, b: 0, a: 1 } } } });
    expect(a.material).not.toBe(original);
    expect((a.material as THREE.MeshStandardMaterial).roughness).toBe(0.9);
    expect(original.roughness).toBe(0.5);
    expect(b.material).toBe(other);
    applier.apply({});
    expect(a.material).toBe(original);
    applier.apply({ Vidro: { override: { metalness: 1 } } });
    expect((b.material as THREE.MeshStandardMaterial).metalness).toBe(1);
    applier.dispose();
    expect(a.material).toBe(original);
    expect(b.material).toBe(other);
  });

  it('o albedo do slot vira textura do material alterado (herda a orientação do mapa original)', () => {
    const { root, a, original, infos } = makeModel();
    const calls: string[] = [];
    const applier = new ModelMaterialApplier(root, infos, (url) => {
      calls.push(url);
      return new THREE.Texture();
    });
    applier.apply({ Casco: { override: {}, albedoDataUrl: PNG } });
    expect(calls).toEqual([PNG]);
    expect((a.material as THREE.MeshStandardMaterial).map).toBeInstanceOf(THREE.Texture);
    expect(original.map).toBeNull();
  });

  it('buildMaterialPlan segue a regra slot × override e resolve o PNG por ResourceRef', () => {
    const ref = { id: 'res_png' };
    const plan = buildMaterialPlan(
      { materialOverride: { roughness: 0.7 }, materialSlots: { Casco: { albedoTexture: ref } } },
      [{ name: 'Casco' }, { name: 'Vidro' }],
      (r) => (r.id === 'res_png' ? PNG : undefined)
    );
    expect(plan.Casco.albedoDataUrl).toBe(PNG);
    expect(plan.Vidro.override).toMatchObject({ roughness: 0.7 });
    expect(buildMaterialPlan({}, [{ name: 'Casco' }], () => undefined)).toEqual({});
    expect(buildMaterialPlan({ materialSlots: { Casco: { albedoTexture: ref } } }, [{ name: 'Casco' }], () => 'não-é-imagem').Casco.albedoDataUrl).toBeUndefined();
  });
});

// ── Import com extração (AIS-35-C03) ────────────────────────────────────────────────────────────────────
type F = Record<string, any>;
function setup() {
  const project = { files: {} as F };
  const io: PipelineIO = {
    files: () => project.files,
    write: (uri, content, meta) => {
      project.files[uri] = { ...(project.files[uri] ?? {}), path: uri, name: uri.split('/').pop(), isDirectory: false, content, size: content.length, updatedAt: 'x', ...meta };
    },
  };
  const registry = new ResourceRegistry();
  const pipeline = new AssetPipeline(registry, io);
  for (const importer of [...BUILTIN_IMPORTERS, ...MODEL_SUPPORT_IMPORTERS]) pipeline.registerImporter(importer);
  const added: { name: string; props: Record<string, any> }[] = [];
  const discarded: string[] = [];
  const deps: ImportDeps = {
    pipeline,
    existingUris: () => new Set(Object.keys(project.files)),
    refForUri: (uri) => registry.refForUri(uri),
    readContent: (uri) => project.files[uri]?.content,
    addNode: (_t, _p, name, props) => {
      added.push({ name, props });
      return { id: `node_${added.length}` };
    },
    discard: async (uri) => {
      discarded.push(uri);
      delete project.files[uri];
      registry.syncFromProject({ files: project.files } as never);
    },
  };
  return { project, registry, pipeline, deps, added, discarded };
}

const baseInput = () => ({
  fileName: 'Cube.glb',
  bytes: buildGlb(CUBE),
  siblings: [],
  draft: { ...DEFAULT_TRANSFORM_DRAFT },
  bounds: { size: { x: 1, y: 1, z: 1 }, center: { x: 0, y: 0, z: 0 } },
  collision: { enabled: true, bodyMode: 'static' as const, shape: 'auto' as const },
  parentId: 'root',
});

const materialsInput = (images: MaterialImageInput[], edit: Partial<ReturnType<typeof editFromInfo>> = {}) => {
  const infos = [info({ name: 'Casco' }), info({ name: 'Vidro', uuid: 'u2', hasMap: true })];
  const edits = infos.map((i) => ({ ...editFromInfo(i), ...(i.name === 'Casco' ? { pattern: 'wood' as const, roughness: 0.9, ...edit } : {}) }));
  return { edits, infos, images };
};

describe('import com extração de texturas (AIS-35-C03)', () => {
  const images: MaterialImageInput[] = [
    { material: 'Casco', map: 'albedo', source: 'procedural', dataUrl: PNG, apply: true },
    { material: 'Casco', map: 'normal', source: 'procedural', dataUrl: PNG, apply: true },
    { material: 'Vidro', map: 'albedo', source: 'embedded', dataUrl: PNG, apply: false },
  ];

  it('grava PNGs em res://textures/<asset>/ + <asset>_material.json válido, sem base64, com ResourceRef e resourceId', async () => {
    const { project, registry, deps, added } = setup();
    const r = await importModelAsset({ ...baseInput(), materials: materialsInput(images) }, deps);
    expect(r.ok).toBe(true);
    for (const n of [1, 2, 3]) {
      const png = project.files[`res://textures/Cube/${n}.png`];
      expect(png?.resourceId).toBeTruthy();
      expect(registry.getByUri(`res://textures/Cube/${n}.png`)?.kind).toBe('texture');
    }
    const manifestFile = project.files['res://textures/Cube_material.json'];
    expect(manifestFile.resourceId).toBeTruthy();
    expect(registry.getByUri('res://textures/Cube_material.json')?.kind).toBe('material');
    expect(manifestFile.content).not.toContain('data:image');
    expect(manifestFile.content).not.toContain('base64');
    const parsed = parseModelMaterialManifest(manifestFile.content);
    expect(parsed.ok && parsed.legacy).toBe(false);
    if (!parsed.ok) return;
    const casco = parsed.manifest.materials.find((m) => m.name === 'Casco')!;
    expect(casco.source).toBe('procedural');
    expect(casco.maps.albedo?.id).toBe(project.files['res://textures/Cube/1.png'].resourceId);
    expect(casco.maps.normal?.id).toBe(project.files['res://textures/Cube/2.png'].resourceId);
    expect(parsed.manifest.materials.find((m) => m.name === 'Vidro')!.source).toBe('embedded');
    expect(parsed.manifest.asset.id).toBe(project.files['res://models/Cube.glb'].resourceId);
    // o modelo aponta para o manifesto e para o que o import gerou
    const settings = project.files['res://models/Cube.glb'].importSettings;
    expect(settings.materials.id).toBe(manifestFile.resourceId);
    expect(settings.outputs.map((o: { id: string }) => o.id)).toEqual(expect.arrayContaining([manifestFile.resourceId, project.files['res://textures/Cube/1.png'].resourceId]));
    // o grafo enxerga manifesto → PNGs
    const deps2 = extractDependencies('material', 'res://textures/Cube_material.json', manifestFile.content).map((d) => d.targetUri);
    expect(deps2.some((d) => String(d).includes('res://textures/Cube/1.png'))).toBe(true);
    // o nó leva só os materiais alterados, com o albedo gerado por ResourceRef
    expect(added).toHaveLength(1);
    const slots = added[0].props.materialSlots;
    expect(Object.keys(slots)).toEqual(['Casco']);
    expect(slots.Casco.albedoTexture.id).toBe(project.files['res://textures/Cube/1.png'].resourceId);
    expect(slots.Casco.normalTexture.id).toBe(project.files['res://textures/Cube/2.png'].resourceId);
    expect(slots.Casco.roughness).toBe(0.9);
    expect(JSON.stringify(added[0].props)).not.toContain('data:image');
  });

  it('sem edição nem imagem: nenhum slot, mas o manifesto ainda descreve os materiais', async () => {
    const { project, deps, added } = setup();
    const infos = [info()];
    const r = await importModelAsset({ ...baseInput(), materials: { edits: infos.map(editFromInfo), infos, images: [] } }, deps);
    expect(r.ok).toBe(true);
    expect(added[0].props.materialSlots).toBeUndefined();
    expect(project.files['res://textures/Cube_material.json']).toBeTruthy();
  });

  it('nome da pasta de texturas livre: Cube, Cube_2…', () => {
    expect(uniqueTextureStem('Cube', new Set())).toBe('Cube');
    expect(uniqueTextureStem('Cube', new Set(['res://textures/Cube/1.png']))).toBe('Cube_2');
    expect(uniqueTextureStem('Cube', new Set(['res://textures/Cube_material.json', 'res://textures/Cube_2/1.png']))).toBe('Cube_3');
  });

  it('falha num PNG: nenhum nó e nenhum arquivo parcial (rollback total)', async () => {
    const { project, deps, added, discarded } = setup();
    const bad: MaterialImageInput[] = [{ material: 'Casco', map: 'albedo', source: 'procedural', dataUrl: PNG, apply: true }, { material: 'Casco', map: 'normal', source: 'procedural', dataUrl: 'não-é-data-url', apply: false }];
    const r = await importModelAsset({ ...baseInput(), materials: materialsInput(bad) }, deps);
    expect(r.ok).toBe(false);
    expect(added).toHaveLength(0);
    expect(discarded).toEqual(expect.arrayContaining(['res://textures/Cube/1.png', 'res://models/Cube.glb']));
    expect(Object.keys(project.files).filter((u) => u.startsWith('res://textures/') || u.startsWith('res://models/'))).toEqual([]);
  });

  it('reimportar com o mesmo nome não sobrescreve a pasta anterior (Cube_2)', async () => {
    const { project, deps } = setup();
    await importModelAsset({ ...baseInput(), materials: materialsInput(images) }, deps);
    await importModelAsset({ ...baseInput(), materials: materialsInput(images) }, deps);
    expect(project.files['res://textures/Cube_2/1.png']).toBeTruthy();
    expect(project.files['res://textures/Cube_2_material.json']).toBeTruthy();
  });
});
