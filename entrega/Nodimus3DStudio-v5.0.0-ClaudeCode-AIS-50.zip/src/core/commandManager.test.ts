import { describe, expect, it, vi } from 'vitest';
import { CommandManager } from './commandManager';
import { getCommandLabel, type ICommand } from '../types/commands';

const counter = (label = 'Inc') => {
  const state = { n: 0 };
  const cmd: ICommand = { label, execute: () => void state.n++, undo: () => void state.n-- };
  return { state, cmd };
};

describe('CommandManager (AIS-18)', () => {
  it('pushCommand executa, registra e atribui timestamp', () => {
    const m = new CommandManager();
    const { state, cmd } = counter();
    m.pushCommand(cmd);
    expect(state.n).toBe(1);
    expect(m.canUndo()).toBe(true);
    expect(typeof cmd.timestamp).toBe('number');
    expect(m.getHistory()).toEqual([{ label: 'Inc', timestamp: cmd.timestamp }]);
  });

  it('undo/redo restauram e reaplicam; novo Command limpa o redo', () => {
    const m = new CommandManager();
    const a = counter('A');
    m.pushCommand(a.cmd);
    m.undo();
    expect(a.state.n).toBe(0);
    expect(m.canRedo()).toBe(true);
    expect(m.getRedoLabel()).toBe('A');
    m.redo();
    expect(a.state.n).toBe(1);
    m.undo();
    m.pushCommand(counter('B').cmd);
    expect(m.canRedo()).toBe(false);
  });

  it('histórico sem limite numérico (muito além de 50 e 100)', () => {
    const m = new CommandManager();
    const { state, cmd } = counter();
    for (let i = 0; i < 500; i++) m.pushCommand({ ...cmd });
    expect(m.getHistory()).toHaveLength(500);
    for (let i = 0; i < 500; i++) m.undo();
    expect(state.n).toBe(0);
    expect(m.canUndo()).toBe(false);
  });

  it('label canônico; name e description aceitos', () => {
    const noop = () => {};
    expect(getCommandLabel({ label: 'L', name: 'N', execute: noop, undo: noop })).toBe('L');
    expect(getCommandLabel({ name: 'N', execute: noop, undo: noop })).toBe('N');
    expect(getCommandLabel({ description: 'D', execute: noop, undo: noop })).toBe('D');
  });

  it('clearHistory esvazia as duas pilhas', () => {
    const m = new CommandManager();
    m.pushCommand(counter().cmd);
    m.undo();
    m.clearHistory();
    expect(m.canUndo()).toBe(false);
    expect(m.canRedo()).toBe(false);
  });

  it('notifica assinantes e incrementa a versão; unsubscribe para de notificar', () => {
    const m = new CommandManager();
    const listener = vi.fn();
    const off = m.subscribe(listener);
    const v0 = m.getVersion();
    m.pushCommand(counter().cmd);
    m.undo();
    m.redo();
    m.clearHistory();
    expect(listener).toHaveBeenCalledTimes(4);
    expect(m.getVersion()).toBe(v0 + 4);
    off();
    m.pushCommand(counter().cmd);
    expect(listener).toHaveBeenCalledTimes(4);
  });

  it('Command que falha ao executar não entra no histórico; falha no undo mantém a pilha', () => {
    const m = new CommandManager();
    expect(() =>
      m.pushCommand({ label: 'Boom', execute: () => { throw new Error('x'); }, undo: () => {} })
    ).toThrow();
    expect(m.canUndo()).toBe(false);

    let fail = true;
    m.pushCommand({ label: 'U', execute: () => {}, undo: () => { if (fail) throw new Error('u'); } });
    expect(() => m.undo()).toThrow();
    expect(m.canUndo()).toBe(true);
    fail = false;
    m.undo();
    expect(m.canUndo()).toBe(false);
  });

  it('redo usa command.redo quando existe', () => {
    const m = new CommandManager();
    const redo = vi.fn();
    const exec = vi.fn();
    m.pushCommand({ label: 'R', execute: exec, undo: () => {}, redo });
    m.undo();
    m.redo();
    expect(redo).toHaveBeenCalledTimes(1);
    expect(exec).toHaveBeenCalledTimes(1);
  });
});
