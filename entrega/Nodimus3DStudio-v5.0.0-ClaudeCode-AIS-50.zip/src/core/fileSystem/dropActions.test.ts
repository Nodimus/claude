import { describe, expect, it } from 'vitest';
import { DEFAULT_VIDEO_SETTINGS } from '../../types/video';
import { nodeMaterialOverride, textureRefFromPath } from '../material/nodeMaterial';
import { buildVideoScreenSpec } from './videoScreen';
import { resolveFileAction } from './fileActions';
import {
  SCENE_DROP_HINT,
  materialDropOverride,
  nodeNameFromPath,
  resolveDropAction,
  spriteProjectRef,
  textureDropOverride,
  videoDropSettings,
} from './dropActions';

const f = (path: string) => ({ path });

describe('resolveDropAction (AIS-31-C01: consome resolveFileAction)', () => {
  it('modelo 3D abre o importador, com ou sem malha sob o cursor', () => {
    for (const n of ['a.glb', 'a.gltf', 'a.obj']) {
      expect(resolveDropAction(f(`res://models/${n}`), false)).toEqual({ kind: 'importModel', path: `res://models/${n}` });
      expect(resolveFileAction(f(`res://models/${n}`)).kind).toBe('assetImport');
    }
  });
  it('textura de res://textures sobre malha aplica; sem malha é recusada', () => {
    expect(resolveDropAction(f('res://textures/a.png'), true)).toEqual({ kind: 'applyTexture', path: 'res://textures/a.png' });
    expect(resolveDropAction(f('res://textures/a.png'), false).kind).toBe('reject');
  });
  it('imagem fora de res://textures não é textura', () => {
    expect(resolveDropAction(f('res://other/a.png'), true).kind).toBe('ignore');
  });
  it('.mat.json sobre malha aplica o material', () => {
    expect(resolveDropAction(f('res://materials/Gold.mat.json'), true).kind).toBe('applyMaterial');
    expect(resolveDropAction(f('res://materials/Gold.material.json'), true).kind).toBe('applyMaterial');
    expect(resolveDropAction(f('res://materials/Gold.mat.json'), false).kind).toBe('reject');
  });
  it('.sprite.json cria Billboard e .video.json cria tela de vídeo', () => {
    expect(resolveDropAction(f('res://sprites/Hero.sprite.json'), false).kind).toBe('createBillboard');
    expect(resolveDropAction(f('res://videos/Tv.video.json'), false).kind).toBe('createVideoScreen');
  });
  it('vídeo cru é recusado com orientação', () => {
    expect(resolveDropAction(f('res://videos/a.mp4'), false).kind).toBe('reject');
  });
  it('cena não é instanciável: recusa e aponta o prefab', () => {
    expect(resolveDropAction(f('res://scenes/Main.scene.json'), false)).toEqual({ kind: 'reject', reason: SCENE_DROP_HINT });
  });
  it('script, áudio e pasta nunca instanciam', () => {
    for (const p of ['res://scripts/a.js', 'res://scripts/a.ts', 'res://audio/a.wav', 'res://x/y.bin']) {
      expect(resolveDropAction(f(p), true).kind).toBe('ignore');
    }
    expect(resolveDropAction({ path: 'res://audio/', isDirectory: true }, true).kind).toBe('ignore');
  });
  it('prefab recusa com "em breve"', () => {
    const a = resolveDropAction(f('res://prefabs/Door.prefab.json'), true);
    expect(a.kind).toBe('reject');
  });
});

describe('textureDropOverride', () => {
  it('põe a textura no albedo e preserva o resto do material do nó', () => {
    const props = { materialOverride: { roughness: 0.2, color: { r: 1, g: 0, b: 0, a: 1 } } };
    const ref = textureRefFromPath('res://textures/brick.png');
    const next = textureDropOverride(props, ref);
    expect(next.albedoTexture).toEqual(ref);
    expect(next.roughness).toBe(0.2);
    expect(nodeMaterialOverride({ materialOverride: next }).color).toEqual({ r: 1, g: 0, b: 0, a: 1 });
  });
});

describe('materialDropOverride', () => {
  it('converte as propriedades do .mat.json em override (só o que difere do padrão)', () => {
    const r = materialDropOverride(JSON.stringify({ name: 'Gold', roughness: 0.15, metalness: 1, color: { r: 1, g: 0.8, b: 0.2, a: 1 } }));
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.override.roughness).toBe(0.15);
      expect(r.override.metalness).toBe(1);
      expect(r.override.albedoTexture).toBeUndefined();
      expect('name' in r.override).toBe(false);
    }
  });
  it('custom_image sem arquivo volta a "none"', () => {
    const r = materialDropOverride(JSON.stringify({ textureType: 'custom_image', customImageDataUrl: 'data:image/png;base64,AAAA' }));
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.override.textureType).toBeUndefined();
  });
  it('JSON inválido, vazio ou não-objeto não quebra', () => {
    expect(materialDropOverride('{ quebrado')).toEqual({ ok: false, error: 'JSON de material inválido' });
    expect(materialDropOverride('')).toMatchObject({ ok: false });
    expect(materialDropOverride(undefined)).toMatchObject({ ok: false });
    expect(materialDropOverride('[1]')).toMatchObject({ ok: false });
  });
});

describe('videoDropSettings / buildVideoScreenSpec', () => {
  it('completa campos ausentes com os padrões', () => {
    const r = videoDropSettings(JSON.stringify({ name: 'Tv', shape: 'Cube' }));
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.settings.shape).toBe('Cube');
      expect(r.settings.roughness).toBe(DEFAULT_VIDEO_SETTINGS.roughness);
    }
  });
  it('forma → tipo de malha, igual ao VideoEditorModal', () => {
    const base = DEFAULT_VIDEO_SETTINGS;
    expect(buildVideoScreenSpec({ ...base, shape: 'Cube' }).properties.meshType).toBe('BoxMesh');
    expect(buildVideoScreenSpec({ ...base, shape: 'Sphere360' }).properties.meshType).toBe('SphereMesh');
    expect(buildVideoScreenSpec({ ...base, shape: 'CurvedScreen' }).properties.meshType).toBe('CylinderMesh');
    expect(buildVideoScreenSpec({ ...base, shape: 'Cube' }).name).toBe('VideoScreen_Cube');
  });
  it('JSON inválido é erro, não exceção', () => {
    expect(videoDropSettings('nope')).toEqual({ ok: false, error: 'JSON de vídeo inválido' });
  });
});

describe('helpers de nome e referência', () => {
  it('nome do nó vem do arquivo sem sufixos compostos', () => {
    expect(nodeNameFromPath('res://sprites/Hero.sprite.json')).toBe('Hero');
    expect(nodeNameFromPath('res://videos/Tv.video.json')).toBe('Tv');
  });
  it('referência de sprite usa o registry quando existe, senão uma estável por caminho', () => {
    const reg = { id: 'abc', type: 'sprite', path: 'res://sprites/H.sprite.json' };
    expect(spriteProjectRef('res://sprites/H.sprite.json', reg)).toBe(reg);
    expect(spriteProjectRef('res://sprites/H.sprite.json')).toMatchObject({ id: 'res:res://sprites/H.sprite.json', type: 'sprite' });
  });
});
