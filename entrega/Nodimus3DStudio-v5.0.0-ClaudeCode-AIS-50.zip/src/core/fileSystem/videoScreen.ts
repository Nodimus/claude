import type { VideoClipSettings } from '../../types/video';
import { patchNodeMaterial } from '../material/nodeMaterial';

/**
 * Nó "Tela de Vídeo" a partir das configurações de um clipe: única fonte para o `VideoEditorModal` (botão criar na
 * cena) e para soltar um `.video.json` no viewport/árvore (AIS-31).
 */
export function buildVideoScreenSpec(settings: VideoClipSettings): { name: string; properties: Record<string, unknown> } {
  let meshType = 'PlaneMesh';
  if (settings.shape === 'CurvedScreen' || settings.shape === 'Cylinder') meshType = 'CylinderMesh';
  else if (settings.shape === 'Cube') meshType = 'BoxMesh';
  else if (settings.shape === 'Sphere360') meshType = 'SphereMesh';

  return {
    name: `VideoScreen_${settings.shape}`,
    properties: {
      meshType,
      videoSettings: settings,
      materialOverride: patchNodeMaterial({}, {
        emissiveIntensity: settings.emissiveIntensity,
        roughness: settings.roughness,
        metalness: settings.metalness,
      }),
    },
  };
}
