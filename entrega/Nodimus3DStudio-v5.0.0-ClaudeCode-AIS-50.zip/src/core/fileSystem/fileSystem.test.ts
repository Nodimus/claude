import { describe, expect, it } from 'vitest';
import { PREFAB_COMING_SOON, UPLOAD_ACCEPT, isBinaryUploadName, isModelFileName, resolveFileAction } from './fileActions';
import {
  allFolderPaths,
  baseNameOf,
  collectDeleteTargets,
  parentFolderOf,
  pathInFolder,
  pathWithName,
  planPathChange,
  remapPath,
  uniqueName,
  validMoveDestinations,
  validateName,
} from './fileOps';

const f = (path: string) => ({ path });

describe('resolveFileAction (AIS-28-C01/C02)', () => {
  it('sufixos compostos vencem .json', () => {
    expect(resolveFileAction(f('res://scenes/Main.scene.json')).kind).toBe('loadScene');
    expect(resolveFileAction(f('res://materials/Gold.mat.json')).kind).toBe('texturePreview');
    expect(resolveFileAction(f('res://materials/Gold.material.json')).kind).toBe('texturePreview');
    expect(resolveFileAction(f('res://sprites/Hero.sprite.json')).kind).toBe('spriteEditor');
    expect(resolveFileAction(f('res://videos/Tv.video.json')).kind).toBe('videoEditor');
    expect(resolveFileAction(f('res://data/config.json')).kind).toBe('scriptEditor');
  });
  it('prefab: reconhecido, mas desabilitado "em breve" (decisão do usuário)', () => {
    const a = resolveFileAction(f('res://prefabs/Door.prefab.json'));
    expect(a.kind).toBe('comingSoon');
    expect(a.hint).toBe(PREFAB_COMING_SOON);
  });
  it('texto e scripts abrem no editor de código', () => {
    for (const n of ['a.js', 'a.ts', 'a.xml', 'a.html', 'a.css', 'a.md', 'a.txt']) expect(resolveFileAction(f(`res://scripts/${n}`)).kind).toBe('scriptEditor');
  });
  it('modelos 3D, áudio, vídeo e texturas', () => {
    for (const n of ['a.gltf', 'a.glb', 'a.obj', 'a.fbx', 'a.dae']) expect(resolveFileAction(f(`res://models/${n}`)).kind).toBe('assetImport');
    for (const n of ['a.wav', 'a.ogg', 'a.mp3']) expect(resolveFileAction(f(`res://audio/${n}`)).kind).toBe('audio');
    for (const n of ['a.mp4', 'a.webm', 'a.mov', 'a.ogv']) expect(resolveFileAction(f(`res://videos/${n}`)).kind).toBe('videoEditor');
    expect(resolveFileAction(f('res://textures/a.png')).kind).toBe('texturePreview');
    expect(resolveFileAction(f('res://other/a.png')).kind).toBe('none');
  });
  it('não existe .logic nem .gd: nenhuma ação (decisão 5)', () => {
    expect(resolveFileAction(f('res://scripts/Behavior_1.logic')).kind).toBe('none');
    expect(resolveFileAction(f('res://scripts/old.gd')).kind).toBe('none');
    expect(UPLOAD_ACCEPT).not.toMatch(/\.logic|\.gd/);
  });
  it('pasta e extensão desconhecida: nada', () => {
    expect(resolveFileAction({ path: 'res://audio/', isDirectory: true }).kind).toBe('none');
    expect(resolveFileAction(f('res://x/y.bin')).kind).toBe('none');
    expect(resolveFileAction({ path: 'res://x/Y', extension: 'GLB' }).kind).toBe('assetImport');
  });
  it('import de modelo nunca pula o modal; upload classifica binários', () => {
    expect(isModelFileName('Robot.FBX')).toBe(true);
    expect(isModelFileName('a.png')).toBe(false);
    expect(isBinaryUploadName('a.mp4')).toBe(true);
    expect(isBinaryUploadName('a.json')).toBe(false);
    for (const ext of ['.fbx', '.dae', '.mp4', '.webm']) expect(UPLOAD_ACCEPT).toContain(ext);
  });
});

describe('nomes e caminhos', () => {
  it('validateName', () => {
    expect(validateName('ok.txt').ok).toBe(true);
    for (const bad of ['', ' ', 'a/b', 'a\\b', 'a:b', ' x', 'x ', '..', 'a*b']) expect(validateName(bad).ok).toBe(false);
  });
  it('pai, nome base, renomear e mover', () => {
    expect(parentFolderOf('res://a/b.txt')).toBe('res://a/');
    expect(parentFolderOf('res://a/')).toBe('res://');
    expect(parentFolderOf('res://')).toBeNull();
    expect(baseNameOf('res://a/sub/')).toBe('sub');
    expect(pathWithName('res://a/b.txt', 'c.txt')).toBe('res://a/c.txt');
    expect(pathWithName('res://a/sub/', 'x')).toBe('res://a/x/');
    expect(pathInFolder('res://a/b.txt', 'res://z/')).toBe('res://z/b.txt');
    expect(pathInFolder('res://a/sub/', 'res://z/')).toBe('res://z/sub/');
  });
});

describe('planPathChange (AIS-28-C03/C10/C12)', () => {
  const files = {
    'res://a/': { isDirectory: true },
    'res://a/one.txt': { isDirectory: false },
    'res://a/sub/': { isDirectory: true },
    'res://a/sub/two.txt': { isDirectory: false },
    'res://b/': { isDirectory: true },
    'res://b/one.txt': { isDirectory: false },
  };
  it('renomear arquivo', () => {
    expect(planPathChange(files, 'res://a/one.txt', 'res://a/uno.txt')).toEqual({ ok: true, moves: [['res://a/one.txt', 'res://a/uno.txt']] });
  });
  it('renomear/mover pasta leva os descendentes junto', () => {
    const plan = planPathChange(files, 'res://a/', 'res://c/');
    expect(plan.ok).toBe(true);
    expect(plan.moves).toEqual([
      ['res://a/', 'res://c/'],
      ['res://a/one.txt', 'res://c/one.txt'],
      ['res://a/sub/', 'res://c/sub/'],
      ['res://a/sub/two.txt', 'res://c/sub/two.txt'],
    ]);
  });
  it('conflito de nome no destino: nunca sobrescreve', () => {
    const plan = planPathChange(files, 'res://a/one.txt', 'res://b/one.txt');
    expect(plan.ok).toBe(false);
    expect(plan.conflict).toBe(true);
    expect(planPathChange(files, 'res://a/', 'res://b/').conflict).toBe(true);
  });
  it('bloqueios: raiz, mesma origem/destino, pasta dentro de si mesma, arquivo inexistente', () => {
    expect(planPathChange(files, 'res://', 'res://x/').ok).toBe(false);
    expect(planPathChange(files, 'res://a/one.txt', 'res://a/one.txt').ok).toBe(false);
    expect(planPathChange(files, 'res://a/', 'res://a/sub/a/').ok).toBe(false);
    expect(planPathChange(files, 'res://nao.txt', 'res://x.txt').ok).toBe(false);
  });
  it('pasta implícita (só existe pelos filhos) também se move', () => {
    const plan = planPathChange({ 'res://x/y.txt': { isDirectory: false } }, 'res://x/', 'res://z/');
    expect(plan.ok).toBe(true);
    expect(plan.moves).toEqual([['res://x/', 'res://z/'], ['res://x/y.txt', 'res://z/y.txt']]);
  });
  it('uniqueName sugere nome livre', () => {
    expect(uniqueName(files, 'res://b/', 'one.txt', false)).toBe('one (2).txt');
    expect(uniqueName(files, 'res://b/', 'novo.txt', false)).toBe('novo.txt');
    expect(uniqueName(files, 'res://', 'a', true)).toBe('a (2)');
  });
  it('remapPath acompanha o item movido (ex.: cena principal)', () => {
    expect(remapPath('res://a/one.txt', [['res://a/one.txt', 'res://c/one.txt']])).toBe('res://c/one.txt');
    expect(remapPath('res://q', [['res://a/', 'res://c/']])).toBe('res://q');
  });
});

describe('exclusão e seletor de pasta', () => {
  const files = {
    'res://a/': { isDirectory: true },
    'res://a/one.txt': { isDirectory: false },
    'res://a/sub/two.txt': { isDirectory: false },
    'res://b/x.txt': { isDirectory: false },
  };
  it('excluir pasta leva o conteúdo; raiz nunca', () => {
    expect(collectDeleteTargets(files, 'res://a/').sort()).toEqual(['res://a/', 'res://a/one.txt', 'res://a/sub/two.txt']);
    expect(collectDeleteTargets(files, 'res://b/x.txt')).toEqual(['res://b/x.txt']);
    expect(collectDeleteTargets(files, 'res://')).toEqual([]);
    expect(collectDeleteTargets(files, 'res://nao.txt')).toEqual([]);
  });
  it('allFolderPaths inclui pastas implícitas e a raiz', () => {
    expect(allFolderPaths(files)).toEqual(['res://', 'res://a/', 'res://a/sub/', 'res://b/']);
  });
  it('destinos válidos de "Mover para...": sem a pasta atual, sem si mesma, sem descendentes', () => {
    expect(validMoveDestinations(files, 'res://a/one.txt')).toEqual(['res://', 'res://a/sub/', 'res://b/']);
    expect(validMoveDestinations(files, 'res://a/')).toEqual(['res://b/']);
  });
});
