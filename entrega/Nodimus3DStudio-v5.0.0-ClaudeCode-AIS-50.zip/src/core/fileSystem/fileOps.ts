/**
 * AIS-28 — operações puras sobre o mapa de arquivos virtual (`ProjectData.files`): renomear, mover, excluir e listar
 * pastas. Calculam o PLANO (mapeamento de caminhos e conflitos); quem grava é o adapter provisório do EditorContext
 * (até o `moveResource`/`deleteResource` do AIS-29e). Não são Commands: afetam o sistema de arquivos, não entram no Undo.
 */

export const RES_ROOT = 'res://';

type FileMap = Record<string, { isDirectory: boolean }>;

export const isFolderPath = (path: string): boolean => path.endsWith('/');
const withSlash = (p: string) => (p.endsWith('/') ? p : p + '/');

/** Pasta que contém `path` (`res://` na raiz); `null` para a própria raiz. */
export function parentFolderOf(path: string): string | null {
  if (path === RES_ROOT || !path.startsWith(RES_ROOT)) return null;
  const clean = path.endsWith('/') ? path.slice(0, -1) : path;
  const i = clean.lastIndexOf('/');
  return i < RES_ROOT.length - 1 ? RES_ROOT : clean.slice(0, i + 1);
}

export function baseNameOf(path: string): string {
  const clean = path.endsWith('/') ? path.slice(0, -1) : path;
  return clean.slice(clean.lastIndexOf('/') + 1);
}

/** Nome válido de arquivo/pasta: sem separadores, sem `:`/`*`/`?`/aspas/`<>|`, sem espaços nas pontas, não vazio. */
export function validateName(name: string): { ok: boolean; error?: string } {
  const n = name;
  if (!n.trim()) return { ok: false, error: 'O nome não pode ser vazio.' };
  if (n !== n.trim()) return { ok: false, error: 'O nome não pode começar nem terminar com espaço.' };
  if (n === '.' || n === '..') return { ok: false, error: 'Nome inválido.' };
  if (/[\\/:*?"<>|]/.test(n)) return { ok: false, error: 'O nome não pode conter \\ / : * ? " < > |.' };
  if (n.length > 120) return { ok: false, error: 'O nome é longo demais (máximo 120 caracteres).' };
  return { ok: true };
}

/** Caminho de `path` depois de trocar o nome (mesma pasta). */
export function pathWithName(path: string, newName: string): string {
  const parent = parentFolderOf(path) ?? RES_ROOT;
  return parent + newName + (isFolderPath(path) ? '/' : '');
}

/** Caminho de `path` dentro da pasta `destFolder` (mesmo nome). */
export function pathInFolder(path: string, destFolder: string): string {
  return withSlash(destFolder) + baseNameOf(path) + (isFolderPath(path) ? '/' : '');
}

export interface PathChangePlan {
  ok: boolean;
  /** Pares [de, para] de TODOS os itens afetados (pasta + descendentes). */
  moves: [string, string][];
  /** Motivo quando `!ok`. */
  error?: string;
  /** `true` quando o destino já existe (o painel pergunta por novo nome ou cancela). */
  conflict?: boolean;
}

/**
 * Plano de renomear/mover `from` → `to`. Bloqueia: raiz, mover pasta para dentro de si mesma, destino igual à origem
 * e conflito de nome no destino (nunca sobrescreve).
 */
export function planPathChange(files: FileMap, from: string, to: string): PathChangePlan {
  if (from === RES_ROOT) return { ok: false, moves: [], error: 'A raiz res:// não pode ser alterada.' };
  if (from === to) return { ok: false, moves: [], error: 'Origem e destino são iguais.' };
  const folder = isFolderPath(from);
  if (folder && to.startsWith(from)) return { ok: false, moves: [], error: 'Uma pasta não pode ser movida para dentro dela mesma.' };

  const moving = Object.keys(files).filter((p) => p === from || (folder && p.startsWith(from)));
  if (!moving.length && !folder) return { ok: false, moves: [], error: 'Arquivo não encontrado.' };
  const moves: [string, string][] = moving.map((p) => [p, to + p.slice(from.length)]);
  if (folder && !files[from]) moves.unshift([from, to]); // pasta implícita (só existe por causa dos filhos)

  const moveSet = new Set(moving);
  const occupied = (p: string) => (files[p] !== undefined && !moveSet.has(p)) || (isFolderPath(p) && Object.keys(files).some((k) => k.startsWith(p) && !moveSet.has(k)));
  if (occupied(to)) return { ok: false, moves: [], conflict: true, error: `Já existe um item chamado "${baseNameOf(to)}" no destino.` };
  return { ok: true, moves };
}

/** Nome livre na pasta (`nome (2).ext`) para sugerir no diálogo de conflito. */
export function uniqueName(files: FileMap, folder: string, name: string, isFolder: boolean): string {
  const dot = isFolder ? -1 : name.lastIndexOf('.');
  const stem = dot > 0 ? name.slice(0, dot) : name;
  const ext = dot > 0 ? name.slice(dot) : '';
  const exists = (n: string) => files[withSlash(folder) + n + (isFolder ? '/' : '')] !== undefined;
  if (!exists(name)) return name;
  for (let i = 2; i < 1000; i++) {
    const candidate = `${stem} (${i})${ext}`;
    if (!exists(candidate)) return candidate;
  }
  return `${stem}_${Date.now()}${ext}`;
}

/** Caminhos que uma exclusão remove: o item e, se for pasta, tudo abaixo dela. A raiz nunca é excluível. */
export function collectDeleteTargets(files: FileMap, path: string): string[] {
  if (path === RES_ROOT) return [];
  if (!isFolderPath(path)) return files[path] ? [path] : [];
  return Object.keys(files).filter((p) => p === path || p.startsWith(path));
}

/** Todas as pastas (reais e implícitas), com `res://`, em ordem alfabética — alimenta o seletor "Mover para...". */
export function allFolderPaths(files: FileMap): string[] {
  const set = new Set<string>([RES_ROOT]);
  for (const [p, f] of Object.entries(files)) {
    if (f.isDirectory) set.add(withSlash(p));
    let cur = parentFolderOf(p);
    while (cur && cur !== RES_ROOT) {
      set.add(cur);
      cur = parentFolderOf(cur);
    }
  }
  return [...set].sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
}

/** Pastas de destino válidas para mover `path` (exclui a pasta atual do item, ele mesmo e seus descendentes). */
export function validMoveDestinations(files: FileMap, path: string): string[] {
  const current = parentFolderOf(path);
  return allFolderPaths(files).filter((f) => f !== current && !(isFolderPath(path) && (f === path || f.startsWith(path))));
}

/** Atualiza um caminho único (ex.: cena principal) depois de um plano de mover; igual se não foi afetado. */
export function remapPath(path: string, moves: readonly [string, string][]): string {
  for (const [from, to] of moves) if (path === from) return to;
  return path;
}
