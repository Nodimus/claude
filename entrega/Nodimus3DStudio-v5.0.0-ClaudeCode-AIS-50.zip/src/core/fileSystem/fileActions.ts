/**
 * AIS-28 — `resolveFileAction(file)`: roteador ÚNICO do duplo clique no FileSystemPanel (reutilizado pelo AIS-31).
 * Função pura: só decide o destino; quem abre o editor é o painel. Sufixos compostos (`.scene.json`, `.mat.json`…)
 * são testados ANTES de `.json`. Não existe `.logic`/`.gd` (decisão 5: Logic Script não é arquivo).
 */

export type FileActionKind =
  | 'loadScene'
  | 'scriptEditor'
  | 'texturePreview'
  | 'assetImport'
  | 'audio'
  | 'spriteEditor'
  | 'videoEditor'
  /** Reconhecido, mas o recurso ainda não existe (decisão 14): desabilitado com tooltip "em breve". */
  | 'comingSoon'
  /** Sem editor associado: o duplo clique não faz nada. */
  | 'none';

export interface FileAction {
  kind: FileActionKind;
  /** Texto do tooltip quando `comingSoon`. */
  hint?: string;
}

export interface FileLike {
  path: string;
  isDirectory?: boolean;
  extension?: string;
}

const SCRIPT_EDITOR_EXTENSIONS = ['js', 'ts', 'jsx', 'tsx', 'json', 'xml', 'svg', 'html', 'css', 'md', 'txt', 'glsl', 'shader', 'cfg', 'ini'];
const MODEL_EXTENSIONS = ['gltf', 'glb', 'obj', 'fbx', 'dae'];
const AUDIO_EXTENSIONS = ['wav', 'ogg', 'mp3'];
const VIDEO_EXTENSIONS = ['mp4', 'webm', 'mov', 'ogv'];
const IMAGE_EXTENSIONS = ['png', 'jpg', 'jpeg', 'webp'];

export const PREFAB_COMING_SOON = 'em breve — o prefab abrirá no Scene Editor em modo Prefab (AIS-81)';

/** Extensão em minúsculas, a partir de `extension` ou do nome (sem ponto). */
export function extensionOf(file: FileLike): string {
  if (file.extension) return file.extension.toLowerCase();
  const name = file.path.split('/').pop() ?? '';
  const dot = name.lastIndexOf('.');
  return dot > 0 ? name.slice(dot + 1).toLowerCase() : '';
}

export function resolveFileAction(file: FileLike): FileAction {
  if (file.isDirectory) return { kind: 'none' };
  const path = file.path.toLowerCase();
  const ext = extensionOf(file);

  // sufixos compostos vencem `.json`
  if (path.endsWith('.scene.json')) return { kind: 'loadScene' };
  if (path.endsWith('.prefab.json')) return { kind: 'comingSoon', hint: PREFAB_COMING_SOON };
  if (path.endsWith('.sprite.json')) return { kind: 'spriteEditor' };
  if (path.endsWith('.video.json')) return { kind: 'videoEditor' };
  if (path.endsWith('.mat.json') || path.endsWith('.material.json')) return { kind: 'texturePreview' };

  if (MODEL_EXTENSIONS.includes(ext)) return { kind: 'assetImport' };
  if (AUDIO_EXTENSIONS.includes(ext)) return { kind: 'audio' };
  if (VIDEO_EXTENSIONS.includes(ext)) return { kind: 'videoEditor' };
  if (IMAGE_EXTENSIONS.includes(ext) && path.startsWith('res://textures/')) return { kind: 'texturePreview' };
  if (SCRIPT_EDITOR_EXTENSIONS.includes(ext)) return { kind: 'scriptEditor' };
  return { kind: 'none' };
}

/** Modelo 3D: nenhum caminho de import de modelo pula o `AssetImportModal` (AIS-28-C04). */
export const isModelFileName = (name: string): boolean => MODEL_EXTENSIONS.includes((name.split('.').pop() ?? '').toLowerCase());

/** Tipos que o upload lê como texto; o resto (imagem, áudio, vídeo) vira data URL. */
export const isBinaryUploadName = (name: string): boolean => {
  const ext = (name.split('.').pop() ?? '').toLowerCase();
  return IMAGE_EXTENSIONS.includes(ext) || AUDIO_EXTENSIONS.includes(ext) || VIDEO_EXTENSIONS.includes(ext);
};

/** Valor do atributo `accept` do input de upload (inclui `.fbx`, `.dae` e vídeo; sem `.gd`). */
export const UPLOAD_ACCEPT = [
  ...IMAGE_EXTENSIONS,
  ...MODEL_EXTENSIONS,
  ...AUDIO_EXTENSIONS,
  ...VIDEO_EXTENSIONS,
  'json',
  'js',
  'ts',
  'xml',
  'txt',
  'md',
]
  .map((e) => `.${e}`)
  .join(',');
