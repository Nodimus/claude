/**
 * AIS-43 — operações de variável usadas pela UI (aba Variables do Project Settings, seção Variables do Inspector).
 * Fina de propósito: a regra mora em `variableManager.ts` (funções puras) e a mutação em `VariableCommands.ts`; aqui só se
 * liga as portas (projeto, nó, Behaviors) ao `CommandManager`.
 */
import type { ICommand } from '../types/commands';
import type { Behavior } from '../types/visualLogic';
import type { ProjectGlobalVariable } from '../types/projectFile';
import type { BehaviorStore } from './commands/BehaviorCommands';
import { createSetGlobalVariablesCommand, createSetLocalVariablesCommand, type GlobalVariableStore, type LocalVariableStore } from './commands/VariableCommands';
import { findVariableConsumers, renameVariableReferences, type VariableConsumer } from './variableManager';

export interface VariableOpsDeps {
  globals: GlobalVariableStore;
  locals: LocalVariableStore;
  behaviors: BehaviorStore;
  execute: (command: ICommand) => void;
  /** ID do nó por nome ou ID (alvos antigos gravavam o nome). */
  resolveNodeId?: (ref: string) => string | undefined;
}

export interface VariableOps {
  /** `renames`: pares nome antigo → novo já presentes em `next` (as referências dos Behaviors acompanham, no MESMO Command). */
  commitGlobals(next: ProjectGlobalVariable[], label: string, renames?: { from: string; to: string }[]): boolean;
  commitLocals(nodeId: string, next: Record<string, any>, label: string, renames?: { from: string; to: string }[]): boolean;
  globalConsumers(name: string): VariableConsumer[];
  localConsumers(nodeId: string, name: string): VariableConsumer[];
}

/** Várias renomeações de uma vez em DUAS fases (nome temporário), para que trocar a↔b não se atropele. */
export function renameAll(list: readonly Behavior[], scope: 'global' | 'local', renames: { from: string; to: string }[], scopeNodeId?: string, resolveNode?: (ref: string) => string | undefined): Behavior[] {
  const tmp = (i: number) => `__renaming_${i}__`; // só existe dentro desta função (improvável de colidir com um nome real)
  let out: Behavior[] = [...list];
  renames.forEach((r, i) => (out = renameVariableReferences(out, scope, r.from, tmp(i), scopeNodeId, resolveNode)));
  renames.forEach((r, i) => (out = renameVariableReferences(out, scope, tmp(i), r.to, scopeNodeId, resolveNode)));
  return out.every((b, i) => b === list[i]) ? [...list] : out;
}

export function createVariableOps(deps: VariableOpsDeps): VariableOps {
  const { globals, locals, behaviors, execute, resolveNodeId } = deps;
  return {
    commitGlobals(next, label, renames) {
      const rewrite = renames?.length ? { store: behaviors, next: renameAll(behaviors.get(), 'global', renames, undefined, resolveNodeId) } : undefined;
      const command = createSetGlobalVariablesCommand({ label, store: globals, next, behaviors: rewrite });
      if (command) execute(command);
      return !!command;
    },
    commitLocals(nodeId, next, label, renames) {
      const rewrite = renames?.length ? { store: behaviors, next: renameAll(behaviors.get(), 'local', renames, nodeId, resolveNodeId) } : undefined;
      const command = createSetLocalVariablesCommand({ label, store: locals, nodeId, next, behaviors: rewrite });
      if (command) execute(command);
      return !!command;
    },
    globalConsumers: (name) => findVariableConsumers(behaviors.get(), 'global', name, undefined, resolveNodeId),
    localConsumers: (nodeId, name) => findVariableConsumers(behaviors.get(), 'local', name, nodeId, resolveNodeId),
  };
}
