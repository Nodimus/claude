/**
 * @file editorStore.ts
 * @module core/editorStore
 *
 * AIS-03d — Zustand EditorStore (canonical)
 *
 * Single reactive state authority for IDE-level UI state:
 *  - Selection (primary + multi-select)
 *  - Active document / scene identity (path + name — NOT the scene graph)
 *  - Workspace / viewport mode
 *  - Manipulation (gizmo) mode
 *  - Layout: dialog/panel open-closed flags
 *  - Script editor tabs & active path
 *  - Bottom panel
 *  - Play-mode flags (mirrors, not data authority)
 *
 * ────────────────────────────────────────────────────────────────────
 * BOUNDARIES — things that MUST NOT live here:
 *  • THREE.Scene / Object3D / renderer / Rapier World / audio nodes
 *  • Undo/Redo stack (owned by CommandManager)
 *  • AuthoringModel data copy (AuthoringModel is the persistent authority)
 *  • RuntimeSession serialised state
 *  • SceneData / GameNode objects (owned by AuthoringModel)
 *
 * Persistent mutations (rename, move, property change …) MUST follow:
 *  UI → CommandManager → AuthoringModel → notify → store.syncXxx()
 * ────────────────────────────────────────────────────────────────────
 */

import { create } from 'zustand';
import { globalSelectionService } from './selection/SelectionService';

// ─── Types ────────────────────────────────────────────────────────────────────

/** Workspace modes matching the three central viewport workspaces. */
export type WorkspaceMode = '3D' | 'VisualLogic' | 'Script';

/**
 * Gizmo / transform-tool modes.
 * Q = select (neutral), W = translate, E = rotate, R = scale.
 * Matches canonical Item 2 keyboard shortcuts.
 */
export type ManipulationMode = 'select' | 'translate' | 'rotate' | 'scale';

/** AIS-09: grid snapping steps (meters) offered by the viewport precision toolbar. */
export const GRID_SNAP_STEPS = [0.1, 0.25, 0.5, 1, 2] as const;
export type GridSnapStep = (typeof GRID_SNAP_STEPS)[number];

/** AIS-09: angle snapping steps (degrees) for the rotate gizmo. */
export const ANGLE_SNAP_STEPS = [15, 30, 45, 90] as const;
export type AngleSnapStep = (typeof ANGLE_SNAP_STEPS)[number];

/**
 * AIS-09: viewport precision toolbar — independent toggles per snap type.
 * Transient IDE preference (not persisted in the project).
 */
export interface ViewportSnapSettings {
  gridEnabled: boolean;
  gridStep: GridSnapStep;
  angleEnabled: boolean;
  angleStep: AngleSnapStep;
  /** Translate drags place the object's base on the static mesh under the cursor. */
  surfaceEnabled: boolean;
}

/** Defaults preserve the shell's previous 3D snap (1 m / 15°, on). */
export const DEFAULT_VIEWPORT_SNAP: ViewportSnapSettings = {
  gridEnabled: true,
  gridStep: 1,
  angleEnabled: true,
  angleStep: 15,
  surfaceEnabled: false,
};

const PREF_SHOW_COLLIDERS = 'nodimus.pref.showColliders';
const PREF_ADD_WITH_COLLISION = 'nodimus.pref.addWithCollision';

/** Preferência de UI em localStorage (nunca no projeto); sem acesso ao storage, vale o padrão. */
function readEditorPref(key: string, fallback: boolean): boolean {
  try {
    const raw = globalThis.localStorage?.getItem(key);
    return raw === null || raw === undefined ? fallback : raw === '1';
  } catch {
    return fallback;
  }
}

function writeEditorPref(key: string, value: boolean): void {
  try {
    globalThis.localStorage?.setItem(key, value ? '1' : '0');
  } catch {
    /* storage indisponível: a preferência vale só na sessão */
  }
}

/**
 * Lightweight identity record for the active scene.
 * Contains only the path and display name — NOT the full SceneData graph,
 * which remains under AuthoringModel authority.
 */
export interface ActiveSceneRef {
  /** Canonical res:// path, e.g. "res://scenes/Main.scene.json" */
  path: string;
  /** Human-readable display name */
  name: string;
}

/**
 * Lightweight identity record for the active project.
 * Only id + name for display and routing — full ProjectData lives in AuthoringModel.
 */
export interface ActiveProjectRef {
  id: string;
  name: string;
}

// ─── Store Shape ──────────────────────────────────────────────────────────────

/** AIS-33: de onde o AssetImportModal carrega o modelo. `path` = arquivo de `res://` (os bytes saem do projeto); `bytes` = arquivo de fora do projeto (+ dependências do `.gltf`). */
export interface AssetImportSource {
  path?: string;
  name: string;
  bytes?: ArrayBuffer;
  siblings?: { rel: string; bytes: ArrayBuffer }[];
  /** AIS-38c: "Editar importação…" — o modal reabre este modelo com os ajustes salvos e aplica no nó (um Command). */
  reeditNodeId?: string;
}

/** AIS-38c: pedido ao FileSystemPanel para selecionar um arquivo ("Mostrar no FileSystem"). `nonce` permite repetir o mesmo caminho. */
export interface FileSystemRevealRequest {
  path: string;
  nonce: number;
}

export interface EditorStoreState {
  // ── Selection ───────────────────────────────────────────────────────────────
  /** Primary selected node ID. null = nothing selected. */
  selectedNodeId: string | null;
  /**
   * Additional node IDs in the multi-selection set (Ctrl+Click).
   * AIS-18b: SelectionService (`core/selection`) é a autoridade canônica;
   * esta é só uma projeção reativa para React — NÃO a trate como segunda
   * source of truth for domain logic.
   */
  multiSelectedNodeIds: string[];

  // ── Active Document / Scene Identity ────────────────────────────────────────
  /**
   * Identity ref of the currently open scene (path + name).
   * NOT the SceneData — the full graph is owned by AuthoringModel.
   */
  activeSceneRef: ActiveSceneRef | null;
  /** Identity ref of the active project. */
  activeProjectRef: ActiveProjectRef | null;

  // ── Viewport & Manipulation ──────────────────────────────────────────────────
  /** Which central workspace is currently shown. */
  workspaceMode: WorkspaceMode;
  /** Current gizmo mode in the 3D viewport (Q/W/E/R shortcuts). */
  manipulationMode: ManipulationMode;
  /** AIS-09: grid / angle / surface snapping of the 3D viewport. */
  viewportSnap: ViewportSnapSettings;
  /** AIS-26b: preferências do editor (localStorage, nunca no projeto) — "Mostrar colisores" e "Adicionar com colisão". */
  showColliders: boolean;
  addWithCollision: boolean;

  // ── Play Mode Flags (mirror — not data authority) ───────────────────────────
  isPlaying: boolean;
  isPaused: boolean;
  playMode: 'project' | 'scene' | null;

  // ── Bottom Panel ─────────────────────────────────────────────────────────────
  bottomTab: 'output' | 'debugger';
  isBottomOpen: boolean;

  // ── Script / Code Editor ─────────────────────────────────────────────────────
  activeScriptPath: string | null;
  openScriptTabs: string[];

  // ── Dialog / Panel Visibility Flags ─────────────────────────────────────────
  isProjectSettingsOpen: boolean;
  isProjectManagerOpen: boolean;
  isCreateNodeModalOpen: boolean;
  isPostProcessingOpen: boolean;
  isTerrainEditorOpen: boolean;
  isTreeEditorOpen: boolean;
  isFogModalOpen: boolean;
  isSoundModalOpen: boolean;
  isParticleModalOpen: boolean;
  /** AIS-18c: nó-alvo do modo "editar" do ParticleModal (consumido pelo AIS-53); `null` = criação. */
  particleModalTargetNodeId: string | null;
  /** AIS-49b: nó cujo gerador foi reaberto por "Editar no gerador" (`null` = criação). O modal do `generatorId` troca para "Aplicar ao nó". */
  generatorEdit: { nodeId: string; generatorId: string } | null;
  isAssetImportModalOpen: boolean;
  /** AIS-31: modelo de `res://` solto no viewport/árvore; o AssetImportModal abre com ele pré-carregado (`null` = nenhum). */
  assetImportSource: AssetImportSource | null;
  /** AIS-38c: último pedido de "Mostrar no FileSystem" (o painel o consome). */
  fileSystemReveal: FileSystemRevealRequest | null;
  isTexturePreviewOpen: boolean;
  isVideoEditorOpen: boolean;
  isSpriteEditorOpen: boolean;
  isExtensionsPanelOpen: boolean;
  isScriptEditorModalOpen: boolean;
}

// ─── Store Actions ────────────────────────────────────────────────────────────

export interface EditorStoreActions {
  // Selection
  /** Set primary selection. Clears multi-selection. */
  selectNode: (id: string | null) => void;
  /** Replace the multi-selection set. */
  setMultiSelectedNodeIds: (ids: string[]) => void;
  /** Toggle a node in/out of the multi-selection set (Ctrl+Click). */
  toggleMultiSelectNode: (id: string) => void;

  // Active document sync (called by EditorContext/AuthoringModel subscriber)
  /** Sync active scene ref from AuthoringModel notification. Non-persistent. */
  syncActiveScene: (ref: ActiveSceneRef | null) => void;
  /** Sync active project ref from AuthoringModel notification. Non-persistent. */
  syncActiveProject: (ref: ActiveProjectRef | null) => void;

  // Viewport
  setWorkspaceMode: (mode: WorkspaceMode) => void;
  setManipulationMode: (mode: ManipulationMode) => void;
  /** AIS-09: merge snap settings (toggles and steps). */
  setViewportSnap: (patch: Partial<ViewportSnapSettings>) => void;
  setShowColliders: (value: boolean) => void;
  setAddWithCollision: (value: boolean) => void;

  // Play mode mirrors (set only from EditorContext play/stop handlers)
  setPlayState: (playing: boolean, paused: boolean, mode: 'project' | 'scene' | null) => void;

  // Bottom panel
  setBottomTab: (tab: 'output' | 'debugger') => void;
  setIsBottomOpen: (open: boolean) => void;

  // Script editor
  openScriptTab: (path: string) => void;
  closeScriptTab: (path: string) => void;
  setActiveScriptPath: (path: string | null) => void;

  // Dialog toggles
  setIsProjectSettingsOpen: (open: boolean) => void;
  setIsProjectManagerOpen: (open: boolean) => void;
  setIsCreateNodeModalOpen: (open: boolean) => void;
  setIsPostProcessingOpen: (open: boolean) => void;
  setIsTerrainEditorOpen: (open: boolean) => void;
  setIsTreeEditorOpen: (open: boolean) => void;
  setIsFogModalOpen: (open: boolean) => void;
  setIsSoundModalOpen: (open: boolean) => void;
  setIsParticleModalOpen: (open: boolean) => void;
  setParticleModalTargetNodeId: (nodeId: string | null) => void;
  startGeneratorEdit: (target: { nodeId: string; generatorId: string }) => void;
  endGeneratorEdit: () => void;
  setIsAssetImportModalOpen: (open: boolean) => void;
  /** AIS-31: abre o AssetImportModal com o modelo de `res://` já carregado. */
  openAssetImportWithSource: (source: AssetImportSource) => void;
  /** AIS-38c: seleciona `path` no FileSystemPanel (expande as pastas). */
  revealInFileSystem: (path: string) => void;
  setIsTexturePreviewOpen: (open: boolean) => void;
  setIsVideoEditorOpen: (open: boolean) => void;
  setIsSpriteEditorOpen: (open: boolean) => void;
  setIsExtensionsPanelOpen: (open: boolean) => void;
  setIsScriptEditorModalOpen: (open: boolean) => void;
}

// ─── Full Store Type ──────────────────────────────────────────────────────────

export type EditorStore = EditorStoreState & EditorStoreActions;

// ─── Initial State ────────────────────────────────────────────────────────────

const INITIAL_STATE: EditorStoreState = {
  selectedNodeId: null,
  multiSelectedNodeIds: [],
  activeSceneRef: null,
  activeProjectRef: null,
  workspaceMode: '3D',
  manipulationMode: 'select',
  viewportSnap: DEFAULT_VIEWPORT_SNAP,
  showColliders: readEditorPref(PREF_SHOW_COLLIDERS, false),
  addWithCollision: readEditorPref(PREF_ADD_WITH_COLLISION, true),
  isPlaying: false,
  isPaused: false,
  playMode: null,
  bottomTab: 'output',
  isBottomOpen: false,
  activeScriptPath: 'res://scripts/PlayerController.ts',
  openScriptTabs: [
    'res://scripts/PlayerController.ts',
    'res://scripts/GameConfig.json',
    'res://scripts/materials_def.xml',
    'res://notes.txt',
  ],
  isProjectSettingsOpen: false,
  isProjectManagerOpen: false,
  isCreateNodeModalOpen: false,
  isPostProcessingOpen: false,
  isTerrainEditorOpen: false,
  isTreeEditorOpen: false,
  isFogModalOpen: false,
  isSoundModalOpen: false,
  isParticleModalOpen: false,
  particleModalTargetNodeId: null,
  generatorEdit: null,
  isAssetImportModalOpen: false,
  assetImportSource: null,
  fileSystemReveal: null,
  isTexturePreviewOpen: false,
  isVideoEditorOpen: false,
  isSpriteEditorOpen: false,
  isExtensionsPanelOpen: false,
  isScriptEditorModalOpen: false,
};

// ─── Store ────────────────────────────────────────────────────────────────────

/**
 * `useEditorStore` — canonical Zustand React hook.
 *
 * Always prefer granular selectors to avoid global re-renders:
 * ```ts
 * const selectedNodeId = useEditorStore(s => s.selectedNodeId);
 * const selectNode     = useEditorStore(s => s.selectNode);
 * ```
 */
export const useEditorStore = create<EditorStore>((set, get) => ({
  ...INITIAL_STATE,

  // ── Selection ──────────────────────────────────────────────────────────────
  // AIS-18b: a autoridade da seleção é o SelectionService; estas ações delegam a ele e o
  // store é apenas a projeção reativa (atualizada pela assinatura abaixo, sem sync manual).
  selectNode: (id) => globalSelectionService.replace(id),

  setMultiSelectedNodeIds: (ids) => globalSelectionService.set(get().selectedNodeId, ids),

  toggleMultiSelectNode: (id) => globalSelectionService.toggle(id),

  // ── Active Document Sync ───────────────────────────────────────────────────
  // AIS-49b: trocar de cena encerra uma edição de gerador pendente (o nó-alvo é da cena anterior)
  syncActiveScene: (ref) =>
    set((s) => {
      const sameScene = s.activeSceneRef?.path === ref?.path;
      return sameScene ? { activeSceneRef: ref } : { activeSceneRef: ref, generatorEdit: null };
    }),
  syncActiveProject: (ref) => set({ activeProjectRef: ref }),

  // ── Viewport ───────────────────────────────────────────────────────────────
  setWorkspaceMode: (mode) => set({ workspaceMode: mode }),
  setManipulationMode: (mode) => set({ manipulationMode: mode }),
  setViewportSnap: (patch) => set((s) => ({ viewportSnap: { ...s.viewportSnap, ...patch } })),
  setShowColliders: (value) => {
    writeEditorPref(PREF_SHOW_COLLIDERS, value);
    set({ showColliders: value });
  },
  setAddWithCollision: (value) => {
    writeEditorPref(PREF_ADD_WITH_COLLISION, value);
    set({ addWithCollision: value });
  },

  // ── Play Mode Mirrors ──────────────────────────────────────────────────────
  setPlayState: (playing, paused, mode) =>
    set({ isPlaying: playing, isPaused: paused, playMode: mode }),

  // ── Bottom Panel ───────────────────────────────────────────────────────────
  setBottomTab: (tab) => set({ bottomTab: tab }),
  setIsBottomOpen: (open) => set({ isBottomOpen: open }),

  // ── Script Editor ──────────────────────────────────────────────────────────
  openScriptTab: (path) =>
    set((s) => ({
      openScriptTabs: s.openScriptTabs.includes(path)
        ? s.openScriptTabs
        : [...s.openScriptTabs, path],
      activeScriptPath: path,
    })),

  closeScriptTab: (path) =>
    set((s) => {
      const next = s.openScriptTabs.filter((p) => p !== path);
      const active =
        s.activeScriptPath === path
          ? next.length > 0 ? next[next.length - 1] : null
          : s.activeScriptPath;
      return { openScriptTabs: next, activeScriptPath: active };
    }),

  setActiveScriptPath: (path) => set({ activeScriptPath: path }),

  // ── Dialog / Panel Toggles ─────────────────────────────────────────────────
  setIsProjectSettingsOpen:   (open) => set({ isProjectSettingsOpen: open }),
  setIsProjectManagerOpen:    (open) => set({ isProjectManagerOpen: open }),
  setIsCreateNodeModalOpen:   (open) => set({ isCreateNodeModalOpen: open }),
  setIsPostProcessingOpen:    (open) => set({ isPostProcessingOpen: open }),
  setIsTerrainEditorOpen:     (open) => set({ isTerrainEditorOpen: open }),
  setIsTreeEditorOpen:        (open) => set({ isTreeEditorOpen: open }),
  setIsFogModalOpen:          (open) => set({ isFogModalOpen: open }),
  setIsSoundModalOpen:        (open) => set({ isSoundModalOpen: open }),
  setIsParticleModalOpen:     (open) => set(open ? { isParticleModalOpen: true } : { isParticleModalOpen: false, particleModalTargetNodeId: null }),
  setParticleModalTargetNodeId: (nodeId) => set({ particleModalTargetNodeId: nodeId }),
  startGeneratorEdit:         (target) => set({ generatorEdit: { ...target } }),
  endGeneratorEdit:           () => set({ generatorEdit: null }),
  setIsAssetImportModalOpen:  (open) => set(open ? { isAssetImportModalOpen: true } : { isAssetImportModalOpen: false, assetImportSource: null }),
  openAssetImportWithSource:  (source) => set({ isAssetImportModalOpen: true, assetImportSource: source }),
  revealInFileSystem:         (path) => set((s) => ({ fileSystemReveal: { path, nonce: (s.fileSystemReveal?.nonce ?? 0) + 1 } })),
  setIsTexturePreviewOpen:    (open) => set({ isTexturePreviewOpen: open }),
  setIsVideoEditorOpen:       (open) => set({ isVideoEditorOpen: open }),
  setIsSpriteEditorOpen:      (open) => set({ isSpriteEditorOpen: open }),
  setIsExtensionsPanelOpen:   (open) => set({ isExtensionsPanelOpen: open }),
  setIsScriptEditorModalOpen: (open) => set({ isScriptEditorModalOpen: open }),
}));

// AIS-18b: projeção SelectionService → EditorStore (única via de escrita de seleção no store).
globalSelectionService.subscribe((snapshot) => {
  useEditorStore.setState({
    selectedNodeId: snapshot.primaryId,
    multiSelectedNodeIds: snapshot.ids.filter((id) => id !== snapshot.primaryId),
  });
});

/**
 * Vanilla store accessor — usable outside React components (services, tests).
 * Follows the Zustand recommended pattern for external access.
 */
export const editorStoreApi = useEditorStore;

// ─── Pure-function Selectors (tree-shakeable, testable without React) ─────────

/** Returns the primary selected node ID. */
export const selectSelectedNodeId = (s: EditorStoreState): string | null =>
  s.selectedNodeId;

/** Returns the multi-selection set. */
export const selectMultiSelectedNodeIds = (s: EditorStoreState): string[] =>
  s.multiSelectedNodeIds;

/** Returns true when at least one node (primary or multi) is selected. */
export const selectHasSelection = (s: EditorStoreState): boolean =>
  s.selectedNodeId !== null || s.multiSelectedNodeIds.length > 0;

/** Returns all selected node IDs (primary + multi), deduped. */
export const selectAllSelectedNodeIds = (s: EditorStoreState): string[] => {
  const ids = new Set<string>(s.multiSelectedNodeIds);
  if (s.selectedNodeId) ids.add(s.selectedNodeId);
  return Array.from(ids);
};

/** Returns the active scene display name. */
export const selectActiveSceneName = (s: EditorStoreState): string | null =>
  s.activeSceneRef?.name ?? null;

/** Returns the active scene path. */
export const selectActiveScenePath = (s: EditorStoreState): string | null =>
  s.activeSceneRef?.path ?? null;

/** Returns current workspace mode. */
export const selectWorkspaceMode = (s: EditorStoreState): WorkspaceMode =>
  s.workspaceMode;

/** Returns the current manipulation (gizmo) mode. */
export const selectManipulationMode = (s: EditorStoreState): ManipulationMode =>
  s.manipulationMode;

/** AIS-09: snap settings of the 3D viewport precision toolbar. */
export const selectViewportSnap = (s: EditorStoreState): ViewportSnapSettings => s.viewportSnap;

/** Returns true when the editor is in play/simulation mode. */
export const selectIsPlaying = (s: EditorStoreState): boolean => s.isPlaying;

/** Returns true when all dialog overlays are closed. */
export const selectNoDialogOpen = (s: EditorStoreState): boolean =>
  !s.isProjectSettingsOpen &&
  !s.isProjectManagerOpen &&
  !s.isCreateNodeModalOpen &&
  !s.isPostProcessingOpen &&
  !s.isTerrainEditorOpen &&
  !s.isTreeEditorOpen &&
  !s.isFogModalOpen &&
  !s.isSoundModalOpen &&
  !s.isParticleModalOpen &&
  !s.isAssetImportModalOpen &&
  !s.isTexturePreviewOpen &&
  !s.isVideoEditorOpen &&
  !s.isSpriteEditorOpen &&
  !s.isExtensionsPanelOpen &&
  !s.isScriptEditorModalOpen;
