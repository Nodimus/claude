import { CommandHistoryEntry, getCommandLabel, ICommand } from '../types/commands';
import { createMacroCommand } from './commands/MacroCommand';

/**
 * CommandManager (AIS-18) — pilha única de Undo/Redo das edições do usuário.
 *
 * - Histórico da sessão **sem limite numérico** (decisão canônica 10).
 * - `label` é o campo canônico do Command (`name`/`description` aceitos); o
 *   `timestamp` é atribuído aqui ao registrar.
 * - Falha em `execute` não registra o Command; falha em `undo`/`redo` devolve o
 *   Command à pilha de origem, mantendo as pilhas consistentes.
 * - AIS-22: transações — Commands executados dentro de `transaction()` viram UMA entrada
 *   (MacroCommand): um Ctrl+Z desfaz o gesto composto inteiro; erro no meio reverte e não registra.
 * - Notifica assinantes a cada mudança (TopBar: botões Undo/Redo); `getVersion()`
 *   serve de snapshot para `useSyncExternalStore`.
 */
export class CommandManager {
  private undoStack: ICommand[] = [];
  private redoStack: ICommand[] = [];
  private listeners: (() => void)[] = [];
  private version = 0;
  // AIS-18b: revisão por Command + base; o "checkpoint" é a revisão do topo do Undo.
  private revisionCounter = 0;
  private baseRevision = 0;
  private revisions = new WeakMap<ICommand, number>();
  // AIS-24: gesto contínuo aberto (arrasto/seta mantida) e o Command que absorve os seguintes
  private gestureOpen = false;
  private gestureHead: ICommand | null = null;
  // AIS-22: pilha de transações abertas (aninhadas se juntam à externa)
  private transactions: { label: string; commands: ICommand[] }[] = [];

  /** Executa o Command e o registra no histórico (limpa o Redo). */
  public pushCommand(command: ICommand): void {
    command.execute();
    const open = this.transactions[this.transactions.length - 1];
    if (open) {
      // dentro de uma transação: aplica agora, mas só entra no histórico no commit (como Macro)
      open.commands.push(command);
      return;
    }
    if (this.gestureOpen) {
      const head = this.gestureHead;
      const onTop = head !== null && this.undoStack[this.undoStack.length - 1] === head;
      if (onTop && head.mergeKey !== undefined && head.mergeKey === command.mergeKey && head.merge?.(command)) {
        // absorvido: o histórico continua com UMA entrada (início → fim do gesto); muda o checkpoint (dirty)
        this.revisions.set(head, ++this.revisionCounter);
        this.notify();
        return;
      }
    }
    this.record(command);
    if (this.gestureOpen && this.gestureHead === null) this.gestureHead = command;
  }

  // ── AIS-24: mescla por gesto ────────────────────────────────────────────────────────────────

  /**
   * Abre um gesto contínuo (arrastar um campo numérico, segurar ↑/↓): os Commands compatíveis
   * (mesma `mergeKey`) empurrados até `endGesture()` viram UMA entrada de Undo.
   */
  public beginGesture(): void {
    this.gestureOpen = true;
    this.gestureHead = null;
  }

  public endGesture(): void {
    this.gestureOpen = false;
    this.gestureHead = null;
  }

  public isInGesture(): boolean {
    return this.gestureOpen;
  }

  /** Registra no histórico um Command JÁ aplicado (limpa o Redo). */
  private record(command: ICommand): void {
    if (command.timestamp === undefined) command.timestamp = Date.now();
    this.revisions.set(command, ++this.revisionCounter);
    this.undoStack.push(command);
    this.redoStack = [];
    this.notify();
  }

  // ── AIS-22: transações atômicas ─────────────────────────────────────────────────────────────

  public isInTransaction(): boolean {
    return this.transactions.length > 0;
  }

  public beginTransaction(label: string): void {
    this.transactions.push({ label, commands: [] });
  }

  /**
   * Fecha a transação: os Commands aplicados viram um único MacroCommand no histórico
   * (nada entra se não houve Commands). Transação aninhada entrega o macro à externa.
   */
  public commitTransaction(): void {
    const tx = this.transactions.pop();
    if (!tx) return;
    const macro = createMacroCommand(tx.label, tx.commands);
    if (!macro) return;
    const outer = this.transactions[this.transactions.length - 1];
    if (outer) outer.commands.push(macro);
    else this.record(macro);
  }

  /** Abandona a transação: desfaz o que foi aplicado (ordem inversa) e não registra nada. */
  public rollbackTransaction(): void {
    const tx = this.transactions.pop();
    if (!tx) return;
    let firstError: unknown;
    for (const command of [...tx.commands].reverse()) {
      try {
        command.undo();
      } catch (error) {
        firstError ??= error;
      }
    }
    if (firstError) throw firstError;
  }

  /**
   * Executa `fn` como uma transação: tudo que ela empurrar vira UMA entrada de histórico.
   * Se `fn` lançar, o que foi aplicado é desfeito e o erro relançado (estado consistente).
   */
  public transaction<T>(label: string, fn: () => T): T {
    this.beginTransaction(label);
    let result: T;
    try {
      result = fn();
    } catch (error) {
      try {
        this.rollbackTransaction();
      } catch {
        /* o erro original é o que importa */
      }
      throw error;
    }
    this.commitTransaction();
    return result;
  }

  /** Nome histórico de `pushCommand`; mantido para os chamadores existentes. */
  public execute(command: ICommand): void {
    this.pushCommand(command);
  }

  public undo(): void {
    if (this.isInTransaction()) return; // histórico congelado até o fim da transação
    this.endGesture();
    const command = this.undoStack.pop();
    if (!command) return;
    try {
      command.undo();
    } catch (error) {
      this.undoStack.push(command);
      throw error;
    }
    this.redoStack.push(command);
    this.notify();
  }

  public redo(): void {
    if (this.isInTransaction()) return;
    this.endGesture();
    const command = this.redoStack.pop();
    if (!command) return;
    try {
      if (command.redo) {
        command.redo();
      } else {
        command.execute();
      }
    } catch (error) {
      this.redoStack.push(command);
      throw error;
    }
    this.undoStack.push(command);
    this.notify();
  }

  public canUndo(): boolean {
    return this.undoStack.length > 0;
  }

  public canRedo(): boolean {
    return this.redoStack.length > 0;
  }

  public getUndoLabel(): string | null {
    const top = this.undoStack[this.undoStack.length - 1];
    return top ? getCommandLabel(top) : null;
  }

  public getRedoLabel(): string | null {
    const top = this.redoStack[this.redoStack.length - 1];
    return top ? getCommandLabel(top) : null;
  }

  /** @deprecated use `getUndoLabel` (nome anterior ao AIS-18). */
  public getUndoActionName(): string | null {
    return this.getUndoLabel();
  }

  /** @deprecated use `getRedoLabel` (nome anterior ao AIS-18). */
  public getRedoActionName(): string | null {
    return this.getRedoLabel();
  }

  /** Histórico de Undo (do mais antigo ao mais recente), só dados para exibição. */
  public getHistory(): CommandHistoryEntry[] {
    return this.undoStack.map((c) => ({ label: getCommandLabel(c), timestamp: c.timestamp ?? 0 }));
  }

  public clearHistory(): void {
    this.undoStack = [];
    this.redoStack = [];
    // Nova base única: documentos que estavam limpos/sujos não "voltam" a um checkpoint antigo.
    this.baseRevision = ++this.revisionCounter;
    this.notify();
  }

  /** @deprecated use `clearHistory` (nome anterior ao AIS-18). */
  public clear(): void {
    this.clearHistory();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  /**
   * Token do estado atual do histórico (revisão do topo do Undo; base se vazio).
   * Dirty-state por checkpoint: salvar guarda o token; Undo/Redo que voltam a ele
   * deixam o documento limpo de novo. Não é booleano irreversível.
   */
  public getCheckpointToken(): number {
    const top = this.undoStack[this.undoStack.length - 1];
    return top ? (this.revisions.get(top) ?? this.baseRevision) : this.baseRevision;
  }

  /** Contador que muda a cada alteração do histórico (snapshot para `useSyncExternalStore`). */
  public getVersion(): number {
    return this.version;
  }

  private notify(): void {
    this.version++;
    for (const listener of this.listeners) {
      try {
        listener();
      } catch (e) {
        console.error('Command listener error:', e);
      }
    }
  }
}

export const globalCommandManager = new CommandManager();
