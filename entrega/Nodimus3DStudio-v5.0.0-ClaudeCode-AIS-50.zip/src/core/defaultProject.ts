import { ProjectData, ProjectSettings, VirtualFile } from '../types/project';
import { SceneData } from '../types/scene';
import { GameNode } from '../types/node';
import { createDefaultNode } from '../nodes/registry';
import { STARTER_BEHAVIOR_IDS, createStarterBehavior } from './starterBehaviors';
import { serializeSceneToJson } from './serialization/sceneSerializer';
import { sceneIdFromContent } from './sceneIds';
import { CURRENT_PROJECT_SCHEMA_VERSION, CURRENT_SCENE_SCHEMA_VERSION } from './persistenceVersions';
import { ProjectFile, ProjectSceneEntry } from '../types/projectFile';

export const DEFAULT_PROJECT_SETTINGS: ProjectSettings = {
  general: {
    projectName: 'Nodimus 3D Adventure',
    version: '1.0.0',
    description: '',
    mainScene: 'res://scenes/Main.scene.json',
    author: 'Developer',
  },
  display: {
    width: 1280,
    height: 720,
    resizable: true,
    fullscreen: false,
    windowMode: 'windowed',
    orientation: 'landscape',
  },
  rendering: {
    renderer: 'Three.js (WebGL)',
    clearColor: '#141822',
    vsync: true,
    msaa: '2x',
    shadowsEnabled: true,
    shadowQuality: 'medium',
    hdr: false,
  },
  physics: {
    gravity3D: { x: 0, y: -9.8, z: 0 },
    defaultLinearDamp: 0.1,
  },
  input: {
    actions: [
      { name: 'move_left', bindings: [{ type: 'key', code: 'KeyA' }, { type: 'key', code: 'ArrowLeft' }] },
      { name: 'move_right', bindings: [{ type: 'key', code: 'KeyD' }, { type: 'key', code: 'ArrowRight' }] },
      { name: 'move_forward', bindings: [{ type: 'key', code: 'KeyW' }, { type: 'key', code: 'ArrowUp' }] },
      { name: 'move_back', bindings: [{ type: 'key', code: 'KeyS' }, { type: 'key', code: 'ArrowDown' }] },
      { name: 'jump', bindings: [{ type: 'key', code: 'Space' }] },
    ],
  },
  audio: {
    masterVolume: 1.0,
    musicVolume: 0.8,
    sfxVolume: 0.9,
  },
};

export function createDefault3DStarterScene(): SceneData {
  const root = createDefaultNode('Spatial', 'World3D', null);

  // Exactly one Environment default of the Scene (AIS-05 requirement)
  const env = createDefaultNode('Environment', 'WorldEnvironment', root.id);
  env.properties.ambientColor = { r: 0.5, g: 0.6, b: 0.75, a: 1 };
  env.properties.ambientIntensity = 0.45;
  env.properties.backgroundMode = 'Color';
  env.properties.backgroundColor = { r: 0.08, g: 0.1, b: 0.14, a: 1 };
  env.properties.realtimeShadows = true;
  env.properties.fogEnabled = false;

  // 3D DirectionalLight default of the Scene
  const sun = createDefaultNode('DirectionalLight', 'SunLight', root.id);
  sun.properties.position = { x: 6, y: 12, z: 8 };
  sun.properties.rotation = { x: -45, y: 35, z: 0 };
  sun.properties.lightColor = { r: 1, g: 0.98, b: 0.92, a: 1 };
  sun.properties.energy = 1.4;
  sun.properties.castShadow = true;

  // Runtime Camera GameNode (active: true, destined for game/runtime — editor orbit camera is ephemeral)
  const camera = createDefaultNode('Camera', 'MainCamera', root.id);
  camera.properties.position = { x: 0, y: 4, z: 8 };
  camera.properties.rotation = { x: -20, y: 0, z: 0 };
  camera.properties.active = true;
  camera.properties.current = true;
  camera.properties.fov = 65;
  camera.properties.near = 0.1;
  camera.properties.far = 1000;
  camera.properties.projection = 'perspective';

  // Demonstrative Ground/Grid PlaneMesh
  const floor = createDefaultNode('MeshInstance', 'FloorPlane', root.id);
  floor.properties.meshType = 'PlaneMesh';
  floor.properties.position = { x: 0, y: 0, z: 0 };
  floor.properties.scale = { x: 16, y: 1, z: 16 };
  floor.properties.materialOverride = { color: { r: 0.22, g: 0.28, b: 0.36, a: 1 }, roughness: 0.4, metalness: 0.1 };

  // 3D Meshes from casca bootstrap
  const playerCube = createDefaultNode('MeshInstance', 'PlayerMesh', root.id);
  playerCube.properties.meshType = 'CubeMesh';
  playerCube.properties.position = { x: 0, y: 0.8, z: 0 };
  playerCube.properties.scale = { x: 1.2, y: 1.6, z: 1.2 };
  playerCube.properties.materialOverride = { color: { r: 0.28, g: 0.62, b: 0.98, a: 1 }, roughness: 0.3, metalness: 0.1 };
  playerCube.behaviors = [createStarterBehavior(STARTER_BEHAVIOR_IDS.player)!]; // AIS-41b: instância inline

  const pillar = createDefaultNode('MeshInstance', 'StonePillar', root.id);
  pillar.properties.meshType = 'CylinderMesh';
  pillar.properties.position = { x: -3.5, y: 2, z: -2.5 };
  pillar.properties.scale = { x: 0.8, y: 4, z: 0.8 };
  pillar.properties.materialOverride = { color: { r: 0.85, g: 0.45, b: 0.3, a: 1 }, roughness: 0.4, metalness: 0.1 };

  const orb = createDefaultNode('MeshInstance', 'MagicOrb', root.id);
  orb.properties.meshType = 'SphereMesh';
  orb.properties.position = { x: 3.2, y: 1.5, z: -1 };
  orb.properties.scale = { x: 1.2, y: 1.2, z: 1.2 };
  orb.properties.materialOverride = { color: { r: 0.96, g: 0.82, b: 0.24, a: 1 }, roughness: 0.4, metalness: 0.1 };
  orb.behaviors = [createStarterBehavior(STARTER_BEHAVIOR_IDS.orb)!];

  const pointLight = createDefaultNode('OmniLight', 'OrbGlow', orb.id);
  pointLight.properties.position = { x: 0, y: 0, z: 0 };
  pointLight.properties.lightColor = { r: 1, g: 0.88, b: 0.4, a: 1 };
  pointLight.properties.energy = 2.5;

  // 3D Billboard facing active camera
  const billboardTree = createDefaultNode('Billboard', 'TreeBillboard', root.id);
  billboardTree.properties.position = { x: -2.5, y: 1.6, z: 2.0 };
  billboardTree.properties.width = 1.8;
  billboardTree.properties.height = 2.4;
  billboardTree.properties.color = { r: 0.2, g: 0.85, b: 0.4, a: 1 };

  // 2D Screen Overlays (HUD / GUI Elements)
  const hudBox = createDefaultNode('Overlay2D', 'HUD_HealthPanel', root.id);
  hudBox.properties.posX = 20;
  hudBox.properties.posY = 20;
  hudBox.properties.width = 180;
  hudBox.properties.height = 42;
  hudBox.properties.alignment = 'Top-Left';
  hudBox.properties.color = { r: 0.1, g: 0.15, b: 0.24, a: 0.85 };

  const hudText = createDefaultNode('TextOverlay2D', 'HUD_HealthText', hudBox.id);
  hudText.properties.posX = 32;
  hudText.properties.posY = 32;
  hudText.properties.text = 'HP: 100 / 100';
  hudText.properties.textColor = { r: 0.3, g: 0.9, b: 0.4, a: 1 };
  hudText.properties.fontSize = 14;

  const hudBtn = createDefaultNode('ButtonOverlay2D', 'HUD_InventoryButton', root.id);
  hudBtn.behaviors = [createStarterBehavior(STARTER_BEHAVIOR_IDS.inventoryButton)!];
  hudBtn.properties.posX = 20;
  hudBtn.properties.posY = 72;
  hudBtn.properties.width = 140;
  hudBtn.properties.height = 36;
  hudBtn.properties.text = 'Inventory';

  // Build hierarchy (Environment first child of root)
  root.childrenIds = [
    env.id,
    sun.id,
    camera.id,
    floor.id,
    playerCube.id,
    pillar.id,
    orb.id,
    billboardTree.id,
    hudBox.id,
    hudBtn.id,
  ];
  orb.childrenIds = [pointLight.id];
  hudBox.childrenIds = [hudText.id];

  const nodes: Record<string, GameNode> = {
    [root.id]: root,
    [env.id]: env,
    [sun.id]: sun,
    [camera.id]: camera,
    [floor.id]: floor,
    [playerCube.id]: playerCube,
    [pillar.id]: pillar,
    [orb.id]: orb,
    [pointLight.id]: pointLight,
    [billboardTree.id]: billboardTree,
    [hudBox.id]: hudBox,
    [hudText.id]: hudText,
    [hudBtn.id]: hudBtn,
  };

  const now = new Date().toISOString();
  return {
    schemaVersion: CURRENT_SCENE_SCHEMA_VERSION,
    id: 'scene_main_3d',
    name: 'Main3D',
    path: 'res://scenes/Main.scene.json',
    rootNodeId: root.id,
    environmentNodeId: env.id,
    nodes,
    environment: {
      ambientColor: '#334155',
      ambientIntensity: 0.45,
      backgroundColor: '#141822',
      realtimeShadows: true,
      gravity: { x: 0, y: -9.8, z: 0 },
      wind: { x: 0, y: 0, z: 0 },
    },
    createdAt: now,
    updatedAt: now,
  };
}

export function createEmptyScene(): SceneData {
  const root = createDefaultNode('Spatial', 'Spatial', null);
  const now = new Date().toISOString();
  return {
    schemaVersion: CURRENT_SCENE_SCHEMA_VERSION,
    id: 'scene_' + Math.random().toString(36).substring(2, 9),
    name: 'NewScene',
    path: 'res://scenes/NewScene.scene.json',
    rootNodeId: root.id,
    nodes: { [root.id]: root },
    createdAt: now,
    updatedAt: now,
  };
}


/** Lista canônica de pastas `res://` (única fonte: o projeto novo e `ensureStarterFiles` a usam; AIS-32-C13 a confere). */
export const CANONICAL_RES_DIRS: readonly string[] = [
  'res://',
  'res://scenes/',
  'res://sprites/',
  'res://textures/',
  'res://materials/',
  'res://audio/',
  'res://scripts/',
  'res://prefabs/',
  'res://models/',
  'res://overlays/',
  'res://videos/',
];

export function createNewProject(
  name: string,
  location: string,
  template: '3d' | 'empty' = '3d'
): ProjectData {
  const scene: SceneData = template === 'empty' ? createEmptyScene() : createDefault3DStarterScene();
  const projectId = 'proj_' + Math.random().toString(36).substring(2, 9);
  const now = new Date().toISOString();

  // cópia profunda: projetos novos nunca compartilham objetos aninhados com o padrão do módulo (AIS-32b)
  const defaults = JSON.parse(JSON.stringify(DEFAULT_PROJECT_SETTINGS)) as ProjectSettings;
  const settings: ProjectSettings = {
    ...defaults,
    general: {
      ...DEFAULT_PROJECT_SETTINGS.general,
      projectName: name,
      mainScene: scene.path,
    },
    rendering: {
      ...DEFAULT_PROJECT_SETTINGS.rendering,
      renderer: 'Three.js (WebGL)',
    },
  };

  const samplePlayerScript = `/**
 * Nodimus 3D - PlayerController.ts
 * Example TypeScript controller for 3D physics, movement & camera
 */
export class PlayerController {
  public speed: number = 6.0;
  public jumpForce: number = 8.5;
  public isGrounded: boolean = true;
  private velocity = { x: 0, y: 0, z: 0 };

  constructor(public targetNode: string = "PlayerMesh") {}

  public onReady(): void {
    console.log(\`[PlayerController] Initialized on node: \${this.targetNode}\`);
  }

  public onProcess(delta: number, input: Record<string, boolean>): void {
    // Process keyboard movement
    let moveX = 0;
    let moveZ = 0;

    if (input["KeyW"] || input["ArrowUp"]) moveZ -= 1;
    if (input["KeyS"] || input["ArrowDown"]) moveZ += 1;
    if (input["KeyA"] || input["ArrowLeft"]) moveX -= 1;
    if (input["KeyD"] || input["ArrowRight"]) moveX += 1;

    // Normalize movement vector
    const length = Math.hypot(moveX, moveZ);
    if (length > 0) {
      this.velocity.x = (moveX / length) * this.speed * delta;
      this.velocity.z = (moveZ / length) * this.speed * delta;
    } else {
      this.velocity.x = 0;
      this.velocity.z = 0;
    }

    if (input["Space"] && this.isGrounded) {
      this.velocity.y = this.jumpForce;
      this.isGrounded = false;
    }
  }
}
`;

  const sampleMathUtils = `/**
 * Nodimus Studio - math_utils.js
 * Utility mathematical helper functions for vectors, interpolation & easing
 */

export function lerp(start, end, alpha) {
  return start + (end - start) * alpha;
}

export function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

export function degToRad(degrees) {
  return (degrees * Math.PI) / 180;
}

export function radToDeg(radians) {
  return (radians * 180) / Math.PI;
}

export function distance3D(x1, y1, z1, x2, y2, z2) {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const dz = z2 - z1;
  return Math.hypot(dx, dy, dz);
}
`;

  const sampleGameConfig = JSON.stringify(
    {
      title: name,
      version: '1.0.0',
      difficulty: 'Normal',
      graphics: {
        shadows: true,
        msaa: '2x',
        bloom: false,
        targetFps: 60,
      },
      audio: {
        masterVolume: 1.0,
        musicVolume: 0.8,
        sfxVolume: 0.9,
      },
      gameplay: {
        cameraFov: 60,
        mouseSensitivity: 1.2,
        invertY: false,
      },
    },
    null,
    2
  );

  const sampleXmlData = `<?xml version="1.0" encoding="UTF-8"?>
<materials version="1.0">
  <material id="mat_player" type="StandardMaterial">
    <albedo r="0.28" g="0.62" b="0.98" a="1.0" />
    <roughness>0.35</roughness>
    <metalness>0.10</metalness>
    <shading>PBR</shading>
  </material>
  <material id="mat_floor" type="StandardMaterial">
    <albedo r="0.22" g="0.28" b="0.36" a="1.0" />
    <roughness>0.80</roughness>
    <metalness>0.05</metalness>
  </material>
  <material id="mat_magic_orb" type="EmissiveMaterial">
    <albedo r="0.96" g="0.82" b="0.24" a="1.0" />
    <emissive r="1.0" g="0.85" b="0.3" intensity="2.5" />
  </material>
</materials>
`;

  const sampleNotes = `=== Nodimus 3D Studio - Project Notes ===

Welcome to your 3D Game Project!

This editor uses CodeMirror with full multi-language syntax highlighting:
- .txt  (Plain Text, Notes, Logs)
- .ts   (TypeScript Game Scripts & Node Logic)
- .js   (JavaScript Modules & Math Helpers)
- .json (Game Configurations, Level Data & Dumps)
- .xml  (Data Schemas, UI Layouts & Material Manifests)
- .html, .css, .md

Key Features:
- Ctrl+S to save changes directly to virtual file system.
- Format / Prettify button for quick indentation and cleanup.
- Double-click any file in the FileSystem panel to open it in Code Editor.
- Toggle between Workspace Mode and ScriptEditorModal at any time!
`;

  const sampleSpriteJson = JSON.stringify(
    {
      name: 'Character_Idle',
      texturePath: 'res://textures/player_spritesheet.png',
      frameWidth: 32,
      frameHeight: 32,
      frameCount: 6,
      fps: 10,
      loop: true,
      animations: {
        idle: { startFrame: 0, endFrame: 5, fps: 10, loop: true },
      },
    },
    null,
    2
  );

  const sampleGoldMat = JSON.stringify(
    {
      name: 'Ouro Polido 24K',
      shadingModel: 'Standard',
      color: { r: 0.96, g: 0.78, b: 0.25, a: 1 },
      roughness: 0.12,
      metalness: 0.95,
      clearcoat: 0.4,
      textureType: 'none',
    },
    null,
    2
  );

  const sampleHexMat = JSON.stringify(
    {
      name: 'Blindagem Hexagonal Sci-Fi',
      shadingModel: 'Standard',
      color: { r: 0.16, g: 0.2, b: 0.28, a: 1 },
      roughness: 0.28,
      metalness: 0.75,
      textureType: 'hex',
      textureScale: 6,
      textureColorA: '#151b27',
      textureColorB: '#3a5078',
      enableNormalMap: true,
      normalScale: 1.2,
    },
    null,
    2
  );

  const sampleVideoJson = JSON.stringify(
    {
      name: 'Cyberpunk_Display',
      url: '',
      duration: 12,
      trimStart: 0,
      trimEnd: 12,
      playbackRate: 1,
      loop: true,
      muted: true,
      volume: 0.8,
      aspectRatio: '16:9',
      emissiveIntensity: 0.85,
      roughness: 0.25,
      metalness: 0.15,
      shape: 'CurvedScreen',
      filters: {
        brightness: 105,
        contrast: 110,
        saturation: 120,
        hueRotate: 0,
        grayscale: 0,
        invert: false,
        sepia: 0,
        scanlines: true,
      },
    },
    null,
    2
  );

  const canonicalProjectFile: ProjectFile = {
    schemaVersion: CURRENT_PROJECT_SCHEMA_VERSION,
    projectId,
    name,
    appId: 'com.nodimus.' + name.toLowerCase().replace(/[^a-z0-9]/g, ''),
    engineVersion: '1.0.0',
    startSceneId: scene.id,
    scenes: [
      {
        id: scene.id,
        name: scene.name,
        path: scene.path,
        isStartScene: true,
      },
    ],
    globalVariables: [],
    inputMap: settings.input?.actions || [],
    settings,
    createdAt: now,
    updatedAt: now,
  };
  const projectJsonContent = JSON.stringify(canonicalProjectFile, null, 2);
  // AIS-29: a cena inicial já nasce no formato canônico compacto
  const sceneContent = serializeSceneToJson(scene);

  const files: Record<string, VirtualFile> = {
    // Canonical virtual res:// directory tree
    'res://': { path: 'res://', name: 'res://', isDirectory: true, updatedAt: now },
    'res://scenes/': { path: 'res://scenes/', name: 'scenes', isDirectory: true, updatedAt: now },
    'res://sprites/': { path: 'res://sprites/', name: 'sprites', isDirectory: true, updatedAt: now },
    'res://textures/': { path: 'res://textures/', name: 'textures', isDirectory: true, updatedAt: now },
    'res://materials/': { path: 'res://materials/', name: 'materials', isDirectory: true, updatedAt: now },
    'res://audio/': { path: 'res://audio/', name: 'audio', isDirectory: true, updatedAt: now },
    'res://scripts/': { path: 'res://scripts/', name: 'scripts', isDirectory: true, updatedAt: now },
    'res://prefabs/': { path: 'res://prefabs/', name: 'prefabs', isDirectory: true, updatedAt: now },
    'res://models/': { path: 'res://models/', name: 'models', isDirectory: true, updatedAt: now },
    'res://overlays/': { path: 'res://overlays/', name: 'overlays', isDirectory: true, updatedAt: now },
    'res://videos/': { path: 'res://videos/', name: 'videos', isDirectory: true, updatedAt: now },

    // Canonical project.json
    'res://project.json': {
      path: 'res://project.json',
      name: 'project.json',
      isDirectory: false,
      extension: 'json',
      content: projectJsonContent,
      size: projectJsonContent.length,
      updatedAt: now,
    },

    // Default Main scene
    [scene.path]: {
      path: scene.path,
      name: scene.name + '.scene.json',
      isDirectory: false,
      extension: 'json',
      content: sceneContent,
      size: sceneContent.length,
      updatedAt: now,
    },

    // First-class 2D Sprite resource
    'res://sprites/character_idle.sprite.json': {
      path: 'res://sprites/character_idle.sprite.json',
      name: 'character_idle.sprite.json',
      isDirectory: false,
      extension: 'json',
      content: sampleSpriteJson,
      size: sampleSpriteJson.length,
      updatedAt: now,
    },

    // Materials definitions
    'res://materials/Gold_Polished.mat.json': {
      path: 'res://materials/Gold_Polished.mat.json',
      name: 'Gold_Polished.mat.json',
      isDirectory: false,
      extension: 'json',
      content: sampleGoldMat,
      size: sampleGoldMat.length,
      updatedAt: now,
    },
    'res://materials/SciFi_HexArmor.mat.json': {
      path: 'res://materials/SciFi_HexArmor.mat.json',
      name: 'SciFi_HexArmor.mat.json',
      isDirectory: false,
      extension: 'json',
      content: sampleHexMat,
      size: sampleHexMat.length,
      updatedAt: now,
    },

    // Video texture demo
    'res://videos/Cyberpunk_Display.video.json': {
      path: 'res://videos/Cyberpunk_Display.video.json',
      name: 'Cyberpunk_Display.video.json',
      isDirectory: false,
      extension: 'json',
      content: sampleVideoJson,
      size: sampleVideoJson.length,
      updatedAt: now,
    },

    // Scripts
    'res://scripts/PlayerController.ts': {
      path: 'res://scripts/PlayerController.ts',
      name: 'PlayerController.ts',
      isDirectory: false,
      extension: 'ts',
      content: samplePlayerScript,
      size: samplePlayerScript.length,
      updatedAt: now,
    },
    'res://scripts/math_utils.js': {
      path: 'res://scripts/math_utils.js',
      name: 'math_utils.js',
      isDirectory: false,
      extension: 'js',
      content: sampleMathUtils,
      size: sampleMathUtils.length,
      updatedAt: now,
    },
    'res://scripts/GameConfig.json': {
      path: 'res://scripts/GameConfig.json',
      name: 'GameConfig.json',
      isDirectory: false,
      extension: 'json',
      content: sampleGameConfig,
      size: sampleGameConfig.length,
      updatedAt: now,
    },
    'res://scripts/materials_def.xml': {
      path: 'res://scripts/materials_def.xml',
      name: 'materials_def.xml',
      isDirectory: false,
      extension: 'xml',
      content: sampleXmlData,
      size: sampleXmlData.length,
      updatedAt: now,
    },
    'res://notes.txt': {
      path: 'res://notes.txt',
      name: 'notes.txt',
      isDirectory: false,
      extension: 'txt',
      content: sampleNotes,
      size: sampleNotes.length,
      updatedAt: now,
    },
  };

  return {
    schemaVersion: CURRENT_PROJECT_SCHEMA_VERSION,
    id: projectId,
    name,
    location,
    renderer: 'Three.js (WebGL)',
    lastOpenedScene: scene.path,
    createdAt: now,
    updatedAt: now,
    settings,
    files,
  };
}

/**
 * Entradas de cena do `project.json` canônico. Exatamente uma é a cena inicial: `lastOpenedScene`
 * quando ela existe em `files`, senão a primeira. Fonte única (projectStorage e ensureStarterFiles).
 */
export function buildProjectSceneEntries(
  files: Record<string, { name: string; content?: string }>,
  startScenePath: string,
  lastOpenedScene?: string,
): ProjectSceneEntry[] {
  const paths = Object.keys(files).filter((path) => path.endsWith('.scene.json'));
  if (paths.length === 0) {
    return [{ id: 'scene_main_3d', name: 'Main3D', path: 'res://scenes/Main.scene.json', isStartScene: true }];
  }
  // AIS-29f: a cena inicial é `settings.general.mainScene` (não a última aberta); sem ela, a última aberta; sem ela, a primeira
  const startPath = paths.includes(startScenePath) ? startScenePath : lastOpenedScene && paths.includes(lastOpenedScene) ? lastOpenedScene : paths[0];
  return paths.map((path) => {
    const name = files[path].name.replace(/\.scene\.json$/, '');
    return {
      // AIS-29f: o id é o `sceneId` estável do arquivo — renomear o arquivo não o altera
      id: sceneIdFromContent(files[path].content, path),
      name: name || 'Scene',
      path: path.startsWith('res://') ? path : `res://${path.replace(/^\.?\//, '')}`,
      isStartScene: path === startPath,
    };
  });
}

export function ensureStarterFiles(project: ProjectData): ProjectData {
  const now = new Date().toISOString();
  let modified = false;
  const files = { ...project.files };

  // Ensure canonical directories in res://
  for (const dirPath of CANONICAL_RES_DIRS) {
    if (!files[dirPath]) {
      const dirName = dirPath === 'res://' ? 'res://' : dirPath.replace(/^res:\/\//, '').replace(/\/$/, '');
      files[dirPath] = { path: dirPath, name: dirName, isDirectory: true, updatedAt: now };
      modified = true;
    }
  }

  // Ensure res://project.json
  if (!files['res://project.json']) {
    const sceneEntries = buildProjectSceneEntries(files, project.settings?.general?.mainScene ?? '', project.lastOpenedScene);

    const canonicalProjectFile: ProjectFile = {
      schemaVersion: CURRENT_PROJECT_SCHEMA_VERSION,
      projectId: project.id,
      name: project.name,
      appId: 'com.nodimus.' + project.name.toLowerCase().replace(/[^a-z0-9]/g, ''),
      engineVersion: '1.0.0',
      startSceneId: sceneEntries.find((s) => s.isStartScene)?.id || sceneEntries[0].id,
      scenes: sceneEntries,
      globalVariables: project.globalVariables ?? [],
      inputMap: project.settings.input?.actions || [],
      settings: project.settings,
      createdAt: project.createdAt || now,
      updatedAt: now,
    };
    const content = JSON.stringify(canonicalProjectFile, null, 2);
    files['res://project.json'] = {
      path: 'res://project.json',
      name: 'project.json',
      isDirectory: false,
      extension: 'json',
      content,
      size: content.length,
      updatedAt: now,
    };
    modified = true;
  }

  // Ensure scripts
  if (!files['res://scripts/PlayerController.ts']) {
    const code = `/**\n * Nodimus 3D - PlayerController.ts\n */\nexport class PlayerController {\n  public speed = 6.0;\n  public jumpForce = 8.5;\n  public onReady() {\n    console.log("Ready!");\n  }\n}\n`;
    files['res://scripts/PlayerController.ts'] = {
      path: 'res://scripts/PlayerController.ts',
      name: 'PlayerController.ts',
      isDirectory: false,
      extension: 'ts',
      content: code,
      size: code.length,
      updatedAt: now,
    };
    modified = true;
  }

  if (!files['res://scripts/GameConfig.json']) {
    const json = JSON.stringify({ title: project.name, version: '1.0.0', difficulty: 'Normal' }, null, 2);
    files['res://scripts/GameConfig.json'] = {
      path: 'res://scripts/GameConfig.json',
      name: 'GameConfig.json',
      isDirectory: false,
      extension: 'json',
      content: json,
      size: json.length,
      updatedAt: now,
    };
    modified = true;
  }

  if (!files['res://scripts/materials_def.xml']) {
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<materials version="1.0">\n  <material id="mat_player" type="StandardMaterial">\n    <albedo r="0.28" g="0.62" b="0.98" a="1.0" />\n  </material>\n</materials>\n`;
    files['res://scripts/materials_def.xml'] = {
      path: 'res://scripts/materials_def.xml',
      name: 'materials_def.xml',
      isDirectory: false,
      extension: 'xml',
      content: xml,
      size: xml.length,
      updatedAt: now,
    };
    modified = true;
  }

  if (!files['res://notes.txt']) {
    const notes = `=== Nodimus 3D Studio - Project Notes ===\n\nEdit .txt, .js, .ts, .json, .xml files using CodeMirror.\nPress Ctrl+S to save.\n`;
    files['res://notes.txt'] = {
      path: 'res://notes.txt',
      name: 'notes.txt',
      isDirectory: false,
      extension: 'txt',
      content: notes,
      size: notes.length,
      updatedAt: now,
    };
    modified = true;
  }

  if (!files['res://materials/Gold_Polished.mat.json']) {
    const goldMat = JSON.stringify(
      {
        name: 'Ouro Polido 24K',
        shadingModel: 'Standard',
        color: { r: 0.96, g: 0.78, b: 0.25, a: 1 },
        roughness: 0.12,
        metalness: 0.95,
        clearcoat: 0.4,
        textureType: 'none',
      },
      null,
      2
    );
    files['res://materials/Gold_Polished.mat.json'] = {
      path: 'res://materials/Gold_Polished.mat.json',
      name: 'Gold_Polished.mat.json',
      isDirectory: false,
      extension: 'json',
      content: goldMat,
      size: goldMat.length,
      updatedAt: now,
    };
    modified = true;
  }

  if (!files['res://materials/SciFi_HexArmor.mat.json']) {
    const hexMat = JSON.stringify(
      {
        name: 'Blindagem Hexagonal Sci-Fi',
        shadingModel: 'Standard',
        color: { r: 0.16, g: 0.2, b: 0.28, a: 1 },
        roughness: 0.28,
        metalness: 0.75,
        textureType: 'hex',
        textureScale: 6,
        textureColorA: '#151b27',
        textureColorB: '#3a5078',
        enableNormalMap: true,
        normalScale: 1.2,
      },
      null,
      2
    );
    files['res://materials/SciFi_HexArmor.mat.json'] = {
      path: 'res://materials/SciFi_HexArmor.mat.json',
      name: 'SciFi_HexArmor.mat.json',
      isDirectory: false,
      extension: 'json',
      content: hexMat,
      size: hexMat.length,
      updatedAt: now,
    };
    modified = true;
  }

  // v4.7.0 — res://addons/ no longer exists. Remove only the sample addon that
  // older editor builds generated automatically; anything else the user put in
  // res://addons/ is preserved (never deleted silently) and reported.
  if (removeLegacyAddonSample(files)) {
    modified = true;
  }

  if (!files['res://videos/Cyberpunk_Display.video.json']) {
    const videoData = JSON.stringify(
      {
        name: 'Cyberpunk_Display',
        url: '',
        duration: 12,
        trimStart: 0,
        trimEnd: 12,
        playbackRate: 1,
        loop: true,
        muted: true,
        volume: 0.8,
        aspectRatio: '16:9',
        emissiveIntensity: 0.85,
        roughness: 0.25,
        metalness: 0.15,
        shape: 'CurvedScreen',
        filters: {
          brightness: 105,
          contrast: 110,
          saturation: 120,
          hueRotate: 0,
          grayscale: 0,
          invert: false,
          sepia: 0,
          scanlines: true,
        },
      },
      null,
      2
    );
    files['res://videos/Cyberpunk_Display.video.json'] = {
      path: 'res://videos/Cyberpunk_Display.video.json',
      name: 'Cyberpunk_Display.video.json',
      isDirectory: false,
      extension: 'json',
      content: videoData,
      size: videoData.length,
      updatedAt: now,
    };
    modified = true;
  }

  const schemaVersion = project.schemaVersion || CURRENT_PROJECT_SCHEMA_VERSION;
  if (project.schemaVersion !== schemaVersion) {
    modified = true;
  }

  if (modified) {
    return { ...project, schemaVersion, files };
  }
  return project;
}


/**
 * v4.7.0 — pure helper. Removes the editor-generated legacy addon sample
 * (`res://addons/zylann.hterrain/` with its `plugin.cfg` and `terrain_plugin.ts`)
 * and the `res://addons/` folder itself when it becomes empty.
 * User content inside `res://addons/` is never deleted: it stays in place and a
 * warning is emitted so the user can move it (e.g. to `res://scripts/`).
 * Returns `true` when `files` was changed.
 */
export function removeLegacyAddonSample(files: Record<string, VirtualFile>): boolean {
  let changed = false;
  const legacySample = [
    'res://addons/zylann.hterrain/plugin.cfg',
    'res://addons/zylann.hterrain/terrain_plugin.ts',
  ];
  for (const path of legacySample) {
    if (files[path]) {
      delete files[path];
      changed = true;
    }
  }
  // project.json de builds antigos: remover só a referência gerada ao sample.
  const projectJson = files['res://project.json'];
  if (projectJson?.content) {
    try {
      const parsed = JSON.parse(projectJson.content);
      if (Array.isArray(parsed.addons)) {
        const kept = parsed.addons.filter((a: any) => a?.id !== 'zylann.hterrain');
        if (kept.length !== parsed.addons.length) {
          if (kept.length === 0) delete parsed.addons;
          else parsed.addons = kept; // entradas do usuário: preservadas
          const content = JSON.stringify(parsed, null, 2);
          files['res://project.json'] = { ...projectJson, content, size: content.length };
          changed = true;
        }
      }
    } catch {
      // project.json inválido é tratado pelo loader/validador; nada é descartado aqui.
    }
  }

  const remainingUnder = (prefix: string) =>
    Object.keys(files).filter((k) => k !== prefix && k.startsWith(prefix));

  if (files['res://addons/zylann.hterrain/'] && remainingUnder('res://addons/zylann.hterrain/').length === 0) {
    delete files['res://addons/zylann.hterrain/'];
    changed = true;
  }
  if (files['res://addons/']) {
    const leftovers = remainingUnder('res://addons/');
    if (leftovers.length === 0) {
      delete files['res://addons/'];
      changed = true;
    } else {
      console.warn(
        '[Nodimus v4.7.0] res://addons/ não é mais usado pelo editor; arquivos do usuário preservados:',
        leftovers
      );
    }
  }
  return changed;
}
