import { describe, expect, it } from 'vitest';
import { DEFAULT_MATERIAL_PROPERTIES, MATERIAL_PRESETS } from '../../types/material';
import {
  listProjectTextures,
  materialForRender,
  nodeMaterialOverride,
  patchNodeMaterial,
  presetNodeMaterial,
  readNodeMaterial,
  resolveAlbedoTexture,
  textureRefFromPath,
  toMaterialOverride,
} from './nodeMaterial';

const file = (path: string, content?: string, isDirectory = false) => ({ path, name: path.split('/').pop()!, isDirectory, content });
const PNG = 'data:image/png;base64,iVBORw0KGgo=';

describe('leitura do material do nó', () => {
  it('sem nada: padrões completos', () => {
    const m = readNodeMaterial({}, 'Cubo');
    expect(m).toEqual({ ...DEFAULT_MATERIAL_PROPERTIES, name: 'Cubo' });
  });

  it('cena antiga (chaves planas) continua válida', () => {
    const m = readNodeMaterial({
      materialColor: { r: 1, g: 0, b: 0, a: 1 },
      roughness: 0.2,
      metalness: 0.9,
      wireframe: true,
      shadingModel: 'Phong',
      textureType: 'wood',
      uvTiling: { x: 3, y: 2 },
    });
    expect(m.color).toEqual({ r: 1, g: 0, b: 0, a: 1 });
    expect(m.roughness).toBe(0.2);
    expect(m.wireframe).toBe(true);
    expect(m.shadingModel).toBe('Phong');
    expect(m.textureType).toBe('wood');
    expect(m.uvTiling).toEqual({ x: 3, y: 2 });
    expect(m.opacity).toBe(DEFAULT_MATERIAL_PROPERTIES.opacity); // o resto vem dos padrões
  });

  it('materialOverride vence as chaves planas, campo a campo', () => {
    const o = nodeMaterialOverride({ roughness: 0.2, metalness: 0.5, materialOverride: { roughness: 0.9 } });
    expect(o.roughness).toBe(0.9);
    expect(o.metalness).toBe(0.5);
  });

  it('objetos aninhados parciais são completados (cor sem alfa, tiling sem y)', () => {
    const m = readNodeMaterial({ materialOverride: { color: { r: 0.1, g: 0.2, b: 0.3 }, uvTiling: { x: 4 } } });
    expect(m.color.a).toBe(1);
    expect(m.uvTiling).toEqual({ x: 4, y: 1 });
  });

  it('valores de tipo errado nas chaves planas são ignorados (sem exceção)', () => {
    const m = readNodeMaterial({ roughness: 'alto', wireframe: 'sim', materialColor: 'vermelho', uvTiling: 5 });
    expect(m.roughness).toBe(DEFAULT_MATERIAL_PROPERTIES.roughness);
    expect(m.wireframe).toBe(false);
  });
});

describe('gravação do material (sempre materialOverride)', () => {
  it('toMaterialOverride remove name/base64 e guarda só o que difere dos padrões', () => {
    const edited = {
      ...DEFAULT_MATERIAL_PROPERTIES,
      name: 'X',
      roughness: 0.1,
      customImageDataUrl: PNG,
      textureFileName: 'a.png',
    };
    const o = toMaterialOverride(edited);
    expect(o).toEqual({ roughness: 0.1 });
    expect(JSON.stringify(o)).not.toContain('data:image');
    expect('name' in o).toBe(false);
  });

  it('patchNodeMaterial: troca um canal e preserva o resto (inclusive a textura escolhida)', () => {
    const ref = textureRefFromPath('res://textures/brick.png');
    const props = { materialOverride: { roughness: 0.2, albedoTexture: ref, presetId: 'x' } };
    const next = patchNodeMaterial(props, { metalness: 0.7 });
    expect(next).toMatchObject({ roughness: 0.2, metalness: 0.7, albedoTexture: ref, presetId: 'x' });
  });

  it('patch converte o material legado para o override (migração na primeira edição)', () => {
    const next = patchNodeMaterial({ roughness: 0.3, materialColor: { r: 0, g: 1, b: 0, a: 1 } }, { metalness: 0.8 });
    expect(next).toMatchObject({ roughness: 0.3, metalness: 0.8, color: { r: 0, g: 1, b: 0, a: 1 } });
  });

  it('patch pode remover a textura de albedo (null) e o override só guarda diferenças', () => {
    const props = { materialOverride: { albedoTexture: textureRefFromPath('res://textures/a.png') } };
    expect(patchNodeMaterial(props, { albedoTexture: null }).albedoTexture).toBeUndefined();
    expect(patchNodeMaterial({}, { roughness: DEFAULT_MATERIAL_PROPERTIES.roughness })).toEqual({});
  });

  it('presetNodeMaterial aplica o preset, marca o presetId e mantém a textura de albedo', () => {
    const preset = MATERIAL_PRESETS.find((p) => p.id === 'stone_gray')!;
    const ref = textureRefFromPath('res://textures/t.png');
    const o = presetNodeMaterial({ materialOverride: { albedoTexture: ref } }, preset);
    expect(o.presetId).toBe('stone_gray');
    expect(o.albedoTexture).toEqual(ref);
    expect(o.roughness).toBe(0.88);
    expect('name' in o).toBe(false);
  });
});

describe('textura de albedo = ResourceRef (res://textures/)', () => {
  const files = {
    'res://textures/': file('res://textures/', undefined, true),
    'res://textures/brick.png': file('res://textures/brick.png', PNG),
    'res://textures/note.txt': file('res://textures/note.txt', 'x'),
    'res://textures/noimg.jpg': file('res://textures/noimg.jpg', 'placeholder'),
    'res://scenes/a.png': file('res://scenes/a.png', PNG),
  };

  it('a referência usa identidade estável e o caminho normalizado', () => {
    const ref = textureRefFromPath('res://textures/brick.png');
    expect(ref).toEqual({ id: 'res:res://textures/brick.png', type: 'texture', path: 'res://textures/brick.png', label: 'brick.png' });
    expect(textureRefFromPath('res://textures/brick.png').id).toBe(ref.id);
  });

  it('lista só imagens de res://textures/, ordenadas, com data URL quando existe', () => {
    const list = listProjectTextures(files);
    expect(list.map((t) => t.name)).toEqual(['brick.png', 'noimg.jpg']);
    expect(list[0].dataUrl).toBe(PNG);
    expect(list[1].dataUrl).toBeNull();
    expect(listProjectTextures(undefined)).toEqual([]);
  });

  it('resolve: ok, ausente (órfã, sem exceção) e sem referência', () => {
    expect(resolveAlbedoTexture(textureRefFromPath('res://textures/brick.png'), files)).toEqual({ status: 'resolved', path: 'res://textures/brick.png', dataUrl: PNG });
    expect(resolveAlbedoTexture(textureRefFromPath('res://textures/apagada.png'), files)).toEqual({ status: 'unresolved', path: 'res://textures/apagada.png' });
    expect(resolveAlbedoTexture(undefined, files)).toEqual({ status: 'none' });
    expect(resolveAlbedoTexture({ id: 'x' }, files)).toEqual({ status: 'none' });
  });

  it('materialForRender: imagem resolvida entra como custom_image; órfã cai no material sem arquivo', () => {
    const ok = materialForRender({ materialOverride: { albedoTexture: textureRefFromPath('res://textures/brick.png'), roughness: 0.3 } }, files);
    expect(ok.material.textureType).toBe('custom_image');
    expect(ok.material.customImageDataUrl).toBe(PNG);
    expect(ok.material.roughness).toBe(0.3);

    const orphan = materialForRender({ materialOverride: { albedoTexture: textureRefFromPath('res://textures/apagada.png'), textureType: 'checkerboard' } }, files);
    expect(orphan.texture.status).toBe('unresolved');
    expect(orphan.material.textureType).toBe('checkerboard');
    expect(orphan.material.customImageDataUrl).toBeUndefined();
  });
});

describe('presets de material', () => {
  it('ids únicos e propriedades válidas', () => {
    const ids = MATERIAL_PRESETS.map((p) => p.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const p of MATERIAL_PRESETS) {
      const m = { ...DEFAULT_MATERIAL_PROPERTIES, ...p.properties };
      expect(m.roughness).toBeGreaterThanOrEqual(0);
      expect(m.roughness).toBeLessThanOrEqual(1);
      expect(m.metalness).toBeGreaterThanOrEqual(0);
      expect(m.metalness).toBeLessThanOrEqual(1);
      expect(m.opacity).toBeGreaterThanOrEqual(0);
      expect(m.opacity).toBeLessThanOrEqual(1);
      for (const c of [m.color.r, m.color.g, m.color.b]) {
        expect(c).toBeGreaterThanOrEqual(0);
        expect(c).toBeLessThanOrEqual(1);
      }
      expect(p.previewColor).toMatch(/^#[0-9a-f]{6}$/i);
    }
  });

  it('inclui água, madeira, terra, pedra, metal e grama', () => {
    const ids = MATERIAL_PRESETS.map((p) => p.id);
    for (const id of ['water_clear', 'wood_rustic', 'dirt_soil', 'stone_gray', 'metal_iron', 'grass_lawn']) expect(ids).toContain(id);
  });

  it('a água é translúcida e física; terra e grama são foscas', () => {
    const get = (id: string) => ({ ...DEFAULT_MATERIAL_PROPERTIES, ...MATERIAL_PRESETS.find((p) => p.id === id)!.properties });
    expect(get('water_clear').shadingModel).toBe('Physical');
    expect(get('water_clear').opacity).toBeLessThan(1);
    expect(get('dirt_soil').roughness).toBeGreaterThan(0.9);
    expect(get('grass_lawn').roughness).toBeGreaterThan(0.9);
    expect(get('metal_iron').metalness).toBeGreaterThan(0.8);
  });

  it('cada preset gera um override sem name e sem base64', () => {
    for (const p of MATERIAL_PRESETS) {
      const o = presetNodeMaterial({}, p);
      expect('name' in o).toBe(false);
      expect(JSON.stringify(o)).not.toContain('data:image');
      expect(o.presetId).toBe(p.id);
    }
  });
});
