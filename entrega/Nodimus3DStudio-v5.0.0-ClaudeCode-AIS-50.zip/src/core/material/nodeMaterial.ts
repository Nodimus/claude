import type { ResourceRef } from '../../types/node';
import {
  DEFAULT_MATERIAL_PROPERTIES,
  type MaterialOverride,
  type MaterialProperties,
  type MaterialPreset,
} from '../../types/material';

/**
 * AIS-25 — Material por nó (decisão do usuário, opção B): `GameNode.properties.materialOverride`.
 *
 * Funções puras (sem React/Three) usadas por Viewport, Inspector e Studio 3D, para existir UMA só
 * regra de leitura e de gravação:
 *  - leitura: padrões ← chaves planas LEGADAS ← `materialOverride` (cenas antigas continuam válidas);
 *  - gravação: sempre o objeto `materialOverride` (nunca as chaves planas).
 */

/** Chaves planas antigas em `properties` (lidas por compatibilidade; nunca mais gravadas). */
export const LEGACY_MATERIAL_KEYS = [
  'materialColor',
  'roughness',
  'metalness',
  'wireframe',
  'shadingModel',
  'textureType',
  'textureScale',
  'textureColorA',
  'textureColorB',
  'enableNormalMap',
  'normalScale',
  'uvTiling',
] as const;

type Props = Record<string, any> | undefined;

const isObj = (v: unknown): v is Record<string, any> => typeof v === 'object' && v !== null && !Array.isArray(v);

/** Material legado extraído das chaves planas (só o que existe). */
function legacyMaterial(props: Props): MaterialOverride {
  const out: Record<string, any> = {};
  if (!props) return out;
  if (isObj(props.materialColor)) out.color = props.materialColor;
  for (const key of ['roughness', 'metalness', 'textureScale', 'normalScale'] as const) {
    if (typeof props[key] === 'number') out[key] = props[key];
  }
  for (const key of ['wireframe', 'enableNormalMap'] as const) {
    if (typeof props[key] === 'boolean') out[key] = props[key];
  }
  for (const key of ['shadingModel', 'textureType', 'textureColorA', 'textureColorB'] as const) {
    if (typeof props[key] === 'string') out[key] = props[key];
  }
  if (isObj(props.uvTiling)) out.uvTiling = props.uvTiling;
  return out as MaterialOverride;
}

/** Override efetivo do nó: legado ← `materialOverride` (o override ganha campo a campo). */
export function nodeMaterialOverride(props: Props): MaterialOverride {
  const override = isObj(props?.materialOverride) ? (props!.materialOverride as MaterialOverride) : {};
  return { ...legacyMaterial(props), ...override };
}

/** Material completo (todos os canais) para renderizar/editar; o que falta vem dos padrões. */
export function readNodeMaterial(props: Props, name?: string): MaterialProperties {
  const o = nodeMaterialOverride(props);
  const { albedoTexture: _albedo, normalTexture: _normal, presetId: _preset, ...channels } = o;
  return {
    ...DEFAULT_MATERIAL_PROPERTIES,
    ...(channels as Partial<MaterialProperties>),
    // objetos aninhados: completa campos ausentes
    color: { ...DEFAULT_MATERIAL_PROPERTIES.color, ...(o.color ?? {}) },
    emissiveColor: { ...DEFAULT_MATERIAL_PROPERTIES.emissiveColor, ...(o.emissiveColor ?? {}) },
    uvTiling: { ...DEFAULT_MATERIAL_PROPERTIES.uvTiling, ...(o.uvTiling ?? {}) },
    uvOffset: { ...DEFAULT_MATERIAL_PROPERTIES.uvOffset, ...(o.uvOffset ?? {}) },
    name: name ?? DEFAULT_MATERIAL_PROPERTIES.name,
  };
}

/**
 * Material editado → override para gravar. Remove `name` e `customImageDataUrl` (o nome é do nó e
 * base64 nunca entra na cena) e guarda só o que difere dos padrões (JSON compacto).
 */
export function toMaterialOverride(
  material: MaterialProperties,
  extras: { albedoTexture?: ResourceRef | null; normalTexture?: ResourceRef | null; presetId?: string | null } = {}
): MaterialOverride {
  const { name: _name, customImageDataUrl: _img, textureFileName: _file, ...channels } = material;
  const out: Record<string, any> = {};
  for (const [key, value] of Object.entries(channels)) {
    const def = (DEFAULT_MATERIAL_PROPERTIES as unknown as Record<string, unknown>)[key];
    if (JSON.stringify(value) !== JSON.stringify(def)) out[key] = value;
  }
  if (extras.albedoTexture) out.albedoTexture = extras.albedoTexture;
  if (extras.normalTexture) out.normalTexture = extras.normalTexture;
  if (extras.presetId) out.presetId = extras.presetId;
  return out as MaterialOverride;
}

/** Override depois de aplicar `patch` ao material efetivo do nó (valores iguais ao padrão saem do JSON). */
export function patchNodeMaterial(props: Props, patch: Partial<MaterialProperties> & { albedoTexture?: ResourceRef | null; normalTexture?: ResourceRef | null; presetId?: string | null }): MaterialOverride {
  const current = nodeMaterialOverride(props);
  const { albedoTexture, normalTexture, presetId, ...channels } = patch;
  const merged = { ...readNodeMaterial(props), ...channels };
  return toMaterialOverride(merged, {
    albedoTexture: albedoTexture === undefined ? current.albedoTexture : albedoTexture,
    normalTexture: normalTexture === undefined ? current.normalTexture : normalTexture,
    presetId: presetId === undefined ? current.presetId : presetId,
  });
}

/** Override que aplica um preset (mantém a textura de albedo escolhida; marca o `presetId`). */
export function presetNodeMaterial(props: Props, preset: MaterialPreset): MaterialOverride {
  const current = nodeMaterialOverride(props);
  const base: MaterialProperties = { ...DEFAULT_MATERIAL_PROPERTIES, ...preset.properties, name: preset.name };
  return toMaterialOverride(base, { albedoTexture: current.albedoTexture ?? null, normalTexture: current.normalTexture ?? null, presetId: preset.id });
}

// ── Textura de albedo = ResourceRef ───────────────────────────────────────────────────────────

export const TEXTURES_DIR = 'res://textures/';
const IMAGE_EXT = /\.(png|jpe?g|webp|gif|bmp)$/i;

/**
 * Referência a uma textura de `res://textures/`. O `id` é estável por recurso neste estágio
 * (`res:<caminho>`, igual em todos os nós que usam o arquivo); o ResourceRegistry (AIS-28c)
 * passará a emitir ids próprios sem mudar o formato da referência.
 */
export function textureRefFromPath(path: string): ResourceRef {
  const label = path.split('/').pop() || path;
  return { id: `res:${path}`, type: 'texture', path, label };
}

export interface ProjectTexture {
  path: string;
  name: string;
  /** Conteúdo exibível (data URL) quando o arquivo guarda a imagem; `null` caso contrário. */
  dataUrl: string | null;
}

type FileMap = Record<string, { path: string; name: string; isDirectory: boolean; content?: string }> | undefined;

/** Imagens do projeto em `res://textures/`, ordenadas por nome. */
export function listProjectTextures(files: FileMap): ProjectTexture[] {
  return Object.values(files ?? {})
    .filter((f) => !f.isDirectory && f.path.startsWith(TEXTURES_DIR) && IMAGE_EXT.test(f.name))
    .map((f) => ({
      path: f.path,
      name: f.name,
      dataUrl: typeof f.content === 'string' && f.content.startsWith('data:image') ? f.content : null,
    }))
    .sort((a, b) => a.name.localeCompare(b.name));
}

export type AlbedoResolution =
  | { status: 'none' }
  | { status: 'resolved'; path: string; dataUrl: string | null }
  | { status: 'unresolved'; path: string };

/** Resolve a referência contra os arquivos do projeto; arquivo ausente = referência órfã (não é erro). */
/** Resolve o caminho de uma referência (ResourceRegistry, AIS-28c): pela identidade, para sobreviver a renomear/mover. */
export type RefPathResolver = (ref: ResourceRef) => string | undefined;

export function resolveAlbedoTexture(ref: ResourceRef | undefined, files: FileMap, pathOf?: RefPathResolver): AlbedoResolution {
  if (!ref || (typeof ref.path !== 'string' && !pathOf)) return { status: 'none' };
  const path = pathOf?.(ref) ?? ref.path;
  if (typeof path !== 'string') return { status: 'none' };
  const file = files?.[path];
  if (!file || file.isDirectory) return { status: 'unresolved', path };
  return { status: 'resolved', path, dataUrl: typeof file.content === 'string' && file.content.startsWith('data:image') ? file.content : null };
}

/**
 * Material pronto para o render do nó: canais do override + textura de albedo resolvida.
 * Referência órfã ou sem imagem exibível cai no material sem textura de arquivo (padrão procedural
 * ou cor sólida), sem exceção.
 */
export function materialForRender(props: Props, files: FileMap, name?: string, pathOf?: RefPathResolver): { material: MaterialProperties; texture: AlbedoResolution } {
  const material = readNodeMaterial(props, name);
  const texture = resolveAlbedoTexture(nodeMaterialOverride(props).albedoTexture, files, pathOf);
  if (texture.status === 'resolved' && texture.dataUrl) {
    return { material: { ...material, textureType: 'custom_image', customImageDataUrl: texture.dataUrl }, texture };
  }
  return { material, texture };
}
