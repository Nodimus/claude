import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import {
  applyGroupDelta,
  deltaFromInspectorEdit,
  identityDelta,
  planGroupTransform,
  selectionPivot,
  worldMatrixOf,
} from './groupTransform';
import { groupTransformTargets } from './selectionUtils';

const node = (id: string, parentId: string | null, props: Record<string, any> = {}, locked = false) => ({
  id,
  parentId,
  locked,
  properties: props,
});
const P = (x: number, y = 0, z = 0) => ({ x, y, z });
const flat = (id: string, x: number, y = 0, z = 0) => node(id, 'root', { position: P(x, y, z) });
const world = (nodes: Record<string, any>) => (id: string) => new THREE.Vector3().setFromMatrixPosition(worldMatrixOf(nodes, id));

describe('selectionPivot', () => {
  it('é o centro da bounding box (não a média) dos pontos', () => {
    const c = selectionPivot([new THREE.Vector3(0, 0, 0), new THREE.Vector3(1, 0, 0), new THREE.Vector3(10, 4, 0)]);
    expect(c.toArray()).toEqual([5, 2, 0]);
  });
});

describe('planGroupTransform — translação', () => {
  it('todos recebem o mesmo delta; posições relativas preservadas', () => {
    const nodes = { root: node('root', null), a: flat('a', 0), b: flat('b', 4, 2) };
    const delta = identityDelta();
    delta.translation.set(1, 0, -3);
    const plan = planGroupTransform(nodes, ['a', 'b'], 'translate', delta);
    expect(plan[0].after.position).toEqual(P(1, 0, -3));
    expect(plan[1].after.position).toEqual(P(5, 2, -3));
    expect(plan[0].after.rotation).toEqual(P(0));
    expect(plan[0].after.scale).toEqual(P(1, 1, 1));
  });
});

describe('planGroupTransform — rotação em torno do pivô', () => {
  it('90° em Y: a=(−2,0,0) e b=(2,0,0) giram em torno do centro (0,0,0)', () => {
    const nodes = { root: node('root', null), a: flat('a', -2), b: flat('b', 2) };
    const delta = identityDelta();
    delta.rotation.setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI / 2);
    const [a, b] = planGroupTransform(nodes, ['a', 'b'], 'rotate', delta);
    expect(a.after.position.x).toBeCloseTo(0, 3);
    expect(a.after.position.z).toBeCloseTo(2, 3); // (-2,0,0) → (0,0,2)
    expect(b.after.position.z).toBeCloseTo(-2, 3);
    expect(a.after.rotation.y).toBeCloseTo(90, 1);
    expect(b.after.rotation.y).toBeCloseTo(90, 1);
    // distância entre os nós preservada
    const d = Math.hypot(a.after.position.x - b.after.position.x, a.after.position.z - b.after.position.z);
    expect(d).toBeCloseTo(4, 2);
  });
});

describe('planGroupTransform — escala em torno do pivô', () => {
  it('2× afasta os nós do centro e multiplica a escala', () => {
    const nodes = { root: node('root', null), a: flat('a', -2), b: flat('b', 2) };
    const delta = identityDelta();
    delta.scale.set(2, 2, 2);
    const [a, b] = planGroupTransform(nodes, ['a', 'b'], 'scale', delta);
    expect(a.after.position.x).toBe(-4);
    expect(b.after.position.x).toBe(4);
    expect(a.after.scale).toEqual(P(2, 2, 2));
  });

  it('pivô explícito (centro da bounding box dos meshes) vale sobre o das posições', () => {
    const nodes = { root: node('root', null), a: flat('a', 0), b: flat('b', 2) };
    const delta = identityDelta();
    delta.scale.set(2, 1, 1);
    const [a, b] = planGroupTransform(nodes, ['a', 'b'], 'scale', delta, new THREE.Vector3(0, 0, 0));
    expect(a.after.position.x).toBe(0);
    expect(b.after.position.x).toBe(4);
  });
});

describe('hierarquia e filhos', () => {
  it('posição local respeita o pai transformado (resultado mundial correto)', () => {
    const nodes = {
      root: node('root', null),
      parent: node('parent', 'root', { position: P(10), scale: P(2, 2, 2) }),
      child: node('child', 'parent', { position: P(1) }), // mundo = 12
    };
    const delta = identityDelta();
    delta.translation.set(4, 0, 0);
    const [c] = planGroupTransform(nodes, ['child'], 'translate', delta);
    expect(c.after.position.x).toBeCloseTo(3, 3); // local 1 + (4 mundo / escala 2 do pai) = 3
  });

  it('descendente de selecionado é podado; locked fica parado', () => {
    const nodes = {
      root: node('root', null),
      a: flat('a', 0),
      kid: node('kid', 'a', {}),
      lock: node('lock', 'root', {}, true),
      b: flat('b', 5),
    };
    const targets = groupTransformTargets(nodes, ['a', 'kid', 'lock', 'b'], 'root');
    expect(targets).toEqual(['a', 'b']);
    const delta = identityDelta();
    delta.translation.set(1, 0, 0);
    const plan = planGroupTransform(nodes, targets, 'translate', delta);
    expect(plan.map((p) => p.nodeId)).toEqual(['a', 'b']);
    // o filho acompanha pela hierarquia: mundo = pai + local
    const nextNodes = { ...nodes, a: { ...nodes.a, properties: { position: plan[0].after.position } } };
    expect(world(nextNodes)('kid').x).toBeCloseTo(1, 5);
  });
});

describe('deltaFromInspectorEdit', () => {
  it('posição: delta = novo − antigo no espaço mundial', () => {
    const d = deltaFromInspectorEdit('translate', P(1), P(4, 2), new THREE.Matrix4());
    expect(d.translation.toArray()).toEqual([3, 2, 0]);
  });
  it('rotação: Y 0→90 equivale a 90° em Y', () => {
    const d = deltaFromInspectorEdit('rotate', P(0), P(0, 90, 0), new THREE.Matrix4());
    const v = new THREE.Vector3(1, 0, 0).applyQuaternion(d.rotation);
    expect(v.z).toBeCloseTo(-1, 5);
  });
  it('escala: razão novo/antigo; antigo zero não explode', () => {
    const d = deltaFromInspectorEdit('scale', P(1, 2, 0), P(3, 2, 5), new THREE.Matrix4());
    expect(d.scale.toArray()).toEqual([3, 1, 1]);
  });
});

describe('applyGroupDelta — arredondamento', () => {
  it('usa a precisão da casca (posição 3 casas, rotação 1 casa) e sem -0', () => {
    const t = applyGroupDelta('translate', new THREE.Vector3(), { ...identityDelta(), translation: new THREE.Vector3(0.12349, 0, 0) }, {
      world: new THREE.Matrix4(),
      parentWorld: new THREE.Matrix4(),
    });
    expect(t.position.x).toBe(0.123);
    expect(Object.is(t.position.y, 0)).toBe(true);
  });
});
