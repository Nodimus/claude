import type { GameNode } from '../../types/node';

/** Subconjunto do AuthoringModel usado para restaurar nós (facilita testar). */
export interface SubtreeRestoreTarget {
  addNode(node: GameNode, parentId?: string | null): unknown;
  reparentNode(nodeId: string, newParentId: string | null, targetIndex?: number): void;
}

export interface DeletedRoot {
  id: string;
  parentId: string | null;
  /** Posição do nó entre os irmãos antes da exclusão (-1 = desconhecida). */
  index: number;
}

/**
 * Desfaz a exclusão de subárvores (Undo de delete).
 *
 * `backups` deve estar em ordem pai→filhos (DFS), como foi salvo antes de excluir.
 * Cada nó é reinserido SEM `childrenIds`: `addNode` já anexa o nó à lista do pai, então
 * manter a lista original duplicaria os filhos (mesma chave duas vezes na árvore).
 * Em seguida, cada raiz excluída volta à posição original entre os irmãos.
 */
export function restoreDeletedSubtrees(
  target: SubtreeRestoreTarget,
  backups: readonly GameNode[],
  roots: readonly DeletedRoot[]
): void {
  for (const node of backups) {
    target.addNode({ ...node, childrenIds: [] }, node.parentId);
  }
  // índices ascendentes: cada reinserção respeita as já feitas
  const ordered = [...roots].filter((r) => r.index >= 0 && r.parentId).sort((a, b) => a.index - b.index);
  for (const root of ordered) {
    target.reparentNode(root.id, root.parentId, root.index);
  }
}
