import { describe, expect, it } from 'vitest';
import { AuthoringModel } from './AuthoringModel';
import { createEmptyScene } from '../defaultProject';
import { restoreDeletedSubtrees } from './restoreSubtree';
import type { GameNode } from '../../types/node';

const node = (id: string, parentId: string | null, childrenIds: string[] = []): GameNode =>
  ({ id, name: id, type: 'Spatial', parentId, childrenIds, visible: true, locked: false, properties: {} }) as GameNode;

function makeModel() {
  const scene = createEmptyScene();
  const rootId = scene.rootNodeId;
  scene.nodes = {
    [rootId]: node(rootId, null, ['a', 'b', 'c']),
    a: node('a', rootId),
    b: node('b', rootId, ['b1', 'b2']),
    b1: node('b1', 'b'),
    b2: node('b2', 'b'),
    c: node('c', rootId),
  };
  const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene);
  return { model, rootId };
}

const snapshot = (model: AuthoringModel, ids: string[]) => ids.map((id) => structuredClone(model.getScene().nodes[id]));

describe('restoreDeletedSubtrees', () => {
  it('Undo de subárvore com filhos não duplica os filhos e restaura a posição', () => {
    const { model, rootId } = makeModel();
    const before = structuredClone(model.getScene().nodes);
    const backups = snapshot(model, ['b', 'b1', 'b2']);
    model.deleteNode('b');
    expect(model.getScene().nodes.b).toBeUndefined();

    restoreDeletedSubtrees(model, backups, [{ id: 'b', parentId: rootId, index: 1 }]);
    const after = model.getScene().nodes;
    expect(after[rootId].childrenIds).toEqual(['a', 'b', 'c']);
    expect(after.b.childrenIds).toEqual(['b1', 'b2']);
    expect(Object.keys(after).sort()).toEqual(Object.keys(before).sort());
  });

  it('Undo em lote restaura várias raízes nas posições originais', () => {
    const { model, rootId } = makeModel();
    const backups = snapshot(model, ['a', 'b', 'b1', 'b2', 'c']);
    model.deleteMultipleNodes(['a', 'b', 'c']);
    expect(model.getScene().nodes[rootId].childrenIds).toEqual([]);

    restoreDeletedSubtrees(model, backups, [
      { id: 'a', parentId: rootId, index: 0 },
      { id: 'b', parentId: rootId, index: 1 },
      { id: 'c', parentId: rootId, index: 2 },
    ]);
    const nodes = model.getScene().nodes;
    expect(nodes[rootId].childrenIds).toEqual(['a', 'b', 'c']);
    expect(nodes.b.childrenIds).toEqual(['b1', 'b2']);
  });
});
