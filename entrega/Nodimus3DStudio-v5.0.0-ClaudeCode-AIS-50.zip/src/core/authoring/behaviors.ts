/**
 * AIS-41b — Behaviors como `GameNode.behaviors` (a ÚNICA fonte da verdade) e a visão achatada que a UI e os Commands usam.
 *
 *   cena (nós com `behaviors: BehaviorInstance[]`)  ⇄  lista de `Behavior` (= instância + `targetNodeId` = ID do nó dono)
 *
 * `collectBehaviors` deriva a lista (nada é copiado para um segundo lugar); `applyBehaviorList` escreve de volta só o que
 * mudou, por nó (`AuthoringModel.setNodeBehaviors`). A visão de uma instância que não mudou é a MESMA referência entre
 * chamadas (WeakMap) — sem isso o React re-renderizaria tudo e os Commands não detectariam "nada mudou".
 */
import type { Behavior, BehaviorInstance } from '../../types/visualLogic';
import type { GameNode } from '../../types/node';

type SceneLike = { nodes: Record<string, GameNode> };
interface BehaviorSink {
  getScene(): SceneLike;
  setNodeBehaviors(nodeId: string, behaviors: BehaviorInstance[]): void;
}

const viewOfInstance = new WeakMap<BehaviorInstance, Behavior>();
const instanceOfView = new WeakMap<Behavior, BehaviorInstance>();

function viewOf(instance: BehaviorInstance, nodeId: string): Behavior {
  const cached = viewOfInstance.get(instance);
  if (cached && cached.targetNodeId === nodeId) return cached;
  const view: Behavior = { ...instance, targetNodeId: nodeId };
  viewOfInstance.set(instance, view);
  instanceOfView.set(view, instance);
  return view;
}

/** Instância de uma visão: a original se a visão não foi alterada; senão uma nova, sem o `targetNodeId`. */
function instanceOf(view: Behavior): BehaviorInstance {
  const original = instanceOfView.get(view);
  if (original) return original;
  const { targetNodeId: _target, ...instance } = view;
  return instance;
}

/** Todos os Behaviors da cena, na ordem dos nós, cada um com o nó dono em `targetNodeId` (ID do nó). */
export function collectBehaviors(scene: SceneLike): Behavior[] {
  const out: Behavior[] = [];
  for (const node of Object.values(scene.nodes ?? {})) for (const instance of node.behaviors ?? []) out.push(viewOf(instance, node.id));
  return out;
}

/** Nó dono de um `targetNodeId`: por ID, ou por nome quando for único (dados antigos usavam o nome). */
export function resolveBehaviorOwner(scene: SceneLike, target: string): string | null {
  if (scene.nodes[target]) return target;
  const byName = Object.values(scene.nodes).filter((n) => n.name === target);
  return byName.length === 1 ? byName[0].id : null;
}

export interface GroupedBehaviors {
  byNode: Map<string, BehaviorInstance[]>;
  /** Visões cujo `targetNodeId` não resolve para nenhum nó (nada é gravado para elas). */
  orphans: Behavior[];
}

export function groupBehaviorsByNode(list: readonly Behavior[], scene: SceneLike): GroupedBehaviors {
  const byNode = new Map<string, BehaviorInstance[]>();
  const orphans: Behavior[] = [];
  for (const view of list) {
    const owner = resolveBehaviorOwner(scene, view.targetNodeId);
    if (!owner) {
      orphans.push(view);
      continue;
    }
    byNode.set(owner, [...(byNode.get(owner) ?? []), instanceOf(view)]);
  }
  return { byNode, orphans };
}

const sameInstances = (a: readonly BehaviorInstance[], b: readonly BehaviorInstance[]) => a.length === b.length && a.every((x, i) => x === b[i]);

/**
 * Faz a cena refletir `list`: reescreve só os nós cujas instâncias mudaram (identidade); um nó que deixou de aparecer na
 * lista fica sem Behaviors. Devolve as visões órfãs (alvo inexistente) para o chamador avisar.
 */
export function applyBehaviorList(sink: BehaviorSink, list: readonly Behavior[]): Behavior[] {
  const scene = sink.getScene();
  const { byNode, orphans } = groupBehaviorsByNode(list, scene);
  for (const node of Object.values(scene.nodes)) {
    const current = node.behaviors ?? [];
    const next = byNode.get(node.id) ?? [];
    if (!sameInstances(current, next)) sink.setNodeBehaviors(node.id, next);
  }
  return orphans;
}
