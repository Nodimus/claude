/**
 * Nodimus 3D Studio — Snapshot and Materialization
 *
 * Implements deterministic creation of AuthoringSceneSnapshot and materialization
 * of RuntimeSceneContract from an authoring scene.
 */

import { SceneData } from '../../types/scene';
import { GameNode, NodeType } from '../../types/node';
import {
  AuthoringSceneSnapshot,
  RuntimeInstanceHandle,
  RuntimeSceneContract,
} from '../../types/runtime';
import { CURRENT_SCENE_SCHEMA_VERSION } from '../persistenceVersions';

/**
 * Extracts a normalized 3D transform tuple from a node, reading from either
 * node.transform or node.properties.
 */
export function extractNodeTransform(node: GameNode): {
  position: [number, number, number];
  rotation: [number, number, number];
  scale: [number, number, number];
} {
  const p = node.transform?.position ?? node.properties?.position ?? { x: 0, y: 0, z: 0 };
  const r = node.transform?.rotation ?? node.properties?.rotation ?? { x: 0, y: 0, z: 0 };
  const s = node.transform?.scale ?? node.properties?.scale ?? { x: 1, y: 1, z: 1 };

  const posX = Array.isArray(p) ? (p[0] ?? 0) : (p?.x ?? 0);
  const posY = Array.isArray(p) ? (p[1] ?? 0) : (p?.y ?? 0);
  const posZ = Array.isArray(p) ? (p[2] ?? 0) : (p?.z ?? 0);

  const rotX = Array.isArray(r) ? (r[0] ?? 0) : (r?.x ?? 0);
  const rotY = Array.isArray(r) ? (r[1] ?? 0) : (r?.y ?? 0);
  const rotZ = Array.isArray(r) ? (r[2] ?? 0) : (r?.z ?? 0);

  const scaleX = Array.isArray(s) ? (s[0] ?? 1) : (s?.x ?? 1);
  const scaleY = Array.isArray(s) ? (s[1] ?? 1) : (s?.y ?? 1);
  const scaleZ = Array.isArray(s) ? (s[2] ?? 1) : (s?.z ?? 1);

  return {
    position: [posX, posY, posZ],
    rotation: [rotX, rotY, rotZ],
    scale: [scaleX, scaleY, scaleZ],
  };
}

/**
 * Creates an immutable, serializable snapshot of the given authoring scene.
 * Guarantees deep decoupling from authoring scene references.
 */
export function createRuntimeSnapshot(authoringScene: SceneData): AuthoringSceneSnapshot {
  const snapshotId = `snap_${authoringScene.id || 'scene'}_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;

  // Deep clone nodes and eliminate any non-serializable properties
  const clonedNodes: Record<string, GameNode> = {};
  for (const [id, node] of Object.entries(authoringScene.nodes)) {
    const t = extractNodeTransform(node);
    clonedNodes[id] = {
      id: node.id,
      name: node.name,
      type: node.type,
      parentId: node.parentId ?? null,
      childrenIds: [...(node.childrenIds || [])],
      transform: {
        position: t.position,
        rotation: t.rotation,
        scale: t.scale,
      },
      properties: JSON.parse(JSON.stringify(node.properties || {})),
      tags: [...(node.tags || [])],
      variables: JSON.parse(JSON.stringify(node.variables || {})),
      behaviors: JSON.parse(JSON.stringify(node.behaviors || [])), // AIS-41b: instâncias inline (objetos): cópia profunda
      visualLogic: node.visualLogic ? JSON.parse(JSON.stringify(node.visualLogic)) : undefined,
      visible: node.visible !== false,
      locked: Boolean(node.locked),
    };
  }

  const snapshot: AuthoringSceneSnapshot = {
    snapshotId,
    sceneId: authoringScene.id || 'default_scene',
    name: authoringScene.name,
    schemaVersion: authoringScene.schemaVersion ?? CURRENT_SCENE_SCHEMA_VERSION,
    rootNodeId: authoringScene.rootNodeId,
    nodes: Object.freeze(clonedNodes),
    environmentNodeId: authoringScene.environmentNodeId ?? null,
    sceneSettings: authoringScene.environmentSettings
      ? Object.freeze(JSON.parse(JSON.stringify(authoringScene.environmentSettings)))
      : undefined,
    createdAt: new Date().toISOString(),
  };

  return Object.freeze(snapshot);
}

/**
 * Materializes an executable RuntimeSceneContract from an AuthoringSceneSnapshot.
 * Generates decoupled runtime instance handles with independent transform state.
 */
export function materializeRuntimeScene(snapshot: AuthoringSceneSnapshot): RuntimeSceneContract {
  const instancesMap = new Map<string, RuntimeInstanceHandle>();
  const instancesList: RuntimeInstanceHandle[] = [];

  for (const [nodeId, node] of Object.entries(snapshot.nodes)) {
    const runtimeHandleId = `inst_${nodeId}_${Math.random().toString(36).substring(2, 7)}`;
    const t = extractNodeTransform(node);

    const handle: RuntimeInstanceHandle = {
      id: runtimeHandleId,
      persistentNodeId: nodeId,
      name: node.name,
      type: node.type,
      transform: {
        position: [...t.position],
        rotation: [...t.rotation],
        scale: [...t.scale],
      },
      properties: JSON.parse(JSON.stringify(node.properties || {})),
      tags: [...(node.tags || [])],
      visible: node.visible,
      disposed: false,
    };

    instancesMap.set(runtimeHandleId, handle);
    instancesMap.set(nodeId, handle); // indexed by persistentNodeId as well
    instancesList.push(handle);
  }

  return {
    sceneId: snapshot.sceneId,
    name: snapshot.name,
    rootNodeId: snapshot.rootNodeId,
    getInstance(idOrNodeId: string): RuntimeInstanceHandle | undefined {
      return instancesMap.get(idOrNodeId);
    },
    getAllInstances(): RuntimeInstanceHandle[] {
      return instancesList.filter((inst) => !inst.disposed);
    },
    findInstancesByTag(tag: string): RuntimeInstanceHandle[] {
      return instancesList.filter((inst) => !inst.disposed && inst.tags.includes(tag));
    },
    findInstancesByType(type: NodeType): RuntimeInstanceHandle[] {
      return instancesList.filter((inst) => !inst.disposed && inst.type === type);
    },
  };
}
