/**
 * Nodimus 3D Studio — Authoring Model (AIS-03c)
 *
 * Single in-memory authority for persistent project and scene data.
 * All user authoring mutations (directly or via CommandManager) target this model.
 * UI frameworks (e.g. EditorContext facade) subscribe to this model for projection.
 * Runtime simulation operates exclusively on snapshots materialized from this model.
 */

import { ProjectData } from '../../types/project';
import { SceneData, DEFAULT_SCENE_ENVIRONMENT, DEFAULT_SCENE_FOG } from '../../types/scene';
import { GameNode, Transform3D } from '../../types/node';
import { createDefault3DStarterScene, ensureStarterFiles } from '../defaultProject';
import { ProjectStorage } from '../projectStorage';
import { AuthoringSceneSnapshot } from '../../types/runtime';
import { parseSceneJson } from '../serialization/sceneSerializer';
import { notePendingBackup } from '../serialization/migrationBackup';
import { blockWrites } from '../serialization/writeGuard';
import { createRuntimeSnapshot, extractNodeTransform } from './snapshot';

export type AuthoringEventType =
  | 'project_loaded'
  | 'project_updated'
  | 'scene_loaded'
  | 'scene_updated'
  | 'node_added'
  | 'node_updated'
  | 'node_deleted'
  | 'node_reparented'
  | 'settings_updated';

export interface AuthoringEvent {
  type: AuthoringEventType;
  timestamp: string;
  nodeId?: string;
  details?: Record<string, any>;
}

export type AuthoringListener = (event: AuthoringEvent) => void;

export class AuthoringModel {
  private project: ProjectData;
  private activeScene: SceneData;
  private listeners: Set<AuthoringListener> = new Set();

  constructor(initialProject?: ProjectData, initialScene?: SceneData) {
    if (initialProject && initialScene) {
      this.project = initialProject;
      this.activeScene = initialScene;
    } else {
      const raw = ProjectStorage.getOrCreateDefaultProject();
      this.project = ensureStarterFiles(raw);
      const initialScenePath = this.project.lastOpenedScene || this.project.settings.general.mainScene;
      const sceneFile = this.project.files[initialScenePath];
      if (sceneFile && sceneFile.content) {
        // AIS-29: leitura tolerante; cena irrecuperável cai na cena inicial (o arquivo em disco não é tocado)
        const parsed = parseSceneJson(sceneFile.content, initialScenePath);
        if (parsed.ok && parsed.scene) {
          this.activeScene = parsed.scene;
          if (parsed.migration?.migrated) notePendingBackup(initialScenePath, parsed.migration.fromVersion, sceneFile.content);
        } else {
          // AIS-29b: a cena inicial é só um substituto — o arquivo ilegível NUNCA é sobrescrito por ela
          this.activeScene = createDefault3DStarterScene();
          blockWrites(initialScenePath, parsed.diagnostics.find((d) => d.severity === 'error')?.message ?? 'cena inválida');
        }
      } else {
        this.activeScene = createDefault3DStarterScene();
      }
    }
  }

  // ── Read API ──────────────────────────────────────────────────────────────

  public getProject(): ProjectData {
    return this.project;
  }

  public getScene(): SceneData {
    return this.activeScene;
  }

  public getNode(nodeId: string): GameNode | undefined {
    return this.activeScene.nodes[nodeId];
  }

  public getRootNode(): GameNode | undefined {
    return this.activeScene.nodes[this.activeScene.rootNodeId];
  }

  // ── Subscription API ──────────────────────────────────────────────────────

  public subscribe(listener: AuthoringListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(type: AuthoringEventType, details?: Record<string, any>, nodeId?: string): void {
    const event: AuthoringEvent = {
      type,
      timestamp: new Date().toISOString(),
      nodeId,
      details,
    };
    for (const listener of this.listeners) {
      try {
        listener(event);
      } catch (err) {
        console.error('Error in AuthoringModel subscriber:', err);
      }
    }
  }

  // ── Replacements / Loading ────────────────────────────────────────────────

  public loadProject(newProject: ProjectData): void {
    this.project = newProject;
    this.notify('project_loaded');
  }

  public loadScene(newScene: SceneData): void {
    this.activeScene = newScene;
    this.notify('scene_loaded');
  }

  public setProject(updater: ProjectData | ((prev: ProjectData) => ProjectData)): void {
    const updated = typeof updater === 'function' ? updater(this.project) : updater;
    this.project = updated;
    this.notify('project_updated');
  }

  public setScene(updater: SceneData | ((prev: SceneData) => SceneData)): void {
    const updated = typeof updater === 'function' ? updater(this.activeScene) : updater;
    this.activeScene = updated;
    this.notify('scene_updated');
  }

  // ── Explicit Authoring Operations ─────────────────────────────────────────

  public updateNodeProperties(nodeId: string, updates: Record<string, any>): void {
    const node = this.activeScene.nodes[nodeId];
    if (!node) return;

    let updatedEnv = this.activeScene.environment;
    let updatedFog = this.activeScene.fog;

    // AIS-06: Canonical Environment GameNode is the authority; sync transitional fallbacks
    if (node.type === 'Environment') {
      const mergedProps = { ...node.properties, ...updates };
      const currentEnv = this.activeScene.environment || DEFAULT_SCENE_ENVIRONMENT;
      const currentFog = this.activeScene.fog || DEFAULT_SCENE_FOG;

      const toHex = (c: any, fallback: string): string => {
        if (!c) return fallback;
        if (typeof c === 'string') return c.startsWith('#') ? c : `#${c}`;
        if (typeof c.r === 'number' && typeof c.g === 'number' && typeof c.b === 'number') {
          const f = (n: number) => Math.round(Math.max(0, Math.min(1, n)) * 255).toString(16).padStart(2, '0');
          return `#${f(c.r)}${f(c.g)}${f(c.b)}`;
        }
        return fallback;
      };

      updatedEnv = {
        ...currentEnv,
        ambientColor: toHex(mergedProps.ambientColor, currentEnv.ambientColor),
        ambientIntensity: typeof mergedProps.ambientIntensity === 'number' ? mergedProps.ambientIntensity : currentEnv.ambientIntensity,
        backgroundColor: toHex(mergedProps.backgroundColor, currentEnv.backgroundColor),
        realtimeShadows: mergedProps.realtimeShadows !== undefined ? Boolean(mergedProps.realtimeShadows) : currentEnv.realtimeShadows,
      };

      updatedFog = {
        ...currentFog,
        enabled: mergedProps.fogEnabled !== undefined ? Boolean(mergedProps.fogEnabled) : currentFog.enabled,
        mode: mergedProps.fogMode || currentFog.mode,
        color: toHex(mergedProps.fogColor, currentFog.color),
        density: typeof mergedProps.fogDensity === 'number' ? mergedProps.fogDensity : currentFog.density,
        near: typeof mergedProps.fogNear === 'number' ? mergedProps.fogNear : currentFog.near,
        far: typeof mergedProps.fogFar === 'number' ? mergedProps.fogFar : currentFog.far,
      };
    }

    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      environment: updatedEnv,
      environmentSettings: updatedEnv,
      fog: updatedFog,
      nodes: {
        ...this.activeScene.nodes,
        [nodeId]: {
          ...node,
          properties: {
            ...node.properties,
            ...updates,
          },
        },
      },
    };
    this.notify('node_updated', { updates }, nodeId);
  }

  /** AIS-27: substitui as conexões de sinal do nó (Commands de sinal; nunca mutar `node.signals` direto). */
  public setNodeSignals(nodeId: string, signals: NonNullable<GameNode['signals']>): void {
    const node = this.activeScene.nodes[nodeId];
    if (!node) return;
    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      nodes: { ...this.activeScene.nodes, [nodeId]: { ...node, signals: signals.map((s) => ({ ...s, arguments: s.arguments?.map((a) => ({ ...a })) })) } },
    };
    this.notify('node_updated', { signals: signals.length }, nodeId);
  }

  /**
   * AIS-41b: substitui as instâncias de Behavior do nó (`GameNode.behaviors`). Só os Commands do Visual Logic chamam isto
   * (via `BehaviorStore`); as instâncias são imutáveis (cada edição cria objetos novos), então são guardadas como vêm.
   */
  public setNodeBehaviors(nodeId: string, behaviors: NonNullable<GameNode['behaviors']>): void {
    const node = this.activeScene.nodes[nodeId];
    if (!node) return;
    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      nodes: { ...this.activeScene.nodes, [nodeId]: { ...node, behaviors: [...behaviors] } },
    };
    this.notify('node_updated', { behaviors: behaviors.length }, nodeId);
  }

  /** AIS-43: substitui as variáveis locais do nó (`GameNode.variables`; só os Commands de variável chamam isto). */
  public setNodeVariables(nodeId: string, variables: Record<string, any>): void {
    const node = this.activeScene.nodes[nodeId];
    if (!node) return;
    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      nodes: { ...this.activeScene.nodes, [nodeId]: { ...node, variables: { ...variables } } },
    };
    this.notify('node_updated', { variables: Object.keys(variables).length }, nodeId);
  }

  /** AIS-49b: troca (ou remove, com `undefined`) o `generatorSource` do nó; só os Commands de gerador chamam isto. */
  public setNodeGeneratorSource(nodeId: string, source: GameNode['generatorSource'] | undefined): void {
    const node = this.activeScene.nodes[nodeId];
    if (!node) return;
    const { generatorSource: _previous, ...rest } = node;
    const next = (source === undefined ? rest : { ...rest, generatorSource: source }) as GameNode;
    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      nodes: { ...this.activeScene.nodes, [nodeId]: next },
    };
    this.notify('node_updated', { generatorSource: source?.generatorId ?? null }, nodeId);
  }

  /** AIS-21: remove chaves de `properties` (Undo de uma propriedade que não existia antes). */
  public removeNodeProperties(nodeId: string, keys: string[]): void {
    const node = this.activeScene.nodes[nodeId];
    if (!node || keys.length === 0) return;
    const properties = { ...node.properties };
    for (const key of keys) delete properties[key];
    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      nodes: { ...this.activeScene.nodes, [nodeId]: { ...node, properties } },
    };
    this.notify('node_updated', { removed: keys }, nodeId);
  }

  public setNodeTransform(nodeId: string, transform: Partial<Transform3D>): void {
    const node = this.activeScene.nodes[nodeId];
    if (!node) return;

    const currentT = extractNodeTransform(node);

    const newPos: [number, number, number] = transform.position
      ? (Array.isArray(transform.position)
        ? [transform.position[0] ?? 0, transform.position[1] ?? 0, transform.position[2] ?? 0]
        : [transform.position.x ?? 0, transform.position.y ?? 0, transform.position.z ?? 0])
      : currentT.position;

    const newRot: [number, number, number] = transform.rotation
      ? (Array.isArray(transform.rotation)
        ? [transform.rotation[0] ?? 0, transform.rotation[1] ?? 0, transform.rotation[2] ?? 0]
        : [transform.rotation.x ?? 0, transform.rotation.y ?? 0, transform.rotation.z ?? 0])
      : currentT.rotation;

    const newScale: [number, number, number] = transform.scale
      ? (Array.isArray(transform.scale)
        ? [transform.scale[0] ?? 1, transform.scale[1] ?? 1, transform.scale[2] ?? 1]
        : [transform.scale.x ?? 1, transform.scale.y ?? 1, transform.scale.z ?? 1])
      : currentT.scale;

    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      nodes: {
        ...this.activeScene.nodes,
        [nodeId]: {
          ...node,
          transform: {
            position: newPos,
            rotation: newRot,
            scale: newScale,
          },
          properties: {
            ...node.properties,
            position: { x: newPos[0], y: newPos[1], z: newPos[2] },
            rotation: { x: newRot[0], y: newRot[1], z: newRot[2] },
            scale: { x: newScale[0], y: newScale[1], z: newScale[2] },
          },
        },
      },
    };
    this.notify('node_updated', { transform }, nodeId);
  }

  public addNode(node: GameNode, parentId?: string | null): GameNode {
    const effectiveParentId = parentId || this.activeScene.rootNodeId;
    const parentNode = this.activeScene.nodes[effectiveParentId];

    const updatedNode: GameNode = {
      ...node,
      parentId: effectiveParentId,
    };

    const updatedNodes = {
      ...this.activeScene.nodes,
      [node.id]: updatedNode,
    };

    if (parentNode) {
      updatedNodes[effectiveParentId] = {
        ...parentNode,
        childrenIds: [...(parentNode.childrenIds || []), node.id],
      };
    }

    let updatedEnvironmentNodeId = this.activeScene.environmentNodeId;
    if (node.type === 'Environment') {
      updatedEnvironmentNodeId = node.id;
    }

    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      environmentNodeId: updatedEnvironmentNodeId,
      nodes: updatedNodes,
    };

    this.notify('node_added', { node: updatedNode }, node.id);
    return updatedNode;
  }

  public deleteNode(nodeId: string): void {
    if (nodeId === this.activeScene.rootNodeId) return;
    const targetNode = this.activeScene.nodes[nodeId];
    if (!targetNode) return;

    // Collect all descendants
    const toDelete = new Set<string>();
    const collectDescendants = (id: string) => {
      toDelete.add(id);
      const n = this.activeScene.nodes[id];
      if (n && n.childrenIds) {
        n.childrenIds.forEach(collectDescendants);
      }
    };
    collectDescendants(nodeId);

    const updatedNodes = { ...this.activeScene.nodes };
    toDelete.forEach((id) => delete updatedNodes[id]);

    // Remove from parent's childrenIds
    const parentId = targetNode.parentId;
    if (parentId && updatedNodes[parentId]) {
      updatedNodes[parentId] = {
        ...updatedNodes[parentId],
        childrenIds: updatedNodes[parentId].childrenIds.filter((cid) => cid !== nodeId),
      };
    }

    let updatedEnvId = this.activeScene.environmentNodeId;
    if (toDelete.has(updatedEnvId || '')) {
      updatedEnvId = null;
    }

    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      environmentNodeId: updatedEnvId,
      nodes: updatedNodes,
    };

    this.notify('node_deleted', { deletedIds: Array.from(toDelete) }, nodeId);
  }

  public deleteMultipleNodes(nodeIds: string[]): void {
    const toDelete = new Set<string>();
    const collectDescendants = (id: string) => {
      toDelete.add(id);
      const n = this.activeScene.nodes[id];
      if (n && n.childrenIds) {
        n.childrenIds.forEach(collectDescendants);
      }
    };

    for (const id of nodeIds) {
      if (id !== this.activeScene.rootNodeId && this.activeScene.nodes[id]) {
        collectDescendants(id);
      }
    }

    if (toDelete.size === 0) return;

    const updatedNodes = { ...this.activeScene.nodes };
    toDelete.forEach((id) => delete updatedNodes[id]);

    // Clean parent references
    for (const parent of Object.values(updatedNodes)) {
      const remainingChildren = parent.childrenIds.filter((cid) => !toDelete.has(cid));
      if (remainingChildren.length !== parent.childrenIds.length) {
        updatedNodes[parent.id] = {
          ...parent,
          childrenIds: remainingChildren,
        };
      }
    }

    let updatedEnvId = this.activeScene.environmentNodeId;
    if (toDelete.has(updatedEnvId || '')) {
      updatedEnvId = null;
    }

    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      environmentNodeId: updatedEnvId,
      nodes: updatedNodes,
    };

    this.notify('node_deleted', { deletedIds: Array.from(toDelete) });
  }

  public renameNode(nodeId: string, newName: string): void {
    const node = this.activeScene.nodes[nodeId];
    if (!node) return;

    const trimmed = newName.trim();
    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      nodes: {
        ...this.activeScene.nodes,
        [nodeId]: {
          ...node,
          name: trimmed,
        },
      },
    };
    this.notify('node_updated', { name: trimmed }, nodeId);
  }

  public reparentNode(nodeId: string, newParentId: string | null, targetIndex?: number): void {
    if (nodeId === newParentId) return;
    const node = this.activeScene.nodes[nodeId];
    if (!node) return;

    const effectiveParentId = newParentId || this.activeScene.rootNodeId;
    const updatedNodes = { ...this.activeScene.nodes };

    // Remove from old parent
    const oldParentId = node.parentId;
    if (oldParentId && updatedNodes[oldParentId]) {
      updatedNodes[oldParentId] = {
        ...updatedNodes[oldParentId],
        childrenIds: updatedNodes[oldParentId].childrenIds.filter((id) => id !== nodeId),
      };
    }

    // Add to new parent
    if (updatedNodes[effectiveParentId]) {
      const currentChildren = [...updatedNodes[effectiveParentId].childrenIds];
      if (targetIndex !== undefined && targetIndex >= 0 && targetIndex <= currentChildren.length) {
        currentChildren.splice(targetIndex, 0, nodeId);
      } else {
        currentChildren.push(nodeId);
      }
      updatedNodes[effectiveParentId] = {
        ...updatedNodes[effectiveParentId],
        childrenIds: currentChildren,
      };
    }

    updatedNodes[nodeId] = {
      ...node,
      parentId: effectiveParentId,
    };

    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      nodes: updatedNodes,
    };

    this.notify('node_reparented', { newParentId: effectiveParentId, targetIndex }, nodeId);
  }

  public toggleNodeVisibility(nodeId: string): void {
    const node = this.activeScene.nodes[nodeId];
    if (!node) return;

    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      nodes: {
        ...this.activeScene.nodes,
        [nodeId]: {
          ...node,
          visible: !node.visible,
        },
      },
    };
    this.notify('node_updated', { visible: !node.visible }, nodeId);
  }

  public toggleNodeLock(nodeId: string): void {
    const node = this.activeScene.nodes[nodeId];
    if (!node) return;

    this.activeScene = {
      ...this.activeScene,
      updatedAt: new Date().toISOString(),
      nodes: {
        ...this.activeScene.nodes,
        [nodeId]: {
          ...node,
          locked: !node.locked,
        },
      },
    };
    this.notify('node_updated', { locked: !node.locked }, nodeId);
  }

  public updateSceneSettings(settings: Partial<SceneData>): void {
    this.activeScene = {
      ...this.activeScene,
      ...settings,
      updatedAt: new Date().toISOString(),
    };
    this.notify('settings_updated', { settings });
  }

  // ── Snapshot Creation ─────────────────────────────────────────────────────

  /**
   * Produces an immutable, serializable snapshot of the current active scene.
   * Modifying this snapshot or entities spawned from it never alters the authoring scene.
   */
  public createSceneSnapshot(): AuthoringSceneSnapshot {
    return createRuntimeSnapshot(this.activeScene);
  }
}

/** Global singleton authoring model for in-memory persistent authority */
export const globalAuthoringModel = new AuthoringModel();
