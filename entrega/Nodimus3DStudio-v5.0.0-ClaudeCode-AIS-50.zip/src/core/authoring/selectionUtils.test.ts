import { describe, it, expect } from 'vitest';
import { pruneNestedSelection, groupTransformTargets } from './selectionUtils';

const nodes: any = {
  r: { parentId: null },
  a: { parentId: 'r' },
  b: { parentId: 'a' },
  c: { parentId: 'r', locked: true },
  d: { parentId: 'r' },
};

describe('selectionUtils', () => {
  it('poda filhos cujo ancestral está selecionado e a raiz', () => {
    expect(pruneNestedSelection(nodes, ['a', 'b', 'd'], 'r')).toEqual(['a', 'd']);
    expect(pruneNestedSelection(nodes, ['r', 'a'], 'r')).toEqual(['a']);
    expect(pruneNestedSelection(nodes, ['b', 'b', 'x'], 'r')).toEqual(['b']);
  });
  it('ignora locked na transformação em grupo', () => {
    expect(groupTransformTargets(nodes, ['a', 'c', 'd'], 'r')).toEqual(['a', 'd']);
  });
});
