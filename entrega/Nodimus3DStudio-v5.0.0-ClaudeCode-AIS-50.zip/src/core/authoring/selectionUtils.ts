import type { GameNode } from '../../types/node';

type NodeMap = Record<string, Pick<GameNode, 'parentId' | 'locked'> | undefined>;

/** True se algum ancestral de `id` está em `set`. */
function hasSelectedAncestor(nodes: NodeMap, id: string, set: ReadonlySet<string>): boolean {
  const seen = new Set<string>();
  let cur = nodes[id]?.parentId;
  while (cur && !seen.has(cur)) {
    if (set.has(cur)) return true;
    seen.add(cur);
    cur = nodes[cur]?.parentId;
  }
  return false;
}

/**
 * Remove da seleção os nós cujo ancestral também está selecionado (o ancestral já
 * leva a subárvore) e a raiz da cena. Preserva a ordem de entrada, sem duplicatas.
 * Usado por exclusão em lote e por transformação em grupo (evita aplicar duas vezes).
 */
export function pruneNestedSelection(
  nodes: NodeMap,
  ids: readonly string[],
  rootNodeId?: string | null
): string[] {
  const set = new Set(ids.filter((id) => id !== rootNodeId));
  const out: string[] = [];
  for (const id of ids) {
    if (out.includes(id)) continue;
    if (!nodes[id] || id === rootNodeId) continue;
    if (hasSelectedAncestor(nodes, id, set)) continue;
    out.push(id);
  }
  return out;
}

/** Alvos de uma transformação em grupo: poda aninhados e ignora nós `locked`. */
export function groupTransformTargets(
  nodes: NodeMap,
  ids: readonly string[],
  rootNodeId?: string | null
): string[] {
  return pruneNestedSelection(nodes, ids, rootNodeId).filter((id) => !nodes[id]?.locked);
}
