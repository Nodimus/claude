import * as THREE from 'three';
import type { GameNode } from '../../types/node';
import type { NodeTransform, TransformMode, Vec3 } from '../commands/SetTransformCommand';

/**
 * AIS-19 — Matemática pura da transformação em grupo (sem cena Three, sem React).
 *
 * Todos os nós selecionados recebem o MESMO delta relativo ao pivô (centro da bounding box
 * composta): translação rígida; rotação e escala em torno do pivô, preservando as posições
 * relativas. O delta é dado em espaço mundial; o resultado volta em espaço local do pai
 * (propriedades `position`/`rotation`(graus, Euler XYZ)/`scale` do GameNode).
 *
 * Escala não uniforme em nó rotado: o delta é aplicado ao longo dos eixos mundiais sobre a
 * posição e como razão sobre a escala do nó (sem cisalhamento) — exato para escala uniforme.
 */

export interface GroupDelta {
  /** Deslocamento mundial (modo translate). */
  translation: THREE.Vector3;
  /** Rotação mundial acumulada em torno do pivô (modo rotate). */
  rotation: THREE.Quaternion;
  /** Razão de escala por eixo mundial em torno do pivô (modo scale). */
  scale: THREE.Vector3;
}

export interface GroupNodeInput {
  /** Matriz mundial inicial do nó. */
  world: THREE.Matrix4;
  /** Matriz mundial inicial do pai (identidade para filho da raiz sem transform). */
  parentWorld: THREE.Matrix4;
}

export const identityDelta = (): GroupDelta => ({
  translation: new THREE.Vector3(),
  rotation: new THREE.Quaternion(),
  scale: new THREE.Vector3(1, 1, 1),
});

const round = (value: number, digits: number) => {
  const r = Number(value.toFixed(digits));
  return Object.is(r, -0) ? 0 : r; // -0 → 0 (precisão da casca: 3 casas; rotação 1 casa em graus)
};

/** Centro da bounding box (AABB) de um conjunto de pontos mundiais. */
export function selectionPivot(points: readonly THREE.Vector3[]): THREE.Vector3 {
  const box = new THREE.Box3();
  for (const p of points) box.expandByPoint(p);
  return box.isEmpty() ? new THREE.Vector3() : box.getCenter(new THREE.Vector3());
}

/** Novo transform LOCAL do nó depois de aplicar o delta de grupo do `mode` em torno de `pivot`. */
export function applyGroupDelta(
  mode: TransformMode,
  pivot: THREE.Vector3,
  delta: GroupDelta,
  node: GroupNodeInput
): NodeTransform {
  const pos = new THREE.Vector3();
  const quat = new THREE.Quaternion();
  const scl = new THREE.Vector3();
  node.world.decompose(pos, quat, scl);

  if (mode === 'translate') {
    pos.add(delta.translation);
  } else if (mode === 'rotate') {
    pos.sub(pivot).applyQuaternion(delta.rotation).add(pivot);
    quat.premultiply(delta.rotation);
  } else {
    pos.sub(pivot).multiply(delta.scale).add(pivot);
    scl.multiply(delta.scale);
  }

  const newWorld = new THREE.Matrix4().compose(pos, quat, scl);
  const local = new THREE.Matrix4().copy(node.parentWorld).invert().multiply(newWorld);
  const lp = new THREE.Vector3();
  const lq = new THREE.Quaternion();
  const ls = new THREE.Vector3();
  local.decompose(lp, lq, ls);
  const euler = new THREE.Euler().setFromQuaternion(lq, 'XYZ');
  const deg = THREE.MathUtils.radToDeg;
  return {
    position: { x: round(lp.x, 3), y: round(lp.y, 3), z: round(lp.z, 3) },
    rotation: { x: round(deg(euler.x), 1), y: round(deg(euler.y), 1), z: round(deg(euler.z), 1) },
    scale: { x: round(ls.x, 3), y: round(ls.y, 3), z: round(ls.z, 3) },
  };
}

// ── Dados autorais → matrizes (Inspector em grupo; sem objetos Three) ─────────────────────────

const v3 = (v: Partial<Vec3> | undefined, fallback: number) =>
  new THREE.Vector3(
    typeof v?.x === 'number' ? v.x : fallback,
    typeof v?.y === 'number' ? v.y : fallback,
    typeof v?.z === 'number' ? v.z : fallback
  );

export function localMatrixOf(properties: Record<string, any>): THREE.Matrix4 {
  const r = v3(properties.rotation, 0);
  const q = new THREE.Quaternion().setFromEuler(
    new THREE.Euler(THREE.MathUtils.degToRad(r.x), THREE.MathUtils.degToRad(r.y), THREE.MathUtils.degToRad(r.z), 'XYZ')
  );
  return new THREE.Matrix4().compose(v3(properties.position, 0), q, v3(properties.scale, 1));
}

type NodeMap = Record<string, Pick<GameNode, 'parentId' | 'properties'> | undefined>;

/** Matriz mundial do nó pelos dados autorais (cadeia de pais). */
export function worldMatrixOf(nodes: NodeMap, id: string): THREE.Matrix4 {
  const chain: string[] = [];
  const seen = new Set<string>();
  for (let cur: string | null | undefined = id; cur && !seen.has(cur) && nodes[cur]; cur = nodes[cur]!.parentId) {
    seen.add(cur);
    chain.push(cur);
  }
  const m = new THREE.Matrix4();
  for (let i = chain.length - 1; i >= 0; i--) m.multiply(localMatrixOf(nodes[chain[i]]!.properties ?? {}));
  return m;
}

export function parentWorldMatrixOf(nodes: NodeMap, id: string): THREE.Matrix4 {
  const parentId = nodes[id]?.parentId;
  return parentId && nodes[parentId] ? worldMatrixOf(nodes, parentId) : new THREE.Matrix4();
}

/**
 * Delta mundial equivalente a uma edição do Inspector no nó primário (valor local antigo → novo):
 * os demais nós recebem esse mesmo delta em torno do pivô.
 */
export function deltaFromInspectorEdit(
  mode: TransformMode,
  oldValue: Vec3,
  newValue: Vec3,
  parentWorld: THREE.Matrix4
): GroupDelta {
  const delta = identityDelta();
  if (mode === 'translate') {
    const a = v3(oldValue, 0).applyMatrix4(parentWorld);
    const b = v3(newValue, 0).applyMatrix4(parentWorld);
    delta.translation.copy(b.sub(a));
  } else if (mode === 'rotate') {
    const q = (v: Vec3) =>
      new THREE.Quaternion().setFromEuler(
        new THREE.Euler(THREE.MathUtils.degToRad(v.x), THREE.MathUtils.degToRad(v.y), THREE.MathUtils.degToRad(v.z), 'XYZ')
      );
    const parentQ = new THREE.Quaternion().setFromRotationMatrix(parentWorld);
    // delta local (novo · antigo⁻¹) conjugado para o espaço mundial
    const local = q(newValue).multiply(q(oldValue).invert());
    delta.rotation.copy(parentQ.clone().multiply(local).multiply(parentQ.clone().invert()));
  } else {
    const ratio = (n: number, o: number) => (o === 0 || !Number.isFinite(n / o) ? 1 : n / o);
    delta.scale.set(ratio(newValue.x, oldValue.x), ratio(newValue.y, oldValue.y), ratio(newValue.z, oldValue.z));
  }
  return delta;
}

export interface GroupTransformPlanItem {
  nodeId: string;
  before: NodeTransform;
  after: NodeTransform;
}

/**
 * Plano completo a partir dos dados autorais: aplica o `delta` a todos os `targetIds`
 * (já podados de aninhados e `locked`) em torno do pivô = centro da AABB das posições mundiais.
 */
export function planGroupTransform(
  nodes: NodeMap,
  targetIds: readonly string[],
  mode: TransformMode,
  delta: GroupDelta,
  pivot?: THREE.Vector3
): GroupTransformPlanItem[] {
  const worlds = targetIds.map((id) => worldMatrixOf(nodes, id));
  const center =
    pivot ?? selectionPivot(worlds.map((w) => new THREE.Vector3().setFromMatrixPosition(w)));
  return targetIds.map((nodeId, i) => {
    const props = nodes[nodeId]?.properties ?? {};
    const before: NodeTransform = {
      position: { x: v3(props.position, 0).x, y: v3(props.position, 0).y, z: v3(props.position, 0).z },
      rotation: { x: v3(props.rotation, 0).x, y: v3(props.rotation, 0).y, z: v3(props.rotation, 0).z },
      scale: { x: v3(props.scale, 1).x, y: v3(props.scale, 1).y, z: v3(props.scale, 1).z },
    };
    const after = applyGroupDelta(mode, center, delta, { world: worlds[i], parentWorld: parentWorldMatrixOf(nodes, nodeId) });
    return { nodeId, before, after };
  });
}
