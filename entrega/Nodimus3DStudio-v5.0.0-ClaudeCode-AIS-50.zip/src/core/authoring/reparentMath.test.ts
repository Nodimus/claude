import { describe, it, expect } from 'vitest';
import * as THREE from 'three';
import { computeLocalForNewParent, getWorldMatrix, isInSubtree, planMove } from './reparentMath';

const mk = (id: string, parentId: string | null, childrenIds: string[], properties: any = {}) =>
  ({ id, name: id, type: 'Spatial', parentId, childrenIds, visible: true, locked: false, properties }) as any;

const scene = () =>
  ({
    rootNodeId: 'r',
    nodes: {
      r: mk('r', null, ['a', 'b', 'c']),
      a: mk('a', 'r', [], {
        position: { x: 5, y: 0, z: 0 },
        rotation: { x: 0, y: 90, z: 0 },
        scale: { x: 2, y: 2, z: 2 },
      }),
      b: mk('b', 'r', ['d'], { position: { x: 1, y: 2, z: 3 } }),
      c: mk('c', 'r', []),
      d: mk('d', 'b', []),
    },
  }) as any;

describe('reparentMath', () => {
  it('mantém a pose mundial ao reparentar', () => {
    const s = scene();
    const before = getWorldMatrix(s, 'a');
    const local = computeLocalForNewParent(s, 'a', 'b');
    s.nodes.a.properties = { ...s.nodes.a.properties, ...local };
    s.nodes.a.parentId = 'b';
    const after = getWorldMatrix(s, 'a');
    before.elements.forEach((v, i) => expect(after.elements[i]).toBeCloseTo(v, 5));
    expect(new THREE.Vector3().setFromMatrixPosition(after).x).toBeCloseTo(5);
  });

  it('detecta ciclo', () => {
    const s = scene();
    expect(isInSubtree(s, 'b', 'd')).toBe(true);
    expect(planMove(s, 'b', 'd')).toBeNull();
    expect(planMove(s, 'b', 'b')).toBeNull();
    expect(planMove(s, 'r', 'a')).toBeNull();
  });

  it('reordena irmãos ajustando o índice', () => {
    const s = scene();
    expect(planMove(s, 'a', 'r', 3)).toEqual({ parentId: 'r', index: 2 });
    expect(planMove(s, 'a', 'r', 1)).toBeNull();
    expect(planMove(s, 'c', 'r', 0)).toEqual({ parentId: 'r', index: 0 });
    expect(planMove(s, 'c', 'b', 0)).toEqual({ parentId: 'b', index: 0 });
  });
});
