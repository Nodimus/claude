import * as THREE from 'three';
import type { SceneData } from '../../types/scene';

export type Vec3 = { x: number; y: number; z: number };
export interface LocalTransform {
  position: Vec3;
  rotation: Vec3; // graus, Euler XYZ (igual ao Viewport3D)
  scale: Vec3;
}

const ZERO: Vec3 = { x: 0, y: 0, z: 0 };
const ONE: Vec3 = { x: 1, y: 1, z: 1 };

export function readLocalTransform(props: Record<string, any> | undefined): LocalTransform {
  return {
    position: { ...ZERO, ...(props?.position ?? {}) },
    rotation: { ...ZERO, ...(props?.rotation ?? {}) },
    scale: { ...ONE, ...(props?.scale ?? {}) },
  };
}

function toMatrix(t: LocalTransform): THREE.Matrix4 {
  const q = new THREE.Quaternion().setFromEuler(
    new THREE.Euler(
      THREE.MathUtils.degToRad(t.rotation.x),
      THREE.MathUtils.degToRad(t.rotation.y),
      THREE.MathUtils.degToRad(t.rotation.z),
      'XYZ'
    )
  );
  return new THREE.Matrix4().compose(
    new THREE.Vector3(t.position.x, t.position.y, t.position.z),
    q,
    new THREE.Vector3(t.scale.x, t.scale.y, t.scale.z)
  );
}

/** Matriz mundial de um nó: composição da cadeia de pais. */
export function getWorldMatrix(scene: SceneData, nodeId: string): THREE.Matrix4 {
  const chain: string[] = [];
  const seen = new Set<string>();
  let cur: string | null | undefined = nodeId;
  while (cur && scene.nodes[cur] && !seen.has(cur)) {
    seen.add(cur);
    chain.unshift(cur);
    cur = scene.nodes[cur].parentId;
  }
  const m = new THREE.Matrix4();
  for (const id of chain) m.multiply(toMatrix(readLocalTransform(scene.nodes[id].properties)));
  return m;
}

/** True se `maybeDescendantId` está na subárvore de `ancestorId` (inclui o próprio nó). */
export function isInSubtree(scene: SceneData, ancestorId: string, maybeDescendantId: string | null): boolean {
  const seen = new Set<string>();
  let cur: string | null | undefined = maybeDescendantId;
  while (cur && !seen.has(cur)) {
    if (cur === ancestorId) return true;
    seen.add(cur);
    cur = scene.nodes[cur]?.parentId;
  }
  return false;
}

/** Transform local que o nó deve ter sob `newParentId` para manter a pose mundial atual. */
export function computeLocalForNewParent(
  scene: SceneData,
  nodeId: string,
  newParentId: string
): LocalTransform {
  const world = getWorldMatrix(scene, nodeId);
  const parentInv = getWorldMatrix(scene, newParentId).invert();
  const local = parentInv.multiply(world);
  const p = new THREE.Vector3();
  const q = new THREE.Quaternion();
  const s = new THREE.Vector3();
  local.decompose(p, q, s);
  const e = new THREE.Euler().setFromQuaternion(q, 'XYZ');
  const clean = (n: number) => (Math.abs(n) < 1e-9 ? 0 : n);
  return {
    position: { x: clean(p.x), y: clean(p.y), z: clean(p.z) },
    rotation: {
      x: clean(THREE.MathUtils.radToDeg(e.x)),
      y: clean(THREE.MathUtils.radToDeg(e.y)),
      z: clean(THREE.MathUtils.radToDeg(e.z)),
    },
    scale: { x: clean(s.x), y: clean(s.y), z: clean(s.z) },
  };
}

/**
 * Valida e normaliza um drop. `index` é a posição final desejada entre os irmãos do
 * novo pai, calculada com o nó ainda no pai antigo; devolve o índice já ajustado
 * para após a remoção. `null` = movimento inválido (ciclo, raiz, no-op).
 */
export function planMove(
  scene: SceneData,
  nodeId: string,
  newParentId: string,
  index?: number
): { parentId: string; index?: number } | null {
  const node = scene.nodes[nodeId];
  const parent = scene.nodes[newParentId];
  if (!node || !parent) return null;
  if (nodeId === scene.rootNodeId) return null;
  if (isInSubtree(scene, nodeId, newParentId)) return null;
  if (index === undefined) {
    // soltar "dentro": no-op se já é o último filho do mesmo pai
    if (node.parentId === newParentId && parent.childrenIds[parent.childrenIds.length - 1] === nodeId) return null;
    return { parentId: newParentId };
  }
  let adj = index;
  if (node.parentId === newParentId) {
    const old = parent.childrenIds.indexOf(nodeId);
    if (old >= 0 && old < index) adj = index - 1;
    if (adj === old) return null;
  }
  return { parentId: newParentId, index: adj };
}
