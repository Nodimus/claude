import { beforeEach, describe, expect, it } from 'vitest';
import { ProjectStorage } from './projectStorage';
import { CANONICAL_RES_DIRS, createNewProject } from './defaultProject';
import { PROJECT_TEMPLATES, getProjectTemplate } from './projectTemplates';
import { importProjectFromFolder, type FolderBridge } from './projectFolder';
import {
  PROJECT_NAME_MAX,
  applyProjectName,
  canDeleteProject,
  deleteConfirmationMatches,
  deleteStoredProject,
  duplicateProject,
  duplicateStoredProject,
  renameStoredProject,
  sortProjectsByRecent,
  uniqueCopyName,
  validateProjectName,
} from './projectOps';

const list = (...names: string[]) => names.map((name, i) => ({ id: `p${i}`, name, location: '~', renderer: 'x', updatedAt: '2026-01-01T00:00:00.000Z' }));

function seed(name: string): string {
  const p = createNewProject(name, '~/Projects/' + name, '3d');
  ProjectStorage.saveProject(p);
  return p.id;
}

beforeEach(() => {
  ProjectStorage.saveProjectsList([]);
});

describe('validateProjectName / uniqueCopyName', () => {
  it('rejeita vazio, longo demais e duplicado; aceita o próprio nome', () => {
    const l = list('Alfa', 'Beta');
    expect(validateProjectName('   ', l)).toMatch(/vazio/);
    expect(validateProjectName('x'.repeat(PROJECT_NAME_MAX + 1), l)).toMatch(/máximo/);
    expect(validateProjectName('beta', l)).toMatch(/Já existe/);
    expect(validateProjectName('Beta', l, 'p1')).toBeNull();
    expect(validateProjectName('x'.repeat(PROJECT_NAME_MAX), l)).toBeNull();
  });
  it('nome de cópia incrementa', () => {
    expect(uniqueCopyName('A', ['A'])).toBe('A (cópia)');
    expect(uniqueCopyName('A', ['A', 'A (cópia)'])).toBe('A (cópia 2)');
    expect(uniqueCopyName('A', ['A', 'A (cópia)', 'A (cópia 2)'])).toBe('A (cópia 3)');
  });
});

describe('renomear (AIS-32-C05)', () => {
  it('atualiza name, general.projectName, lista e res://project.json', () => {
    const id = seed('Original');
    const r = renameStoredProject(id, '  Novo Nome ');
    expect(r.ok).toBe(true);
    const stored = ProjectStorage.loadProject(id)!;
    expect(stored.name).toBe('Novo Nome');
    expect(stored.settings.general.projectName).toBe('Novo Nome');
    expect(JSON.parse(stored.files['res://project.json'].content!).name).toBe('Novo Nome');
    expect(ProjectStorage.getProjectsList().find((p) => p.id === id)?.name).toBe('Novo Nome');
  });
  it('não move nada: arquivos, id e location ficam iguais', () => {
    const id = seed('A');
    const before = ProjectStorage.loadProject(id)!;
    renameStoredProject(id, 'B');
    const after = ProjectStorage.loadProject(id)!;
    expect(after.id).toBe(before.id);
    expect(after.location).toBe(before.location);
    expect(Object.keys(after.files).sort()).toEqual(Object.keys(before.files).sort());
  });
  it('rejeita vazio e duplicado sem alterar nada', () => {
    const a = seed('A');
    seed('B');
    expect(renameStoredProject(a, '')).toMatchObject({ ok: false });
    expect(renameStoredProject(a, 'b')).toMatchObject({ ok: false });
    expect(ProjectStorage.loadProject(a)!.name).toBe('A');
  });
  it('applyProjectName é pura', () => {
    const p = createNewProject('X', '~', 'empty');
    const q = applyProjectName(p, 'Y');
    expect(p.name).toBe('X');
    expect(q.settings.general.projectName).toBe('Y');
    expect(p.settings.general.projectName).toBe('X');
  });
});

describe('duplicar (AIS-32-C06)', () => {
  it('novo id, nome único, cópia profunda, topo da lista; original intacto', () => {
    const id = seed('Jogo');
    const original = ProjectStorage.loadProject(id)!;
    const r = duplicateStoredProject(id);
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    const copy = r.value;
    expect(copy.id).not.toBe(id);
    expect(copy.name).toBe('Jogo (cópia)');
    expect(copy.settings.general.projectName).toBe('Jogo (cópia)');
    expect(ProjectStorage.getProjectsList()[0].id).toBe(copy.id);

    // editar a cópia não altera o original
    const stored = ProjectStorage.loadProject(copy.id)!;
    stored.files['res://scripts/novo.ts'] = { path: 'res://scripts/novo.ts', name: 'novo.ts', isDirectory: false, content: 'x', updatedAt: '' };
    ProjectStorage.saveProject(stored);
    expect(ProjectStorage.loadProject(id)!.files['res://scripts/novo.ts']).toBeUndefined();
    expect(ProjectStorage.loadProject(id)!.name).toBe(original.name);
  });
  it('não compartilha referências em memória e aceita location editada', () => {
    const src = createNewProject('S', '~/a', '3d');
    const copy = duplicateProject(src, list('S'), { location: ' ~/b ' });
    expect(copy.location).toBe('~/b');
    expect(copy.files).not.toBe(src.files);
    const anyPath = Object.keys(src.files).find((p) => !src.files[p].isDirectory)!;
    expect(copy.files[anyPath]).not.toBe(src.files[anyPath]);
    expect(copy.settings).not.toBe(src.settings);
  });
  it('segunda cópia incrementa o nome', () => {
    const id = seed('Jogo');
    duplicateStoredProject(id);
    const r2 = duplicateStoredProject(id);
    expect(r2.ok && r2.value.name).toBe('Jogo (cópia 2)');
  });
  it('nome informado duplicado é recusado', () => {
    const id = seed('Jogo');
    expect(duplicateStoredProject(id, { name: 'jogo' })).toMatchObject({ ok: false });
  });
});

describe('excluir (AIS-32-C07/C08)', () => {
  it('confirmação exige o nome exato (com trim)', () => {
    expect(deleteConfirmationMatches('  Jogo ', 'Jogo')).toBe(true);
    expect(deleteConfirmationMatches('jogo', 'Jogo')).toBe(false);
    expect(deleteConfirmationMatches('', 'Jogo')).toBe(false);
  });
  it('o projeto aberto não pode ser excluído', () => {
    expect(canDeleteProject('a', 'a')).toMatchObject({ ok: false });
    expect(canDeleteProject('b', 'a')).toEqual({ ok: true });
    const id = seed('Aberto');
    expect(deleteStoredProject(id, id)).toMatchObject({ ok: false });
    expect(ProjectStorage.loadProject(id)).not.toBeNull();
  });
  it('excluir um de três não afeta os outros', () => {
    const a = seed('A');
    const b = seed('B');
    const c = seed('C');
    expect(deleteStoredProject(b, a)).toMatchObject({ ok: true });
    expect(ProjectStorage.loadProject(b)).toBeNull();
    expect(ProjectStorage.loadProject(a)?.name).toBe('A');
    expect(ProjectStorage.loadProject(c)?.name).toBe('C');
    expect(ProjectStorage.getProjectsList().map((p) => p.id).sort()).toEqual([a, c].sort());
  });
});

describe('exportar → importar (AIS-32-C09/C10)', () => {
  it('o ciclo reabre o projeto com novo id e o mesmo conteúdo', () => {
    const id = seed('Ciclo');
    const src = ProjectStorage.loadProject(id)!;
    const json = ProjectStorage.exportProjectAsNodimus(src);
    const imported = ProjectStorage.importProjectFromNodimus(json);
    expect(imported.id).not.toBe(id);
    expect(imported.name).toBe('Ciclo');
    expect(Object.keys(imported.files).sort()).toEqual(Object.keys(src.files).sort());
    expect(ProjectStorage.loadProject(imported.id)).not.toBeNull();
  });
  it('JSON quebrado, objeto sem estrutura e projeto inválido não criam projeto', () => {
    const before = ProjectStorage.getProjectsList().length;
    expect(() => ProjectStorage.importProjectFromNodimus('{ quebrado')).toThrow();
    expect(() => ProjectStorage.importProjectFromNodimus('{"x":1}')).toThrow();
    expect(() => ProjectStorage.importProjectFromNodimus('{"files":{"a":1},"name":42}')).toThrow();
    expect(ProjectStorage.getProjectsList().length).toBe(before);
  });
});

describe('templates (AIS-32-C12)', () => {
  it('3d e empty clonam; os 3 exemplos estão desabilitados com motivo e não constroem nada', () => {
    expect(getProjectTemplate('3d')!.available).toBe(true);
    expect(getProjectTemplate('empty')!.available).toBe(true);
    const p = getProjectTemplate('empty')!.build('E', '~/e');
    expect(p.name).toBe('E');
    for (const id of ['fps-starter', 'third-person-platformer', 'top-down-rpg']) {
      const t = getProjectTemplate(id)!;
      expect(t.available).toBe(false);
      expect(t.unavailableReason).toMatch(/em breve/);
      expect(() => t.build('x', 'y')).toThrow();
    }
    expect(PROJECT_TEMPLATES.map((t) => t.id)).toHaveLength(5);
  });
});

describe('projeto novo (AIS-32-C13)', () => {
  it('inclui todas as pastas da lista canônica', () => {
    for (const template of ['3d', 'empty'] as const) {
      const p = createNewProject('N', '~', template);
      for (const dir of CANONICAL_RES_DIRS) expect(p.files[dir]?.isDirectory).toBe(true);
    }
  });
});

describe('lista ordenada (AIS-32-C02)', () => {
  it('mais recente primeiro', () => {
    const l = [{ updatedAt: '2026-01-01T00:00:00Z' }, { updatedAt: '2026-03-01T00:00:00Z' }, { updatedAt: '2026-02-01T00:00:00Z' }];
    expect(sortProjectsByRecent(l).map((x) => x.updatedAt.slice(5, 7))).toEqual(['03', '02', '01']);
  });
});

describe('Abrir Pasta (AIS-32-C11) com bridge mockado', () => {
  const projectJson = (name = 'Da Pasta') => {
    const p = createNewProject(name, '~', 'empty');
    return JSON.stringify(ProjectStorage.toProjectFile(p));
  };
  const fakeBridge = (tree: Record<string, string | Uint8Array>, native = true): FolderBridge => ({
    getCapabilities: () => ({ hasNativeFS: native }),
    readTextFile: async (p) => {
      const v = tree[p];
      if (typeof v !== 'string') throw new Error('não encontrado');
      return v;
    },
    readBinaryFile: async (p) => {
      const v = tree[p];
      if (!(v instanceof Uint8Array)) throw new Error('não encontrado');
      return v;
    },
    listDirectory: async (p) => {
      const prefix = p.replace(/\/$/, '') + '/';
      const names = new Map<string, boolean>();
      for (const k of Object.keys(tree)) {
        if (!k.startsWith(prefix)) continue;
        const rest = k.slice(prefix.length);
        const first = rest.split('/')[0];
        names.set(first, rest.includes('/'));
      }
      return [...names].map(([name, isDirectory]) => ({ name, isDirectory, isFile: !isDirectory }));
    },
  });

  it('importa uma pasta com project.json válido como projeto novo', async () => {
    const tree = {
      'C:/Proj/project.json': projectJson(),
      'C:/Proj/scenes/Main.scene.json': '{"x":1}',
      'C:/Proj/scripts/a.ts': 'export {}',
      'C:/Proj/textures/t.png': new Uint8Array([1, 2, 3]),
      'C:/Proj/models/m.bin': new Uint8Array([9]),
      'C:/Proj/.git/config': 'x',
    };
    const r = await importProjectFromFolder('C:/Proj', fakeBridge(tree));
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.project.name).toBe('Da Pasta');
    expect(r.project.location).toBe('C:/Proj');
    expect(r.project.files['res://scripts/a.ts'].content).toBe('export {}');
    expect(r.project.files['res://textures/t.png'].content).toMatch(/^data:image\/png;base64,/);
    expect(r.project.files['res://scenes/Main.scene.json']).toBeDefined();
    expect(r.skipped).toEqual(['models/m.bin']);
    expect(Object.keys(r.project.files).some((p) => p.includes('.git'))).toBe(false);
    for (const dir of CANONICAL_RES_DIRS) expect(r.project.files[dir]).toBeDefined();
  });
  it('rejeita pasta sem project.json ou com project.json inválido', async () => {
    const none = await importProjectFromFolder('C:/Vazia', fakeBridge({ 'C:/Vazia/a.txt': 'x' }));
    expect(none).toMatchObject({ ok: false });
    const bad = await importProjectFromFolder('C:/Ruim', fakeBridge({ 'C:/Ruim/project.json': '{"foo":1}' }));
    expect(bad).toMatchObject({ ok: false });
    const broken = await importProjectFromFolder('C:/Q', fakeBridge({ 'C:/Q/project.json': '{ quebrado' }));
    expect(broken).toMatchObject({ ok: false });
  });
  it('sem FS nativo (web) recusa', async () => {
    expect(await importProjectFromFolder('C:/P', fakeBridge({}, false))).toMatchObject({ ok: false });
  });
});
