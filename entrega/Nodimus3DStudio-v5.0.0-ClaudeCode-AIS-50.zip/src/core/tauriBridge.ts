/**
 * Tauri Bridge & Platform Abstraction Layer
 * Única porta de disco e diálogos do editor. Tauri v2 via `@tauri-apps/plugin-fs` e `plugin-dialog`
 * (import dinâmico, só dentro do Tauri); no modo web os diálogos usam o fallback do navegador e o FS
 * nativo lança `NativeFsUnavailableError` (decisão 14: sem simulação silenciosa).
 */

export interface PlatformCapabilities {
  isTauri: boolean;
  isDesktopOnly: boolean;
  isMobile: boolean;
  hasNativeFS: boolean;
  hasNativeDialog: boolean;
}

/** Operação de disco pedida fora do Tauri: o modo web não tem pasta de projeto real. */
export class NativeFsUnavailableError extends Error {
  constructor(operation: string) {
    super(`${operation}: o sistema de arquivos nativo só existe no app desktop (Tauri).`);
    this.name = 'NativeFsUnavailableError';
  }
}

export interface DirectoryEntry {
  name: string;
  isDirectory: boolean;
  isFile: boolean;
}

/** Junta segmentos de caminho com "/" sem duplicar separadores (aceita "\" do Windows). */
export function joinPath(...segments: string[]): string {
  const parts = segments.filter(Boolean).map((seg, i) => {
    const norm = seg.replace(/\\/g, '/');
    return i === 0 ? norm.replace(/\/+$/, '') : norm.replace(/^\/+|\/+$/g, '');
  });
  return parts.join('/');
}

/** Nome do arquivo temporário da escrita atômica (grava o temporário, depois renomeia). */
export function atomicTempPath(path: string): string {
  return `${path}.nodimus-tmp`;
}

export class TauriBridge {
  /**
   * Check if running inside Tauri runtime (v2 expõe `__TAURI_INTERNALS__`).
   */
  public static isTauriEnvironment(): boolean {
    return typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;
  }

  /**
   * Detect platform capabilities.
   * As determined in Quiz Item 2 (Decisão: Opção C), Nodimus 3D Studio is strictly a Desktop Editor.
   */
  public static getCapabilities(): PlatformCapabilities {
    const isTauri = this.isTauriEnvironment();

    return {
      isTauri,
      isDesktopOnly: true,
      isMobile: false,
      hasNativeFS: isTauri,
      hasNativeDialog: isTauri,
    };
  }

  private static async fs() {
    if (!this.isTauriEnvironment()) throw new NativeFsUnavailableError('fs');
    return import('@tauri-apps/plugin-fs');
  }

  /** Lê um arquivo de texto do disco. */
  public static async readTextFile(path: string): Promise<string> {
    return (await this.fs()).readTextFile(path);
  }

  /** Lê um arquivo binário do disco. */
  public static async readBinaryFile(path: string): Promise<Uint8Array> {
    return (await this.fs()).readFile(path);
  }

  /** Escrita atômica: grava em arquivo temporário e renomeia; nunca deixa o destino pela metade. */
  public static async writeTextFile(path: string, content: string): Promise<void> {
    const fs = await this.fs();
    const tmp = atomicTempPath(path);
    try {
      await fs.writeTextFile(tmp, content);
      await fs.rename(tmp, path);
    } catch (err) {
      await fs.remove(tmp).catch(() => undefined);
      throw err;
    }
  }

  /** Escrita atômica de binário. */
  public static async writeBinaryFile(path: string, data: Uint8Array): Promise<void> {
    const fs = await this.fs();
    const tmp = atomicTempPath(path);
    try {
      await fs.writeFile(tmp, data);
      await fs.rename(tmp, path);
    } catch (err) {
      await fs.remove(tmp).catch(() => undefined);
      throw err;
    }
  }

  public static async exists(path: string): Promise<boolean> {
    return (await this.fs()).exists(path);
  }

  public static async listDirectory(path: string): Promise<DirectoryEntry[]> {
    const entries = await (await this.fs()).readDir(path);
    return entries.map((e) => ({ name: e.name, isDirectory: e.isDirectory, isFile: e.isFile }));
  }

  public static async createDirectory(path: string): Promise<void> {
    await (await this.fs()).mkdir(path, { recursive: true });
  }

  /** Uso restrito ao serviço `deleteResource` (AIS-29e); a UI nunca chama direto. */
  public static async deleteFile(path: string): Promise<void> {
    await (await this.fs()).remove(path, { recursive: true });
  }

  /** Uso restrito ao serviço `moveResource` (AIS-29e); a UI nunca chama direto. */
  public static async moveFile(from: string, to: string): Promise<void> {
    await (await this.fs()).rename(from, to);
  }

  /** "Abrir Pasta de Projeto": caminho escolhido, ou `null` se cancelado ou fora do Tauri. */
  public static async openProjectFolderDialog(): Promise<string | null> {
    if (!this.isTauriEnvironment()) return null;
    const { open } = await import('@tauri-apps/plugin-dialog');
    const selected = await open({ directory: true, multiple: false, title: 'Abrir Pasta de Projeto' });
    return typeof selected === 'string' ? selected : null;
  }

  /** "Exportar Projeto": salva em arquivo `.nodimus` pelo diálogo nativo (download no web). */
  public static async exportProjectDialog(fileName: string, content: string): Promise<void> {
    await this.saveFile(fileName, content, 'application/json', [{ name: 'Nodimus', extensions: ['nodimus'] }]);
  }

  /**
   * Native or Browser File Dialog Picker
   */
  public static async openFileDialog(options?: {
    multiple?: boolean;
    extensions?: string[];
    /** AIS-33: devolve os BYTES (ArrayBuffer) também no fallback web (modelos 3D); o padrão do fallback é texto. */
    binary?: boolean;
  }): Promise<{ name: string; path?: string; data: string | ArrayBuffer }[]> {
    if (this.isTauriEnvironment()) {
      try {
        const { open } = await import('@tauri-apps/plugin-dialog');
        const { readFile } = await import('@tauri-apps/plugin-fs');
        const selected = await open({
          multiple: options?.multiple ?? false,
          filters: options?.extensions ? [{ name: 'Assets', extensions: options.extensions }] : undefined,
        });

        if (!selected) return [];

        const paths = Array.isArray(selected) ? selected : [selected];
        const results = [];
        for (const p of paths) {
          const fileName = p.split(/[/\\]/).pop() || 'asset';
          const binary = await readFile(p);
          results.push({
            name: fileName,
            path: p,
            data: binary.buffer.slice(binary.byteOffset, binary.byteOffset + binary.byteLength) as ArrayBuffer,
          });
        }
        return results;
      } catch (err) {
        console.warn('Tauri native dialog failed, falling back to browser input:', err);
      }
    }

    // Web Fallback using HTMLInputElement
    return new Promise((resolve) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.multiple = options?.multiple ?? false;
      if (options?.extensions && options.extensions.length > 0) {
        input.accept = options.extensions.map((ext) => (ext.startsWith('.') ? ext : `.${ext}`)).join(',');
      }

      input.onchange = async () => {
        const files = input.files;
        if (!files || files.length === 0) {
          resolve([]);
          return;
        }

        const out = [];
        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          out.push({
            name: file.name,
            data: options?.binary ? await file.arrayBuffer() : await file.text(),
          });
        }
        resolve(out);
      };

      input.click();
    });
  }

  /**
   * Save content safely with native Tauri or browser download fallback
   */
  public static async saveFile(
    fileName: string,
    content: string,
    mimeType = 'application/json',
    filters?: { name: string; extensions: string[] }[],
  ): Promise<void> {
    if (this.isTauriEnvironment()) {
      try {
        const { save } = await import('@tauri-apps/plugin-dialog');
        const targetPath = await save({ defaultPath: fileName, filters });
        if (targetPath) await this.writeTextFile(targetPath, content);
        return; // cancelado no diálogo nativo: não cai no download
      } catch (err) {
        console.warn('Tauri native save failed, using browser download:', err);
      }
    }

    // Browser fallback
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  /**
   * Checks if a path is an absolute OS path (Windows drive, UNC or Unix root)
   */
  public static isAbsolutePath(path: string): boolean {
    if (!path || typeof path !== 'string') return false;
    const trimmed = path.trim();
    if (/^[a-zA-Z]:[/\\]/.test(trimmed)) return true;
    if (/^\\\\[^\\]/.test(trimmed) || /^\/\/[^/]/.test(trimmed)) return true;
    if (trimmed.startsWith('/') && !trimmed.startsWith('//') && !trimmed.includes('://')) return true;
    return false;
  }

  /**
   * Normalizes an asset or scene path to project-relative format (e.g. "res://...").
   * Rejects/cleans operating system absolute paths.
   */
  public static normalizeProjectPath(path: string, defaultFolder = 'res'): string {
    if (!path) return '';
    const trimmed = path.trim().replace(/\\/g, '/');

    if (trimmed.startsWith('res://')) return trimmed;

    if (this.isAbsolutePath(trimmed)) {
      const resIdx = trimmed.indexOf('/res/');
      if (resIdx !== -1) {
        return 'res://' + trimmed.slice(resIdx + 5);
      }
      const filename = trimmed.split('/').pop() || 'asset';
      return `res://${defaultFolder}/${filename}`;
    }

    if (trimmed.startsWith('./')) {
      return `res://${trimmed.slice(2)}`;
    }
    if (!trimmed.startsWith('res://')) {
      return `res://${trimmed}`;
    }
    return trimmed;
  }
}
