/**
 * AIS-32 — registry de templates do "Novo Projeto" / "Clonar Exemplo". `3d` e `empty` já existiam (`createNewProject`);
 * os três exemplos do original ficam LISTADOS E DESABILITADOS (decisão 14): não existem cenas fictícias com nós
 * que o editor ainda não tem. Cada um vira `available: true` no prompt que entregar o que ele precisa.
 */
import type { ProjectData } from '../types/project';
import { createNewProject } from './defaultProject';

export interface ProjectTemplate {
  id: string;
  label: string;
  description: string;
  available: boolean;
  unavailableReason?: string;
  /** Prompts que precisam ficar prontos para o template existir (registrado também no log do AIS-32). */
  dependsOn?: string[];
  build: (name: string, location: string) => ProjectData;
}

const COMING_SOON =
  'em breve — depende de controle de personagem (InputManager, AIS-40b), física (AIS-45) e behaviors/actions (AIS-41) ainda não implementados';

const unavailable = (id: string): ProjectTemplate['build'] => () => {
  throw new Error(`O template '${id}' ainda não está disponível.`);
};

export const PROJECT_TEMPLATES: readonly ProjectTemplate[] = [
  {
    id: '3d',
    label: '3D Scene + 2D Overlay',
    description: 'Three.js World, Billboards, 2D Overlays',
    available: true,
    build: (name, location) => createNewProject(name, location, '3d'),
  },
  {
    id: 'empty',
    label: 'Empty Scene',
    description: 'Blank Spatial Root',
    available: true,
    build: (name, location) => createNewProject(name, location, 'empty'),
  },
  {
    id: 'fps-starter',
    label: 'FPS Starter',
    description: 'Primeira pessoa com movimento e tiro',
    available: false,
    unavailableReason: COMING_SOON,
    dependsOn: ['AIS-40b', 'AIS-41', 'AIS-45'],
    build: unavailable('fps-starter'),
  },
  {
    id: 'third-person-platformer',
    label: 'Third-Person Platformer',
    description: 'Plataforma em terceira pessoa com câmera de seguimento',
    available: false,
    unavailableReason: COMING_SOON,
    dependsOn: ['AIS-40b', 'AIS-41', 'AIS-45'],
    build: unavailable('third-person-platformer'),
  },
  {
    id: 'top-down-rpg',
    label: 'Top-Down RPG',
    description: 'RPG visto de cima com movimento no plano',
    available: false,
    unavailableReason: COMING_SOON,
    dependsOn: ['AIS-40b', 'AIS-41', 'AIS-45'],
    build: unavailable('top-down-rpg'),
  },
];

export function getProjectTemplate(id: string): ProjectTemplate | undefined {
  return PROJECT_TEMPLATES.find((t) => t.id === id);
}
