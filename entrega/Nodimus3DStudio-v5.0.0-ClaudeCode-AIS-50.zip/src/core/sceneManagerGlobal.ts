import { globalAuthoringModel } from './authoring';
import { ProjectStorage } from './projectStorage';
import { getSceneDocument } from './documents/sceneDocument';
import { applyActiveSceneEffects } from './resourceOpsGlobal';
import { serializeSceneToJson } from './serialization/sceneSerializer';
import type { ProjectData } from '../types/project';
import { duplicateScene, renameScene, setInitialScene, type AddSceneResult } from './sceneManager';

/**
 * AIS-29f — ligação do CRUD de cenas ao editor: aplica o resultado das funções puras ao projeto (um commit) e cuida da
 * cena aberta. A exclusão do arquivo da cena NÃO mora aqui: passa por `deleteResource` (AIS-29e).
 */

/** UM commit: atualiza o modelo autoral e grava o projeto (o `project.json` é derivado e regravado junto). */
export function commitProject(next: ProjectData): void {
  globalAuthoringModel.setProject(next);
  ProjectStorage.saveProject(next);
}

/** Cópia independente de uma cena. Se for a cena aberta, copia o estado em memória (inclusive alterações não salvas). */
export function duplicateSceneNow(path: string): AddSceneResult | { error: string } {
  const project = globalAuthoringModel.getProject();
  const active = globalAuthoringModel.getScene();
  const memory = active.path === path ? serializeSceneToJson(active) : undefined;
  const result = duplicateScene(project, path, memory);
  if ('error' in result) return result;
  commitProject(result.project);
  return result;
}

/** Renomeia (nome + caminho; `sceneId` preservado). A cena aberta só pode ser renomeada sem alterações pendentes. */
export function renameSceneNow(path: string, newName: string): { ok: true; to: string } | { ok: false; error: string } {
  const project = globalAuthoringModel.getProject();
  const active = globalAuthoringModel.getScene();
  const isActive = active.path === path;
  if (isActive && getSceneDocument()?.dirty) {
    return { ok: false, error: 'A cena aberta tem alterações não salvas: salve antes de renomeá-la.' };
  }
  const result = renameScene(project, path, newName);
  if (!result.ok) return result;
  commitProject(result.project);
  if (isActive) applyActiveSceneEffects({ deferred: [], activeSceneMovedTo: result.to });
  return { ok: true, to: result.to };
}

export function setInitialSceneNow(path: string): { ok: true } | { ok: false; error: string } {
  const result = setInitialScene(globalAuthoringModel.getProject(), path);
  if (!result.ok) return result;
  commitProject(result.project);
  return { ok: true };
}
