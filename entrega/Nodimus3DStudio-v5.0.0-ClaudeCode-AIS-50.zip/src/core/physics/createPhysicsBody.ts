import type { RapierModule } from './rapierInit';
import type { PhysicsBodyDescriptor } from './physicsDescriptor';

/**
 * AIS-45 — camada C ("Aplicação") do núcleo físico: a ÚNICA factory de corpo/collider. Recebe o descritor já resolvido
 * (`resolvePhysicsDescriptor`) e cria o `RigidBody` + `Collider` no mundo. Nenhuma outra camada decide forma/argumento de collider.
 *
 *  - `character` NUNCA é `dynamic`: `kinematicPositionBased` + `KinematicCharacterController` (a ponte move o corpo).
 *  - `kinematic` e `trigger` = `kinematicPositionBased` (o trigger com `sensor:true`, sem resposta sólida).
 *  - `static` = `fixed`; `dynamic` = `dynamic` (posição e rotação resolvidas pela simulação).
 */

export interface CreatedBody {
  body: import('@dimforge/rapier3d-compat').RigidBody;
  collider: import('@dimforge/rapier3d-compat').Collider;
  /** Só em `character`. */
  controller: import('@dimforge/rapier3d-compat').KinematicCharacterController | null;
}

/** Folga do controlador de personagem (distância mantida das paredes). */
export const CHARACTER_OFFSET = 0.01;

/** Transpõe `rows × cols` (linha = Z, coluna = X; índice `row * cols + col`) para a ordem de colunas que o Rapier espera. */
export function heightsColumnMajor(heights: Float32Array, rows: number, cols: number): Float32Array {
  const out = new Float32Array(heights.length);
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) out[c * rows + r] = heights[r * cols + c];
  return out;
}

function colliderDescFor(R: RapierModule, d: PhysicsBodyDescriptor): import('@dimforge/rapier3d-compat').ColliderDesc {
  const { x, y, z } = d.collider.size;
  switch (d.collider.kind) {
    case 'sphere':
      return R.ColliderDesc.ball(x / 2);
    case 'capsule':
      return R.ColliderDesc.capsule(Math.max(0.001, (y - x) / 2), x / 2);
    case 'cylinder':
      return R.ColliderDesc.cylinder(y / 2, x / 2);
    case 'mesh':
      return R.ColliderDesc.trimesh(d.trimesh!.vertices, d.trimesh!.indices) as import('@dimforge/rapier3d-compat').ColliderDesc;
    case 'heightfield': {
      const hf = d.heightfield!;
      return R.ColliderDesc.heightfield(hf.rows - 1, hf.cols - 1, heightsColumnMajor(hf.heights, hf.rows, hf.cols), { x: hf.scale.x, y: hf.scale.y, z: hf.scale.z });
    }
    default:
      return R.ColliderDesc.cuboid(x / 2, y / 2, z / 2);
  }
}

export function createPhysicsBody(R: RapierModule, world: import('@dimforge/rapier3d-compat').World, d: PhysicsBodyDescriptor): CreatedBody {
  const bodyDesc =
    d.bodyMode === 'dynamic'
      ? R.RigidBodyDesc.dynamic()
      : d.bodyMode === 'static'
        ? R.RigidBodyDesc.fixed()
        : R.RigidBodyDesc.kinematicPositionBased(); // kinematic, trigger e character
  bodyDesc.setTranslation(d.position.x, d.position.y, d.position.z).setRotation(d.rotation);
  if (d.bodyMode === 'dynamic') {
    bodyDesc.enabledTranslations(!d.lockTranslations.x, !d.lockTranslations.y, !d.lockTranslations.z);
    bodyDesc.enabledRotations(!d.lockRotations.x, !d.lockRotations.y, !d.lockRotations.z);
    if (d.linearDamping !== undefined) bodyDesc.setLinearDamping(d.linearDamping);
  }
  const body = world.createRigidBody(bodyDesc);

  const desc = colliderDescFor(R, d);
  if (d.collider.kind !== 'heightfield' && d.collider.kind !== 'mesh') desc.setTranslation(d.collider.offset.x, d.collider.offset.y, d.collider.offset.z);
  desc.setFriction(d.friction).setRestitution(d.bounce);
  if (d.mass !== undefined) desc.setMass(d.mass);
  if (d.bodyMode === 'trigger') desc.setSensor(true);
  desc.setCollisionGroups(d.groups);
  // eventos de contato/trigger e de força de contato (a ponte os expõe pelo `onPhysicsEvent`)
  desc.setActiveEvents(R.ActiveEvents.COLLISION_EVENTS | R.ActiveEvents.CONTACT_FORCE_EVENTS);
  desc.setContactForceEventThreshold(0);
  const collider = world.createCollider(desc, body);

  const controller = d.bodyMode === 'character' ? world.createCharacterController(CHARACTER_OFFSET) : null;
  controller?.setUp({ x: 0, y: 1, z: 0 });
  controller?.enableAutostep(0.3, 0.1, false);
  controller?.enableSnapToGround(0.2);
  return { body, collider, controller };
}
