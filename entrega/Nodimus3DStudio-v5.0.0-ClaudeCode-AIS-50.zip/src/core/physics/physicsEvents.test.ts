import { beforeAll, describe, expect, it } from 'vitest';
import type { PhysicsConfig } from '../../types/node';
import { PhysicsBridge, type PhysicsEvent } from './PhysicsBridge';
import { resolvePhysicsDescriptor, type PhysicsBodyDescriptor } from './physicsDescriptor';
import { ensureRapier, type RapierModule } from './rapierInit';

/**
 * AIS-48 — harness Rapier HEADLESS dos EVENTOS físicos: Enter/Exit (nunca Stay), payload de colisão (ponto, normal, força) e de gatilho
 * (sem força), `force` acima/abaixo de um limiar e `onPhysicsEvent → unsubscribe`.
 */

let R: RapierModule;
beforeAll(async () => {
  R = await ensureRapier();
});

const Q0 = { x: 0, y: 0, z: 0, w: 1 };
const box = (x = 1, y = 1, z = 1) => ({ size: { x, y, z }, center: { x: 0, y: 0, z: 0 } });

function body(id: string, physics: Partial<PhysicsConfig>, at: { x: number; y: number; z: number }, bounds = box()): PhysicsBodyDescriptor {
  const r = resolvePhysicsDescriptor({
    nodeId: id,
    name: id,
    nodeType: 'MeshInstance',
    properties: { meshType: 'CubeMesh', physics: { enabled: true, bodyMode: 'static', shape: 'auto', ...physics } },
    bounds,
    worldScale: { x: 1, y: 1, z: 1 },
    worldPosition: at,
    worldRotation: Q0,
  });
  return r.descriptor!;
}
const FLOOR = () => body('floor', { bodyMode: 'static' }, { x: 0, y: -0.5, z: 0 }, box(40, 1, 40));
const run = (bridge: PhysicsBridge, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) bridge.step(1 / 60);
};
const record = (bridge: PhysicsBridge): PhysicsEvent[] => {
  const events: PhysicsEvent[] = [];
  bridge.onPhysicsEvent('*', (e) => events.push(e));
  return events;
};

describe('payload de colisão: selfId, otherId, ponto, normal e força (AIS-48-C03)', () => {
  it('collisionEnter traz as duas pontas, o ponto de contato mundial e a normal de self PARA other (oposta no outro lado)', () => {
    const bridge = new PhysicsBridge(R);
    const events = record(bridge);
    bridge.addBody(FLOOR());
    bridge.addBody(body('ball', { bodyMode: 'dynamic', shape: 'sphere', bounce: 0 }, { x: 2, y: 3, z: -1 }));
    run(bridge, 3);
    const enters = events.filter((e) => e.name === 'collisionEnter');
    const ball = enters.find((e) => e.selfId === 'ball')!;
    const floor = enters.find((e) => e.selfId === 'floor')!;
    expect(ball.otherId).toBe('floor');
    expect(floor.otherId).toBe('ball');
    // ponto de contato mundial: no plano do chão, debaixo da bola
    expect(ball.contact!.point.y).toBeGreaterThan(-0.1);
    expect(ball.contact!.point.y).toBeLessThan(0.1);
    expect(Math.abs(ball.contact!.point.x - 2)).toBeLessThan(0.6);
    expect(Math.abs(ball.contact!.point.z + 1)).toBeLessThan(0.6);
    // normal unitária: da bola PARA o chão = para baixo; do chão para a bola = para cima
    const len = (n: { x: number; y: number; z: number }) => Math.hypot(n.x, n.y, n.z);
    expect(len(ball.contact!.normal)).toBeCloseTo(1, 3);
    expect(ball.contact!.normal.y).toBeLessThan(-0.9);
    expect(floor.contact!.normal.y).toBeGreaterThan(0.9);
    expect(floor.contact!.normal.x).toBeCloseTo(-ball.contact!.normal.x, 5);
    expect(typeof ball.force).toBe('number');
    expect(ball.force).toBeGreaterThan(0);
    bridge.dispose();
  });

  it('a normal respeita o lado: bola que bate numa parede à direita tem normal +X; à esquerda, -X', () => {
    const hit = (wallX: number) => {
      const bridge = new PhysicsBridge(R, { gravity: { x: 0, y: 0, z: 0 } });
      const events = record(bridge);
      bridge.addBody(body('wall', { bodyMode: 'static' }, { x: wallX, y: 0, z: 0 }, box(1, 10, 10)));
      bridge.addBody(body('ball', { bodyMode: 'dynamic', shape: 'sphere' }, { x: 0, y: 0, z: 0 }));
      bridge.setLinearVelocity('ball', { x: Math.sign(wallX) * 8, y: 0, z: 0 });
      run(bridge, 1);
      const n = events.find((e) => e.name === 'collisionEnter' && e.selfId === 'ball')!.contact!.normal;
      bridge.dispose();
      return n;
    };
    expect(hit(4).x).toBeGreaterThan(0.9);
    expect(hit(-4).x).toBeLessThan(-0.9);
  });

  it('a força do impacto cresce com a velocidade da batida (acima/abaixo de um limiar de teste)', () => {
    const forceFrom = (height: number) => {
      const bridge = new PhysicsBridge(R);
      const events = record(bridge);
      bridge.addBody(FLOOR());
      bridge.addBody(body('crate', { bodyMode: 'dynamic', bounce: 0 }, { x: 0, y: height, z: 0 }));
      run(bridge, 4);
      const f = events.find((e) => e.name === 'collisionEnter' && e.selfId === 'crate')!.force!;
      bridge.dispose();
      return f;
    };
    const gentle = forceFrom(0.55);
    const hard = forceFrom(12);
    const THRESHOLD = (gentle + hard) / 2; // limiar de teste entre os dois
    expect(hard).toBeGreaterThan(THRESHOLD);
    expect(gentle).toBeLessThan(THRESHOLD);
    expect(hard).toBeGreaterThan(gentle * 3);
  });

  it('collisionExit não carrega força nem contato; ocorre quando o objeto se separa', () => {
    const bridge = new PhysicsBridge(R);
    const events = record(bridge);
    bridge.addBody(FLOOR());
    bridge.addBody(body('ball', { bodyMode: 'dynamic', shape: 'sphere', bounce: 0.9 }, { x: 0, y: 4, z: 0 }));
    run(bridge, 4);
    const exit = events.find((e) => e.name === 'collisionExit' && e.selfId === 'ball');
    expect(exit).toBeDefined();
    expect(exit!.force).toBeUndefined();
    expect(exit!.contact).toBeUndefined();
    // todo Enter tem Exit correspondente (ou o contato continua aberto): nunca mais Exits que Enters
    const enters = events.filter((e) => e.name === 'collisionEnter' && e.selfId === 'ball').length;
    const exits = events.filter((e) => e.name === 'collisionExit' && e.selfId === 'ball').length;
    expect(exits).toBeLessThanOrEqual(enters);
    expect(enters - exits).toBeLessThanOrEqual(1);
    bridge.dispose();
  });
});

describe('gatilhos (trigger) — sem resistência sólida e sem dado de força (AIS-48-C03/C05)', () => {
  it('triggerEnter/triggerExit trazem selfId/otherId e NENHUM dado de força ou contato; o objeto atravessa', () => {
    const bridge = new PhysicsBridge(R);
    const events = record(bridge);
    bridge.addBody(body('zone', { bodyMode: 'trigger' }, { x: 0, y: 0, z: 0 }, box(4, 1, 4)));
    bridge.addBody(body('ball', { bodyMode: 'dynamic', shape: 'sphere' }, { x: 0, y: 4, z: 0 }));
    run(bridge, 3);
    expect(bridge.getPose('ball')!.position.y).toBeLessThan(-5); // sem resposta sólida: atravessou
    const trig = events.filter((e) => e.name === 'triggerEnter' || e.name === 'triggerExit');
    expect(trig.map((e) => `${e.name}:${e.selfId}>${e.otherId}`)).toEqual(expect.arrayContaining(['triggerEnter:zone>ball', 'triggerEnter:ball>zone', 'triggerExit:zone>ball', 'triggerExit:ball>zone']));
    for (const e of trig) {
      expect(e.force).toBeUndefined();
      expect(e.contact).toBeUndefined();
    }
    expect(events.some((e) => e.name === 'collisionEnter')).toBe(false); // gatilho não é colisão
    bridge.dispose();
  });
});

describe('não existe Stay (AIS-48-C04)', () => {
  it('corpo parado em contato por 5 s emite UM Enter e nada mais (nenhum evento por passo)', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(FLOOR());
    bridge.addBody(body('crate', { bodyMode: 'dynamic', bounce: 0 }, { x: 0, y: 0.5, z: 0 }));
    run(bridge, 1); // assenta
    const events = record(bridge);
    run(bridge, 5);
    expect(events).toEqual([]); // contato contínuo: silêncio
    bridge.dispose();
  });

  it('corpo parado DENTRO de um gatilho por 5 s emite UM Enter e nenhum evento depois', () => {
    const bridge = new PhysicsBridge(R, { gravity: { x: 0, y: 0, z: 0 } });
    const events = record(bridge);
    bridge.addBody(body('zone', { bodyMode: 'trigger' }, { x: 0, y: 0, z: 0 }, box(4, 4, 4)));
    bridge.addBody(body('crate', { bodyMode: 'dynamic' }, { x: 0, y: 0, z: 0 }));
    run(bridge, 5);
    expect(events.filter((e) => e.name === 'triggerEnter' && e.selfId === 'zone')).toHaveLength(1);
    expect(events.filter((e) => e.name === 'triggerExit')).toHaveLength(0);
    expect(events.some((e) => (e.name as string).toLowerCase().includes('stay'))).toBe(false);
    bridge.dispose();
  });
});

describe('onPhysicsEvent(name, cb) → unsubscribe (AIS-48-C06)', () => {
  it('filtra por nome, devolve o unsubscribe e para de receber depois dele', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(FLOOR());
    bridge.addBody(body('a', { bodyMode: 'dynamic' }, { x: 0, y: 2, z: 0 }));
    let enters = 0;
    let all = 0;
    const offEnter = bridge.onPhysicsEvent('collisionEnter', () => enters++);
    bridge.onPhysicsEvent('*', () => all++);
    run(bridge, 2);
    expect(enters).toBeGreaterThan(0);
    expect(all).toBeGreaterThanOrEqual(enters);
    offEnter();
    offEnter(); // idempotente
    const before = enters;
    bridge.teleport('a', { x: 0, y: 3, z: 0 });
    run(bridge, 2);
    expect(enters).toBe(before);
    bridge.dispose();
  });
});
