import RAPIER from '@dimforge/rapier3d-compat';

/**
 * AIS-45 — carga ÚNICA do Rapier (`@dimforge/rapier3d-compat`, WASM embutido: sem CDN, offline). `init()` é assíncrono, então a
 * `RuntimeSession` (síncrona) consulta `getRapierIfReady()`: o editor dispara `ensureRapier()` ao abrir e, quando o Play
 * começa antes de a carga terminar, a ponte física entra assim que ela termina (o Play nunca espera nem quebra).
 */
export type RapierModule = typeof RAPIER;

let loading: Promise<RapierModule> | null = null;
let loaded = false;

export function ensureRapier(): Promise<RapierModule> {
  loading ??= RAPIER.init().then(() => {
    loaded = true;
    return RAPIER;
  });
  return loading;
}

export const getRapierIfReady = (): RapierModule | null => (loaded ? RAPIER : null);
