import type { PhysicsBodyMode, PhysicsConfig, PhysicsShape } from '../../types/node';
import { PhysicsConfigSchema } from '../../schemas/v1/physics.schema';

/** Rótulos da interface (AIS-26b §3.2). */
export const BODY_MODE_LABEL: Record<PhysicsBodyMode, string> = {
  static: 'Sólido parado',
  dynamic: 'Físico',
  kinematic: 'Movido pela lógica',
  character: 'Personagem',
  trigger: 'Área (gatilho)',
};

export const BODY_MODE_ORDER: readonly PhysicsBodyMode[] = ['static', 'dynamic', 'kinematic', 'character', 'trigger'];

export const SHAPE_LABEL: Record<PhysicsShape, string> = {
  auto: 'Auto',
  box: 'Caixa',
  sphere: 'Esfera',
  capsule: 'Cápsula',
  cylinder: 'Cilindro',
  mesh: 'Malha exata',
};

export const SHAPE_ORDER: readonly PhysicsShape[] = ['auto', 'box', 'sphere', 'capsule', 'cylinder', 'mesh'];

export const PHYSICS_DEFAULTS = { friction: 0.5, bounce: 0, layer: 1, mask: 255 } as const;

/** Bloco criado por "Adicionar colisão" / "Adicionar com colisão": estático e automático. Nunca `dynamic`. */
export function defaultPhysicsConfig(): PhysicsConfig {
  return { enabled: true, bodyMode: 'static', shape: 'auto' };
}

/** Lê `properties.physics`; `null` se ausente ou inválido (o resolvedor nunca quebra por dado ruim). */
export function readPhysics(properties: Record<string, any> | undefined): PhysicsConfig | null {
  const raw = properties?.physics;
  if (raw === undefined || raw === null) return null;
  const parsed = PhysicsConfigSchema.safeParse(raw);
  return parsed.success ? (parsed.data as PhysicsConfig) : null;
}

/** `Malha exata` só existe em "Sólido parado". */
export const isShapeAllowed = (shape: PhysicsShape, bodyMode: PhysicsBodyMode): boolean =>
  shape !== 'mesh' || bodyMode === 'static';

const clamp = (n: number, min: number, max: number) => Math.min(max, Math.max(min, n));

/**
 * Aplica um patch ao bloco mantendo os estados válidos (AIS-26b §3.1): um gesto = um resultado coerente.
 *  - `mesh` em corpo não `static` não é aceita (o patch de forma é ignorado);
 *  - trocar o tipo de uma `mesh` para outro tipo volta a forma para `auto`;
 *  - `character` força a cápsula;
 *  - `floats` só existe em `dynamic`.
 * `undefined` num campo opcional do patch o remove (ex.: `size: undefined` = "Ajustar à malha").
 */
export function applyPhysicsPatch(current: PhysicsConfig, patch: Partial<PhysicsConfig>): PhysicsConfig {
  const next: PhysicsConfig = { ...current };
  for (const [key, value] of Object.entries(patch) as [keyof PhysicsConfig, any][]) {
    if (value === undefined) delete (next as any)[key];
    else (next as any)[key] = value;
  }
  if (next.friction !== undefined) next.friction = clamp(next.friction, 0, 1);
  if (next.bounce !== undefined) next.bounce = clamp(next.bounce, 0, 1);
  if (next.layer !== undefined) next.layer = clamp(Math.round(next.layer), 0, 255);
  if (next.mask !== undefined) next.mask = clamp(Math.round(next.mask), 0, 255);
  if (next.mass !== undefined && !(next.mass > 0)) delete next.mass;

  if (next.bodyMode === 'character') next.shape = 'capsule';
  else if (!isShapeAllowed(next.shape, next.bodyMode)) {
    // veio de uma troca de tipo (mesh → outro tipo) ou de uma forma inválida pedida: volta/mantém o estado coerente
    next.shape = patch.shape !== undefined && current.shape !== 'mesh' ? current.shape : 'auto';
  }
  if (next.bodyMode !== 'dynamic') delete next.floats;
  return next;
}

/** `physics.<campo>` → valor, só do que mudou; é o `changes` do `ChangePropertyCommand` (um Undo por gesto). */
export function diffPhysics(prev: PhysicsConfig | null, next: PhysicsConfig): Record<string, any> {
  const out: Record<string, any> = {};
  const keys = new Set<string>([...Object.keys(prev ?? {}), ...Object.keys(next)]);
  for (const key of keys) {
    const a = (prev as any)?.[key];
    const b = (next as any)[key];
    if (JSON.stringify(a) === JSON.stringify(b)) continue;
    out[`physics.${key}`] = b;
  }
  return out;
}
