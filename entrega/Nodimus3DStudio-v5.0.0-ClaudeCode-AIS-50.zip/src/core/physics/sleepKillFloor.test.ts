import { beforeAll, describe, expect, it } from 'vitest';
import type { PhysicsConfig } from '../../types/node';
import { DEFAULT_KILL_FLOOR_Y, PhysicsBridge, type PhysicsEvent } from './PhysicsBridge';
import { resolvePhysicsDescriptor, type PhysicsBodyDescriptor } from './physicsDescriptor';
import { ensureRapier, type RapierModule } from './rapierInit';

/**
 * AIS-49 — harness Rapier HEADLESS: sono de corpos em repouso (e reativação por força/impacto/teleporte) e Kill Floor (evento antes do
 * descarte, resgate por assinante, só dynamic/character).
 */

let R: RapierModule;
beforeAll(async () => {
  R = await ensureRapier();
});

const Q0 = { x: 0, y: 0, z: 0, w: 1 };
const box = (x = 1, y = 1, z = 1) => ({ size: { x, y, z }, center: { x: 0, y: 0, z: 0 } });
function body(id: string, physics: Partial<PhysicsConfig>, at: { x: number; y: number; z: number }, bounds = box()): PhysicsBodyDescriptor {
  return resolvePhysicsDescriptor({
    nodeId: id,
    name: id,
    nodeType: 'MeshInstance',
    properties: { meshType: 'CubeMesh', physics: { enabled: true, bodyMode: 'static', shape: 'auto', ...physics } },
    bounds,
    worldScale: { x: 1, y: 1, z: 1 },
    worldPosition: at,
    worldRotation: Q0,
  }).descriptor!;
}
const FLOOR = () => body('floor', { bodyMode: 'static' }, { x: 0, y: -0.5, z: 0 }, box(40, 1, 40));
const run = (bridge: PhysicsBridge, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) bridge.step(1 / 60);
};

describe('sono dos corpos em repouso (AIS-49-C01/C02/C04)', () => {
  it('caixa pousada dorme; o contador de ativos cai e o de dormindo sobe', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(FLOOR());
    bridge.addBody(body('crate', { bodyMode: 'dynamic', bounce: 0 }, { x: 0, y: 1, z: 0 }));
    expect(bridge.activeBodyCount).toBe(1);
    expect(bridge.isSleeping('crate')).toBe(false);
    run(bridge, 6);
    expect(bridge.isSleeping('crate')).toBe(true);
    expect(bridge.activeBodyCount).toBe(0);
    expect(bridge.sleepingBodyCount).toBe(1);
    expect(bridge.isSleeping('floor')).toBe(false); // estático não conta como dormindo
    bridge.dispose();
  });

  it('um corpo em queda livre NÃO dorme', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(body('falling', { bodyMode: 'dynamic' }, { x: 0, y: 500, z: 0 }));
    run(bridge, 2);
    expect(bridge.isSleeping('falling')).toBe(false);
    expect(bridge.activeBodyCount).toBe(1);
    bridge.dispose();
  });

  const settled = () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(FLOOR());
    bridge.addBody(body('crate', { bodyMode: 'dynamic', bounce: 0 }, { x: 0, y: 0.5, z: 0 }));
    run(bridge, 6);
    expect(bridge.isSleeping('crate')).toBe(true);
    return bridge;
  };

  it('impulso acorda e move o corpo adormecido', () => {
    const bridge = settled();
    bridge.addImpulse('crate', { x: 6, y: 0, z: 0 });
    expect(bridge.isSleeping('crate')).toBe(false);
    run(bridge, 0.5);
    expect(bridge.getPose('crate')!.position.x).toBeGreaterThan(0.3);
    bridge.dispose();
  });

  it('força contínua acorda o corpo', () => {
    const bridge = settled();
    bridge.addForce('crate', { x: 400, y: 0, z: 0 });
    run(bridge, 0.5);
    expect(bridge.isSleeping('crate')).toBe(false);
    expect(bridge.getPose('crate')!.position.x).toBeGreaterThan(0.05);
    bridge.dispose();
  });

  it('velocidade, torque e teleporte também acordam', () => {
    for (const wake of [
      (b: PhysicsBridge) => b.setLinearVelocity('crate', { x: 3, y: 0, z: 0 }),
      (b: PhysicsBridge) => b.applyTorque('crate', { x: 0, y: 50, z: 0 }, 'impulse'),
      (b: PhysicsBridge) => b.teleport('crate', { x: 0, y: 3, z: 0 }),
    ]) {
      const bridge = settled();
      wake(bridge);
      expect(bridge.isSleeping('crate')).toBe(false);
      bridge.dispose();
    }
  });

  it('impacto de outro corpo acorda o que dormia (e o evento de contato chega)', () => {
    const bridge = settled();
    const events: PhysicsEvent[] = [];
    bridge.onPhysicsEvent('collisionEnter', (e) => events.push(e));
    bridge.addBody(body('ball', { bodyMode: 'dynamic', shape: 'sphere', mass: 50 }, { x: 0, y: 4, z: 0 }));
    run(bridge, 1.5);
    expect(events.some((e) => e.selfId === 'crate' && e.otherId === 'ball')).toBe(true);
    expect(bridge.isSleeping('crate')).toBe(false);
    bridge.dispose();
  });

  it('desligar o corpo tira-o das contagens de ativos', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(body('a', { bodyMode: 'dynamic' }, { x: 0, y: 5, z: 0 }));
    bridge.setEnabled('a', false);
    expect(bridge.activeBodyCount).toBe(0);
    expect(bridge.sleepingBodyCount).toBe(0);
    bridge.dispose();
  });
});

describe('Kill Floor em Y = -50 m (AIS-49-C03/C04)', () => {
  it('o padrão é -50', () => expect(DEFAULT_KILL_FLOOR_Y).toBe(-50));

  it('corpo caindo abaixo de -50: evento killFloor ANTES do descarte, depois o corpo some do mundo', () => {
    const bridge = new PhysicsBridge(R);
    const events: PhysicsEvent[] = [];
    let hadBodyDuringEvent = false;
    bridge.onPhysicsEvent('killFloor', (e) => {
      hadBodyDuringEvent = bridge.has(e.selfId); // o aviso chega com o corpo ainda no mundo
      events.push(e);
    });
    bridge.addBody(body('rock', { bodyMode: 'dynamic' }, { x: 3, y: 0, z: 0 }));
    for (let i = 0; i < 60 * 8 && bridge.has('rock'); i++) bridge.step(1 / 60);
    expect(bridge.has('rock')).toBe(false);
    expect(events).toHaveLength(1);
    expect(events[0]).toMatchObject({ name: 'killFloor', selfId: 'rock', otherId: '' });
    expect(events[0].position!.y).toBeLessThan(-50);
    expect(hadBodyDuringEvent).toBe(true);
    expect(bridge.takeDiscarded()).toEqual(['rock']);
    expect(bridge.takeDiscarded()).toEqual([]); // consumido uma vez
    bridge.dispose();
  });

  it('um assinante pode resgatar o corpo (teleporte) e ele NÃO é descartado', () => {
    const bridge = new PhysicsBridge(R);
    let saved = 0;
    bridge.onPhysicsEvent('killFloor', (e) => {
      saved++;
      bridge.teleport(e.selfId, { x: 0, y: 5, z: 0 });
    });
    bridge.addBody(body('hero', { bodyMode: 'dynamic' }, { x: 0, y: 0, z: 0 }));
    run(bridge, 8);
    expect(saved).toBeGreaterThanOrEqual(1);
    expect(bridge.has('hero')).toBe(true);
    expect(bridge.takeDiscarded()).toEqual([]);
    bridge.dispose();
  });

  it('só dynamic/character são descartados: estático, kinematic e gatilho abaixo do limite ficam', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(body('s', { bodyMode: 'static' }, { x: 0, y: -80, z: 0 }));
    bridge.addBody(body('k', { bodyMode: 'kinematic' }, { x: 5, y: -80, z: 0 }));
    bridge.addBody(body('t', { bodyMode: 'trigger' }, { x: 9, y: -80, z: 0 }));
    const events: PhysicsEvent[] = [];
    bridge.onPhysicsEvent('killFloor', (e) => events.push(e));
    run(bridge, 1);
    expect(events).toHaveLength(0);
    for (const id of ['s', 'k', 't']) expect(bridge.has(id)).toBe(true);
    bridge.dispose();
  });

  it('o limite é configurável e -Infinity desliga o Kill Floor', () => {
    const custom = new PhysicsBridge(R, { killFloorY: -5 });
    custom.addBody(body('a', { bodyMode: 'dynamic' }, { x: 0, y: 0, z: 0 }));
    for (let i = 0; i < 300 && custom.has('a'); i++) custom.step(1 / 60);
    expect(custom.has('a')).toBe(false);
    custom.dispose();
    const off = new PhysicsBridge(R, { killFloorY: Number.NEGATIVE_INFINITY });
    off.addBody(body('a', { bodyMode: 'dynamic' }, { x: 0, y: -200, z: 0 }));
    run(off, 1);
    expect(off.has('a')).toBe(true);
    off.dispose();
  });

  it('corpo acima do limite nunca dispara o aviso', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(FLOOR());
    bridge.addBody(body('crate', { bodyMode: 'dynamic' }, { x: 0, y: 2, z: 0 }));
    const events: PhysicsEvent[] = [];
    bridge.onPhysicsEvent('killFloor', (e) => events.push(e));
    run(bridge, 5);
    expect(events).toHaveLength(0);
    expect(bridge.has('crate')).toBe(true);
    bridge.dispose();
  });
});
