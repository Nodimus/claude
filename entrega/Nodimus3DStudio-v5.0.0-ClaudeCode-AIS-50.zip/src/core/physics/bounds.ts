import * as THREE from 'three';

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface LocalBounds {
  size: Vec3;
  center: Vec3;
}

/**
 * AABB do objeto no espaço LOCAL dele (sem a escala do próprio nó; os filhos herdam a dele). `null` se não houver malha.
 * É o mesmo `Box3` que o importador usa para o pivô; aqui sobre a geometria de cada malha filha.
 * Alimenta o tamanho automático do colisor (`resolveCollider`, AIS-26b).
 */
export function measureLocalBounds(object: THREE.Object3D): LocalBounds | null {
  object.updateWorldMatrix(true, true);
  const inverse = object.matrixWorld.clone().invert();
  const box = new THREE.Box3();
  let any = false;
  object.traverse((child) => {
    const mesh = child as THREE.Mesh;
    if (!mesh.isMesh || !mesh.geometry) return;
    let geoBox: THREE.Box3 | null;
    const skinned = child as THREE.SkinnedMesh;
    if (skinned.isSkinnedMesh && skinned.skeleton) {
      // malha skinned: a caixa de bind não é o tamanho visto (ex.: Mixamo com Armature a 0,01); mede com os ossos aplicados
      skinned.skeleton.update();
      skinned.computeBoundingBox();
      geoBox = skinned.boundingBox;
    } else {
      if (!mesh.geometry.boundingBox) mesh.geometry.computeBoundingBox();
      geoBox = mesh.geometry.boundingBox;
    }
    if (!geoBox || geoBox.isEmpty()) return;
    child.updateWorldMatrix(true, false);
    box.union(geoBox.clone().applyMatrix4(inverse.clone().multiply(child.matrixWorld)));
    any = true;
  });
  if (!any || box.isEmpty()) return null;
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  return { size: { x: size.x, y: size.y, z: size.z }, center: { x: center.x, y: center.y, z: center.z } };
}
