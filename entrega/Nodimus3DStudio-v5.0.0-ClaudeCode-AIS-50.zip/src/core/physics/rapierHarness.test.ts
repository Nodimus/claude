import { beforeAll, describe, expect, it } from 'vitest';
import RAPIER from '@dimforge/rapier3d-compat';
import type { PhysicsConfig } from '../../types/node';
import { defaultPhysicsConfig } from './physicsConfig';
import { resolveCollider, type ColliderSpec, type ResolveColliderContext } from './resolveCollider';

/**
 * AIS-26b — harness Rapier HEADLESS. Prova que o contrato de `resolveCollider` (tamanho total, offset e escala já
 * aplicados) é aceito pelo Rapier e produz o comportamento esperado. NÃO é a factory de corpos do AIS-45 (que cria o
 * mundo no Play, dentro da `RuntimeSession`): o adaptador abaixo é mínimo e vive só neste teste.
 */

const ctx = (over: Partial<ResolveColliderContext> = {}): ResolveColliderContext => ({
  nodeType: 'MeshInstance',
  properties: { meshType: 'CubeMesh' },
  bounds: { size: { x: 1, y: 1, z: 1 }, center: { x: 0, y: 0, z: 0 } },
  scale: { x: 1, y: 1, z: 1 },
  ...over,
});
const cfg = (over: Partial<PhysicsConfig> = {}): PhysicsConfig => ({ ...defaultPhysicsConfig(), ...over });

/** `ColliderSpec` (tamanho TOTAL) → ColliderDesc do Rapier (meia-extensão / raio / meia-altura). */
function colliderDesc(spec: ColliderSpec, config: PhysicsConfig): RAPIER.ColliderDesc {
  const { x, y, z } = spec.size;
  let desc: RAPIER.ColliderDesc;
  switch (spec.kind) {
    case 'sphere':
      desc = RAPIER.ColliderDesc.ball(x / 2);
      break;
    case 'capsule':
      desc = RAPIER.ColliderDesc.capsule(Math.max(0.001, (y - x) / 2), x / 2);
      break;
    case 'cylinder':
      desc = RAPIER.ColliderDesc.cylinder(y / 2, x / 2);
      break;
    default:
      desc = RAPIER.ColliderDesc.cuboid(x / 2, y / 2, z / 2);
  }
  desc.setTranslation(spec.offset.x, spec.offset.y, spec.offset.z);
  desc.setFriction(config.friction ?? 0.5).setRestitution(config.bounce ?? 0);
  if (config.bodyMode === 'trigger') desc.setSensor(true);
  // semântica nativa do Rapier: grupos = (membership << 16) | filter
  desc.setCollisionGroups(((config.layer ?? 1) << 16) | (config.mask ?? 255));
  return desc;
}

function addBody(world: RAPIER.World, config: PhysicsConfig, spec: ColliderSpec, position: { x: number; y: number; z: number }) {
  const bodyDesc =
    config.bodyMode === 'dynamic' ? RAPIER.RigidBodyDesc.dynamic()
    : config.bodyMode === 'kinematic' ? RAPIER.RigidBodyDesc.kinematicPositionBased()
    : RAPIER.RigidBodyDesc.fixed();
  bodyDesc.setTranslation(position.x, position.y, position.z);
  const body = world.createRigidBody(bodyDesc);
  const collider = world.createCollider(colliderDesc(spec, config), body);
  return { body, collider };
}

const step = (world: RAPIER.World, seconds: number) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) world.step();
};

let world: RAPIER.World;
beforeAll(async () => {
  await RAPIER.init();
});

describe('Rapier headless (AIS-26b-C11)', () => {
  const newWorld = () => (world = new RAPIER.World({ x: 0, y: -9.81, z: 0 }));

  it('chão estático (caixa automática) segura uma caixa "Físico": queda e repouso', () => {
    newWorld();
    const groundCfg = cfg({ bodyMode: 'static' });
    const ground = resolveCollider(groundCfg, ctx({ bounds: { size: { x: 20, y: 1, z: 20 }, center: { x: 0, y: 0, z: 0 } } }))!;
    addBody(world, groundCfg, ground, { x: 0, y: -0.5, z: 0 }); // topo do chão em y = 0

    const boxCfg = cfg({ bodyMode: 'dynamic' });
    const box = resolveCollider(boxCfg, ctx({ bounds: { size: { x: 1, y: 1, z: 1 }, center: { x: 0, y: 0, z: 0 } } }))!;
    const { body } = addBody(world, boxCfg, box, { x: 0, y: 5, z: 0 });

    step(world, 4);
    const y = body.translation().y;
    expect(y).toBeGreaterThan(0.45);
    expect(y).toBeLessThan(0.56); // repousa com a base no topo do chão (centro a 0,5)
  });

  it('a escala global já está no tamanho: objeto com scale 2 repousa mais alto', () => {
    newWorld();
    const groundCfg = cfg({ bodyMode: 'static' });
    addBody(world, groundCfg, resolveCollider(groundCfg, ctx({ bounds: { size: { x: 20, y: 1, z: 20 }, center: { x: 0, y: 0, z: 0 } } }))!, { x: 0, y: -0.5, z: 0 });
    const boxCfg = cfg({ bodyMode: 'dynamic' });
    const big = resolveCollider(boxCfg, ctx({ scale: { x: 2, y: 2, z: 2 } }))!;
    expect(big.size).toEqual({ x: 2, y: 2, z: 2 });
    const { body } = addBody(world, boxCfg, big, { x: 0, y: 5, z: 0 });
    step(world, 4);
    expect(body.translation().y).toBeGreaterThan(0.95);
    expect(body.translation().y).toBeLessThan(1.06);
  });

  it('esfera e cápsula automáticas também repousam sobre o chão', () => {
    newWorld();
    const groundCfg = cfg({ bodyMode: 'static' });
    addBody(world, groundCfg, resolveCollider(groundCfg, ctx({ bounds: { size: { x: 20, y: 1, z: 20 }, center: { x: 0, y: 0, z: 0 } } }))!, { x: 0, y: -0.5, z: 0 });
    const sphereCfg = cfg({ bodyMode: 'dynamic' });
    const sphere = resolveCollider(sphereCfg, ctx({ properties: { meshType: 'SphereMesh' }, bounds: { size: { x: 1, y: 1, z: 1 }, center: { x: 0, y: 0, z: 0 } } }))!;
    expect(sphere.kind).toBe('sphere');
    const s = addBody(world, sphereCfg, sphere, { x: -3, y: 4, z: 0 });
    const capsuleCfg = cfg({ bodyMode: 'dynamic', shape: 'capsule' });
    const capsule = resolveCollider(capsuleCfg, ctx({ bounds: { size: { x: 1, y: 2, z: 1 }, center: { x: 0, y: 0, z: 0 } } }))!;
    const c = addBody(world, capsuleCfg, capsule, { x: 3, y: 4, z: 0 });
    step(world, 4);
    expect(s.body.translation().y).toBeGreaterThan(0.4);
    expect(s.body.translation().y).toBeLessThan(0.6);
    expect(c.body.translation().y).toBeGreaterThan(0.9); // meia-altura da cápsula = 1
    expect(c.body.translation().y).toBeLessThan(1.1);
  });

  it('o offset do colisor desloca o contato (centro da malha ≠ origem do nó)', () => {
    newWorld();
    const groundCfg = cfg({ bodyMode: 'static' });
    addBody(world, groundCfg, resolveCollider(groundCfg, ctx({ bounds: { size: { x: 20, y: 1, z: 20 }, center: { x: 0, y: 0, z: 0 } } }))!, { x: 0, y: -0.5, z: 0 });
    const boxCfg = cfg({ bodyMode: 'dynamic' });
    // origem do nó na base da malha: centro do colisor a 1 acima da origem
    const spec = resolveCollider(boxCfg, ctx({ bounds: { size: { x: 1, y: 2, z: 1 }, center: { x: 0, y: 1, z: 0 } } }))!;
    expect(spec.offset.y).toBe(1);
    const { body } = addBody(world, boxCfg, spec, { x: 0, y: 5, z: 0 });
    step(world, 4);
    expect(body.translation().y).toBeLessThan(0.06); // a origem do nó (base) toca o chão
    expect(body.translation().y).toBeGreaterThan(-0.06);
  });

  it('"Área (gatilho)" não bloqueia: o objeto atravessa o sensor e o contato é detectado', () => {
    newWorld();
    const groundCfg = cfg({ bodyMode: 'static' });
    addBody(world, groundCfg, resolveCollider(groundCfg, ctx({ bounds: { size: { x: 20, y: 1, z: 20 }, center: { x: 0, y: 0, z: 0 } } }))!, { x: 0, y: -10.5, z: 0 });
    const triggerCfg = cfg({ bodyMode: 'trigger' });
    const trigger = resolveCollider(triggerCfg, ctx({ bounds: { size: { x: 4, y: 1, z: 4 }, center: { x: 0, y: 0, z: 0 } } }))!;
    const sensor = addBody(world, triggerCfg, trigger, { x: 0, y: 0, z: 0 });
    const boxCfg = cfg({ bodyMode: 'dynamic' });
    const falling = addBody(world, boxCfg, resolveCollider(boxCfg, ctx())!, { x: 0, y: 5, z: 0 });
    let entered = false;
    const queue = new RAPIER.EventQueue(true);
    sensor.collider.setActiveEvents(RAPIER.ActiveEvents.COLLISION_EVENTS);
    falling.collider.setActiveEvents(RAPIER.ActiveEvents.COLLISION_EVENTS);
    for (let i = 0; i < 240; i++) {
      world.step(queue);
      queue.drainCollisionEvents((a, b, started) => {
        if (started && [a, b].includes(sensor.collider.handle) && [a, b].includes(falling.collider.handle)) entered = true;
      });
    }
    expect(entered).toBe(true);
    expect(falling.body.translation().y).toBeLessThan(-5); // atravessou o gatilho até o chão distante
  });

  it('filtro layer/mask nativo: os dois lados precisam aceitar', () => {
    const run = (maskOfBox: number) => {
      newWorld();
      const groundCfg = cfg({ bodyMode: 'static', layer: 1, mask: 255 });
      addBody(world, groundCfg, resolveCollider(groundCfg, ctx({ bounds: { size: { x: 20, y: 1, z: 20 }, center: { x: 0, y: 0, z: 0 } } }))!, { x: 0, y: -0.5, z: 0 });
      const boxCfg = cfg({ bodyMode: 'dynamic', layer: 2, mask: maskOfBox });
      const { body } = addBody(world, boxCfg, resolveCollider(boxCfg, ctx())!, { x: 0, y: 3, z: 0 });
      step(world, 3);
      return body.translation().y;
    };
    expect(run(255)).toBeGreaterThan(0.4); // aceita a camada 1: repousa
    expect(run(2)).toBeLessThan(-5); // máscara não inclui a camada 1: atravessa o chão
  });

  it('o mundo é liberado sem estado residual', () => {
    newWorld();
    expect(() => world.free()).not.toThrow();
  });
});
