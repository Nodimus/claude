import type { PhysicsBodyMode, PhysicsConfig } from '../../types/node';
import type { LocalBounds, Vec3 } from './bounds';
import { readPhysics, PHYSICS_DEFAULTS } from './physicsConfig';
import { resolveCollider, type ColliderSpec } from './resolveCollider';

/**
 * AIS-45 — camada B ("Resolução") do núcleo físico: `resolvePhysicsDescriptor` é a ÚNICA função que transforma um nó com
 * `properties.physics` em um descritor de corpo para o Rapier. Pura (sem Rapier nem Three): forma e tamanho vêm de
 * `resolveCollider` (decisão 26) — o MESMO que alimenta o wireframe de "Mostrar colisores" —, então o colisor do Rapier tem
 * sempre a forma e o tamanho do que o editor desenha. Sem bloco, ou com `enabled:false`, não há corpo (nada de corpo
 * implícito). Problemas viram `PhysicsIssue` (a ponte os publica como diagnósticos efêmeros); nunca exceções.
 */

export interface Quat {
  x: number;
  y: number;
  z: number;
  w: number;
}

/** Malha triangular no espaço LOCAL do corpo, com a escala global já aplicada (o Rapier não escala colisores). */
export interface TriMesh {
  vertices: Float32Array;
  indices: Uint32Array;
}

/**
 * Campo de alturas (decisão 23: o MESMO `Float32Array` do terreno, nunca uma cópia derivada de `displacementMap`).
 * `heights` em ordem de linhas (`rows` amostras em Z × `cols` em X, índice `row * cols + col`); `scale` = extensão total
 * (x: largura, y: multiplicador de altura, z: profundidade). O colisor fica centrado na origem do nó, como no Rapier.
 */
export interface HeightfieldData {
  rows: number;
  cols: number;
  heights: Float32Array;
  scale: Vec3;
}

export interface PhysicsBodyDescriptor {
  nodeId: string;
  name: string;
  bodyMode: PhysicsBodyMode;
  collider: ColliderSpec;
  /** Pose MUNDIAL inicial (calculada uma vez; depois o corpo é o dono da pose). */
  position: Vec3;
  rotation: Quat;
  friction: number;
  bounce: number;
  /** Ausente = automática pelo volume (densidade 1). */
  mass?: number;
  /** Amortecimento linear padrão do projeto (`settings.physics.defaultLinearDamp`); só em `dynamic`. */
  linearDamping?: number;
  /** Filtro nativo do Rapier: `(layer << 16) | mask` — os DOIS lados precisam aceitar. */
  groups: number;
  lockTranslations: { x: boolean; y: boolean; z: boolean };
  lockRotations: { x: boolean; y: boolean; z: boolean };
  trimesh?: TriMesh;
  heightfield?: HeightfieldData;
}

export type PhysicsIssueCode =
  | 'physics.nonuniform_scale'
  | 'physics.mesh_missing_geometry'
  | 'physics.mesh_not_static'
  | 'physics.invalid_config'
  | 'physics.heightfield_missing_data';

export interface PhysicsIssue {
  code: PhysicsIssueCode;
  /** `warning`: o corpo é criado mesmo assim; `error`: o nó fica SEM corpo (o Play não quebra). */
  severity: 'warning' | 'error';
  message: string;
  nodeId: string;
}

export interface ResolvePhysicsInput {
  nodeId: string;
  name: string;
  nodeType: string;
  properties: Record<string, any>;
  /** AABB local (`measureLocalBounds`); `null` se o nó não tem malha. */
  bounds: LocalBounds | null;
  worldScale: Vec3;
  worldPosition: Vec3;
  worldRotation: Quat;
  /** Triângulos do nó (só para `shape: 'mesh'`), já no espaço local com a escala global aplicada. */
  triangles?: TriMesh | null;
  /** Buffer do terreno (decisão 23), para nós com `heightfield`. */
  heightfield?: HeightfieldData | null;
  /** `settings.physics.defaultLinearDamp` do projeto. */
  defaultLinearDamp?: number;
}

export interface ResolvePhysicsResult {
  descriptor: PhysicsBodyDescriptor | null;
  issues: PhysicsIssue[];
}

/** `constrainToPlane` → eixos travados (translação do eixo normal; rotações fora do eixo normal). */
export function planeLocks(plane: PhysicsConfig['constrainToPlane']): Pick<PhysicsBodyDescriptor, 'lockTranslations' | 'lockRotations'> {
  const free = { x: false, y: false, z: false };
  switch (plane) {
    case 'xy':
      return { lockTranslations: { ...free, z: true }, lockRotations: { x: true, y: true, z: false } };
    case 'xz':
      return { lockTranslations: { ...free, y: true }, lockRotations: { x: true, y: false, z: true } };
    case 'yz':
      return { lockTranslations: { ...free, x: true }, lockRotations: { x: false, y: true, z: true } };
    default:
      return { lockTranslations: free, lockRotations: { ...free } };
  }
}

export function resolvePhysicsDescriptor(input: ResolvePhysicsInput): ResolvePhysicsResult {
  const config = readPhysics(input.properties);
  const raw = input.properties?.physics as Record<string, any> | undefined;
  if (!config && raw && typeof raw === 'object' && raw.enabled !== false) {
    // bloco presente mas inválido (arquivo adulterado/legado): o nó fica sem corpo COM um motivo, nunca em silêncio
    const label = `"${input.name}"`;
    const meshNotStatic = raw.shape === 'mesh' && raw.bodyMode !== 'static';
    return {
      descriptor: null,
      issues: [
        meshNotStatic
          ? { code: 'physics.mesh_not_static', severity: 'error', nodeId: input.nodeId, message: `${label}: "Malha exata" só funciona em "Sólido parado" (static); o objeto ficou sem colisão.` }
          : { code: 'physics.invalid_config', severity: 'error', nodeId: input.nodeId, message: `${label}: o bloco de colisão é inválido; o objeto ficou sem colisão.` },
      ],
    };
  }
  if (!config || !config.enabled) return { descriptor: null, issues: [] };

  const issues: PhysicsIssue[] = [];
  const issue = (code: PhysicsIssueCode, severity: 'warning' | 'error', message: string) => issues.push({ code, severity, message, nodeId: input.nodeId });
  const label = `"${input.name}"`;

  const spec = resolveCollider(config, { nodeType: input.nodeType, properties: input.properties, bounds: input.bounds, scale: input.worldScale });
  if (!spec) return { descriptor: null, issues };

  // Malha exata só em `static` (a regra vem do schema/applyPhysicsPatch; o runtime revalida com erro claro)
  if (spec.kind === 'mesh' && config.bodyMode !== 'static') {
    issue('physics.mesh_not_static', 'error', `${label}: "Malha exata" só funciona em "Sólido parado" (static); o objeto ficou sem colisão.`);
    return { descriptor: null, issues };
  }
  if (spec.warnings.includes('nonuniform_scale')) {
    issue('physics.nonuniform_scale', 'warning', `${label}: escala não uniforme com forma redonda; o colisor usa a melhor aproximação.`);
  }
  let trimesh: TriMesh | undefined;
  if (spec.kind === 'mesh') {
    if (!input.triangles || input.triangles.indices.length < 3 || input.triangles.vertices.length < 9) {
      issue('physics.mesh_missing_geometry', 'warning', `${label}: a malha exata não tem geometria carregada; o objeto ficou sem colisão.`);
      return { descriptor: null, issues };
    }
    trimesh = input.triangles;
  }
  let heightfield: HeightfieldData | undefined;
  if (spec.kind === 'heightfield') {
    const hf = input.heightfield;
    if (!hf || hf.rows < 2 || hf.cols < 2 || hf.heights.length !== hf.rows * hf.cols) {
      issue('physics.heightfield_missing_data', 'warning', `${label}: o terreno não tem campo de alturas válido; o objeto ficou sem colisão.`);
      return { descriptor: null, issues };
    }
    heightfield = hf;
  }

  const locks = planeLocks(config.constrainToPlane);
  return {
    descriptor: {
      nodeId: input.nodeId,
      name: input.name,
      bodyMode: config.bodyMode,
      collider: spec,
      position: { ...input.worldPosition },
      rotation: { ...input.worldRotation },
      friction: config.friction ?? PHYSICS_DEFAULTS.friction,
      bounce: config.bounce ?? PHYSICS_DEFAULTS.bounce,
      mass: config.mass,
      linearDamping: config.bodyMode === 'dynamic' && typeof input.defaultLinearDamp === 'number' && input.defaultLinearDamp >= 0 ? input.defaultLinearDamp : undefined,
      groups: (((config.layer ?? PHYSICS_DEFAULTS.layer) & 0xff) << 16) | ((config.mask ?? PHYSICS_DEFAULTS.mask) & 0xff),
      ...locks,
      trimesh,
      heightfield,
    },
    issues,
  };
}
