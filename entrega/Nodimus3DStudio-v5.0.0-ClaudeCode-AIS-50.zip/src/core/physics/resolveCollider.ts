import type { PhysicsConfig, PhysicsShape } from '../../types/node';
import type { LocalBounds, Vec3 } from './bounds';

/**
 * AIS-26b — ÚNICA função que decide forma e tamanho do colisor (decisão 26). Usada pelo wireframe do editor, pelo Play
 * (AIS-45) e pelo jogo publicado. Pura: sem Three.js, sem Rapier.
 */

export type ColliderKind = 'box' | 'sphere' | 'capsule' | 'cylinder' | 'mesh' | 'heightfield';

export interface ColliderSpec {
  kind: ColliderKind;
  /**
   * Tamanho TOTAL já multiplicado pela escala global (o Rapier não escala colisores).
   * box: largura/altura/profundidade · sphere: (d,d,d) · capsule/cylinder: (d,h,d) · mesh/heightfield: AABB.
   */
  size: Vec3;
  /** Centro do colisor em relação à origem do nó, já com a escala global. */
  offset: Vec3;
  /** Avisos únicos (ex.: escala não uniforme); quem consome decide como exibir, nunca um por quadro. */
  warnings: ColliderWarning[];
}

export type ColliderWarning = 'nonuniform_scale' | 'mesh_missing_geometry';

export interface ResolveColliderContext {
  nodeType: string;
  properties: Record<string, any>;
  /** AABB local medido (`measureLocalBounds`); `null` se o nó não tem malha. */
  bounds: LocalBounds | null;
  /** Escala global do nó. */
  scale: Vec3;
}

export const THIN_PLANE_HEIGHT = 0.05;
const MIN_SIZE = 0.001;

const abs = (n: number) => Math.max(MIN_SIZE, Math.abs(Number.isFinite(n) ? n : 1));
const maxAxis = (v: Vec3) => Math.max(v.x, v.y, v.z);
const isUniform = (s: Vec3) => Math.abs(s.x - s.y) < 1e-4 && Math.abs(s.y - s.z) < 1e-4;

/** Forma que o `auto` escolhe para este nó (tabela 3.3 do prompt). */
export function autoShapeFor(bodyMode: PhysicsConfig['bodyMode'], ctx: Pick<ResolveColliderContext, 'nodeType' | 'properties'>): Exclude<PhysicsShape, 'auto'> | 'heightfield' {
  if (bodyMode === 'character') return 'capsule';
  if (ctx.nodeType === 'Terrain') return 'heightfield';
  if (ctx.properties.isProceduralTree) return 'cylinder';
  if (ctx.nodeType === 'MeshInstance') {
    switch (ctx.properties.meshType) {
      case 'SphereMesh': return 'sphere';
      case 'CylinderMesh': return 'cylinder';
      case 'TorusMesh': return bodyMode === 'static' ? 'mesh' : 'box';
      default: return 'box';
    }
  }
  return 'box';
}

export function resolveCollider(config: PhysicsConfig | null | undefined, ctx: ResolveColliderContext): ColliderSpec | null {
  if (!config || !config.enabled) return null;
  const warnings: ColliderWarning[] = [];
  const scale: Vec3 = { x: abs(ctx.scale.x), y: abs(ctx.scale.y), z: abs(ctx.scale.z) };

  const requested = config.shape;
  const kind: ColliderKind = config.bodyMode === 'character'
    ? 'capsule'
    : requested === 'auto' ? autoShapeFor(config.bodyMode, ctx) : requested;

  // 1) tamanho LOCAL (total) e centro LOCAL
  let local: Vec3;
  let center: Vec3 = config.offset ?? { x: 0, y: 0, z: 0 };
  let sizeIsExplicit = false;
  if (config.size) {
    local = { x: abs(config.size.x), y: abs(config.size.y), z: abs(config.size.z) };
    sizeIsExplicit = true;
  } else if (ctx.properties.isProceduralTree && kind === 'cylinder' && requested === 'auto') {
    const height = abs(Number(ctx.properties.trunkHeight ?? 2));
    const radius = abs(Math.max(Number(ctx.properties.trunkRadiusBase ?? 0.25), Number(ctx.properties.trunkRadiusTop ?? 0)));
    local = { x: radius * 2, y: height, z: radius * 2 };
    if (!config.offset) center = { x: 0, y: height / 2, z: 0 };
  } else if (ctx.bounds) {
    local = { x: abs(ctx.bounds.size.x), y: abs(ctx.bounds.size.y), z: abs(ctx.bounds.size.z) };
    if (!config.offset) center = { ...ctx.bounds.center };
  } else if (kind === 'heightfield' || kind === 'mesh') {
    // sem geometria para medir: o descritor continua válido (o AIS-50/45 preenche a partir do buffer)
    local = { x: 1, y: 1, z: 1 };
    if (kind === 'mesh') warnings.push('mesh_missing_geometry');
  } else {
    local = { x: 1, y: 1, z: 1 };
  }

  // 2) ajuste por forma
  if (!sizeIsExplicit && ctx.nodeType === 'MeshInstance' && ctx.properties.meshType === 'PlaneMesh' && kind === 'box') {
    local = { ...local, y: THIN_PLANE_HEIGHT };
  }
  if (kind === 'sphere') {
    const d = sizeIsExplicit ? local.x : maxAxis(local);
    local = { x: d, y: d, z: d };
  } else if (kind === 'capsule' || kind === 'cylinder') {
    const d = sizeIsExplicit ? local.x : Math.max(local.x, local.z);
    const h = kind === 'capsule' ? Math.max(local.y, d) : local.y; // a cápsula nunca é mais baixa que o diâmetro
    local = { x: d, y: h, z: d };
  }

  // 3) escala global (o Rapier não escala colisores)
  let sized: Vec3;
  if (kind === 'sphere' || kind === 'capsule' || kind === 'cylinder') {
    // esfera: qualquer eixo diferente é aproximação; cilindro/cápsula: Y livre é exato — só X≠Z (raio) é aproximação (AIS-45)
    const approximated = kind === 'sphere' ? !isUniform(scale) : Math.abs(scale.x - scale.z) >= 1e-4;
    if (approximated) warnings.push('nonuniform_scale');
    const radial = kind === 'sphere' ? maxAxis(scale) : Math.max(scale.x, scale.z);
    const vertical = kind === 'sphere' ? maxAxis(scale) : scale.y;
    sized = { x: local.x * radial, y: local.y * vertical, z: local.z * radial };
  } else {
    sized = { x: local.x * scale.x, y: local.y * scale.y, z: local.z * scale.z };
  }
  return {
    kind,
    size: sized,
    offset: { x: center.x * scale.x, y: center.y * scale.y, z: center.z * scale.z },
    warnings,
  };
}

/** Tamanho automático que o Inspector mostra em cinza (valor LOCAL, antes da escala): o mesmo cálculo sem `size`. */
export function autoLocalSize(config: PhysicsConfig, ctx: ResolveColliderContext): Vec3 | null {
  const spec = resolveCollider({ ...config, enabled: true, size: undefined }, { ...ctx, scale: { x: 1, y: 1, z: 1 } });
  return spec ? spec.size : null;
}
