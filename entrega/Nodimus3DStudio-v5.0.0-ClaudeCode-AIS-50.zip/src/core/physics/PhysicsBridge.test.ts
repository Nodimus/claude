import { beforeAll, describe, expect, it } from 'vitest';
import type { PhysicsConfig } from '../../types/node';
import { PhysicsBridge, PhysicsBridgeError, type PhysicsEvent } from './PhysicsBridge';
import { resolvePhysicsDescriptor, type HeightfieldData, type PhysicsBodyDescriptor, type TriMesh } from './physicsDescriptor';
import { ensureRapier, type RapierModule } from './rapierInit';
import { resolveCollider } from './resolveCollider';

/**
 * AIS-45-C06 — harness Rapier HEADLESS da `PhysicsBridge` (teste de função pura não prova o contrato do mundo): chão fixo,
 * malha exata estática, Layer/Mask filtrado, heightfield, character com gravidade, kinematic, trigger, dois dynamic, teleporte
 * com limpeza de velocidade, validação por `bodyMode` e reinício sem estado residual.
 */

let R: RapierModule;
beforeAll(async () => {
  R = await ensureRapier();
});

const Q0 = { x: 0, y: 0, z: 0, w: 1 };
const box = (x = 1, y = 1, z = 1) => ({ size: { x, y, z }, center: { x: 0, y: 0, z: 0 } });

function describeBody(id: string, physics: Partial<PhysicsConfig>, at: { x: number; y: number; z: number }, extra: Partial<Parameters<typeof resolvePhysicsDescriptor>[0]> = {}): PhysicsBodyDescriptor {
  const result = resolvePhysicsDescriptor({
    nodeId: id,
    name: id,
    nodeType: 'MeshInstance',
    properties: { meshType: 'CubeMesh', physics: { enabled: true, bodyMode: 'static', shape: 'auto', ...physics } },
    bounds: box(),
    worldScale: { x: 1, y: 1, z: 1 },
    worldPosition: at,
    worldRotation: Q0,
    ...extra,
  });
  if (!result.descriptor) throw new Error(`sem descritor: ${JSON.stringify(result.issues)}`);
  return result.descriptor;
}

const ground = (id = 'ground') => describeBody(id, { bodyMode: 'static' }, { x: 0, y: -0.5, z: 0 }, { bounds: box(40, 1, 40) });
const run = (bridge: PhysicsBridge, seconds: number, poseSource?: Parameters<PhysicsBridge['step']>[1]) => {
  for (let i = 0; i < Math.round(seconds * 60); i++) bridge.step(1 / 60, poseSource);
};

describe('chão fixo, queda e repouso (AIS-45-C06)', () => {
  it('dynamic cai e repousa sobre o chão; o corpo é o dono da pose', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(ground());
    bridge.addBody(describeBody('box', { bodyMode: 'dynamic' }, { x: 0, y: 5, z: 0 }));
    run(bridge, 4);
    const pose = bridge.getPose('box')!;
    expect(pose.position.y).toBeGreaterThan(0.45);
    expect(pose.position.y).toBeLessThan(0.55);
    bridge.dispose();
  });

  it('dois dynamic se empilham (dynamic × dynamic)', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(ground());
    bridge.addBody(describeBody('a', { bodyMode: 'dynamic' }, { x: 0, y: 0.5, z: 0 }));
    bridge.addBody(describeBody('b', { bodyMode: 'dynamic' }, { x: 0, y: 3, z: 0 }));
    run(bridge, 4);
    expect(bridge.getPose('b')!.position.y).toBeGreaterThan(1.4);
    expect(bridge.getPose('b')!.position.y).toBeLessThan(1.6);
    bridge.dispose();
  });

  it('o passo é FIXO: quadros curtos acumulam e não rodam passos fracionados', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(describeBody('b', { bodyMode: 'dynamic' }, { x: 0, y: 5, z: 0 }));
    expect(bridge.step(0.005)).toBe(0);
    expect(bridge.step(0.005)).toBe(0);
    expect(bridge.step(0.01)).toBe(1); // 0.02 acumulados ≥ 1/60
    expect(bridge.step(0.5)).toBe(5); // teto de 5 passos por chamada
    bridge.dispose();
  });
});

describe('formas e C01: o colisor do Rapier tem a forma e o tamanho de resolveCollider', () => {
  it.each([
    ['box', { shape: 'box' as const }, { x: 1, y: 2, z: 3 }],
    ['sphere', { shape: 'sphere' as const }, { x: 2, y: 2, z: 2 }],
    ['capsule', { shape: 'capsule' as const }, { x: 1, y: 3, z: 1 }],
    ['cylinder', { shape: 'cylinder' as const }, { x: 1, y: 2, z: 1 }],
  ])('%s', (kind, physics, size) => {
    const bridge = new PhysicsBridge(R);
    const d = describeBody(`n_${kind}`, physics, { x: 0, y: 1, z: 0 }, { bounds: box(size.x, size.y, size.z) });
    // a MESMA função que desenha o wireframe de "Mostrar colisores"
    const spec = resolveCollider({ enabled: true, bodyMode: 'static', shape: physics.shape }, { nodeType: 'MeshInstance', properties: { meshType: 'CubeMesh' }, bounds: box(size.x, size.y, size.z), scale: { x: 1, y: 1, z: 1 } })!;
    expect(d.collider).toEqual(spec);
    bridge.addBody(d);
    const collider = (bridge as any).entries.get(d.nodeId).collider;
    const half = collider.halfExtents?.();
    if (kind === 'box') expect(half).toMatchObject({ x: d.collider.size.x / 2, y: d.collider.size.y / 2, z: d.collider.size.z / 2 });
    if (kind === 'sphere') expect(collider.radius()).toBeCloseTo(d.collider.size.x / 2);
    if (kind === 'capsule') {
      expect(collider.radius()).toBeCloseTo(d.collider.size.x / 2);
      expect(collider.halfHeight()).toBeCloseTo((d.collider.size.y - d.collider.size.x) / 2);
    }
    if (kind === 'cylinder') {
      expect(collider.radius()).toBeCloseTo(d.collider.size.x / 2);
      expect(collider.halfHeight()).toBeCloseTo(d.collider.size.y / 2);
    }
    bridge.dispose();
  });

  it('a escala global já está no tamanho (o Rapier não escala colisores)', () => {
    const bridge = new PhysicsBridge(R);
    const d = describeBody('big', { bodyMode: 'static' }, { x: 0, y: 0, z: 0 }, { worldScale: { x: 2, y: 3, z: 4 } });
    expect(d.collider.size).toEqual({ x: 2, y: 3, z: 4 });
    bridge.dispose();
  });
});

describe('malha exata (trimesh) só em static (AIS-45-C03/C04/C06)', () => {
  // piso de cenário: dois triângulos formando um quadrado horizontal em y = 0
  const ramp: TriMesh = {
    vertices: new Float32Array([-5, 0, -5, 5, 0, -5, 5, 0, 5, -5, 0, 5]),
    indices: new Uint32Array([0, 1, 2, 0, 2, 3]),
  };

  it('uma esfera dynamic repousa sobre a malha exata estática e não a atravessa', () => {
    const bridge = new PhysicsBridge(R);
    const mesh = describeBody('ramp', { bodyMode: 'static', shape: 'mesh' }, { x: 0, y: 0, z: 0 }, { triangles: ramp });
    expect(mesh.collider.kind).toBe('mesh');
    bridge.addMesh(mesh);
    bridge.addBody(describeBody('ball', { bodyMode: 'dynamic', shape: 'sphere' }, { x: 0, y: 6, z: 0 }, { bounds: box(1, 1, 1) }));
    run(bridge, 4);
    expect(bridge.getPose('ball')!.position.y).toBeGreaterThan(0.4); // não atravessou o piso (raio 0.5)
    expect(bridge.getPose('ball')!.position.y).toBeLessThan(0.6);
    bridge.dispose();
  });

  it('o runtime revalida: Malha exata em dynamic/kinematic/character NÃO cria corpo e explica o motivo', () => {
    for (const bodyMode of ['dynamic', 'kinematic', 'character'] as const) {
      const r = resolvePhysicsDescriptor({
        nodeId: 'n', name: 'Rampa', nodeType: 'MeshInstance',
        properties: { physics: { enabled: true, bodyMode, shape: 'mesh' } },
        bounds: box(), worldScale: { x: 1, y: 1, z: 1 }, worldPosition: { x: 0, y: 0, z: 0 }, worldRotation: Q0, triangles: ramp,
      });
      // o schema recusa "mesh" fora de static (também em character): o runtime revalida e diz POR QUE ficou sem colisão
      expect(r.descriptor).toBeNull();
      expect(r.issues[0]).toMatchObject({ code: 'physics.mesh_not_static', severity: 'error' });
      expect(r.issues[0].message).toContain('Malha exata');
    }
    const bridge = new PhysicsBridge(R);
    const dyn = describeBody('x', { bodyMode: 'static', shape: 'mesh' }, { x: 0, y: 0, z: 0 }, { triangles: ramp });
    expect(() => bridge.addMesh({ ...dyn, bodyMode: 'dynamic' })).toThrow(PhysicsBridgeError);
    bridge.dispose();
  });

  it('malha exata sem geometria: o nó fica sem corpo com `physics.mesh_missing_geometry` (nunca exceção)', () => {
    const r = resolvePhysicsDescriptor({
      nodeId: 'n', name: 'Cenário', nodeType: 'MeshInstance',
      properties: { physics: { enabled: true, bodyMode: 'static', shape: 'mesh' } },
      bounds: null, worldScale: { x: 1, y: 1, z: 1 }, worldPosition: { x: 0, y: 0, z: 0 }, worldRotation: Q0, triangles: null,
    });
    expect(r.descriptor).toBeNull();
    expect(r.issues.map((i) => i.code)).toEqual(['physics.mesh_missing_geometry']);
  });
});

describe('heightfield do terreno (AIS-45-C03)', () => {
  // 5×5 amostras, rampa em X: altura = col (0..4) × 0.5
  const rows = 5;
  const cols = 5;
  const heights = new Float32Array(rows * cols);
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) heights[r * cols + c] = c / (cols - 1);
  const field: HeightfieldData = { rows, cols, heights, scale: { x: 20, y: 4, z: 20 } };

  it('um corpo repousa sobre o campo de alturas (mesmo Float32Array do terreno), seguindo a rampa em X', () => {
    const bridge = new PhysicsBridge(R);
    const terrain = resolvePhysicsDescriptor({
      nodeId: 'terrain', name: 'Terrain', nodeType: 'Terrain',
      properties: { physics: { enabled: true, bodyMode: 'static', shape: 'auto' } },
      bounds: null, worldScale: { x: 1, y: 1, z: 1 }, worldPosition: { x: 0, y: 0, z: 0 }, worldRotation: Q0, heightfield: field,
    });
    expect(terrain.descriptor?.collider.kind).toBe('heightfield');
    expect(terrain.descriptor?.heightfield?.heights).toBe(heights); // o MESMO buffer, sem cópia
    bridge.addHeightfield(terrain.descriptor!);
    // baixa (x = -8 → altura 0.1·4...) e alta (x = +8): a de x maior repousa mais alto
    bridge.addBody(describeBody('low', { bodyMode: 'dynamic', shape: 'sphere' }, { x: -8, y: 8, z: 0 }, { bounds: box() }));
    bridge.addBody(describeBody('high', { bodyMode: 'dynamic', shape: 'sphere' }, { x: 8, y: 8, z: 0 }, { bounds: box() }));
    run(bridge, 3);
    expect(bridge.getPose('high')!.position.y).toBeGreaterThan(bridge.getPose('low')!.position.y + 1);
    bridge.dispose();
  });

  it('sem buffer de alturas: sem corpo e com `physics.heightfield_missing_data`', () => {
    const r = resolvePhysicsDescriptor({
      nodeId: 't', name: 'Terrain', nodeType: 'Terrain', properties: { physics: { enabled: true, bodyMode: 'static', shape: 'auto' } },
      bounds: null, worldScale: { x: 1, y: 1, z: 1 }, worldPosition: { x: 0, y: 0, z: 0 }, worldRotation: Q0,
    });
    expect(r.descriptor).toBeNull();
    expect(r.issues[0].code).toBe('physics.heightfield_missing_data');
  });
});

describe('Layer/Mask nativos (AIS-45-C05/C06): os dois lados precisam aceitar', () => {
  const fall = (boxPhysics: Partial<PhysicsConfig>, groundPhysics: Partial<PhysicsConfig> = {}) => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(describeBody('ground', { bodyMode: 'static', layer: 1, mask: 255, ...groundPhysics }, { x: 0, y: -0.5, z: 0 }, { bounds: box(40, 1, 40) }));
    bridge.addBody(describeBody('box', { bodyMode: 'dynamic', ...boxPhysics }, { x: 0, y: 3, z: 0 }));
    run(bridge, 3);
    const y = bridge.getPose('box')!.position.y;
    bridge.dispose();
    return y;
  };

  it('máscara que inclui a camada do chão: repousa; que não inclui: atravessa', () => {
    expect(fall({ layer: 2, mask: 255 })).toBeGreaterThan(0.4);
    expect(fall({ layer: 2, mask: 2 })).toBeLessThan(-5);
  });

  it('o outro lado também decide: o chão que não aceita a camada do corpo é atravessado', () => {
    expect(fall({ layer: 2, mask: 255 }, { layer: 1, mask: 1 })).toBeLessThan(-5);
    expect(fall({ layer: 1, mask: 255 }, { layer: 1, mask: 1 })).toBeGreaterThan(0.4);
  });

  it('o descritor guarda `(layer << 16) | mask` com os padrões 1 e 255', () => {
    expect(describeBody('a', {}, { x: 0, y: 0, z: 0 }).groups).toBe((1 << 16) | 255);
    expect(describeBody('b', { layer: 4, mask: 6 }, { x: 0, y: 0, z: 0 }).groups).toBe((4 << 16) | 6);
  });
});

describe('contratos por bodyMode', () => {
  it('trigger não bloqueia e emite triggerEnter/triggerExit (um por participante)', () => {
    const bridge = new PhysicsBridge(R);
    const events: PhysicsEvent[] = [];
    bridge.onPhysicsEvent('*', (e) => events.push(e));
    bridge.addBody(describeBody('zone', { bodyMode: 'trigger' }, { x: 0, y: 0, z: 0 }, { bounds: box(4, 1, 4) }));
    bridge.addBody(describeBody('ball', { bodyMode: 'dynamic', shape: 'sphere' }, { x: 0, y: 4, z: 0 }));
    run(bridge, 3);
    expect(bridge.getPose('ball')!.position.y).toBeLessThan(-5); // atravessou (sem chão): o gatilho não é sólido
    const names = events.map((e) => `${e.name}:${e.selfId}>${e.otherId}`);
    expect(names).toContain('triggerEnter:zone>ball');
    expect(names).toContain('triggerEnter:ball>zone');
    expect(names).toContain('triggerExit:zone>ball');
    bridge.dispose();
  });

  it('collisionEnter chega com `force` e collisionExit ao separar', () => {
    const bridge = new PhysicsBridge(R);
    const events: PhysicsEvent[] = [];
    bridge.onPhysicsEvent('collisionEnter', (e) => events.push(e));
    bridge.addBody(ground());
    bridge.addBody(describeBody('b', { bodyMode: 'dynamic', bounce: 0 }, { x: 0, y: 3, z: 0 }));
    run(bridge, 3);
    const hit = events.find((e) => e.selfId === 'b' && e.otherId === 'ground');
    expect(hit).toBeDefined();
    expect(typeof hit!.force).toBe('number');
    bridge.dispose();
  });

  it('kinematic segue a pose pedida pelo runtime e empurra um dynamic', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(ground());
    bridge.addBody(describeBody('plat', { bodyMode: 'kinematic' }, { x: 0, y: 0.5, z: 0 }, { bounds: box(2, 1, 2) }));
    bridge.addBody(describeBody('crate', { bodyMode: 'dynamic' }, { x: 3, y: 0.5, z: 0 }));
    let x = 0;
    for (let i = 0; i < 120; i++) {
      x += 0.04; // a lógica move a plataforma; o corpo só segue
      bridge.step(1 / 60, (id) => (id === 'plat' ? { position: { x, y: 0.5, z: 0 }, rotation: Q0 } : null));
    }
    expect(bridge.getPose('plat')!.position.x).toBeCloseTo(x, 1);
    expect(bridge.getPose('crate')!.position.x).toBeGreaterThan(3.5); // foi empurrada
    bridge.dispose();
  });

  it('character NUNCA é dynamic: cai com gravidade, pousa e não atravessa parede', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(ground());
    bridge.addBody(describeBody('wall', { bodyMode: 'static' }, { x: 3, y: 1, z: 0 }, { bounds: box(1, 4, 10) }));
    const player = describeBody('player', { bodyMode: 'character' }, { x: 0, y: 4, z: 0 }, { bounds: box(1, 2, 1) });
    expect(player.collider.kind).toBe('capsule');
    bridge.addBody(player);
    expect((bridge as any).entries.get('player').body.isDynamic()).toBe(false);
    run(bridge, 2); // cai e pousa
    expect(bridge.isGrounded('player')).toBe(true);
    expect(bridge.getPose('player')!.position.y).toBeGreaterThan(0.9);
    expect(bridge.getPose('player')!.position.y).toBeLessThan(1.15);
    // a lógica empurra o personagem para a parede (intenção de movimento): ele é bloqueado
    let want = { x: 0, y: bridge.getPose('player')!.position.y, z: 0 };
    for (let i = 0; i < 120; i++) {
      want = { x: bridge.getPose('player')!.position.x + 0.1, y: want.y, z: 0 };
      bridge.step(1 / 60, (id) => (id === 'player' ? { position: want, rotation: Q0 } : null));
    }
    expect(bridge.getPose('player')!.position.x).toBeLessThan(2.1); // parede em x = 2.5 (meia largura 0.5) menos o raio
    bridge.dispose();
  });
});

describe('Actions sobre o corpo resolvido (nenhuma toca o Rapier direto)', () => {
  it('Add Force num corpo static/kinematic falha com mensagem clara, sem crash', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(ground());
    bridge.addBody(describeBody('k', { bodyMode: 'kinematic' }, { x: 0, y: 1, z: 0 }));
    expect(() => bridge.addForce('ground', { x: 1, y: 0, z: 0 })).toThrow(/não funciona em corpo "static"/);
    expect(() => bridge.addForce('k', { x: 1, y: 0, z: 0 })).toThrow(PhysicsBridgeError);
    expect(() => bridge.addForce('nao-existe', { x: 1, y: 0, z: 0 })).toThrow(/não tem corpo físico/);
    expect(() => bridge.addImpulse('ground', { x: 0, y: NaN, z: 0 })).toThrow(PhysicsBridgeError);
    bridge.dispose();
  });

  it('impulso, força contínua, velocidades e torque movem o dynamic', () => {
    const bridge = new PhysicsBridge(R, { gravity: { x: 0, y: 0, z: 0 } });
    bridge.addBody(describeBody('b', { bodyMode: 'dynamic' }, { x: 0, y: 0, z: 0 }));
    bridge.addImpulse('b', { x: 5, y: 0, z: 0 });
    run(bridge, 0.5);
    expect(bridge.getPose('b')!.linearVelocity.x).toBeGreaterThan(1);
    bridge.setLinearVelocity('b', { x: 0, y: 0, z: 0 });
    for (let i = 0; i < 15; i++) {
      bridge.addForce('b', { x: 0, y: 0, z: 20 }); // contínua: sustentada chamando a cada quadro
      bridge.step(1 / 60);
    }
    expect(bridge.getPose('b')!.linearVelocity.z).toBeGreaterThan(3);
    const vzAfter = bridge.getPose('b')!.linearVelocity.z;
    run(bridge, 0.25); // a força NÃO persiste sem nova chamada
    expect(Math.abs(bridge.getPose('b')!.linearVelocity.z - vzAfter)).toBeLessThan(0.05);
    bridge.setAngularVelocity('b', { x: 0, y: 3, z: 0 });
    run(bridge, 0.1);
    expect(Math.abs(bridge.getPose('b')!.rotation.y)).toBeGreaterThan(0.01);
    bridge.applyTorque('b', { x: 0, y: 1, z: 0 }, 'impulse');
    bridge.dispose();
  });

  it('espaço local rotaciona o vetor pela orientação do corpo', () => {
    const bridge = new PhysicsBridge(R, { gravity: { x: 0, y: 0, z: 0 } });
    const d = describeBody('b', { bodyMode: 'dynamic' }, { x: 0, y: 0, z: 0 });
    const half = Math.SQRT1_2;
    bridge.addBody({ ...d, rotation: { x: 0, y: half, z: 0, w: half } }); // 90° em Y: o +Z local vira +X mundial
    bridge.addImpulse('b', { x: 0, y: 0, z: 5 }, 'local');
    run(bridge, 0.2);
    const v = bridge.getPose('b')!.linearVelocity;
    expect(v.x).toBeGreaterThan(0.5);
    expect(Math.abs(v.z)).toBeLessThan(0.1);
    bridge.dispose();
  });

  it('teleporte reposiciona e LIMPA as velocidades quando pedido', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(describeBody('b', { bodyMode: 'dynamic' }, { x: 0, y: 10, z: 0 }));
    run(bridge, 0.5);
    expect(bridge.getPose('b')!.linearVelocity.y).toBeLessThan(-2);
    bridge.teleport('b', { x: 4, y: 20, z: 0 }, true);
    expect(bridge.getPose('b')!.position).toMatchObject({ x: 4, y: 20, z: 0 });
    expect(bridge.getPose('b')!.linearVelocity.y).toBe(0);
    bridge.dispose();
  });

  it('Set Physics Enabled desliga o corpo sem remover o nó; Set Physics Material muda o atrito', () => {
    const bridge = new PhysicsBridge(R);
    bridge.addBody(ground());
    bridge.addBody(describeBody('b', { bodyMode: 'dynamic' }, { x: 0, y: 2, z: 0 }));
    bridge.setEnabled('b', false);
    expect(bridge.isEnabled('b')).toBe(false);
    run(bridge, 1);
    expect(bridge.getPose('b')!.position.y).toBeCloseTo(2, 1); // desligado: não cai
    expect(() => bridge.addImpulse('b', { x: 1, y: 0, z: 0 })).toThrow(/desligado/);
    bridge.setEnabled('b', true);
    run(bridge, 3);
    expect(bridge.getPose('b')!.position.y).toBeLessThan(0.6);
    bridge.setMaterial('b', 0.1, 0.9);
    expect((bridge as any).entries.get('b').collider.friction()).toBeCloseTo(0.1);
    expect((bridge as any).entries.get('b').collider.restitution()).toBeCloseTo(0.9);
    bridge.dispose();
  });

  it('defaultLinearDamp do projeto amortece os dynamic (e só eles)', () => {
    const speedAfter = (damp: number | undefined) => {
      const bridge = new PhysicsBridge(R, { gravity: { x: 0, y: 0, z: 0 } });
      bridge.addBody(describeBody('b', { bodyMode: 'dynamic' }, { x: 0, y: 0, z: 0 }, { defaultLinearDamp: damp }));
      bridge.setLinearVelocity('b', { x: 10, y: 0, z: 0 });
      run(bridge, 1);
      const v = bridge.getPose('b')!.linearVelocity.x;
      bridge.dispose();
      return v;
    };
    expect(speedAfter(undefined)).toBeGreaterThan(9.9);
    expect(speedAfter(2)).toBeLessThan(2);
    expect(describeBody('s', { bodyMode: 'static' }, { x: 0, y: 0, z: 0 }, { defaultLinearDamp: 2 }).linearDamping).toBeUndefined();
  });
});

describe('ciclo de vida', () => {
  it('sem bloco ou com enabled:false não há corpo (nada de corpo implícito)', () => {
    const base = { nodeId: 'n', name: 'N', nodeType: 'MeshInstance', bounds: box(), worldScale: { x: 1, y: 1, z: 1 }, worldPosition: { x: 0, y: 0, z: 0 }, worldRotation: Q0 };
    expect(resolvePhysicsDescriptor({ ...base, properties: {} }).descriptor).toBeNull();
    expect(resolvePhysicsDescriptor({ ...base, properties: { physics: { enabled: false, bodyMode: 'dynamic', shape: 'auto' } } }).descriptor).toBeNull();
    expect(resolvePhysicsDescriptor({ ...base, properties: { physics: { enabled: true, bodyMode: 'dynamic', shape: 'auto' } } }).descriptor).not.toBeNull();
  });

  it('escala não uniforme com forma redonda gera UM aviso e o corpo é criado', () => {
    const r = resolvePhysicsDescriptor({
      nodeId: 'n', name: 'Bola', nodeType: 'MeshInstance', properties: { physics: { enabled: true, bodyMode: 'static', shape: 'sphere' } },
      bounds: box(), worldScale: { x: 1, y: 2, z: 1 }, worldPosition: { x: 0, y: 0, z: 0 }, worldRotation: Q0,
    });
    expect(r.descriptor).not.toBeNull();
    expect(r.issues.map((i) => i.code)).toEqual(['physics.nonuniform_scale']);
  });

  it('bloco de colisão inválido: sem corpo e com `physics.invalid_config` (nunca em silêncio)', () => {
    const r = resolvePhysicsDescriptor({ nodeId: 'n', name: 'N', nodeType: 'MeshInstance', properties: { physics: { enabled: true, bodyMode: 'voador', shape: 'auto' } }, bounds: box(), worldScale: { x: 1, y: 1, z: 1 }, worldPosition: { x: 0, y: 0, z: 0 }, worldRotation: Q0 });
    expect(r.descriptor).toBeNull();
    expect(r.issues[0].code).toBe('physics.invalid_config');
  });

  it('constrainToPlane trava os eixos certos (2D respeita o plano)', () => {
    const bridge = new PhysicsBridge(R, { gravity: { x: 0, y: 0, z: 0 } });
    bridge.addBody(describeBody('b', { bodyMode: 'dynamic', constrainToPlane: 'xy' }, { x: 0, y: 0, z: 0 }));
    bridge.addImpulse('b', { x: 3, y: 0, z: 3 });
    run(bridge, 1);
    expect(bridge.getPose('b')!.position.x).toBeGreaterThan(0.5);
    expect(bridge.getPose('b')!.position.z).toBe(0); // z travado
    bridge.dispose();
  });

  it('dispose libera o mundo (idempotente) e toda operação depois falha com session_disposed; reiniciar não deixa resíduo', () => {
    const first = new PhysicsBridge(R);
    first.addBody(describeBody('b', { bodyMode: 'dynamic' }, { x: 0, y: 5, z: 0 }));
    run(first, 1);
    first.dispose();
    first.dispose();
    expect(first.isDisposed).toBe(true);
    expect(first.step(1)).toBe(0);
    expect(() => first.addImpulse('b', { x: 1, y: 0, z: 0 })).toThrow(/encerrada/);
    // "reinício do Play": um mundo NOVO começa do zero (sem velocidade, nem corpos, nem assinantes)
    const second = new PhysicsBridge(R);
    expect(second.bodyCount).toBe(0);
    second.addBody(describeBody('b', { bodyMode: 'dynamic' }, { x: 0, y: 5, z: 0 }));
    expect(second.getPose('b')!.linearVelocity.y).toBe(0);
    second.dispose();
  });

  it('assinante com defeito não derruba o mundo; unsubscribe para de receber', () => {
    const bridge = new PhysicsBridge(R);
    let received = 0;
    bridge.onPhysicsEvent('*', () => {
      throw new Error('quebrou');
    });
    const off = bridge.onPhysicsEvent('collisionEnter', () => received++);
    bridge.addBody(ground());
    bridge.addBody(describeBody('b', { bodyMode: 'dynamic' }, { x: 0, y: 2, z: 0 }));
    expect(() => run(bridge, 2)).not.toThrow();
    expect(received).toBeGreaterThan(0);
    off();
    const before = received;
    bridge.teleport('b', { x: 0, y: 3, z: 0 });
    run(bridge, 2);
    expect(received).toBe(before);
    bridge.dispose();
  });
});
