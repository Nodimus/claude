import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import type { GameNode, PhysicsConfig } from '../../types/node';
import { measureLocalBounds } from './bounds';
import { applyPhysicsPatch, defaultPhysicsConfig, diffPhysics, isShapeAllowed, readPhysics } from './physicsConfig';
import { autoLocalSize, resolveCollider, type ResolveColliderContext } from './resolveCollider';
import { buildColliderWireframe, colliderSignature } from './colliderWireframe';
import { createChangePropertyCommand } from '../commands/ChangePropertyCommand';
import { createAddNodeCommand } from '../commands/SceneTreeCommands';
import { AuthoringModel } from '../authoring/AuthoringModel';
import { createEmptyScene } from '../defaultProject';
import { CommandManager } from '../commandManager';
import { convertLegacyPhysics, convertLegacyPhysicsNodes, legacyPhysicsWarning } from '../../schemas/legacyPhysics';
import { normalizeUnknownNodes, collectMissingTypes, withRestoredMissingNodes } from '../../schemas/missingNodes';
import { NODE_DEFINITIONS } from '../../nodes/registry';
import { GameNodeV1Schema } from '../../schemas/v1/node.schema';

const ONE = { x: 1, y: 1, z: 1 };
const bounds = (sx: number, sy: number, sz: number, cy = 0) => ({ size: { x: sx, y: sy, z: sz }, center: { x: 0, y: cy, z: 0 } });
const ctx = (over: Partial<ResolveColliderContext> = {}): ResolveColliderContext => ({
  nodeType: 'MeshInstance',
  properties: { meshType: 'CubeMesh' },
  bounds: bounds(2, 1, 2),
  scale: ONE,
  ...over,
});
const cfg = (over: Partial<PhysicsConfig> = {}): PhysicsConfig => ({ ...defaultPhysicsConfig(), ...over });

describe('AIS-26b-C01 — bloco properties.physics', () => {
  it('nó sem physics round-trip igual; com physics idêntico', () => {
    const base = { id: 'a', name: 'A', type: 'MeshInstance', parentId: null, childrenIds: [], visible: true, locked: false, properties: {} };
    const noPhysics = GameNodeV1Schema.parse(base);
    expect(noPhysics.properties).toEqual({});
    const physics = { enabled: true, bodyMode: 'dynamic', shape: 'box', size: { x: 1, y: 2, z: 3 }, mass: 2, friction: 0.3 };
    const withPhysics = GameNodeV1Schema.parse({ ...base, properties: { physics } });
    expect(JSON.parse(JSON.stringify(withPhysics)).properties.physics).toEqual(physics);
    expect(readPhysics(withPhysics.properties)).toEqual(physics);
  });
  it('bloco inválido é ignorado pelo leitor, nunca quebra', () => {
    expect(readPhysics({ physics: { enabled: 'sim' } })).toBeNull();
    expect(readPhysics({ physics: { enabled: true, bodyMode: 'dynamic', shape: 'mesh' } })).toBeNull();
    expect(readPhysics({})).toBeNull();
  });
  it('o rascunho v1 (GameNode.physics de primeiro nível, colliders[]) não é mais interpretado: é só um campo desconhecido, preservado intacto (AIS-29)', () => {
    const parsed = GameNodeV1Schema.parse({ id: 'a', name: 'A', type: 'MeshInstance', parentId: null, childrenIds: [], physics: { colliders: [] } } as any);
    expect(readPhysics(parsed.properties)).toBeNull(); // nada no bloco oficial
    expect((parsed as any).physics).toEqual({ colliders: [] }); // preservado, nunca descartado
  });
});

describe('AIS-26b-C02 — ligar/desligar/remover com Undo', () => {
  const setup = () => {
    const scene = createEmptyScene();
    const root = scene.rootNodeId;
    const node = (id: string, type: string, parentId: string | null, childrenIds: string[], properties: Record<string, any>) =>
      ({ id, name: id, type, parentId, childrenIds, visible: true, locked: false, properties }) as GameNode;
    scene.nodes = { [root]: node(root, 'Spatial', null, ['m'], {}), m: node('m', 'MeshInstance', root, [], { physics: cfg({ shape: 'box', size: { x: 3, y: 3, z: 3 } }) }) };
    return { model: new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene), manager: new CommandManager() };
  };
  const run = (s: ReturnType<typeof setup>, changes: Record<string, any>) => {
    const command = createChangePropertyCommand({ target: s.model as any, nodeId: 'm', changes });
    if (command) s.manager.execute(command);
  };

  it('desligar preserva a configuração; Undo religa', () => {
    const s = setup();
    run(s, { 'physics.enabled': false });
    expect(s.model.getScene().nodes.m.properties.physics).toMatchObject({ enabled: false, shape: 'box', size: { x: 3, y: 3, z: 3 } });
    s.manager.undo();
    expect(s.model.getScene().nodes.m.properties.physics.enabled).toBe(true);
  });
  it('Remover colisão apaga o bloco; Undo o restaura', () => {
    const s = setup();
    run(s, { physics: undefined });
    expect(readPhysics(s.model.getScene().nodes.m.properties)).toBeNull();
    s.manager.undo();
    expect(readPhysics(s.model.getScene().nodes.m.properties)).toMatchObject({ shape: 'box' });
  });
  it('Adicionar colisão em nó sem bloco; Undo remove', () => {
    const s = setup();
    run(s, { physics: undefined });
    run(s, { physics: defaultPhysicsConfig() });
    expect(readPhysics(s.model.getScene().nodes.m.properties)).toEqual(defaultPhysicsConfig());
    s.manager.undo();
    expect(readPhysics(s.model.getScene().nodes.m.properties)).toBeNull();
  });
});

describe('AIS-26b-C03 — resolveCollider (tabela 3.3)', () => {
  it('desligado ou sem bloco → null', () => {
    expect(resolveCollider(null, ctx())).toBeNull();
    expect(resolveCollider(cfg({ enabled: false }), ctx())).toBeNull();
  });
  it('character → cápsula com diâmetro e altura do AABB', () => {
    const s = resolveCollider(cfg({ bodyMode: 'character' }), ctx({ bounds: bounds(1, 2, 1, 1) }))!;
    expect(s.kind).toBe('capsule');
    expect(s.size).toEqual({ x: 1, y: 2, z: 1 });
    expect(s.offset.y).toBe(1);
  });
  it('Terrain → heightfield', () => {
    expect(resolveCollider(cfg(), ctx({ nodeType: 'Terrain', properties: {} }))!.kind).toBe('heightfield');
  });
  it('árvore procedural → cilindro no tronco (a copa não colide)', () => {
    const s = resolveCollider(cfg(), ctx({ properties: { isProceduralTree: true, trunkHeight: 4, trunkRadiusBase: 0.4, trunkRadiusTop: 0.2 }, bounds: bounds(6, 9, 6, 4.5) }))!;
    expect(s.kind).toBe('cylinder');
    expect(s.size).toEqual({ x: 0.8, y: 4, z: 0.8 });
    expect(s.offset).toEqual({ x: 0, y: 2, z: 0 });
  });
  it('SphereMesh → esfera (diâmetro = maior eixo); CylinderMesh → cilindro', () => {
    const sphere = resolveCollider(cfg(), ctx({ properties: { meshType: 'SphereMesh' }, bounds: bounds(2, 2, 2) }))!;
    expect(sphere.kind).toBe('sphere');
    expect(sphere.size).toEqual({ x: 2, y: 2, z: 2 });
    expect(resolveCollider(cfg(), ctx({ properties: { meshType: 'CylinderMesh' }, bounds: bounds(1, 3, 1) }))!.kind).toBe('cylinder');
  });
  it('PlaneMesh → caixa fina (altura 0,05)', () => {
    const s = resolveCollider(cfg(), ctx({ properties: { meshType: 'PlaneMesh' }, bounds: bounds(10, 0, 10) }))!;
    expect(s.kind).toBe('box');
    expect(s.size.y).toBeCloseTo(0.05);
  });
  it('TorusMesh → malha exata se static; senão caixa', () => {
    const props = { meshType: 'TorusMesh' };
    expect(resolveCollider(cfg({ bodyMode: 'static' }), ctx({ properties: props }))!.kind).toBe('mesh');
    expect(resolveCollider(cfg({ bodyMode: 'dynamic' }), ctx({ properties: props }))!.kind).toBe('box');
  });
  it('cubo e modelo importado → caixa do AABB, centrada na malha', () => {
    const s = resolveCollider(cfg(), ctx({ bounds: bounds(2, 4, 6, 2) }))!;
    expect(s.kind).toBe('box');
    expect(s.size).toEqual({ x: 2, y: 4, z: 6 });
    expect(s.offset).toEqual({ x: 0, y: 2, z: 0 });
  });
  it('sem malha e sem tamanho → caixa 1×1×1; malha exata sem geometria avisa', () => {
    expect(resolveCollider(cfg(), ctx({ bounds: null }))!.size).toEqual(ONE);
    expect(resolveCollider(cfg({ shape: 'mesh' }), ctx({ bounds: null }))!.warnings).toContain('mesh_missing_geometry');
  });
});

describe('AIS-26b-C04 — tamanho automático × explícito', () => {
  it('automático acompanha escala e meshType; explícito (size) é do autor', () => {
    const auto = cfg();
    expect(resolveCollider(auto, ctx({ scale: { x: 2, y: 2, z: 2 } }))!.size).toEqual({ x: 4, y: 2, z: 4 });
    const sphere = resolveCollider(auto, ctx({ properties: { meshType: 'SphereMesh' }, bounds: bounds(2, 2, 2) }))!;
    expect(sphere.kind).toBe('sphere');
    const explicit = cfg({ shape: 'box', size: { x: 5, y: 1, z: 1 } });
    expect(resolveCollider(explicit, ctx({ bounds: bounds(100, 100, 100) }))!.size).toEqual({ x: 5, y: 1, z: 1 });
  });
  it('"Ajustar à malha" (size: undefined) volta ao automático e é um diff com um único campo', () => {
    const explicit = cfg({ shape: 'box', size: { x: 5, y: 1, z: 1 } });
    const next = applyPhysicsPatch(explicit, { size: undefined });
    expect(next.size).toBeUndefined();
    expect(Object.keys(diffPhysics(explicit, next))).toEqual(['physics.size']);
    expect(autoLocalSize(next, ctx())).toEqual({ x: 2, y: 1, z: 2 });
  });
  it('cilindro/cápsula esticados só em Y (X = Z) são EXATOS: sem aviso; X ≠ Z avisa', () => {
    expect(resolveCollider(cfg({ shape: 'cylinder' }), ctx({ scale: { x: 0.8, y: 4, z: 0.8 } }))!.warnings).not.toContain('nonuniform_scale');
    expect(resolveCollider(cfg({ shape: 'capsule' }), ctx({ scale: { x: 1, y: 2, z: 1 } }))!.warnings).not.toContain('nonuniform_scale');
    expect(resolveCollider(cfg({ shape: 'cylinder' }), ctx({ scale: { x: 1, y: 1, z: 2 } }))!.warnings).toContain('nonuniform_scale');
  });
  it('escala não uniforme em esfera/cápsula usa o maior eixo e avisa uma vez', () => {
    const s = resolveCollider(cfg({ shape: 'sphere' }), ctx({ scale: { x: 1, y: 3, z: 1 } }))!;
    expect(s.warnings).toContain('nonuniform_scale');
    expect(s.size.x).toBe(s.size.y);
  });
});

describe('AIS-26b-C05 — estados inválidos não existem', () => {
  it('malha exata só em "Sólido parado"', () => {
    expect(isShapeAllowed('mesh', 'static')).toBe(true);
    expect(isShapeAllowed('mesh', 'dynamic')).toBe(false);
    const dyn = cfg({ bodyMode: 'dynamic', shape: 'box' });
    expect(applyPhysicsPatch(dyn, { shape: 'mesh' }).shape).toBe('box');
  });
  it('trocar o tipo de uma malha exata troca a forma para auto, no mesmo patch/Undo', () => {
    const mesh = cfg({ bodyMode: 'static', shape: 'mesh' });
    const next = applyPhysicsPatch(mesh, { bodyMode: 'dynamic' });
    expect(next).toMatchObject({ bodyMode: 'dynamic', shape: 'auto' });
    expect(Object.keys(diffPhysics(mesh, next)).sort()).toEqual(['physics.bodyMode', 'physics.shape']);
  });
  it('personagem força a cápsula e nunca é dynamic', () => {
    const next = applyPhysicsPatch(cfg({ shape: 'box' }), { bodyMode: 'character' });
    expect(next.shape).toBe('capsule');
    expect(next.bodyMode).not.toBe('dynamic');
    expect(applyPhysicsPatch(next, { shape: 'box' }).shape).toBe('capsule');
  });
  it('floats só em dynamic; valores são limitados', () => {
    expect(applyPhysicsPatch(cfg({ bodyMode: 'dynamic', floats: true }), { bodyMode: 'static' }).floats).toBeUndefined();
    const n = applyPhysicsPatch(cfg(), { friction: 3, bounce: -1, layer: 999, mask: -4 });
    expect(n).toMatchObject({ friction: 1, bounce: 0, layer: 255, mask: 0 });
  });
});

describe('AIS-26b-C06 — wireframe', () => {
  it('uma LineSegments por colisor, tracejada quando desligada, nunca selecionável', () => {
    const spec = resolveCollider(cfg(), ctx())!;
    const on = buildColliderWireframe(spec, { bodyMode: 'static' });
    const off = buildColliderWireframe(spec, { bodyMode: 'static', disabled: true });
    expect(on.material).toBeInstanceOf(THREE.LineBasicMaterial);
    expect(off.material).toBeInstanceOf(THREE.LineDashedMaterial);
    const hits: THREE.Intersection[] = [];
    on.raycast(new THREE.Raycaster(), hits);
    expect(hits).toHaveLength(0);
    expect(colliderSignature(spec, { bodyMode: 'static' })).not.toBe(colliderSignature(spec, { bodyMode: 'dynamic' }));
  });
  it('as 6 formas geram geometria', () => {
    for (const shape of ['box', 'sphere', 'capsule', 'cylinder', 'mesh'] as const) {
      const spec = resolveCollider(cfg({ shape }), ctx())!;
      expect(buildColliderWireframe(spec, { bodyMode: 'static' }).geometry.getAttribute('position').count).toBeGreaterThan(0);
    }
  });
});

describe('AIS-26b-C07 — Adicionar com colisão: nó + bloco em um só Undo', () => {
  it('addNode com physics inicial cria tudo num Command; sem a caixa cria só o nó', () => {
    const scene = createEmptyScene();
    const root = scene.rootNodeId;
    scene.nodes = { [root]: { id: root, name: 'root', type: 'Spatial', parentId: null, childrenIds: [], visible: true, locked: false, properties: {} } as GameNode };
    const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene);
    const manager = new CommandManager();
    const mk = (id: string, properties: Record<string, any>) =>
      ({ id, name: id, type: 'MeshInstance', parentId: null, childrenIds: [], visible: true, locked: false, properties }) as GameNode;
    manager.execute(createAddNodeCommand({ target: model, node: mk('c1', { physics: defaultPhysicsConfig() }), parentId: root }));
    manager.execute(createAddNodeCommand({ target: model, node: mk('c2', {}), parentId: root }));
    expect(readPhysics(model.getScene().nodes.c1.properties)).toEqual({ enabled: true, bodyMode: 'static', shape: 'auto' });
    expect(readPhysics(model.getScene().nodes.c2.properties)).toBeNull();
    manager.undo();
    manager.undo();
    expect(model.getScene().nodes.c1).toBeUndefined();
    expect(defaultPhysicsConfig().bodyMode).not.toBe('dynamic');
  });
});

describe('AIS-26b-C08 — legados eliminados e migrados', () => {
  const raw = (id: string, type: string, parentId: string | null, childrenIds: string[], properties: Record<string, any> = {}) =>
    ({ id, name: id, type, parentId, childrenIds, visible: true, locked: false, properties });

  it('os cinco tipos legados não existem mais no registry', () => {
    for (const t of ['StaticBody', 'RigidBody', 'KinematicBody', 'Area', 'CollisionShape']) expect(NODE_DEFINITIONS).not.toHaveProperty(t);
  });
  it('StaticBody + CollisionShape (caixa) vira Spatial com physics; extents × 2; o filho some', () => {
    const nodes = {
      r: raw('r', 'Spatial', null, ['b']),
      b: raw('b', 'StaticBody', 'r', ['s'], { position: { x: 1, y: 0, z: 0 }, friction: 0.7, collisionLayer: 2, collisionMask: 4 }),
      s: raw('s', 'CollisionShape', 'b', [], { shapeType: 'BoxShape', extents: { x: 1, y: 0.5, z: 2 }, position: { x: 0, y: 0.5, z: 0 } }),
    };
    const { nodes: out, report } = convertLegacyPhysicsNodes(nodes);
    expect(report).toEqual({ converted: 1, unconverted: [] });
    expect(out.s).toBeUndefined();
    expect(out.b.type).toBe('Spatial');
    expect(out.b.childrenIds).toEqual([]);
    expect(out.b.properties.position).toEqual({ x: 1, y: 0, z: 0 });
    expect(out.b.properties.physics).toEqual({
      enabled: true, bodyMode: 'static', shape: 'box', size: { x: 2, y: 1, z: 4 }, offset: { x: 0, y: 0.5, z: 0 }, friction: 0.7, layer: 2, mask: 4,
    });
    expect(readPhysics(out.b.properties)).not.toBeNull();
  });
  it('RigidBody(dynamic) + esfera; Area sem filho vira gatilho esférico; KinematicBody vira kinematic', () => {
    const nodes = {
      r: raw('r', 'Spatial', null, ['b', 'a', 'k', 'ks']),
      b: raw('b', 'RigidBody', 'r', ['s'], { bodyMode: 'dynamic', mass: 3, restitution: 0.4 }),
      s: raw('s', 'CollisionShape', 'b', [], { shapeType: 'SphereShape', radius: 0.75 }),
      a: raw('a', 'Area', 'r', [], { radius: 2 }),
      k: raw('k', 'KinematicBody', 'r', ['ks']),
      ks: raw('ks', 'CollisionShape', 'k', [], { shapeType: 'CapsuleShape', radius: 0.5, height: 1 }),
    };
    const { nodes: out } = convertLegacyPhysicsNodes(nodes);
    expect(out.b.properties.physics).toMatchObject({ bodyMode: 'dynamic', shape: 'sphere', size: { x: 1.5, y: 1.5, z: 1.5 }, mass: 3, bounce: 0.4 });
    expect(out.a.properties.physics).toMatchObject({ bodyMode: 'trigger', shape: 'sphere', size: { x: 4, y: 4, z: 4 } });
    expect(out.k.properties.physics).toMatchObject({ bodyMode: 'kinematic', shape: 'capsule', size: { x: 1, y: 2, z: 1 } });
    for (const id of ['b', 'a', 'k']) expect(readPhysics(out[id].properties)).not.toBeNull();
  });
  it('o que não converte (CollisionShape órfão, rotacionado, corpo sem forma) vira Missing e é regravado intacto', () => {
    const nodes = {
      r: raw('r', 'Spatial', null, ['orphan', 'b']),
      orphan: raw('orphan', 'CollisionShape', 'r', [], { shapeType: 'BoxShape' }),
      b: raw('b', 'RigidBody', 'r', ['s'], {}),
      s: raw('s', 'CollisionShape', 'b', [], { shapeType: 'BoxShape', rotation: { x: 0, y: 45, z: 0 } }),
    };
    const scene = { nodes };
    expect(legacyPhysicsWarning(convertLegacyPhysics(scene).nodes as any)).toMatch(/physics\.legacy_unconverted: 3/);
    const normalized = normalizeUnknownNodes(scene) as any;
    expect(collectMissingTypes(normalized.nodes)).toEqual({ count: 3, types: ['CollisionShape', 'RigidBody'] });
    const restored = withRestoredMissingNodes(normalized);
    expect(restored.nodes).toEqual(nodes);
  });
  it('sem legado: mesma referência (custo zero)', () => {
    const scene = { nodes: { r: raw('r', 'Spatial', null, []) } };
    expect(convertLegacyPhysics(scene)).toBe(scene);
  });
  it('normalizeUnknownNodes (todo carregamento de cena/prefab) migra antes de virar Missing', () => {
    const scene = { nodes: { b: raw('b', 'StaticBody', null, ['s']), s: raw('s', 'CollisionShape', 'b', [], { shapeType: 'BoxShape' }) } };
    const out = normalizeUnknownNodes(scene) as any;
    expect(out.nodes.b.type).toBe('Spatial');
    expect(Object.keys(out.nodes)).toEqual(['b']);
  });
});

describe('measureLocalBounds', () => {
  it('mede no espaço LOCAL do nó (o filho herda a escala do pai)', () => {
    const root = new THREE.Group();
    root.scale.set(3, 3, 3);
    root.position.set(10, 0, 0);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(2, 4, 1));
    mesh.position.set(0, 2, 0);
    root.add(mesh);
    const b = measureLocalBounds(root)!;
    expect(b.size.x).toBeCloseTo(2, 5);
    expect(b.size.y).toBeCloseTo(4, 5);
    expect(b.size.z).toBeCloseTo(1, 5);
    expect(b.center.y).toBeCloseTo(2, 5);
  });
  it('devolve null sem malha', () => {
    expect(measureLocalBounds(new THREE.Group())).toBeNull();
  });
});
