import * as THREE from 'three';
import type { PhysicsBodyMode } from '../../types/node';
import type { ColliderSpec } from './resolveCollider';

/** Cor por tipo de corpo (AIS-26b "Mostrar colisores"). */
export const COLLIDER_COLOR: Record<PhysicsBodyMode, number> = {
  static: 0x22d3ee,
  dynamic: 0x4ade80,
  kinematic: 0xfacc15,
  character: 0xa78bfa,
  trigger: 0xf472b6,
};

export interface WireframeStyle {
  bodyMode: PhysicsBodyMode;
  /** Colisão desligada: desenhada tracejada. */
  disabled?: boolean;
}

/** Chave estável: só reconstrói a geometria quando o desenho muda (a pose é copiada por quadro, fora daqui). */
export function colliderSignature(spec: ColliderSpec, style: WireframeStyle): string {
  const r = (n: number) => Math.round(n * 1000) / 1000;
  return [spec.kind, r(spec.size.x), r(spec.size.y), r(spec.size.z), r(spec.offset.x), r(spec.offset.y), r(spec.offset.z), style.bodyMode, style.disabled ? 'off' : 'on'].join('|');
}

function baseGeometry(spec: ColliderSpec): THREE.BufferGeometry {
  const { x, y, z } = spec.size;
  switch (spec.kind) {
    case 'sphere':
      return new THREE.WireframeGeometry(new THREE.SphereGeometry(x / 2, 16, 10));
    case 'cylinder':
      return new THREE.WireframeGeometry(new THREE.CylinderGeometry(x / 2, x / 2, y, 16, 1));
    case 'capsule': {
      const radius = x / 2;
      return new THREE.WireframeGeometry(new THREE.CapsuleGeometry(radius, Math.max(0, y - 2 * radius), 4, 12));
    }
    default: // box, mesh e heightfield: caixa do AABB (aproximação de edição)
      return new THREE.EdgesGeometry(new THREE.BoxGeometry(x, y, z));
  }
}

/**
 * Wireframe do colisor no espaço do nó (origem do nó + `offset`). Pura sobre `ColliderSpec`: o mesmo desenho no
 * editor, no Play e no overlay de debug (AIS-77). Nunca altera dados.
 */
export function buildColliderWireframe(spec: ColliderSpec, style: WireframeStyle): THREE.LineSegments {
  const geometry = baseGeometry(spec);
  const color = COLLIDER_COLOR[style.bodyMode];
  const material = style.disabled
    ? new THREE.LineDashedMaterial({ color, dashSize: 0.12, gapSize: 0.08, depthTest: false, transparent: true, opacity: 0.7 })
    : new THREE.LineBasicMaterial({ color, depthTest: false, transparent: true, opacity: 0.9 });
  const lines = new THREE.LineSegments(geometry, material);
  if (style.disabled) lines.computeLineDistances();
  lines.position.set(spec.offset.x, spec.offset.y, spec.offset.z);
  lines.renderOrder = 999;
  lines.name = 'collider-wireframe';
  lines.raycast = () => {}; // nunca selecionável nem bloqueia o clique
  lines.userData.isEditorHelper = true;
  return lines;
}
