import type * as RapierTypes from '@dimforge/rapier3d-compat';
import type { PhysicsBodyMode } from '../../types/node';
import type { Vec3 } from './bounds';
import { createPhysicsBody } from './createPhysicsBody';
import type { PhysicsBodyDescriptor, Quat } from './physicsDescriptor';
import type { RapierModule } from './rapierInit';

/**
 * AIS-45 — PhysicsBridge: a ÚNICA fachada de runtime do mundo físico (camadas D/E do núcleo Rapier). Behaviors, Actions,
 * controladores e scripts NUNCA recebem `RigidBody`/`Collider` do Rapier: toda operação passa por aqui, que valida a sessão
 * ativa, a existência do corpo, o `bodyMode`, os parâmetros e a autoridade da pose. O mundo só existe durante uma
 * `RuntimeSession` (criado no Play, `dispose()` no Stop/troca de cena; em edição não há mundo).
 *
 * Contrato por `bodyMode` (um corpo por GameNode):
 *  - `dynamic`   — o Rapier resolve posição e rotação; o corpo é o dono da pose (sem write-back no authoring).
 *  - `kinematic` — a pose pedida pelo runtime (`PoseSource`) é a autoridade; o corpo só segue.
 *  - `trigger`   — como `kinematic`, com `sensor:true`: sem resposta sólida, só eventos de entrada/saída.
 *  - `character` — NUNCA `dynamic`: `KinematicCharacterController` antes do passo. A intenção de movimento é a diferença entre
 *                  a pose pedida e a última pose física; a gravidade e a colisão são resolvidas aqui.
 *  - `static`    — fixo.
 *
 * Passo fixo (acumulador de 1/60 s; nunca `dt` variável direto no Rapier). Erros de operação são `PhysicsBridgeError` com
 * código estável (`physics.no_body`, `physics.incompatible_body_mode`, `physics.body_disabled`, `physics.invalid_params`,
 * `physics.session_disposed`): quem chama (as Actions) loga com contexto, nunca ignora em silêncio.
 */

/** Limite inferior padrão do mundo (m): corpo `dynamic`/`character` abaixo dele é descartado (Kill Floor, AIS-49). */
export const DEFAULT_KILL_FLOOR_Y = -50;

export type PhysicsEventName = 'collisionEnter' | 'collisionExit' | 'triggerEnter' | 'triggerExit' | 'killFloor';

export interface PhysicsEvent {
  name: PhysicsEventName;
  /** O corpo "dono" do evento e o outro participante (um evento por participante). */
  selfId: string;
  otherId: string;
  /** Só em `collisionEnter`: força de contato (N) do passo em que o contato começou (0 se o Rapier não reportou). */
  force?: number;
  /**
   * Só em `collisionEnter` (AIS-48): ponto de contato MUNDIAL e normal MUNDIAL unitária apontando de `selfId` PARA `otherId`
   * (o evento do outro participante traz a normal oposta). Gatilhos (`trigger*`) e saídas não têm contato nem força.
   */
  contact?: { point: Vec3; normal: Vec3 };
  /** Só em `killFloor` (AIS-49): posição mundial do corpo no momento do aviso (`otherId` vem vazio). */
  position?: Vec3;
}

export class PhysicsBridgeError extends Error {
  constructor(
    public readonly code: 'physics.no_body' | 'physics.incompatible_body_mode' | 'physics.body_disabled' | 'physics.invalid_params' | 'physics.session_disposed',
    message: string
  ) {
    super(message);
    this.name = 'PhysicsBridgeError';
  }
}

/** Pose MUNDIAL que o runtime quer para um corpo controlado (kinematic/trigger/character). */
export type PoseSource = (nodeId: string) => { position: Vec3; rotation: Quat } | null;

export interface PhysicsBridgeOptions {
  gravity?: Vec3;
  /** Passo fixo em segundos (padrão 1/60). */
  fixedStep?: number;
  /** Teto de passos por chamada de `step` (evita a "espiral da morte" depois de um quadro longo). */
  maxSubSteps?: number;
  /** Kill Floor (AIS-49): Y mundial abaixo do qual corpos `dynamic`/`character` são descartados (padrão -50; `-Infinity` desliga). */
  killFloorY?: number;
}

interface Entry {
  descriptor: PhysicsBodyDescriptor;
  body: RapierTypes.RigidBody;
  collider: RapierTypes.Collider;
  controller: RapierTypes.KinematicCharacterController | null;
  enabled: boolean;
  /** character: velocidade vertical acumulada, velocidade "dirigida" (m/s) e última pose física aplicada. */
  vy: number;
  drive: Vec3;
  lastPos: Vec3;
  grounded: boolean;
  /** Recebeu força/torque contínuo neste quadro (zerado depois do passo). */
  pushed: boolean;
}

const isVec = (v: Vec3 | undefined): v is Vec3 => !!v && Number.isFinite(v.x) && Number.isFinite(v.y) && Number.isFinite(v.z);

function rotateByQuat(v: Vec3, q: Quat): Vec3 {
  // v' = q * v * q^-1
  const { x, y, z } = v;
  const ix = q.w * x + q.y * z - q.z * y;
  const iy = q.w * y + q.z * x - q.x * z;
  const iz = q.w * z + q.x * y - q.y * x;
  const iw = -q.x * x - q.y * y - q.z * z;
  return {
    x: ix * q.w + iw * -q.x + iy * -q.z - iz * -q.y,
    y: iy * q.w + iw * -q.y + iz * -q.x - ix * -q.z,
    z: iz * q.w + iw * -q.z + ix * -q.y - iy * -q.x,
  };
}

export class PhysicsBridge {
  private readonly R: RapierModule;
  private readonly world: RapierTypes.World;
  private readonly queue: RapierTypes.EventQueue;
  private readonly fixedStep: number;
  private readonly maxSubSteps: number;
  private readonly gravity: Vec3;
  private readonly killFloorY: number;
  private discarded: string[] = [];
  private readonly entries = new Map<string, Entry>();
  private readonly byCollider = new Map<number, string>();
  private readonly listeners = new Set<{ name: PhysicsEventName | '*'; cb: (e: PhysicsEvent) => void }>();
  private accumulator = 0;
  private disposed = false;

  constructor(R: RapierModule, options: PhysicsBridgeOptions = {}) {
    this.R = R;
    this.gravity = options.gravity ?? { x: 0, y: -9.8, z: 0 };
    this.fixedStep = options.fixedStep ?? 1 / 60;
    this.maxSubSteps = options.maxSubSteps ?? 5;
    this.killFloorY = Number.isFinite(options.killFloorY ?? DEFAULT_KILL_FLOOR_Y) || options.killFloorY === Number.NEGATIVE_INFINITY ? (options.killFloorY ?? DEFAULT_KILL_FLOOR_Y) : DEFAULT_KILL_FLOOR_Y;
    this.world = new R.World(this.gravity);
    this.world.timestep = this.fixedStep;
    this.queue = new R.EventQueue(true);
  }

  // ── corpos ────────────────────────────────────────────────────────────────────────────────────

  get isDisposed(): boolean {
    return this.disposed;
  }
  get bodyCount(): number {
    return this.entries.size;
  }
  has(nodeId: string): boolean {
    return this.entries.has(nodeId);
  }
  modeOf(nodeId: string): PhysicsBodyMode | undefined {
    return this.entries.get(nodeId)?.descriptor.bodyMode;
  }
  isEnabled(nodeId: string): boolean {
    return this.entries.get(nodeId)?.enabled ?? false;
  }
  /**
   * AIS-49 — sono do Rapier (`canSleep` é padrão do corpo; sem campo novo no bloco de Colisão). Corpo `dynamic` em repouso dorme no
   * `world.step()` e deixa de custar; força, impulso, teleporte ou contato de outro corpo o acordam sozinhos.
   */
  isSleeping(nodeId: string): boolean {
    const e = this.entries.get(nodeId);
    return !!e && e.enabled && e.descriptor.bodyMode === 'dynamic' && e.body.isSleeping();
  }
  /** Corpos `dynamic` ligados e ACORDADOS (o custo real do loop de corpos rígidos). */
  get activeBodyCount(): number {
    let n = 0;
    for (const e of this.entries.values()) if (e.enabled && e.descriptor.bodyMode === 'dynamic' && !e.body.isSleeping()) n++;
    return n;
  }
  /** Corpos `dynamic` ligados e dormindo. */
  get sleepingBodyCount(): number {
    let n = 0;
    for (const e of this.entries.values()) if (e.enabled && e.descriptor.bodyMode === 'dynamic' && e.body.isSleeping()) n++;
    return n;
  }
  /** IDs descartados pelo Kill Floor desde a última chamada (o host destrói as instâncias correspondentes). */
  takeDiscarded(): string[] {
    const out = this.discarded;
    this.discarded = [];
    return out;
  }

  isGrounded(nodeId: string): boolean {
    return this.entries.get(nodeId)?.grounded ?? false;
  }

  /** Cria o corpo do descritor (um por nó; recriar o mesmo nó substitui o anterior). */
  addBody(descriptor: PhysicsBodyDescriptor): void {
    this.assertAlive();
    this.remove(descriptor.nodeId);
    const created = createPhysicsBody(this.R, this.world, descriptor);
    const entry: Entry = { descriptor, ...created, enabled: true, vy: 0, drive: { x: 0, y: 0, z: 0 }, lastPos: { ...descriptor.position }, grounded: false, pushed: false };
    this.entries.set(descriptor.nodeId, entry);
    this.byCollider.set(created.collider.handle, descriptor.nodeId);
  }

  /** Malha exata (trimesh): só `static`. */
  addMesh(descriptor: PhysicsBodyDescriptor): void {
    if (descriptor.collider.kind !== 'mesh' || !descriptor.trimesh) throw new PhysicsBridgeError('physics.invalid_params', `"${descriptor.name}": addMesh exige forma "mesh" com geometria.`);
    if (descriptor.bodyMode !== 'static') throw new PhysicsBridgeError('physics.incompatible_body_mode', `"${descriptor.name}": Malha exata só funciona em corpo static.`);
    this.addBody(descriptor);
  }

  /** Campo de alturas do terreno (o MESMO `Float32Array` do terreno, decisão 23). */
  addHeightfield(descriptor: PhysicsBodyDescriptor): void {
    if (descriptor.collider.kind !== 'heightfield' || !descriptor.heightfield) throw new PhysicsBridgeError('physics.invalid_params', `"${descriptor.name}": addHeightfield exige forma "heightfield" com alturas.`);
    this.addBody(descriptor);
  }

  remove(nodeId: string): void {
    const entry = this.entries.get(nodeId);
    if (!entry) return;
    this.byCollider.delete(entry.collider.handle);
    if (entry.controller) this.world.removeCharacterController(entry.controller);
    this.world.removeRigidBody(entry.body);
    this.entries.delete(nodeId);
  }

  // ── passo ─────────────────────────────────────────────────────────────────────────────────────

  /**
   * Avança a simulação por `dt` segundos de jogo (passo fixo). Devolve quantos passos fixos rodaram; com `0` nada mudou (as
   * poses continuam as do passo anterior). Eventos são entregues aos assinantes DEPOIS de cada passo.
   */
  step(dt: number, poseSource?: PoseSource): number {
    if (this.disposed) return 0;
    const delta = Number.isFinite(dt) && dt > 0 ? Math.min(dt, 0.25) : 0;
    this.accumulator += delta;
    let steps = Math.floor(this.accumulator / this.fixedStep + 1e-9);
    if (steps === 0) return 0;
    if (steps > this.maxSubSteps) {
      steps = this.maxSubSteps;
      this.accumulator = 0;
    } else {
      this.accumulator -= steps * this.fixedStep;
    }
    const elapsed = steps * this.fixedStep;

    for (const entry of this.entries.values()) {
      if (!entry.enabled) continue;
      const mode = entry.descriptor.bodyMode;
      const wanted = poseSource?.(entry.descriptor.nodeId) ?? null;
      if (mode === 'kinematic' || mode === 'trigger') {
        if (wanted) {
          entry.body.setNextKinematicTranslation(wanted.position);
          entry.body.setNextKinematicRotation(wanted.rotation);
        }
      } else if (mode === 'character') {
        this.moveCharacter(entry, wanted, elapsed);
      }
    }

    for (let i = 0; i < steps; i++) {
      this.world.step(this.queue);
      this.drainEvents();
    }
    this.enforceKillFloor();
    for (const entry of this.entries.values()) {
      if (!entry.pushed) continue;
      entry.body.resetForces(false);
      entry.body.resetTorques(false);
      entry.pushed = false;
    }
    return steps;
  }

  private moveCharacter(entry: Entry, wanted: { position: Vec3; rotation: Quat } | null, dt: number): void {
    const controller = entry.controller;
    if (!controller) return;
    // intenção do runtime (Behaviors só emitem intenção): quanto a pose pedida se afastou da última pose física
    const intent = wanted ? { x: wanted.position.x - entry.lastPos.x, y: wanted.position.y - entry.lastPos.y, z: wanted.position.z - entry.lastPos.z } : { x: 0, y: 0, z: 0 };
    entry.vy = entry.grounded && entry.vy < 0 ? 0 : entry.vy + this.gravity.y * dt;
    const desired = { x: intent.x + entry.drive.x * dt, y: intent.y + (entry.vy + entry.drive.y) * dt, z: intent.z + entry.drive.z * dt };
    controller.computeColliderMovement(entry.collider, desired);
    const move = controller.computedMovement();
    entry.grounded = controller.computedGrounded();
    if (entry.grounded && desired.y <= 0) entry.vy = 0;
    const t = entry.body.translation();
    const next = { x: t.x + move.x, y: t.y + move.y, z: t.z + move.z };
    entry.body.setNextKinematicTranslation(next);
    if (wanted) entry.body.setNextKinematicRotation(wanted.rotation);
    entry.lastPos = next;
  }

  private drainEvents(): void {
    const forces = new Map<string, number>();
    const key = (a: number, b: number) => (a < b ? `${a}:${b}` : `${b}:${a}`);
    this.queue.drainContactForceEvents((e) => {
      const k = key(e.collider1(), e.collider2());
      forces.set(k, Math.max(forces.get(k) ?? 0, e.totalForceMagnitude()));
    });
    this.queue.drainCollisionEvents((h1, h2, started) => {
      const a = this.byCollider.get(h1);
      const b = this.byCollider.get(h2);
      if (!a || !b) return;
      const sensor = this.entries.get(a)?.descriptor.bodyMode === 'trigger' || this.entries.get(b)?.descriptor.bodyMode === 'trigger';
      const name: PhysicsEventName = sensor ? (started ? 'triggerEnter' : 'triggerExit') : started ? 'collisionEnter' : 'collisionExit';
      const force = name === 'collisionEnter' ? (forces.get(key(h1, h2)) ?? 0) : undefined;
      const contact = name === 'collisionEnter' ? this.contactBetween(a, b) : undefined;
      this.emit({ name, selfId: a, otherId: b, force, contact });
      this.emit({ name, selfId: b, otherId: a, force, contact: contact && { point: { ...contact.point }, normal: { x: -contact.normal.x, y: -contact.normal.y, z: -contact.normal.z } } });
    });
  }

  /** Ponto e normal (de `a` para `b`) do contato recém-criado; sem manifold (contato já desfeito), aproxima pelos centros. */
  private contactBetween(aId: string, bId: string): { point: Vec3; normal: Vec3 } | undefined {
    const a = this.entries.get(aId);
    const b = this.entries.get(bId);
    if (!a || !b) return undefined;
    let found: { point: Vec3; normal: Vec3 } | undefined;
    this.world.contactPair(a.collider, b.collider, (manifold, flipped) => {
      if (found || manifold.numSolverContacts() === 0) return;
      const n = manifold.normal();
      const p = manifold.solverContactPoint(0);
      if (!p) return;
      const s = flipped ? -1 : 1; // normal do manifold: do 1º collider do PAR ao 2º; flipped = o par está invertido
      found = { point: { x: p.x, y: p.y, z: p.z }, normal: { x: n.x * s, y: n.y * s, z: n.z * s } };
    });
    if (found) return found;
    const pa = a.body.translation();
    const pb = b.body.translation();
    const d = { x: pb.x - pa.x, y: pb.y - pa.y, z: pb.z - pa.z };
    const len = Math.hypot(d.x, d.y, d.z) || 1;
    return { point: { x: (pa.x + pb.x) / 2, y: (pa.y + pb.y) / 2, z: (pa.z + pb.z) / 2 }, normal: { x: d.x / len, y: d.y / len, z: d.z / len } };
  }

  private emit(event: PhysicsEvent): void {
    for (const l of [...this.listeners]) {
      if (l.name !== '*' && l.name !== event.name) continue;
      try {
        l.cb(event);
      } catch {
        // um assinante com defeito não derruba o mundo nem os outros assinantes
      }
    }
  }

  /** `EngineApi.onPhysicsEvent(name, cb) → unsubscribe` (`'*'` = todos). Nunca configuração de Inspector. */
  onPhysicsEvent(name: PhysicsEventName | '*', cb: (e: PhysicsEvent) => void): () => void {
    const l = { name, cb };
    this.listeners.add(l);
    return () => {
      this.listeners.delete(l);
    };
  }

  // ── pose (o corpo é o dono; nunca gravada no authoring) ───────────────────────────────────────

  getPose(nodeId: string): { position: Vec3; rotation: Quat; linearVelocity: Vec3 } | undefined {
    const entry = this.entries.get(nodeId);
    if (!entry) return undefined;
    const p = entry.body.translation();
    const r = entry.body.rotation();
    const v = entry.body.linvel();
    return { position: { x: p.x, y: p.y, z: p.z }, rotation: { x: r.x, y: r.y, z: r.z, w: r.w }, linearVelocity: { x: v.x, y: v.y, z: v.z } };
  }

  /** Corpos cuja pose é DO Rapier (a sessão copia para a instância de runtime depois do passo). */
  forEachSimulated(fn: (nodeId: string, pose: { position: Vec3; rotation: Quat }) => void): void {
    for (const [nodeId, entry] of this.entries) {
      const mode = entry.descriptor.bodyMode;
      if (!entry.enabled || (mode !== 'dynamic' && mode !== 'character')) continue;
      const p = entry.body.translation();
      const r = entry.body.rotation();
      fn(nodeId, { position: { x: p.x, y: p.y, z: p.z }, rotation: { x: r.x, y: r.y, z: r.z, w: r.w } });
    }
  }

  // ── operações das Actions (todas validadas) ───────────────────────────────────────────────────

  private entry(nodeId: string, label: string, allowed: readonly PhysicsBodyMode[], options: { allowDisabled?: boolean } = {}): Entry {
    if (this.disposed) throw new PhysicsBridgeError('physics.session_disposed', `${label}: a simulação já foi encerrada.`);
    const entry = this.entries.get(nodeId);
    if (!entry) throw new PhysicsBridgeError('physics.no_body', `${label}: o nó não tem corpo físico (ative "Colisão" no Inspector).`);
    if (!allowed.includes(entry.descriptor.bodyMode)) {
      throw new PhysicsBridgeError('physics.incompatible_body_mode', `${label} não funciona em corpo "${entry.descriptor.bodyMode}" (${entry.descriptor.name}); use ${allowed.map((m) => `"${m}"`).join(' ou ')}.`);
    }
    if (!entry.enabled && !options.allowDisabled) throw new PhysicsBridgeError('physics.body_disabled', `${label}: o corpo físico de "${entry.descriptor.name}" está desligado.`);
    return entry;
  }

  private vector(label: string, v: Vec3 | undefined): Vec3 {
    if (!isVec(v)) throw new PhysicsBridgeError('physics.invalid_params', `${label}: vetor inválido.`);
    return v;
  }

  private inSpace(entry: Entry, v: Vec3, space: 'world' | 'local'): Vec3 {
    return space === 'local' ? rotateByQuat(v, entry.body.rotation()) : v;
  }

  /**
   * Kill Floor: `dynamic`/`character` abaixo do limite inferior emitem `killFloor` ANTES de serem descartados (os assinantes podem
   * reagir, ex.: teleportar de volta); se continuar abaixo depois do evento, o corpo é removido e entra em `takeDiscarded()`.
   */
  private enforceKillFloor(): void {
    for (const [nodeId, entry] of [...this.entries]) {
      const mode = entry.descriptor.bodyMode;
      if (!entry.enabled || (mode !== 'dynamic' && mode !== 'character')) continue;
      const p = entry.body.translation();
      if (!(p.y < this.killFloorY)) continue;
      this.emit({ name: 'killFloor', selfId: nodeId, otherId: '', position: { x: p.x, y: p.y, z: p.z } });
      const still = this.entries.get(nodeId);
      if (!still || !(still.body.translation().y < this.killFloorY)) continue; // um assinante o removeu ou o resgatou
      this.remove(nodeId);
      this.discarded.push(nodeId);
    }
  }

  /** Força contínua (vale até o fim do próximo passo; chame a cada quadro para sustentar). Só `dynamic`. */
  addForce(nodeId: string, force: Vec3, space: 'world' | 'local' = 'world'): void {
    const e = this.entry(nodeId, 'Add Force', ['dynamic']);
    e.body.addForce(this.inSpace(e, this.vector('Add Force', force), space), true);
    e.pushed = true;
  }

  addImpulse(nodeId: string, impulse: Vec3, space: 'world' | 'local' = 'world'): void {
    const e = this.entry(nodeId, 'Add Impulse', ['dynamic']);
    e.body.applyImpulse(this.inSpace(e, this.vector('Add Impulse', impulse), space), true);
  }

  setLinearVelocity(nodeId: string, velocity: Vec3, space: 'world' | 'local' = 'world'): void {
    const e = this.entry(nodeId, 'Set Linear Velocity', ['dynamic', 'character']);
    const v = this.inSpace(e, this.vector('Set Linear Velocity', velocity), space);
    if (e.descriptor.bodyMode === 'character') {
      e.drive = { x: v.x, y: 0, z: v.z };
      e.vy = v.y;
    } else e.body.setLinvel(v, true);
  }

  setAngularVelocity(nodeId: string, velocity: Vec3): void {
    const e = this.entry(nodeId, 'Set Angular Velocity', ['dynamic']);
    e.body.setAngvel(this.vector('Set Angular Velocity', velocity), true);
  }

  applyTorque(nodeId: string, torque: Vec3, mode: 'continuous' | 'impulse' = 'continuous', space: 'world' | 'local' = 'world'): void {
    const e = this.entry(nodeId, 'Apply Torque', ['dynamic']);
    const t = this.inSpace(e, this.vector('Apply Torque', torque), space);
    if (mode === 'impulse') e.body.applyTorqueImpulse(t, true);
    else {
      e.body.addTorque(t, true);
      e.pushed = true;
    }
  }

  /** Reposiciona (pose MUNDIAL); `clearVelocities` zera velocidades e a queda acumulada. Vale para qualquer `bodyMode`. */
  teleport(nodeId: string, position: Vec3, clearVelocities = true): void {
    const e = this.entry(nodeId, 'Teleport Physics Body', ['static', 'dynamic', 'kinematic', 'character', 'trigger']);
    const p = this.vector('Teleport Physics Body', position);
    e.body.setTranslation(p, true);
    if (e.descriptor.bodyMode === 'kinematic' || e.descriptor.bodyMode === 'trigger' || e.descriptor.bodyMode === 'character') e.body.setNextKinematicTranslation(p);
    e.lastPos = { ...p };
    if (clearVelocities) {
      e.body.setLinvel({ x: 0, y: 0, z: 0 }, true);
      e.body.setAngvel({ x: 0, y: 0, z: 0 }, true);
      e.vy = 0;
      e.drive = { x: 0, y: 0, z: 0 };
    }
  }

  /** Liga/desliga o corpo sem remover a GameNode. */
  setEnabled(nodeId: string, enabled: boolean): void {
    const e = this.entry(nodeId, 'Set Physics Enabled', ['static', 'dynamic', 'kinematic', 'character', 'trigger'], { allowDisabled: true });
    e.body.setEnabled(enabled);
    e.enabled = enabled;
    if (enabled) e.lastPos = { ...e.body.translation() };
  }

  setMaterial(nodeId: string, friction: number, bounce: number): void {
    const e = this.entry(nodeId, 'Set Physics Material', ['static', 'dynamic', 'kinematic', 'character']);
    if (!Number.isFinite(friction) || !Number.isFinite(bounce)) throw new PhysicsBridgeError('physics.invalid_params', 'Set Physics Material: valores inválidos.');
    e.collider.setFriction(Math.min(1, Math.max(0, friction)));
    e.collider.setRestitution(Math.min(1, Math.max(0, bounce)));
  }

  // ── ciclo de vida ─────────────────────────────────────────────────────────────────────────────

  /** `world.free()` + fila de eventos liberada; idempotente. Depois disto toda operação falha com `physics.session_disposed`. */
  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.listeners.clear();
    this.entries.clear();
    this.byCollider.clear();
    this.queue.free();
    this.world.free();
  }

  private assertAlive(): void {
    if (this.disposed) throw new PhysicsBridgeError('physics.session_disposed', 'A simulação física já foi encerrada.');
  }
}

