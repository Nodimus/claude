/**
 * AIS-44d — campos de `project.settings` que AINDA não têm leitor (decisão 14: recurso não implementado aparece desabilitado
 * com tooltip "em breve", nunca como controle que finge funcionar). O AIS-32b grava todos os campos; cada um tem UM prompt
 * dono que o lê (tabela "Dono de cada campo de `settings`" da `ORDEM-CANONICA-V4.md`). Quando o prompt dono entregar o
 * leitor, ele REMOVE a linha daqui e o campo volta a ser editável no modal. Os valores gravados permanecem e são preservados.
 *
 * Já têm leitor (editáveis): `physics.defaultLinearDamp` (AIS-45, `PhysicsBridge`), `rendering.shadowsEnabled`, `shadowQuality`, `clearColor`, `hdr` e `display.width/height`
 * (AIS-44d, via `resolveRenderSettings`); `rendering.msaa` é lido ao abrir o projeto (limitação até o AIS-55).
 */
export const SETTINGS_WITHOUT_READER: Readonly<Record<string, string>> = {
  'display.windowMode': 'AIS-85c / AIS-85',
  'display.resizable': 'AIS-85c',
  'display.orientation': 'AIS-85c',
  'rendering.vsync': 'AIS-85c',
  'audio.masterVolume': 'AIS-52',
  'audio.musicVolume': 'AIS-52',
  'audio.sfxVolume': 'AIS-52',
};

/** Dono do leitor de um campo (`display.windowMode`…), ou `undefined` se o campo já tem leitor. */
export const readerOwnerOf = (fieldPath: string): string | undefined => SETTINGS_WITHOUT_READER[fieldPath];

/** Tooltip do campo desabilitado; `undefined` quando o campo é editável. */
export const pendingReaderTooltip = (fieldPath: string): string | undefined => {
  const owner = readerOwnerOf(fieldPath);
  return owner ? `em breve — ${owner}` : undefined;
};
