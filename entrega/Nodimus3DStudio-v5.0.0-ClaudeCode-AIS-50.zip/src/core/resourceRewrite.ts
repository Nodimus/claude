import { stringifyCompact } from './serialization/sceneSerializer';

/**
 * AIS-29e — reescrita de referências dentro de arquivos de recurso. Funções PURAS (texto in → texto out), usadas pelo
 * serviço `resourceDeletion` ao mover, excluir (mantendo referências não resolvidas) e substituir recursos.
 *
 * - MOVER: troca de caminho em texto (preserva a formatação do arquivo byte a byte; o `ResourceRef.id` não muda, só o
 *   `path`; ids antigos `res:<caminho>` acompanham o novo caminho).
 * - EXCLUIR mantendo referências: o `ResourceRef` fica no arquivo com `unresolved: true` (nunca é apagado).
 * - SUBSTITUIR: o `ResourceRef` passa a apontar para o recurso escolhido.
 */

type AnyRecord = Record<string, any>;
const isRecord = (v: unknown): v is AnyRecord => typeof v === 'object' && v !== null && !Array.isArray(v);

const escapeRegExp = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/** Um recurso (id estável + caminho atual) que as regras reconhecem dentro de `ResourceRef`s. */
export interface ResourceIdentity {
  id: string | null;
  uri: string;
}

/** `ResourceRef` (objeto com id estável, caminho `res://` ou id legado `res:<caminho>`) que cita o recurso? */
export function refMatches(ref: AnyRecord, resource: ResourceIdentity): boolean {
  if (typeof ref.id !== 'string') return false;
  if (resource.id && ref.id === resource.id) return true;
  if (ref.id === `res:${resource.uri}`) return true;
  return typeof ref.path === 'string' && ref.path === resource.uri;
}

/** Heurística de `ResourceRef` (a mesma do extrator de dependências): id estável/legado + type/path/label. */
export function looksLikeResourceRef(value: AnyRecord): boolean {
  return (
    typeof value.id === 'string' &&
    (typeof value.path === 'string' || value.id.startsWith('res:') || /^res_[a-z0-9]+$/i.test(value.id)) &&
    ('type' in value || 'path' in value || 'label' in value)
  );
}

export interface JsonRewriteRules {
  /** Recebe um `ResourceRef`; devolve o novo objeto, ou `undefined` para não mexer. */
  ref?: (ref: AnyRecord) => AnyRecord | undefined;
  /** Recebe uma string que é um caminho `res://…` inteiro; devolve o novo caminho, ou `undefined`. */
  uri?: (uri: string) => string | undefined;
}

export function rewriteJsonValue(value: unknown, rules: JsonRewriteRules): { value: unknown; changed: boolean } {
  let changed = false;
  const walk = (v: unknown): unknown => {
    if (typeof v === 'string') {
      if (v.startsWith('res://') && rules.uri) {
        const next = rules.uri(v);
        if (next !== undefined && next !== v) {
          changed = true;
          return next;
        }
      }
      return v;
    }
    if (Array.isArray(v)) return v.map(walk);
    if (!isRecord(v)) return v;
    if (rules.ref && looksLikeResourceRef(v)) {
      const next = rules.ref(v);
      if (next) {
        changed = true;
        return next;
      }
    }
    const out: AnyRecord = {};
    for (const [key, child] of Object.entries(v)) out[key] = walk(child);
    return out;
  };
  const result = walk(value);
  return { value: result, changed };
}

/** Reescreve um arquivo JSON preservando o estilo (cena = compacto canônico; resto = 2 espaços). */
export function rewriteJsonContent(content: string, uri: string, rules: JsonRewriteRules): { content: string; changed: boolean } {
  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    return { content, changed: false };
  }
  const result = rewriteJsonValue(parsed, rules);
  if (!result.changed) return { content, changed: false };
  const text = uri.toLowerCase().endsWith('.scene.json') ? stringifyCompact(result.value) : JSON.stringify(result.value, null, 2);
  return { content: content.endsWith('\n') || uri.toLowerCase().endsWith('.scene.json') ? text + '\n' : text, changed: true };
}

/**
 * Troca de caminhos em TEXTO (qualquer arquivo): cada `de` vira `para` quando o trecho não é prefixo de um nome maior
 * (`res://a.png` não casa dentro de `res://a.png.bak`). Preserva a formatação byte a byte.
 */
export function replaceUrisInText(content: string, moves: readonly { from: string; to: string }[]): { content: string; changed: boolean } {
  let out = content;
  const ordered = [...moves].sort((a, b) => b.from.length - a.from.length); // mais específico primeiro
  for (const { from, to } of ordered) {
    if (from === to) continue;
    const pattern = from.endsWith('/') ? new RegExp(escapeRegExp(from), 'g') : new RegExp(`${escapeRegExp(from)}(?![A-Za-z0-9_.\\-/])`, 'g');
    out = out.replace(pattern, () => to);
  }
  return { content: out, changed: out !== content };
}

/** Regras para EXCLUIR mantendo as referências: o `ResourceRef` continua, marcado `unresolved: true`. */
export function unresolveRules(targets: readonly ResourceIdentity[]): JsonRewriteRules {
  return {
    ref: (ref) => {
      if (ref.unresolved === true) return undefined;
      return targets.some((t) => refMatches(ref, t)) ? { ...ref, unresolved: true } : undefined;
    },
  };
}

export interface ReplacementRef {
  id: string;
  type?: string;
  path: string;
  label?: string;
}

/** Regras para SUBSTITUIR um recurso por outro (do mesmo tipo): refs e caminhos passam a apontar para o novo. */
export function replaceRules(target: ResourceIdentity, replacement: ReplacementRef): JsonRewriteRules {
  return {
    ref: (ref) => {
      if (!refMatches(ref, target)) return undefined;
      const { unresolved: _drop, ...rest } = ref;
      return { ...rest, id: replacement.id, ...(replacement.type ? { type: replacement.type } : {}), path: replacement.path, ...(replacement.label ? { label: replacement.label } : {}) };
    },
    uri: (uri) => (uri === target.uri ? replacement.path : undefined),
  };
}
