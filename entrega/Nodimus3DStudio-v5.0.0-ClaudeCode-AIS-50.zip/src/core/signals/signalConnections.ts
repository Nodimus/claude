import type { NodeSignalConnection, SignalArgument, SignalArgumentType } from '../../types/signal';

/**
 * AIS-27 — regras puras da aba de Sinais: nomes de método, argumentos tipados e duplicidade.
 * Sem React nem store; a UI e os Commands consomem estas funções.
 */

export const SIGNAL_ARGUMENT_TYPES: readonly SignalArgumentType[] = ['string', 'number', 'boolean', 'node'];

export const SIGNAL_ARGUMENT_LABEL: Record<SignalArgumentType, string> = {
  string: 'Texto',
  number: 'Número',
  boolean: 'Booleano',
  node: 'Nó',
};

/** Método alvo: identificador (letras, dígitos, `_`; não começa com dígito). */
export const METHOD_NAME_PATTERN = /^[A-Za-z_][A-Za-z0-9_]*$/;
export const isValidMethodName = (name: string): boolean => METHOD_NAME_PATTERN.test(name.trim());

/** Método padrão sugerido para um sinal (convenção Godot `_on_<sinal>`). */
export const defaultMethodFor = (signalName: string): string => `_on_${signalName}`;

/** Argumento digitado pelo usuário (sempre texto) → argumento tipado; `null` se inválido. */
export function parseSignalArgument(type: SignalArgumentType, raw: string): SignalArgument | null {
  const text = raw.trim();
  switch (type) {
    case 'string':
      return { type, value: raw };
    case 'number': {
      if (text === '') return null;
      const n = Number(text.replace(',', '.')); // vírgula decimal (pt-BR)
      return Number.isFinite(n) ? { type, value: n } : null;
    }
    case 'boolean':
      if (text === 'true') return { type, value: true };
      if (text === 'false') return { type, value: false };
      return null;
    case 'node':
      return text === '' ? null : { type, value: text };
  }
}

/** Valor de um argumento como texto editável. */
export const argumentToText = (arg: SignalArgument): string => (arg.value === null ? '' : String(arg.value));

export interface ConnectionDraft {
  signalName: string;
  targetNodeId: string;
  targetMethod: string;
  /** Argumentos como o usuário os digitou. */
  args: { type: SignalArgumentType; text: string }[];
}

export interface DraftResult {
  ok: boolean;
  errors: string[];
  /** Presente quando `ok`. */
  connection?: Omit<NodeSignalConnection, 'id'>;
}

/**
 * Valida o rascunho do modal. `existingNodeIds`: alvos válidos. Erros em português, um por problema, para exibição
 * acessível junto aos campos.
 */
export function buildConnectionFromDraft(draft: ConnectionDraft, existingNodeIds: ReadonlySet<string>): DraftResult {
  const errors: string[] = [];
  if (!draft.signalName) errors.push('Escolha um sinal.');
  if (!draft.targetNodeId || !existingNodeIds.has(draft.targetNodeId)) errors.push('Escolha um nó alvo existente.');
  if (!isValidMethodName(draft.targetMethod)) {
    errors.push('O método deve ser um identificador (letras, dígitos e _; sem espaços; não começa com dígito).');
  }
  const args: SignalArgument[] = [];
  draft.args.forEach((a, i) => {
    const parsed = parseSignalArgument(a.type, a.text);
    if (!parsed) errors.push(`Argumento ${i + 1}: valor inválido para o tipo ${SIGNAL_ARGUMENT_LABEL[a.type]}.`);
    else if (a.type === 'node' && !existingNodeIds.has(String(parsed.value))) errors.push(`Argumento ${i + 1}: o nó informado não existe.`);
    else args.push(parsed);
  });
  if (errors.length) return { ok: false, errors };
  const connection: Omit<NodeSignalConnection, 'id'> = {
    signalName: draft.signalName,
    targetNodeId: draft.targetNodeId,
    targetMethod: draft.targetMethod.trim(),
  };
  if (args.length) connection.arguments = args;
  return { ok: true, errors, connection };
}

const sameArgs = (a: SignalArgument[] = [], b: SignalArgument[] = []) =>
  a.length === b.length && a.every((x, i) => x.type === b[i].type && x.value === b[i].value);

/** Duplicata: mesmo sinal, alvo, método e argumentos. `ignoreId` = a própria conexão ao editar. */
export function findDuplicateConnection(
  connections: readonly NodeSignalConnection[],
  candidate: Omit<NodeSignalConnection, 'id'>,
  ignoreId?: string
): NodeSignalConnection | undefined {
  return connections.find(
    (c) =>
      c.id !== ignoreId &&
      c.signalName === candidate.signalName &&
      c.targetNodeId === candidate.targetNodeId &&
      c.targetMethod === candidate.targetMethod &&
      sameArgs(c.arguments, candidate.arguments)
  );
}

export const hasActiveConnections = (node: { signals?: readonly unknown[] } | undefined): boolean =>
  !!node?.signals && node.signals.length > 0;

/** Conexões de um sinal (agrupamento da lista). */
export const connectionsOfSignal = (connections: readonly NodeSignalConnection[], signalName: string) =>
  connections.filter((c) => c.signalName === signalName);

export const newConnectionId = (): string => 'sig_' + Math.random().toString(36).slice(2, 10);

/** Texto curto de uma conexão: `sinal → Alvo.metodo(args)`. */
export function describeConnection(c: NodeSignalConnection, targetName: string): string {
  const args = (c.arguments ?? []).map((a) => (a.type === 'string' ? JSON.stringify(a.value) : String(a.value))).join(', ');
  return `${c.signalName} → ${targetName}.${c.targetMethod}(${args})`;
}
