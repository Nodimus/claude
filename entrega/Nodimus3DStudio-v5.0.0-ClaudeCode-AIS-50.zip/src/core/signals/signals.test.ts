import { describe, expect, it } from 'vitest';
import type { GameNode } from '../../types/node';
import type { NodeSignalConnection } from '../../types/signal';
import {
  buildConnectionFromDraft,
  defaultMethodFor,
  describeConnection,
  findDuplicateConnection,
  hasActiveConnections,
  isValidMethodName,
  parseSignalArgument,
} from './signalConnections';
import { createConnectSignalCommand, createDisconnectSignalCommand, createEditSignalConnectionCommand } from '../commands/SignalCommands';
import { AuthoringModel } from '../authoring/AuthoringModel';
import { createEmptyScene } from '../defaultProject';
import { CommandManager } from '../commandManager';
import { GameNodeV1Schema } from '../../schemas/v1/node.schema';

const conn = (id: string, over: Partial<NodeSignalConnection> = {}): NodeSignalConnection => ({
  id,
  signalName: 'body_entered',
  targetNodeId: 'b',
  targetMethod: '_on_body_entered',
  ...over,
});

const setup = (signals: NodeSignalConnection[] = []) => {
  const scene = createEmptyScene();
  const root = scene.rootNodeId;
  const node = (id: string, type: string, parentId: string | null, childrenIds: string[], extra: Partial<GameNode> = {}) =>
    ({ id, name: id, type, parentId, childrenIds, visible: true, locked: false, properties: {}, ...extra }) as GameNode;
  scene.nodes = {
    [root]: node(root, 'Spatial', null, ['a', 'b']),
    a: node('a', 'MeshInstance', root, [], { signals }),
    b: node('b', 'MeshInstance', root, []),
  };
  const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene);
  return { model, manager: new CommandManager(), signalsOf: () => model.getScene().nodes.a.signals ?? [] };
};

describe('regras puras de conexão (AIS-27)', () => {
  it('método: identificador válido', () => {
    expect(isValidMethodName('_on_hit')).toBe(true);
    expect(isValidMethodName('onHit2')).toBe(true);
    expect(isValidMethodName('2fast')).toBe(false);
    expect(isValidMethodName('on hit')).toBe(false);
    expect(isValidMethodName('')).toBe(false);
    expect(defaultMethodFor('ready')).toBe('_on_ready');
  });
  it('argumentos tipados: converte ao tipo e rejeita o inválido', () => {
    expect(parseSignalArgument('number', '3,5')).toEqual({ type: 'number', value: 3.5 });
    expect(parseSignalArgument('number', 'abc')).toBeNull();
    expect(parseSignalArgument('number', '')).toBeNull();
    expect(parseSignalArgument('boolean', 'true')).toEqual({ type: 'boolean', value: true });
    expect(parseSignalArgument('boolean', 'talvez')).toBeNull();
    expect(parseSignalArgument('string', ' olá ')).toEqual({ type: 'string', value: ' olá ' });
    expect(parseSignalArgument('node', 'b')).toEqual({ type: 'node', value: 'b' });
    expect(parseSignalArgument('node', '')).toBeNull();
  });
  it('rascunho: erros acumulados; ok devolve a conexão tipada', () => {
    const ids = new Set(['a', 'b']);
    const bad = buildConnectionFromDraft({ signalName: '', targetNodeId: 'zzz', targetMethod: '1x', args: [{ type: 'number', text: 'x' }] }, ids);
    expect(bad.ok).toBe(false);
    expect(bad.errors.length).toBe(4);
    const ok = buildConnectionFromDraft(
      { signalName: 'body_entered', targetNodeId: 'b', targetMethod: ' _on_hit ', args: [{ type: 'number', text: '2' }, { type: 'node', text: 'a' }] },
      ids
    );
    expect(ok.ok).toBe(true);
    expect(ok.connection).toEqual({
      signalName: 'body_entered',
      targetNodeId: 'b',
      targetMethod: '_on_hit',
      arguments: [{ type: 'number', value: 2 }, { type: 'node', value: 'a' }],
    });
    expect(buildConnectionFromDraft({ signalName: 's', targetNodeId: 'b', targetMethod: 'm', args: [{ type: 'node', text: 'fantasma' }] }, ids).ok).toBe(false);
  });
  it('duplicata: mesmo sinal+alvo+método+argumentos; a própria conexão é ignorada ao editar', () => {
    const list = [conn('1'), conn('2', { targetMethod: 'outro' })];
    expect(findDuplicateConnection(list, { signalName: 'body_entered', targetNodeId: 'b', targetMethod: '_on_body_entered' })?.id).toBe('1');
    expect(findDuplicateConnection(list, { signalName: 'body_entered', targetNodeId: 'b', targetMethod: '_on_body_entered' }, '1')).toBeUndefined();
    expect(findDuplicateConnection(list, { signalName: 'body_entered', targetNodeId: 'b', targetMethod: '_on_body_entered', arguments: [{ type: 'number', value: 1 }] })).toBeUndefined();
  });
  it('descrição e indicador', () => {
    expect(describeConnection(conn('1', { arguments: [{ type: 'string', value: 'oi' }, { type: 'number', value: 2 }] }), 'Porta')).toBe('body_entered → Porta._on_body_entered("oi", 2)');
    expect(hasActiveConnections({ signals: [] })).toBe(false);
    expect(hasActiveConnections({ signals: [conn('1')] })).toBe(true);
    expect(hasActiveConnections(undefined)).toBe(false);
  });
  it('o schema aceita argumentos tipados e conexões sem argumentos (formato antigo)', () => {
    const base = { id: 'a', name: 'A', type: 'MeshInstance', parentId: null, childrenIds: [], properties: {} };
    expect(GameNodeV1Schema.safeParse({ ...base, signals: [conn('1')] }).success).toBe(true);
    expect(GameNodeV1Schema.safeParse({ ...base, signals: [conn('1', { arguments: [{ type: 'boolean', value: true }] })] }).success).toBe(true);
    expect(GameNodeV1Schema.safeParse({ ...base, signals: [conn('1', { arguments: [{ type: 'color' as any, value: 1 }] })] }).success).toBe(false);
  });
});

describe('Commands de sinal (AIS-27-C05..C08)', () => {
  it('conectar: Undo remove, Redo reinsere a mesma conexão (mesmo id)', () => {
    const s = setup();
    s.manager.execute(createConnectSignalCommand({ target: s.model, nodeId: 'a', connection: conn('1', { arguments: [{ type: 'number', value: 5 }] }) })!);
    expect(s.signalsOf()).toEqual([conn('1', { arguments: [{ type: 'number', value: 5 }] })]);
    s.manager.undo();
    expect(s.signalsOf()).toEqual([]);
    s.manager.redo();
    expect(s.signalsOf()[0].id).toBe('1');
  });
  it('C05 editar: atualiza alvo, método e argumentos no mesmo lugar; Undo restaura a anterior', () => {
    const s = setup([conn('1'), conn('2', { signalName: 'body_exited' })]);
    const next = conn('1', { targetNodeId: 'a', targetMethod: '_novo', arguments: [{ type: 'string', value: 'x' }] });
    s.manager.execute(createEditSignalConnectionCommand({ target: s.model, nodeId: 'a', oldConn: conn('1'), newConn: next })!);
    expect(s.signalsOf()[0]).toEqual(next);
    expect(s.signalsOf()[1].id).toBe('2');
    s.manager.undo();
    expect(s.signalsOf()).toEqual([conn('1'), conn('2', { signalName: 'body_exited' })]);
  });
  it('editar sem mudança não cria Command (nada entra no histórico)', () => {
    const s = setup([conn('1')]);
    expect(createEditSignalConnectionCommand({ target: s.model, nodeId: 'a', oldConn: conn('1'), newConn: conn('1') })).toBeNull();
  });
  it('C06 desconectar: Command; Undo restaura na posição original', () => {
    const s = setup([conn('1'), conn('2', { signalName: 'x' }), conn('3', { signalName: 'y' })]);
    s.manager.execute(createDisconnectSignalCommand({ target: s.model, nodeId: 'a', conn: conn('2', { signalName: 'x' }) })!);
    expect(s.signalsOf().map((c) => c.id)).toEqual(['1', '3']);
    s.manager.undo();
    expect(s.signalsOf().map((c) => c.id)).toEqual(['1', '2', '3']);
  });
  it('C07 remover a última conexão apaga o indicador da SceneTree; Undo o traz de volta', () => {
    const s = setup([conn('1')]);
    expect(hasActiveConnections(s.model.getScene().nodes.a)).toBe(true);
    s.manager.execute(createDisconnectSignalCommand({ target: s.model, nodeId: 'a', conn: conn('1') })!);
    expect(hasActiveConnections(s.model.getScene().nodes.a)).toBe(false);
    s.manager.undo();
    expect(hasActiveConnections(s.model.getScene().nodes.a)).toBe(true);
  });
  it('C08 cancelar não cria Command: o estado autoral só muda quando o Command é executado', () => {
    const s = setup([conn('1')]);
    // criar o Command não altera nada; o chamador só o executa ao confirmar o modal
    createDisconnectSignalCommand({ target: s.model, nodeId: 'a', conn: conn('1') });
    createEditSignalConnectionCommand({ target: s.model, nodeId: 'a', oldConn: conn('1'), newConn: conn('1', { targetMethod: 'z' }) });
    expect(s.signalsOf()).toEqual([conn('1')]);
    expect(s.manager.undo).toBeDefined();
  });
  it('Command para nó inexistente devolve null; não toca o nó vizinho', () => {
    const s = setup();
    expect(createConnectSignalCommand({ target: s.model, nodeId: 'nao', connection: conn('1') })).toBeNull();
    s.manager.execute(createConnectSignalCommand({ target: s.model, nodeId: 'a', connection: conn('1') })!);
    expect(s.model.getScene().nodes.b.signals).toBeUndefined();
  });
});
