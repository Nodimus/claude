import type { GameNode } from '../../types/node';
import { getNodeMetadata } from '../../nodes/registry';
import { readPhysics } from '../physics/physicsConfig';

/**
 * Sinais que um nó emite. AIS-48: `body_entered`/`body_exited` pertencem ao NÓ QUE TEM `properties.physics` — qualquer tipo de nó
 * com o bloco de Colisão (os tipos `RigidBody`/`Area` não existem mais, decisão 26) —, não a um tipo; sem o bloco, não existem.
 * Disparam com o `otherId` (Enter/Exit; sem Stay). `fell_out_of_world` (AIS-49) avisa que o corpo passou do Kill Floor, ANTES de ser descartado. Executar as conexões é do AIS-57; o barramento é `RuntimeSession.onNodeSignal`.
 */
export const PHYSICS_SIGNALS = ['body_entered', 'body_exited', 'fell_out_of_world'] as const;

/** Sinais declarados pelo tipo (registry; sem declaração, os do ciclo de vida) + os de física quando há o bloco de Colisão. */
export function signalsEmittedBy(type: GameNode['type'], properties?: Record<string, any>): string[] {
  const declared = getNodeMetadata(type).availableSignals;
  const base = declared.length > 0 ? declared : ['ready', 'tree_entered'];
  return readPhysics(properties) ? [...base, ...PHYSICS_SIGNALS.filter((s) => !base.includes(s))] : base;
}
