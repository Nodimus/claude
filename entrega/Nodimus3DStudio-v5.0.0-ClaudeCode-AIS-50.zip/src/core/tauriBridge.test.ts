import { afterEach, describe, expect, it, vi } from 'vitest';

const fsMock = vi.hoisted(() => ({
  writeTextFile: vi.fn(async () => undefined),
  writeFile: vi.fn(async () => undefined),
  rename: vi.fn(async () => undefined),
  remove: vi.fn(async () => undefined),
  readTextFile: vi.fn(async () => 'conteudo'),
  readFile: vi.fn(async () => new Uint8Array([1, 2])),
  readDir: vi.fn(async () => [{ name: 'a.json', isDirectory: false, isFile: true, isSymlink: false }]),
  mkdir: vi.fn(async () => undefined),
  exists: vi.fn(async () => true),
}));
const dialogMock = vi.hoisted(() => ({ open: vi.fn(), save: vi.fn() }));
vi.mock('@tauri-apps/plugin-fs', () => fsMock);
vi.mock('@tauri-apps/plugin-dialog', () => dialogMock);

import { NativeFsUnavailableError, TauriBridge, atomicTempPath, joinPath } from './tauriBridge';

const setTauri = (on: boolean) => {
  if (on) vi.stubGlobal('window', { __TAURI_INTERNALS__: {} });
  else vi.unstubAllGlobals();
};

afterEach(() => {
  setTauri(false);
  vi.clearAllMocks();
});

describe('TauriBridge (web)', () => {
  it('não detecta Tauri e expõe capacidades sem FS nativo', () => {
    expect(TauriBridge.getCapabilities()).toMatchObject({ isTauri: false, hasNativeFS: false, isDesktopOnly: true });
  });
  it('FS nativo lança erro explícito, sem simular', async () => {
    await expect(TauriBridge.readTextFile('x')).rejects.toBeInstanceOf(NativeFsUnavailableError);
    await expect(TauriBridge.listDirectory('x')).rejects.toBeInstanceOf(NativeFsUnavailableError);
  });
  it('Abrir Pasta de Projeto devolve null fora do Tauri', async () => {
    expect(await TauriBridge.openProjectFolderDialog()).toBeNull();
  });
});

describe('TauriBridge (Tauri v2)', () => {
  it('detecta por __TAURI_INTERNALS__', () => {
    setTauri(true);
    expect(TauriBridge.getCapabilities()).toMatchObject({ isTauri: true, hasNativeFS: true });
  });
  it('escrita atômica grava o temporário e renomeia', async () => {
    setTauri(true);
    await TauriBridge.writeTextFile('C:/p/Main.scene', '{}');
    expect(fsMock.writeTextFile).toHaveBeenCalledWith(atomicTempPath('C:/p/Main.scene'), '{}');
    expect(fsMock.rename).toHaveBeenCalledWith(atomicTempPath('C:/p/Main.scene'), 'C:/p/Main.scene');
  });
  it('falha na escrita remove o temporário e propaga o erro', async () => {
    setTauri(true);
    fsMock.rename.mockRejectedValueOnce(new Error('disco cheio'));
    await expect(TauriBridge.writeTextFile('a', 'b')).rejects.toThrow('disco cheio');
    expect(fsMock.remove).toHaveBeenCalledWith(atomicTempPath('a'));
  });
  it('lista diretório, cria pasta, move e exclui', async () => {
    setTauri(true);
    expect(await TauriBridge.listDirectory('d')).toEqual([{ name: 'a.json', isDirectory: false, isFile: true }]);
    await TauriBridge.createDirectory('d/n');
    expect(fsMock.mkdir).toHaveBeenCalledWith('d/n', { recursive: true });
    await TauriBridge.moveFile('a', 'b');
    expect(fsMock.rename).toHaveBeenCalledWith('a', 'b');
    await TauriBridge.deleteFile('b');
    expect(fsMock.remove).toHaveBeenCalledWith('b', { recursive: true });
  });
  it('Abrir Pasta usa diálogo de diretório; cancelar devolve null', async () => {
    setTauri(true);
    dialogMock.open.mockResolvedValueOnce('C:/Projeto');
    expect(await TauriBridge.openProjectFolderDialog()).toBe('C:/Projeto');
    expect(dialogMock.open).toHaveBeenCalledWith(expect.objectContaining({ directory: true }));
    dialogMock.open.mockResolvedValueOnce(null);
    expect(await TauriBridge.openProjectFolderDialog()).toBeNull();
  });
  it('Exportar Projeto salva via diálogo nativo com filtro .nodimus', async () => {
    setTauri(true);
    dialogMock.save.mockResolvedValueOnce('C:/out/p.nodimus');
    await TauriBridge.exportProjectDialog('p.nodimus', '{}');
    expect(dialogMock.save).toHaveBeenCalledWith(expect.objectContaining({ filters: [{ name: 'Nodimus', extensions: ['nodimus'] }] }));
    expect(fsMock.rename).toHaveBeenCalledWith(expect.any(String), 'C:/out/p.nodimus');
  });
  it('cancelar o diálogo de salvar não grava nada', async () => {
    setTauri(true);
    dialogMock.save.mockResolvedValueOnce(null);
    await TauriBridge.saveFile('x.json', '{}');
    expect(fsMock.writeTextFile).not.toHaveBeenCalled();
  });
});

describe('joinPath', () => {
  it('junta sem duplicar separadores', () => {
    expect(joinPath('C:\\proj\\', '/scenes/', 'Main.scene')).toBe('C:/proj/scenes/Main.scene');
  });
});
