import * as THREE from 'three';
import type { HeightfieldData } from './physics/physicsDescriptor';
import { contentToBytes } from './models/modelBytes';
import { getDecodedHeightmap, heightmapDecodeFailed } from './terrainHeightmapCache';
import {
  buildTerrainGeometry,
  generateHeightBuffer,
  heightmapImageToBuffer,
  parseHeightFile,
  readTerrainConfig,
  terrainHeightfield,
  terrainVertexColors,
  type ImageDataLike,
  type TerrainConfig,
} from './terrainGeometry';

/**
 * AIS-50 — constrói/atualiza o `THREE.Mesh` de um nó `Terrain` a partir das `properties`. É a ÚNICA fábrica: o Viewport do editor
 * e o Play (`RuntimeObjectFactory`) a usam, e o buffer de alturas devolvido é o mesmo que alimenta o collider (decisão 23).
 *
 * Fonte das alturas, por prioridade: `.height` esculpido (`heightBufferRef`, escrito pelo AIS-50b) › heightmap (`heightmapRef`)
 * › preset procedural. Arquivo ausente/inválido nunca derruba o editor: cai para a próxima fonte e registra o motivo em `issues`.
 */

type Ref = { id: string; path?: string };
const isRef = (v: unknown): v is Ref => !!v && typeof v === 'object' && typeof (v as Ref).id === 'string' && (v as Ref).id.length > 0;

/** Acesso ao projeto injetado pelo chamador (o módulo não conhece o AuthoringModel). */
export interface TerrainResolveContext {
  files: Record<string, { content?: string } | undefined>;
  pathOf: (ref: Ref) => string | undefined;
  /** Imagem já decodificada (padrão: cache do navegador; testes injetam). */
  imageOf?: (dataUrl: string) => ImageDataLike | null;
}

/**
 * Contexto padrão do projeto aberto, instalado pelo editor (`core/resources/global.ts`). Sem ele (testes, publicação sem projeto)
 * o terreno usa o preset: arquivos de heightmap/.height não são encontrados e o motivo vai em `issues`.
 */
let contextProvider: (() => TerrainResolveContext) | null = null;
export function setTerrainContextProvider(provider: (() => TerrainResolveContext) | null): void {
  contextProvider = provider;
}
export function getTerrainContext(): TerrainResolveContext {
  return contextProvider?.() ?? { files: {}, pathOf: () => undefined };
}

export type TerrainHeightSource = 'sculpted' | 'heightmap' | 'preset';

export interface TerrainBuild {
  config: TerrainConfig;
  heights: Float32Array;
  source: TerrainHeightSource;
  /** Identifica o que gerou o buffer: igual → a geometria não precisa ser reconstruída. */
  heightSignature: string;
  /** Motivos de uma fonte ter sido ignorada (heightmap ainda decodificando, `.height` inválido…). */
  issues: string[];
  /** O heightmap existe mas ainda está sendo decodificado (o chamador deve reconstruir quando o cache avisar). */
  pendingHeightmap: boolean;
}

/** Buffers recentes por assinatura: o sync do Viewport roda a cada mudança da cena e não pode regenerar (nem reler) o terreno à toa. */
const BUFFER_CACHE_LIMIT = 6;
const bufferCache = new Map<string, Float32Array>();
function memoBuffer(signature: string, compute: () => Float32Array): Float32Array {
  const hit = bufferCache.get(signature);
  if (hit) {
    bufferCache.delete(signature); // LRU: reinsere como o mais recente
    bufferCache.set(signature, hit);
    return hit;
  }
  const value = compute();
  bufferCache.set(signature, value);
  while (bufferCache.size > BUFFER_CACHE_LIMIT) bufferCache.delete(bufferCache.keys().next().value as string);
  return value;
}

export function resolveTerrainHeights(properties: Record<string, any>, ctx: TerrainResolveContext): TerrainBuild {
  const config = readTerrainConfig(properties);
  const issues: string[] = [];
  const cols = config.segmentsW + 1;
  const rows = config.segmentsH + 1;

  if (isRef(properties.heightBufferRef)) {
    const uri = ctx.pathOf(properties.heightBufferRef);
    const content = uri ? ctx.files[uri]?.content : undefined;
    if (!uri || content === undefined) {
      issues.push('O arquivo .height do terreno não foi encontrado; usando a geometria gerada.');
    } else {
      const heightSignature = `h:${uri}:${content.length}:${content.slice(-16)}`;
      const cached = bufferCache.get(heightSignature);
      if (cached && cached.length === rows * cols) return { config, heights: memoBuffer(heightSignature, () => cached), source: 'sculpted', heightSignature, issues, pendingHeightmap: false };
      const parsed = parseHeightFile(contentToBytes(content));
      if (!parsed.ok) issues.push(`O .height "${uri}" é inválido (${parsed.reason}); usando a geometria gerada.`);
      else if (parsed.file.rows !== rows || parsed.file.cols !== cols) issues.push(`O .height "${uri}" tem ${parsed.file.cols - 1}×${parsed.file.rows - 1} segmentos, diferente do nó (${config.segmentsW}×${config.segmentsH}); usando a geometria gerada.`);
      else return { config, heights: memoBuffer(heightSignature, () => parsed.file.heights), source: 'sculpted', heightSignature, issues, pendingHeightmap: false };
    }
  }

  let pendingHeightmap = false;
  if (isRef(properties.heightmapRef)) {
    const uri = ctx.pathOf(properties.heightmapRef);
    const content = uri ? ctx.files[uri]?.content : undefined;
    if (!uri || typeof content !== 'string' || !content.startsWith('data:image')) {
      issues.push('O heightmap do terreno não foi encontrado; usando o preset.');
    } else {
      const image = (ctx.imageOf ?? getDecodedHeightmap)(content);
      if (image) {
        const heightSignature = `m:${uri}:${content.length}:${content.slice(-16)}:${config.segmentsW}x${config.segmentsH}:${config.maxHeight}:${config.invertHeightmap}:${config.smoothHeightmap}`;
        const heights = memoBuffer(heightSignature, () => heightmapImageToBuffer(image, config.segmentsW, config.segmentsH, config.maxHeight, config.invertHeightmap, config.smoothHeightmap));
        return { config, heights, source: 'heightmap', heightSignature, issues, pendingHeightmap: false };
      }
      if (heightmapDecodeFailed(content)) issues.push(`O heightmap "${uri}" não pôde ser decodificado; usando o preset.`);
      else pendingHeightmap = true;
    }
  }

  const heightSignature = `p:${config.preset}:${config.presetSeed}:${config.segmentsW}x${config.segmentsH}:${config.maxHeight}`;
  const heights = memoBuffer(heightSignature, () => generateHeightBuffer(config.segmentsW, config.segmentsH, config.preset, config.presetSeed, config.maxHeight));
  return { config, heights, source: 'preset', heightSignature, issues, pendingHeightmap };
}

export interface TerrainMeshData {
  heightSignature: string;
  colorSignature: string;
  dimensionSignature: string;
  heights: Float32Array;
  config: TerrainConfig;
  source: TerrainHeightSource;
}

const colorSignatureOf = (c: TerrainConfig) => `${c.groundTexture}|${c.midTexture}|${c.highTexture}|${c.blendSharpness}|${c.maxHeight}`;
const dimensionSignatureOf = (c: TerrainConfig) => `${c.width}x${c.depth}:${c.segmentsW}x${c.segmentsH}`;

export const terrainDataOf = (object: THREE.Object3D | undefined | null): TerrainMeshData | null => (object?.userData?.terrain as TerrainMeshData | undefined) ?? null;

function applyColors(geometry: THREE.BufferGeometry, build: TerrainBuild): void {
  geometry.setAttribute('color', new THREE.BufferAttribute(terrainVertexColors(build.heights, build.config), 3));
}

/**
 * Cria o mesh do terreno ou atualiza o `existing`: reconstrói a geometria só quando altura/dimensões mudaram e recalcula as
 * cores só quando as texturas/mistura mudaram (mudar só material reaproveita a geometria). Devolve o mesmo objeto quando possível.
 */
export function syncTerrainMesh(existing: THREE.Mesh | undefined, properties: Record<string, any>, ctx: TerrainResolveContext): { mesh: THREE.Mesh; build: TerrainBuild } {
  const build = resolveTerrainHeights(properties, ctx);
  const { config } = build;
  const colorSignature = colorSignatureOf(config);
  const dimensionSignature = dimensionSignatureOf(config);

  let mesh = existing;
  const previous = terrainDataOf(mesh);
  const geometryChanged = !mesh || !previous || previous.heightSignature !== build.heightSignature || previous.dimensionSignature !== dimensionSignature;
  if (!mesh) {
    mesh = new THREE.Mesh(new THREE.BufferGeometry(), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.95, metalness: 0 }));
    mesh.castShadow = false;
    mesh.receiveShadow = true;
  }
  if (geometryChanged) {
    const geometry = buildTerrainGeometry(config.width, config.depth, config.segmentsW, config.segmentsH, build.heights);
    applyColors(geometry, build);
    mesh.geometry.dispose();
    mesh.geometry = geometry;
  } else if (!previous || previous.colorSignature !== colorSignature) {
    applyColors(mesh.geometry, build);
  }
  mesh.userData.terrain = { heightSignature: build.heightSignature, colorSignature, dimensionSignature, heights: build.heights, config, source: build.source } satisfies TerrainMeshData;
  return { mesh, build };
}

/** Campo de alturas de um objeto de terreno para o `PhysicsBridge` (o MESMO `Float32Array` da geometria); `null` se não for terreno. */
export function terrainHeightfieldOf(object: THREE.Object3D | undefined | null): HeightfieldData | null {
  const data = terrainDataOf(object);
  if (!data || !object) return null;
  const field = terrainHeightfield(data.heights, data.config);
  // o transform do nó (escala) vale para o collider como vale para a malha; posição/rotação entram pelo descritor
  object.updateWorldMatrix(true, false);
  const s = object.getWorldScale(new THREE.Vector3());
  return { ...field, scale: { x: field.scale.x * Math.abs(s.x), y: field.scale.y * Math.abs(s.y), z: field.scale.z * Math.abs(s.z) } };
}

/** Libera geometria e material do mesh de terreno. */
export function disposeTerrainMesh(object: THREE.Object3D): void {
  const mesh = object as THREE.Mesh;
  mesh.geometry?.dispose?.();
  const m = mesh.material;
  for (const material of Array.isArray(m) ? m : m ? [m] : []) material.dispose();
}
