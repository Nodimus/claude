import { ProjectData } from '../types/project';
import { ProjectFile } from '../types/projectFile';
import { SceneData } from '../types/scene';
import { SceneFile } from '../types/sceneFile';
import { createNewProject, ensureStarterFiles, buildProjectSceneEntries } from './defaultProject';
import { validateProject, validateProjectFile, validateSceneFile, restoreMissingNodes } from '../schemas';
import { applyMigrations } from '../migrations';
import { CURRENT_PROJECT_SCHEMA_VERSION, CURRENT_SCENE_SCHEMA_VERSION } from './persistenceVersions';
import { TauriBridge } from './tauriBridge';

const STORAGE_PROJECTS_KEY = 'nodimus_projects_list';
const STORAGE_CURRENT_PROJECT_KEY = 'nodimus_current_project_id';

const memoryFallbackStorage = new Map<string, string>();

function safeGetStorageItem(key: string): string | null {
  if (typeof localStorage !== 'undefined') {
    return localStorage.getItem(key);
  }
  return memoryFallbackStorage.get(key) ?? null;
}

function safeSetStorageItem(key: string, value: string): void {
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem(key, value);
  } else {
    memoryFallbackStorage.set(key, value);
  }
}

function safeRemoveStorageItem(key: string): void {
  if (typeof localStorage !== 'undefined') {
    localStorage.removeItem(key);
  } else {
    memoryFallbackStorage.delete(key);
  }
}

type SaveErrorListener = (message: string, error: unknown) => void;
const saveErrorListeners = new Set<SaveErrorListener>();

function describeStorageError(e: unknown): string {
  const name = (e as { name?: string } | null)?.name;
  if (name === 'QuotaExceededError' || name === 'NS_ERROR_DOM_QUOTA_REACHED') {
    return 'Armazenamento local cheio: o projeto NÃO foi salvo. Remova arquivos grandes (imagens/base64) ou exporte o projeto.';
  }
  return `Falha ao gravar o projeto: ${(e as { message?: string } | null)?.message ?? String(e)}`;
}

export class ProjectStorage {
  /**
   * AIS-29b: escritor dos backups pré-migração (mesma infraestrutura do projeto: localStorage; no Tauri vira arquivo).
   * Nunca sobrescreve um backup existente.
   */
  public static readonly backupWriter = {
    exists: (key: string): boolean => safeGetStorageItem(key) !== null,
    write: (key: string, content: string): void => {
      try {
        safeSetStorageItem(key, content);
      } catch (e) {
        console.warn('[ProjectStorage] Não foi possível gravar o backup pré-migração', e);
      }
    },
  };

  /** Assina falhas de gravação (quota etc.). Retorna o disposer (AIS-48b). */
  public static onSaveError(listener: SaveErrorListener): () => void {
    saveErrorListeners.add(listener);
    return () => {
      saveErrorListeners.delete(listener);
    };
  }

  private static reportSaveError(e: unknown): void {
    const message = describeStorageError(e);
    console.error('[ProjectStorage] ' + message, e);
    saveErrorListeners.forEach((l) => l(message, e));
  }

  public static getProjectsList(): { id: string; name: string; location: string; renderer: string; updatedAt: string }[] {
    try {
      const data = safeGetStorageItem(STORAGE_PROJECTS_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error('Failed to load projects list', e);
    }
    return [];
  }

  public static saveProjectsList(list: { id: string; name: string; location: string; renderer: string; updatedAt: string }[]): void {
    try {
      safeSetStorageItem(STORAGE_PROJECTS_KEY, JSON.stringify(list));
    } catch (e) {
      this.reportSaveError(e);
    }
  }

  /**
   * Loads a project with strict JSON integrity protection.
   * If stored data is corrupted, logs an error without overwriting or destroying data.
   */
  public static loadProject(projectId: string): ProjectData | null {
    try {
      const raw = safeGetStorageItem(`nodimus_proj_${projectId}`);
      if (!raw) return null;

      let parsed: any;
      try {
        parsed = JSON.parse(raw);
      } catch (jsonErr) {
        console.error(`[ProjectStorage] JSON integrity failure for project ${projectId}: malformed JSON. Data preserved in storage.`, jsonErr);
        return null;
      }

      const validation = validateProject(parsed);
      let projectData: ProjectData;
      if (validation.success && validation.data) {
        projectData = validation.data as unknown as ProjectData;
      } else {
        // Dado inválido: usa a versão migrada (nunca o cru nem uma versão carimbada) e preserva o armazenado.
        console.warn(`[ProjectStorage] Boundary validation warning for project ${projectId}:
${validation.formattedError}`);
        projectData = applyMigrations<ProjectData>('project', parsed).data;
      }

      return ensureStarterFiles(projectData);
    } catch (e) {
      console.error('[ProjectStorage] Unexpected error loading project ' + projectId, e);
      return null;
    }
  }

  /**
   * AIS-18b — grava SÓ os arquivos informados sobre o projeto persistido (read-modify-write).
   * Salvar um arquivo não pode sobrescrever, com a cópia em memória, as alterações externas
   * de outros arquivos (a cena salva sem apagar o script editado por fora, e vice-versa).
   * Os demais campos do projeto vêm da memória; sem projeto persistido, grava o projeto inteiro.
   */
  public static saveProjectFiles(project: ProjectData, paths: string[]): void {
    const stored = this.loadProject(project.id);
    if (!stored) {
      this.saveProject(project);
      return;
    }
    const files = { ...stored.files };
    for (const path of paths) {
      if (project.files[path]) files[path] = project.files[path];
      else delete files[path];
    }
    this.saveProject({ ...project, files });
  }

  /**
   * Saves a project with JSON integrity protection and automatic sync of canonical res://project.json.
   */
  public static saveProject(project: ProjectData): boolean {
    try {
      project.updatedAt = new Date().toISOString();
      project.schemaVersion = CURRENT_PROJECT_SCHEMA_VERSION;

      // Synchronize canonical project.json inside files
      const canonicalProjectFile = this.toProjectFile(project);
      const validationProjFile = validateProjectFile(canonicalProjectFile);
      if (!validationProjFile.success) {
        console.warn(`[ProjectStorage] Warning on canonical project.json generation:\n${validationProjFile.formattedError}`);
      }
      const projectJsonContent = JSON.stringify(canonicalProjectFile, null, 2);
      project.files['res://project.json'] = {
        path: 'res://project.json',
        name: 'project.json',
        isDirectory: false,
        extension: 'json',
        content: projectJsonContent,
        size: projectJsonContent.length,
        updatedAt: project.updatedAt,
      };

      const serialized = JSON.stringify(project);
      // AIS-29f: gravação atômica — o texto é montado por inteiro ANTES de tocar no armazenamento, vai numa única
      // `setItem` (atômica por chave) e é relido para confirmar. No host Tauri vira arquivo temporário + rename (AIS-AP).
      const projectKey = `nodimus_proj_${project.id}`;
      safeSetStorageItem(projectKey, serialized);
      if (safeGetStorageItem(projectKey) !== serialized) throw new Error('A verificação da gravação do projeto falhou (conteúdo diferente do esperado).');
      safeSetStorageItem(STORAGE_CURRENT_PROJECT_KEY, project.id);

      // Update in master list
      const list = this.getProjectsList();
      const idx = list.findIndex((p) => p.id === project.id);
      const summary = {
        id: project.id,
        name: project.name,
        location: project.location,
        renderer: project.renderer,
        updatedAt: project.updatedAt,
      };

      if (idx >= 0) {
        list[idx] = summary;
      } else {
        list.unshift(summary);
      }
      this.saveProjectsList(list);
      return true;
    } catch (e) {
      this.reportSaveError(e);
      return false;
    }
  }

  public static deleteProject(projectId: string): void {
    try {
      safeRemoveStorageItem(`nodimus_proj_${projectId}`);
      const list = this.getProjectsList().filter((p) => p.id !== projectId);
      this.saveProjectsList(list);
      if (safeGetStorageItem(STORAGE_CURRENT_PROJECT_KEY) === projectId) {
        safeRemoveStorageItem(STORAGE_CURRENT_PROJECT_KEY);
      }
    } catch (e) {
      console.error('Failed to delete project', e);
    }
  }

  public static getCurrentProjectId(): string | null {
    return safeGetStorageItem(STORAGE_CURRENT_PROJECT_KEY);
  }

  public static getOrCreateDefaultProject(): ProjectData {
    const list = this.getProjectsList();
    const currentId = this.getCurrentProjectId();

    if (currentId) {
      const proj = this.loadProject(currentId);
      if (proj) return proj;
    }

    if (list.length > 0) {
      const proj = this.loadProject(list[0].id);
      if (proj) return proj;
    }

    // Create fresh starter 3D + 2D Overlay project
    const defaultProj = createNewProject('Nodimus 3D Adventure', '~/Projects/Nodimus3D', '3d');
    this.saveProject(defaultProj);
    return defaultProj;
  }

  /**
   * Serializes project to canonical string format for .nodimus files.
   */
  public static exportProjectAsNodimus(project: ProjectData): string {
    project.schemaVersion = project.schemaVersion || CURRENT_PROJECT_SCHEMA_VERSION;
    const canonicalProjectFile = this.toProjectFile(project);
    const projectJsonContent = JSON.stringify(canonicalProjectFile, null, 2);
    project.files['res://project.json'] = {
      path: 'res://project.json',
      name: 'project.json',
      isDirectory: false,
      extension: 'json',
      content: projectJsonContent,
      size: projectJsonContent.length,
      updatedAt: new Date().toISOString(),
    };
    return JSON.stringify(project, null, 2);
  }

  /**
   * Native file export of .nodimus project bundle (Tauri v2 native with isomorphic web download fallback)
   */
  public static async exportProjectAsNodimusFile(project: ProjectData): Promise<void> {
    const jsonStr = this.exportProjectAsNodimus(project);
    const safeName = project.name.toLowerCase().replace(/[^a-z0-9]/g, '_') || 'project';
    const fileName = `${safeName}.nodimus`;
    await TauriBridge.saveFile(fileName, jsonStr, 'application/json');
  }

  /**
   * Import project from .nodimus bundle with strict JSON integrity protection.
   */
  public static importProjectFromNodimus(content: string): ProjectData {
    let rawParsed: any;
    try {
      rawParsed = JSON.parse(content);
    } catch (err: any) {
      throw new Error(`[ProjectStorage] JSON integrity failure: ${err?.message || 'Invalid or malformed JSON content'}`);
    }

    if (!rawParsed || typeof rawParsed !== 'object') {
      throw new Error('[ProjectStorage] Invalid project format: Expected an object');
    }

    // Case 1: Full ProjectData bundle (contains files)
    if (rawParsed.files && typeof rawParsed.files === 'object') {
      const validation = validateProject(rawParsed);
      if (!validation.success) {
        // AIS-32-C10: arquivo inválido NÃO cria projeto parcial; o erro chega ao Gerenciador de Projetos
        throw new Error(`[ProjectStorage] Invalid project file:\n${validation.formattedError}`);
      }
      const project = ensureStarterFiles(rawParsed as ProjectData);
      project.id = 'proj_' + Math.random().toString(36).substring(2, 9);
      project.schemaVersion = CURRENT_PROJECT_SCHEMA_VERSION;
      project.updatedAt = new Date().toISOString();
      this.saveProject(project);
      return project;
    }

    // Case 2: Canonical project.json file (ProjectFile)
    const validationProjFile = validateProjectFile(rawParsed);
    if (validationProjFile.success && validationProjFile.data) {
      const projFile = validationProjFile.data;
      const newProj = createNewProject(projFile.name, '~/Projects/' + projFile.name, '3d');
      newProj.settings = projFile.settings as unknown as ProjectData['settings'];
      newProj.globalVariables = (projFile.globalVariables ?? []) as ProjectData['globalVariables'];
      if (projFile.createdAt) newProj.createdAt = projFile.createdAt;
      // O project.json só referencia cenas (não as contém): a cena inicial só vale se já existir no projeto.
      const startScene = projFile.scenes.find((sc) => sc.id === projFile.startSceneId || sc.isStartScene);
      if (startScene && newProj.files[startScene.path]) newProj.lastOpenedScene = startScene.path;
      const missingScenes = projFile.scenes.filter((sc) => !newProj.files[sc.path]).map((sc) => sc.path);
      if (missingScenes.length > 0) {
        console.warn(`[ProjectStorage] project.json importado referencia cenas ausentes (não foram criadas): ${missingScenes.join(', ')}`);
      }
      newProj.schemaVersion = CURRENT_PROJECT_SCHEMA_VERSION;
      this.saveProject(newProj);
      return newProj;
    }

    throw new Error('[ProjectStorage] Unrecognized project file structure: missing files or project.json metadata');
  }

  public static exportProjectAsJSON(project: ProjectData): string {
    return this.exportProjectAsNodimus(project);
  }

  public static importProjectFromJSON(jsonString: string): ProjectData {
    return this.importProjectFromNodimus(jsonString);
  }

  /**
   * Converts ProjectData to canonical ProjectFile format for `project.json`
   */
  public static toProjectFile(project: ProjectData): ProjectFile {
    const sceneEntries = buildProjectSceneEntries(project.files, project.settings?.general?.mainScene ?? '', project.lastOpenedScene);

    return {
      schemaVersion: CURRENT_PROJECT_SCHEMA_VERSION,
      projectId: project.id,
      name: project.name,
      appId: 'com.nodimus.' + project.name.toLowerCase().replace(/[^a-z0-9]/g, ''),
      engineVersion: '1.0.0',
      startSceneId: sceneEntries.find((s) => s.isStartScene)?.id || sceneEntries[0].id,
      scenes: sceneEntries,
      globalVariables: project.globalVariables ?? [],
      inputMap: project.settings.input?.actions || [],
      settings: project.settings,
      createdAt: project.createdAt,
      updatedAt: project.updatedAt,
    };
  }

  /**
   * Converts SceneData to canonical SceneFile format for `*.scene.json`
   */
  public static toSceneFile(scene: SceneData): SceneFile {
    return {
      schemaVersion: CURRENT_SCENE_SCHEMA_VERSION,
      sceneId: scene.id,
      name: scene.name,
      rootNodeId: scene.rootNodeId,
      environmentNodeId: scene.environmentNodeId || null,
      nodes: restoreMissingNodes(scene.nodes),
      sceneSettings: {
        environment: scene.environment,
        cameraSettings: scene.cameraSettings,
        postProcessing: scene.postProcessing,
        fog: scene.fog,
      },
      createdAt: scene.createdAt,
      updatedAt: scene.updatedAt,
    };
  }
}


