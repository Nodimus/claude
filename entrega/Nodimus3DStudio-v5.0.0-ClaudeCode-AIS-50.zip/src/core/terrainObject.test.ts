import { beforeAll, describe, expect, it } from 'vitest';
import * as THREE from 'three';
import { PhysicsBridge } from './physics/PhysicsBridge';
import { resolvePhysicsDescriptor } from './physics/physicsDescriptor';
import { ensureRapier, type RapierModule } from './physics/rapierInit';
import { createDefaultNode } from '../nodes/registry';
import { RuntimeObjectFactory } from '../runtime/RuntimeObjectFactory';
import { __primeHeightmapCache } from './terrainHeightmapCache';
import { encodeHeightFile, sampleHeight } from './terrainGeometry';
import { bytesToDataUrl } from './models/modelBytes';
import { disposeTerrainMesh, getTerrainContext, resolveTerrainHeights, setTerrainContextProvider, syncTerrainMesh, terrainDataOf, terrainHeightfieldOf, type TerrainResolveContext } from './terrainObject';

const props = (extra: Record<string, any> = {}) => ({ ...createDefaultNode('Terrain').properties, segmentsW: 32, segmentsH: 32, ...extra });
const EMPTY: TerrainResolveContext = { files: {}, pathOf: () => undefined };

describe('entrada do registry (AIS-50-C01)', () => {
  it('Terrain nasce com os padrões do prompt e o bloco physics static/auto', () => {
    const n = createDefaultNode('Terrain', 'Terrain');
    expect(n.type).toBe('Terrain');
    expect(n.properties).toMatchObject({ width: 120, depth: 120, segmentsW: 128, segmentsH: 128, maxHeight: 24, heightmapRef: null, terrainPreset: 'flat', presetSeed: 0, groundTexture: 'Grass_Green', midTexture: 'Rock_Cliff', highTexture: 'Snow_Mountain', textureTiling: 16, blendSharpness: 0.5, physics: { enabled: true, bodyMode: 'static', shape: 'auto' } });
  });
});

describe('syncTerrainMesh', () => {
  it('cria o mesh com a resolução pedida e vertex colors; mantém o objeto ao editar só o material', () => {
    const { mesh, build } = syncTerrainMesh(undefined, props({ terrainPreset: 'hills' }), EMPTY);
    expect(mesh.geometry.getAttribute('position').count).toBe(33 * 33);
    expect(mesh.geometry.getAttribute('color').count).toBe(33 * 33);
    expect(mesh.castShadow).toBe(false);
    expect(mesh.receiveShadow).toBe(true);
    const geometry = mesh.geometry;
    const colorsBefore = Array.from(geometry.getAttribute('color').array.slice(0, 3));
    const again = syncTerrainMesh(mesh, props({ terrainPreset: 'hills', groundTexture: 'Sand_Desert' }), EMPTY);
    expect(again.mesh).toBe(mesh);
    expect(mesh.geometry).toBe(geometry); // só as cores mudaram: geometria reaproveitada
    expect(Array.from(mesh.geometry.getAttribute('color').array.slice(0, 3))).not.toEqual(colorsBefore);
    expect(again.build.heights).toBe(build.heights); // mesmo buffer (cache por assinatura)
  });
  it('mudar o preset reconstrói a geometria (Command → viewport atualiza) e descarta a anterior', () => {
    const { mesh } = syncTerrainMesh(undefined, props({ terrainPreset: 'flat' }), EMPTY);
    const old = mesh.geometry;
    let disposed = false;
    old.addEventListener('dispose', () => (disposed = true));
    syncTerrainMesh(mesh, props({ terrainPreset: 'mountains', maxHeight: 40 }), EMPTY);
    expect(mesh.geometry).not.toBe(old);
    expect(disposed).toBe(true);
    expect(terrainDataOf(mesh)!.config.preset).toBe('mountains');
    disposeTerrainMesh(mesh);
  });
  it('dimensões e segmentos refletem na geometria', () => {
    const { mesh } = syncTerrainMesh(undefined, props({ width: 50, depth: 30, segmentsW: 64, segmentsH: 32 }), EMPTY);
    mesh.geometry.computeBoundingBox();
    expect(mesh.geometry.getAttribute('position').count).toBe(65 * 33);
    expect(mesh.geometry.boundingBox!.max.x).toBeCloseTo(25);
    expect(mesh.geometry.boundingBox!.max.z).toBeCloseTo(15);
  });
});

describe('fontes de altura (heightmap e .height)', () => {
  const ref = { id: 'res_1', path: 'res://textures/h.png' };
  const dataUrl = 'data:image/png;base64,AAAA';
  const files = { 'res://textures/h.png': { content: dataUrl } };
  const ctx = (image: ReturnType<typeof ramp> | null): TerrainResolveContext => ({ files, pathOf: () => 'res://textures/h.png', imageOf: () => image });
  const ramp = () => ({ width: 2, height: 2, data: new Uint8ClampedArray([0, 0, 0, 255, 255, 0, 0, 255, 0, 0, 0, 255, 255, 0, 0, 255]) });

  it('C04: heightmap grayscale gera o relevo da imagem (esquerda baixa, direita alta)', () => {
    const b = resolveTerrainHeights(props({ heightmapRef: ref, maxHeight: 10, smoothHeightmap: false }), ctx(ramp()));
    expect(b.source).toBe('heightmap');
    expect(b.heights[0]).toBeCloseTo(0);
    expect(b.heights[32]).toBeCloseTo(10);
    expect(b.issues).toEqual([]);
  });
  it('imagem ainda decodificando: usa o preset e marca pendente (o Viewport reconstrói ao terminar)', () => {
    const b = resolveTerrainHeights(props({ heightmapRef: ref }), ctx(null));
    expect(b).toMatchObject({ source: 'preset', pendingHeightmap: true });
  });
  it('heightmap ausente ou não-imagem: preset + motivo, sem lançar', () => {
    const b = resolveTerrainHeights(props({ heightmapRef: ref }), EMPTY);
    expect(b.source).toBe('preset');
    expect(b.issues[0]).toContain('heightmap');
  });
  it('.height válido substitui o preset; inválido/incompatível cai para a próxima fonte com motivo', () => {
    const heights = new Float32Array(33 * 33).fill(7);
    const good = bytesToDataUrl(encodeHeightFile({ rows: 33, cols: 33, scale: { x: 120, y: 1, z: 120 }, heights }));
    const hRef = { id: 'res_2', path: 'res://terrain/t.height' };
    const mk = (content: string): TerrainResolveContext => ({ files: { 'res://terrain/t.height': { content } }, pathOf: () => 'res://terrain/t.height' });
    const ok = resolveTerrainHeights(props({ heightBufferRef: hRef }), mk(good));
    expect(ok.source).toBe('sculpted');
    expect(ok.heights[100]).toBe(7);
    const wrongSize = bytesToDataUrl(encodeHeightFile({ rows: 5, cols: 5, scale: { x: 1, y: 1, z: 1 }, heights: new Float32Array(25) }));
    expect(resolveTerrainHeights(props({ heightBufferRef: hRef }), mk(wrongSize))).toMatchObject({ source: 'preset', issues: [expect.stringContaining('segmentos')] });
    expect(resolveTerrainHeights(props({ heightBufferRef: hRef }), mk('data:application/octet-stream;base64,AAAA'))).toMatchObject({ source: 'preset', issues: [expect.stringContaining('inválido')] });
    expect(resolveTerrainHeights(props({ heightBufferRef: hRef }), EMPTY).issues[0]).toContain('não foi encontrado');
  });
  it('cache primado por teste', () => {
    __primeHeightmapCache(dataUrl, ramp());
    expect(resolveTerrainHeights(props({ heightmapRef: ref, smoothHeightmap: false }), { files, pathOf: () => 'res://textures/h.png' }).source).toBe('heightmap');
  });
});

describe('Play: RuntimeObjectFactory (mesma fábrica) e collider (AIS-45 heightfield)', () => {
  let R: RapierModule;
  beforeAll(async () => {
    R = await ensureRapier();
  });

  it('a fábrica de runtime cria o terreno com o buffer em userData e libera tudo no dispose', () => {
    setTerrainContextProvider(() => EMPTY);
    const factory = new RuntimeObjectFactory();
    const node = createDefaultNode('Terrain', 'T');
    const object = factory.create({ type: 'Terrain', name: 'T', properties: { ...node.properties, segmentsW: 32, segmentsH: 32 }, persistentNodeId: 'n1' });
    expect(terrainDataOf(object)).not.toBeNull();
    expect(factory.liveCount).toBe(1);
    factory.dispose();
    expect(factory.liveCount).toBe(0);
    setTerrainContextProvider(null);
    expect(getTerrainContext().files).toEqual({});
  });

  it('o heightfield usa o MESMO Float32Array e honra a escala do nó', () => {
    const { mesh, build } = syncTerrainMesh(undefined, props({ terrainPreset: 'hills' }), EMPTY);
    mesh.scale.set(2, 3, 2);
    const hf = terrainHeightfieldOf(mesh)!;
    expect(hf.heights).toBe(build.heights);
    expect(hf).toMatchObject({ rows: 33, cols: 33, scale: { x: 240, y: 3, z: 240 } });
    expect(terrainHeightfieldOf(new THREE.Group())).toBeNull();
  });

  it('um corpo repousa sobre a superfície do terreno gerado (collider = sampleHeight)', () => {
    const { mesh, build } = syncTerrainMesh(undefined, props({ terrainPreset: 'mountains', width: 100, depth: 100 }), EMPTY);
    const hf = terrainHeightfieldOf(mesh)!;
    const bridge = new PhysicsBridge(R);
    const result = resolvePhysicsDescriptor({
      nodeId: 'terrain', name: 'Terrain', nodeType: 'Terrain', properties: { physics: { enabled: true, bodyMode: 'static', shape: 'auto' } },
      bounds: null, worldScale: { x: 1, y: 1, z: 1 }, worldPosition: { x: 0, y: 0, z: 0 }, worldRotation: { x: 0, y: 0, z: 0, w: 1 }, heightfield: hf,
    });
    expect(result.issues).toEqual([]);
    bridge.addHeightfield(result.descriptor!);
    const sphere = (id: string, x: number, z: number) =>
      resolvePhysicsDescriptor({ nodeId: id, name: id, nodeType: 'MeshInstance', properties: { meshType: 'SphereMesh', physics: { enabled: true, bodyMode: 'dynamic', shape: 'sphere' } }, bounds: { size: { x: 1, y: 1, z: 1 }, center: { x: 0, y: 0, z: 0 } }, worldScale: { x: 1, y: 1, z: 1 }, worldPosition: { x, y: 60, z }, worldRotation: { x: 0, y: 0, z: 0, w: 1 } }).descriptor!;
    bridge.addBody(sphere('center', 0, 0));
    bridge.addBody(sphere('edge', 40, 40));
    for (let i = 0; i < 60 * 8; i++) bridge.step(1 / 60);
    const surface = (x: number, z: number) => sampleHeight(build.heights, 32, 32, 100, 100, x, z);
    const c = bridge.getPose('center')!.position;
    const e = bridge.getPose('edge')!.position;
    expect(Math.abs(c.y - 0.5 - surface(c.x, c.z))).toBeLessThan(0.8);
    expect(Math.abs(e.y - 0.5 - surface(e.x, e.z))).toBeLessThan(0.8);
    expect(c.y).toBeGreaterThan(e.y + 3); // pico central bem acima da borda
    bridge.dispose();
  });
});
