/**
 * AIS-33a — liga `createModelObject` ao projeto aberto: `ResourceRef` resolvido pelo `ResourceRegistry` (identidade, não
 * caminho), conteúdo lido do projeto (AuthoringModel), diagnósticos para o `DiagnosticService` (fase `import`) e cache
 * invalidado quando o recurso muda, é movido ou removido. Chamado por `bindEditorServices` (idempotente).
 */
import { globalAuthoringModel } from '../authoring';
import { globalDiagnosticService } from '../diagnostics/global';
import { globalResourceRegistry } from '../resources/global';
import { configureModelSource, type ModelSourceBinding } from './createModelObject';
import { globalModelCache } from './modelCache';

export const projectModelSource: ModelSourceBinding = {
  resolve: (ref) => {
    const result = globalResourceRegistry.resolve(ref);
    if (result.status !== 'resolved') return null;
    const { entry } = result;
    const file = globalAuthoringModel.getProject().files[entry.uri];
    return { resourceId: entry.resourceId, uri: entry.uri, contentHash: entry.contentHash, content: file?.content };
  },
  readFile: (uri) => globalAuthoringModel.getProject().files[uri]?.content,
  report: (d) => {
    globalDiagnosticService.report({
      source: 'model',
      severity: d.severity,
      phase: 'import',
      code: d.code,
      message: d.message,
      uri: d.uri,
      resourceRef: d.resourceId ? { id: d.resourceId, path: d.uri } : undefined,
    });
  },
};

let wired = false;

export function wireModelSource(): () => void {
  if (wired) return () => {};
  wired = true;
  const offConfigure = configureModelSource(projectModelSource);
  const offRegistry = globalResourceRegistry.subscribe((event) => {
    if (event.type === 'changed' || event.type === 'removed' || event.type === 'moved') {
      globalModelCache.invalidate(event.resourceId);
      // o diagnóstico `model.unresolved` deste recurso deixa de valer assim que ele reaparece/é reimportado
      globalDiagnosticService.clear({ source: 'model', resourceId: event.resourceId });
    }
  });
  return () => {
    wired = false;
    offConfigure();
    offRegistry();
  };
}
