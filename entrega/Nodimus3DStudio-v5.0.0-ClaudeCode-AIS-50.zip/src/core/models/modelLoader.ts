/**
 * AIS-33a — `loadModel`: ÚNICO carregador de modelo 3D (decisão 27). Só `parse(...)` sobre bytes/texto com os loaders de
 * `three/addons/loaders/*` (sem dependência nova); nunca `load(url)` nem rede. Devolve estatísticas, AABB local
 * (`measureLocalBounds`) e as animações. Falhas viram `ModelLoadError` tipado — nada de exceção crua.
 */
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import { ColladaLoader } from 'three/addons/loaders/ColladaLoader.js';
import { measureLocalBounds } from '../physics/bounds';
import { bytesToDataUrl, contentToBytes, isExternalGltfUri, resolveRelativeUri } from './modelBytes';
import { ModelLoadError, type LoadedModel, type ModelMaterialInfo, type ModelSource, type ModelStats } from './types';

const UNSUPPORTED_GLTF_EXTENSIONS: Record<string, string> = {
  KHR_draco_mesh_compression: 'Draco',
  EXT_meshopt_compression: 'Meshopt',
  KHR_texture_basisu: 'KTX2/Basis',
};

const decodeText = (bytes: ArrayBuffer): string => new TextDecoder('utf-8').decode(bytes);

/** JSON de um GLB (primeiro chunk) ou de um `.gltf` (texto). `null` se não for possível ler. */
export function readGltfJson(bytes: ArrayBuffer, ext: 'glb' | 'gltf'): Record<string, any> | null {
  try {
    if (ext === 'gltf') return JSON.parse(decodeText(bytes));
    const view = new DataView(bytes);
    if (bytes.byteLength < 20 || view.getUint32(0, true) !== 0x46546c67) return null; // 'glTF'
    const length = view.getUint32(12, true);
    if (view.getUint32(16, true) !== 0x4e4f534a) return null; // 'JSON'
    return JSON.parse(decodeText(bytes.slice(20, 20 + length)));
  } catch {
    return null;
  }
}

/** Extensões exigidas que não suportamos (Draco/Meshopt/KTX2): erro explícito, nunca falha silenciosa. */
export function unsupportedGltfExtensions(json: Record<string, any> | null): string[] {
  const required: string[] = Array.isArray(json?.extensionsRequired) ? json!.extensionsRequired : [];
  return required.filter((e) => e in UNSUPPORTED_GLTF_EXTENSIONS);
}

/**
 * `.gltf` com `.bin`/imagens externas: lê as dependências dos arquivos fornecidos e as INCORPORA como data URI no JSON,
 * para o `GLTFLoader` não tentar buscar nada na rede. Dependência ausente → `model.missing_dependency` (antes de gravar
 * qualquer coisa).
 */
export function inlineGltfDependencies(json: Record<string, any>, resolveSibling: ModelSource['resolveSibling']): Record<string, any> {
  const missing: string[] = [];
  const inline = (list: unknown, mime: (uri: string) => string) => {
    if (!Array.isArray(list)) return;
    for (const item of list) {
      const uri = item?.uri;
      if (typeof uri !== 'string' || !isExternalGltfUri(uri)) continue;
      const rel = (() => {
        try {
          return decodeURIComponent(uri);
        } catch {
          return uri;
        }
      })();
      const data = resolveSibling?.(rel) ?? null;
      if (!data) missing.push(rel);
      else item.uri = bytesToDataUrl(data, mime(rel));
    }
  };
  const copy = JSON.parse(JSON.stringify(json)) as Record<string, any>;
  inline(copy.buffers, () => 'application/octet-stream');
  inline(copy.images, (u) => (/\.jpe?g$/i.test(u) ? 'image/jpeg' : /\.webp$/i.test(u) ? 'image/webp' : 'image/png'));
  if (missing.length) {
    throw new ModelLoadError('model.missing_dependency', `Dependência(s) ausente(s): ${[...new Set(missing)].join(', ')}`, [...new Set(missing)]);
  }
  return copy;
}

const pad4 = (n: number) => (4 - (n % 4)) % 4;

/**
 * `.gltf` → GLB EM MEMÓRIA: junta todos os buffers (arquivo externo ou data URI) num único chunk BIN e remonta os
 * `bufferViews`. O `GLTFLoader` então lê só bytes (nada de `fetch`/rede). Dependência ausente → `model.missing_dependency`.
 * Imagens externas continuam sendo incorporadas como data URI (`inlineGltfDependencies`).
 */
export function packGltfAsGlb(json: Record<string, any>, resolveSibling: ModelSource['resolveSibling']): ArrayBuffer {
  const withImages = inlineGltfDependencies({ ...json, buffers: [] }, resolveSibling); // imagens (e acusa ausentes)
  const missing: string[] = [];
  const chunks: Uint8Array[] = [];
  const starts: number[] = [];
  let total = 0;
  for (const buffer of Array.isArray(json.buffers) ? json.buffers : []) {
    let data: Uint8Array | null = null;
    const uri = buffer?.uri;
    if (typeof uri === 'string' && !isExternalGltfUri(uri)) data = new Uint8Array(contentToBytes(uri));
    else if (typeof uri === 'string') {
      const rel = (() => {
        try {
          return decodeURIComponent(uri);
        } catch {
          return uri;
        }
      })();
      const found = resolveSibling?.(rel) ?? null;
      if (found) data = new Uint8Array(found);
      else missing.push(rel);
    }
    starts.push(total);
    const bytes = data ?? new Uint8Array(0);
    chunks.push(bytes);
    total += bytes.byteLength + pad4(bytes.byteLength);
  }
  if (missing.length) throw new ModelLoadError('model.missing_dependency', `Dependência(s) ausente(s): ${[...new Set(missing)].join(', ')}`, [...new Set(missing)]);

  const bin = new Uint8Array(total);
  chunks.forEach((c, i) => bin.set(c, starts[i]));
  const out: Record<string, any> = { ...withImages, buffers: total > 0 ? [{ byteLength: total }] : [] };
  out.bufferViews = (Array.isArray(json.bufferViews) ? json.bufferViews : []).map((v: any) => ({ ...v, buffer: 0, byteOffset: (starts[v.buffer] ?? 0) + (v.byteOffset ?? 0) }));

  const jsonBytes = new TextEncoder().encode(JSON.stringify(out));
  const jsonLength = jsonBytes.byteLength + pad4(jsonBytes.byteLength);
  const size = 12 + 8 + jsonLength + (total > 0 ? 8 + total : 0);
  const glb = new Uint8Array(size);
  const view = new DataView(glb.buffer);
  view.setUint32(0, 0x46546c67, true);
  view.setUint32(4, 2, true);
  view.setUint32(8, size, true);
  view.setUint32(12, jsonLength, true);
  view.setUint32(16, 0x4e4f534a, true);
  glb.set(jsonBytes, 20);
  glb.fill(0x20, 20 + jsonBytes.byteLength, 20 + jsonLength);
  if (total > 0) {
    const at = 20 + jsonLength;
    view.setUint32(at, total, true);
    view.setUint32(at + 4, 0x004e4942, true);
    glb.set(bin, at + 8);
  }
  return glb.buffer;
}

function parseGltf(data: ArrayBuffer | string): Promise<{ scene: THREE.Object3D; animations: THREE.AnimationClip[] }> {
  return new Promise((resolve, reject) => {
    new GLTFLoader().parse(
      data,
      '',
      (gltf) => resolve({ scene: gltf.scene, animations: gltf.animations ?? [] }),
      (error) => reject(error)
    );
  });
}

const hex = (c: THREE.Color) => `#${c.getHexString()}`;

/** A textura tem imagem decodificada (ou dados) — `.gltf` com imagem ausente deixa o mapa sem `image`. */
function imageReady(texture: THREE.Texture | null | undefined): boolean {
  const image = texture?.image as { width?: number; height?: number; data?: unknown } | null | undefined;
  if (!image) return false;
  if (image.data) return true;
  return (image.width ?? 1) > 0 && (image.height ?? 1) > 0;
}

function collect(root: THREE.Object3D, animations: THREE.AnimationClip[]): { materials: ModelMaterialInfo[]; stats: ModelStats; boneNames: string[] } {
  const materials = new Map<string, ModelMaterialInfo>();
  const textures = new Set<THREE.Texture>();
  const bones = new Set<THREE.Object3D>();
  let meshes = 0;
  let triangles = 0;
  let vertices = 0;

  root.traverse((child) => {
    if ((child as THREE.Bone).isBone) bones.add(child);
    const mesh = child as THREE.Mesh;
    if (!mesh.isMesh || !mesh.geometry) return;
    meshes++;
    const geo = mesh.geometry;
    const count = geo.index ? geo.index.count : geo.getAttribute('position')?.count ?? 0;
    triangles += Math.floor(count / 3);
    vertices += geo.getAttribute('position')?.count ?? 0;
    const skinned = mesh as THREE.SkinnedMesh;
    if (skinned.isSkinnedMesh && skinned.skeleton) for (const b of skinned.skeleton.bones) bones.add(b);
    const list = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    for (const m of list) {
      if (!m || materials.has(m.uuid)) continue;
      const std = m as THREE.MeshStandardMaterial;
      for (const value of Object.values(m)) if (value instanceof THREE.Texture) textures.add(value);
      materials.set(m.uuid, {
        name: m.name || `Material_${materials.size}`,
        uuid: m.uuid,
        type: m.type,
        color: std.color ? hex(std.color) : null,
        hasMap: Boolean(std.map),
        transparent: Boolean(m.transparent),
        roughness: typeof std.roughness === 'number' ? std.roughness : undefined,
        metalness: typeof std.metalness === 'number' ? std.metalness : undefined,
        emissive: std.emissive ? hex(std.emissive) : null,
        emissiveIntensity: typeof std.emissiveIntensity === 'number' ? std.emissiveIntensity : undefined,
        opacity: typeof m.opacity === 'number' ? m.opacity : undefined,
        mapMissing: Boolean(std.map) && !imageReady(std.map),
        unnamed: !m.name,
      });
    }
  });

  return {
    materials: [...materials.values()],
    boneNames: [...bones].map((b) => b.name).filter((n) => n.length > 0),
    stats: { meshes, triangles, vertices, materials: materials.size, textures: textures.size, bones: bones.size, clips: animations.length },
  };
}

/** Heurística de eixo vertical do arquivo (só dica; o AIS-34 decide). */
function upAxisOf(ext: string, size: { x: number; y: number; z: number } | undefined): 'y' | 'z' {
  if (!size || ext === 'glb' || ext === 'gltf' || ext === 'dae') return 'y';
  return size.z > size.y * 2 && size.z > size.x ? 'z' : 'y';
}

export async function loadModel(source: ModelSource): Promise<LoadedModel> {
  const { bytes, ext, name } = source;
  if (!bytes || bytes.byteLength === 0) throw new ModelLoadError('model.empty', `${name}: arquivo vazio.`);

  let root: THREE.Object3D;
  let animations: THREE.AnimationClip[] = [];

  try {
    if (ext === 'glb' || ext === 'gltf') {
      const json = readGltfJson(bytes, ext);
      if (!json) throw new ModelLoadError('model.parse_failed', `${name}: não é um ${ext.toUpperCase()} válido.`);
      const unsupported = unsupportedGltfExtensions(json);
      if (unsupported.length) {
        throw new ModelLoadError('model.unsupported_extension', `${name}: extensão não suportada (${unsupported.map((e) => UNSUPPORTED_GLTF_EXTENSIONS[e]).join(', ')}).`);
      }
      let parsed;
      if (ext === 'gltf') {
        // buffers (.bin externo ou data URI) são empacotados num GLB em memória: sem fetch, sem rede
        parsed = await parseGltf(packGltfAsGlb(json, source.resolveSibling));
      } else {
        const hasExternal = [...(json.buffers ?? []), ...(json.images ?? [])].some((i: any) => typeof i?.uri === 'string' && isExternalGltfUri(i.uri));
        if (hasExternal) inlineGltfDependencies(json, source.resolveSibling); // só valida a presença
        parsed = await parseGltf(bytes);
      }
      root = parsed.scene;
      animations = parsed.animations;
    } else if (ext === 'obj') {
      root = new OBJLoader().parse(decodeText(bytes));
    } else if (ext === 'fbx') {
      root = new FBXLoader().parse(bytes, '');
      animations = (root as THREE.Object3D & { animations?: THREE.AnimationClip[] }).animations ?? [];
    } else if (ext === 'dae') {
      const collada = new ColladaLoader().parse(decodeText(bytes), '');
      if (!collada) throw new ModelLoadError('model.parse_failed', `${name}: Collada ilegível.`);
      root = collada.scene;
      animations = (collada as unknown as { animations?: THREE.AnimationClip[] }).animations ?? [];
    } else {
      throw new ModelLoadError('model.unsupported_extension', `${name}: extensão .${String(ext)} não suportada.`);
    }
  } catch (error) {
    if (error instanceof ModelLoadError) throw error;
    throw new ModelLoadError('model.parse_failed', `${name}: falha ao ler o modelo (${error instanceof Error ? error.message : String(error)}).`);
  }

  const { materials, stats, boneNames } = collect(root, animations);
  if (stats.meshes === 0 && !(source.allowAnimationOnly && animations.length > 0)) throw new ModelLoadError('model.empty', `${name}: o arquivo não tem nenhuma malha.`);
  const bounds = measureLocalBounds(root);
  return { root, animations, materials, bounds, stats, upAxisHint: upAxisOf(ext, bounds?.size), ext, boneNames };
}

export { resolveRelativeUri };
