/**
 * AIS-33a — fixtures de modelo 3D para testes (Node, sem DOM): GLB mínimo (triângulo e cubo), `.gltf` com `.bin` externo e
 * OBJ textual. Sem imagens (decodificar textura exige DOM). REUTILIZADO pelos AIS-33 a 38c e pelo gate AIS-61b: não duplicar.
 */
import { bytesToDataUrl } from './modelBytes';

export interface MeshData {
  positions: number[];
  /** `null` = sem índice (triângulos sequenciais). */
  indices: number[] | null;
}

/** Um triângulo no plano XY: AABB 1×1×0, centro (0.5, 0.5, 0). */
export const TRIANGLE: MeshData = { positions: [0, 0, 0, 1, 0, 0, 0, 1, 0], indices: [0, 1, 2] };

/** Cubo unitário centrado na origem: 8 vértices, 12 triângulos, AABB 1×1×1. */
export const CUBE: MeshData = {
  positions: [-0.5, -0.5, -0.5, 0.5, -0.5, -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, -0.5, -0.5, -0.5, 0.5, 0.5, -0.5, 0.5, 0.5, 0.5, 0.5, -0.5, 0.5, 0.5],
  indices: [0, 2, 1, 0, 3, 2, 4, 5, 6, 4, 6, 7, 0, 1, 5, 0, 5, 4, 3, 7, 6, 3, 6, 2, 1, 2, 6, 1, 6, 5, 0, 4, 7, 0, 7, 3],
};

/** Caixa `w × h × d` com o centro em (cx, cy, cz): serve para testar rotação, pivô e centragem (AIS-34). */
export function boxMesh(w: number, h: number, d: number, center: { x: number; y: number; z: number } = { x: 0, y: 0, z: 0 }): MeshData {
  const positions: number[] = [];
  for (const z of [-0.5, 0.5]) for (const y of [-0.5, 0.5]) for (const x of [-0.5, 0.5]) positions.push(center.x + x * w, center.y + y * h, center.z + z * d);
  return { positions, indices: CUBE.indices };
}

const pad4 = (n: number) => (4 - (n % 4)) % 4;

function geometryBuffer(mesh: MeshData): { bin: Uint8Array; json: Record<string, any> } {
  const positions = new Float32Array(mesh.positions);
  const indices = mesh.indices ? new Uint16Array(mesh.indices) : null;
  const posBytes = new Uint8Array(positions.buffer);
  const idxBytes = indices ? new Uint8Array(indices.buffer) : new Uint8Array(0);
  const idxPad = pad4(idxBytes.byteLength);
  const bin = new Uint8Array(posBytes.byteLength + idxBytes.byteLength + idxPad);
  bin.set(posBytes, 0);
  if (indices) bin.set(idxBytes, posBytes.byteLength);

  const xs = [0, 1, 2].map((a) => mesh.positions.filter((_, i) => i % 3 === a));
  const accessors: Record<string, any>[] = [
    { bufferView: 0, componentType: 5126, count: positions.length / 3, type: 'VEC3', min: xs.map((v) => Math.min(...v)), max: xs.map((v) => Math.max(...v)) },
  ];
  const bufferViews: Record<string, any>[] = [{ buffer: 0, byteOffset: 0, byteLength: posBytes.byteLength, target: 34962 }];
  const primitive: Record<string, any> = { attributes: { POSITION: 0 } };
  if (indices) {
    accessors.push({ bufferView: 1, componentType: 5123, count: indices.length, type: 'SCALAR' });
    bufferViews.push({ buffer: 0, byteOffset: posBytes.byteLength, byteLength: idxBytes.byteLength, target: 34963 });
    primitive.indices = 1;
  }
  return {
    bin,
    json: {
      asset: { version: '2.0', generator: 'nodimus-test-fixture' },
      scene: 0,
      scenes: [{ nodes: [0] }],
      nodes: [{ mesh: 0, name: 'FixtureMesh' }],
      meshes: [{ primitives: [primitive] }],
      accessors,
      bufferViews,
      buffers: [{ byteLength: bin.byteLength }],
    },
  };
}

export interface BuildGlbOptions {
  /** Extensões que o arquivo EXIGE (ex.: `KHR_draco_mesh_compression` → deve virar `model.unsupported_extension`). */
  extensionsRequired?: string[];
}

/** GLB mínimo válido (JSON + BIN embutido). */
export function buildGlb(mesh: MeshData = CUBE, options: BuildGlbOptions = {}): ArrayBuffer {
  const { bin, json } = geometryBuffer(mesh);
  if (options.extensionsRequired) json.extensionsRequired = options.extensionsRequired;
  const jsonBytes = new TextEncoder().encode(JSON.stringify(json));
  const jsonPad = pad4(jsonBytes.byteLength);
  const jsonChunkLength = jsonBytes.byteLength + jsonPad;
  const total = 12 + 8 + jsonChunkLength + 8 + bin.byteLength;
  const out = new Uint8Array(total);
  const view = new DataView(out.buffer);
  view.setUint32(0, 0x46546c67, true); // 'glTF'
  view.setUint32(4, 2, true);
  view.setUint32(8, total, true);
  view.setUint32(12, jsonChunkLength, true);
  view.setUint32(16, 0x4e4f534a, true); // 'JSON'
  out.set(jsonBytes, 20);
  out.fill(0x20, 20 + jsonBytes.byteLength, 20 + jsonChunkLength); // padding com espaços
  const binStart = 20 + jsonChunkLength;
  view.setUint32(binStart, bin.byteLength, true);
  view.setUint32(binStart + 4, 0x004e4942, true); // 'BIN\0'
  out.set(bin, binStart + 8);
  return out.buffer;
}

/** `.gltf` (texto) com `.bin` EXTERNO: devolve o JSON, os bytes do `.bin` e o nome relativo usado no `uri`. */
export function buildGltfWithExternalBin(mesh: MeshData = CUBE, binName = 'fixture.bin'): { gltf: string; bin: ArrayBuffer; binName: string } {
  const { bin, json } = geometryBuffer(mesh);
  json.buffers = [{ uri: binName, byteLength: bin.byteLength }];
  return { gltf: JSON.stringify(json), bin: bin.buffer.slice(bin.byteOffset, bin.byteOffset + bin.byteLength) as ArrayBuffer, binName };
}

/** `.gltf` com o `.bin` embutido como data URI (sem dependências externas). */
export function buildGltfSelfContained(mesh: MeshData = CUBE): string {
  const { bin, json } = geometryBuffer(mesh);
  json.buffers = [{ uri: bytesToDataUrl(bin), byteLength: bin.byteLength }];
  return JSON.stringify(json);
}

/** OBJ textual (vértices + faces triangulares, índices base 1). */
export function buildObj(mesh: MeshData = CUBE): string {
  const lines = ['# fixture', 'o Fixture'];
  for (let i = 0; i < mesh.positions.length; i += 3) lines.push(`v ${mesh.positions[i]} ${mesh.positions[i + 1]} ${mesh.positions[i + 2]}`);
  const idx = mesh.indices ?? Array.from({ length: mesh.positions.length / 3 }, (_, i) => i);
  for (let i = 0; i < idx.length; i += 3) lines.push(`f ${idx[i] + 1} ${idx[i + 1] + 1} ${idx[i + 2] + 1}`);
  return lines.join('\n') + '\n';
}

export const toBuffer = (text: string): ArrayBuffer => {
  const u8 = new TextEncoder().encode(text);
  return u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength) as ArrayBuffer;
};

/**
 * AIS-37 — GLB SÓ de animação (sem malha): `boneNames` viram nós soltos e o clipe `clipName` anima a translação do primeiro
 * (0 → 1 em 1 s, +1 em X). Serve ao `loadModel({ allowAnimationOnly })` e ao import de arquivos extras de animação.
 */
export function buildAnimationOnlyGlb(boneNames: string[], clipName = 'Walk'): ArrayBuffer {
  const times = new Float32Array([0, 1]);
  const values = new Float32Array([0, 0, 0, 1, 0, 0]);
  const bin = new Uint8Array(times.byteLength + values.byteLength);
  bin.set(new Uint8Array(times.buffer), 0);
  bin.set(new Uint8Array(values.buffer), times.byteLength);
  const json = {
    asset: { version: '2.0', generator: 'nodimus-test-fixture' },
    scene: 0,
    scenes: [{ nodes: boneNames.map((_, i) => i) }],
    nodes: boneNames.map((name, i) => ({ name, translation: [0, i * 0.1, 0] })),
    animations: [{ name: clipName, channels: [{ sampler: 0, target: { node: 0, path: 'translation' } }], samplers: [{ input: 0, output: 1 }] }],
    accessors: [
      { bufferView: 0, componentType: 5126, count: 2, type: 'SCALAR', min: [0], max: [1] },
      { bufferView: 1, componentType: 5126, count: 2, type: 'VEC3' },
    ],
    bufferViews: [
      { buffer: 0, byteOffset: 0, byteLength: times.byteLength },
      { buffer: 0, byteOffset: times.byteLength, byteLength: values.byteLength },
    ],
    buffers: [{ byteLength: bin.byteLength }],
  };
  const jsonBytes = new TextEncoder().encode(JSON.stringify(json));
  const jsonPad = pad4(jsonBytes.byteLength);
  const jsonChunk = jsonBytes.byteLength + jsonPad;
  const total = 12 + 8 + jsonChunk + 8 + bin.byteLength;
  const out = new Uint8Array(total);
  const view = new DataView(out.buffer);
  view.setUint32(0, 0x46546c67, true);
  view.setUint32(4, 2, true);
  view.setUint32(8, total, true);
  view.setUint32(12, jsonChunk, true);
  view.setUint32(16, 0x4e4f534a, true);
  out.set(jsonBytes, 20);
  out.fill(0x20, 20 + jsonBytes.byteLength, 20 + jsonChunk);
  const binStart = 20 + jsonChunk;
  view.setUint32(binStart, bin.byteLength, true);
  view.setUint32(binStart + 4, 0x004e4942, true);
  out.set(bin, binStart + 8);
  return out.buffer;
}
