/**
 * AIS-35 — materiais de um modelo 3D na cena: aplica `materialSlots`/`materialOverride` do nó (decisão 3.2) sobre o clone
 * do modelo, sem tocar nos materiais do cache. Chamado só por `createModelObject` (modal, Viewport, Play e Publish).
 *
 * Regra por slot (nome do material no arquivo): slot com entrada → o slot; senão `materialOverride` do nó; senão o material
 * original. Um material alterado é CLONE do original (o cache compartilha os originais); as texturas criadas aqui e os clones
 * são liberados por `dispose()`.
 *
 * Canais (Execução 2): albedo = PNG do slot (`albedoTexture`) → padrão procedural do override (`textureType`) → mapa original;
 * normal = PNG do slot (`normalTexture`) → normal procedural (`enableNormalMap`) → normal original. Espaço de cor, `flipY` e
 * sinal do `normalScale` vêm de `materialChannels.ts`. As texturas do gerador procedural são compartilhadas (cache do
 * gerador): aqui só se usa CLONE delas, e só o clone é descartado.
 */
import * as THREE from 'three';
import { DEFAULT_MATERIAL_PROPERTIES, type MaterialOverride, type MaterialProperties } from '../../types/material';
import type { ResourceRef } from '../../types/node';
import { toThreeColor } from '../../utils/sceneColor';
import { generateProceduralTexture } from '../../utils/textureGenerator';
import { resolveSlotMaterial } from '../modelImport/materials';
import { normalScaleFor, textureSpecFor, wantsProcedural, type TextureSpec } from './materialChannels';
import type { ModelMaterialInfo } from './types';

export interface MaterialPlanEntry {
  override: MaterialOverride;
  /** Imagem do albedo (data URL), já resolvida de `override.albedoTexture`. */
  albedoDataUrl?: string;
  /** Imagem do mapa normal (data URL), já resolvida de `override.normalTexture`. */
  normalDataUrl?: string;
}

/** Nome do material no arquivo → como desenhá-lo. Material ausente = original. */
export type MaterialPlan = Record<string, MaterialPlanEntry>;

const asImage = (value: unknown): string | undefined => (typeof value === 'string' && value.startsWith('data:image') ? value : undefined);

/** Plano do nó: aplica a regra slot × override a cada material do arquivo. `resolveImage` devolve o data URL de uma `ResourceRef`. */
export function buildMaterialPlan(
  props: Record<string, any> | undefined,
  materials: readonly Pick<ModelMaterialInfo, 'name'>[],
  resolveImage: (ref: ResourceRef) => string | undefined
): MaterialPlan {
  const plan: MaterialPlan = {};
  for (const { name } of materials) {
    const resolved = resolveSlotMaterial(props, name);
    if (resolved.kind === 'original') continue;
    const { albedoTexture, normalTexture } = resolved.override;
    plan[name] = {
      override: resolved.override,
      albedoDataUrl: albedoTexture ? asImage(resolveImage(albedoTexture)) : undefined,
      normalDataUrl: normalTexture ? asImage(resolveImage(normalTexture)) : undefined,
    };
  }
  return plan;
}

const IMAGE_KEYS = new Set(['albedoDataUrl', 'normalDataUrl']);

/** Assinatura barata do plano (a imagem entra por tamanho + final do data URL, não inteira). */
export const planSignature = (plan: MaterialPlan): string =>
  JSON.stringify(plan, (key, value) => (IMAGE_KEYS.has(key) && typeof value === 'string' ? `${value.length}:${value.slice(-48)}` : value));

type StdLike = THREE.Material & {
  color?: THREE.Color;
  roughness?: number;
  metalness?: number;
  emissive?: THREE.Color;
  emissiveIntensity?: number;
  map?: THREE.Texture | null;
  normalMap?: THREE.Texture | null;
  normalScale?: THREE.Vector2;
};

const num = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);

/** Aplica um override num material JÁ clonado. Só toca nos canais que o override traz. */
export function applyOverrideToMaterial(material: THREE.Material, override: MaterialOverride, albedo?: THREE.Texture | null, normal?: THREE.Texture | null): void {
  const m = material as StdLike;
  if (override.color && m.color) m.color.copy(toThreeColor(override.color, 0xffffff));
  if (num(override.roughness) && 'roughness' in m) m.roughness = override.roughness;
  if (num(override.metalness) && 'metalness' in m) m.metalness = override.metalness;
  if (override.emissiveColor && m.emissive) m.emissive.copy(toThreeColor(override.emissiveColor, 0x000000));
  if (num(override.emissiveIntensity) && 'emissiveIntensity' in m) m.emissiveIntensity = override.emissiveIntensity;
  if (num(override.opacity)) {
    m.opacity = override.opacity;
    m.transparent = override.transparent ?? override.opacity < 1;
  } else if (typeof override.transparent === 'boolean') {
    m.transparent = override.transparent;
  }
  if (typeof override.wireframe === 'boolean' && 'wireframe' in m) (m as THREE.MeshStandardMaterial).wireframe = override.wireframe;
  if (albedo && 'map' in m) m.map = albedo;
  if (normal && 'normalMap' in m && m.normalScale) {
    m.normalMap = normal;
    const [x, y] = normalScaleFor(num(override.normalScale) ? override.normalScale : 1, normal.flipY);
    m.normalScale.set(x, y);
  }
  const tiling = override.uvTiling;
  if (tiling && (tiling.x !== 1 || tiling.y !== 1)) {
    const own = new Set<THREE.Texture>([albedo, normal].filter((t): t is THREE.Texture => !!t));
    for (const key of ['map', 'normalMap'] as const) {
      const current = m[key];
      if (!current) continue;
      const tex = own.has(current) ? current : current.clone(); // mapas do arquivo são do cache
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(tiling.x, tiling.y);
      tex.needsUpdate = true;
      m[key] = tex;
    }
  }
  m.needsUpdate = true;
}

/** Textura a partir de um data URL (DOM). Substituível nos testes. */
export type TextureFactory = (dataUrl: string, spec: TextureSpec) => THREE.Texture;

export const domTextureFactory: TextureFactory = (dataUrl, spec) => {
  const texture = new THREE.Texture();
  const image = new Image();
  image.onload = () => {
    texture.image = image;
    texture.needsUpdate = true;
  };
  image.src = dataUrl;
  texture.colorSpace = spec.colorSpace;
  texture.flipY = spec.flipY;
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  return texture;
};

/** Padrão procedural de um override com `textureType` (DOM/Canvas, pelo gerador único). Devolve CLONES com a orientação certa. */
export type ProceduralFactory = (override: MaterialOverride, specs: { albedo: TextureSpec; normal: TextureSpec }) => { albedo?: THREE.Texture; normal?: THREE.Texture };

export const domProceduralFactory: ProceduralFactory = (override, specs) => {
  const props = { ...DEFAULT_MATERIAL_PROPERTIES, ...override, name: '' } as MaterialProperties;
  const generated = generateProceduralTexture(props, 512);
  const adapt = (source: THREE.Texture | undefined, spec: TextureSpec): THREE.Texture | undefined => {
    if (!source) return undefined;
    const texture = source.clone(); // o original é do cache do gerador (compartilhado com os primitivos)
    texture.flipY = spec.flipY;
    texture.colorSpace = spec.colorSpace;
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.needsUpdate = true;
    return texture;
  };
  return {
    albedo: adapt(generated.threeTexture, specs.albedo),
    normal: override.enableNormalMap ? adapt(generated.normalTexture, specs.normal) : undefined,
  };
};

export interface ApplierOptions {
  /** O modelo é glTF/GLB (UV com origem no topo): texturas novas nascem com `flipY = false`. */
  gltf?: boolean;
  procedural?: ProceduralFactory;
}

interface MeshState {
  mesh: THREE.Mesh;
  originals: THREE.Material | THREE.Material[];
}

/**
 * Aplica/reaplica planos de material sobre as malhas de UMA instância do modelo. Guarda os materiais originais (do cache) e
 * devolve-os ao reaplicar; os clones e as texturas criados aqui são descartados a cada troca de plano e em `dispose()`.
 */
export class ModelMaterialApplier {
  private readonly meshes: MeshState[] = [];
  private readonly nameByUuid = new Map<string, string>();
  private owned: { dispose(): void }[] = [];
  private signature = '';

  constructor(
    instance: THREE.Object3D,
    materials: readonly ModelMaterialInfo[],
    private readonly textures: TextureFactory = domTextureFactory,
    private readonly options: ApplierOptions = {}
  ) {
    for (const info of materials) if (info.uuid) this.nameByUuid.set(info.uuid, info.name);
    instance.traverse((child) => {
      const mesh = child as THREE.Mesh;
      if (mesh.isMesh && mesh.material) this.meshes.push({ mesh, originals: mesh.material });
    });
  }

  /** Reaplica o plano (idempotente: o mesmo plano não refaz nada). */
  apply(plan: MaterialPlan): void {
    const signature = planSignature(plan);
    if (signature === this.signature) return;
    this.signature = signature;
    this.releaseOwned();
    const gltf = this.options.gltf === true;
    const procedural = this.options.procedural ?? domProceduralFactory;
    const textureCache = new Map<string, THREE.Texture>();
    const textureFor = (dataUrl: string, spec: TextureSpec) => {
      const key = `${spec.kind}:${spec.flipY}:${dataUrl.length}:${dataUrl.slice(-48)}`;
      let texture = textureCache.get(key);
      if (!texture) {
        texture = this.textures(dataUrl, spec);
        textureCache.set(key, texture);
        this.owned.push(texture);
      }
      return texture;
    };
    const build = (original: THREE.Material): THREE.Material => {
      const name = this.nameByUuid.get(original.uuid) ?? original.name;
      const entry = plan[name];
      if (!entry) return original;
      const clone = original.clone();
      const orig = original as StdLike;
      const albedoSpec = textureSpecFor('albedo', { gltf, like: orig.map ?? null });
      const normalSpec = textureSpecFor('normal', { gltf, like: orig.normalMap ?? null });
      let albedo = entry.albedoDataUrl ? textureFor(entry.albedoDataUrl, albedoSpec) : null;
      let normal = entry.normalDataUrl ? textureFor(entry.normalDataUrl, normalSpec) : null;
      if ((!albedo || !normal) && wantsProcedural(entry.override)) {
        const generated = procedural(entry.override, { albedo: albedoSpec, normal: normalSpec });
        if (!albedo && generated.albedo) {
          albedo = generated.albedo;
          this.owned.push(generated.albedo);
        }
        if (!normal && generated.normal) {
          normal = generated.normal;
          this.owned.push(generated.normal);
        }
      }
      applyOverrideToMaterial(clone, entry.override, albedo, normal);
      this.owned.push(clone);
      return clone;
    };
    for (const state of this.meshes) {
      state.mesh.material = Array.isArray(state.originals) ? state.originals.map(build) : build(state.originals);
    }
  }

  private releaseOwned(): void {
    for (const item of this.owned) item.dispose();
    this.owned = [];
  }

  /** Devolve os materiais originais às malhas e libera o que foi criado aqui. */
  dispose(): void {
    for (const state of this.meshes) state.mesh.material = state.originals;
    this.releaseOwned();
    this.signature = '';
  }
}
