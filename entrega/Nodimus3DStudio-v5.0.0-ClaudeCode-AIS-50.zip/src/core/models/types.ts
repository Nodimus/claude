import type * as THREE from 'three';
import type { LocalBounds } from '../physics/bounds';

/** Extensões de modelo 3D aceitas (decisão 27). Draco, Meshopt e KTX2 ficam fora de escopo. */
export type ModelExt = 'glb' | 'gltf' | 'obj' | 'fbx' | 'dae';
export const MODEL_EXTS: readonly ModelExt[] = ['glb', 'gltf', 'obj', 'fbx', 'dae'];

export const isModelExt = (ext: string): ext is ModelExt => (MODEL_EXTS as readonly string[]).includes(ext.toLowerCase());

/** Códigos de erro de carga (viram `ResourceDiagnostic`/`RuntimeDiagnostic` de fase `import`). */
export type ModelLoadErrorCode = 'model.parse_failed' | 'model.empty' | 'model.missing_dependency' | 'model.unsupported_extension';

/** Erro tipado de `loadModel`: nunca exceção crua na UI. */
export class ModelLoadError extends Error {
  public readonly code: ModelLoadErrorCode;
  /** Dependências ausentes (`model.missing_dependency`), relativas ao arquivo. */
  public readonly missing?: string[];
  constructor(code: ModelLoadErrorCode, message: string, missing?: string[]) {
    super(message);
    this.name = 'ModelLoadError';
    this.code = code;
    this.missing = missing;
  }
}

export interface ModelMaterialInfo {
  name: string;
  type: string;
  /** `#rrggbb` ou `null` quando o material não tem cor. */
  color: string | null;
  hasMap: boolean;
  transparent: boolean;
  /** AIS-35: `uuid` do material no arquivo (liga o nome do slot ao material Three; só vale na sessão). */
  uuid?: string;
  /** AIS-35: detalhes do material (ausentes em materiais que não são PBR). */
  roughness?: number;
  metalness?: number;
  /** `#rrggbb` ou `null`. */
  emissive?: string | null;
  emissiveIntensity?: number;
  opacity?: number;
  /** O arquivo referencia um mapa de cor, mas a imagem não chegou (`texture.missing`). */
  mapMissing?: boolean;
  /** O material não tinha nome no arquivo (o nome acima é gerado: `Material_n`). */
  unnamed?: boolean;
}

export interface ModelStats {
  meshes: number;
  triangles: number;
  vertices: number;
  materials: number;
  textures: number;
  bones: number;
  clips: number;
}

export interface LoadedModel {
  /** Raiz original (NUNCA entra na cena: o cache a guarda e `createModelObject` entrega clones). */
  root: THREE.Object3D;
  animations: THREE.AnimationClip[];
  materials: ModelMaterialInfo[];
  /** AABB local (`measureLocalBounds`); `null` sem malha. */
  bounds: LocalBounds | null;
  stats: ModelStats;
  /** Dica (heurística) do eixo "para cima" do arquivo; a decisão é do AIS-34. */
  upAxisHint: 'y' | 'z';
  /** Formato de origem (AIS-35: `glb`/`gltf` têm UV com origem no topo → texturas novas com `flipY = false`). */
  ext?: ModelExt;
  /** AIS-36: nomes dos ossos do esqueleto real, na ordem da hierarquia (vazio = sem esqueleto). */
  boneNames?: string[];
}

export interface ModelSource {
  bytes: ArrayBuffer;
  ext: ModelExt;
  name: string;
  /**
   * `.gltf`: lê um arquivo vizinho (`.bin`, imagem) pelo caminho relativo ao modelo. `null` = ausente.
   * Só usado para dependências externas; sem rede, nunca `load(url)`.
   */
  resolveSibling?: (relPath: string) => ArrayBuffer | null;
  /** AIS-37: aceita arquivo SEM malha desde que traga animações (arquivo só de animação, ex.: `Walk.fbx`). */
  allowAnimationOnly?: boolean;
}
