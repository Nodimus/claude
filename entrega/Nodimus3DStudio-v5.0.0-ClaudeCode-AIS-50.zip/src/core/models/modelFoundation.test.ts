import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import { ModelCache, disposeObject3D } from './modelCache';
import { createModelObject, type ModelDiagnosticInput, type ModelSourceBinding } from './createModelObject';
import { loadModel } from './modelLoader';
import { modelRefOf, modelKeyOf } from './modelNodeSync';
import { CUBE, TRIANGLE, buildGlb, buildGltfWithExternalBin, toBuffer } from './modelFixtures';
import { bytesToDataUrl } from './modelBytes';
import { ResourceRegistry } from '../resources/ResourceRegistry';
import { AssetPipeline, type PipelineIO } from '../resources/AssetPipeline';
import { BUILTIN_IMPORTERS } from '../resources/builtinImporters';
import { extractDependencies } from '../resources/dependencyExtractor';
import { planDeletion, type FileLike, type ResourceOpsContext } from '../resourceDeletion';
import { DEFAULT_MODEL_IMPORT_SETTINGS, ModelImportSettingsSchema, parseModelImportSettings } from '../../schemas/v1/modelImportSettings.schema';
import { NODE_DEFINITIONS, createDefaultNode } from '../../nodes/registry';
import { RuntimeObjectFactory } from '../../runtime/RuntimeObjectFactory';

const glbUrl = (mesh = CUBE) => bytesToDataUrl(buildGlb(mesh), 'model/gltf-binary');

/** Fonte de teste: um mapa de recursos `id → { uri, content }`. */
function makeSource(files: Record<string, { uri: string; content?: string; hash?: string }>, reports: ModelDiagnosticInput[] = []): ModelSourceBinding {
  return {
    resolve: (ref) => {
      const f = files[ref.id];
      return f ? { resourceId: ref.id, uri: f.uri, contentHash: f.hash ?? 'h1', content: f.content } : null;
    },
    readFile: (uri) => Object.values(files).find((f) => f.uri === uri)?.content,
    report: (d) => reports.push(d),
  };
}

const watchDispose = (root: THREE.Object3D) => {
  const log = { geometry: 0, material: 0 };
  root.traverse((c) => {
    const mesh = c as THREE.Mesh;
    if (!mesh.isMesh) return;
    mesh.geometry.addEventListener('dispose', () => log.geometry++);
    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    for (const m of mats) m.addEventListener('dispose', () => log.material++);
  });
  return log;
};

describe('ModelCache: acquire/release e descarte (AIS-33a-C08)', () => {
  it('compartilha a carga, conta referências e só descarta no zero', async () => {
    const cache = new ModelCache();
    let loads = 0;
    const load = () => {
      loads++;
      return loadModel({ bytes: buildGlb(CUBE), ext: 'glb', name: 'c.glb' });
    };
    const a = cache.acquire('r1', 'h1', load);
    const b = cache.acquire('r1', 'h1', load);
    expect(loads).toBe(1);
    expect(cache.refCount('r1', 'h1')).toBe(2);
    const model = await a.promise;
    expect(await b.promise).toBe(model);
    const log = watchDispose(model.root);
    a.release();
    a.release(); // idempotente
    expect(cache.refCount('r1', 'h1')).toBe(1);
    expect(log.geometry).toBe(0);
    b.release();
    expect(cache.size).toBe(0);
    expect(log.geometry).toBe(1);
    expect(log.material).toBeGreaterThanOrEqual(1);
  });
  it('reimport invalida: quem tem concessão segue com o antigo; o próximo acquire recarrega; o antigo cai ao soltar', async () => {
    const cache = new ModelCache();
    const load = () => loadModel({ bytes: buildGlb(CUBE), ext: 'glb', name: 'c.glb' });
    const old = cache.acquire('r1', 'h1', load);
    const oldModel = await old.promise;
    const log = watchDispose(oldModel.root);
    cache.invalidate('r1');
    expect(cache.size).toBe(0);
    expect(log.geometry).toBe(0); // ainda tem dono
    const fresh = cache.acquire('r1', 'h1', load);
    expect(await fresh.promise).not.toBe(oldModel);
    old.release();
    expect(log.geometry).toBe(1);
    fresh.release();
  });
  it('invalidar sem donos descarta na hora; carga com falha não fica em cache', async () => {
    const cache = new ModelCache();
    const lease = cache.acquire('r2', 'h', () => loadModel({ bytes: buildGlb(TRIANGLE), ext: 'glb', name: 't.glb' }));
    const model = await lease.promise;
    lease.release();
    expect(cache.size).toBe(0);
    const log = watchDispose(model.root);
    disposeObject3D(model.root);
    expect(log.geometry).toBe(1);
    const bad = cache.acquire('r3', 'h', () => Promise.reject(new Error('x')));
    await expect(bad.promise).rejects.toThrow();
    expect(cache.size).toBe(0);
  });
});

describe('createModelObject: marcador → modelo / ausente (AIS-33a-C03, C05, C06)', () => {
  it('nasce com marcador e troca pelo modelo; offset aplicado ao conteúdo', async () => {
    const cache = new ModelCache();
    const reports: ModelDiagnosticInput[] = [];
    const source = makeSource({ r1: { uri: 'res://models/c.glb', content: glbUrl() } }, reports);
    const h = createModelObject({ id: 'r1', type: 'mesh', path: 'res://models/c.glb' }, { source, cache, offset: { x: 1, y: 2, z: 3 } });
    expect(h.status()).toBe('loading');
    expect(h.object.children.some((c) => c.userData.modelMarker)).toBe(true);
    expect(await h.ready).toBe('ready');
    expect(h.object.children.some((c) => c.userData.modelMarker)).toBe(false);
    const content = h.object.getObjectByName('ModelContent')!;
    expect(content.position.toArray()).toEqual([1, 2, 3]);
    h.setOffset({ x: 0, y: 0.5, z: 0 });
    expect(content.position.toArray()).toEqual([0, 0.5, 0]);
    expect(reports).toEqual([]);
    h.release();
  });
  it('duas instâncias compartilham geometria; soltar uma não afeta a outra', async () => {
    const cache = new ModelCache();
    const source = makeSource({ r1: { uri: 'res://models/c.glb', content: glbUrl() } });
    const a = createModelObject({ id: 'r1' }, { source, cache });
    const b = createModelObject({ id: 'r1' }, { source, cache });
    await Promise.all([a.ready, b.ready]);
    expect(cache.refCount('r1', 'h1')).toBe(2);
    const geoA = (a.object.getObjectByName('ModelContent')!.children[0] as THREE.Mesh).geometry ?? (a.object.getObjectByName('ModelContent') as THREE.Mesh).geometry;
    const geoB = (b.object.getObjectByName('ModelContent')!.children[0] as THREE.Mesh).geometry ?? (b.object.getObjectByName('ModelContent') as THREE.Mesh).geometry;
    expect(geoA).toBe(geoB);
    a.release();
    expect(cache.refCount('r1', 'h1')).toBe(1);
    b.release();
    expect(cache.size).toBe(0);
  });
  it('arquivo ausente: marcador vermelho + model.unresolved; a referência é preservada', async () => {
    const reports: ModelDiagnosticInput[] = [];
    const ref = { id: 'sumiu', type: 'mesh', path: 'res://models/sumiu.glb' };
    const h = createModelObject(ref, { source: makeSource({}, reports), cache: new ModelCache() });
    expect(await h.ready).toBe('unresolved');
    const marker = h.object.children.find((c) => c.userData.modelMarker) as THREE.Mesh;
    expect((marker.material as THREE.MeshBasicMaterial).color.getHex()).toBe(0xef4444);
    expect(reports.map((r) => r.code)).toEqual(['model.unresolved']);
    expect(h.object.userData.modelRef).toBe(ref);
    h.release();
  });
  it('conteúdo corrompido → failed + código tipado; sem fonte configurada → unresolved sem exceção', async () => {
    const reports: ModelDiagnosticInput[] = [];
    const bad = createModelObject({ id: 'r1' }, { source: makeSource({ r1: { uri: 'res://models/c.glb', content: 'data:model/gltf-binary;base64,AAAA' } }, reports), cache: new ModelCache() });
    expect(await bad.ready).toBe('failed');
    expect(reports[0].code).toBe('model.parse_failed');
    bad.release();
    const none = createModelObject({ id: 'x' }, { cache: new ModelCache() });
    expect(await none.ready).toBe('unresolved');
    none.release();
  });
  it('.gltf com .bin vizinho do projeto carrega pela fonte (resolveSibling)', async () => {
    const { gltf, bin } = buildGltfWithExternalBin(CUBE, 'cube.bin');
    const source = makeSource({
      g: { uri: 'res://models/hero/hero.gltf', content: gltf },
      b: { uri: 'res://models/hero/cube.bin', content: bytesToDataUrl(bin) },
    });
    const h = createModelObject({ id: 'g' }, { source, cache: new ModelCache() });
    expect(await h.ready).toBe('ready');
    h.release();
  });
});

describe('Nó e fábrica de runtime (AIS-33a-C05)', () => {
  it('MeshInstance tem model e modelOffset no registry, sem NodeType novo', () => {
    const keys = NODE_DEFINITIONS.MeshInstance.propertyDescriptors.map((d) => d.key);
    expect(keys).toEqual(expect.arrayContaining(['model', 'modelOffset']));
    expect(NODE_DEFINITIONS.MeshInstance.propertyDescriptors.find((d) => d.key === 'model')!.type).toBe('resource');
    expect(Object.keys(NODE_DEFINITIONS).filter((k) => /model/i.test(k))).toEqual([]);
    // sem `model` o nó é idêntico ao de antes
    const node = createDefaultNode('MeshInstance', 'M', null);
    expect(node.properties.model).toBeUndefined();
    expect(modelRefOf(node)).toBeNull();
    expect(modelRefOf({ id: 'n', properties: { model: { id: 'r1' } } })).toEqual({ id: 'r1' });
    expect(modelKeyOf({ id: 'zzz' })).toContain('missing');
  });
  it('o Play cria o nó com model pela MESMA createModelObject e solta a concessão no destroy', async () => {
    const cache = new ModelCache();
    const factory = new RuntimeObjectFactory();
    // a fábrica usa a fonte configurada (global); aqui só se prova o ramo e o descarte sem fonte: marcador, sem exceção
    const obj = factory.create({ persistentNodeId: 'n1', type: 'MeshInstance', name: 'Hero', properties: { model: { id: 'r1' }, modelOffset: { x: 0, y: 1, z: 0 } } });
    expect(obj.userData.modelHandle).toBeDefined();
    expect(obj.userData.runtimeNodeId).toBe('n1');
    factory.destroy(obj);
    expect(factory.liveCount).toBe(0);
    expect(cache.size).toBe(0);
    const plain = factory.create({ persistentNodeId: 'n2', type: 'MeshInstance', name: 'Cube', properties: { meshType: 'CubeMesh' } });
    expect(plain.userData.modelHandle).toBeUndefined();
    factory.destroy(plain);
  });
});

type F = Record<string, any>;
const file = (path: string, extra: F = {}) => ({ path, name: path.split('/').filter(Boolean).pop()!, isDirectory: false, updatedAt: '2026-10-05T00:00:00Z', ...extra });

function makeProject(files: F = {}) {
  const project = { files: { ...files } as F };
  const io: PipelineIO = {
    files: () => project.files,
    write: (uri, content, meta) => {
      project.files[uri] = { ...(project.files[uri] ?? file(uri)), path: uri, name: uri.split('/').pop(), isDirectory: false, content, size: content.length, ...meta };
    },
  };
  const registry = new ResourceRegistry();
  const pipeline = new AssetPipeline(registry, io);
  for (const importer of BUILTIN_IMPORTERS) pipeline.registerImporter(importer);
  return { project, registry, pipeline };
}

describe('modelImporter no AssetPipeline (AIS-33a-C01, C02)', () => {
  it('importa GLB real: estatísticas e AABB derivadas; settings = ModelImportSettings; original preservado', async () => {
    const { project, pipeline } = makeProject();
    const content = glbUrl();
    const r = await pipeline.import({ uri: 'res://models/cube.glb', content });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect((r.derived as any).stats).toMatchObject({ meshes: 1, triangles: 12 });
    expect(project.files['res://models/cube.glb'].content).toBe(content); // sem conversão
    const settings = project.files['res://models/cube.glb'].importSettings;
    expect(settings).toMatchObject({ upAxis: 'y', scale: 1, pivot: 'bottom' });
    expect(project.files['res://models/cube.glb'].importerVersion).toBe(2);
  });
  it('corrompido/vazio/extensão: erro tipado e NADA é gravado', async () => {
    const { project, pipeline } = makeProject();
    const bad = await pipeline.import({ uri: 'res://models/ruim.glb', content: 'data:model/gltf-binary;base64,AAAA' });
    expect(bad.ok).toBe(false);
    expect(bad.diagnostics[0].code).toBe('model.parse_failed');
    const empty = await pipeline.import({ uri: 'res://models/vazio.glb', content: '' });
    expect(empty.diagnostics[0].code).toBe('model.empty');
    const draco = await pipeline.import({ uri: 'res://models/d.glb', content: bytesToDataUrl(buildGlb(CUBE, { extensionsRequired: ['KHR_draco_mesh_compression'] })) });
    expect(draco.diagnostics.some((d) => d.code === 'model.unsupported_extension')).toBe(true);
    expect(Object.keys(project.files)).toEqual([]);
  });
  it('.gltf: sem o .bin → model.missing_dependency (nada gravado); com o .bin no projeto → importa', async () => {
    const { gltf, bin } = buildGltfWithExternalBin(CUBE, 'cube.bin');
    const { project, pipeline } = makeProject();
    const miss = await pipeline.import({ uri: 'res://models/hero/hero.gltf', content: gltf });
    expect(miss.ok).toBe(false);
    expect(miss.diagnostics[0].code).toBe('model.missing_dependency');
    expect(project.files['res://models/hero/hero.gltf']).toBeUndefined();

    project.files['res://models/hero/cube.bin'] = file('res://models/hero/cube.bin', { content: bytesToDataUrl(bin) });
    const ok = await pipeline.import({ uri: 'res://models/hero/hero.gltf', content: gltf });
    expect(ok.ok).toBe(true);
  });
  it('reimport preserva o resourceId', async () => {
    const { pipeline } = makeProject();
    const a = await pipeline.import({ uri: 'res://models/c.glb', content: glbUrl() });
    const b = await pipeline.import({ uri: 'res://models/c.glb', content: glbUrl(TRIANGLE) });
    expect(a.ok && b.ok && a.resourceId === b.resourceId).toBe(true);
  });
});

describe('dependências: properties.model e .gltf (AIS-33a-C07)', () => {
  it('extractDependencies acha o modelo por identidade na cena e os .bin/imagens externos de um .gltf', () => {
    const scene = JSON.stringify({ nodes: { n1: { id: 'n1', type: 'MeshInstance', properties: { model: { id: 'res_abc123', type: 'mesh', path: 'res://models/hero.glb', label: 'hero.glb' } } } } });
    const deps = extractDependencies('scene', 'res://scenes/Main.scene.json', scene);
    expect(deps.some((d) => d.targetId === 'res_abc123' && d.targetUri === 'res://models/hero.glb' && d.strength === 'runtime')).toBe(true);

    const gltf = JSON.stringify({ buffers: [{ uri: 'hero.bin' }, { uri: 'data:application/octet-stream;base64,AAAA' }], images: [{ uri: 'tex/a%20b.png' }, { uri: 'https://x/y.png' }] });
    const gdeps = extractDependencies('mesh', 'res://models/hero/hero.gltf', gltf).map((d) => d.targetUri).sort();
    expect(gdeps).toEqual(['res://models/hero/hero.bin', 'res://models/hero/tex/a b.png']);
    expect(extractDependencies('mesh', 'res://models/c.glb', glbUrl())).toEqual([]);
  });
  it('excluir o modelo lista o nó que o usa (deleteResource); o .bin do .gltf também é consumidor', () => {
    const registry = new ResourceRegistry();
    const { gltf } = buildGltfWithExternalBin(CUBE, 'cube.bin');
    const files: Record<string, FileLike & F> = {
      'res://models/hero.glb': file('res://models/hero.glb', { content: glbUrl(), resourceId: 'res_model1' }),
      'res://scenes/Main.scene.json': file('res://scenes/Main.scene.json', {
        content: JSON.stringify({ nodes: { n1: { id: 'n1', type: 'MeshInstance', properties: { model: { id: 'res_model1', type: 'mesh', path: 'res://models/hero.glb' } } } } }),
        resourceId: 'res_scene1',
      }),
      'res://models/p/p.gltf': file('res://models/p/p.gltf', { content: buildGltfWithExternalBin(CUBE, 'cube.bin').gltf, resourceId: 'res_gltf1' }),
      'res://models/p/cube.bin': file('res://models/p/cube.bin', { content: bytesToDataUrl(new Uint8Array([1, 2, 3])), resourceId: 'res_bin1' }),
    };
    void gltf;
    registry.syncFromProject({ files } as never);
    const ctx = { registry, now: () => 'x', activeScene: () => null, io: { files: () => files, commit: () => undefined } } as unknown as ResourceOpsContext;
    expect(planDeletion(ctx, 'res://models/hero.glb').consumers.map((c) => c.uri)).toEqual(['res://scenes/Main.scene.json']);
    expect(planDeletion(ctx, 'res://models/p/cube.bin').consumers.map((c) => c.uri)).toEqual(['res://models/p/p.gltf']);
  });
});

describe('ModelImportSettings (Zod v1, leitura tolerante)', () => {
  it('padrões neutros e leitura que nunca lança', () => {
    expect(DEFAULT_MODEL_IMPORT_SETTINGS).toMatchObject({ schemaVersion: 1, upAxis: 'y', scale: 1, pivot: 'bottom', pivotOffset: { x: 0, y: 0, z: 0 }, outputs: [] });
    expect(parseModelImportSettings(undefined)).toEqual(DEFAULT_MODEL_IMPORT_SETTINGS);
    const mixed = parseModelImportSettings({ scale: 2, pivot: 'base', upAxis: 'z', lixo: 1 });
    expect(mixed).toMatchObject({ scale: 2, pivot: 'bottom', upAxis: 'z' });
    expect(parseModelImportSettings({ scale: -1, outputs: 'x' })).toMatchObject({ scale: 1, outputs: [] });
  });
  it('aceita rig/materials como ResourceRef e é aditivo', () => {
    const r = ModelImportSettingsSchema.parse({ rig: { id: 'res_1', path: 'res://materials/a_rig.json' }, materials: { id: 'res_2' }, outputs: [{ id: 'res_3' }] });
    expect(r.rig?.id).toBe('res_1');
    expect(r.outputs).toHaveLength(1);
  });
});

describe('GLB como texto/DOM não é necessário', () => {
  it('toBuffer preserva UTF-8', () => {
    expect(new TextDecoder().decode(toBuffer('açaí'))).toBe('açaí');
  });
});
