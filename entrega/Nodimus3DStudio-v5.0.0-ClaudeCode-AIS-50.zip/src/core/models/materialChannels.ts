/**
 * AIS-35 (Execução 2) — regras puras dos canais de textura de um material de MODELO 3D: espaço de cor, orientação (`flipY`) e
 * sinal do `normalScale`. Usadas só pelo caminho de modelo (`ModelMaterialApplier`); `createThreeMaterial` (primitivos,
 * Studio 3D) não muda.
 *
 * - Albedo é cor (sRGB); normal é dado linear (`NoColorSpace`).
 * - UV de glTF tem origem no canto superior esquerdo: a textura precisa de `flipY = false`. OBJ/FBX/DAE e os primitivos
 *   seguem o padrão do three (`flipY = true`). Se o material já tinha mapa, a orientação dele manda (herda).
 * - Normal map sem tangentes (caso comum): o shader do three deriva o tangente das UVs, com o bitangente no sentido de +v.
 *   Com `flipY = false` o +v aponta para BAIXO da imagem, mas o PNG gerado segue a convenção OpenGL (verde = para cima), então
 *   o `y` do `normalScale` troca de sinal: `(k, -k)`. Com `flipY = true`, `(k, k)`.
 */
import * as THREE from 'three';
import type { MaterialOverride } from '../../types/material';

export type ChannelKind = 'albedo' | 'normal';

export interface TextureSpec {
  kind: ChannelKind;
  colorSpace: string;
  flipY: boolean;
}

/** `glb`/`gltf` usam UV com origem no topo. */
export const isGltfExt = (ext: string | undefined): boolean => ext === 'glb' || ext === 'gltf';

/** Como criar a textura de um canal. `like` = mapa original do material (herda a orientação, se existir). */
export function textureSpecFor(kind: ChannelKind, options: { gltf: boolean; like?: { flipY: boolean } | null }): TextureSpec {
  return {
    kind,
    colorSpace: kind === 'albedo' ? THREE.SRGBColorSpace : THREE.NoColorSpace,
    flipY: options.like ? options.like.flipY : !options.gltf,
  };
}

/** `normalScale` para a intensidade `k` e a orientação da textura (ver o cabeçalho). */
export function normalScaleFor(k: number, flipY: boolean): [number, number] {
  const s = Number.isFinite(k) ? k : 1;
  return flipY ? [s, s] : [s, -s];
}

/** O override pede um padrão procedural gerado em runtime (nó com `textureType`)? `custom_image` não conta (é arquivo). */
export function wantsProcedural(override: MaterialOverride): boolean {
  const t = override.textureType;
  return !!t && t !== 'none' && t !== 'custom_image';
}
