/**
 * Conteúdo persistido do projeto → bytes. O projeto guarda binários como data URL base64 e texto como texto
 * (`.gltf`, `.obj`, `.dae`, `.fbx` ASCII). Funções puras, sem DOM (`atob`/`btoa` existem no Node ≥ 16).
 */

const DATA_URL = /^data:([^;,]*)(;[^,]*)?,([\s\S]*)$/;

export function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64.replace(/\s/g, ''));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function bytesToBase64(bytes: Uint8Array): string {
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

export function toArrayBuffer(bytes: Uint8Array): ArrayBuffer {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
}

/** `data:…;base64,…` → bytes; qualquer outro texto → UTF-8. */
export function contentToBytes(content: string): ArrayBuffer {
  const m = DATA_URL.exec(content);
  if (m) {
    const isBase64 = (m[2] ?? '').includes('base64');
    return toArrayBuffer(isBase64 ? base64ToBytes(m[3]) : new TextEncoder().encode(decodeURIComponent(m[3])));
  }
  return toArrayBuffer(new TextEncoder().encode(content));
}

export function bytesToDataUrl(bytes: ArrayBuffer | Uint8Array, mime = 'application/octet-stream'): string {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  return `data:${mime};base64,${bytesToBase64(u8)}`;
}

/** Pasta de um caminho (`res://models/a/b.gltf` → `res://models/a/`). */
export function dirOfUri(uri: string): string {
  const i = uri.lastIndexOf('/');
  return i >= 0 ? uri.slice(0, i + 1) : '';
}

/** Resolve `rel` (com `./`, `../` e `%20`) contra a pasta de `baseUri`. */
export function resolveRelativeUri(baseUri: string, rel: string): string {
  const decoded = (() => {
    try {
      return decodeURIComponent(rel);
    } catch {
      return rel;
    }
  })();
  const base = dirOfUri(baseUri);
  const m = /^(res:\/\/)(.*)$/.exec(base);
  const prefix = m ? m[1] : '';
  const parts = (m ? m[2] : base).split('/').filter(Boolean);
  for (const seg of decoded.split('/')) {
    if (seg === '' || seg === '.') continue;
    if (seg === '..') parts.pop();
    else parts.push(seg);
  }
  return prefix + parts.join('/');
}

/** URI externa de um `.gltf` (não `data:` nem URL de rede)? */
export const isExternalGltfUri = (uri: string): boolean => !/^(data:|https?:|blob:)/i.test(uri);
