import { describe, expect, it, vi } from 'vitest';
import * as THREE from 'three';
import { isGltfExt, normalScaleFor, textureSpecFor, wantsProcedural } from './materialChannels';
import { ModelMaterialApplier, applyOverrideToMaterial, buildMaterialPlan, planSignature, type ProceduralFactory, type TextureFactory } from './modelMaterials';
import { patchNodeMaterial, presetNodeMaterial, readNodeMaterial } from '../material/nodeMaterial';
import { MATERIAL_PRESETS } from '../../types/material';
import { collectMaterialSlots, editFromInfo, materialSlotFromEdit } from '../modelImport/materials';
import type { ModelMaterialInfo } from './types';

const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
const NORMAL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAEklEQVR42mM8c+bMfwYiAOOoQgBYAAkbPp5QAAAAAElFTkSuQmCC';

const info = (over: Partial<ModelMaterialInfo> = {}): ModelMaterialInfo => ({ name: 'Casco', uuid: 'u1', type: 'MeshStandardMaterial', color: '#808080', hasMap: false, transparent: false, ...over });

describe('canais de textura de modelo (regras puras)', () => {
  it('albedo é sRGB, normal é dado linear', () => {
    expect(textureSpecFor('albedo', { gltf: false }).colorSpace).toBe(THREE.SRGBColorSpace);
    expect(textureSpecFor('normal', { gltf: false }).colorSpace).toBe(THREE.NoColorSpace);
  });
  it('flipY: glTF sem mapa original = false; outros formatos = true; mapa original manda', () => {
    expect(textureSpecFor('albedo', { gltf: true }).flipY).toBe(false);
    expect(textureSpecFor('albedo', { gltf: false }).flipY).toBe(true);
    expect(textureSpecFor('normal', { gltf: true, like: { flipY: true } }).flipY).toBe(true);
    expect(textureSpecFor('normal', { gltf: false, like: { flipY: false } }).flipY).toBe(false);
    expect(isGltfExt('glb')).toBe(true);
    expect(isGltfExt('gltf')).toBe(true);
    expect(isGltfExt('obj')).toBe(false);
    expect(isGltfExt(undefined)).toBe(false);
  });
  it('normalScale: (k, k) com flipY e (k, -k) sem flipY; valor inválido vira 1', () => {
    expect(normalScaleFor(0.7, true)).toEqual([0.7, 0.7]);
    expect(normalScaleFor(0.7, false)).toEqual([0.7, -0.7]);
    expect(normalScaleFor(Number.NaN, false)).toEqual([1, -1]);
  });
  it('wantsProcedural: só padrão procedural de verdade', () => {
    expect(wantsProcedural({})).toBe(false);
    expect(wantsProcedural({ textureType: 'none' })).toBe(false);
    expect(wantsProcedural({ textureType: 'custom_image' })).toBe(false);
    expect(wantsProcedural({ textureType: 'wood' })).toBe(true);
    expect(wantsProcedural({ textureType: 'fabric' })).toBe(true);
  });
});

describe('normalTexture no MaterialOverride', () => {
  const ref = { id: 'res_n', path: 'res://textures/a/2.png' };
  it('sobrevive a patchNodeMaterial e presetNodeMaterial (como o albedo) e não vai para MaterialProperties', () => {
    const props = { materialOverride: { roughness: 0.3, normalTexture: ref } };
    expect(patchNodeMaterial(props, { roughness: 0.9 }).normalTexture).toEqual(ref);
    expect(patchNodeMaterial(props, { normalTexture: null }).normalTexture).toBeUndefined();
    expect(presetNodeMaterial(props, MATERIAL_PRESETS[0]).normalTexture).toEqual(ref);
    expect('normalTexture' in readNodeMaterial(props)).toBe(false);
  });
  it('o slot gerado no import referencia o normal por ResourceRef', () => {
    const i = info();
    const e = { ...editFromInfo(i), pattern: 'brushed' as const };
    const slot = materialSlotFromEdit(e, i, { id: 'a' }, ref)!;
    expect(slot.albedoTexture).toEqual({ id: 'a' });
    expect(slot.normalTexture).toEqual(ref);
    const slots = collectMaterialSlots([e], [i], new Map([['Casco', { id: 'a' }]]), new Map([['Casco', ref]]));
    expect(slots.Casco.normalTexture).toEqual(ref);
  });
  it('buildMaterialPlan resolve o PNG normal e a assinatura muda quando ele muda', () => {
    const props = { materialSlots: { Casco: { normalTexture: ref } } };
    const names = [{ name: 'Casco' }];
    const a = buildMaterialPlan(props, names, () => NORMAL);
    expect(a.Casco.normalDataUrl).toBe(NORMAL);
    const b = buildMaterialPlan(props, names, () => PNG);
    expect(planSignature(a)).not.toBe(planSignature(b));
    expect(buildMaterialPlan(props, names, () => 'não-imagem').Casco.normalDataUrl).toBeUndefined();
  });
});

describe('aplicação do normal e do padrão procedural no modelo', () => {
  const makeModel = (withMaps = false) => {
    const original = new THREE.MeshStandardMaterial({ color: 0x808080 });
    original.name = 'Casco';
    if (withMaps) {
      original.map = new THREE.Texture();
      original.map.flipY = false;
      original.normalMap = new THREE.Texture();
      original.normalMap.flipY = false;
    }
    const other = new THREE.MeshStandardMaterial();
    other.name = 'Vidro';
    const root = new THREE.Group();
    const a = new THREE.Mesh(new THREE.BoxGeometry(), original);
    const b = new THREE.Mesh(new THREE.BoxGeometry(), other);
    root.add(a, b);
    return { root, a, b, original, other, infos: [info({ uuid: original.uuid }), info({ name: 'Vidro', uuid: other.uuid })] };
  };
  const factory = (): { fn: TextureFactory; specs: { url: string; flipY: boolean; cs: string }[] } => {
    const specs: { url: string; flipY: boolean; cs: string }[] = [];
    return {
      specs,
      fn: (url, spec) => {
        specs.push({ url, flipY: spec.flipY, cs: spec.colorSpace });
        const t = new THREE.Texture();
        t.flipY = spec.flipY;
        t.colorSpace = spec.colorSpace as THREE.ColorSpace;
        return t;
      },
    };
  };

  it('glTF: albedo sRGB e normal linear com flipY=false e normalScale (k,-k); o original fica intacto', () => {
    const { root, a, original, infos } = makeModel();
    const f = factory();
    const applier = new ModelMaterialApplier(root, infos, f.fn, { gltf: true });
    applier.apply({ Casco: { override: { normalScale: 0.8 }, albedoDataUrl: PNG, normalDataUrl: NORMAL } });
    const m = a.material as THREE.MeshStandardMaterial;
    expect(m).not.toBe(original);
    expect(m.map!.flipY).toBe(false);
    expect(m.map!.colorSpace).toBe(THREE.SRGBColorSpace);
    expect(m.normalMap!.flipY).toBe(false);
    expect(m.normalMap!.colorSpace).toBe(THREE.NoColorSpace);
    expect(m.normalScale.x).toBeCloseTo(0.8);
    expect(m.normalScale.y).toBeCloseTo(-0.8);
    expect(original.normalMap).toBeNull();
    expect(original.map).toBeNull();
    expect(original.normalScale.y).toBe(1);
  });

  it('OBJ/FBX/DAE: flipY=true e normalScale (k,k)', () => {
    const { root, a, infos } = makeModel();
    const applier = new ModelMaterialApplier(root, infos, factory().fn, { gltf: false });
    applier.apply({ Casco: { override: {}, normalDataUrl: NORMAL } });
    const m = a.material as THREE.MeshStandardMaterial;
    expect(m.normalMap!.flipY).toBe(true);
    expect([m.normalScale.x, m.normalScale.y]).toEqual([1, 1]);
  });

  it('a orientação do mapa original do material manda sobre o formato', () => {
    const { root, infos } = makeModel(true);
    const f = factory();
    new ModelMaterialApplier(root, infos, f.fn, { gltf: false }).apply({ Casco: { override: {}, albedoDataUrl: PNG, normalDataUrl: NORMAL } });
    expect(f.specs.every((s) => s.flipY === false)).toBe(true);
  });

  it('textureType do override gera o padrão por clones com a orientação certa; só os clones são descartados', () => {
    const { root, a, infos } = makeModel();
    const shared = { albedo: new THREE.Texture(), normal: new THREE.Texture() };
    const disposed: string[] = [];
    const procedural: ProceduralFactory = vi.fn((_o, specs) => {
      const albedo = shared.albedo.clone();
      albedo.flipY = specs.albedo.flipY;
      const normal = shared.normal.clone();
      normal.flipY = specs.normal.flipY;
      normal.colorSpace = specs.normal.colorSpace as THREE.ColorSpace;
      albedo.addEventListener('dispose', () => disposed.push('albedo-clone'));
      normal.addEventListener('dispose', () => disposed.push('normal-clone'));
      return { albedo, normal };
    });
    shared.albedo.addEventListener('dispose', () => disposed.push('SHARED-albedo'));
    shared.normal.addEventListener('dispose', () => disposed.push('SHARED-normal'));
    const applier = new ModelMaterialApplier(root, infos, factory().fn, { gltf: true, procedural });
    applier.apply({ Casco: { override: { textureType: 'wood', enableNormalMap: true, normalScale: 1 } } });
    const m = a.material as THREE.MeshStandardMaterial;
    expect(procedural).toHaveBeenCalledTimes(1);
    expect(m.map!.flipY).toBe(false);
    expect(m.normalMap!.colorSpace).toBe(THREE.NoColorSpace);
    expect(m.normalScale.y).toBeLessThan(0);
    applier.dispose();
    expect(disposed.sort()).toEqual(['albedo-clone', 'normal-clone']);
  });

  it('sem enableNormalMap o padrão procedural não coloca normal; textura do slot vence o padrão', () => {
    const { root, a, infos } = makeModel();
    const calls: string[] = [];
    const procedural: ProceduralFactory = () => {
      calls.push('proc');
      return { albedo: new THREE.Texture() };
    };
    const f = factory();
    const applier = new ModelMaterialApplier(root, infos, f.fn, { gltf: false, procedural });
    applier.apply({ Casco: { override: { textureType: 'hex' } } });
    expect((a.material as THREE.MeshStandardMaterial).normalMap).toBeNull();
    expect((a.material as THREE.MeshStandardMaterial).map).toBeInstanceOf(THREE.Texture);
    applier.apply({ Casco: { override: { textureType: 'hex' }, albedoDataUrl: PNG } });
    expect(f.specs.some((s) => s.url === PNG)).toBe(true);
  });

  it('trocar o plano e dispor descartam os clones e as texturas criadas (sem vazamento) e devolvem o original', () => {
    const { root, a, original, infos } = makeModel();
    const created: THREE.Texture[] = [];
    const disposeSpies: ReturnType<typeof vi.spyOn>[] = [];
    const fn: TextureFactory = (_u, spec) => {
      const t = new THREE.Texture();
      t.flipY = spec.flipY;
      disposeSpies.push(vi.spyOn(t, 'dispose'));
      created.push(t);
      return t;
    };
    const applier = new ModelMaterialApplier(root, infos, fn, { gltf: true });
    applier.apply({ Casco: { override: {}, albedoDataUrl: PNG, normalDataUrl: NORMAL } });
    expect(created).toHaveLength(2);
    const firstClone = a.material as THREE.Material;
    const cloneSpy = vi.spyOn(firstClone, 'dispose');
    applier.apply({}); // plano vazio: tudo liberado, original de volta
    expect(a.material).toBe(original);
    expect(disposeSpies.every((s) => s.mock.calls.length === 1)).toBe(true);
    expect(cloneSpy).toHaveBeenCalledTimes(1);
    applier.apply({ Casco: { override: {}, albedoDataUrl: PNG } });
    applier.dispose();
    expect(a.material).toBe(original);
    expect(created).toHaveLength(3);
    expect(disposeSpies[2].mock.calls.length).toBe(1);
  });

  it('applyOverrideToMaterial: tiling clona o mapa do arquivo (cache intacto) e não aplica normal em material sem normalMap', () => {
    const original = new THREE.MeshStandardMaterial();
    original.map = new THREE.Texture();
    const clone = original.clone();
    applyOverrideToMaterial(clone, { uvTiling: { x: 3, y: 2 } });
    expect(clone.map).not.toBe(original.map);
    expect(clone.map!.repeat.x).toBe(3);
    expect(original.map.repeat.x).toBe(1);
    const basic = new THREE.MeshBasicMaterial();
    expect(() => applyOverrideToMaterial(basic, {}, null, new THREE.Texture())).not.toThrow();
    expect('normalMap' in basic).toBe(false);
  });
});
