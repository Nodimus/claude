/**
 * AIS-33a — ponte entre um `GameNode` (`MeshInstance` com `properties.model`) e o `Object3D` que o desenha. O Viewport do
 * editor só chama estas funções; quem constrói o modelo é a `createModelObject` única. O Gizmo, a seleção e o Undo operam
 * sobre o nó (CommandManager): o `Object3D` interno do modelo nunca é editado.
 */
import * as THREE from 'three';
import type { ResourceRef } from '../../types/node';
import { createModelObject, type ModelObjectHandle } from './createModelObject';
import { projectModelSource } from './global';

export interface ModelNodeLike {
  id: string;
  properties: Record<string, any>;
}

const isRef = (v: unknown): v is ResourceRef => !!v && typeof v === 'object' && typeof (v as ResourceRef).id === 'string' && (v as ResourceRef).id.length > 0;

/** Referência de modelo do nó, se houver. */
export function modelRefOf(node: ModelNodeLike): ResourceRef | null {
  return isRef(node.properties.model) ? node.properties.model : null;
}

const offsetOf = (node: ModelNodeLike) => {
  const o = node.properties.modelOffset;
  return { x: Number(o?.x) || 0, y: Number(o?.y) || 0, z: Number(o?.z) || 0 };
};

/** Identidade do modelo desenhado: recurso + conteúdo (reimport muda o hash e refaz o objeto). */
export function modelKeyOf(ref: ResourceRef): string {
  const resolved = projectModelSource.resolve(ref);
  return `${resolved?.resourceId ?? ref.id}|${resolved?.contentHash ?? ''}|${resolved ? 'ok' : 'missing'}`;
}

/** Solta o modelo do cache (se o objeto for de modelo) — chamar antes de descartar o objeto do nó. */
export function releaseModelNodeObject(object: THREE.Object3D | undefined | null): void {
  const handle = object?.userData?.modelHandle as ModelObjectHandle | undefined;
  handle?.release();
}

/**
 * Garante o objeto do nó: reaproveita o titular quando o modelo é o mesmo; troca (soltando o anterior) quando mudou.
 * Devolve o objeto que deve estar em `objectsMap` para o nó.
 */
export function syncModelNodeObject(node: ModelNodeLike, existing: THREE.Object3D | undefined, scene: THREE.Object3D): THREE.Object3D | null {
  const ref = modelRefOf(node);
  if (!ref) return null;
  const key = modelKeyOf(ref);
  const castShadow = node.properties.castShadow !== false;
  const receiveShadow = node.properties.receiveShadow !== false;

  const handle = existing?.userData?.modelHandle as ModelObjectHandle | undefined;
  if (existing && handle && existing.userData.modelKey === key) {
    handle.setOffset(offsetOf(node));
    handle.setMaterialProps(node.properties); // AIS-35: slots/override editados (Inspector, Undo) refletem sem refazer o modelo
    return existing;
  }
  if (existing) {
    releaseModelNodeObject(existing);
    existing.removeFromParent();
  }
  const created = createModelObject(ref, { offset: offsetOf(node), castShadow, receiveShadow, source: projectModelSource, materialProps: node.properties }); // fonte explícita: os efeitos dos filhos rodam antes do `bindEditorServices`
  const object = created.object;
  object.userData.modelKey = key;
  (object as THREE.Object3D & { __nodeId?: string }).__nodeId = node.id;
  scene.add(object);
  return object;
}
