/**
 * AIS-33a — `createModelObject`: ÚNICA fábrica do `Object3D` de um modelo. Viewport do editor, Play (`RuntimeObjectFactory`)
 * e preview do modal chamam esta função. Devolve um `Group` "titular" que nasce com um marcador (cubo em wireframe) e
 * troca pelo modelo quando o carregamento termina; arquivo ausente ou falha → marcador vermelho + diagnóstico (a referência
 * nunca é apagada, padrão `unresolved` do AIS-28c). As malhas do modelo são clones do cache (`SkeletonUtils.clone`): geometria
 * e material são compartilhados e liberados pelo cache, nunca pela instância.
 */
import * as THREE from 'three';
import { clone as cloneSkinned } from 'three/addons/utils/SkeletonUtils.js';
import type { ResourceRef } from '../../types/node';
import { contentToBytes, dirOfUri, resolveRelativeUri } from './modelBytes';
import { globalModelCache, type ModelCache, type ModelLease } from './modelCache';
import { loadModel } from './modelLoader';
import { isGltfExt } from './materialChannels';
import { ModelMaterialApplier, buildMaterialPlan, type MaterialPlan, type ProceduralFactory, type TextureFactory } from './modelMaterials';
import { ModelLoadError, isModelExt, type LoadedModel, type ModelExt } from './types';

export interface ResolvedModelFile {
  resourceId: string;
  uri: string;
  contentHash?: string;
  /** Conteúdo persistido (data URL ou texto). `undefined` = arquivo sem conteúdo. */
  content?: string;
}

export interface ModelDiagnosticInput {
  code: string;
  severity: 'error' | 'warning';
  message: string;
  uri?: string;
  resourceId?: string;
}

/** Ponte entre `ResourceRef` e o conteúdo do projeto (registrada por `models/global.ts`; nos testes, um mapa). */
export interface ModelSourceBinding {
  /** `null` = a referência não resolve (arquivo ausente/órfão). */
  resolve(ref: ResourceRef): ResolvedModelFile | null;
  /** Conteúdo de outro arquivo do projeto (`.bin`, imagens de um `.gltf`). */
  readFile(uri: string): string | undefined;
  report?(diagnostic: ModelDiagnosticInput): void;
}

let configured: ModelSourceBinding | null = null;
/** Liga a fábrica ao projeto aberto (idempotente; devolve o disposer). */
export function configureModelSource(binding: ModelSourceBinding | null): () => void {
  configured = binding;
  return () => {
    if (configured === binding) configured = null;
  };
}

export interface ModelObjectOptions {
  /** Compensação de pivô aplicada ao modelo dentro do nó (`modelOffset`). */
  offset?: { x: number; y: number; z: number };
  castShadow?: boolean;
  receiveShadow?: boolean;
  source?: ModelSourceBinding;
  cache?: ModelCache;
  /** `properties` do nó: `materialSlots`/`materialOverride` (AIS-35, decisão 3.2). Sem isto, materiais originais do arquivo. */
  materialProps?: Record<string, any>;
  /** Fábrica de texturas dos materiais alterados (padrão: DOM; os testes injetam a deles). */
  textureFactory?: TextureFactory;
  /** Fábrica do padrão procedural de um override com `textureType` (padrão: gerador único, DOM). */
  proceduralFactory?: ProceduralFactory;
}

export type ModelObjectStatus = 'loading' | 'ready' | 'unresolved' | 'failed';

export interface ModelObjectHandle {
  /** Titular: entra na cena como o objeto do nó. */
  readonly object: THREE.Group;
  status(): ModelObjectStatus;
  /** Modelo carregado (estatísticas, AABB, materiais, animações); `null` enquanto carrega ou se falhou. Compartilhado: não alterar. */
  loaded(): LoadedModel | null;
  /** Resolve quando saiu de `loading` (nunca rejeita). */
  readonly ready: Promise<ModelObjectStatus>;
  setOffset(offset: { x: number; y: number; z: number }): void;
  /** AIS-35: novas `properties` do nó (`materialSlots`/`materialOverride`); reaplica só se o resultado mudou. */
  setMaterialProps(props: Record<string, any> | undefined): void;
  /** AIS-35: plano pronto (rascunho do modal: nome do material → override + imagem). Substitui `setMaterialProps`. */
  setMaterialPlan(plan: MaterialPlan | null): void;
  /** Idempotente: solta o cache e descarta o marcador. */
  release(): void;
}

const MARKER_LOADING = 0x38bdf8;
const MARKER_ERROR = 0xef4444;

function createMarker(color: number): THREE.Mesh {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshBasicMaterial({ color, wireframe: true, transparent: true, opacity: 0.85 }));
  mesh.name = 'ModelMarker';
  mesh.userData.modelMarker = true;
  return mesh;
}

function disposeMarker(marker: THREE.Object3D | null): void {
  if (!marker) return;
  marker.removeFromParent();
  const mesh = marker as THREE.Mesh;
  mesh.geometry?.dispose();
  (mesh.material as THREE.Material | undefined)?.dispose();
}

export function createModelObject(ref: ResourceRef, options: ModelObjectOptions = {}): ModelObjectHandle {
  const source = options.source ?? configured;
  const cache = options.cache ?? globalModelCache;
  const holder = new THREE.Group();
  holder.name = 'ModelHolder';
  holder.userData.modelRef = ref;

  let marker: THREE.Object3D | null = createMarker(MARKER_LOADING);
  holder.add(marker);
  let content: THREE.Object3D | null = null;
  let lease: ModelLease | null = null;
  let state: ModelObjectStatus = 'loading';
  let loadedModel: LoadedModel | null = null;
  let released = false;
  let offset = options.offset ?? { x: 0, y: 0, z: 0 };
  let materialProps: Record<string, any> | undefined = options.materialProps;
  let explicitPlan: MaterialPlan | null = null;
  let applier: ModelMaterialApplier | null = null;

  const refreshMaterials = () => {
    if (!applier || !loadedModel) return;
    const plan = explicitPlan ?? buildMaterialPlan(materialProps, loadedModel.materials, (ref) => source?.resolve(ref)?.content);
    applier.apply(plan);
  };

  const showError = (status: 'unresolved' | 'failed') => {
    state = status;
    disposeMarker(marker);
    marker = createMarker(MARKER_ERROR);
    holder.add(marker);
  };

  const finish = (): Promise<ModelObjectStatus> => {
    const resolved = source?.resolve(ref) ?? null;
    if (!resolved || resolved.content === undefined) {
      source?.report?.({
        code: 'model.unresolved',
        severity: 'error',
        message: `O modelo ${ref.path ?? ref.label ?? ref.id} não foi encontrado no projeto (referência preservada).`,
        uri: resolved?.uri ?? ref.path,
        resourceId: resolved?.resourceId ?? ref.id,
      });
      showError('unresolved');
      return Promise.resolve(state);
    }
    const ext = (resolved.uri.split('.').pop() ?? '').toLowerCase();
    if (!isModelExt(ext)) {
      source?.report?.({ code: 'model.unsupported_extension', severity: 'error', message: `${resolved.uri}: extensão .${ext} não suportada.`, uri: resolved.uri, resourceId: resolved.resourceId });
      showError('failed');
      return Promise.resolve(state);
    }
    const bytes = contentToBytes(resolved.content);
    const loading = (): Promise<LoadedModel> =>
      loadModel({
        bytes,
        ext: ext as ModelExt,
        name: resolved.uri.split('/').pop() ?? resolved.uri,
        resolveSibling: (rel) => {
          const text = source?.readFile(resolveRelativeUri(resolved.uri, rel));
          return text === undefined ? null : contentToBytes(text);
        },
      });
    lease = cache.acquire(resolved.resourceId, resolved.contentHash, loading);
    return lease.promise.then(
      (model) => {
        if (released) return state;
        const instance = cloneSkinned(model.root);
        instance.name = 'ModelContent';
        instance.position.set(offset.x, offset.y, offset.z);
        instance.traverse((child) => {
          const mesh = child as THREE.Mesh;
          if (mesh.isMesh) {
            mesh.castShadow = options.castShadow !== false;
            mesh.receiveShadow = options.receiveShadow !== false;
          }
        });
        disposeMarker(marker);
        marker = null;
        loadedModel = model;
        content = instance;
        holder.add(instance);
        applier = new ModelMaterialApplier(instance, model.materials, options.textureFactory, { gltf: isGltfExt(model.ext), procedural: options.proceduralFactory });
        refreshMaterials();
        state = 'ready';
        return state;
      },
      (error) => {
        if (released) return state;
        const code = error instanceof ModelLoadError ? error.code : 'model.parse_failed';
        source?.report?.({ code, severity: 'error', message: error instanceof Error ? error.message : String(error), uri: resolved.uri, resourceId: resolved.resourceId });
        showError('failed');
        return state;
      }
    );
  };

  const handle: ModelObjectHandle = {
    object: holder,
    status: () => state,
    loaded: () => loadedModel,
    ready: finish(),
    setOffset(next) {
      offset = next;
      content?.position.set(next.x, next.y, next.z);
    },
    setMaterialProps(next) {
      materialProps = next;
      explicitPlan = null;
      refreshMaterials();
    },
    setMaterialPlan(plan) {
      explicitPlan = plan;
      refreshMaterials();
    },
    release() {
      if (released) return;
      released = true;
      lease?.release();
      lease = null;
      disposeMarker(marker);
      marker = null;
      applier?.dispose();
      applier = null;
      if (content) holder.remove(content); // geometria/material são do cache
      content = null;
      loadedModel = null;
    },
  };
  holder.userData.modelHandle = handle;
  return handle;
}

/** Pasta de um modelo (útil a quem monta `readFile`). */
export const modelFolderOf = dirOfUri;
