/**
 * AIS-37 — ponte entre o estado PURO do player (`createClipMixer`, `runtime/skeletalAnimation.ts`) e o `THREE.AnimationMixer` do
 * preview do modal. O tempo, a velocidade, o loop, o scrub por quadro e o crossfade vivem em `createClipMixer`; aqui só se
 * aplica `layers()` às ações do three (tempo e peso explícitos, sem avançar o relógio do three). Reproduzir no Viewport/Play é
 * do AIS-60 (que reutiliza `skeletalAnimation.ts`, não esta ponte).
 */
import * as THREE from 'three';
import { createClipMixer, type ClipLike, type ClipMixer, type TrackLike } from '../../runtime/skeletalAnimation';

/** `THREE.AnimationClip` → `ClipLike` (cópias dos arrays: o clipe do cache nunca é tocado). */
export function likeFromClip(clip: THREE.AnimationClip): ClipLike {
  return {
    name: clip.name,
    duration: clip.duration,
    tracks: clip.tracks.map((t): TrackLike => ({ name: t.name, times: Array.from(t.times), values: Array.from(t.values) })),
  };
}

/** `ClipLike` → `THREE.AnimationClip` (posição/escala = vetor, `quaternion` = rotação, o resto = trilha genérica). */
export function clipFromLike(like: ClipLike): THREE.AnimationClip {
  const tracks = like.tracks.map((t) => {
    const times = Array.from(t.times);
    const values = Array.from(t.values);
    if (t.name.endsWith('.quaternion')) return new THREE.QuaternionKeyframeTrack(t.name, times, values);
    if (t.name.endsWith('.position') || t.name.endsWith('.scale')) return new THREE.VectorKeyframeTrack(t.name, times, values);
    return new THREE.KeyframeTrack(t.name, times, values);
  });
  return new THREE.AnimationClip(like.name, like.duration, tracks);
}

export interface PlayerSnapshot {
  clip: string | null;
  time: number;
  duration: number;
  playing: boolean;
  speed: number;
  loop: boolean;
  fading: boolean;
}

export class ClipPlayer {
  readonly mixer: ClipMixer;
  private readonly three: THREE.AnimationMixer;
  private readonly actions = new Map<string, THREE.AnimationAction>();
  private readonly durations = new Map<string, number>();
  private raf = 0;
  private last = 0;
  private disposed = false;

  constructor(
    private readonly root: THREE.Object3D,
    clips: readonly THREE.AnimationClip[],
    private readonly onTick?: (snapshot: PlayerSnapshot) => void
  ) {
    this.three = new THREE.AnimationMixer(root);
    for (const clip of clips) {
      this.durations.set(clip.name, clip.duration);
      this.actions.set(clip.name, this.three.clipAction(clip));
    }
    this.mixer = createClipMixer(clips.map((c) => ({ name: c.name, duration: c.duration })));
    this.apply();
  }

  snapshot(): PlayerSnapshot {
    const s = this.mixer.state();
    return { clip: s.clip, time: s.time, duration: s.clip ? this.durations.get(s.clip) ?? 0 : 0, playing: s.playing, speed: s.speed, loop: s.loop, fading: s.fade !== null };
  }

  /** Aplica as camadas do estado puro às ações do three: tempo e peso explícitos, relógio do three parado. */
  apply(): void {
    if (this.disposed) return;
    const layers = this.mixer.layers();
    const active = new Set(layers.map((l) => l.clip));
    for (const [name, action] of this.actions) {
      if (!active.has(name)) {
        action.enabled = false;
        action.weight = 0;
      }
    }
    for (const layer of layers) {
      const action = this.actions.get(layer.clip);
      if (!action) continue;
      const duration = this.durations.get(layer.clip) ?? 0;
      action.loop = THREE.LoopRepeat;
      action.enabled = true;
      if (!action.isRunning()) action.play();
      action.setEffectiveTimeScale(0);
      action.setEffectiveWeight(layer.weight);
      action.time = duration > 0 ? Math.min(layer.time, duration - 1e-6) : 0; // sem dar a volta no último quadro
    }
    this.three.update(0);
  }

  /** Liga o laço (só roda enquanto há o que animar: reproduzindo ou em crossfade). */
  start(): void {
    if (this.raf || this.disposed) return;
    this.last = performance.now();
    const loop = (now: number) => {
      this.raf = 0;
      if (this.disposed) return;
      const dt = Math.min(0.1, (now - this.last) / 1000);
      this.last = now;
      this.mixer.step(dt);
      this.apply();
      this.onTick?.(this.snapshot());
      const s = this.mixer.state();
      if (s.playing || s.fade) this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  /** Depois de qualquer ação do usuário (play, scrub, crossfade…): reaplica, avisa a UI e religa o laço se preciso. */
  refresh(): void {
    this.apply();
    this.onTick?.(this.snapshot());
    const s = this.mixer.state();
    if (s.playing || s.fade) this.start();
  }

  /** Volta o esqueleto à pose de bind e solta o mixer (o clone do modelo continua do preview, o cache não é tocado). */
  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
    this.three.stopAllAction();
    this.three.uncacheRoot(this.root);
    this.root.traverse((o) => {
      const skinned = o as THREE.SkinnedMesh;
      if (skinned.isSkinnedMesh) skinned.skeleton?.pose();
    });
  }
}

/**
 * Comprimento da posição LOCAL de cada nó nomeado do arquivo (pose de bind), por nome. A posição local de um osso está no
 * mesmo espaço dos valores das trilhas `<osso>.position`: a razão entre os `Hips` de dois esqueletos converte unidades
 * (FBX em cm × glTF em m). Nós sem nome ou na origem ficam de fora.
 */
export function boneLocalLengths(root: THREE.Object3D): Record<string, number> {
  const out: Record<string, number> = {};
  for (const [name, p] of Object.entries(boneLocalPositions(root))) out[name] = Math.hypot(p[0], p[1], p[2]);
  return out;
}

/** Posição local de cada nó nomeado (pose de bind), por nome; nós na origem ficam de fora. */
export function boneLocalPositions(root: THREE.Object3D): Record<string, [number, number, number]> {
  const out: Record<string, [number, number, number]> = {};
  root.traverse((o) => {
    if (o.name && o.position.lengthSq() > 0 && !(o.name in out)) out[o.name] = [o.position.x, o.position.y, o.position.z];
  });
  return out;
}
