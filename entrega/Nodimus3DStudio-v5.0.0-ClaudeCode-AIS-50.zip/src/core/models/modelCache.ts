/**
 * AIS-33a — cache ÚNICO de modelos carregados. Derivado e descartável (como o `ResourceCache` do AIS-28c): chave =
 * `resourceId + contentHash`, contagem de referência por `acquire/release` e `dispose` de geometria, material e textura
 * quando a contagem zera. O reimport invalida (`invalidate`): quem já tem uma concessão continua com o modelo antigo até
 * soltá-la; o próximo `acquire` recarrega.
 */
import * as THREE from 'three';
import type { LoadedModel } from './types';

/** Libera geometria, materiais e texturas de uma árvore (não mexe em nada compartilhado fora dela). */
export function disposeObject3D(root: THREE.Object3D): void {
  const textures = new Set<THREE.Texture>();
  root.traverse((child) => {
    const mesh = child as THREE.Mesh;
    mesh.geometry?.dispose?.();
    const materials = Array.isArray(mesh.material) ? mesh.material : mesh.material ? [mesh.material] : [];
    for (const m of materials) {
      for (const value of Object.values(m)) if (value instanceof THREE.Texture) textures.add(value);
      m.dispose();
    }
  });
  for (const t of textures) t.dispose();
}

interface Entry {
  key: string;
  resourceId: string;
  promise: Promise<LoadedModel>;
  model?: LoadedModel;
  refs: number;
  /** Fora do mapa (invalidado): descarta quando o último dono soltar. */
  detached: boolean;
  disposed: boolean;
}

export interface ModelLease {
  readonly key: string;
  /** Resolve com o modelo (compartilhado: não alterar nem descartar). */
  readonly promise: Promise<LoadedModel>;
  /** Idempotente. */
  release(): void;
}

export const modelCacheKey = (resourceId: string, contentHash: string | undefined): string => `${resourceId}:${contentHash ?? ''}`;

export class ModelCache {
  private entries = new Map<string, Entry>();

  /** Concessão do modelo (carrega na primeira vez; as seguintes reaproveitam). */
  acquire(resourceId: string, contentHash: string | undefined, load: () => Promise<LoadedModel>): ModelLease {
    const key = modelCacheKey(resourceId, contentHash);
    let entry = this.entries.get(key);
    if (!entry) {
      const created: Entry = { key, resourceId, promise: undefined as unknown as Promise<LoadedModel>, refs: 0, detached: false, disposed: false };
      created.promise = load().then(
        (model) => {
          created.model = model;
          if (created.disposed) disposeObject3D(model.root);
          return model;
        },
        (error) => {
          // falha de carga não fica em cache: a próxima tentativa recarrega
          if (this.entries.get(key) === created) this.entries.delete(key);
          created.disposed = true;
          throw error;
        }
      );
      this.entries.set(key, created);
      entry = created;
    }
    entry.refs++;
    const owned = entry;
    let released = false;
    return {
      key,
      promise: owned.promise,
      release: () => {
        if (released) return;
        released = true;
        this.drop(owned);
      },
    };
  }

  private drop(entry: Entry): void {
    entry.refs--;
    if (entry.refs > 0) return;
    if (this.entries.get(entry.key) === entry) this.entries.delete(entry.key);
    this.dispose(entry);
  }

  private dispose(entry: Entry): void {
    if (entry.disposed) return;
    entry.disposed = true;
    if (entry.model) disposeObject3D(entry.model.root);
  }

  /** Reimport/troca de conteúdo: o recurso deixa de ser servido do cache. Sem donos → descarta já. */
  invalidate(resourceId: string): void {
    for (const [key, entry] of [...this.entries]) {
      if (entry.resourceId !== resourceId) continue;
      this.entries.delete(key);
      entry.detached = true;
      if (entry.refs <= 0) this.dispose(entry);
    }
  }

  /** Teardown total (ex.: troca de projeto): descarta o que não tem dono; o resto sai quando soltarem. */
  clear(): void {
    for (const [key, entry] of [...this.entries]) {
      this.entries.delete(key);
      entry.detached = true;
      if (entry.refs <= 0) this.dispose(entry);
    }
  }

  get size(): number {
    return this.entries.size;
  }

  refCount(resourceId: string, contentHash?: string): number {
    return this.entries.get(modelCacheKey(resourceId, contentHash))?.refs ?? 0;
  }
}

/** Instância única (editor, Play e preview do modal compartilham). */
export const globalModelCache = new ModelCache();
