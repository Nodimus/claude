import { describe, expect, it } from 'vitest';
import { loadModel } from './modelLoader';
import { ModelLoadError } from './types';
import { CUBE, TRIANGLE, buildGlb, buildGltfSelfContained, buildGltfWithExternalBin, buildObj, toBuffer } from './modelFixtures';
import { resolveCollider } from '../physics/resolveCollider';
import { measureLocalBounds } from '../physics/bounds';
import { contentToBytes, bytesToDataUrl, resolveRelativeUri } from './modelBytes';

const approx = (a: number, b: number) => expect(a).toBeCloseTo(b, 5);

async function failure(promise: Promise<unknown>): Promise<ModelLoadError> {
  try {
    await promise;
  } catch (e) {
    expect(e).toBeInstanceOf(ModelLoadError);
    return e as ModelLoadError;
  }
  throw new Error('deveria ter falhado');
}

describe('loadModel — carga de fixtures em Node (AIS-33a-C01)', () => {
  it('GLB: cubo → 1 malha, 12 triângulos e AABB 1×1×1 centrada', async () => {
    const m = await loadModel({ bytes: buildGlb(CUBE), ext: 'glb', name: 'cube.glb' });
    expect(m.stats).toMatchObject({ meshes: 1, triangles: 12, bones: 0, clips: 0 });
    expect(m.stats.materials).toBeGreaterThanOrEqual(1);
    expect(m.bounds).not.toBeNull();
    approx(m.bounds!.size.x, 1);
    approx(m.bounds!.size.y, 1);
    approx(m.bounds!.size.z, 1);
    approx(m.bounds!.center.x, 0);
    expect(m.upAxisHint).toBe('y');
  });
  it('GLB: triângulo sem índice → 1 triângulo, AABB 1×1×0', async () => {
    const m = await loadModel({ bytes: buildGlb({ positions: TRIANGLE.positions, indices: null }), ext: 'glb', name: 't.glb' });
    expect(m.stats.triangles).toBe(1);
    approx(m.bounds!.size.x, 1);
    approx(m.bounds!.size.y, 1);
    approx(m.bounds!.size.z, 0);
    approx(m.bounds!.center.x, 0.5);
  });
  it('OBJ: cubo e triângulo', async () => {
    const cube = await loadModel({ bytes: toBuffer(buildObj(CUBE)), ext: 'obj', name: 'cube.obj' });
    expect(cube.stats).toMatchObject({ meshes: 1, triangles: 12 });
    approx(cube.bounds!.size.y, 1);
    const tri = await loadModel({ bytes: toBuffer(buildObj(TRIANGLE)), ext: 'obj', name: 't.obj' });
    expect(tri.stats.triangles).toBe(1);
  });
  it('.gltf autocontido (data URI) carrega sem arquivos vizinhos', async () => {
    const m = await loadModel({ bytes: toBuffer(buildGltfSelfContained(CUBE)), ext: 'gltf', name: 'self.gltf' });
    expect(m.stats.triangles).toBe(12);
  });
  it('.gltf com .bin externo carrega pelos arquivos fornecidos (sem rede)', async () => {
    const { gltf, bin, binName } = buildGltfWithExternalBin(CUBE, 'cube.bin');
    const asked: string[] = [];
    const m = await loadModel({
      bytes: toBuffer(gltf),
      ext: 'gltf',
      name: 'cube.gltf',
      resolveSibling: (rel) => {
        asked.push(rel);
        return rel === binName ? bin : null;
      },
    });
    expect(asked).toEqual(['cube.bin']);
    expect(m.stats).toMatchObject({ meshes: 1, triangles: 12 });
  });
});

describe('loadModel — falhas tipadas, sem gravar nada (AIS-33a-C02)', () => {
  it('arquivo vazio → model.empty', async () => {
    expect((await failure(loadModel({ bytes: new ArrayBuffer(0), ext: 'glb', name: 'a.glb' }))).code).toBe('model.empty');
  });
  it('GLB/GLTF corrompido → model.parse_failed', async () => {
    expect((await failure(loadModel({ bytes: toBuffer('isto não é um glb'), ext: 'glb', name: 'a.glb' }))).code).toBe('model.parse_failed');
    expect((await failure(loadModel({ bytes: toBuffer('{ json quebrado'), ext: 'gltf', name: 'a.gltf' }))).code).toBe('model.parse_failed');
    const truncated = buildGlb(CUBE).slice(0, 40);
    expect((await failure(loadModel({ bytes: truncated, ext: 'glb', name: 'cut.glb' }))).code).toBe('model.parse_failed');
  });
  it('OBJ sem nenhuma malha → model.empty', async () => {
    expect((await failure(loadModel({ bytes: toBuffer('# só comentário\n'), ext: 'obj', name: 'a.obj' }))).code).toBe('model.empty');
  });
  it('.gltf com .bin ausente → model.missing_dependency, listando o que falta', async () => {
    const { gltf } = buildGltfWithExternalBin(CUBE, 'sumiu.bin');
    const e = await failure(loadModel({ bytes: toBuffer(gltf), ext: 'gltf', name: 'a.gltf', resolveSibling: () => null }));
    expect(e.code).toBe('model.missing_dependency');
    expect(e.missing).toEqual(['sumiu.bin']);
    const sem = await failure(loadModel({ bytes: toBuffer(gltf), ext: 'gltf', name: 'a.gltf' }));
    expect(sem.code).toBe('model.missing_dependency');
  });
  it('Draco/Meshopt/KTX2 exigidos → model.unsupported_extension (nunca falha silenciosa)', async () => {
    for (const ext of ['KHR_draco_mesh_compression', 'EXT_meshopt_compression', 'KHR_texture_basisu']) {
      const e = await failure(loadModel({ bytes: buildGlb(CUBE, { extensionsRequired: [ext] }), ext: 'glb', name: 'a.glb' }));
      expect(e.code).toBe('model.unsupported_extension');
    }
  });
});

describe('AABB do modelo = a mesma que o colisor automático usa (decisão 26/27)', () => {
  it('measureLocalBounds do modelo bate com o resolveCollider automático', async () => {
    const m = await loadModel({ bytes: buildGlb(CUBE), ext: 'glb', name: 'c.glb' });
    const again = measureLocalBounds(m.root);
    expect(again).toEqual(m.bounds);
    const spec = resolveCollider(
      { enabled: true, bodyMode: 'static', shape: 'auto' },
      { nodeType: 'MeshInstance', properties: { model: { id: 'r1' } }, bounds: m.bounds, scale: { x: 2, y: 2, z: 2 } }
    );
    expect(spec).not.toBeNull();
    approx(spec!.size.x, 2); // 1 (modelo) × escala 2
    approx(spec!.size.y, 2);
    approx(spec!.size.z, 2);
  });
});

describe('modelBytes', () => {
  it('data URL ↔ bytes e caminhos relativos', () => {
    const url = bytesToDataUrl(new Uint8Array([1, 2, 3, 250]).buffer, 'model/gltf-binary');
    expect([...new Uint8Array(contentToBytes(url))]).toEqual([1, 2, 3, 250]);
    expect(new TextDecoder().decode(contentToBytes('olá'))).toBe('olá');
    expect(resolveRelativeUri('res://models/hero/hero.gltf', 'tex/a%20b.png')).toBe('res://models/hero/tex/a b.png');
    expect(resolveRelativeUri('res://models/hero/hero.gltf', '../shared.bin')).toBe('res://models/shared.bin');
  });
});
