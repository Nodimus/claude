import { describe, expect, it, vi } from 'vitest';
import { ProjectStorage } from './projectStorage';
import { createNewProject } from './defaultProject';

const file = (path: string, content: string) => ({
  path,
  name: path.split('/').pop() as string,
  isDirectory: false,
  extension: 'ts',
  content,
  size: content.length,
  updatedAt: new Date().toISOString(),
});

describe('ProjectStorage.saveProjectFiles (AIS-18b)', () => {
  it('grava só os arquivos informados e preserva alterações externas dos demais', () => {
    const project = createNewProject('Teste', 'res://', '3d');
    project.files['res://scripts/A.ts'] = file('res://scripts/A.ts', 'A v1');
    project.files['res://scripts/B.ts'] = file('res://scripts/B.ts', 'B v1');
    ProjectStorage.saveProject(project);

    // alteração externa de A no armazenamento persistido
    const external = ProjectStorage.loadProject(project.id)!;
    external.files['res://scripts/A.ts'] = file('res://scripts/A.ts', 'A EXTERNO');
    ProjectStorage.saveProject(external);

    // a memória ainda tem A v1; salvar só B não pode desfazer o externo de A
    project.files['res://scripts/B.ts'] = file('res://scripts/B.ts', 'B v2');
    ProjectStorage.saveProjectFiles(project, ['res://scripts/B.ts']);

    const after = ProjectStorage.loadProject(project.id)!;
    expect(after.files['res://scripts/A.ts'].content).toBe('A EXTERNO');
    expect(after.files['res://scripts/B.ts'].content).toBe('B v2');
  });

  it('sem projeto persistido grava o projeto inteiro', () => {
    const project = createNewProject('Outro', 'res://', '3d');
    project.files['res://scripts/C.ts'] = file('res://scripts/C.ts', 'C');
    ProjectStorage.saveProjectFiles(project, ['res://scripts/C.ts']);
    expect(ProjectStorage.loadProject(project.id)?.files['res://scripts/C.ts'].content).toBe('C');
  });
});

describe('ProjectStorage — correções de persistência', () => {
  const sceneFile = (path: string) => ({
    path,
    name: path.split('/').pop() as string,
    isDirectory: false,
    extension: 'json',
    content: '{}',
    size: 2,
    updatedAt: new Date().toISOString(),
  });

  it('toProjectFile marca exatamente uma cena inicial', () => {
    const project = createNewProject('Cenas', 'res://', '3d');
    project.files['res://scenes/A.scene.json'] = sceneFile('res://scenes/A.scene.json');
    project.files['res://scenes/B.scene.json'] = sceneFile('res://scenes/B.scene.json');
    // AIS-29f: a cena inicial é `settings.general.mainScene` — abrir outra cena (lastOpenedScene) não a troca
    project.settings.general.mainScene = 'res://scenes/B.scene.json';
    project.lastOpenedScene = 'res://scenes/A.scene.json';
    const pf = ProjectStorage.toProjectFile(project);
    const starts = pf.scenes.filter((s) => s.isStartScene);
    expect(starts).toHaveLength(1);
    expect(starts[0].path).toBe('res://scenes/B.scene.json');
    expect(pf.startSceneId).toBe(starts[0].id);
  });

  it('lastOpenedScene inexistente cai na primeira cena (ainda uma só inicial)', () => {
    const project = createNewProject('Cenas2', 'res://', '3d');
    project.lastOpenedScene = 'res://scenes/NaoExiste.scene.json';
    const pf = ProjectStorage.toProjectFile(project);
    expect(pf.scenes.filter((s) => s.isStartScene)).toHaveLength(1);
  });

  it('globalVariables sobrevivem a save/load e à exportação', () => {
    const project = createNewProject('Globais', 'res://', '3d');
    project.globalVariables = [{ id: 'g1', name: 'vidas', type: 'number', value: 3 }];
    ProjectStorage.saveProject(project);
    expect(ProjectStorage.loadProject(project.id)?.globalVariables?.[0].name).toBe('vidas');
    expect(ProjectStorage.toProjectFile(project).globalVariables).toHaveLength(1);
  });

  it('importar project.json canônico preserva nome, settings e variáveis globais', () => {
    const src = createNewProject('Canon', 'res://', '3d');
    src.settings.display.width = 777;
    src.globalVariables = [{ id: 'g1', name: 'pontos', type: 'number', value: 0 }];
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const imported = ProjectStorage.importProjectFromNodimus(JSON.stringify(ProjectStorage.toProjectFile(src)));
    warn.mockRestore();
    expect(imported.name).toBe('Canon');
    expect(imported.settings.display.width).toBe(777);
    expect(imported.globalVariables?.[0].name).toBe('pontos');
  });

  it('falha de gravação (quota) é reportada ao assinante e saveProject retorna false', () => {
    const project = createNewProject('Quota', 'res://', '3d');
    const quota = Object.assign(new Error('cheio'), { name: 'QuotaExceededError' });
    vi.stubGlobal('localStorage', {
      getItem: () => null,
      removeItem: () => {},
      setItem: () => {
        throw quota;
      },
    });
    const err = vi.spyOn(console, 'error').mockImplementation(() => {});
    const messages: string[] = [];
    const dispose = ProjectStorage.onSaveError((m) => messages.push(m));
    const ok = ProjectStorage.saveProject(project);
    dispose();
    err.mockRestore();
    vi.unstubAllGlobals();
    expect(ok).toBe(false);
    expect(messages[0]).toMatch(/cheio/i);
  });

  it('disposer remove o assinante', () => {
    const messages: string[] = [];
    const dispose = ProjectStorage.onSaveError((m) => messages.push(m));
    dispose();
    vi.stubGlobal('localStorage', { getItem: () => null, removeItem: () => {}, setItem: () => { throw new Error('x'); } });
    const err = vi.spyOn(console, 'error').mockImplementation(() => {});
    ProjectStorage.saveProject(createNewProject('Sem', 'res://', '3d'));
    err.mockRestore();
    vi.unstubAllGlobals();
    expect(messages).toHaveLength(0);
  });
});
