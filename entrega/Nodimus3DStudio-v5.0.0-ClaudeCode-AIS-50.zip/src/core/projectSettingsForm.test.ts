import { beforeEach, describe, expect, it } from 'vitest';
import { ProjectSettingsV1Schema } from '../schemas/v1/project.schema';
import { validateProject } from '../schemas';
import { createNewProject } from './defaultProject';
import { ProjectStorage } from './projectStorage';
import { addScene } from './sceneManager';
import { DEFAULT_SCENE_ENVIRONMENT } from '../types/scene';
import {
  applySettingsToProject,
  isDirty,
  normalizeSettings,
  parseNumberText,
  resetTabToDefaults,
  schemaDefaults,
  tabOfPath,
  toDraft,
  validateDraft,
  type SettingsDraft,
} from './projectSettingsForm';

const base = () => createNewProject('Proj', '~/p', '3d').settings;
const draftOf = (): SettingsDraft => toDraft(base());
const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v));

beforeEach(() => ProjectStorage.saveProjectsList([]));

describe('schema: padrões e retrocompatibilidade (AIS-32b-C08)', () => {
  it('os padrões por aba vêm do schema', () => {
    const d = schemaDefaults();
    expect(d.general).toMatchObject({ version: '1.0.0', description: '', author: 'Developer' });
    expect(d.display).toMatchObject({ width: 1280, height: 720, resizable: true, windowMode: 'windowed', orientation: 'landscape' });
    expect(d.rendering).toMatchObject({ msaa: '2x', shadowsEnabled: true, shadowQuality: 'medium', hdr: false, vsync: true, clearColor: '#141822' });
    expect(d.physics).toMatchObject({ gravity3D: { x: 0, y: -9.8, z: 0 }, defaultLinearDamp: 0.1 });
    expect(d.audio).toEqual({ masterVolume: 1, musicVolume: 0.8, sfxVolume: 0.9 });
  });
  it('projeto antigo sem os campos novos continua válido e ganha os padrões', () => {
    const old = clone(base()) as any;
    delete old.general.description;
    delete old.display.windowMode;
    delete old.rendering.shadowQuality;
    delete old.rendering.hdr;
    const r = ProjectSettingsV1Schema.safeParse(old);
    expect(r.success).toBe(true);
    if (r.success) {
      expect(r.data.general.description).toBe('');
      expect(r.data.display.windowMode).toBe('windowed');
      expect(r.data.rendering.shadowQuality).toBe('medium');
      expect(r.data.rendering.hdr).toBe(false);
    }
  });
  it('legado: fullscreen=true sem windowMode vira windowMode "fullscreen"', () => {
    const old = clone(base()) as any;
    old.display.fullscreen = true;
    delete old.display.windowMode;
    const r = ProjectSettingsV1Schema.parse(old);
    expect(r.display.windowMode).toBe('fullscreen');
    // windowMode explícito vence o legado
    old.display.windowMode = 'borderless';
    expect(ProjectSettingsV1Schema.parse(old).display.windowMode).toBe('borderless');
  });
  it('um projeto completo antigo (sem campos novos) passa por validateProject', () => {
    const p = clone(createNewProject('Antigo', '~', 'empty')) as any;
    delete p.settings.general.description;
    delete p.settings.display.windowMode;
    delete p.settings.rendering.hdr;
    const r = validateProject(p);
    expect(r.success).toBe(true);
  });
  it('limites com mensagem em português', () => {
    const bad = (mut: (s: any) => void) => {
      const s = clone(base()) as any;
      mut(s);
      return ProjectSettingsV1Schema.safeParse(s);
    };
    expect(bad((s) => (s.display.width = 0)).success).toBe(false);
    expect(bad((s) => (s.display.width = 16385)).success).toBe(false);
    expect(bad((s) => (s.display.height = 10.5)).success).toBe(false);
    expect(bad((s) => (s.physics.defaultLinearDamp = -1)).success).toBe(false);
    expect(bad((s) => (s.audio.musicVolume = 1.2)).success).toBe(false);
    expect(bad((s) => (s.general.version = '1.0')).success).toBe(false);
    expect(bad((s) => (s.general.projectName = '  ')).success).toBe(false);
    expect(bad((s) => (s.general.projectName = 'x'.repeat(121))).success).toBe(false);
    expect(bad((s) => (s.rendering.clearColor = 'vermelho')).success).toBe(false);
    expect(bad((s) => (s.display.width = 1)).success).toBe(true);
    expect(bad((s) => (s.display.width = 16384)).success).toBe(true);
    expect(bad((s) => (s.physics.gravity3D.y = 0)).success).toBe(true);
  });
});

describe('toDraft / normalizeSettings', () => {
  it('rascunho em texto, completo mesmo com settings antigas ou parciais', () => {
    const d = toDraft({ general: { projectName: 'A' }, display: { width: 800 } });
    expect(d.display.width).toBe('800');
    expect(d.display.height).toBe('720');
    expect(d.rendering.shadowQuality).toBe('medium');
    expect(typeof d.physics.gravity3D.y).toBe('string');
  });
  it('normalizeSettings preserva o que existe quando inválido', () => {
    const s = normalizeSettings({ general: { projectName: 'A', version: 'x' }, display: { width: 0 } });
    expect(s.general.version).toBe('x'); // não inventa: o validador acusa depois
    expect(s.display.height).toBe(720);
  });
});

describe('validateDraft (AIS-32b-C05)', () => {
  it('rascunho inicial é válido e devolve as settings', () => {
    const r = validateDraft(draftOf(), base());
    expect(r.ok).toBe(true);
  });
  it('apagar um campo numérico dá erro no campo, sem valor silencioso', () => {
    const d = draftOf();
    d.display.width = '';
    const r = validateDraft(d, base());
    expect(r.ok).toBe(false);
    expect(Object.keys(r.errors)).toEqual(['display.width']);
    expect(r.errors['display.width']).toMatch(/número/);
  });
  it('gravidade 0 é válida (nenhum "|| -9.8")', () => {
    const d = draftOf();
    d.physics.gravity3D.y = '0';
    const r = validateDraft(d, base());
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.settings.physics.gravity3D.y).toBe(0);
  });
  it('aceita vírgula decimal e rejeita texto', () => {
    expect(parseNumberText('-9,8')).toBe(-9.8);
    expect(parseNumberText(' 0 ')).toBe(0);
    expect(Number.isNaN(parseNumberText('abc'))).toBe(true);
    expect(Number.isNaN(parseNumberText(''))).toBe(true);
    expect(Number.isNaN(parseNumberText('1e5'))).toBe(true);
  });
  it('um erro não bloqueia os outros: todos os campos errados aparecem juntos, cada um no seu caminho', () => {
    const d = draftOf();
    d.display.width = '0';
    d.general.version = 'abc';
    d.audio.musicVolume = '2';
    d.physics.gravity3D.z = 'x';
    const r = validateDraft(d, base());
    expect(r.ok).toBe(false);
    expect(Object.keys(r.errors).sort()).toEqual(['audio.musicVolume', 'display.width', 'general.version', 'physics.gravity3D.z']);
    expect(tabOfPath('physics.gravity3D.z')).toBe('physics');
    expect(tabOfPath('general.version')).toBe('general');
  });
  it('nome vazio/duplicado e cena principal fora da lista', () => {
    const d = draftOf();
    d.general.projectName = '  ';
    expect(validateDraft(d, base()).errors['general.projectName']).toMatch(/vazio/);
    const projects = [
      { id: 'a', name: 'Outro', location: '', renderer: '', updatedAt: '' },
      { id: 'me', name: 'Proj', location: '', renderer: '', updatedAt: '' },
    ];
    const dup = draftOf();
    dup.general.projectName = 'outro';
    expect(validateDraft(dup, base(), { projects, projectId: 'me' }).errors['general.projectName']).toMatch(/Já existe/);
    expect(validateDraft(draftOf(), base(), { projects, projectId: 'me' }).ok).toBe(true);
    expect(validateDraft(draftOf(), base(), { scenePaths: ['res://scenes/Outra.scene.json'] }).errors['general.mainScene']).toBeDefined();
  });
  it('preserva o que o modal não edita (input.actions, renderer) e espelha fullscreen', () => {
    const b = base();
    const d = draftOf();
    d.display.windowMode = 'fullscreen';
    const r = validateDraft(d, b);
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.settings.input.actions).toEqual(b.input.actions);
      expect(r.settings.rendering.renderer).toBe(b.rendering.renderer);
      expect(r.settings.display.fullscreen).toBe(true);
      expect(r.settings.display.windowMode).toBe('fullscreen');
    }
    d.display.windowMode = 'borderless';
    const r2 = validateDraft(d, b);
    if (r2.ok) expect(r2.settings.display.fullscreen).toBe(false);
  });
});

describe('resetTabToDefaults (AIS-32b-C04)', () => {
  const dirtyDraft = (): SettingsDraft => {
    const d = draftOf();
    d.general = { projectName: 'Mudei', author: 'Eu', version: '9.9.9', description: 'x', mainScene: 'res://scenes/Outra.scene.json' };
    d.display = { width: '100', height: '200', windowMode: 'borderless', resizable: false, orientation: 'portrait' };
    d.rendering = { shadowsEnabled: false, shadowQuality: 'high', msaa: '8x', hdr: true, vsync: false, clearColor: '#ffffff' };
    d.physics = { gravity3D: { x: '1', y: '2', z: '3' }, defaultLinearDamp: '5' };
    d.audio = { masterVolume: '0.1', musicVolume: '0.2', sfxVolume: '0.3' };
    return d;
  };
  it('cada aba repõe só os próprios campos', () => {
    const d = dirtyDraft();
    const fresh = toDraft(schemaDefaults());
    for (const tab of ['display', 'rendering', 'physics', 'audio'] as const) {
      const r = resetTabToDefaults(d, tab);
      expect(r[tab]).toEqual(fresh[tab]);
      for (const other of ['general', 'display', 'rendering', 'physics', 'audio'] as const) {
        if (other !== tab) expect(r[other]).toEqual(d[other]);
      }
    }
  });
  it('General não restaura nome nem cena principal', () => {
    const d = dirtyDraft();
    const r = resetTabToDefaults(d, 'general');
    expect(r.general.projectName).toBe('Mudei');
    expect(r.general.mainScene).toBe('res://scenes/Outra.scene.json');
    expect(r.general.author).toBe('Developer');
    expect(r.general.version).toBe('1.0.0');
    expect(r.general.description).toBe('');
    expect(r.display).toEqual(d.display);
  });
});

describe('isDirty (AIS-32b-C06)', () => {
  it('compara por valor: editar suja, voltar ao original limpa', () => {
    const b = base();
    const d = draftOf();
    expect(isDirty(d, b)).toBe(false);
    d.display.width = '1920';
    expect(isDirty(d, b)).toBe(true);
    d.display.width = '1280';
    expect(isDirty(d, b)).toBe(false);
  });
});

describe('aplicar ao projeto (AIS-32b-C02/C09)', () => {
  it('persiste todos os campos e o nome nas quatro pontas (name, espelho, lista, project.json)', () => {
    const project = createNewProject('Antes', '~/p', '3d');
    ProjectStorage.saveProject(project);
    const d = toDraft(project.settings);
    d.general = { ...d.general, projectName: 'Depois', author: 'Ana', version: '2.1.0', description: 'Um jogo' };
    d.display = { ...d.display, width: '1920', height: '1080', windowMode: 'borderless' };
    d.rendering = { ...d.rendering, shadowQuality: 'high', hdr: true, clearColor: '#112233' };
    d.physics = { gravity3D: { x: '1', y: '0', z: '-2' }, defaultLinearDamp: '0.5' };
    d.audio = { masterVolume: '0.5', musicVolume: '0.4', sfxVolume: '0.3' };
    const v = validateDraft(d, project.settings);
    expect(v.ok).toBe(true);
    if (!v.ok) return;

    const updated = applySettingsToProject(project, v.settings);
    expect(ProjectStorage.saveProject(updated)).toBe(true);

    const stored = ProjectStorage.loadProject(project.id)!;
    expect(stored.name).toBe('Depois');
    expect(stored.settings.general).toMatchObject({ projectName: 'Depois', author: 'Ana', version: '2.1.0', description: 'Um jogo' });
    expect(stored.settings.display).toMatchObject({ width: 1920, height: 1080, windowMode: 'borderless', fullscreen: false });
    expect(stored.settings.rendering).toMatchObject({ shadowQuality: 'high', hdr: true, clearColor: '#112233' });
    expect(stored.settings.physics).toMatchObject({ gravity3D: { x: 1, y: 0, z: -2 }, defaultLinearDamp: 0.5 });
    expect(stored.settings.audio).toEqual({ masterVolume: 0.5, musicVolume: 0.4, sfxVolume: 0.3 });
    const pj = JSON.parse(stored.files['res://project.json'].content!);
    expect(pj.name).toBe('Depois');
    expect(pj.settings.general.projectName).toBe('Depois');
    expect(pj.settings.rendering.hdr).toBe(true);
    expect(ProjectStorage.getProjectsList().find((p) => p.id === project.id)?.name).toBe('Depois');
  });
  it('não muta o projeto original', () => {
    const project = createNewProject('Orig', '~', 'empty');
    const d = toDraft(project.settings);
    d.general.projectName = 'Novo';
    const v = validateDraft(d, project.settings);
    if (!v.ok) throw new Error('inválido');
    applySettingsToProject(project, v.settings);
    expect(project.name).toBe('Orig');
    expect(project.settings.general.projectName).toBe('Orig');
  });
});

describe('gravidade padrão para cenas novas (AIS-32b §3.3, C08)', () => {
  it('cena nova nasce com a gravidade do projeto; cenas existentes não mudam', () => {
    const project = createNewProject('G', '~', '3d');
    const existingPath = Object.keys(project.files).find((p) => p.endsWith('.scene.json'))!;
    const before = project.files[existingPath].content;
    project.settings.physics.gravity3D = { x: 0, y: -3.7, z: 1 };

    const added = addScene(project, '3D');
    const scene = JSON.parse(added.project.files[added.path].content!);
    expect(JSON.stringify(scene)).toContain('-3.7');
    expect(scene.sceneSettings?.environment?.gravity ?? scene.environment?.gravity).toEqual({ x: 0, y: -3.7, z: 1 });

    const empty = addScene(added.project, 'Empty');
    const emptyScene = JSON.parse(empty.project.files[empty.path].content!);
    expect((emptyScene.sceneSettings?.environment ?? emptyScene.environment).gravity).toEqual({ x: 0, y: -3.7, z: 1 });

    expect(empty.project.files[existingPath].content).toBe(before); // existente intocada
  });
  it('com a gravidade padrão do editor o resultado é o de antes (nada novo é escrito em cena vazia)', () => {
    const project = createNewProject('G', '~', 'empty');
    expect(project.settings.physics.gravity3D).toEqual(DEFAULT_SCENE_ENVIRONMENT.gravity);
    const added = addScene(project, 'Empty');
    const scene = JSON.parse(added.project.files[added.path].content!);
    expect(scene.sceneSettings?.environment).toBeUndefined();
  });
});
