import { describe, expect, it } from 'vitest';
import { createState, emitBurst, resetState, step } from './particleEngine';
import { PARTICLE_PRESETS, presetProperties } from './particlePresets';
import { PARTICLE_DEFAULTS, normalizeParticleProps, type ParticleProps } from './particleTypes';
import { NODE_REGISTRY, createDefaultNode } from '../../nodes/registry';
import { AuthoringModel } from '../authoring/AuthoringModel';
import { CommandManager } from '../commandManager';
import { createDefault3DStarterScene } from '../defaultProject';

const base = (over: Partial<ParticleProps> = {}): ParticleProps =>
  normalizeParticleProps({ ...PARTICLE_DEFAULTS, ...over });

function run(state: ReturnType<typeof createState>, props: ParticleProps, seconds: number, fps = 60) {
  const frames = Math.round(seconds * fps);
  for (let i = 0; i < frames; i++) step(state, props, 1 / fps);
}

describe('motor de partículas (AIS-18c)', () => {
  it('25 p/s por 1 s emite ≈25 (acumulador fracionário)', () => {
    const props = base({ particlesPerSecond: 25, lifetimeMin: 10, lifetimeMax: 10, maxParticles: 2000 });
    const state = createState(props);
    run(state, props, 1);
    expect(state.count).toBeGreaterThanOrEqual(24);
    expect(state.count).toBeLessThanOrEqual(25);
  });

  it('taxa fracionária por frame não perde partículas (10 p/s a 120 fps)', () => {
    const props = base({ particlesPerSecond: 10, lifetimeMin: 10, lifetimeMax: 10 });
    const state = createState(props);
    run(state, props, 2, 120);
    expect(state.count).toBeGreaterThanOrEqual(19);
    expect(state.count).toBeLessThanOrEqual(20);
  });

  it('respeita o teto de maxParticles', () => {
    const props = base({ particlesPerSecond: 1000, maxParticles: 50, lifetimeMin: 30, lifetimeMax: 30 });
    const state = createState(props);
    run(state, props, 3);
    expect(state.count).toBe(50);
    expect(emitBurst(state, props, 100)).toBe(0);
  });

  it('gravidade atua nos 3 eixos', () => {
    const props = base({
      emitting: false,
      speedMin: 0,
      speedMax: 0,
      lifetimeMin: 30,
      lifetimeMax: 30,
      emitterType: 'point',
      gravity: { x: 1, y: -2, z: 3 },
    });
    const state = createState(props);
    emitBurst(state, props, 1);
    for (let i = 0; i < 10; i++) step(state, props, 0.1);
    expect(state.vx[0]).toBeCloseTo(1, 4);
    expect(state.vy[0]).toBeCloseTo(-2, 4);
    expect(state.vz[0]).toBeCloseTo(3, 4);
    expect(state.x[0]).toBeGreaterThan(0);
    expect(state.y[0]).toBeLessThan(0);
    expect(state.z[0]).toBeGreaterThan(0);
  });

  it('emitBurst cria exatamente n partículas e respeita o teto', () => {
    const props = base({ emitting: false, maxParticles: 40 });
    const state = createState(props);
    expect(emitBurst(state, props, 25)).toBe(25);
    expect(state.count).toBe(25);
    expect(emitBurst(state, props, 25)).toBe(15);
    expect(state.count).toBe(40);
  });

  it('é determinístico por seed (e reset reproduz a sequência)', () => {
    const props = base({ seed: 42 });
    const a = createState(props);
    const b = createState(props);
    run(a, props, 1);
    run(b, props, 1);
    expect(Array.from(a.x.slice(0, a.count))).toEqual(Array.from(b.x.slice(0, b.count)));
    expect(Array.from(a.vy.slice(0, a.count))).toEqual(Array.from(b.vy.slice(0, b.count)));

    resetState(a);
    run(a, props, 1);
    expect(Array.from(a.x.slice(0, a.count))).toEqual(Array.from(b.x.slice(0, b.count)));

    const c = createState(props, 7);
    run(c, props, 1);
    expect(Array.from(c.x.slice(0, c.count))).not.toEqual(Array.from(b.x.slice(0, b.count)));
  });

  it('partículas morrem ao fim da vida', () => {
    const props = base({ emitting: false, lifetimeMin: 0.5, lifetimeMax: 0.5 });
    const state = createState(props);
    emitBurst(state, props, 10);
    run(state, props, 0.6);
    expect(state.count).toBe(0);
  });

  it('sinais: started ao ligar emitting; finished uma vez quando para e esvazia', () => {
    const on = base({ lifetimeMin: 0.2, lifetimeMax: 0.2 });
    const off = { ...on, emitting: false };
    const state = createState(on);
    expect(step(state, on, 0.05).started).toBe(true);
    expect(step(state, on, 0.05).started).toBe(false);
    let finished = 0;
    for (let i = 0; i < 30; i++) if (step(state, off, 0.05).finished) finished++;
    expect(finished).toBe(1);
    expect(state.count).toBe(0);
  });
});

describe('presets e contrato de propriedades', () => {
  const descriptors = NODE_REGISTRY.ParticleSystem.propertyDescriptors;
  const byKey = new Map(descriptors.map((d) => [d.key, d]));

  it('existem 8 presets com ids únicos, Fogo primeiro', () => {
    expect(PARTICLE_PRESETS).toHaveLength(8);
    expect(new Set(PARTICLE_PRESETS.map((p) => p.id)).size).toBe(8);
    expect(PARTICLE_PRESETS[0].id).toBe('fire');
  });

  it('todo preset está dentro dos limites dos descriptors', () => {
    for (const preset of PARTICLE_PRESETS) {
      const props = preset.properties as unknown as Record<string, unknown>;
      expect(props.presetId).toBe(preset.id);
      for (const [key, value] of Object.entries(props)) {
        const d = byKey.get(key);
        expect(d, `${preset.id}.${key} sem descriptor`).toBeDefined();
        if (typeof value === 'number' && d!.min !== undefined) {
          expect(value, `${preset.id}.${key}`).toBeGreaterThanOrEqual(d!.min!);
          expect(value, `${preset.id}.${key}`).toBeLessThanOrEqual(d!.max!);
        }
        if (d!.type === 'enum') {
          expect(d!.options!.map((o) => o.value), `${preset.id}.${key}`).toContain(value);
        }
      }
      expect(preset.properties.lifetimeMin).toBeLessThanOrEqual(preset.properties.lifetimeMax);
      expect(preset.properties.speedMin).toBeLessThanOrEqual(preset.properties.speedMax);
      expect(normalizeParticleProps(props)).toEqual(preset.properties);
    }
  });

  it('toda chave de defaultProperties tem descriptor; numéricos têm min/max', () => {
    const defaults = NODE_REGISTRY.ParticleSystem.defaultProperties;
    for (const key of Object.keys(defaults)) {
      const d = byKey.get(key);
      expect(d, `defaultProperties.${key} sem descriptor`).toBeDefined();
      if (d!.type === 'integer' || d!.type === 'float') {
        expect(d!.min, `${key}.min`).toBeDefined();
        expect(d!.max, `${key}.max`).toBeDefined();
      }
    }
  });

  it('o preset Fogo é o default do nó', () => {
    expect(presetProperties('fire')).toMatchObject(JSON.parse(JSON.stringify(PARTICLE_DEFAULTS)));
    expect(NODE_REGISTRY.ParticleSystem.defaultProperties.presetId).toBe('fire');
  });

  it('o tipo duplicado removido não existe mais e ParticleSystem existe uma vez no registry', () => {
    expect(Object.keys(NODE_REGISTRY)).not.toContain(['Particle', 'Emitter'].join(''));
    expect(Object.keys(NODE_REGISTRY).filter((k) => k === 'ParticleSystem')).toHaveLength(1);
  });
});

describe('addNode com initialProperties (AIS-18c-C05)', () => {
  it('createDefaultNode grava exatamente os valores do draft, sem compartilhar referências', () => {
    const draft = presetProperties('rain');
    const node = createDefaultNode('ParticleSystem', 'Chuva', 'root', draft);
    expect(node.properties).toMatchObject(JSON.parse(JSON.stringify(draft)));
    expect(node.properties.presetId).toBe('rain');
    expect(node.properties.position).toEqual({ x: 0, y: 0, z: 0 });
    (draft.gravity as { y: number }).y = 99;
    expect(node.properties.gravity.y).toBe(-9.8);
  });

  it('um único Command cria o nó com as propriedades e o Undo remove o nó inteiro', () => {
    const scene = createDefault3DStarterScene();
    const model = new AuthoringModel({ files: {}, settings: { general: {} } } as any, scene);
    const manager = new CommandManager();
    const rootId = model.getScene().rootNodeId;
    const draft = presetProperties('sparks');
    const node = createDefaultNode('ParticleSystem', 'Faiscas', rootId, draft);
    const before = Object.keys(model.getScene().nodes).length;

    // mesmo formato do Command de criação de `addNode` (EditorContext)
    manager.pushCommand({
      label: `Add node ${node.name}`,
      execute: () => void model.addNode(node, rootId),
      undo: () => model.deleteNode(node.id),
    });

    const created = model.getScene().nodes[node.id];
    expect(created.properties).toMatchObject(JSON.parse(JSON.stringify(draft)));
    expect(manager.getHistory()).toHaveLength(1);

    manager.undo();
    expect(model.getScene().nodes[node.id]).toBeUndefined();
    expect(Object.keys(model.getScene().nodes)).toHaveLength(before);
    expect(model.getScene().nodes[rootId].childrenIds).not.toContain(node.id);
  });
});
