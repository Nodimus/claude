/**
 * Motor único de partículas (AIS-18c). Funções puras sobre um estado mutável explícito:
 * sem React, sem THREE, sem DOM — roda em Node. Viewport (`viewportParticles.ts`) e preview do
 * modal (`ParticlePreviewCanvas`) chamam o mesmo `step()`.
 */
import { PARTICLE_LIMITS, type ParticleProps } from './particleTypes';

const CAPACITY = PARTICLE_LIMITS.maxParticles.max;
/** Passo máximo por chamada: evita rajadas quando a aba volta de background. */
export const MAX_STEP_DT = 0.1;

export interface ParticleState {
  /** Partículas vivas ocupam os índices `[0, count)`. */
  count: number;
  x: Float32Array;
  y: Float32Array;
  z: Float32Array;
  vx: Float32Array;
  vy: Float32Array;
  vz: Float32Array;
  age: Float32Array;
  life: Float32Array;
  /** Acumulador de spawn: taxa fracionária não perde partículas. */
  spawnAcc: number;
  rng: number;
  seed: number;
  /** Último valor de `emitting` visto por `step` (para o sinal `started`). */
  wasEmitting: boolean;
  /** Já houve partículas desde o último reset (para o sinal `finished` disparar uma vez). */
  hasEmitted: boolean;
}

/** Sinais do nó (somente declarados/expostos; ligação à aba Sinais segue o AIS-27). */
export interface ParticleSignals {
  started: boolean;
  finished: boolean;
}

export function createState(props: Pick<ParticleProps, 'seed'>, seed: number = props.seed): ParticleState {
  return {
    count: 0,
    x: new Float32Array(CAPACITY),
    y: new Float32Array(CAPACITY),
    z: new Float32Array(CAPACITY),
    vx: new Float32Array(CAPACITY),
    vy: new Float32Array(CAPACITY),
    vz: new Float32Array(CAPACITY),
    age: new Float32Array(CAPACITY),
    life: new Float32Array(CAPACITY),
    spawnAcc: 0,
    rng: seed >>> 0,
    seed: seed >>> 0,
    wasEmitting: false,
    hasEmitted: false,
  };
}

/** Volta ao instante inicial (mesma seed ⇒ mesma sequência). */
export function resetState(state: ParticleState): void {
  state.count = 0;
  state.spawnAcc = 0;
  state.rng = state.seed;
  state.wasEmitting = false;
  state.hasEmitted = false;
}

/** mulberry32 — determinístico por seed. */
function nextRandom(state: ParticleState): number {
  state.rng = (state.rng + 0x6d2b79f5) >>> 0;
  let t = state.rng;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

function spawnOne(state: ParticleState, props: ParticleProps): void {
  const i = state.count;
  const rnd = () => nextRandom(state);

  // Posição inicial segundo o formato do emissor
  let px = 0;
  let py = 0;
  let pz = 0;
  if (props.emitterType === 'ring') {
    const angle = rnd() * Math.PI * 2;
    const r = props.emitterRadius * (0.8 + rnd() * 0.4);
    px = Math.cos(angle) * r;
    pz = Math.sin(angle) * r;
  } else if (props.emitterType === 'box') {
    px = (rnd() - 0.5) * props.emitterBoxSize.x;
    py = (rnd() - 0.5) * props.emitterBoxSize.y;
    pz = (rnd() - 0.5) * props.emitterBoxSize.z;
  } else if (props.emitterType === 'sphere') {
    const theta = rnd() * Math.PI * 2;
    const cosPhi = 2 * rnd() - 1;
    const sinPhi = Math.sqrt(Math.max(0, 1 - cosPhi * cosPhi));
    const r = props.emitterRadius * Math.cbrt(rnd());
    px = r * sinPhi * Math.cos(theta);
    py = r * cosPhi;
    pz = r * sinPhi * Math.sin(theta);
  }

  // Direção: cone de meio-ângulo `maxAngleDeviation` em torno de `direction` (180° = esfera)
  let dx = props.direction.x;
  let dy = props.direction.y;
  let dz = props.direction.z;
  const len = Math.hypot(dx, dy, dz);
  if (len < 1e-6) {
    dx = 0; dy = 1; dz = 0;
  } else {
    dx /= len; dy /= len; dz /= len;
  }
  const maxAngle = (props.maxAngleDeviation * Math.PI) / 180;
  const cosMax = Math.cos(maxAngle);
  const cosT = cosMax + rnd() * (1 - cosMax);
  const sinT = Math.sqrt(Math.max(0, 1 - cosT * cosT));
  const phi = rnd() * Math.PI * 2;

  // Base ortonormal (u, v) perpendicular a d
  const ax = Math.abs(dy) < 0.99 ? 0 : 1;
  const ay = Math.abs(dy) < 0.99 ? 1 : 0;
  let ux = ay * dz - 0 * dy;
  let uy = 0 * dx - ax * dz;
  let uz = ax * dy - ay * dx;
  const ul = Math.hypot(ux, uy, uz) || 1;
  ux /= ul; uy /= ul; uz /= ul;
  const vx = dy * uz - dz * uy;
  const vy = dz * ux - dx * uz;
  const vz = dx * uy - dy * ux;

  const cp = Math.cos(phi) * sinT;
  const sp = Math.sin(phi) * sinT;
  const speed = props.speedMin + rnd() * (props.speedMax - props.speedMin);

  state.x[i] = px;
  state.y[i] = py;
  state.z[i] = pz;
  state.vx[i] = (dx * cosT + ux * cp + vx * sp) * speed;
  state.vy[i] = (dy * cosT + uy * cp + vy * sp) * speed;
  state.vz[i] = (dz * cosT + uz * cp + vz * sp) * speed;
  state.age[i] = 0;
  state.life[i] = props.lifetimeMin + rnd() * (props.lifetimeMax - props.lifetimeMin);
  state.count = i + 1;
  state.hasEmitted = true;
}

function capacityFor(props: ParticleProps): number {
  return Math.min(props.maxParticles, CAPACITY);
}

/** Emite `n` partículas de uma vez (rajada), respeitando `maxParticles`. Devolve quantas nasceram. */
export function emitBurst(state: ParticleState, props: ParticleProps, n: number): number {
  const room = Math.max(0, capacityFor(props) - state.count);
  const toSpawn = Math.min(room, Math.max(0, Math.floor(n)));
  for (let k = 0; k < toSpawn; k++) spawnOne(state, props);
  return toSpawn;
}

/** Avança a simulação `dt` segundos. Integra as vivas, depois emite pelo acumulador. */
export function step(state: ParticleState, props: ParticleProps, dt: number): ParticleSignals {
  const signals: ParticleSignals = { started: false, finished: false };
  const h = Math.min(MAX_STEP_DT, Math.max(0, dt));

  // Integração (swap-remove das mortas)
  let i = 0;
  while (i < state.count) {
    state.age[i] += h;
    if (state.age[i] >= state.life[i]) {
      const last = state.count - 1;
      if (i !== last) {
        state.x[i] = state.x[last]; state.y[i] = state.y[last]; state.z[i] = state.z[last];
        state.vx[i] = state.vx[last]; state.vy[i] = state.vy[last]; state.vz[i] = state.vz[last];
        state.age[i] = state.age[last]; state.life[i] = state.life[last];
      }
      state.count = last;
      continue;
    }
    state.vx[i] += props.gravity.x * h;
    state.vy[i] += props.gravity.y * h;
    state.vz[i] += props.gravity.z * h;
    state.x[i] += state.vx[i] * h;
    state.y[i] += state.vy[i] * h;
    state.z[i] += state.vz[i] * h;
    i++;
  }

  // Sinal `started`
  if (props.emitting && !state.wasEmitting) signals.started = true;
  state.wasEmitting = props.emitting;

  // Emissão contínua
  if (props.emitting) {
    state.spawnAcc += props.particlesPerSecond * h;
    const whole = Math.floor(state.spawnAcc);
    state.spawnAcc -= whole;
    const room = Math.max(0, capacityFor(props) - state.count);
    const toSpawn = Math.min(whole, room);
    for (let k = 0; k < toSpawn; k++) spawnOne(state, props);
  } else {
    state.spawnAcc = 0;
  }

  // Sinal `finished`: parado e sem partículas vivas (uma vez por ciclo)
  if (!props.emitting && state.count === 0 && state.hasEmitted) {
    signals.finished = true;
    state.hasEmitted = false;
  }

  return signals;
}

export interface ParticleSample {
  size: number;
  r: number;
  g: number;
  b: number;
  a: number;
}

const _sample: ParticleSample = { size: 0, r: 0, g: 0, b: 0, a: 0 };

/** Tamanho/cor da partícula `i` (interpolação início → fim). Devolve um objeto reutilizado. */
export function sampleParticle(state: ParticleState, props: ParticleProps, i: number, out: ParticleSample = _sample): ParticleSample {
  const t = Math.min(1, Math.max(0, state.age[i] / state.life[i]));
  const s = props.startColor;
  const e = props.endColor;
  out.size = props.startSize + (props.endSize - props.startSize) * t;
  out.r = s.r + (e.r - s.r) * t;
  out.g = s.g + (e.g - s.g) * t;
  out.b = s.b + (e.b - s.b) * t;
  const alpha = s.a + (e.a - s.a) * t;
  out.a = props.fadeOut ? alpha * (1 - t) : alpha;
  return out;
}

/**
 * Preenche buffers de render (posição xyz, cor rgba, tamanho). Devolve a quantidade de partículas.
 * Os arrays precisam ter capacidade para `state.count` partículas.
 */
export function writeParticleBuffers(
  state: ParticleState,
  props: ParticleProps,
  positions: Float32Array,
  colors: Float32Array,
  sizes: Float32Array
): number {
  for (let i = 0; i < state.count; i++) {
    const s = sampleParticle(state, props, i);
    positions[i * 3] = state.x[i];
    positions[i * 3 + 1] = state.y[i];
    positions[i * 3 + 2] = state.z[i];
    colors[i * 4] = s.r;
    colors[i * 4 + 1] = s.g;
    colors[i * 4 + 2] = s.b;
    colors[i * 4 + 3] = s.a;
    sizes[i] = s.size;
  }
  return state.count;
}

export const PARTICLE_CAPACITY = CAPACITY;
