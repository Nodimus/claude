/**
 * Contrato do `ParticleSystem` (AIS-18c). Módulo puro: sem React, sem THREE, sem DOM.
 * `GameNode.properties` é a única fonte de verdade; estes tipos descrevem o seu recorte de partículas.
 */

export type EmitterType = 'point' | 'box' | 'ring' | 'sphere';
export type ParticleBlendMode = 'additive' | 'alpha' | 'modulate';
export type ParticleTextureType = 'glow' | 'flame' | 'smoke' | 'spark' | 'drop' | 'snow' | 'star';

export const EMITTER_TYPES: readonly EmitterType[] = ['point', 'box', 'ring', 'sphere'];
export const BLEND_MODES: readonly ParticleBlendMode[] = ['additive', 'alpha', 'modulate'];
export const PARTICLE_TEXTURES: readonly ParticleTextureType[] = ['glow', 'flame', 'smoke', 'spark', 'drop', 'snow', 'star'];

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

/** Cor com canais em 0..1 (mesmo formato dos descriptors `color` do registry). */
export interface RGBA {
  r: number;
  g: number;
  b: number;
  a: number;
}

export interface ParticleProps {
  emitting: boolean;
  emitterType: EmitterType;
  emitterRadius: number;
  emitterBoxSize: Vec3;
  particlesPerSecond: number;
  maxParticles: number;
  lifetimeMin: number;
  lifetimeMax: number;
  direction: Vec3;
  maxAngleDeviation: number;
  speedMin: number;
  speedMax: number;
  gravity: Vec3;
  startColor: RGBA;
  endColor: RGBA;
  startSize: number;
  endSize: number;
  fadeOut: boolean;
  blending: ParticleBlendMode;
  texture: ParticleTextureType;
  presetId: string;
  seed: number;
}

export interface NumericLimit {
  min: number;
  max: number;
}

/** Limites numéricos: fonte única para clamp do motor e `min/max` dos descriptors do registry. */
export const PARTICLE_LIMITS = {
  emitterRadius: { min: 0, max: 50 },
  emitterBoxSize: { min: 0, max: 100 },
  particlesPerSecond: { min: 1, max: 1000 },
  maxParticles: { min: 10, max: 2000 },
  lifetimeMin: { min: 0.05, max: 30 },
  lifetimeMax: { min: 0.1, max: 30 },
  maxAngleDeviation: { min: 0, max: 180 },
  speedMin: { min: 0, max: 50 },
  speedMax: { min: 0, max: 50 },
  gravity: { min: -100, max: 100 },
  startSize: { min: 0.01, max: 10 },
  endSize: { min: 0.01, max: 10 },
  seed: { min: 0, max: 2147483647 },
} as const satisfies Record<string, NumericLimit>;

/** Defaults = preset Fogo (criar `ParticleSystem` pelo menu gera Fogo, sem diálogo). */
export const PARTICLE_DEFAULTS: ParticleProps = {
  emitting: true,
  emitterType: 'ring',
  emitterRadius: 0.8,
  emitterBoxSize: { x: 1.5, y: 0.2, z: 1.5 },
  particlesPerSecond: 80,
  maxParticles: 350,
  lifetimeMin: 0.8,
  lifetimeMax: 1.8,
  direction: { x: 0, y: 1, z: 0 },
  maxAngleDeviation: 22,
  speedMin: 1.5,
  speedMax: 3.2,
  gravity: { x: 0, y: 0.8, z: 0 },
  startColor: { r: 1, g: 0.667, b: 0.133, a: 0.95 },
  endColor: { r: 0.867, g: 0.133, b: 0, a: 0 },
  startSize: 0.35,
  endSize: 0.85,
  fadeOut: true,
  blending: 'additive',
  texture: 'flame',
  presetId: 'fire',
  seed: 1337,
};

export function clampNumber(value: unknown, limit: NumericLimit, fallback: number): number {
  const n = typeof value === 'number' && Number.isFinite(value) ? value : fallback;
  return Math.min(limit.max, Math.max(limit.min, n));
}

function pickEnum<T extends string>(value: unknown, allowed: readonly T[], fallback: T): T {
  return allowed.includes(value as T) ? (value as T) : fallback;
}

function readVec3(value: unknown, fallback: Vec3, limit?: NumericLimit): Vec3 {
  const v = (value ?? {}) as Partial<Vec3>;
  const read = (n: unknown, f: number) => (limit ? clampNumber(n, limit, f) : typeof n === 'number' && Number.isFinite(n) ? n : f);
  return { x: read(v.x, fallback.x), y: read(v.y, fallback.y), z: read(v.z, fallback.z) };
}

function readColor(value: unknown, fallback: RGBA): RGBA {
  const c = (value ?? {}) as Partial<RGBA>;
  const unit = (n: unknown, f: number) => clampNumber(n, { min: 0, max: 1 }, f);
  return { r: unit(c.r, fallback.r), g: unit(c.g, fallback.g), b: unit(c.b, fallback.b), a: unit(c.a, fallback.a) };
}

/**
 * Lê as propriedades de um nó (ou de um draft parcial) e devolve um `ParticleProps` completo e
 * dentro dos limites. Chaves ausentes/inválidas caem nos defaults; `min ≤ max` é garantido.
 */
export function normalizeParticleProps(raw: Record<string, unknown> | undefined | null): ParticleProps {
  const p = raw ?? {};
  const D = PARTICLE_DEFAULTS;
  const L = PARTICLE_LIMITS;

  const lifetimeMin = clampNumber(p.lifetimeMin, L.lifetimeMin, D.lifetimeMin);
  const lifetimeMax = Math.max(lifetimeMin, clampNumber(p.lifetimeMax, L.lifetimeMax, D.lifetimeMax));
  const speedMin = clampNumber(p.speedMin, L.speedMin, D.speedMin);
  const speedMax = Math.max(speedMin, clampNumber(p.speedMax, L.speedMax, D.speedMax));

  return {
    emitting: typeof p.emitting === 'boolean' ? p.emitting : D.emitting,
    emitterType: pickEnum(p.emitterType, EMITTER_TYPES, D.emitterType),
    emitterRadius: clampNumber(p.emitterRadius, L.emitterRadius, D.emitterRadius),
    emitterBoxSize: readVec3(p.emitterBoxSize, D.emitterBoxSize, L.emitterBoxSize),
    particlesPerSecond: clampNumber(p.particlesPerSecond, L.particlesPerSecond, D.particlesPerSecond),
    maxParticles: Math.round(clampNumber(p.maxParticles, L.maxParticles, D.maxParticles)),
    lifetimeMin,
    lifetimeMax,
    direction: readVec3(p.direction, D.direction),
    maxAngleDeviation: clampNumber(p.maxAngleDeviation, L.maxAngleDeviation, D.maxAngleDeviation),
    speedMin,
    speedMax,
    gravity: readVec3(p.gravity, D.gravity, L.gravity),
    startColor: readColor(p.startColor, D.startColor),
    endColor: readColor(p.endColor, D.endColor),
    startSize: clampNumber(p.startSize, L.startSize, D.startSize),
    endSize: clampNumber(p.endSize, L.endSize, D.endSize),
    fadeOut: typeof p.fadeOut === 'boolean' ? p.fadeOut : D.fadeOut,
    blending: pickEnum(p.blending, BLEND_MODES, D.blending),
    texture: pickEnum(p.texture, PARTICLE_TEXTURES, D.texture),
    presetId: typeof p.presetId === 'string' ? p.presetId : D.presetId,
    seed: Math.floor(clampNumber(p.seed, L.seed, D.seed)),
  };
}

export function rgbaToHex(c: RGBA): string {
  const h = (v: number) => Math.round(Math.min(1, Math.max(0, v)) * 255).toString(16).padStart(2, '0');
  return `#${h(c.r)}${h(c.g)}${h(c.b)}`;
}

export function hexToRgba(hex: string, a: number): RGBA {
  const clean = hex.replace('#', '');
  const full = clean.length === 3 ? clean.split('').map((ch) => ch + ch).join('') : clean;
  const n = parseInt(full.padEnd(6, '0').slice(0, 6), 16);
  return { r: ((n >> 16) & 255) / 255, g: ((n >> 8) & 255) / 255, b: (n & 255) / 255, a };
}
