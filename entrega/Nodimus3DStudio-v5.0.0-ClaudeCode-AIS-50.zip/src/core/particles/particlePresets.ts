/**
 * Presets de partículas como dados, no formato das propriedades do nó (AIS-18c).
 * Modal, Inspector (AIS-23) e CreateNodeModal leem daqui.
 */
import { PARTICLE_DEFAULTS, hexToRgba, type ParticleProps } from './particleTypes';

export interface ParticlePreset {
  id: string;
  /** Nome exibido no catálogo. */
  name: string;
  /** Rótulo curto do chip de preset. */
  shortName: string;
  /** Nome de ícone lucide (resolvido pela UI). */
  icon: string;
  description: string;
  /** Sufixo do nome sugerido para o nó (`ParticleSystem_<suffix>`). */
  nodeNameSuffix: string;
  properties: ParticleProps;
}

/** Rótulo curto = primeiro termo do nome. */
function shortName(name: string): string {
  return name.split(' ')[0];
}

function make(
  id: string,
  name: string,
  icon: string,
  nodeNameSuffix: string,
  description: string,
  overrides: Partial<ParticleProps> & Pick<ParticleProps, 'startColor' | 'endColor'>
): ParticlePreset {
  return {
    id,
    name,
    shortName: shortName(name),
    icon,
    nodeNameSuffix,
    description,
    properties: { ...PARTICLE_DEFAULTS, emitting: true, ...overrides, presetId: id },
  };
}

export const PARTICLE_PRESETS: readonly ParticlePreset[] = [
  {
    id: 'fire',
    name: 'Fogo',
    shortName: 'Fogo',
    icon: 'Flame',
    nodeNameSuffix: 'Fogo',
    description: 'Chamas crepitantes ascendentes com brilho aditivo e transição âmbar para vermelho.',
    properties: { ...PARTICLE_DEFAULTS, presetId: 'fire' },
  },
  make('smoke', 'Fumaça', 'Wind', 'Fumaca',
    'Fumaça volumosa translúcida que se expande gradualmente conforme sobe.', {
      emitterType: 'point',
      particlesPerSecond: 45,
      maxParticles: 220,
      lifetimeMin: 1.8,
      lifetimeMax: 3.8,
      direction: { x: 0.1, y: 1, z: 0 },
      maxAngleDeviation: 35,
      speedMin: 0.8,
      speedMax: 1.8,
      gravity: { x: 0.2, y: 0.3, z: 0 },
      startColor: hexToRgba('#444c58', 0.7),
      endColor: hexToRgba('#1a1e24', 0),
      startSize: 0.4,
      endSize: 2.2,
      fadeOut: true,
      blending: 'alpha',
      texture: 'smoke',
    }),
  make('rain', 'Chuva', 'CloudRain', 'Chuva',
    'Gotas de chuva caindo em alta velocidade a partir de um volume superior retangular.', {
      emitterType: 'box',
      emitterBoxSize: { x: 12, y: 0.2, z: 12 },
      particlesPerSecond: 250,
      maxParticles: 600,
      lifetimeMin: 0.6,
      lifetimeMax: 1.2,
      direction: { x: 0, y: -1, z: 0 },
      maxAngleDeviation: 5,
      speedMin: 8,
      speedMax: 14,
      gravity: { x: 0, y: -9.8, z: 0 },
      startColor: hexToRgba('#80b8e6', 0.6),
      endColor: hexToRgba('#b0d8ff', 0.1),
      startSize: 0.15,
      endSize: 0.2,
      fadeOut: false,
      blending: 'alpha',
      texture: 'drop',
    }),
  make('snow', 'Neve', 'Snowflake', 'Neve',
    'Flocos de neve flutuando e oscilando suavemente sobre a cena.', {
      emitterType: 'box',
      emitterBoxSize: { x: 12, y: 0.2, z: 12 },
      particlesPerSecond: 120,
      maxParticles: 450,
      lifetimeMin: 2.5,
      lifetimeMax: 5.5,
      direction: { x: 0, y: -1, z: 0 },
      maxAngleDeviation: 30,
      speedMin: 0.8,
      speedMax: 1.8,
      gravity: { x: 0.1, y: -0.6, z: 0 },
      startColor: hexToRgba('#ffffff', 0.9),
      endColor: hexToRgba('#d6e6f5', 0.2),
      startSize: 0.15,
      endSize: 0.35,
      fadeOut: true,
      blending: 'alpha',
      texture: 'snow',
    }),
  make('sparks', 'Faíscas', 'Zap', 'Faiscas',
    'Faíscas rápidas e brilhantes lançadas em leque, que caem sob a gravidade.', {
      emitterType: 'point',
      particlesPerSecond: 90,
      maxParticles: 300,
      lifetimeMin: 0.4,
      lifetimeMax: 1.0,
      direction: { x: 0, y: 1, z: 0 },
      maxAngleDeviation: 55,
      speedMin: 3,
      speedMax: 7,
      gravity: { x: 0, y: -8, z: 0 },
      startColor: hexToRgba('#fff2a8', 1),
      endColor: hexToRgba('#ff7a18', 0),
      startSize: 0.12,
      endSize: 0.03,
      fadeOut: true,
      blending: 'additive',
      texture: 'spark',
    }),
  make('explosion', 'Explosão', 'Bomb', 'Explosao',
    'Explosão radial de alta energia em todas as direções.', {
      emitterType: 'sphere',
      emitterRadius: 0.3,
      particlesPerSecond: 300,
      maxParticles: 500,
      lifetimeMin: 0.4,
      lifetimeMax: 1.1,
      maxAngleDeviation: 180,
      speedMin: 5,
      speedMax: 12,
      gravity: { x: 0, y: -2, z: 0 },
      startColor: hexToRgba('#ffdd44', 1),
      endColor: hexToRgba('#ff3300', 0),
      startSize: 0.5,
      endSize: 1.6,
      fadeOut: true,
      blending: 'additive',
      texture: 'glow',
    }),
  make('magic_dust', 'Poeira Mágica', 'Sparkles', 'PoeiraMagica',
    'Partículas cintilantes púrpuras e cianas, ideais para auras místicas e portais.', {
      emitterType: 'ring',
      emitterRadius: 1,
      particlesPerSecond: 110,
      maxParticles: 400,
      lifetimeMin: 1,
      lifetimeMax: 2.2,
      maxAngleDeviation: 45,
      speedMin: 1.8,
      speedMax: 4.2,
      gravity: { x: 0, y: 0.4, z: 0 },
      startColor: hexToRgba('#c056f5', 1),
      endColor: hexToRgba('#38bdf8', 0),
      startSize: 0.25,
      endSize: 0.05,
      fadeOut: true,
      blending: 'additive',
      texture: 'star',
    }),
  make('fireflies', 'Vaga-lumes', 'Zap', 'VagaLumes',
    'Pontos de luz verdejantes e bioluminescentes flutuando na escuridão.', {
      emitterType: 'box',
      emitterBoxSize: { x: 6, y: 2, z: 6 },
      particlesPerSecond: 25,
      maxParticles: 90,
      lifetimeMin: 3,
      lifetimeMax: 6,
      direction: { x: 0, y: 0.2, z: 0 },
      maxAngleDeviation: 120,
      speedMin: 0.3,
      speedMax: 0.8,
      gravity: { x: 0, y: 0.05, z: 0 },
      startColor: hexToRgba('#a3e635', 0.9),
      endColor: hexToRgba('#22c55e', 0),
      startSize: 0.2,
      endSize: 0.25,
      fadeOut: true,
      blending: 'additive',
      texture: 'glow',
    }),
];

export const DEFAULT_PARTICLE_PRESET_ID = 'fire';

export function getParticlePreset(id: string): ParticlePreset | undefined {
  return PARTICLE_PRESETS.find((p) => p.id === id);
}

/** Cópia profunda das propriedades de um preset (nunca devolve a referência compartilhada). */
export function presetProperties(id: string = DEFAULT_PARTICLE_PRESET_ID): ParticleProps {
  const preset = getParticlePreset(id) ?? PARTICLE_PRESETS[0];
  return JSON.parse(JSON.stringify(preset.properties)) as ParticleProps;
}
