/**
 * Texturas procedurais de partículas (AIS-18c): máscaras brancas com alpha desenhadas em canvas 2D.
 * `drawParticleTexture` só precisa de um contexto 2D (testável com um stub); a cor vem do material.
 */
import type { ParticleTextureType } from './particleTypes';

export const PARTICLE_TEXTURE_SIZE = 64;

type Ctx = Pick<
  CanvasRenderingContext2D,
  | 'clearRect' | 'createRadialGradient' | 'fillRect' | 'beginPath' | 'arc' | 'fill' | 'save' | 'restore'
  | 'translate' | 'scale' | 'moveTo' | 'lineTo' | 'closePath' | 'ellipse' | 'fillStyle'
>;

function radial(ctx: Ctx, size: number, stops: Array<[number, number]>, radiusScale = 0.5): void {
  const c = size / 2;
  const g = ctx.createRadialGradient(c, c, 0, c, c, c * 2 * radiusScale);
  for (const [at, alpha] of stops) g.addColorStop(at, `rgba(255,255,255,${alpha})`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
}

/** Desenha a máscara `kind` ocupando o canvas `size`×`size`. */
export function drawParticleTexture(ctx: Ctx, kind: ParticleTextureType, size: number = PARTICLE_TEXTURE_SIZE): void {
  const c = size / 2;
  ctx.clearRect(0, 0, size, size);
  switch (kind) {
    case 'glow':
      radial(ctx, size, [[0, 1], [0.35, 0.6], [1, 0]]);
      break;
    case 'flame':
      radial(ctx, size, [[0, 1], [0.25, 0.85], [0.6, 0.3], [1, 0]]);
      break;
    case 'smoke':
      radial(ctx, size, [[0, 0.7], [0.5, 0.4], [1, 0]]);
      break;
    case 'spark':
      radial(ctx, size, [[0, 1], [0.12, 0.9], [0.3, 0.15], [1, 0]]);
      break;
    case 'drop': {
      ctx.save();
      ctx.translate(c, c);
      ctx.scale(0.35, 1);
      const g = ctx.createRadialGradient(0, 0, 0, 0, 0, c);
      g.addColorStop(0, 'rgba(255,255,255,1)');
      g.addColorStop(0.7, 'rgba(255,255,255,0.7)');
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(0, 0, c, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      break;
    }
    case 'snow':
      radial(ctx, size, [[0, 1], [0.5, 0.9], [0.75, 0.4], [1, 0]]);
      break;
    case 'star': {
      radial(ctx, size, [[0, 0.9], [0.2, 0.35], [1, 0]]);
      ctx.fillStyle = 'rgba(255,255,255,0.95)';
      ctx.beginPath();
      for (let i = 0; i < 8; i++) {
        const r = i % 2 === 0 ? c * 0.95 : c * 0.18;
        const a = (Math.PI / 4) * i - Math.PI / 2;
        const x = c + Math.cos(a) * r;
        const y = c + Math.sin(a) * r;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
      break;
    }
  }
}

const maskCache = new Map<ParticleTextureType, HTMLCanvasElement>();

/** Máscara em cache (requer DOM). Compartilhada entre a viewport e o preview. */
export function getParticleMaskCanvas(kind: ParticleTextureType): HTMLCanvasElement {
  let canvas = maskCache.get(kind);
  if (!canvas) {
    canvas = document.createElement('canvas');
    canvas.width = PARTICLE_TEXTURE_SIZE;
    canvas.height = PARTICLE_TEXTURE_SIZE;
    const ctx = canvas.getContext('2d');
    if (ctx) drawParticleTexture(ctx, kind);
    maskCache.set(kind, canvas);
  }
  return canvas;
}

const tintCache = new Map<string, HTMLCanvasElement>();
const TINT_SIZE = 32;

/** Sprite tingido (cor quantizada em 8 níveis/canal) para o preview 2D. */
export function getTintedParticleCanvas(kind: ParticleTextureType, r: number, g: number, b: number): HTMLCanvasElement {
  const q = (v: number) => Math.round(Math.min(1, Math.max(0, v)) * 7);
  const qr = q(r), qg = q(g), qb = q(b);
  const key = `${kind}:${qr}:${qg}:${qb}`;
  let canvas = tintCache.get(key);
  if (!canvas) {
    canvas = document.createElement('canvas');
    canvas.width = TINT_SIZE;
    canvas.height = TINT_SIZE;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(getParticleMaskCanvas(kind), 0, 0, TINT_SIZE, TINT_SIZE);
      ctx.globalCompositeOperation = 'source-in';
      ctx.fillStyle = `rgb(${Math.round((qr / 7) * 255)},${Math.round((qg / 7) * 255)},${Math.round((qb / 7) * 255)})`;
      ctx.fillRect(0, 0, TINT_SIZE, TINT_SIZE);
    }
    tintCache.set(key, canvas);
  }
  return canvas;
}
