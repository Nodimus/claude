/**
 * Canonical Persistence Versions & Schema Registry
 *
 * Defines current integer schema versions for all persisted JSON documents
 * in the Nodimus 3D Studio ecosystem:
 * - project.json
 * - *.scene.json
 * - *.prefab.json
 * - *.material.json
 * - *.rig.json / *.anim
 */

export const CURRENT_PROJECT_SCHEMA_VERSION = 1;
/**
 * v2 (AIS-29b): formato canônico `SceneFile` (v1 = `SceneData` gravado direto). v3 (AIS-41b): `GameNode.behaviors` passa a ser a lista
 * de instâncias inline (antes: IDs de uma lista global). Migrações em `src/migrations/sceneMigrations.ts`.
 */
export const CURRENT_SCENE_SCHEMA_VERSION = 3;
export const CURRENT_NODE_SCHEMA_VERSION = 1;
export const CURRENT_BEHAVIOR_SCHEMA_VERSION = 1;
export const CURRENT_PREFAB_SCHEMA_VERSION = 1;
export const CURRENT_MATERIAL_SCHEMA_VERSION = 1;

export const MINIMUM_SUPPORTED_PROJECT_SCHEMA_VERSION = 1;
export const MINIMUM_SUPPORTED_SCENE_SCHEMA_VERSION = 1;

export interface DocumentVersionInfo {
  documentType: 'project' | 'scene' | 'node' | 'behavior' | 'prefab' | 'material';
  schemaVersion: number;
  isSupported: boolean;
  requiresMigration: boolean;
}

/**
 * Checks document version compatibility.
 */
export function checkSchemaVersion(
  documentType: 'project' | 'scene' | 'node' | 'behavior' | 'prefab' | 'material',
  version: unknown
): DocumentVersionInfo {
  const numVersion = typeof version === 'number' && Number.isInteger(version) ? version : 0;

  let currentVersion = 1;
  let minSupported = 1;

  switch (documentType) {
    case 'project':
      currentVersion = CURRENT_PROJECT_SCHEMA_VERSION;
      minSupported = MINIMUM_SUPPORTED_PROJECT_SCHEMA_VERSION;
      break;
    case 'scene':
      currentVersion = CURRENT_SCENE_SCHEMA_VERSION;
      minSupported = MINIMUM_SUPPORTED_SCENE_SCHEMA_VERSION;
      break;
    case 'node':
      currentVersion = CURRENT_NODE_SCHEMA_VERSION;
      break;
    case 'behavior':
      currentVersion = CURRENT_BEHAVIOR_SCHEMA_VERSION;
      break;
    case 'prefab':
      currentVersion = CURRENT_PREFAB_SCHEMA_VERSION;
      break;
    case 'material':
      currentVersion = CURRENT_MATERIAL_SCHEMA_VERSION;
      break;
  }

  const isSupported = numVersion >= minSupported && numVersion <= currentVersion;
  const requiresMigration = numVersion < currentVersion;

  return {
    documentType,
    schemaVersion: numVersion,
    isSupported,
    requiresMigration,
  };
}
