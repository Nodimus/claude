import type { ResourceRef } from '../types/node';
import type { GeneratorSource } from '../types/generatorSource';
import { readTerrainConfig, snapSegments, TERRAIN_PRESETS } from './terrainGeometry';

/**
 * AIS-50 — regras puras de edição do nó `Terrain` (Inspector, modal, drag-and-drop). Nada aqui muda estado: devolve as
 * alterações de `properties` e o `generatorSource`, e quem chama as grava por Command (um Undo).
 */

type Props = Record<string, any> | undefined;
const isRef = (v: unknown): v is ResourceRef => !!v && typeof v === 'object' && typeof (v as ResourceRef).id === 'string' && (v as ResourceRef).id.length > 0;

/** O terreno foi esculpido (existe `.height`): a geometria vem do arquivo e não pode ser trocada sem descartar a escultura. */
export const hasSculptedHeights = (props: Props): boolean => isRef(props?.heightBufferRef);

export type GeometryEditCheck = { ok: true } | { ok: false; reason: string };

/** Trocar preset/seed/heightmap/segmentos exige geometria nova: com `.height` só pelo "Regenerar geometria" (com confirmação). */
export function canChangeGeometry(props: Props): GeometryEditCheck {
  return hasSculptedHeights(props)
    ? { ok: false, reason: 'Terreno editado manualmente: use "Regenerar geometria" no Editor de Terreno (descarta a escultura).' }
    : { ok: true };
}

/** Marca de origem do gerador a partir das propriedades: `params` mínimo, propriedades do nó são a fonte de verdade. */
export function terrainGeneratorSource(props: Props): GeneratorSource {
  const config = readTerrainConfig(props);
  return { generatorId: 'terrain', version: 1, params: { preset: config.preset }, seed: config.presetSeed };
}

/** Define o heightmap (imagem em `res://textures/`) e, por consequência, a fonte de altura deixa de ser o preset. */
export function heightmapChanges(ref: ResourceRef | null): Record<string, any> {
  return { heightmapRef: ref };
}

/** Nova semente do preset; `random` injetável (determinístico em teste). */
export function reseedChanges(props: Props, random: () => number = Math.random): Record<string, any> {
  const current = readTerrainConfig(props).presetSeed;
  let next = Math.floor(random() * 1_000_000);
  if (next === current) next = (next + 1) % 1_000_000;
  return { presetSeed: next };
}

/** Rascunho do modal (somente os campos de geração/textura que ele edita) → mudanças reais em relação ao nó. */
export interface TerrainDraft {
  width: number;
  depth: number;
  segmentsW: number;
  segmentsH: number;
  maxHeight: number;
  terrainPreset: string;
  presetSeed: number;
  heightmapRef: ResourceRef | null;
  invertHeightmap: boolean;
  smoothHeightmap: boolean;
  groundTexture: string;
  midTexture: string;
  highTexture: string;
  textureTiling: number;
  blendSharpness: number;
}

export const GEOMETRY_KEYS = ['width', 'depth', 'segmentsW', 'segmentsH', 'terrainPreset', 'presetSeed', 'heightmapRef', 'invertHeightmap', 'smoothHeightmap'] as const;
export const VISUAL_KEYS = ['groundTexture', 'midTexture', 'highTexture', 'textureTiling', 'blendSharpness'] as const;
/** `maxHeight` conta nas duas: muda a geometria gerada, mas num terreno esculpido vale só como escala visual. */
const ALL_KEYS = [...GEOMETRY_KEYS, 'maxHeight', ...VISUAL_KEYS] as const;

const same = (a: unknown, b: unknown) => JSON.stringify(a ?? null) === JSON.stringify(b ?? null);

export function draftFromProps(props: Props): TerrainDraft {
  const c = readTerrainConfig(props);
  return {
    width: c.width,
    depth: c.depth,
    segmentsW: c.segmentsW,
    segmentsH: c.segmentsH,
    maxHeight: c.maxHeight,
    terrainPreset: c.preset,
    presetSeed: c.presetSeed,
    heightmapRef: isRef(props?.heightmapRef) ? props!.heightmapRef : null,
    invertHeightmap: c.invertHeightmap,
    smoothHeightmap: c.smoothHeightmap,
    groundTexture: c.groundTexture,
    midTexture: c.midTexture,
    highTexture: c.highTexture,
    textureTiling: c.textureTiling,
    blendSharpness: c.blendSharpness,
  };
}

/** Normaliza o rascunho (mesmos limites de `readTerrainConfig`): o que o modal grava é o que o nó vai ler. */
export function normalizeDraft(draft: TerrainDraft): TerrainDraft {
  const c = readTerrainConfig({ ...draft, segmentsW: snapSegments(draft.segmentsW), segmentsH: snapSegments(draft.segmentsH) });
  return { ...draft, width: c.width, depth: c.depth, segmentsW: c.segmentsW, segmentsH: c.segmentsH, maxHeight: c.maxHeight, terrainPreset: TERRAIN_PRESETS.some((p) => p.id === draft.terrainPreset) ? draft.terrainPreset : c.preset, presetSeed: c.presetSeed, textureTiling: c.textureTiling, blendSharpness: c.blendSharpness };
}

/** Só as chaves que mudam entre o nó e o rascunho (vazio = nada a aplicar). */
export function draftChanges(props: Props, draft: TerrainDraft, keys: readonly (keyof TerrainDraft)[] = ALL_KEYS): Record<string, any> {
  const base = draftFromProps(props);
  const next = normalizeDraft(draft);
  const out: Record<string, any> = {};
  for (const k of keys) if (!same(base[k], next[k])) out[k] = next[k];
  return out;
}

/** Há mudança que exige geometria nova (habilita "Regenerar geometria"). */
export function geometryDirty(props: Props, draft: TerrainDraft): boolean {
  return Object.keys(draftChanges(props, draft, [...GEOMETRY_KEYS, 'maxHeight'])).length > 0;
}

/**
 * "Atualizar parâmetros visuais" (terreno esculpido): só texturas/tiling/blend e `maxHeight` como escala visual — nunca
 * segmentos, heightmap, preset ou seed (travados no modal).
 */
export function visualOnlyChanges(props: Props, draft: TerrainDraft): Record<string, any> {
  return draftChanges(props, draft, [...VISUAL_KEYS, 'maxHeight']);
}

/** Mudanças que "Regenerar geometria" aplica num terreno esculpido: tudo do rascunho + remoção do vínculo do `.height`. */
export function regenerateChanges(props: Props, draft: TerrainDraft): Record<string, any> {
  const changes = draftChanges(props, draft);
  if (hasSculptedHeights(props)) changes.heightBufferRef = null;
  return changes;
}
