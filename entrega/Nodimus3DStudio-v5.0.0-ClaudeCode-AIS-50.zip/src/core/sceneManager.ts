import type { ProjectData, VirtualFile } from '../types/project';
import { DEFAULT_SCENE_ENVIRONMENT, type SceneData } from '../types/scene';
import { createDefault3DStarterScene, createEmptyScene } from './defaultProject';
import { baseNameOf, parentFolderOf, remapPath, validateName } from './fileSystem/fileOps';
import { replaceUrisInText } from './resourceRewrite';
import { derivedSceneId, parseSceneJson, serializeSceneToJson } from './serialization/sceneSerializer';
import { sceneIdFromContent } from './sceneIds';

/**
 * AIS-29f — CRUD de cenas do projeto (add, duplicar, renomear, cena inicial, regras de exclusão): funções PURAS sobre o
 * `ProjectData`. O `project.json` canônico é derivado destes dados (`ProjectStorage.toProjectFile`): a cena inicial é
 * `settings.general.mainScene` (→ `startSceneId` / `isStartScene`) e o id de cada cena no `project.json` é o `sceneId`
 * estável do arquivo, que nunca muda ao renomear.
 *
 * Excluir o arquivo da cena NÃO mora aqui: passa pelo `deleteResource` (AIS-29e), que lista os consumidores e nunca
 * apaga referências em silêncio. Aqui ficam só as regras de cena (única, inicial) e a escolha da nova cena inicial.
 */

export const SCENES_DIR = 'res://scenes/';
export const SCENE_SUFFIX = '.scene.json';

export interface SceneInfo {
  path: string;
  /** Nome exibido (nome do arquivo sem o sufixo). */
  name: string;
  /** Identidade estável da cena (`sceneId` do arquivo; derivada do caminho se o arquivo não traz). */
  sceneId: string;
  isInitial: boolean;
}

const isSceneFile = (f: VirtualFile) => !f.isDirectory && f.path.endsWith(SCENE_SUFFIX);
export const sceneNameOf = (path: string): string => baseNameOf(path).replace(/\.scene\.json$/i, '');

/** Caminho da cena inicial: `mainScene` se existir; senão a última aberta; senão a primeira cena. */
export function initialScenePath(project: ProjectData): string {
  const scenes = Object.values(project.files).filter(isSceneFile).map((f) => f.path).sort();
  const main = project.settings?.general?.mainScene;
  if (main && project.files[main]) return main;
  if (project.lastOpenedScene && project.files[project.lastOpenedScene]) return project.lastOpenedScene;
  return scenes[0] ?? main ?? '';
}

export function listScenes(project: ProjectData): SceneInfo[] {
  const initial = initialScenePath(project);
  return Object.values(project.files)
    .filter(isSceneFile)
    .map((f) => ({ path: f.path, name: sceneNameOf(f.path), sceneId: sceneIdFromContent(f.content, f.path), isInitial: f.path === initial }))
    .sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
}

const scenePathFor = (folder: string, name: string) => `${folder}${name}${SCENE_SUFFIX}`;

/** Nome livre na pasta de cenas: `base`, `base_2`, `base_3`… (compara sem diferenciar maiúsculas). */
export function uniqueSceneName(project: ProjectData, base: string, folder: string = SCENES_DIR): string {
  const taken = new Set(Object.keys(project.files).map((p) => p.toLowerCase()));
  if (!taken.has(scenePathFor(folder, base).toLowerCase())) return base;
  for (let i = 2; i < 1000; i++) {
    if (!taken.has(scenePathFor(folder, `${base}_${i}`).toLowerCase())) return `${base}_${i}`;
  }
  return `${base}_${Date.now()}`;
}

/** Nome de cena válido e livre (`ignorePath` = a própria cena ao renomear). */
export function validateSceneName(project: ProjectData, name: string, folder: string = SCENES_DIR, ignorePath?: string): { ok: boolean; error?: string } {
  const v = validateName(name);
  if (!v.ok) return v;
  if (/\.scene\.json$/i.test(name)) return { ok: false, error: 'Não inclua ".scene.json" no nome.' };
  const wanted = scenePathFor(folder, name).toLowerCase();
  const clash = Object.keys(project.files).some((p) => p.toLowerCase() === wanted && p !== ignorePath);
  return clash ? { ok: false, error: `Já existe uma cena chamada "${name}".` } : { ok: true };
}

function sceneFile(scene: SceneData, now: string): VirtualFile {
  const content = serializeSceneToJson(scene);
  return { path: scene.path, name: baseNameOf(scene.path), isDirectory: false, extension: 'json', content, size: content.length, updatedAt: now };
}

/**
 * AIS-32b (decisão 17): `settings.physics.gravity3D` é o PADRÃO de `Scene.gravity` para cenas NOVAS. Cenas já existentes
 * nunca são tocadas. Com o padrão do projeto igual ao padrão do editor e cena sem `environment`, nada é escrito
 * (o resultado fica idêntico ao de antes).
 */
export function applyProjectGravity(scene: SceneData, project: ProjectData): void {
  const g = project.settings?.physics?.gravity3D;
  if (!g) return;
  const base = DEFAULT_SCENE_ENVIRONMENT.gravity;
  const differs = g.x !== base.x || g.y !== base.y || g.z !== base.z;
  if (!scene.environment && !differs) return;
  scene.environment = { ...(scene.environment ?? DEFAULT_SCENE_ENVIRONMENT), gravity: { x: g.x, y: g.y, z: g.z } };
}

export type SceneKind = '3D' | 'Empty';

export interface SceneOpOptions {
  now?: () => string;
  /** Fábrica de `sceneId` novo (testes usam uma determinística). */
  newSceneId?: () => string;
}

const freshId = () => `scene_${Math.random().toString(36).slice(2, 9)}`;

export interface AddSceneResult {
  project: ProjectData;
  path: string;
  name: string;
  sceneId: string;
}

/** Add: nova cena com nome padrão único em `res://scenes/`; vira a última aberta (o editor a abre). */
export function addScene(project: ProjectData, kind: SceneKind, name?: string, options: SceneOpOptions = {}): AddSceneResult {
  const now = (options.now ?? (() => new Date().toISOString()))();
  const chosen = name && validateSceneName(project, name).ok ? name : uniqueSceneName(project, name || 'Scene');
  const scene: SceneData = kind === '3D' ? createDefault3DStarterScene() : createEmptyScene();
  applyProjectGravity(scene, project);
  scene.id = (options.newSceneId ?? freshId)();
  scene.name = chosen;
  scene.path = scenePathFor(SCENES_DIR, chosen);
  scene.createdAt = now;
  scene.updatedAt = now;
  const file = sceneFile(scene, now);
  return {
    project: { ...project, lastOpenedScene: scene.path, updatedAt: now, files: { ...project.files, [scene.path]: file } },
    path: scene.path,
    name: chosen,
    sceneId: scene.id,
  };
}

/**
 * Duplicar: cópia INDEPENDENTE — novo `sceneId`, nome único (`Nome_copy`), arquivo próprio (novo `resourceId`, que o
 * registry atribui). `sourceContent` permite copiar o estado em memória da cena aberta (com alterações não salvas).
 * A original não é tocada.
 */
export function duplicateScene(project: ProjectData, sourcePath: string, sourceContent?: string, options: SceneOpOptions = {}): AddSceneResult | { error: string } {
  const source = project.files[sourcePath];
  const text = sourceContent ?? source?.content;
  if (!source || typeof text !== 'string') return { error: 'A cena de origem não foi encontrada.' };
  const parsed = parseSceneJson(text, sourcePath);
  if (!parsed.ok || !parsed.scene) return { error: `A cena de origem não pôde ser lida: ${parsed.diagnostics.find((d) => d.severity === 'error')?.message ?? 'inválida'}` };
  const now = (options.now ?? (() => new Date().toISOString()))();
  const name = uniqueSceneName(project, `${sceneNameOf(sourcePath)}_copy`, parentFolderOf(sourcePath) ?? SCENES_DIR);
  const folder = parentFolderOf(sourcePath) ?? SCENES_DIR;
  const copy: SceneData = { ...parsed.scene, id: (options.newSceneId ?? freshId)(), name, path: scenePathFor(folder, name), createdAt: now, updatedAt: now };
  const file = sceneFile(copy, now);
  return {
    project: { ...project, updatedAt: now, files: { ...project.files, [copy.path]: file } },
    path: copy.path,
    name,
    sceneId: copy.id,
  };
}

export type RenameSceneResult = { ok: true; project: ProjectData; from: string; to: string } | { ok: false; error: string };

/**
 * Renomear: muda nome E caminho, preservando o `sceneId` e o `resourceId` do arquivo. Referências por caminho em outros
 * arquivos (ex.: `change_scene`) são reescritas; cena inicial e última aberta acompanham.
 */
export function renameScene(project: ProjectData, from: string, newName: string, options: SceneOpOptions = {}): RenameSceneResult {
  const file = project.files[from];
  if (!file || !isSceneFile(file)) return { ok: false, error: 'A cena não foi encontrada.' };
  const folder = parentFolderOf(from) ?? SCENES_DIR;
  const check = validateSceneName(project, newName, folder, from);
  if (!check.ok) return { ok: false, error: check.error ?? 'Nome inválido.' };
  const to = scenePathFor(folder, newName);
  if (to === from) return { ok: false, error: 'O nome não mudou.' };
  const now = (options.now ?? (() => new Date().toISOString()))();

  // o nome dentro do arquivo acompanha; o sceneId não muda (se o arquivo não tem, o derivado do caminho antigo é gravado)
  let content = file.content ?? '';
  const parsed = parseSceneJson(content, from);
  if (parsed.ok && parsed.scene) {
    const sceneId = sceneIdFromContent(content, from);
    content = serializeSceneToJson({ ...parsed.scene, id: sceneId === derivedSceneId(from) ? derivedSceneId(from) : sceneId, name: newName, path: to, updatedAt: now });
  }

  const files: Record<string, VirtualFile> = {};
  for (const [path, f] of Object.entries(project.files)) {
    if (path === from) continue;
    const text = typeof f.content === 'string' && !f.content.startsWith('data:') ? replaceUrisInText(f.content, [{ from, to }]) : null;
    files[path] = text?.changed ? { ...f, content: text.content, size: text.content.length, updatedAt: now } : f;
  }
  files[to] = { ...file, path: to, name: baseNameOf(to), content, size: content.length, updatedAt: now };

  const moves: [string, string][] = [[from, to]];
  const settings = project.settings?.general
    ? { ...project.settings, general: { ...project.settings.general, mainScene: remapPath(project.settings.general.mainScene, moves) } }
    : project.settings;
  return { ok: true, from, to, project: { ...project, files, settings, lastOpenedScene: remapPath(project.lastOpenedScene, moves), updatedAt: now } };
}

/** Definir como inicial: grava `mainScene` (o `project.json` marca `startSceneId`/`isStartScene` a partir dele). */
export function setInitialScene(project: ProjectData, path: string, options: SceneOpOptions = {}): { ok: true; project: ProjectData } | { ok: false; error: string } {
  const file = project.files[path];
  if (!file || !isSceneFile(file)) return { ok: false, error: 'A cena não foi encontrada.' };
  const now = (options.now ?? (() => new Date().toISOString()))();
  const settings = { ...project.settings, general: { ...project.settings.general, mainScene: path } };
  return { ok: true, project: { ...project, settings, updatedAt: now } };
}

export interface SceneDeletionPlan {
  path: string;
  /** Excluir é recusado (cena única ou não encontrada). */
  blocked?: string;
  /** É a cena inicial: o usuário precisa escolher outra antes de confirmar. */
  needsNewInitial: boolean;
  isActive: boolean;
  /** Cenas que podem ser a nova inicial / a próxima a abrir. */
  candidates: SceneInfo[];
}

/** Regras de exclusão de cena (única, inicial, aberta). Não grava nada. */
export function planSceneDeletion(project: ProjectData, path: string, activePath?: string | null): SceneDeletionPlan {
  const scenes = listScenes(project);
  const target = scenes.find((s) => s.path === path);
  const candidates = scenes.filter((s) => s.path !== path);
  if (!target) return { path, blocked: 'A cena não foi encontrada.', needsNewInitial: false, isActive: false, candidates };
  if (scenes.length <= 1) {
    return { path, blocked: 'Esta é a única cena do projeto: o projeto precisa de pelo menos uma cena. Crie outra antes de excluir esta.', needsNewInitial: false, isActive: path === activePath, candidates };
  }
  return { path, needsNewInitial: target.isInitial, isActive: path === activePath, candidates };
}
