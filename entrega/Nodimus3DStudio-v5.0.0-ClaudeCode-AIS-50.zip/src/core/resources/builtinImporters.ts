import { checkSyntax } from '../scripts/syntaxCheck';
import type { Importer, ImporterInput } from './AssetPipeline';
import type { ResourceDiagnostic } from './ResourceRegistry';
import { extensionOfPath } from './resourceKinds';
import { contentToBytes, resolveRelativeUri } from '../models/modelBytes';
import { loadModel } from '../models/modelLoader';
import { disposeObject3D } from '../models/modelCache';
import { isModelExt, type ModelExt } from '../models/types';
import { DEFAULT_MODEL_IMPORT_SETTINGS } from '../../schemas/v1/modelImportSettings.schema';

/**
 * AIS-28c — importadores nativos. Cada um valida a entrada e produz informação derivada (cacheável); os conteúdos
 * já chegam no formato de persistência do projeto (data URL para binários, texto para o resto).
 * O processamento pesado de modelos 3D (gizmo, texturas, rig) continua no AssetImportModal (AIS-33) e no
 * retargeting/merge de clipes (AIS-36/37); aqui o modelo ganha identidade, validação básica e reimport.
 */

const err = (code: string, message: string): ResourceDiagnostic => ({ code, severity: 'error', message });
const warn = (code: string, message: string): ResourceDiagnostic => ({ code, severity: 'warning', message });

function dataUrlInfo(content: string): { mime: string; bytes: number } | null {
  const m = /^data:([\w.+-]+\/[\w.+-]+);base64,([A-Za-z0-9+/=\s]*)$/.exec(content);
  if (!m) return null;
  const b64 = m[2].replace(/\s/g, '');
  const padding = b64.endsWith('==') ? 2 : b64.endsWith('=') ? 1 : 0;
  return { mime: m[1], bytes: Math.floor((b64.length * 3) / 4) - padding };
}

function binaryImporter(id: string, kind: 'texture' | 'audio' | 'video', mimePrefix: string, extensions: string[], defaults: Record<string, unknown>): Importer {
  return {
    id,
    version: 1,
    kinds: [kind],
    extensions,
    defaultSettings: defaults,
    validate: ({ content, uri }: ImporterInput) => {
      const info = dataUrlInfo(content);
      if (!info) return [err(`${kind}.invalid_data_url`, `${uri}: o conteúdo precisa ser um data URL base64 (${mimePrefix}…).`)];
      if (!info.mime.startsWith(mimePrefix)) return [err(`${kind}.wrong_mime`, `${uri}: tipo ${info.mime} não é ${mimePrefix}…`)];
      if (info.bytes === 0) return [err(`${kind}.empty`, `${uri}: arquivo vazio.`)];
      return [];
    },
    process: ({ content }: ImporterInput) => ({ content, derived: { ...dataUrlInfo(content) } }),
  };
}

export const textureImporter = binaryImporter('texture', 'texture', 'image/', ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'], { colorSpace: 'srgb', generateMipmaps: true });
export const audioImporter = binaryImporter('audio', 'audio', 'audio/', ['wav', 'ogg', 'mp3'], { streaming: false });
export const videoImporter = binaryImporter('video', 'video', 'video/', ['mp4', 'webm', 'mov', 'ogv'], { loop: false });

/**
 * Modelos 3D (AIS-33a): parse REAL pelo `loadModel` único (estatísticas, AABB, animações). O arquivo é preservado como veio
 * (decisão 27: sem conversão); `importSettings` = `ModelImportSettings`. Erro tipado (`ModelLoadError`) mantém o código
 * (`model.parse_failed`, `model.empty`, `model.missing_dependency`, `model.unsupported_extension`) e NADA é gravado.
 */
export const modelImporter: Importer = {
  id: 'model',
  version: 2,
  kinds: ['mesh'],
  extensions: ['gltf', 'glb', 'obj', 'fbx', 'dae'],
  defaultSettings: { ...DEFAULT_MODEL_IMPORT_SETTINGS },
  validate: ({ content, uri }) => {
    if (content.length === 0) return [err('model.empty', `${uri}: arquivo vazio.`)];
    return isModelExt(extensionOfPath(uri)) ? [] : [err('model.unsupported_extension', `${uri}: extensão não suportada.`)];
  },
  process: async ({ content, uri, readFile }) => {
    const ext = extensionOfPath(uri) as ModelExt;
    const model = await loadModel({
      bytes: contentToBytes(content),
      ext,
      name: uri.split('/').pop() ?? uri,
      allowAnimationOnly: true, // AIS-37: `Walk.fbx` sem malha é um arquivo de animação válido
      resolveSibling: (rel) => {
        const text = readFile?.(resolveRelativeUri(uri, rel));
        return text === undefined ? null : contentToBytes(text);
      },
    });
    const derived = { bytes: content.length, stats: model.stats, bounds: model.bounds, upAxisHint: model.upAxisHint, materials: model.materials.length };
    disposeObject3D(model.root); // o import só mede: a geometria não fica retida
    return { content, derived };
  },
};

/** Scripts de texto: erro de sintaxe é aviso (o arquivo continua importável e editável). */
export const scriptImporter: Importer = {
  id: 'script',
  version: 1,
  kinds: ['script'],
  extensions: ['js', 'ts', 'jsx', 'tsx', 'mjs', 'cjs'],
  validate: ({ content, uri }) => {
    const issues = checkSyntax(content, extensionOfPath(uri));
    return issues.length ? [warn('script.syntax', `${uri}: erro de sintaxe detectado (${issues.length}).`)] : [];
  },
  process: ({ content }) => ({ content, derived: { lines: content.split('\n').length } }),
};

/** Recursos JSON (material, sprite, cena, prefab, animação, vídeo e dados): precisam ser JSON válido. */
export const jsonImporter: Importer = {
  id: 'json',
  version: 1,
  kinds: ['material', 'sprite', 'scene', 'prefab', 'animation', 'video', 'data'],
  extensions: ['json'],
  validate: ({ content, uri }) => {
    try {
      JSON.parse(content);
      return [];
    } catch (error) {
      return [err('json.invalid', `${uri}: JSON inválido (${error instanceof Error ? error.message : 'erro'}).`)];
    }
  },
  process: ({ content }) => ({ content, derived: { bytes: content.length } }),
};

/** Texto livre (xml, txt, md, html, css…): sem validação estrutural. */
export const textImporter: Importer = {
  id: 'text',
  version: 1,
  kinds: ['data'],
  extensions: ['xml', 'txt', 'md', 'html', 'css', 'cfg', 'ini', 'svg', 'glsl', 'shader'],
  validate: () => [],
  process: ({ content }) => ({ content, derived: { bytes: content.length } }),
};

/** Dados binários de apoio (ex.: `.bin` de um `.gltf`, AIS-33): data URL base64, não vazio. Sem processamento. */
export const binaryDataImporter: Importer = {
  id: 'binary',
  version: 1,
  kinds: ['other'],
  extensions: ['bin'],
  validate: ({ content, uri }) => {
    const info = dataUrlInfo(content);
    if (!info) return [err('binary.invalid_data_url', `${uri}: o conteúdo precisa ser um data URL base64.`)];
    return info.bytes === 0 ? [err('binary.empty', `${uri}: arquivo vazio.`)] : [];
  },
  process: ({ content }) => ({ content, derived: { ...dataUrlInfo(content) } }),
};

export const BUILTIN_IMPORTERS: readonly Importer[] = [textureImporter, audioImporter, videoImporter, modelImporter, scriptImporter, jsonImporter, textImporter];

/** Apoio à importação de modelos (AIS-33): dependências binárias de um `.gltf`. Registrado pelo editor junto com os nativos. */
export const MODEL_SUPPORT_IMPORTERS: readonly Importer[] = [binaryDataImporter];
