import { globalAuthoringModel } from '../authoring';
import { ProjectStorage } from '../projectStorage';
import { AssetPipeline, type PipelineIO } from './AssetPipeline';
import { BUILTIN_IMPORTERS, MODEL_SUPPORT_IMPORTERS } from './builtinImporters';
import { ResourceRegistry } from './ResourceRegistry';
import { isKnownLogicContribution } from '../serialization/logicResolver';
import { setTerrainContextProvider } from '../terrainObject';

/**
 * AIS-28c — instâncias únicas do ResourceRegistry e do AssetPipeline do editor, ligadas ao AuthoringModel.
 *
 * - O índice é derivado de `project.files`: toda alteração do projeto (criar, renomear, mover, excluir, trocar de
 *   projeto) re-sincroniza o registry, que emite os eventos para os painéis.
 * - Arquivos sem `resourceId` recebem um (em lugar) e o projeto é salvo na hora, para a identidade sobreviver ao
 *   recarregar; `renameFile` preserva o objeto do arquivo e, com ele, o id.
 */

export const globalResourceRegistry = new ResourceRegistry();
// o catálogo de Visual Logic (`LogicRegistry`) diz quais Behaviors/Actions existem: o grafo liga a pasta ou preserva o ID desconhecido
globalResourceRegistry.setLogicResolver((kind, id) => isKnownLogicContribution(kind as never, id));

const io: PipelineIO = {
  files: () => globalAuthoringModel.getProject().files as ReturnType<PipelineIO['files']>,
  write: (uri, content, meta) => {
    const project = globalAuthoringModel.getProject();
    const previous = project.files[uri];
    const name = uri.split('/').pop() || 'file';
    const dot = name.lastIndexOf('.');
    const updated = {
      ...project,
      files: {
        ...project.files,
        [uri]: {
          ...previous,
          ...meta,
          path: uri,
          name,
          isDirectory: false,
          extension: dot > 0 ? name.slice(dot + 1) : '',
          content,
          size: content.length,
          updatedAt: new Date().toISOString(),
        },
      },
    };
    globalAuthoringModel.setProject(updated);
    ProjectStorage.saveProjectFiles(updated, [uri]);
  },
};

/** Caminho atual de uma `ResourceRef` (pela identidade; referência antiga cai no caminho). `undefined` = órfã. */
export function resourcePathOf(ref: { id: string; path?: string }): string | undefined {
  const result = globalResourceRegistry.resolve(ref as never);
  return result.status === 'resolved' ? result.entry.uri : undefined;
}

// AIS-50: o Play cria o terreno pela mesma fábrica do Viewport e precisa achar o heightmap/.height do projeto aberto
setTerrainContextProvider(() => ({ files: globalAuthoringModel.getProject().files, pathOf: resourcePathOf }));

export const globalAssetPipeline = new AssetPipeline(globalResourceRegistry, io);
for (const importer of [...BUILTIN_IMPORTERS, ...MODEL_SUPPORT_IMPORTERS]) globalAssetPipeline.registerImporter(importer);

function syncRegistry(): void {
  const project = globalAuthoringModel.getProject();
  const assigned = globalResourceRegistry.syncFromProject(project);
  if (assigned > 0) ProjectStorage.saveProject(project); // a identidade recém-criada precisa persistir
}

syncRegistry();
globalAuthoringModel.subscribe((event) => {
  if (event.type === 'project_loaded' || event.type === 'project_updated') syncRegistry();
});
