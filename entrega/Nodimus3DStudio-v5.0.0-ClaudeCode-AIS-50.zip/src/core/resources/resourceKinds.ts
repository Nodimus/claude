/**
 * AIS-28c — vocabulário de recursos: o TIPO semântico de um arquivo de `res://`. Funções puras.
 * O FileSystemPanel representa arquivos; quem sabe o que um arquivo É para o editor é o `ResourceRegistry`.
 */

export type ResourceKind =
  | 'mesh'
  | 'texture'
  | 'material'
  | 'audio'
  | 'video'
  | 'script'
  | 'animation'
  | 'scene'
  | 'prefab'
  | 'sprite'
  | 'data'
  | 'other';

export const RESOURCE_KINDS: readonly ResourceKind[] = ['mesh', 'texture', 'material', 'audio', 'video', 'script', 'animation', 'scene', 'prefab', 'sprite', 'data', 'other'];

const MESH_EXT = ['gltf', 'glb', 'obj', 'fbx', 'dae'];
const IMAGE_EXT = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'];
const AUDIO_EXT = ['wav', 'ogg', 'mp3'];
const VIDEO_EXT = ['mp4', 'webm', 'mov', 'ogv'];
const SCRIPT_EXT = ['js', 'ts', 'jsx', 'tsx', 'mjs', 'cjs'];
const DATA_EXT = ['json', 'xml', 'txt', 'md', 'html', 'css', 'cfg', 'ini', 'svg', 'glsl', 'shader'];

export function extensionOfPath(path: string): string {
  const name = path.split('/').pop() ?? '';
  const dot = name.lastIndexOf('.');
  return dot > 0 ? name.slice(dot + 1).toLowerCase() : '';
}

/** Tipo do recurso pelo caminho. Sufixos compostos (`.scene.json`…) vencem a extensão simples. */
export function kindOfPath(path: string): ResourceKind {
  const p = path.toLowerCase();
  if (p.endsWith('.scene.json')) return 'scene';
  if (p.endsWith('.prefab.json')) return 'prefab';
  if (p.endsWith('.sprite.json')) return 'sprite';
  if (p.endsWith('.video.json')) return 'video';
  if (p.endsWith('.mat.json') || p.endsWith('.material.json') || p.endsWith('_material.json')) return 'material';
  if (p.endsWith('.rig.json') || p.endsWith('_rig.json') || p.endsWith('.anim.json')) return 'animation';
  const ext = extensionOfPath(p);
  if (MESH_EXT.includes(ext)) return 'mesh';
  if (IMAGE_EXT.includes(ext)) return 'texture';
  if (AUDIO_EXT.includes(ext)) return 'audio';
  if (VIDEO_EXT.includes(ext)) return 'video';
  if (SCRIPT_EXT.includes(ext)) return 'script';
  if (DATA_EXT.includes(ext)) return 'data';
  return 'other';
}

/** Arquivos do sistema que não são recursos do jogo (gerados pelo editor). */
export const NON_RESOURCE_URIS: ReadonlySet<string> = new Set(['res://project.json']);

/** Procura referências `res://…` dentro de um recurso textual (material, sprite, cena, prefab). */
export function scanDependencyUris(content: string | undefined): string[] {
  if (!content || content.startsWith('data:')) return [];
  const found = new Set<string>();
  for (const m of content.matchAll(/res:\/\/[^"'\s\\)<>]+/g)) found.add(m[0].replace(/[,.;]+$/, ''));
  return [...found];
}
