/**
 * AIS-28c — identidade persistente de recursos. O `resourceId` mora no próprio `VirtualFile` (persiste com o projeto)
 * e acompanha o arquivo em renomear/mover: o objeto do arquivo é preservado, só o caminho muda.
 */

export interface ResourceMeta {
  resourceId?: string;
  importerId?: string;
  importerVersion?: number;
  importSettings?: Record<string, unknown>;
  contentHash?: string;
}

export const RESOURCE_META_KEYS = ['resourceId', 'importerId', 'importerVersion', 'importSettings', 'contentHash'] as const;

export function newResourceId(): string {
  const random = () => Math.random().toString(36).slice(2, 8);
  return `res_${random()}${random()}`;
}

type FileLike = { isDirectory: boolean } & ResourceMeta;

/** Dá `resourceId` aos arquivos que ainda não têm (EM LUGAR; idempotente). Devolve quantos receberam. */
export function ensureResourceIds(files: Record<string, FileLike>, factory: () => string = newResourceId): number {
  let assigned = 0;
  for (const file of Object.values(files)) {
    if (file.isDirectory || file.resourceId) continue;
    file.resourceId = factory();
    assigned++;
  }
  return assigned;
}

/**
 * Metadados de recurso do arquivo anterior que o novo conteúdo herda (sobrescrever um arquivo NÃO troca sua
 * identidade nem apaga as configurações de importação).
 */
export function carryResourceMeta<T extends object>(previous: ResourceMeta | undefined, next: T): T {
  if (!previous) return next;
  const out = { ...next } as Record<string, unknown>;
  for (const key of RESOURCE_META_KEYS) {
    if (previous[key] !== undefined && out[key] === undefined) out[key] = previous[key];
  }
  return out as T;
}
