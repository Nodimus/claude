import { describe, expect, it } from 'vitest';
import { DependencyGraph } from './DependencyGraph';
import { extractDependencies, logicNodeId, strengthForPath } from './dependencyExtractor';
import { ResourceRegistry } from './ResourceRegistry';
import { AssetPipeline, type PipelineIO } from './AssetPipeline';
import { BUILTIN_IMPORTERS } from './builtinImporters';
import { planPathChange } from '../fileSystem/fileOps';
import { isKnownLogicContribution } from '../serialization/logicResolver';

type F = Record<string, any>;
const file = (path: string, extra: F = {}) => ({ path, name: path.split('/').filter(Boolean).pop()!, isDirectory: path.endsWith('/'), updatedAt: '2026-10-02T00:00:00Z', ...extra });
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

function setup(files: F) {
  const project = { files: { ...files } as F };
  const registry = new ResourceRegistry();
  registry.setLogicResolver((kind, id) => isKnownLogicContribution(kind as any, id));
  registry.syncFromProject(project);
  const id = (uri: string) => registry.getByUri(uri)!.resourceId;
  return { project, registry, graph: registry.graph, id };
}

function rename(project: { files: F }, from: string, to: string) {
  const plan = planPathChange(project.files, from, to);
  if (!plan.ok) throw new Error(plan.error);
  const next: F = { ...project.files };
  for (const [a] of plan.moves) delete next[a];
  for (const [a, b] of plan.moves) next[b] = { ...project.files[a], path: b, name: b.split('/').filter(Boolean).pop() };
  project.files = next;
}

describe('grafo: operações básicas (AIS-29c-C01)', () => {
  const g = () => {
    const graph = new DependencyGraph();
    for (const [id, uri, kind] of [['scene', 'res://s.scene.json', 'scene'], ['mat', 'res://m.mat.json', 'material'], ['tex', 'res://t.png', 'texture'], ['tex2', 'res://t2.png', 'texture']]) graph.addResource({ id, uri, kind });
    graph.setDependencies('scene', [{ targetId: 'mat', strength: 'runtime', via: 'nodes.a.material' }]);
    graph.setDependencies('mat', [{ targetUri: 'res://t.png', strength: 'runtime', via: 'albedo' }, { targetId: 'tex2', strength: 'editor', via: 'preview' }]);
    return graph;
  };
  it('dependência direta e reversa por id estável, com tipos', () => {
    const graph = g();
    expect(graph.getDirect('scene').map((e) => e.to)).toEqual(['mat']);
    expect(graph.getDirect('mat').map((e) => `${e.to}:${e.type}`)).toEqual(['tex:runtime', 'tex2:editor']);
    expect(graph.getDirect('mat', { types: ['runtime'] }).map((e) => e.to)).toEqual(['tex']);
    expect(graph.getReverse('tex').map((e) => e.from)).toEqual(['mat']);
    expect(graph.getReverse('mat').map((e) => e.from)).toEqual(['scene']);
    expect(graph.getReverse('scene')).toEqual([]);
  });
  it('alcançáveis (Publish): runtime+optional por padrão; editor só se pedido', () => {
    const graph = g();
    expect(graph.getReachable('scene')).toEqual(['mat', 'tex']);
    expect(graph.getReachable('scene', { types: ['runtime', 'optional', 'editor'] }).sort()).toEqual(['mat', 'tex', 'tex2']);
  });
  it('invalidação incremental: quem é afetado quando um recurso muda', () => {
    const graph = g();
    expect(graph.invalidate('tex')).toEqual(['mat', 'scene']);
    expect(graph.invalidate('scene')).toEqual([]);
  });
  it('setDependencies substitui só as saídas daquele recurso e ignora auto-referência e duplicata', () => {
    const graph = g();
    graph.setDependencies('mat', [{ targetId: 'mat', strength: 'runtime', via: 'self' }, { targetId: 'tex', strength: 'runtime', via: 'a' }, { targetId: 'tex', strength: 'runtime', via: 'a' }]);
    expect(graph.getDirect('mat').map((e) => e.to)).toEqual(['tex']);
    expect(graph.getDirect('scene').map((e) => e.to)).toEqual(['mat']);
  });
  it('ciclos: detectados só quando consultados; wouldCreateCycle antecipa', () => {
    const graph = g();
    expect(graph.findCycles()).toEqual([]);
    expect(graph.wouldCreateCycle('tex', 'scene')).toBe(true);
    expect(graph.wouldCreateCycle('scene', 'tex')).toBe(false);
    graph.setDependencies('tex', [{ targetId: 'scene', strength: 'runtime', via: 'loop' }]);
    expect(graph.findCycles()).toEqual([['mat', 'scene', 'tex']]);
    expect(graph.findCycles({ types: ['editor'] })).toEqual([]);
    expect(graph.getReachable('scene')).toEqual(['mat', 'tex']); // não trava no ciclo
  });
});

describe('renomear/mover não quebra arestas (AIS-29c-C03)', () => {
  it('updateResource muda o URI e mantém identidade e arestas', () => {
    const graph = new DependencyGraph();
    graph.addResource({ id: 'a', uri: 'res://a.json', kind: 'data' });
    graph.addResource({ id: 'b', uri: 'res://b.png', kind: 'texture' });
    graph.setDependencies('a', [{ targetUri: 'res://b.png', strength: 'runtime', via: 'x' }]); // escrita por caminho
    graph.updateResource('b', { uri: 'res://novo/b.png' });
    expect(graph.getDirect('a')[0]).toMatchObject({ to: 'b', type: 'runtime' });
    expect(graph.getIdByUri('res://novo/b.png')).toBe('b');
    expect(graph.getIdByUri('res://b.png')).toBeUndefined();
    // a referência escrita como caminho ficou desatualizada: o 29e a reescreve
    expect(graph.getStaleReferences().map((e) => `${e.from}→${e.to}`)).toEqual(['a→b']);
  });
  it('no registry: mover o arquivo da textura mantém a aresta do material', () => {
    const { project, registry, graph, id } = setup({
      'res://m.mat.json': file('res://m.mat.json', { content: '{"albedo":{"id":"res:res://t.png","type":"texture","path":"res://t.png"}}' }),
      'res://t.png': file('res://t.png', { content: PNG }),
      'res://d/': file('res://d/'),
    });
    const mat = id('res://m.mat.json');
    const tex = id('res://t.png');
    expect(graph.getDirect(mat).map((e) => e.to)).toEqual([tex]);
    rename(project, 'res://t.png', 'res://d/t.png');
    registry.syncFromProject(project);
    expect(id('res://d/t.png')).toBe(tex);
    expect(graph.getDirect(mat).map((e) => `${e.to}:${e.type}`)).toEqual([`${tex}:runtime`]);
    expect(graph.getReverse(tex).map((e) => e.from)).toEqual([mat]);
  });
});

describe('referências faltando permanecem representadas e reparáveis (AIS-29c-C04)', () => {
  it('apagar o alvo NÃO apaga a referência: vira unresolved com a força original', () => {
    const { project, registry, graph, id } = setup({
      'res://m.mat.json': file('res://m.mat.json', { content: '{"albedo":"res://t.png","preview":"res://p.png"}' }),
      'res://t.png': file('res://t.png', { content: PNG }),
      'res://p.png': file('res://p.png', { content: PNG }),
    });
    const mat = id('res://m.mat.json');
    delete project.files['res://t.png'];
    registry.syncFromProject(project);
    const missing = graph.getMissing();
    expect(missing).toHaveLength(1);
    expect(missing[0]).toMatchObject({ from: mat, to: null, toUri: 'res://t.png', type: 'unresolved', intended: 'runtime' });
    expect(registry.get(mat)!.unresolvedDependencies).toEqual(['res://t.png']);
    expect(graph.getDirect(mat)).toHaveLength(2); // nada sumiu
  });
  it('o arquivo voltando ao mesmo caminho repara a aresta sozinho', () => {
    const { project, registry, graph, id } = setup({
      'res://m.mat.json': file('res://m.mat.json', { content: '{"albedo":"res://t.png"}' }),
    });
    expect(graph.getMissing()).toHaveLength(1);
    project.files['res://t.png'] = file('res://t.png', { content: PNG });
    registry.syncFromProject(project);
    expect(graph.getMissing()).toHaveLength(0);
    expect(graph.getDirect(id('res://m.mat.json'))[0]).toMatchObject({ to: id('res://t.png'), type: 'runtime' });
  });
  it('reparo explícito: o arquivo voltou com outro nome', () => {
    const { project, registry, graph, id } = setup({
      'res://m.mat.json': file('res://m.mat.json', { content: '{"albedo":"res://antigo.png"}' }),
      'res://novo.png': file('res://novo.png', { content: PNG }),
    });
    expect(graph.resolveMissing('res://antigo.png', id('res://novo.png'))).toBe(1);
    expect(graph.getMissing()).toHaveLength(0);
    expect(graph.getReachable(id('res://m.mat.json'))).toEqual([id('res://novo.png')]);
    expect(graph.resolveMissing('res://x.png', 'nao_existe')).toBe(0);
  });
  it('URL externa não conta como faltando', () => {
    const { graph, id } = setup({ 'res://v.video.json': file('res://v.video.json', { content: '{"url":"https://exemplo.com/v.mp4"}' }) });
    const edge = graph.getDirect(id('res://v.video.json'))[0];
    expect(edge).toMatchObject({ type: 'external', to: null });
    expect(graph.getMissing()).toEqual([]);
  });
});

describe('excluir/mover consulta as referências reversas (AIS-29c-C02)', () => {
  it('relatório de remoção: bloqueia quando há referência de fora; ignora referências internas ao conjunto', () => {
    const { graph, id } = setup({
      'res://s.scene.json': file('res://s.scene.json', { content: '{"material":"res://m.mat.json"}' }),
      'res://m.mat.json': file('res://m.mat.json', { content: '{"albedo":"res://t.png","preview":"res://p.png"}' }),
      'res://t.png': file('res://t.png', { content: PNG }),
      'res://p.png': file('res://p.png', { content: PNG }),
      'res://lixo.png': file('res://lixo.png', { content: PNG }),
    });
    const alone = graph.getRemovalReport([id('res://t.png')]);
    expect(alone.blockers.map((b) => b.uri)).toEqual(['res://t.png']);
    expect(alone.blockers[0].referrers[0]).toMatchObject({ from: id('res://m.mat.json'), via: 'albedo' });
    expect(graph.getRemovalReport([id('res://p.png')]).editorOnly.map((b) => b.uri)).toEqual(['res://p.png']);
    expect(graph.getRemovalReport([id('res://lixo.png')]).safe).toEqual([id('res://lixo.png')]);
    // apagar o material junto com a textura: a referência é interna ao conjunto, mas a CENA ainda aponta para o material
    const both = graph.getRemovalReport([id('res://m.mat.json'), id('res://t.png')]);
    expect(both.blockers.map((b) => b.uri)).toEqual(['res://m.mat.json']);
    expect(both.safe).toContain(id('res://t.png'));
  });
});

describe('extração de dependências (único lugar que conhece os formatos)', () => {
  it('ResourceRef por id, caminho, lógica e força por caminho do campo', () => {
    const content = JSON.stringify({
      nodes: {
        a: { id: 'a', name: 'A', type: 'MeshInstance', script: 'res://scripts/s.ts', properties: { materialOverride: { albedoTexture: { id: 'res_abc123', type: 'texture', path: 'res://t.png', label: 't.png' } } } },
        b: { id: 'b', visualLogic: { behaviors: [{ id: 'x', contributionId: 'simple_wasd_movement', source: 'builtin', properties: {} }] } },
      },
      editorPreview: 'res://p.png',
      optionalSound: 'res://s.wav',
    });
    const deps = extractDependencies('scene', 'res://s.scene.json', content);
    const by = (via: string) => deps.find((d) => d.via === via)!;
    expect(by('nodes.a.properties.materialOverride.albedoTexture')).toMatchObject({ targetId: 'res_abc123', targetUri: 'res://t.png', strength: 'runtime' });
    expect(by('nodes.a.script')).toMatchObject({ targetUri: 'res://scripts/s.ts' });
    expect(by('nodes.b.visualLogic.behaviors.0.contributionId')).toMatchObject({ targetId: logicNodeId('behavior', 'simple_wasd_movement') });
    expect(by('editorPreview').strength).toBe('editor');
    expect(by('optionalSound').strength).toBe('optional');
    expect(strengthForPath('a.preview.b', 'runtime')).toBe('editor');
  });
  it('referência antiga (res:<caminho>) e texto livre; data URL e JSON inválido não quebram', () => {
    const legacy = extractDependencies('material', 'res://m.mat.json', '{"t":{"id":"res:res://t.png","type":"texture","path":"res://t.png"}}');
    expect(legacy[0]).toMatchObject({ targetId: undefined, targetUri: 'res://t.png' });
    expect(extractDependencies('script', 'res://s.ts', "import x from 'res://lib/x.ts'; load('res://a.png')").map((d) => d.targetUri)).toEqual(['res://lib/x.ts', 'res://a.png']);
    expect(extractDependencies('texture', 'res://t.png', PNG)).toEqual([]);
    expect(extractDependencies('data', 'res://d.json', '{ quebrado res://x.png')[0]).toMatchObject({ targetUri: 'res://x.png' });
  });
});

describe('Behavior/Action serializado → pasta do catálogo (AIS-29c §3)', () => {
  const scene = JSON.stringify({ nodes: { h: { id: 'h', visualLogic: { behaviors: [{ id: 'b1', contributionId: 'simple_wasd_movement' }, { id: 'b2', contributionId: 'comportamento_removido' }], actions: [{ id: 'a1', contributionId: 'acao_inexistente' }] } } } });
  it('item conhecido vira nó externo do catálogo; desconhecido vira referência não resolvida preservada', () => {
    const { graph, id } = setup({ 'res://s.scene.json': file('res://s.scene.json', { content: scene }) });
    const edges = graph.getDirect(id('res://s.scene.json'));
    const known = edges.find((e) => e.toUri === logicNodeId('behavior', 'simple_wasd_movement'))!;
    expect(known).toMatchObject({ type: 'runtime' });
    expect(graph.getNode(known.to!)).toMatchObject({ external: true, kind: 'logic', uri: 'src/logic/behaviors/simple_wasd_movement/' });
    expect(graph.getMissing().map((e) => e.toUri).sort()).toEqual([logicNodeId('action', 'acao_inexistente'), logicNodeId('behavior', 'comportamento_removido')]);
  });
  it('quem usa um item do catálogo é consultável pelo id do item', () => {
    const { graph, id } = setup({ 'res://s.scene.json': file('res://s.scene.json', { content: scene }) });
    expect(graph.getReverse(logicNodeId('behavior', 'simple_wasd_movement')).map((e) => e.from)).toEqual([id('res://s.scene.json')]);
  });
});

describe('Prefab e Publish reutilizam o MESMO grafo (AIS-29c-C05)', () => {
  const project = () => ({
    'res://scenes/Main.scene.json': file('res://scenes/Main.scene.json', { content: '{"nodes":{"p":{"id":"p","prefab":"res://prefabs/Door.prefab.json","script":"res://scripts/main.ts"}}}' }),
    'res://prefabs/Door.prefab.json': file('res://prefabs/Door.prefab.json', { content: '{"mesh":"res://models/door.glb","material":{"id":"res:res://m.mat.json","type":"material","path":"res://m.mat.json"}}' }),
    'res://m.mat.json': file('res://m.mat.json', { content: '{"albedo":"res://t.png"}' }),
    'res://t.png': file('res://t.png', { content: PNG }),
    'res://models/door.glb': file('res://models/door.glb', { content: 'glb' }),
    'res://scripts/main.ts': file('res://scripts/main.ts', { content: 'export {}' }),
    'res://unused.png': file('res://unused.png', { content: PNG }),
  });
  it('Publish: getReachable(cena principal) = o que embarca, sem revarrer formatos', () => {
    const { graph, id } = setup(project());
    const uris = graph.getReachable(id('res://scenes/Main.scene.json')).map((rid) => graph.getNode(rid)!.uri).sort();
    expect(uris).toEqual(['res://m.mat.json', 'res://models/door.glb', 'res://prefabs/Door.prefab.json', 'res://scripts/main.ts', 'res://t.png']);
    expect(uris).not.toContain('res://unused.png');
  });
  it('Prefab: o subgrafo do prefab é o mesmo cálculo a partir dele', () => {
    const { graph, id } = setup(project());
    const sub = graph.subgraph(id('res://prefabs/Door.prefab.json'));
    expect(sub.nodes.map((n) => n.uri).sort()).toEqual(['res://m.mat.json', 'res://models/door.glb', 'res://prefabs/Door.prefab.json', 'res://t.png']);
    expect(sub.edges.every((e) => sub.nodes.some((n) => n.id === e.from))).toBe(true);
  });
  it('Cena → Prefab → Cena é detectado como ciclo proibido', () => {
    const files = project();
    files['res://prefabs/Door.prefab.json'] = file('res://prefabs/Door.prefab.json', { content: '{"scene":"res://scenes/Main.scene.json"}' });
    const { graph, id } = setup(files);
    const cycles = graph.findCycles();
    expect(cycles).toHaveLength(1);
    expect(cycles[0].sort()).toEqual([id('res://prefabs/Door.prefab.json'), id('res://scenes/Main.scene.json')].sort());
  });
});

describe('AssetPipeline atualiza as arestas após import/reimport (AIS-29c §4)', () => {
  it('importar o alvo que faltava repara a referência e o resultado lista os dependentes a revalidar', async () => {
    const project = { files: { 'res://m.mat.json': file('res://m.mat.json', { content: '{"albedo":"res://t.png"}' }) } as F };
    const io: PipelineIO = {
      files: () => project.files,
      write: (uri, content, meta) => {
        project.files[uri] = { ...(project.files[uri] ?? file(uri)), path: uri, name: uri.split('/').pop(), isDirectory: false, content, size: content.length, ...meta, updatedAt: String(Date.now()) };
      },
    };
    const registry = new ResourceRegistry();
    registry.syncFromProject(project);
    expect(registry.graph.getMissing()).toHaveLength(1);
    const pipeline = new AssetPipeline(registry, io);
    for (const importer of BUILTIN_IMPORTERS) pipeline.registerImporter(importer);
    const result = await pipeline.import({ uri: 'res://t.png', content: PNG });
    expect(result.ok).toBe(true);
    expect(registry.graph.getMissing()).toHaveLength(0);
    if (result.ok) expect(result.dependents).toEqual([registry.getByUri('res://m.mat.json')!.resourceId]);
  });
});
