import { hashContent } from '../documents/documentKinds';
import { newResourceId } from './ids';
import { ResourceCache, cacheKey } from './ResourceCache';
import type { ResourceDiagnostic, ResourceEntry, ResourceRegistry } from './ResourceRegistry';
import { extensionOfPath, type ResourceKind } from './resourceKinds';

/**
 * AIS-28c — AssetPipeline. Fluxo obrigatório:
 *   source → importer → validate → process → persist resource → register → dependency scan → cache → notify
 *
 * - Importadores são registrados por ID, com extensões e tipos suportados.
 * - Reimport reutiliza as `importSettings` persistidas e PRESERVA o `resourceId`.
 * - Falha de importação nunca destrói a última versão válida: o arquivo fica como estava e o recurso é marcado
 *   `importFailed` com diagnóstico.
 * - Retargeting humanoide e merge de clipes (AIS-36/37) usam este pipeline para identidade e reimport; a lógica
 *   deles não mora aqui.
 */

export interface ImporterInput {
  /** URI de destino (`res://…`). */
  uri: string;
  /** Conteúdo da fonte (texto, JSON ou data URL). */
  content: string;
  settings: Record<string, unknown>;
  /** Conteúdo de OUTRO arquivo do projeto (dependências de um recurso, ex.: `.bin` de um `.gltf`). */
  readFile?: (uri: string) => string | undefined;
}

export interface ImporterOutput {
  /** Conteúdo a persistir (pode ser o mesmo da entrada). */
  content: string;
  /** Informação derivada, guardada no cache (ex.: tipo MIME e tamanho). */
  derived?: Record<string, unknown>;
}

export interface Importer {
  id: string;
  /** Muda quando o processamento muda: invalida o cache. */
  version: number;
  kinds: ResourceKind[];
  extensions: string[];
  defaultSettings?: Record<string, unknown>;
  validate(input: ImporterInput): ResourceDiagnostic[];
  process(input: ImporterInput): ImporterOutput | Promise<ImporterOutput>;
}

type FileWithMeta = {
  path: string;
  name: string;
  isDirectory: boolean;
  content?: string;
  size?: number;
  updatedAt?: string;
  resourceId?: string;
  importerId?: string;
  importerVersion?: number;
  importSettings?: Record<string, unknown>;
  contentHash?: string;
};

/** Porta de persistência (hoje o EditorContext/ProjectStorage; nos testes, um mapa). */
export interface PipelineIO {
  files(): Record<string, FileWithMeta>;
  write(uri: string, content: string, meta: { resourceId: string; importerId: string; importerVersion: number; importSettings: Record<string, unknown>; contentHash?: string }): void;
}

export type ImportResult =
  | { ok: true; resourceId: string; uri: string; created: boolean; cached: boolean; diagnostics: ResourceDiagnostic[]; derived?: Record<string, unknown>; /** Recursos que dependem deste (do DependencyGraph): revalidar depois do import. */ dependents: string[] }
  | { ok: false; resourceId?: string; uri: string; diagnostics: ResourceDiagnostic[] };

export interface ImportRequest {
  uri: string;
  content: string;
  /** Sobrepõe as settings salvas (mescladas por cima das persistidas). */
  settings?: Record<string, unknown>;
  sourceUri?: string;
}

export type DiagnosticSink = (diagnostic: ResourceDiagnostic) => void;

export class AssetPipeline {
  private importers = new Map<string, Importer>();
  private sink: DiagnosticSink | null = null;

  constructor(
    private readonly registry: ResourceRegistry,
    private readonly io: PipelineIO,
    public readonly cache: ResourceCache<ImporterOutput> = new ResourceCache<ImporterOutput>()
  ) {}

  /** Sink de diagnóstico: `wireDiagnosticPublishers` (AIS-32c) o liga ao `DiagnosticService` único; o console é consumidor dele. */
  public setDiagnosticSink(sink: DiagnosticSink | null): void {
    this.sink = sink;
  }

  public registerImporter(importer: Importer): () => void {
    this.importers.set(importer.id, importer);
    return () => {
      this.importers.delete(importer.id);
    };
  }

  public importerFor(uri: string): Importer | undefined {
    const ext = extensionOfPath(uri);
    for (const importer of this.importers.values()) if (importer.extensions.includes(ext)) return importer;
    return undefined;
  }

  public listImporters(): Importer[] {
    return [...this.importers.values()];
  }

  private report(diagnostics: ResourceDiagnostic[]): void {
    if (!this.sink) return;
    for (const d of diagnostics) this.sink(d);
  }

  /** Importa (cria ou substitui) o recurso em `uri`. Mesmo `uri` já registrado = reimport: mantém o `resourceId`. */
  public async import(request: ImportRequest): Promise<ImportResult> {
    const { uri } = request;
    const importer = this.importerFor(uri);
    if (!importer) {
      const d: ResourceDiagnostic = { code: 'import.no_importer', severity: 'error', message: `Nenhum importador registrado para ${uri}.`, uri };
      this.report([d]);
      return { ok: false, uri, diagnostics: [d] };
    }

    const existing = this.registry.getByUri(uri);
    const settings = { ...(importer.defaultSettings ?? {}), ...(existing?.importSettings ?? {}), ...(request.settings ?? {}) };
    const input: ImporterInput = { uri, content: request.content, settings, readFile: (u) => this.io.files()[u]?.content };

    // validate — falha: a última versão válida NÃO é tocada
    const diagnostics = importer.validate(input).map((d) => ({ ...d, uri, resourceId: existing?.resourceId }));
    const errors = diagnostics.filter((d) => d.severity === 'error');
    if (errors.length > 0) {
      if (existing) this.registry.setImportFailure(existing.resourceId, errors[0]);
      this.report(diagnostics);
      return { ok: false, resourceId: existing?.resourceId, uri, diagnostics };
    }

    // process (com cache derivado: chave = conteúdo + settings + versão do importer + versão do engine)
    const key = cacheKey({ contentHash: hashContent(request.content) ?? undefined, importSettings: settings, importerId: importer.id, importerVersion: importer.version });
    let output = this.cache.get(key);
    const cached = output !== undefined;
    if (!output) {
      try {
        output = await importer.process(input);
      } catch (error) {
        // erro tipado do importador (ex.: `ModelLoadError`, AIS-33a) mantém o próprio código; os demais viram `import.process_failed`
        const typed = typeof (error as { code?: unknown } | null)?.code === 'string' && /^[a-z]+.[a-z_]+$/.test((error as { code: string }).code) ? (error as { code: string }).code : null;
        const d: ResourceDiagnostic = typed
          ? { code: typed, severity: 'error', message: error instanceof Error ? error.message : String(error), uri, resourceId: existing?.resourceId }
          : { code: 'import.process_failed', severity: 'error', message: `Falha ao processar ${uri}: ${error instanceof Error ? error.message : String(error)}`, uri, resourceId: existing?.resourceId };
        if (existing) this.registry.setImportFailure(existing.resourceId, d);
        this.report([...diagnostics, d]);
        return { ok: false, resourceId: existing?.resourceId, uri, diagnostics: [...diagnostics, d] };
      }
      this.cache.set(key, output);
    }

    // persist + register (o arquivo carrega o resourceId e as settings)
    const resourceId = existing?.resourceId ?? newResourceId();
    this.io.write(uri, output.content, {
      resourceId,
      importerId: importer.id,
      importerVersion: importer.version,
      importSettings: settings,
      contentHash: hashContent(output.content) ?? undefined,
    });
    this.registry.syncFromProject({ files: this.io.files() });
    this.registry.setImportFailure(resourceId, null);
    this.report(diagnostics);
    // dependency scan: o registry já atualizou o DependencyGraph; quem depende deste recurso precisa revalidar
    const dependents = this.registry.graph.invalidate(resourceId);
    return { ok: true, resourceId, uri, created: !existing, cached, diagnostics, derived: output.derived, dependents };
  }

  /**
   * Reimporta um recurso existente reutilizando as configurações persistidas e preservando o `resourceId`.
   * `content` ausente = reprocessa o conteúdo atual do arquivo.
   */
  public async reimport(resourceId: string, options: { content?: string; settings?: Record<string, unknown> } = {}): Promise<ImportResult> {
    const entry: ResourceEntry | undefined = this.registry.get(resourceId);
    if (!entry) {
      const d: ResourceDiagnostic = { code: 'import.unknown_resource', severity: 'error', message: `Recurso ${resourceId} não está registrado.`, resourceId };
      this.report([d]);
      return { ok: false, uri: '', diagnostics: [d] };
    }
    const content = options.content ?? this.io.files()[entry.uri]?.content;
    if (content === undefined) {
      const d: ResourceDiagnostic = { code: 'import.source_missing', severity: 'error', message: `O arquivo de ${entry.uri} não tem conteúdo para reimportar.`, uri: entry.uri, resourceId };
      this.registry.setImportFailure(resourceId, d);
      this.report([d]);
      return { ok: false, resourceId, uri: entry.uri, diagnostics: [d] };
    }
    return this.import({ uri: entry.uri, content, settings: options.settings });
  }

  /** Limpa o cache derivado (nada autoral é perdido). */
  public clearCache(): void {
    this.cache.clear();
  }
}
