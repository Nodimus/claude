/**
 * AIS-29c — DependencyGraph canônico: UMA representação das dependências entre recursos, reutilizada por edição,
 * Prefabs e Publish (nenhum deles revarre formatos por conta própria).
 *
 * - Nós são identificados pelo `resourceId` estável (ou por um id sintético `logic:<tipo>/<id>` para itens do catálogo
 *   de Visual Logic, que moram em pastas de `src/logic/`). Mudança de URI NÃO muda a identidade: as arestas ligam ids.
 * - Arestas tipadas: `runtime` (dependência forte), `optional`, `editor` (só no editor), `external` (referência a algo
 *   fora do projeto, ex.: URL) e `unresolved` (o alvo não existe: a referência é PRESERVADA, nunca apagada em silêncio,
 *   e pode ser reparada).
 * - Incremental: `addResource/updateResource/removeResource/setDependencies` mexem só no que mudou.
 * Sem React/Three; quem consome lê pelas consultas.
 */

export type DependencyEdgeType = 'runtime' | 'optional' | 'editor' | 'external' | 'unresolved';
/** Força que a aresta tinha (ou terá, depois de reparada) — preservada quando o alvo some. */
export type DependencyStrength = 'runtime' | 'optional' | 'editor';

export interface DependencyNode {
  id: string;
  uri: string;
  kind: string;
  /** Item fora de `project.files` (ex.: pasta de Visual Logic): existe no editor, não no projeto. */
  external?: boolean;
}

export interface DependencyEdge {
  from: string;
  /** `null` = alvo não resolvido (ou externo). */
  to: string | null;
  /** Como o alvo é citado (URI `res://…`, `logic:…`, URL). Presente também nas arestas resolvidas por caminho. */
  toUri: string;
  type: DependencyEdgeType;
  intended: DependencyStrength;
  /** Onde, no documento de origem, a referência aparece (caminho JSON). */
  via: string;
  /** `true` se a referência foi escrita como CAMINHO (e não por id): fica desatualizada quando o alvo é movido. */
  byPath: boolean;
}

export interface DependencyInput {
  /** Id do recurso alvo, se a referência o traz (ex.: `ResourceRef`). */
  targetId?: string;
  /** URI citado (`res://…`, `logic:…`, `https://…`). */
  targetUri?: string;
  strength: DependencyStrength;
  via: string;
}

export interface RemovalBlocker {
  id: string;
  uri: string;
  kind: string;
  /** Quem referencia este recurso (de fora do conjunto que está sendo removido). */
  referrers: DependencyEdge[];
}

export interface RemovalReport {
  /** Recursos com referência forte/opcional de fora: a remoção exige decisão explícita. */
  blockers: RemovalBlocker[];
  /** Referenciados só pelo editor (não bloqueiam). */
  editorOnly: RemovalBlocker[];
  /** Sem referência: podem ser removidos sem aviso. */
  safe: string[];
}

const edgeKey = (e: Pick<DependencyEdge, 'from' | 'to' | 'toUri' | 'via'>) => `${e.from}→${e.to ?? e.toUri}#${e.via}`;

export class DependencyGraph {
  private nodes = new Map<string, DependencyNode>();
  private byUri = new Map<string, string>();
  private out = new Map<string, DependencyEdge[]>();
  /** Muda a cada alteração (para caches e `useSyncExternalStore`). */
  public version = 0;

  private reverseCache: { version: number; map: Map<string, DependencyEdge[]> } | null = null;

  // ── Recursos ─────────────────────────────────────────────────────────────

  public hasResource(id: string): boolean {
    return this.nodes.has(id);
  }

  public getNode(id: string): DependencyNode | undefined {
    return this.nodes.get(id);
  }

  public getIdByUri(uri: string): string | undefined {
    return this.byUri.get(uri);
  }

  public listNodes(): DependencyNode[] {
    return [...this.nodes.values()];
  }

  /** Registra um recurso. Arestas não resolvidas que citavam este URI passam a apontar para ele (reparo automático). */
  public addResource(node: DependencyNode): void {
    this.nodes.set(node.id, { ...node });
    this.byUri.set(node.uri, node.id);
    if (!this.out.has(node.id)) this.out.set(node.id, []);
    this.bindPending(node.uri, node.id);
    this.version++;
  }

  /** Atualiza URI/tipo mantendo a identidade e todas as arestas (renomear/mover não quebra nada). */
  public updateResource(id: string, patch: Partial<Pick<DependencyNode, 'uri' | 'kind'>>): void {
    const node = this.nodes.get(id);
    if (!node) return;
    if (patch.uri !== undefined && patch.uri !== node.uri) {
      if (this.byUri.get(node.uri) === id) this.byUri.delete(node.uri);
      node.uri = patch.uri;
      this.byUri.set(patch.uri, id);
      this.bindPending(patch.uri, id);
    }
    if (patch.kind !== undefined) node.kind = patch.kind;
    this.version++;
  }

  /**
   * Remove o recurso. As referências que APONTAVAM para ele não são apagadas: viram `unresolved` (guardando o URI e a
   * força original), prontas para reparo ou migração.
   */
  public removeResource(id: string): void {
    const node = this.nodes.get(id);
    if (!node) return;
    this.nodes.delete(id);
    if (this.byUri.get(node.uri) === id) this.byUri.delete(node.uri);
    this.out.delete(id);
    for (const [from, edges] of this.out) {
      this.out.set(
        from,
        edges.map((e) => (e.to === id ? { ...e, to: null, type: 'unresolved' as const, toUri: e.toUri || node.uri } : e))
      );
    }
    this.version++;
  }

  private bindPending(uri: string, id: string): void {
    for (const [from, edges] of this.out) {
      if (!edges.some((e) => e.to === null && e.type === 'unresolved' && e.toUri === uri)) continue;
      this.out.set(
        from,
        edges.map((e) => (e.to === null && e.type === 'unresolved' && e.toUri === uri ? { ...e, to: id, type: e.intended } : e))
      );
    }
  }

  // ── Arestas ──────────────────────────────────────────────────────────────

  /** Substitui TODAS as dependências de saída de `from` (uma extração = uma chamada). Referências não resolvidas ficam. */
  public setDependencies(from: string, inputs: readonly DependencyInput[]): void {
    if (!this.nodes.has(from)) return;
    const seen = new Set<string>();
    const edges: DependencyEdge[] = [];
    for (const input of inputs) {
      const isExternal = !!input.targetUri && /^[a-z][a-z0-9+.-]*:\/\//i.test(input.targetUri) && !input.targetUri.startsWith('res://');
      let to: string | null = null;
      if (!isExternal) {
        if (input.targetId && this.nodes.has(input.targetId)) to = input.targetId;
        else if (input.targetUri && this.byUri.has(input.targetUri)) to = this.byUri.get(input.targetUri)!;
      }
      if (to === from) continue;
      const toUri = input.targetUri ?? (to ? this.nodes.get(to)!.uri : input.targetId ?? '');
      const edge: DependencyEdge = {
        from,
        to,
        toUri,
        type: isExternal ? 'external' : to ? input.strength : 'unresolved',
        intended: input.strength,
        via: input.via,
        byPath: !input.targetId && !!input.targetUri,
      };
      const key = edgeKey(edge);
      if (seen.has(key)) continue;
      seen.add(key);
      edges.push(edge);
    }
    this.out.set(from, edges);
    this.version++;
  }

  private reverse(): Map<string, DependencyEdge[]> {
    if (this.reverseCache?.version === this.version) return this.reverseCache.map;
    const map = new Map<string, DependencyEdge[]>();
    for (const edges of this.out.values()) {
      for (const e of edges) {
        if (!e.to) continue;
        const list = map.get(e.to);
        if (list) list.push(e);
        else map.set(e.to, [e]);
      }
    }
    this.reverseCache = { version: this.version, map };
    return map;
  }

  /** Dependências diretas (saída) de `id`. */
  public getDirect(id: string, options: { types?: readonly DependencyEdgeType[] } = {}): DependencyEdge[] {
    const edges = this.out.get(id) ?? [];
    return options.types ? edges.filter((e) => options.types!.includes(e.type)) : [...edges];
  }

  /** Quem depende diretamente de `id` (entrada). */
  public getReverse(id: string, options: { types?: readonly DependencyEdgeType[] } = {}): DependencyEdge[] {
    const edges = this.reverse().get(id) ?? [];
    return options.types ? edges.filter((e) => options.types!.includes(e.type)) : [...edges];
  }

  /**
   * Tudo o que `rootId` alcança (transitivo), sem incluí-lo. Padrão: dependências `runtime` e `optional` — é o que o
   * Publish embarca (`getReachable(mainScene)`); o subgrafo de um Prefab é o mesmo cálculo a partir dele.
   */
  public getReachable(rootId: string, options: { types?: readonly DependencyEdgeType[] } = {}): string[] {
    const types = options.types ?? (['runtime', 'optional'] as const);
    const seen = new Set<string>([rootId]);
    const order: string[] = [];
    const queue = [rootId];
    while (queue.length) {
      const current = queue.shift()!;
      for (const e of this.out.get(current) ?? []) {
        if (!e.to || !types.includes(e.type) || seen.has(e.to)) continue;
        seen.add(e.to);
        order.push(e.to);
        queue.push(e.to);
      }
    }
    return order;
  }

  /** Quem é afetado se `id` mudar (dependentes transitivos, todos os tipos): a invalidação incremental. */
  public invalidate(id: string): string[] {
    const seen = new Set<string>([id]);
    const order: string[] = [];
    const queue = [id];
    while (queue.length) {
      const current = queue.shift()!;
      for (const e of this.reverse().get(current) ?? []) {
        if (seen.has(e.from)) continue;
        seen.add(e.from);
        order.push(e.from);
        queue.push(e.from);
      }
    }
    return order;
  }

  /** Subgrafo fechado por alcançabilidade (raiz + tudo o que ela alcança + as arestas entre eles). */
  public subgraph(rootId: string, options: { types?: readonly DependencyEdgeType[] } = {}): { nodes: DependencyNode[]; edges: DependencyEdge[] } {
    const ids = new Set<string>([rootId, ...this.getReachable(rootId, options)]);
    const types = options.types ?? (['runtime', 'optional'] as const);
    const edges: DependencyEdge[] = [];
    for (const id of ids) for (const e of this.out.get(id) ?? []) if (types.includes(e.type) || e.type === 'unresolved') edges.push(e);
    return { nodes: [...ids].map((id) => this.nodes.get(id)).filter((n): n is DependencyNode => !!n), edges };
  }

  // ── Integridade ──────────────────────────────────────────────────────────

  /**
   * Ciclos (componentes fortemente conexos com mais de um nó, ou auto-referência) usando só os tipos pedidos.
   * Quem PROÍBE ciclos (ex.: Cena → Prefab → Cena) chama isto e trata o resultado; o grafo em si os aceita.
   */
  public findCycles(options: { types?: readonly DependencyEdgeType[] } = {}): string[][] {
    const types = options.types ?? (['runtime'] as const);
    const index = new Map<string, number>();
    const low = new Map<string, number>();
    const onStack = new Set<string>();
    const stack: string[] = [];
    const cycles: string[][] = [];
    let counter = 0;
    const strong = (v: string) => {
      index.set(v, counter);
      low.set(v, counter);
      counter++;
      stack.push(v);
      onStack.add(v);
      for (const e of this.out.get(v) ?? []) {
        if (!e.to || !types.includes(e.type)) continue;
        const w = e.to;
        if (!index.has(w)) {
          strong(w);
          low.set(v, Math.min(low.get(v)!, low.get(w)!));
        } else if (onStack.has(w)) low.set(v, Math.min(low.get(v)!, index.get(w)!));
      }
      if (low.get(v) === index.get(v)) {
        const component: string[] = [];
        let w: string;
        do {
          w = stack.pop()!;
          onStack.delete(w);
          component.push(w);
        } while (w !== v);
        if (component.length > 1) cycles.push(component.sort());
      }
    };
    for (const id of this.nodes.keys()) if (!index.has(id)) strong(id);
    return cycles.sort((a, b) => a[0].localeCompare(b[0]));
  }

  /** Adicionar a dependência `from → to` fecharia um ciclo (com os tipos dados)? */
  public wouldCreateCycle(from: string, to: string, options: { types?: readonly DependencyEdgeType[] } = {}): boolean {
    if (from === to) return true;
    return this.getReachable(to, { types: options.types ?? ['runtime'] }).includes(from);
  }

  /** Referências cujo alvo não existe (preservadas e reparáveis). Externas (URL) não contam como faltando. */
  public getMissing(): DependencyEdge[] {
    const missing: DependencyEdge[] = [];
    for (const edges of this.out.values()) for (const e of edges) if (e.type === 'unresolved') missing.push(e);
    return missing;
  }

  /**
   * Reparo explícito: liga as referências não resolvidas a `toUri` ao recurso `targetId` (ex.: o arquivo voltou com
   * outro nome). O texto do documento de origem não é reescrito aqui (isso é do serviço de mover/excluir, AIS-29e).
   */
  public resolveMissing(toUri: string, targetId: string): number {
    if (!this.nodes.has(targetId)) return 0;
    let count = 0;
    for (const [from, edges] of this.out) {
      this.out.set(
        from,
        edges.map((e) => {
          if (e.type === 'unresolved' && e.toUri === toUri && from !== targetId) {
            count++;
            return { ...e, to: targetId, type: e.intended };
          }
          return e;
        })
      );
    }
    if (count) this.version++;
    return count;
  }

  /**
   * Antes de excluir/mover/substituir: quem referencia estes recursos (de fora do conjunto). `blockers` pedem decisão
   * explícita; `editorOnly` não bloqueiam; `safe` não têm referência.
   */
  public getRemovalReport(ids: readonly string[]): RemovalReport {
    const set = new Set(ids);
    const blockers: RemovalBlocker[] = [];
    const editorOnly: RemovalBlocker[] = [];
    const safe: string[] = [];
    for (const id of ids) {
      const node = this.nodes.get(id);
      if (!node) continue;
      const external = this.getReverse(id).filter((e) => !set.has(e.from));
      const strong = external.filter((e) => e.type === 'runtime' || e.type === 'optional');
      const editor = external.filter((e) => e.type === 'editor');
      if (strong.length) blockers.push({ id, uri: node.uri, kind: node.kind, referrers: strong });
      else if (editor.length) editorOnly.push({ id, uri: node.uri, kind: node.kind, referrers: editor });
      else safe.push(id);
    }
    return { blockers, editorOnly, safe };
  }

  /**
   * Referências escritas como CAMINHO cujo alvo já mudou de URI (foram resolvidas pela identidade, mas o texto do
   * documento ainda traz o caminho antigo): o AIS-29e as reescreve ao mover.
   */
  public getStaleReferences(): DependencyEdge[] {
    const stale: DependencyEdge[] = [];
    for (const edges of this.out.values()) {
      for (const e of edges) {
        if (!e.to || !e.byPath) continue;
        const target = this.nodes.get(e.to);
        if (target && target.uri !== e.toUri) stale.push(e);
      }
    }
    return stale;
  }

  /** Esvazia o grafo (troca de projeto). */
  public clear(): void {
    this.nodes.clear();
    this.byUri.clear();
    this.out.clear();
    this.version++;
  }
}
