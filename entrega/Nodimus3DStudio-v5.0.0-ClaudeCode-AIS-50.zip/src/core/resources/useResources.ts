import { useMemo, useSyncExternalStore } from 'react';
import { globalResourceRegistry } from './global';
import type { ResourceEntry } from './ResourceRegistry';
import type { ResourceKind } from './resourceKinds';

/** Assina o registry e reflete a versão do índice (re-renderiza quando algo muda). */
export function useResourceRegistryVersion(): number {
  return useSyncExternalStore(
    (cb) => globalResourceRegistry.subscribe(cb),
    () => globalResourceRegistry.version
  );
}

/** Recursos de um tipo, direto do ResourceRegistry (pickers não consultam o FileSystemPanel). */
export function useResources(kind?: ResourceKind): ResourceEntry[] {
  const version = useResourceRegistryVersion();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  return useMemo(() => globalResourceRegistry.list(kind), [kind, version]);
}
