import type { DependencyInput, DependencyStrength } from './DependencyGraph';
import type { ResourceKind } from './resourceKinds';
import { isExternalGltfUri, resolveRelativeUri } from '../models/modelBytes';

/**
 * AIS-29c — extração de dependências de UM recurso (função pura). É o ÚNICO lugar que conhece os formatos de arquivo
 * (cena, prefab, material, sprite, animação…): o grafo, o Prefab e o Publish consomem o resultado, nunca revarrem
 * os formatos por conta própria.
 */

type AnyRecord = Record<string, any>;
const isRecord = (v: unknown): v is AnyRecord => typeof v === 'object' && v !== null && !Array.isArray(v);

export const LOGIC_NODE_PREFIX = 'logic:';

/** Id sintético de um item do catálogo de Visual Logic (pasta em `src/logic/<tipo>s/<id>/`). */
export const logicNodeId = (kind: string, contributionId: string): string => `${LOGIC_NODE_PREFIX}${kind}/${contributionId}`;
export const logicFolderUri = (kind: string, contributionId: string): string => `src/logic/${kind}s/${contributionId}/`;

const KIND_BY_CONTAINER: Record<string, string> = { behaviors: 'behavior', actions: 'action', conditions: 'condition', triggers: 'trigger', events: 'trigger' };

function logicKindOf(item: AnyRecord, container: string | undefined): string {
  if (container && KIND_BY_CONTAINER[container]) return KIND_BY_CONTAINER[container];
  if (typeof item.kind === 'string' && ['behavior', 'action', 'condition', 'trigger'].includes(item.kind)) return item.kind;
  return 'parameters' in item && !('properties' in item) ? 'action' : 'behavior';
}

/** Força da dependência pelo caminho do campo: `editor*`/`preview*`/`thumbnail*` = só editor; `optional*`/`fallback*` = opcional. */
export function strengthForPath(path: string, base: DependencyStrength): DependencyStrength {
  const segments = path.split('.');
  if (segments.some((s) => /^(editor|preview|thumb(nail)?)/i.test(s))) return 'editor';
  if (segments.some((s) => /(optional|fallback)/i.test(s))) return 'optional';
  return base;
}

/** Força padrão por tipo de recurso: arquivos de jogo = runtime; dados e scripts podem citar caminhos dinamicamente. */
function baseStrength(kind: ResourceKind): DependencyStrength {
  return kind === 'data' || kind === 'script' || kind === 'other' ? 'optional' : 'runtime';
}

const RES_URI = /res:\/\/[^"'\s\\)<>]+/g;
const trimUri = (u: string) => u.replace(/[,.;]+$/, '');
const isExternalUrl = (s: string) => /^https?:\/\//i.test(s);

/**
 * Dependências de um recurso, a partir do conteúdo persistido. Aceita:
 *  - `ResourceRef` (`{ id, type?, path? }` com `path` `res://` ou id `res:<caminho>`): alvo por identidade;
 *  - strings `res://…` (campo inteiro): alvo por caminho;
 *  - `contributionId` (Behavior/Action/Condition/Trigger): alvo = item do catálogo de Visual Logic;
 *  - URLs `http(s)://…`: referência externa.
 * Texto que não é JSON (scripts, XML…) é varrido por `res://` no corpo.
 */
export function extractDependencies(kind: ResourceKind, selfUri: string, content: string | undefined): DependencyInput[] {
  if (!content || content.startsWith('data:')) return [];
  const base = baseStrength(kind);
  const out: DependencyInput[] = [];

  // AIS-33a: `.gltf` depende dos seus `.bin` e imagens externos (caminhos relativos ao modelo); `data:` e URLs ficam de fora
  if (selfUri.toLowerCase().endsWith('.gltf')) {
    try {
      const gltf = JSON.parse(content) as AnyRecord;
      for (const group of ['buffers', 'images'] as const) {
        (Array.isArray(gltf[group]) ? gltf[group] : []).forEach((item: AnyRecord, i: number) => {
          if (typeof item?.uri === 'string' && isExternalGltfUri(item.uri)) out.push({ targetUri: resolveRelativeUri(selfUri, item.uri), strength: 'runtime', via: `${group}.${i}.uri` });
        });
      }
    } catch {
      /* glTF ilegível: sem dependências (o importador acusa o erro) */
    }
    return out;
  }

  let json: unknown;
  const looksJson = selfUri.toLowerCase().endsWith('.json');
  if (looksJson) {
    try {
      json = JSON.parse(content);
    } catch {
      json = undefined;
    }
  }

  if (json === undefined) {
    // texto livre: só caminhos res:// no corpo
    for (const m of content.matchAll(RES_URI)) {
      const uri = trimUri(m[0]);
      if (uri !== selfUri) out.push({ targetUri: uri, strength: base, via: 'text' });
    }
    return out;
  }

  const walk = (value: unknown, path: string, container: string | undefined) => {
    if (typeof value === 'string') {
      if (value.startsWith('res://') && !/\s/.test(value)) {
        if (value !== selfUri) out.push({ targetUri: trimUri(value), strength: strengthForPath(path, base), via: path });
      } else if (isExternalUrl(value) && /(^|\.)(url|src|source|href)$/i.test(path)) {
        out.push({ targetUri: value, strength: 'optional', via: path });
      }
      return;
    }
    if (Array.isArray(value)) {
      value.forEach((item, i) => walk(item, `${path}.${i}`, container));
      return;
    }
    if (!isRecord(value)) return;

    // ResourceRef: id estável (+ caminho/legado como dica)
    const isRef = typeof value.id === 'string' && (typeof value.path === 'string' || value.id.startsWith('res:') || /^res_[a-z0-9]+$/i.test(value.id)) && ('type' in value || 'path' in value || 'label' in value);
    if (isRef) {
      const legacyUri = value.id.startsWith('res:') ? value.id.slice(4) : undefined;
      const uri = typeof value.path === 'string' ? value.path : legacyUri;
      out.push({ targetId: value.id.startsWith('res:') ? undefined : value.id, targetUri: uri, strength: strengthForPath(path, base), via: path });
    }

    // Behavior/Action/Condition/Trigger → pasta do catálogo
    if (typeof value.contributionId === 'string' && value.contributionId) {
      const logicKind = logicKindOf(value, container);
      out.push({ targetId: logicNodeId(logicKind, value.contributionId), targetUri: logicNodeId(logicKind, value.contributionId), strength: 'runtime', via: `${path}.contributionId` });
    }

    for (const [key, child] of Object.entries(value)) {
      if (isRef && (key === 'path' || key === 'id')) continue; // já contados pela referência
      walk(child, path ? `${path}.${key}` : key, key);
    }
  };
  walk(json, '', undefined);
  return out;
}
