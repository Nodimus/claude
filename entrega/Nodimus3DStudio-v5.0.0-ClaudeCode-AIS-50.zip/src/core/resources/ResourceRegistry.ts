import type { ResourceRef } from '../../types/node';
import { hashContent } from '../documents/documentKinds';
import { ensureResourceIds, type ResourceMeta } from './ids';
import { NON_RESOURCE_URIS, kindOfPath, type ResourceKind } from './resourceKinds';
import { DependencyGraph } from './DependencyGraph';
import { extractDependencies, logicFolderUri, LOGIC_NODE_PREFIX } from './dependencyExtractor';

/**
 * AIS-28c — ResourceRegistry: registro canônico dos recursos do projeto, indexado por `resourceId` persistente e por
 * URI `res://`. Fonte única para Inspector, pickers, Prefabs e Publish; o FileSystemPanel só apresenta arquivos.
 *
 * As dependências entre recursos vivem no `DependencyGraph` (`registry.graph`), atualizado de forma incremental a cada
 * sincronização (AIS-29c): só os recursos cujo conteúdo mudou são re-extraídos.
 *
 * O índice é DERIVADO de `project.files` (cada arquivo carrega o seu `resourceId`): renomear/mover preserva a
 * identidade porque o arquivo é o mesmo objeto com outro caminho. Sem React/Three; quem consome assina `subscribe`.
 */

export type ResourceStatus = 'resolved' | 'importFailed';

export interface ResourceDiagnostic {
  /** Código estável (ex.: `texture.invalid_data_url`). Formato compatível com o futuro DiagnosticService (AIS-32c). */
  code: string;
  severity: 'error' | 'warning' | 'info';
  message: string;
  uri?: string;
  resourceId?: string;
}

export interface ResourceEntry {
  resourceId: string;
  kind: ResourceKind;
  uri: string;
  sourceUri?: string;
  schemaVersion?: number;
  importerId?: string;
  importSettings?: Record<string, unknown>;
  contentHash?: string;
  /** `resourceId`s dos recursos que este usa (vem do `DependencyGraph`; use `graph` para o detalhe). */
  dependencies: string[];
  /** URIs citados que não existem mais (referência órfã preservada, nunca apagada). */
  unresolvedDependencies: string[];
  status: ResourceStatus;
  diagnostic?: ResourceDiagnostic;
}

export type ResourceEvent =
  | { type: 'added'; resourceId: string; uri: string }
  | { type: 'removed'; resourceId: string; uri: string }
  | { type: 'moved'; resourceId: string; from: string; to: string }
  | { type: 'changed'; resourceId: string; uri: string }
  | { type: 'status'; resourceId: string; uri: string; status: ResourceStatus };

export type ResolveResult =
  | { status: 'resolved'; entry: ResourceEntry }
  | { status: 'unresolved'; ref: ResourceRef };

type ProjectFile = {
  path: string;
  name: string;
  isDirectory: boolean;
  content?: string;
  size?: number;
  updatedAt?: string;
} & ResourceMeta & { schemaVersion?: number };

type ProjectLike = { files: Record<string, ProjectFile> };

type Listener = (event: ResourceEvent) => void;

const LEGACY_ID_PREFIX = 'res:';

export class ResourceRegistry {
  private byId = new Map<string, ResourceEntry>();
  private byUri = new Map<string, ResourceEntry>();
  private listeners = new Set<Listener>();
  private hashCache = new Map<string, { size: number; updatedAt: string; hash: string }>();
  private failures = new Map<string, ResourceDiagnostic>();
  /** Grafo canônico de dependências (AIS-29c): único; Prefab e Publish o reutilizam. */
  public readonly graph = new DependencyGraph();
  private depSignature = new Map<string, string>();
  private logicResolver: ((kind: string, id: string) => boolean) | null = null;
  /** Muda a cada alteração do índice (para `useSyncExternalStore`). */
  public version = 0;

  /** Assina eventos de alteração; devolve o disposer (AIS-48b). */
  public subscribe = (listener: Listener): (() => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };

  private emit(event: ResourceEvent): void {
    this.version++;
    for (const listener of this.listeners) {
      try {
        listener(event);
      } catch (error) {
        console.error('Error in ResourceRegistry subscriber:', error);
      }
    }
  }

  private hashOf(file: ProjectFile, resourceId: string): string | undefined {
    if (file.content === undefined) return undefined;
    const size = file.size ?? file.content.length;
    const stamp = file.updatedAt ?? '';
    const cached = this.hashCache.get(resourceId);
    if (cached && cached.size === size && cached.updatedAt === stamp) return cached.hash;
    const hash = hashContent(file.content) ?? undefined;
    if (hash) this.hashCache.set(resourceId, { size, updatedAt: stamp, hash });
    return hash;
  }

  /**
   * Reconstrói o índice a partir dos arquivos do projeto. Dá `resourceId` (EM LUGAR) aos arquivos que ainda não têm;
   * compara com o índice anterior e emite `added`/`removed`/`moved`/`changed`. Devolve quantos ids novos foram dados.
   */
  public syncFromProject(project: ProjectLike): number {
    const assigned = ensureResourceIds(project.files);
    const next = new Map<string, ResourceEntry>();
    const nextByUri = new Map<string, ResourceEntry>();

    for (const file of Object.values(project.files)) {
      if (file.isDirectory || !file.resourceId || NON_RESOURCE_URIS.has(file.path)) continue;
      const id = file.resourceId;
      const failure = this.failures.get(id);
      const entry: ResourceEntry = {
        resourceId: id,
        kind: kindOfPath(file.path),
        uri: file.path,
        schemaVersion: file.schemaVersion,
        importerId: file.importerId,
        importSettings: file.importSettings,
        contentHash: file.contentHash ?? this.hashOf(file, id),
        dependencies: [],
        unresolvedDependencies: [],
        status: failure ? 'importFailed' : 'resolved',
        diagnostic: failure,
      };
      next.set(id, entry);
      nextByUri.set(file.path, entry);
    }

    // grafo de dependências: atualização incremental (só o que mudou)
    this.updateGraph(project, next);

    const events: ResourceEvent[] = [];
    for (const [id, entry] of next) {
      const before = this.byId.get(id);
      if (!before) events.push({ type: 'added', resourceId: id, uri: entry.uri });
      else if (before.uri !== entry.uri) events.push({ type: 'moved', resourceId: id, from: before.uri, to: entry.uri });
      else if (before.contentHash !== entry.contentHash || JSON.stringify(before.importSettings) !== JSON.stringify(entry.importSettings) || before.status !== entry.status) {
        events.push({ type: 'changed', resourceId: id, uri: entry.uri });
      }
    }
    for (const [id, entry] of this.byId) if (!next.has(id)) events.push({ type: 'removed', resourceId: id, uri: entry.uri });

    this.byId = next;
    this.byUri = nextByUri;
    for (const id of [...this.failures.keys()]) if (!next.has(id)) this.failures.delete(id);
    for (const id of [...this.hashCache.keys()]) if (!next.has(id)) this.hashCache.delete(id);
    if (events.length === 0) return assigned;
    for (const event of events) this.emit(event);
    return assigned;
  }

  /** O catálogo de Visual Logic informa se um item existe (`LogicRegistry`); sem resolvedor, todo item é "não resolvido". */
  public setLogicResolver(resolver: ((kind: string, id: string) => boolean) | null): void {
    this.logicResolver = resolver;
    this.depSignature.clear(); // a resposta pode ter mudado: re-extrai na próxima sincronização
  }

  private updateGraph(project: ProjectLike, next: Map<string, ResourceEntry>): void {
    const graph = this.graph;
    // removidos
    for (const node of graph.listNodes()) {
      if (node.external) continue;
      if (!next.has(node.id)) {
        graph.removeResource(node.id);
        this.depSignature.delete(node.id);
      }
    }
    // novos / movidos / mudança de tipo
    for (const entry of next.values()) {
      const node = graph.getNode(entry.resourceId);
      if (!node) graph.addResource({ id: entry.resourceId, uri: entry.uri, kind: entry.kind });
      else if (node.uri !== entry.uri || node.kind !== entry.kind) graph.updateResource(entry.resourceId, { uri: entry.uri, kind: entry.kind });
    }
    // extração: só de quem mudou
    for (const entry of next.values()) {
      const file = project.files[entry.uri];
      const signature = `${entry.contentHash ?? ''}|${entry.kind}`;
      if (this.depSignature.get(entry.resourceId) === signature) continue;
      this.depSignature.set(entry.resourceId, signature);
      const inputs = extractDependencies(entry.kind, entry.uri, file?.content);
      for (const input of inputs) {
        const id = input.targetId;
        if (!id || !id.startsWith(LOGIC_NODE_PREFIX) || graph.hasResource(id)) continue;
        const [kind, contributionId] = id.slice(LOGIC_NODE_PREFIX.length).split('/');
        if (this.logicResolver?.(kind, contributionId)) {
          graph.addResource({ id, uri: logicFolderUri(kind, contributionId), kind: 'logic', external: true });
        }
      }
      graph.setDependencies(entry.resourceId, inputs);
    }
    // campos derivados do grafo (compatibilidade com consumidores do registry)
    for (const entry of next.values()) {
      const direct = graph.getDirect(entry.resourceId);
      entry.dependencies = [...new Set(direct.filter((e) => e.to && !graph.getNode(e.to)?.external).map((e) => e.to!))];
      entry.unresolvedDependencies = [...new Set(direct.filter((e) => e.type === 'unresolved').map((e) => e.toUri))];
    }
  }

  // ── Consulta ─────────────────────────────────────────────────────────────

  public get(resourceId: string): ResourceEntry | undefined {
    return this.byId.get(resourceId);
  }

  public getByUri(uri: string): ResourceEntry | undefined {
    return this.byUri.get(uri);
  }

  /** Recursos, opcionalmente de um tipo, ordenados por nome. */
  public list(kind?: ResourceKind): ResourceEntry[] {
    const all = [...this.byId.values()].filter((e) => !kind || e.kind === kind);
    return all.sort((a, b) => a.uri.localeCompare(b.uri, undefined, { numeric: true, sensitivity: 'base' }));
  }

  public get size(): number {
    return this.byId.size;
  }

  /**
   * Resolve um `ResourceRef`: primeiro pela identidade (`id`), depois — só para referências antigas (`res:<caminho>`)
   * ou sem id conhecido — pelo caminho. Não achou = `unresolved` (a referência é preservada pelo chamador).
   */
  public resolve(ref: ResourceRef | null | undefined): ResolveResult | { status: 'none' } {
    if (!ref || typeof ref.id !== 'string') return { status: 'none' };
    const byId = this.byId.get(ref.id);
    if (byId) return { status: 'resolved', entry: byId };
    const legacyPath = ref.id.startsWith(LEGACY_ID_PREFIX) ? ref.id.slice(LEGACY_ID_PREFIX.length) : undefined;
    const path = typeof ref.path === 'string' ? ref.path : legacyPath;
    const byPath = path ? this.byUri.get(path) : undefined;
    if (byPath) return { status: 'resolved', entry: byPath };
    return { status: 'unresolved', ref };
  }

  /** `ResourceRef` canônico de um recurso (o `id` é o `resourceId`; `path` é só a dica de leitura). */
  public makeRef(resourceId: string): ResourceRef | undefined {
    const entry = this.byId.get(resourceId);
    if (!entry) return undefined;
    return { id: entry.resourceId, type: entry.kind, path: entry.uri, label: entry.uri.split('/').pop() || entry.uri };
  }

  public refForUri(uri: string): ResourceRef | undefined {
    const entry = this.byUri.get(uri);
    return entry ? this.makeRef(entry.resourceId) : undefined;
  }

  /** Referências que não resolvem (órfãs): para diagnóstico e publicação. */
  public findUnresolved(refs: readonly (ResourceRef | null | undefined)[]): ResourceRef[] {
    const out: ResourceRef[] = [];
    for (const ref of refs) {
      const result = this.resolve(ref);
      if (result.status === 'unresolved') out.push(result.ref);
    }
    return out;
  }

  // ── Estado de importação ─────────────────────────────────────────────────

  /** Marca falha de importação (a última versão válida do arquivo é mantida) ou limpa o estado. */
  public setImportFailure(resourceId: string, diagnostic: ResourceDiagnostic | null): void {
    const entry = this.byId.get(resourceId);
    if (!entry) return;
    if (diagnostic) this.failures.set(resourceId, diagnostic);
    else this.failures.delete(resourceId);
    const status: ResourceStatus = diagnostic ? 'importFailed' : 'resolved';
    if (entry.status === status && entry.diagnostic === diagnostic) return;
    entry.status = status;
    entry.diagnostic = diagnostic ?? undefined;
    this.emit({ type: 'status', resourceId, uri: entry.uri, status });
  }

  /** Descarta o índice (ex.: troca de projeto). Os ids continuam nos arquivos. */
  public clear(): void {
    this.byId.clear();
    this.byUri.clear();
    this.failures.clear();
    this.hashCache.clear();
    this.depSignature.clear();
    this.graph.clear();
    this.version++;
  }
}
