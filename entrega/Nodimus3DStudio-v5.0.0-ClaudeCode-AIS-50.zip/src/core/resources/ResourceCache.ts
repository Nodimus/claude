/**
 * AIS-28c — cache do pipeline: DERIVADO e DESCARTÁVEL. Guarda só o que se recalcula a partir do recurso
 * (resultado de `process`); nunca é fonte de verdade. Limpar o cache não perde nenhum dado autoral: a próxima
 * importação/reimportação o reconstrói.
 */

/** Versão do engine considerada nas chaves (muda quando o processamento muda de forma incompatível). */
export const ENGINE_CACHE_VERSION = 'nodimus-5.0';

export interface CacheKeyParts {
  contentHash: string | undefined;
  importSettings: Record<string, unknown> | undefined;
  importerId: string;
  importerVersion: number;
  engineVersion?: string;
}

/** JSON estável (chaves ordenadas) para a chave não depender da ordem das propriedades. */
function stable(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stable).join(',')}]`;
  if (value && typeof value === 'object') {
    const obj = value as Record<string, unknown>;
    return `{${Object.keys(obj).sort().map((k) => `${JSON.stringify(k)}:${stable(obj[k])}`).join(',')}}`;
  }
  return JSON.stringify(value) ?? 'null';
}

/** Chave: conteúdo + import settings + versão do importer + versão do engine. */
export function cacheKey(parts: CacheKeyParts): string {
  return [parts.importerId, parts.importerVersion, parts.engineVersion ?? ENGINE_CACHE_VERSION, parts.contentHash ?? '-', stable(parts.importSettings ?? {})].join('|');
}

export class ResourceCache<T = unknown> {
  private store = new Map<string, T>();
  public hits = 0;
  public misses = 0;

  get(key: string): T | undefined {
    const value = this.store.get(key);
    if (value === undefined) this.misses++;
    else this.hits++;
    return value;
  }

  set(key: string, value: T): void {
    this.store.set(key, value);
  }

  get size(): number {
    return this.store.size;
  }

  /** Apaga tudo (derivado): nada autoral é perdido. */
  clear(): void {
    this.store.clear();
    this.hits = 0;
    this.misses = 0;
  }
}
