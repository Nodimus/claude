import { describe, expect, it } from 'vitest';
import { kindOfPath, scanDependencyUris } from './resourceKinds';
import { carryResourceMeta, ensureResourceIds } from './ids';
import { ResourceRegistry, type ResourceEvent } from './ResourceRegistry';
import { AssetPipeline, type PipelineIO } from './AssetPipeline';
import { BUILTIN_IMPORTERS } from './builtinImporters';
import { cacheKey } from './ResourceCache';
import { planPathChange } from '../fileSystem/fileOps';

type F = Record<string, any>;
const file = (path: string, extra: F = {}) => ({ path, name: path.split('/').filter(Boolean).pop()!, isDirectory: path.endsWith('/'), updatedAt: '2026-10-02T00:00:00Z', ...extra });
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

/** Projeto fake: o mesmo tipo de mapa que `project.files`. */
const makeProject = (files: F = {}) => {
  const project = { files: { ...files } as F };
  const io: PipelineIO = {
    files: () => project.files,
    write: (uri, content, meta) => {
      const prev = project.files[uri];
      project.files[uri] = { ...(prev ?? file(uri)), path: uri, name: uri.split('/').pop(), isDirectory: false, content, size: content.length, ...meta, updatedAt: String(Date.now()) };
    },
  };
  const registry = new ResourceRegistry();
  const pipeline = new AssetPipeline(registry, io);
  for (const importer of BUILTIN_IMPORTERS) pipeline.registerImporter(importer);
  return { project, registry, pipeline };
};

/** Mesmo efeito do `renameFile` do EditorContext: o arquivo (com seus metadados) muda de caminho. */
function rename(project: { files: F }, from: string, to: string) {
  const plan = planPathChange(project.files, from, to);
  if (!plan.ok) throw new Error(plan.error);
  const next: F = { ...project.files };
  for (const [a] of plan.moves) delete next[a];
  for (const [a, b] of plan.moves) next[b] = { ...project.files[a], path: b, name: b.split('/').filter(Boolean).pop() };
  project.files = next;
}

describe('tipos de recurso', () => {
  it('sufixos compostos vencem a extensão; texturas extraídas são material', () => {
    expect(kindOfPath('res://scenes/Main.scene.json')).toBe('scene');
    expect(kindOfPath('res://prefabs/Door.prefab.json')).toBe('prefab');
    expect(kindOfPath('res://sprites/Hero.sprite.json')).toBe('sprite');
    expect(kindOfPath('res://materials/Gold.mat.json')).toBe('material');
    expect(kindOfPath('res://textures/robot_material.json')).toBe('material');
    expect(kindOfPath('res://materials/robot_rig.json')).toBe('animation');
    expect(kindOfPath('res://textures/a.PNG')).toBe('texture');
    expect(kindOfPath('res://models/a.glb')).toBe('mesh');
    expect(kindOfPath('res://audio/a.wav')).toBe('audio');
    expect(kindOfPath('res://scripts/a.ts')).toBe('script');
    expect(kindOfPath('res://data/a.json')).toBe('data');
    expect(kindOfPath('res://x/a.bin')).toBe('other');
  });
  it('dependências: varre res:// em recursos textuais; data URL não', () => {
    expect(scanDependencyUris('{"albedo":{"path":"res://textures/a.png"},"b":"res://models/m.glb"}').sort()).toEqual(['res://models/m.glb', 'res://textures/a.png']);
    expect(scanDependencyUris(PNG)).toEqual([]);
    expect(scanDependencyUris(undefined)).toEqual([]);
  });
});

describe('identidade persistente (AIS-28c-C01)', () => {
  it('ids são dados em lugar, uma vez, e nunca mudam', () => {
    const files: F = { 'res://a.txt': file('res://a.txt'), 'res://d/': file('res://d/') };
    expect(ensureResourceIds(files as any, () => 'res_1')).toBe(1);
    expect(files['res://a.txt'].resourceId).toBe('res_1');
    expect(files['res://d/'].resourceId).toBeUndefined();
    expect(ensureResourceIds(files as any, () => 'res_2')).toBe(0);
    expect(files['res://a.txt'].resourceId).toBe('res_1');
  });
  it('sobrescrever o arquivo herda id e settings (updateFileContent não troca a identidade)', () => {
    const prev = { resourceId: 'res_1', importerId: 'texture', importSettings: { colorSpace: 'linear' } };
    const next = carryResourceMeta(prev, { path: 'x', content: 'novo' });
    expect(next).toMatchObject({ resourceId: 'res_1', importerId: 'texture', importSettings: { colorSpace: 'linear' }, content: 'novo' });
    expect(carryResourceMeta({ resourceId: 'res_1' }, { resourceId: 'res_9' }).resourceId).toBe('res_9');
  });
  it('renomear/mover preserva o resourceId e a referência antiga continua resolvendo', () => {
    const { project, registry } = makeProject({ 'res://textures/a.png': file('res://textures/a.png', { content: PNG }), 'res://m/': file('res://m/') });
    registry.syncFromProject(project);
    const entry = registry.getByUri('res://textures/a.png')!;
    const ref = registry.makeRef(entry.resourceId)!;
    expect(ref).toMatchObject({ id: entry.resourceId, type: 'texture', path: 'res://textures/a.png' });

    const events: ResourceEvent[] = [];
    registry.subscribe((e) => events.push(e));
    rename(project, 'res://textures/a.png', 'res://m/b.png');
    registry.syncFromProject(project);

    const moved = registry.getByUri('res://m/b.png')!;
    expect(moved.resourceId).toBe(entry.resourceId);
    expect(registry.getByUri('res://textures/a.png')).toBeUndefined();
    expect(events).toContainEqual({ type: 'moved', resourceId: entry.resourceId, from: 'res://textures/a.png', to: 'res://m/b.png' });
    const resolved = registry.resolve(ref);
    expect(resolved.status).toBe('resolved');
    if (resolved.status === 'resolved') expect(resolved.entry.uri).toBe('res://m/b.png'); // path da ref está velho; o id manda
  });
  it('renomear uma pasta leva os recursos de dentro, cada um com o seu id', () => {
    const { project, registry } = makeProject({
      'res://a/': file('res://a/'),
      'res://a/x.png': file('res://a/x.png', { content: PNG }),
      'res://a/y.png': file('res://a/y.png', { content: PNG }),
    });
    registry.syncFromProject(project);
    const ids = ['res://a/x.png', 'res://a/y.png'].map((u) => registry.getByUri(u)!.resourceId);
    rename(project, 'res://a/', 'res://b/');
    registry.syncFromProject(project);
    expect(['res://b/x.png', 'res://b/y.png'].map((u) => registry.getByUri(u)!.resourceId)).toEqual(ids);
  });
  it('referência antiga (res:<caminho>) resolve pelo caminho; sem arquivo = unresolved, nunca apagada', () => {
    const { project, registry } = makeProject({ 'res://textures/a.png': file('res://textures/a.png', { content: PNG }) });
    registry.syncFromProject(project);
    const legacy = { id: 'res:res://textures/a.png', type: 'texture', path: 'res://textures/a.png' };
    expect(registry.resolve(legacy).status).toBe('resolved');
    const orphan = { id: 'res_zzz', type: 'texture', path: 'res://textures/sumiu.png' };
    expect(registry.resolve(orphan)).toEqual({ status: 'unresolved', ref: orphan });
    expect(registry.findUnresolved([legacy, orphan, null])).toEqual([orphan]);
    expect(registry.resolve(undefined).status).toBe('none');
  });
  it('remover o arquivo emite removed; res://project.json e pastas não são recursos', () => {
    const { project, registry } = makeProject({ 'res://project.json': file('res://project.json', { content: '{}' }), 'res://d/': file('res://d/'), 'res://a.txt': file('res://a.txt', { content: 'x' }) });
    registry.syncFromProject(project);
    expect(registry.list().map((e) => e.uri)).toEqual(['res://a.txt']);
    const events: ResourceEvent[] = [];
    registry.subscribe((e) => events.push(e));
    delete project.files['res://a.txt'];
    registry.syncFromProject(project);
    expect(events.map((e) => e.type)).toEqual(['removed']);
  });
  it('subscribe devolve disposer', () => {
    const { project, registry } = makeProject({ 'res://a.txt': file('res://a.txt', { content: 'x' }) });
    let count = 0;
    const off = registry.subscribe(() => count++);
    registry.syncFromProject(project);
    off();
    project.files['res://b.txt'] = file('res://b.txt', { content: 'y' });
    registry.syncFromProject(project);
    expect(count).toBe(1);
  });
});

describe('consultas e dependências (AIS-28c-C03/C05)', () => {
  it('list(kind) alimenta os pickers; texturas extraídas são recursos independentes em res://textures/', () => {
    const { project, registry } = makeProject({
      'res://textures/a.png': file('res://textures/a.png', { content: PNG }),
      'res://textures/b.jpg': file('res://textures/b.jpg', { content: PNG }),
      'res://textures/robot_material.json': file('res://textures/robot_material.json', { content: '{"maps":["res://textures/a.png"]}' }),
      'res://scripts/s.ts': file('res://scripts/s.ts', { content: 'x' }),
    });
    registry.syncFromProject(project);
    expect(registry.list('texture').map((e) => e.uri)).toEqual(['res://textures/a.png', 'res://textures/b.jpg']);
    const descriptor = registry.getByUri('res://textures/robot_material.json')!;
    expect(descriptor.kind).toBe('material');
    expect(descriptor.resourceId).not.toBe(registry.getByUri('res://textures/a.png')!.resourceId);
    expect(descriptor.dependencies).toEqual([registry.getByUri('res://textures/a.png')!.resourceId]);
  });
  it('dependência para arquivo que não existe fica registrada como não resolvida', () => {
    const { project, registry } = makeProject({ 'res://m.mat.json': file('res://m.mat.json', { content: '{"t":"res://textures/falta.png"}' }) });
    registry.syncFromProject(project);
    expect(registry.getByUri('res://m.mat.json')!.unresolvedDependencies).toEqual(['res://textures/falta.png']);
  });
});

describe('AssetPipeline (AIS-28c-C02/C04/C06)', () => {
  it('importa: valida, processa, persiste com id e settings, registra e notifica', async () => {
    const { project, registry, pipeline } = makeProject();
    const events: ResourceEvent[] = [];
    registry.subscribe((e) => events.push(e));
    const result = await pipeline.import({ uri: 'res://textures/a.png', content: PNG, settings: { colorSpace: 'linear' } });
    expect(result).toMatchObject({ ok: true, created: true, cached: false, derived: { mime: 'image/png' } });
    const stored = project.files['res://textures/a.png'];
    expect(stored.resourceId).toBe(result.ok && result.resourceId);
    expect(stored.importerId).toBe('texture');
    expect(stored.importSettings).toEqual({ colorSpace: 'linear', generateMipmaps: true });
    expect(registry.getByUri('res://textures/a.png')?.kind).toBe('texture');
    expect(events.some((e) => e.type === 'added')).toBe(true);
  });
  it('reimport preserva identidade e configurações; settings novas se mesclam por cima', async () => {
    const { project, registry, pipeline } = makeProject();
    const first = await pipeline.import({ uri: 'res://textures/a.png', content: PNG, settings: { colorSpace: 'linear' } });
    if (!first.ok) throw new Error('falhou');
    const again = await pipeline.reimport(first.resourceId);
    expect(again).toMatchObject({ ok: true, created: false, resourceId: first.resourceId, cached: true });
    expect(project.files['res://textures/a.png'].importSettings).toMatchObject({ colorSpace: 'linear' });
    await pipeline.reimport(first.resourceId, { settings: { generateMipmaps: false } });
    expect(project.files['res://textures/a.png'].importSettings).toEqual({ colorSpace: 'linear', generateMipmaps: false });
    expect(registry.getByUri('res://textures/a.png')!.resourceId).toBe(first.resourceId);
  });
  it('reimport depois de mover mantém o id', async () => {
    const { project, registry, pipeline } = makeProject();
    const first = await pipeline.import({ uri: 'res://textures/a.png', content: PNG });
    if (!first.ok) throw new Error('falhou');
    rename(project, 'res://textures/a.png', 'res://textures/novo.png');
    registry.syncFromProject(project);
    const again = await pipeline.reimport(first.resourceId);
    expect(again).toMatchObject({ ok: true, resourceId: first.resourceId, uri: 'res://textures/novo.png' });
  });
  it('falha de validação NUNCA destrói a última versão válida; o recurso fica importFailed com diagnóstico', async () => {
    const { project, registry, pipeline } = makeProject();
    const sunk: string[] = [];
    pipeline.setDiagnosticSink((d) => sunk.push(d.code));
    const first = await pipeline.import({ uri: 'res://textures/a.png', content: PNG });
    if (!first.ok) throw new Error('falhou');
    const bad = await pipeline.import({ uri: 'res://textures/a.png', content: 'isto não é imagem' });
    expect(bad.ok).toBe(false);
    expect(project.files['res://textures/a.png'].content).toBe(PNG);
    const entry = registry.get(first.resourceId)!;
    expect(entry.status).toBe('importFailed');
    expect(entry.diagnostic?.code).toBe('texture.invalid_data_url');
    expect(sunk).toContain('texture.invalid_data_url');
    // reimportar conteúdo válido limpa o estado
    const fixed = await pipeline.import({ uri: 'res://textures/a.png', content: PNG });
    expect(fixed.ok).toBe(true);
    expect(registry.get(first.resourceId)!.status).toBe('resolved');
  });
  it('sem importador para a extensão: erro de diagnóstico, nada é gravado', async () => {
    const { project, pipeline } = makeProject();
    const r = await pipeline.import({ uri: 'res://x/arquivo.bin', content: 'x' });
    expect(r.ok).toBe(false);
    expect(r.diagnostics[0].code).toBe('import.no_importer');
    expect(project.files['res://x/arquivo.bin']).toBeUndefined();
  });
  it('JSON inválido é rejeitado; script com erro de sintaxe é só aviso (continua importável)', async () => {
    const { pipeline } = makeProject();
    expect((await pipeline.import({ uri: 'res://m.mat.json', content: '{ quebrado' })).ok).toBe(false);
    const script = await pipeline.import({ uri: 'res://scripts/a.ts', content: 'function ( {' });
    expect(script.ok).toBe(true);
    expect(script.diagnostics[0].severity).toBe('warning');
  });
  it('cache é derivado e descartável: apagar e reimportar reconstrói sem perda autoral', async () => {
    const { project, pipeline } = makeProject();
    const first = await pipeline.import({ uri: 'res://textures/a.png', content: PNG });
    if (!first.ok) throw new Error('falhou');
    const before = JSON.stringify(project.files['res://textures/a.png'], (k, v) => (k === 'updatedAt' ? undefined : v));
    expect(pipeline.cache.size).toBe(1);
    pipeline.clearCache();
    expect(pipeline.cache.size).toBe(0);
    const again = await pipeline.reimport(first.resourceId);
    expect(again).toMatchObject({ ok: true, cached: false, resourceId: first.resourceId });
    expect(pipeline.cache.size).toBe(1);
    expect(JSON.stringify(project.files['res://textures/a.png'], (k, v) => (k === 'updatedAt' ? undefined : v))).toBe(before);
  });
  it('chave de cache considera conteúdo, settings, versão do importer e do engine', () => {
    const base = { contentHash: 'h', importSettings: { a: 1, b: 2 }, importerId: 'texture', importerVersion: 1 };
    expect(cacheKey(base)).toBe(cacheKey({ ...base, importSettings: { b: 2, a: 1 } }));
    expect(cacheKey(base)).not.toBe(cacheKey({ ...base, contentHash: 'h2' }));
    expect(cacheKey(base)).not.toBe(cacheKey({ ...base, importSettings: { a: 9 } }));
    expect(cacheKey(base)).not.toBe(cacheKey({ ...base, importerVersion: 2 }));
    expect(cacheKey(base)).not.toBe(cacheKey({ ...base, engineVersion: 'outro' }));
  });
  it('reimport de recurso desconhecido ou sem conteúdo falha com diagnóstico', async () => {
    const { project, registry, pipeline } = makeProject({ 'res://a.txt': file('res://a.txt') });
    registry.syncFromProject(project);
    expect((await pipeline.reimport('nao_existe')).diagnostics[0].code).toBe('import.unknown_resource');
    const id = registry.getByUri('res://a.txt')!.resourceId;
    expect((await pipeline.reimport(id)).diagnostics[0].code).toBe('import.source_missing');
  });
});
