import { describe, expect, it } from 'vitest';
import { resolveDropAction } from './fileSystem/dropActions';
import {
  canChangeGeometry,
  draftChanges,
  draftFromProps,
  geometryDirty,
  hasSculptedHeights,
  heightmapChanges,
  normalizeDraft,
  regenerateChanges,
  reseedChanges,
  terrainGeneratorSource,
  visualOnlyChanges,
} from './terrainOps';

const ref = { id: 'res_1', path: 'res://textures/h.png' };
const sculptedProps = { heightBufferRef: { id: 'res_9', path: 'res://terrain/t.height' }, segmentsW: 64, segmentsH: 64 };

describe('terrainOps (AIS-50)', () => {
  it('marca de origem: params mínimo + seed (as propriedades do nó mandam)', () => {
    expect(terrainGeneratorSource({ terrainPreset: 'hills', presetSeed: 7, heightmapRef: ref })).toEqual({ generatorId: 'terrain', version: 1, params: { preset: 'hills' }, seed: 7 });
    expect(terrainGeneratorSource(undefined)).toEqual({ generatorId: 'terrain', version: 1, params: { preset: 'flat' }, seed: 0 });
  });
  it('heightmap e semente: mudanças mínimas; a nova semente difere da atual', () => {
    expect(heightmapChanges(ref)).toEqual({ heightmapRef: ref });
    expect(heightmapChanges(null)).toEqual({ heightmapRef: null });
    expect(reseedChanges({ presetSeed: 5 }, () => 5 / 1_000_000).presetSeed).not.toBe(5);
    expect(reseedChanges({ presetSeed: 5 }, () => 0.123).presetSeed).toBe(123000);
  });
  it('terreno esculpido trava a geometria', () => {
    expect(hasSculptedHeights(sculptedProps)).toBe(true);
    expect(hasSculptedHeights({})).toBe(false);
    expect(canChangeGeometry({})).toEqual({ ok: true });
    expect(canChangeGeometry(sculptedProps)).toMatchObject({ ok: false, reason: expect.stringContaining('Regenerar geometria') });
  });
  it('rascunho: só as chaves que mudam, normalizadas', () => {
    const props = { width: 120, terrainPreset: 'flat' };
    const draft = { ...draftFromProps(props), terrainPreset: 'hills', segmentsW: 40, textureTiling: 999 };
    expect(draftChanges(props, draft)).toEqual({ terrainPreset: 'hills', segmentsW: 32, textureTiling: 256 });
    expect(draftChanges(props, draftFromProps(props))).toEqual({});
    expect(normalizeDraft({ ...draft, terrainPreset: 'lava' }).terrainPreset).toBe('flat');
  });
  it('Regenerar geometria fica habilitado só quando algo de geometria mudou', () => {
    const props = {};
    const base = draftFromProps(props);
    expect(geometryDirty(props, base)).toBe(false);
    expect(geometryDirty(props, { ...base, textureTiling: 8 })).toBe(false);
    for (const change of [{ terrainPreset: 'canyon' }, { presetSeed: 3 }, { width: 200 }, { depth: 80 }, { segmentsW: 64 }, { segmentsH: 256 }, { heightmapRef: ref }, { maxHeight: 40 }]) {
      expect(geometryDirty(props, { ...base, ...change } as typeof base)).toBe(true);
    }
  });
  it('terreno esculpido: "visuais" nunca toca geometria; "regenerar" remove o vínculo do .height', () => {
    const base = draftFromProps(sculptedProps);
    const edited = { ...base, groundTexture: 'Sand_Desert', blendSharpness: 0.9, maxHeight: 40, segmentsW: 256, terrainPreset: 'canyon' };
    expect(visualOnlyChanges(sculptedProps, edited)).toEqual({ groundTexture: 'Sand_Desert', blendSharpness: 0.9, maxHeight: 40 });
    const regen = regenerateChanges(sculptedProps, edited);
    expect(regen).toMatchObject({ heightBufferRef: null, segmentsW: 256, terrainPreset: 'canyon', groundTexture: 'Sand_Desert' });
    expect(regenerateChanges({ segmentsW: 64 }, { ...draftFromProps({ segmentsW: 64 }), presetSeed: 2 })).toEqual({ presetSeed: 2 }); // sem .height: nada a desvincular
  });
});

describe('drop de heightmap (AIS-50-C04)', () => {
  const f = (path: string) => ({ path, extension: path.split('.').pop() ?? '' });
  it('imagem de res://textures/ sobre Terrain vira heightmap; sobre malha continua textura', () => {
    expect(resolveDropAction(f('res://textures/h.png'), false, true)).toEqual({ kind: 'setHeightmap', path: 'res://textures/h.png' });
    expect(resolveDropAction(f('res://textures/h.jpg'), false, true)).toEqual({ kind: 'setHeightmap', path: 'res://textures/h.jpg' });
    expect(resolveDropAction(f('res://textures/h.png'), true, false)).toEqual({ kind: 'applyTexture', path: 'res://textures/h.png' });
    expect(resolveDropAction(f('res://textures/h.png'), false, false)).toMatchObject({ kind: 'reject' });
  });
  it('fora de res://textures/ ou formato não suportado, não vira heightmap', () => {
    expect(resolveDropAction(f('res://sprites/h.png'), false, true).kind).not.toBe('setHeightmap');
    expect(resolveDropAction(f('res://textures/h.webp'), false, true).kind).not.toBe('setHeightmap');
  });
});
