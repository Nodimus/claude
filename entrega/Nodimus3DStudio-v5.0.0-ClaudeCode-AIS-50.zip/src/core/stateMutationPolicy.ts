/**
 * @file stateMutationPolicy.ts
 * @module core/stateMutationPolicy
 *
 * AIS-03e — State Mutation Policy: runtime guards and programmatic checklist.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * This module provides:
 *  1. TYPE-LEVEL enforcement of state boundaries (compile-time)
 *  2. verifyStateMutationPolicy() — deterministic test suite (no React/Zustand)
 *     covering the 8 policy rules defined in docs/policy/STATE-MUTATION-POLICY.md
 *  3. assertEditorStoreBoundary() — runtime guard used in dev to detect
 *     illegal writes to EditorStore (call in __DEV__ blocks only)
 *
 * Reference: docs/policy/STATE-MUTATION-POLICY.md (@STATE-MUTATION-POLICY)
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { EditorStoreState, useEditorStore } from './editorStore';
import * as __schemas from '../schemas';
import { AuthoringModel } from './authoring/AuthoringModel';
import { ICommand } from '../types/commands';
import { CommandManager } from './commandManager';
import { AuthoringSceneSnapshot, RuntimeInstanceHandle } from '../types/runtime';

// ─── Section 1: Type-level boundary enforcement ───────────────────────────────

/**
 * Type guard: ensures that a value does NOT contain imperative heavy objects.
 * Add new banned types here as the engine grows.
 *
 * This is a compile-time documentation type — it does not generate runtime code.
 * Its purpose is to make forbidden shapes explicit and IDE-searchable.
 */
export type ForbiddenInEditorStore =
  | { threeScene: unknown }           // P-02: THREE.Scene
  | { renderer: unknown }             // P-02: THREE.WebGLRenderer
  | { rapierWorld: unknown }          // P-02: Rapier.World
  | { audioContext: unknown }         // P-02: Web Audio nodes
  | { undoStack: unknown }            // P-04: undo stack (owned by CommandManager)
  | { redoStack: unknown }            // P-04: redo stack (owned by CommandManager)
  | { sceneData: unknown }            // P-07: full SceneData (owned by AuthoringModel)
  | { gameNodes: unknown };           // P-07: GameNode map (owned by AuthoringModel)

/**
 * Compile-time assertion that EditorStoreState does not satisfy ForbiddenInEditorStore.
 * If this line causes a type error, a forbidden key was added to EditorStoreState.
 *
 * NOTE: This is enforced via `verifyStateMutationPolicy()` test P-02 at runtime.
 */
type _AssertNoBannedKeysInStore =
  EditorStoreState extends ForbiddenInEditorStore ? 'TYPE_VIOLATION_EDITOR_STORE_CONTAINS_FORBIDDEN_KEY' : 'OK';
const _compileCheck: _AssertNoBannedKeysInStore = 'OK';
void _compileCheck; // suppress unused-variable lint

// ─── Section 2: Runtime dev guard ─────────────────────────────────────────────

/** Known forbidden key patterns — matched against store snapshot keys in dev mode. */
const FORBIDDEN_STORE_KEY_PATTERNS: readonly string[] = [
  'threeScene',
  'renderer',
  'rapierWorld',
  'audioContext',
  'undoStack',
  'redoStack',
  'sceneData',
  'gameNodes',
  'object3d',
  'webgl',
  'rapier',
  'audioNode',
];

/**
 * Dev-only runtime guard. Call after any EditorStore mutation in __DEV__ mode.
 * Throws if a forbidden key is found in the store snapshot.
 *
 * @example
 * if (import.meta.env.DEV) assertEditorStoreBoundary(useEditorStore.getState());
 */
export function assertEditorStoreBoundary(storeSnapshot: Record<string, unknown>): void {
  const keys = Object.keys(storeSnapshot).map((k) => k.toLowerCase());
  for (const pattern of FORBIDDEN_STORE_KEY_PATTERNS) {
    const hit = keys.find((k) => k.includes(pattern.toLowerCase()));
    if (hit) {
      throw new Error(
        `[AIS-03e] STATE BOUNDARY VIOLATION: EditorStore contains forbidden key "${hit}". ` +
        `Rule P-02/P-04/P-07: imperative objects and authoring data must NOT live in the store. ` +
        `See docs/policy/STATE-MUTATION-POLICY.md`
      );
    }
  }
}

// ─── Section 3: Deterministic policy test suite ────────────────────────────────

export interface PolicyTestResult {
  allPassed: boolean;
  results: { label: string; passed: boolean; detail?: string }[];
}

/**
 * AIS-03e deterministic test suite — 8 policy rules verified without React/Zustand/THREE.
 *
 * Each test corresponds to a rule in docs/policy/STATE-MUTATION-POLICY.md.
 * Import and call in fixtures or CI without any browser/React environment.
 */
export function verifyStateMutationPolicy(): PolicyTestResult {
  const checks: { label: string; passed: boolean; detail?: string }[] = [];

  // ── R-01 / P-03: Zod validates external data before loading ───────────────
  // Simulate: loading a scene bypasses Zod → catches errors.
  {
    // Verify that a raw invalid scene object fails Zod (validates gateway behaviour).
    try {
      const validateScene = __schemas.validateScene;
      const invalidRaw = { schemaVersion: 1, id: '', name: '', path: '', rootNodeId: '', nodes: {} };
      const result = validateScene(invalidRaw);
      checks.push({
        label: 'AIS-03e-P01: R-01 Zod rejects invalid scene before AuthoringModel load',
        passed: result.success === false,
        detail: result.success ? 'Zod unexpectedly passed invalid data' : undefined,
      });
    } catch (err) {
      checks.push({
        label: 'AIS-03e-P01: R-01 Zod rejects invalid scene before AuthoringModel load',
        passed: false,
        detail: `Exception: ${err}`,
      });
    }
  }

  // ── R-02: AuthoringModel is the single authority for SceneData ─────────────
  {
    const model = new AuthoringModel();
    const rootId = model.getRootNode()?.id ?? Object.keys(model.getScene().nodes)[0];
    const originalName = model.getNode(rootId)?.name ?? '';
    model.renameNode(rootId, 'PolicyTestName_R02');
    const after = model.getNode(rootId)?.name;
    model.renameNode(rootId, originalName); // restore
    checks.push({
      label: 'AIS-03e-P02: R-02 AuthoringModel is single authority for node mutation',
      passed: after === 'PolicyTestName_R02',
    });
  }

  // ── R-03: CommandManager wraps authorable mutations (ICommand contract) ────
  {
    let executed = false;
    let undone = false;
    const cmd: ICommand = {
      name: 'PolicyTestCommand_R03',
      execute: () => { executed = true; },
      undo: () => { undone = true; },
    };
    const mgr = new CommandManager();
    mgr.execute(cmd);
    mgr.undo();
    checks.push({
      label: 'AIS-03e-P03: R-03 CommandManager executes and undoes reversible commands',
      passed: executed && undone && mgr.canRedo(),
    });
  }

  // ── P-01: EditorStore must not contain persistent scene/node mutations ─────
  // Verified by checking that EditorStoreState keys do NOT include banned patterns.
  {
    // Chaves REAIS do store (estado inicial + ações): novos campos entram sozinhos na verificação.
    const storeKeys = Object.keys(useEditorStore.getState());
    const forbidden = FORBIDDEN_STORE_KEY_PATTERNS;
    const violations = storeKeys.filter((k) =>
      forbidden.some((f) => k.toLowerCase().includes(f.toLowerCase()))
    );
    checks.push({
      label: 'AIS-03e-P04: P-01/P-02 EditorStore (chaves reais) has zero forbidden keys (scene/THREE/undo)',
      passed: violations.length === 0,
      detail: violations.length > 0 ? `Violations: ${violations.join(', ')}` : undefined,
    });
  }

  // ── P-04: CommandManager is the sole undo/redo stack (no duplication) ──────
  {
    const mgr = new CommandManager();
    let count = 0;
    const cmd: ICommand = { name: 'counter', execute: () => count++, undo: () => count-- };
    mgr.execute(cmd);
    mgr.execute(cmd);
    mgr.undo();
    checks.push({
      label: 'AIS-03e-P05: P-04 CommandManager maintains single undo stack, undo reverses correctly',
      passed: count === 1 && mgr.canUndo() && mgr.canRedo(),
    });
  }

  // ── R-05 / P-06: RuntimeSession receives a snapshot (deep copy) of AuthoringModel ─
  {
    const model = new AuthoringModel();
    const snapshot: AuthoringSceneSnapshot = model.createSceneSnapshot();
    // Simulate runtime mutating a handle — authoring must be untouched
    const rootId = snapshot.rootNodeId;
    const snapNode = snapshot.nodes[rootId];

    // Mutate the snapshot node's transform (simulating runtime physics)
    const runtimeHandle: RuntimeInstanceHandle = {
      id: `rt-${rootId}`,
      persistentNodeId: rootId,
      name: snapNode?.name ?? 'root',
      type: snapNode?.type ?? 'Spatial',
      transform: { position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1] },
      properties: {},
      tags: [],
      visible: true,
      disposed: false,
    };
    runtimeHandle.transform.position = [9999, 8888, 7777];

    // AuthoringModel must be untouched
    const authoringPos = model.getNode(rootId)?.transform?.position;
    const authoringUntouched = !Array.isArray(authoringPos) || authoringPos[0] !== 9999;

    checks.push({
      label: 'AIS-03e-P06: R-05/P-06 Runtime handle mutation does not contaminate AuthoringModel',
      passed: authoringUntouched,
      detail: authoringUntouched ? undefined : `Authoring pos[0]=${Array.isArray(authoringPos) ? authoringPos[0] : 'N/A'}`,
    });
  }

  // ── P-05: CommandManager not used for transient UI state (selection) ────────
  // Structural check: selection actions exist in EditorStore, NOT in CommandManager.
  {
    // If CommandManager had a `selectNode` property, this would be a violation.
    const mgr = new CommandManager();
    const hasSelectionMethod = 'selectNode' in mgr || 'setSelection' in mgr;
    checks.push({
      label: 'AIS-03e-P07: P-05 CommandManager has no selection/panel methods (transient UI)',
      passed: !hasSelectionMethod,
    });
  }

  // ── Snapshot immutability: readonly contract ───────────────────────────────
  {
    const model = new AuthoringModel();
    const snap = model.createSceneSnapshot();
    // The nodes property should be a frozen/readonly object (TypeScript contract)
    // We verify the snapshot was created with snapshotId and is structurally complete.
    const hasRequiredFields =
      typeof snap.snapshotId === 'string' && snap.snapshotId.length > 0 &&
      typeof snap.sceneId === 'string' &&
      typeof snap.rootNodeId === 'string' &&
      typeof snap.nodes === 'object' &&
      typeof snap.createdAt === 'string';
    checks.push({
      label: 'AIS-03e-P08: R-05 Snapshot has complete immutable contract fields',
      passed: hasRequiredFields,
    });
  }

  const allPassed = checks.every((c) => c.passed);
  return { allPassed, results: checks };
}
