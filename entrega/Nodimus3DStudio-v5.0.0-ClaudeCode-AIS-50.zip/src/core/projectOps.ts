/**
 * AIS-32 — operações puras do Gerenciador de Projetos: nome (validação, unicidade, `applyProjectName`),
 * renomear, duplicar e a guarda de exclusão. O modal só chama estas funções; nada aqui toca em disco:
 * a gravação passa por `ProjectStorage` (decisão 2: o projeto vive no armazenamento do editor até o AIS-AP).
 */
import type { ProjectData } from '../types/project';
import { CURRENT_PROJECT_SCHEMA_VERSION } from './persistenceVersions';
import { ProjectStorage } from './projectStorage';

export const PROJECT_NAME_MAX = 120;

export interface ProjectSummary {
  id: string;
  name: string;
  location: string;
  renderer: string;
  updatedAt: string;
}

const norm = (s: string) => s.trim().toLowerCase();

/** Erro de nome (texto para o usuário) ou `null` se válido: não vazio, ≤ 120 e único na lista (ignora o próprio projeto). */
export function validateProjectName(name: string, list: readonly ProjectSummary[], selfId?: string): string | null {
  const trimmed = name.trim();
  if (!trimmed) return 'O nome não pode ficar vazio.';
  if (trimmed.length > PROJECT_NAME_MAX) return `O nome pode ter no máximo ${PROJECT_NAME_MAX} caracteres.`;
  if (list.some((p) => p.id !== selfId && norm(p.name) === norm(trimmed))) return 'Já existe um projeto com este nome.';
  return null;
}

/** "<base> (cópia)", "<base> (cópia 2)"… — o primeiro que não colide com `taken`. */
export function uniqueCopyName(base: string, taken: readonly string[]): string {
  const used = new Set(taken.map(norm));
  const root = base.trim();
  let candidate = `${root} (cópia)`;
  for (let n = 2; used.has(norm(candidate)); n++) candidate = `${root} (cópia ${n})`;
  return candidate.slice(0, PROJECT_NAME_MAX);
}

/**
 * Função ÚNICA de nome do projeto (também usada pelo AIS-32b): atualiza `name` e `settings.general.projectName` juntos.
 * `res://project.json` e a lista são regravados por `ProjectStorage.saveProject`. Não mexe em mais nada.
 */
export function applyProjectName(project: ProjectData, name: string): ProjectData {
  const trimmed = name.trim();
  return {
    ...project,
    name: trimmed,
    files: { ...project.files }, // `saveProject` regrava res://project.json: não pode mutar o mapa do original
    settings: { ...project.settings, general: { ...project.settings.general, projectName: trimmed } },
  };
}

export type OpResult<T> = { ok: true; value: T } | { ok: false; error: string };

/** Renomeia um projeto do armazenamento (ou o já em memória, quando é o aberto, via `loaded`). Não move nada. */
export function renameStoredProject(id: string, name: string, loaded?: ProjectData): OpResult<ProjectData> {
  const error = validateProjectName(name, ProjectStorage.getProjectsList(), id);
  if (error) return { ok: false, error };
  const project = loaded ?? ProjectStorage.loadProject(id);
  if (!project) return { ok: false, error: 'Projeto não encontrado no armazenamento.' };
  const renamed = applyProjectName(project, name);
  if (!ProjectStorage.saveProject(renamed)) return { ok: false, error: 'Não foi possível gravar o projeto (armazenamento cheio?).' };
  return { ok: true, value: renamed };
}

/**
 * Cópia profunda (nenhuma referência compartilhada com o original): novo `id`, nome único, datas novas.
 * Cenas, variáveis globais e `resourceId`s seguem como estão (a identidade de recurso é por projeto).
 */
export function duplicateProject(source: ProjectData, list: readonly ProjectSummary[], opts: { name?: string; location?: string } = {}): ProjectData {
  const copy = JSON.parse(JSON.stringify(source)) as ProjectData;
  const now = new Date().toISOString();
  const name = (opts.name ?? '').trim() || uniqueCopyName(source.name, list.map((p) => p.name));
  copy.id = 'proj_' + Math.random().toString(36).substring(2, 9);
  copy.name = name;
  copy.settings.general.projectName = name;
  copy.location = (opts.location ?? source.location).trim();
  copy.createdAt = now;
  copy.updatedAt = now;
  copy.schemaVersion = CURRENT_PROJECT_SCHEMA_VERSION;
  return copy;
}

/** Duplica um projeto do armazenamento e o grava (entra no topo da lista). O original não é alterado. */
export function duplicateStoredProject(id: string, opts: { name?: string; location?: string } = {}): OpResult<ProjectData> {
  const source = ProjectStorage.loadProject(id);
  if (!source) return { ok: false, error: 'Projeto não encontrado no armazenamento.' };
  const list = ProjectStorage.getProjectsList();
  if (opts.name !== undefined) {
    const error = validateProjectName(opts.name, list);
    if (error) return { ok: false, error };
  }
  const copy = duplicateProject(source, list, opts);
  if (!ProjectStorage.saveProject(copy)) return { ok: false, error: 'Não foi possível gravar a cópia (armazenamento cheio?).' };
  return { ok: true, value: copy };
}

/** O projeto aberto não pode ser excluído; qualquer outro, sim. */
export function canDeleteProject(id: string, activeId: string): { ok: true } | { ok: false; reason: string } {
  return id === activeId ? { ok: false, reason: 'feche/troque de projeto antes' } : { ok: true };
}

/** Confirmação por digitação: o texto (com trim) precisa ser igual ao nome do projeto. */
export function deleteConfirmationMatches(typed: string, projectName: string): boolean {
  return typed.trim() === projectName;
}

export const DELETE_PROJECT_NOTICE =
  'Remove o projeto do Nodimus (armazenamento local do editor). Arquivos exportados (.nodimus) e pastas no disco não são afetados.';

/** Exclui do armazenamento do editor (nunca do disco). Recusa o projeto aberto. */
export function deleteStoredProject(id: string, activeId: string): OpResult<null> {
  const guard = canDeleteProject(id, activeId);
  if (!guard.ok) return { ok: false, error: guard.reason };
  ProjectStorage.deleteProject(id);
  return { ok: true, value: null };
}

/** Lista ordenada do mais recente para o mais antigo (`updatedAt`). */
export function sortProjectsByRecent<T extends { updatedAt: string }>(list: readonly T[]): T[] {
  return [...list].sort((a, b) => (Date.parse(b.updatedAt) || 0) - (Date.parse(a.updatedAt) || 0));
}
