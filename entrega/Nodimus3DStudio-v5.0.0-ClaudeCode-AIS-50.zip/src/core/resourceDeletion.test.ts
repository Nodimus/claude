import { describe, expect, it } from 'vitest';
import { deleteResourceWith, moveResourceWith, planDeletion, type FileLike, type ResourceCommit, type ResourceOpsContext } from './resourceDeletion';
import { replaceUrisInText, rewriteJsonContent, unresolveRules, replaceRules, refMatches } from './resourceRewrite';
import { ResourceRegistry } from './resources/ResourceRegistry';

type F = Record<string, any>;
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
const file = (path: string, extra: F = {}): FileLike => ({ path, name: path.split('/').filter(Boolean).pop()!, isDirectory: path.endsWith('/'), updatedAt: '2026-10-02T00:00:00Z', ...extra });

function setup(files: F, active: { path: string; dirty: boolean } | null = null) {
  const project = { files: { ...files } as Record<string, FileLike>, mainScene: 'res://scenes/Main.scene.json' };
  const registry = new ResourceRegistry();
  registry.syncFromProject(project as never);
  const commits: ResourceCommit[] = [];
  const ctx: ResourceOpsContext = {
    registry,
    now: () => '2026-10-03T00:00:00Z',
    activeScene: () => active,
    io: {
      files: () => project.files,
      commit: (change) => {
        commits.push(change);
        const next = { ...project.files };
        for (const p of change.remove) delete next[p];
        for (const [p, f] of Object.entries(change.upsert)) next[p] = f;
        project.files = next;
        registry.syncFromProject(project as never); // o editor re-sincroniza a cada alteração do projeto
      },
    },
  };
  return { project, registry, ctx, commits, id: (uri: string) => registry.getByUri(uri)!.resourceId };
}

const MAT = (tex: string) => JSON.stringify({ name: 'M', albedoTexture: { id: 'res:' + tex, type: 'texture', path: tex, label: tex.split('/').pop() }, preview: tex }, null, 2) + '\n';

describe('reescrita de referências (puro)', () => {
  it('troca de caminho em texto preserva a formatação e respeita limites de nome', () => {
    const text = '{\n  "a": "res://textures/a.png",\n  "b": "res://textures/a.png.bak",\n  "c": "res://textures/a.pngx"\n}\n';
    const r = replaceUrisInText(text, [{ from: 'res://textures/a.png', to: 'res://m/a.png' }]);
    expect(r.content).toBe('{\n  "a": "res://m/a.png",\n  "b": "res://textures/a.png.bak",\n  "c": "res://textures/a.pngx"\n}\n');
    expect(replaceUrisInText('res://x/y.png', [{ from: 'res://x/', to: 'res://z/' }]).content).toBe('res://z/y.png');
  });
  it('unresolve: o ResourceRef continua, marcado unresolved; refs de outros recursos não mudam', () => {
    const content = JSON.stringify({ a: { id: 'res_1', type: 'texture', path: 'res://a.png' }, b: { id: 'res_2', type: 'texture', path: 'res://b.png' } });
    const r = rewriteJsonContent(content, 'res://m.json', unresolveRules([{ id: 'res_1', uri: 'res://a.png' }]));
    const out = JSON.parse(r.content);
    expect(out.a).toEqual({ id: 'res_1', type: 'texture', path: 'res://a.png', unresolved: true });
    expect(out.b).toEqual({ id: 'res_2', type: 'texture', path: 'res://b.png' });
    expect(rewriteJsonContent(r.content, 'res://m.json', unresolveRules([{ id: 'res_1', uri: 'res://a.png' }])).changed).toBe(false); // idempotente
  });
  it('replace: ref e caminho passam a apontar para o novo; unresolved some', () => {
    const content = JSON.stringify({ a: { id: 'res_1', type: 'texture', path: 'res://a.png', unresolved: true }, p: 'res://a.png' });
    const out = JSON.parse(rewriteJsonContent(content, 'res://m.json', replaceRules({ id: 'res_1', uri: 'res://a.png' }, { id: 'res_9', type: 'texture', path: 'res://n.png', label: 'n.png' })).content);
    expect(out.a).toEqual({ id: 'res_9', type: 'texture', path: 'res://n.png', label: 'n.png' });
    expect(out.p).toBe('res://n.png');
  });
  it('refMatches reconhece id, id legado res:<caminho> e caminho', () => {
    const r = { id: 'res_1', uri: 'res://a.png' };
    expect(refMatches({ id: 'res_1' }, r)).toBe(true);
    expect(refMatches({ id: 'res:res://a.png' }, r)).toBe(true);
    expect(refMatches({ id: 'x', path: 'res://a.png' }, r)).toBe(true);
    expect(refMatches({ id: 'x', path: 'res://b.png' }, r)).toBe(false);
  });
});

describe('excluir recurso sem dependências (AIS-29e-C01/C04)', () => {
  const base = () => setup({ 'res://textures/free.png': file('res://textures/free.png', { content: PNG }), 'res://textures/keep.png': file('res://textures/keep.png', { content: PNG }) });
  it('sem confirmação NADA é gravado; devolve o plano', async () => {
    const { ctx, commits, project } = base();
    const r = await deleteResourceWith(ctx, { path: 'res://textures/free.png' });
    expect(r).toMatchObject({ ok: false, status: 'needs_confirmation' });
    expect(commits).toHaveLength(0);
    expect(project.files['res://textures/free.png']).toBeDefined();
  });
  it('confirmado: remove só o arquivo; plano simples (sem consumidores)', async () => {
    const { ctx, commits, project } = base();
    const plan = planDeletion(ctx, 'res://textures/free.png');
    expect(plan.consumers).toEqual([]);
    expect(plan.fileCount).toBe(1);
    const r = await deleteResourceWith(ctx, { path: 'res://textures/free.png' }, { confirmed: true });
    expect(r.ok && r.removed).toEqual(['res://textures/free.png']);
    expect(commits).toHaveLength(1);
    expect(project.files['res://textures/free.png']).toBeUndefined();
    expect(project.files['res://textures/keep.png']).toBeDefined();
  });
  it('recurso inexistente e raiz', async () => {
    const { ctx } = base();
    expect(await deleteResourceWith(ctx, { path: 'res://nao/existe.png' }, { confirmed: true })).toMatchObject({ ok: false, status: 'not_found' });
    expect(await deleteResourceWith(ctx, { path: 'res://' }, { confirmed: true })).toMatchObject({ ok: false, status: 'blocked' });
  });
  it('aceita um ResourceRef (resolvido pelo registry, mesmo com o caminho velho)', async () => {
    const { ctx, registry, project } = base();
    const ref = registry.refForUri('res://textures/free.png')!;
    const r = await deleteResourceWith(ctx, { ...ref, path: 'res://caminho/velho.png' }, { confirmed: true });
    expect(r.ok).toBe(true);
    expect(project.files['res://textures/free.png']).toBeUndefined();
  });
});

describe('excluir recurso com dependências (AIS-29e-C02/C05)', () => {
  const base = (active: { path: string; dirty: boolean } | null = null) =>
    setup(
      {
        'res://textures/stone.png': file('res://textures/stone.png', { content: PNG }),
        'res://textures/other.png': file('res://textures/other.png', { content: PNG }),
        'res://materials/m.mat.json': file('res://materials/m.mat.json', { content: MAT('res://textures/stone.png') }),
        'res://scenes/Main.scene.json': file('res://scenes/Main.scene.json', { content: JSON.stringify({ nodes: { a: { id: 'a', name: 'A', type: 'MeshInstance', parentId: null, properties: { albedo: { id: 'res:res://textures/stone.png', type: 'texture', path: 'res://textures/stone.png' } } } } }) }),
      },
      active
    );
  it('o plano lista TODOS os consumidores (arquivo, campo e tipo)', () => {
    const { ctx } = base();
    const plan = planDeletion(ctx, 'res://textures/stone.png');
    expect(plan.consumers.map((c) => `${c.uri}|${c.editorOnly}`).sort()).toEqual(['res://materials/m.mat.json|false', 'res://scenes/Main.scene.json|false']);
    expect(plan.consumers.find((c) => c.uri.endsWith('m.mat.json'))).toMatchObject({ kind: 'material', via: 'albedoTexture' });
    expect(plan.canReplace).toBe(true);
    expect(plan.replaceKind).toBe('texture');
  });
  it('confirmar SEM decisão não apaga nada: exige decisão explícita', async () => {
    const { ctx, commits, project } = base();
    const r = await deleteResourceWith(ctx, { path: 'res://textures/stone.png' }, { confirmed: true });
    expect(r).toMatchObject({ ok: false, status: 'needs_decision' });
    expect(commits).toHaveLength(0);
    expect(project.files['res://textures/stone.png']).toBeDefined();
  });
  it('manter como unresolved: arquivo removido, referências PRESERVADAS e marcadas, num único commit', async () => {
    const { ctx, commits, project, registry } = base();
    const r = await deleteResourceWith(ctx, { path: 'res://textures/stone.png' }, { confirmed: true, decision: { kind: 'unresolve' } });
    expect(r.ok).toBe(true);
    expect(commits).toHaveLength(1);
    expect(project.files['res://textures/stone.png']).toBeUndefined();
    const mat = JSON.parse(project.files['res://materials/m.mat.json'].content!);
    expect(mat.albedoTexture).toMatchObject({ id: 'res:res://textures/stone.png', path: 'res://textures/stone.png', unresolved: true });
    const scene = JSON.parse(project.files['res://scenes/Main.scene.json'].content!);
    expect(scene.nodes.a.properties.albedo.unresolved).toBe(true);
    // o grafo mantém as referências não resolvidas (reparáveis)
    expect(registry.graph.getMissing().length).toBeGreaterThan(0);
    expect(registry.resolve({ id: 'res:res://textures/stone.png', path: 'res://textures/stone.png' } as never).status).toBe('unresolved');
  });
  it('substituir por outro recurso do mesmo tipo reaponta todas as referências', async () => {
    const { ctx, project, registry } = base();
    const other = registry.refForUri('res://textures/other.png')!;
    const r = await deleteResourceWith(ctx, { path: 'res://textures/stone.png' }, { confirmed: true, decision: { kind: 'replace', with: other } });
    expect(r.ok).toBe(true);
    const mat = JSON.parse(project.files['res://materials/m.mat.json'].content!);
    expect(mat.albedoTexture).toMatchObject({ id: other.id, path: 'res://textures/other.png', type: 'texture' });
    expect(mat.albedoTexture.unresolved).toBeUndefined();
    expect(mat.preview).toBe('res://textures/other.png');
    expect(registry.graph.getMissing()).toHaveLength(0);
  });
  it('substituição inválida (tipo diferente, inexistente ou o próprio excluído) é recusada sem gravar', async () => {
    const { ctx, commits, registry } = base();
    const mat = registry.refForUri('res://materials/m.mat.json')!;
    const self = registry.refForUri('res://textures/stone.png')!;
    for (const withRef of [mat, self, { id: 'res_zzz', path: 'res://x.png' }]) {
      const r = await deleteResourceWith(ctx, { path: 'res://textures/stone.png' }, { confirmed: true, decision: { kind: 'replace', with: withRef } });
      expect(r).toMatchObject({ ok: false, status: 'invalid_replacement' });
    }
    expect(commits).toHaveLength(0);
  });
  it('a cena aberta é bloqueada se for o alvo; se for só consumidora, a reescrita é ADIADA (não regravada por baixo)', async () => {
    const blocked = base({ path: 'res://scenes/Main.scene.json', dirty: false });
    expect(await deleteResourceWith(blocked.ctx, { path: 'res://scenes/Main.scene.json' }, { confirmed: true })).toMatchObject({ ok: false, status: 'blocked' });
    const { ctx, project } = base({ path: 'res://scenes/Main.scene.json', dirty: true });
    const sceneBefore = project.files['res://scenes/Main.scene.json'].content;
    const r = await deleteResourceWith(ctx, { path: 'res://textures/stone.png' }, { confirmed: true, decision: { kind: 'unresolve' } });
    expect(r.ok && r.deferred.map((d) => d.uri)).toEqual(['res://scenes/Main.scene.json']);
    expect(project.files['res://scenes/Main.scene.json'].content).toBe(sceneBefore); // arquivo da cena aberta intacto
    if (r.ok) expect(JSON.parse(r.deferred[0].rewrite(sceneBefore!)).nodes.a.properties.albedo.unresolved).toBe(true);
  });
  it('pasta: o diálogo soma conteúdo e referências de todos os filhos; excluir leva a pasta inteira', async () => {
    const { ctx, project } = setup({
      'res://t/': file('res://t/'),
      'res://t/a.png': file('res://t/a.png', { content: PNG }),
      'res://t/b.png': file('res://t/b.png', { content: PNG }),
      'res://m.mat.json': file('res://m.mat.json', { content: JSON.stringify({ x: 'res://t/a.png', y: 'res://t/b.png' }) }),
    });
    const plan = planDeletion(ctx, 'res://t/');
    expect(plan.fileCount).toBe(2);
    expect(plan.folderCount).toBe(1);
    expect(plan.consumers.map((c) => c.resourceUri).sort()).toEqual(['res://t/a.png', 'res://t/b.png']);
    expect(plan.canReplace).toBe(false);
    expect((await deleteResourceWith(ctx, { path: 'res://t/' }, { confirmed: true })).ok).toBe(false);
    const r = await deleteResourceWith(ctx, { path: 'res://t/' }, { confirmed: true, decision: { kind: 'unresolve' } });
    expect(r.ok && r.removed.sort()).toEqual(['res://t/', 'res://t/a.png', 'res://t/b.png']);
    expect(project.files['res://t/a.png']).toBeUndefined();
  });
  it('referenciadores dentro do próprio conjunto excluído não bloqueiam', async () => {
    const { ctx } = setup({
      'res://t/': file('res://t/'),
      'res://t/a.png': file('res://t/a.png', { content: PNG }),
      'res://t/m.mat.json': file('res://t/m.mat.json', { content: JSON.stringify({ x: 'res://t/a.png' }) }),
    });
    expect(planDeletion(ctx, 'res://t/').consumers).toEqual([]);
  });
});

describe('mover/renomear (AIS-29e-C03)', () => {
  const base = (active: { path: string; dirty: boolean } | null = null) =>
    setup(
      {
        'res://textures/stone.png': file('res://textures/stone.png', { content: PNG }),
        'res://m/': file('res://m/'),
        'res://materials/m.mat.json': file('res://materials/m.mat.json', { content: MAT('res://textures/stone.png') }),
        'res://scenes/Main.scene.json': file('res://scenes/Main.scene.json', { content: '{"nodes":{"a":{"id":"a","script":"res://textures/stone.png"}}}\n' }),
      },
      active
    );
  it('preserva o resourceId, atualiza as referências por caminho e mantém a formatação (um commit)', async () => {
    const { ctx, commits, project, registry, id } = base();
    const stone = id('res://textures/stone.png');
    const r = await moveResourceWith(ctx, { path: 'res://textures/stone.png' }, 'res://m/stone2.png', { confirmed: true });
    expect(r.ok).toBe(true);
    expect(commits).toHaveLength(1); // atômico
    expect(project.files['res://textures/stone.png']).toBeUndefined();
    expect(registry.getByUri('res://m/stone2.png')!.resourceId).toBe(stone);
    expect(project.files['res://m/stone2.png']).toMatchObject({ name: 'stone2.png', extension: 'png', resourceId: stone });
    const mat = project.files['res://materials/m.mat.json'].content!;
    expect(mat).toContain('"path": "res://m/stone2.png"');
    expect(mat).toContain('"id": "res:res://m/stone2.png"'); // id legado acompanha o novo caminho
    expect(mat).toContain('\n  "name": "M"'); // formatação intacta
    expect(project.files['res://scenes/Main.scene.json'].content).toBe('{"nodes":{"a":{"id":"a","script":"res://m/stone2.png"}}}\n');
    // nada ficou desatualizado no grafo e ninguém está faltando
    expect(registry.graph.getStaleReferences()).toEqual([]);
    expect(registry.graph.getMissing()).toEqual([]);
  });
  it('referência por ResourceRef (id estável) continua resolvendo depois de mover', async () => {
    const { ctx, registry, id } = base();
    const ref = registry.refForUri('res://textures/stone.png')!;
    await moveResourceWith(ctx, { path: 'res://textures/stone.png' }, 'res://m/s.png', { confirmed: true });
    const resolved = registry.resolve(ref);
    expect(resolved.status).toBe('resolved');
    if (resolved.status === 'resolved') expect(resolved.entry.resourceId).toBe(id('res://m/s.png'));
  });
  it('pasta: todos os recursos de dentro mantêm id e as referências seguem a pasta', async () => {
    const { ctx, project, registry } = setup({
      'res://a/': file('res://a/'),
      'res://a/x.png': file('res://a/x.png', { content: PNG }),
      'res://a/y.png': file('res://a/y.png', { content: PNG }),
      'res://m.mat.json': file('res://m.mat.json', { content: JSON.stringify({ x: 'res://a/x.png', y: 'res://a/y.png' }) }),
    });
    const ids = ['res://a/x.png', 'res://a/y.png'].map((u) => registry.getByUri(u)!.resourceId);
    const r = await moveResourceWith(ctx, { path: 'res://a/' }, 'res://b/', { confirmed: true });
    expect(r.ok).toBe(true);
    expect(['res://b/x.png', 'res://b/y.png'].map((u) => registry.getByUri(u)!.resourceId)).toEqual(ids);
    expect(JSON.parse(project.files['res://m.mat.json'].content!)).toEqual({ x: 'res://b/x.png', y: 'res://b/y.png' });
    expect(project.files['res://a/']).toBeUndefined();
    expect(project.files['res://b/']).toBeDefined();
  });
  it('sem confirmação nada é gravado; conflito de nome e movimento inválido são recusados', async () => {
    const { ctx, commits } = base();
    expect(await moveResourceWith(ctx, { path: 'res://textures/stone.png' }, 'res://m/s.png')).toMatchObject({ ok: false, status: 'needs_confirmation' });
    expect(await moveResourceWith(ctx, { path: 'res://textures/stone.png' }, 'res://materials/m.mat.json', { confirmed: true })).toMatchObject({ ok: false, status: 'conflict' });
    expect(await moveResourceWith(ctx, { path: 'res://m/' }, 'res://m/dentro/', { confirmed: true })).toMatchObject({ ok: false });
    expect(await moveResourceWith(ctx, { path: 'res://nao.png' }, 'res://x.png', { confirmed: true })).toMatchObject({ ok: false });
    expect(commits).toHaveLength(0);
  });
  it('referenciador que também é movido: o conteúdo reescrito vai para o novo caminho', async () => {
    const { ctx, project } = setup({
      'res://d/': file('res://d/'),
      'res://d/t.png': file('res://d/t.png', { content: PNG }),
      'res://d/m.mat.json': file('res://d/m.mat.json', { content: JSON.stringify({ a: 'res://d/t.png' }, null, 2) }),
    });
    await moveResourceWith(ctx, { path: 'res://d/' }, 'res://e/', { confirmed: true });
    expect(JSON.parse(project.files['res://e/m.mat.json'].content!)).toEqual({ a: 'res://e/t.png' });
  });
  it('cena aberta: mover com alterações é bloqueado; sem alterações o novo caminho é informado; consumidora é adiada', async () => {
    const dirty = base({ path: 'res://scenes/Main.scene.json', dirty: true });
    expect(await moveResourceWith(dirty.ctx, { path: 'res://scenes/Main.scene.json' }, 'res://scenes/Other.scene.json', { confirmed: true })).toMatchObject({ ok: false, status: 'blocked' });
    const clean = base({ path: 'res://scenes/Main.scene.json', dirty: false });
    const r = await moveResourceWith(clean.ctx, { path: 'res://scenes/Main.scene.json' }, 'res://scenes/Other.scene.json', { confirmed: true });
    expect(r.ok && r.activeSceneMovedTo).toBe('res://scenes/Other.scene.json');
    const consumer = base({ path: 'res://scenes/Main.scene.json', dirty: false });
    const before = consumer.project.files['res://scenes/Main.scene.json'].content;
    const r2 = await moveResourceWith(consumer.ctx, { path: 'res://textures/stone.png' }, 'res://m/s.png', { confirmed: true });
    expect(r2.ok && r2.deferred.map((d) => d.uri)).toEqual(['res://scenes/Main.scene.json']);
    expect(consumer.project.files['res://scenes/Main.scene.json'].content).toBe(before);
  });
  it('mover cria entradas de pasta implícitas e remove os caminhos antigos', async () => {
    const { ctx, commits } = setup({ 'res://x/y.png': file('res://x/y.png', { content: PNG }) });
    await moveResourceWith(ctx, { path: 'res://x/' }, 'res://z/', { confirmed: true });
    const c = commits[0];
    expect(Object.keys(c.upsert).sort()).toEqual(['res://z/', 'res://z/y.png']);
    expect(c.remove.sort()).toEqual(['res://x/', 'res://x/y.png']);
    expect(c.moves).toEqual([['res://x/', 'res://z/'], ['res://x/y.png', 'res://z/y.png']]);
  });
});

describe('ResourceRef unresolved (AIS-29e-C05)', () => {
  it('uma referência já marcada unresolved continua intacta ao excluir outro recurso e ao ser reparada depois', async () => {
    const { ctx, project, registry } = setup({
      'res://a.png': file('res://a.png', { content: PNG }),
      'res://m.mat.json': file('res://m.mat.json', { content: JSON.stringify({ t: { id: 'res_gone', type: 'texture', path: 'res://gone.png', unresolved: true }, u: { id: 'res:res://a.png', type: 'texture', path: 'res://a.png' } }) }),
    });
    await deleteResourceWith(ctx, { path: 'res://a.png' }, { confirmed: true, decision: { kind: 'unresolve' } });
    const mat = JSON.parse(project.files['res://m.mat.json'].content!);
    expect(mat.t).toEqual({ id: 'res_gone', type: 'texture', path: 'res://gone.png', unresolved: true });
    expect(mat.u.unresolved).toBe(true);
    // o arquivo volta ao mesmo caminho: a aresta se repara sozinha
    project.files['res://a.png'] = file('res://a.png', { content: PNG });
    registry.syncFromProject(project as never);
    expect(registry.graph.getMissing().map((e) => e.toUri)).toEqual(['res://gone.png']);
  });
});
