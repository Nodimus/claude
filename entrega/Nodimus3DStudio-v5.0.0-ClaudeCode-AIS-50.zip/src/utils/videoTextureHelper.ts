import * as THREE from 'three';
import { VideoClipSettings, VideoFilter } from '../types/video';

export interface ProceduralVideoSource {
  id: string;
  name: string;
  category: 'Cyberpunk' | 'Hologram' | 'Sci-Fi' | 'Test Pattern';
  description: string;
  duration: number; // in seconds
  renderFrame: (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    time: number,
    filters: VideoFilter
  ) => void;
}

/**
 * Built-in procedural video sources that generate real-time 60fps dynamic video streams.
 * These require zero internet connection, have no CORS issues, and provide rich visual content.
 */
export const PROCEDURAL_VIDEO_PRESETS: ProceduralVideoSource[] = [
  {
    id: 'cyberpunk_synthwave',
    name: 'Cyberpunk Neon City & Grid',
    category: 'Cyberpunk',
    description: 'Neon wireframe synthwave grid with glowing horizon sun, futuristic skyscrapers, and audio spectrum bars.',
    duration: 12,
    renderFrame: (ctx, w, h, t, filters) => {
      // Background gradient
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, '#050314');
      bgGrad.addColorStop(0.5, '#1e0836');
      bgGrad.addColorStop(0.7, '#671452');
      bgGrad.addColorStop(1, '#020008');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // Starfield / digital dust
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 60; i++) {
        const sx = ((i * 137.5) % w);
        const sy = ((i * 83.1) % (h * 0.55));
        const alpha = 0.3 + 0.7 * Math.sin(t * 3 + i);
        ctx.globalAlpha = Math.max(0.1, alpha);
        ctx.fillRect(sx, sy, 1.5, 1.5);
      }
      ctx.globalAlpha = 1.0;

      // Glowing Neon Sun on Horizon
      const horizonY = h * 0.58;
      const sunRadius = Math.min(w, h) * 0.22;
      const sunX = w * 0.5;
      const sunGrad = ctx.createRadialGradient(sunX, horizonY - 10, 5, sunX, horizonY - 10, sunRadius);
      sunGrad.addColorStop(0, '#fff475');
      sunGrad.addColorStop(0.4, '#ff0077');
      sunGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = sunGrad;
      ctx.beginPath();
      ctx.arc(sunX, horizonY - 10, sunRadius, 0, Math.PI * 2);
      ctx.fill();

      // Sun horizontal blinds/stripes
      ctx.fillStyle = '#1e0836';
      for (let s = 0; s < 7; s++) {
        const barY = horizonY - sunRadius * 0.7 + s * (sunRadius * 0.2);
        const barH = 2 + s * 1.5;
        if (barY < horizonY) {
          ctx.fillRect(sunX - sunRadius, barY, sunRadius * 2, barH);
        }
      }

      // 3D Perspective Grid
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, horizonY, w, h - horizonY);
      ctx.clip();

      ctx.fillStyle = '#0a0518';
      ctx.fillRect(0, horizonY, w, h - horizonY);

      // Perspective horizon vanishing lines
      ctx.strokeStyle = '#00f0ff';
      ctx.lineWidth = 1.5;
      ctx.shadowColor = '#00f0ff';
      ctx.shadowBlur = 8;

      const numLines = 28;
      for (let i = -numLines / 2; i <= numLines / 2; i++) {
        ctx.beginPath();
        const startX = w * 0.5 + i * (w / (numLines * 0.35));
        ctx.moveTo(w * 0.5, horizonY);
        ctx.lineTo(startX, h);
        ctx.stroke();
      }

      // Horizontal moving lines with speed
      const speed = 1.5;
      const cycle = (t * speed) % 1;
      ctx.strokeStyle = '#ff007f';
      ctx.shadowColor = '#ff007f';
      ctx.shadowBlur = 6;
      ctx.lineWidth = 2;

      for (let j = 0; j < 14; j++) {
        const norm = Math.pow((j + cycle) / 14, 2.4);
        const ly = horizonY + norm * (h - horizonY);
        ctx.beginPath();
        ctx.moveTo(0, ly);
        ctx.lineTo(w, ly);
        ctx.stroke();
      }
      ctx.restore();

      // Audio spectrum visualizer bars at bottom
      const numBars = 32;
      const barW = (w * 0.7) / numBars;
      const startBx = w * 0.15;
      for (let b = 0; b < numBars; b++) {
        const val = Math.abs(Math.sin(t * 5 + b * 0.45) * Math.cos(t * 2 + b * 0.2));
        const barH = 15 + val * 60;
        const bx = startBx + b * barW;
        const by = h - 25 - barH;

        const barGrad = ctx.createLinearGradient(0, by, 0, by + barH);
        barGrad.addColorStop(0, '#00ffff');
        barGrad.addColorStop(0.5, '#ff00aa');
        barGrad.addColorStop(1, '#3b0066');
        ctx.fillStyle = barGrad;
        ctx.fillRect(bx + 1, by, barW - 2, barH);
      }

      // Futuristic HUD overlays
      ctx.fillStyle = '#00f0ff';
      ctx.font = 'bold 13px monospace';
      ctx.fillText(`REC [LIVE]  CH-01 // 60FPS`, 24, 30);
      ctx.fillText(`TIMECODE: 00:${Math.floor(t % 60).toString().padStart(2, '0')}:${Math.floor((t * 100) % 100).toString().padStart(2, '0')}`, 24, 48);

      ctx.fillStyle = '#ff007f';
      ctx.font = 'bold 16px sans-serif';
      ctx.textAlign = 'right';
      ctx.fillText(`NODIMUS 3D VIDEO ENGINE`, w - 24, 30);
      ctx.font = '11px monospace';
      ctx.fillText(`THREE.VideoTexture READY`, w - 24, 48);
      ctx.textAlign = 'left';

      // Crosshairs / frame corners
      ctx.strokeStyle = '#00f0ff';
      ctx.lineWidth = 2;
      const cornerSize = 18;
      // Top-Left
      ctx.beginPath();
      ctx.moveTo(14, 14 + cornerSize);
      ctx.lineTo(14, 14);
      ctx.lineTo(14 + cornerSize, 14);
      ctx.stroke();
      // Top-Right
      ctx.beginPath();
      ctx.moveTo(w - 14 - cornerSize, 14);
      ctx.lineTo(w - 14, 14);
      ctx.lineTo(w - 14, 14 + cornerSize);
      ctx.stroke();
      // Bottom-Left
      ctx.beginPath();
      ctx.moveTo(14, h - 14 - cornerSize);
      ctx.lineTo(14, h - 14);
      ctx.lineTo(14 + cornerSize, h - 14);
      ctx.stroke();
      // Bottom-Right
      ctx.beginPath();
      ctx.moveTo(w - 14 - cornerSize, h - 14);
      ctx.lineTo(w - 14, h - 14);
      ctx.lineTo(w - 14, h - 14 - cornerSize);
      ctx.stroke();
    },
  },
  {
    id: 'matrix_hologram',
    name: 'Matrix Digital Rain & Hologram Wireframe',
    category: 'Hologram',
    description: 'Cascading digital phosphor code stream with floating 3D rotating holographic wireframe cube.',
    duration: 10,
    renderFrame: (ctx, w, h, t, filters) => {
      // Dark emerald background
      ctx.fillStyle = '#010c05';
      ctx.fillRect(0, 0, w, h);

      // Rain columns
      const cols = 45;
      const colWidth = w / cols;
      ctx.font = 'bold 13px monospace';

      for (let c = 0; c < cols; c++) {
        const speed = 0.8 + ((c * 17) % 10) * 0.15;
        const colY = ((t * speed * 220 + c * 45) % (h + 200)) - 100;
        const charCount = 14;

        for (let i = 0; i < charCount; i++) {
          const cy = colY - i * 16;
          if (cy > 0 && cy < h) {
            const charCode = 65 + ((c * 7 + i * 13 + Math.floor(t * 8)) % 26);
            const char = String.fromCharCode(charCode);

            if (i === 0) {
              ctx.fillStyle = '#ffffff';
              ctx.shadowColor = '#00ff66';
              ctx.shadowBlur = 10;
            } else if (i < 4) {
              ctx.fillStyle = '#55ff88';
              ctx.shadowBlur = 4;
            } else {
              const alpha = Math.max(0.1, 1 - i / charCount);
              ctx.fillStyle = `rgba(0, 200, 80, ${alpha})`;
              ctx.shadowBlur = 0;
            }
            ctx.fillText(char, c * colWidth + 4, cy);
          }
        }
      }
      ctx.shadowBlur = 0;

      // Center floating rotating holographic wireframe cube
      const cx = w * 0.5;
      const cy = h * 0.5;
      const cubeSize = Math.min(w, h) * 0.22;

      ctx.save();
      ctx.translate(cx, cy);

      const angleX = t * 1.2;
      const angleY = t * 1.6;

      // Project 8 vertices of cube in 3D
      const verts: [number, number, number][] = [
        [-1, -1, -1],
        [1, -1, -1],
        [1, 1, -1],
        [-1, 1, -1],
        [-1, -1, 1],
        [1, -1, 1],
        [1, 1, 1],
        [-1, 1, 1],
      ];

      const projected = verts.map(([vx, vy, vz]) => {
        // Rotate Y
        let x1 = vx * Math.cos(angleY) - vz * Math.sin(angleY);
        let z1 = vx * Math.sin(angleY) + vz * Math.cos(angleY);
        // Rotate X
        let y2 = vy * Math.cos(angleX) - z1 * Math.sin(angleX);
        let z2 = vy * Math.sin(angleX) + z1 * Math.cos(angleX);

        const fov = 3.5;
        const scale = fov / (fov + z2);
        return {
          x: x1 * cubeSize * scale,
          y: y2 * cubeSize * scale,
          z: z2,
        };
      });

      // Draw cube edges
      const edges = [
        [0, 1], [1, 2], [2, 3], [3, 0], // back
        [4, 5], [5, 6], [6, 7], [7, 4], // front
        [0, 4], [1, 5], [2, 6], [3, 7], // connectors
      ];

      ctx.strokeStyle = '#00ffaa';
      ctx.shadowColor = '#00ffaa';
      ctx.shadowBlur = 12;
      ctx.lineWidth = 2.5;

      for (const [p1, p2] of edges) {
        ctx.beginPath();
        ctx.moveTo(projected[p1].x, projected[p1].y);
        ctx.lineTo(projected[p2].x, projected[p2].y);
        ctx.stroke();
      }

      // Center glowing holographic core
      const corePulse = 0.7 + 0.3 * Math.sin(t * 6);
      const radGrad = ctx.createRadialGradient(0, 0, 2, 0, 0, cubeSize * 0.6);
      radGrad.addColorStop(0, 'rgba(0, 255, 170, 0.4)');
      radGrad.addColorStop(0.5, 'rgba(0, 255, 100, 0.15)');
      radGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = radGrad;
      ctx.beginPath();
      ctx.arc(0, 0, cubeSize * 0.6 * corePulse, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();

      // UI Banner
      ctx.fillStyle = '#00ffaa';
      ctx.font = 'bold 12px monospace';
      ctx.fillText('SYSTEM STATUS: HOLOGRAM_STREAM_ONLINE', 20, h - 24);
      ctx.textAlign = 'right';
      ctx.fillText('NODE_ID: #89X-V3D', w - 20, h - 24);
      ctx.textAlign = 'left';
    },
  },
  {
    id: 'cosmic_nebula',
    name: 'Cosmic Nebula & Galactic Vortex',
    category: 'Sci-Fi',
    description: 'Swirling deep space galaxy with stellar accretion disk, chromatic stars, and pulsing cosmic energy ring.',
    duration: 15,
    renderFrame: (ctx, w, h, t, filters) => {
      // Deep space background
      ctx.fillStyle = '#02010a';
      ctx.fillRect(0, 0, w, h);

      const cx = w * 0.5;
      const cy = h * 0.5;

      // Swirling nebula spiral arms
      const arms = 3;
      const particlesPerArm = 65;

      for (let a = 0; a < arms; a++) {
        const baseAngle = (a * (Math.PI * 2)) / arms + t * 0.35;
        for (let p = 0; p < particlesPerArm; p++) {
          const distNorm = p / particlesPerArm;
          const dist = distNorm * (Math.min(w, h) * 0.45);
          const spiralAngle = baseAngle + distNorm * 4.2;

          const px = cx + Math.cos(spiralAngle) * dist * 1.3;
          const py = cy + Math.sin(spiralAngle) * dist * 0.75; // tilted perspective

          const size = 1.2 + (1 - distNorm) * 4.5;
          const r = Math.floor(180 + Math.sin(distNorm * 5 + t) * 70);
          const g = Math.floor(80 + Math.cos(distNorm * 3) * 60);
          const b = Math.floor(220 + Math.sin(t * 2) * 35);
          const alpha = 0.2 + (1 - distNorm) * 0.7;

          ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha})`;
          ctx.beginPath();
          ctx.arc(px, py, size, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Bright galactic core
      const corePulse = 1 + 0.15 * Math.sin(t * 4);
      const coreRadius = Math.min(w, h) * 0.12 * corePulse;
      const coreGrad = ctx.createRadialGradient(cx, cy, 2, cx, cy, coreRadius);
      coreGrad.addColorStop(0, '#ffffff');
      coreGrad.addColorStop(0.3, '#ffccaa');
      coreGrad.addColorStop(0.7, '#ff3388');
      coreGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, coreRadius, 0, Math.PI * 2);
      ctx.fill();

      // Overlay text
      ctx.fillStyle = '#ff88bb';
      ctx.font = '12px sans-serif';
      ctx.fillText('SECTOR 7G // DEEP SPACE OBSERVATORY', 24, 30);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 15px monospace';
      ctx.fillText(`STELLAR FLUX: ${(98.4 + Math.sin(t * 2) * 1.2).toFixed(2)}%`, 24, 52);
    },
  },
  {
    id: 'smpte_test_pattern',
    name: 'SMPTE Broadcast Color Bars & Oscilloscope',
    category: 'Test Pattern',
    description: 'Standard TV broadcast test signal bars with audio waveform oscilloscope and sync crosshair.',
    duration: 8,
    renderFrame: (ctx, w, h, t, filters) => {
      // 7 top SMPTE bars
      const topBars = [
        '#c0c0c0', // 75% white
        '#c0c000', // yellow
        '#00c0c0', // cyan
        '#00c000', // green
        '#c000c0', // magenta
        '#c00000', // red
        '#0000c0', // blue
      ];
      const topH = h * 0.67;
      const barW = w / topBars.length;

      for (let i = 0; i < topBars.length; i++) {
        ctx.fillStyle = topBars[i];
        ctx.fillRect(i * barW, 0, barW + 1, topH);
      }

      // Middle cast bars
      const midH = h * 0.08;
      const midY = topH;
      const midBars = [
        '#0000c0', '#131313', '#c000c0', '#131313', '#00c0c0', '#131313', '#c0c0c0'
      ];
      for (let i = 0; i < midBars.length; i++) {
        ctx.fillStyle = midBars[i];
        ctx.fillRect(i * barW, midY, barW + 1, midH);
      }

      // Bottom section
      const botY = topH + midH;
      const botH = h - botY;
      ctx.fillStyle = '#101010';
      ctx.fillRect(0, botY, w, botH);

      // Oscilloscope Sine Wave at bottom
      ctx.strokeStyle = '#00ff66';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      for (let x = 0; x < w; x += 3) {
        const normX = x / w;
        const wave = Math.sin(normX * 24 + t * 12) * Math.cos(normX * 8 + t * 4);
        const y = botY + botH * 0.5 + wave * (botH * 0.35);
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Center crosshair and timecode box
      ctx.fillStyle = 'rgba(0,0,0,0.75)';
      ctx.fillRect(w * 0.5 - 120, h * 0.5 - 30, 240, 60);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(w * 0.5 - 120, h * 0.5 - 30, 240, 60);

      ctx.fillStyle = '#ffff00';
      ctx.font = 'bold 20px monospace';
      ctx.textAlign = 'center';
      const sec = Math.floor(t % 60).toString().padStart(2, '0');
      const ms = Math.floor((t * 100) % 100).toString().padStart(2, '0');
      ctx.fillText(`1000Hz // 00:${sec}:${ms}`, w * 0.5, h * 0.5 + 6);
      ctx.textAlign = 'left';
    },
  },
];

/**
 * Creates a Three.js material configured for video display.
 * Supports standard PBR MeshStandardMaterial or MeshPhysicalMaterial with emissiveMap,
 * roughness, metalness, and double-sided rendering.
 */
export function createThreeVideoMaterial(
  texture: THREE.Texture,
  settings: VideoClipSettings
): THREE.MeshStandardMaterial {
  const mat = new THREE.MeshStandardMaterial({
    map: texture,
    emissive: new THREE.Color(0xffffff),
    emissiveMap: texture,
    emissiveIntensity: settings.emissiveIntensity,
    roughness: settings.roughness,
    metalness: settings.metalness,
    side: THREE.DoubleSide,
    toneMapped: false, // Ensures glowing vibrant colors on screens
  });

  return mat;
}

/**
 * Generates ready-to-use Three.js JavaScript snippet
 */
export function generateThreeJsVideoSnippet(settings: VideoClipSettings): string {
  return `// ==========================================
// Three.js VideoTexture Implementation
// Compatible with Three.js r128+
// ==========================================
import * as THREE from 'three';

// 1. Create HTML5 Video Element
const video = document.createElement('video');
video.src = '${settings.url || 'https://assets.codepen.io/329180/cyberpunk-loop.mp4'}';
video.crossOrigin = 'anonymous';
video.loop = ${settings.loop ? 'true' : 'false'};
video.muted = ${settings.muted ? 'true' : 'false'};
video.playbackRate = ${settings.playbackRate};
video.playsInline = true;

// Autoplay handling (required by modern browsers)
video.play().catch((err) => {
  console.warn('Click page to trigger video playback:', err);
  window.addEventListener('click', () => video.play(), { once: true });
});

// 2. Wrap in Three.js VideoTexture
const videoTexture = new THREE.VideoTexture(video);
videoTexture.minFilter = THREE.LinearFilter;
videoTexture.magFilter = THREE.LinearFilter;
videoTexture.format = THREE.RGBAFormat;
videoTexture.generateMipmaps = false;
videoTexture.colorSpace = THREE.SRGBColorSpace;

// 3. Create Screen Material (PBR with Emissive Glow)
const videoMaterial = new THREE.MeshStandardMaterial({
  map: videoTexture,
  emissive: new THREE.Color(0xffffff),
  emissiveMap: videoTexture,
  emissiveIntensity: ${settings.emissiveIntensity.toFixed(2)},
  roughness: ${settings.roughness.toFixed(2)},
  metalness: ${settings.metalness.toFixed(2)},
  side: THREE.DoubleSide,
  toneMapped: false
});

// 4. Create Screen Geometry (${settings.shape} - ${settings.aspectRatio})
${getGeometrySnippet(settings.shape, settings.aspectRatio)}

const screenMesh = new THREE.Mesh(geometry, videoMaterial);
screenMesh.name = "${settings.name}";
scene.add(screenMesh);

// 5. In your render / animation loop:
function animate() {
  requestAnimationFrame(animate);
  // Three.js VideoTexture automatically updates frames when video plays!
  renderer.render(scene, camera);
}
animate();
`;
}

function getGeometrySnippet(shape: string, aspectRatio: string): string {
  const [aspectW, aspectH] = aspectRatio.split(':').map(Number);
  const ratio = (aspectW || 16) / (aspectH || 9);
  const width = 3.6;
  const height = width / ratio;

  switch (shape) {
    case 'CurvedScreen':
      return `// Curved Cinema Screen (Cylinder segment)
const geometry = new THREE.CylinderGeometry(
  4.0, 4.0, ${height.toFixed(2)}, 32, 1, true, -Math.PI / 6, Math.PI / 3
);
geometry.scale(-1, 1, 1); // Face inwards towards camera`;
    case 'Sphere360':
      return `// 360° VR Video Sphere / Dome
const geometry = new THREE.SphereGeometry(15, 60, 40);
geometry.scale(-1, 1, 1); // Invert normals for inside viewing`;
    case 'Cylinder':
      return `// Cyberpunk Column Display
const geometry = new THREE.CylinderGeometry(1.2, 1.2, ${height.toFixed(2)}, 32);`;
    case 'Cube':
      return `// Multisided Video Cube
const geometry = new THREE.BoxGeometry(2.5, 2.5, 2.5);`;
    case 'HologramBillboard':
    case 'FlatDisplay':
    default:
      return `// Flat Display Panel (${aspectRatio})
const geometry = new THREE.PlaneGeometry(${width.toFixed(2)}, ${height.toFixed(2)});`;
  }
}
