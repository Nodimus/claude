import {
  SpriteProject,
  SpriteFrame,
  SpriteAnimation,
  SpriteSheetConfig,
  DEFAULT_SPRITE_3D_SETTINGS,
} from '../types/sprite';

// Popular Retro & Pixel Art Color Palettes
export const PALETTES = {
  pico8: [
    '#000000', '#1D2B53', '#7E2553', '#008751',
    '#AB5236', '#5F574F', '#C2C3C7', '#FFF1E8',
    '#FF004D', '#FFA300', '#FFEC27', '#00E436',
    '#29ADFF', '#83769C', '#FF77A8', '#FFCCAA',
  ],
  gameboy: [
    '#0f380f', '#306230', '#8bac0f', '#9bbc0f',
  ],
  cyberpunk: [
    '#0b0d19', '#1d1934', '#3d2953', '#683668',
    '#b4437a', '#fe5b79', '#ff9770', '#ffde6a',
    '#0ef3ff', '#00b4d8', '#0077b6', '#03045e',
    '#39ff14', '#00ffc8', '#ffffff', '#222533',
  ],
  endesga32: [
    '#be4a2f', '#d77643', '#ead4aa', '#e4a672',
    '#b86f56', '#733e39', '#3e2731', '#a22633',
    '#e43b44', '#f77622', '#feae34', '#fee761',
    '#63c74d', '#3e8948', '#265c42', '#193c3e',
    '#124e89', '#0099db', '#2ce8f5', '#ffffff',
    '#c0cbdc', '#8b9bb4', '#5a6988', '#3a4466',
    '#262b44', '#181425', '#ff0044', '#68386c',
    '#b55088', '#f6757a', '#e8b796', '#c28569',
  ],
};

// Helper to draw a pixel block
function drawPixel(ctx: CanvasRenderingContext2D, x: number, y: number, color: string, scale = 1) {
  ctx.fillStyle = color;
  ctx.fillRect(Math.floor(x * scale), Math.floor(y * scale), Math.ceil(scale), Math.ceil(scale));
}

// -------------------------------------------------------------
// Generator 1: Knight / Pixel Warrior (32x32, 4 columns, 4 rows = 16 frames)
// -------------------------------------------------------------
export function generateKnightSheet(): {
  canvas: HTMLCanvasElement;
  config: SpriteSheetConfig;
  frames: SpriteFrame[];
  animations: SpriteAnimation[];
} {
  const fw = 32;
  const fh = 32;
  const cols = 4;
  const rows = 4;
  const canvas = document.createElement('canvas');
  canvas.width = fw * cols;
  canvas.height = fh * rows;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;

  // Colors
  const armor = '#8b9bb4';
  const armorShade = '#5a6988';
  const armorHighlight = '#c0cbdc';
  const skin = '#e8b796';
  const cape = '#e43b44';
  const capeShade = '#a22633';
  const sword = '#2ce8f5';
  const swordHandle = '#feae34';
  const gold = '#fee761';
  const eye = '#181425';

  const frames: SpriteFrame[] = [];
  let frameIdx = 0;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const ox = c * fw;
      const oy = r * fh;

      // Draw character frame
      // Bob offset for idle/walk
      const bob = (r === 0) ? (c % 2 === 0 ? 0 : -1) : (r === 1) ? (c % 2 === 0 ? 1 : -1) : 0;
      const legOffset = (r === 1) ? (c === 0 ? 2 : c === 1 ? 0 : c === 2 ? -2 : 0) : 0;
      const slash = (r === 2);
      const jumpY = (r === 3) ? (c === 0 ? -2 : c === 1 ? -5 : c === 2 ? -3 : 0) : 0;

      const yBase = 12 + bob + jumpY;

      // Cape behind
      ctx.fillStyle = capeShade;
      ctx.fillRect(ox + 8, oy + yBase + 4, 6, 12);
      ctx.fillStyle = cape;
      ctx.fillRect(ox + 9, oy + yBase + 3, 4, 11);

      // Head / Helmet
      ctx.fillStyle = armorHighlight;
      ctx.fillRect(ox + 12, oy + yBase - 8, 8, 2);
      ctx.fillStyle = armor;
      ctx.fillRect(ox + 11, oy + yBase - 6, 10, 8);
      // Visor slit
      ctx.fillStyle = eye;
      ctx.fillRect(ox + 15, oy + yBase - 3, 5, 2);
      // Plume / Crest
      ctx.fillStyle = cape;
      ctx.fillRect(ox + 13, oy + yBase - 11, 4, 3);
      ctx.fillStyle = gold;
      ctx.fillRect(ox + 12, oy + yBase - 8, 6, 1);

      // Face / Skin peek
      ctx.fillStyle = skin;
      ctx.fillRect(ox + 14, oy + yBase - 1, 3, 2);

      // Torso / Chestplate
      ctx.fillStyle = armor;
      ctx.fillRect(ox + 12, oy + yBase + 2, 8, 8);
      ctx.fillStyle = gold;
      ctx.fillRect(ox + 14, oy + yBase + 4, 4, 4);
      ctx.fillStyle = armorShade;
      ctx.fillRect(ox + 12, oy + yBase + 9, 8, 2);

      // Legs / Boots
      ctx.fillStyle = armorShade;
      ctx.fillRect(ox + 12 + legOffset, oy + yBase + 11, 3, 6);
      ctx.fillRect(ox + 17 - legOffset, oy + yBase + 11, 3, 6);

      // Hands & Weapon
      if (slash) {
        // Attack slash frame
        const swordAngle = c * 30;
        ctx.fillStyle = sword;
        if (c === 0) {
          // Windup
          ctx.fillRect(ox + 7, oy + yBase - 4, 3, 10);
        } else if (c === 1) {
          // Strike forward
          ctx.fillRect(ox + 20, oy + yBase + 2, 10, 3);
          // Energy swoosh
          ctx.fillStyle = '#2ce8f588';
          ctx.fillRect(ox + 22, oy + yBase - 3, 8, 12);
        } else if (c === 2) {
          // Follow through
          ctx.fillStyle = sword;
          ctx.fillRect(ox + 22, oy + yBase + 7, 8, 3);
        } else {
          // Recover
          ctx.fillRect(ox + 19, oy + yBase + 2, 4, 6);
        }
      } else {
        // Normal hand with shield and idle sword
        ctx.fillStyle = armorHighlight;
        ctx.fillRect(ox + 9, oy + yBase + 4, 4, 6); // shield
        ctx.fillStyle = gold;
        ctx.fillRect(ox + 10, oy + yBase + 6, 2, 2);

        // Sword blade
        ctx.fillStyle = sword;
        ctx.fillRect(ox + 21, oy + yBase + 1, 2, 8);
        ctx.fillStyle = swordHandle;
        ctx.fillRect(ox + 20, oy + yBase + 9, 4, 2);
      }

      frames.push({
        id: `frame_${frameIdx}`,
        index: frameIdx,
        x: ox,
        y: oy,
        width: fw,
        height: fh,
        durationMs: 100,
        customDataUrl: canvas.toDataURL(),
      });
      frameIdx++;
    }
  }

  const config: SpriteSheetConfig = {
    name: 'Knight_Warrior_32x32',
    imageUrl: canvas.toDataURL('image/png'),
    imageWidth: canvas.width,
    imageHeight: canvas.height,
    frameWidth: fw,
    frameHeight: fh,
    columns: cols,
    rows: rows,
    spacing: 0,
    margin: 0,
    totalFrames: cols * rows,
  };

  const animations: SpriteAnimation[] = [
    { id: 'anim_idle', name: 'idle', frameIndices: [0, 1, 2, 3], fps: 6, loopMode: 'loop' },
    { id: 'anim_walk', name: 'walk', frameIndices: [4, 5, 6, 7], fps: 8, loopMode: 'loop' },
    { id: 'anim_attack', name: 'attack', frameIndices: [8, 9, 10, 11], fps: 12, loopMode: 'once' },
    { id: 'anim_jump', name: 'jump', frameIndices: [12, 13, 14, 15], fps: 8, loopMode: 'ping-pong' },
  ];

  return { canvas, config, frames, animations };
}

// -------------------------------------------------------------
// Generator 2: Sci-Fi Drone & Robot (32x32, 4 columns, 3 rows = 12 frames)
// -------------------------------------------------------------
export function generateDroneSheet(): {
  canvas: HTMLCanvasElement;
  config: SpriteSheetConfig;
  frames: SpriteFrame[];
  animations: SpriteAnimation[];
} {
  const fw = 32;
  const fh = 32;
  const cols = 4;
  const rows = 3;
  const canvas = document.createElement('canvas');
  canvas.width = fw * cols;
  canvas.height = fh * rows;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;

  const hull = '#262b44';
  const hullLight = '#5a6988';
  const glowCyan = '#2ce8f5';
  const glowOrange = '#ff9770';
  const thrusterFire = '#0ef3ff';

  const frames: SpriteFrame[] = [];
  let frameIdx = 0;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const ox = c * fw;
      const oy = r * fh;
      const floatY = Math.sin((c / cols) * Math.PI * 2) * 2;
      const cy = 14 + floatY;

      // Thruster trail below
      const flameHeight = 4 + (c % 3) * 2;
      ctx.fillStyle = thrusterFire;
      ctx.fillRect(ox + 14, oy + cy + 8, 4, flameHeight);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(ox + 15, oy + cy + 8, 2, flameHeight - 2);

      // Drone Wings
      ctx.fillStyle = hullLight;
      ctx.fillRect(ox + 6, oy + cy - 1, 6, 3);
      ctx.fillRect(ox + 20, oy + cy - 1, 6, 3);

      // Wingtips glow
      ctx.fillStyle = (r === 1) ? glowOrange : glowCyan;
      ctx.fillRect(ox + 5, oy + cy - 2, 2, 5);
      ctx.fillRect(ox + 25, oy + cy - 2, 2, 5);

      // Main Hull Sphere
      ctx.fillStyle = hull;
      ctx.fillRect(ox + 11, oy + cy - 4, 10, 10);
      ctx.fillStyle = hullLight;
      ctx.fillRect(ox + 12, oy + cy - 5, 8, 1);
      ctx.fillRect(ox + 12, oy + cy + 6, 8, 1);

      // Center Scanner Eye
      const eyeCol = (r === 2) ? '#ff0044' : (r === 1) ? glowOrange : glowCyan;
      ctx.fillStyle = eyeCol;
      const eyeShift = (r === 1) ? ((c - 1.5) * 1.5) : 0;
      ctx.fillRect(ox + 14 + eyeShift, oy + cy - 1, 4, 4);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(ox + 15 + eyeShift, oy + cy, 2, 2);

      // Antenna
      ctx.fillStyle = hullLight;
      ctx.fillRect(ox + 15, oy + cy - 8, 2, 4);
      ctx.fillStyle = glowCyan;
      ctx.fillRect(ox + 14, oy + cy - 9, 4, 2);

      frames.push({
        id: `frame_${frameIdx}`,
        index: frameIdx,
        x: ox,
        y: oy,
        width: fw,
        height: fh,
        durationMs: 90,
      });
      frameIdx++;
    }
  }

  const config: SpriteSheetConfig = {
    name: 'SciFi_Drone_32x32',
    imageUrl: canvas.toDataURL('image/png'),
    imageWidth: canvas.width,
    imageHeight: canvas.height,
    frameWidth: fw,
    frameHeight: fh,
    columns: cols,
    rows: rows,
    spacing: 0,
    margin: 0,
    totalFrames: cols * rows,
  };

  const animations: SpriteAnimation[] = [
    { id: 'anim_hover', name: 'hover', frameIndices: [0, 1, 2, 3], fps: 8, loopMode: 'loop' },
    { id: 'anim_scan', name: 'scan', frameIndices: [4, 5, 6, 7], fps: 6, loopMode: 'ping-pong' },
    { id: 'anim_boost', name: 'boost', frameIndices: [8, 9, 10, 11], fps: 12, loopMode: 'loop' },
  ];

  return { canvas, config, frames, animations };
}

// -------------------------------------------------------------
// Generator 3: Dungeon Slime (24x24, 4 columns, 3 rows = 12 frames)
// -------------------------------------------------------------
export function generateSlimeSheet(): {
  canvas: HTMLCanvasElement;
  config: SpriteSheetConfig;
  frames: SpriteFrame[];
  animations: SpriteAnimation[];
} {
  const fw = 24;
  const fh = 24;
  const cols = 4;
  const rows = 3;
  const canvas = document.createElement('canvas');
  canvas.width = fw * cols;
  canvas.height = fh * rows;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;

  const slimeMain = '#63c74d';
  const slimeDark = '#3e8948';
  const slimeHighlight = '#9bbc0f';
  const eyeColor = '#181425';

  const frames: SpriteFrame[] = [];
  let frameIdx = 0;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const ox = c * fw;
      const oy = r * fh;

      let w = 14;
      let h = 10;
      let jumpY = 0;

      if (r === 0) {
        // Idle breathing
        w = c % 2 === 0 ? 14 : 16;
        h = c % 2 === 0 ? 10 : 8;
      } else if (r === 1) {
        // Jump / Bounce
        if (c === 0) { w = 18; h = 6; } // Squash
        else if (c === 1) { w = 10; h = 14; jumpY = -4; } // Stretch up
        else if (c === 2) { w = 12; h = 12; jumpY = -7; } // Peak
        else { w = 16; h = 8; jumpY = -1; } // Land
      } else {
        // Splat / Attack
        w = 12 + c * 2;
        h = 11 - c;
      }

      const bx = ox + (fw - w) / 2;
      const by = oy + fh - h - 3 + jumpY;

      // Shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
      ctx.beginPath();
      ctx.ellipse(ox + fw / 2, oy + fh - 2, w / 2 + 1, 2, 0, 0, Math.PI * 2);
      ctx.fill();

      // Slime Body
      ctx.fillStyle = slimeDark;
      ctx.fillRect(bx, by + 2, w, h - 2);
      ctx.fillRect(bx + 2, by, w - 4, h);

      ctx.fillStyle = slimeMain;
      ctx.fillRect(bx + 1, by + 2, w - 2, h - 4);
      ctx.fillRect(bx + 2, by + 1, w - 4, h - 2);

      // Highlight
      ctx.fillStyle = slimeHighlight;
      ctx.fillRect(bx + 3, by + 2, Math.max(2, w - 8), 2);
      ctx.fillRect(bx + 3, by + 4, 2, 2);

      // Cute Eyes
      ctx.fillStyle = eyeColor;
      const eyeY = by + Math.floor(h * 0.4);
      ctx.fillRect(bx + Math.floor(w * 0.3), eyeY, 2, 2);
      ctx.fillRect(bx + Math.floor(w * 0.7) - 1, eyeY, 2, 2);

      // Eye glimmer
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(bx + Math.floor(w * 0.3), eyeY, 1, 1);
      ctx.fillRect(bx + Math.floor(w * 0.7) - 1, eyeY, 1, 1);

      frames.push({
        id: `frame_${frameIdx}`,
        index: frameIdx,
        x: ox,
        y: oy,
        width: fw,
        height: fh,
        durationMs: 110,
      });
      frameIdx++;
    }
  }

  const config: SpriteSheetConfig = {
    name: 'Dungeon_Slime_24x24',
    imageUrl: canvas.toDataURL('image/png'),
    imageWidth: canvas.width,
    imageHeight: canvas.height,
    frameWidth: fw,
    frameHeight: fh,
    columns: cols,
    rows: rows,
    spacing: 0,
    margin: 0,
    totalFrames: cols * rows,
  };

  const animations: SpriteAnimation[] = [
    { id: 'anim_idle', name: 'idle', frameIndices: [0, 1, 2, 3], fps: 5, loopMode: 'loop' },
    { id: 'anim_bounce', name: 'bounce', frameIndices: [4, 5, 6, 7], fps: 8, loopMode: 'loop' },
    { id: 'anim_splat', name: 'splat', frameIndices: [8, 9, 10, 11], fps: 7, loopMode: 'ping-pong' },
  ];

  return { canvas, config, frames, animations };
}

// -------------------------------------------------------------
// Generator 4: Pixel Fire & VFX (32x32, 6 columns, 2 rows = 12 frames)
// -------------------------------------------------------------
export function generateFlameSheet(): {
  canvas: HTMLCanvasElement;
  config: SpriteSheetConfig;
  frames: SpriteFrame[];
  animations: SpriteAnimation[];
} {
  const fw = 32;
  const fh = 32;
  const cols = 6;
  const rows = 2;
  const canvas = document.createElement('canvas');
  canvas.width = fw * cols;
  canvas.height = fh * rows;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;

  const red = '#e43b44';
  const orange = '#f77622';
  const yellow = '#fee761';
  const white = '#ffffff';

  const frames: SpriteFrame[] = [];
  let frameIdx = 0;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const ox = c * fw;
      const oy = r * fh;
      const phase = (c / cols) * Math.PI * 2;

      const flameH = 14 + Math.sin(phase) * 5;
      const sway = Math.cos(phase) * 3;

      // Outer Red
      ctx.fillStyle = red;
      ctx.beginPath();
      ctx.moveTo(ox + 16 + sway, oy + 28 - flameH);
      ctx.lineTo(ox + 25, oy + 28);
      ctx.lineTo(ox + 7, oy + 28);
      ctx.closePath();
      ctx.fill();

      // Middle Orange
      ctx.fillStyle = orange;
      ctx.beginPath();
      ctx.moveTo(ox + 16 + sway * 0.7, oy + 28 - flameH * 0.75);
      ctx.lineTo(ox + 22, oy + 28);
      ctx.lineTo(ox + 10, oy + 28);
      ctx.closePath();
      ctx.fill();

      // Core Yellow
      ctx.fillStyle = yellow;
      ctx.beginPath();
      ctx.moveTo(ox + 16 + sway * 0.4, oy + 28 - flameH * 0.5);
      ctx.lineTo(ox + 19, oy + 28);
      ctx.lineTo(ox + 13, oy + 28);
      ctx.closePath();
      ctx.fill();

      // White Hot Center
      ctx.fillStyle = white;
      ctx.fillRect(ox + 15, oy + 23, 2, 4);

      // Sparks rising
      ctx.fillStyle = yellow;
      const sparkY = (oy + 28 - flameH - ((c * 4) % 10));
      ctx.fillRect(ox + 16 + (c % 4 - 2) * 3, sparkY, 2, 2);

      frames.push({
        id: `frame_${frameIdx}`,
        index: frameIdx,
        x: ox,
        y: oy,
        width: fw,
        height: fh,
        durationMs: 80,
      });
      frameIdx++;
    }
  }

  const config: SpriteSheetConfig = {
    name: 'Pixel_Fire_VFX_32x32',
    imageUrl: canvas.toDataURL('image/png'),
    imageWidth: canvas.width,
    imageHeight: canvas.height,
    frameWidth: fw,
    frameHeight: fh,
    columns: cols,
    rows: rows,
    spacing: 0,
    margin: 0,
    totalFrames: cols * rows,
  };

  const animations: SpriteAnimation[] = [
    { id: 'anim_fire_loop', name: 'flame_loop', frameIndices: [0, 1, 2, 3, 4, 5], fps: 12, loopMode: 'loop' },
    { id: 'anim_burst', name: 'flare_burst', frameIndices: [6, 7, 8, 9, 10, 11], fps: 14, loopMode: 'loop' },
  ];

  return { canvas, config, frames, animations };
}

// -------------------------------------------------------------
// Generator 5: Spinning Golden Coin / Gem (16x16, 6 columns, 1 row = 6 frames)
// -------------------------------------------------------------
export function generateCoinSheet(): {
  canvas: HTMLCanvasElement;
  config: SpriteSheetConfig;
  frames: SpriteFrame[];
  animations: SpriteAnimation[];
} {
  const fw = 16;
  const fh = 16;
  const cols = 6;
  const rows = 1;
  const canvas = document.createElement('canvas');
  canvas.width = fw * cols;
  canvas.height = fh * rows;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;

  const goldDark = '#d77643';
  const goldMid = '#feae34';
  const goldLight = '#fee761';
  const white = '#ffffff';

  const frames: SpriteFrame[] = [];
  const widths = [10, 8, 4, 2, 4, 8];

  for (let c = 0; c < cols; c++) {
    const ox = c * fw;
    const oy = 0;
    const w = widths[c];
    const bx = ox + (fw - w) / 2;
    const by = 3;
    const h = 10;

    // Coin Edge
    ctx.fillStyle = goldDark;
    ctx.fillRect(bx, by, w, h);

    // Coin Face
    ctx.fillStyle = goldMid;
    ctx.fillRect(bx + 1, by + 1, Math.max(1, w - 2), h - 2);

    // Shimmer
    if (c === 0 || c === 5) {
      ctx.fillStyle = goldLight;
      ctx.fillRect(bx + 2, by + 2, 2, 2);
      ctx.fillStyle = white;
      ctx.fillRect(bx + 3, by + 3, 1, 1);
    } else if (c === 1) {
      ctx.fillStyle = white;
      ctx.fillRect(bx + 1, by + 2, 1, 3);
    }

    frames.push({
      id: `frame_${c}`,
      index: c,
      x: ox,
      y: oy,
      width: fw,
      height: fh,
      durationMs: 90,
    });
  }

  const config: SpriteSheetConfig = {
    name: 'Spinning_Coin_16x16',
    imageUrl: canvas.toDataURL('image/png'),
    imageWidth: canvas.width,
    imageHeight: canvas.height,
    frameWidth: fw,
    frameHeight: fh,
    columns: cols,
    rows: rows,
    spacing: 0,
    margin: 0,
    totalFrames: cols,
  };

  const animations: SpriteAnimation[] = [
    { id: 'anim_spin', name: 'spin', frameIndices: [0, 1, 2, 3, 4, 5], fps: 10, loopMode: 'loop' },
  ];

  return { canvas, config, frames, animations };
}

// -------------------------------------------------------------
// Generator 6: Blank Sprite Project for custom pixel painting
// -------------------------------------------------------------
export function createBlankSpriteProject(width = 32, height = 32, frameCount = 4): SpriteProject {
  const canvas = document.createElement('canvas');
  canvas.width = width * frameCount;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  const frames: SpriteFrame[] = [];
  for (let i = 0; i < frameCount; i++) {
    frames.push({
      id: `frame_${i}`,
      index: i,
      x: i * width,
      y: 0,
      width,
      height,
      durationMs: 100,
    });
  }

  return {
    id: `sprite_${Date.now()}`,
    name: 'New_Sprite_Animation',
    sheetConfig: {
      name: 'New_Sprite_Sheet',
      imageUrl: canvas.toDataURL('image/png'),
      imageWidth: canvas.width,
      imageHeight: canvas.height,
      frameWidth: width,
      frameHeight: height,
      columns: frameCount,
      rows: 1,
      spacing: 0,
      margin: 0,
      totalFrames: frameCount,
    },
    frames,
    animations: [
      {
        id: 'anim_default',
        name: 'idle',
        frameIndices: frames.map((_, idx) => idx),
        fps: 8,
        loopMode: 'loop',
      },
    ],
    activeAnimationId: 'anim_default',
    currentFrameIndex: 0,
    settings3D: { ...DEFAULT_SPRITE_3D_SETTINGS },
    palette: [...PALETTES.pico8],
  };
}

// -------------------------------------------------------------
// Preset Catalog
// -------------------------------------------------------------
export interface PresetItem {
  id: string;
  name: string;
  category: string;
  description: string;
  create: () => SpriteProject;
}

export const SPRITE_PRESETS: PresetItem[] = [
  {
    id: 'knight',
    name: 'Guerreiro / Cavaleiro Pixel (Knight)',
    category: 'Personagens',
    description: 'Heroi animado com Idle, Caminhar, Ataque de Espada e Pulo (32x32).',
    create: () => {
      const res = generateKnightSheet();
      return {
        id: 'proj_knight',
        name: 'Knight_Hero',
        sheetConfig: res.config,
        frames: res.frames,
        animations: res.animations,
        activeAnimationId: res.animations[0].id,
        currentFrameIndex: 0,
        settings3D: {
          ...DEFAULT_SPRITE_3D_SETTINGS,
          billboardMode: 'spherical',
          renderScale: { x: 1.8, y: 1.8 },
        },
        palette: [...PALETTES.endesga32],
      };
    },
  },
  {
    id: 'drone',
    name: 'Drone Sci-Fi & Robô',
    category: 'Sci-Fi / Mecha',
    description: 'Robô flutuante com propulsor azul, scan de mira e asas com LED (32x32).',
    create: () => {
      const res = generateDroneSheet();
      return {
        id: 'proj_drone',
        name: 'SciFi_Drone',
        sheetConfig: res.config,
        frames: res.frames,
        animations: res.animations,
        activeAnimationId: res.animations[0].id,
        currentFrameIndex: 0,
        settings3D: {
          ...DEFAULT_SPRITE_3D_SETTINGS,
          billboardMode: 'spherical',
          renderScale: { x: 1.6, y: 1.6 },
          emissiveIntensity: 0.5,
          emissiveColor: '#0ef3ff',
        },
        palette: [...PALETTES.cyberpunk],
      };
    },
  },
  {
    id: 'slime',
    name: 'Slime de Masmorra (Dungeon Slime)',
    category: 'Monstros & Inimigos',
    description: 'Slime gelatinoso clássico com squash & stretch e pulo elástico (24x24).',
    create: () => {
      const res = generateSlimeSheet();
      return {
        id: 'proj_slime',
        name: 'Green_Slime',
        sheetConfig: res.config,
        frames: res.frames,
        animations: res.animations,
        activeAnimationId: res.animations[0].id,
        currentFrameIndex: 0,
        settings3D: {
          ...DEFAULT_SPRITE_3D_SETTINGS,
          billboardMode: 'cylindrical_y',
          renderScale: { x: 1.4, y: 1.4 },
        },
        palette: [...PALETTES.gameboy],
      };
    },
  },
  {
    id: 'flame',
    name: 'Fogo & Partícula VFX (Pixel Flame)',
    category: 'Efeitos Visuais (VFX)',
    description: 'Loop orgânico de chama ardente e faíscas brilhantes (32x32).',
    create: () => {
      const res = generateFlameSheet();
      return {
        id: 'proj_flame',
        name: 'Fire_VFX',
        sheetConfig: res.config,
        frames: res.frames,
        animations: res.animations,
        activeAnimationId: res.animations[0].id,
        currentFrameIndex: 0,
        settings3D: {
          ...DEFAULT_SPRITE_3D_SETTINGS,
          billboardMode: 'spherical',
          renderScale: { x: 1.5, y: 1.5 },
          emissiveIntensity: 0.8,
          emissiveColor: '#fee761',
        },
        palette: [...PALETTES.pico8],
      };
    },
  },
  {
    id: 'coin',
    name: 'Moeda Dourada Giratória (Item Pickup)',
    category: 'Itens & Colecionáveis',
    description: 'Moeda de ouro com reflexo metálico e rotação 3D contínua (16x16).',
    create: () => {
      const res = generateCoinSheet();
      return {
        id: 'proj_coin',
        name: 'Gold_Coin',
        sheetConfig: res.config,
        frames: res.frames,
        animations: res.animations,
        activeAnimationId: res.animations[0].id,
        currentFrameIndex: 0,
        settings3D: {
          ...DEFAULT_SPRITE_3D_SETTINGS,
          billboardMode: 'spherical',
          renderScale: { x: 1.0, y: 1.0 },
          emissiveIntensity: 0.4,
          emissiveColor: '#fee761',
        },
        palette: [...PALETTES.pico8],
      };
    },
  },
];

// -------------------------------------------------------------
// Code Generators (Three.js & Godot 4)
// -------------------------------------------------------------
export function generateThreeJsSpriteSnippet(proj: SpriteProject): string {
  const activeAnim = proj.animations.find((a) => a.id === proj.activeAnimationId) || proj.animations[0];
  const fps = activeAnim?.fps || 10;
  const cols = proj.sheetConfig.columns || 4;
  const rows = proj.sheetConfig.rows || 1;
  const fw = proj.sheetConfig.frameWidth || 32;
  const fh = proj.sheetConfig.frameHeight || 32;
  const scaleX = proj.settings3D.renderScale.x;
  const scaleY = proj.settings3D.renderScale.y;

  return `// ==============================================================
// Three.js Animated Sprite / Billboard Controller
// Asset: ${proj.name} (${fw}x${fh} px | ${cols} cols x ${rows} rows)
// Generated by Nodimus Studio Sprite Editor
// ==============================================================
import * as THREE from 'three';

export function createAnimatedSprite3D(scene, textureUrl = '${proj.sheetConfig.imageUrl ? 'res://sprites/' + proj.name + '.png' : ''}') {
  const textureLoader = new THREE.TextureLoader();
  const texture = textureLoader.load(textureUrl);

  // 1. Pixel-Art Crisp Nearest Filtering
  ${proj.settings3D.pixelPerfectFilter ? `texture.magFilter = THREE.NearestFilter;
  texture.minFilter = THREE.NearestFilter;` : `texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;`}
  texture.generateMipmaps = false;

  // 2. Spritesheet UV Tiling
  const columns = ${cols};
  const rows = ${rows};
  texture.repeat.set(1 / columns, 1 / rows);

  // 3. Material & Billboard Setup
  const spriteMaterial = new THREE.SpriteMaterial({
    map: texture,
    color: new THREE.Color(${proj.settings3D.tintColor.r}, ${proj.settings3D.tintColor.g}, ${proj.settings3D.tintColor.b}),
    transparent: true,
    alphaTest: ${proj.settings3D.alphaTest},
    depthWrite: false,
  });

  const sprite = new THREE.Sprite(spriteMaterial);
  sprite.scale.set(${scaleX}, ${scaleY}, 1.0);
  sprite.position.set(0, ${scaleY / 2}, 0);
  scene.add(sprite);

  // 4. Animation Sequencer
  const frames = [${(activeAnim?.frameIndices || [0, 1, 2, 3]).join(', ')}];
  let currentFrameIdx = 0;
  let timer = 0;
  const frameDuration = 1 / ${fps}; // ${fps} FPS

  function updateFrame(frameNumber) {
    const col = frameNumber % columns;
    const row = Math.floor(frameNumber / columns);
    // Three.js UV origin is bottom-left
    texture.offset.x = col / columns;
    texture.offset.y = (rows - 1 - row) / rows;
  }

  // Set initial frame
  updateFrame(frames[0]);

  // Call this update method in your main requestAnimationFrame render loop
  return {
    sprite,
    texture,
    update: function(delta) {
      timer += delta;
      if (timer >= frameDuration) {
        timer -= frameDuration;
        currentFrameIdx = (currentFrameIdx + 1) % frames.length;
        updateFrame(frames[currentFrameIdx]);
      }
    },
    destroy: function() {
      scene.remove(sprite);
      spriteMaterial.dispose();
      texture.dispose();
    }
  };
}

// --------------------------------------------------------------
// Usage Example in Render Loop:
// const character = createAnimatedSprite3D(scene);
// const timer = new THREE.Timer();
// function animate(timestamp) {
//   requestAnimationFrame(animate);
//   timer.update(timestamp);
//   const delta = timer.getDelta();
//   character.update(delta);
//   renderer.render(scene, camera);
// }
// ==============================================================`;
}

export function generateGodotSpriteFramesSnippet(proj: SpriteProject): string {
  const animationsData: any = {};
  proj.animations.forEach((anim) => {
    animationsData[anim.name] = {
      fps: anim.fps,
      loop: anim.loopMode === 'loop',
      frames: anim.frameIndices.map((idx) => `frame_${idx}`),
    };
  });

  return JSON.stringify(
    {
      format: 'Godot_AnimatedSprite3D_SpriteFrames',
      spritesheet: `${proj.name}.png`,
      frameSize: {
        width: proj.sheetConfig.frameWidth,
        height: proj.sheetConfig.frameHeight,
      },
      columns: proj.sheetConfig.columns,
      rows: proj.sheetConfig.rows,
      animations: animationsData,
    },
    null,
    2
  );
}
