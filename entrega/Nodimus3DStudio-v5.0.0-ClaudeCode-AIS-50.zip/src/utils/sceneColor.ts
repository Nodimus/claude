import * as THREE from 'three';

/**
 * AIS-06 — conversão única de cor autoral → THREE.Color.
 *
 * As cores dos GameNodes (`{ r, g, b }` em 0..1) são gravadas no mesmo espaço
 * que o Inspector exibe em hex, ou seja, **sRGB**. `new THREE.Color(r, g, b)`
 * trata os componentes como lineares (working space) e, com
 * `renderer.outputColorSpace = SRGBColorSpace`, o render ficava mais claro que
 * o valor exibido (ex.: #141A24 renderizava #4F5A69). Strings hex/CSS já são
 * interpretadas como sRGB pelo próprio three.
 */
export function toThreeColor(col: unknown, fallback: THREE.ColorRepresentation): THREE.Color {
  if (typeof col === 'string' && col.length > 0) return new THREE.Color(col);
  if (typeof col === 'number') return new THREE.Color(col);
  if (col && typeof col === 'object') {
    const c = col as { r?: unknown; g?: unknown; b?: unknown };
    if (typeof c.r === 'number' && typeof c.g === 'number' && typeof c.b === 'number') {
      return new THREE.Color().setRGB(c.r, c.g, c.b, THREE.SRGBColorSpace);
    }
  }
  return new THREE.Color(fallback);
}
