import * as THREE from 'three';
import { MaterialProperties } from '../types/material';
import { generateProceduralTexture } from './textureGenerator';
import { toThreeColor } from './sceneColor';

/**
 * Creates or updates a Three.js material based on MaterialProperties
 */
export function createThreeMaterial(props: MaterialProperties): THREE.Material {
  // AIS-06: componentes {r,g,b} autorais são sRGB (mesmo valor exibido no Inspector)
  const color = toThreeColor(props.color, 0xffffff);
  const emissive = toThreeColor(props.emissiveColor, 0x000000);

  let side: THREE.Side = THREE.FrontSide;
  if (props.side === 'back') side = THREE.BackSide;
  else if (props.side === 'double') side = THREE.DoubleSide;

  // Generate procedural or custom texture if type !== 'none'
  let map: THREE.Texture | undefined;
  let normalMap: THREE.Texture | undefined;

  if (props.textureType !== 'none') {
    const gen = generateProceduralTexture(props, 512);
    map = gen.threeTexture;
    if (props.enableNormalMap && gen.normalTexture) {
      normalMap = gen.normalTexture;
    }
  }

  const baseParams = {
    wireframe: props.wireframe,
    transparent: props.transparent || props.opacity < 1 || props.transmission > 0,
    opacity: props.opacity,
    side,
  };

  switch (props.shadingModel) {
    case 'Physical': {
      const mat = new THREE.MeshPhysicalMaterial({
        ...baseParams,
        color,
        roughness: props.roughness,
        metalness: props.metalness,
        emissive,
        emissiveIntensity: props.emissiveIntensity,
        clearcoat: props.clearcoat,
        clearcoatRoughness: props.clearcoatRoughness,
        transmission: props.transmission,
        ior: props.ior,
        flatShading: props.flatShading,
        map: map || null,
        normalMap: normalMap || null,
      });
      if (normalMap) {
        mat.normalScale.set(props.normalScale, props.normalScale);
      }
      return mat;
    }

    case 'Phong': {
      const mat = new THREE.MeshPhongMaterial({
        ...baseParams,
        color,
        emissive,
        shininess: (1 - props.roughness) * 100,
        flatShading: props.flatShading,
        map: map || null,
        normalMap: normalMap || null,
      });
      if (normalMap) {
        mat.normalScale.set(props.normalScale, props.normalScale);
      }
      return mat;
    }

    case 'Toon': {
      return new THREE.MeshToonMaterial({
        ...baseParams,
        color,
        emissive,
        map: map || null,
      });
    }

    case 'Basic': {
      return new THREE.MeshBasicMaterial({
        ...baseParams,
        color,
        map: map || null,
      });
    }

    case 'Standard':
    default: {
      const mat = new THREE.MeshStandardMaterial({
        ...baseParams,
        color,
        roughness: props.roughness,
        metalness: props.metalness,
        emissive,
        emissiveIntensity: props.emissiveIntensity,
        flatShading: props.flatShading,
        map: map || null,
        normalMap: normalMap || null,
      });
      if (normalMap) {
        mat.normalScale.set(props.normalScale, props.normalScale);
      }
      return mat;
    }
  }
}
