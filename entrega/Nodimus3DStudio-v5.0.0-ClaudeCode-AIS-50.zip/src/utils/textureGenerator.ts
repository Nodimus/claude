import * as THREE from 'three';
import { MaterialProperties, TexturePatternType } from '../types/material';

export interface GeneratedTextureResult {
  canvas: HTMLCanvasElement;
  dataUrl: string;
  threeTexture: THREE.CanvasTexture;
  normalTexture?: THREE.CanvasTexture;
  normalDataUrl?: string;
}

// Cache texture canvases to avoid recomputing every frame
const textureCache = new Map<string, GeneratedTextureResult>();

/**
 * Procedurally generates high-quality 2D texture maps and normal maps
 */
export function generateProceduralTexture(
  props: MaterialProperties,
  resolution: number = 512
): GeneratedTextureResult {
  const cacheKey = `${props.textureType}_${props.textureColorA}_${props.textureColorB}_${props.textureScale}_${props.uvTiling.x}_${props.uvTiling.y}_${props.enableNormalMap}_${props.normalScale}_${resolution}_${props.customImageDataUrl ? 'custom' : 'none'}`;

  if (!props.customImageDataUrl && textureCache.has(cacheKey)) {
    return textureCache.get(cacheKey)!;
  }

  const canvas = document.createElement('canvas');
  canvas.width = resolution;
  canvas.height = resolution;
  const ctx = canvas.getContext('2d')!;

  // Heightmap canvas for calculating normal maps
  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = resolution;
  heightCanvas.height = resolution;
  const heightCtx = heightCanvas.getContext('2d')!;

  const type = props.textureType;
  const colA = props.textureColorA || '#1c222e';
  const colB = props.textureColorB || '#4982ea';
  const scale = Math.max(1, props.textureScale || 4);

  // Default fill
  ctx.fillStyle = colA;
  ctx.fillRect(0, 0, resolution, resolution);
  heightCtx.fillStyle = '#000000';
  heightCtx.fillRect(0, 0, resolution, resolution);

  if (type === 'custom_image' && props.customImageDataUrl) {
    const img = new Image();
    img.src = props.customImageDataUrl;
    if (img.complete && img.naturalWidth > 0) {
      ctx.drawImage(img, 0, 0, resolution, resolution);
    }
  } else if (type === 'checkerboard') {
    const tileSize = resolution / scale;
    ctx.fillStyle = colB;
    heightCtx.fillStyle = '#ffffff';

    for (let y = 0; y < scale; y++) {
      for (let x = 0; x < scale; x++) {
        if ((x + y) % 2 === 1) {
          ctx.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
          heightCtx.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
        }
      }
    }
  } else if (type === 'grid' || type === 'cyberpunk') {
    const step = resolution / scale;

    // Background
    ctx.fillStyle = colA;
    ctx.fillRect(0, 0, resolution, resolution);
    heightCtx.fillStyle = '#101010';
    heightCtx.fillRect(0, 0, resolution, resolution);

    // Minor sub-lines
    ctx.strokeStyle = type === 'cyberpunk' ? 'rgba(0, 240, 255, 0.15)' : 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 1;
    const sub = step / 4;
    for (let i = 0; i <= resolution; i += sub) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, resolution);
      ctx.moveTo(0, i);
      ctx.lineTo(resolution, i);
      ctx.stroke();
    }

    // Main grid lines
    ctx.strokeStyle = colB;
    ctx.lineWidth = 2.5;
    heightCtx.strokeStyle = '#ffffff';
    heightCtx.lineWidth = 2.5;

    for (let i = 0; i <= resolution; i += step) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, resolution);
      ctx.moveTo(0, i);
      ctx.lineTo(resolution, i);
      ctx.stroke();

      heightCtx.beginPath();
      heightCtx.moveTo(i, 0);
      heightCtx.lineTo(i, resolution);
      heightCtx.moveTo(0, i);
      heightCtx.lineTo(resolution, i);
      heightCtx.stroke();
    }

    // Corner crosshairs / intersection nodes
    ctx.fillStyle = colB;
    heightCtx.fillStyle = '#ffffff';
    const nodeSize = 4;
    for (let y = 0; y <= resolution; y += step) {
      for (let x = 0; x <= resolution; x += step) {
        ctx.fillRect(x - nodeSize / 2, y - nodeSize / 2, nodeSize, nodeSize);
        heightCtx.fillRect(x - nodeSize / 2, y - nodeSize / 2, nodeSize, nodeSize);
      }
    }
  } else if (type === 'hex') {
    const r = resolution / (scale * 2);
    const h = r * Math.sqrt(3);

    ctx.strokeStyle = colB;
    ctx.lineWidth = 2.5;
    heightCtx.strokeStyle = '#ffffff';
    heightCtx.lineWidth = 2.5;

    for (let y = -h; y < resolution + h * 2; y += h) {
      for (let x = -r * 3; x < resolution + r * 3; x += r * 3) {
        drawHex(ctx, x, y, r);
        drawHex(ctx, x + r * 1.5, y + h / 2, r);
        drawHex(heightCtx, x, y, r);
        drawHex(heightCtx, x + r * 1.5, y + h / 2, r);
      }
    }
  } else if (type === 'brick') {
    const brickH = resolution / (scale * 2);
    const brickW = brickH * 2.2;
    const mortar = 3;

    // Mortar background
    ctx.fillStyle = colB;
    ctx.fillRect(0, 0, resolution, resolution);
    heightCtx.fillStyle = '#111111';
    heightCtx.fillRect(0, 0, resolution, resolution);

    ctx.fillStyle = colA;
    heightCtx.fillStyle = '#eeeeee';

    let row = 0;
    for (let y = 0; y < resolution + brickH; y += brickH + mortar) {
      const offsetX = (row % 2) * (brickW / 2);
      for (let x = -brickW; x < resolution + brickW; x += brickW + mortar) {
        ctx.fillRect(x + offsetX, y, brickW, brickH);
        heightCtx.fillRect(x + offsetX, y, brickW, brickH);
      }
      row++;
    }
  } else if (type === 'dots') {
    const step = resolution / scale;
    const radius = step * 0.28;

    ctx.fillStyle = colB;
    heightCtx.fillStyle = '#ffffff';

    for (let y = step / 2; y < resolution; y += step) {
      for (let x = step / 2; x < resolution; x += step) {
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();

        heightCtx.beginPath();
        heightCtx.arc(x, y, radius, 0, Math.PI * 2);
        heightCtx.fill();
      }
    }
  } else if (type === 'wood') {
    // Concentric growth rings with wavy distortion
    const imgData = ctx.createImageData(resolution, resolution);
    const heightData = heightCtx.createImageData(resolution, resolution);
    const cA = hexToRgb(colA);
    const cB = hexToRgb(colB);

    const cx = resolution * 0.45;
    const cy = resolution * 0.5;

    for (let y = 0; y < resolution; y++) {
      for (let x = 0; x < resolution; x++) {
        const dx = (x - cx) * 0.35;
        const dy = y - cy;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const wave = Math.sin(dist * 0.12 * (scale / 4) + Math.sin(x * 0.04) * 2.5);
        const t = (wave + 1) * 0.5;

        const idx = (y * resolution + x) * 4;
        imgData.data[idx] = Math.round(cA.r * (1 - t) + cB.r * t);
        imgData.data[idx + 1] = Math.round(cA.g * (1 - t) + cB.g * t);
        imgData.data[idx + 2] = Math.round(cA.b * (1 - t) + cB.b * t);
        imgData.data[idx + 3] = 255;

        const hVal = Math.round(t * 255);
        heightData.data[idx] = hVal;
        heightData.data[idx + 1] = hVal;
        heightData.data[idx + 2] = hVal;
        heightData.data[idx + 3] = 255;
      }
    }
    ctx.putImageData(imgData, 0, 0);
    heightCtx.putImageData(heightData, 0, 0);
  } else if (type === 'brushed') {
    // Anisotropic brushed metal streaks
    ctx.fillStyle = colA;
    ctx.fillRect(0, 0, resolution, resolution);
    heightCtx.fillStyle = '#808080';
    heightCtx.fillRect(0, 0, resolution, resolution);

    const cB = hexToRgb(colB);
    for (let i = 0; i < scale * 40; i++) {
      const y = Math.random() * resolution;
      const alpha = 0.05 + Math.random() * 0.15;
      const len = resolution * (0.3 + Math.random() * 0.7);
      const x = Math.random() * resolution;

      ctx.fillStyle = `rgba(${cB.r}, ${cB.g}, ${cB.b}, ${alpha})`;
      ctx.fillRect(x, y, len, 1.2);

      const hAlpha = (Math.random() - 0.5) * 60;
      heightCtx.fillStyle = `rgba(255, 255, 255, ${Math.abs(hAlpha) / 255})`;
      heightCtx.fillRect(x, y, len, 1.2);
    }
  } else if (type === 'marble') {
    const imgData = ctx.createImageData(resolution, resolution);
    const heightData = heightCtx.createImageData(resolution, resolution);
    const cA = hexToRgb(colA);
    const cB = hexToRgb(colB);

    for (let y = 0; y < resolution; y++) {
      for (let x = 0; x < resolution; x++) {
        const nx = x / resolution;
        const ny = y / resolution;
        const vein = Math.sin((nx * 4 + ny * 6) * scale * 0.8 + Math.sin(nx * 10) * 1.5 + Math.cos(ny * 8) * 1.2);
        const t = Math.pow(Math.abs(vein), 4);

        const idx = (y * resolution + x) * 4;
        imgData.data[idx] = Math.round(cA.r * (1 - t) + cB.r * t);
        imgData.data[idx + 1] = Math.round(cA.g * (1 - t) + cB.g * t);
        imgData.data[idx + 2] = Math.round(cA.b * (1 - t) + cB.b * t);
        imgData.data[idx + 3] = 255;

        const hVal = Math.round((1 - t) * 255);
        heightData.data[idx] = hVal;
        heightData.data[idx + 1] = hVal;
        heightData.data[idx + 2] = hVal;
        heightData.data[idx + 3] = 255;
      }
    }
    ctx.putImageData(imgData, 0, 0);
    heightCtx.putImageData(heightData, 0, 0);
  } else if (type === 'lava') {
    // Volcanic basalt cracks with molten lava
    ctx.fillStyle = colA;
    ctx.fillRect(0, 0, resolution, resolution);
    heightCtx.fillStyle = '#dddddd';
    heightCtx.fillRect(0, 0, resolution, resolution);

    ctx.strokeStyle = colB;
    ctx.lineWidth = 4;
    heightCtx.strokeStyle = '#000000';
    heightCtx.lineWidth = 4;

    for (let i = 0; i < scale * 4; i++) {
      ctx.beginPath();
      heightCtx.beginPath();
      let sx = Math.random() * resolution;
      let sy = Math.random() * resolution;
      ctx.moveTo(sx, sy);
      heightCtx.moveTo(sx, sy);

      for (let j = 0; j < 5; j++) {
        sx += (Math.random() - 0.5) * (resolution / 4);
        sy += (Math.random() - 0.5) * (resolution / 4);
        ctx.lineTo(sx, sy);
        heightCtx.lineTo(sx, sy);
      }
      ctx.stroke();
      heightCtx.stroke();
    }
  } else if (type === 'noise') {
    const imgData = ctx.createImageData(resolution, resolution);
    const heightData = heightCtx.createImageData(resolution, resolution);
    const cA = hexToRgb(colA);
    const cB = hexToRgb(colB);

    for (let y = 0; y < resolution; y++) {
      for (let x = 0; x < resolution; x++) {
        const val = Math.random();
        const idx = (y * resolution + x) * 4;
        imgData.data[idx] = Math.round(cA.r * (1 - val) + cB.r * val);
        imgData.data[idx + 1] = Math.round(cA.g * (1 - val) + cB.g * val);
        imgData.data[idx + 2] = Math.round(cA.b * (1 - val) + cB.b * val);
        imgData.data[idx + 3] = 255;

        const hVal = Math.round(val * 255);
        heightData.data[idx] = hVal;
        heightData.data[idx + 1] = hVal;
        heightData.data[idx + 2] = hVal;
        heightData.data[idx + 3] = 255;
      }
    }
    ctx.putImageData(imgData, 0, 0);
    heightCtx.putImageData(heightData, 0, 0);
  } else if (type === 'fabric') {
    // Tecido: trama simples (fios em X e Y alternando por cima/por baixo), determinística
    const imgData = ctx.createImageData(resolution, resolution);
    const heightData = heightCtx.createImageData(resolution, resolution);
    const cA = hexToRgb(colA);
    const cB = hexToRgb(colB);
    const period = Math.max(2, resolution / (scale * 2));

    for (let y = 0; y < resolution; y++) {
      for (let x = 0; x < resolution; x++) {
        const i = Math.floor(x / period);
        const j = Math.floor(y / period);
        const warpOnTop = (i + j) % 2 === 0;
        // perfil do fio: mais claro no centro do fio, sombra nas bordas
        const along = warpOnTop ? (x % period) / period : (y % period) / period;
        const t = 0.35 + 0.65 * Math.sin(along * Math.PI);
        const mix = warpOnTop ? t : 1 - t * 0.7;
        const idx = (y * resolution + x) * 4;
        imgData.data[idx] = Math.round(cA.r * (1 - mix) + cB.r * mix);
        imgData.data[idx + 1] = Math.round(cA.g * (1 - mix) + cB.g * mix);
        imgData.data[idx + 2] = Math.round(cA.b * (1 - mix) + cB.b * mix);
        imgData.data[idx + 3] = 255;

        const hVal = Math.round((warpOnTop ? t : t * 0.6) * 255);
        heightData.data[idx] = hVal;
        heightData.data[idx + 1] = hVal;
        heightData.data[idx + 2] = hVal;
        heightData.data[idx + 3] = 255;
      }
    }
    ctx.putImageData(imgData, 0, 0);
    heightCtx.putImageData(heightData, 0, 0);
  }

  // Create primary Three.js CanvasTexture
  const threeTexture = new THREE.CanvasTexture(canvas);
  configureTextureWrapping(threeTexture, props);

  let normalTexture: THREE.CanvasTexture | undefined;
  let normalDataUrl: string | undefined;

  // Calculate real Tangent Space Normal Map if enabled
  if (props.enableNormalMap) {
    const normalCanvas = generateNormalMapFromHeight(heightCanvas, props.normalScale || 1.0);
    normalDataUrl = normalCanvas.toDataURL('image/png');
    normalTexture = new THREE.CanvasTexture(normalCanvas);
    configureTextureWrapping(normalTexture, props);
  }

  const result: GeneratedTextureResult = {
    canvas,
    dataUrl: canvas.toDataURL('image/png'),
    threeTexture,
    normalTexture,
    normalDataUrl,
  };

  if (!props.customImageDataUrl) {
    textureCache.set(cacheKey, result);
  }

  return result;
}

function configureTextureWrapping(tex: THREE.Texture, props: MaterialProperties) {
  if (props.wrapMode === 'clamp') {
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
  } else if (props.wrapMode === 'mirror') {
    tex.wrapS = THREE.MirroredRepeatWrapping;
    tex.wrapT = THREE.MirroredRepeatWrapping;
  } else {
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
  }

  tex.repeat.set(props.uvTiling.x, props.uvTiling.y);
  tex.offset.set(props.uvOffset.x, props.uvOffset.y);
  tex.rotation = (props.uvRotation * Math.PI) / 180;
  tex.needsUpdate = true;
}

function drawHex(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.beginPath();
  for (let i = 0; i < 6; i++) {
    const angle = (i * Math.PI) / 3;
    const hx = x + r * Math.cos(angle);
    const hy = y + r * Math.sin(angle);
    if (i === 0) ctx.moveTo(hx, hy);
    else ctx.lineTo(hx, hy);
  }
  ctx.closePath();
  ctx.stroke();
}

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const sanitized = hex.replace('#', '');
  if (sanitized.length === 3) {
    return {
      r: parseInt(sanitized[0] + sanitized[0], 16),
      g: parseInt(sanitized[1] + sanitized[1], 16),
      b: parseInt(sanitized[2] + sanitized[2], 16),
    };
  }
  return {
    r: parseInt(sanitized.substring(0, 2), 16) || 0,
    g: parseInt(sanitized.substring(2, 4), 16) || 0,
    b: parseInt(sanitized.substring(4, 6), 16) || 0,
  };
}

/**
 * Computes Sobel tangent space normal vectors from heightmap data
 * Encodes [Nx, Ny, Nz] -> RGB [0.5+0.5*Nx, 0.5+0.5*Ny, 0.5+0.5*Nz]
 */
function generateNormalMapFromHeight(heightCanvas: HTMLCanvasElement, strength: number = 1.0): HTMLCanvasElement {
  const w = heightCanvas.width;
  const h = heightCanvas.height;
  const hCtx = heightCanvas.getContext('2d')!;
  const hData = hCtx.getImageData(0, 0, w, h).data;

  const normalCanvas = document.createElement('canvas');
  normalCanvas.width = w;
  normalCanvas.height = h;
  const nCtx = normalCanvas.getContext('2d')!;
  const nImgData = nCtx.createImageData(w, h);
  const nData = nImgData.data;

  const getHeight = (x: number, y: number) => {
    const wrappedX = (x + w) % w;
    const wrappedY = (y + h) % h;
    const idx = (wrappedY * w + wrappedX) * 4;
    return hData[idx] / 255;
  };

  const k = strength * 2.5;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      // Sobel operator
      const tl = getHeight(x - 1, y - 1);
      const l = getHeight(x - 1, y);
      const bl = getHeight(x - 1, y + 1);
      const tr = getHeight(x + 1, y - 1);
      const r = getHeight(x + 1, y);
      const br = getHeight(x + 1, y + 1);
      const t = getHeight(x, y - 1);
      const b = getHeight(x, y + 1);

      const dX = (tr + 2 * r + br - (tl + 2 * l + bl)) * k;
      const dY = (bl + 2 * b + br - (tl + 2 * t + tr)) * k;
      const dZ = 1.0;

      // Normalize
      const len = Math.sqrt(dX * dX + dY * dY + dZ * dZ);
      const nx = -dX / len;
      const ny = -dY / len;
      const nz = dZ / len;

      const idx = (y * w + x) * 4;
      nData[idx] = Math.round((nx * 0.5 + 0.5) * 255);
      nData[idx + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      nData[idx + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      nData[idx + 3] = 255;
    }
  }

  nCtx.putImageData(nImgData, 0, 0);
  return normalCanvas;
}
