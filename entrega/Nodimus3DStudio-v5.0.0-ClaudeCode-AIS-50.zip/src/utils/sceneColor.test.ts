import { describe, expect, it } from 'vitest';
import { toThreeColor } from './sceneColor';

describe('toThreeColor (AIS-06)', () => {
  it('interpreta {r,g,b} como sRGB: o hex de saída é o mesmo que o Inspector exibe', () => {
    const c = toThreeColor({ r: 20 / 255, g: 26 / 255, b: 36 / 255, a: 1 }, '#000000');
    expect(c.getHexString()).toBe('141a24');
  });

  it('objeto e string hex equivalentes produzem a mesma cor', () => {
    const fromObj = toThreeColor({ r: 128 / 255, g: 153 / 255, b: 191 / 255 }, '#000000');
    const fromHex = toThreeColor('#8099bf', '#000000');
    expect(fromObj.getHexString()).toBe(fromHex.getHexString());
  });

  it('usa o fallback para valores ausentes ou inválidos', () => {
    expect(toThreeColor(undefined, '#123456').getHexString()).toBe('123456');
    expect(toThreeColor({ r: 'x' }, '#123456').getHexString()).toBe('123456');
    expect(toThreeColor('', 0x123456).getHexString()).toBe('123456');
  });
});
