import React, { useState } from 'react';
import { GameNode } from '../../types/node';
import type { NodeSignalConnection } from '../../types/signal';
import { useEditor } from '../../core/EditorContext';
import { signalsEmittedBy } from '../../core/signals/emittedSignals';
import { Radio, Link2, Pencil, Unlink, ArrowRight } from 'lucide-react';
import { SignalConnectionModal } from '../modals/SignalConnectionModal';
import { connectionsOfSignal, describeConnection, newConnectionId } from '../../core/signals/signalConnections';

// `signalsEmittedBy` (registry + sinais de física `body_entered`/`body_exited` quando o nó tem Colisão) mora em `core/signals/emittedSignals`
export { signalsEmittedBy };

/**
 * AIS-27 — aba de Sinais do nó: lista os sinais emitidos, com as conexões de cada um, e abre o modal
 * "Conectar Sinal..." (novo ou edição). Conectar, editar e desconectar são Commands (Undo/Redo).
 * Executar os sinais em runtime é do AIS-57; aqui só se edita o dado autoral.
 */
export const NodeSignalsTab: React.FC<{ node: GameNode }> = ({ node }) => {
  const { activeScene, connectSignal, editSignalConnection, disconnectSignal, addLog } = useEditor();
  const signals = signalsEmittedBy(node.type, node.properties);
  const connections = node.signals || [];
  // conexões de sinais que o tipo atual não declara (dado legado) continuam visíveis e editáveis, nunca somem
  const orphanSignals = [...new Set(connections.map((c) => c.signalName))].filter((s) => !signals.includes(s));
  const shownSignals = [...signals, ...orphanSignals];

  // `null` = fechado · `{ editing: null }` = nova · `{ editing }` = edição
  const [dialog, setDialog] = useState<{ editing: NodeSignalConnection | null; signal?: string } | null>(null);

  const targetName = (id: string) => activeScene.nodes[id]?.name ?? 'Desconhecido';

  const onConfirm = (data: Omit<NodeSignalConnection, 'id'>) => {
    if (!dialog) return;
    if (dialog.editing) {
      editSignalConnection(node.id, dialog.editing, { ...data, id: dialog.editing.id });
      addLog('log', `Edited signal connection [${node.name}] ${describeConnection({ ...data, id: dialog.editing.id }, targetName(data.targetNodeId))}`);
    } else {
      const connection = { ...data, id: newConnectionId() };
      connectSignal(node.id, connection);
      addLog('log', `Connected signal [${node.name}] ${describeConnection(connection, targetName(data.targetNodeId))}`);
    }
    setDialog(null);
  };

  const disconnect = (c: NodeSignalConnection) => {
    disconnectSignal(node.id, c);
    addLog('log', `Disconnected signal [${node.name}] ${describeConnection(c, targetName(c.targetNodeId))}`);
  };

  return (
    <div className="p-3 text-xs space-y-3" data-testid="node-signals-tab">
      <button
        onClick={() => setDialog({ editing: null })}
        className="w-full bg-[#4982ea] hover:bg-[#3d72d6] text-white py-1.5 px-3 rounded flex items-center justify-center gap-1.5 text-xs font-medium transition-colors"
      >
        <Link2 className="w-3.5 h-3.5" />
        <span>Conectar Sinal...</span>
      </button>

      <div>
        <div className="text-[11px] font-semibold text-[#8b97a8] uppercase tracking-wider mb-2">Sinais do nó</div>
        <div className="space-y-1.5">
          {shownSignals.map((sig) => {
            const list = connectionsOfSignal(connections, sig);
            return (
              <div key={sig} className="bg-[#181c24] rounded border border-[#2c3345]">
                <div className="flex items-center justify-between p-2">
                  <div className="flex items-center gap-1.5">
                    <Radio className={`w-3.5 h-3.5 shrink-0 ${list.length ? 'text-emerald-400' : 'text-[#6e7b91]'}`} />
                    <span className="font-mono text-emerald-300">{sig}</span>
                    {list.length > 0 && (
                      <span className="text-[10px] px-1.5 rounded bg-[#141820] border border-[#2c3345] text-[#b8c4d6]" title={`${list.length} conexão(ões)`}>
                        {list.length}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => setDialog({ editing: null, signal: sig })}
                    className="text-[11px] text-[#9db8ee] hover:text-white"
                    title={`Conectar o sinal ${sig}`}
                  >
                    Conectar...
                  </button>
                </div>
                {list.map((c) => (
                  <div
                    key={c.id}
                    onDoubleClick={() => setDialog({ editing: c })}
                    className="flex items-center justify-between border-t border-[#2c3345] px-2 py-1.5 hover:bg-[#1b212c]"
                    title="Duplo clique para editar"
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      <ArrowRight className="w-3 h-3 text-[#8b97a8] shrink-0" />
                      <span className="text-[#dfe4ec] truncate max-w-[90px]">{targetName(c.targetNodeId)}</span>
                      <span className="font-mono text-blue-300 truncate">
                        .{c.targetMethod}({(c.arguments ?? []).map((a) => (a.type === 'string' ? JSON.stringify(a.value) : String(a.value))).join(', ')})
                      </span>
                    </div>
                    <div className="flex items-center shrink-0">
                      <button onClick={() => setDialog({ editing: c })} className="p-1 text-[#8b97a8] hover:text-white transition-colors" title="Editar" aria-label="Editar conexão">
                        <Pencil className="w-3 h-3" />
                      </button>
                      <button onClick={() => disconnect(c)} className="p-1 text-[#8b97a8] hover:text-rose-400 transition-colors" title="Desconectar" aria-label="Desconectar">
                        <Unlink className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      </div>

      {dialog && (
        <SignalConnectionModal
          // `key` reinicia o rascunho a cada abertura (nova × edição de outra conexão)
          key={dialog.editing?.id ?? `new:${dialog.signal ?? ''}`}
          node={node}
          signals={signals}
          nodes={activeScene.nodes}
          editing={dialog.editing}
          initialSignal={dialog.signal}
          onConfirm={onConfirm}
          onCancel={() => setDialog(null)}
        />
      )}
    </div>
  );
};
