import React, { useMemo, useState } from 'react';
import { Box, FolderSearch, RefreshCw, Settings2, Repeat, Search, X } from 'lucide-react';
import type { GameNode, ResourceRef } from '../../types/node';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { globalAssetPipeline, globalResourceRegistry } from '../../core/resources/global';
import { useResourceRegistryVersion } from '../../core/resources/useResources';
import { ModelThumbnail } from './ModelThumbnail';

const isRef = (v: unknown): v is ResourceRef => !!v && typeof v === 'object' && typeof (v as ResourceRef).id === 'string' && (v as ResourceRef).id.length > 0;
const nameOf = (uri: string) => uri.split('/').pop() ?? uri;
const BTN = 'px-2 py-1 rounded text-[10px] font-medium border bg-[#222a3b] hover:bg-[#2b354a] border-[#2e3b52] text-[#93a1b8] hover:text-white flex items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed';
export const MODELS_ROOT = 'res://models/';

/** Seletor de arquivo de `res://models/` (trocar modelo, ou localizar um arquivo ausente). */
const ModelPickerDialog: React.FC<{ title: string; currentId?: string; onPick: (ref: ResourceRef) => void; onClose: () => void }> = ({ title, currentId, onPick, onClose }) => {
  useResourceRegistryVersion();
  const [filter, setFilter] = useState('');
  const entries = globalResourceRegistry
    .list('mesh')
    .filter((e) => e.uri.startsWith(MODELS_ROOT) && e.uri.toLowerCase().includes(filter.trim().toLowerCase()))
    .sort((a, b) => a.uri.localeCompare(b.uri));
  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/60" role="dialog" aria-label={title} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="w-[420px] max-h-[70vh] flex flex-col rounded-lg border border-[#2c3345] bg-[#1a1e27] shadow-2xl text-[11px] text-[#dfe4ec]">
        <div className="flex items-center justify-between px-3 py-2 border-b border-[#2c3345]">
          <span className="font-semibold text-white">{title}</span>
          <button onClick={onClose} aria-label="Fechar" className="text-[#8b97a8] hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-2 border-b border-[#2c3345] flex items-center gap-1.5">
          <Search className="w-3.5 h-3.5 text-[#718096]" />
          <input autoFocus value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Filtrar modelos de res://models/" className="flex-1 bg-[#12151c] rounded border border-[#2c3345] px-2 py-1 outline-none focus:border-blue-500" />
        </div>
        <div role="listbox" aria-label="Modelos do projeto" className="flex-1 overflow-y-auto">
          {entries.length === 0 ? (
            <p className="p-3 text-[#8b97a8]">Nenhum modelo em res://models/. Importe um pelo botão "Importar 3D".</p>
          ) : (
            entries.map((e) => (
              <button
                key={e.resourceId}
                role="option"
                aria-selected={e.resourceId === currentId}
                onClick={() => {
                  const ref = globalResourceRegistry.makeRef(e.resourceId);
                  if (ref) onPick(ref);
                }}
                className={`w-full text-left px-3 py-1.5 font-mono break-all ${e.resourceId === currentId ? 'bg-[#4982ea]/30 text-white' : 'hover:bg-[#272e3d]'}`}
              >
                {e.uri}
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

/**
 * AIS-38c — seção **Modelo** do Inspector (MeshInstance com `model`): referência, miniatura e estado; trocar o arquivo (UM
 * Command, com Undo), "Editar importação…", "Reimportar" e "Mostrar no FileSystem". Referência que não resolve (`unresolved`)
 * oferece "Localizar arquivo…" — a referência nunca é apagada.
 */
export const ModelSection: React.FC<{ node: GameNode }> = ({ node }) => {
  const { changeNodeProperty, addLog } = useEditor();
  const openAssetImportWithSource = useEditorStore((s) => s.openAssetImportWithSource);
  const revealInFileSystem = useEditorStore((s) => s.revealInFileSystem);
  const version = useResourceRegistryVersion();
  const [picker, setPicker] = useState(false);
  const [busy, setBusy] = useState(false);

  const ref = isRef(node.properties.model) ? node.properties.model : null;
  const resolved = useMemo(() => (ref ? globalResourceRegistry.resolve(ref) : null), [ref, version]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!ref) return null;

  const entry = resolved?.status === 'resolved' ? resolved.entry : null;
  const state: 'ok' | 'failed' | 'unresolved' = !entry ? 'unresolved' : entry.status === 'importFailed' ? 'failed' : 'ok';
  const stateLabel = { ok: 'ok', failed: 'falha na importação (última versão válida mantida)', unresolved: 'unresolved — arquivo não encontrado' }[state];
  const stateColor = { ok: 'text-emerald-400', failed: 'text-amber-400', unresolved: 'text-rose-400' }[state];

  const reimport = () => {
    if (!entry || busy) return;
    setBusy(true);
    void globalAssetPipeline
      .reimport(entry.resourceId)
      .then((r) => addLog(r.ok ? 'log' : 'warn', r.ok ? `Reimportado ${entry.uri} (id ${entry.resourceId} preservado).` : `Falha ao reimportar ${entry.uri}: ${r.diagnostics[0]?.message ?? 'erro'}. A última versão válida foi mantida.`))
      .finally(() => setBusy(false));
  };

  return (
    <div className="px-2 pt-2" data-testid="model-section">
      <div className="rounded border border-[#252c3c] bg-[#171b23]/60 p-2 space-y-2">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-400 uppercase tracking-wider">
          <Box className="w-3.5 h-3.5" /> Modelo
        </div>
        <div className="flex items-start gap-2">
          <ModelThumbnail model={ref} />
          <div className="min-w-0 flex-1 text-[11px]">
            <div className="truncate text-white font-medium" title={entry?.uri ?? ref.path}>
              {entry ? nameOf(entry.uri) : ref.label || nameOf(ref.path ?? ref.id)}
            </div>
            <div className="truncate font-mono text-[10px] text-[#718096]" title={entry?.uri ?? ref.path}>
              {entry?.uri ?? ref.path ?? ref.id}
            </div>
            <div className={`text-[10px] ${stateColor}`} data-testid="model-state">
              Estado: {stateLabel}
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          <button onClick={() => setPicker(true)} className={BTN} title={entry ? 'Trocar o arquivo de modelo deste nó (Ctrl+Z desfaz)' : 'Escolher um arquivo de res://models/ para esta referência'}>
            {entry ? <Repeat className="w-3 h-3" /> : <FolderSearch className="w-3 h-3" />}
            {entry ? 'Trocar modelo' : 'Localizar arquivo…'}
          </button>
          <button
            onClick={() => entry && openAssetImportWithSource({ path: entry.uri, name: nameOf(entry.uri), reeditNodeId: node.id })}
            disabled={!entry}
            className={BTN}
            title={entry ? 'Reabre o importador com o arquivo e os ajustes salvos' : 'O arquivo do modelo não foi encontrado'}
          >
            <Settings2 className="w-3 h-3" /> Editar importação…
          </button>
          <button onClick={reimport} disabled={!entry || busy} className={BTN} title={entry ? 'Reimporta o arquivo com as configurações salvas (preserva o id)' : 'O arquivo do modelo não foi encontrado'}>
            <RefreshCw className={`w-3 h-3 ${busy ? 'animate-spin' : ''}`} /> Reimportar
          </button>
          <button onClick={() => entry && revealInFileSystem(entry.uri)} disabled={!entry} className={BTN} title={entry ? 'Seleciona o arquivo no painel FileSystem' : 'O arquivo do modelo não foi encontrado'}>
            <FolderSearch className="w-3 h-3" /> Mostrar no FileSystem
          </button>
        </div>
      </div>
      {picker && (
        <ModelPickerDialog
          title={entry ? 'Trocar modelo' : 'Localizar arquivo do modelo'}
          currentId={entry?.resourceId}
          onClose={() => setPicker(false)}
          onPick={(next) => {
            setPicker(false);
            if (next.id !== ref.id) changeNodeProperty(node.id, 'model', next); // UM Command (ChangeProperty): Undo devolve a referência anterior
          }}
        />
      )}
    </div>
  );
};
