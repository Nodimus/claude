import React, { useMemo } from 'react';
import { Variable } from 'lucide-react';
import type { GameNode } from '../../types/node';
import { useEditor } from '../../core/EditorContext';
import { addLocal, coerceVariableValue, localEntries, removeLocal, renameLocal, updateLocal, type VariableType } from '../../core/variableManager';
import { VariablesEditor } from '../variables/VariablesEditor';

/**
 * AIS-43 — seção "Variables" do Inspector: variáveis LOCAIS do nó (`GameNode.variables`), livres de qualquer Behavior.
 * Criar, renomear, mudar tipo/valor e excluir são Commands (Undo); renomear atualiza as referências dos Behaviors do nó e
 * excluir uma local usada avisa quem a consome. As locais são reinicializadas com o nó (não persistem entre sessões de Play).
 */
export const LocalVariablesSection: React.FC<{ node: GameNode }> = ({ node }) => {
  const { variableOps } = useEditor();
  const rows = useMemo(() => localEntries(node.variables).map((v) => ({ key: v.name, name: v.name, type: v.type, value: v.value })), [node.variables]);

  const run = (result: { ok: true; value: Record<string, any> } | { ok: false; error: string }, label: string, renames?: { from: string; to: string }[]): string | null => {
    if (!result.ok) return result.error;
    variableOps.commitLocals(node.id, result.value, label, renames);
    return null;
  };

  return (
    <div className="px-3 py-2 text-xs" data-testid="local-variables-section">
      <div className="flex items-center gap-1.5 mb-2 text-[#8b97a8] font-semibold text-[11px] uppercase tracking-wider select-none">
        <Variable className="w-3.5 h-3.5" />
        <span>Variables</span>
      </div>
      <VariablesEditor
        testId="local-vars"
        emptyHint="Nenhuma variável local. Ex.: health, ammo — #nome.atributo lê de outro objeto."
        rows={rows}
        onAdd={({ name, type, value }) => run(addLocal(node.variables, { name, type, value: value === '' ? undefined : type === 'boolean' ? value === 'true' : value }), `Add Variable ${name.trim()}`)}
        onRename={(key, to) => run(renameLocal(node.variables, key, to), `Rename Variable ${key} → ${to.trim()}`, [{ from: key, to: to.trim() }])}
        onUpdate={(key, patch) => {
          const type = patch.type ?? (rows.find((r) => r.key === key)?.type as VariableType);
          if ('value' in patch && coerceVariableValue(type, patch.value) === null) return `O valor não é ${type}.`;
          return run(updateLocal(node.variables, key, patch), patch.type ? `Change Type of ${key}` : `Set Variable ${key}`);
        }}
        onRemove={(key) => {
          variableOps.commitLocals(node.id, removeLocal(node.variables, key), `Delete Variable ${key}`);
        }}
        consumersOf={(row) => variableOps.localConsumers(node.id, row.name)}
      />
    </div>
  );
};
