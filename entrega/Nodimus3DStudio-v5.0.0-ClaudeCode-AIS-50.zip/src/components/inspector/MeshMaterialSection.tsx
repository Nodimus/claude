import React, { useEffect, useMemo, useRef, useState } from 'react';
import { GameNode } from '../../types/node';
import { useEditor } from '../../core/EditorContext';
import { globalCommandManager } from '../../core/commandManager';
import { Palette, ExternalLink, Box, Image as ImageIcon, X as XIcon, AlertTriangle } from 'lucide-react';
import {
  MATERIAL_PRESETS,
  type MaterialOverride,
  type MaterialPreset,
  type MaterialProperties,
  type ShadingModel,
  type TexturePatternType,
} from '../../types/material';
import {
  listProjectTextures,
  nodeMaterialOverride,
  patchNodeMaterial,
  presetNodeMaterial,
  readNodeMaterial,
  resolveAlbedoTexture,
  textureRefFromPath,
} from '../../core/material/nodeMaterial';
import { DraftNumberInput } from './DraftNumberInput';
import { ModelMaterialSlots } from './ModelMaterialSlots';
import { useResources } from '../../core/resources/useResources';
import { globalResourceRegistry, resourcePathOf } from '../../core/resources/global';

interface MeshMaterialSectionProps {
  node: GameNode;
}

const toHex = (n: number) =>
  Math.round(Math.max(0, Math.min(1, n)) * 255)
    .toString(16)
    .padStart(2, '0');
const colorToHex = (c: { r: number; g: number; b: number }) => `#${toHex(c.r)}${toHex(c.g)}${toHex(c.b)}`;
const hexToRgb = (hex: string) => ({
  r: parseInt(hex.slice(1, 3), 16) / 255,
  g: parseInt(hex.slice(3, 5), 16) / 255,
  b: parseInt(hex.slice(5, 7), 16) / 255,
});
const HEX_RE = /^#?([0-9a-fA-F]{6})$/;

/** Shaders oferecidos (o `Basic` do Three é o "Unlit"); `Physical` só aparece se o nó já o usa (Studio 3D). */
const SHADERS: { value: ShadingModel; label: string }[] = [
  { value: 'Standard', label: 'PBR Standard' },
  { value: 'Phong', label: 'Phong' },
  { value: 'Toon', label: 'Toon' },
  { value: 'Basic', label: 'Unlit' },
];

/** Slider contínuo: o arrasto inteiro vira UM gesto no CommandManager (uma entrada de Undo). */
const gestureProps = {
  onPointerDown: () => globalCommandManager.beginGesture(),
  onPointerUp: () => globalCommandManager.endGesture(),
  onPointerCancel: () => globalCommandManager.endGesture(),
  onBlur: () => globalCommandManager.endGesture(),
  onKeyUp: () => globalCommandManager.endGesture(),
  onKeyDown: () => globalCommandManager.beginGesture(),
};

/** Campo de cor em texto (#RRGGBB): grava em Enter/blur; entrada inválida fica em vermelho. */
const HexInput: React.FC<{ hex: string; onCommit: (hex: string) => void; label: string }> = ({ hex, onCommit, label }) => {
  const [draft, setDraft] = useState<string | null>(null);
  const [invalid, setInvalid] = useState(false);
  const commit = () => {
    if (draft === null) return;
    const m = HEX_RE.exec(draft.trim());
    if (!m) {
      setInvalid(true);
      return;
    }
    setInvalid(false);
    setDraft(null);
    const next = `#${m[1].toLowerCase()}`;
    if (next !== hex.toLowerCase()) onCommit(next);
  };
  return (
    <input
      type="text"
      value={draft ?? hex.toUpperCase()}
      aria-label={label}
      aria-invalid={invalid || undefined}
      spellCheck={false}
      maxLength={7}
      onFocus={(e) => {
        setDraft(hex.toUpperCase());
        e.currentTarget.select();
      }}
      onChange={(e) => {
        setDraft(e.target.value);
        setInvalid(false);
      }}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          commit();
          if (HEX_RE.test((draft ?? '').trim())) e.currentTarget.blur();
        } else if (e.key === 'Escape') {
          e.stopPropagation();
          setDraft(null);
          setInvalid(false);
          e.currentTarget.blur();
        }
      }}
      className={`w-[68px] bg-[#12151c] font-mono text-[11px] uppercase text-white px-1 py-0.5 rounded border outline-none ${
        invalid ? 'border-red-500 text-red-300' : 'border-[#2c3345] focus:border-[#4982ea]'
      }`}
    />
  );
};

export const MeshMaterialSection: React.FC<MeshMaterialSectionProps> = ({ node }) => {
  const { project, changeNodeProperty, setIsTexturePreviewOpen } = useEditor();
  const [textureMenuOpen, setTextureMenuOpen] = useState(false);

  const material: MaterialProperties = useMemo(() => readNodeMaterial(node.properties, node.name), [node.properties, node.name]);
  const override: MaterialOverride = useMemo(() => nodeMaterialOverride(node.properties), [node.properties]);
  // AIS-28c: o picker consulta o ResourceRegistry (não a lista de arquivos do painel) e a textura resolve pela identidade
  const textureResources = useResources('texture');
  const textures = useMemo(
    () =>
      textureResources.map((e) => {
        const content = project.files[e.uri]?.content;
        return { resourceId: e.resourceId, path: e.uri, name: e.uri.split('/').pop() || e.uri, dataUrl: typeof content === 'string' && content.startsWith('data:image') ? content : null };
      }),
    [textureResources, project.files]
  );
  const albedo = useMemo(() => resolveAlbedoTexture(override.albedoTexture, project.files, resourcePathOf), [override.albedoTexture, project.files, textureResources]);

  const { color, roughness, metalness, wireframe, textureType, shadingModel } = material;
  const hex = colorToHex(color);
  const emissiveHex = colorToHex(material.emissiveColor);

  // seletor de cor nativo emite eventos contínuos sem pointer events no popup: o gesto fecha após uma pausa
  const colorGestureTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const liveChange = (patch: Parameters<typeof patchNodeMaterial>[1]) => {
    globalCommandManager.beginGesture();
    change(patch);
    if (colorGestureTimer.current) clearTimeout(colorGestureTimer.current);
    colorGestureTimer.current = setTimeout(() => globalCommandManager.endGesture(), 500);
  };
  useEffect(
    () => () => {
      if (colorGestureTimer.current) clearTimeout(colorGestureTimer.current);
      globalCommandManager.endGesture();
    },
    []
  );

  /** Único ponto de gravação: o objeto `materialOverride` do nó, num Command (com mescla por gesto). */
  const change = (patch: Parameters<typeof patchNodeMaterial>[1]) =>
    changeNodeProperty(node.id, 'materialOverride', patchNodeMaterial(node.properties, patch));
  const applyPreset = (preset: MaterialPreset) =>
    changeNodeProperty(node.id, 'materialOverride', presetNodeMaterial(node.properties, preset));

  const albedoThumb = albedo.status === 'resolved' ? albedo.dataUrl : null;

  // Swatch style preview
  const swatchStyle = useMemo(() => {
    let bg = hex;
    if (albedoThumb) {
      bg = `center / cover url(${albedoThumb})`;
    } else if (textureType === 'checkerboard') {
      bg = `repeating-conic-gradient(${hex} 0% 25%, #181c25 0% 50%) 50% / 12px 12px`;
    } else if (textureType === 'grid' || textureType === 'cyberpunk') {
      bg = `linear-gradient(to right, #00f0ff 1px, transparent 1px) 0 0 / 10px 10px, linear-gradient(to bottom, #00f0ff 1px, ${hex} 1px) 0 0 / 10px 10px`;
    } else if (textureType === 'brick') {
      bg = `linear-gradient(335deg, ${hex} 23px, transparent 23px), linear-gradient(155deg, #181c25 23px, transparent 23px)`;
    }
    return {
      background: bg,
      boxShadow: metalness > 0.5 ? 'inset 0 0 12px rgba(255,255,255,0.4)' : undefined,
    };
  }, [hex, textureType, metalness, albedoThumb]);

  const shaderOptions = SHADERS.some((s) => s.value === shadingModel)
    ? SHADERS
    : [...SHADERS, { value: shadingModel, label: shadingModel === 'Physical' ? 'PBR Physical' : shadingModel }];

  const presetGroups = useMemo(() => {
    const groups = new Map<string, MaterialPreset[]>();
    for (const p of MATERIAL_PRESETS) groups.set(p.category, [...(groups.get(p.category) ?? []), p]);
    return [...groups.entries()];
  }, []);

  const labelCls = 'text-[#8b97a8]';

  return (
    <div className="p-3 bg-[#181c25] rounded-lg border border-[#2c3345] space-y-3 select-none my-1">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-white">
          <Palette className="w-3.5 h-3.5 text-blue-400" />
          <span>Material & Textura</span>
        </div>

        <button
          onClick={() => setIsTexturePreviewOpen(true)}
          className="flex items-center gap-1 px-2 py-0.5 rounded bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 text-[11px] transition-colors"
          title="Abrir Editor Completo com Preview 3D"
        >
          <ExternalLink className="w-3 h-3" />
          <span>Studio 3D</span>
        </button>
      </div>

      {/* AIS-35: nó com modelo 3D → um slot por material do arquivo (decisão 3.2) */}
      {node.properties.model && <ModelMaterialSlots node={node} />}

      {/* Swatch & Quick Info */}
      <div className="flex items-center gap-3 bg-[#12151c] p-2 rounded-lg border border-[#252c3c]">
        {/* Interactive Material Swatch */}
        <div
          onClick={() => setIsTexturePreviewOpen(true)}
          style={swatchStyle}
          className="w-12 h-12 rounded-lg border border-white/20 shadow-md cursor-pointer hover:scale-105 transition-transform flex items-center justify-center shrink-0 relative overflow-hidden group"
          title="Clique para abrir o Preview de Textura / Material"
        >
          {wireframe && (
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
              <Box className="w-5 h-5 text-white/80" />
            </div>
          )}
          <span className="opacity-0 group-hover:opacity-100 transition-opacity absolute inset-0 bg-black/50 text-[9px] font-bold text-white flex items-center justify-center">
            EDITAR
          </span>
        </div>

        <div className="flex-1 min-w-0 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-white font-medium truncate">{node.name}_mat</span>
            <span className="text-[10px] text-[#718096] font-mono">{shadingModel}</span>
          </div>

          <div className="flex items-center gap-2 mt-1 text-[11px] text-[#8b97a8]">
            <span className="font-mono text-white">{hex}</span>
            <span>•</span>
            <span>R: {roughness.toFixed(2)}</span>
            <span>•</span>
            <span>M: {metalness.toFixed(2)}</span>
          </div>

          <div className="text-[10px] text-blue-400 mt-0.5 capitalize">
            {albedo.status === 'resolved'
              ? `Textura: ${albedo.path.split('/').pop()}`
              : `Padrão: ${textureType === 'none' ? 'Cor sólida' : textureType}`}
          </div>
        </div>
      </div>

      <div className="space-y-2 pt-1 border-t border-[#252c3c]">
        {/* Preset */}
        <div className="flex items-center justify-between text-xs gap-2">
          <label htmlFor={`mat-preset-${node.id}`} className={labelCls}>
            Preset
          </label>
          <select
            id={`mat-preset-${node.id}`}
            value={override.presetId ?? ''}
            onChange={(e) => {
              const preset = MATERIAL_PRESETS.find((p) => p.id === e.target.value);
              if (preset) applyPreset(preset);
            }}
            className="flex-1 min-w-0 bg-[#12151c] text-white text-[11px] py-0.5 px-2 rounded border border-[#2c3345] outline-none cursor-pointer"
          >
            <option value="" disabled>
              Personalizado
            </option>
            {presetGroups.map(([category, presets]) => (
              <optgroup key={category} label={category}>
                {presets.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </optgroup>
            ))}
          </select>
        </div>

        {/* Shader */}
        <div className="flex items-center justify-between text-xs gap-2">
          <label htmlFor={`mat-shader-${node.id}`} className={labelCls}>
            Shader
          </label>
          <select
            id={`mat-shader-${node.id}`}
            value={shadingModel}
            onChange={(e) => change({ shadingModel: e.target.value as ShadingModel })}
            className="bg-[#12151c] text-white text-[11px] py-0.5 px-2 rounded border border-[#2c3345] outline-none cursor-pointer"
          >
            {shaderOptions.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </select>
        </div>

        {/* Albedo: color picker + hex */}
        <div className="flex items-center justify-between text-xs">
          <span className={labelCls}>Cor Albedo</span>
          <div className="flex items-center gap-1.5">
            <input
              type="color"
              value={hex}
              aria-label="Cor Albedo"
              onChange={(e) => liveChange({ color: { ...color, ...hexToRgb(e.target.value) } })}
              className="w-5 h-5 rounded border border-[#2c3345] bg-transparent cursor-pointer p-0"
            />
            <HexInput hex={hex} label="Cor Albedo (hex)" onCommit={(h) => change({ color: { ...color, ...hexToRgb(h) } })} />
          </div>
        </div>

        {/* Roughness */}
        <div>
          <div className="flex items-center justify-between text-[11px] mb-0.5 text-[#8b97a8]">
            <span>Rugosidade</span>
            <span className="font-mono text-white">{roughness.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={roughness}
            aria-label="Rugosidade"
            onChange={(e) => change({ roughness: parseFloat(e.target.value) })}
            {...gestureProps}
            className="w-full h-1 bg-[#2c3345] rounded appearance-none cursor-pointer accent-blue-500"
          />
        </div>

        {/* Metalness */}
        <div>
          <div className="flex items-center justify-between text-[11px] mb-0.5 text-[#8b97a8]">
            <span>Metalicidade</span>
            <span className="font-mono text-white">{metalness.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={metalness}
            aria-label="Metalicidade"
            onChange={(e) => change({ metalness: parseFloat(e.target.value) })}
            {...gestureProps}
            className="w-full h-1 bg-[#2c3345] rounded appearance-none cursor-pointer accent-amber-500"
          />
        </div>

        {/* Emissivo: cor + intensidade */}
        <div className="flex items-center justify-between text-xs gap-2">
          <span className={labelCls}>Emissivo</span>
          <div className="flex items-center gap-1.5">
            <input
              type="color"
              value={emissiveHex}
              aria-label="Cor emissiva"
              onChange={(e) => liveChange({ emissiveColor: { ...material.emissiveColor, ...hexToRgb(e.target.value) } })}
              className="w-5 h-5 rounded border border-[#2c3345] bg-transparent cursor-pointer p-0"
            />
            <DraftNumberInput
              aria-label="Intensidade emissiva"
              value={material.emissiveIntensity}
              min={0}
              max={20}
              step={0.1}
              onCommit={(v) => change({ emissiveIntensity: v })}
              className="w-14 bg-[#12151c] text-[11px] text-right font-mono text-white px-1 py-0.5 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none"
            />
          </div>
        </div>

        {/* Textura de albedo (res://textures/) com miniatura */}
        <div className="text-xs">
          <div className="flex items-center justify-between gap-2">
            <span className={labelCls}>Textura</span>
            <div className="relative flex-1 min-w-0 flex justify-end">
              <button
                type="button"
                aria-haspopup="listbox"
                aria-expanded={textureMenuOpen}
                onClick={() => setTextureMenuOpen((o) => !o)}
                className="flex items-center gap-1.5 max-w-full bg-[#12151c] text-white text-[11px] py-0.5 px-1.5 rounded border border-[#2c3345] hover:border-[#4982ea] outline-none"
                title={override.albedoTexture?.path ?? 'Escolher textura de res://textures/'}
              >
                <span className="w-4 h-4 rounded-sm overflow-hidden bg-[#1e2433] flex items-center justify-center shrink-0">
                  {albedoThumb ? <img src={albedoThumb} alt="" className="w-full h-full object-cover" /> : <ImageIcon className="w-3 h-3 text-[#637185]" />}
                </span>
                <span className="truncate">{albedo.status === 'none' ? 'Nenhuma' : albedo.path.split('/').pop()}</span>
              </button>
              {textureMenuOpen && (
                <ul
                  role="listbox"
                  aria-label="Texturas do projeto"
                  className="absolute right-0 top-full mt-1 z-20 w-56 max-h-48 overflow-y-auto bg-[#12151c] border border-[#2c3345] rounded shadow-xl py-1"
                >
                  <li>
                    <button
                      type="button"
                      role="option"
                      aria-selected={albedo.status === 'none'}
                      onClick={() => {
                        setTextureMenuOpen(false);
                        change({ albedoTexture: null });
                      }}
                      className="w-full flex items-center gap-2 px-2 py-1 text-left text-[11px] text-[#b8c4d6] hover:bg-[#1e2433]"
                    >
                      <XIcon className="w-3 h-3 text-[#637185]" />
                      Nenhuma
                    </button>
                  </li>
                  {textures.length === 0 && <li className="px-2 py-1 text-[10px] text-[#637185]">Nenhuma imagem em res://textures/</li>}
                  {textures.map((t) => (
                    <li key={t.path}>
                      <button
                        type="button"
                        role="option"
                        aria-selected={override.albedoTexture?.id === t.resourceId || override.albedoTexture?.path === t.path}
                        onClick={() => {
                          setTextureMenuOpen(false);
                          change({ albedoTexture: globalResourceRegistry.makeRef(t.resourceId) ?? textureRefFromPath(t.path) });
                        }}
                        className="w-full flex items-center gap-2 px-2 py-1 text-left text-[11px] text-white hover:bg-[#1e2433]"
                      >
                        <span className="w-8 h-8 rounded-sm overflow-hidden bg-[#1e2433] flex items-center justify-center shrink-0">
                          {t.dataUrl ? <img src={t.dataUrl} alt="" className="w-full h-full object-cover" /> : <ImageIcon className="w-4 h-4 text-[#637185]" />}
                        </span>
                        <span className="truncate">{t.name}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
          {albedo.status === 'unresolved' && (
            <div className="mt-1 flex items-center gap-1 text-[10px] text-amber-400" role="status">
              <AlertTriangle className="w-3 h-3 shrink-0" />
              <span className="truncate" title={albedo.path}>
                Textura ausente: {albedo.path.split('/').pop()} (usando o padrão)
              </span>
            </div>
          )}
        </div>

        {/* Texture Pattern quick select */}
        <div className="flex items-center justify-between text-xs">
          <span className={labelCls}>Padrão Textura</span>
          <select
            value={textureType}
            aria-label="Padrão Textura"
            onChange={(e) => change({ textureType: e.target.value as TexturePatternType })}
            className="bg-[#12151c] text-white text-[11px] py-0.5 px-2 rounded border border-[#2c3345] outline-none cursor-pointer"
          >
            <option value="none">Nenhum (Liso)</option>
            <option value="checkerboard">Xadrez (Checker)</option>
            <option value="grid">Grade Tech (Grid)</option>
            <option value="hex">Colmeia Hex</option>
            <option value="noise">Ruído (Noise)</option>
            <option value="brick">Tijolo (Brick)</option>
            <option value="wood">Madeira (Wood)</option>
            <option value="brushed">Metal Escovado</option>
            <option value="marble">Mármore</option>
            <option value="lava">Magma Vulcânico</option>
            <option value="cyberpunk">Cyberpunk Neon</option>
            <option value="fabric">Tecido (Fabric)</option>
          </select>
        </div>

        {/* UV Tiling */}
        <div className="flex items-center justify-between text-xs gap-2">
          <span className={labelCls}>Tiling UV</span>
          <div className="flex items-center gap-1">
            <span className="bg-red-500/20 text-red-400 font-bold px-1 py-0.5 text-[10px] rounded-sm">x</span>
            <DraftNumberInput
              aria-label="Tiling UV X"
              value={material.uvTiling.x}
              min={0.01}
              max={100}
              step={0.5}
              onCommit={(v) => change({ uvTiling: { ...material.uvTiling, x: v } })}
              className="w-12 bg-[#12151c] text-[11px] text-right font-mono text-white px-1 py-0.5 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none"
            />
            <span className="bg-emerald-500/20 text-emerald-400 font-bold px-1 py-0.5 text-[10px] rounded-sm">y</span>
            <DraftNumberInput
              aria-label="Tiling UV Y"
              value={material.uvTiling.y}
              min={0.01}
              max={100}
              step={0.5}
              onCommit={(v) => change({ uvTiling: { ...material.uvTiling, y: v } })}
              className="w-12 bg-[#12151c] text-[11px] text-right font-mono text-white px-1 py-0.5 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none"
            />
          </div>
        </div>

        {/* Wireframe */}
        <div className="flex items-center justify-between text-xs">
          <label htmlFor={`mat-wire-${node.id}`} className={labelCls}>
            Wireframe
          </label>
          <input
            id={`mat-wire-${node.id}`}
            type="checkbox"
            checked={wireframe}
            onChange={(e) => change({ wireframe: e.target.checked })}
            className="w-4 h-4 rounded bg-[#181c24] border border-[#2c3345] cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
};
