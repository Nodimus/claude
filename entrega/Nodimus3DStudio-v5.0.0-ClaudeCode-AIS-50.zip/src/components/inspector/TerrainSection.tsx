import React, { useMemo, useState } from 'react';
import { Mountain, Dices, ImageOff, Image as ImageIcon, SquarePen, Search, X } from 'lucide-react';
import type { GameNode, ResourceRef } from '../../types/node';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { globalResourceRegistry } from '../../core/resources/global';
import { useResourceRegistryVersion } from '../../core/resources/useResources';
import { applyTerrainChanges } from '../../core/generators/terrainGenerator';
import { canChangeGeometry, hasSculptedHeights, heightmapChanges, reseedChanges } from '../../core/terrainOps';

const isRef = (v: unknown): v is ResourceRef => !!v && typeof v === 'object' && typeof (v as ResourceRef).id === 'string' && (v as ResourceRef).id.length > 0;
const nameOf = (uri: string) => uri.split('/').pop() ?? uri;
const BTN = 'px-2 py-1 rounded text-[10px] font-medium border bg-[#222a3b] hover:bg-[#2b354a] border-[#2e3b52] text-[#93a1b8] hover:text-white flex items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed';
const HEIGHTMAP_ROOT = 'res://textures/';
const HEIGHTMAP_EXT = /\.(png|jpe?g)$/i;

/** Seletor de imagem de `res://textures/` para o heightmap. */
export const HeightmapPicker: React.FC<{ currentId?: string; onPick: (ref: ResourceRef) => void; onClose: () => void }> = ({ currentId, onPick, onClose }) => {
  useResourceRegistryVersion();
  const [filter, setFilter] = useState('');
  const entries = globalResourceRegistry
    .list('texture')
    .filter((e) => e.uri.startsWith(HEIGHTMAP_ROOT) && HEIGHTMAP_EXT.test(e.uri) && e.uri.toLowerCase().includes(filter.trim().toLowerCase()))
    .sort((a, b) => a.uri.localeCompare(b.uri));
  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/60" role="dialog" aria-label="Escolher heightmap" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="w-[420px] max-h-[70vh] flex flex-col rounded-lg border border-[#2c3345] bg-[#1a1e27] shadow-2xl text-[11px] text-[#dfe4ec]">
        <div className="flex items-center justify-between px-3 py-2 border-b border-[#2c3345]">
          <span className="font-semibold text-white">Escolher heightmap (PNG/JPG grayscale)</span>
          <button onClick={onClose} aria-label="Fechar" className="text-[#8b97a8] hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-2 border-b border-[#2c3345] flex items-center gap-1.5">
          <Search className="w-3.5 h-3.5 text-[#718096]" />
          <input autoFocus value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Filtrar imagens de res://textures/" className="flex-1 bg-[#12151c] rounded border border-[#2c3345] px-2 py-1 outline-none focus:border-blue-500" />
        </div>
        <div role="listbox" aria-label="Imagens do projeto" className="flex-1 overflow-y-auto">
          {entries.length === 0 ? (
            <p className="p-3 text-[#8b97a8]">Nenhuma imagem PNG/JPG em res://textures/. Importe uma pelo painel FileSystem.</p>
          ) : (
            entries.map((e) => (
              <button
                key={e.resourceId}
                role="option"
                aria-selected={e.resourceId === currentId}
                onClick={() => {
                  const ref = globalResourceRegistry.makeRef(e.resourceId);
                  if (ref) onPick(ref);
                }}
                className={`w-full text-left px-3 py-1.5 font-mono break-all ${e.resourceId === currentId ? 'bg-[#4982ea]/30 text-white' : 'hover:bg-[#272e3d]'}`}
              >
                {e.uri}
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

/**
 * AIS-50 — seção **Terrain** do Inspector (nó `Terrain`): heightmap (escolher/limpar), "Regerar" a semente do preset e "Abrir
 * Editor de Terreno". As demais propriedades (dimensões, preset, texturas) vêm do Inspector genérico pelos `PropertyDescriptor`s.
 * Toda edição é UM `MacroCommand` (propriedades + marca de origem `generatorSource`); terreno esculpido trava a geometria.
 */
export const TerrainSection: React.FC<{ node: GameNode }> = ({ node }) => {
  const setIsTerrainEditorOpen = useEditorStore((s) => s.setIsTerrainEditorOpen);
  const { addLog } = useEditor();
  const version = useResourceRegistryVersion();
  const [picker, setPicker] = useState(false);

  const ref = isRef(node.properties.heightmapRef) ? node.properties.heightmapRef : null;
  const resolved = useMemo(() => (ref ? globalResourceRegistry.resolve(ref) : null), [ref, version]); // eslint-disable-line react-hooks/exhaustive-deps
  const entry = resolved?.status === 'resolved' ? resolved.entry : null;
  const sculpted = hasSculptedHeights(node.properties);
  const geometry = canChangeGeometry(node.properties);
  const lock = geometry.ok ? undefined : geometry.reason;

  return (
    <div className="px-2 pt-2" data-testid="terrain-section">
      <div className="rounded border border-[#252c3c] bg-[#171b23]/60 p-2 space-y-2">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-green-500 uppercase tracking-wider">
          <Mountain className="w-3.5 h-3.5" /> Terrain
        </div>
        {sculpted && (
          <div className="text-[10px] text-amber-400" data-testid="terrain-sculpted-badge">
            Terreno editado manualmente — a geometria vem do arquivo .height.
          </div>
        )}
        <div className="text-[11px]">
          <div className="text-[#8b97a8]">Heightmap</div>
          <div className="truncate font-mono text-[10px] text-[#dfe4ec]" title={entry?.uri ?? ref?.path} data-testid="terrain-heightmap-name">
            {ref ? (entry ? nameOf(entry.uri) : <span className="text-rose-400">unresolved — {ref.label || nameOf(ref.path ?? ref.id)}</span>) : 'nenhum (usa o preset)'}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          <button onClick={() => setPicker(true)} disabled={!geometry.ok} title={lock ?? 'Escolher uma imagem grayscale de res://textures/ (Ctrl+Z desfaz)'} className={BTN}>
            <ImageIcon className="w-3 h-3" /> Escolher heightmap…
          </button>
          <button
            onClick={() => applyTerrainChanges(node.id, heightmapChanges(null), 'Limpar Heightmap')}
            disabled={!ref || !geometry.ok}
            title={lock ?? 'Volta ao preset procedural'}
            className={BTN}
          >
            <ImageOff className="w-3 h-3" /> Limpar
          </button>
          <button
            onClick={() => applyTerrainChanges(node.id, reseedChanges(node.properties), 'Regerar Terreno')}
            disabled={!!ref || !geometry.ok}
            title={lock ?? (ref ? 'Com heightmap, o preset não é usado (use "Limpar")' : 'Nova semente do preset (Ctrl+Z desfaz)')}
            className={BTN}
          >
            <Dices className="w-3 h-3" /> Regerar
          </button>
          <button onClick={() => setIsTerrainEditorOpen(true)} title="Abre o Editor de Terreno sobre este nó" className={BTN}>
            <SquarePen className="w-3 h-3" /> Abrir Editor de Terreno
          </button>
        </div>
      </div>
      {picker && (
        <HeightmapPicker
          currentId={entry?.resourceId}
          onClose={() => setPicker(false)}
          onPick={(next) => {
            setPicker(false);
            if (applyTerrainChanges(node.id, heightmapChanges(next), 'Definir Heightmap')) addLog('log', `Heightmap aplicado em '${node.name}'.`);
          }}
        />
      )}
    </div>
  );
};
