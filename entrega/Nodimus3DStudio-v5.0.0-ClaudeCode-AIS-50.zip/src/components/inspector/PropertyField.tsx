import React from 'react';
import { RotateCcw } from 'lucide-react';
import { PropertyDescriptor } from '../../types/node';
import { DraftNumberInput } from './DraftNumberInput';

interface PropertyFieldProps {
  descriptor: PropertyDescriptor;
  value: any;
  onChange: (newValue: any) => void;
}

export const PropertyField: React.FC<PropertyFieldProps> = ({
  descriptor,
  value,
  onChange,
}) => {
  const currentValue = value !== undefined ? value : descriptor.defaultValue;

  switch (descriptor.type) {
    case 'boolean':
      return (
        <div className="flex items-center justify-between py-1 px-1">
          <label className="text-xs text-[#b8c4d6] select-none truncate max-w-[120px]" title={descriptor.description || descriptor.label}>
            {descriptor.label}
          </label>
          <input
            type="checkbox"
            checked={Boolean(currentValue)}
            onChange={(e) => onChange(e.target.checked)}
            className="w-4 h-4 rounded bg-[#181c24] border border-[#2c3345] text-[#4982ea] focus:ring-0 focus:ring-offset-0 cursor-pointer"
          />
        </div>
      );

    case 'integer':
    case 'float': {
      const step = descriptor.step || (descriptor.type === 'integer' ? 1 : 0.1);
      return (
        <div className="flex items-center justify-between py-1 px-1 gap-2">
          <label className="text-xs text-[#b8c4d6] select-none truncate max-w-[120px]" title={descriptor.description || descriptor.label}>
            {descriptor.label}
          </label>
          <DraftNumberInput
            aria-label={descriptor.label}
            value={typeof currentValue === 'number' ? currentValue : 0}
            integer={descriptor.type === 'integer'}
            step={step}
            min={descriptor.min}
            max={descriptor.max}
            onCommit={(val) => onChange(val)}
            className="w-28 bg-[#141820] text-xs text-right font-mono text-[#dfe4ec] px-1.5 py-0.5 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none"
          />
        </div>
      );
    }

    case 'string':
    case 'file':
      return (
        <div className="flex items-center justify-between py-1 px-1 gap-2">
          <label className="text-xs text-[#b8c4d6] select-none truncate max-w-[100px]" title={descriptor.description || descriptor.label}>
            {descriptor.label}
          </label>
          <input
            type="text"
            value={currentValue ?? ''}
            onChange={(e) => onChange(e.target.value)}
            className="flex-1 bg-[#141820] text-xs text-[#dfe4ec] px-1.5 py-0.5 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none"
          />
        </div>
      );

    case 'resource': {
      // `ResourceRef` (identidade estável): mostra o caminho de leitura; a troca do modelo é da seção "Modelo" (AIS-38c); as demais referências seguem "em breve" — decisão 14
      // (AIS-36: cenas antigas guardam o caminho como string — `rigConfig` — e continuam abrindo; exibe o caminho)
      const ref = currentValue as { id?: string; path?: string; label?: string } | string | null | undefined;
      const text = typeof ref === 'string' ? ref : ref ? ref.path ?? ref.label ?? ref.id ?? '' : '';
      return (
        <div className="flex items-center justify-between py-1 px-1 gap-2">
          <label className="text-xs text-[#b8c4d6] select-none truncate max-w-[100px]" title={descriptor.description || descriptor.label}>
            {descriptor.label}
          </label>
          <input
            type="text"
            readOnly
            value={text}
            title={text ? `${text} — para trocar o arquivo do modelo use a seção "Modelo"; trocar outras referências: em breve` : undefined}
            className="flex-1 bg-[#141820] text-xs text-[#8b97a8] px-1.5 py-0.5 rounded border border-[#2c3345] outline-none cursor-default"
          />
        </div>
      );
    }

    case 'bitmask': {
      const bits = descriptor.bitCount ?? 8;
      const mask = typeof currentValue === 'number' ? currentValue : 0;
      return (
        <div className="py-1 px-1 space-y-1">
          <label className="text-xs text-[#b8c4d6] select-none" title={descriptor.description || descriptor.label}>
            {descriptor.label}
          </label>
          <div className="flex items-center gap-1" role="group" aria-label={descriptor.label}>
            {Array.from({ length: bits }, (_, i) => {
              const on = (mask & (1 << i)) !== 0;
              return (
                <button
                  key={i}
                  type="button"
                  role="checkbox"
                  aria-checked={on}
                  aria-label={`${descriptor.label} ${i + 1}`}
                  title={`${descriptor.label}: bit ${i + 1}`}
                  onClick={() => onChange(mask ^ (1 << i))}
                  className={`w-5 h-5 text-[10px] font-mono rounded border transition-colors ${
                    on ? 'bg-[#4982ea] border-[#4982ea] text-white' : 'bg-[#141820] border-[#2c3345] text-[#8b97a8] hover:border-[#4982ea]'
                  }`}
                >
                  {i + 1}
                </button>
              );
            })}
          </div>
        </div>
      );
    }

    case 'enum':
      return (
        <div className="flex items-center justify-between py-1 px-1 gap-2">
          <label className="text-xs text-[#b8c4d6] select-none truncate max-w-[110px]" title={descriptor.description || descriptor.label}>
            {descriptor.label}
          </label>
          <select
            value={currentValue}
            onChange={(e) => onChange(e.target.value)}
            className="flex-1 bg-[#141820] text-xs text-[#dfe4ec] px-1.5 py-0.5 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none cursor-pointer"
          >
            {descriptor.options?.map((opt) => (
              <option key={opt.value} value={opt.value} disabled={opt.disabled} title={opt.disabled ? 'em breve' : undefined}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>
      );

    case 'vector2': {
      const vec = currentValue || { x: 0, y: 0 };
      const resetVector = () => {
        const fallback = descriptor.defaultValue && typeof descriptor.defaultValue === 'object'
          ? descriptor.defaultValue
          : { x: 0, y: 0 };
        onChange({ ...fallback, x: Number(fallback.x ?? 0), y: Number(fallback.y ?? 0) });
      };
      return (
        <div className="py-1 px-1">
          <div className="flex items-center justify-between mb-1">
            <div className="text-xs text-[#b8c4d6] select-none">{descriptor.label}</div>
            <button
              type="button"
              aria-label={`Reset ${descriptor.label}`}
              title={`Reset ${descriptor.label}`}
              onClick={resetVector}
              className="inline-flex h-5 w-5 items-center justify-center rounded border border-[#2c3345] bg-[#1b2030] text-[#b8c4d6] hover:text-white hover:border-[#4982ea]"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <div className="flex items-center bg-[#141820] rounded border border-[#2c3345] overflow-hidden">
              <span className="bg-red-500/20 text-red-400 font-bold px-1.5 py-0.5 text-[10px] select-none">
                x
              </span>
              <DraftNumberInput
                aria-label={`${descriptor.label} X`}
                value={typeof vec.x === 'number' ? vec.x : 0}
                step={1}
                onCommit={(v) => onChange({ ...vec, x: v })}
                className="w-full bg-transparent text-xs text-right font-mono text-[#dfe4ec] px-1 py-0.5 outline-none"
              />
            </div>
            <div className="flex items-center bg-[#141820] rounded border border-[#2c3345] overflow-hidden">
              <span className="bg-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.5 text-[10px] select-none">
                y
              </span>
              <DraftNumberInput
                aria-label={`${descriptor.label} Y`}
                value={typeof vec.y === 'number' ? vec.y : 0}
                step={1}
                onCommit={(v) => onChange({ ...vec, y: v })}
                className="w-full bg-transparent text-xs text-right font-mono text-[#dfe4ec] px-1 py-0.5 outline-none"
              />
            </div>
          </div>
        </div>
      );
    }

    case 'vector3': {
      const vec3 = currentValue || { x: 0, y: 0, z: 0 };
      const resetVector = () => {
        const fallback = descriptor.defaultValue && typeof descriptor.defaultValue === 'object'
          ? descriptor.defaultValue
          : { x: 0, y: 0, z: 0 };
        onChange({ ...fallback, x: Number(fallback.x ?? 0), y: Number(fallback.y ?? 0), z: Number(fallback.z ?? 0) });
      };
      return (
        <div className="py-1 px-1">
          <div className="flex items-center justify-between mb-1">
            <div className="text-xs text-[#b8c4d6] select-none">{descriptor.label}</div>
            <button
              type="button"
              aria-label={`Reset ${descriptor.label}`}
              title={`Reset ${descriptor.label}`}
              onClick={resetVector}
              className="inline-flex h-5 w-5 items-center justify-center rounded border border-[#2c3345] bg-[#1b2030] text-[#b8c4d6] hover:text-white hover:border-[#4982ea]"
            >
              <RotateCcw className="w-3 h-3" />
            </button>
          </div>
          <div className="grid grid-cols-3 gap-1">
            <div className="flex items-center bg-[#141820] rounded border border-[#2c3345] overflow-hidden">
              <span className="bg-red-500/20 text-red-400 font-bold px-1 py-0.5 text-[10px] select-none">
                x
              </span>
              <DraftNumberInput
                aria-label={`${descriptor.label} X`}
                value={typeof vec3.x === 'number' ? vec3.x : 0}
                step={0.1}
                onCommit={(v) => onChange({ ...vec3, x: v })}
                className="w-full bg-transparent text-xs text-right font-mono text-[#dfe4ec] px-1 py-0.5 outline-none"
              />
            </div>
            <div className="flex items-center bg-[#141820] rounded border border-[#2c3345] overflow-hidden">
              <span className="bg-emerald-500/20 text-emerald-400 font-bold px-1 py-0.5 text-[10px] select-none">
                y
              </span>
              <DraftNumberInput
                aria-label={`${descriptor.label} Y`}
                value={typeof vec3.y === 'number' ? vec3.y : 0}
                step={0.1}
                onCommit={(v) => onChange({ ...vec3, y: v })}
                className="w-full bg-transparent text-xs text-right font-mono text-[#dfe4ec] px-1 py-0.5 outline-none"
              />
            </div>
            <div className="flex items-center bg-[#141820] rounded border border-[#2c3345] overflow-hidden">
              <span className="bg-blue-500/20 text-blue-400 font-bold px-1 py-0.5 text-[10px] select-none">
                z
              </span>
              <DraftNumberInput
                aria-label={`${descriptor.label} Z`}
                value={typeof vec3.z === 'number' ? vec3.z : 0}
                step={0.1}
                onCommit={(v) => onChange({ ...vec3, z: v })}
                className="w-full bg-transparent text-xs text-right font-mono text-[#dfe4ec] px-1 py-0.5 outline-none"
              />
            </div>
          </div>
        </div>
      );
    }

    case 'color': {
      const color = currentValue || { r: 1, g: 1, b: 1, a: 1 };
      // Convert RGBA 0..1 to hex
      const toHex = (n: number) =>
        Math.round(Math.max(0, Math.min(1, n)) * 255)
          .toString(16)
          .padStart(2, '0');
      const hex = `#${toHex(color.r)}${toHex(color.g)}${toHex(color.b)}`;

      return (
        <div className="flex items-center justify-between py-1 px-1 gap-2">
          <label className="text-xs text-[#b8c4d6] select-none">{descriptor.label}</label>
          <div className="flex items-center gap-1.5">
            <input
              type="color"
              value={hex}
              onChange={(e) => {
                const hexVal = e.target.value;
                const r = parseInt(hexVal.slice(1, 3), 16) / 255;
                const g = parseInt(hexVal.slice(3, 5), 16) / 255;
                const b = parseInt(hexVal.slice(5, 7), 16) / 255;
                onChange({ ...color, r, g, b });
              }}
              className="w-6 h-6 rounded cursor-pointer border border-[#2c3345] bg-transparent p-0"
            />
            <span className="font-mono text-xs text-[#8b97a8] uppercase">{hex}</span>
          </div>
        </div>
      );
    }

    default:
      return null;
  }
};
