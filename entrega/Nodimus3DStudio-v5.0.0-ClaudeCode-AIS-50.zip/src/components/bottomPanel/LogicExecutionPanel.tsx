import React, { useSyncExternalStore } from 'react';
import { ListTree } from 'lucide-react';
import { logicExecutionLog } from '../../runtime/logicRunnerSession';

/**
 * AIS-44 — log de execução do Visual Logic no Debugger: cada regra disparada (Trigger → Actions), Conditions que não
 * puderam ser avaliadas, Actions inválidas/sem executor e erros. Só leitura; vem do buffer do `LogicRunner` (descartável com o Play).
 */
const COLOR = { info: 'text-[#dfe4ec]', warn: 'text-amber-300', error: 'text-red-400' } as const;

export const LogicExecutionPanel: React.FC = () => {
  const entries = useSyncExternalStore(logicExecutionLog.subscribe, logicExecutionLog.getEntries);
  return (
    <div className="mt-3 bg-[#1c2230] p-3 rounded border border-[#2c3345] text-xs" data-testid="debug-logic-log">
      <div className="flex items-center gap-1.5 text-[#8b97a8] text-[11px] mb-1.5">
        <ListTree className="w-3 h-3 text-sky-400" />
        <span>Visual Logic ({entries.length})</span>
        <button
          type="button"
          onClick={logicExecutionLog.clear}
          disabled={entries.length === 0}
          className="ml-auto text-[10px] text-[#8b97a8] hover:text-[#dfe4ec] disabled:opacity-40"
        >
          Limpar
        </button>
      </div>
      <div className="max-h-40 overflow-y-auto font-mono leading-snug">
        {entries.length === 0 ? (
          <span className="text-[#8b97a8]">Nenhuma regra executada (inicie o Play).</span>
        ) : (
          entries.map((entry, i) => (
            <div key={i} className={COLOR[entry.level]}>
              <span className="text-[#8b97a8]">{entry.time.toFixed(2)}s </span>
              {entry.message}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
