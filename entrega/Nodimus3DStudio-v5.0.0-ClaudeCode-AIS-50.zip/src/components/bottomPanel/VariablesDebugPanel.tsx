import React, { useEffect, useReducer } from 'react';
import { Variable } from 'lucide-react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { getActiveRuntimeSession } from '../../runtime/RuntimeSession';
import { coerceVariableValue, localEntries, type LocalVariable, type VariableScope } from '../../core/variableManager';

/**
 * AIS-43 — variáveis no Debugger. Em Play mostra os valores VIVOS da sessão (`VariableManager` do runtime, que reage ao
 * barramento `onVariableChanged` sem recarregar a cena) e permite editar o valor da sessão; fora do Play mostra os valores
 * iniciais autorais, só leitura. Editar aqui nunca escreve no projeto nem gera Undo (o Play é descartável).
 */
export const VariablesDebugPanel: React.FC = () => {
  const { project, selectedNode } = useEditor();
  const isPlaying = useEditorStore((s) => s.isPlaying);
  const [, bump] = useReducer((n: number) => n + 1, 0);
  const manager = isPlaying ? (getActiveRuntimeSession()?.variables ?? null) : null;

  useEffect(() => (manager ? manager.onVariableChanged(() => bump()) : undefined), [manager]);

  const globals: LocalVariable[] = manager ? manager.listGlobals() : (project.globalVariables ?? []).map((v) => ({ name: v.name, type: v.type as LocalVariable['type'], value: v.value }));
  const locals: LocalVariable[] = !selectedNode ? [] : manager ? manager.listLocals(selectedNode.id) : localEntries(selectedNode.variables);

  const edit = (scope: VariableScope, v: LocalVariable, raw: string | boolean) => {
    if (!manager) return;
    const value = coerceVariableValue(v.type, raw);
    if (value !== null) manager.setVariable(scope, v.name, value, scope === 'local' ? selectedNode?.id : undefined);
  };

  const row = (scope: VariableScope, v: LocalVariable) => (
    <div key={`${scope}-${v.name}`} className="flex items-center gap-2 py-0.5" data-testid={`debug-var-${scope}-${v.name}`}>
      <span className="font-mono text-[#dfe4ec] w-28 truncate" title={v.name}>
        {v.name}
      </span>
      <span className="text-[10px] text-[#8b97a8] w-14">{v.type}</span>
      {!manager ? (
        <span className="font-mono text-emerald-300">{String(v.value)}</span>
      ) : v.type === 'boolean' ? (
        <input type="checkbox" aria-label={`Valor de ${v.name}`} checked={v.value === true} onChange={(e) => edit(scope, v, e.target.checked)} />
      ) : (
        <input
          aria-label={`Valor de ${v.name}`}
          key={String(v.value)}
          defaultValue={String(v.value)}
          className="bg-[#141820] text-emerald-300 font-mono px-1.5 py-0.5 rounded border border-[#2c3345] outline-none w-32"
          onBlur={(e) => edit(scope, v, e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && (e.currentTarget as HTMLInputElement).blur()}
        />
      )}
    </div>
  );

  return (
    <div className="mt-3 bg-[#1c2230] p-3 rounded border border-[#2c3345] text-xs" data-testid="debug-variables">
      <div className="flex items-center gap-1.5 text-[#8b97a8] text-[11px] mb-1.5">
        <Variable className="w-3 h-3 text-violet-400" />
        <span>Variables</span>
        <span className="ml-auto">{manager ? 'ao vivo (sessão de Play)' : 'valores iniciais (fora do Play)'}</span>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <div className="text-[10px] uppercase tracking-wider text-[#68768e] mb-0.5">Globais</div>
          {globals.length === 0 ? <span className="text-[#68768e]">nenhuma</span> : globals.map((v) => row('global', v))}
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-[#68768e] mb-0.5">Locais{selectedNode ? ` — ${selectedNode.name}` : ''}</div>
          {!selectedNode ? <span className="text-[#68768e]">selecione um nó</span> : locals.length === 0 ? <span className="text-[#68768e]">nenhuma</span> : locals.map((v) => row('local', v))}
        </div>
      </div>
    </div>
  );
};
