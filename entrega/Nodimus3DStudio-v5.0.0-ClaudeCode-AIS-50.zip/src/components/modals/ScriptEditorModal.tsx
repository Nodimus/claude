import React, { useState, useMemo, useEffect, useSyncExternalStore } from 'react';
import { useEditor } from '../../core/EditorContext';
import { CodeMirrorEditor } from '../codeEditor/CodeMirrorEditor';
import { globalDocumentManager } from '../../core/documents/DocumentManager';
import { ensureScriptDocument, getScriptDraft, saveScript, setScriptDraft } from '../../core/documents/scriptDocuments';
import {
  FileCode,
  X,
  Maximize2,
  Minimize2,
  FolderOpen,
  Plus,
  ExternalLink,
  ChevronDown,
} from 'lucide-react';

export const ScriptEditorModal: React.FC = () => {
  const {
    project,
    activeScriptPath,
    setActiveScriptPath,
    isScriptEditorModalOpen,
    setIsScriptEditorModalOpen,
    updateFileContent,
    createFile,
    setWorkspaceMode,
    addLog,
  } = useEditor();

  const [isMaximized, setIsMaximized] = useState(false);
  const [showFilePicker, setShowFilePicker] = useState(false);

  // List all editable files
  const editableFiles = useMemo(() => {
    return Object.values(project.files).filter((file) => {
      if (file.isDirectory) return false;
      const ext = file.extension?.toLowerCase() || '';
      return [
        'txt',
        'js',
        'ts',
        'jsx',
        'tsx',
        'json',
        'xml',
        'svg',
        'html',
        'css',
        'md',
        'glsl',
        'shader',
      ].includes(ext) || file.path.endsWith('.txt') || file.path.endsWith('.json');
    });
  }, [project.files]);

  // AIS-18b: mesmo documento/rascunho do workspace de código (dedupe por caminho)
  const documents = useSyncExternalStore(
    (cb) => globalDocumentManager.subscribe(cb),
    () => globalDocumentManager.list()
  );
  const modalPath = activeScriptPath || (editableFiles[0]?.path ?? 'res://notes.txt');
  useEffect(() => {
    if (isScriptEditorModalOpen && project.files[modalPath]) void ensureScriptDocument(modalPath);
  }, [isScriptEditorModalOpen, modalPath, project.files]);

  if (!isScriptEditorModalOpen) return null;

  // Selected file
  const currentPath = activeScriptPath || (editableFiles[0]?.path ?? 'res://notes.txt');
  const currentFile = project.files[currentPath];

  const handleSwitchToWorkspace = () => {
    setIsScriptEditorModalOpen(false);
    setWorkspaceMode('Script');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-3 select-none">
      <div
        className={`bg-[#181c24] border border-[#2c3345] rounded-md shadow-2xl flex flex-col overflow-hidden transition-all duration-150 ${
          isMaximized
            ? 'w-full h-full'
            : 'w-[92vw] max-w-5xl h-[86vh]'
        }`}
      >
        {/* Modal Window Header */}
        <div className="h-10 px-3 bg-[#1e232f] border-b border-[#2c3345] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded bg-[#4982ea] flex items-center justify-center text-white">
              <FileCode className="w-3.5 h-3.5" />
            </div>
            <span className="font-semibold text-xs text-white">Editor de Código (CodeMirror)</span>

            {/* File Switcher Dropdown */}
            <div className="relative ml-2">
              <button
                onClick={() => setShowFilePicker(!showFilePicker)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#141822] hover:bg-[#272e3d] text-xs font-mono text-[#dfe4ec] border border-[#2c3345] transition-colors"
              >
                <span className="truncate max-w-[200px]">{currentPath}</span>
                <ChevronDown className="w-3 h-3 text-[#8b97a8]" />
              </button>

              {showFilePicker && (
                <div className="absolute top-full left-0 mt-1 w-64 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50 max-h-60 overflow-y-auto">
                  <div className="px-2 py-1 text-[10px] uppercase text-[#8b97a8] font-semibold border-b border-[#2c3345]">
                    Arquivos do Projeto
                  </div>
                  {editableFiles.map((f) => (
                    <button
                      key={f.path}
                      onClick={() => {
                        setActiveScriptPath(f.path);
                        setShowFilePicker(false);
                      }}
                      className={`w-full text-left px-2.5 py-1.5 hover:bg-[#2c3345] text-xs font-mono truncate flex items-center justify-between ${
                        f.path === currentPath ? 'bg-[#4982ea]/20 text-[#5b91f5]' : 'text-[#dfe4ec]'
                      }`}
                    >
                      <span className="truncate">{f.name}</span>
                      <span className="text-[10px] text-[#8b97a8] uppercase ml-2">{f.extension || 'txt'}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right Header Buttons */}
          <div className="flex items-center gap-1.5">
            {/* Switch to Workspace Mode */}
            <button
              onClick={handleSwitchToWorkspace}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#272e3d] hover:bg-[#323b4e] text-blue-300 hover:text-white border border-[#374158] transition-colors text-xs"
              title="Abrir como Modo Workspace completo"
            >
              <ExternalLink className="w-3 h-3" />
              <span className="hidden sm:inline">Modo Workspace</span>
            </button>

            {/* Maximize / Restore */}
            <button
              onClick={() => setIsMaximized(!isMaximized)}
              className="p-1 rounded hover:bg-[#2c3345] text-[#8b97a8] hover:text-white transition-colors"
              title={isMaximized ? 'Restaurar tamanho' : 'Maximizar'}
            >
              {isMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Close */}
            <button
              onClick={() => setIsScriptEditorModalOpen(false)}
              className="p-1 rounded hover:bg-rose-900/40 text-[#8b97a8] hover:text-rose-400 transition-colors"
              title="Fechar (ESC)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Body: CodeMirror */}
        <div className="flex-1 overflow-hidden relative bg-[#141822]">
          {currentFile ? (
            <CodeMirrorEditor
              key={currentPath}
              filePath={currentPath}
              initialContent={getScriptDraft(currentPath) ?? (currentFile.content || '')}
              initialDirty={documents.some((d) => d.kind === 'script' && d.dirty && d.resourceRef.path === currentPath)}
              onDraftChange={(path, content) => setScriptDraft(path, content, project.files[path]?.content || '')}
              onSave={(path, content) => {
                const ok = saveScript(path, content);
                if (ok) addLog('log', `Arquivo salvo: ${path}`);
                return ok;
              }}
              className="h-full border-none rounded-none"
            />
          ) : (
            <div className="h-full flex items-center justify-center text-xs text-[#8b97a8]">
              Arquivo não encontrado.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
