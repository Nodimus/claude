import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { VideoClipSettings } from '../../types/video';
import { GameNode } from '../../types/node';
import { createThreeVideoMaterial } from '../../utils/videoTextureHelper';

interface VideoPreviewCanvasProps {
  settings: VideoClipSettings;
  textureSource: HTMLVideoElement | HTMLCanvasElement | null;
  selectedNode: GameNode | null;
  lightingPreset: 'DarkCinema' | 'CyberpunkNeon' | 'StudioBright' | 'OutdoorDay';
  autoRotate: boolean;
  showWireframe: boolean;
  showGrid: boolean;
}

export const VideoPreviewCanvas: React.FC<VideoPreviewCanvasProps> = ({
  settings,
  textureSource,
  selectedNode,
  lightingPreset,
  autoRotate,
  showWireframe,
  showGrid,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const screenMeshRef = useRef<THREE.Mesh | null>(null);
  const screenGroupRef = useRef<THREE.Group | null>(null);
  const lightsGroupRef = useRef<THREE.Group | null>(null);
  const gridHelperRef = useRef<THREE.GridHelper | null>(null);
  const threeTextureRef = useRef<THREE.Texture | null>(null);
  const reqIdRef = useRef<number | null>(null);

  const [fps, setFps] = useState<number>(60);
  const fpsCounterRef = useRef({ frames: 0, lastTime: performance.now() });

  // Initialize Three.js scene
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || 640;
    const height = container.clientHeight || 420;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0e1117);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 1.2, 5.2);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;
    container.replaceChildren(renderer.domElement);
    rendererRef.current = renderer;

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.maxDistance = 35;
    controls.minDistance = 0.8;
    controls.target.set(0, 0.4, 0);
    controlsRef.current = controls;

    // Groups
    const screenGroup = new THREE.Group();
    scene.add(screenGroup);
    screenGroupRef.current = screenGroup;

    const lightsGroup = new THREE.Group();
    scene.add(lightsGroup);
    lightsGroupRef.current = lightsGroup;

    // Grid Floor
    const grid = new THREE.GridHelper(16, 24, 0x3d4a66, 0x1a2130);
    grid.position.y = -0.7;
    scene.add(grid);
    gridHelperRef.current = grid;

    // Studio reflective floor disk
    const floorGeo = new THREE.CircleGeometry(8, 48);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x090c12,
      roughness: 0.45,
      metalness: 0.6,
      side: THREE.DoubleSide,
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.y = -0.71;
    floorMesh.receiveShadow = true;
    scene.add(floorMesh);

    // Resize observer
    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        if (w > 0 && h > 0 && cameraRef.current && rendererRef.current) {
          cameraRef.current.aspect = w / h;
          cameraRef.current.updateProjectionMatrix();
          rendererRef.current.setSize(w, h);
        }
      }
    });
    ro.observe(container);

    // Animation loop
    const animate = (time: number) => {
      reqIdRef.current = requestAnimationFrame(animate);

      // FPS Calculation
      fpsCounterRef.current.frames++;
      if (time - fpsCounterRef.current.lastTime >= 1000) {
        setFps(fpsCounterRef.current.frames);
        fpsCounterRef.current.frames = 0;
        fpsCounterRef.current.lastTime = time;
      }

      // Texture frame update
      if (threeTextureRef.current) {
        threeTextureRef.current.needsUpdate = true;
      }

      // Auto rotation
      if (screenGroupRef.current && autoRotate) {
        screenGroupRef.current.rotation.y += 0.008;
      }

      controls.update();
      renderer.render(scene, camera);
    };

    reqIdRef.current = requestAnimationFrame(animate);

    return () => {
      ro.disconnect();
      if (reqIdRef.current) cancelAnimationFrame(reqIdRef.current);
      controls.dispose();
      renderer.dispose();
      scene.clear();
    };
  }, []);

  // Update Three.js Texture whenever textureSource changes
  useEffect(() => {
    if (!textureSource) return;

    let texture: THREE.Texture;
    if (textureSource instanceof HTMLVideoElement) {
      texture = new THREE.VideoTexture(textureSource);
    } else {
      texture = new THREE.CanvasTexture(textureSource);
    }

    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.format = THREE.RGBAFormat;
    texture.generateMipmaps = false;
    texture.colorSpace = THREE.SRGBColorSpace;

    threeTextureRef.current = texture;

    // Apply to current mesh if already created
    if (screenMeshRef.current) {
      screenMeshRef.current.material = createThreeVideoMaterial(texture, settings);
    }

    return () => {
      texture.dispose();
    };
  }, [textureSource]);

  // Update Lighting
  useEffect(() => {
    if (!lightsGroupRef.current) return;
    const group = lightsGroupRef.current;
    group.clear();

    switch (lightingPreset) {
      case 'CyberpunkNeon': {
        const ambient = new THREE.AmbientLight(0x050814, 0.8);
        group.add(ambient);

        const cyanLight = new THREE.PointLight(0x00f0ff, 3.5, 12);
        cyanLight.position.set(-3, 2, 2.5);
        group.add(cyanLight);

        const magentaLight = new THREE.PointLight(0xff00aa, 3.2, 12);
        magentaLight.position.set(3, 1.5, -2);
        group.add(magentaLight);

        const topSpot = new THREE.SpotLight(0xffffff, 2, 15, Math.PI / 4, 0.4);
        topSpot.position.set(0, 4.5, 2.5);
        group.add(topSpot);
        break;
      }

      case 'StudioBright': {
        const ambient = new THREE.AmbientLight(0xffffff, 1.2);
        group.add(ambient);

        const keyLight = new THREE.DirectionalLight(0xffffff, 2.5);
        keyLight.position.set(4, 5, 4);
        keyLight.castShadow = true;
        group.add(keyLight);

        const fillLight = new THREE.DirectionalLight(0xbad2ff, 1.5);
        fillLight.position.set(-4, 3, -2);
        group.add(fillLight);
        break;
      }

      case 'OutdoorDay': {
        const hemiLight = new THREE.HemisphereLight(0x87ceeb, 0x3d352e, 1.8);
        group.add(hemiLight);

        const sun = new THREE.DirectionalLight(0xfff4e0, 3.0);
        sun.position.set(5, 8, 3);
        sun.castShadow = true;
        group.add(sun);
        break;
      }

      case 'DarkCinema':
      default: {
        const ambient = new THREE.AmbientLight(0x141724, 0.5);
        group.add(ambient);

        const softKey = new THREE.DirectionalLight(0x384a6e, 1.2);
        softKey.position.set(2, 4, 3);
        group.add(softKey);

        const rim = new THREE.PointLight(0x6080b0, 1.0, 10);
        rim.position.set(0, 2, -3);
        group.add(rim);
        break;
      }
    }
  }, [lightingPreset]);

  // Update Grid Helper
  useEffect(() => {
    if (gridHelperRef.current) {
      gridHelperRef.current.visible = showGrid;
    }
  }, [showGrid]);

  // Build & Rebuild Screen Mesh depending on shape, aspect ratio, settings, and selected node
  useEffect(() => {
    if (!screenGroupRef.current) return;
    const group = screenGroupRef.current;
    group.clear();

    const [aspectW, aspectH] = settings.aspectRatio.split(':').map(Number);
    const ratio = (aspectW || 16) / (aspectH || 9);
    const screenWidth = 3.6;
    const screenHeight = screenWidth / ratio;

    let screenGeo: THREE.BufferGeometry;
    let frameMesh: THREE.Object3D | null = null;

    // Reset camera target if VR 360
    if (settings.shape === 'Sphere360') {
      screenGeo = new THREE.SphereGeometry(15, 60, 40);
      screenGeo.scale(-1, 1, 1); // inside out
      if (cameraRef.current && controlsRef.current) {
        cameraRef.current.position.set(0, 0, 0.1);
        controlsRef.current.target.set(0, 0, 0);
      }
    } else if (settings.shape === 'CurvedScreen') {
      const radius = 4.2;
      const arcAngle = Math.PI / 3.2; // approx 56 degrees
      screenGeo = new THREE.CylinderGeometry(
        radius,
        radius,
        screenHeight,
        48,
        1,
        true,
        -arcAngle / 2 + Math.PI / 2,
        arcAngle
      );
      screenGeo.scale(-1, 1, 1); // curve concave towards camera

      // Curved Screen Frame & Base
      const frameGroup = new THREE.Group();
      const frameMat = new THREE.MeshStandardMaterial({
        color: 0x111319,
        metalness: 0.85,
        roughness: 0.25,
      });

      // Outer bezel curve
      const bezelRadius = radius + 0.03;
      const bezelGeo = new THREE.CylinderGeometry(
        bezelRadius,
        bezelRadius,
        screenHeight + 0.08,
        48,
        1,
        true,
        -arcAngle / 2 + Math.PI / 2 - 0.02,
        arcAngle + 0.04
      );
      const bezelMesh = new THREE.Mesh(bezelGeo, frameMat);
      frameGroup.add(bezelMesh);

      // Stand column
      const standColGeo = new THREE.CylinderGeometry(0.08, 0.08, 1.2, 16);
      const standCol = new THREE.Mesh(standColGeo, frameMat);
      standCol.position.set(0, -screenHeight * 0.5 - 0.4, 0.1);
      frameGroup.add(standCol);

      // Base plate
      const baseGeo = new THREE.CylinderGeometry(0.7, 0.8, 0.08, 24);
      const base = new THREE.Mesh(baseGeo, frameMat);
      base.position.set(0, -0.66, 0);
      frameGroup.add(base);

      frameMesh = frameGroup;
    } else if (settings.shape === 'Cube') {
      screenGeo = new THREE.BoxGeometry(2.4, 2.4, 2.4);
      // Stand pedestal
      const pedGeo = new THREE.CylinderGeometry(0.8, 0.9, 0.4, 24);
      const pedMat = new THREE.MeshStandardMaterial({ color: 0x181e2b, metalness: 0.7, roughness: 0.3 });
      const ped = new THREE.Mesh(pedGeo, pedMat);
      ped.position.set(0, -0.5, 0);
      frameMesh = ped;
    } else if (settings.shape === 'Cylinder') {
      screenGeo = new THREE.CylinderGeometry(1.2, 1.2, screenHeight, 48);
      // Top and bottom metallic caps
      const capGroup = new THREE.Group();
      const capMat = new THREE.MeshStandardMaterial({ color: 0x0f141e, metalness: 0.9, roughness: 0.2 });
      const topCap = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.3, 0.1, 48), capMat);
      topCap.position.y = screenHeight * 0.5 + 0.05;
      const botCap = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.3, 0.1, 48), capMat);
      botCap.position.y = -screenHeight * 0.5 - 0.05;
      capGroup.add(topCap, botCap);
      frameMesh = capGroup;
    } else if (settings.shape === 'HologramBillboard') {
      screenGeo = new THREE.PlaneGeometry(screenWidth, screenHeight);
      // Floating hologram projector pylons
      const holoGroup = new THREE.Group();
      const pylonMat = new THREE.MeshStandardMaterial({
        color: 0x050a12,
        metalness: 0.9,
        roughness: 0.2,
      });
      const beamMat = new THREE.MeshBasicMaterial({
        color: 0x00f0ff,
        transparent: true,
        opacity: 0.35,
        wireframe: true,
      });

      // 4 corner hologram emitter nodes
      const corners = [
        [-screenWidth * 0.5, screenHeight * 0.5],
        [screenWidth * 0.5, screenHeight * 0.5],
        [-screenWidth * 0.5, -screenHeight * 0.5],
        [screenWidth * 0.5, -screenHeight * 0.5],
      ];
      for (const [cx, cy] of corners) {
        const node = new THREE.Mesh(new THREE.SphereGeometry(0.06, 12, 12), new THREE.MeshBasicMaterial({ color: 0x00f0ff }));
        node.position.set(cx, cy, 0.02);
        holoGroup.add(node);
      }

      // Base projector ring
      const baseRing = new THREE.Mesh(new THREE.TorusGeometry(1.4, 0.06, 16, 32), pylonMat);
      baseRing.rotation.x = Math.PI / 2;
      baseRing.position.set(0, -0.68, 0);
      holoGroup.add(baseRing);

      // Light beam cone
      const beam = new THREE.Mesh(new THREE.ConeGeometry(screenWidth * 0.65, screenHeight * 1.2, 16, 1, true), beamMat);
      beam.position.set(0, 0, 0);
      beam.rotation.x = Math.PI;
      holoGroup.add(beam);

      frameMesh = holoGroup;
    } else if (settings.shape === 'SelectedMesh' && selectedNode) {
      // Use selected node mesh shape
      const meshType = selectedNode.properties.meshType || 'BoxMesh';
      if (meshType === 'SphereMesh') screenGeo = new THREE.SphereGeometry(1.2, 32, 24);
      else if (meshType === 'CylinderMesh') screenGeo = new THREE.CylinderGeometry(1.0, 1.0, 2.0, 32);
      else if (meshType === 'PlaneMesh' || meshType === 'QuadMesh') screenGeo = new THREE.PlaneGeometry(screenWidth, screenHeight);
      else if (meshType === 'TorusMesh') screenGeo = new THREE.TorusGeometry(1.1, 0.4, 16, 40);
      else screenGeo = new THREE.BoxGeometry(2, 2, 2);
    } else {
      // Flat Display (Modern Monitor)
      screenGeo = new THREE.PlaneGeometry(screenWidth, screenHeight);

      // Flat monitor frame
      const frameGroup = new THREE.Group();
      const frameMat = new THREE.MeshStandardMaterial({
        color: 0x12141a,
        metalness: 0.8,
        roughness: 0.25,
      });

      // Bezel backplate
      const backBezel = new THREE.Mesh(
        new THREE.BoxGeometry(screenWidth + 0.08, screenHeight + 0.08, 0.06),
        frameMat
      );
      backBezel.position.z = -0.035;
      frameGroup.add(backBezel);

      // Stand
      const standArm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.2, 0.1), frameMat);
      standArm.position.set(0, -screenHeight * 0.5 - 0.35, -0.1);
      frameGroup.add(standArm);

      const standBase = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.04, 0.9), frameMat);
      standBase.position.set(0, -0.68, 0.2);
      frameGroup.add(standBase);

      frameMesh = frameGroup;
    }

    // Video Texture or fallback placeholder texture
    let texture = threeTextureRef.current;
    if (!texture) {
      const dummyCanvas = document.createElement('canvas');
      dummyCanvas.width = 64;
      dummyCanvas.height = 64;
      const ctx = dummyCanvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#0a101d';
        ctx.fillRect(0, 0, 64, 64);
        ctx.fillStyle = '#00f0ff';
        ctx.fillText('VIDEO', 10, 36);
      }
      texture = new THREE.CanvasTexture(dummyCanvas);
    }

    const material = createThreeVideoMaterial(texture, settings);
    material.wireframe = showWireframe;

    const screenMesh = new THREE.Mesh(screenGeo, material);
    screenMesh.castShadow = true;
    screenMesh.receiveShadow = true;
    screenMeshRef.current = screenMesh;

    group.add(screenMesh);
    if (frameMesh) {
      group.add(frameMesh);
    }

    // Position adjustments for shapes
    if (settings.shape === 'CurvedScreen') {
      group.position.set(0, 0.4, 0);
    } else if (settings.shape === 'FlatDisplay' || settings.shape === 'HologramBillboard') {
      group.position.set(0, 0.4, 0);
    } else if (settings.shape === 'Cube' || settings.shape === 'Cylinder' || settings.shape === 'SelectedMesh') {
      group.position.set(0, 0.5, 0);
    } else {
      group.position.set(0, 0, 0);
    }
  }, [settings.shape, settings.aspectRatio, settings.emissiveIntensity, settings.roughness, settings.metalness, showWireframe, selectedNode]);

  const resetCamera = () => {
    if (!cameraRef.current || !controlsRef.current) return;
    if (settings.shape === 'Sphere360') {
      cameraRef.current.position.set(0, 0, 0.1);
      controlsRef.current.target.set(0, 0, 0);
    } else {
      cameraRef.current.position.set(0, 1.2, 5.2);
      controlsRef.current.target.set(0, 0.4, 0);
    }
    controlsRef.current.update();
  };

  return (
    <div className="relative w-full h-full min-h-[380px] bg-[#0b0e14] rounded-lg overflow-hidden border border-[#232936] select-none">
      {/* Three.js Container */}
      <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Floating Viewport Overlay Bar */}
      <div className="absolute top-3 left-3 flex items-center gap-2 bg-[#121722]/85 backdrop-blur-md px-3 py-1.5 rounded-md border border-[#2a3449] text-xs text-[#a6b5cc] shadow-lg">
        <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span className="font-semibold text-white">Three.js WebGL</span>
        <span className="text-[#596a88]">|</span>
        <span className="font-mono text-emerald-400 font-bold">{fps} FPS</span>
        <span className="text-[#596a88]">|</span>
        <span className="text-[#8495b0]">{settings.shape} ({settings.aspectRatio})</span>
      </div>

      {/* Viewport Action Controls (Bottom Right) */}
      <div className="absolute bottom-3 right-3 flex items-center gap-1.5 bg-[#121722]/90 backdrop-blur-md p-1.5 rounded-md border border-[#2a3449] shadow-lg">
        <button
          onClick={resetCamera}
          className="px-2 py-1 text-[11px] rounded bg-[#1e2638] hover:bg-[#2b374e] text-[#c2cbdb] hover:text-white transition flex items-center gap-1 font-medium"
          title="Reset Camera Position"
        >
          <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
            <path d="M3 3v5h5" />
          </svg>
          Reset Cam
        </button>
      </div>

      {/* Navigation Hint */}
      <div className="absolute bottom-3 left-3 text-[10px] text-[#55657e] pointer-events-none bg-[#0e121a]/70 px-2 py-0.5 rounded border border-[#1b2230]">
        Left drag: Rotate | Right drag: Pan | Scroll: Zoom
      </div>
    </div>
  );
};
