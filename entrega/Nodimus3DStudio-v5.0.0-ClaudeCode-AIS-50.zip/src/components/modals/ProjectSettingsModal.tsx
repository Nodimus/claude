import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useEditor } from '../../core/EditorContext';
import { ProjectStorage } from '../../core/projectStorage';
import { listScenes } from '../../core/sceneManager';
import { globalDocumentManager } from '../../core/documents/DocumentManager';
import { PROJECT_SETTINGS_KIND } from '../../core/documents/documentKinds';
import { SAVE_DISCARD_CANCEL, getPendingDecision, requestDecision } from '../../core/documents/decisions';
import {
  isDirty,
  resetTabToDefaults,
  tabOfPath,
  toDraft,
  validateDraft,
  type SettingsDraft,
  type SettingsTab,
} from '../../core/projectSettingsForm';
import { pendingReaderTooltip } from '../../core/projectSettingsReaders';
import { VariablesEditor } from '../variables/VariablesEditor';
import { addGlobal, coerceVariableValue, removeGlobal, renameGlobal, updateGlobal, type VariableType } from '../../core/variableManager';
import type { ProjectGlobalVariable } from '../../types/projectFile';
import { Settings, X, Save, Monitor, Cpu, Sparkles, Volume2, Shield, Puzzle, ExternalLink, Keyboard, Variable, RotateCcw } from 'lucide-react';

type Tab = SettingsTab | 'inputMap' | 'variables';

let docSeq = 0;

const newVariableId = (): string => (typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `var_${Math.random().toString(36).slice(2, 10)}`);

const TAB_BTN = (active: boolean) =>
  `w-full text-left px-3 py-1.5 rounded flex items-center gap-2 transition-colors ${
    active ? 'bg-[#4982ea] text-white font-medium' : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'
  }`;

const INPUT = 'w-full bg-[#141820] text-white px-2.5 py-1.5 rounded border outline-none disabled:opacity-50 disabled:cursor-not-allowed';
const border = (error?: string) => (error ? 'border-rose-500' : 'border-[#2c3345]');

/** `pending` (AIS-44d, decisão 14): campo sem leitor — o controle fica desabilitado e o tooltip diz de qual prompt vem. */
const Field: React.FC<{ label: string; error?: string; hint?: string; title?: string; pending?: string; children: React.ReactNode }> = ({ label, error, hint, title, pending, children }) => (
  <div title={pending ?? title}>
    <label className="text-[#8b97a8] text-[11px] block mb-1">
      {label}
      {pending && <span className="ml-1.5 text-amber-300/80">· {pending}</span>}
    </label>
    {children}
    {error ? (
      <span role="alert" className="text-[10px] text-rose-400 mt-1 block">
        {error}
      </span>
    ) : hint ? (
      <span className="text-[10px] text-[#8b97a8] mt-1 block">{hint}</span>
    ) : null}
  </div>
);

/** O corpo só monta enquanto o modal está aberto: o rascunho é recriado a cada abertura (editar → cancelar → reabrir mostra o persistido). */
export const ProjectSettingsModal: React.FC = () => {
  const { isProjectSettingsOpen } = useEditor();
  if (!isProjectSettingsOpen) return null;
  return <ProjectSettingsBody />;
};

const ProjectSettingsBody: React.FC = () => {
  const { setIsProjectSettingsOpen, setIsExtensionsPanelOpen, project, updateProjectSettings, variableOps } = useEditor();

  const [activeTab, setActiveTab] = useState<Tab>('general');
  const [draft, setDraft] = useState<SettingsDraft>(() => toDraft(project.settings));
  // AIS-43: variáveis globais editadas DENTRO do rascunho do modal (dirty/Cancelar/Salvar); gravam num único Command ao salvar
  const [varDraft, setVarDraft] = useState<ProjectGlobalVariable[]>(() => [...(project.globalVariables ?? [])]);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [docId, setDocId] = useState<string | null>(null);

  const storageError = useRef<string | null>(null);
  const saveRef = useRef<() => { ok: true } | { ok: false; error: string }>(() => ({ ok: true }));

  const scenePaths = useMemo(() => listScenes(project).map((s) => s.path), [project]);
  const validation = useMemo(
    () => validateDraft(draft, project.settings, { scenePaths, projects: ProjectStorage.getProjectsList(), projectId: project.id }),
    [draft, project.settings, project.id, scenePaths]
  );
  const errors = validation.errors;
  const errorCount = Object.keys(errors).length;
  const origVars = project.globalVariables ?? [];
  const varsDirty = JSON.stringify(varDraft) !== JSON.stringify(origVars);
  const dirty = isDirty(draft, project.settings) || varsDirty;
  const tabsWithErrors = new Set(Object.keys(errors).map(tabOfPath));

  // salvar do documento: valida de novo, entrega ao EditorContext e FALHA (lança) se não gravou
  saveRef.current = () => {
    const check = validateDraft(draft, project.settings, { scenePaths, projects: ProjectStorage.getProjectsList(), projectId: project.id });
    if (!check.ok) return { ok: false, error: `Corrija ${Object.keys(check.errors).length} campo(s) com erro antes de salvar.` };
    const result = updateProjectSettings(check.settings);
    if (result.ok && varsDirty) {
      // renomeadas = mesmo ID, nome novo: as referências dos Behaviors acompanham no MESMO Command (um Undo)
      const renames = varDraft.flatMap((v) => {
        const before = origVars.find((o) => o.id === v.id);
        return before && before.name !== v.name ? [{ from: before.name, to: v.name }] : [];
      });
      variableOps.commitGlobals(varDraft, 'Edit Global Variables', renames);
    }
    return result;
  };

  // documento `project-settings` no DocumentManager (dirty único do editor; sem contador paralelo)
  useEffect(() => {
    let id: string | null = null;
    let disposed = false;
    void globalDocumentManager
      .open({
        kind: PROJECT_SETTINGS_KIND,
        // um documento por montagem (o StrictMode monta/desmonta/monta: cada efeito fecha só o SEU documento)
        resourceRef: { id: `project-settings:${project.id}:${++docSeq}`, type: 'project-settings', label: 'Project Settings' },
        title: 'Project Settings',
        adapter: {
          readVersionToken: () => null,
          save: () => {
            const result = saveRef.current();
            if (!result.ok) throw new Error(storageError.current ?? result.error);
            return null;
          },
        },
      })
      .then((doc) => {
        id = doc.documentId;
        if (disposed) void globalDocumentManager.close(id, 'discard');
        else setDocId(id);
      });
    return () => {
      disposed = true;
      if (id) void globalDocumentManager.close(id, 'discard');
    };
  }, [project.id]);

  useEffect(() => {
    if (!docId) return;
    if (dirty) globalDocumentManager.markDirty(docId);
    else globalDocumentManager.markClean(docId);
  }, [dirty, docId]);

  // falha de gravação (quota etc.): a mensagem real aparece no modal, que continua aberto com o rascunho
  useEffect(
    () =>
      ProjectStorage.onSaveError((message) => {
        storageError.current = message;
      }),
    []
  );

  const close = () => setIsProjectSettingsOpen(false);

  const trySave = (): boolean => {
    storageError.current = null;
    setSaveError(null);
    const result = docId ? globalDocumentManager.saveNow(docId) : ((r) => (r.ok ? { ok: true as const } : { ok: false as const, error: new Error(r.error) }))(saveRef.current());
    if (result.ok) return true;
    const err = (result as { error?: unknown }).error;
    setSaveError(storageError.current ?? (err instanceof Error ? err.message : 'Não foi possível salvar as configurações.'));
    return false;
  };

  const handleSave = () => {
    if (errorCount > 0) return;
    if (trySave()) close();
  };

  const requestClose = () => {
    if (!dirty) return close();
    void requestDecision({
      title: 'Alterações não salvas',
      message: 'As configurações do projeto têm alterações não salvas.',
      options: SAVE_DISCARD_CANCEL,
    }).then((choice) => {
      if (choice === 'save') {
        if (errorCount === 0 && trySave()) close();
        else if (errorCount > 0) setSaveError(`Corrija ${errorCount} campo(s) com erro antes de salvar.`);
      } else if (choice === 'discard') close();
      // 'cancel' / fechado: permanece aberto
    });
  };

  const requestCloseRef = useRef(requestClose);
  requestCloseRef.current = requestClose;
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape' || e.defaultPrevented || getPendingDecision()) return;
      requestCloseRef.current();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // ── Atualizadores do rascunho (texto; nunca um padrão silencioso) ───────────────────────────────
  const set = <K extends keyof SettingsDraft>(section: K, patch: Partial<SettingsDraft[K]>) =>
    setDraft((d) => ({ ...d, [section]: { ...d[section], ...patch } }));
  const setGravity = (axis: 'x' | 'y' | 'z', value: string) =>
    setDraft((d) => ({ ...d, physics: { ...d.physics, gravity3D: { ...d.physics.gravity3D, [axis]: value } } }));

  const isConfigTab = activeTab !== 'inputMap' && activeTab !== 'variables';

  const tabButton = (tab: Tab, label: string, icon: React.ReactNode) => (
    <button key={tab} onClick={() => setActiveTab(tab)} className={TAB_BTN(activeTab === tab)}>
      {icon}
      <span className="flex-1">{label}</span>
      {tabsWithErrors.has(tab as SettingsTab) && <span className="w-1.5 h-1.5 rounded-full bg-rose-400" title="Há campos com erro nesta aba" />}
    </button>
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) requestClose();
      }}
    >
      <div className="w-[720px] h-[500px] bg-[#1e232f] border border-[#3b475f] rounded-lg shadow-2xl flex flex-col overflow-hidden text-xs">
        {/* Header */}
        <div className="h-10 bg-[#171b24] border-b border-[#2c3345] px-4 flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-white">
            <Settings className="w-4 h-4 text-[#4982ea]" />
            <span>Project Settings ({project.name})</span>
            {dirty && (
              <span className="text-amber-400" title="Alterações não salvas" aria-label="Alterações não salvas">
                ●
              </span>
            )}
          </div>
          <button onClick={requestClose} className="p-1 text-[#8b97a8] hover:text-white" aria-label="Fechar">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Main Content Split: Category Sidebar vs Fields */}
        <div className="flex-1 flex overflow-hidden">
          {/* Category tabs */}
          <div className="w-44 border-r border-[#2c3345] bg-[#1a1e29] p-2 space-y-1 overflow-y-auto">
            {tabButton('general', 'General', <Cpu className="w-3.5 h-3.5" />)}
            {tabButton('display', 'Display / Window', <Monitor className="w-3.5 h-3.5" />)}
            {tabButton('rendering', 'Rendering', <Sparkles className="w-3.5 h-3.5" />)}
            {tabButton('physics', 'Physics', <Shield className="w-3.5 h-3.5" />)}
            {tabButton('audio', 'Audio', <Volume2 className="w-3.5 h-3.5" />)}
            {tabButton('inputMap', 'Input Map', <Keyboard className="w-3.5 h-3.5" />)}
            {tabButton('variables', 'Variables', <Variable className="w-3.5 h-3.5" />)}

            <div className="pt-2 border-t border-[#2c3345]">
              <button
                type="button"
                onClick={() => {
                  setIsProjectSettingsOpen(false);
                  setIsExtensionsPanelOpen(true);
                }}
                className="w-full text-left px-3 py-1.5 rounded flex items-center justify-between text-indigo-300 hover:text-white hover:bg-[#202531] transition-colors"
                title="Painel de extensões (stub) — sistema removido na v4.7.0"
              >
                <div className="flex items-center gap-2">
                  <Puzzle className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Extensões (stub)</span>
                </div>
                <ExternalLink className="w-3 h-3 text-[#6b7280]" />
              </button>
            </div>
          </div>

          {/* Settings Fields */}
          <div className="flex-1 p-5 overflow-y-auto bg-[#181c24]">
            {isConfigTab && (
              <div className="max-w-md flex justify-end mb-3">
                <button
                  type="button"
                  onClick={() => setDraft((d) => resetTabToDefaults(d, activeTab as SettingsTab))}
                  className="flex items-center gap-1.5 px-2 py-1 rounded text-[#8b97a8] hover:text-white hover:bg-[#202531]"
                  title="Repõe os valores padrão só desta aba"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Restaurar padrão</span>
                </button>
              </div>
            )}

            {activeTab === 'general' && (
              <div className="space-y-4 max-w-md">
                <Field label="Project Name" error={errors['general.projectName']}>
                  <input
                    type="text"
                    value={draft.general.projectName}
                    onChange={(e) => set('general', { projectName: e.target.value })}
                    aria-invalid={!!errors['general.projectName']}
                    className={`${INPUT} ${border(errors['general.projectName'])}`}
                  />
                </Field>

                <div className="grid grid-cols-2 gap-3">
                  <Field label="Author" error={errors['general.author']}>
                    <input
                      type="text"
                      value={draft.general.author}
                      onChange={(e) => set('general', { author: e.target.value })}
                      className={`${INPUT} ${border(errors['general.author'])}`}
                    />
                  </Field>
                  <Field label="Version" error={errors['general.version']}>
                    <input
                      type="text"
                      value={draft.general.version}
                      onChange={(e) => set('general', { version: e.target.value })}
                      aria-invalid={!!errors['general.version']}
                      className={`${INPUT} font-mono ${border(errors['general.version'])}`}
                    />
                  </Field>
                </div>

                <Field label="Description" error={errors['general.description']}>
                  <textarea
                    rows={3}
                    value={draft.general.description}
                    onChange={(e) => set('general', { description: e.target.value })}
                    className={`${INPUT} resize-none ${border(errors['general.description'])}`}
                  />
                </Field>

                <Field label="Main Scene" error={errors['general.mainScene']}>
                  <select
                    value={draft.general.mainScene}
                    onChange={(e) => set('general', { mainScene: e.target.value })}
                    aria-invalid={!!errors['general.mainScene']}
                    className={`${INPUT} font-mono ${border(errors['general.mainScene'])}`}
                  >
                    {!scenePaths.includes(draft.general.mainScene) && (
                      <option value={draft.general.mainScene}>{draft.general.mainScene || '(nenhuma)'} — não existe</option>
                    )}
                    {scenePaths.map((path) => (
                      <option key={path} value={path}>
                        {path}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>
            )}

            {activeTab === 'display' && (
              <div className="space-y-4 max-w-md">
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Viewport Width" error={errors['display.width']}>
                    <input
                      type="text"
                      inputMode="numeric"
                      value={draft.display.width}
                      onChange={(e) => set('display', { width: e.target.value })}
                      aria-invalid={!!errors['display.width']}
                      className={`${INPUT} font-mono ${border(errors['display.width'])}`}
                    />
                  </Field>
                  <Field label="Viewport Height" error={errors['display.height']}>
                    <input
                      type="text"
                      inputMode="numeric"
                      value={draft.display.height}
                      onChange={(e) => set('display', { height: e.target.value })}
                      aria-invalid={!!errors['display.height']}
                      className={`${INPUT} font-mono ${border(errors['display.height'])}`}
                    />
                  </Field>
                </div>

                <Field label="Window Mode" error={errors['display.windowMode']} pending={pendingReaderTooltip('display.windowMode')}>
                  <select
                    disabled={!!pendingReaderTooltip('display.windowMode')}
                    value={draft.display.windowMode}
                    onChange={(e) => set('display', { windowMode: e.target.value as SettingsDraft['display']['windowMode'] })}
                    className={`${INPUT} ${border(errors['display.windowMode'])}`}
                  >
                    <option value="windowed">Windowed</option>
                    <option value="fullscreen">Fullscreen</option>
                    <option value="borderless">Borderless</option>
                  </select>
                </Field>

                <Field label="Orientation" error={errors['display.orientation']} pending={pendingReaderTooltip('display.orientation')}>
                  <select
                    disabled={!!pendingReaderTooltip('display.orientation')}
                    value={draft.display.orientation}
                    onChange={(e) => set('display', { orientation: e.target.value as SettingsDraft['display']['orientation'] })}
                    className={`${INPUT} ${border(errors['display.orientation'])}`}
                  >
                    <option value="landscape">Landscape</option>
                    <option value="portrait">Portrait</option>
                    <option value="auto">Auto</option>
                  </select>
                </Field>

                <div className="space-y-2 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-[#dfe4ec]" title={pendingReaderTooltip('display.resizable')}>
                    <input
                      type="checkbox"
                      disabled={!!pendingReaderTooltip('display.resizable')}
                      checked={draft.display.resizable}
                      onChange={(e) => set('display', { resizable: e.target.checked })}
                      className="w-4 h-4 rounded text-[#4982ea]"
                    />
                    <span>Window Resizable</span>
                    {pendingReaderTooltip('display.resizable') && <span className="text-amber-300/80">· {pendingReaderTooltip('display.resizable')}</span>}
                  </label>
                </div>
              </div>
            )}

            {activeTab === 'rendering' && (
              <div className="space-y-4 max-w-md">
                <div>
                  <label className="text-[#8b97a8] text-[11px] block mb-1">Graphics Engine</label>
                  <div className="p-2.5 bg-[#141820] rounded border border-[#2c3345] text-white font-mono flex items-center justify-between">
                    <span>Three.js (WebGL)</span>
                    <span className="text-[10px] text-emerald-400 font-sans font-medium px-2 py-0.5 rounded bg-emerald-500/10">ACTIVE</span>
                  </div>
                  <span className="text-[10px] text-[#8b97a8] mt-1 block">
                    Three.js provides full 3D PBR rendering, shadow maps, camera controls, and interactive 2D Overlays.
                  </span>
                </div>

                <Field label="Anti-Aliasing (MSAA)" error={errors['rendering.msaa']} hint="Lido ao abrir o projeto (o contexto WebGL só aceita antialias na criação); o ajuste fino em tempo de execução chega com o AIS-55.">
                  <select
                    value={draft.rendering.msaa}
                    onChange={(e) => set('rendering', { msaa: e.target.value as SettingsDraft['rendering']['msaa'] })}
                    className={`${INPUT} ${border(errors['rendering.msaa'])}`}
                  >
                    <option value="disabled">Disabled</option>
                    <option value="2x">2x MSAA</option>
                    <option value="4x">4x MSAA</option>
                    <option value="8x">8x MSAA</option>
                  </select>
                </Field>

                <Field label="Shadow Quality" error={errors['rendering.shadowQuality']}>
                  <select
                    value={draft.rendering.shadowQuality}
                    onChange={(e) => set('rendering', { shadowQuality: e.target.value as SettingsDraft['rendering']['shadowQuality'] })}
                    className={`${INPUT} ${border(errors['rendering.shadowQuality'])}`}
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </Field>

                <Field label="Clear Color" error={errors['rendering.clearColor']}>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={/^#[0-9a-fA-F]{6}$/.test(draft.rendering.clearColor) ? draft.rendering.clearColor : '#141822'}
                      onChange={(e) => set('rendering', { clearColor: e.target.value })}
                      className="w-8 h-7 bg-transparent border border-[#2c3345] rounded cursor-pointer"
                      aria-label="Escolher cor de limpeza"
                    />
                    <input
                      type="text"
                      value={draft.rendering.clearColor}
                      onChange={(e) => set('rendering', { clearColor: e.target.value })}
                      aria-invalid={!!errors['rendering.clearColor']}
                      className={`${INPUT} font-mono ${border(errors['rendering.clearColor'])}`}
                    />
                  </div>
                </Field>

                <div className="pt-1 space-y-2">
                  <label className="flex items-center gap-2 cursor-pointer text-[#dfe4ec]">
                    <input
                      type="checkbox"
                      checked={draft.rendering.shadowsEnabled}
                      onChange={(e) => set('rendering', { shadowsEnabled: e.target.checked })}
                      className="w-4 h-4 rounded text-[#4982ea]"
                    />
                    <span>Enable Realtime Shadow Maps</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-[#dfe4ec]">
                    <input
                      type="checkbox"
                      checked={draft.rendering.hdr}
                      onChange={(e) => set('rendering', { hdr: e.target.checked })}
                      className="w-4 h-4 rounded text-[#4982ea]"
                    />
                    <span>HDR</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-[#dfe4ec]" title={pendingReaderTooltip('rendering.vsync')}>
                    <input
                      type="checkbox"
                      disabled={!!pendingReaderTooltip('rendering.vsync')}
                      checked={draft.rendering.vsync}
                      onChange={(e) => set('rendering', { vsync: e.target.checked })}
                      className="w-4 h-4 rounded text-[#4982ea]"
                    />
                    <span>V-Sync</span>
                    {pendingReaderTooltip('rendering.vsync') && <span className="text-amber-300/80">· {pendingReaderTooltip('rendering.vsync')}</span>}
                  </label>
                </div>
              </div>
            )}

            {activeTab === 'physics' && (
              <div className="space-y-4 max-w-md">
                <div title="Cenas já existentes mantêm a própria gravidade (definida na Scene); este valor só vale para cenas novas.">
                  <label className="text-[#8b97a8] text-[11px] block mb-1">Gravidade padrão para novas cenas (m/s²)</label>
                  <div className="grid grid-cols-3 gap-3">
                    {(['x', 'y', 'z'] as const).map((axis) => {
                      const error = errors[`physics.gravity3D.${axis}`];
                      const color = axis === 'x' ? 'text-red-400' : axis === 'y' ? 'text-green-400' : 'text-blue-400';
                      return (
                        <div key={axis}>
                          <div className="flex items-center gap-1.5">
                            <span className={`font-mono font-semibold uppercase ${color}`}>{axis}</span>
                            <input
                              type="text"
                              inputMode="decimal"
                              value={draft.physics.gravity3D[axis]}
                              onChange={(e) => setGravity(axis, e.target.value)}
                              aria-label={`Gravidade ${axis.toUpperCase()}`}
                              aria-invalid={!!error}
                              className={`${INPUT} font-mono ${border(error)}`}
                            />
                          </div>
                          {error && (
                            <span role="alert" className="text-[10px] text-rose-400 mt-1 block">
                              {error}
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                  <span className="text-[10px] text-[#8b97a8] mt-1 block">Cenas existentes mantêm a própria gravidade.</span>
                </div>

                <Field label="Default Linear Damp" error={errors['physics.defaultLinearDamp']} pending={pendingReaderTooltip('physics.defaultLinearDamp')}>
                  <input
                    disabled={!!pendingReaderTooltip('physics.defaultLinearDamp')}
                    type="text"
                    inputMode="decimal"
                    value={draft.physics.defaultLinearDamp}
                    onChange={(e) => set('physics', { defaultLinearDamp: e.target.value })}
                    aria-invalid={!!errors['physics.defaultLinearDamp']}
                    className={`${INPUT} font-mono ${border(errors['physics.defaultLinearDamp'])}`}
                  />
                </Field>
              </div>
            )}

            {activeTab === 'audio' && (
              <div className="space-y-4 max-w-md">
                {(
                  [
                    ['masterVolume', 'Master Volume (0.0 to 1.0)'],
                    ['musicVolume', 'Music Volume (0.0 to 1.0)'],
                    ['sfxVolume', 'SFX Volume (0.0 to 1.0)'],
                  ] as const
                ).map(([key, label]) => {
                  const error = errors[`audio.${key}`];
                  const shown = Number(draft.audio[key].replace(',', '.'));
                  return (
                    <Field key={key} label={label} error={error} pending={pendingReaderTooltip(`audio.${key}`)}>
                      <input
                        disabled={!!pendingReaderTooltip(`audio.${key}`)}
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={Number.isFinite(shown) ? Math.min(1, Math.max(0, shown)) : 0}
                        onChange={(e) => set('audio', { [key]: e.target.value } as Partial<SettingsDraft['audio']>)}
                        aria-label={label}
                        className="w-full"
                      />
                      <div className="text-right text-[11px] text-[#8b97a8] font-mono">{Number.isFinite(shown) ? `${Math.round(shown * 100)}%` : '—'}</div>
                    </Field>
                  );
                })}
              </div>
            )}

            {activeTab === 'inputMap' && (
              <div className="max-w-md text-[#8b97a8] leading-relaxed" data-testid="tab-soon">
                <div className="text-white font-medium mb-1">Input Map</div>
                em breve — o editor do mapa de entradas (teclado, mouse e gamepad) chega com o AIS-58. As ações atuais ficam preservadas no projeto.
              </div>
            )}

            {activeTab === 'variables' && (
              <div className="space-y-3" data-testid="tab-variables">
                <div>
                  <div className="text-white font-medium mb-0.5">Variables (globais)</div>
                  <p className="text-[#8b97a8] leading-relaxed">Pertencem ao projeto e sobrevivem à troca de Scene. As alterações entram em Save Settings (um único Undo).</p>
                </div>
                <VariablesEditor
                  testId="global-vars"
                  emptyHint="Nenhuma variável global. Crie a primeira abaixo."
                  rows={varDraft.map((v) => ({ key: v.id, name: v.name, type: v.type, value: v.value }))}
                  onAdd={({ name, type, value }) => {
                    const r = addGlobal(varDraft, { id: newVariableId(), name, type, value: value === '' ? undefined : type === 'boolean' ? value === 'true' : value });
                    if (!r.ok) return r.error;
                    setVarDraft(r.value);
                    return null;
                  }}
                  onRename={(key, name) => {
                    const r = renameGlobal(varDraft, key, name);
                    if (!r.ok) return r.error;
                    setVarDraft(r.value);
                    return null;
                  }}
                  onUpdate={(key, patch) => {
                    const type = patch.type ?? (varDraft.find((v) => v.id === key)?.type as VariableType);
                    if ('value' in patch && coerceVariableValue(type, patch.value) === null) return `O valor inicial não é ${type}.`;
                    const r = updateGlobal(varDraft, key, patch);
                    if (!r.ok) return r.error;
                    setVarDraft(r.value);
                    return null;
                  }}
                  onRemove={(key) => setVarDraft((list) => removeGlobal(list, key))}
                  consumersOf={(row) => {
                    const before = origVars.find((o) => o.id === row.key);
                    return before ? variableOps.globalConsumers(before.name) : [];
                  }}
                />
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="h-11 bg-[#171b24] border-t border-[#2c3345] px-4 flex items-center justify-between gap-2">
          <div className="min-w-0 flex-1 text-[11px] truncate">
            {saveError ? (
              <span role="alert" className="text-rose-400" title={saveError}>
                {saveError}
              </span>
            ) : dirty ? (
              <span className="text-amber-400">● alterações não salvas</span>
            ) : null}
          </div>
          <button onClick={close} className="px-3 py-1.5 rounded hover:bg-[#2c3345] text-[#b3bed0]" title="Descarta as alterações e fecha">
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={errorCount > 0}
            title={errorCount > 0 ? `${errorCount} campo(s) com erro para corrigir` : undefined}
            className="bg-[#4982ea] hover:bg-[#3d72d6] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-[#4982ea] text-white px-4 py-1.5 rounded font-medium transition-colors flex items-center gap-1.5"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
};
