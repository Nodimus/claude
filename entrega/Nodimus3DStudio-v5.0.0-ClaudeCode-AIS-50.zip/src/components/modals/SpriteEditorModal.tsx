import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useEditor } from '../../core/EditorContext';
import {
  SpriteProject,
  SpriteFrame,
  SpriteAnimation,
  SpriteSheetConfig,
  BillboardMode,
  LightingPreset,
} from '../../types/sprite';
import {
  SPRITE_PRESETS,
  createBlankSpriteProject,
} from '../../utils/spritePresets';
import { SpriteCanvasEditor } from './sprite/SpriteCanvasEditor';
import { SpriteTimeline } from './sprite/SpriteTimeline';
import { SpriteVisualizer3D } from './sprite/SpriteVisualizer3D';
import { SpriteSheetAtlasView } from './sprite/SpriteSheetAtlasView';
import {
  Sparkles,
  Layers,
  Box,
  Download,
  Upload,
  Check,
  Plus,
  Play,
  Pause,
  X,
  Sliders,
  Sun,
  Eye,
  FileCode,
  FolderOpen,
  Save,
  Palette,
} from 'lucide-react';

export const SpriteEditorModal: React.FC = () => {
  const {
    isSpriteEditorOpen,
    setIsSpriteEditorOpen,
    activeScene,
    selectedNodeId,
    selectedNode,
    updateNodeProperties,
    addNode,
    createFile,
    addLog,
  } = useEditor();

  // Active Tab
  const [activeTab, setActiveTab] = useState<'editor' | 'atlas' | 'material'>('editor');

  // Sprite Project State
  const [project, setProject] = useState<SpriteProject>(() => {
    // Default initial preset: Knight Hero
    return SPRITE_PRESETS[0].create();
  });

  // Current Frame & Animation state
  const [activeFrameIndex, setActiveFrameIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [onionSkinEnabled, setOnionSkinEnabled] = useState<boolean>(false);

  // Cache for rendered frame canvases
  const [frameCanvases, setFrameCanvases] = useState<(HTMLCanvasElement | null)[]>([]);

  // Ping-pong animation direction
  const pingPongDirRef = useRef<number>(1);

  // Initialize or re-render frame canvases from project spritesheet
  useEffect(() => {
    const fw = project.sheetConfig.frameWidth || 32;
    const fh = project.sheetConfig.frameHeight || 32;

    const img = new Image();
    img.onload = () => {
      const canvases: (HTMLCanvasElement | null)[] = project.frames.map((frame) => {
        const c = document.createElement('canvas');
        c.width = fw;
        c.height = fh;
        const ctx = c.getContext('2d')!;
        ctx.imageSmoothingEnabled = false;

        if (frame.customDataUrl) {
          const frameImg = new Image();
          frameImg.onload = () => {
            ctx.drawImage(frameImg, 0, 0);
          };
          frameImg.src = frame.customDataUrl;
        } else {
          ctx.drawImage(
            img,
            frame.x,
            frame.y,
            frame.width,
            frame.height,
            0,
            0,
            fw,
            fh
          );
        }
        return c;
      });
      setFrameCanvases(canvases);
    };
    img.src = project.sheetConfig.imageUrl;
  }, [project.sheetConfig.imageUrl, project.frames.length]);

  // Update canvas for specific frame
  const handleUpdateFrameCanvas = useCallback(
    (index: number, canvas: HTMLCanvasElement) => {
      setFrameCanvases((prev) => {
        const next = [...prev];
        next[index] = canvas;
        return next;
      });

      // Update customDataUrl in project frames
      setProject((prev) => {
        const nextFrames = [...prev.frames];
        if (nextFrames[index]) {
          nextFrames[index] = {
            ...nextFrames[index],
            customDataUrl: canvas.toDataURL(),
          };
        }
        return {
          ...prev,
          frames: nextFrames,
        };
      });
    },
    []
  );

  // Animation Playback Loop
  useEffect(() => {
    if (!isPlaying) return;

    const activeAnim =
      project.animations.find((a) => a.id === project.activeAnimationId) ||
      project.animations[0];

    if (!activeAnim || activeAnim.frameIndices.length === 0) return;

    const fps = activeAnim.fps || 8;
    const intervalMs = 1000 / fps;

    const interval = setInterval(() => {
      setActiveFrameIndex((prevIndex) => {
        const frameIndices = activeAnim.frameIndices;
        const currentPosInAnim = frameIndices.indexOf(prevIndex);

        if (activeAnim.loopMode === 'once') {
          if (currentPosInAnim >= frameIndices.length - 1) {
            setIsPlaying(false);
            return prevIndex;
          }
          return frameIndices[currentPosInAnim + 1];
        } else if (activeAnim.loopMode === 'ping-pong') {
          let nextPos = currentPosInAnim + pingPongDirRef.current;
          if (nextPos >= frameIndices.length) {
            pingPongDirRef.current = -1;
            nextPos = Math.max(0, frameIndices.length - 2);
          } else if (nextPos < 0) {
            pingPongDirRef.current = 1;
            nextPos = Math.min(frameIndices.length - 1, 1);
          }
          return frameIndices[nextPos] ?? frameIndices[0];
        } else {
          // Standard Loop
          const nextPos = (currentPosInAnim + 1) % frameIndices.length;
          return frameIndices[nextPos];
        }
      });
    }, intervalMs);

    return () => clearInterval(interval);
  }, [isPlaying, project.activeAnimationId, project.animations]);

  // Frame Stepping
  const handleStepFrame = (dir: number) => {
    const activeAnim =
      project.animations.find((a) => a.id === project.activeAnimationId) ||
      project.animations[0];
    if (!activeAnim) return;

    const frameIndices = activeAnim.frameIndices;
    if (dir === 1000) {
      setActiveFrameIndex(frameIndices[frameIndices.length - 1]);
    } else if (dir === -1000) {
      setActiveFrameIndex(frameIndices[0]);
    } else {
      const currentPos = frameIndices.indexOf(activeFrameIndex);
      const nextPos = (currentPos + dir + frameIndices.length) % frameIndices.length;
      setActiveFrameIndex(frameIndices[nextPos]);
    }
  };

  // Add blank frame
  const handleAddFrame = () => {
    const fw = project.sheetConfig.frameWidth || 32;
    const fh = project.sheetConfig.frameHeight || 32;
    const newIdx = project.frames.length;

    const dummyCanvas = document.createElement('canvas');
    dummyCanvas.width = fw;
    dummyCanvas.height = fh;

    const newFrame: SpriteFrame = {
      id: `frame_${Date.now()}`,
      index: newIdx,
      x: 0,
      y: 0,
      width: fw,
      height: fh,
      durationMs: 100,
      customDataUrl: dummyCanvas.toDataURL(),
    };

    setProject((prev) => {
      const nextFrames = [...prev.frames, newFrame];
      const nextAnimations = prev.animations.map((anim) => {
        if (anim.id === prev.activeAnimationId) {
          return {
            ...anim,
            frameIndices: [...anim.frameIndices, newIdx],
          };
        }
        return anim;
      });

      return {
        ...prev,
        frames: nextFrames,
        animations: nextAnimations,
      };
    });

    setFrameCanvases((prev) => [...prev, dummyCanvas]);
    setActiveFrameIndex(newIdx);
  };

  // Duplicate frame
  const handleDuplicateFrame = (index: number) => {
    const frame = project.frames[index];
    if (!frame) return;

    const newIdx = project.frames.length;
    const canvas = frameCanvases[index];
    const dataUrl = canvas ? canvas.toDataURL() : frame.customDataUrl;

    const newFrame: SpriteFrame = {
      ...frame,
      id: `frame_${Date.now()}`,
      index: newIdx,
      customDataUrl: dataUrl,
    };

    setProject((prev) => {
      const nextFrames = [...prev.frames, newFrame];
      const nextAnimations = prev.animations.map((anim) => {
        if (anim.id === prev.activeAnimationId) {
          return {
            ...anim,
            frameIndices: [...anim.frameIndices, newIdx],
          };
        }
        return anim;
      });

      return {
        ...prev,
        frames: nextFrames,
        animations: nextAnimations,
      };
    });

    setFrameCanvases((prev) => [...prev, canvas || null]);
    setActiveFrameIndex(newIdx);
  };

  // Delete frame
  const handleDeleteFrame = (index: number) => {
    if (project.frames.length <= 1) return;

    setProject((prev) => {
      const nextFrames = prev.frames.filter((_, idx) => idx !== index);
      // Remap frame indices in animations
      const nextAnimations = prev.animations.map((anim) => ({
        ...anim,
        frameIndices: anim.frameIndices
          .filter((idx) => idx !== index)
          .map((idx) => (idx > index ? idx - 1 : idx)),
      }));

      return {
        ...prev,
        frames: nextFrames,
        animations: nextAnimations,
      };
    });

    setFrameCanvases((prev) => prev.filter((_, idx) => idx !== index));
    setActiveFrameIndex(Math.max(0, index - 1));
  };

  // Move frame in strip
  const handleMoveFrame = (fromIndex: number, toIndex: number) => {
    if (toIndex < 0 || toIndex >= project.frames.length) return;

    setProject((prev) => {
      const nextFrames = [...prev.frames];
      const [moved] = nextFrames.splice(fromIndex, 1);
      nextFrames.splice(toIndex, 0, moved);

      return {
        ...prev,
        frames: nextFrames,
      };
    });

    setFrameCanvases((prev) => {
      const next = [...prev];
      const [moved] = next.splice(fromIndex, 1);
      next.splice(toIndex, 0, moved);
      return next;
    });

    setActiveFrameIndex(toIndex);
  };

  // Load preset
  const handleLoadPreset = (presetId: string) => {
    const item = SPRITE_PRESETS.find((p) => p.id === presetId);
    if (!item) return;
    const newProj = item.create();
    setProject(newProj);
    setActiveFrameIndex(0);
    setIsPlaying(true);
    addLog('log', `Preset de sprite carregado: ${item.name}`);
  };

  // Upload image
  const handleUploadImage = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      const img = new Image();
      img.onload = () => {
        const fw = 32;
        const fh = 32;
        const cols = Math.max(1, Math.floor(img.width / fw));
        const rows = Math.max(1, Math.floor(img.height / fh));
        const total = cols * rows;

        const frames: SpriteFrame[] = [];
        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            frames.push({
              id: `frame_${r * cols + c}`,
              index: r * cols + c,
              x: c * fw,
              y: r * fh,
              width: fw,
              height: fh,
              durationMs: 100,
            });
          }
        }

        const newConfig: SpriteSheetConfig = {
          name: file.name.replace(/\.[^/.]+$/, ''),
          imageUrl: dataUrl,
          imageWidth: img.width,
          imageHeight: img.height,
          frameWidth: fw,
          frameHeight: fh,
          columns: cols,
          rows,
          spacing: 0,
          margin: 0,
          totalFrames: total,
        };

        setProject((prev) => ({
          ...prev,
          name: newConfig.name,
          sheetConfig: newConfig,
          frames,
          animations: [
            {
              id: 'anim_default',
              name: 'anim_1',
              frameIndices: frames.map((_, i) => i),
              fps: 8,
              loopMode: 'loop',
            },
          ],
          activeAnimationId: 'anim_default',
          currentFrameIndex: 0,
        }));

        setActiveFrameIndex(0);
        addLog('log', `Imagem de sprite importada: ${file.name} (${img.width}x${img.height}px)`);
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  // Slice grid
  const handleSliceGrid = (cols: number, rows: number, fw: number, fh: number) => {
    const frames: SpriteFrame[] = [];
    const total = cols * rows;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        frames.push({
          id: `frame_${r * cols + c}`,
          index: r * cols + c,
          x: c * fw,
          y: r * fh,
          width: fw,
          height: fh,
          durationMs: 100,
        });
      }
    }

    setProject((prev) => ({
      ...prev,
      sheetConfig: {
        ...prev.sheetConfig,
        columns: cols,
        rows,
        frameWidth: fw,
        frameHeight: fh,
        totalFrames: total,
      },
      frames,
      animations: [
        {
          id: 'anim_default',
          name: 'anim_1',
          frameIndices: frames.map((_, i) => i),
          fps: 8,
          loopMode: 'loop',
        },
      ],
      activeAnimationId: 'anim_default',
      currentFrameIndex: 0,
    }));

    setActiveFrameIndex(0);
    addLog('log', `Grade fatiada com sucesso: ${cols} colunas x ${rows} linhas (${total} quadros)`);
  };

  // Export Spritesheet PNG
  const handleExportPng = () => {
    const fw = project.sheetConfig.frameWidth || 32;
    const fh = project.sheetConfig.frameHeight || 32;
    const cols = project.sheetConfig.columns || 4;
    const rows = Math.ceil(project.frames.length / cols);

    const canvas = document.createElement('canvas');
    canvas.width = cols * fw;
    canvas.height = rows * fh;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;

    project.frames.forEach((frame, idx) => {
      const c = idx % cols;
      const r = Math.floor(idx / cols);
      const frameCanvas = frameCanvases[idx];
      if (frameCanvas) {
        ctx.drawImage(frameCanvas, c * fw, r * fh);
      }
    });

    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = `${project.name}_spritesheet.png`;
    a.click();
    addLog('log', `Spritesheet exportado: ${project.name}_spritesheet.png`);
  };

  // Direct Engine Action: Create Sprite3D / Billboard Node in Scene
  const handleAddToScene = () => {
    const sx = project.settings3D.renderScale.x;
    const sy = project.settings3D.renderScale.y;

    // Criação + propriedades finais num único Command (antes: criar e depois alterar = 2 entradas de Undo)
    const billboard = addNode('Billboard', null, `${project.name}_Sprite3D`, {
      width: sx,
      height: sy,
      color: project.settings3D.tintColor,
      alwaysFaceCamera: project.settings3D.billboardMode === 'spherical',
      spriteProject: project,
      texture: `res://sprites/${project.name}.png`,
    });

    // Save project into virtual file system
    createFile(
      `res://sprites/${project.name}.sprite.json`,
      JSON.stringify(project, null, 2)
    );

    addLog('log', `Nó Sprite 3D '${billboard.name}' adicionado à cena e salvo em res://sprites/`);
  };

  // Direct Engine Action: Apply to selected node
  const handleApplyToSelectedNode = () => {
    if (!selectedNodeId) return;
    const sx = project.settings3D.renderScale.x;
    const sy = project.settings3D.renderScale.y;

    updateNodeProperties(selectedNodeId, {
      width: sx,
      height: sy,
      color: project.settings3D.tintColor,
      spriteProject: project,
    });

    addLog('log', `Configurações do Sprite aplicadas ao nó selecionado #${selectedNodeId}`);
  };

  // Save to Virtual Filesystem
  const handleSaveToFilesystem = () => {
    const path = `res://sprites/${project.name}.sprite.json`;
    createFile(path, JSON.stringify(project, null, 2));
    addLog('log', `Projeto Sprite salvo com sucesso em ${path}`);
  };

  if (!isSpriteEditorOpen) return null;

  const currentCanvas = frameCanvases[activeFrameIndex] || null;
  const prevCanvas = frameCanvases[activeFrameIndex - 1] || null;
  const nextCanvas = frameCanvases[activeFrameIndex + 1] || null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in select-none">
      <div className="flex flex-col w-[96vw] max-w-[1340px] h-[92vh] bg-[#1a1f2c] border border-[#2e3748] rounded-xl shadow-2xl overflow-hidden text-[#dfe4ec]">
        {/* Modal Header */}
        <header className="flex items-center justify-between px-4 py-2.5 bg-[#202531] border-b border-[#2c3345] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-md">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white tracking-wide">
                  Sprite Studio & Visualizador 3D
                </h2>
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-sky-500/20 text-sky-300 font-semibold border border-sky-500/30">
                  Three.js Billboard & Atlas
                </span>
              </div>
              <p className="text-[11px] text-[#8b97a8]">
                Editor de Pixel Art, Sequenciador de Animações e Visualizador 3D em Tempo Real
              </p>
            </div>
          </div>

          {/* Quick Actions & Close */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleAddToScene}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs shadow-md transition-colors"
              title="Instanciar novo nó Billboard 3D na cena ativa"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Adicionar Sprite3D à Cena</span>
            </button>

            {selectedNode && (
              <button
                onClick={handleApplyToSelectedNode}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#273042] hover:bg-[#344059] text-sky-300 hover:text-white border border-[#3b475e] text-xs transition-colors"
                title={`Aplicar ao nó selecionado: ${selectedNode.name}`}
              >
                <Check className="w-3.5 h-3.5" />
                <span>Aplicar no Nó Ativo</span>
              </button>
            )}

            <button
              onClick={handleSaveToFilesystem}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#273042] hover:bg-[#344059] text-[#cbd5e1] hover:text-white border border-[#3b475e] text-xs transition-colors"
              title="Salvar arquivo .sprite.json em res://sprites/"
            >
              <Save className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Salvar</span>
            </button>

            <button
              onClick={handleExportPng}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#273042] hover:bg-[#344059] text-sky-300 hover:text-white border border-[#3b475e] text-xs transition-colors"
              title="Baixar Spritesheet empacotado (PNG)"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Baixar PNG</span>
            </button>

            <div className="h-5 w-[1px] bg-[#374158] mx-1" />

            <button
              onClick={() => setIsSpriteEditorOpen(false)}
              className="p-1.5 rounded-lg text-[#8b97a8] hover:text-white hover:bg-[#2c3345] transition-colors"
              title="Fechar (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Tab Navigation */}
        <div className="flex items-center justify-between px-4 py-1.5 bg-[#181c24] border-b border-[#2c3345] shrink-0 text-xs">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveTab('editor')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
                activeTab === 'editor'
                  ? 'bg-[#4982ea] text-white shadow-sm'
                  : 'text-[#9ca7b7] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Editor de Pixel & Desenho 2D</span>
            </button>

            <button
              onClick={() => setActiveTab('atlas')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
                activeTab === 'atlas'
                  ? 'bg-[#4982ea] text-white shadow-sm'
                  : 'text-[#9ca7b7] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <Box className="w-3.5 h-3.5" />
              <span>Spritesheet & Fatiamento (Atlas)</span>
            </button>

            <button
              onClick={() => setActiveTab('material')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
                activeTab === 'material'
                  ? 'bg-[#4982ea] text-white shadow-sm'
                  : 'text-[#9ca7b7] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Material 3D & Iluminação (Three.js)</span>
            </button>
          </div>

          {/* Project Name Input */}
          <div className="flex items-center gap-2">
            <span className="text-[#64748b] text-[11px]">Nome do Sprite:</span>
            <input
              type="text"
              value={project.name}
              onChange={(e) => setProject({ ...project, name: e.target.value })}
              className="bg-[#202531] text-xs font-semibold text-white px-2 py-0.5 rounded border border-[#3b475e] w-36 focus:outline-none focus:border-sky-400"
            />
          </div>
        </div>

        {/* Modal Body / Tab Views */}
        <div className="flex-1 overflow-hidden flex flex-col">
          {/* TAB 1: 2D Pixel Canvas + 3D Viewport Split */}
          {activeTab === 'editor' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="flex-1 flex overflow-hidden">
                {/* Left 58%: 2D Canvas Editor */}
                <div className="w-[58%] h-full flex flex-col border-r border-[#2c3345] overflow-hidden">
                  <SpriteCanvasEditor
                    project={project}
                    activeFrameIndex={activeFrameIndex}
                    onUpdateFrameCanvas={handleUpdateFrameCanvas}
                    onionSkinEnabled={onionSkinEnabled}
                    onToggleOnionSkin={() => setOnionSkinEnabled(!onionSkinEnabled)}
                    previousFrameCanvas={prevCanvas}
                    nextFrameCanvas={nextCanvas}
                  />
                </div>

                {/* Right 42%: 3D Viewport in Real-Time */}
                <div className="w-[42%] h-full flex flex-col overflow-hidden bg-[#141822]">
                  <SpriteVisualizer3D
                    project={project}
                    currentFrameCanvas={currentCanvas}
                    isPlaying={isPlaying}
                    onTogglePlay={() => setIsPlaying(!isPlaying)}
                  />
                </div>
              </div>

              {/* Bottom: Timeline Sequencer */}
              <SpriteTimeline
                project={project}
                currentFrameIndex={activeFrameIndex}
                onSelectFrame={(idx) => setActiveFrameIndex(idx)}
                isPlaying={isPlaying}
                onTogglePlay={() => setIsPlaying(!isPlaying)}
                onStepFrame={handleStepFrame}
                onAddFrame={handleAddFrame}
                onDuplicateFrame={handleDuplicateFrame}
                onDeleteFrame={handleDeleteFrame}
                onMoveFrame={handleMoveFrame}
                onSelectAnimation={(animId) =>
                  setProject({ ...project, activeAnimationId: animId })
                }
                onAddAnimation={(name) => {
                  const newAnim: SpriteAnimation = {
                    id: `anim_${Date.now()}`,
                    name,
                    frameIndices: [activeFrameIndex],
                    fps: 8,
                    loopMode: 'loop',
                  };
                  setProject({
                    ...project,
                    animations: [...project.animations, newAnim],
                    activeAnimationId: newAnim.id,
                  });
                }}
                onUpdateAnimation={(updated) => {
                  setProject({
                    ...project,
                    animations: project.animations.map((a) =>
                      a.id === updated.id ? updated : a
                    ),
                  });
                }}
                onDeleteAnimation={(animId) => {
                  const remaining = project.animations.filter((a) => a.id !== animId);
                  setProject({
                    ...project,
                    animations: remaining,
                    activeAnimationId: remaining[0]?.id || '',
                  });
                }}
                frameCanvases={frameCanvases}
              />
            </div>
          )}

          {/* TAB 2: Spritesheet & Grid Slicing */}
          {activeTab === 'atlas' && (
            <SpriteSheetAtlasView
              project={project}
              onUpdateSheetConfig={(cfg) => setProject({ ...project, sheetConfig: cfg })}
              onSelectFrame={(idx) => {
                setActiveFrameIndex(idx);
                setActiveTab('editor');
              }}
              onLoadPreset={handleLoadPreset}
              onUploadImage={handleUploadImage}
              onSliceGrid={handleSliceGrid}
              currentFrameIndex={activeFrameIndex}
            />
          )}

          {/* TAB 3: Material 3D & Iluminação */}
          {activeTab === 'material' && (
            <div className="flex-1 flex overflow-hidden p-6 gap-6 bg-[#141822] overflow-y-auto">
              {/* Left Column: Properties */}
              <div className="w-1/2 flex flex-col gap-5 bg-[#1c222e] p-5 rounded-xl border border-[#2e3748] shadow-lg">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-sky-400" />
                  Propriedades do Material 3D & Billboard
                </h3>

                {/* Billboard Mode */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-[#9ca7b7] font-medium">
                    Modo Billboard (Alinhamento com a Câmera):
                  </label>
                  <select
                    value={project.settings3D.billboardMode}
                    onChange={(e) =>
                      setProject({
                        ...project,
                        settings3D: {
                          ...project.settings3D,
                          billboardMode: e.target.value as BillboardMode,
                        },
                      })
                    }
                    className="bg-[#141822] text-xs text-white border border-[#374158] rounded-lg p-2 focus:outline-none focus:border-sky-400"
                  >
                    <option value="spherical">
                      Esférico (Olhar para Câmera em Todos os Eixos) - Estilo Doom/RPG
                    </option>
                    <option value="cylindrical_y">
                      Cilíndrico Y (Girar apenas no Eixo Y - Em Pé no Chão)
                    </option>
                    <option value="flat_quad">
                      Quad Plano Fixo (Parede / Decalque no Mundo 3D)
                    </option>
                    <option value="isometric">
                      Perspectiva Isométrica (Ângulo Fixo 45°)
                    </option>
                  </select>
                </div>

                {/* Render Scale */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs text-[#9ca7b7]">Escala Largura (m):</label>
                    <input
                      type="number"
                      step="0.1"
                      min="0.1"
                      max="20"
                      value={project.settings3D.renderScale.x}
                      onChange={(e) =>
                        setProject({
                          ...project,
                          settings3D: {
                            ...project.settings3D,
                            renderScale: {
                              ...project.settings3D.renderScale,
                              x: parseFloat(e.target.value) || 1,
                            },
                          },
                        })
                      }
                      className="bg-[#141822] text-xs text-white border border-[#374158] rounded-lg p-2"
                    />
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs text-[#9ca7b7]">Escala Altura (m):</label>
                    <input
                      type="number"
                      step="0.1"
                      min="0.1"
                      max="20"
                      value={project.settings3D.renderScale.y}
                      onChange={(e) =>
                        setProject({
                          ...project,
                          settings3D: {
                            ...project.settings3D,
                            renderScale: {
                              ...project.settings3D.renderScale,
                              y: parseFloat(e.target.value) || 1,
                            },
                          },
                        })
                      }
                      className="bg-[#141822] text-xs text-white border border-[#374158] rounded-lg p-2"
                    />
                  </div>
                </div>

                {/* Pixel-Art Filter Toggle */}
                <div className="flex items-center justify-between p-3 bg-[#141822] rounded-lg border border-[#2e3748]">
                  <div>
                    <div className="text-xs font-semibold text-white">
                      Filtro Pixel-Art Nítido (NearestFilter)
                    </div>
                    <div className="text-[11px] text-[#8b97a8]">
                      Preserva os pixels nítidos sem borramento bilinear
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={project.settings3D.pixelPerfectFilter}
                    onChange={(e) =>
                      setProject({
                        ...project,
                        settings3D: {
                          ...project.settings3D,
                          pixelPerfectFilter: e.target.checked,
                        },
                      })
                    }
                    className="w-4 h-4 rounded text-sky-500 accent-sky-500"
                  />
                </div>

                {/* Alpha Test Cutoff */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-[#9ca7b7]">Corte Alfa (Alpha Test Cutoff):</span>
                    <span className="font-mono text-white">
                      {project.settings3D.alphaTest.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={project.settings3D.alphaTest}
                    onChange={(e) =>
                      setProject({
                        ...project,
                        settings3D: {
                          ...project.settings3D,
                          alphaTest: parseFloat(e.target.value),
                        },
                      })
                    }
                    className="accent-sky-500"
                  />
                </div>

                {/* Emissive Glow */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs text-[#9ca7b7]">Cor Emissiva (Brilho):</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={project.settings3D.emissiveColor}
                        onChange={(e) =>
                          setProject({
                            ...project,
                            settings3D: {
                              ...project.settings3D,
                              emissiveColor: e.target.value,
                            },
                          })
                        }
                        className="w-8 h-8 rounded border-0 cursor-pointer bg-transparent"
                      />
                      <span className="font-mono text-xs uppercase text-white">
                        {project.settings3D.emissiveColor}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <div className="flex justify-between text-xs">
                      <span className="text-[#9ca7b7]">Intensidade do Brilho:</span>
                      <span className="font-mono text-white">
                        {project.settings3D.emissiveIntensity.toFixed(1)}
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="3"
                      step="0.1"
                      value={project.settings3D.emissiveIntensity}
                      onChange={(e) =>
                        setProject({
                          ...project,
                          settings3D: {
                            ...project.settings3D,
                            emissiveIntensity: parseFloat(e.target.value),
                          },
                        })
                      }
                      className="accent-sky-500"
                    />
                  </div>
                </div>

                {/* Lighting Presets */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs text-[#9ca7b7]">Ambiente de Iluminação:</label>
                  <select
                    value={project.settings3D.environmentLighting}
                    onChange={(e) =>
                      setProject({
                        ...project,
                        settings3D: {
                          ...project.settings3D,
                          environmentLighting: e.target.value as LightingPreset,
                        },
                      })
                    }
                    className="bg-[#141822] text-xs text-white border border-[#374158] rounded-lg p-2 focus:outline-none focus:border-sky-400"
                  >
                    <option value="studio">Estúdio Neutro (Chave Branca + Fill Azulada)</option>
                    <option value="cyberpunk">Cyberpunk Neon (Ciano + Magenta)</option>
                    <option value="night">Noite Enluarada (Azul Escuro Suave)</option>
                    <option value="sunset">Pôr do Sol (Laranja Quente + Púrpura)</option>
                    <option value="retro_arcade">Fliperama Retrô (Verde Neon + Fundo Escuro)</option>
                  </select>
                </div>
              </div>

              {/* Right Column: Live 3D Preview */}
              <div className="w-1/2 h-full flex flex-col rounded-xl overflow-hidden border border-[#2e3748] bg-[#141822] shadow-lg">
                <SpriteVisualizer3D
                  project={project}
                  currentFrameCanvas={currentCanvas}
                  isPlaying={isPlaying}
                  onTogglePlay={() => setIsPlaying(!isPlaying)}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
