import React, { useEffect, useMemo, useState } from 'react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { globalCommandManager } from '../../core/commandManager';
import { globalResourceRegistry } from '../../core/resources/global';
import { useResourceRegistryVersion } from '../../core/resources/useResources';
import { useGeneratorEdit } from '../../core/generators/useGeneratorEdit';
import { createSetGeneratorSourceCommand } from '../../core/generators/generatorCommands';
import { globalAuthoringModel } from '../../core/authoring';
import { applyTerrainChanges, regenerateTerrainGeometry, registerTerrainGenerator, TERRAIN_GENERATOR_ID } from '../../core/generators/terrainGenerator';
import {
  TERRAIN_HIGH_TEXTURES,
  TERRAIN_GROUND_TEXTURES,
  TERRAIN_MID_TEXTURES,
  TERRAIN_PRESETS,
  TERRAIN_SEGMENT_OPTIONS,
  TERRAIN_TEXTURE_COLORS,
  type TerrainPreset,
} from '../../core/terrainGeometry';
import {
  draftChanges,
  draftFromProps,
  geometryDirty,
  hasSculptedHeights,
  normalizeDraft,
  regenerateChanges,
  terrainGeneratorSource,
  visualOnlyChanges,
  type TerrainDraft,
} from '../../core/terrainOps';
import { HeightmapPicker } from '../inspector/TerrainSection';
import { Mountain, Trees, X, Upload, RotateCcw, Check, Palette, Info, Lock, TriangleAlert } from 'lucide-react';

/** Mantido por compatibilidade com quem importava o tipo (preset de topologia = `terrainPreset`). */
export type TerrainTopology = TerrainPreset;

const LOCKED_TIP = 'Terreno editado manualmente: este campo exige geometria nova. Use "Regenerar geometria" (descarta a escultura).';
const nameOf = (uri: string) => uri.split('/').pop() ?? uri;

/**
 * AIS-50 — editor do nó `Terrain` (decisão 23). É só uma VIEW de edição: lê as `properties` do nó (o selecionado, ou o alvo de
 * "Editar no gerador"), guarda um rascunho de UI e grava por Command (um Undo). Não tem geometria nem estado de terreno próprios
 * e nunca cria `MeshInstance` com `isTerrain`; o preview é a viewport 3D real (o resultado aparece ao aplicar).
 * Abas: Gerar e Texturas. Escultura é do AIS-50b; Vegetação (AIS-51d) fica desabilitada ("em breve", decisão 14).
 */
export const TerrainEditorModal: React.FC = () => {
  const { isTerrainEditorOpen, setIsTerrainEditorOpen, activeScene, addNode, selectNode, addLog } = useEditor();
  const selectedNodeId = useEditorStore((s) => s.selectedNodeId);
  const endGeneratorEdit = useEditorStore((s) => s.endGeneratorEdit);
  const gen = useGeneratorEdit(TERRAIN_GENERATOR_ID);
  useResourceRegistryVersion();

  // "Editar no gerador" registra o gerador (disposer devolvido no unmount, AIS-48b)
  useEffect(() => registerTerrainGenerator(), []);

  // alvo: o nó de "Editar no gerador" ou o Terrain selecionado; sem nenhum, o modal cria um novo
  const selected = selectedNodeId ? activeScene.nodes[selectedNodeId] : undefined;
  const node = gen.editing && gen.nodeId ? activeScene.nodes[gen.nodeId] : selected?.type === 'Terrain' ? selected : undefined;
  const sculpted = hasSculptedHeights(node?.properties);

  const [activeTab, setActiveTab] = useState<'generate' | 'textures'>('generate');
  const [draft, setDraft] = useState<TerrainDraft>(() => draftFromProps(undefined));
  const [pickerOpen, setPickerOpen] = useState(false);
  const [confirmRegenerate, setConfirmRegenerate] = useState(false);

  // o rascunho recomeça a cada abertura/troca de nó (nunca fica estado de terreno entre aberturas)
  useEffect(() => {
    if (!isTerrainEditorOpen) return;
    setDraft(draftFromProps(node?.properties));
    setActiveTab('generate');
    setConfirmRegenerate(false);
    setPickerOpen(false);
  }, [isTerrainEditorOpen, node?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const set = <K extends keyof TerrainDraft>(key: K, value: TerrainDraft[K]) => setDraft((d) => ({ ...d, [key]: value }));

  const heightmapEntry = useMemo(() => {
    if (!draft.heightmapRef) return null;
    const r = globalResourceRegistry.resolve(draft.heightmapRef);
    return r.status === 'resolved' ? r.entry : null;
  }, [draft.heightmapRef, globalResourceRegistry.version]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!isTerrainEditorOpen) return null;

  const normalized = normalizeDraft(draft);
  const allChanges = node ? draftChanges(node.properties, normalized) : {};
  const visualChanges = node ? visualOnlyChanges(node.properties, normalized) : {};
  const dirtyGeometry = node ? geometryDirty(node.properties, normalized) : false;

  const close = () => {
    endGeneratorEdit(); // fechar sem aplicar não altera o nó
    setIsTerrainEditorOpen(false);
  };

  /** Aplica por Command: via `useGeneratorEdit` quando veio de "Editar no gerador", senão direto (os dois = um `MacroCommand`). */
  const applyToNode = (changes: Record<string, any>, label: string): boolean => {
    if (!node) return false;
    if (gen.editing) {
      const source = terrainGeneratorSource({ ...node.properties, ...changes });
      return gen.apply(changes, source);
    }
    return applyTerrainChanges(node.id, changes, label);
  };

  const handleApply = () => {
    if (!node) return;
    applyToNode(allChanges, 'Aplicar ao nó');
    addLog('log', `Terrain '${node.name}' atualizado.`);
    close();
  };

  const handleApplyVisual = () => {
    if (!node) return;
    applyToNode(visualChanges, 'Atualizar parâmetros visuais');
    addLog('log', `Parâmetros visuais de '${node.name}' atualizados.`);
    close();
  };

  const handleRegenerate = async () => {
    if (!node) return;
    if (sculpted && !confirmRegenerate) {
      setConfirmRegenerate(true); // nunca regenera em silêncio: a escultura será descartada
      return;
    }
    const changes = sculpted ? regenerateChanges(node.properties, normalized) : draftChanges(node.properties, normalized, ['width', 'depth', 'segmentsW', 'segmentsH', 'maxHeight', 'terrainPreset', 'presetSeed', 'heightmapRef', 'invertHeightmap', 'smoothHeightmap']);
    const result = await regenerateTerrainGeometry(node.id, changes);
    if (result.deletedFile) addLog('log', `Escultura descartada: ${result.deletedFile} removido.`);
    addLog('log', `Geometria de '${node.name}' regenerada.`);
    close();
  };

  /** Cria um Terrain novo (modo criar, ou "Inserir novo" em modo edição): nó + marca de origem = UMA transação (um Undo). */
  const handleCreateNew = () => {
    const initial = { ...draftChanges(undefined, normalized), heightBufferRef: null };
    const created = globalCommandManager.transaction('Create Terrain', () => {
      const n = addNode('Terrain', activeScene.rootNodeId, 'Terrain', initial);
      const command = createSetGeneratorSourceCommand({ target: globalAuthoringModel, nodeId: n.id, source: terrainGeneratorSource({ ...n.properties, ...initial }) });
      if (command) globalCommandManager.execute(command);
      return n;
    });
    selectNode(created.id);
    addLog('log', `Terrain '${created.name}' criado (${normalized.segmentsW}x${normalized.segmentsH}).`);
    close();
  };

  const swatch = (name: string) => TERRAIN_TEXTURE_COLORS[name]?.color ?? '#808080';
  const textureSelect = (value: string, names: readonly string[], onChange: (v: string) => void) => (
    <select value={value} onChange={(e) => onChange(e.target.value)} className="w-full px-2 py-1 bg-[#202636] border border-[#2c3345] rounded text-white">
      {names.map((n) => (
        <option key={n} value={n}>
          {TERRAIN_TEXTURE_COLORS[n]?.label ?? n}
        </option>
      ))}
    </select>
  );
  const lockedProps = (locked: boolean) => (locked ? { disabled: true, title: LOCKED_TIP } : {});

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none" data-testid="terrain-editor-modal">
      <div className="w-[840px] h-[610px] bg-[#1e232f] border border-[#3b475f] rounded-lg shadow-2xl flex flex-col overflow-hidden text-xs text-[#dfe4ec]">
        {/* Header */}
        <div className="h-11 bg-[#171b24] border-b border-[#2c3345] px-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5 font-semibold text-white">
            <div className="p-1 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Mountain className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[13px]">Terrain Editor & Generator</span>
                <span className="px-1.5 py-0.2 bg-[#2a3244] text-[#8b97a8] rounded text-[10px] font-normal">{node ? `Editando: ${node.name}` : 'Novo Terrain'}</span>
                {sculpted && (
                  <span data-testid="terrain-sculpted-seal" className="px-1.5 py-0.2 bg-amber-500/15 text-amber-300 border border-amber-500/30 rounded text-[10px] font-normal">
                    Terreno editado manualmente
                  </span>
                )}
              </div>
              <div className="text-[10px] text-[#8b97a8] font-normal">
                Scene: <span className="text-white">{activeScene?.name}</span>
              </div>
            </div>
          </div>
          <button onClick={close} aria-label="Fechar" className="p-1 text-[#8b97a8] hover:text-white rounded hover:bg-[#2c3345] transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar Tabs */}
          <div className="w-48 border-r border-[#2c3345] bg-[#171b24] p-2 space-y-1">
            <button
              onClick={() => setActiveTab('generate')}
              className={`w-full text-left px-3 py-2 rounded flex items-center gap-2 transition-colors ${activeTab === 'generate' ? 'bg-[#4982ea] text-white font-medium shadow-sm' : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'}`}
            >
              <Mountain className="w-3.5 h-3.5 text-amber-400" />
              <span>Generation & Size</span>
            </button>
            <button
              onClick={() => setActiveTab('textures')}
              className={`w-full text-left px-3 py-2 rounded flex items-center gap-2 transition-colors ${activeTab === 'textures' ? 'bg-[#4982ea] text-white font-medium shadow-sm' : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'}`}
            >
              <Palette className="w-3.5 h-3.5 text-sky-400" />
              <span>Textures & Splatting</span>
            </button>
            <button
              disabled
              title="em breve — vegetação sobre o terreno chega com o AIS-51d"
              className="w-full text-left px-3 py-2 rounded flex items-center gap-2 text-[#5b667a] cursor-not-allowed opacity-60"
            >
              <Trees className="w-3.5 h-3.5" />
              <span>Vegetação (em breve)</span>
            </button>

            <div className="pt-3">
              <div className="px-2 pb-1 text-[10px] font-semibold text-[#68768e] uppercase tracking-wider">Preview</div>
              <div className="p-2 rounded bg-[#13161f] border border-[#2c3345] text-[10px] text-[#8b97a8] space-y-1" data-testid="terrain-preview-note">
                <div className="flex items-start gap-1.5">
                  <Info className="w-3 h-3 mt-0.5 shrink-0 text-sky-400" />
                  <span>O preview é a viewport 3D: o resultado aparece ao aplicar (Ctrl+Z desfaz).</span>
                </div>
                <div className="font-mono text-[#dfe4ec]">
                  {normalized.width}×{normalized.depth} m · {normalized.segmentsW}×{normalized.segmentsH}
                </div>
              </div>
            </div>
          </div>

          {/* Configuration Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#1b202c]">
            {confirmRegenerate && (
              <div className="rounded border border-amber-500/40 bg-amber-500/10 p-3 flex items-start gap-2 text-amber-200" role="alert" data-testid="terrain-regenerate-confirm">
                <TriangleAlert className="w-4 h-4 mt-0.5 shrink-0" />
                <div className="flex-1">
                  <div className="font-semibold">Regenerar a geometria descarta a escultura.</div>
                  <div className="text-[11px]">O vínculo do arquivo .height é removido e o arquivo é apagado. O Undo restaura o vínculo, não o arquivo apagado.</div>
                  <div className="flex gap-2 pt-2">
                    <button onClick={() => void handleRegenerate()} className="px-2.5 py-1 rounded bg-amber-500 text-black font-medium hover:bg-amber-400">
                      Descartar escultura e regenerar
                    </button>
                    <button onClick={() => setConfirmRegenerate(false)} className="px-2.5 py-1 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec]">
                      Cancelar
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 1. Generate & Dimensions Tab */}
            {activeTab === 'generate' && (
              <div className="space-y-4">
                <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-[#2c3345]">
                    <Mountain className="w-4 h-4 text-amber-400" />
                    <div>
                      <div className="font-semibold text-white">Terrain Dimensions & Geometry</div>
                      <div className="text-[10px] text-[#8b97a8]">Dimensões em metros, resolução da malha e escala de altura.</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-[#8b97a8]">
                        <span>Width (X)</span>
                        <span className="text-white font-mono">{draft.width}m</span>
                      </div>
                      <input type="range" min={10} max={1000} step={10} value={draft.width} onChange={(e) => set('width', parseInt(e.target.value) || 120)} className="w-full accent-[#4982ea]" {...lockedProps(sculpted)} aria-label="Width" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-[#8b97a8]">
                        <span>Depth (Z)</span>
                        <span className="text-white font-mono">{draft.depth}m</span>
                      </div>
                      <input type="range" min={10} max={1000} step={10} value={draft.depth} onChange={(e) => set('depth', parseInt(e.target.value) || 120)} className="w-full accent-[#4982ea]" {...lockedProps(sculpted)} aria-label="Depth" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-[#8b97a8]">
                        <span>Max Height (Elevation){sculpted ? ' — escala visual' : ''}</span>
                        <span className="text-white font-mono">{draft.maxHeight}m</span>
                      </div>
                      <input type="range" min={1} max={200} step={1} value={draft.maxHeight} onChange={(e) => set('maxHeight', parseInt(e.target.value) || 24)} className="w-full accent-[#4982ea]" aria-label="Max Height" />
                    </div>
                    <div>
                      <label className="text-[#8b97a8] block mb-1">Resolution (segments W × H):</label>
                      <div className="flex gap-1.5">
                        <select
                          value={draft.segmentsW}
                          onChange={(e) => set('segmentsW', parseInt(e.target.value))}
                          className="flex-1 px-2.5 py-1.5 bg-[#171b24] border border-[#2c3345] rounded text-white disabled:opacity-50"
                          aria-label="Segments W"
                          {...lockedProps(sculpted)}
                        >
                          {TERRAIN_SEGMENT_OPTIONS.map((v) => (
                            <option key={v} value={v}>
                              {v}
                            </option>
                          ))}
                        </select>
                        <select
                          value={draft.segmentsH}
                          onChange={(e) => set('segmentsH', parseInt(e.target.value))}
                          className="flex-1 px-2.5 py-1.5 bg-[#171b24] border border-[#2c3345] rounded text-white disabled:opacity-50"
                          aria-label="Segments H"
                          {...lockedProps(sculpted)}
                        >
                          {TERRAIN_SEGMENT_OPTIONS.map((v) => (
                            <option key={v} value={v}>
                              {v}
                            </option>
                          ))}
                        </select>
                      </div>
                      <span className="text-[10px] text-[#718096] mt-0.5 block">128 × 128 é o recomendado para WebGL.</span>
                    </div>
                  </div>

                  <div className="pt-1">
                    <label className="text-[#8b97a8] block mb-1">Terrain Preset (usado quando não há heightmap):</label>
                    <div className="grid grid-cols-5 gap-1.5">
                      {TERRAIN_PRESETS.map((p) => (
                        <button
                          key={p.id}
                          onClick={() => set('terrainPreset', p.id)}
                          disabled={sculpted}
                          title={sculpted ? LOCKED_TIP : p.label}
                          className={`px-2 py-1.5 rounded text-center transition-colors border disabled:opacity-50 disabled:cursor-not-allowed ${draft.terrainPreset === p.id ? 'bg-[#4982ea] text-white border-blue-400 font-medium' : 'bg-[#171b24] text-[#8b97a8] border-[#2c3345] hover:text-white'}`}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                    <div className="flex items-center gap-2 pt-2 text-[#8b97a8]">
                      <span>Seed</span>
                      <input
                        type="number"
                        value={draft.presetSeed}
                        onChange={(e) => set('presetSeed', Math.trunc(Number(e.target.value)) || 0)}
                        className="w-28 px-2 py-1 bg-[#171b24] border border-[#2c3345] rounded text-white font-mono disabled:opacity-50"
                        aria-label="Seed"
                        {...lockedProps(sculpted)}
                      />
                      <button
                        onClick={() => set('presetSeed', Math.floor(Math.random() * 1_000_000))}
                        disabled={sculpted}
                        title={sculpted ? LOCKED_TIP : 'Sorteia uma nova semente (aplique para ver na viewport)'}
                        className="px-2 py-1 rounded bg-[#2a3244] hover:bg-[#343e54] text-white border border-[#3b475f] disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Sortear
                      </button>
                    </div>
                  </div>
                </div>

                {/* Heightmap Card */}
                <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-[#2c3345]">
                    <Upload className="w-4 h-4 text-sky-400" />
                    <div>
                      <div className="font-semibold text-white">Heightmap (Optional)</div>
                      <div className="text-[10px] text-[#8b97a8]">Imagem PNG/JPG grayscale de res://textures/ (canal R = altura).</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setPickerOpen(true)}
                      disabled={sculpted}
                      title={sculpted ? LOCKED_TIP : 'Escolher uma imagem do projeto'}
                      className="px-3 py-1.5 rounded bg-[#2a3244] hover:bg-[#343e54] text-white font-medium border border-[#3b475f] flex items-center gap-1.5 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>Choose Heightmap…</span>
                    </button>
                    <button onClick={() => set('heightmapRef', null)} disabled={sculpted || !draft.heightmapRef} className="px-2.5 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] disabled:opacity-50 disabled:cursor-not-allowed" title={sculpted ? LOCKED_TIP : 'Volta ao preset'}>
                      Limpar
                    </button>
                    <span className="text-[#8b97a8] truncate max-w-xs font-mono" data-testid="terrain-modal-heightmap">
                      {draft.heightmapRef ? (heightmapEntry ? nameOf(heightmapEntry.uri) : 'unresolved') : 'nenhum (usa o preset)'}
                    </span>
                  </div>
                  <div className="flex items-center gap-6 pt-1 text-[#8b97a8]">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={draft.invertHeightmap} onChange={(e) => set('invertHeightmap', e.target.checked)} disabled={sculpted} className="rounded bg-[#171b24] border-[#2c3345] text-[#4982ea]" />
                      <span>Invert Heightmap</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={draft.smoothHeightmap} onChange={(e) => set('smoothHeightmap', e.target.checked)} disabled={sculpted} className="rounded bg-[#171b24] border-[#2c3345] text-[#4982ea]" />
                      <span>Smooth Heightmap Filtering</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* 2. Textures & Splatting Tab */}
            {activeTab === 'textures' && (
              <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-[#2c3345]">
                  <Palette className="w-4 h-4 text-sky-400" />
                  <div>
                    <div className="font-semibold text-white">Multi-Texture Elevation Splatting</div>
                    <div className="text-[10px] text-[#8b97a8]">Camadas por altitude relativa: chão &lt; 35% &lt; meio &lt; 70% &lt; alto. A viewport mistura a cor de cada camada.</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="p-3 rounded bg-[#171b24] border border-[#2c3345] space-y-2">
                    <div className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                      <span>Ground (Valley/Base)</span>
                    </div>
                    {textureSelect(draft.groundTexture, TERRAIN_GROUND_TEXTURES, (v) => set('groundTexture', v))}
                    <div className="h-14 rounded border border-[#2c3345] flex items-center justify-center text-[10px] text-white/90" style={{ background: swatch(draft.groundTexture) }}>
                      {draft.groundTexture}
                    </div>
                  </div>
                  <div className="p-3 rounded bg-[#171b24] border border-[#2c3345] space-y-2">
                    <div className="text-[11px] font-semibold text-amber-400 flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                      <span>Mid-Level (Slope/Cliff)</span>
                    </div>
                    {textureSelect(draft.midTexture, TERRAIN_MID_TEXTURES, (v) => set('midTexture', v))}
                    <div className="h-14 rounded border border-[#2c3345] flex items-center justify-center text-[10px] text-white/90" style={{ background: swatch(draft.midTexture) }}>
                      {draft.midTexture}
                    </div>
                  </div>
                  <div className="p-3 rounded bg-[#171b24] border border-[#2c3345] space-y-2">
                    <div className="text-[11px] font-semibold text-cyan-300 flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                      <span>High-Point (Mountain Peak)</span>
                    </div>
                    {textureSelect(draft.highTexture, TERRAIN_HIGH_TEXTURES, (v) => set('highTexture', v))}
                    <div className="h-14 rounded border border-[#2c3345] flex items-center justify-center text-[10px] text-slate-800" style={{ background: swatch(draft.highTexture) }}>
                      {draft.highTexture}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div className="space-y-1">
                    <div className="flex justify-between text-[#8b97a8]">
                      <span>Texture UV Tiling Repeat</span>
                      <span className="text-white font-mono">{draft.textureTiling}x</span>
                    </div>
                    <input type="range" min={4} max={64} step={4} value={draft.textureTiling} onChange={(e) => set('textureTiling', parseInt(e.target.value) || 16)} className="w-full accent-[#4982ea]" aria-label="Texture Tiling" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[#8b97a8]">
                      <span>Layer Blend Sharpness</span>
                      <span className="text-white font-mono">{draft.blendSharpness.toFixed(2)}</span>
                    </div>
                    <input type="range" min={0} max={1} step={0.05} value={draft.blendSharpness} onChange={(e) => set('blendSharpness', parseFloat(e.target.value) || 0)} className="w-full accent-[#4982ea]" aria-label="Blend Sharpness" />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="h-12 bg-[#171b24] border-t border-[#2c3345] px-4 flex items-center justify-between">
          <button
            onClick={() => setDraft(draftFromProps(sculpted ? { ...node?.properties } : undefined))}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#8b97a8] hover:text-white transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Defaults</span>
          </button>

          <div className="flex items-center gap-2">
            <button onClick={close} className="px-3.5 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] transition-colors">
              Cancel
            </button>
            {!node && (
              <button onClick={handleCreateNew} className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-[#4982ea] hover:bg-[#3b6ecc] text-white font-medium shadow-md transition-colors">
                <Check className="w-3.5 h-3.5" />
                <span>Create Terrain in Scene</span>
              </button>
            )}
            {node && (
              <>
                <button onClick={handleCreateNew} className="px-3 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] transition-colors" title="Cria um Terrain adicional, independente do atual">
                  Inserir novo
                </button>
                <button
                  onClick={() => void handleRegenerate()}
                  disabled={!sculpted && !dirtyGeometry}
                  title={sculpted ? 'Descarta a escultura (pede confirmação)' : dirtyGeometry ? 'Reconstrói só a geometria alterada' : 'Habilita quando heightmap, preset/seed, dimensões ou segmentos mudam'}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  data-testid="terrain-regenerate"
                >
                  {sculpted && <Lock className="w-3 h-3" />}
                  <span>Regenerar geometria{sculpted ? ' ⚠' : ''}</span>
                </button>
                {sculpted ? (
                  <button onClick={handleApplyVisual} disabled={Object.keys(visualChanges).length === 0} className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-[#4982ea] hover:bg-[#3b6ecc] text-white font-medium shadow-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed" data-testid="terrain-apply-visual">
                    <Check className="w-3.5 h-3.5" />
                    <span>Atualizar parâmetros visuais</span>
                  </button>
                ) : (
                  <button onClick={handleApply} disabled={Object.keys(allChanges).length === 0} className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-[#4982ea] hover:bg-[#3b6ecc] text-white font-medium shadow-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed" data-testid="terrain-apply">
                    <Check className="w-3.5 h-3.5" />
                    <span>Aplicar ao nó</span>
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      </div>
      {pickerOpen && (
        <HeightmapPicker
          currentId={heightmapEntry?.resourceId}
          onClose={() => setPickerOpen(false)}
          onPick={(ref) => {
            setPickerOpen(false);
            set('heightmapRef', ref);
          }}
        />
      )}
    </div>
  );
};
