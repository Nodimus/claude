import React from 'react';
import { AlertTriangle, Check, FolderOpen, HelpCircle, Info, Move, Palette, Play, Sparkles, Upload, X, Activity, Loader2 } from 'lucide-react';
import { useEditorStore } from '../../../core/editorStore';
import { BODY_MODE_LABEL, BODY_MODE_ORDER, SHAPE_LABEL } from '../../../core/physics/physicsConfig';
import { allowedShapes } from '../../../core/modelImport/importPlan';
import { ImportPreview } from './ImportPreview';
import { TransformTab } from './TransformTab';
import { TextureTab } from './TextureTab';
import { SkeletonTab } from './SkeletonTab';
import { AnimationTab } from './AnimationTab';
import { QuizTab } from './QuizTab';
import { useModelImportSession, type ImportTab, type ModelImportSession } from './useModelImportSession';

interface TabDef {
  id: ImportTab;
  label: string;
  icon: React.ReactNode;
  /** Recurso que ainda não existe (decisão 14): aba visível, desabilitada, com tooltip "em breve". */
  soon?: string;
}

/** As 5 abas canônicas (AIS-33 §3.2). A aba Skeleton fica desabilitada até o AIS-36. */
const TABS: TabDef[] = [
  { id: 'transform', label: 'Transform & Gizmo', icon: <Move className="w-3.5 h-3.5 text-blue-400" /> },
  { id: 'texture', label: 'Texture & Material', icon: <Palette className="w-3.5 h-3.5 text-purple-400" /> },
  { id: 'skeleton', label: 'Skeleton & Retargeting', icon: <Activity className="w-3.5 h-3.5 text-emerald-400" /> },
  { id: 'animation', label: 'Animation Player', icon: <Sparkles className="w-3.5 h-3.5 text-emerald-400" /> },
  { id: 'quiz', label: 'Quiz de Dúvidas / Diagnóstico', icon: <Play className="w-3.5 h-3.5 text-amber-400" /> },
];

const ACCEPT_HINT = 'GLTF • GLB • FBX • OBJ • DAE';

/** O corpo só monta enquanto o modal está aberto: o rascunho é recriado a cada abertura e os recursos são liberados ao fechar. */
export const AssetImportModal: React.FC = () => {
  const open = useEditorStore((s) => s.isAssetImportModalOpen);
  if (!open) return null;
  return <AssetImportBody />;
};

const AssetImportBody: React.FC = () => {
  const s = useModelImportSession();

  const onDrop = (e: React.DragEvent) => {
    if (!e.dataTransfer.files?.length) return;
    e.preventDefault();
    void s.dropFiles(Array.from(e.dataTransfer.files));
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm select-none p-4"
      onDragOver={(e) => {
        if (e.dataTransfer.types.includes('Files')) e.preventDefault();
      }}
      onDrop={onDrop}
    >
      <div className="w-[1240px] max-w-[98vw] h-[780px] max-h-[96vh] bg-[#1a1f2b] border border-[#2f3b52] rounded-xl shadow-2xl flex flex-col overflow-hidden text-xs text-[#dbe2ed]">
        {/* Top Header */}
        <div className="h-12 bg-[#141822] border-b border-[#252f42] px-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Upload className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-sm text-white tracking-wide">{s.isReedit ? `Editar importação — ${s.reeditName ?? ''}` : 'Importador & Mini-Editor de Assets 3D'}</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30">{ACCEPT_HINT}</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">SketchUp Scale Reference</span>
              </div>
              <p className="text-[11px] text-[#8492a6]">Configure pivô, centralize no chão, compare com boneco humano 1.80m, edite texturas e una esqueletos compatíveis.</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => s.setTab('quiz')}
              className={`px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-all ${
                s.tab === 'quiz' ? 'bg-amber-500 text-black border-amber-400 shadow-md shadow-amber-500/30' : 'bg-amber-500/15 border-amber-500/30 text-amber-400 hover:bg-amber-500/25'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Dúvidas? Abrir Quiz Assistente</span>
            </button>

            <button onClick={() => void s.requestClose()} className="p-1.5 rounded-lg hover:bg-[#252e42] text-[#8492a6] hover:text-white transition-colors" aria-label="Fechar">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Sub-Header Navigation Tabs */}
        <div className="h-10 bg-[#161b26] border-b border-[#252f42] px-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1" role="tablist">
            {TABS.map((t) => {
              const active = s.tab === t.id;
              return (
                <button
                  key={t.id}
                  role="tab"
                  aria-selected={active}
                  disabled={!!t.soon}
                  title={t.soon}
                  onClick={() => s.setTab(t.id)}
                  className={`px-3 py-1.5 rounded-md font-medium flex items-center gap-1.5 transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                    active
                      ? t.id === 'quiz'
                        ? 'bg-amber-600/30 text-amber-300 border border-amber-500/40'
                        : 'bg-[#29354a] text-white shadow-sm'
                      : 'text-[#8a98ae] hover:text-white hover:bg-[#1f2738] disabled:hover:bg-transparent disabled:hover:text-[#8a98ae]'
                  }`}
                >
                  {t.icon}
                  <span>{t.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-[#78879e]">Arquivo:</span>
            <span className="max-w-[260px] truncate font-mono text-[11px] text-white" title={s.file?.name}>
              {s.file ? s.file.name : '— nenhum —'}
            </span>
            <button
              onClick={() => void s.pickFiles()}
              className="px-2.5 py-1 rounded bg-[#273245] hover:bg-[#324058] border border-[#374661] text-[#ccd6e6] flex items-center gap-1.5 transition-colors font-medium"
              title="Carregar arquivo .glb / .gltf / .obj / .fbx / .dae local (para .gltf, selecione também o .bin e as imagens)"
            >
              <FolderOpen className="w-3 h-3 text-blue-400" />
              <span>Carregar Arquivo...</span>
            </button>
          </div>
        </div>

        {/* Main Body: Left 3D Viewport + Right Configuration Panels */}
        <div className="flex-1 flex overflow-hidden">
          <ImportPreview
            model={s.handle?.object ?? null}
            revision={s.revision}
            transform={s.draft}
            status={s.status}
            stats={s.stats}
            showHuman={s.showHuman}
            showRuler={s.showRuler}
            humanDistance={s.humanDistance}
            wireframe={s.wireframe}
            showSkeleton={s.skeletonOverlay && s.tab === 'skeleton'}
            skeletonBones={s.mappedBoneNames}
            gizmoMode={s.gizmoMode}
            onGizmoChange={s.onGizmoChange}
            onShowHuman={s.setShowHuman}
            onShowRuler={s.setShowRuler}
            onHumanDistance={s.setHumanDistance}
            onToggleWireframe={s.toggleWireframe}
            onCenterToOrigin={s.center}
            onNormalizeToHuman={s.normalizeToHuman}
            onFlipZUp={s.flipZUp}
            onPickFile={() => void s.pickFiles()}
          />

          {/* Right: Dynamic Configuration Inspector Tabs */}
          <div className="w-[430px] bg-[#171c26] border-l border-[#252f42] flex flex-col overflow-y-auto">
            {s.error && (
              <div role="alert" className="m-4 mb-0 flex items-start gap-2 text-[11px] text-rose-300 bg-rose-500/10 border border-rose-500/30 rounded px-3 py-2">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                <span className="flex-1 break-words">
                  <span className="font-mono text-rose-200">[{s.error.code}]</span> {s.error.message}
                </span>
                <button onClick={s.clearError} className="text-rose-300 hover:text-white" aria-label="Fechar aviso">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
            {s.status === 'loading' && (
              <div className="m-4 mb-0 flex items-center gap-2 text-[11px] text-[#bac7db]">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-400" />
                <span>Lendo o arquivo...</span>
              </div>
            )}
            <TabBody session={s} />
          </div>
        </div>

        <Footer session={s} />
      </div>
    </div>
  );
};

const TabBody: React.FC<{ session: ModelImportSession }> = ({ session: s }) => {
  switch (s.tab) {
    case 'texture':
      return <TextureTab session={s} />;
    case 'skeleton':
      return <SkeletonTab session={s} />;
    case 'animation':
      return <AnimationTab session={s} />;
    case 'quiz':
      return <QuizTab session={s} />;
    default:
      return <TransformTab session={s} />;
  }
};

const SELECT = 'bg-[#1f2636] border border-[#303d54] text-white text-[11px] rounded px-2 py-1 outline-none focus:border-blue-500 disabled:opacity-50 disabled:cursor-not-allowed';

/** Rodapé: "Importar com colisão" (preferência persistida), Cancelar e "Importar & Adicionar à Cena". */
const Footer: React.FC<{ session: ModelImportSession }> = ({ session: s }) => {
  const shapes = allowedShapes(s.collision.bodyMode);
  const disabledReason = s.canImport ? undefined : s.importing ? (s.isReedit ? 'Aplicando...' : 'Importando...') : 'Carregue um arquivo 3D para importar';
  return (
    <div className="h-14 bg-[#141822] border-t border-[#252f42] px-5 flex items-center justify-between shrink-0 gap-4">
      <div className="flex items-center gap-3 min-w-0 text-[11px] text-[#8292aa]">
        <Info className="w-4 h-4 text-blue-400 shrink-0" />
        <label className="flex items-center gap-1.5 cursor-pointer text-[#dbe2ed] shrink-0">
          <input
            type="checkbox"
            checked={s.collision.enabled}
            disabled={s.isReedit}
            title={s.isReedit ? 'A colisão do nó é editada no Inspector' : undefined}
            onChange={(e) => s.setImportWithCollision(e.target.checked)}
            className="rounded bg-[#232c3d] border-[#384661] text-blue-500 focus:ring-0"
          />
          <span>Importar com colisão</span>
        </label>
        <select
          value={s.collision.bodyMode}
          disabled={!s.collision.enabled || s.isReedit}
          onChange={(e) => s.setBodyMode(e.target.value as typeof s.collision.bodyMode)}
          aria-label="Tipo de corpo"
          title="Tipo"
          className={SELECT}
        >
          {BODY_MODE_ORDER.map((m) => (
            <option key={m} value={m}>
              {BODY_MODE_LABEL[m]}
            </option>
          ))}
        </select>
        <select
          value={s.collision.shape}
          disabled={!s.collision.enabled || s.isReedit}
          onChange={(e) => s.setShape(e.target.value as typeof s.collision.shape)}
          aria-label="Forma do colisor"
          title="Forma (Malha exata só com Sólido parado)"
          className={SELECT}
        >
          {shapes.map((sh) => (
            <option key={sh} value={sh}>
              {SHAPE_LABEL[sh]}
            </option>
          ))}
        </select>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={() => void s.requestClose()}
          className="px-4 py-2 rounded-lg bg-[#202736] hover:bg-[#2b3548] text-[#a0afc4] hover:text-white font-medium transition-colors"
        >
          Cancelar
        </button>

        <button
          onClick={() => void s.importNow()}
          disabled={!s.canImport}
          title={disabledReason}
          className="px-5 py-2 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold flex items-center gap-2 shadow-lg shadow-blue-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Check className="w-4 h-4" />
          <span>{s.isReedit ? 'Aplicar importação' : 'Importar & Adicionar à Cena'}</span>
        </button>
      </div>
    </div>
  );
};
