/**
 * AIS-33 — construtores da cena de preview do importador (movidos do monólito, sem mudança visual): o manequim de
 * referência humana de 1,80 m (régua de calibração, NÃO é um modelo de exemplo) e o tripé RGB (X vermelho, Y verde,
 * Z azul, igual ao Gizmo e ao Inspector).
 */
import * as THREE from 'three';
import { overlaySegments } from '../../../runtime/skeletalAnimation';

export const MANNEQUIN_NAME = 'Mannequin';
export const RULER_NAME = 'Ruler';

/**
 * Referência humana de 1,80 m (AIS-34 §3.3): UMA definição, só no preview do modal (nunca vai para a cena nem para o jogo).
 * `Mannequin` (manequim) e `Ruler` (poste com marcas a cada 0,5 m, destaque em 1,80 m e etiqueta) são grupos separados
 * para os toggles `showSketchUpFigure` e `showRulerLines`.
 */
export function buildSketchUpHumanFigure(): THREE.Group {
  const root = new THREE.Group();
  root.name = 'SketchUpHumanFigure';
  const group = new THREE.Group();
  group.name = MANNEQUIN_NAME;
  const ruler = new THREE.Group();
  ruler.name = RULER_NAME;
  root.add(group, ruler);

  const silhouetteMat = new THREE.MeshBasicMaterial({ color: 0x223244, transparent: true, opacity: 0.85 });

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.11, 16, 16), silhouetteMat);
  head.position.y = 1.71;
  group.add(head);

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.52, 0.2), silhouetteMat);
  torso.position.y = 1.3;
  group.add(torso);

  const legGeom = new THREE.BoxGeometry(0.13, 1.04, 0.15);
  const leftLeg = new THREE.Mesh(legGeom, silhouetteMat);
  leftLeg.position.set(-0.11, 0.52, 0);
  group.add(leftLeg);
  const rightLeg = new THREE.Mesh(legGeom, silhouetteMat);
  rightLeg.position.set(0.11, 0.52, 0);
  group.add(rightLeg);

  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 2.2, 8), new THREE.MeshBasicMaterial({ color: 0xffaa00 }));
  pole.position.set(0.35, 1.1, 0);
  ruler.add(pole);

  const markerGeom = new THREE.BoxGeometry(0.16, 0.02, 0.02);
  for (const h of [0.5, 1.0, 1.5, 1.8, 2.0]) {
    const marker = new THREE.Mesh(markerGeom, new THREE.MeshBasicMaterial({ color: h === 1.8 ? 0x00ffcc : 0xffffff }));
    marker.position.set(0.35, h, 0);
    ruler.add(marker);
  }

  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 80;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, 256, 80);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 4;
    ctx.strokeRect(4, 4, 248, 72);
    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 32px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('1.80m (SketchUp)', 128, 40);
  }
  const tag = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas) }));
  tag.scale.set(0.65, 0.22, 1);
  tag.position.set(0.35, 1.95, 0);
  ruler.add(tag);

  return root;
}

/** Billboard flutuante com a altura do modelo em metros e "× humano". `setText` redesenha só quando o texto muda. */
export function buildHeightBillboard(): { sprite: THREE.Sprite; setText(text: string): void } {
  const canvas = document.createElement('canvas');
  canvas.width = 320;
  canvas.height = 80;
  const texture = new THREE.CanvasTexture(canvas);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, depthTest: false, transparent: true }));
  sprite.scale.set(0.8, 0.2, 1);
  sprite.renderOrder = 10;
  sprite.name = 'HeightBillboard';
  let current = '';
  return {
    sprite,
    setText(text) {
      if (text === current) return;
      current = text;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 4;
      ctx.strokeRect(3, 3, canvas.width - 6, canvas.height - 6);
      ctx.fillStyle = '#facc15';
      ctx.font = 'bold 30px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text, canvas.width / 2, canvas.height / 2);
      texture.needsUpdate = true;
    },
  };
}

/** Tripé RGB na origem do modelo. */
export function buildGizmoTripod(): THREE.Group {
  const gizmo = new THREE.Group();
  gizmo.add(new THREE.Mesh(new THREE.SphereGeometry(0.04, 12, 12), new THREE.MeshBasicMaterial({ color: 0xffffff })));
  const origin = new THREE.Vector3(0, 0, 0);
  gizmo.add(new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), origin, 0.45, 0xff3b30, 0.1, 0.05));
  gizmo.add(new THREE.ArrowHelper(new THREE.Vector3(0, 1, 0), origin, 0.45, 0x34c759, 0.1, 0.05));
  gizmo.add(new THREE.ArrowHelper(new THREE.Vector3(0, 0, 1), origin, 0.45, 0x007aff, 0.1, 0.05));
  return gizmo;
}

/** Libera geometria, material e textura de uma árvore do preview (só o que o preview criou). */
export function disposeTree(root: THREE.Object3D): void {
  root.traverse((child) => {
    const m = child as THREE.Mesh & THREE.Sprite;
    m.geometry?.dispose?.();
    const materials = Array.isArray(m.material) ? m.material : m.material ? [m.material] : [];
    for (const mat of materials) {
      for (const value of Object.values(mat)) if (value instanceof THREE.Texture) value.dispose();
      mat.dispose();
    }
  });
}

/**
 * AIS-36 — overlay do esqueleto mapeado: linhas entre os ossos dos 19 (só os mapeados, por nome do `THREE.Skeleton`) e um ponto em
 * cada um. Só desenho do preview. `frustumCulled = false` e `depthTest = false`: as posições mudam a cada quadro (o
 * `SkeletonHelper` era cortado pela esfera de contorno velha e desenhava dedos e ossos de torção juntos).
 */
export function buildRigOverlay(root: THREE.Object3D, mappedNames: readonly string[]): THREE.Group | null {
  const mapped = new Set(mappedNames);
  const bones = new Map<string, THREE.Object3D>();
  const parentOf = new Map<string, string | null>();
  root.traverse((o) => {
    if (!(o as THREE.Bone).isBone) return;
    if (!bones.has(o.name)) bones.set(o.name, o);
    parentOf.set(o.name, o.parent && (o.parent as THREE.Bone).isBone ? o.parent.name : null);
  });
  const names = [...mapped].filter((n) => bones.has(n));
  if (names.length === 0) return null;
  const pairs = overlaySegments(parentOf, new Set(names));

  const group = new THREE.Group();
  group.name = 'RigOverlay';
  const lineGeo = new THREE.BufferGeometry();
  lineGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pairs.length * 6), 3));
  const lines = new THREE.LineSegments(lineGeo, new THREE.LineBasicMaterial({ color: 0x34d399, depthTest: false, transparent: true }));
  const pointGeo = new THREE.BufferGeometry();
  pointGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(names.length * 3), 3));
  const points = new THREE.Points(pointGeo, new THREE.PointsMaterial({ color: 0xfacc15, size: 7, sizeAttenuation: false, depthTest: false, transparent: true }));
  for (const o of [lines, points]) {
    o.frustumCulled = false;
    o.renderOrder = 10;
    group.add(o);
  }
  const v = new THREE.Vector3();
  const write = (attr: THREE.BufferAttribute, i: number, bone: THREE.Object3D) => {
    bone.updateWorldMatrix(true, false);
    v.setFromMatrixPosition(bone.matrixWorld);
    attr.setXYZ(i, v.x, v.y, v.z);
  };
  group.onBeforeRender = () => {
    const la = lineGeo.getAttribute('position') as THREE.BufferAttribute;
    pairs.forEach(([parent, child], i) => {
      write(la, i * 2, bones.get(parent)!);
      write(la, i * 2 + 1, bones.get(child)!);
    });
    la.needsUpdate = true;
    const pa = pointGeo.getAttribute('position') as THREE.BufferAttribute;
    names.forEach((n, i) => write(pa, i, bones.get(n)!));
    pa.needsUpdate = true;
  };
  // `onBeforeRender` só dispara em objetos desenháveis: a atualização roda no desenho das linhas
  lines.onBeforeRender = group.onBeforeRender as unknown as THREE.Object3D['onBeforeRender'];
  return group;
}
