import React from 'react';

/** Peças comuns das abas 2 a 5 do importador (AIS-33). */
export const HEADER = 'flex items-center justify-between border-b border-[#252f42] pb-2';
export const NOTE = 'bg-[#1b2230] p-3 rounded-lg border border-[#273347] text-[11px] text-[#8695ad] leading-relaxed';

export const NoModel: React.FC = () => <div className={NOTE}>Carregue um arquivo 3D para ver os dados desta aba.</div>;
