import React from 'react';
import { AlertTriangle, Palette, RotateCcw } from 'lucide-react';
import { DraftNumberInput } from '../../inspector/DraftNumberInput';
import {
  PROCEDURAL_PATTERNS,
  colorToHex,
  hexToColor,
  isEditDirty,
  patternOption,
  type MaterialEdit,
  type MaterialFilters,
} from '../../../core/modelImport/materials';
import type { ModelImportSession } from './useModelImportSession';
import { HEADER, NOTE, NoModel } from './tabParts';

const CARD = 'space-y-2 bg-[#1b2230] p-3 rounded-lg border border-[#273347]';
const LABEL = 'text-[11px] font-bold text-white uppercase tracking-wider block';
const BTN = 'bg-[#222a3b] hover:bg-[#2b354a] border border-[#2e3b52] text-[#93a1b8]';
const ACTIVE = 'bg-blue-600/30 border-blue-500 text-blue-300 font-bold';
const NUM = 'w-16 bg-[#141820] text-xs text-right font-mono text-[#dfe4ec] px-1.5 py-0.5 rounded border border-[#2c3345] focus:border-blue-500 outline-none';

const Slider: React.FC<{ label: string; value: number; min: number; max: number; step: number; format?: (v: number) => string; onChange(v: number): void }> = ({ label, value, min, max, step, format, onChange }) => (
  <div className="space-y-0.5">
    <div className="flex justify-between text-[10px] text-[#8695ad]">
      <span>{label}</span>
      <span className="font-mono text-white">{format ? format(value) : value.toFixed(2)}</span>
    </div>
    <input type="range" min={min} max={max} step={step} value={Math.min(max, Math.max(min, value))} aria-label={label} onChange={(e) => onChange(parseFloat(e.target.value))} className="w-full accent-purple-500 h-1 bg-[#253042] rounded" />
  </div>
);

const ColorField: React.FC<{ label: string; value: string; onChange(hex: string): void }> = ({ label, value, onChange }) => (
  <label className="flex items-center justify-between gap-2 text-[10px] text-[#8695ad]">
    <span>{label}</span>
    <span className="flex items-center gap-1.5">
      <span className="font-mono text-white">{value}</span>
      <input type="color" aria-label={label} value={value} onChange={(e) => onChange(e.target.value)} className="w-6 h-5 p-0 bg-transparent border border-[#2c3345] rounded cursor-pointer" />
    </span>
  </label>
);

const FILTERS: { key: keyof MaterialFilters; label: string; min: number; max: number; step: number; format?: (v: number) => string }[] = [
  { key: 'brightness', label: 'Brilho', min: 0, max: 2, step: 0.05, format: (v) => `${Math.round(v * 100)}%` },
  { key: 'contrast', label: 'Contraste', min: 0, max: 2, step: 0.05, format: (v) => `${Math.round(v * 100)}%` },
  { key: 'saturation', label: 'Saturação', min: 0, max: 2, step: 0.05, format: (v) => `${Math.round(v * 100)}%` },
  { key: 'hueShift', label: 'Matiz', min: -180, max: 180, step: 1, format: (v) => `${Math.round(v)}°` },
];

/** Aba 2 — Texture & Material (AIS-35): materiais REAIS do arquivo; cor/PBR/filtros/UV e padrões procedurais em tempo real no preview. */
export const TextureTab: React.FC<{ session: ModelImportSession }> = ({ session: s }) => {
  const model = s.loaded;
  const selected = s.materialEdits.find((e) => e.name === s.selectedMaterial) ?? null;
  const info = model?.materials.find((m) => m.name === s.selectedMaterial) ?? null;
  const patch = (p: Partial<MaterialEdit>) => selected && s.patchMaterial(selected.name, p);
  const diagnostics = s.materialDiagnostics;

  return (
    <div className="p-4 space-y-4">
      <div className={HEADER}>
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 text-purple-400" />
          <h3 className="font-bold text-sm text-white">Editor de Textura & Cor</h3>
        </div>
        {selected && (
          <button onClick={() => s.resetMaterial(selected.name)} className="text-[11px] text-blue-400 hover:underline flex items-center gap-1" title="Volta este material ao que veio no arquivo">
            <RotateCcw className="w-3 h-3" /> Resetar material
          </button>
        )}
      </div>

      {!model ? (
        <NoModel />
      ) : (
        <>
          <div className="space-y-1.5">
            <label className={LABEL}>Materiais do Modelo ({model.materials.length})</label>
            <div className="grid grid-cols-2 gap-1.5">
              {model.materials.map((m) => {
                const edit = s.materialEdits.find((e) => e.name === m.name);
                const dirty = !!edit && isEditDirty(edit, m);
                const on = m.name === s.selectedMaterial;
                return (
                  <button
                    key={m.uuid ?? m.name}
                    onClick={() => s.setSelectedMaterial(m.name)}
                    aria-pressed={on}
                    className={`p-2 rounded-lg border flex items-center gap-2.5 text-left ${on ? 'bg-blue-600/20 border-blue-500' : 'bg-[#1b2230] border-[#29354a] hover:border-[#3a4a66]'}`}
                  >
                    <div className="w-4 h-4 rounded-full border border-white/20 shrink-0" style={{ backgroundColor: edit ? colorToHex(edit.color) : m.color ?? '#808080' }} />
                    <div className="truncate">
                      <div className="font-bold text-[11px] truncate text-white">
                        {m.name}
                        {dirty ? <span className="text-amber-400"> •</span> : null}
                      </div>
                      <div className="text-[9px] text-[#718199] truncate">
                        {m.type}
                        {m.hasMap ? ' · com textura' : ''}
                        {m.transparent ? ' · transparente' : ''}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {diagnostics.length > 0 && (
            <div className="space-y-1">
              {diagnostics.map((d) => (
                <div key={`${d.code}:${d.material}`} role="status" className="flex items-start gap-1.5 text-[10px] text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded px-2 py-1.5">
                  <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
                  <span>
                    <span className="font-mono">[{d.code}]</span> {d.message}
                  </span>
                </div>
              ))}
            </div>
          )}

          {selected && info && (
            <>
              <div className={CARD}>
                <label className={LABEL}>Cor & PBR — {selected.name}</label>
                <ColorField label="Albedo (cor base)" value={colorToHex(selected.color)} onChange={(hex) => patch({ color: hexToColor(hex, selected.color) })} />
                <Slider label="Rugosidade (Roughness)" value={selected.roughness} min={0} max={1} step={0.01} onChange={(roughness) => patch({ roughness })} />
                <Slider label="Metalicidade (Metalness)" value={selected.metalness} min={0} max={1} step={0.01} onChange={(metalness) => patch({ metalness })} />
                <ColorField label="Emissivo" value={colorToHex(selected.emissiveColor)} onChange={(hex) => patch({ emissiveColor: hexToColor(hex, selected.emissiveColor) })} />
                <Slider label="Intensidade emissiva" value={selected.emissiveIntensity} min={0} max={5} step={0.05} onChange={(emissiveIntensity) => patch({ emissiveIntensity })} />
              </div>

              <div className={CARD}>
                <label className={LABEL}>Filtros</label>
                {FILTERS.map((f) => (
                  <Slider key={f.key} label={f.label} value={selected.filters[f.key]} min={f.min} max={f.max} step={f.step} format={f.format} onChange={(v) => patch({ filters: { ...selected.filters, [f.key]: v } })} />
                ))}
                <p className="text-[10px] text-[#8695ad]">Com textura (do arquivo ou procedural) os filtros vão assados no PNG extraído; sem textura, na cor.</p>
              </div>

              <div className={CARD}>
                <label className={LABEL}>Tiling UV</label>
                <div className="grid grid-cols-2 gap-2">
                  {(['x', 'y'] as const).map((axis) => (
                    <label key={axis} className="flex items-center justify-between gap-2 text-[10px] text-[#8695ad]">
                      <span className="font-bold uppercase">{axis}</span>
                      <DraftNumberInput value={selected.uvTiling[axis]} min={0.01} max={64} step={0.5} className={NUM} aria-label={`Tiling UV ${axis.toUpperCase()}`} onCommit={(v) => patch({ uvTiling: { ...selected.uvTiling, [axis]: v } })} />
                    </label>
                  ))}
                </div>
              </div>

              <div className={CARD}>
                <label className={LABEL}>Textura Procedural</label>
                <div className="grid grid-cols-2 gap-1.5" role="group" aria-label="Padrão procedural">
                  <button onClick={() => patch({ pattern: 'none' })} aria-pressed={selected.pattern === 'none'} className={`px-2 py-1.5 rounded text-[11px] border ${selected.pattern === 'none' ? ACTIVE : BTN}`}>
                    {info.hasMap ? 'Original do arquivo' : 'Nenhuma (só cor)'}
                  </button>
                  {PROCEDURAL_PATTERNS.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => patch({ pattern: p.id, patternColorA: p.colorA, patternColorB: p.colorB, patternScale: p.scale })}
                      aria-pressed={selected.pattern === p.id}
                      className={`px-2 py-1.5 rounded text-[11px] border ${selected.pattern === p.id ? ACTIVE : BTN}`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
                {selected.pattern !== 'none' && patternOption(selected.pattern) && (
                  <div className="space-y-2 pt-1">
                    <ColorField label="Cor A" value={selected.patternColorA} onChange={(patternColorA) => patch({ patternColorA })} />
                    <ColorField label="Cor B" value={selected.patternColorB} onChange={(patternColorB) => patch({ patternColorB })} />
                    <Slider label="Escala do padrão" value={selected.patternScale} min={1} max={32} step={1} format={(v) => `${v}`} onChange={(patternScale) => patch({ patternScale })} />
                  </div>
                )}
              </div>
            </>
          )}

          <div className={NOTE}>
            Ao importar, as texturas embutidas e as procedurais viram PNG em <span className="font-mono">res://textures/&lt;asset&gt;/</span>, descritas por <span className="font-mono">res://textures/&lt;asset&gt;_material.json</span>; o nó leva só os materiais alterados em <span className="font-mono">materialSlots</span>.
          </div>
        </>
      )}
    </div>
  );
};
