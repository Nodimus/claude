import React from 'react';
import { Activity, AlertTriangle, CheckCircle2, RotateCcw } from 'lucide-react';
import { CANONICAL_BONES, REQUIRED_BONES, type CanonicalBone } from '../../../runtime/skeletalAnimation';
import type { ModelImportSession } from './useModelImportSession';
import { HEADER, NOTE, NoModel } from './tabParts';

const CARD = 'space-y-2 bg-[#1b2230] p-3 rounded-lg border border-[#273347]';
const LABEL = 'text-[11px] font-bold text-white uppercase tracking-wider block';

const CONVENTION_LABEL = { generic: 'Mixamo / Unity / Godot', rigify: 'Blender Rigify' } as const;

/** Aba 3 — Skeleton & Retargeting (AIS-36): mapeia o esqueleto REAL do modelo para os 19 ossos padrão e permite corrigir à mão. */
export const SkeletonTab: React.FC<{ session: ModelImportSession }> = ({ session: s }) => {
  const model = s.loaded;
  const names = s.boneNames;
  const v = s.rigValidation;
  const percent = Math.round((s.rigFound / CANONICAL_BONES.length) * 100);

  return (
    <div className="p-4 space-y-4">
      <div className={HEADER}>
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400" />
          <h3 className="font-bold text-sm text-white">Skeleton & Retargeting</h3>
        </div>
        {model && names.length > 0 && (
          <button onClick={s.redetectRig} className="text-[11px] text-blue-400 hover:underline flex items-center gap-1" title="Descarta as correções manuais e detecta de novo">
            <RotateCcw className="w-3 h-3" /> Redetectar
          </button>
        )}
      </div>

      {!model ? (
        <NoModel />
      ) : names.length === 0 ? (
        <div className={NOTE} role="status" data-testid="rig-no-skeleton">
          <b className="text-white">Este modelo não tem esqueleto.</b> Não há o que mapear e nenhum rig será gravado (<span className="font-mono">rig.not_humanoid</span>).
        </div>
      ) : (
        <>
          <div className={CARD}>
            <div className="flex items-center justify-between">
              <label className={LABEL}>Esqueleto do arquivo</label>
              <span className="text-[10px] text-[#8695ad]">{names.length} osso(s) · {CONVENTION_LABEL[s.rigConvention]}</span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-[#8695ad]">Confiança (ossos dos 19 mapeados)</span>
              <span className="font-mono text-white" data-testid="rig-confidence">
                {s.rigFound}/{CANONICAL_BONES.length} · {percent}%
              </span>
            </div>
            <div className="h-1.5 rounded bg-[#253042] overflow-hidden">
              <div className={`h-full ${v.humanoid ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{ width: `${percent}%` }} />
            </div>
            {v.humanoid ? (
              <div role="status" className="flex items-start gap-1.5 text-[10px] text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded px-2 py-1.5" data-testid="rig-valid">
                <CheckCircle2 className="w-3 h-3 shrink-0 mt-0.5" />
                <span>Humanoide: ao importar, o rig é gravado em <span className="font-mono">res://materials/&lt;asset&gt;_rig.json</span>.</span>
              </div>
            ) : (
              <div role="status" className="flex items-start gap-1.5 text-[10px] text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded px-2 py-1.5" data-testid="rig-invalid">
                <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
                <span>
                  Faltam ossos obrigatórios: <b>{v.missingRequired.join(', ')}</b>. Corrija à mão abaixo; enquanto faltarem, <b>nenhum rig é gravado</b>.
                </span>
              </div>
            )}
            {v.duplicates.length > 0 && (
              <div role="status" className="flex items-start gap-1.5 text-[10px] text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded px-2 py-1.5">
                <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
                <span>O mesmo osso está em mais de um lugar: {v.duplicates.join(', ')}.</span>
              </div>
            )}
            <label className="flex items-center gap-2 cursor-pointer text-[11px] text-white font-medium">
              <input type="checkbox" checked={s.skeletonOverlay} onChange={(e) => s.setSkeletonOverlay(e.target.checked)} className="rounded bg-[#232c3d] border-[#384661] text-emerald-500 focus:ring-0" />
              <span>Mostrar esqueleto no preview</span>
            </label>
          </div>

          <div className={CARD}>
            <label className={LABEL}>Osso do arquivo → osso padrão</label>
            <div className="space-y-1" role="table" aria-label="Mapeamento de ossos">
              {CANONICAL_BONES.map((bone) => (
                <BoneRow key={bone} bone={bone} value={s.rigMap[bone]} names={names} duplicate={!!s.rigMap[bone] && v.duplicates.includes(s.rigMap[bone]!)} onChange={(name) => s.setRigBone(bone, name)} />
              ))}
            </div>
            <p className="text-[10px] text-[#8695ad]">
              * obrigatório. Dedos e dedos do pé não fazem parte dos 19 ossos. O rig guarda só o mapeamento (nenhum keyframe).
            </p>
          </div>
        </>
      )}
    </div>
  );
};

const BoneRow: React.FC<{ bone: CanonicalBone; value: string | null; names: readonly string[]; duplicate: boolean; onChange(name: string | null): void }> = ({ bone, value, names, duplicate, onChange }) => {
  const required = REQUIRED_BONES.includes(bone);
  const missing = !value;
  return (
    <div role="row" className="flex items-center justify-between gap-2 text-[11px]">
      <span role="cell" className={`w-32 shrink-0 font-mono ${missing && required ? 'text-amber-300' : 'text-white'}`}>
        {bone}
        {required ? <span className="text-amber-400"> *</span> : null}
      </span>
      <select
        role="cell"
        aria-label={`Osso para ${bone}`}
        value={value ?? ''}
        onChange={(e) => onChange(e.target.value === '' ? null : e.target.value)}
        className={`flex-1 min-w-0 bg-[#141820] text-[11px] text-[#dfe4ec] px-1.5 py-0.5 rounded border outline-none focus:border-blue-500 ${duplicate ? 'border-amber-500' : missing && required ? 'border-amber-500/60' : 'border-[#2c3345]'}`}
      >
        <option value="">— nenhum —</option>
        {names.map((n) => (
          <option key={n} value={n}>
            {n}
          </option>
        ))}
      </select>
    </div>
  );
};
