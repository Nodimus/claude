import React, { useState } from 'react';
import { useEditor } from '../../core/EditorContext';
import { NODE_REGISTRY, getNodeMetadata } from '../../nodes/registry';
import { presetProperties } from '../../core/particles/particlePresets';
import { NodeType, CreateNodeCategory } from '../../types/node';
import { NodeIcon } from '../common/NodeIcon';
import { useEditorStore } from '../../core/editorStore';
import { defaultPhysicsConfig } from '../../core/physics/physicsConfig';
import { Search, X, Plus, Info, Mountain, Trees, Headphones, Sparkles, Layers } from 'lucide-react';



export const CreateNodeModal: React.FC = () => {
  const {
    isCreateNodeModalOpen,
    setIsCreateNodeModalOpen,
    setIsTerrainEditorOpen,
    setIsTreeEditorOpen,
    setIsSoundModalOpen,
    setIsParticleModalOpen,
    setIsSpriteEditorOpen,
    addNode,
    selectedNodeId,
    activeScene,
  } = useEditor();

  const addWithCollision = useEditorStore((s) => s.addWithCollision);
  const setAddWithCollision = useEditorStore((s) => s.setAddWithCollision);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<NodeType>('MeshInstance');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<CreateNodeCategory | 'All'>('All');

  const hasEnvironmentInScene = Boolean(
    activeScene && Object.values(activeScene.nodes).some((n) => n.type === 'Environment')
  );

  if (!isCreateNodeModalOpen) return null;

  const categories: (CreateNodeCategory | 'All')[] = [
    'All',
    '3D Nodes',
    'Lights',
    'Animation & Audio',
    'Environment',
    'UI',
    'Special',
  ];

  const allNodeTypes = (Object.keys(NODE_REGISTRY) as NodeType[]).filter((t) => NODE_REGISTRY[t].creatable !== false);

  const filteredNodes = allNodeTypes.filter((type) => {
    const meta = NODE_REGISTRY[type];
    const matchesSearch =
      type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      meta.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory =
      activeCategoryFilter === 'All' || meta.createCategory === activeCategoryFilter;

    return matchesSearch && matchesCategory;
  });

  const selectedMeta = getNodeMetadata(selectedType);
  // AIS-26b: preferência do editor; a primitiva nasce com colisão (estática, auto) no MESMO Command da criação
  const offersCollision = selectedType === 'MeshInstance';

  const handleCreate = () => {
    // AIS-18c: ParticleSystem pelo menu nasce com o preset Fogo, sem diálogo
    const initialProperties =
      selectedType === 'ParticleSystem'
        ? presetProperties('fire')
        : offersCollision && addWithCollision
          ? { physics: defaultPhysicsConfig() }
          : undefined;
    addNode(selectedType, selectedNodeId, undefined, initialProperties);
    setIsCreateNodeModalOpen(false);
  };

  const handleSearchKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      event.stopPropagation();
      handleCreate();
    } else if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      setIsCreateNodeModalOpen(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm select-none">
      <div className="w-[680px] h-[520px] bg-[#1e232f] border border-[#3b475f] rounded-lg shadow-2xl flex flex-col overflow-hidden text-xs">
        {/* Header */}
        <div className="h-10 bg-[#171b24] border-b border-[#2c3345] px-4 flex items-center justify-between">
          <div className="flex items-center gap-2 font-semibold text-white">
            <Plus className="w-4 h-4 text-emerald-400" />
            <span>Create New Node</span>
          </div>
          <button
            onClick={() => setIsCreateNodeModalOpen(false)}
            className="p-1 text-[#8b97a8] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search & Category Filter */}
        <div className="p-3 border-b border-[#2c3345] bg-[#1a1e29] space-y-2">
          <div className="relative flex items-center">
            <Search className="w-3.5 h-3.5 absolute left-2.5 text-[#8b97a8]" />
            <input
              type="text"
              autoFocus
              placeholder="Search Node types (e.g. MeshInstance, Camera, Overlay2D, Billboard)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={handleSearchKeyDown}
              className="w-full bg-[#141820] text-[#dfe4ec] pl-8 pr-3 py-1.5 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none"
            />
          </div>

          <div className="flex items-center gap-1 overflow-x-auto pb-0.5">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategoryFilter(cat)}
                aria-pressed={activeCategoryFilter === cat}
                className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors whitespace-nowrap ${
                  activeCategoryFilter === cat
                    ? 'bg-[#4982ea] text-white'
                    : 'bg-[#202531] text-[#8b97a8] hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Content split: List vs Preview/Info */}
        <div className="flex-1 flex overflow-hidden">
          {/* Nodes list */}
          <div className="flex-1 p-2 overflow-y-auto bg-[#181c24] space-y-1">
            {filteredNodes.map((type) => {
              const meta = NODE_REGISTRY[type];
              const isSelected = selectedType === type;

              return (
                <div
                  key={type}
                  onClick={() => setSelectedType(type)}
                  onDoubleClick={handleCreate}
                  className={`p-2 rounded cursor-pointer flex items-center justify-between transition-colors ${
                    isSelected
                      ? 'bg-[#2b3548] border border-[#4982ea] text-white'
                      : 'hover:bg-[#202531] text-[#c2cbd8]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <NodeIcon type={type} className="w-4 h-4" />
                    <span className="font-semibold">{meta.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {type === 'Environment' && hasEnvironmentInScene && (
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono">
                        0..1 in scene
                      </span>
                    )}
                    <span className="text-[10px] px-2 py-0.5 rounded bg-[#141820] text-[#8b97a8] font-mono">
                      {meta.createCategory}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Node Info Side-Panel */}
          <div className="w-64 border-l border-[#2c3345] bg-[#1a1e29] p-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <NodeIcon type={selectedType} className="w-5 h-5" />
                <h4 className="text-sm font-bold text-white">{selectedMeta.name}</h4>
              </div>

              {selectedType === 'Environment' && hasEnvironmentInScene && (
                <div className="p-2 rounded bg-amber-950/30 border border-amber-800/40 text-amber-300 text-[11px] leading-snug">
                  Scene already contains an Environment node (0..1 relation). Duplicate is prohibited; existing node will be selected.
                </div>
              )}

              <div className="text-[11px] text-[#8b97a8] leading-relaxed">
                {selectedMeta.description}
              </div>

              <div className="space-y-1 pt-2 border-t border-[#2c3345]">
                <div className="text-[10px] text-[#8b97a8] uppercase tracking-wider font-semibold">
                  Attributes:
                </div>
                <div className="flex flex-wrap gap-1 text-[10px]">
                  {selectedMeta.is3D && (
                    <span className="bg-rose-900/30 text-rose-300 px-1.5 py-0.5 rounded border border-rose-800/40">
                      3D Spatial
                    </span>
                  )}
                  {selectedMeta.is2D && (
                    <span className="bg-sky-900/30 text-sky-300 px-1.5 py-0.5 rounded border border-sky-800/40">
                      2D Overlay
                    </span>
                  )}
                  {selectedMeta.isUI && (
                    <span className="bg-emerald-900/30 text-emerald-300 px-1.5 py-0.5 rounded border border-emerald-800/40">
                      Screen HUD
                    </span>
                  )}
                </div>
              </div>

              {selectedMeta.availableSignals && selectedMeta.availableSignals.length > 0 && (
                <div className="pt-2 border-t border-[#2c3345]">
                  <div className="text-[10px] text-[#8b97a8] uppercase tracking-wider font-semibold mb-1">
                    Event Signals:
                  </div>
                  <div className="flex flex-wrap gap-1 font-mono text-[10px] text-amber-300">
                    {selectedMeta.availableSignals.map((sig) => (
                      <span key={sig} className="bg-[#141820] px-1.5 py-0.5 rounded border border-[#2c3345]">
                        {sig}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {offersCollision && (
              <label className="flex items-center gap-2 text-[11px] text-[#b3bed0] cursor-pointer select-none mb-2 px-1" title="O objeto já nasce colidindo (sólido parado, forma automática)">
                <input
                  type="checkbox"
                  checked={addWithCollision}
                  onChange={(e) => setAddWithCollision(e.target.checked)}
                  className="w-3.5 h-3.5 rounded bg-[#181c24] border border-[#2c3345] text-[#4982ea] focus:ring-0 focus:ring-offset-0 cursor-pointer"
                />
                Adicionar com colisão
              </label>
            )}
            <div className="text-[10px] text-[#8b97a8] flex items-center gap-1.5 bg-[#141820] p-2 rounded border border-[#2c3345]">
              <Info className="w-3.5 h-3.5 text-[#4982ea] shrink-0" />
              <span>Double-click or press Create to instantiate in scene.</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="h-11 bg-[#171b24] border-t border-[#2c3345] px-4 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                setIsCreateNodeModalOpen(false);
                setIsTerrainEditorOpen(true);
              }}
              className="px-2.5 py-1 rounded bg-[#1f2533] hover:bg-[#283144] border border-[#2e394d] text-emerald-400 text-[11px] flex items-center gap-1.5 transition-colors"
            >
              <Mountain className="w-3.5 h-3.5" />
              <span>Terrain Editor...</span>
            </button>
            <button
              onClick={() => {
                setIsCreateNodeModalOpen(false);
                setIsTreeEditorOpen(true);
              }}
              className="px-2.5 py-1 rounded bg-[#1f2533] hover:bg-[#283144] border border-[#2e394d] text-emerald-400 text-[11px] flex items-center gap-1.5 transition-colors"
            >
              <Trees className="w-3.5 h-3.5" />
              <span>Tree Editor...</span>
            </button>
            <button
              onClick={() => {
                setIsCreateNodeModalOpen(false);
                setIsSoundModalOpen(true);
              }}
              className="px-2.5 py-1 rounded bg-[#1f2533] hover:bg-[#283144] border border-[#2e394d] text-indigo-400 text-[11px] flex items-center gap-1.5 transition-colors"
            >
              <Headphones className="w-3.5 h-3.5" />
              <span>Sound & Audio...</span>
            </button>
            <button
              onClick={() => {
                setIsCreateNodeModalOpen(false);
                setIsParticleModalOpen(true);
              }}
              className="px-2.5 py-1 rounded bg-[#1f2533] hover:bg-[#283144] border border-[#2e394d] text-amber-400 text-[11px] flex items-center gap-1.5 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Particle Generator...</span>
            </button>
            <button
              onClick={() => {
                setIsCreateNodeModalOpen(false);
                setIsSpriteEditorOpen(true);
              }}
              className="px-2.5 py-1 rounded bg-[#1f2533] hover:bg-[#283144] border border-[#2e394d] text-sky-400 text-[11px] flex items-center gap-1.5 transition-colors"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Sprite Studio...</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsCreateNodeModalOpen(false)}
              className="px-3 py-1.5 rounded hover:bg-[#2c3345] text-[#b3bed0]"
            >
              Cancel
            </button>
            <button
              onClick={handleCreate}
              className="bg-[#4982ea] hover:bg-[#3d72d6] text-white px-4 py-1.5 rounded font-medium transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Node</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
