import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  MaterialProperties,
  PreviewLightingEnvironment,
  PreviewMeshShape,
} from '../../types/material';
import { createThreeMaterial } from '../../utils/materialBuilder';
import { generateProceduralTexture, GeneratedTextureResult } from '../../utils/textureGenerator';
import {
  RotateCw,
  Maximize2,
  Minimize2,
  Sun,
  Eye,
  Layers,
  ZoomIn,
  ZoomOut,
  Download,
  Box,
  Circle,
  Sparkles,
  RefreshCw,
  Compass,
} from 'lucide-react';

interface TexturePreviewCanvasProps {
  properties: MaterialProperties;
  meshShape: PreviewMeshShape;
  setMeshShape: (shape: PreviewMeshShape) => void;
  lighting: PreviewLightingEnvironment;
  setLighting: (lighting: PreviewLightingEnvironment) => void;
  activeViewTab: '3d' | '2d_albedo' | '2d_normal';
  setActiveViewTab: (tab: '3d' | '2d_albedo' | '2d_normal') => void;
  selectedNodeMeshType?: string;
}

export const TexturePreviewCanvas: React.FC<TexturePreviewCanvasProps> = ({
  properties,
  meshShape,
  setMeshShape,
  lighting,
  setLighting,
  activeViewTab,
  setActiveViewTab,
  selectedNodeMeshType,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // Three.js References
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const meshRef = useRef<THREE.Mesh | null>(null);
  const lightsGroupRef = useRef<THREE.Group | null>(null);
  const pedestalRef = useRef<THREE.Mesh | null>(null);

  // Orbit state
  const isMouseDownRef = useRef(false);
  const mouseButtonRef = useRef(0);
  const mousePosRef = useRef({ x: 0, y: 0 });
  const sphericalRef = useRef({ radius: 3.4, theta: 0.8, phi: 1.15 });
  const targetRef = useRef(new THREE.Vector3(0, 0, 0));

  // Controls state
  const [autoRotate, setAutoRotate] = useState(true);
  const [rotateSpeed, setRotateSpeed] = useState(1.0);
  const [bgColor, setBgColor] = useState<'dark' | 'neutral' | 'transparent'>('dark');
  const [stats, setStats] = useState({ vertices: 0, triangles: 0 });

  // 2D Texture inspection state
  const [generatedTextures, setGeneratedTextures] = useState<GeneratedTextureResult | null>(null);
  const [zoom2D, setZoom2D] = useState(1.0);

  // Generate textures when properties change
  useEffect(() => {
    if (properties.textureType !== 'none') {
      const result = generateProceduralTexture(properties, 512);
      setGeneratedTextures(result);
    } else {
      setGeneratedTextures(null);
    }
  }, [properties]);

  // Setup Three.js Scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      preserveDrawingBuffer: true,
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Circular shadow pedestal
    const pedGeo = new THREE.CylinderGeometry(1.4, 1.4, 0.08, 48);
    const pedMat = new THREE.MeshStandardMaterial({
      color: 0x181c25,
      roughness: 0.8,
      metalness: 0.1,
    });
    const pedestal = new THREE.Mesh(pedGeo, pedMat);
    pedestal.position.y = -1.1;
    pedestal.receiveShadow = true;
    scene.add(pedestal);
    pedestalRef.current = pedestal;

    // Lights group
    const lightsGroup = new THREE.Group();
    scene.add(lightsGroup);
    lightsGroupRef.current = lightsGroup;

    // Initial camera position
    const updateCam = () => {
      const s = sphericalRef.current;
      const t = targetRef.current;
      camera.position.x = t.x + s.radius * Math.sin(s.phi) * Math.sin(s.theta);
      camera.position.y = t.y + s.radius * Math.cos(s.phi);
      camera.position.z = t.z + s.radius * Math.sin(s.phi) * Math.cos(s.theta);
      camera.lookAt(t);
    };
    updateCam();

    // Animation Loop
    let animId: number;
    const timer = new THREE.Timer();

    const animate = (timestamp?: number) => {
      animId = requestAnimationFrame(animate);
      timer.update(timestamp);
      const delta = timer.getDelta();

      if (autoRotate && meshRef.current) {
        meshRef.current.rotation.y += delta * 0.5 * rotateSpeed;
      }

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!container || !camera || !renderer) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  // Update Background Color
  useEffect(() => {
    if (!sceneRef.current) return;
    if (bgColor === 'dark') {
      sceneRef.current.background = new THREE.Color(0x131720);
    } else if (bgColor === 'neutral') {
      sceneRef.current.background = new THREE.Color(0x232936);
    } else {
      sceneRef.current.background = null;
    }
  }, [bgColor]);

  // Update Lighting Environment
  useEffect(() => {
    const group = lightsGroupRef.current;
    if (!group) return;

    // Clear existing lights
    while (group.children.length > 0) {
      group.remove(group.children[0]);
    }

    if (lighting === 'StudioNeutral') {
      const amb = new THREE.AmbientLight(0xffffff, 0.6);
      group.add(amb);

      const key = new THREE.DirectionalLight(0xfff5ea, 1.8);
      key.position.set(4, 5, 4);
      key.castShadow = true;
      key.shadow.mapSize.width = 1024;
      key.shadow.mapSize.height = 1024;
      group.add(key);

      const fill = new THREE.DirectionalLight(0xcde0ff, 0.8);
      fill.position.set(-4, 2, -3);
      group.add(fill);

      const rim = new THREE.DirectionalLight(0xffffff, 1.0);
      rim.position.set(0, 4, -5);
      group.add(rim);
    } else if (lighting === 'GoldenHour') {
      const amb = new THREE.AmbientLight(0x403020, 0.5);
      group.add(amb);

      const sun = new THREE.DirectionalLight(0xff8833, 2.5);
      sun.position.set(6, 2, 4);
      sun.castShadow = true;
      group.add(sun);

      const sky = new THREE.DirectionalLight(0x3366cc, 0.9);
      sky.position.set(-4, 5, -2);
      group.add(sky);
    } else if (lighting === 'CyberpunkNeon') {
      const amb = new THREE.AmbientLight(0x0f1525, 0.4);
      group.add(amb);

      const cyan = new THREE.DirectionalLight(0x00f0ff, 2.2);
      cyan.position.set(4, 3, 3);
      cyan.castShadow = true;
      group.add(cyan);

      const magenta = new THREE.DirectionalLight(0xff0066, 2.0);
      magenta.position.set(-4, 2, -2);
      group.add(magenta);

      const topGlow = new THREE.DirectionalLight(0x9d00ff, 1.2);
      topGlow.position.set(0, 6, 0);
      group.add(topGlow);
    } else if (lighting === 'DramaticSpotlight') {
      const amb = new THREE.AmbientLight(0x0a0c10, 0.2);
      group.add(amb);

      const spot = new THREE.SpotLight(0xffffff, 3.5, 20, Math.PI / 6, 0.3);
      spot.position.set(0, 6, 3);
      spot.castShadow = true;
      group.add(spot);
    } else if (lighting === 'OvercastSoft') {
      const amb = new THREE.AmbientLight(0xdde8f5, 1.4);
      group.add(amb);

      const top = new THREE.DirectionalLight(0xffffff, 0.6);
      top.position.set(0, 6, 2);
      group.add(top);
    } else {
      // Dark Void
      const amb = new THREE.AmbientLight(0xffffff, 0.15);
      group.add(amb);
      const subtle = new THREE.DirectionalLight(0xffffff, 0.5);
      subtle.position.set(3, 4, 3);
      group.add(subtle);
    }
  }, [lighting]);

  // Update Geometry & Material
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (meshRef.current) {
      scene.remove(meshRef.current);
      meshRef.current.geometry.dispose();
      meshRef.current = null;
    }

    // Build Geometry
    let geo: THREE.BufferGeometry;
    let actualShape = meshShape;
    if (actualShape === 'CurrentSceneMesh' && selectedNodeMeshType) {
      if (selectedNodeMeshType === 'CubeMesh') actualShape = 'Cube';
      else if (selectedNodeMeshType === 'SphereMesh') actualShape = 'Sphere';
      else if (selectedNodeMeshType === 'CylinderMesh') actualShape = 'Cylinder';
      else if (selectedNodeMeshType === 'PlaneMesh') actualShape = 'Plane';
      else if (selectedNodeMeshType === 'TorusMesh') actualShape = 'Torus';
    }

    switch (actualShape) {
      case 'Cube':
        geo = new THREE.BoxGeometry(1.4, 1.4, 1.4, 16, 16, 16);
        break;
      case 'Cylinder':
        geo = new THREE.CylinderGeometry(0.8, 0.8, 1.8, 48);
        break;
      case 'Torus':
        geo = new THREE.TorusGeometry(0.85, 0.35, 32, 64);
        break;
      case 'TorusKnot':
        geo = new THREE.TorusKnotGeometry(0.7, 0.25, 100, 24);
        break;
      case 'Plane':
        geo = new THREE.PlaneGeometry(2.0, 2.0, 32, 32);
        geo.rotateX(-Math.PI / 5);
        break;
      case 'Capsule':
        geo = new THREE.CapsuleGeometry(0.65, 0.8, 24, 32);
        break;
      case 'Sphere':
      default:
        geo = new THREE.SphereGeometry(1.0, 64, 48);
        break;
    }

    // Build Material
    const mat = createThreeMaterial(properties);

    const mesh = new THREE.Mesh(geo, mat);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    scene.add(mesh);
    meshRef.current = mesh;

    // Update geometry stats
    const vertCount = geo.attributes.position ? geo.attributes.position.count : 0;
    const triCount = geo.index
      ? geo.index.count / 3
      : vertCount / 3;
    setStats({ vertices: vertCount, triangles: Math.round(triCount) });
  }, [meshShape, properties, selectedNodeMeshType]);

  // Orbit camera mouse events
  const handleMouseDown = (e: React.MouseEvent) => {
    isMouseDownRef.current = true;
    mouseButtonRef.current = e.button;
    mousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDownRef.current || !cameraRef.current) return;
    const dx = e.clientX - mousePosRef.current.x;
    const dy = e.clientY - mousePosRef.current.y;
    mousePosRef.current = { x: e.clientX, y: e.clientY };

    const s = sphericalRef.current;
    const t = targetRef.current;
    const cam = cameraRef.current;

    if (mouseButtonRef.current === 0 || mouseButtonRef.current === 2) {
      // Orbit
      s.theta -= dx * 0.008;
      s.phi = Math.max(0.15, Math.min(Math.PI - 0.15, s.phi - dy * 0.008));
    } else if (mouseButtonRef.current === 1) {
      // Pan
      const right = new THREE.Vector3(1, 0, 0).applyQuaternion(cam.quaternion);
      const up = new THREE.Vector3(0, 1, 0).applyQuaternion(cam.quaternion);
      t.addScaledVector(right, -dx * 0.004);
      t.addScaledVector(up, dy * 0.004);
    }

    cam.position.x = t.x + s.radius * Math.sin(s.phi) * Math.sin(s.theta);
    cam.position.y = t.y + s.radius * Math.cos(s.phi);
    cam.position.z = t.z + s.radius * Math.sin(s.phi) * Math.cos(s.theta);
    cam.lookAt(t);
  };

  const handleMouseUp = () => {
    isMouseDownRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (!cameraRef.current) return;
    const s = sphericalRef.current;
    const t = targetRef.current;
    s.radius = Math.max(1.5, Math.min(8.0, s.radius + e.deltaY * 0.003));

    cameraRef.current.position.x = t.x + s.radius * Math.sin(s.phi) * Math.sin(s.theta);
    cameraRef.current.position.y = t.y + s.radius * Math.cos(s.phi);
    cameraRef.current.position.z = t.z + s.radius * Math.sin(s.phi) * Math.cos(s.theta);
    cameraRef.current.lookAt(t);
  };

  const resetCamera = () => {
    sphericalRef.current = { radius: 3.4, theta: 0.8, phi: 1.15 };
    targetRef.current.set(0, 0, 0);
    if (cameraRef.current) {
      const s = sphericalRef.current;
      cameraRef.current.position.set(
        s.radius * Math.sin(s.phi) * Math.sin(s.theta),
        s.radius * Math.cos(s.phi),
        s.radius * Math.sin(s.phi) * Math.cos(s.theta)
      );
      cameraRef.current.lookAt(0, 0, 0);
    }
  };

  const downloadTexturePng = (type: 'albedo' | 'normal') => {
    if (!generatedTextures) return;
    const data = type === 'albedo' ? generatedTextures.dataUrl : generatedTextures.normalDataUrl;
    if (!data) return;
    const a = document.createElement('a');
    a.href = data;
    a.download = `${properties.name.replace(/\s+/g, '_')}_${type}.png`;
    a.click();
  };

  return (
    <div className="flex flex-col h-full bg-[#141822] relative select-none overflow-hidden">
      {/* Viewport Top Header & Tabs (3D Preview vs 2D Texture Channel) */}
      <div className="h-9 px-3 border-b border-[#2c3345] bg-[#1a1f2b] flex items-center justify-between z-10">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setActiveViewTab('3d')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors ${
              activeViewTab === '3d'
                ? 'bg-[#4982ea] text-white shadow-sm'
                : 'text-[#8b97a8] hover:text-[#dfe4ec] hover:bg-[#252c3c]'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            <span>3D Mesh Preview</span>
          </button>

          <button
            onClick={() => setActiveViewTab('2d_albedo')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors ${
              activeViewTab === '2d_albedo'
                ? 'bg-[#4982ea] text-white shadow-sm'
                : 'text-[#8b97a8] hover:text-[#dfe4ec] hover:bg-[#252c3c]'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-blue-400" />
            <span>2D Albedo Map</span>
          </button>

          {properties.enableNormalMap && (
            <button
              onClick={() => setActiveViewTab('2d_normal')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                activeViewTab === '2d_normal'
                  ? 'bg-[#4982ea] text-white shadow-sm'
                  : 'text-[#8b97a8] hover:text-[#dfe4ec] hover:bg-[#252c3c]'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>2D Normal Map</span>
            </button>
          )}
        </div>

        {/* Viewport Actions */}
        <div className="flex items-center gap-1.5">
          {activeViewTab === '3d' ? (
            <>
              {/* Turntable Auto-rotate */}
              <button
                onClick={() => setAutoRotate(!autoRotate)}
                className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] border transition-colors ${
                  autoRotate
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-[#202636] text-[#8b97a8] border-[#2c3345] hover:text-white'
                }`}
                title="Girar objeto automaticamente (Turntable)"
              >
                <RotateCw className={`w-3 h-3 ${autoRotate ? 'animate-spin' : ''}`} />
                <span>Turntable</span>
              </button>

              <button
                onClick={resetCamera}
                className="p-1 rounded bg-[#202636] hover:bg-[#2c3345] text-[#8b97a8] hover:text-white border border-[#2c3345]"
                title="Reset Camera View"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </>
          ) : (
            <div className="flex items-center gap-1">
              <button
                onClick={() => setZoom2D(Math.max(0.5, zoom2D - 0.25))}
                className="p-1 rounded bg-[#202636] hover:bg-[#2c3345] text-[#8b97a8] hover:text-white"
                title="Zoom Out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="text-[11px] font-mono text-[#8b97a8] px-1">
                {Math.round(zoom2D * 100)}%
              </span>
              <button
                onClick={() => setZoom2D(Math.min(3.0, zoom2D + 0.25))}
                className="p-1 rounded bg-[#202636] hover:bg-[#2c3345] text-[#8b97a8] hover:text-white"
                title="Zoom In"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() =>
                  downloadTexturePng(activeViewTab === '2d_normal' ? 'normal' : 'albedo')
                }
                className="flex items-center gap-1 ml-1 px-2 py-0.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-[11px]"
                title="Baixar imagem da textura (.png)"
              >
                <Download className="w-3 h-3" />
                <span>Exportar PNG</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main View Area */}
      <div className="flex-1 relative overflow-hidden">
        {/* 3D WebGL Canvas Mode */}
        <div
          ref={mountRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onWheel={handleWheel}
          className={`w-full h-full cursor-grab active:cursor-grabbing ${
            activeViewTab !== '3d' ? 'hidden' : 'block'
          }`}
        />

        {/* 2D Texture Map Inspector Mode */}
        {activeViewTab !== '3d' && (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 bg-[#0f1219] overflow-auto">
            {generatedTextures ? (
              <div
                style={{ transform: `scale(${zoom2D})`, transformOrigin: 'center' }}
                className="transition-transform duration-100 shadow-2xl rounded border border-[#2c3345] bg-[#141822] overflow-hidden p-1"
              >
                <img
                  src={
                    activeViewTab === '2d_normal' && generatedTextures.normalDataUrl
                      ? generatedTextures.normalDataUrl
                      : generatedTextures.dataUrl
                  }
                  alt="Texture Map"
                  className="w-80 h-80 object-contain pixelated"
                />
              </div>
            ) : (
              <div className="flex flex-col items-center text-[#67758d] text-xs">
                <Layers className="w-10 h-10 mb-2 opacity-30" />
                <p>Nenhuma textura procedural ou arquivo carregado para este material.</p>
                <p className="text-[11px] text-[#4d596e] mt-1">
                  Selecione um padrão (ex: Hex, Brick, Grid, Wood) na aba Texturas.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Floating 3D Controls Bar */}
        {activeViewTab === '3d' && (
          <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none">
            {/* Left: Shape Selector Pills */}
            <div className="flex items-center gap-1 p-1 bg-[#1a1f2be6] backdrop-blur-md rounded-lg border border-[#2c3345] shadow-lg pointer-events-auto">
              {(
                [
                  'Sphere',
                  'Cube',
                  'Cylinder',
                  'Torus',
                  'TorusKnot',
                  'Plane',
                  'Capsule',
                ] as PreviewMeshShape[]
              ).map((shape) => (
                <button
                  key={shape}
                  onClick={() => setMeshShape(shape)}
                  className={`px-2 py-1 rounded text-[11px] font-medium transition-all ${
                    meshShape === shape
                      ? 'bg-[#4982ea] text-white shadow-sm'
                      : 'text-[#8b97a8] hover:text-[#dfe4ec] hover:bg-[#252c3c]'
                  }`}
                  title={`Preview em formato ${shape}`}
                >
                  {shape === 'Sphere' && 'Esfera'}
                  {shape === 'Cube' && 'Cubo'}
                  {shape === 'Cylinder' && 'Cilindro'}
                  {shape === 'Torus' && 'Toro'}
                  {shape === 'TorusKnot' && 'Nó'}
                  {shape === 'Plane' && 'Plano'}
                  {shape === 'Capsule' && 'Cápsula'}
                </button>
              ))}

              {selectedNodeMeshType && (
                <button
                  onClick={() => setMeshShape('CurrentSceneMesh')}
                  className={`px-2 py-1 rounded text-[11px] font-medium transition-all ${
                    meshShape === 'CurrentSceneMesh'
                      ? 'bg-amber-600 text-white shadow-sm'
                      : 'text-amber-400/80 hover:text-amber-300 hover:bg-[#252c3c]'
                  }`}
                  title="Usar forma do nó MeshInstance selecionado na cena"
                >
                  Malha da Cena ({selectedNodeMeshType.replace('Mesh', '')})
                </button>
              )}
            </div>

            {/* Right: Lighting Environment Pill */}
            <div className="flex items-center gap-1 p-1 bg-[#1a1f2be6] backdrop-blur-md rounded-lg border border-[#2c3345] shadow-lg pointer-events-auto">
              <Sun className="w-3.5 h-3.5 text-amber-400 ml-1.5 mr-0.5" />
              <select
                value={lighting}
                onChange={(e) => setLighting(e.target.value as PreviewLightingEnvironment)}
                className="bg-[#141822] text-[#dfe4ec] text-[11px] py-1 px-2 rounded border border-[#2c3345] outline-none cursor-pointer"
              >
                <option value="StudioNeutral">Estúdio 3 Pontos (Neutro)</option>
                <option value="GoldenHour">Pôr do Sol (Golden Hour)</option>
                <option value="CyberpunkNeon">Cyberpunk Neon (Ciano/Magenta)</option>
                <option value="OvercastSoft">Luz Difusa Suave</option>
                <option value="DramaticSpotlight">Spotlight Dramático</option>
                <option value="DarkVoid">Fundo Escuro Mínimo</option>
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Viewport Footer Bar with Stats */}
      <div className="h-6 px-3 border-t border-[#2c3345] bg-[#161a24] flex items-center justify-between text-[10px] text-[#718096] z-10">
        <div className="flex items-center gap-3">
          <span>
            Modelo:{' '}
            <strong className="text-[#a0aec0] font-mono">{properties.shadingModel}</strong>
          </span>
          <span>
            Vértices: <strong className="text-[#a0aec0] font-mono">{stats.vertices}</strong>
          </span>
          <span>
            Triângulos: <strong className="text-[#a0aec0] font-mono">{stats.triangles}</strong>
          </span>
          {properties.textureType !== 'none' && (
            <span className="text-blue-400 font-mono">
              Textura: {properties.textureType} (512x512)
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <span>Arraste: Girar | Botão Meio: Mover | Scroll: Zoom</span>
        </div>
      </div>
    </div>
  );
};
