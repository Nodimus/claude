import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useEditor } from '../../core/EditorContext';
import {
  Trees,
  Wind,
  Sliders,
  Palette,
  Layers,
  Sparkles,
  X,
  RotateCcw,
  Check,
  Eye,
  Info,
  ExternalLink,
  ChevronRight,
  Maximize2,
  RefreshCw,
  Mountain,
  Sun,
  Flame,
  CheckSquare,
  Square,
  Compass,
} from 'lucide-react';

export type TreeSpeciesPreset =
  | 'oak'
  | 'pine'
  | 'palm'
  | 'birch'
  | 'willow'
  | 'autumn'
  | 'dead';

export type FoliageStyle = 'cards' | 'clusters' | 'fronds' | 'needles';

export interface TreePresetConfig {
  name: string;
  species: TreeSpeciesPreset;
  description: string;
  trunkHeight: number;
  trunkRadiusBase: number;
  trunkRadiusTop: number;
  trunkGnarl: number;
  trunkSegments: number;
  radialSegments: number;
  barkTexture: string;
  barkColor: string;
  rootFlare: boolean;
  branchLevels: number;
  branchStartHeight: number; // 0 to 1
  branchesPerLevel: number;
  branchAngle: number; // degrees
  branchLength: number;
  branchDroop: number; // -1 to 1 (negative = droop downwards, positive = reach upwards)
  subBranching: boolean;
  foliageStyle: FoliageStyle;
  leafSize: number;
  leafDensity: number;
  leafTexture: string;
  leafColor: string;
  leafRandomAngle: number;
  windEnabled: boolean;
  windStrength: number;
  windFrequency: number;
  leafFlutter: number;
}

const PRESETS: Record<TreeSpeciesPreset, TreePresetConfig> = {
  oak: {
    name: 'Carvalho (Oak)',
    species: 'oak',
    description: 'Árvore frondosa clássica com copa arredondada, múltiplos ramos e madeira encorpada.',
    trunkHeight: 7.5,
    trunkRadiusBase: 0.45,
    trunkRadiusTop: 0.22,
    trunkGnarl: 0.35,
    trunkSegments: 8,
    radialSegments: 8,
    barkTexture: 'Oak_Bark_Rough',
    barkColor: '#5a3d28',
    rootFlare: true,
    branchLevels: 3,
    branchStartHeight: 0.38,
    branchesPerLevel: 4,
    branchAngle: 55,
    branchLength: 3.2,
    branchDroop: 0.05,
    subBranching: true,
    foliageStyle: 'cards',
    leafSize: 0.65,
    leafDensity: 42,
    leafTexture: 'Broadleaf_Oak_Green',
    leafColor: '#2d6a36',
    leafRandomAngle: 0.8,
    windEnabled: true,
    windStrength: 0.35,
    windFrequency: 1.2,
    leafFlutter: 0.5,
  },
  pine: {
    name: 'Pinheiro (Conifer Pine)',
    species: 'pine',
    description: 'Tronco reto cônico, ramos horizontais e agulhas perenes distribuídas em camadas.',
    trunkHeight: 11.0,
    trunkRadiusBase: 0.35,
    trunkRadiusTop: 0.08,
    trunkGnarl: 0.08,
    trunkSegments: 10,
    radialSegments: 7,
    barkTexture: 'Pine_Scaly_Bark',
    barkColor: '#452b1b',
    rootFlare: false,
    branchLevels: 6,
    branchStartHeight: 0.22,
    branchesPerLevel: 5,
    branchAngle: 72,
    branchLength: 2.8,
    branchDroop: -0.15,
    subBranching: true,
    foliageStyle: 'needles',
    leafSize: 0.45,
    leafDensity: 55,
    leafTexture: 'Pine_Needles_Dark',
    leafColor: '#1d482c',
    leafRandomAngle: 0.4,
    windEnabled: true,
    windStrength: 0.25,
    windFrequency: 1.6,
    leafFlutter: 0.3,
  },
  palm: {
    name: 'Palmeira Tropical (Palm)',
    species: 'palm',
    description: 'Tronco delgado e curvado com anéis, sem ramificações laterais e grandes palmas no topo.',
    trunkHeight: 9.0,
    trunkRadiusBase: 0.3,
    trunkRadiusTop: 0.26,
    trunkGnarl: 0.65,
    trunkSegments: 12,
    radialSegments: 8,
    barkTexture: 'Palm_Rings_Fibrous',
    barkColor: '#7a5a3a',
    rootFlare: true,
    branchLevels: 1,
    branchStartHeight: 0.94,
    branchesPerLevel: 9,
    branchAngle: 38,
    branchLength: 3.8,
    branchDroop: -0.65,
    subBranching: false,
    foliageStyle: 'fronds',
    leafSize: 1.3,
    leafDensity: 14,
    leafTexture: 'Palm_Frond_Large',
    leafColor: '#38782a',
    leafRandomAngle: 0.3,
    windEnabled: true,
    windStrength: 0.7,
    windFrequency: 0.9,
    leafFlutter: 0.8,
  },
  birch: {
    name: 'Bétula (White Birch)',
    species: 'birch',
    description: 'Tronco esguio característico com casca branca e marcas pretas, folhagem leve e dourada.',
    trunkHeight: 8.5,
    trunkRadiusBase: 0.26,
    trunkRadiusTop: 0.12,
    trunkGnarl: 0.2,
    trunkSegments: 8,
    radialSegments: 7,
    barkTexture: 'Birch_White_Striated',
    barkColor: '#e0ded8',
    rootFlare: false,
    branchLevels: 3,
    branchStartHeight: 0.45,
    branchesPerLevel: 3,
    branchAngle: 42,
    branchLength: 2.6,
    branchDroop: 0.15,
    subBranching: true,
    foliageStyle: 'cards',
    leafSize: 0.5,
    leafDensity: 36,
    leafTexture: 'Birch_Leaves_Light',
    leafColor: '#589432',
    leafRandomAngle: 0.7,
    windEnabled: true,
    windStrength: 0.45,
    windFrequency: 1.4,
    leafFlutter: 0.65,
  },
  willow: {
    name: 'Salgueiro-Chorão (Weeping Willow)',
    species: 'willow',
    description: 'Tronco espesso com galhos cascateantes que pendem em direção ao solo com balanço gracioso.',
    trunkHeight: 6.8,
    trunkRadiusBase: 0.55,
    trunkRadiusTop: 0.28,
    trunkGnarl: 0.45,
    trunkSegments: 8,
    radialSegments: 8,
    barkTexture: 'Willow_Furrowed_Bark',
    barkColor: '#4d3a2b',
    rootFlare: true,
    branchLevels: 4,
    branchStartHeight: 0.35,
    branchesPerLevel: 5,
    branchAngle: 50,
    branchLength: 3.6,
    branchDroop: -0.75,
    subBranching: true,
    foliageStyle: 'cards',
    leafSize: 0.4,
    leafDensity: 60,
    leafTexture: 'Willow_Drooping_Green',
    leafColor: '#4f7d3a',
    leafRandomAngle: 0.9,
    windEnabled: true,
    windStrength: 0.65,
    windFrequency: 0.85,
    leafFlutter: 0.7,
  },
  autumn: {
    name: 'Árvore de Outono (Autumn Maple)',
    species: 'autumn',
    description: 'Copa densa e vibrante com cores outonais quentes em tons de laranja, dourado e carmesim.',
    trunkHeight: 7.2,
    trunkRadiusBase: 0.42,
    trunkRadiusTop: 0.2,
    trunkGnarl: 0.3,
    trunkSegments: 8,
    radialSegments: 8,
    barkTexture: 'Maple_Gray_Bark',
    barkColor: '#524338',
    rootFlare: true,
    branchLevels: 3,
    branchStartHeight: 0.36,
    branchesPerLevel: 4,
    branchAngle: 52,
    branchLength: 3.1,
    branchDroop: 0.0,
    subBranching: true,
    foliageStyle: 'clusters',
    leafSize: 0.6,
    leafDensity: 48,
    leafTexture: 'Maple_Autumn_Orange',
    leafColor: '#c85a17',
    leafRandomAngle: 0.85,
    windEnabled: true,
    windStrength: 0.4,
    windFrequency: 1.1,
    leafFlutter: 0.6,
  },
  dead: {
    name: 'Árvore Seca / Mística (Dead Tree)',
    species: 'dead',
    description: 'Tronco retorcido e seco sem folhas, ideal para cenários góticos, desérticos ou sombrios.',
    trunkHeight: 6.5,
    trunkRadiusBase: 0.48,
    trunkRadiusTop: 0.16,
    trunkGnarl: 0.85,
    trunkSegments: 10,
    radialSegments: 7,
    barkTexture: 'Dead_Charred_Wood',
    barkColor: '#332a24',
    rootFlare: true,
    branchLevels: 3,
    branchStartHeight: 0.28,
    branchesPerLevel: 4,
    branchAngle: 65,
    branchLength: 3.4,
    branchDroop: 0.25,
    subBranching: true,
    foliageStyle: 'cards',
    leafSize: 0.0,
    leafDensity: 0,
    leafTexture: 'None',
    leafColor: '#332a24',
    leafRandomAngle: 0.0,
    windEnabled: true,
    windStrength: 0.15,
    windFrequency: 1.5,
    leafFlutter: 0.0,
  },
};

export const TreeEditorModal: React.FC = () => {
  const {
    isTreeEditorOpen,
    setIsTreeEditorOpen,
    setIsTerrainEditorOpen,
    activeScene,
    addNode,
    selectNode,
    addLog,
  } = useEditor();

  const [activeTab, setActiveTab] = useState<'trunk' | 'branches' | 'leaves' | 'wind_lod'>('trunk');
  const [selectedPreset, setSelectedPreset] = useState<TreeSpeciesPreset>('oak');

  // Parameters state
  const [trunkHeight, setTrunkHeight] = useState<number>(PRESETS.oak.trunkHeight);
  const [trunkRadiusBase, setTrunkRadiusBase] = useState<number>(PRESETS.oak.trunkRadiusBase);
  const [trunkRadiusTop, setTrunkRadiusTop] = useState<number>(PRESETS.oak.trunkRadiusTop);
  const [trunkGnarl, setTrunkGnarl] = useState<number>(PRESETS.oak.trunkGnarl);
  const [trunkSegments, setTrunkSegments] = useState<number>(PRESETS.oak.trunkSegments);
  const [radialSegments, setRadialSegments] = useState<number>(PRESETS.oak.radialSegments);
  const [barkTexture, setBarkTexture] = useState<string>(PRESETS.oak.barkTexture);
  const [barkColor, setBarkColor] = useState<string>(PRESETS.oak.barkColor);
  const [rootFlare, setRootFlare] = useState<boolean>(PRESETS.oak.rootFlare);

  // Branches
  const [branchLevels, setBranchLevels] = useState<number>(PRESETS.oak.branchLevels);
  const [branchStartHeight, setBranchStartHeight] = useState<number>(PRESETS.oak.branchStartHeight);
  const [branchesPerLevel, setBranchesPerLevel] = useState<number>(PRESETS.oak.branchesPerLevel);
  const [branchAngle, setBranchAngle] = useState<number>(PRESETS.oak.branchAngle);
  const [branchLength, setBranchLength] = useState<number>(PRESETS.oak.branchLength);
  const [branchDroop, setBranchDroop] = useState<number>(PRESETS.oak.branchDroop);
  const [subBranching, setSubBranching] = useState<boolean>(PRESETS.oak.subBranching);

  // Foliage
  const [foliageStyle, setFoliageStyle] = useState<FoliageStyle>(PRESETS.oak.foliageStyle);
  const [leafSize, setLeafSize] = useState<number>(PRESETS.oak.leafSize);
  const [leafDensity, setLeafDensity] = useState<number>(PRESETS.oak.leafDensity);
  const [leafTexture, setLeafTexture] = useState<string>(PRESETS.oak.leafTexture);
  const [leafColor, setLeafColor] = useState<string>(PRESETS.oak.leafColor);
  const [leafRandomAngle, setLeafRandomAngle] = useState<number>(PRESETS.oak.leafRandomAngle);

  // Wind & LOD
  const [windEnabled, setWindEnabled] = useState<boolean>(PRESETS.oak.windEnabled);
  const [windStrength, setWindStrength] = useState<number>(PRESETS.oak.windStrength);
  const [windFrequency, setWindFrequency] = useState<number>(PRESETS.oak.windFrequency);
  const [leafFlutter, setLeafFlutter] = useState<number>(PRESETS.oak.leafFlutter);
  const [randomSeed, setRandomSeed] = useState<number>(42);
  const [wireframeMode, setWireframeMode] = useState<boolean>(false);
  const [animateWindPreview, setAnimateWindPreview] = useState<boolean>(true);
  const [previewRotation, setPreviewRotation] = useState<number>(0);

  // Preview canvas ref
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number | null>(null);

  // Apply preset
  const applyPreset = (presetKey: TreeSpeciesPreset) => {
    setSelectedPreset(presetKey);
    const p = PRESETS[presetKey];
    setTrunkHeight(p.trunkHeight);
    setTrunkRadiusBase(p.trunkRadiusBase);
    setTrunkRadiusTop(p.trunkRadiusTop);
    setTrunkGnarl(p.trunkGnarl);
    setTrunkSegments(p.trunkSegments);
    setRadialSegments(p.radialSegments);
    setBarkTexture(p.barkTexture);
    setBarkColor(p.barkColor);
    setRootFlare(p.rootFlare);
    setBranchLevels(p.branchLevels);
    setBranchStartHeight(p.branchStartHeight);
    setBranchesPerLevel(p.branchesPerLevel);
    setBranchAngle(p.branchAngle);
    setBranchLength(p.branchLength);
    setBranchDroop(p.branchDroop);
    setSubBranching(p.subBranching);
    setFoliageStyle(p.foliageStyle);
    setLeafSize(p.leafSize);
    setLeafDensity(p.leafDensity);
    setLeafTexture(p.leafTexture);
    setLeafColor(p.leafColor);
    setLeafRandomAngle(p.leafRandomAngle);
    setWindEnabled(p.windEnabled);
    setWindStrength(p.windStrength);
    setWindFrequency(p.windFrequency);
    setLeafFlutter(p.leafFlutter);
    setRandomSeed(Math.floor(Math.random() * 9999));
  };

  // Re-roll seed
  const randomizeSeed = () => {
    setRandomSeed(Math.floor(Math.random() * 99999));
  };

  // Estimated stats
  const estimatedStats = useMemo(() => {
    const trunkTris = radialSegments * trunkSegments * 2;
    const branchTris = branchLevels * branchesPerLevel * (subBranching ? 2.5 : 1) * radialSegments * 6;
    const leafTris = leafDensity > 0 ? branchLevels * branchesPerLevel * leafDensity * 2 : 0;
    const totalTris = Math.round(trunkTris + branchTris + leafTris);
    const totalVerts = Math.round(totalTris * 0.65);
    return {
      triangles: totalTris,
      vertices: totalVerts,
      materials: leafDensity > 0 ? 2 : 1,
      estimatedMemoryKb: Math.max(12, Math.round(totalTris * 0.045)),
    };
  }, [radialSegments, trunkSegments, branchLevels, branchesPerLevel, subBranching, leafDensity]);

  // Real-time canvas rendering of procedural tree
  useEffect(() => {
    if (!isTreeEditorOpen) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let startTime = performance.now();

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      // Background gradient: studio dark gradient with ground plane hint
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, '#151923');
      bgGrad.addColorStop(0.7, '#10141c');
      bgGrad.addColorStop(1, '#0c0f16');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // Ground shadow & circular platform
      const groundY = h * 0.82;
      const centerX = w * 0.5;

      ctx.beginPath();
      ctx.ellipse(centerX, groundY, w * 0.38, 22, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(7, 10, 16, 0.7)';
      ctx.fill();

      // Grid concentric lines on ground
      ctx.strokeStyle = 'rgba(56, 70, 95, 0.25)';
      ctx.lineWidth = 1;
      for (let r = 0.15; r <= 0.38; r += 0.08) {
        ctx.beginPath();
        ctx.ellipse(centerX, groundY, w * r, 20 * (r / 0.38), 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Time for wind calculation
      const elapsed = (performance.now() - startTime) * 0.001;
      const windAngle =
        animateWindPreview && windEnabled
          ? Math.sin(elapsed * windFrequency * 2.2) * (windStrength * 0.12)
          : 0;

      // Deterministic PRNG using randomSeed
      let prngSeed = randomSeed;
      const random = () => {
        const x = Math.sin(prngSeed++) * 10000;
        return x - Math.floor(x);
      };

      // Root flares
      if (rootFlare) {
        ctx.strokeStyle = barkColor;
        ctx.fillStyle = barkColor;
        ctx.lineWidth = Math.max(3, trunkRadiusBase * 16);
        ctx.beginPath();
        ctx.moveTo(centerX - trunkRadiusBase * 25, groundY);
        ctx.lineTo(centerX - trunkRadiusBase * 55, groundY + 4);
        ctx.moveTo(centerX + trunkRadiusBase * 25, groundY);
        ctx.lineTo(centerX + trunkRadiusBase * 55, groundY + 5);
        ctx.stroke();
      }

      // Draw Trunk (Segmented with gnarl & wind sway)
      const scaleY = (h * 0.6) / 12; // pixels per meter
      const totalPixelsHeight = trunkHeight * scaleY;

      const segments = trunkSegments;
      const trunkPoints: { x: number; y: number; r: number }[] = [];

      for (let i = 0; i <= segments; i++) {
        const t = i / segments;
        const py = groundY - t * totalPixelsHeight;
        const curRadius =
          (trunkRadiusBase * (1 - t) + trunkRadiusTop * t) * (w * 0.035);

        // Curvature / gnarl & wind bend
        const gnarlOffset =
          Math.sin(t * Math.PI * 1.5 + (randomSeed % 10)) * (trunkGnarl * 32 * t);
        const swayOffset = windAngle * Math.pow(t, 1.6) * totalPixelsHeight * 0.8;

        // Apply rotation angle
        const rotRad = (previewRotation * Math.PI) / 180;
        const px = centerX + (gnarlOffset + swayOffset) * Math.cos(rotRad);

        trunkPoints.push({ x: px, y: py, r: curRadius });
      }

      // Draw trunk mesh / silhouette
      if (wireframeMode) {
        ctx.strokeStyle = '#4ade80';
        ctx.lineWidth = 1.2;
      } else {
        ctx.fillStyle = barkColor;
        ctx.strokeStyle = 'rgba(0,0,0,0.4)';
        ctx.lineWidth = 1;
      }

      // Draw trunk body as tapered polygonal strips
      ctx.beginPath();
      for (let i = 0; i < trunkPoints.length; i++) {
        const pt = trunkPoints[i];
        if (i === 0) ctx.moveTo(pt.x - pt.r, pt.y);
        else ctx.lineTo(pt.x - pt.r, pt.y);
      }
      for (let i = trunkPoints.length - 1; i >= 0; i--) {
        const pt = trunkPoints[i];
        ctx.lineTo(pt.x + pt.r, pt.y);
      }
      ctx.closePath();

      if (wireframeMode) {
        ctx.stroke();
        // Draw cross segments
        for (const pt of trunkPoints) {
          ctx.beginPath();
          ctx.ellipse(pt.x, pt.y, pt.r, pt.r * 0.35, 0, 0, Math.PI * 2);
          ctx.stroke();
        }
      } else {
        ctx.fill();
        ctx.stroke();

        // Shading on trunk (bark highlight / shadow)
        const trunkGrad = ctx.createLinearGradient(
          centerX - 30,
          0,
          centerX + 30,
          0
        );
        trunkGrad.addColorStop(0, 'rgba(0,0,0,0.35)');
        trunkGrad.addColorStop(0.4, 'rgba(255,255,255,0.15)');
        trunkGrad.addColorStop(1, 'rgba(0,0,0,0.45)');
        ctx.fillStyle = trunkGrad;
        ctx.fill();
      }

      // Branches & Leaves
      const branchAngleRad = (branchAngle * Math.PI) / 180;
      const leafColorBase = leafColor;

      // Draw branches and canopy
      for (let lvl = 0; lvl < branchLevels; lvl++) {
        const levelNorm = (lvl + 1) / branchLevels;
        const segIdx = Math.floor(
          trunkPoints.length *
            (branchStartHeight +
              (1 - branchStartHeight) * (lvl / Math.max(1, branchLevels - 1 || 1)))
        );
        const attachPt =
          trunkPoints[Math.min(segIdx, trunkPoints.length - 1)] ||
          trunkPoints[trunkPoints.length - 1];

        const count = branchesPerLevel;
        for (let b = 0; b < count; b++) {
          const side = b % 2 === 0 ? 1 : -1;
          const spreadFactor = ((b % 3) - 1) * 0.3;
          const len = branchLength * scaleY * (1.1 - levelNorm * 0.4);

          // Angle affected by droop and wind
          const curBranchAngle =
            branchAngleRad +
            branchDroop * 0.6 +
            windAngle * 0.4 +
            spreadFactor * 0.2;
          const endX = attachPt.x + side * Math.sin(curBranchAngle) * len;
          const endY =
            attachPt.y -
            Math.cos(curBranchAngle) * len +
            branchDroop * (len * 0.35);

          // Draw Branch line
          const branchThick = Math.max(2, (1 - levelNorm * 0.6) * 6);
          ctx.beginPath();
          ctx.moveTo(attachPt.x, attachPt.y);
          // quadratic curve for natural droop
          const midX = (attachPt.x + endX) * 0.5;
          const midY = (attachPt.y + endY) * 0.5 + branchDroop * 14;
          ctx.quadraticCurveTo(midX, midY, endX, endY);

          if (wireframeMode) {
            ctx.strokeStyle = '#60a5fa';
            ctx.lineWidth = 1;
            ctx.stroke();
          } else {
            ctx.strokeStyle = barkColor;
            ctx.lineWidth = branchThick;
            ctx.lineCap = 'round';
            ctx.stroke();
          }

          // Sub-branches
          if (subBranching && lvl < branchLevels - 1) {
            const subEndX = endX + side * (len * 0.35);
            const subEndY = endY - len * 0.25;
            ctx.beginPath();
            ctx.moveTo(midX, midY);
            ctx.lineTo(subEndX, subEndY);
            ctx.strokeStyle = barkColor;
            ctx.lineWidth = Math.max(1.5, branchThick * 0.6);
            ctx.stroke();
          }

          // Foliage / Leaves cards at the tip of the branches
          if (leafDensity > 0) {
            const numLeaves = Math.min(18, Math.max(3, Math.floor(leafDensity / 3)));
            for (let l = 0; l < numLeaves; l++) {
              const lx = endX + (random() - 0.5) * leafSize * 45;
              const ly = endY + (random() - 0.5) * leafSize * 35;
              const leafSway =
                animateWindPreview && windEnabled
                  ? Math.sin(elapsed * windFrequency * 4 + l) * (leafFlutter * 4)
                  : 0;

              ctx.save();
              ctx.translate(lx + leafSway, ly);
              ctx.rotate((random() * 2 - 1) * leafRandomAngle * Math.PI);

              if (foliageStyle === 'fronds') {
                // Large tropical palm fronds
                ctx.beginPath();
                ctx.ellipse(0, 0, leafSize * 24, leafSize * 6, 0.4, 0, Math.PI * 2);
                ctx.fillStyle = leafColorBase;
                ctx.fill();
                if (wireframeMode) {
                  ctx.strokeStyle = '#22c55e';
                  ctx.stroke();
                }
              } else if (foliageStyle === 'needles') {
                // Pine needle bunch
                ctx.strokeStyle = leafColorBase;
                ctx.lineWidth = 1.5;
                for (let a = -0.5; a <= 0.5; a += 0.2) {
                  ctx.beginPath();
                  ctx.moveTo(0, 0);
                  ctx.lineTo(Math.sin(a) * leafSize * 22, -Math.cos(a) * leafSize * 22);
                  ctx.stroke();
                }
              } else if (foliageStyle === 'clusters') {
                // Fluffy volumetric puffs
                ctx.beginPath();
                ctx.arc(0, 0, leafSize * 16, 0, Math.PI * 2);
                ctx.fillStyle = leafColorBase;
                ctx.globalAlpha = 0.85;
                ctx.fill();
                ctx.globalAlpha = 1.0;
                if (wireframeMode) {
                  ctx.strokeStyle = '#86efac';
                  ctx.stroke();
                }
              } else {
                // Standard quad cards
                const cardW = leafSize * 16;
                const cardH = leafSize * 12;
                ctx.fillStyle = leafColorBase;
                ctx.fillRect(-cardW * 0.5, -cardH * 0.5, cardW, cardH);
                if (wireframeMode) {
                  ctx.strokeStyle = '#86efac';
                  ctx.strokeRect(-cardW * 0.5, -cardH * 0.5, cardW, cardH);
                }
              }

              ctx.restore();
            }
          }
        }
      }

      // Top apex foliage cluster
      if (leafDensity > 0 && trunkPoints.length > 0) {
        const topPt = trunkPoints[trunkPoints.length - 1];
        ctx.save();
        ctx.translate(topPt.x, topPt.y - 10);
        ctx.beginPath();
        ctx.arc(0, 0, leafSize * 22, 0, Math.PI * 2);
        ctx.fillStyle = leafColorBase;
        ctx.globalAlpha = 0.9;
        ctx.fill();
        ctx.globalAlpha = 1.0;
        ctx.restore();
      }

      // Request next frame if animation is active
      if (animateWindPreview) {
        animFrameRef.current = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [
    isTreeEditorOpen,
    trunkHeight,
    trunkRadiusBase,
    trunkRadiusTop,
    trunkGnarl,
    trunkSegments,
    radialSegments,
    barkColor,
    rootFlare,
    branchLevels,
    branchStartHeight,
    branchesPerLevel,
    branchAngle,
    branchLength,
    branchDroop,
    subBranching,
    foliageStyle,
    leafSize,
    leafDensity,
    leafColor,
    leafRandomAngle,
    windEnabled,
    windStrength,
    windFrequency,
    leafFlutter,
    randomSeed,
    wireframeMode,
    animateWindPreview,
    previewRotation,
  ]);

  if (!isTreeEditorOpen) return null;

  // Insert tree into active scene
  const handleInsertTree = () => {
    const parentId = activeScene.rootNodeId;
    const treeNodeName = `Tree_${PRESETS[selectedPreset].species.toUpperCase()}_${Date.now().toString().slice(-4)}`;

    // Criação + metadados/propriedades procedurais num único Command (um Undo remove o nó)
    const newNode = addNode('MeshInstance', parentId, treeNodeName, {
      meshType: 'cylinder',
      isProceduralTree: true,
      treePreset: selectedPreset,
      trunkHeight,
      trunkRadiusBase,
      trunkRadiusTop,
      barkColor,
      leafColor,
      foliageStyle,
      windEnabled,
      windStrength,
      windFrequency,
      seed: randomSeed,
      castShadow: true,
      receiveShadow: true,
    });

    selectNode(newNode.id);
    addLog(
      'log',
      `Generated procedural tree "${treeNodeName}" (${estimatedStats.triangles} triangles, ${estimatedStats.vertices} vertices, Wind: ${windEnabled ? 'Enabled' : 'Disabled'})`
    );

    setIsTreeEditorOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 select-none animate-in fade-in duration-150">
      <div className="bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-5xl h-[92vh] max-h-[820px] flex flex-col overflow-hidden text-sm text-[#d4dbe8]">
        {/* Header */}
        <div className="px-5 py-3.5 bg-[#141720] border-b border-[#242b3b] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <Trees className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-semibold text-white text-base">
                  Tree Editor & Generator
                </h2>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
                  CopperCube Procedural
                </span>
              </div>
              <p className="text-xs text-[#828f9f] mt-0.5">
                Gere árvores 3D procedurais e folhagens otimizadas com animação de vento em tempo real
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="https://www.ambiera.com/coppercube/doc/cnt_terrain.html"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 text-xs text-[#828f9f] hover:text-[#c5d0e2] hover:bg-[#202636] border border-transparent hover:border-[#2f394c] rounded flex items-center gap-1.5 transition-colors"
              title="CopperCube Documentation"
            >
              <span>Doc</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={() => setIsTreeEditorOpen(false)}
              className="p-1.5 text-[#828f9f] hover:text-white hover:bg-[#252c3c] rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Species Presets Quick Toolbar */}
        <div className="px-5 py-2.5 bg-[#12151d] border-b border-[#202636] flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-[11px] font-semibold text-[#6d7a8d] uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" /> Presets:
          </span>
          {(Object.keys(PRESETS) as TreeSpeciesPreset[]).map((key) => {
            const p = PRESETS[key];
            const isSelected = selectedPreset === key;
            return (
              <button
                key={key}
                onClick={() => applyPreset(key)}
                className={`px-2.5 py-1 text-xs rounded-md border flex items-center gap-1.5 shrink-0 transition-all ${
                  isSelected
                    ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 font-medium shadow-sm shadow-emerald-950'
                    : 'bg-[#181c26] border-[#262e3e] text-[#8e9cb0] hover:text-[#dfe4ec] hover:border-[#384358]'
                }`}
              >
                <span>{p.name.split(' ')[0]}</span>
                {isSelected && <Check className="w-3 h-3 text-emerald-400" />}
              </button>
            );
          })}
        </div>

        {/* Main Content: Two Columns */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Column: Tabs & Parameters */}
          <div className="w-[58%] border-r border-[#242b3b] flex flex-col bg-[#161a24]">
            {/* Category Tabs */}
            <div className="flex border-b border-[#222838] bg-[#141721] px-3 pt-2 gap-1 shrink-0">
              <button
                onClick={() => setActiveTab('trunk')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'trunk'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-amber-400" />
                <span>Trunk (Tronco)</span>
              </button>

              <button
                onClick={() => setActiveTab('branches')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'branches'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                <span>Branches (Galhos)</span>
              </button>

              <button
                onClick={() => setActiveTab('leaves')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'leaves'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Trees className="w-3.5 h-3.5 text-emerald-400" />
                <span>Leaves & Foliage</span>
              </button>

              <button
                onClick={() => setActiveTab('wind_lod')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'wind_lod'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Wind className="w-3.5 h-3.5 text-cyan-400" />
                <span>Wind & LOD</span>
              </button>
            </div>

            {/* Tab Panels with Smooth Scroll */}
            <div className="flex-1 overflow-y-auto p-5 space-y-5 text-xs text-[#a9b6c8]">
              {/* TAB 1: TRUNK */}
              {activeTab === 'trunk' && (
                <div className="space-y-4">
                  <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg">
                    <h3 className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
                      <Layers className="w-4 h-4 text-amber-400" />
                      Geometria do Tronco (Trunk Geometry)
                    </h3>
                    <p className="text-[11px] text-[#788496]">
                      Ajuste altura, curvatura orgânica, espessura e resolução radial para a malha cilíndrica.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Trunk Height (Altura)</label>
                        <span className="font-mono text-emerald-400">{trunkHeight.toFixed(1)}m</span>
                      </div>
                      <input
                        type="range"
                        min="2.0"
                        max="22.0"
                        step="0.5"
                        value={trunkHeight}
                        onChange={(e) => setTrunkHeight(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Base Radius (Raio da Base)</label>
                        <span className="font-mono text-emerald-400">{trunkRadiusBase.toFixed(2)}m</span>
                      </div>
                      <input
                        type="range"
                        min="0.1"
                        max="1.5"
                        step="0.05"
                        value={trunkRadiusBase}
                        onChange={(e) => setTrunkRadiusBase(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Top Radius (Raio do Topo)</label>
                        <span className="font-mono text-emerald-400">{trunkRadiusTop.toFixed(2)}m</span>
                      </div>
                      <input
                        type="range"
                        min="0.05"
                        max="0.8"
                        step="0.02"
                        value={trunkRadiusTop}
                        onChange={(e) => setTrunkRadiusTop(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Gnarl / Curvature (Curvatura)</label>
                        <span className="font-mono text-emerald-400">{(trunkGnarl * 100).toFixed(0)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0.0"
                        max="1.0"
                        step="0.05"
                        value={trunkGnarl}
                        onChange={(e) => setTrunkGnarl(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>
                  </div>

                  <div className="border-t border-[#232a3a] pt-4 grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Radial Segments (Resolução Vértices)</label>
                        <span className="font-mono text-emerald-400">{radialSegments} lados</span>
                      </div>
                      <input
                        type="range"
                        min="5"
                        max="16"
                        step="1"
                        value={radialSegments}
                        onChange={(e) => setRadialSegments(parseInt(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                      <span className="text-[10px] text-[#697587]">
                        CopperCube padrão: 7 a 9 vértices para performance máxima em tempo real.
                      </span>
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Height Segments (Anéis)</label>
                        <span className="font-mono text-emerald-400">{trunkSegments}</span>
                      </div>
                      <input
                        type="range"
                        min="4"
                        max="16"
                        step="1"
                        value={trunkSegments}
                        onChange={(e) => setTrunkSegments(parseInt(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>
                  </div>

                  {/* Bark Material */}
                  <div className="border-t border-[#232a3a] pt-4 space-y-3">
                    <h4 className="text-white font-medium flex items-center gap-2">
                      <Palette className="w-3.5 h-3.5 text-amber-400" />
                      Material e Textura da Casca (Bark Texture)
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-[#98a5b8] mb-1 block">Textura da Casca</label>
                        <select
                          value={barkTexture}
                          onChange={(e) => setBarkTexture(e.target.value)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs focus:outline-none focus:border-emerald-500"
                        >
                          <option value="Oak_Bark_Rough">Oak Rough Bark (Carvalho)</option>
                          <option value="Pine_Scaly_Bark">Pine Scaly Bark (Pinheiro)</option>
                          <option value="Birch_White_Striated">Birch White (Bétula Branca)</option>
                          <option value="Palm_Rings_Fibrous">Palm Fibrous Rings (Palmeira)</option>
                          <option value="Willow_Furrowed_Bark">Willow Furrowed (Salgueiro)</option>
                          <option value="Dead_Charred_Wood">Charred Dark Wood (Madeira Queimada)</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[#98a5b8] mb-1 block">Tonalidade / Bark Color</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={barkColor}
                            onChange={(e) => setBarkColor(e.target.value)}
                            className="w-8 h-8 rounded border border-[#2b3345] bg-transparent cursor-pointer p-0.5"
                          />
                          <input
                            type="text"
                            value={barkColor}
                            onChange={(e) => setBarkColor(e.target.value)}
                            className="flex-1 bg-[#1b202c] border border-[#2c3447] rounded px-2.5 py-1.5 text-white font-mono text-xs uppercase"
                          />
                        </div>
                      </div>
                    </div>

                    <label className="flex items-center gap-2 text-[#c4cfdf] cursor-pointer mt-2">
                      <input
                        type="checkbox"
                        checked={rootFlare}
                        onChange={(e) => setRootFlare(e.target.checked)}
                        className="rounded border-[#2c3447] bg-[#1a1f2b] text-emerald-500 focus:ring-0"
                      />
                      <span>Gerar raízes superficiais na base (Root Flare / Buttress)</span>
                    </label>
                  </div>
                </div>
              )}

              {/* TAB 2: BRANCHES */}
              {activeTab === 'branches' && (
                <div className="space-y-4">
                  <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg">
                    <h3 className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
                      <ChevronRight className="w-4 h-4 text-blue-400" />
                      Sistema de Ramos e Galhos (Branching Architecture)
                    </h3>
                    <p className="text-[11px] text-[#788496]">
                      Controle os parâmetros de ramificação idênticos ao CopperCube (First branch segment, Branch degrees, Segment count).
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Branch Levels (Níveis de Ramos)</label>
                        <span className="font-mono text-blue-400">{branchLevels}</span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="8"
                        step="1"
                        value={branchLevels}
                        onChange={(e) => setBranchLevels(parseInt(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Branches Per Level (Ramos p/ Nível)</label>
                        <span className="font-mono text-blue-400">{branchesPerLevel}</span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="10"
                        step="1"
                        value={branchesPerLevel}
                        onChange={(e) => setBranchesPerLevel(parseInt(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">First Branch Height (Início da Copa)</label>
                        <span className="font-mono text-blue-400">{(branchStartHeight * 100).toFixed(0)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0.1"
                        max="0.95"
                        step="0.05"
                        value={branchStartHeight}
                        onChange={(e) => setBranchStartHeight(parseFloat(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                      <span className="text-[10px] text-[#697587]">
                        Define onde o tronco começa a ramificar (alto para palmeiras, médio para carvalho).
                      </span>
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Branch Degrees / Angle (Ângulo)</label>
                        <span className="font-mono text-blue-400">{branchAngle}°</span>
                      </div>
                      <input
                        type="range"
                        min="20"
                        max="88"
                        step="2"
                        value={branchAngle}
                        onChange={(e) => setBranchAngle(parseInt(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Branch Length (Comprimento)</label>
                        <span className="font-mono text-blue-400">{branchLength.toFixed(1)}m</span>
                      </div>
                      <input
                        type="range"
                        min="1.0"
                        max="8.0"
                        step="0.2"
                        value={branchLength}
                        onChange={(e) => setBranchLength(parseFloat(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Branch Droop / Gravity (Gravidade)</label>
                        <span className="font-mono text-blue-400">{branchDroop.toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min="-1.0"
                        max="1.0"
                        step="0.05"
                        value={branchDroop}
                        onChange={(e) => setBranchDroop(parseFloat(e.target.value))}
                        className="w-full accent-blue-500"
                      />
                      <span className="text-[10px] text-[#697587]">
                        Negativo: galhos caídos (salgueiro). Positivo: apontando para cima (pinheiro).
                      </span>
                    </div>
                  </div>

                  <div className="border-t border-[#232a3a] pt-4">
                    <label className="flex items-center gap-2 text-[#c4cfdf] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={subBranching}
                        onChange={(e) => setSubBranching(e.target.checked)}
                        className="rounded border-[#2c3447] bg-[#1a1f2b] text-blue-500 focus:ring-0"
                      />
                      <div>
                        <span className="font-medium">Ativar Sub-ramificação (Secondary Twig Splits)</span>
                        <p className="text-[10px] text-[#697587]">
                          Cria ramificações finas secundárias nas extremidades dos galhos principais.
                        </p>
                      </div>
                    </label>
                  </div>
                </div>
              )}

              {/* TAB 3: LEAVES & FOLIAGE */}
              {activeTab === 'leaves' && (
                <div className="space-y-4">
                  <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg">
                    <h3 className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
                      <Trees className="w-4 h-4 text-emerald-400" />
                      Folhas e Copa (Leaves & Foliage Cards)
                    </h3>
                    <p className="text-[11px] text-[#788496]">
                      Configuração de planos de folhas com recorte alfa, tamanho e densidade de cobertura.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[#c4cfdf] font-medium mb-1 block">Estilo de Folhagem</label>
                      <select
                        value={foliageStyle}
                        onChange={(e) => setFoliageStyle(e.target.value as FoliageStyle)}
                        className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs focus:outline-none focus:border-emerald-500"
                      >
                        <option value="cards">Cross Quads (Cartões Cruzados Alpha)</option>
                        <option value="clusters">Volumetric Puffs (Moitas Esféricas)</option>
                        <option value="fronds">Tropical Fronds (Palmas Grandes)</option>
                        <option value="needles">Pine Needles (Agulhas de Conífera)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[#c4cfdf] font-medium mb-1 block">Textura da Folhagem</label>
                      <select
                        value={leafTexture}
                        onChange={(e) => setLeafTexture(e.target.value)}
                        className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs focus:outline-none focus:border-emerald-500"
                      >
                        <option value="Broadleaf_Oak_Green">Oak Green Leaves (Carvalho)</option>
                        <option value="Pine_Needles_Dark">Dark Pine Needles (Pinheiro)</option>
                        <option value="Palm_Frond_Large">Palm Frond (Palmeira)</option>
                        <option value="Birch_Leaves_Light">Light Birch Leaves (Bétula Clara)</option>
                        <option value="Maple_Autumn_Orange">Autumn Maple (Laranja Outonal)</option>
                        <option value="Cherry_Blossom_Pink">Cherry Blossom (Sakura Rosa)</option>
                      </select>
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Leaf Size (Tamanho da Folha)</label>
                        <span className="font-mono text-emerald-400">{leafSize.toFixed(2)}m</span>
                      </div>
                      <input
                        type="range"
                        min="0.0"
                        max="2.5"
                        step="0.05"
                        value={leafSize}
                        onChange={(e) => setLeafSize(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Leaf Density (Densidade da Copa)</label>
                        <span className="font-mono text-emerald-400">{leafDensity}</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        step="2"
                        value={leafDensity}
                        onChange={(e) => setLeafDensity(parseInt(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                      <span className="text-[10px] text-[#697587]">
                        Defina 0 para árvores mortas/secas sem folhas.
                      </span>
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Leaf Rotation Randomness</label>
                        <span className="font-mono text-emerald-400">{(leafRandomAngle * 100).toFixed(0)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0.0"
                        max="1.0"
                        step="0.05"
                        value={leafRandomAngle}
                        onChange={(e) => setLeafRandomAngle(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="text-[#c4cfdf] font-medium mb-1 block">Cor da Folhagem (Leaf Tint)</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={leafColor}
                          onChange={(e) => setLeafColor(e.target.value)}
                          className="w-8 h-8 rounded border border-[#2b3345] bg-transparent cursor-pointer p-0.5"
                        />
                        <input
                          type="text"
                          value={leafColor}
                          onChange={(e) => setLeafColor(e.target.value)}
                          className="flex-1 bg-[#1b202c] border border-[#2c3447] rounded px-2.5 py-1.5 text-white font-mono text-xs uppercase"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-[#232a3a] pt-3 flex items-center justify-between">
                    <span className="text-[11px] text-[#8695a8]">
                      ✔ Alpha Cutout habilitado (sem artefatos de ordenação de transparência)
                    </span>
                    <span className="text-[11px] text-[#8695a8]">
                      ✔ Double-Sided Rendering ativado
                    </span>
                  </div>
                </div>
              )}

              {/* TAB 4: WIND & LOD */}
              {activeTab === 'wind_lod' && (
                <div className="space-y-4">
                  <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg">
                    <h3 className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
                      <Wind className="w-4 h-4 text-cyan-400" />
                      Animação de Vento em Tempo Real (CopperCube Animated Mesh)
                    </h3>
                    <p className="text-[11px] text-[#788496]">
                      O CopperCube suporta movimento automático de folhas e galhos por vento com parâmetros na raiz.
                    </p>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-[#181d29] border border-[#262f40] rounded-lg">
                    <div>
                      <div className="font-medium text-white flex items-center gap-2">
                        <Wind className="w-4 h-4 text-cyan-400" />
                        <span>Ativar Animação Procedural de Vento</span>
                      </div>
                      <p className="text-[10px] text-[#7c889a] mt-0.5">
                        Aplica shader vertex displacement oscilatório nos galhos e folhas
                      </p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={windEnabled}
                        onChange={(e) => setWindEnabled(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-[#252c3c] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500"></div>
                    </label>
                  </div>

                  {windEnabled && (
                    <div className="grid grid-cols-2 gap-4 pt-2">
                      <div>
                        <div className="flex justify-between mb-1">
                          <label className="text-[#c4cfdf] font-medium">Wind Sway Strength (Força do Balanço)</label>
                          <span className="font-mono text-cyan-400">{(windStrength * 100).toFixed(0)}%</span>
                        </div>
                        <input
                          type="range"
                          min="0.05"
                          max="1.0"
                          step="0.05"
                          value={windStrength}
                          onChange={(e) => setWindStrength(parseFloat(e.target.value))}
                          className="w-full accent-cyan-500"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between mb-1">
                          <label className="text-[#c4cfdf] font-medium">Wind Frequency (Velocidade do Vento)</label>
                          <span className="font-mono text-cyan-400">{windFrequency.toFixed(1)} Hz</span>
                        </div>
                        <input
                          type="range"
                          min="0.3"
                          max="3.0"
                          step="0.1"
                          value={windFrequency}
                          onChange={(e) => setWindFrequency(parseFloat(e.target.value))}
                          className="w-full accent-cyan-500"
                        />
                      </div>

                      <div className="col-span-2">
                        <div className="flex justify-between mb-1">
                          <label className="text-[#c4cfdf] font-medium">Leaf Flutter (Tremulação das Folhas)</label>
                          <span className="font-mono text-cyan-400">{(leafFlutter * 100).toFixed(0)}%</span>
                        </div>
                        <input
                          type="range"
                          min="0.0"
                          max="1.0"
                          step="0.05"
                          value={leafFlutter}
                          onChange={(e) => setLeafFlutter(parseFloat(e.target.value))}
                          className="w-full accent-cyan-500"
                        />
                      </div>
                    </div>
                  )}

                  {/* Seed and Randomizer */}
                  <div className="border-t border-[#232a3a] pt-4 space-y-3">
                    <h4 className="text-white font-medium flex items-center gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      Semente de Variação (Random Seed)
                    </h4>
                    <div className="flex items-center gap-3">
                      <div className="flex-1 bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 flex items-center justify-between">
                        <span className="text-[#7f8da0] text-xs">Seed ID:</span>
                        <span className="font-mono text-white text-xs font-semibold">{randomSeed}</span>
                      </div>
                      <button
                        onClick={randomizeSeed}
                        className="px-3 py-1.5 bg-[#212735] hover:bg-[#2b3346] border border-[#303a4e] text-white rounded text-xs flex items-center gap-1.5 transition-colors"
                      >
                        <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
                        <span>Sortear Variação</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Live 3D / 2.5D Real-Time Preview Canvas */}
          <div className="w-[42%] flex flex-col bg-[#11141c]">
            {/* Canvas Header Toolbar */}
            <div className="px-3.5 py-2 bg-[#141822] border-b border-[#212737] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Eye className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-xs font-medium text-white">Preview 3D Interativo</span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setAnimateWindPreview(!animateWindPreview)}
                  className={`px-2 py-0.5 text-[11px] rounded flex items-center gap-1 transition-colors ${
                    animateWindPreview
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                      : 'bg-[#1b202c] text-[#7c889a] border border-[#2a3244]'
                  }`}
                  title="Alternar simulação de vento em tempo real no preview"
                >
                  <Wind className="w-3 h-3" />
                  <span>Vento</span>
                </button>

                <button
                  onClick={() => setWireframeMode(!wireframeMode)}
                  className={`px-2 py-0.5 text-[11px] rounded flex items-center gap-1 transition-colors ${
                    wireframeMode
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-[#1b202c] text-[#7c889a] border border-[#2a3244]'
                  }`}
                  title="Alternar visualização em arame (wireframe)"
                >
                  <span>Wireframe</span>
                </button>
              </div>
            </div>

            {/* Interactive Canvas */}
            <div className="flex-1 relative flex items-center justify-center p-2 bg-[#0e1117] overflow-hidden">
              <canvas
                ref={canvasRef}
                width={360}
                height={400}
                className="w-full h-full max-h-[440px] object-contain rounded-md"
              />

              {/* Angle rotation slider overlay */}
              <div className="absolute bottom-3 left-3 right-3 bg-[#161a25]/90 border border-[#262e40] rounded-lg px-3 py-1.5 flex items-center gap-2 backdrop-blur-sm">
                <Compass className="w-3.5 h-3.5 text-[#738297] shrink-0" />
                <span className="text-[10px] text-[#738297] shrink-0">Rotação:</span>
                <input
                  type="range"
                  min="-180"
                  max="180"
                  value={previewRotation}
                  onChange={(e) => setPreviewRotation(parseInt(e.target.value))}
                  className="flex-1 accent-emerald-500 h-1.5"
                />
                <button
                  onClick={() => setPreviewRotation(0)}
                  className="text-[10px] text-[#8695a8] hover:text-white px-1.5 py-0.5 rounded bg-[#202636]"
                >
                  0°
                </button>
              </div>
            </div>

            {/* Mesh Statistics Readout */}
            <div className="p-3 bg-[#141822] border-t border-[#212737] space-y-2 shrink-0">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-[#728094] uppercase tracking-wider font-semibold">Estatísticas da Malha</span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-[#1c2230] text-emerald-400 border border-[#293246]">
                  Game Ready
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-[#181d29] px-2.5 py-1.5 rounded border border-[#242c3d] flex justify-between items-center">
                  <span className="text-[#8492a5]">Triângulos:</span>
                  <span className="font-mono text-white font-medium">~{estimatedStats.triangles.toLocaleString()}</span>
                </div>
                <div className="bg-[#181d29] px-2.5 py-1.5 rounded border border-[#242c3d] flex justify-between items-center">
                  <span className="text-[#8492a5]">Vértices:</span>
                  <span className="font-mono text-white font-medium">~{estimatedStats.vertices.toLocaleString()}</span>
                </div>
                <div className="bg-[#181d29] px-2.5 py-1.5 rounded border border-[#242c3d] flex justify-between items-center">
                  <span className="text-[#8492a5]">Materiais:</span>
                  <span className="font-mono text-white font-medium">{estimatedStats.materials} (Bark + Leaves)</span>
                </div>
                <div className="bg-[#181d29] px-2.5 py-1.5 rounded border border-[#242c3d] flex justify-between items-center">
                  <span className="text-[#8492a5]">Memória GPU:</span>
                  <span className="font-mono text-white font-medium">~{estimatedStats.estimatedMemoryKb} KB</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-[#13161f] border-t border-[#232938] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setIsTreeEditorOpen(false);
                setIsTerrainEditorOpen(true);
              }}
              className="px-3 py-1.5 text-xs text-[#a0aebf] hover:text-white bg-[#1b202c] hover:bg-[#252c3c] border border-[#2a3346] rounded-lg flex items-center gap-1.5 transition-colors"
              title="Abrir editor de terreno para distribuir vegetação"
            >
              <Mountain className="w-3.5 h-3.5 text-emerald-400" />
              <span>Distribuir no Terreno...</span>
            </button>

            <button
              onClick={() => applyPreset(selectedPreset)}
              className="px-2.5 py-1.5 text-xs text-[#7d8c9e] hover:text-[#d3dce9] transition-colors"
            >
              Restaurar Padrões
            </button>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setIsTreeEditorOpen(false)}
              className="px-4 py-1.5 text-xs font-medium text-[#92a1b5] hover:text-white hover:bg-[#202636] border border-transparent hover:border-[#2f384a] rounded-lg transition-colors"
            >
              Cancelar
            </button>

            <button
              onClick={handleInsertTree}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-lg shadow-emerald-950 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Trees className="w-4 h-4" />
              <span>Inserir Árvore na Cena</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
