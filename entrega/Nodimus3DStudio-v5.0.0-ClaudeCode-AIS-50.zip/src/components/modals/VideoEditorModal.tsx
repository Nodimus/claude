import React, { useState, useEffect, useRef, useMemo } from 'react';
import { patchNodeMaterial } from '../../core/material/nodeMaterial';
import { buildVideoScreenSpec } from '../../core/fileSystem/videoScreen';
import { useEditor } from '../../core/EditorContext';
import {
  VideoClipSettings,
  DEFAULT_VIDEO_SETTINGS,
  VideoScreenShape,
} from '../../types/video';
import { VideoPreviewCanvas } from './VideoPreviewCanvas';
import {
  PROCEDURAL_VIDEO_PRESETS,
  ProceduralVideoSource,
} from '../../utils/videoTextureHelper';
import {
  Film,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Sliders,
  Sparkles,
  Download,
  Upload,
  Tv,
  Check,
  Plus,
  Layers,
  Scissors,
  Sun,
  Monitor,
  Eye,
  X,
  FastForward,
  Rewind,
  Globe,
} from 'lucide-react';

export const VideoEditorModal: React.FC = () => {
  const {
    isVideoEditorOpen,
    setIsVideoEditorOpen,
    activeScene,
    selectedNodeId,
    selectedNode,
    updateNodeProperties,
    addNode,
    createFile,
    addLog,
  } = useEditor();

  // Video Settings state
  const [settings, setSettings] = useState<VideoClipSettings>(() => {
    if (selectedNode && selectedNode.properties.videoSettings) {
      return { ...DEFAULT_VIDEO_SETTINGS, ...selectedNode.properties.videoSettings };
    }
    return { ...DEFAULT_VIDEO_SETTINGS };
  });

  // Editor Tabs
  const [activeTab, setActiveTab] = useState<'source' | 'timeline' | 'filters' | 'screen'>('source');

  // Video playback & stream engine state
  const [selectedPresetId, setSelectedPresetId] = useState<string>('cyberpunk_synthwave');
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(12);
  const [customUrlInput, setCustomUrlInput] = useState<string>('');
  const [savePresetSuccess, setSavePresetSuccess] = useState<boolean>(false);
  const [applyNodeSuccess, setApplyNodeSuccess] = useState<boolean>(false);

  // 3D Preview environment settings
  const [lightingPreset, setLightingPreset] = useState<'DarkCinema' | 'CyberpunkNeon' | 'StudioBright' | 'OutdoorDay'>('DarkCinema');
  const [autoRotate, setAutoRotate] = useState<boolean>(false);
  const [showWireframe, setShowWireframe] = useState<boolean>(false);
  const [showGrid, setShowGrid] = useState<boolean>(true);

  // HTML5 Video & Canvas references
  const videoElementRef = useRef<HTMLVideoElement | null>(null);
  const proceduralCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const displayCanvas2DRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [textureSource, setTextureSource] = useState<HTMLVideoElement | HTMLCanvasElement | null>(null);

  // Procedural Animation ticker reference
  const animationFrameRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(performance.now());

  // Initialize and run video/procedural render loop
  useEffect(() => {
    if (!isVideoEditorOpen) return;

    // Create offscreen procedural canvas
    const pCanvas = document.createElement('canvas');
    pCanvas.width = 960;
    pCanvas.height = 540;
    proceduralCanvasRef.current = pCanvas;

    // If using procedural preset
    if (!settings.url) {
      setTextureSource(pCanvas);
    }

    const currentPreset = PROCEDURAL_VIDEO_PRESETS.find((p) => p.id === selectedPresetId) || PROCEDURAL_VIDEO_PRESETS[0];
    setDuration(currentPreset.duration);

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [isVideoEditorOpen, selectedPresetId]);

  // Main tick for procedural video generator
  useEffect(() => {
    if (!isVideoEditorOpen) return;

    const renderLoop = (timestamp: number) => {
      const dt = (timestamp - lastTimeRef.current) / 1000;
      lastTimeRef.current = timestamp;

      // If procedural source is active
      if (!settings.url && proceduralCanvasRef.current) {
        const pCanvas = proceduralCanvasRef.current;
        const ctx = pCanvas.getContext('2d');
        const currentPreset = PROCEDURAL_VIDEO_PRESETS.find((p) => p.id === selectedPresetId) || PROCEDURAL_VIDEO_PRESETS[0];

        if (ctx) {
          // Progress time if playing
          if (isPlaying) {
            setCurrentTime((prev) => {
              let next = prev + dt * settings.playbackRate;
              if (next > settings.trimEnd || next > currentPreset.duration) {
                if (settings.loop) {
                  return settings.trimStart;
                } else {
                  setIsPlaying(false);
                  return settings.trimEnd;
                }
              }
              return next;
            });
          }

          // Render procedural frame
          currentPreset.renderFrame(ctx, pCanvas.width, pCanvas.height, currentTime, settings.filters);

          // Copy to 2D UI display canvas with CSS filters
          if (displayCanvas2DRef.current) {
            const dispCtx = displayCanvas2DRef.current.getContext('2d');
            if (dispCtx) {
              dispCtx.clearRect(0, 0, displayCanvas2DRef.current.width, displayCanvas2DRef.current.height);
              dispCtx.drawImage(
                pCanvas,
                0,
                0,
                displayCanvas2DRef.current.width,
                displayCanvas2DRef.current.height
              );

              // Draw scanlines if enabled
              if (settings.filters.scanlines) {
                dispCtx.fillStyle = 'rgba(0, 0, 0, 0.28)';
                for (let y = 0; y < displayCanvas2DRef.current.height; y += 3) {
                  dispCtx.fillRect(0, y, displayCanvas2DRef.current.width, 1);
                }
              }
            }
          }
        }
      }

      animationFrameRef.current = requestAnimationFrame(renderLoop);
    };

    lastTimeRef.current = performance.now();
    animationFrameRef.current = requestAnimationFrame(renderLoop);

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [isVideoEditorOpen, settings.url, selectedPresetId, isPlaying, currentTime, settings.playbackRate, settings.loop, settings.trimStart, settings.trimEnd, settings.filters]);

  // Video element event listeners
  const onVideoLoadedMetadata = () => {
    if (!videoElementRef.current) return;
    const v = videoElementRef.current;
    const dur = v.duration || 10;
    setDuration(dur);
    setSettings((prev) => ({
      ...prev,
      duration: dur,
      trimEnd: dur,
    }));
  };

  const onVideoTimeUpdate = () => {
    if (!videoElementRef.current) return;
    const v = videoElementRef.current;
    setCurrentTime(v.currentTime);

    // Enforce trim out / loop
    if (v.currentTime >= settings.trimEnd) {
      if (settings.loop) {
        v.currentTime = settings.trimStart;
        v.play().catch(() => {});
      } else {
        v.pause();
        setIsPlaying(false);
      }
    }
  };

  // Play/Pause toggle
  const togglePlayPause = () => {
    if (settings.url && videoElementRef.current) {
      const v = videoElementRef.current;
      if (isPlaying) {
        v.pause();
        setIsPlaying(false);
      } else {
        if (v.currentTime >= settings.trimEnd) {
          v.currentTime = settings.trimStart;
        }
        v.play().catch(() => {});
        setIsPlaying(true);
      }
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  // Seek handler
  const handleSeek = (time: number) => {
    const clamped = Math.max(settings.trimStart, Math.min(settings.trimEnd, time));
    setCurrentTime(clamped);
    if (settings.url && videoElementRef.current) {
      videoElementRef.current.currentTime = clamped;
    }
  };

  // Step frame (-1 or +1 frame, assuming 30fps)
  const stepFrame = (frames: number) => {
    const frameTime = 1 / 30;
    handleSeek(currentTime + frames * frameTime);
  };

  // Handle local video file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const objectUrl = URL.createObjectURL(file);
    setSettings((prev) => ({
      ...prev,
      url: objectUrl,
      name: file.name.replace(/\.[^/.]+$/, ''),
    }));

    if (videoElementRef.current) {
      videoElementRef.current.src = objectUrl;
      videoElementRef.current.load();
      videoElementRef.current.play().catch(() => {});
      setTextureSource(videoElementRef.current);
      setIsPlaying(true);
    }
    addLog('log', `Vídeo local carregado: ${file.name}`);
  };

  // Handle preset selection
  const selectPreset = (preset: ProceduralVideoSource) => {
    setSelectedPresetId(preset.id);
    setSettings((prev) => ({
      ...prev,
      url: '',
      name: preset.name,
      duration: preset.duration,
      trimStart: 0,
      trimEnd: preset.duration,
    }));
    setCurrentTime(0);
    setDuration(preset.duration);
    if (proceduralCanvasRef.current) {
      setTextureSource(proceduralCanvasRef.current);
    }
    setIsPlaying(true);
  };

  // Handle custom URL load
  const loadCustomUrl = () => {
    if (!customUrlInput.trim()) return;
    const url = customUrlInput.trim();
    setSettings((prev) => ({
      ...prev,
      url,
      name: 'Stream_Web_Video',
    }));

    if (videoElementRef.current) {
      videoElementRef.current.src = url;
      videoElementRef.current.load();
      videoElementRef.current.play().catch((err) => {
        addLog('warn', `Erro ao carregar URL do vídeo (possível restrição de CORS): ${err.message}`);
      });
      setTextureSource(videoElementRef.current);
      setIsPlaying(true);
    }
  };

  // Apply to Selected Node
  const handleApplyToSelectedNode = () => {
    if (!selectedNode) {
      addLog('warn', 'Nenhum nó selecionado para aplicar o vídeo.');
      return;
    }

    // um Command: vídeo + material (emissivo/rugosidade/metal) no `materialOverride` do nó
    updateNodeProperties(selectedNode.id, {
      videoSettings: settings,
      materialOverride: patchNodeMaterial(selectedNode.properties, {
        emissiveIntensity: settings.emissiveIntensity,
        roughness: settings.roughness,
        metalness: settings.metalness,
      }),
    });

    setApplyNodeSuccess(true);
    setTimeout(() => setApplyNodeSuccess(false), 2200);
    addLog('log', `Vídeo '${settings.name}' aplicado ao nó '${selectedNode.name}'`);
  };

  // Create New Video Screen in Scene
  const handleCreateVideoScreenInScene = () => {
    // Criação + propriedades finais num único Command (antes: criar e depois alterar = 2 entradas de Undo)
    // AIS-31: o mesmo nó é criado ao soltar um `.video.json` na cena (`buildVideoScreenSpec`)
    const spec = buildVideoScreenSpec(settings);
    addNode('MeshInstance', null, spec.name, spec.properties);

    addLog('log', `Nova Tela de Vídeo 3D (${settings.shape}) criada na cena!`);
    setApplyNodeSuccess(true);
    setTimeout(() => setApplyNodeSuccess(false), 2200);
  };

  // Save preset to Virtual File System
  const handleSaveToProject = () => {
    const filename = `res://videos/${settings.name.replace(/\s+/g, '_')}.video.json`;
    const content = JSON.stringify(settings, null, 2);
    createFile(filename, content);
    setSavePresetSuccess(true);
    setTimeout(() => setSavePresetSuccess(false), 2200);
    addLog('log', `Preset de vídeo salvo em: ${filename}`);
  };

  // Download Current Snapshot Frame as PNG
  const handleDownloadSnapshot = () => {
    let canvasToSave: HTMLCanvasElement | null = null;
    if (!settings.url && proceduralCanvasRef.current) {
      canvasToSave = proceduralCanvasRef.current;
    } else if (displayCanvas2DRef.current) {
      canvasToSave = displayCanvas2DRef.current;
    }

    if (canvasToSave) {
      const link = document.createElement('a');
      link.download = `${settings.name}_frame_${currentTime.toFixed(2)}s.png`;
      link.href = canvasToSave.toDataURL('image/png');
      link.click();
      addLog('log', `Snapshot do vídeo salvo como PNG!`);
    }
  };

  // Time format helper (MM:SS.ms)
  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 100);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
  };

  // Generate CSS Filter string for 2D canvas
  const cssFilterString = useMemo(() => {
    const f = settings.filters;
    let str = `brightness(${f.brightness}%) contrast(${f.contrast}%) saturate(${f.saturation}%) hue-rotate(${f.hueRotate}deg) grayscale(${f.grayscale}%) sepia(${f.sepia}%)`;
    if (f.invert) str += ' invert(100%)';
    return str;
  }, [settings.filters]);

  if (!isVideoEditorOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-3 select-none">
      {/* Hidden Video element for URL / file playback */}
      <video
        ref={videoElementRef}
        className="hidden"
        crossOrigin="anonymous"
        playsInline
        muted={settings.muted}
        onLoadedMetadata={onVideoLoadedMetadata}
        onTimeUpdate={onVideoTimeUpdate}
      />
      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/mp4,video/webm,video/ogg,video/quicktime"
        className="hidden"
        onChange={handleFileUpload}
      />

      <div className="flex flex-col w-full max-w-7xl h-[92vh] bg-[#121620] border border-[#2b3549] rounded-xl shadow-2xl overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#171d2b] border-b border-[#252f44]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-500/15 border border-blue-500/30 text-blue-400">
              <Film className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-wide">
                  Editor & Preview de Vídeos 3D (Three.js VideoTexture Studio)
                </h2>
                <span className="px-2 py-0.5 text-[11px] font-mono rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  Three.js r128+ VideoTexture
                </span>
              </div>
              <p className="text-xs text-[#8091ad]">
                Trimming, filtros dinâmicos, aspect ratio e projeção em monitores curvos, hologramas e telas 3D
              </p>
            </div>
          </div>

          {/* Quick Header Actions */}
          <div className="flex items-center gap-2">
            {selectedNode && (
              <button
                onClick={handleApplyToSelectedNode}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow transition"
              >
                {applyNodeSuccess ? <Check className="w-3.5 h-3.5" /> : <Layers className="w-3.5 h-3.5" />}
                {applyNodeSuccess ? 'Aplicado com Sucesso!' : `Aplicar em '${selectedNode.name}'`}
              </button>
            )}

            <button
              onClick={handleCreateVideoScreenInScene}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#273550] hover:bg-[#34466a] text-blue-300 hover:text-white text-xs font-medium border border-blue-500/30 transition"
              title="Cria um novo nó de tela na cena 3D com este vídeo"
            >
              <Plus className="w-3.5 h-3.5 text-blue-400" />
              Criar Tela na Cena
            </button>

            <button
              onClick={handleSaveToProject}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#1e2738] hover:bg-[#2b374e] text-[#c2cbdb] text-xs font-medium border border-[#2e3b52] transition"
            >
              {savePresetSuccess ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Download className="w-3.5 h-3.5" />}
              {savePresetSuccess ? 'Salvo em res://videos/' : 'Salvar (.video.json)'}
            </button>

            <button
              onClick={() => setIsVideoEditorOpen(false)}
              className="p-1.5 rounded hover:bg-[#283348] text-[#8091ad] hover:text-white transition ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Content: Split Grid */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
          {/* Left Column: Video Controls & Settings Tabs (7 cols) */}
          <div className="lg:col-span-7 flex flex-col border-r border-[#222a3b] bg-[#141924] overflow-hidden">
            {/* Tab Navigation */}
            <div className="flex items-center border-b border-[#222a3b] bg-[#11151f] px-3 gap-1 overflow-x-auto">
              <button
                onClick={() => setActiveTab('source')}
                className={`flex items-center gap-1.5 px-3 py-2.5 text-xs font-medium border-b-2 transition ${
                  activeTab === 'source'
                    ? 'border-blue-500 text-blue-400 bg-[#171e2c]'
                    : 'border-transparent text-[#7a8ca8] hover:text-[#c2cbdb]'
                }`}
              >
                <Tv className="w-3.5 h-3.5" />
                Fontes & Clipes
              </button>

              <button
                onClick={() => setActiveTab('timeline')}
                className={`flex items-center gap-1.5 px-3 py-2.5 text-xs font-medium border-b-2 transition ${
                  activeTab === 'timeline'
                    ? 'border-blue-500 text-blue-400 bg-[#171e2c]'
                    : 'border-transparent text-[#7a8ca8] hover:text-[#c2cbdb]'
                }`}
              >
                <Film className="w-3.5 h-3.5" />
                Linha do Tempo & Corte
              </button>

              <button
                onClick={() => setActiveTab('screen')}
                className={`flex items-center gap-1.5 px-3 py-2.5 text-xs font-medium border-b-2 transition ${
                  activeTab === 'screen'
                    ? 'border-blue-500 text-blue-400 bg-[#171e2c]'
                    : 'border-transparent text-[#7a8ca8] hover:text-[#c2cbdb]'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                Tela 3D & PBR
              </button>

              <button
                onClick={() => setActiveTab('filters')}
                className={`flex items-center gap-1.5 px-3 py-2.5 text-xs font-medium border-b-2 transition ${
                  activeTab === 'filters'
                    ? 'border-blue-500 text-blue-400 bg-[#171e2c]'
                    : 'border-transparent text-[#7a8ca8] hover:text-[#c2cbdb]'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                Filtros & Shaders 2D
              </button>
            </div>

            {/* Tab Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {/* TAB 1: SOURCES & PRESETS */}
              {activeTab === 'source' && (
                <div className="space-y-4">
                  <div>
                    <h3 className="text-xs font-semibold text-white uppercase tracking-wider mb-2 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                      Loops Procedurais (100% Offline & Sem Restrição de CORS)
                    </h3>
                    <div className="grid grid-cols-2 gap-2.5">
                      {PROCEDURAL_VIDEO_PRESETS.map((preset) => {
                        const isSelected = !settings.url && selectedPresetId === preset.id;
                        return (
                          <div
                            key={preset.id}
                            onClick={() => selectPreset(preset)}
                            className={`p-3 rounded-lg border cursor-pointer transition flex flex-col justify-between ${
                              isSelected
                                ? 'bg-blue-600/15 border-blue-500 text-white shadow-md'
                                : 'bg-[#18202d] border-[#273347] text-[#9db0cc] hover:border-[#3b4b66]'
                            }`}
                          >
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <span className="font-semibold text-xs text-white">{preset.name}</span>
                                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#202b3d] text-blue-300 font-mono">
                                  {preset.category}
                                </span>
                              </div>
                              <p className="text-[11px] text-[#7a8ca7] line-clamp-2">{preset.description}</p>
                            </div>
                            <div className="mt-2.5 flex items-center justify-between text-[10px] text-[#55667e]">
                              <span>Duração: {preset.duration}s</span>
                              {isSelected && <span className="text-emerald-400 font-bold">Ativo no Player</span>}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Upload Local Video */}
                  <div className="p-3 bg-[#18202e] rounded-lg border border-[#273347] space-y-2">
                    <h3 className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                      <Upload className="w-3.5 h-3.5 text-emerald-400" />
                      Carregar Arquivo de Vídeo Local (.mp4, .webm, .mov)
                    </h3>
                    <p className="text-xs text-[#8091ad]">
                      Selecione um arquivo de vídeo do seu computador para utilizar como VideoTexture no Three.js.
                    </p>
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center justify-center gap-2 w-full py-2.5 rounded-lg border-2 border-dashed border-[#34445f] hover:border-blue-500 bg-[#141b27] hover:bg-[#1a2333] text-xs font-medium text-blue-300 transition"
                    >
                      <Upload className="w-4 h-4" />
                      Escolher Vídeo do Computador...
                    </button>
                  </div>

                  {/* Direct HTTPS Video Stream URL */}
                  <div className="p-3 bg-[#18202e] rounded-lg border border-[#273347] space-y-2">
                    <h3 className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                      <Globe className="w-3.5 h-3.5 text-blue-400" />
                      URL Direta de Vídeo (HTTPS MP4 / WebM)
                    </h3>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="https://exemplo.com/meu-video.mp4"
                        value={customUrlInput}
                        onChange={(e) => setCustomUrlInput(e.target.value)}
                        className="flex-1 px-3 py-1.5 bg-[#0e121a] border border-[#293549] rounded text-xs text-white outline-none focus:border-blue-500"
                      />
                      <button
                        onClick={loadCustomUrl}
                        className="px-3 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium transition"
                      >
                        Carregar
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: TIMELINE & TRIM */}
              {activeTab === 'timeline' && (
                <div className="space-y-4">
                  {/* 2D Video Monitor Screen */}
                  <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden border border-[#2b354a] shadow-inner flex items-center justify-center group">
                    <canvas
                      ref={displayCanvas2DRef}
                      width={640}
                      height={360}
                      style={{ filter: cssFilterString }}
                      className="w-full h-full object-contain"
                    />

                    {/* HUD Timecode Overlay */}
                    <div className="absolute top-2 left-2 flex items-center gap-2 bg-black/60 backdrop-blur-sm px-2.5 py-1 rounded text-xs font-mono text-emerald-400 border border-emerald-500/20">
                      <span>{formatTime(currentTime)}</span>
                      <span className="text-[#55667e]">/</span>
                      <span className="text-[#899bb5]">{formatTime(duration)}</span>
                    </div>

                    {/* Quick overlay buttons */}
                    <div className="absolute top-2 right-2 flex items-center gap-1">
                      <button
                        onClick={handleDownloadSnapshot}
                        className="p-1.5 rounded bg-black/60 hover:bg-black/80 text-[#a2b4cc] hover:text-white transition border border-[#33425b]"
                        title="Baixar Quadro Atual (PNG)"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Center Play Button if paused */}
                    {!isPlaying && (
                      <button
                        onClick={togglePlayPause}
                        className="absolute w-14 h-14 rounded-full bg-blue-600/80 hover:bg-blue-600 text-white flex items-center justify-center shadow-xl transition backdrop-blur-sm"
                      >
                        <Play className="w-7 h-7 ml-1" />
                      </button>
                    )}
                  </div>

                  {/* Interactive Timeline & Trim Scrubber */}
                  <div className="p-3 bg-[#18202e] rounded-lg border border-[#28354c] space-y-2">
                    <div className="flex items-center justify-between text-xs text-[#8da0bd]">
                      <div className="flex items-center gap-1 font-mono">
                        <span className="text-white font-semibold">{formatTime(currentTime)}</span>
                        <span>/</span>
                        <span>{formatTime(duration)}</span>
                      </div>
                      <div className="flex items-center gap-3 font-mono text-[11px]">
                        <span>Trim In: <strong className="text-emerald-400">{settings.trimStart.toFixed(1)}s</strong></span>
                        <span>Trim Out: <strong className="text-amber-400">{settings.trimEnd.toFixed(1)}s</strong></span>
                      </div>
                    </div>

                    {/* Timeline Slider Track */}
                    <div className="relative w-full h-8 bg-[#0e121a] rounded flex items-center px-2 cursor-pointer border border-[#222c3f]">
                      {/* Trim active range highlight */}
                      <div
                        className="absolute h-full bg-blue-500/20 border-l-2 border-r-2 border-blue-500 rounded"
                        style={{
                          left: `${(settings.trimStart / duration) * 100}%`,
                          width: `${((settings.trimEnd - settings.trimStart) / duration) * 100}%`,
                        }}
                      />

                      {/* Scrubber slider */}
                      <input
                        type="range"
                        min={0}
                        max={duration}
                        step={0.05}
                        value={currentTime}
                        onChange={(e) => handleSeek(parseFloat(e.target.value))}
                        className="w-full relative z-10 accent-blue-500 cursor-pointer"
                      />
                    </div>

                    {/* Timeline Trimming Controls */}
                    <div className="grid grid-cols-2 gap-3 pt-2">
                      <div className="flex flex-col gap-1">
                        <label className="text-[11px] text-[#8091ad] flex items-center gap-1">
                          <Scissors className="w-3 h-3 text-emerald-400" />
                          Ponto de Início (Trim Start)
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="range"
                            min={0}
                            max={Math.max(0, settings.trimEnd - 0.5)}
                            step={0.1}
                            value={settings.trimStart}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value);
                              setSettings((prev) => ({ ...prev, trimStart: val }));
                              if (currentTime < val) handleSeek(val);
                            }}
                            className="flex-1 accent-emerald-500"
                          />
                          <span className="text-xs font-mono text-emerald-400 w-12 text-right">
                            {settings.trimStart.toFixed(1)}s
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-col gap-1">
                        <label className="text-[11px] text-[#8091ad] flex items-center gap-1">
                          <Scissors className="w-3 h-3 text-amber-400" />
                          Ponto Final (Trim End)
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="range"
                            min={settings.trimStart + 0.5}
                            max={duration}
                            step={0.1}
                            value={settings.trimEnd}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value);
                              setSettings((prev) => ({ ...prev, trimEnd: val }));
                              if (currentTime > val) handleSeek(val);
                            }}
                            className="flex-1 accent-amber-500"
                          />
                          <span className="text-xs font-mono text-amber-400 w-12 text-right">
                            {settings.trimEnd.toFixed(1)}s
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Playback Transport Bar */}
                  <div className="flex items-center justify-between p-2.5 bg-[#161c28] rounded-lg border border-[#252f44]">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleSeek(settings.trimStart)}
                        className="p-1.5 rounded hover:bg-[#242e42] text-[#8da0bd] hover:text-white transition"
                        title="Ir para o Início"
                      >
                        <Rewind className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => stepFrame(-1)}
                        className="px-2 py-1 text-xs rounded hover:bg-[#242e42] text-[#8da0bd] hover:text-white transition font-mono"
                        title="Voltar 1 Quadro (-1/30s)"
                      >
                        -1F
                      </button>
                      <button
                        onClick={togglePlayPause}
                        className="p-2 rounded-md bg-blue-600 hover:bg-blue-500 text-white shadow transition mx-1"
                        title={isPlaying ? 'Pausar (Espaço)' : 'Reproduzir (Espaço)'}
                      >
                        {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                      </button>
                      <button
                        onClick={() => stepFrame(1)}
                        className="px-2 py-1 text-xs rounded hover:bg-[#242e42] text-[#8da0bd] hover:text-white transition font-mono"
                        title="Avançar 1 Quadro (+1/30s)"
                      >
                        +1F
                      </button>
                      <button
                        onClick={() => handleSeek(settings.trimEnd)}
                        className="p-1.5 rounded hover:bg-[#242e42] text-[#8da0bd] hover:text-white transition"
                        title="Ir para o Final"
                      >
                        <FastForward className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Speed & Loop Controls */}
                    <div className="flex items-center gap-3">
                      {/* Playback speed */}
                      <div className="flex items-center gap-1 text-xs text-[#8da0bd]">
                        <span>Velocidade:</span>
                        <select
                          value={settings.playbackRate}
                          onChange={(e) => {
                            const rate = parseFloat(e.target.value);
                            setSettings((prev) => ({ ...prev, playbackRate: rate }));
                            if (videoElementRef.current) videoElementRef.current.playbackRate = rate;
                          }}
                          className="bg-[#1e2638] text-white text-xs rounded px-2 py-1 border border-[#2d3a50] outline-none"
                        >
                          <option value="0.25">0.25x</option>
                          <option value="0.5">0.5x</option>
                          <option value="0.75">0.75x</option>
                          <option value="1">1.0x (Normal)</option>
                          <option value="1.25">1.25x</option>
                          <option value="1.5">1.5x</option>
                          <option value="2">2.0x</option>
                        </select>
                      </div>

                      {/* Loop toggle */}
                      <button
                        onClick={() => setSettings((prev) => ({ ...prev, loop: !prev.loop }))}
                        className={`flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition ${
                          settings.loop
                            ? 'bg-blue-600/20 border-blue-500/50 text-blue-300 font-semibold'
                            : 'bg-[#1e2638] border-[#2c374d] text-[#7d8fa9]'
                        }`}
                      >
                        <RotateCcw className="w-3 h-3" />
                        Loop
                      </button>

                      {/* Audio Mute toggle */}
                      <button
                        onClick={() => {
                          const nextMute = !settings.muted;
                          setSettings((prev) => ({ ...prev, muted: nextMute }));
                          if (videoElementRef.current) videoElementRef.current.muted = nextMute;
                        }}
                        className={`p-1.5 rounded border transition ${
                          settings.muted
                            ? 'bg-[#1e2638] border-[#2c374d] text-[#7d8fa9]'
                            : 'bg-emerald-600/20 border-emerald-500/50 text-emerald-300'
                        }`}
                        title={settings.muted ? 'Desmutar áudio' : 'Mutar áudio'}
                      >
                        {settings.muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: 3D SCREEN & PBR PROPERTIES */}
              {activeTab === 'screen' && (
                <div className="space-y-4">
                  {/* Screen Geometry Shape Selection */}
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                      <Monitor className="w-3.5 h-3.5 text-blue-400" />
                      Modelo da Tela 3D (Screen Shape)
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { id: 'CurvedScreen', label: 'Cinema Curvo', desc: 'Tela curva côncava com moldura' },
                        { id: 'FlatDisplay', label: 'Monitor OLED', desc: 'Tela plana com suporte' },
                        { id: 'HologramBillboard', label: 'Holograma', desc: 'Flutuante com emissores de luz' },
                        { id: 'Sphere360', label: 'Domo 360° VR', desc: 'Esfera imersiva invertida' },
                        { id: 'Cube', label: 'Cubo 3D', desc: 'Display em caixa de vídeo' },
                        { id: 'Cylinder', label: 'Coluna Kiosk', desc: 'Cilindro cyberpunk vertical' },
                        { id: 'SelectedMesh', label: 'Nó Selecionado', desc: 'Aplica na malha da cena' },
                      ].map((item) => (
                        <button
                          key={item.id}
                          onClick={() => setSettings((prev) => ({ ...prev, shape: item.id as VideoScreenShape }))}
                          className={`p-2.5 rounded-lg border text-left transition ${
                            settings.shape === item.id
                              ? 'bg-blue-600/20 border-blue-500 text-white shadow-sm'
                              : 'bg-[#18202e] border-[#273347] text-[#8da0bd] hover:border-[#384863]'
                          }`}
                        >
                          <div className="font-semibold text-xs text-white">{item.label}</div>
                          <div className="text-[10px] text-[#6b7d99] mt-0.5">{item.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Aspect Ratio Selection */}
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-white uppercase tracking-wider">
                      Proporção de Tela (Aspect Ratio)
                    </label>
                    <div className="grid grid-cols-5 gap-2">
                      {(['16:9', '21:9', '4:3', '1:1', '9:16'] as const).map((ratio) => (
                        <button
                          key={ratio}
                          onClick={() => setSettings((prev) => ({ ...prev, aspectRatio: ratio }))}
                          className={`py-2 text-xs font-medium rounded border transition ${
                            settings.aspectRatio === ratio
                              ? 'bg-blue-600 text-white border-blue-500 font-bold'
                              : 'bg-[#18202e] text-[#8da0bd] border-[#273347] hover:border-[#384863]'
                          }`}
                        >
                          {ratio}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* PBR Material & Glow Parameters */}
                  <div className="p-3 bg-[#18202e] rounded-lg border border-[#273347] space-y-3">
                    <h3 className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                      <Sun className="w-3.5 h-3.5 text-amber-400" />
                      Propriedades de Iluminação & Brilho PBR
                    </h3>

                    {/* Emissive Glow Intensity */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#a4b5cf]">Intensidade Emissiva (Glow na Cena):</span>
                        <span className="font-mono text-amber-400 font-semibold">{settings.emissiveIntensity.toFixed(2)}x</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={2.5}
                        step={0.05}
                        value={settings.emissiveIntensity}
                        onChange={(e) => setSettings((prev) => ({ ...prev, emissiveIntensity: parseFloat(e.target.value) }))}
                        className="w-full accent-amber-500"
                      />
                    </div>

                    {/* Roughness */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#a4b5cf]">Rugosidade (Roughness):</span>
                        <span className="font-mono text-blue-400 font-semibold">{settings.roughness.toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.02}
                        value={settings.roughness}
                        onChange={(e) => setSettings((prev) => ({ ...prev, roughness: parseFloat(e.target.value) }))}
                        className="w-full accent-blue-500"
                      />
                    </div>

                    {/* Metalness */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#a4b5cf]">Metalicidade (Metalness):</span>
                        <span className="font-mono text-purple-400 font-semibold">{settings.metalness.toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.02}
                        value={settings.metalness}
                        onChange={(e) => setSettings((prev) => ({ ...prev, metalness: parseFloat(e.target.value) }))}
                        className="w-full accent-purple-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: 2D FILTERS & SHADERS */}
              {activeTab === 'filters' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-blue-400" />
                      Grading de Cor & Filtros de Imagem
                    </h3>
                    <button
                      onClick={() =>
                        setSettings((prev) => ({
                          ...prev,
                          filters: {
                            brightness: 100,
                            contrast: 100,
                            saturation: 100,
                            hueRotate: 0,
                            grayscale: 0,
                            invert: false,
                            sepia: 0,
                            scanlines: false,
                          },
                        }))
                      }
                      className="text-[11px] text-blue-400 hover:underline flex items-center gap-1"
                    >
                      <RotateCcw className="w-3 h-3" />
                      Resetar Filtros
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-3 p-3 bg-[#18202e] rounded-lg border border-[#273347]">
                    {/* Brightness */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#9cb0ce]">Brilho:</span>
                        <span className="font-mono text-white">{settings.filters.brightness}%</span>
                      </div>
                      <input
                        type="range"
                        min={50}
                        max={200}
                        value={settings.filters.brightness}
                        onChange={(e) =>
                          setSettings((prev) => ({
                            ...prev,
                            filters: { ...prev.filters, brightness: parseInt(e.target.value) },
                          }))
                        }
                        className="w-full accent-blue-500"
                      />
                    </div>

                    {/* Contrast */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#9cb0ce]">Contraste:</span>
                        <span className="font-mono text-white">{settings.filters.contrast}%</span>
                      </div>
                      <input
                        type="range"
                        min={50}
                        max={200}
                        value={settings.filters.contrast}
                        onChange={(e) =>
                          setSettings((prev) => ({
                            ...prev,
                            filters: { ...prev.filters, contrast: parseInt(e.target.value) },
                          }))
                        }
                        className="w-full accent-blue-500"
                      />
                    </div>

                    {/* Saturation */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#9cb0ce]">Saturação:</span>
                        <span className="font-mono text-white">{settings.filters.saturation}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={200}
                        value={settings.filters.saturation}
                        onChange={(e) =>
                          setSettings((prev) => ({
                            ...prev,
                            filters: { ...prev.filters, saturation: parseInt(e.target.value) },
                          }))
                        }
                        className="w-full accent-blue-500"
                      />
                    </div>

                    {/* Hue Rotation */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#9cb0ce]">Matiz (Hue):</span>
                        <span className="font-mono text-white">{settings.filters.hueRotate}°</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={360}
                        value={settings.filters.hueRotate}
                        onChange={(e) =>
                          setSettings((prev) => ({
                            ...prev,
                            filters: { ...prev.filters, hueRotate: parseInt(e.target.value) },
                          }))
                        }
                        className="w-full accent-purple-500"
                      />
                    </div>

                    {/* Grayscale */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#9cb0ce]">Preto & Branco:</span>
                        <span className="font-mono text-white">{settings.filters.grayscale}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        value={settings.filters.grayscale}
                        onChange={(e) =>
                          setSettings((prev) => ({
                            ...prev,
                            filters: { ...prev.filters, grayscale: parseInt(e.target.value) },
                          }))
                        }
                        className="w-full accent-blue-500"
                      />
                    </div>

                    {/* Sepia */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#9cb0ce]">Sépia:</span>
                        <span className="font-mono text-white">{settings.filters.sepia}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        value={settings.filters.sepia}
                        onChange={(e) =>
                          setSettings((prev) => ({
                            ...prev,
                            filters: { ...prev.filters, sepia: parseInt(e.target.value) },
                          }))
                        }
                        className="w-full accent-amber-500"
                      />
                    </div>
                  </div>

                  {/* Special Effects Toggles */}
                  <div className="grid grid-cols-2 gap-3">
                    <label className="flex items-center gap-2 p-3 bg-[#18202e] rounded-lg border border-[#273347] cursor-pointer hover:border-blue-500 transition">
                      <input
                        type="checkbox"
                        checked={settings.filters.scanlines}
                        onChange={(e) =>
                          setSettings((prev) => ({
                            ...prev,
                            filters: { ...prev.filters, scanlines: e.target.checked },
                          }))
                        }
                        className="w-4 h-4 rounded text-blue-600 focus:ring-0"
                      />
                      <div>
                        <div className="text-xs font-semibold text-white">Linhas CRT (Scanlines)</div>
                        <div className="text-[10px] text-[#6b7d99]">Efeito retro de monitor de tubo</div>
                      </div>
                    </label>

                    <label className="flex items-center gap-2 p-3 bg-[#18202e] rounded-lg border border-[#273347] cursor-pointer hover:border-blue-500 transition">
                      <input
                        type="checkbox"
                        checked={settings.filters.invert}
                        onChange={(e) =>
                          setSettings((prev) => ({
                            ...prev,
                            filters: { ...prev.filters, invert: e.target.checked },
                          }))
                        }
                        className="w-4 h-4 rounded text-blue-600 focus:ring-0"
                      />
                      <div>
                        <div className="text-xs font-semibold text-white">Inverter Cores</div>
                        <div className="text-[10px] text-[#6b7d99]">Negativo de filme digital</div>
                      </div>
                    </label>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Interactive 3D Three.js Viewport (5 cols) */}
          <div className="lg:col-span-5 flex flex-col bg-[#0e1219] p-4 space-y-3 overflow-hidden">
            {/* Viewport Header Controls */}
            <div className="flex items-center justify-between bg-[#151a24] px-3 py-2 rounded-lg border border-[#222a3a]">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-blue-400" />
                <span className="text-xs font-semibold text-white">Preview 3D em Tempo Real</span>
              </div>

              {/* Viewport Toggles */}
              <div className="flex items-center gap-2">
                {/* Lighting Preset Selector */}
                <select
                  value={lightingPreset}
                  onChange={(e) => setLightingPreset(e.target.value as any)}
                  className="bg-[#1e2535] text-xs text-[#c2cbdb] rounded px-2 py-1 border border-[#2c374c] outline-none"
                >
                  <option value="DarkCinema">Cinema Escuro</option>
                  <option value="CyberpunkNeon">Neon Cyberpunk</option>
                  <option value="StudioBright">Estúdio Neutro</option>
                  <option value="OutdoorDay">Dia Claro</option>
                </select>

                {/* Turntable Auto-Rotate */}
                <button
                  onClick={() => setAutoRotate(!autoRotate)}
                  className={`px-2 py-1 text-xs rounded border transition flex items-center gap-1 ${
                    autoRotate
                      ? 'bg-blue-600/20 border-blue-500/50 text-blue-300 font-semibold'
                      : 'bg-[#1c2331] border-[#293447] text-[#7487a3]'
                  }`}
                  title="Girar mesa giratória"
                >
                  <RotateCcw className="w-3 h-3" />
                  Girar
                </button>

                {/* Wireframe */}
                <button
                  onClick={() => setShowWireframe(!showWireframe)}
                  className={`px-2 py-1 text-xs rounded border transition ${
                    showWireframe
                      ? 'bg-blue-600/20 border-blue-500/50 text-blue-300 font-semibold'
                      : 'bg-[#1c2331] border-[#293447] text-[#7487a3]'
                  }`}
                  title="Modo Wireframe"
                >
                  Arames
                </button>

                {/* Grid */}
                <button
                  onClick={() => setShowGrid(!showGrid)}
                  className={`px-2 py-1 text-xs rounded border transition ${
                    showGrid
                      ? 'bg-blue-600/20 border-blue-500/50 text-blue-300 font-semibold'
                      : 'bg-[#1c2331] border-[#293447] text-[#7487a3]'
                  }`}
                  title="Grade do Chão"
                >
                  Grade
                </button>
              </div>
            </div>

            {/* 3D Canvas Element */}
            <div className="flex-1 w-full min-h-[350px] relative">
              <VideoPreviewCanvas
                settings={settings}
                textureSource={textureSource}
                selectedNode={selectedNode}
                lightingPreset={lightingPreset}
                autoRotate={autoRotate}
                showWireframe={showWireframe}
                showGrid={showGrid}
              />
            </div>

            {/* Bottom Status & Info Bar */}
            <div className="flex items-center justify-between text-xs text-[#70819c] bg-[#141923] p-2.5 rounded-lg border border-[#21293a]">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="font-mono text-white font-medium">{settings.name}</span>
                <span className="text-[#49576e]">|</span>
                <span>Forma: <strong className="text-[#9fb0c9]">{settings.shape}</strong></span>
              </div>
              <div className="text-[11px] font-mono text-[#5b6e8a]">
                Three.js VideoTexture Shader
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
