import React, { useState, useEffect } from 'react';
import { useEditor } from '../../core/EditorContext';
import {
  PostProcessingSettings,
  DEFAULT_POST_PROCESSING,
} from '../../types/scene';
import {
  Sparkles,
  X,
  RotateCcw,
  Check,
  Eye,
  Sliders,
  Sun,
  Contrast,
  Palette,
  CircleDot,
  Info,
  ExternalLink,
} from 'lucide-react';

export const PostProcessingModal: React.FC = () => {
  const {
    isPostProcessingOpen,
    setIsPostProcessingOpen,
    activeScene,
    updateScenePostProcessing,
    saveCurrentScene,
  } = useEditor();

  const [activeTab, setActiveTab] = useState<
    'all' | 'bloom' | 'color' | 'blur' | 'vignette'
  >('all');

  const [settings, setSettings] = useState<PostProcessingSettings>(() => {
    return activeScene?.postProcessing
      ? JSON.parse(JSON.stringify(activeScene.postProcessing))
      : JSON.parse(JSON.stringify(DEFAULT_POST_PROCESSING));
  });

  // Keep in sync when modal opens or activeScene changes
  useEffect(() => {
    if (isPostProcessingOpen) {
      setSettings(
        activeScene?.postProcessing
          ? JSON.parse(JSON.stringify(activeScene.postProcessing))
          : JSON.parse(JSON.stringify(DEFAULT_POST_PROCESSING))
      );
    }
  }, [isPostProcessingOpen, activeScene]);

  if (!isPostProcessingOpen) return null;

  const handleApply = () => {
    updateScenePostProcessing(settings);
    saveCurrentScene();
    setIsPostProcessingOpen(false);
  };

  const handleReset = () => {
    setSettings(JSON.parse(JSON.stringify(DEFAULT_POST_PROCESSING)));
  };

  const countActiveEffects = () => {
    let count = 0;
    if (settings.bloom.enabled) count++;
    if (settings.blackAndWhite.enabled) count++;
    if (settings.invert.enabled) count++;
    if (settings.blur.enabled) count++;
    if (settings.colorize.enabled) count++;
    if (settings.vignette.enabled) count++;
    return count;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none">
      <div className="w-[780px] h-[580px] bg-[#1e232f] border border-[#3b475f] rounded-lg shadow-2xl flex flex-col overflow-hidden text-xs text-[#dfe4ec]">
        {/* Header */}
        <div className="h-11 bg-[#171b24] border-b border-[#2c3345] px-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5 font-semibold text-white">
            <div className="p-1 rounded bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[13px]">Post Processing Effects</span>
                <span className="px-1.5 py-0.2 bg-[#2a3244] text-[#8b97a8] rounded text-[10px] font-normal">
                  {countActiveEffects()} active
                </span>
              </div>
              <div className="text-[10px] text-[#8b97a8] font-normal">
                Scene: <span className="text-white">{activeScene?.name}</span> (WebGL & Runtime Post-Effects)
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="https://www.ambiera.com/coppercube/doc/cnt_posteffects.html"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#8b97a8] hover:text-purple-400 p-1 flex items-center gap-1 transition-colors"
              title="Open documentation"
            >
              <Info className="w-3.5 h-3.5" />
              <span className="text-[10px]">Doc</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <button
              onClick={() => setIsPostProcessingOpen(false)}
              className="p-1 text-[#8b97a8] hover:text-white rounded hover:bg-[#2c3345] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar Navigation */}
          <div className="w-44 border-r border-[#2c3345] bg-[#171b24] p-2 space-y-1">
            <button
              onClick={() => setActiveTab('all')}
              className={`w-full text-left px-3 py-2 rounded flex items-center justify-between transition-colors ${
                activeTab === 'all'
                  ? 'bg-[#4982ea] text-white font-medium shadow-sm'
                  : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <span className="flex items-center gap-2">
                <Sliders className="w-3.5 h-3.5" />
                <span>All Effects</span>
              </span>
              <span className="text-[10px] opacity-75">{countActiveEffects()}</span>
            </button>

            <div className="pt-2 pb-1 px-2 text-[10px] font-semibold text-[#68768e] uppercase tracking-wider">
              Effects
            </div>

            <button
              onClick={() => setActiveTab('bloom')}
              className={`w-full text-left px-3 py-1.5 rounded flex items-center justify-between transition-colors ${
                activeTab === 'bloom'
                  ? 'bg-[#4982ea] text-white font-medium'
                  : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <span className="flex items-center gap-2">
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>Bloom</span>
              </span>
              {settings.bloom.enabled && (
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('color')}
              className={`w-full text-left px-3 py-1.5 rounded flex items-center justify-between transition-colors ${
                activeTab === 'color'
                  ? 'bg-[#4982ea] text-white font-medium'
                  : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <span className="flex items-center gap-2">
                <Palette className="w-3.5 h-3.5 text-sky-400" />
                <span>Color & Invert</span>
              </span>
              {(settings.blackAndWhite.enabled || settings.invert.enabled || settings.colorize.enabled) && (
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('blur')}
              className={`w-full text-left px-3 py-1.5 rounded flex items-center justify-between transition-colors ${
                activeTab === 'blur'
                  ? 'bg-[#4982ea] text-white font-medium'
                  : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <span className="flex items-center gap-2">
                <Eye className="w-3.5 h-3.5 text-indigo-400" />
                <span>Blur</span>
              </span>
              {settings.blur.enabled && (
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('vignette')}
              className={`w-full text-left px-3 py-1.5 rounded flex items-center justify-between transition-colors ${
                activeTab === 'vignette'
                  ? 'bg-[#4982ea] text-white font-medium'
                  : 'text-[#8b97a8] hover:text-white hover:bg-[#202531]'
              }`}
            >
              <span className="flex items-center gap-2">
                <CircleDot className="w-3.5 h-3.5 text-purple-400" />
                <span>Vignette</span>
              </span>
              {settings.vignette.enabled && (
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
              )}
            </button>

            <div className="pt-4 px-2">
              <div className="p-2.5 rounded bg-[#13161f] border border-[#2c3345] text-[11px] text-[#7d8ba1] space-y-1">
                <div className="font-semibold text-[#a0aec0] flex items-center gap-1">
                  <Info className="w-3 h-3 text-blue-400" />
                  <span>Engine Notes</span>
                </div>
                <p className="text-[10px] leading-relaxed">
                  Post effects can be enabled, disabled, and configured dynamically during runtime via scripting or scene actions.
                </p>
              </div>
            </div>
          </div>

          {/* Configuration Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#1b202c]">
            {/* 1. Bloom */}
            {(activeTab === 'all' || activeTab === 'bloom') && (
              <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-[#2c3345]">
                  <div className="flex items-center gap-2">
                    <Sun className="w-4 h-4 text-amber-400" />
                    <div>
                      <div className="font-semibold text-white text-[12px]">Bloom</div>
                      <div className="text-[11px] text-[#8b97a8]">
                        Fakes a glow, creating bleeding shiny light on top of bright light sources.
                      </div>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.bloom.enabled}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          bloom: { ...settings.bloom, enabled: e.target.checked },
                        })
                      }
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-[#2c3345] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-[#3b475f] after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#4982ea]"></div>
                  </label>
                </div>

                <div
                  className={`grid grid-cols-2 gap-4 pt-1 transition-opacity ${
                    settings.bloom.enabled ? 'opacity-100' : 'opacity-40 pointer-events-none'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex justify-between text-[#8b97a8]">
                      <span>Bloom_BlurIterations</span>
                      <span className="text-white font-mono">{settings.bloom.blurIterations}</span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={10}
                      step={1}
                      value={settings.bloom.blurIterations}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          bloom: {
                            ...settings.bloom,
                            blurIterations: parseInt(e.target.value) || 1,
                          },
                        })
                      }
                      className="w-full accent-[#4982ea]"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[#8b97a8]">
                      <span>Bloom_Threshold</span>
                      <span className="text-white font-mono">{settings.bloom.threshold.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={settings.bloom.threshold}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          bloom: {
                            ...settings.bloom,
                            threshold: parseFloat(e.target.value) || 0,
                          },
                        })
                      }
                      className="w-full accent-[#4982ea]"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 2. Color Effects (Black & White, Invert, Colorize) */}
            {(activeTab === 'all' || activeTab === 'color') && (
              <div className="space-y-4">
                {/* Black and White & Invert in row */}
                <div className="grid grid-cols-2 gap-3">
                  {/* Black and White */}
                  <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Contrast className="w-4 h-4 text-slate-300" />
                        <div>
                          <div className="font-semibold text-white">Black and White</div>
                          <div className="text-[10px] text-[#8b97a8]">Renders scene in grayscale</div>
                        </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.blackAndWhite.enabled}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              blackAndWhite: { enabled: e.target.checked },
                            })
                          }
                          className="sr-only peer"
                        />
                        <div className="w-8 h-4 bg-[#2c3345] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-[#4982ea]"></div>
                      </label>
                    </div>
                  </div>

                  {/* Invert */}
                  <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Palette className="w-4 h-4 text-emerald-400" />
                        <div>
                          <div className="font-semibold text-white">Invert</div>
                          <div className="text-[10px] text-[#8b97a8]">Inverts colors (e.g. night vision)</div>
                        </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.invert.enabled}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              invert: { enabled: e.target.checked },
                            })
                          }
                          className="sr-only peer"
                        />
                        <div className="w-8 h-4 bg-[#2c3345] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-[#4982ea]"></div>
                      </label>
                    </div>
                  </div>
                </div>

                {/* Colorize */}
                <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-[#2c3345]">
                    <div className="flex items-center gap-2">
                      <Palette className="w-4 h-4 text-pink-400" />
                      <div>
                        <div className="font-semibold text-white text-[12px]">Colorize</div>
                        <div className="text-[11px] text-[#8b97a8]">
                          Colorizes the image by multiplying the color of each pixel with the specified color.
                        </div>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.colorize.enabled}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            colorize: { ...settings.colorize, enabled: e.target.checked },
                          })
                        }
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-[#2c3345] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-[#3b475f] after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#4982ea]"></div>
                    </label>
                  </div>

                  <div
                    className={`flex items-center gap-4 pt-1 transition-opacity ${
                      settings.colorize.enabled ? 'opacity-100' : 'opacity-40 pointer-events-none'
                    }`}
                  >
                    <span className="text-[#8b97a8] whitespace-nowrap">Colorize_Color:</span>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={settings.colorize.color}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            colorize: { ...settings.colorize, color: e.target.value },
                          })
                        }
                        className="w-8 h-8 rounded border border-[#2c3345] bg-transparent cursor-pointer"
                      />
                      <input
                        type="text"
                        value={settings.colorize.color}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            colorize: { ...settings.colorize, color: e.target.value },
                          })
                        }
                        className="w-24 px-2 py-1 bg-[#171b24] border border-[#2c3345] rounded font-mono text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 3. Blur */}
            {(activeTab === 'all' || activeTab === 'blur') && (
              <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-[#2c3345]">
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4 text-indigo-400" />
                    <div>
                      <div className="font-semibold text-white text-[12px]">Blur</div>
                      <div className="text-[11px] text-[#8b97a8]">
                        Blurs the entire image, reducing its sharpness.
                      </div>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.blur.enabled}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          blur: { ...settings.blur, enabled: e.target.checked },
                        })
                      }
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-[#2c3345] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-[#3b475f] after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#4982ea]"></div>
                  </label>
                </div>

                <div
                  className={`pt-1 transition-opacity ${
                    settings.blur.enabled ? 'opacity-100' : 'opacity-40 pointer-events-none'
                  }`}
                >
                  <div className="space-y-1 max-w-sm">
                    <div className="flex justify-between text-[#8b97a8]">
                      <span>Blur_Iterations</span>
                      <span className="text-white font-mono">{settings.blur.iterations}</span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={10}
                      step={1}
                      value={settings.blur.iterations}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          blur: {
                            ...settings.blur,
                            iterations: parseInt(e.target.value) || 1,
                          },
                        })
                      }
                      className="w-full accent-[#4982ea]"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* 4. Vignette */}
            {(activeTab === 'all' || activeTab === 'vignette') && (
              <div className="bg-[#202636] border border-[#2c3345] rounded-lg p-3.5 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-[#2c3345]">
                  <div className="flex items-center gap-2">
                    <CircleDot className="w-4 h-4 text-purple-400" />
                    <div>
                      <div className="font-semibold text-white text-[12px]">Vignette</div>
                      <div className="text-[11px] text-[#8b97a8]">
                        Fades out the borders of the screen for a cinematic look.
                      </div>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.vignette.enabled}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          vignette: { ...settings.vignette, enabled: e.target.checked },
                        })
                      }
                      className="sr-only peer"
                    />
                    <div className="w-9 h-5 bg-[#2c3345] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-[#3b475f] after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#4982ea]"></div>
                  </label>
                </div>

                <div
                  className={`grid grid-cols-3 gap-4 pt-1 transition-opacity ${
                    settings.vignette.enabled ? 'opacity-100' : 'opacity-40 pointer-events-none'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex justify-between text-[#8b97a8]">
                      <span>Vignette_Intensity</span>
                      <span className="text-white font-mono">{settings.vignette.intensity.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={settings.vignette.intensity}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          vignette: {
                            ...settings.vignette,
                            intensity: parseFloat(e.target.value) || 0,
                          },
                        })
                      }
                      className="w-full accent-[#4982ea]"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[#8b97a8]">
                      <span>Vignette_RadiusA</span>
                      <span className="text-white font-mono">{settings.vignette.radiusA.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={settings.vignette.radiusA}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          vignette: {
                            ...settings.vignette,
                            radiusA: parseFloat(e.target.value) || 0,
                          },
                        })
                      }
                      className="w-full accent-[#4982ea]"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[#8b97a8]">
                      <span>Vignette_RadiusB</span>
                      <span className="text-white font-mono">{settings.vignette.radiusB.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={1}
                      step={0.05}
                      value={settings.vignette.radiusB}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          vignette: {
                            ...settings.vignette,
                            radiusB: parseFloat(e.target.value) || 0,
                          },
                        })
                      }
                      className="w-full accent-[#4982ea]"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="h-12 bg-[#171b24] border-t border-[#2c3345] px-4 flex items-center justify-between">
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#8b97a8] hover:text-white transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Defaults</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPostProcessingOpen(false)}
              className="px-3.5 py-1.5 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-[#4982ea] hover:bg-[#3b6ecc] text-white font-medium shadow-md transition-colors"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Apply & Save</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
