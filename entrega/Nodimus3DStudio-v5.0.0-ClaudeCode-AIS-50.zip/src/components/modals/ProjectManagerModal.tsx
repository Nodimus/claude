import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useEditor } from '../../core/EditorContext';
import { ProjectStorage } from '../../core/projectStorage';
import { globalAuthoringModel } from '../../core/authoring';
import { TauriBridge } from '../../core/tauriBridge';
import { PROJECT_TEMPLATES, getProjectTemplate } from '../../core/projectTemplates';
import { importProjectFromFolder } from '../../core/projectFolder';
import {
  DELETE_PROJECT_NOTICE,
  PROJECT_NAME_MAX,
  canDeleteProject,
  deleteConfirmationMatches,
  deleteStoredProject,
  duplicateStoredProject,
  renameStoredProject,
  sortProjectsByRecent,
  uniqueCopyName,
  validateProjectName,
} from '../../core/projectOps';
import {
  FolderOpen,
  Plus,
  Trash2,
  Download,
  Upload,
  Play,
  Box,
  HardDrive,
  X,
  Copy,
  Pencil,
  LayoutTemplate,
  AlertTriangle,
} from 'lucide-react';

type Dialog =
  | { kind: 'new' }
  | { kind: 'clone' }
  | { kind: 'duplicate'; id: string }
  | { kind: 'delete'; id: string };

const TEMPLATE_ICON: Record<string, React.ReactNode> = {
  '3d': <Box className="w-5 h-5 text-blue-400 shrink-0" />,
  empty: <HardDrive className="w-5 h-5 text-slate-400 shrink-0" />,
};

export const ProjectManagerModal: React.FC = () => {
  const {
    isProjectManagerOpen,
    setIsProjectManagerOpen,
    switchProject,
    project: activeProject,
    addLog,
  } = useEditor();

  const [projectsList, setProjectsList] = useState(() => ProjectStorage.getProjectsList());
  const [selectedProjectId, setSelectedProjectId] = useState<string>(activeProject.id);
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Formulário Novo Projeto / Clonar Exemplo / Duplicar
  const [formName, setFormName] = useState('Nodimus 3D Adventure');
  const [formPath, setFormPath] = useState('~/Projects/Nodimus3D');
  const [formTemplate, setFormTemplate] = useState<string>('3d');
  const [formError, setFormError] = useState<string | null>(null);

  // Renomear inline
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [renameError, setRenameError] = useState<string | null>(null);

  // Excluir
  const [deleteTyped, setDeleteTyped] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const capabilities = TauriBridge.getCapabilities();

  const refresh = () => setProjectsList(ProjectStorage.getProjectsList());

  useEffect(() => {
    refresh();
    setError(null);
    setDialog(null);
    setRenamingId(null);
  }, [isProjectManagerOpen]);

  const sortedProjects = useMemo(() => sortProjectsByRecent(projectsList), [projectsList]);

  if (!isProjectManagerOpen) return null;

  const closeDialog = () => {
    setDialog(null);
    setFormError(null);
    setDeleteTyped('');
  };

  const handleOpenSelected = () => {
    const proj = ProjectStorage.loadProject(selectedProjectId);
    if (proj) {
      switchProject(proj);
      setIsProjectManagerOpen(false);
    }
  };

  // ── Renomear (inline) ────────────────────────────────────────────────────────────────────────────
  const startRename = (id: string, name: string) => {
    setRenamingId(id);
    setRenameValue(name);
    setRenameError(null);
  };

  const commitRename = (id: string) => {
    const current = projectsList.find((p) => p.id === id);
    if (!current) return setRenamingId(null);
    if (renameValue.trim() === current.name) return setRenamingId(null);
    const isActive = id === activeProject.id;
    const result = renameStoredProject(id, renameValue, isActive ? globalAuthoringModel.getProject() : undefined);
    if (!result.ok) {
      setRenameError(result.error);
      return;
    }
    // o projeto aberto: a projeção do editor (título) acompanha pelo AuthoringModel
    if (isActive) globalAuthoringModel.setProject(result.value);
    setRenamingId(null);
    setRenameError(null);
    refresh();
    addLog('log', `Projeto renomeado para '${result.value.name}'.`);
  };

  // ── Novo Projeto / Clonar Exemplo ────────────────────────────────────────────────────────────────
  const openNewDialog = (kind: 'new' | 'clone') => {
    setError(null);
    setFormError(null);
    setFormName(kind === 'clone' ? 'Meu Exemplo' : 'Nodimus 3D Adventure');
    setFormPath('~/Projects/Nodimus3D');
    setFormTemplate('3d');
    setDialog({ kind });
  };

  const pickFolderInto = async (setter: (path: string) => void) => {
    try {
      const folder = await TauriBridge.openProjectFolderDialog();
      if (folder) setter(folder);
    } catch (e: any) {
      setFormError(`Não foi possível abrir o seletor de pasta: ${e?.message || 'erro desconhecido'}`);
    }
  };

  const handleCreateProject = () => {
    const template = getProjectTemplate(formTemplate);
    if (!template || !template.available) return;
    const nameError = validateProjectName(formName, projectsList);
    if (nameError) return setFormError(nameError);
    const newProj = template.build(formName.trim(), formPath.trim());
    if (!ProjectStorage.saveProject(newProj)) return setFormError('Não foi possível gravar o projeto (armazenamento cheio?).');
    refresh();
    switchProject(newProj);
    closeDialog();
    setIsProjectManagerOpen(false);
  };

  // ── Duplicar ─────────────────────────────────────────────────────────────────────────────────────
  const openDuplicate = (id: string) => {
    const p = projectsList.find((x) => x.id === id);
    if (!p) return;
    setError(null);
    setFormError(null);
    setFormName(uniqueCopyName(p.name, projectsList.map((x) => x.name)));
    setFormPath(p.location);
    setDialog({ kind: 'duplicate', id });
  };

  const handleDuplicate = () => {
    if (dialog?.kind !== 'duplicate') return;
    const result = duplicateStoredProject(dialog.id, { name: formName, location: formPath });
    if (!result.ok) return setFormError(result.error);
    refresh();
    setSelectedProjectId(result.value.id);
    closeDialog();
    addLog('log', `Projeto duplicado como '${result.value.name}'.`);
  };

  // ── Excluir ──────────────────────────────────────────────────────────────────────────────────────
  const openDelete = (id: string) => {
    setError(null);
    setDeleteTyped('');
    setDialog({ kind: 'delete', id });
  };

  const handleDelete = () => {
    if (dialog?.kind !== 'delete') return;
    const target = projectsList.find((p) => p.id === dialog.id);
    if (!target || !deleteConfirmationMatches(deleteTyped, target.name)) return;
    const result = deleteStoredProject(dialog.id, activeProject.id);
    if (!result.ok) return setError(`Não foi possível excluir: ${result.error}.`);
    const remaining = ProjectStorage.getProjectsList();
    setProjectsList(remaining);
    if (selectedProjectId === dialog.id) setSelectedProjectId(activeProject.id);
    closeDialog();
    addLog('log', `Projeto '${target.name}' removido do armazenamento do editor.`);
  };

  // ── Exportar / Importar / Abrir Pasta ────────────────────────────────────────────────────────────
  const handleExport = async (id: string) => {
    // exporta do armazenamento: funciona para qualquer projeto, não só o aberto
    const proj = ProjectStorage.loadProject(id);
    if (!proj) return;
    try {
      await ProjectStorage.exportProjectAsNodimusFile(proj);
      addLog('log', `Exported project ${proj.name} (.nodimus)`);
    } catch (e: any) {
      addLog('error', `Failed to export project: ${e?.message || 'Unknown error'}`);
    }
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (!file) return;
    setError(null);

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const content = reader.result as string;
        const imported = ProjectStorage.importProjectFromNodimus(content);
        refresh();
        switchProject(imported);
        setIsProjectManagerOpen(false);
        addLog('log', `Imported project: ${imported.name} (.nodimus)`);
      } catch (err: any) {
        setError(`Falha ao importar o arquivo: ${String(err?.message || 'formato inválido').replace(/^\[ProjectStorage\]\s*/, '')}`);
      }
    };
    reader.onerror = () => setError('Falha ao ler o arquivo selecionado.');
    reader.readAsText(file);
  };

  const handleOpenFolder = async () => {
    setError(null);
    try {
      const folder = await TauriBridge.openProjectFolderDialog();
      if (!folder) return;
      const result = await importProjectFromFolder(folder, TauriBridge);
      if (!result.ok) return setError(result.error);
      if (!ProjectStorage.saveProject(result.project)) return setError('Não foi possível gravar o projeto importado (armazenamento cheio?).');
      refresh();
      switchProject(result.project);
      setIsProjectManagerOpen(false);
      addLog('log', `Pasta importada como projeto '${result.project.name}'${result.skipped.length ? ` (${result.skipped.length} arquivo(s) não suportado(s) ignorado(s))` : ''}.`);
    } catch (e: any) {
      setError(`Falha ao abrir a pasta: ${e?.message || 'erro desconhecido'}`);
    }
  };

  const deleteTarget = dialog?.kind === 'delete' ? projectsList.find((p) => p.id === dialog.id) : undefined;

  const renderTemplatePicker = (all: boolean) => {
    const templates = all ? PROJECT_TEMPLATES : PROJECT_TEMPLATES.filter((t) => t.available);
    return (
      <div className={all ? 'grid grid-cols-1 gap-2' : 'grid grid-cols-2 gap-2'}>
        {templates.map((t) => (
          <button
            key={t.id}
            type="button"
            disabled={!t.available}
            title={t.available ? undefined : t.unavailableReason}
            onClick={() => setFormTemplate(t.id)}
            className={`p-2.5 rounded border text-left flex items-center gap-2.5 ${
              !t.available
                ? 'border-[#2c3345] bg-[#141820] text-[#5d6a80] opacity-60 cursor-not-allowed'
                : formTemplate === t.id
                  ? 'border-[#4982ea] bg-[#4982ea]/15 text-white'
                  : 'border-[#2c3345] bg-[#141820] text-[#8b97a8]'
            }`}
          >
            {TEMPLATE_ICON[t.id] ?? <LayoutTemplate className="w-5 h-5 text-slate-500 shrink-0" />}
            <div>
              <div className="font-semibold text-xs text-white">{t.label}</div>
              <div className="text-[10px] text-[#8b97a8]">{t.available ? t.description : 'em breve'}</div>
            </div>
          </button>
        ))}
      </div>
    );
  };

  const renderLocationField = () => (
    <div>
      <label className="text-[#8b97a8] text-[11px] block mb-1 font-medium">Project Path</label>
      <div className="flex items-center gap-2">
        <input
          type="text"
          value={formPath}
          onChange={(e) => setFormPath(e.target.value)}
          className="flex-1 bg-[#141820] text-white font-mono px-3 py-1.5 rounded border border-[#2c3345] outline-none text-[11px]"
        />
        {capabilities.hasNativeDialog && (
          <button
            type="button"
            onClick={() => pickFolderInto(setFormPath)}
            className="px-2.5 py-1.5 rounded bg-[#272e3d] hover:bg-[#323b4e] text-[#dfe4ec] border border-[#2c3345]"
          >
            Escolher…
          </button>
        )}
      </div>
    </div>
  );

  const renderNameField = () => (
    <div>
      <label className="text-[#8b97a8] text-[11px] block mb-1 font-medium">Project Name</label>
      <input
        type="text"
        value={formName}
        maxLength={PROJECT_NAME_MAX}
        onChange={(e) => {
          setFormName(e.target.value);
          setFormError(null);
        }}
        className="w-full bg-[#141820] text-white px-3 py-1.5 rounded border border-[#2c3345] outline-none"
        placeholder="Enter project name..."
      />
    </div>
  );

  const renderFormError = () =>
    formError ? (
      <div role="alert" className="text-[11px] text-rose-400 bg-rose-500/10 border border-rose-500/30 rounded px-2.5 py-1.5">
        {formError}
      </div>
    ) : null;

  const renderFormFooter = (confirmLabel: string, onConfirm: () => void, disabled = false) => (
    <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#2c3345]">
      <button type="button" onClick={closeDialog} className="px-3 py-1.5 rounded hover:bg-[#2c3345] text-[#b3bed0]">
        Cancel
      </button>
      <button
        type="button"
        onClick={onConfirm}
        disabled={disabled}
        className="bg-[#4982ea] hover:bg-[#3d72d6] disabled:opacity-50 disabled:cursor-not-allowed text-white px-4 py-1.5 rounded font-medium transition-colors"
      >
        {confirmLabel}
      </button>
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none">
      <div className="w-[780px] h-[520px] bg-[#1e232f] border border-[#3b475f] rounded-lg shadow-2xl flex flex-col overflow-hidden text-xs">
        {/* Top Header */}
        <div className="h-12 bg-[#171b24] border-b border-[#2c3345] px-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded bg-[#4982ea] flex items-center justify-center font-bold text-xs text-white">
              N
            </div>
            <span className="font-bold text-sm text-white">Nodimus Project Manager</span>
          </div>

          <button
            onClick={() => setIsProjectManagerOpen(false)}
            className="p-1 text-[#8b97a8] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Toolbar */}
        <div className="h-10 bg-[#1a1e29] border-b border-[#2c3345] px-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => openNewDialog('new')}
              className="flex items-center gap-1.5 bg-[#4982ea] hover:bg-[#3d72d6] text-white px-3 py-1 rounded font-medium transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Project</span>
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 bg-[#272e3d] hover:bg-[#323b4e] text-[#dfe4ec] px-3 py-1 rounded border border-[#2c3345] transition-colors"
            >
              <Upload className="w-3.5 h-3.5 text-blue-400" />
              <span>Import</span>
            </button>

            <button
              onClick={() => openNewDialog('clone')}
              className="flex items-center gap-1.5 bg-[#272e3d] hover:bg-[#323b4e] text-[#dfe4ec] px-3 py-1 rounded border border-[#2c3345] transition-colors"
              title="Criar um projeto a partir de um exemplo"
            >
              <LayoutTemplate className="w-3.5 h-3.5 text-blue-400" />
              <span>Clonar Exemplo</span>
            </button>

            <button
              onClick={handleOpenFolder}
              disabled={!capabilities.hasNativeFS}
              title={capabilities.hasNativeFS ? 'Importar uma pasta de projeto (com project.json)' : 'em breve — requer o app desktop (AIS-AP)'}
              className="flex items-center gap-1.5 bg-[#272e3d] hover:bg-[#323b4e] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-[#272e3d] text-[#dfe4ec] px-3 py-1 rounded border border-[#2c3345] transition-colors"
            >
              <FolderOpen className="w-3.5 h-3.5 text-blue-400" />
              <span>Abrir Pasta…</span>
            </button>

            <input
              ref={fileInputRef}
              type="file"
              accept=".nodimus,.nodimus.json,.json"
              className="hidden"
              onChange={handleImportFile}
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleOpenSelected}
              disabled={!selectedProjectId}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white px-4 py-1 rounded font-medium transition-colors"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Open Project</span>
            </button>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 p-4 overflow-y-auto bg-[#141822]">
          {error && (
            <div role="alert" className="mb-3 flex items-start gap-2 text-[11px] text-rose-300 bg-rose-500/10 border border-rose-500/30 rounded px-3 py-2">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              <span className="flex-1 whitespace-pre-wrap break-words">{error}</span>
              <button onClick={() => setError(null)} className="text-rose-300 hover:text-white" aria-label="Fechar aviso">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {dialog?.kind === 'new' || dialog?.kind === 'clone' ? (
            /* New Project / Clonar Exemplo Form */
            <div className="max-w-lg mx-auto bg-[#1c2230] p-5 rounded-lg border border-[#2c3345] space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#2c3345] pb-2">
                {dialog.kind === 'new' ? (
                  <>
                    <Plus className="w-4 h-4 text-[#4982ea]" /> Create New Project
                  </>
                ) : (
                  <>
                    <LayoutTemplate className="w-4 h-4 text-[#4982ea]" /> Clonar Exemplo
                  </>
                )}
              </h3>

              <div className="space-y-3">
                {renderNameField()}
                {renderLocationField()}

                <div>
                  <label className="text-[#8b97a8] text-[11px] block mb-1.5 font-medium">
                    {dialog.kind === 'new' ? 'Starter Template' : 'Exemplo'}
                  </label>
                  {renderTemplatePicker(dialog.kind === 'clone')}
                </div>

                <div>
                  <label className="text-[#8b97a8] text-[11px] block mb-1 font-medium">
                    Graphics Engine
                  </label>
                  <div className="p-2 bg-[#141820] rounded border border-[#2c3345] text-white font-mono text-xs flex items-center justify-between">
                    <span>Three.js (WebGL)</span>
                    <span className="text-[10px] text-emerald-400 font-sans font-medium px-2 py-0.5 rounded bg-emerald-500/10">Default</span>
                  </div>
                </div>
              </div>

              {renderFormError()}
              {renderFormFooter(dialog.kind === 'new' ? 'Create & Open' : 'Clonar & Abrir', handleCreateProject)}
            </div>
          ) : dialog?.kind === 'duplicate' ? (
            <div className="max-w-lg mx-auto bg-[#1c2230] p-5 rounded-lg border border-[#2c3345] space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#2c3345] pb-2">
                <Copy className="w-4 h-4 text-[#4982ea]" /> Duplicar Projeto
              </h3>
              <div className="space-y-3">
                {renderNameField()}
                {renderLocationField()}
              </div>
              {renderFormError()}
              {renderFormFooter('Duplicar', handleDuplicate)}
            </div>
          ) : dialog?.kind === 'delete' && deleteTarget ? (
            <div className="max-w-lg mx-auto bg-[#1c2230] p-5 rounded-lg border border-rose-500/40 space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#2c3345] pb-2">
                <Trash2 className="w-4 h-4 text-rose-400" /> Excluir Projeto
              </h3>
              <p className="text-[#b3bed0] leading-relaxed">
                Para excluir <span className="font-semibold text-white">{deleteTarget.name}</span>, digite o nome exato do projeto:
              </p>
              <input
                autoFocus
                type="text"
                value={deleteTyped}
                onChange={(e) => setDeleteTyped(e.target.value)}
                aria-label="Digite o nome do projeto para confirmar"
                className="w-full bg-[#141820] text-white px-3 py-1.5 rounded border border-[#2c3345] outline-none"
                placeholder={deleteTarget.name}
              />
              <p className="text-[11px] text-[#8b97a8] leading-relaxed" title={DELETE_PROJECT_NOTICE}>
                {DELETE_PROJECT_NOTICE}
              </p>
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#2c3345]">
                <button type="button" onClick={closeDialog} className="px-3 py-1.5 rounded hover:bg-[#2c3345] text-[#b3bed0]">
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDelete}
                  disabled={!deleteConfirmationMatches(deleteTyped, deleteTarget.name)}
                  className="bg-rose-600 hover:bg-rose-500 disabled:opacity-40 disabled:cursor-not-allowed text-white px-4 py-1.5 rounded font-medium transition-colors"
                >
                  Excluir
                </button>
              </div>
            </div>
          ) : (
            /* Projects Grid / Table */
            <div className="space-y-2">
              {sortedProjects.map((p) => {
                const isSelected = selectedProjectId === p.id;
                const isCurrent = activeProject.id === p.id;
                const isRenaming = renamingId === p.id;
                const deleteGuard = canDeleteProject(p.id, activeProject.id);

                return (
                  <div
                    key={p.id}
                    onClick={() => setSelectedProjectId(p.id)}
                    onDoubleClick={() => !isRenaming && handleOpenSelected()}
                    className={`p-3 rounded-lg border cursor-pointer flex items-center justify-between transition-colors ${
                      isSelected
                        ? 'bg-[#272e3e] border-[#4982ea]'
                        : 'bg-[#181c24] border-[#2c3345] hover:border-[#3b475f]'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-9 rounded bg-[#2c3345] flex items-center justify-center font-bold text-sm text-[#4982ea] shrink-0">
                        {p.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          {isRenaming ? (
                            <input
                              autoFocus
                              value={renameValue}
                              maxLength={PROJECT_NAME_MAX}
                              aria-label="Novo nome do projeto"
                              aria-invalid={!!renameError}
                              title={renameError ?? undefined}
                              spellCheck={false}
                              onFocus={(e) => e.currentTarget.select()}
                              onChange={(e) => {
                                setRenameValue(e.target.value);
                                setRenameError(null);
                              }}
                              onClick={(e) => e.stopPropagation()}
                              onDoubleClick={(e) => e.stopPropagation()}
                              onBlur={() => (renameError ? setRenamingId(null) : commitRename(p.id))}
                              onKeyDown={(e) => {
                                e.stopPropagation();
                                if (e.key === 'Enter') commitRename(p.id);
                                else if (e.key === 'Escape') {
                                  setRenamingId(null);
                                  setRenameError(null);
                                }
                              }}
                              className={`bg-[#141820] text-white text-xs px-1.5 py-0.5 rounded border outline-none ${renameError ? 'border-rose-500' : 'border-[#4982ea]'}`}
                            />
                          ) : (
                            <span className="font-semibold text-white text-xs truncate">{p.name}</span>
                          )}
                          {isCurrent && (
                            <span className="bg-emerald-500/20 text-emerald-400 text-[10px] px-1.5 py-0.5 rounded font-medium">
                              Active
                            </span>
                          )}
                          <span className="bg-[#2c3345] text-[#8b97a8] text-[10px] px-1.5 py-0.5 rounded font-mono">
                            Three.js
                          </span>
                        </div>
                        {isRenaming && renameError && (
                          <div role="alert" className="text-[10px] text-rose-400 mt-0.5">{renameError}</div>
                        )}
                        <div className="text-[11px] text-[#8b97a8] font-mono mt-0.5 truncate">
                          {p.location}
                        </div>
                        <div className="text-[10px] text-[#6c788d] mt-0.5">
                          {p.updatedAt && !Number.isNaN(Date.parse(p.updatedAt)) ? new Date(p.updatedAt).toLocaleString() : '—'}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          startRename(p.id, p.name);
                        }}
                        className="p-1.5 rounded hover:bg-[#343e52] text-[#8b97a8] hover:text-white"
                        title="Renomear projeto"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          openDuplicate(p.id);
                        }}
                        className="p-1.5 rounded hover:bg-[#343e52] text-[#8b97a8] hover:text-white"
                        title="Duplicar projeto"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleExport(p.id);
                        }}
                        className="p-1.5 rounded hover:bg-[#343e52] text-[#8b97a8] hover:text-white"
                        title="Export Project (.nodimus)"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (deleteGuard.ok) openDelete(p.id);
                        }}
                        disabled={!deleteGuard.ok}
                        className="p-1.5 rounded hover:bg-rose-900/30 text-[#8b97a8] hover:text-rose-400 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-[#8b97a8]"
                        title={deleteGuard.ok ? 'Delete Project' : deleteGuard.reason}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
