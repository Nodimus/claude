import React from 'react';
import { useEditorStore } from '../../core/editorStore';
import { Puzzle, X, Info, FolderTree } from 'lucide-react';

/**
 * ExtensionsPanel — STUB/MOCK (v4.7.0 · AIS-05r)
 *
 * O sistema de extensões/plugins e a pasta `res://addons/` foram eliminados.
 * Este painel é mantido apenas como casca visual (stub): abre e fecha pelos
 * mesmos pontos de entrada, não lê nem grava arquivos, não instala, não cria
 * `plugin.cfg` e não executa código.
 *
 * Expansão de Behaviors/Actions/Triggers/Conditions é feita no código-fonte do
 * editor, uma pasta por item em `src/logic/<tipo>/<id>/` (ver `src/logic/README.md`).
 */
export const ExtensionsPanel: React.FC = () => {
  const isOpen = useEditorStore((s) => s.isExtensionsPanelOpen);
  const setOpen = useEditorStore((s) => s.setIsExtensionsPanelOpen);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-150 select-none">
      <div className="bg-[#1e232f] border border-[#2c3345] rounded-xl shadow-2xl w-full max-w-5xl h-[86vh] flex flex-col overflow-hidden text-[#dfe4ec]">
        {/* Header (mesma casca visual do painel original) */}
        <div className="h-12 border-b border-[#2c3345] px-4 flex items-center justify-between bg-[#191d27]">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-600 to-blue-600 flex items-center justify-center text-white shadow-md">
              <Puzzle className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-sm text-white">Extensões & Plugins</span>
                <span className="text-[11px] px-2 py-0.5 rounded bg-[#252c3c] text-[#8b97a8] font-mono border border-[#2c3345]">
                  stub
                </span>
              </div>
              <p className="text-[11px] text-[#8b97a8] hidden sm:block">
                Painel mantido como casca; o sistema de extensões não faz parte do editor.
              </p>
            </div>
          </div>

          <button
            onClick={() => setOpen(false)}
            className="p-1.5 rounded-lg hover:bg-[#2c3345] text-[#8b97a8] hover:text-white transition-colors ml-1"
            title="Fechar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body — conteúdo estático */}
        <div className="flex-1 flex flex-col items-center justify-center text-center p-8 gap-3">
          <FolderTree className="w-10 h-10 text-[#68768e] opacity-60" />
          <p className="font-medium text-white text-sm">Sem extensões nem plugins</p>
          <p className="text-xs text-[#8b97a8] max-w-md">
            Behaviors, Actions, Triggers e Conditions fazem parte do próprio editor e ficam organizados em
            pastas no código-fonte: <span className="font-mono text-[#dfe4ec]">src/logic/&lt;tipo&gt;/&lt;id&gt;/</span>.
            Não há pasta <span className="font-mono">res://addons/</span> no projeto.
          </p>
        </div>

        {/* Footer */}
        <div className="h-10 border-t border-[#2c3345] px-4 flex items-center justify-between bg-[#191d27] text-xs">
          <div className="flex items-center gap-2 text-[#718096] text-[11px]">
            <Info className="w-3.5 h-3.5" />
            <span>Stub/mock: nenhuma ação deste painel lê, grava ou executa arquivos.</span>
          </div>
          <button
            onClick={() => setOpen(false)}
            className="px-4 py-1.5 rounded-lg bg-[#273042] hover:bg-[#344057] text-white font-medium transition-colors text-xs"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
