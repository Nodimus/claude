import React, { useRef, useEffect, useState, useCallback } from 'react';
import * as THREE from 'three';
import { SpriteProject, BillboardMode, LightingPreset } from '../../../types/sprite';
import { toThreeColor } from '../../../utils/sceneColor';
import {
  RotateCcw,
  Sun,
  Eye,
  Maximize2,
  Grid,
  Layers,
  Compass,
  Play,
  Pause,
  Sparkles,
} from 'lucide-react';

interface SpriteVisualizer3DProps {
  project: SpriteProject;
  currentFrameCanvas: HTMLCanvasElement | null;
  isPlaying: boolean;
  onTogglePlay: () => void;
}

export const SpriteVisualizer3D: React.FC<SpriteVisualizer3DProps> = ({
  project,
  currentFrameCanvas,
  isPlaying,
  onTogglePlay,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const spriteMeshRef = useRef<THREE.Mesh | null>(null);
  const textureRef = useRef<THREE.CanvasTexture | null>(null);
  const lightsGroupRef = useRef<THREE.Group | null>(null);

  // Orbit controls state
  const isDraggingRef = useRef(false);
  const dragButtonRef = useRef(0);
  const mousePosRef = useRef({ x: 0, y: 0 });
  const cameraSphericalRef = useRef({ radius: 4.5, theta: 0.2, phi: 1.2 });
  const cameraTargetRef = useRef(new THREE.Vector3(0, 1.0, 0));

  // FPS calculation
  const [fps, setFps] = useState(60);
  const [autoRotate, setAutoRotate] = useState(false);
  const [showWireframe, setShowWireframe] = useState(false);

  // Update camera from spherical coordinates
  const updateCameraPosition = useCallback(() => {
    if (!cameraRef.current) return;
    const s = cameraSphericalRef.current;
    const target = cameraTargetRef.current;
    cameraRef.current.position.x = target.x + s.radius * Math.sin(s.phi) * Math.sin(s.theta);
    cameraRef.current.position.y = target.y + s.radius * Math.cos(s.phi);
    cameraRef.current.position.z = target.z + s.radius * Math.sin(s.phi) * Math.cos(s.theta);
    cameraRef.current.lookAt(target);
  }, []);

  const resetCamera = useCallback(() => {
    cameraSphericalRef.current = { radius: 4.5, theta: 0.2, phi: 1.2 };
    cameraTargetRef.current.set(0, project.settings3D.renderScale.y / 2, 0);
    updateCameraPosition();
  }, [project.settings3D.renderScale.y, updateCameraPosition]);

  // Setup Three.js scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    cameraRef.current = camera;
    resetCamera();

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 4. Lights Group
    const lightsGroup = new THREE.Group();
    lightsGroupRef.current = lightsGroup;
    scene.add(lightsGroup);

    // 5. Studio Floor Grid & Shadow Receiver
    const floorGeo = new THREE.PlaneGeometry(16, 16);
    floorGeo.rotateX(-Math.PI / 2);
    const floorMat = new THREE.ShadowMaterial({ opacity: 0.35 });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.receiveShadow = true;
    floor.position.y = -0.01;
    scene.add(floor);

    const grid = new THREE.GridHelper(16, 32, 0x4982ea, 0x272e3d);
    grid.position.y = -0.005;
    scene.add(grid);

    // 6. Sprite Quad Mesh
    const sx = project.settings3D.renderScale.x;
    const sy = project.settings3D.renderScale.y;
    const quadGeo = new THREE.PlaneGeometry(sx, sy);

    // Initial dummy canvas texture
    const dummyCanvas = document.createElement('canvas');
    dummyCanvas.width = 32;
    dummyCanvas.height = 32;
    const canvasTexture = new THREE.CanvasTexture(dummyCanvas);
    canvasTexture.magFilter = project.settings3D.pixelPerfectFilter
      ? THREE.NearestFilter
      : THREE.LinearFilter;
    canvasTexture.minFilter = project.settings3D.pixelPerfectFilter
      ? THREE.NearestFilter
      : THREE.LinearFilter;
    textureRef.current = canvasTexture;

    const quadMat = new THREE.MeshStandardMaterial({
      map: canvasTexture,
      transparent: true,
      alphaTest: project.settings3D.alphaTest,
      side: project.settings3D.doubleSided ? THREE.DoubleSide : THREE.FrontSide,
      roughness: 0.5,
      metalness: 0.1,
      color: toThreeColor(project.settings3D.tintColor, 0xffffff),
      emissive: new THREE.Color(project.settings3D.emissiveColor),
      emissiveIntensity: project.settings3D.emissiveIntensity,
    });

    const spriteMesh = new THREE.Mesh(quadGeo, quadMat);
    spriteMesh.position.y = sy / 2;
    spriteMesh.castShadow = project.settings3D.castShadow;
    spriteMesh.receiveShadow = project.settings3D.receiveShadow;
    scene.add(spriteMesh);
    spriteMeshRef.current = spriteMesh;

    // 7. Render Loop with FPS monitoring
    let animationFrameId: number;
    let lastTime = performance.now();
    let frameCount = 0;
    let fpsTimer = 0;

    const animate = (time: number) => {
      animationFrameId = requestAnimationFrame(animate);

      const delta = (time - lastTime) / 1000;
      lastTime = time;

      // Calculate FPS
      frameCount++;
      fpsTimer += delta;
      if (fpsTimer >= 0.5) {
        setFps(Math.round((frameCount / fpsTimer)));
        frameCount = 0;
        fpsTimer = 0;
      }

      // Auto rotation
      if (autoRotate && spriteMeshRef.current) {
        cameraSphericalRef.current.theta += delta * 0.8;
        updateCameraPosition();
      }

      // Billboard orientation
      if (spriteMeshRef.current && cameraRef.current) {
        const mode = project.settings3D.billboardMode;
        if (mode === 'spherical') {
          // Full camera-facing quaternion copy
          spriteMeshRef.current.quaternion.copy(cameraRef.current.quaternion);
        } else if (mode === 'cylindrical_y') {
          // Rotate around Y only
          const camPos = cameraRef.current.position.clone();
          camPos.y = spriteMeshRef.current.position.y;
          spriteMeshRef.current.lookAt(camPos);
        } else if (mode === 'flat_quad') {
          // Static facing forward (Z+)
          spriteMeshRef.current.rotation.set(0, 0, 0);
        } else if (mode === 'isometric') {
          spriteMeshRef.current.rotation.set(0, Math.PI / 4, 0);
        }
      }

      renderer.render(scene, camera);
    };

    animate(performance.now());

    // Resize observer
    const handleResize = () => {
      if (!container || !camera || !renderer) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      renderer.dispose();
      quadGeo.dispose();
      quadMat.dispose();
      canvasTexture.dispose();
    };
  }, []);

  // Update lighting when environmentLighting changes
  useEffect(() => {
    const lightsGroup = lightsGroupRef.current;
    const scene = sceneRef.current;
    if (!lightsGroup || !scene) return;

    // Clear previous lights
    while (lightsGroup.children.length > 0) {
      const child = lightsGroup.children[0];
      lightsGroup.remove(child);
    }

    const preset = project.settings3D.environmentLighting;

    if (preset === 'cyberpunk') {
      scene.background = new THREE.Color(0x0b0d19);
      const ambient = new THREE.AmbientLight(0x221d3f, 1.2);
      const cyanSpot = new THREE.SpotLight(0x0ef3ff, 4.0, 15, Math.PI / 4, 0.4);
      cyanSpot.position.set(-3, 4, 3);
      cyanSpot.castShadow = true;
      const pinkRim = new THREE.DirectionalLight(0xff007f, 3.0);
      pinkRim.position.set(3, 2, -2);
      lightsGroup.add(ambient, cyanSpot, pinkRim);
    } else if (preset === 'night') {
      scene.background = new THREE.Color(0x0d121d);
      const ambient = new THREE.AmbientLight(0x1a2639, 0.9);
      const moon = new THREE.DirectionalLight(0x89b4fa, 2.5);
      moon.position.set(4, 8, 3);
      moon.castShadow = true;
      lightsGroup.add(ambient, moon);
    } else if (preset === 'sunset') {
      scene.background = new THREE.Color(0x22131b);
      const ambient = new THREE.AmbientLight(0x4a2838, 1.0);
      const sun = new THREE.DirectionalLight(0xff8c42, 3.5);
      sun.position.set(-5, 3, 4);
      sun.castShadow = true;
      const skyLight = new THREE.HemisphereLight(0xff77a8, 0x1d1934, 1.0);
      lightsGroup.add(ambient, sun, skyLight);
    } else if (preset === 'retro_arcade') {
      scene.background = new THREE.Color(0x08080c);
      const ambient = new THREE.AmbientLight(0x141822, 0.8);
      const greenLight = new THREE.PointLight(0x39ff14, 3, 10);
      greenLight.position.set(0, 3, 2);
      lightsGroup.add(ambient, greenLight);
    } else {
      // Default Studio
      scene.background = new THREE.Color(0x181c24);
      const ambient = new THREE.AmbientLight(0xffffff, 1.1);
      const keyLight = new THREE.DirectionalLight(0xffffff, 2.0);
      keyLight.position.set(3, 5, 4);
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      const fillLight = new THREE.DirectionalLight(0x90b0e0, 0.8);
      fillLight.position.set(-3, 2, -2);
      lightsGroup.add(ambient, keyLight, fillLight);
    }
  }, [project.settings3D.environmentLighting]);

  // Update texture whenever the current frame canvas changes
  useEffect(() => {
    if (!currentFrameCanvas) return;

    if (textureRef.current) {
      textureRef.current.image = currentFrameCanvas;
      textureRef.current.magFilter = project.settings3D.pixelPerfectFilter
        ? THREE.NearestFilter
        : THREE.LinearFilter;
      textureRef.current.minFilter = project.settings3D.pixelPerfectFilter
        ? THREE.NearestFilter
        : THREE.LinearFilter;
      textureRef.current.needsUpdate = true;
    }

    if (spriteMeshRef.current) {
      const mat = spriteMeshRef.current.material as THREE.MeshStandardMaterial;
      if (mat) {
        mat.color.copy(toThreeColor(project.settings3D.tintColor, 0xffffff));
        mat.emissive.set(project.settings3D.emissiveColor);
        mat.emissiveIntensity = project.settings3D.emissiveIntensity;
        mat.alphaTest = project.settings3D.alphaTest;
        mat.wireframe = showWireframe;
        mat.needsUpdate = true;
      }
    }
  }, [
    currentFrameCanvas,
    project.settings3D.pixelPerfectFilter,
    project.settings3D.tintColor,
    project.settings3D.emissiveColor,
    project.settings3D.emissiveIntensity,
    project.settings3D.alphaTest,
    showWireframe,
  ]);

  // Update scale
  useEffect(() => {
    if (spriteMeshRef.current) {
      const sx = project.settings3D.renderScale.x;
      const sy = project.settings3D.renderScale.y;
      spriteMeshRef.current.scale.set(sx, sy, 1.0);
      spriteMeshRef.current.position.y = sy / 2;
    }
  }, [project.settings3D.renderScale.x, project.settings3D.renderScale.y]);

  // Mouse Orbit & Pan handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    dragButtonRef.current = e.button;
    mousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - mousePosRef.current.x;
    const dy = e.clientY - mousePosRef.current.y;
    mousePosRef.current = { x: e.clientX, y: e.clientY };

    if (dragButtonRef.current === 0) {
      // Orbit rotate
      cameraSphericalRef.current.theta -= dx * 0.008;
      cameraSphericalRef.current.phi = Math.max(
        0.1,
        Math.min(Math.PI / 2 - 0.02, cameraSphericalRef.current.phi - dy * 0.008)
      );
      updateCameraPosition();
    } else if (dragButtonRef.current === 2) {
      // Pan
      const panSpeed = 0.004;
      cameraTargetRef.current.y += dy * panSpeed;
      updateCameraPosition();
    }
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    cameraSphericalRef.current.radius = Math.max(
      1.0,
      Math.min(15.0, cameraSphericalRef.current.radius + e.deltaY * 0.005)
    );
    updateCameraPosition();
  };

  return (
    <div
      className="relative w-full h-full overflow-hidden bg-[#141822] select-none cursor-grab active:cursor-grabbing"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onWheel={handleWheel}
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* 3D WebGL Canvas Mount */}
      <div ref={mountRef} className="w-full h-full" />

      {/* Top Floating Controls Bar */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-1.5 bg-[#1e2330]/90 backdrop-blur-md px-2.5 py-1.5 rounded-lg border border-[#2e3748] pointer-events-auto shadow-lg text-xs">
          <span className="font-semibold text-sky-400 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-sky-400" />
            3D Billboard Viewport
          </span>
          <span className="text-[#64748b]">|</span>
          <span className="text-[#94a3b8] font-mono text-[11px]">{fps} FPS</span>
          <span className="text-[#64748b]">|</span>
          <span className="text-[#38bdf8] font-mono text-[11px]">
            Modo: {project.settings3D.billboardMode}
          </span>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1.5 bg-[#1e2330]/90 backdrop-blur-md p-1 rounded-lg border border-[#2e3748] pointer-events-auto shadow-lg">
          <button
            onClick={onTogglePlay}
            className={`p-1.5 rounded transition-colors ${
              isPlaying
                ? 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30'
                : 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
            }`}
            title={isPlaying ? 'Pausar Animação' : 'Reproduzir Animação'}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={() => setAutoRotate(!autoRotate)}
            className={`p-1.5 rounded transition-colors ${
              autoRotate ? 'bg-sky-500 text-white' : 'text-[#94a3b8] hover:text-white hover:bg-[#2c3345]'
            }`}
            title="Auto-Girar Vitrine 360°"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setShowWireframe(!showWireframe)}
            className={`p-1.5 rounded transition-colors ${
              showWireframe ? 'bg-purple-600 text-white' : 'text-[#94a3b8] hover:text-white hover:bg-[#2c3345]'
            }`}
            title="Alternar Wireframe"
          >
            <Grid className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={resetCamera}
            className="p-1.5 rounded text-[#94a3b8] hover:text-white hover:bg-[#2c3345] transition-colors"
            title="Resetar Câmera"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Bottom Floating Info Pill */}
      <div className="absolute bottom-3 left-3 bg-[#1a202c]/85 backdrop-blur-sm px-3 py-1.5 rounded-md border border-[#2d3748] text-[11px] text-[#94a3b8] pointer-events-none flex items-center gap-3">
        <span>🖱️ Botão Esquerdo: Girar</span>
        <span>🖱️ Botão Direito: Pan</span>
        <span>🔍 Scroll: Zoom</span>
        <span className="text-emerald-400 font-medium">
          Tamanho: {project.sheetConfig.frameWidth}x{project.sheetConfig.frameHeight}px
        </span>
      </div>
    </div>
  );
};
