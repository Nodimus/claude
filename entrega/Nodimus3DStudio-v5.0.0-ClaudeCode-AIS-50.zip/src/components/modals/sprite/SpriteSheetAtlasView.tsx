import React, { useRef, useState } from 'react';
import { SpriteProject, SpriteSheetConfig } from '../../../types/sprite';
import {
  Upload,
  Download,
  Grid,
  Sparkles,
  Scissors,
  Layers,
  Check,
  RefreshCw,
  FolderOpen,
} from 'lucide-react';
import { SPRITE_PRESETS } from '../../../utils/spritePresets';

interface SpriteSheetAtlasViewProps {
  project: SpriteProject;
  onUpdateSheetConfig: (newConfig: SpriteSheetConfig) => void;
  onSelectFrame: (index: number) => void;
  onLoadPreset: (presetId: string) => void;
  onUploadImage: (file: File) => void;
  onSliceGrid: (cols: number, rows: number, fw: number, fh: number) => void;
  currentFrameIndex: number;
}

export const SpriteSheetAtlasView: React.FC<SpriteSheetAtlasViewProps> = ({
  project,
  onUpdateSheetConfig,
  onSelectFrame,
  onLoadPreset,
  onUploadImage,
  onSliceGrid,
  currentFrameIndex,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [cols, setCols] = useState(project.sheetConfig.columns || 4);
  const [rows, setRows] = useState(project.sheetConfig.rows || 1);
  const [fw, setFw] = useState(project.sheetConfig.frameWidth || 32);
  const [fh, setFh] = useState(project.sheetConfig.frameHeight || 32);

  const handleApplySlice = () => {
    onSliceGrid(cols, rows, fw, fh);
  };

  const handleAutoCalc = () => {
    if (project.sheetConfig.imageWidth && fw > 0) {
      const calculatedCols = Math.max(1, Math.floor(project.sheetConfig.imageWidth / fw));
      const calculatedRows = Math.max(1, Math.floor(project.sheetConfig.imageHeight / fh));
      setCols(calculatedCols);
      setRows(calculatedRows);
      onSliceGrid(calculatedCols, calculatedRows, fw, fh);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#181c24] select-none overflow-y-auto">
      {/* Top Config Header */}
      <div className="flex flex-wrap items-center justify-between p-3 bg-[#202531] border-b border-[#2c3345] gap-3">
        {/* Presets Selector */}
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-semibold text-[#dfe4ec]">Modelos Prontos:</span>
          <select
            onChange={(e) => {
              if (e.target.value) {
                onLoadPreset(e.target.value);
              }
            }}
            defaultValue=""
            className="bg-[#141822] text-xs text-[#cbd5e1] border border-[#374158] rounded px-2.5 py-1 focus:outline-none focus:border-sky-400"
          >
            <option value="" disabled>
              -- Carregar Personagem / Efeito --
            </option>
            {SPRITE_PRESETS.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.category})
              </option>
            ))}
          </select>
        </div>

        {/* Upload Custom Image */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#2c374b] hover:bg-[#384660] text-sky-300 hover:text-white border border-[#3c4a64] text-xs transition-colors shadow-sm"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Importar Imagem (PNG/JPG/WebP/SVG)</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp,image/svg+xml"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                onUploadImage(e.target.files[0]);
              }
            }}
          />
        </div>
      </div>

      {/* Grid Slicing Controls Bar */}
      <div className="flex flex-wrap items-center gap-3 px-3 py-2 bg-[#1c222e] border-b border-[#2c3345] text-xs">
        <span className="font-semibold text-sky-400 flex items-center gap-1">
          <Scissors className="w-3.5 h-3.5 text-sky-400" />
          Fatiamento de Grade (Grid Slicing):
        </span>

        {/* Columns & Rows */}
        <div className="flex items-center gap-1.5 bg-[#141822] px-2 py-1 rounded border border-[#2c3345]">
          <span className="text-[#8b97a8]">Colunas:</span>
          <input
            type="number"
            min="1"
            max="64"
            value={cols}
            onChange={(e) => setCols(Math.max(1, parseInt(e.target.value) || 1))}
            className="w-12 bg-transparent text-center font-mono text-white text-xs border-b border-[#475569] focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-1.5 bg-[#141822] px-2 py-1 rounded border border-[#2c3345]">
          <span className="text-[#8b97a8]">Linhas:</span>
          <input
            type="number"
            min="1"
            max="64"
            value={rows}
            onChange={(e) => setRows(Math.max(1, parseInt(e.target.value) || 1))}
            className="w-12 bg-transparent text-center font-mono text-white text-xs border-b border-[#475569] focus:outline-none"
          />
        </div>

        {/* Frame Dimensions */}
        <div className="flex items-center gap-1.5 bg-[#141822] px-2 py-1 rounded border border-[#2c3345]">
          <span className="text-[#8b97a8]">Largura (px):</span>
          <input
            type="number"
            min="8"
            max="512"
            value={fw}
            onChange={(e) => setFw(Math.max(8, parseInt(e.target.value) || 16))}
            className="w-14 bg-transparent text-center font-mono text-white text-xs border-b border-[#475569] focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-1.5 bg-[#141822] px-2 py-1 rounded border border-[#2c3345]">
          <span className="text-[#8b97a8]">Altura (px):</span>
          <input
            type="number"
            min="8"
            max="512"
            value={fh}
            onChange={(e) => setFh(Math.max(8, parseInt(e.target.value) || 16))}
            className="w-14 bg-transparent text-center font-mono text-white text-xs border-b border-[#475569] focus:outline-none"
          />
        </div>

        <button
          onClick={handleApplySlice}
          className="flex items-center gap-1 px-3 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded font-medium shadow-sm transition-colors"
        >
          <Check className="w-3.5 h-3.5" />
          <span>Fatiar Grade ({cols * rows} quadros)</span>
        </button>

        <button
          onClick={handleAutoCalc}
          className="flex items-center gap-1 px-2 py-1 bg-[#252d3d] hover:bg-[#323d53] text-[#cbd5e1] rounded transition-colors"
          title="Auto-calcular colunas/linhas com base na largura da imagem"
        >
          <RefreshCw className="w-3 h-3" />
          <span>Auto-Ajustar</span>
        </button>
      </div>

      {/* Spritesheet Canvas Display */}
      <div className="flex-1 p-6 flex flex-col items-center justify-center bg-[#12151d] overflow-auto">
        <div className="relative border-2 border-[#3b475e] rounded shadow-2xl bg-[#0c0e14] p-2">
          {/* Transparency background */}
          <div
            className="relative"
            style={{
              width: project.sheetConfig.imageWidth || 256,
              height: project.sheetConfig.imageHeight || 256,
            }}
          >
            {project.sheetConfig.imageUrl ? (
              <img
                src={project.sheetConfig.imageUrl}
                alt="Spritesheet Atlas"
                className="w-full h-full object-contain pointer-events-none"
                style={{ imageRendering: 'pixelated' }}
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-xs text-[#64748b]">
                Nenhuma imagem carregada
              </div>
            )}

            {/* Grid Cell Overlays */}
            {project.frames.map((frame, index) => {
              const isSelected = index === currentFrameIndex;
              return (
                <div
                  key={frame.id || index}
                  onClick={() => onSelectFrame(index)}
                  style={{
                    position: 'absolute',
                    left: `${(frame.x / project.sheetConfig.imageWidth) * 100}%`,
                    top: `${(frame.y / project.sheetConfig.imageHeight) * 100}%`,
                    width: `${(frame.width / project.sheetConfig.imageWidth) * 100}%`,
                    height: `${(frame.height / project.sheetConfig.imageHeight) * 100}%`,
                  }}
                  className={`border cursor-pointer transition-all flex items-start justify-start p-1 ${
                    isSelected
                      ? 'border-sky-400 bg-sky-500/20 ring-2 ring-sky-400 shadow-lg'
                      : 'border-white/20 hover:border-white/60 hover:bg-white/10'
                  }`}
                  title={`Quadro #${index + 1} (${frame.width}x${frame.height}px)`}
                >
                  <span
                    className={`font-mono text-[9px] px-1 rounded ${
                      isSelected
                        ? 'bg-sky-500 text-white font-bold'
                        : 'bg-black/60 text-white/80'
                    }`}
                  >
                    #{index + 1}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-4 text-xs text-[#8b97a8] flex items-center gap-4">
          <span>
            Dimensões do Atlas: <strong>{project.sheetConfig.imageWidth}x{project.sheetConfig.imageHeight}px</strong>
          </span>
          <span>•</span>
          <span>
            Total de Quadros: <strong>{project.frames.length}</strong>
          </span>
          <span>•</span>
          <span>Clique em qualquer quadro para selecioná-lo e editá-lo</span>
        </div>
      </div>
    </div>
  );
};
