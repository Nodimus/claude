import React, { useState } from 'react';
import { SpriteProject, SpriteAnimation, LoopMode } from '../../../types/sprite';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Plus,
  Copy,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Repeat,
  RotateCcw,
  Sparkles,
  Layers,
  Clock,
} from 'lucide-react';

interface SpriteTimelineProps {
  project: SpriteProject;
  currentFrameIndex: number;
  onSelectFrame: (index: number) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onStepFrame: (direction: number) => void;
  onAddFrame: () => void;
  onDuplicateFrame: (index: number) => void;
  onDeleteFrame: (index: number) => void;
  onMoveFrame: (fromIndex: number, toIndex: number) => void;
  onSelectAnimation: (animId: string) => void;
  onAddAnimation: (name: string) => void;
  onUpdateAnimation: (anim: SpriteAnimation) => void;
  onDeleteAnimation: (animId: string) => void;
  frameCanvases: (HTMLCanvasElement | null)[];
}

export const SpriteTimeline: React.FC<SpriteTimelineProps> = ({
  project,
  currentFrameIndex,
  onSelectFrame,
  isPlaying,
  onTogglePlay,
  onStepFrame,
  onAddFrame,
  onDuplicateFrame,
  onDeleteFrame,
  onMoveFrame,
  onSelectAnimation,
  onAddAnimation,
  onUpdateAnimation,
  onDeleteAnimation,
  frameCanvases,
}) => {
  const [isAddingAnim, setIsAddingAnim] = useState(false);
  const [newAnimName, setNewAnimName] = useState('');

  const activeAnim =
    project.animations.find((a) => a.id === project.activeAnimationId) ||
    project.animations[0];

  const handleCreateAnim = () => {
    if (!newAnimName.trim()) return;
    onAddAnimation(newAnimName.trim().toLowerCase());
    setNewAnimName('');
    setIsAddingAnim(false);
  };

  const handleFpsChange = (newFps: number) => {
    if (!activeAnim) return;
    onUpdateAnimation({ ...activeAnim, fps: Math.max(1, Math.min(60, newFps)) });
  };

  const handleLoopModeChange = (loopMode: LoopMode) => {
    if (!activeAnim) return;
    onUpdateAnimation({ ...activeAnim, loopMode });
  };

  const activeFrames = activeAnim ? activeAnim.frameIndices : [];

  return (
    <div className="flex flex-col bg-[#1c222e] border-t border-[#2c3345] select-none h-48 shrink-0">
      {/* Animation Header & Tabs */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-[#2c3345] bg-[#181c24] text-xs">
        {/* Left: Animation Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
          <span className="text-[#64748b] text-[11px] font-semibold flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-sky-400" />
            Animação:
          </span>

          {project.animations.map((anim) => (
            <div
              key={anim.id}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium cursor-pointer transition-colors ${
                anim.id === project.activeAnimationId
                  ? 'bg-[#4982ea] text-white shadow-sm'
                  : 'bg-[#202531] text-[#9ca7b7] hover:bg-[#2c3345] hover:text-[#dfe4ec]'
              }`}
              onClick={() => onSelectAnimation(anim.id)}
            >
              <span>{anim.name}</span>
              <span className="text-[10px] opacity-75">
                ({anim.frameIndices.length}q)
              </span>

              {project.animations.length > 1 && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteAnimation(anim.id);
                  }}
                  className="hover:text-rose-300 ml-0.5"
                  title="Excluir Animação"
                >
                  ×
                </button>
              )}
            </div>
          ))}

          {/* Add Animation Button */}
          {isAddingAnim ? (
            <div className="flex items-center gap-1 bg-[#202531] p-0.5 rounded border border-[#3b475e]">
              <input
                type="text"
                autoFocus
                placeholder="nome..."
                value={newAnimName}
                onChange={(e) => setNewAnimName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleCreateAnim();
                  if (e.key === 'Escape') setIsAddingAnim(false);
                }}
                className="w-20 px-1 py-0.5 text-xs bg-[#141822] text-white border border-[#2c3345] rounded"
              />
              <button
                onClick={handleCreateAnim}
                className="px-1.5 py-0.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px]"
              >
                OK
              </button>
              <button
                onClick={() => setIsAddingAnim(false)}
                className="px-1 text-[#8b97a8] hover:text-white text-[10px]"
              >
                ×
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsAddingAnim(true)}
              className="flex items-center gap-1 px-2 py-1 rounded bg-[#202531] hover:bg-[#2c3345] text-[#9ca7b7] hover:text-white border border-dashed border-[#374158] transition-colors"
              title="Criar Nova Faixa de Animação"
            >
              <Plus className="w-3 h-3 text-sky-400" />
              <span className="text-[11px]">Nova</span>
            </button>
          )}
        </div>

        {/* Right: FPS & Loop Controls */}
        {activeAnim && (
          <div className="flex items-center gap-3">
            {/* FPS */}
            <div className="flex items-center gap-1.5 bg-[#202531] px-2 py-0.5 rounded border border-[#2c3345]">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[11px] text-[#9ca7b7]">Velocidade:</span>
              <input
                type="number"
                min="1"
                max="60"
                value={activeAnim.fps}
                onChange={(e) => handleFpsChange(parseInt(e.target.value) || 8)}
                className="w-12 px-1 py-0.5 bg-[#141822] text-center font-mono text-xs rounded border border-[#3b475e] text-white"
              />
              <span className="text-[10px] text-[#64748b]">FPS</span>
            </div>

            {/* Quick FPS Presets */}
            <div className="hidden lg:flex items-center gap-1">
              {[6, 8, 12, 16, 24].map((f) => (
                <button
                  key={f}
                  onClick={() => handleFpsChange(f)}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                    activeAnim.fps === f
                      ? 'bg-[#4982ea] text-white'
                      : 'bg-[#202531] text-[#8b97a8] hover:text-white'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>

            {/* Loop Mode */}
            <div className="flex items-center gap-1 bg-[#202531] px-1 py-0.5 rounded border border-[#2c3345]">
              <button
                onClick={() => handleLoopModeChange('loop')}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                  activeAnim.loopMode === 'loop'
                    ? 'bg-[#4982ea] text-white'
                    : 'text-[#8b97a8] hover:text-white'
                }`}
                title="Repetir em Loop Infinito"
              >
                Loop
              </button>
              <button
                onClick={() => handleLoopModeChange('once')}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                  activeAnim.loopMode === 'once'
                    ? 'bg-[#4982ea] text-white'
                    : 'text-[#8b97a8] hover:text-white'
                }`}
                title="Tocar Uma Vez e Parar"
              >
                1x
              </button>
              <button
                onClick={() => handleLoopModeChange('ping-pong')}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                  activeAnim.loopMode === 'ping-pong'
                    ? 'bg-[#4982ea] text-white'
                    : 'text-[#8b97a8] hover:text-white'
                }`}
                title="Ping-Pong (Ida e Volta)"
              >
                Ping-Pong
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Main Playback Bar & Controls */}
      <div className="flex items-center justify-between px-3 py-1 bg-[#181c24] border-b border-[#2c3345]">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onStepFrame(-1000)}
            className="p-1 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title="Primeiro Quadro"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => onStepFrame(-1)}
            className="p-1 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title="Quadro Anterior"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            onClick={onTogglePlay}
            className={`px-3 py-1 rounded flex items-center gap-1.5 font-medium text-xs shadow-sm transition-colors ${
              isPlaying
                ? 'bg-amber-600 hover:bg-amber-500 text-white'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5" /> Pausar
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" /> Reproduzir
              </>
            )}
          </button>

          <button
            onClick={() => onStepFrame(1)}
            className="p-1 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title="Próximo Quadro"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => onStepFrame(1000)}
            className="p-1 rounded text-[#9ca7b7] hover:text-white hover:bg-[#2c3345]"
            title="Último Quadro"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>

          <div className="h-4 w-[1px] bg-[#374158] mx-1" />

          {/* Current Frame Readout */}
          <span className="text-xs text-[#cbd5e1] font-mono">
            Quadro: <strong className="text-sky-400">{currentFrameIndex + 1}</strong> /{' '}
            {project.frames.length}
          </span>
        </div>

        {/* Frame Actions: Add, Duplicate, Move, Delete */}
        <div className="flex items-center gap-1">
          <button
            onClick={onAddFrame}
            className="flex items-center gap-1 px-2 py-1 rounded bg-[#202531] hover:bg-[#2c3345] text-sky-400 hover:text-sky-300 text-xs transition-colors"
            title="Adicionar Quadro em Branco"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Adicionar Quadro</span>
          </button>

          <button
            onClick={() => onDuplicateFrame(currentFrameIndex)}
            className="flex items-center gap-1 px-2 py-1 rounded bg-[#202531] hover:bg-[#2c3345] text-[#dfe4ec] text-xs transition-colors"
            title="Duplicar Quadro Selecionado"
          >
            <Copy className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Duplicar</span>
          </button>

          <button
            onClick={() => onMoveFrame(currentFrameIndex, currentFrameIndex - 1)}
            disabled={currentFrameIndex <= 0}
            className={`p-1 rounded transition-colors ${
              currentFrameIndex > 0
                ? 'text-[#dfe4ec] hover:bg-[#2c3345]'
                : 'text-[#4e586c] cursor-not-allowed'
            }`}
            title="Mover Quadro para Esquerda"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => onMoveFrame(currentFrameIndex, currentFrameIndex + 1)}
            disabled={currentFrameIndex >= project.frames.length - 1}
            className={`p-1 rounded transition-colors ${
              currentFrameIndex < project.frames.length - 1
                ? 'text-[#dfe4ec] hover:bg-[#2c3345]'
                : 'text-[#4e586c] cursor-not-allowed'
            }`}
            title="Mover Quadro para Direita"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => onDeleteFrame(currentFrameIndex)}
            disabled={project.frames.length <= 1}
            className={`p-1 rounded transition-colors ${
              project.frames.length > 1
                ? 'text-[#b3bed0] hover:text-rose-400 hover:bg-rose-950/30'
                : 'text-[#4e586c] cursor-not-allowed'
            }`}
            title="Excluir Quadro Atual"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Frame Scrubber / Thumbnails Strip */}
      <div className="flex-1 overflow-x-auto flex items-center gap-2 p-2.5 bg-[#141822]">
        {project.frames.map((frame, index) => {
          const isActive = index === currentFrameIndex;
          const isInActiveAnim = activeFrames.includes(index);
          const frameCanvas = frameCanvases[index];

          return (
            <div
              key={frame.id || index}
              onClick={() => onSelectFrame(index)}
              className={`flex flex-col items-center justify-between p-1 rounded-lg cursor-pointer transition-all shrink-0 w-20 h-24 border ${
                isActive
                  ? 'bg-[#242f44] border-sky-400 ring-2 ring-sky-500/30 shadow-md'
                  : isInActiveAnim
                  ? 'bg-[#1b212d] border-[#374158] hover:border-[#4f5d79]'
                  : 'bg-[#161a24] border-[#252c3c] opacity-60 hover:opacity-100'
              }`}
            >
              {/* Frame Index & Duration */}
              <div className="flex items-center justify-between w-full px-1 text-[10px]">
                <span
                  className={`font-mono font-bold ${
                    isActive ? 'text-sky-400' : 'text-[#8b97a8]'
                  }`}
                >
                  #{index + 1}
                </span>
                {isInActiveAnim && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" title="Presente na Animação" />
                )}
              </div>

              {/* Thumbnail */}
              <div className="w-14 h-14 bg-[#0e1118] rounded flex items-center justify-center overflow-hidden border border-[#2c3345] shadow-inner relative">
                {frameCanvas ? (
                  <img
                    src={frameCanvas.toDataURL()}
                    alt={`Frame ${index + 1}`}
                    className="max-w-full max-h-full object-contain"
                    style={{ imageRendering: 'pixelated' }}
                  />
                ) : frame.customDataUrl ? (
                  <img
                    src={frame.customDataUrl}
                    alt={`Frame ${index + 1}`}
                    className="max-w-full max-h-full object-contain"
                    style={{ imageRendering: 'pixelated' }}
                  />
                ) : (
                  <div className="text-[9px] text-[#4b5563]">Vazio</div>
                )}
              </div>

              {/* Timing */}
              <span className="text-[9px] text-[#64748b] font-mono">
                {frame.durationMs || 100}ms
              </span>
            </div>
          );
        })}

        {/* Quick Add Button at end of strip */}
        <button
          onClick={onAddFrame}
          className="flex flex-col items-center justify-center w-16 h-24 rounded-lg border-2 border-dashed border-[#2e3748] hover:border-sky-400 hover:bg-[#1b2230] text-[#64748b] hover:text-sky-300 transition-colors shrink-0 gap-1"
          title="Novo Quadro"
        >
          <Plus className="w-4 h-4" />
          <span className="text-[10px]">Quadro</span>
        </button>
      </div>
    </div>
  );
};
