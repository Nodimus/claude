import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useEditor } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import {
  CloudFog,
  Sparkles,
  X,
  RotateCcw,
  Check,
  Eye,
  Info,
  ExternalLink,
  Sliders,
  Palette,
  Wind,
  Layers,
  Sun,
  Moon,
  Compass,
} from 'lucide-react';
import {
  FogMode,
  SceneFogSettings,
  DEFAULT_SCENE_FOG,
} from '../../types/scene';

export interface FogPresetConfig {
  name: string;
  description: string;
  color: string;
  mode: FogMode;
  density: number;
  near: number;
  far: number;
  height: number;
  heightFalloff: number;
  affectSkybox: boolean;
}

const FOG_PRESETS: Record<string, FogPresetConfig> = {
  morning_mist: {
    name: 'Morning Mist (Névoa Matinal)',
    description: 'Névoa suave e fresca azulada ao amanhecer, com visibilidade moderada e horizonte limpo.',
    color: '#9cb5c9',
    mode: 'exponential2',
    density: 0.007,
    near: 20,
    far: 240,
    height: 14,
    heightFalloff: 0.6,
    affectSkybox: false,
  },
  dense_forest: {
    name: 'Dense Forest (Floresta Densa)',
    description: 'Nevoeiro denso e úmido em tons verde-musgo acinzentados, ideal para florestas e pântanos.',
    color: '#4e5b52',
    mode: 'exponential2',
    density: 0.018,
    near: 8,
    far: 110,
    height: 25,
    heightFalloff: 0.8,
    affectSkybox: true,
  },
  golden_sunset: {
    name: 'Sunset Smog (Pôr do Sol)',
    description: 'Bruma atmosférica dourada/alaranjada iluminada pela luz rasteira do entardecer.',
    color: '#d48856',
    mode: 'exponential',
    density: 0.005,
    near: 30,
    far: 320,
    height: 18,
    heightFalloff: 0.5,
    affectSkybox: true,
  },
  night_horror: {
    name: 'Horror Night (Noite Sombria)',
    description: 'Névoa escura e opressiva em tons de azul petróleo escuro, escondendo silhuetas a curta distância.',
    color: '#151c27',
    mode: 'exponential2',
    density: 0.024,
    near: 5,
    far: 80,
    height: 20,
    heightFalloff: 0.7,
    affectSkybox: true,
  },
  desert_dust: {
    name: 'Desert Dust (Tempestade de Areia)',
    description: 'Poeira suspensa ocre com visibilidade reduzida e tom arenoso difuso.',
    color: '#c49a6c',
    mode: 'linear',
    density: 0.012,
    near: 10,
    far: 140,
    height: 35,
    heightFalloff: 0.3,
    affectSkybox: true,
  },
  arctic_blizzard: {
    name: 'Arctic Blizzard (Nevasca)',
    description: 'Nevasca ártica densa e alva que dissolve o horizonte em uma parede branca uniforme.',
    color: '#e4ebf2',
    mode: 'exponential2',
    density: 0.028,
    near: 4,
    far: 65,
    height: 40,
    heightFalloff: 0.2,
    affectSkybox: true,
  },
  cyber_haze: {
    name: 'Cyber Haze (Bruma Neon)',
    description: 'Atmosfera estilizada sci-fi com tonalidade magenta/violeta sintética para cidades cyberpunk.',
    color: '#6c4b82',
    mode: 'exponential',
    density: 0.01,
    near: 15,
    far: 190,
    height: 16,
    heightFalloff: 0.6,
    affectSkybox: false,
  },
};

export const FogModal: React.FC = () => {
  // AIS-03f: Modal visibility migrated to canonical Zustand EditorStore
  const isFogModalOpen    = useEditorStore((s) => s.isFogModalOpen);
  const setIsFogModalOpen = useEditorStore((s) => s.setIsFogModalOpen);

  const {
    activeScene,
    updateSceneFog,
    addLog,
  } = useEditor();

  const currentFog = activeScene.fog || DEFAULT_SCENE_FOG;

  const [enabled, setEnabled] = useState<boolean>(currentFog.enabled);
  const [mode, setMode] = useState<FogMode>(currentFog.mode);
  const [color, setColor] = useState<string>(currentFog.color);
  const [density, setDensity] = useState<number>(currentFog.density);
  const [near, setNear] = useState<number>(currentFog.near);
  const [far, setFar] = useState<number>(currentFog.far);
  const [height, setHeight] = useState<number>(currentFog.height);
  const [heightFalloff, setHeightFalloff] = useState<number>(currentFog.heightFalloff);
  const [affectSkybox, setAffectSkybox] = useState<boolean>(currentFog.affectSkybox);
  const [windDrift, setWindDrift] = useState<boolean>(currentFog.windDrift);
  const [windSpeed, setWindSpeed] = useState<number>(currentFog.windSpeed);

  const [activeTab, setActiveTab] = useState<'density' | 'height' | 'skybox'>('density');
  const [selectedPreset, setSelectedPreset] = useState<string>('morning_mist');

  // Preview canvas
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number | null>(null);

  // Sync when active scene changes (preferring canonical Environment GameNode)
  useEffect(() => {
    const envNode = activeScene ? (
      (activeScene.environmentNodeId && activeScene.nodes[activeScene.environmentNodeId]) ||
      Object.values(activeScene.nodes).find((n) => n.type === 'Environment')
    ) : undefined;
    const p = envNode?.properties;

    const toHex = (c: any, fallback: string): string => {
      if (!c) return fallback;
      if (typeof c === 'string') return c.startsWith('#') ? c : `#${c}`;
      if (typeof c.r === 'number' && typeof c.g === 'number' && typeof c.b === 'number') {
        const f = (n: number) => Math.round(Math.max(0, Math.min(1, n)) * 255).toString(16).padStart(2, '0');
        return `#${f(c.r)}${f(c.g)}${f(c.b)}`;
      }
      return fallback;
    };

    if (p && p.fogEnabled !== undefined) {
      setEnabled(Boolean(p.fogEnabled));
      if (p.fogMode) setMode(p.fogMode);
      if (p.fogColor) setColor(toHex(p.fogColor, '#8fa4b8'));
      if (typeof p.fogDensity === 'number') setDensity(p.fogDensity);
      if (typeof p.fogNear === 'number') setNear(p.fogNear);
      if (typeof p.fogFar === 'number') setFar(p.fogFar);
    } else if (activeScene.fog) {
      setEnabled(activeScene.fog.enabled);
      setMode(activeScene.fog.mode);
      setColor(toHex(activeScene.fog.color, '#8fa4b8'));
      setDensity(activeScene.fog.density);
      setNear(activeScene.fog.near);
      setFar(activeScene.fog.far);
      setHeight(activeScene.fog.height);
      setHeightFalloff(activeScene.fog.heightFalloff);
      setAffectSkybox(activeScene.fog.affectSkybox);
      setWindDrift(activeScene.fog.windDrift);
      setWindSpeed(activeScene.fog.windSpeed);
    }
  }, [activeScene, isFogModalOpen]);

  // Apply a preset
  const applyPreset = (key: string) => {
    setSelectedPreset(key);
    const p = FOG_PRESETS[key];
    if (!p) return;
    setEnabled(true);
    setColor(p.color);
    setMode(p.mode);
    setDensity(p.density);
    setNear(p.near);
    setFar(p.far);
    setHeight(p.height);
    setHeightFalloff(p.heightFalloff);
    setAffectSkybox(p.affectSkybox);
  };

  // Approximate visibility distance
  const visibilityDistance = useMemo(() => {
    if (!enabled) return 999;
    if (mode === 'linear') return far;
    // For exp2: fog = exp2(-density * z * 1.442695) -> 95% fog threshold
    const effectiveDensity = Math.max(0.0005, density);
    const vis = Math.round(3.0 / effectiveDensity);
    return Math.min(1000, Math.max(10, vis));
  }, [enabled, mode, density, far]);

  // Real-time canvas preview
  useEffect(() => {
    if (!isFogModalOpen) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let startTime = performance.now();

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const elapsed = (performance.now() - startTime) * 0.001;
      const driftOffset = windDrift ? (elapsed * windSpeed * 25) % w : 0;

      // 1. Skybox / Background
      const skyGrad = ctx.createLinearGradient(0, 0, 0, h * 0.65);
      if (enabled && affectSkybox) {
        skyGrad.addColorStop(0, '#10141e');
        skyGrad.addColorStop(0.6, color);
        skyGrad.addColorStop(1, color);
      } else {
        skyGrad.addColorStop(0, '#131826');
        skyGrad.addColorStop(0.5, '#222b40');
        skyGrad.addColorStop(1, '#3b4967');
      }
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, w, h);

      // Sun / Moon in sky
      ctx.beginPath();
      ctx.arc(w * 0.72, h * 0.22, 18, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 245, 220, 0.4)';
      ctx.fill();

      // Helper function to calculate fog opacity at a given distance and altitude
      const calculateFogAlpha = (distMeters: number, elevationMeters: number = 0) => {
        if (!enabled) return 0;

        let distFactor = 0;
        if (mode === 'exponential2') {
          // CopperCube formula: exp2(-FogDensity * zDepth * 1.442695)
          const exponent = -density * distMeters * 1.442695;
          const visibility = Math.pow(2, exponent);
          distFactor = Math.min(1, Math.max(0, 1 - visibility));
        } else if (mode === 'exponential') {
          const visibility = Math.exp(-density * distMeters);
          distFactor = Math.min(1, Math.max(0, 1 - visibility));
        } else if (mode === 'linear') {
          distFactor = Math.min(1, Math.max(0, (distMeters - near) / Math.max(1, far - near)));
        } else {
          // Height fog / Ground mist
          const baseFog = Math.min(1, Math.max(0, (distMeters - near) / Math.max(1, far - near)));
          const altAttenuation = Math.max(0, 1 - elevationMeters / Math.max(1, height));
          distFactor = baseFog * altAttenuation;
        }

        // Apply ground height attenuation if mode is height or height falloff active
        if (mode === 'height' || elevationMeters > 0) {
          const heightFactor = Math.max(0, 1 - (elevationMeters / Math.max(1, height)) * heightFalloff);
          distFactor *= heightFactor;
        }

        return Math.min(0.98, Math.max(0, distFactor));
      };

      // 2. Far Mountains (Dist: ~300m)
      const drawMountains = (baseY: number, peakH: number, dist: number, baseColor: string) => {
        ctx.beginPath();
        ctx.moveTo(0, baseY);
        const steps = 8;
        for (let i = 0; i <= steps; i++) {
          const px = (w / steps) * i;
          const py = baseY - ((i % 2 === 1) ? peakH : peakH * 0.35);
          ctx.lineTo(px, py);
        }
        ctx.lineTo(w, baseY);
        ctx.lineTo(w, h);
        ctx.lineTo(0, h);
        ctx.closePath();

        ctx.fillStyle = baseColor;
        ctx.fill();

        // Fog layer overlay
        const fogA = calculateFogAlpha(dist, 15);
        if (fogA > 0) {
          ctx.fillStyle = color;
          ctx.globalAlpha = fogA;
          ctx.fill();
          ctx.globalAlpha = 1.0;
        }
      };

      // Far range
      drawMountains(h * 0.62, 55, 320, '#1c2436');
      // Mid range mountains
      drawMountains(h * 0.68, 40, 160, '#222d42');

      // 3. Ground Plane with perspective grid
      const groundY = h * 0.68;
      const groundGrad = ctx.createLinearGradient(0, groundY, 0, h);
      groundGrad.addColorStop(0, '#1d231e');
      groundGrad.addColorStop(1, '#111512');
      ctx.fillStyle = groundGrad;
      ctx.fillRect(0, groundY, w, h - groundY);

      // Ground grid lines
      ctx.strokeStyle = 'rgba(70, 90, 80, 0.2)';
      ctx.lineWidth = 1;
      const numLines = 9;
      for (let i = 0; i < numLines; i++) {
        const t = i / (numLines - 1);
        const y = groundY + Math.pow(t, 2) * (h - groundY);
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Ground fog gradient over the floor
      const floorFogA = calculateFogAlpha(80, 2);
      if (floorFogA > 0) {
        const floorGrad = ctx.createLinearGradient(0, groundY, 0, h);
        floorGrad.addColorStop(0, color);
        floorGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = floorGrad;
        ctx.globalAlpha = floorFogA * 0.85;
        ctx.fillRect(0, groundY, w, h - groundY);
        ctx.globalAlpha = 1.0;
      }

      // 4. Scenery 3D Objects at different depth planes:
      // Object A: Distant Tree/Tower (Dist ~180m)
      const drawTree = (x: number, y: number, scale: number, dist: number) => {
        // Trunk
        ctx.fillStyle = '#2b231d';
        ctx.fillRect(x - 2 * scale, y - 28 * scale, 4 * scale, 28 * scale);
        // Foliage
        ctx.beginPath();
        ctx.arc(x, y - 32 * scale, 14 * scale, 0, Math.PI * 2);
        ctx.fillStyle = '#233827';
        ctx.fill();

        // Fog overlay on this object
        const fogA = calculateFogAlpha(dist, 5 * scale);
        if (fogA > 0) {
          ctx.beginPath();
          ctx.arc(x, y - 32 * scale, 14 * scale, 0, Math.PI * 2);
          ctx.rect(x - 2 * scale, y - 28 * scale, 4 * scale, 28 * scale);
          ctx.fillStyle = color;
          ctx.globalAlpha = fogA;
          ctx.fill();
          ctx.globalAlpha = 1.0;
        }
      };

      // Distant trees
      drawTree(w * 0.2, groundY + 12, 0.45, 180);
      drawTree(w * 0.28, groundY + 15, 0.5, 150);
      drawTree(w * 0.8, groundY + 18, 0.6, 120);

      // Midground pillar/cube (Dist ~70m)
      const midX = w * 0.45;
      const midY = groundY + 45;
      ctx.fillStyle = '#39465e';
      ctx.fillRect(midX - 16, midY - 48, 32, 48);
      ctx.fillStyle = '#4c5c7a';
      ctx.fillRect(midX - 16, midY - 48, 14, 48);

      const midFogA = calculateFogAlpha(70, 4);
      if (midFogA > 0) {
        ctx.fillStyle = color;
        ctx.globalAlpha = midFogA;
        ctx.fillRect(midX - 16, midY - 48, 32, 48);
        ctx.globalAlpha = 1.0;
      }

      // Foreground prominent Tree (Dist ~15m)
      drawTree(w * 0.82, h - 8, 1.3, 15);
      // Foreground crate (Dist ~10m)
      ctx.fillStyle = '#443425';
      ctx.fillRect(w * 0.12, h - 35, 28, 28);
      ctx.fillStyle = '#654f3a';
      ctx.fillRect(w * 0.12, h - 35, 12, 28);

      const fgFogA = calculateFogAlpha(10, 1);
      if (fgFogA > 0) {
        ctx.fillStyle = color;
        ctx.globalAlpha = fgFogA;
        ctx.fillRect(w * 0.12, h - 35, 28, 28);
        ctx.globalAlpha = 1.0;
      }

      // 5. Animated Wind Mist Puff Overlay (Volumetric Billboard Fog Drift)
      if (enabled && windDrift) {
        ctx.save();
        ctx.globalAlpha = 0.18;
        ctx.fillStyle = color;

        // Draw flowing mist clouds along the ground
        for (let i = -1; i <= 2; i++) {
          const mx = ((i * 140 + driftOffset) % (w + 140)) - 70;
          const my = groundY + Math.sin(elapsed + i) * 6 + 10;
          ctx.beginPath();
          ctx.ellipse(mx, my, 80, 22, 0, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      // 6. Fog Status & Formula Tag on Canvas
      ctx.fillStyle = 'rgba(10, 13, 20, 0.75)';
      ctx.fillRect(10, 10, w - 20, 24);
      ctx.strokeStyle = 'rgba(45, 55, 75, 0.8)';
      ctx.strokeRect(10, 10, w - 20, 24);

      ctx.fillStyle = enabled ? '#4ade80' : '#94a3b8';
      ctx.font = '10px monospace';
      const statusText = enabled
        ? `FOG ON | Mode: ${mode.toUpperCase()} | Vis: ~${visibilityDistance}m`
        : 'FOG DISABLED (Scene Atmosphere Inactive)';
      ctx.fillText(statusText, 18, 26);

      if (windDrift) {
        animFrameRef.current = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [
    isFogModalOpen,
    enabled,
    mode,
    color,
    density,
    near,
    far,
    height,
    heightFalloff,
    affectSkybox,
    windDrift,
    windSpeed,
    visibilityDistance,
  ]);

  if (!isFogModalOpen) return null;

  // Apply to active scene
  const handleApply = () => {
    const updatedSettings: SceneFogSettings = {
      enabled,
      mode,
      color,
      density,
      near,
      far,
      height,
      heightFalloff,
      affectSkybox,
      windDrift,
      windSpeed,
    };

    updateSceneFog(updatedSettings);
    addLog(
      'log',
      `Applied Fog to "${activeScene.name}": ${enabled ? `Enabled (${mode}, Color: ${color}, Density: ${density})` : 'Disabled'}`
    );
    setIsFogModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 select-none animate-in fade-in duration-150">
      <div className="bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-4xl h-[90vh] max-h-[760px] flex flex-col overflow-hidden text-sm text-[#d4dbe8]">
        {/* Header */}
        <div className="px-5 py-3.5 bg-[#141720] border-b border-[#242b3b] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-sky-500/10 border border-sky-500/20 text-sky-400">
              <CloudFog className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-semibold text-white text-base">
                  Fog & Atmosphere Settings (Névoa da Cena)
                </h2>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-sky-950 text-sky-300 border border-sky-800">
                  CopperCube Standard
                </span>
              </div>
              <p className="text-xs text-[#828f9f] mt-0.5">
                Controle a névoa de distância exponencial, neblina de solo e desvanecimento do horizonte
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="https://www.ambiera.com/coppercube/doc/cnt_fog.html"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 text-xs text-[#828f9f] hover:text-[#c5d0e2] hover:bg-[#202636] border border-transparent hover:border-[#2f394c] rounded flex items-center gap-1.5 transition-colors"
              title="Documentação Oficial CopperCube"
            >
              <span>Doc</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={() => setIsFogModalOpen(false)}
              className="p-1.5 text-[#828f9f] hover:text-white hover:bg-[#252c3c] rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Atmosphere Presets Quick Toolbar */}
        <div className="px-5 py-2.5 bg-[#12151d] border-b border-[#202636] flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-[11px] font-semibold text-[#6d7a8d] uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" /> Presets:
          </span>
          {Object.keys(FOG_PRESETS).map((key) => {
            const p = FOG_PRESETS[key];
            const isSelected = selectedPreset === key;
            return (
              <button
                key={key}
                onClick={() => applyPreset(key)}
                className={`px-2.5 py-1 text-xs rounded-md border flex items-center gap-1.5 shrink-0 transition-all ${
                  isSelected
                    ? 'bg-sky-500/20 border-sky-500/50 text-sky-300 font-medium shadow-sm shadow-sky-950'
                    : 'bg-[#181c26] border-[#262e3e] text-[#8e9cb0] hover:text-[#dfe4ec] hover:border-[#384358]'
                }`}
              >
                <div
                  className="w-2.5 h-2.5 rounded-full border border-black/40"
                  style={{ backgroundColor: p.color }}
                />
                <span>{p.name.split(' ')[0]}</span>
                {isSelected && <Check className="w-3 h-3 text-sky-400" />}
              </button>
            );
          })}
        </div>

        {/* Main Content: Two Columns */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Column: Configuration Controls */}
          <div className="w-[56%] border-r border-[#242b3b] flex flex-col bg-[#161a24]">
            {/* Master Toggle Banner */}
            <div className="p-4 bg-[#131722] border-b border-[#222838] flex items-center justify-between">
              <div>
                <div className="font-semibold text-white flex items-center gap-2">
                  <CloudFog className="w-4 h-4 text-sky-400" />
                  <span>Habilitar Névoa na Cena (Enable Fog)</span>
                </div>
                <p className="text-[11px] text-[#79879c] mt-0.5">
                  Ativa a equação de renderização volumétrica atmosférica na cena ativa
                </p>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={enabled}
                  onChange={(e) => setEnabled(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-[#252c3c] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-sky-500"></div>
              </label>
            </div>

            {/* Category Tabs */}
            <div className="flex border-b border-[#222838] bg-[#141721] px-3 pt-2 gap-1 shrink-0">
              <button
                onClick={() => setActiveTab('density')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'density'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Sliders className="w-3.5 h-3.5 text-sky-400" />
                <span>Densidade & Distância</span>
              </button>

              <button
                onClick={() => setActiveTab('height')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'height'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-emerald-400" />
                <span>Neblina de Solo (Height Mist)</span>
              </button>

              <button
                onClick={() => setActiveTab('skybox')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'skybox'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>Skybox & Shaders</span>
              </button>
            </div>

            {/* Form Fields Scrollable */}
            <div
              className={`flex-1 overflow-y-auto p-5 space-y-4 text-xs text-[#a9b6c8] transition-opacity ${
                enabled ? 'opacity-100' : 'opacity-40 pointer-events-none'
              }`}
            >
              {/* TAB 1: DENSITY & COLOR */}
              {activeTab === 'density' && (
                <div className="space-y-4">
                  {/* Mode / Formula */}
                  <div>
                    <label className="text-white font-medium block mb-1.5">
                      Fórmula de Cálculo da Névoa (Fog Formula)
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => setMode('exponential2')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          mode === 'exponential2'
                            ? 'bg-sky-500/15 border-sky-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center justify-between">
                          <span>Exponential Squared</span>
                          {mode === 'exponential2' && <Check className="w-3.5 h-3.5 text-sky-400" />}
                        </div>
                        <div className="text-[10px] text-[#718096] font-mono mt-1">
                          exp2(-density * z * 1.44) (Padrão CopperCube)
                        </div>
                      </button>

                      <button
                        onClick={() => setMode('exponential')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          mode === 'exponential'
                            ? 'bg-sky-500/15 border-sky-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center justify-between">
                          <span>Exponential (exp)</span>
                          {mode === 'exponential' && <Check className="w-3.5 h-3.5 text-sky-400" />}
                        </div>
                        <div className="text-[10px] text-[#718096] font-mono mt-1">
                          exp(-density * zDepth)
                        </div>
                      </button>

                      <button
                        onClick={() => setMode('linear')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          mode === 'linear'
                            ? 'bg-sky-500/15 border-sky-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center justify-between">
                          <span>Linear Fog (Near / Far)</span>
                          {mode === 'linear' && <Check className="w-3.5 h-3.5 text-sky-400" />}
                        </div>
                        <div className="text-[10px] text-[#718096] font-mono mt-1">
                          (z - near) / (far - near)
                        </div>
                      </button>

                      <button
                        onClick={() => setMode('height')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          mode === 'height'
                            ? 'bg-sky-500/15 border-sky-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center justify-between">
                          <span>Ground Height Mist</span>
                          {mode === 'height' && <Check className="w-3.5 h-3.5 text-sky-400" />}
                        </div>
                        <div className="text-[10px] text-[#718096] font-mono mt-1">
                          Névoa densa rente ao solo com teto
                        </div>
                      </button>
                    </div>
                  </div>

                  {/* Fog Color */}
                  <div className="p-3 bg-[#131722] border border-[#232a3a] rounded-lg space-y-2">
                    <label className="text-white font-medium block">
                      Cor da Névoa (Fog Color / Tint)
                    </label>
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        value={color}
                        onChange={(e) => setColor(e.target.value)}
                        className="w-10 h-10 rounded border border-[#2b3345] bg-transparent cursor-pointer p-0.5 shrink-0"
                      />
                      <input
                        type="text"
                        value={color}
                        onChange={(e) => setColor(e.target.value)}
                        className="flex-1 bg-[#1b202c] border border-[#2c3447] rounded px-3 py-2 text-white font-mono text-xs uppercase"
                      />
                    </div>
                    {/* Quick Swatches */}
                    <div className="flex items-center gap-1.5 pt-1">
                      <span className="text-[10px] text-[#6d7a8d] mr-1">Rápido:</span>
                      {['#9cb5c9', '#4e5b52', '#d48856', '#151c27', '#c49a6c', '#e4ebf2', '#6c4b82', '#ffffff'].map(
                        (swatch) => (
                          <button
                            key={swatch}
                            onClick={() => setColor(swatch)}
                            className="w-5 h-5 rounded border border-[#3b475f] transition-transform hover:scale-110"
                            style={{ backgroundColor: swatch }}
                            title={swatch}
                          />
                        )
                      )}
                    </div>
                  </div>

                  {/* Density Sliders (Exponential) */}
                  {(mode === 'exponential2' || mode === 'exponential') && (
                    <div className="p-3 bg-[#131722] border border-[#232a3a] rounded-lg space-y-3">
                      <div>
                        <div className="flex justify-between mb-1">
                          <label className="text-white font-medium">Fog Density (Densidade)</label>
                          <span className="font-mono text-sky-400 font-semibold">{density.toFixed(4)}</span>
                        </div>
                        <input
                          type="range"
                          min="0.001"
                          max="0.05"
                          step="0.0005"
                          value={density}
                          onChange={(e) => setDensity(parseFloat(e.target.value))}
                          className="w-full accent-sky-500"
                        />
                        <div className="flex justify-between text-[10px] text-[#6c798c] mt-0.5">
                          <span>0.001 (Leve / Ar Raro)</span>
                          <span>0.02 (Médio)</span>
                          <span>0.05 (Muito Denso)</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1 border-t border-[#202737] text-xs">
                        <span className="text-[#8492a5]">Alcance Visual Estimado:</span>
                        <span className="font-mono text-white font-semibold">~{visibilityDistance} metros</span>
                      </div>
                    </div>
                  )}

                  {/* Linear Near & Far Sliders */}
                  {(mode === 'linear' || mode === 'height') && (
                    <div className="p-3 bg-[#131722] border border-[#232a3a] rounded-lg space-y-3">
                      <div>
                        <div className="flex justify-between mb-1">
                          <label className="text-white font-medium">Near Distance (Início da Névoa)</label>
                          <span className="font-mono text-sky-400">{near}m</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="150"
                          step="5"
                          value={near}
                          onChange={(e) => setNear(parseInt(e.target.value))}
                          className="w-full accent-sky-500"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between mb-1">
                          <label className="text-white font-medium">Far Distance (Limite de Visibilidade)</label>
                          <span className="font-mono text-sky-400">{far}m</span>
                        </div>
                        <input
                          type="range"
                          min="20"
                          max="800"
                          step="10"
                          value={far}
                          onChange={(e) => setFar(parseInt(e.target.value))}
                          className="w-full accent-sky-500"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: HEIGHT MIST */}
              {activeTab === 'height' && (
                <div className="space-y-4">
                  <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg">
                    <h3 className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
                      <Layers className="w-4 h-4 text-emerald-400" />
                      Neblina Rasteira e Altitude (Ground Height Mist)
                    </h3>
                    <p className="text-[11px] text-[#788496]">
                      Permite concentrar a névoa nos vales e rente ao solo, mantendo o topo das montanhas nítidos.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Teto de Altitude (Height Ceiling)</label>
                        <span className="font-mono text-emerald-400">{height}m</span>
                      </div>
                      <input
                        type="range"
                        min="2"
                        max="80"
                        step="2"
                        value={height}
                        onChange={(e) => setHeight(parseInt(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                      <span className="text-[10px] text-[#6b788a]">
                        Acima desta elevação a névoa se dissipa gradualmente.
                      </span>
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-[#c4cfdf] font-medium">Gradiente de Queda (Falloff)</label>
                        <span className="font-mono text-emerald-400">{heightFalloff.toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min="0.1"
                        max="2.0"
                        step="0.05"
                        value={heightFalloff}
                        onChange={(e) => setHeightFalloff(parseFloat(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                      <span className="text-[10px] text-[#6b788a]">
                        Taxa de atenuação conforme o objeto sobe no relevo.
                      </span>
                    </div>
                  </div>

                  {/* Wind Drift Simulation */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-3">
                    <div className="flex items-center justify-between pb-2 border-b border-[#212737]">
                      <div>
                        <div className="font-semibold text-white flex items-center gap-2">
                          <Wind className="w-4 h-4 text-cyan-400" />
                          <span>Simulação de Vento e Deriva da Bruma (Wind Drift)</span>
                        </div>
                        <p className="text-[10px] text-[#7c889a] mt-0.5">
                          Move suavemente as nuvens de névoa rasteira na horizontal
                        </p>
                      </div>
                      <input
                        type="checkbox"
                        checked={windDrift}
                        onChange={(e) => setWindDrift(e.target.checked)}
                        className="rounded border-[#2c3447] bg-[#1a1f2b] text-cyan-500 focus:ring-0 cursor-pointer"
                      />
                    </div>

                    {windDrift && (
                      <div>
                        <div className="flex justify-between mb-1">
                          <label className="text-[#c4cfdf] font-medium">Velocidade da Deriva</label>
                          <span className="font-mono text-cyan-400">{windSpeed.toFixed(1)}x</span>
                        </div>
                        <input
                          type="range"
                          min="0.1"
                          max="2.5"
                          step="0.1"
                          value={windSpeed}
                          onChange={(e) => setWindSpeed(parseFloat(e.target.value))}
                          className="w-full accent-cyan-500"
                        />
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 3: SKYBOX & SHADERS */}
              {activeTab === 'skybox' && (
                <div className="space-y-4">
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-white flex items-center gap-2">
                          <Sun className="w-4 h-4 text-amber-400" />
                          <span>Mesclar com Skybox / Fundo da Cena</span>
                        </div>
                        <p className="text-[10px] text-[#7c889a] mt-0.5">
                          Aplica a tonalidade da névoa no céu para ocultar o corte de renderização distante (Clipping Plane).
                        </p>
                      </div>
                      <input
                        type="checkbox"
                        checked={affectSkybox}
                        onChange={(e) => setAffectSkybox(e.target.checked)}
                        className="rounded border-[#2c3447] bg-[#1a1f2b] text-amber-500 focus:ring-0 cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* CopperCube Normal Map Callout Note */}
                  <div className="p-3 bg-[#131b2c] border border-blue-500/30 rounded-lg flex items-start gap-2.5 text-xs text-blue-200">
                    <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-white block mb-0.5">
                        Nota Técnica do CopperCube Engine:
                      </span>
                      <span>
                        No CopperCube original, a renderização de névoa é calculada por vértice na maioria dos shaders. Materiais configurados com <strong>Normal Maps</strong> desabilitam a névoa nativa no objeto para evitar artefatos de iluminação tangente.
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-2">
                    <span className="font-semibold text-white text-xs block">
                      Aplicações Comuns de Névoa:
                    </span>
                    <ul className="list-disc list-inside space-y-1 text-[11px] text-[#8391a3]">
                      <li>Ocultar o limite de carregamento de chunks ou terreno grande (draw distance).</li>
                      <li>Criar atmosfera imersiva de horror, suspense ou manhãs frescas.</li>
                      <li>Estilo retrô nostálgico inspirado em clássicos de PS1 / Nintendo 64.</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Live 2.5D / 3D Canvas Preview */}
          <div className="w-[44%] flex flex-col bg-[#11141c]">
            {/* Canvas Header Toolbar */}
            <div className="px-3.5 py-2.5 bg-[#141822] border-b border-[#212737] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Eye className="w-3.5 h-3.5 text-sky-400" />
                <span className="text-xs font-medium text-white">Preview de Profundidade em Tempo Real</span>
              </div>
              <span className="text-[10px] text-[#718096] font-mono">
                {enabled ? 'Shader: Ativo' : 'Shader: Desligado'}
              </span>
            </div>

            {/* Interactive Preview Canvas */}
            <div className="flex-1 relative flex items-center justify-center p-2 bg-[#0c0e14] overflow-hidden">
              <canvas
                ref={canvasRef}
                width={380}
                height={380}
                className="w-full h-full max-h-[420px] object-contain rounded-md"
              />
            </div>

            {/* Distance Gradient Falloff Bar */}
            <div className="p-3 bg-[#141822] border-t border-[#212737] space-y-2 shrink-0 text-xs">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-[#728094] uppercase tracking-wider font-semibold">Gradiente de Visibilidade</span>
                <span className="font-mono text-sky-400">{visibilityDistance}m max</span>
              </div>

              {/* Visual falloff bar */}
              <div className="h-4 rounded border border-[#2b3345] overflow-hidden flex relative">
                <div
                  className="h-full transition-all"
                  style={{
                    width: '100%',
                    background: enabled
                      ? `linear-gradient(to right, #243048 0%, ${color} 100%)`
                      : '#1e2638',
                  }}
                />
                <span className="absolute inset-0 flex items-center justify-between px-2 text-[9px] font-mono text-white/80">
                  <span>0m (Clear)</span>
                  <span>50%</span>
                  <span>100% (Full Fog)</span>
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-[#13161f] border-t border-[#232938] flex items-center justify-between shrink-0">
          <button
            onClick={() => {
              const def = DEFAULT_SCENE_FOG;
              setEnabled(def.enabled);
              setMode(def.mode);
              setColor(def.color);
              setDensity(def.density);
              setNear(def.near);
              setFar(def.far);
              setHeight(def.height);
              setHeightFalloff(def.heightFalloff);
              setAffectSkybox(def.affectSkybox);
              setWindDrift(def.windDrift);
              setWindSpeed(def.windSpeed);
            }}
            className="px-2.5 py-1.5 text-xs text-[#7d8c9e] hover:text-[#d3dce9] transition-colors"
          >
            Restaurar Padrões
          </button>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setIsFogModalOpen(false)}
              className="px-4 py-1.5 text-xs font-medium text-[#92a1b5] hover:text-white hover:bg-[#202636] border border-transparent hover:border-[#2f384a] rounded-lg transition-colors"
            >
              Cancelar
            </button>

            <button
              onClick={handleApply}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-lg shadow-lg shadow-sky-950 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <CloudFog className="w-4 h-4" />
              <span>Aplicar Névoa na Cena</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
