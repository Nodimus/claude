import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useEditor } from '../../core/EditorContext';
import {
  Volume2,
  VolumeX,
  Volume1,
  Play,
  Pause,
  Square,
  Repeat,
  Radio,
  Sliders,
  Sparkles,
  X,
  RotateCcw,
  Check,
  Eye,
  Info,
  ExternalLink,
  Compass,
  Layers,
  Music,
  Headphones,
  Upload,
  RefreshCw,
  FolderOpen,
  Waves,
} from 'lucide-react';

export type SoundPlayMode = 'loop' | 'once' | 'random';
export type SoundChannel = 'Master' | 'Music' | 'SFX' | 'Ambience';
export type AttenuationModel = 'inverse' | 'linear' | 'exponential';
export type SoundFXType = 'none' | 'reverb' | 'echo' | 'lowpass' | 'distortion';

export interface SoundPresetSample {
  id: string;
  name: string;
  category: SoundChannel;
  path: string;
  is2D: boolean;
  volume: number;
  pitch: number;
  playMode: SoundPlayMode;
  minDist: number;
  maxDist: number;
  duration: number; // in seconds
  description: string;
}

const SOUND_PRESETS: SoundPresetSample[] = [
  {
    id: 'theme_adventure',
    name: 'Theme Adventure (BGM)',
    category: 'Music',
    path: 'res://audio/theme_adventure.ogg',
    is2D: true,
    volume: 75,
    pitch: 1.0,
    playMode: 'loop',
    minDist: 10,
    maxDist: 50,
    duration: 84,
    description: 'Trilha sonora orquestral 2D global de fundo sem atenuação espacial.',
  },
  {
    id: 'campfire_spatial',
    name: 'Campfire (Fogueira 3D)',
    category: 'Ambience',
    path: 'res://audio/campfire_crackling.wav',
    is2D: false,
    volume: 90,
    pitch: 1.0,
    playMode: 'loop',
    minDist: 3.5,
    maxDist: 22,
    duration: 16,
    description: 'Som posicional 3D de fogueira crepitando com raio de atenuação suave.',
  },
  {
    id: 'waterfall_3d',
    name: 'Waterfall (Cachoeira 3D)',
    category: 'Ambience',
    path: 'res://audio/waterfall_ambient.ogg',
    is2D: false,
    volume: 85,
    pitch: 0.95,
    playMode: 'loop',
    minDist: 6.0,
    maxDist: 45,
    duration: 32,
    description: 'Som volumoso de água corrente com alcance médio-longo.',
  },
  {
    id: 'footsteps_grass',
    name: 'Footsteps (Passos na Grama)',
    category: 'SFX',
    path: 'res://audio/footsteps_grass.wav',
    is2D: true,
    volume: 70,
    pitch: 1.05,
    playMode: 'once',
    minDist: 2,
    maxDist: 12,
    duration: 1.2,
    description: 'Efeito sonoro de passos com variação sutil de afinação.',
  },
  {
    id: 'sword_clash',
    name: 'Sword Slash (Espada)',
    category: 'SFX',
    path: 'res://audio/sword_clash.wav',
    is2D: false,
    volume: 95,
    pitch: 1.0,
    playMode: 'once',
    minDist: 4,
    maxDist: 18,
    duration: 0.9,
    description: 'Impacto metálico rápido com alta prioridade de disparo.',
  },
  {
    id: 'thunder_random',
    name: 'Thunder (Trovão Aleatório)',
    category: 'Ambience',
    path: 'res://audio/ambient_thunder.ogg',
    is2D: false,
    volume: 90,
    pitch: 0.85,
    playMode: 'random',
    minDist: 15,
    maxDist: 90,
    duration: 5.5,
    description: 'Disparado em intervalos aleatórios para criar tensão climática.',
  },
];

export const SoundModal: React.FC = () => {
  const {
    isSoundModalOpen,
    setIsSoundModalOpen,
    activeScene,
    addNode,
    selectNode,
    addLog,
  } = useEditor();

  const [activeTab, setActiveTab] = useState<'playback' | 'spatial' | 'fx'>('playback');

  // Node & file configuration
  const [nodeName, setNodeName] = useState<string>('Audio_Ambient_01');
  const [soundPath, setSoundPath] = useState<string>('res://audio/campfire_crackling.wav');
  const [is2D, setIs2D] = useState<boolean>(false); // PlayAs2D in CopperCube
  const [playMode, setPlayMode] = useState<SoundPlayMode>('loop');
  const [channel, setChannel] = useState<SoundChannel>('Ambience');
  const [autoplay, setAutoplay] = useState<boolean>(true);
  const [paused, setPaused] = useState<boolean>(false);

  // Volume & Pitch
  const [volume, setVolume] = useState<number>(85); // 0-100%
  const [pitch, setPitch] = useState<number>(1.0); // 0.2 - 2.5
  const [randomPitchVariation, setRandomPitchVariation] = useState<number>(0.05); // +/- 5%
  const [randomWaitTimeMin, setRandomWaitTimeMin] = useState<number>(6); // sec
  const [randomWaitTimeMax, setRandomWaitTimeMax] = useState<number>(18); // sec

  // 3D Spatial Attenuation (When !is2D)
  const [posX, setPosX] = useState<number>(0);
  const [posY, setPosY] = useState<number>(1.2);
  const [posZ, setPosZ] = useState<number>(0);
  const [minDist, setMinDist] = useState<number>(4.0); // Inner Radius (Max volume)
  const [maxDist, setMaxDist] = useState<number>(25.0); // Outer Radius (Cutoff)
  const [attenuation, setAttenuation] = useState<AttenuationModel>('inverse');
  const [dopplerEffect, setDopplerEffect] = useState<boolean>(false);

  // Sound FX (CopperCube 6 irrKlang SoundFX)
  const [soundFX, setSoundFX] = useState<SoundFXType>('none');
  const [fxGain, setFxGain] = useState<number>(40); // 0-100%
  const [fxRoomSize, setFxRoomSize] = useState<number>(65);

  // Interactive Player & Visualizer State
  const [isPlayingPreview, setIsPlayingPreview] = useState<boolean>(false);
  const [playbackProgress, setPlaybackProgress] = useState<number>(0.2); // 0.0 - 1.0
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [trackDuration, setTrackDuration] = useState<number>(16.0); // seconds

  // Simulated Listener Position for Radar
  const [listenerDist, setListenerDist] = useState<number>(8.5); // meters from source
  const [listenerAngle, setListenerAngle] = useState<number>(45); // degrees

  // Canvas refs
  const waveformCanvasRef = useRef<HTMLCanvasElement>(null);
  const radarCanvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number | null>(null);

  // Apply preset
  const applyPreset = (preset: SoundPresetSample) => {
    setSoundPath(preset.path);
    setNodeName(`Audio_${preset.name.split(' ')[0]}_${preset.is2D ? '2D' : '3D'}`);
    setIs2D(preset.is2D);
    setVolume(preset.volume);
    setPitch(preset.pitch);
    setPlayMode(preset.playMode);
    setMinDist(preset.minDist);
    setMaxDist(preset.maxDist);
    setChannel(preset.category);
    setTrackDuration(preset.duration);
    setPlaybackProgress(0);
  };

  // Calculate current effective volume perceived by listener in 3D
  const calculatedPerceivedVolume = useMemo(() => {
    if (isMuted || volume === 0) return 0;
    if (is2D) return volume;
    if (listenerDist <= minDist) return volume;
    if (listenerDist >= maxDist) return 0;

    let factor = 1.0;
    if (attenuation === 'linear') {
      factor = 1.0 - (listenerDist - minDist) / Math.max(0.1, maxDist - minDist);
    } else if (attenuation === 'inverse') {
      factor = minDist / (minDist + (listenerDist - minDist));
    } else {
      // exponential
      factor = Math.pow(1.0 - (listenerDist - minDist) / Math.max(0.1, maxDist - minDist), 2);
    }

    return Math.round(volume * Math.max(0, Math.min(1, factor)));
  }, [isMuted, volume, is2D, listenerDist, minDist, maxDist, attenuation]);

  // Audio Waveform & VU Meter Rendering Loop
  useEffect(() => {
    if (!isSoundModalOpen) return;
    const canvas = waveformCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let startTime = performance.now();

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const elapsed = (performance.now() - startTime) * 0.001;

      // Advance simulated progress if playing
      if (isPlayingPreview) {
        setPlaybackProgress((prev) => (prev + 0.003) % 1.0);
      }

      // Background gradient
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, '#10141d');
      bgGrad.addColorStop(1, '#0c0f16');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // Center reference line
      const centerY = h * 0.5;
      ctx.strokeStyle = 'rgba(40, 50, 70, 0.4)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, centerY);
      ctx.lineTo(w, centerY);
      ctx.stroke();

      // Frequency / Waveform Bars
      const numBars = 48;
      const barW = (w - (numBars - 1) * 2) / numBars;
      const effectiveVol = isPlayingPreview ? (isMuted ? 0 : volume / 100) : 0.08;

      for (let i = 0; i < numBars; i++) {
        const norm = i / numBars;
        // Animated frequency amplitude
        const wave = Math.sin(norm * 14 + elapsed * 6 * pitch) * Math.cos(norm * 8 - elapsed * 3);
        const noise = Math.sin(i * 99 + elapsed * 12) * 0.3;
        const amplitude = Math.abs(wave + noise) * (h * 0.42) * effectiveVol;

        const bx = i * (barW + 2);
        const by = centerY - amplitude;
        const bh = amplitude * 2;

        // Color gradient: cyan to purple/pink
        const barGrad = ctx.createLinearGradient(0, centerY - amplitude, 0, centerY + amplitude);
        if (norm <= playbackProgress && isPlayingPreview) {
          barGrad.addColorStop(0, '#38bdf8');
          barGrad.addColorStop(0.5, '#818cf8');
          barGrad.addColorStop(1, '#c084fc');
        } else {
          barGrad.addColorStop(0, 'rgba(56, 189, 248, 0.25)');
          barGrad.addColorStop(1, 'rgba(192, 132, 252, 0.15)');
        }

        ctx.fillStyle = barGrad;
        ctx.fillRect(bx, by, barW, Math.max(2, bh));
      }

      // Playback head line
      const headX = playbackProgress * w;
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(headX, 0);
      ctx.lineTo(headX, h);
      ctx.stroke();

      if (isPlayingPreview) {
        animFrameRef.current = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isSoundModalOpen, isPlayingPreview, volume, pitch, isMuted, playbackProgress]);

  // 3D Spatial Radar Rendering
  useEffect(() => {
    if (!isSoundModalOpen || is2D) return;
    const canvas = radarCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Radar background
    ctx.fillStyle = '#0b0e14';
    ctx.fillRect(0, 0, w, h);

    const centerX = w * 0.5;
    const centerY = h * 0.5;
    const scale = (w * 0.44) / Math.max(30, maxDist * 1.15); // pixels per meter

    // Radar concentric distance rings
    ctx.strokeStyle = '#1e2838';
    ctx.lineWidth = 1;
    for (let r = 10; r <= maxDist * 1.2; r += 10) {
      ctx.beginPath();
      ctx.arc(centerX, centerY, r * scale, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Outer Max Distance Ring (Cutoff radius - Sky blue / dashed)
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
    ctx.setLineDash([4, 4]);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(centerX, centerY, maxDist * scale, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // Falloff fill area
    ctx.fillStyle = 'rgba(56, 189, 248, 0.04)';
    ctx.fill();

    // Inner Min Distance Ring (Max Volume 100% radius - Emerald Green)
    ctx.strokeStyle = '#10b981';
    ctx.fillStyle = 'rgba(16, 185, 129, 0.12)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(centerX, centerY, minDist * scale, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fill();

    // Center Crosshair (Sound Source Origin: X, Y, Z)
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(centerX - 8, centerY);
    ctx.lineTo(centerX + 8, centerY);
    ctx.moveTo(centerX, centerY - 8);
    ctx.lineTo(centerX, centerY + 8);
    ctx.stroke();

    // Sound Source Node Icon (Speaker)
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.arc(centerX, centerY, 5, 0, Math.PI * 2);
    ctx.fill();

    // Listener / Player Camera position relative to sound source
    const angleRad = (listenerAngle * Math.PI) / 180;
    const lx = centerX + Math.cos(angleRad) * (listenerDist * scale);
    const ly = centerY + Math.sin(angleRad) * (listenerDist * scale);

    // Dotted line from source to listener
    ctx.strokeStyle = calculatedPerceivedVolume > 0 ? '#10b981' : '#64748b';
    ctx.setLineDash([2, 3]);
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(lx, ly);
    ctx.stroke();
    ctx.setLineDash([]);

    // Listener Icon (Headphones indicator)
    ctx.fillStyle = calculatedPerceivedVolume > 0 ? '#34d399' : '#94a3b8';
    ctx.beginPath();
    ctx.arc(lx, ly, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Labels
    ctx.font = '9px monospace';
    ctx.fillStyle = '#10b981';
    ctx.fillText(`Min: ${minDist}m (100% Vol)`, centerX + 8, centerY - minDist * scale - 4);

    ctx.fillStyle = '#38bdf8';
    ctx.fillText(`Max: ${maxDist}m (Cutoff)`, centerX + 8, centerY - maxDist * scale - 4);

    ctx.fillStyle = '#f8fafc';
    ctx.fillText(`Ouvinte: ${listenerDist.toFixed(1)}m`, lx + 10, ly + 3);
  }, [isSoundModalOpen, is2D, minDist, maxDist, listenerDist, listenerAngle, calculatedPerceivedVolume]);

  if (!isSoundModalOpen) return null;

  // Insert Sound Node into Active Scene
  const handleInsertSound = () => {
    const parentId = activeScene.rootNodeId;
    const finalType = is2D ? 'AudioPlayer' : 'AudioPlayer3D';

    // Criação + propriedades finais num único Command (um Undo remove o nó); nada é ajustado depois.
    const newNode = addNode(finalType, parentId, nodeName, {
      stream: soundPath,
      volumeDb: Math.round(((volume - 100) / 100) * 40), // 0 to -40dB
      volumePercent: volume,
      pitchScale: pitch,
      randomPitchVariation,
      loop: playMode === 'loop',
      playMode,
      channel,
      autoplay,
      paused,
      is2D,
      unitSize: minDist,
      maxDistance: maxDist,
      attenuation,
      soundFX,
      fxGain,
      position: { x: posX, y: posY, z: posZ },
    });

    selectNode(newNode.id);
    addLog(
      'log',
      `Inserted ${is2D ? '2D Audio Player' : '3D Spatial Sound'} node "${nodeName}" (File: ${soundPath.split('/').pop()}, Volume: ${volume}%, Mode: ${playMode})`
    );

    setIsSoundModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 select-none animate-in fade-in duration-150">
      <div className="bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-5xl h-[92vh] max-h-[820px] flex flex-col overflow-hidden text-sm text-[#d4dbe8]">
        {/* Header */}
        <div className="px-5 py-3.5 bg-[#141720] border-b border-[#242b3b] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-semibold text-white text-base">
                  Sound & Audio Manager (Gerenciador de Som 2D/3D)
                </h2>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-indigo-950 text-indigo-300 border border-indigo-800">
                  CopperCube irrKlang Spec
                </span>
              </div>
              <p className="text-xs text-[#828f9f] mt-0.5">
                Configure trilhas musicais 2D, emissores de áudio espacial 3D com atenuação de distância e efeitos
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="https://www.ambiera.com/coppercube/doc/index.html"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 text-xs text-[#828f9f] hover:text-[#c5d0e2] hover:bg-[#202636] border border-transparent hover:border-[#2f394c] rounded flex items-center gap-1.5 transition-colors"
              title="CopperCube Documentation"
            >
              <span>Doc</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={() => setIsSoundModalOpen(false)}
              className="p-1.5 text-[#828f9f] hover:text-white hover:bg-[#252c3c] rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Audio Presets Quick Bar */}
        <div className="px-5 py-2.5 bg-[#12151d] border-b border-[#202636] flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-[11px] font-semibold text-[#6d7a8d] uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" /> Presets:
          </span>
          {SOUND_PRESETS.map((p) => {
            const isSelected = soundPath === p.path;
            return (
              <button
                key={p.id}
                onClick={() => applyPreset(p)}
                className={`px-2.5 py-1 text-xs rounded-md border flex items-center gap-1.5 shrink-0 transition-all ${
                  isSelected
                    ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-300 font-medium shadow-sm shadow-indigo-950'
                    : 'bg-[#181c26] border-[#262e3e] text-[#8e9cb0] hover:text-[#dfe4ec] hover:border-[#384358]'
                }`}
              >
                {p.is2D ? <Music className="w-3 h-3 text-purple-400" /> : <Radio className="w-3 h-3 text-emerald-400" />}
                <span>{p.name.split(' ')[0]}</span>
                {isSelected && <Check className="w-3 h-3 text-indigo-400" />}
              </button>
            );
          })}
        </div>

        {/* Main Content: Two Columns */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Column: Properties & Tabs */}
          <div className="w-[58%] border-r border-[#242b3b] flex flex-col bg-[#161a24]">
            {/* Category Tabs */}
            <div className="flex border-b border-[#222838] bg-[#141721] px-3 pt-2 gap-1 shrink-0">
              <button
                onClick={() => setActiveTab('playback')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'playback'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Music className="w-3.5 h-3.5 text-indigo-400" />
                <span>Reprodução & Arquivo</span>
              </button>

              <button
                onClick={() => setActiveTab('spatial')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'spatial'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Radio className="w-3.5 h-3.5 text-emerald-400" />
                <span>3D Spatial & Distância</span>
              </button>

              <button
                onClick={() => setActiveTab('fx')}
                className={`px-3 py-2 text-xs font-medium rounded-t-md border-t border-x transition-colors flex items-center gap-1.5 ${
                  activeTab === 'fx'
                    ? 'bg-[#161a24] border-[#2b3345] text-white border-b-transparent'
                    : 'border-transparent text-[#7c889a] hover:text-[#c4cfdf] hover:bg-[#1a1f2c]'
                }`}
              >
                <Waves className="w-3.5 h-3.5 text-cyan-400" />
                <span>irrKlang SoundFX</span>
              </button>
            </div>

            {/* Form Panels with Smooth Scroll */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs text-[#a9b6c8]">
              {/* TAB 1: PLAYBACK & SOURCE */}
              {activeTab === 'playback' && (
                <div className="space-y-4">
                  {/* File & Name Inputs */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-white font-medium block mb-1">Nome do Nó (Node Name)</label>
                      <input
                        type="text"
                        value={nodeName}
                        onChange={(e) => setNodeName(e.target.value)}
                        className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
                      />
                    </div>

                    <div>
                      <label className="text-white font-medium block mb-1">Canal de Áudio (Mixer Channel)</label>
                      <select
                        value={channel}
                        onChange={(e) => setChannel(e.target.value as SoundChannel)}
                        className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs focus:outline-none focus:border-indigo-500"
                      >
                        <option value="Master">Master Channel</option>
                        <option value="Music">BGM (Música de Fundo)</option>
                        <option value="Ambience">Ambience (Atmosfera)</option>
                        <option value="SFX">SFX (Efeitos Sonoros)</option>
                      </select>
                    </div>
                  </div>

                  {/* Sound File Path with Browse */}
                  <div>
                    <label className="text-white font-medium block mb-1">
                      Arquivo de Áudio (Sound File .wav, .ogg, .mp3)
                    </label>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 flex items-center justify-between">
                        <span className="font-mono text-white text-xs truncate">{soundPath}</span>
                        <span className="text-[10px] text-[#707e92] shrink-0 font-mono">
                          {soundPath.split('.').pop()?.toUpperCase()}
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          const custom = prompt('Digite o caminho virtual do áudio (ex: res://audio/meu_som.ogg):', soundPath);
                          if (custom) setSoundPath(custom);
                        }}
                        className="px-3 py-1.5 bg-[#212735] hover:bg-[#2b3346] border border-[#303a4e] text-white rounded text-xs flex items-center gap-1.5 shrink-0 transition-colors"
                      >
                        <FolderOpen className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Explorar</span>
                      </button>
                    </div>
                    <span className="text-[10px] text-[#6d7b8e] mt-1 block">
                      CopperCube suporta WAV, OGG Vorbis, MP3, MOD e XM via motor irrKlang.
                    </span>
                  </div>

                  {/* 2D vs 3D Mode (CopperCube PlayAs2D Flag) */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white flex items-center gap-2">
                        <Music className="w-4 h-4 text-purple-400" />
                        <span>Tocar como Áudio 2D Global (PlayAs2D)</span>
                      </div>
                      <p className="text-[11px] text-[#778598] mt-0.5">
                        {is2D
                          ? 'Ativado: O som toca em volume uniforme para todo o ambiente sem cálculo de distância tridimensional.'
                          : 'Desativado: O som será posicionado no espaço 3D com atenuação conforme a distância da câmera.'}
                      </p>
                    </div>

                    <label className="relative inline-flex items-center cursor-pointer shrink-0">
                      <input
                        type="checkbox"
                        checked={is2D}
                        onChange={(e) => setIs2D(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-[#252c3c] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                    </label>
                  </div>

                  {/* Play Mode Selector */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-3">
                    <label className="text-white font-medium block">
                      Modo de Reprodução (Play Mode)
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() => setPlayMode('loop')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          playMode === 'loop'
                            ? 'bg-indigo-500/20 border-indigo-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center gap-1.5">
                          <Repeat className="w-3.5 h-3.5 text-indigo-400" />
                          <span>Loop Infinito</span>
                        </div>
                        <div className="text-[10px] text-[#718096] mt-1">Repete continuamente</div>
                      </button>

                      <button
                        onClick={() => setPlayMode('once')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          playMode === 'once'
                            ? 'bg-indigo-500/20 border-indigo-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center gap-1.5">
                          <Play className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Play Once</span>
                        </div>
                        <div className="text-[10px] text-[#718096] mt-1">Toca 1 vez ao disparar</div>
                      </button>

                      <button
                        onClick={() => setPlayMode('random')}
                        className={`p-2.5 rounded-lg border text-left transition-all ${
                          playMode === 'random'
                            ? 'bg-indigo-500/20 border-indigo-500/60 text-white'
                            : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                        }`}
                      >
                        <div className="font-semibold text-xs flex items-center gap-1.5">
                          <Radio className="w-3.5 h-3.5 text-amber-400" />
                          <span>Random Interval</span>
                        </div>
                        <div className="text-[10px] text-[#718096] mt-1">Toca em pausas aleatórias</div>
                      </button>
                    </div>

                    {playMode === 'random' && (
                      <div className="pt-2 border-t border-[#232a3a] grid grid-cols-2 gap-3">
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-[#c4cfdf]">Tempo Mínimo de Espera</span>
                            <span className="font-mono text-indigo-400">{randomWaitTimeMin}s</span>
                          </div>
                          <input
                            type="range"
                            min="1"
                            max="30"
                            step="1"
                            value={randomWaitTimeMin}
                            onChange={(e) => setRandomWaitTimeMin(parseInt(e.target.value))}
                            className="w-full accent-indigo-500"
                          />
                        </div>
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-[#c4cfdf]">Tempo Máximo de Espera</span>
                            <span className="font-mono text-indigo-400">{randomWaitTimeMax}s</span>
                          </div>
                          <input
                            type="range"
                            min="5"
                            max="60"
                            step="1"
                            value={randomWaitTimeMax}
                            onChange={(e) => setRandomWaitTimeMax(parseInt(e.target.value))}
                            className="w-full accent-indigo-500"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Volume & Pitch Controls */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <label className="text-white font-medium flex items-center gap-1.5">
                            <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
                            <span>Volume</span>
                          </label>
                          <span className="font-mono text-indigo-400 font-semibold">{volume}%</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          step="1"
                          value={volume}
                          onChange={(e) => setVolume(parseInt(e.target.value))}
                          className="w-full accent-indigo-500"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between mb-1">
                          <label className="text-white font-medium">Pitch / Speed (Frequência)</label>
                          <span className="font-mono text-indigo-400 font-semibold">{pitch.toFixed(2)}x</span>
                        </div>
                        <input
                          type="range"
                          min="0.4"
                          max="2.0"
                          step="0.05"
                          value={pitch}
                          onChange={(e) => setPitch(parseFloat(e.target.value))}
                          className="w-full accent-indigo-500"
                        />
                      </div>
                    </div>

                    <div className="pt-2 border-t border-[#232a3a]">
                      <div className="flex justify-between mb-1">
                        <span className="text-[#c4cfdf]">Variação Aleatória de Afinação (+/- Pitch Jitter)</span>
                        <span className="font-mono text-indigo-400 font-semibold">
                          {(randomPitchVariation * 100).toFixed(0)}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0.0"
                        max="0.25"
                        step="0.01"
                        value={randomPitchVariation}
                        onChange={(e) => setRandomPitchVariation(parseFloat(e.target.value))}
                        className="w-full accent-indigo-500"
                      />
                      <span className="text-[10px] text-[#6d7b8e]">
                        Garante que repetições contínuas não soem robóticas ou idênticas.
                      </span>
                    </div>
                  </div>

                  {/* Autoplay & Paused flags */}
                  <div className="flex items-center gap-5 pt-1">
                    <label className="flex items-center gap-2 cursor-pointer text-[#c4cfdf]">
                      <input
                        type="checkbox"
                        checked={autoplay}
                        onChange={(e) => setAutoplay(e.target.checked)}
                        className="rounded border-[#2c3447] bg-[#1a1f2b] text-indigo-500 focus:ring-0"
                      />
                      <span>Autoplay ao iniciar cena</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer text-[#c4cfdf]">
                      <input
                        type="checkbox"
                        checked={paused}
                        onChange={(e) => setPaused(e.target.checked)}
                        className="rounded border-[#2c3447] bg-[#1a1f2b] text-indigo-500 focus:ring-0"
                      />
                      <span>Iniciar em estado pausado (Paused)</span>
                    </label>
                  </div>
                </div>
              )}

              {/* TAB 2: 3D SPATIAL & ATTENUATION */}
              {activeTab === 'spatial' && (
                <div className="space-y-4">
                  {is2D && (
                    <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg flex items-center gap-2 text-amber-200">
                      <Info className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>
                        Atenção: A opção <strong>PlayAs2D</strong> está ativa na primeira aba. Desmarque-a para habilitar o posicionamento espacial 3D em tempo real.
                      </span>
                    </div>
                  )}

                  {/* 3D Coordinate Translation */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-3">
                    <h3 className="font-semibold text-white text-sm flex items-center gap-2">
                      <Compass className="w-4 h-4 text-emerald-400" />
                      Posição do Emissor 3D (Emitter Position)
                    </h3>
                    <div className="grid grid-cols-3 gap-3 font-mono">
                      <div>
                        <label className="text-[10px] text-[#718096] uppercase block mb-1">X (Leste / Oeste)</label>
                        <input
                          type="number"
                          value={posX}
                          onChange={(e) => setPosX(parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-[#718096] uppercase block mb-1">Y (Elevação / Altura)</label>
                        <input
                          type="number"
                          value={posY}
                          onChange={(e) => setPosY(parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-[#718096] uppercase block mb-1">Z (Norte / Sul)</label>
                        <input
                          type="number"
                          value={posZ}
                          onChange={(e) => setPosZ(parseFloat(e.target.value) || 0)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Distance Attenuation Radii (Min & Max Distance) */}
                  <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-4">
                    <div className="flex items-center justify-between pb-2 border-b border-[#232a3a]">
                      <div>
                        <div className="font-semibold text-white">Raios de Atenuação (CopperCube 3D Radius)</div>
                        <p className="text-[10px] text-[#778598] mt-0.5">
                          Dentro do raio mínimo o som toca a 100%. Conforme se afasta em direção ao raio máximo, ele decai suavemente.
                        </p>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-emerald-400 font-medium">Min Distance / Inner Radius (Volume Máximo)</label>
                        <span className="font-mono text-emerald-400 font-semibold">{minDist.toFixed(1)} metros</span>
                      </div>
                      <input
                        type="range"
                        min="0.5"
                        max="30"
                        step="0.5"
                        value={minDist}
                        onChange={(e) => setMinDist(Math.min(maxDist - 1, parseFloat(e.target.value)))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <label className="text-sky-400 font-medium">Max Distance / Outer Radius (Alcance Limite)</label>
                        <span className="font-mono text-sky-400 font-semibold">{maxDist.toFixed(1)} metros</span>
                      </div>
                      <input
                        type="range"
                        min="5"
                        max="120"
                        step="1"
                        value={maxDist}
                        onChange={(e) => setMaxDist(Math.max(minDist + 1, parseFloat(e.target.value)))}
                        className="w-full accent-sky-500"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-2 border-t border-[#232a3a]">
                      <div>
                        <label className="text-white block mb-1">Modelo de Decaimento (Rolloff Curve)</label>
                        <select
                          value={attenuation}
                          onChange={(e) => setAttenuation(e.target.value as AttenuationModel)}
                          className="w-full bg-[#1b202c] border border-[#2c3447] rounded px-3 py-1.5 text-white text-xs"
                        >
                          <option value="inverse">Inverse Distance (Físico Realista)</option>
                          <option value="linear">Linear Falloff (Constante)</option>
                          <option value="exponential">Exponential (Queda Acentuada)</option>
                        </select>
                      </div>

                      <div className="flex items-center pt-4">
                        <label className="flex items-center gap-2 cursor-pointer text-[#c4cfdf]">
                          <input
                            type="checkbox"
                            checked={dopplerEffect}
                            onChange={(e) => setDopplerEffect(e.target.checked)}
                            className="rounded border-[#2c3447] bg-[#1a1f2b] text-emerald-500 focus:ring-0"
                          />
                          <span>Efeito Doppler (Velocidade)</span>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: SOUND FX & FILTERS */}
              {activeTab === 'fx' && (
                <div className="space-y-4">
                  <div className="p-3 bg-[#12151e] border border-[#232a3a] rounded-lg">
                    <h3 className="font-semibold text-white text-sm mb-1 flex items-center gap-2">
                      <Waves className="w-4 h-4 text-cyan-400" />
                      Processamento de Efeitos irrKlang (SoundFX)
                    </h3>
                    <p className="text-[11px] text-[#788496]">
                      O CopperCube 6 adicionou suporte a propriedades SoundFX e FXGain para reverberação e eco em tempo real.
                    </p>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="text-white font-medium block mb-1.5">Efeito DSP Selecionado</label>
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { id: 'none', label: 'Nenhum (Clean)' },
                          { id: 'reverb', label: 'Reverb (Ambiente)' },
                          { id: 'echo', label: 'Echo (Eco de Caverna)' },
                          { id: 'lowpass', label: 'LowPass (Abafado/Submerso)' },
                          { id: 'distortion', label: 'Distortion (Distorção)' },
                        ].map((fx) => (
                          <button
                            key={fx.id}
                            onClick={() => setSoundFX(fx.id as SoundFXType)}
                            className={`p-2.5 rounded-lg border text-left transition-all ${
                              soundFX === fx.id
                                ? 'bg-cyan-500/20 border-cyan-500/60 text-white'
                                : 'bg-[#191e2b] border-[#262f40] text-[#8e9cb0] hover:border-[#37445d]'
                            }`}
                          >
                            <span className="font-semibold text-xs">{fx.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {soundFX !== 'none' && (
                      <div className="p-3.5 bg-[#12151e] border border-[#232a3a] rounded-lg space-y-3">
                        <div>
                          <div className="flex justify-between mb-1">
                            <label className="text-white font-medium">FX Gain (Intensidade do Efeito / Wet Mix)</label>
                            <span className="font-mono text-cyan-400 font-semibold">{fxGain}%</span>
                          </div>
                          <input
                            type="range"
                            min="0"
                            max="100"
                            step="5"
                            value={fxGain}
                            onChange={(e) => setFxGain(parseInt(e.target.value))}
                            className="w-full accent-cyan-500"
                          />
                        </div>

                        {soundFX === 'reverb' && (
                          <div>
                            <div className="flex justify-between mb-1">
                              <label className="text-white font-medium">Tamanho da Sala (Room Size)</label>
                              <span className="font-mono text-cyan-400 font-semibold">{fxRoomSize}%</span>
                            </div>
                            <input
                              type="range"
                              min="10"
                              max="100"
                              step="5"
                              value={fxRoomSize}
                              onChange={(e) => setFxRoomSize(parseInt(e.target.value))}
                              className="w-full accent-cyan-500"
                            />
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Audio Waveform & Interactive 3D Radar */}
          <div className="w-[42%] flex flex-col bg-[#11141c]">
            {/* Waveform Player Section */}
            <div className="p-3.5 bg-[#141822] border-b border-[#212737] space-y-2.5 shrink-0">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Waves className="w-4 h-4 text-indigo-400" />
                  <span className="font-semibold text-white">Player & Waveform Inspector</span>
                </div>
                <span className="text-[10px] font-mono text-[#78879b]">
                  {isPlayingPreview ? 'Tocando (Simulação)' : 'Parado'}
                </span>
              </div>

              {/* Waveform Canvas */}
              <div className="h-20 bg-[#0d1017] rounded border border-[#242b3b] overflow-hidden relative">
                <canvas
                  ref={waveformCanvasRef}
                  width={340}
                  height={80}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Progress Bar & Timing */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] font-mono text-[#78879b]">
                  <span>{(trackDuration * playbackProgress).toFixed(1)}s</span>
                  <span>{trackDuration.toFixed(1)}s</span>
                </div>
                <div
                  onClick={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect();
                    const clickX = e.clientX - rect.left;
                    setPlaybackProgress(Math.max(0, Math.min(1, clickX / rect.width)));
                  }}
                  className="h-2 bg-[#1b212f] rounded-full overflow-hidden cursor-pointer relative"
                >
                  <div
                    className="h-full bg-gradient-to-r from-indigo-500 to-sky-400 transition-all"
                    style={{ width: `${playbackProgress * 100}%` }}
                  />
                </div>
              </div>

              {/* Playback Transport Buttons */}
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setIsPlayingPreview(!isPlayingPreview)}
                    className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors flex items-center gap-1.5 text-xs font-semibold px-3"
                  >
                    {isPlayingPreview ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                    <span>{isPlayingPreview ? 'Pausar' : 'Ouvir Teste'}</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsPlayingPreview(false);
                      setPlaybackProgress(0);
                    }}
                    className="p-2 rounded-lg bg-[#202737] hover:bg-[#2b3449] text-[#93a2b7] hover:text-white transition-colors"
                    title="Parar"
                  >
                    <Square className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className={`p-2 rounded-lg transition-colors ${
                      isMuted
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                        : 'bg-[#202737] text-[#93a2b7] hover:text-white'
                    }`}
                    title={isMuted ? 'Desmutar' : 'Mutar'}
                  >
                    {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                  </button>
                  <span className="font-mono text-xs text-white">{isMuted ? 'Mudo' : `${volume}%`}</span>
                </div>
              </div>
            </div>

            {/* 3D Spatial Radar & Distance Simulation */}
            <div className="flex-1 flex flex-col p-3 bg-[#0d1017] overflow-hidden">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-semibold text-white flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-sky-400" />
                  <span>Radar Acústico 3D (Posicionamento do Ouvinte)</span>
                </span>
                <span className="text-[10px] font-mono text-emerald-400">
                  Vol. Percebido: {calculatedPerceivedVolume}%
                </span>
              </div>

              {/* Radar Canvas */}
              <div className="flex-1 relative flex items-center justify-center rounded-lg border border-[#212839] overflow-hidden bg-[#0a0d14]">
                <canvas
                  ref={radarCanvasRef}
                  width={340}
                  height={220}
                  className="w-full h-full object-contain"
                />

                {is2D && (
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] flex flex-col items-center justify-center text-center p-4">
                    <Music className="w-8 h-8 text-purple-400 mb-2" />
                    <span className="text-white font-medium text-xs">Áudio 2D Global (PlayAs2D Ativo)</span>
                    <span className="text-[11px] text-[#7f8da0] mt-1 max-w-[240px]">
                      Sons 2D tocam uniformemente independente da distância da câmera.
                    </span>
                  </div>
                )}
              </div>

              {/* Interactive Listener Slider */}
              {!is2D && (
                <div className="pt-2 space-y-1.5">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#7c8b9e]">Distância do Ouvinte (Simulação):</span>
                    <span className="font-mono text-white font-semibold">{listenerDist.toFixed(1)}m</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max={maxDist * 1.3}
                    step="0.5"
                    value={listenerDist}
                    onChange={(e) => setListenerDist(parseFloat(e.target.value))}
                    className="w-full accent-emerald-500 h-1.5"
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-[#13161f] border-t border-[#232938] flex items-center justify-between shrink-0">
          <button
            onClick={() => {
              setVolume(80);
              setPitch(1.0);
              setIs2D(false);
              setPlayMode('loop');
              setMinDist(4.0);
              setMaxDist(25.0);
              setSoundFX('none');
            }}
            className="px-2.5 py-1.5 text-xs text-[#7d8c9e] hover:text-[#d3dce9] transition-colors"
          >
            Restaurar Padrões
          </button>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setIsSoundModalOpen(false)}
              className="px-4 py-1.5 text-xs font-medium text-[#92a1b5] hover:text-white hover:bg-[#202636] border border-transparent hover:border-[#2f384a] rounded-lg transition-colors"
            >
              Cancelar
            </button>

            <button
              onClick={handleInsertSound}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-lg shadow-indigo-950 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Headphones className="w-4 h-4" />
              <span>Inserir Som na Cena</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
