import React, { useEffect, useMemo, useRef, useState } from 'react';
import { LogicRegistry } from '../../logic/registry';
import type { LogicCategory, LogicDefinition, LogicKind } from '../../logic/types';

/** Itens do picker: SEMPRE do `LogicRegistry` (pastas de `src/logic/`); nenhuma lista própria da UI. */
export function listLogicDefinitions(kind: LogicKind): LogicDefinition[] {
  switch (kind) {
    case 'trigger':
      return LogicRegistry.listTriggers();
    case 'condition':
      return LogicRegistry.listConditions();
    case 'action':
      return LogicRegistry.listActions();
    case 'behavior':
      return LogicRegistry.listBehaviors();
  }
}

export const KIND_LABEL: Record<LogicKind, string> = { trigger: 'Trigger', condition: 'Condition', action: 'Action', behavior: 'Behavior' };

/** Agrupa por categoria mantendo a ordem alfabética do registry. */
export function groupByCategory(items: readonly LogicDefinition[]): [LogicCategory, LogicDefinition[]][] {
  const groups = new Map<LogicCategory, LogicDefinition[]>();
  for (const item of items) groups.set(item.category, [...(groups.get(item.category) ?? []), item]);
  return [...groups.entries()].sort(([a], [b]) => a.localeCompare(b));
}

interface LogicPickerProps {
  kind: LogicKind;
  onPick: (id: string) => void;
  /** Conteúdo do botão que abre o picker. */
  children: React.ReactNode;
  className?: string;
  title?: string;
  /** ID atual (destacado; usado ao trocar o Trigger). */
  current?: string;
  disabled?: boolean;
  'data-testid'?: string;
}

/**
 * Picker único de Trigger/Condition/Action/Behavior (AIS-39). Itens `disabled` do registry aparecem desabilitados com tooltip
 * "em breve" (decisão 14). Teclado: Esc fecha; Tab percorre os itens.
 */
export const LogicPicker: React.FC<LogicPickerProps> = ({ kind, onPick, children, className, title, current, disabled, ...rest }) => {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<{ left: number; top: number } | null>(null);
  const button = useRef<HTMLButtonElement>(null);
  const groups = useMemo(() => (open ? groupByCategory(listLogicDefinitions(kind)) : []), [open, kind]);

  useEffect(() => {
    if (!open) return;
    const rect = button.current?.getBoundingClientRect();
    if (rect) setPos({ left: Math.min(rect.left, window.innerWidth - 280), top: Math.min(rect.bottom + 4, window.innerHeight - 320) });
    const close = (e: MouseEvent | KeyboardEvent) => {
      if (e instanceof KeyboardEvent) {
        if (e.key === 'Escape') {
          e.stopPropagation();
          setOpen(false);
          button.current?.focus();
        }
      } else if (!(e.target as HTMLElement | null)?.closest('[data-logic-picker]')) setOpen(false);
    };
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', close, true);
    return () => {
      document.removeEventListener('mousedown', close);
      document.removeEventListener('keydown', close, true);
    };
  }, [open]);

  return (
    <>
      <button ref={button} type="button" disabled={disabled} onClick={() => setOpen((o) => !o)} aria-haspopup="listbox" aria-expanded={open} title={title} className={className} data-testid={rest['data-testid']}>
        {children}
      </button>
      {open && pos && (
        <div
          data-logic-picker
          role="listbox"
          aria-label={`Escolher ${KIND_LABEL[kind]}`}
          style={{ position: 'fixed', left: pos.left, top: pos.top, width: 272 }}
          className="z-[400] max-h-80 overflow-y-auto rounded-lg border border-[#2c3345] bg-[#1a1f2b] shadow-2xl py-1 text-[11px]"
        >
          {groups.length === 0 && <div className="px-3 py-2 text-[#8b97a8]">Nenhum item no registro.</div>}
          {groups.map(([category, items]) => (
            <div key={category}>
              <div className="px-3 pt-1.5 pb-0.5 text-[10px] uppercase tracking-wider text-[#68768e]">{category}</div>
              {items.map((item) => {
                const off = item.status === 'disabled';
                return (
                  <button
                    key={item.id}
                    type="button"
                    role="option"
                    aria-selected={item.id === current}
                    disabled={off}
                    title={off ? 'em breve' : item.description}
                    onClick={() => {
                      setOpen(false);
                      onPick(item.id);
                    }}
                    className={`w-full text-left px-3 py-1.5 flex flex-col disabled:opacity-40 disabled:cursor-not-allowed ${item.id === current ? 'bg-[#4982ea]/25 text-white' : 'text-[#dfe4ec] hover:bg-[#272e3d]'}`}
                  >
                    <span className="font-medium">
                      {item.label}
                      {off && <span className="ml-1.5 text-[9px] text-amber-400">em breve</span>}
                    </span>
                    <span className="text-[10px] text-[#8b97a8] truncate">{item.description}</span>
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      )}
    </>
  );
};
