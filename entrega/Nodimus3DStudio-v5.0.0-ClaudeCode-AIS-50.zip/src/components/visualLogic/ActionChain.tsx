import React, { useState } from 'react';
import {
  DndContext,
  KeyboardSensor,
  PointerSensor,
  closestCenter,
  useSensor,
  useSensors,
  type Announcements,
  type DragEndEvent,
} from '@dnd-kit/core';
import { SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { ChevronDown, ChevronUp, GripVertical, Pencil, Plus, Trash2 } from 'lucide-react';
import { LogicRegistry } from '../../logic/registry';
import type { LogicAction, LogicEventRule } from '../../types/visualLogic';
import type { BehaviorOps } from '../../core/commands/BehaviorCommands';
import { LogicPicker } from './LogicPicker';
import { ParamForm, paramValue } from './ParamFields';
import { ParamEditorDialog } from './ParamEditorDialog';
import { VariableOwnerContext, useLogicFormEnvironment } from './useLogicFormContext';
import { describeAction, validateParams } from '../../logic/paramForm';

const BTN = 'p-1 rounded text-[#68768e] hover:text-white hover:bg-[#252c3c] disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-[#68768e] disabled:cursor-not-allowed';

interface StepProps {
  /** O alvo da regra é um nó de UI: campos marcados `hideForUi` (ex.: Z) não aparecem. */
  uiTarget: boolean;
  index: number;
  count: number;
  action: LogicAction;
  expanded: boolean;
  onToggle: () => void;
  onEdit: () => void;
  onMove: (to: number) => void;
  onRemove: () => void;
  onParam: (key: string, value: unknown) => void;
  ownerNodeId?: string;
}

const Step: React.FC<StepProps> = ({ uiTarget, index, count, action, expanded, onToggle, onEdit, onMove, onRemove, onParam, ownerNodeId }) => {
  const env = useLogicFormEnvironment();
  const { attributes, listeners, setNodeRef, setActivatorNodeRef, transform, transition, isDragging } = useSortable({ id: action.id });
  const def = LogicRegistry.getAction(action.type);
  const style: React.CSSProperties = { transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1, zIndex: isDragging ? 50 : undefined };

  return (
    <div
      ref={setNodeRef}
      style={style}
      role="listitem"
      data-testid={`action-step-${index}`}
      className={`rounded border text-xs ${isDragging ? 'border-[#4982ea] ring-1 ring-[#4982ea] shadow-lg' : 'border-[#2c3345] hover:border-[#3b475f]'} bg-[#181c24]`}
    >
      <div className="flex items-center gap-2 p-2">
        <button
          type="button"
          ref={setActivatorNodeRef}
          {...attributes}
          {...listeners}
          aria-label={`Arrastar passo ${index + 1}: ${def?.label ?? action.type}`}
          title="Arrastar para reordenar (ou Espaço e setas)"
          className="cursor-grab active:cursor-grabbing text-[#68768e] hover:text-[#dfe4ec] p-0.5"
        >
          <GripVertical className="w-3.5 h-3.5" />
        </button>
        <span className="w-5 h-5 rounded-full bg-[#4982ea]/25 text-[#9db7ee] text-[10px] font-bold flex items-center justify-center shrink-0" aria-hidden="true">
          {index + 1}
        </span>
        <button
          type="button"
          onClick={onToggle}
          aria-expanded={expanded}
          onKeyDown={(e) => {
            // setas ↑/↓ com o passo focado movem o passo (mesmo Command de reordenar)
            if (e.key === 'ArrowUp' && index > 0) {
              e.preventDefault();
              onMove(index - 1);
            } else if (e.key === 'ArrowDown' && index < count - 1) {
              e.preventDefault();
              onMove(index + 1);
            }
          }}
          onDoubleClick={onEdit}
          className="flex-1 min-w-0 text-left flex flex-col"
          title="Clique para os parâmetros rápidos · duplo clique abre o diálogo · ↑/↓ movem o passo"
        >
          <span className={`font-semibold truncate ${def ? 'text-emerald-300' : 'text-amber-300'}`}>{describeAction(action.type, action.parameters, env.ctx)}</span>
          <span className="text-[10px] font-mono text-[#68768e] truncate">{action.type}</span>
        </button>
        <button type="button" onClick={onEdit} className={BTN} aria-label={`Editar parâmetros do passo ${index + 1}`} title="Editar parâmetros (diálogo)" data-testid={`edit-action-${index}`}>
          <Pencil className="w-3.5 h-3.5" />
        </button>
        <button type="button" onClick={() => onMove(index - 1)} disabled={index === 0} className={BTN} aria-label={`Mover passo ${index + 1} para cima`} title="Para cima">
          <ChevronUp className="w-3.5 h-3.5" />
        </button>
        <button type="button" onClick={() => onMove(index + 1)} disabled={index === count - 1} className={BTN} aria-label={`Mover passo ${index + 1} para baixo`} title="Para baixo">
          <ChevronDown className="w-3.5 h-3.5" />
        </button>
        <button type="button" onClick={onRemove} className={`${BTN} hover:!text-rose-400`} aria-label={`Remover passo ${index + 1}`} title="Remover Action">
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
      {expanded && (
        <div className="border-t border-[#2c3345] px-3 py-2 space-y-1.5" data-testid={`action-params-${index}`}>
          {!def ? (
            <div className="text-[11px] text-amber-300/90 space-y-1">
              <p>Action não resolvida: o ID "{action.type}" não existe neste editor. Os parâmetros são preservados.</p>
              <pre className="font-mono text-[10px] text-[#8b97a8] whitespace-pre-wrap break-all">{JSON.stringify(action.parameters, null, 2)}</pre>
            </div>
          ) : def.params.length === 0 ? (
            <p className="text-[11px] text-[#8b97a8]">Esta Action não tem parâmetros.</p>
          ) : (
            <ParamForm params={def.params} values={action.parameters} onChange={onParam} issues={validateParams(def, action.parameters, env.ctx, { hiddenKeys: new Set(def.params.filter((p) => uiTarget && p.hideForUi).map((p) => p.key)), ownerNodeId })} uiTarget={uiTarget} />
          )}
        </div>
      )}
    </div>
  );
};

/**
 * Cadeia de Actions de uma regra (AIS-39): passos numerados, reordenáveis por mouse e por teclado (@dnd-kit + ↑/↓ + ▲▼),
 * um acordeão de parâmetros por vez e o "+" tracejado como último passo. Toda mudança é um Command via `ops`.
 */
export const ActionChain: React.FC<{ behaviorId: string; rule: LogicEventRule; ops: BehaviorOps; uiTarget?: boolean }> = ({ behaviorId, rule, ops, uiTarget = false }) => {
  const owner = useLogicFormEnvironment().ownerOf(behaviorId);
  const [expandedId, setExpandedId] = useState<string | null>(null); // efêmero (não vai ao histórico)
  const [editingId, setEditingId] = useState<string | null>(null); // diálogo de parâmetros (AIS-42)
  const [announcement, setAnnouncement] = useState('');
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }), useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }));
  const ids = rule.actions.map((a) => a.id);
  const nameOf = (id: string | number) => {
    const a = rule.actions.find((x) => x.id === id);
    return a ? LogicRegistry.getAction(a.type)?.label ?? a.type : String(id);
  };

  const move = (from: number, to: number) => {
    if (to < 0 || to >= rule.actions.length || from === to) return;
    ops.reorderActions(behaviorId, rule.id, from, to);
    setAnnouncement(`${nameOf(rule.actions[from].id)} movida para a posição ${to + 1} de ${rule.actions.length}.`);
  };

  const onDragEnd = ({ active, over }: DragEndEvent) => {
    if (!over || active.id === over.id) return;
    const from = ids.indexOf(String(active.id));
    const to = ids.indexOf(String(over.id));
    if (from >= 0 && to >= 0) ops.reorderActions(behaviorId, rule.id, from, to);
  };

  const announcements: Announcements = {
    onDragStart: ({ active }) => `Pegou ${nameOf(active.id)}, posição ${ids.indexOf(String(active.id)) + 1} de ${ids.length}.`,
    onDragOver: ({ active, over }) => (over ? `${nameOf(active.id)} sobre a posição ${ids.indexOf(String(over.id)) + 1}.` : undefined),
    onDragEnd: ({ active, over }) => (over ? `${nameOf(active.id)} solta na posição ${ids.indexOf(String(over.id)) + 1} de ${ids.length}.` : `${nameOf(active.id)} solta sem mudar de lugar.`),
    onDragCancel: ({ active }) => `Reordenação de ${nameOf(active.id)} cancelada.`,
  };

  return (
    <VariableOwnerContext.Provider value={owner}>
    <div className="space-y-1.5" data-testid="action-chain">
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd} accessibility={{ announcements }}>
        <SortableContext items={ids} strategy={verticalListSortingStrategy}>
          <div role="list" aria-label="Actions em ordem de execução" className="space-y-1.5">
            {rule.actions.map((action, index) => (
              <Step
                key={action.id}
                uiTarget={uiTarget}
                index={index}
                count={rule.actions.length}
                action={action}
                expanded={expandedId === action.id}
                onToggle={() => setExpandedId((cur) => (cur === action.id ? null : action.id))}
                onEdit={() => setEditingId(action.id)}
                onMove={(to) => move(index, to)}
                onRemove={() => ops.removeAction(behaviorId, rule.id, action.id)}
                onParam={(key, value) => ops.setActionParam(behaviorId, rule.id, action.id, key, value)}
                ownerNodeId={owner}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>
      <div role="status" aria-live="polite" className="sr-only">
        {announcement}
      </div>
      {editingId && rule.actions.some((a) => a.id === editingId) && (
        <ParamEditorDialog target={{ kind: 'action', behaviorId, rule, itemId: editingId }} uiTarget={uiTarget} onClose={() => setEditingId(null)} />
      )}
      <LogicPicker
        kind="action"
        onPick={(type) => ops.addAction(behaviorId, rule.id, type)}
        title="Adicionar uma Action ao fim da lista"
        data-testid="add-action"
        className="w-full flex items-center justify-center gap-1.5 rounded border border-dashed border-[#3b475f] py-1.5 text-[11px] text-[#8b97a8] hover:text-white hover:border-[#4982ea] transition-colors"
      >
        <Plus className="w-3.5 h-3.5" />
        {rule.actions.length === 0 ? 'Adicionar a primeira Action' : `Passo ${rule.actions.length + 1}: adicionar Action`}
      </LogicPicker>
    </div>
    </VariableOwnerContext.Provider>
  );
};
