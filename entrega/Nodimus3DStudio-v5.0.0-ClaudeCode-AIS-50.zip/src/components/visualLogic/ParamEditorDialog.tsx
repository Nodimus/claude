import React, { useEffect, useMemo, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { useEditor } from '../../core/EditorContext';
import { LogicRegistry } from '../../logic/registry';
import type { LogicEventRule } from '../../types/visualLogic';
import type { LogicDefinition, LogicParamDescriptor } from '../../logic/types';
import { describeAction, describeStep, describeWhen, hasBlockingIssue, validateParams } from '../../logic/paramForm';
import { ParamForm, paramValue } from './ParamFields';
import { VariableOwnerContext, useLogicFormEnvironment } from './useLogicFormContext';

export type ParamEditTarget =
  | { kind: 'action'; behaviorId: string; rule: LogicEventRule; itemId: string }
  | { kind: 'condition'; behaviorId: string; rule: LogicEventRule; itemId: string }
  | { kind: 'trigger'; behaviorId: string; rule: LogicEventRule };

const KIND_LABEL = { action: 'Action', condition: 'Condition', trigger: 'Trigger' } as const;

const effective = (params: readonly LogicParamDescriptor[], values: Record<string, any>): Record<string, any> =>
  Object.fromEntries(params.map((p) => [p.key, paramValue(values, p)]));

/**
 * AIS-42 — diálogo modal de parâmetros de UMA Action, Condition ou Trigger. Os campos vêm do descritor da pasta
 * (`LogicRegistry`): seletor de nó da cena, vetor X/Y/Z, seletor de arquivo filtrado por `accept`/`root`, captura de tecla,
 * enum, número, texto. Validação inline (obrigatório, tipo, extensão, existência); "Aplicar" só habilita sem erros e grava
 * TUDO num único Command (um Undo). Cancelar/Esc não altera nada. O preview em português acompanha o rascunho.
 */
export const ParamEditorDialog: React.FC<{ target: ParamEditTarget; uiTarget?: boolean; onClose: () => void }> = ({ target, uiTarget = false, onClose }) => {
  const { behaviorOps: ops } = useEditor();
  const env = useLogicFormEnvironment();
  const { rule } = target;
  const ownerNodeId = env.ownerOf(target.behaviorId);

  const item = target.kind === 'action' ? rule.actions.find((a) => a.id === target.itemId) : target.kind === 'condition' ? rule.conditions.find((c) => c.id === target.itemId) : undefined;
  const definition: LogicDefinition | undefined = target.kind === 'action' ? LogicRegistry.getAction(item?.type ?? '') : target.kind === 'condition' ? LogicRegistry.getCondition(item?.type ?? '') : LogicRegistry.getTrigger(rule.eventType);
  const currentParams: Record<string, any> = target.kind === 'trigger' ? rule.parameters : item?.parameters ?? {};
  const typeId = target.kind === 'trigger' ? rule.eventType : item?.type ?? '';

  const [draft, setDraft] = useState<Record<string, any>>(() => effective(definition?.params ?? [], currentParams));
  const panel = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  useEffect(() => {
    panel.current?.querySelector<HTMLElement>('select, input, button[data-testid=key-capture]')?.focus();
  }, []);

  const hiddenKeys = useMemo(() => new Set((definition?.params ?? []).filter((p) => uiTarget && p.hideForUi).map((p) => p.key)), [definition, uiTarget]);
  const issues = useMemo(() => (definition ? validateParams(definition as never, draft, env.ctx, { hiddenKeys, ownerNodeId }) : []), [definition, draft, env.ctx, hiddenKeys, ownerNodeId]);
  const blocked = hasBlockingIssue(issues);

  // preview textual com o RASCUNHO aplicado
  const preview = useMemo(() => {
    const draftRule = {
      ...rule,
      parameters: target.kind === 'trigger' ? draft : rule.parameters,
      conditions: rule.conditions.map((c) => (target.kind === 'condition' && c.id === target.itemId ? { ...c, parameters: draft } : c)),
    };
    if (target.kind === 'action') return describeStep(draftRule, { type: typeId, parameters: draft }, env.ctx);
    const firstAction = rule.actions[0];
    const head = describeWhen(draftRule, env.ctx);
    return firstAction ? `${head} → ${describeAction(firstAction.type, firstAction.parameters, env.ctx)}` : head;
  }, [rule, target, draft, typeId, env.ctx]);

  const changedPatch = (): Record<string, unknown> => {
    const base = effective(definition?.params ?? [], currentParams);
    const patch: Record<string, unknown> = {};
    for (const p of definition?.params ?? []) if (!hiddenKeys.has(p.key) && JSON.stringify(draft[p.key]) !== JSON.stringify(base[p.key])) patch[p.key] = draft[p.key];
    return patch;
  };
  const apply = () => {
    if (blocked || !definition) return;
    const patch = changedPatch();
    if (Object.keys(patch).length > 0) {
      if (target.kind === 'action') ops.setActionParams(target.behaviorId, rule.id, target.itemId, patch);
      else if (target.kind === 'condition') ops.setConditionParams(target.behaviorId, rule.id, target.itemId, patch);
      else ops.setTriggerParams(target.behaviorId, rule.id, patch);
    }
    onClose();
  };

  const title = `Editar ${KIND_LABEL[target.kind]} — ${definition?.label ?? typeId}`;

  return (
    <div className="fixed inset-0 z-[350] flex items-center justify-center bg-black/60" role="dialog" aria-modal="true" aria-label={title} onMouseDown={(e) => e.target === e.currentTarget && onClose()} data-testid="param-dialog">
      <div ref={panel} className="w-[480px] max-h-[80vh] flex flex-col rounded-lg border border-[#2c3345] bg-[#1a1e27] shadow-2xl text-xs text-[#dfe4ec]">
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-[#2c3345]">
          <span className="font-semibold text-white">{title}</span>
          <button onClick={onClose} aria-label="Fechar" className="text-[#8b97a8] hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-4 py-3 border-b border-[#2c3345] bg-[#141822]" data-testid="param-preview-box">
          <div className="text-[10px] uppercase tracking-wider text-[#68768e] mb-1">Prévia do comportamento</div>
          <p className="text-[12px] text-emerald-300 leading-snug" data-testid="param-preview">
            {preview}
          </p>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-3">
          {!definition ? (
            <div className="text-[11px] text-amber-300/90 space-y-1">
              <p>
                {KIND_LABEL[target.kind]} não resolvida: o ID "{typeId}" não existe neste editor. Os parâmetros são preservados e não podem ser editados aqui.
              </p>
              <pre className="font-mono text-[10px] text-[#8b97a8] whitespace-pre-wrap break-all">{JSON.stringify(currentParams, null, 2)}</pre>
            </div>
          ) : definition.params.length === 0 ? (
            <p className="text-[11px] text-[#8b97a8]">{KIND_LABEL[target.kind]} sem parâmetros.</p>
          ) : (
            <VariableOwnerContext.Provider value={ownerNodeId}>
              <ParamForm params={definition.params} values={draft} onChange={(key, value) => setDraft((d) => ({ ...d, [key]: value }))} issues={issues} uiTarget={uiTarget} />
            </VariableOwnerContext.Provider>
          )}
        </div>

        <div className="flex items-center justify-between gap-2 px-4 py-2.5 border-t border-[#2c3345]">
          <span className={`text-[10px] ${blocked ? 'text-rose-400' : 'text-[#68768e]'}`} data-testid="param-status">
            {blocked ? `${issues.filter((i) => i.severity === 'error').length} campo(s) com erro` : issues.length > 0 ? `${issues.length} aviso(s)` : 'Tudo certo'}
          </span>
          <div className="flex items-center gap-2">
            <button onClick={onClose} className="px-3 py-1 rounded bg-[#202736] hover:bg-[#2b3548] text-[#a0afc4] hover:text-white">
              Cancelar
            </button>
            <button
              onClick={apply}
              disabled={blocked || !definition}
              title={blocked ? 'Corrija os campos em vermelho' : 'Aplica tudo num único passo (Ctrl+Z desfaz)'}
              data-testid="param-apply"
              className="px-4 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Aplicar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
