import * as THREE from 'three';
import { EDITOR_CAMERA_FOV, visibleHeightAt } from './editorCamera';

export interface MetricRulerScale {
  meters: number;
  pixels: number;
  label: string;
}

export interface ProjectedViewportPoint {
  x: number;
  y: number;
  visible: boolean;
}

export function metricRulerScale(
  radius: number,
  viewportHeight: number,
  targetPixels = 96,
  fovDeg = EDITOR_CAMERA_FOV
): MetricRulerScale {
  const worldPerPixel = visibleHeightAt(Math.max(radius, 0.01), fovDeg) / Math.max(viewportHeight, 1);
  const rawMeters = worldPerPixel * targetPixels;
  const magnitude = 10 ** Math.floor(Math.log10(rawMeters));
  const normalized = rawMeters / magnitude;
  const factor = normalized >= 5 ? 5 : normalized >= 2 ? 2 : normalized >= 1 ? 1 : 0.5;
  const meters = factor * magnitude;
  return {
    meters,
    pixels: meters / worldPerPixel,
    label: meters < 1 ? `${Math.round(meters * 100)} cm` : `${Number(meters.toPrecision(3))} m`,
  };
}

export function projectWorldPosition(
  camera: THREE.Camera,
  position: { x: number; y: number; z: number },
  viewportWidth: number,
  viewportHeight: number
): ProjectedViewportPoint {
  const projected = new THREE.Vector3(position.x, position.y, position.z).project(camera);
  return {
    x: ((projected.x + 1) / 2) * viewportWidth,
    y: ((1 - projected.y) / 2) * viewportHeight,
    visible: projected.z >= -1 && projected.z <= 1,
  };
}

export function boundingSphereForObjects(objects: readonly THREE.Object3D[]): THREE.Sphere | null {
  if (objects.length === 0) return null;
  const bounds = new THREE.Box3();
  const objectBounds = new THREE.Box3();
  const worldPosition = new THREE.Vector3();

  for (const object of objects) {
    object.updateWorldMatrix(true, false);
    objectBounds.setFromObject(object);
    if (objectBounds.isEmpty()) {
      object.getWorldPosition(worldPosition);
      bounds.expandByPoint(worldPosition);
    } else {
      bounds.union(objectBounds);
    }
  }

  if (bounds.isEmpty()) return null;
  return bounds.getBoundingSphere(new THREE.Sphere());
}