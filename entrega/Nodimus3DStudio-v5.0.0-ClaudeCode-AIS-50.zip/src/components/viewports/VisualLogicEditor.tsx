import React, { useEffect, useState } from 'react';
import { useEditor } from '../../core/EditorContext';
import type { Behavior, LogicEventRule } from '../../types/visualLogic';
import { LogicRegistry } from '../../logic/registry';
import { applyPhysicsPatch, defaultPhysicsConfig, diffPhysics, readPhysics } from '../../core/physics/physicsConfig';
import { Sparkles, Plus, Trash2, Zap, ArrowRight, ToggleLeft, ToggleRight, Copy, X, Pencil } from 'lucide-react';
import { LogicPicker } from '../visualLogic/LogicPicker';
import { ActionChain } from '../visualLogic/ActionChain';
import { CommitInput } from '../visualLogic/ParamFields';
import { ParamEditorDialog } from '../visualLogic/ParamEditorDialog';
import { useLogicFormEnvironment } from '../visualLogic/useLogicFormContext';
import { describeCondition, describeTrigger } from '../../logic/paramForm';
import { UI_NODE_TYPES } from '../../logic/actionHelpers';

/** Rótulo de um item do registro; ID que o registro não conhece continua visível e é marcado como não resolvido. */
const labelOf = (kind: 'trigger' | 'condition', id: string): { label: string; known: boolean } => {
  const def = kind === 'trigger' ? LogicRegistry.getTrigger(id) : LogicRegistry.getCondition(id);
  return { label: def?.label ?? id, known: !!def };
};

/** Gatilho da regra (Trigger): picker do `LogicRegistry`, parâmetros pelo diálogo (AIS-42); trocar é um Command. */
const TriggerRow: React.FC<{ behaviorId: string; rule: LogicEventRule; uiTarget: boolean }> = ({ behaviorId, rule, uiTarget }) => {
  const { behaviorOps: ops } = useEditor();
  const env = useLogicFormEnvironment();
  const [editing, setEditing] = useState(false);
  const { label, known } = labelOf('trigger', rule.eventType);
  const hasParams = (LogicRegistry.getTrigger(rule.eventType)?.params.length ?? 0) > 0;
  return (
    <div className="flex items-center gap-2">
      <div className="w-6 h-6 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold shrink-0">
        <Zap className="w-3.5 h-3.5" />
      </div>
      <div className="flex-1 bg-[#141822] px-3 py-1.5 rounded border border-[#2c3345] flex items-center justify-between gap-2">
        <span className="min-w-0">
          <span className="font-semibold text-white">
            When: <span className={`font-mono ${known ? 'text-amber-300' : 'text-rose-300'}`}>{label}</span>
            {!known && <span className="ml-1.5 text-[10px] text-rose-300">não resolvido (parâmetros preservados)</span>}
          </span>
          {known && hasParams && (
            <span className="block text-[10px] text-[#8b97a8] truncate" data-testid="trigger-summary">
              {describeTrigger(rule.eventType, rule.parameters, env.ctx)}
            </span>
          )}
        </span>
        <span className="flex items-center gap-3 shrink-0">
          {hasParams && (
            <button type="button" onClick={() => setEditing(true)} className="flex items-center gap-1 text-[11px] text-sky-300 hover:text-white" title="Editar os parâmetros do Trigger" data-testid="edit-trigger">
              <Pencil className="w-3 h-3" /> Parâmetros
            </button>
          )}
          <LogicPicker
            kind="trigger"
            current={rule.eventType}
            onPick={(id) => ops.setTrigger(behaviorId, rule.id, id)}
            title="Trocar o Trigger desta regra"
            data-testid="change-trigger"
            className="text-[11px] text-sky-300 hover:text-white underline-offset-2 hover:underline"
          >
            Trocar Trigger
          </LogicPicker>
        </span>
      </div>
      {editing && <ParamEditorDialog target={{ kind: 'trigger', behaviorId, rule }} uiTarget={uiTarget} onClose={() => setEditing(false)} />}
    </div>
  );
};

/** Conditions da regra: cada uma com resumo, "Editar" (diálogo de parâmetros) e "×"; o "+" abre o picker. Sem nenhuma = sempre. */
const ConditionList: React.FC<{ behaviorId: string; rule: LogicEventRule; uiTarget: boolean }> = ({ behaviorId, rule, uiTarget }) => {
  const { behaviorOps: ops } = useEditor();
  const env = useLogicFormEnvironment();
  const [editingId, setEditingId] = useState<string | null>(null);
  return (
    <div className="pl-4 space-y-1.5" data-testid="condition-list">
      {rule.conditions.length === 0 && (
        <div className="flex items-center gap-2 text-[11px] text-[#8b97a8]">
          <ArrowRight className="w-3 h-3" /> Sem condições: a regra sempre executa.
        </div>
      )}
      {rule.conditions.map((c) => {
        const { label, known } = labelOf('condition', c.type);
        const def = LogicRegistry.getCondition(c.type);
        return (
          <div key={c.id} className="flex items-center gap-2" data-testid={`condition-${c.type}`}>
            <ArrowRight className="w-3 h-3 text-[#8b97a8] shrink-0" />
            <div className="flex-1 bg-[#141822] px-3 py-1 rounded border border-[#2c3345] flex items-center justify-between gap-2 min-w-0">
              <span className="text-[#dfe4ec] truncate">
                Condition: <span className={`font-mono ${known ? 'text-sky-300' : 'text-rose-300'}`}>{label}</span>
                {!known && <span className="ml-1.5 text-[10px] text-rose-300">não resolvida</span>}
                {known && (def?.params.length ?? 0) > 0 && <span className="ml-2 text-[10px] text-[#8b97a8]">{describeCondition(c.type, c.parameters, env.ctx)}</span>}
              </span>
              <span className="flex items-center gap-2 shrink-0">
                {(def?.params.length ?? 0) > 0 && (
                  <button type="button" onClick={() => setEditingId(c.id)} className="text-[#68768e] hover:text-white p-0.5" aria-label={`Editar parâmetros da condição ${label}`} title="Editar parâmetros" data-testid={`edit-condition-${c.type}`}>
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                )}
                <button type="button" onClick={() => ops.removeCondition(behaviorId, rule.id, c.id)} className="text-[#68768e] hover:text-rose-400 p-0.5" aria-label={`Remover condição ${label}`} title="Remover Condition">
                  <X className="w-3.5 h-3.5" />
                </button>
              </span>
            </div>
          </div>
        );
      })}
      <LogicPicker
        kind="condition"
        onPick={(type) => ops.addCondition(behaviorId, rule.id, type)}
        title="Adicionar uma Condition à regra"
        data-testid="add-condition"
        className="flex items-center gap-1 text-[11px] text-[#8b97a8] hover:text-white"
      >
        <Plus className="w-3 h-3" /> Condition
      </LogicPicker>
      {editingId && rule.conditions.some((c) => c.id === editingId) && (
        <ParamEditorDialog target={{ kind: 'condition', behaviorId, rule, itemId: editingId }} uiTarget={uiTarget} onClose={() => setEditingId(null)} />
      )}
    </div>
  );
};

export const VisualLogicEditor: React.FC = () => {
  const { selectedNode, behaviors, behaviorOps: ops, addLog, activeScene, changeNodeProperties } = useEditor();

  const [selectedBehaviorId, setSelectedBehaviorId] = useState<string | null>(behaviors[0]?.id || null);
  const [onlySelectedNode, setOnlySelectedNode] = useState(false);
  const [menu, setMenu] = useState<{ x: number; y: number; id: string } | null>(null);

  // AIS-41b: o dono de um Behavior é o NÓ (por ID); sem seleção, a raiz da cena
  const ownerNode = selectedNode ?? activeScene.nodes[activeScene.rootNodeId];
  const targetName = ownerNode ? ownerNode.name : 'World3D';
  const nodeLabel = (target: string) => activeScene.nodes[target]?.name ?? target;
  const isOnSelected = (b: Behavior) => !!selectedNode && (b.targetNodeId === selectedNode.name || b.targetNodeId === selectedNode.id);
  const visible = onlySelectedNode && selectedNode ? behaviors.filter(isOnSelected) : behaviors;
  const selectedBehavior = behaviors.find((b) => b.id === selectedBehaviorId) || null;
  // AIS-41: alvo de UI (Overlay2D…) esconde campos só de 3D (o Z) no formulário das Actions
  const behaviorTarget = selectedBehavior ? Object.values(activeScene.nodes).find((n) => n.id === selectedBehavior.targetNodeId || n.name === selectedBehavior.targetNodeId) : undefined;
  const uiTarget = !!behaviorTarget && UI_NODE_TYPES.includes(behaviorTarget.type);

  // remover/Undo de "adicionar" tira o Behavior da lista: a seleção cai para o primeiro que sobrar
  useEffect(() => {
    if (selectedBehaviorId && !behaviors.some((b) => b.id === selectedBehaviorId)) setSelectedBehaviorId(behaviors[0]?.id ?? null);
  }, [behaviors, selectedBehaviorId]);

  useEffect(() => {
    if (!menu) return;
    const close = () => setMenu(null);
    window.addEventListener('mousedown', close);
    window.addEventListener('blur', close);
    return () => {
      window.removeEventListener('mousedown', close);
      window.removeEventListener('blur', close);
    };
  }, [menu]);

  // Adicionar Behavior: tipo escolhido no picker do LogicRegistry (preset ou qualquer pasta de src/logic/behaviors/)
  const handleAddBehavior = (behaviorId: string) => {
    const definition = LogicRegistry.getBehavior(behaviorId);
    if (!definition) return;
    const created = { ...definition.create({ targetNodeId: targetName }), targetNodeId: ownerNode?.id ?? targetName };
    ops.add(created);
    // AIS-48: o preset "Físico" também liga a Colisão do nó como dynamic (Command próprio, com Undo; decisão 26)
    if (definition.presetPhysics && ownerNode) {
      const current = readPhysics(ownerNode.properties) ?? defaultPhysicsConfig();
      const next = applyPhysicsPatch(current, definition.presetPhysics);
      const diff = diffPhysics(readPhysics(ownerNode.properties), next);
      if (Object.keys(diff).length) changeNodeProperties(ownerNode.id, diff, 'Preset: colisão "Físico"');
    }
    setSelectedBehaviorId(created.id);
    addLog('log', `Attached behavior: ${created.name}`);
  };

  const handleDuplicate = (id: string) => {
    const copyId = ops.duplicate(id);
    if (copyId) setSelectedBehaviorId(copyId);
  };

  return (
    <div className="flex h-full bg-[#141822] select-none text-xs">
      {/* Left Sidebar: Behaviors List */}
      <div className="w-64 border-r border-[#2c3345] bg-[#1a1f2b] flex flex-col">
        <div className="h-9 border-b border-[#2c3345] px-3 flex items-center justify-between">
          <div className="font-semibold text-white flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Behaviors & Logic</span>
          </div>
          <LogicPicker
            kind="behavior"
            onPick={handleAddBehavior}
            title={`Adicionar um Behavior a ${targetName}`}
            data-testid="add-behavior"
            className="w-6 h-6 rounded bg-[#252c3c] hover:bg-[#30394e] text-white flex items-center justify-center border border-[#2c3345]"
          >
            <Plus className="w-3.5 h-3.5" />
          </LogicPicker>
        </div>

        {/* Quick Add Presets */}
        <div className="p-2 border-b border-[#2c3345] bg-[#161a25]">
          <span className="text-[11px] text-[#8b97a8] block mb-1.5">
            Add to: <strong className="text-white">{selectedNode?.name || 'Scene'}</strong>
          </span>
          <div className="grid grid-cols-2 gap-1 text-[11px]">
            {LogicRegistry.listBehaviorPresets().map((b) => (
              <button
                key={b.id}
                onClick={() => handleAddBehavior(b.id)}
                title={b.description}
                className={`p-1.5 bg-[#252c3c] hover:bg-[#30394e] rounded text-left truncate text-[#dfe4ec] border border-[#2c3345]${b.preset!.wide ? ' col-span-2' : ''}`}
              >
                + {b.preset!.label}
              </button>
            ))}
          </div>
          <label className="mt-2 flex items-center gap-1.5 text-[11px] text-[#8b97a8] cursor-pointer">
            <input type="checkbox" checked={onlySelectedNode} onChange={(e) => setOnlySelectedNode(e.target.checked)} disabled={!selectedNode} />
            Só o nó selecionado
          </label>
        </div>

        {/* Behaviors List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1" data-testid="behavior-list">
          {visible.length === 0 && <div className="p-2 text-[11px] text-[#68768e]">{onlySelectedNode ? 'Nenhum Behavior neste nó.' : 'Nenhum Behavior na cena.'}</div>}
          {visible.map((b) => {
            const isSelected = selectedBehaviorId === b.id;
            return (
              <div
                key={b.id}
                onClick={() => setSelectedBehaviorId(b.id)}
                onContextMenu={(e) => {
                  e.preventDefault();
                  setSelectedBehaviorId(b.id);
                  setMenu({ x: e.clientX, y: e.clientY, id: b.id });
                }}
                className={`p-2 rounded cursor-pointer border transition-colors ${
                  isSelected ? 'bg-[#293245] border-[#4982ea] text-white shadow-sm' : 'bg-[#1e2432] border-[#2c3345] text-[#dfe4ec] hover:border-[#3d475f]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold truncate">{b.name}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      ops.setEnabled(b.id, !b.enabled);
                    }}
                    className={b.enabled ? 'text-emerald-400' : 'text-[#616e82]'}
                    title={b.enabled ? 'Enabled' : 'Disabled'}
                    aria-label={b.enabled ? `Desativar ${b.name}` : `Ativar ${b.name}`}
                  >
                    {b.enabled ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                  </button>
                </div>
                <div className="text-[11px] text-[#8b97a8] mt-1 flex items-center gap-1 font-mono">
                  <span>Target:</span>
                  <span className="text-amber-300">{nodeLabel(b.targetNodeId)}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Flow: Behavior Config & dnd-kit Sortable Actions */}
      <div className="flex-1 overflow-y-auto p-5">
        {selectedBehavior ? (
          <div className="max-w-3xl mx-auto space-y-5">
            {/* Header Card */}
            <div className="bg-[#1c2230] p-3.5 rounded-lg border border-[#2c3345] flex items-center justify-between gap-3">
              <div className="min-w-0">
                <CommitInput
                  value={selectedBehavior.name}
                  onCommit={(name) => ops.rename(selectedBehavior.id, String(name))}
                  aria-label="Nome do Behavior"
                  className="!bg-transparent !text-sm !font-sans font-semibold !border-transparent hover:!border-[#2c3345] w-72"
                />
                <div className="text-[11px] text-[#8b97a8] mt-0.5">
                  Type: <span className="font-mono text-amber-300">{selectedBehavior.behaviorType}</span>
                  {!LogicRegistry.isKnownBehavior(selectedBehavior.behaviorType) && <span className="ml-1.5 text-rose-300">não resolvido (dados preservados)</span>}
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => handleDuplicate(selectedBehavior.id)}
                  className="p-1.5 rounded bg-[#252c3c] text-[#dfe4ec] hover:bg-[#30394e] transition-colors flex items-center gap-1 text-xs"
                  title="Duplicar este Behavior (cópia com novos IDs)"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Duplicar</span>
                </button>
                <button
                  onClick={() => ops.remove(selectedBehavior.id)}
                  className="p-1.5 rounded bg-rose-900/30 text-rose-300 hover:bg-rose-900/50 transition-colors flex items-center gap-1 text-xs"
                  title="Remover este Behavior (Ctrl+Z desfaz)"
                  aria-label={`Remover ${selectedBehavior.name}`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Remove</span>
                </button>
              </div>
            </div>

            {/* Behavior Parameters */}
            <div className="bg-[#1c2230] p-3.5 rounded-lg border border-[#2c3345]">
              <div className="text-xs font-semibold text-[#dfe4ec] mb-2 uppercase tracking-wider">Behavior Parameters</div>
              {Object.keys(selectedBehavior.properties).length === 0 && <div className="text-[11px] text-[#68768e]">Este Behavior não tem parâmetros.</div>}
              <div className="grid grid-cols-2 gap-3">
                {Object.entries(selectedBehavior.properties).map(([key, val]) => (
                  <div key={key} className="flex items-center justify-between bg-[#141822] px-3 py-1.5 rounded border border-[#2c3345]">
                    <span className="text-[#8b97a8] font-mono">{key}</span>
                    <CommitInput
                      numeric={typeof val === 'number'}
                      value={typeof val === 'number' ? val : String(val)}
                      onCommit={(v) => ops.setProperty(selectedBehavior.id, key, v)}
                      aria-label={key}
                      className={`text-right ${typeof val === 'number' ? 'w-24' : 'w-32'}`}
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Rules (Trigger -> Conditions -> Actions) */}
            <div className="space-y-4">
              <div className="text-xs font-semibold text-[#dfe4ec] uppercase tracking-wider flex items-center justify-between">
                <span>Rules (Trigger → Conditions → Actions)</span>
                <span className="text-[11px] text-[#8b97a8] font-normal">Reordene as Actions pela alça, por ↑/↓ ou pelas setas ▲▼</span>
              </div>

              {selectedBehavior.rules.map((rule) => (
                <div key={rule.id} className="bg-[#1c2230] rounded-lg border border-[#2c3345] p-3.5 space-y-3" data-testid="rule-card">
                  <TriggerRow behaviorId={selectedBehavior.id} rule={rule} uiTarget={uiTarget} />
                  <ConditionList behaviorId={selectedBehavior.id} rule={rule} uiTarget={uiTarget} />
                  <div className="pl-4">
                    <ActionChain behaviorId={selectedBehavior.id} rule={rule} ops={ops} uiTarget={uiTarget} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-[#8b97a8] text-center p-8">
            <Sparkles className="w-10 h-10 mb-2 opacity-30 text-amber-400" />
            <p className="font-medium text-white">No Behavior Selected</p>
            <p className="text-xs text-[#6e7d95] mt-1 max-w-sm">
              Attach behaviors to 3D and 2D Overlay nodes and configure Trigger → Condition → Action flows with @dnd-kit drag-and-drop.
            </p>
          </div>
        )}
      </div>

      {menu && (
        <div style={{ position: 'fixed', left: menu.x, top: menu.y }} role="menu" className="z-[400] w-40 rounded border border-[#2c3345] bg-[#1a1f2b] shadow-2xl py-1 text-[11px]" onMouseDown={(e) => e.stopPropagation()}>
          <button
            role="menuitem"
            className="w-full text-left px-3 py-1.5 text-[#dfe4ec] hover:bg-[#272e3d]"
            onClick={() => {
              handleDuplicate(menu.id);
              setMenu(null);
            }}
          >
            Duplicar
          </button>
          <button
            role="menuitem"
            className="w-full text-left px-3 py-1.5 text-rose-300 hover:bg-[#272e3d]"
            onClick={() => {
              ops.remove(menu.id);
              setMenu(null);
            }}
          >
            Remover
          </button>
        </div>
      )}
    </div>
  );
};
