import React from 'react';
import { NodeType } from '../../types/node';
import {
  Circle,
  Box,
  Video,
  Sun,
  Zap,
  Flashlight,
  Image as ImageIcon,
  Type,
  MousePointerClick,
  Radio,
  Volume2,
  Headphones,
  Timer,
  Film,
  Sparkles,
  Globe,
  Mountain,
  AlertTriangle,
  PanelTop,
  LayoutPanelTop,
  Columns3,
  Rows3,
  Grid3x3,
  Frame,
  Focus,
  ScrollText,
  SquareCheck,
  SlidersHorizontal,
  Loader,
  TextCursorInput,
} from 'lucide-react';

export const NodeIcon: React.FC<{ type: NodeType; className?: string }> = ({ type, className = 'w-3.5 h-3.5' }) => {
  switch (type) {
    case 'Node':
      return <Circle className={`${className} text-[#8b97a8]`} />;
    case 'Spatial':
      return <Box className={`${className} text-rose-400`} />;
    case 'MeshInstance':
      return <Box className={`${className} text-blue-400`} />;
    case 'Camera':
      return <Video className={`${className} text-fuchsia-400`} />;
    case 'DirectionalLight':
      return <Sun className={`${className} text-yellow-400`} />;
    case 'OmniLight':
      return <Zap className={`${className} text-amber-400`} />;
    case 'SpotLight':
      return <Flashlight className={`${className} text-amber-300`} />;
    case 'Environment':
      return <Globe className={`${className} text-sky-400`} />;
    case 'Terrain':
      return <Mountain className={`${className} text-green-500`} />;
    case 'AnimationPlayer':
      return <Film className={`${className} text-purple-400`} />;
    case 'ParticleSystem':
      return <Sparkles className={`${className} text-amber-400`} />;
    // 2D Overlay
    case 'Overlay2D':
      return <ImageIcon className={`${className} text-sky-400`} />;
    case 'TextOverlay2D':
      return <Type className={`${className} text-amber-300`} />;
    case 'ButtonOverlay2D':
      return <MousePointerClick className={`${className} text-emerald-400`} />;
    case 'Billboard':
      return <Radio className={`${className} text-lime-400`} />;
    // Audio & Misc
    case 'AudioPlayer':
      return <Volume2 className={`${className} text-pink-400`} />;
    case 'AudioPlayer3D':
      return <Headphones className={`${className} text-pink-400`} />;
    case 'Timer':
      return <Timer className={`${className} text-amber-400`} />;
    // AIS-25c: Containers e controles de UI
    case 'Panel':
      return <PanelTop className={`${className} text-sky-300`} />;
    case 'Container':
      return <LayoutPanelTop className={`${className} text-sky-300`} />;
    case 'HBox':
      return <Columns3 className={`${className} text-sky-400`} />;
    case 'VBox':
      return <Rows3 className={`${className} text-sky-400`} />;
    case 'Grid':
      return <Grid3x3 className={`${className} text-sky-400`} />;
    case 'MarginContainer':
      return <Frame className={`${className} text-sky-300`} />;
    case 'CenterContainer':
      return <Focus className={`${className} text-sky-300`} />;
    case 'ScrollContainer':
      return <ScrollText className={`${className} text-sky-300`} />;
    case 'CheckBox':
      return <SquareCheck className={`${className} text-emerald-300`} />;
    case 'Slider':
      return <SlidersHorizontal className={`${className} text-emerald-300`} />;
    case 'ProgressBar':
      return <Loader className={`${className} text-emerald-300`} />;
    case 'TextInput':
      return <TextCursorInput className={`${className} text-emerald-300`} />;
    case 'Missing':
      return <AlertTriangle className={`${className} text-orange-400`} />;
    default:
      return <Circle className={`${className} text-gray-400`} />;
  }
};
