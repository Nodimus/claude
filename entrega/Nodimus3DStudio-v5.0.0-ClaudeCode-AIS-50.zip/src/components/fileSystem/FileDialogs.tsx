import React, { useState } from 'react';
import { FolderInput, Trash2, X } from 'lucide-react';
import { validateName } from '../../core/fileSystem/fileOps';
import type { ResourceRef } from '../../types/node';
import type { DeleteDecision, DeletionPlan } from '../../core/resourceDeletion';

/**
 * AIS-28 — diálogos do FileSystemPanel: confirmação de exclusão, seletor "Mover para..." e conflito de nome.
 * Só coletam a decisão do usuário; quem executa é o painel (via adapter provisório do AIS-29e).
 */

const Shell: React.FC<{ title: string; icon: React.ReactNode; onCancel: () => void; children: React.ReactNode; footer: React.ReactNode }> = ({
  title,
  icon,
  onCancel,
  children,
  footer,
}) => (
  <div
    className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 select-none"
    onKeyDown={(e) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onCancel();
      }
    }}
  >
    <div role="dialog" aria-label={title} className="bg-[#181c26] border border-[#2b3345] rounded-xl shadow-2xl w-full max-w-sm text-xs text-[#d4dbe8] overflow-hidden">
      <div className="px-4 py-3 bg-[#141720] border-b border-[#242b3b] flex items-center justify-between">
        <div className="flex items-center gap-2 font-semibold text-white">
          {icon}
          <span>{title}</span>
        </div>
        <button onClick={onCancel} aria-label="Cancelar" className="p-1 rounded hover:bg-[#2c3345] text-[#8b97a8] hover:text-white">
          <X className="w-4 h-4" />
        </button>
      </div>
      <div className="p-4 space-y-3">{children}</div>
      <div className="px-4 py-3 bg-[#171b24] border-t border-[#2c3345] flex justify-end gap-2">{footer}</div>
    </div>
  </div>
);

const cancelBtn = (onCancel: () => void) => (
  <button onClick={onCancel} className="px-3 py-1.5 rounded hover:bg-[#2c3345] text-[#b3bed0]">
    Cancelar
  </button>
);

export interface ReplaceCandidate {
  ref: ResourceRef;
  label: string;
}

/**
 * Exclusão (AIS-29e): o plano do serviço mostra o conteúdo e TODOS os consumidores. Sem consumidores é uma confirmação
 * simples; com consumidores a decisão é explícita — manter as referências como não resolvidas (preservadas) ou, para
 * texturas e materiais, substituir por outro recurso do mesmo tipo.
 */
export const ConfirmDeleteDialog: React.FC<{
  path: string;
  plan: DeletionPlan | null;
  replaceCandidates?: ReplaceCandidate[];
  /** AIS-38c: arquivos gerados pela importação do modelo; cada um é listado e marcável (nada some em silêncio). */
  packageItems?: { uri: string; kind: string; role: string }[];
  onConfirm: (decision?: DeleteDecision, packageUris?: string[]) => void;
  onCancel: () => void;
}> = ({ path, plan, replaceCandidates = [], packageItems = [], onConfirm, onCancel }) => {
  const [packageChecked, setPackageChecked] = useState<Record<string, boolean>>({});
  const isChecked = (uri: string) => packageChecked[uri] ?? true;
  const packageUris = () => packageItems.filter((i) => isChecked(i.uri)).map((i) => i.uri);
  const consumers = plan?.consumers ?? [];
  const inUse = consumers.length > 0;
  const canReplace = !!plan?.canReplace && replaceCandidates.length > 0;
  const [mode, setMode] = useState<'unresolve' | 'replace'>('unresolve');
  const [replaceId, setReplaceId] = useState<string>(replaceCandidates[0]?.ref.id ?? '');
  const itemCount = plan ? plan.fileCount + plan.folderCount : 1;

  const confirm = () => {
    if (!inUse) return onConfirm(undefined, packageUris());
    if (mode === 'replace') {
      const chosen = replaceCandidates.find((c) => c.ref.id === replaceId);
      if (chosen) return onConfirm({ kind: 'replace', with: chosen.ref }, packageUris());
    }
    onConfirm({ kind: 'unresolve' }, packageUris());
  };

  return (
    <Shell
      title="Excluir"
      icon={<Trash2 className="w-4 h-4 text-rose-400" />}
      onCancel={onCancel}
      footer={
        <>
          {cancelBtn(onCancel)}
          <button autoFocus disabled={!plan} onClick={confirm} className="bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white px-4 py-1.5 rounded font-medium">
            {inUse ? (mode === 'replace' ? 'Substituir e excluir' : 'Excluir mesmo assim') : 'Excluir'}
          </button>
        </>
      }
    >
      <p>
        Excluir <span className="font-mono text-white break-all">{path}</span>?
      </p>
      {plan && plan.fileCount + plan.folderCount > 1 && (
        <p className="text-amber-300">
          {plan.folderCount > 0 ? `A pasta e o conteúdo dela (${plan.fileCount} arquivo(s)${plan.folderCount > 1 ? `, ${plan.folderCount - 1} subpasta(s)` : ''}) serão excluídos.` : `${itemCount} itens serão excluídos.`}
        </p>
      )}
      {inUse ? (
        <div role="alert" className="rounded border border-amber-500/30 bg-amber-500/10 p-2 text-amber-300 space-y-1">
          <p className="font-semibold">Este conteúdo está em uso por {new Set(consumers.map((c) => c.uri)).size} arquivo(s):</p>
          <ul className="max-h-32 overflow-y-auto space-y-0.5">
            {consumers.map((c) => (
              <li key={`${c.resourceUri}|${c.uri}|${c.via}`} className="font-mono break-all">
                {c.resourceUri} <span className="text-amber-200/70">← {c.uri}{c.via ? ` (${c.via})` : ''}{c.editorOnly ? ' · só editor' : ''}</span>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <p className="text-[#8b97a8]">{plan ? 'Nenhuma referência a este conteúdo foi encontrada.' : 'Verificando referências…'}</p>
      )}
      {packageItems.length > 0 && (
        <fieldset className="space-y-1 rounded border border-[#2c3345] p-2" data-testid="delete-package">
          <legend className="text-[#8b97a8] px-1">Pacote do asset (arquivos gerados pela importação)</legend>
          <p className="text-[#8b97a8]">Marque o que deve sair junto com o modelo. O que ficar desmarcado permanece no projeto.</p>
          <ul className="max-h-32 overflow-y-auto space-y-0.5">
            {packageItems.map((item) => (
              <li key={item.uri}>
                <label className="flex items-start gap-2 cursor-pointer">
                  <input type="checkbox" checked={isChecked(item.uri)} onChange={(e) => setPackageChecked((prev) => ({ ...prev, [item.uri]: e.target.checked }))} className="mt-0.5" aria-label={`Excluir ${item.uri}`} />
                  <span className="font-mono break-all">{item.uri}</span>
                </label>
              </li>
            ))}
          </ul>
        </fieldset>
      )}
      {inUse && (
        <fieldset className="space-y-1.5">
          <legend className="text-[#8b97a8] mb-1">O que fazer com as referências?</legend>
          <label className="flex items-start gap-2 cursor-pointer">
            <input type="radio" name="del-mode" checked={mode === 'unresolve'} onChange={() => setMode('unresolve')} className="mt-0.5" />
            <span>Manter como <b>não resolvidas</b> (preservadas nos arquivos, com aviso, para reparar depois)</span>
          </label>
          {canReplace && (
            <label className="flex items-start gap-2 cursor-pointer">
              <input type="radio" name="del-mode" checked={mode === 'replace'} onChange={() => setMode('replace')} className="mt-0.5" />
              <span className="flex-1">
                Substituir por outro recurso ({plan?.replaceKind}):
                <select
                  value={replaceId}
                  disabled={mode !== 'replace'}
                  onChange={(e) => setReplaceId(e.target.value)}
                  aria-label="Substituir por"
                  className="mt-1 w-full bg-[#141820] text-xs text-[#dfe4ec] px-2 py-1 rounded border border-[#2c3345] outline-none"
                >
                  {replaceCandidates.map((c) => (
                    <option key={c.ref.id} value={c.ref.id}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </span>
            </label>
          )}
        </fieldset>
      )}
    </Shell>
  );
};

/** Seletor de pasta destino de "Mover para...". */
export const MoveToDialog: React.FC<{ path: string; folders: string[]; onConfirm: (folder: string) => void; onCancel: () => void }> = ({ path, folders, onConfirm, onCancel }) => {
  const [selected, setSelected] = useState<string>(folders[0] ?? '');
  return (
    <Shell
      title="Mover para..."
      icon={<FolderInput className="w-4 h-4 text-amber-400" />}
      onCancel={onCancel}
      footer={
        <>
          {cancelBtn(onCancel)}
          <button
            disabled={!selected}
            onClick={() => onConfirm(selected)}
            className="bg-[#4982ea] hover:bg-[#3d72d6] disabled:opacity-50 text-white px-4 py-1.5 rounded font-medium"
          >
            Mover
          </button>
        </>
      }
    >
      <p>
        Mover <span className="font-mono text-white break-all">{path}</span> para:
      </p>
      {folders.length === 0 ? (
        <p className="text-[#8b97a8] italic">Não há outra pasta de destino.</p>
      ) : (
        <div role="listbox" aria-label="Pasta destino" className="max-h-48 overflow-y-auto rounded border border-[#2c3345] bg-[#141820]">
          {folders.map((f) => (
            <button
              key={f}
              role="option"
              aria-selected={selected === f}
              onClick={() => setSelected(f)}
              onDoubleClick={() => onConfirm(f)}
              className={`w-full text-left px-2 py-1 font-mono ${selected === f ? 'bg-[#4982ea] text-white' : 'hover:bg-[#272e3d] text-[#dfe4ec]'}`}
            >
              {f}
            </button>
          ))}
        </div>
      )}
    </Shell>
  );
};

/** Conflito de nome no destino: pede um novo nome ou cancela (nunca sobrescreve). */
export const NameConflictDialog: React.FC<{ name: string; suggested: string; onConfirm: (newName: string) => void; onCancel: () => void }> = ({ name, suggested, onConfirm, onCancel }) => {
  const [value, setValue] = useState(suggested);
  const validity = validateName(value);
  return (
    <Shell
      title="Já existe um item com esse nome"
      icon={<FolderInput className="w-4 h-4 text-amber-400" />}
      onCancel={onCancel}
      footer={
        <>
          {cancelBtn(onCancel)}
          <button
            disabled={!validity.ok}
            onClick={() => onConfirm(value)}
            className="bg-[#4982ea] hover:bg-[#3d72d6] disabled:opacity-50 text-white px-4 py-1.5 rounded font-medium"
          >
            Usar novo nome
          </button>
        </>
      }
    >
      <p>
        O destino já tem <span className="font-mono text-white">{name}</span>. Escolha outro nome:
      </p>
      <input
        autoFocus
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && validity.ok) onConfirm(value);
        }}
        aria-label="Novo nome"
        aria-invalid={!validity.ok}
        spellCheck={false}
        className="w-full bg-[#141820] text-xs text-[#dfe4ec] px-2 py-1.5 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none font-mono"
      />
      {!validity.ok && <p role="alert" className="text-amber-300">{validity.error}</p>}
    </Shell>
  );
};
