import React, { useState, useRef, useMemo, useEffect } from 'react';
import { useEditor } from '../../core/EditorContext';
import {
  Folder,
  FolderOpen,
  File,
  FileCode,
  Film,
  Image as ImageIcon,
  Volume2,
  FileJson,
  Plus,
  Trash2,
  Upload,
  Search,
  ChevronRight,
  ChevronDown,
  Box,
  Sparkles,
  Braces,
  FileText,
  Code2,
  Palette,
  Puzzle,
  Layers,
  LayoutGrid,
  List,
  Package,
} from 'lucide-react';
import { FS_DRAG_MIME } from '../../core/fileSystem/dropActions';
import { useEditorStore } from '../../core/editorStore';
import { PREFAB_COMING_SOON, UPLOAD_ACCEPT, isBinaryUploadName, isModelFileName, resolveFileAction } from '../../core/fileSystem/fileActions';
import { baseNameOf, collectDeleteTargets, isFolderPath, parentFolderOf, pathInFolder, pathWithName, planPathChange, uniqueName, validMoveDestinations, validateName } from '../../core/fileSystem/fileOps';
import { ConfirmDeleteDialog, MoveToDialog, NameConflictDialog } from './FileDialogs';
import { FileContextMenu } from './FileContextMenu';
import { globalAssetPipeline, globalResourceRegistry } from '../../core/resources/global';
import { deleteResource, moveResource, planResourceDeletion, type DeletionPlan } from '../../core/resourceDeletion';
import { useResourceRegistryVersion } from '../../core/resources/useResources';
import { planNewFile, type NewFileType } from '../../core/scripts/scriptFiles';
import { modelPackage, type PackageItem } from '../../core/modelImport/modelLifecycle';
import { parseModelImportSettings } from '../../schemas/v1/modelImportSettings.schema';
import { FileGrid, type GridFile } from './FileGrid';

export function getParentPath(path: string): string | null {
  if (path === 'res://' || !path.startsWith('res://')) return null;
  const clean = path.endsWith('/') ? path.slice(0, -1) : path;
  const lastSlash = clean.lastIndexOf('/');
  if (lastSlash < 5) return 'res://';
  return clean.substring(0, lastSlash + 1);
}

interface FileTreeNode {
  file: any;
  children: FileTreeNode[];
  depth: number;
}

export const FileSystemPanel: React.FC = () => {
  const {
    project,
    loadScene,
    createFolder,
    createFile,
    importFileContent,
    setIsAssetImportModalOpen,
    setIsSoundModalOpen,
    setIsTexturePreviewOpen,
    setIsVideoEditorOpen,
    setIsSpriteEditorOpen,
    openFileInScriptEditor,
    addLog,
    activeScene,
  } = useEditor();

  const [searchFilter, setSearchFilter] = useState('');
  const [selectedPath, setSelectedPath] = useState<string>('res://');
  const [showNewFileMenu, setShowNewFileMenu] = useState<boolean>(false);
  const [isRenaming, setIsRenaming] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    'res://': true,
    'res://scenes/': true,
    'res://scripts/': true,
    'res://textures/': true,
    'res://audio/': true,
    'res://materials/': true,
    'res://models/': true,
    'res://overlays/': true,
    'res://videos/': true,
    'res://sprites/': true,
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  // AIS-28: modo de exibição (preferência de UI, não do projeto), menu de contexto, diálogos e arrastar-e-soltar
  const [viewMode, setViewMode] = useState<'tree' | 'grid'>(() => {
    try {
      return globalThis.localStorage?.getItem('nodimus.pref.fsViewMode') === 'grid' ? 'grid' : 'tree';
    } catch {
      return 'tree';
    }
  });
  const [gridFolder, setGridFolder] = useState<string>('res://');
  const [renameError, setRenameError] = useState<string | null>(null);
  const renameDone = useRef(true);
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; file: GridFile } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<GridFile | null>(null);
  const [deletePlan, setDeletePlan] = useState<DeletionPlan | null>(null);
  const [moveTarget, setMoveTarget] = useState<GridFile | null>(null);
  const [conflict, setConflict] = useState<{ kind: 'rename' | 'move'; file: GridFile; folder: string; name: string; suggested: string } | null>(null);
  const [dropTarget, setDropTarget] = useState<string | null>(null);
  const openAssetImportWithSource = useEditorStore((s) => s.openAssetImportWithSource); // AIS-33
  const reveal = useEditorStore((s) => s.fileSystemReveal); // AIS-38c: "Mostrar no FileSystem"
  const [deletePackage, setDeletePackage] = useState<PackageItem[]>([]);
  const registryVersion = useResourceRegistryVersion(); // AIS-28c: re-renderiza quando o ResourceRegistry muda (ids/estado)

  // AIS-38c: modelo (e o pacote dele) que nenhuma cena/prefab referencia aparece como "sem uso" — o usuário decide; nada some sozinho.
  // A cena aberta conta pelo estado em memória (ainda pode não estar salva).
  const unusedModelFiles = useMemo(() => {
    const inOpenScene = new Set<string>();
    for (const n of Object.values(activeScene.nodes ?? {})) {
      const ref = (n as { properties?: Record<string, any> }).properties?.model;
      if (ref && typeof ref.id === 'string') inOpenScene.add(ref.id);
    }
    const out = new Set<string>();
    for (const entry of globalResourceRegistry.list('mesh')) {
      if (!entry.uri.startsWith('res://models/') || !entry.importSettings) continue;
      if (inOpenScene.has(entry.resourceId) || globalResourceRegistry.graph.getReverse(entry.resourceId).length > 0) continue;
      out.add(entry.uri);
      const pkg = modelPackage(parseModelImportSettings(entry.importSettings), (ref) => {
        const r = globalResourceRegistry.resolve(ref as never);
        return r.status === 'resolved' ? { uri: r.entry.uri, kind: r.entry.kind } : null;
      }, entry.resourceId);
      for (const item of pkg.items) out.add(item.uri);
    }
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [registryVersion, activeScene.nodes, project.files]);
  const DRAG_MIME = FS_DRAG_MIME; // AIS-31: o mesmo MIME é lido pelo Viewport3D e pela SceneTree

  const toggleFolder = (path: string) => {
    setExpandedFolders((prev) => ({ ...prev, [path]: !prev[path] }));
  };

  // AIS-38c: seleciona o arquivo pedido pelo Inspector, expande as pastas e leva a grade até ele
  useEffect(() => {
    if (!reveal) return;
    const expanded: Record<string, boolean> = {};
    let cur = getParentPath(reveal.path);
    const parent = cur;
    while (cur) {
      expanded[cur] = true;
      cur = getParentPath(cur);
    }
    setExpandedFolders((prev) => ({ ...prev, ...expanded }));
    setSearchFilter('');
    setGridFolder(parent ?? 'res://');
    setSelectedPath(reveal.path);
  }, [reveal]);

  // Build true hierarchical tree rooted at res://
  const treeNodes = useMemo(() => {
    const allFiles: Record<string, any> = { ...project.files };
    const now = new Date().toISOString();

    // Ensure res:// root exists
    if (!allFiles['res://']) {
      allFiles['res://'] = {
        path: 'res://',
        name: 'res://',
        isDirectory: true,
        updatedAt: now,
      };
    }

    // Ensure all intermediate directories exist up to res://
    for (const f of Object.values(project.files)) {
      let cur = getParentPath(f.path);
      while (cur && cur !== 'res://') {
        if (!allFiles[cur]) {
          const parts = cur.replace('res://', '').split('/').filter(Boolean);
          const dirName = parts[parts.length - 1] || 'folder';
          allFiles[cur] = {
            path: cur,
            name: dirName,
            isDirectory: true,
            updatedAt: now,
          };
        }
        cur = getParentPath(cur);
      }
    }

    // Map parentPath -> children
    const childrenMap = new Map<string, any[]>();
    for (const f of Object.values(allFiles)) {
      if (f.path === 'res://') continue;
      const parent = getParentPath(f.path) || 'res://';
      if (!childrenMap.has(parent)) {
        childrenMap.set(parent, []);
      }
      childrenMap.get(parent)!.push(f);
    }

    // Sort children: directories first, then alphabetical
    const sortList = (list: any[]) => {
      return list.sort((a, b) => {
        if (a.isDirectory && !b.isDirectory) return -1;
        if (!a.isDirectory && b.isDirectory) return 1;
        return a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
      });
    };

    function createTreeNode(file: any, depth: number): FileTreeNode {
      const rawChildren = childrenMap.get(file.path) || [];
      const sorted = sortList(rawChildren);
      const children = sorted.map((child) => createTreeNode(child, depth + 1));
      return { file, children, depth };
    }

    return createTreeNode(allFiles['res://'], 0);
  }, [project.files]);

  // Flattened visible items with expansion & search filtering
  const visibleEntries = useMemo(() => {
    if (!treeNodes) return [];

    if (searchFilter.trim()) {
      const query = searchFilter.toLowerCase().trim();
      const results: FileTreeNode[] = [];
      function searchTree(node: FileTreeNode) {
        if (node.file.name.toLowerCase().includes(query)) {
          results.push(node);
        }
        for (const child of node.children) {
          searchTree(child);
        }
      }
      searchTree(treeNodes);
      return results;
    }

    const list: FileTreeNode[] = [];
    function flatten(node: FileTreeNode) {
      list.push(node);
      if (node.file.isDirectory && expandedFolders[node.file.path]) {
        for (const child of node.children) {
          flatten(child);
        }
      }
    }
    flatten(treeNodes);
    return list;
  }, [treeNodes, expandedFolders, searchFilter]);

  const getFileIcon = (file: any, size = 'w-3.5 h-3.5') => {
    if (file.isDirectory) {
      return expandedFolders[file.path] ? (
        <FolderOpen className={`${size} text-amber-400 shrink-0`} />
      ) : (
        <Folder className={`${size} text-amber-400 shrink-0`} />
      );
    }
    const ext = file.extension?.toLowerCase();
    if (file.path.endsWith('.scene.json')) {
      return <Film className={`${size} text-blue-400 shrink-0`} />;
    }
    if (file.path.endsWith('.sprite.json')) {
      return <Layers className={`${size} text-sky-400 shrink-0`} />;
    }
    if (file.path.endsWith('.video.json') || ext === 'mp4' || ext === 'webm' || ext === 'mov' || ext === 'ogv') {
      return <Film className={`${size} text-cyan-400 shrink-0`} />;
    }
    if (file.name.endsWith('.mat.json') || file.name.endsWith('.material.json')) {
      return <Palette className={`${size} text-blue-400 shrink-0`} />;
    }
    if (file.path.endsWith('.prefab.json')) {
      return <Package className={`${size} text-violet-400 shrink-0`} />;
    }
    if (ext === 'cfg') {
      return <Puzzle className={`${size} text-indigo-400 shrink-0`} />;
    }
    if (ext === 'json') {
      return <FileJson className={`${size} text-emerald-400 shrink-0`} />;
    }
    if (ext === 'xml' || ext === 'svg') {
      return <Braces className={`${size} text-orange-400 shrink-0`} />;
    }
    if (ext === 'ts' || ext === 'tsx') {
      return <FileCode className={`${size} text-blue-400 shrink-0`} />;
    }
    if (ext === 'js' || ext === 'jsx') {
      return <Code2 className={`${size} text-amber-300 shrink-0`} />;
    }
    if (ext === 'txt' || ext === 'md') {
      return <FileText className={`${size} text-[#9ca7b7] shrink-0`} />;
    }
    if (ext === 'gltf' || ext === 'glb' || ext === 'obj' || ext === 'fbx' || ext === 'dae') {
      return <Box className={`${size} text-cyan-400 shrink-0`} />;
    }
    if (ext === 'png' || ext === 'jpg' || ext === 'webp') {
      return <ImageIcon className={`${size} text-purple-400 shrink-0`} />;
    }
    if (ext === 'wav' || ext === 'ogg' || ext === 'mp3') {
      return <Volume2 className={`${size} text-pink-400 shrink-0`} />;
    }
    return <File className={`${size} text-[#8b97a8] shrink-0`} />;
  };

  // AIS-28: roteador único `resolveFileAction` (reutilizado pelo AIS-31); sufixos compostos vencem .json
  const openFile = (file: any) => {
    const action = resolveFileAction(file);
    switch (action.kind) {
      case 'loadScene':
        loadScene(file.path);
        break;
      case 'scriptEditor':
        openFileInScriptEditor(file.path, false);
        break;
      case 'texturePreview':
        setIsTexturePreviewOpen(true);
        break;
      case 'assetImport':
        // AIS-33: o duplo clique abre o modal COM o arquivo de res:// (os bytes saem do projeto), não vazio
        openAssetImportWithSource({ path: file.path, name: file.name });
        break;
      case 'audio':
        setIsSoundModalOpen(true);
        break;
      case 'spriteEditor':
        setIsSpriteEditorOpen(true);
        break;
      case 'videoEditor':
        setIsVideoEditorOpen(true);
        break;
      case 'comingSoon':
        addLog('log', `${file.name}: ${action.hint}`);
        break;
      default:
        break;
    }
  };

  const handleDoubleClick = (file: any) => {
    if (file.isDirectory) {
      if (viewMode === 'grid') {
        setGridFolder(file.path);
        setSearchFilter('');
      } else {
        toggleFolder(file.path);
      }
      return;
    }
    openFile(file);
  };

  const resolveTargetFolder = () => {
    if (!selectedPath) return 'res://';
    if (selectedPath.endsWith('/')) return selectedPath;
    const parent = getParentPath(selectedPath);
    return parent ? parent : 'res://';
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploaded = e.target.files;
    if (!uploaded || uploaded.length === 0) return;

    const targetFolder = resolveTargetFolder();
    const all = Array.from(uploaded);

    // AIS-28-C04 / AIS-33: modelo 3D só entra pelo mini-editor (AssetImportModal), nunca direto como arquivo; o modal recebe
    // os BYTES. Com um .gltf, os outros arquivos escolhidos junto (.bin, imagens) são as dependências dele.
    const modelFile = all.find((f) => isModelFileName(f.name));
    const gltfDeps = modelFile && /.gltf$/i.test(modelFile.name) ? all.filter((f) => f !== modelFile && !isModelFileName(f.name)) : [];
    if (modelFile) {
      void Promise.all([modelFile.arrayBuffer(), ...gltfDeps.map((f) => f.arrayBuffer())]).then(([bytes, ...depBytes]) => {
        openAssetImportWithSource({ name: modelFile.name, bytes, siblings: gltfDeps.map((f, i) => ({ rel: f.name, bytes: depBytes[i] })) });
      });
    }

    for (let i = 0; i < uploaded.length; i++) {
      const file = uploaded[i];
      if (isModelFileName(file.name) || gltfDeps.includes(file)) continue;
      const reader = new FileReader();

      if (isBinaryUploadName(file.name) || file.type.startsWith('image/') || file.type.startsWith('audio/') || file.type.startsWith('video/')) {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }

      reader.onload = () => {
        const content = reader.result as string;
        const targetPath = `${targetFolder}${file.name}`;
        importFileContent(targetPath, content, file.name);
      };
    }

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleNewFolder = () => {
    const targetFolder = resolveTargetFolder();
    const folderName = `folder_${Math.random().toString(36).substring(2, 6)}`;
    const fullPath = `${targetFolder}${folderName}/`;
    createFolder(fullPath);
    setExpandedFolders((prev) => ({ ...prev, [targetFolder]: true, [fullPath]: true }));
    if (viewMode === 'grid') setGridFolder(targetFolder);
    startRename({ path: fullPath, name: folderName, isDirectory: true });
  };

  const handleCreateCustomFile = (type: NewFileType) => {
    // AIS-28b: .ts/.js em res://scripts/ (quando a seleção é a raiz); .json/.xml/.txt na pasta selecionada
    const plan = planNewFile(type, project.files, { selectedFolder: resolveTargetFolder() });
    createFile(plan.path, plan.content);
    openFileInScriptEditor(plan.path, false);
    setShowNewFileMenu(false);
  };

  // ── AIS-28: renomear · mover · excluir (adapter provisório até o AIS-29e) ───────────────────────────
  const lookupFile = (path: string): GridFile => {
    const f = project.files[path];
    return f
      ? { path, name: f.name, isDirectory: !!f.isDirectory, size: f.size }
      : { path, name: path === 'res://' ? 'res://' : baseNameOf(path), isDirectory: isFolderPath(path) };
  };

  const startRename = (file: GridFile) => {
    if (file.path === 'res://') return;
    setSelectedPath(file.path);
    setIsRenaming(file.path);
    setRenameValue(file.name);
    setRenameError(null);
    renameDone.current = false;
  };

  const cancelRename = () => {
    renameDone.current = true;
    setIsRenaming(null);
    setRenameError(null);
  };

  const commitRename = (file: GridFile) => {
    if (renameDone.current) return;
    if (renameValue === file.name) {
      cancelRename();
      return;
    }
    const validity = validateName(renameValue);
    if (!validity.ok) {
      setRenameError(validity.error ?? 'Nome inválido.');
      return;
    }
    const folder = parentFolderOf(file.path) ?? 'res://';
    const to = pathWithName(file.path, renameValue);
    const plan = planPathChange(project.files, file.path, to);
    if (plan.conflict) {
      setConflict({ kind: 'rename', file, folder, name: renameValue, suggested: uniqueName(project.files, folder, renameValue, file.isDirectory) });
      cancelRename();
      return;
    }
    if (!plan.ok) {
      setRenameError(plan.error ?? 'Não foi possível renomear.');
      return;
    }
    void runMove(file.path, to).then((ok) => ok && setSelectedPath(to));
    cancelRename();
  };

  /** AIS-29e: toda movimentação/renomeação passa pelo serviço (id preservado, referências atualizadas atomicamente). */
  const runMove = async (from: string, to: string): Promise<boolean> => {
    const result = await moveResource({ path: from }, to, { confirmed: true });
    if (!result.ok) {
      addLog('warn', `Não foi possível mover ${from}: ${result.message}`);
      return false;
    }
    addLog('log', `Movido ${from} → ${to}${result.rewritten.length ? ` (${result.rewritten.length} arquivo(s) com referências atualizadas)` : ''}`);
    if (result.deferred.length) addLog('warn', 'As referências na cena aberta foram atualizadas em memória: salve a cena para gravá-las.');
    return true;
  };

  const moveItem = (file: GridFile, destFolder: string) => {
    const to = pathInFolder(file.path, destFolder);
    if (to === file.path) return;
    const plan = planPathChange(project.files, file.path, to);
    if (plan.conflict) {
      setConflict({ kind: 'move', file, folder: destFolder, name: file.name, suggested: uniqueName(project.files, destFolder, file.name, file.isDirectory) });
      return;
    }
    void runMove(file.path, to).then((ok) => {
      if (!ok) return;
      setExpandedFolders((prev) => ({ ...prev, [destFolder]: true }));
      setSelectedPath(to);
    });
  };

  const confirmConflict = (newName: string) => {
    if (!conflict) return;
    const { kind, file, folder } = conflict;
    const to = kind === 'move' ? pathInFolder(folder + newName + (file.isDirectory ? '/' : ''), folder) : pathWithName(file.path, newName);
    void runMove(file.path, to).then((ok) => ok && setSelectedPath(to));
    setConflict(null);
  };

  const dragProps = (file: GridFile): React.HTMLAttributes<HTMLDivElement> =>
    file.path === 'res://' || isRenaming === file.path
      ? {}
      : {
          draggable: true,
          onDragStart: (e) => {
            e.dataTransfer.setData(DRAG_MIME, file.path);
            e.dataTransfer.effectAllowed = 'copyMove'; // mover entre pastas; copiar para a cena (AIS-31)
          },
        };

  const dropProps = (file: GridFile): React.HTMLAttributes<HTMLDivElement> =>
    !file.isDirectory
      ? {}
      : {
          onDragOver: (e) => {
            if (!e.dataTransfer.types.includes(DRAG_MIME)) return;
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            setDropTarget(file.path);
          },
          onDragLeave: () => setDropTarget((prev) => (prev === file.path ? null : prev)),
          onDrop: (e) => {
            e.preventDefault();
            setDropTarget(null);
            const from = e.dataTransfer.getData(DRAG_MIME);
            if (from) moveItem(lookupFile(from), file.path);
          },
        };

  const titleFor = (file: GridFile): string | undefined => (file.path.endsWith('.prefab.json') ? PREFAB_COMING_SOON : undefined);

  const renderName = (file: GridFile, className: string) =>
    isRenaming === file.path ? (
      <input
        autoFocus
        value={renameValue}
        aria-label="Novo nome"
        aria-invalid={!!renameError}
        title={renameError ?? undefined}
        spellCheck={false}
        onFocus={(e) => e.currentTarget.select()}
        onChange={(e) => {
          setRenameValue(e.target.value);
          setRenameError(null);
        }}
        onClick={(e) => e.stopPropagation()}
        onDoubleClick={(e) => e.stopPropagation()}
        onBlur={() => commitRename(file)}
        onKeyDown={(e) => {
          e.stopPropagation();
          if (e.key === 'Enter') {
            e.preventDefault();
            commitRename(file);
          } else if (e.key === 'Escape') {
            e.preventDefault();
            cancelRename();
          }
        }}
        className={`bg-[#141820] text-[#dfe4ec] px-1 rounded border outline-none min-w-0 ${renameError ? 'border-rose-500' : 'border-[#4982ea]'} ${viewMode === 'grid' ? 'w-full text-center text-[10px]' : 'flex-1 text-xs'}`}
      />
    ) : (
      <span className={className}>
        {file.name}
        {unusedModelFiles.has(file.path) && (
          <em className="ml-1.5 text-[9px] not-italic text-amber-400/80" title="Nenhuma cena ou prefab usa este arquivo de modelo (o pacote do asset também). Decida se mantém ou exclui." data-testid="unused-badge">
            sem uso
          </em>
        )}
      </span>
    );

  const openContextMenu = (e: React.MouseEvent, file: GridFile) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedPath(file.path);
    setContextMenu({ x: e.clientX, y: e.clientY, file });
  };

  /** AIS-38c: arquivos gerados pela importação do modelo (manifesto, rig, PNGs, dependências do .gltf). Vazio se não for modelo. */
  const packageOf = (path: string): PackageItem[] => {
    const entry = globalResourceRegistry.getByUri(path);
    if (!entry || entry.kind !== 'mesh' || !entry.importSettings) return [];
    return modelPackage(
      parseModelImportSettings(entry.importSettings),
      (ref) => {
        const r = globalResourceRegistry.resolve(ref as never);
        return r.status === 'resolved' ? { uri: r.entry.uri, kind: r.entry.kind } : null;
      },
      entry.resourceId
    ).items;
  };

  const requestDelete = (file: GridFile) => {
    if (file.path === 'res://') return;
    setDeleteTarget(file);
    setDeletePlan(null);
    setDeletePackage(packageOf(file.path));
    // o plano (conteúdo + consumidores) vem do serviço; nada é gravado até a confirmação
    void planResourceDeletion({ path: file.path }).then(setDeletePlan);
  };

  const closeDelete = () => {
    setDeleteTarget(null);
    setDeletePlan(null);
    setDeletePackage([]);
  };

  const replaceCandidates = (plan: DeletionPlan | null) => {
    if (!plan?.canReplace || !plan.replaceKind) return [];
    const removed = new Set(plan.paths);
    return globalResourceRegistry
      .list(plan.replaceKind as never)
      .filter((e) => !removed.has(e.uri))
      .map((e) => ({ ref: globalResourceRegistry.makeRef(e.resourceId)!, label: e.uri }));
  };

  const onListKeyDown = (e: React.KeyboardEvent) => {
    const tag = (e.target as HTMLElement).tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    if (e.key === 'F2') {
      e.preventDefault();
      startRename(lookupFile(selectedPath));
    } else if (e.key === 'Delete') {
      e.preventDefault();
      requestDelete(lookupFile(selectedPath));
    }
  };

  const setMode = (mode: 'tree' | 'grid') => {
    if (mode === 'grid') setGridFolder(selectedPath.endsWith('/') ? selectedPath : parentFolderOf(selectedPath) ?? 'res://');
    setViewMode(mode);
    try {
      globalThis.localStorage?.setItem('nodimus.pref.fsViewMode', mode);
    } catch {
      /* preferência só da sessão */
    }
  };

  // entradas da grade: conteúdo da pasta aberta (ou resultados da busca)
  const gridEntries: GridFile[] = useMemo(() => {
    const toGrid = (n: FileTreeNode): GridFile => ({ path: n.file.path, name: n.file.name, isDirectory: !!n.file.isDirectory, size: n.file.size });
    if (searchFilter.trim()) return visibleEntries.filter((n) => n.file.path !== 'res://').map(toGrid);
    const find = (n: FileTreeNode): FileTreeNode | null => {
      if (n.file.path === gridFolder) return n;
      for (const c of n.children) {
        const r = find(c);
        if (r) return r;
      }
      return null;
    };
    const node = treeNodes ? find(treeNodes) : null;
    return node ? node.children.map(toGrid) : [];
  }, [treeNodes, gridFolder, searchFilter, visibleEntries]);

  return (
    <div className="flex flex-col h-full bg-[#202531] border-r border-[#2c3345] select-none">
      {/* Header */}
      <div className="h-8 border-b border-[#2c3345] px-2.5 flex items-center justify-between bg-[#1e232f]">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-[#dfe4ec]">
          <Folder className="w-3.5 h-3.5 text-amber-400" />
          <span>FileSystem</span>
        </div>

        {/* Toolbar actions */}
        <div className="flex items-center gap-1">
          {/* AIS-28: árvore × grade de ícones */}
          <button
            onClick={() => setMode(viewMode === 'tree' ? 'grid' : 'tree')}
            className="p-1 rounded hover:bg-[#2c3345] text-[#b3bed0] hover:text-white transition-colors"
            title={viewMode === 'tree' ? 'Modo grade de ícones' : 'Modo árvore'}
            aria-label={viewMode === 'tree' ? 'Modo grade' : 'Modo árvore'}
            aria-pressed={viewMode === 'grid'}
          >
            {viewMode === 'tree' ? <LayoutGrid className="w-3.5 h-3.5" /> : <List className="w-3.5 h-3.5" />}
          </button>

          {/* New Folder */}
          <button
            onClick={handleNewFolder}
            className="p-1 rounded hover:bg-[#2c3345] text-[#b3bed0] hover:text-white transition-colors"
            title="Create Folder"
            aria-label="Nova pasta"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>

          {/* New Script / File Menu */}
          <div className="relative">
            <button
              onClick={() => setShowNewFileMenu(!showNewFileMenu)}
              className="p-1 rounded hover:bg-[#2c3345] text-emerald-400 hover:text-emerald-300 transition-colors"
              title="Novo Arquivo de Código / Script / Texto"
            >
              <FileCode className="w-3.5 h-3.5" />
            </button>

            {showNewFileMenu && (
              <div className="absolute top-full left-0 mt-1 w-44 bg-[#1e232f] border border-[#2c3345] rounded shadow-xl py-1 z-50 text-xs">
                <div className="px-2 py-1 text-[10px] text-[#8b97a8] uppercase font-semibold border-b border-[#2c3345]">
                  Criar Arquivo
                </div>
                <button
                  onClick={() => handleCreateCustomFile('ts')}
                  className="w-full text-left px-2.5 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 text-blue-300"
                >
                  <FileCode className="w-3.5 h-3.5" /> Script TypeScript (.ts)
                </button>
                <button
                  onClick={() => handleCreateCustomFile('js')}
                  className="w-full text-left px-2.5 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 text-amber-300"
                >
                  <Code2 className="w-3.5 h-3.5" /> Módulo JavaScript (.js)
                </button>
                <button
                  onClick={() => handleCreateCustomFile('json')}
                  className="w-full text-left px-2.5 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 text-emerald-300"
                >
                  <FileJson className="w-3.5 h-3.5" /> Configuração JSON (.json)
                </button>
                <button
                  onClick={() => handleCreateCustomFile('xml')}
                  className="w-full text-left px-2.5 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 text-orange-300"
                >
                  <Braces className="w-3.5 h-3.5" /> Definição XML (.xml)
                </button>
                <button
                  onClick={() => handleCreateCustomFile('txt')}
                  className="w-full text-left px-2.5 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 text-[#dfe4ec]"
                >
                  <FileText className="w-3.5 h-3.5" /> Documento Texto (.txt)
                </button>
                <button
                  onClick={() => {
                    const name = prompt('Nome do novo material:', 'Gold_Material');
                    if (name) {
                      const cleanName = name.replace(/[^a-zA-Z0-9_-]/g, '_');
                      const path = `res://materials/${cleanName}.mat.json`;
                      const content = JSON.stringify(
                        {
                          name: cleanName,
                          shadingModel: 'Standard',
                          color: { r: 0.96, g: 0.78, b: 0.25, a: 1 },
                          roughness: 0.15,
                          metalness: 0.95,
                          textureType: 'none',
                        },
                        null,
                        2
                      );
                      createFile(path, content);
                      setIsTexturePreviewOpen(true);
                      setShowNewFileMenu(false);
                      addLog('log', `Novo material criado: ${path}`);
                    }
                  }}
                  className="w-full text-left px-2.5 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 text-cyan-300"
                >
                  <Palette className="w-3.5 h-3.5" /> Material PBR (.mat.json)
                </button>
                <button
                  onClick={() => {
                    const name = prompt('Nome do preset de vídeo:', 'Cyberpunk_Display');
                    if (name) {
                      const cleanName = name.replace(/[^a-zA-Z0-9_-]/g, '_');
                      const path = `res://videos/${cleanName}.video.json`;
                      const content = JSON.stringify(
                        {
                          name: cleanName,
                          url: '',
                          shape: 'CurvedScreen',
                          aspectRatio: '16:9',
                          emissiveIntensity: 0.8,
                          roughness: 0.3,
                          metalness: 0.1,
                          loop: true,
                          muted: true,
                          playbackRate: 1,
                        },
                        null,
                        2
                      );
                      createFile(path, content);
                      setIsVideoEditorOpen(true);
                      setShowNewFileMenu(false);
                      addLog('log', `Preset de vídeo criado: ${path}`);
                    }
                  }}
                  className="w-full text-left px-2.5 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 text-blue-300"
                >
                  <Film className="w-3.5 h-3.5 text-cyan-400" /> Tela & Vídeo 3D (.video.json)
                </button>
                <button
                  onClick={() => {
                    const name = prompt('Nome do Sprite (ex: PlayerHero, SlimeMonster, FX_Flame):');
                    if (name) {
                      const cleanName = name.replace(/[^a-zA-Z0-9_-]/g, '_');
                      const path = `res://sprites/${cleanName}.sprite.json`;
                      const content = JSON.stringify(
                        {
                          name: cleanName,
                          sheetConfig: {
                            frameWidth: 32,
                            frameHeight: 32,
                            columns: 4,
                            rows: 1,
                          },
                          animations: [
                            { id: 'anim_idle', name: 'idle', fps: 8, loopMode: 'loop', frameIndices: [0, 1, 2, 3] },
                          ],
                        },
                        null,
                        2
                      );
                      createFile(path, content);
                      setIsSpriteEditorOpen(true);
                      setShowNewFileMenu(false);
                      addLog('log', `Sprite criado: ${path}`);
                    }
                  }}
                  className="w-full text-left px-2.5 py-1.5 hover:bg-[#2c3345] flex items-center gap-2 text-sky-300"
                >
                  <Layers className="w-3.5 h-3.5 text-sky-400" /> Sprite & Animação 2D/3D (.sprite.json)
                </button>
              </div>
            )}
          </div>

          {/* Import file */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-1 rounded hover:bg-[#2c3345] text-[#b3bed0] hover:text-white transition-colors"
            title="Upload Files (PNG, JPG, GLTF, Audio)"
          >
            <Upload className="w-3.5 h-3.5 text-blue-400" />
          </button>

          {/* Import 3D Asset (Mini-Editor) */}
          <button
            onClick={() => setIsAssetImportModalOpen(true)}
            className="p-1 rounded hover:bg-[#2c3345] text-cyan-400 hover:text-cyan-300 transition-colors"
            title="Importar 3D — abre o mini-editor de modelos (Gizmo, Texturas, Rig, Animações, SketchUp Man)"
            aria-label="Importar 3D"
          >
            <Box className="w-3.5 h-3.5" />
          </button>

          {/* Delete */}
          <button
            disabled={!selectedPath || selectedPath === 'res://'}
            onClick={() => selectedPath && requestDelete(lookupFile(selectedPath))}
            className={`p-1 rounded transition-colors ${
              selectedPath && selectedPath !== 'res://'
                ? 'hover:bg-rose-900/30 text-[#b3bed0] hover:text-rose-400'
                : 'text-[#485368] cursor-not-allowed'
            }`}
            title="Delete File"
            aria-label="Excluir"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept={UPLOAD_ACCEPT}
            className="hidden"
            onChange={handleFileUpload}
          />
        </div>
      </div>

      {/* Search Input */}
      <div className="px-2 py-1.5 border-b border-[#2c3345] bg-[#1a1e29]">
        <div className="relative flex items-center">
          <Search className="w-3.5 h-3.5 absolute left-2 text-[#8b97a8] pointer-events-none" />
          <input
            type="text"
            placeholder="Search files..."
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            className="w-full bg-[#141820] text-xs text-[#dfe4ec] pl-7 pr-2 py-1 rounded border border-[#2c3345] focus:border-[#4982ea] outline-none"
          />
        </div>
      </div>

      {/* File List (árvore) ou grade de ícones */}
      {viewMode === 'grid' ? (
        <FileGrid
          folder={searchFilter.trim() ? null : gridFolder}
          entries={gridEntries}
          selectedPath={selectedPath}
          dropTarget={dropTarget}
          onUp={!searchFilter.trim() && parentFolderOf(gridFolder) ? () => setGridFolder(parentFolderOf(gridFolder) ?? 'res://') : null}
          onSelect={(f) => setSelectedPath(f.path)}
          onOpen={(f) => handleDoubleClick(f)}
          onContextMenu={openContextMenu}
          renderIcon={(f, size) => getFileIcon(f, size)}
          renderName={renderName}
          dragProps={dragProps}
          dropProps={dropProps}
          titleFor={titleFor}
        />
      ) : (
      <div className="flex-1 overflow-y-auto py-1 px-1 text-xs outline-none" tabIndex={0} onKeyDown={onListKeyDown}>
        {visibleEntries.map(({ file, depth }) => {
          const isSelected = selectedPath === file.path;
          const isDir = file.isDirectory;
          const isRoot = file.path === 'res://';
          const isExpanded = expandedFolders[file.path];

          return (
            <div
              key={file.path}
              data-path={file.path}
              data-resource-id={globalResourceRegistry.getByUri(file.path)?.resourceId}
              title={titleFor(file)}
              onClick={() => setSelectedPath(file.path)}
              onDoubleClick={() => handleDoubleClick(file)}
              onContextMenu={(e) => openContextMenu(e, file)}
              {...dragProps(file)}
              {...dropProps(file)}
              style={{ paddingLeft: `${Math.max(0, depth * 14 + 4)}px` }}
              className={`flex items-center h-6 pr-2 rounded-sm cursor-pointer transition-colors ${
                dropTarget === file.path
                  ? 'bg-[#273247] ring-1 ring-[#4982ea] text-white'
                  : isSelected
                    ? 'bg-[#4982ea] text-white'
                    : 'hover:bg-[#272e3d] text-[#dfe4ec]'
              }`}
            >
              {/* Expand arrow if directory */}
              <div
                onClick={(e) => {
                  if (isDir) {
                    e.stopPropagation();
                    toggleFolder(file.path);
                  }
                }}
                className="w-4 h-4 flex items-center justify-center shrink-0 text-[#8b97a8] hover:text-white"
              >
                {isDir ? (
                  isExpanded ? (
                    <ChevronDown className="w-3 h-3" />
                  ) : (
                    <ChevronRight className="w-3 h-3" />
                  )
                ) : null}
              </div>

              {/* Icon */}
              <div className="mr-1.5 flex items-center">{getFileIcon(file)}</div>

              {/* Name (inline rename: F2 / menu de contexto) */}
              {renderName(
                { path: file.path, name: file.name, isDirectory: !!isDir },
                `truncate flex-1 ${isRoot ? 'font-semibold text-amber-300 tracking-wide' : 'font-normal'}`
              )}

              {/* File size info */}
              {!isDir && file.size !== undefined && isRenaming !== file.path && (
                <span className="text-[10px] text-[#8b97a8] ml-1 shrink-0 font-mono">
                  {file.size > 1024 ? `${(file.size / 1024).toFixed(1)}k` : `${file.size}b`}
                </span>
              )}
            </div>
          );
        })}
      </div>
      )}

      {/* Bottom Path Bar */}
      <div className="h-6 px-2 border-t border-[#2c3345] bg-[#1a1e29] text-[10px] text-[#8b97a8] flex items-center truncate">
        <span>Path: {selectedPath}</span>
      </div>

      {contextMenu && (
        <FileContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          isDirectory={contextMenu.file.isDirectory}
          isRoot={contextMenu.file.path === 'res://'}
          canOpen={resolveFileAction(contextMenu.file).kind !== 'none' && resolveFileAction(contextMenu.file).kind !== 'comingSoon'}
          openHint={titleFor(contextMenu.file)}
          onOpen={() => openFile(contextMenu.file)}
          onNewFolder={() => {
            setSelectedPath(contextMenu.file.path);
            const folderName = `folder_${Math.random().toString(36).substring(2, 6)}`;
            const fullPath = `${contextMenu.file.path}${folderName}/`;
            createFolder(fullPath);
            setExpandedFolders((prev) => ({ ...prev, [contextMenu.file.path]: true, [fullPath]: true }));
            startRename({ path: fullPath, name: folderName, isDirectory: true });
          }}
          onRename={() => startRename(contextMenu.file)}
          onMove={() => setMoveTarget(contextMenu.file)}
          onDelete={() => requestDelete(contextMenu.file)}
          onReimport={(() => {
            const entry = globalResourceRegistry.getByUri(contextMenu.file.path);
            if (!entry || !globalAssetPipeline.importerFor(entry.uri)) return undefined;
            return () => {
              void globalAssetPipeline.reimport(entry.resourceId).then((r) =>
                addLog(r.ok ? 'log' : 'warn', r.ok ? `Reimportado ${entry.uri} (id ${entry.resourceId} preservado${r.cached ? ', cache' : ''})` : `Falha ao reimportar ${entry.uri}: ${r.diagnostics[0]?.message ?? 'erro'}`)
              );
            };
          })()}
          onClose={() => setContextMenu(null)}
        />
      )}

      {deleteTarget && (
        <ConfirmDeleteDialog
          path={deleteTarget.path}
          plan={deletePlan}
          replaceCandidates={replaceCandidates(deletePlan)}
          packageItems={deletePackage}
          onConfirm={(decision, packageUris = []) => {
            const target = deleteTarget;
            closeDelete();
            void deleteResource({ path: target.path }, { confirmed: true, decision }).then(async (result) => {
              if (!result.ok) {
                addLog('warn', `Exclusão não realizada: ${result.message}`);
                return;
              }
              // AIS-38c: pacote do asset, só o que o usuário marcou (cada arquivo, um a um; nada em silêncio)
              for (const uri of packageUris) {
                const r = await deleteResource({ path: uri }, { confirmed: true, decision: { kind: 'unresolve' } });
                addLog(r.ok ? 'log' : 'warn', r.ok ? `Excluído (pacote do asset): ${uri}` : `Não foi possível excluir ${uri}: ${r.message}`);
              }
              setSelectedPath('res://');
              if (gridFolder.startsWith(target.path)) setGridFolder('res://');
              const kept = result.plan.consumers.length;
              addLog('log', `Excluído: ${target.path}${result.removed.length > 1 ? ` (+${result.removed.length - 1} item(ns) dentro)` : ''}`);
              if (kept > 0) {
                addLog('warn', decision?.kind === 'replace'
                  ? `${kept} referência(s) apontadas para ${target.path} foram substituídas por ${decision.with.path}.`
                  : `${kept} referência(s) a ${target.path} ficaram como não resolvidas (preservadas nos arquivos, para reparo).`);
              }
              if (result.deferred.length) addLog('warn', 'As referências na cena aberta foram atualizadas em memória: salve a cena para gravá-las.');
            });
          }}
          onCancel={closeDelete}
        />
      )}

      {moveTarget && (
        <MoveToDialog
          path={moveTarget.path}
          folders={validMoveDestinations(project.files, moveTarget.path)}
          onConfirm={(folder) => {
            moveItem(moveTarget, folder);
            setMoveTarget(null);
          }}
          onCancel={() => setMoveTarget(null)}
        />
      )}

      {conflict && (
        <NameConflictDialog name={conflict.name} suggested={conflict.suggested} onConfirm={confirmConflict} onCancel={() => setConflict(null)} />
      )}
    </div>
  );
};
