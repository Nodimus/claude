import React from 'react';
import { ArrowUp } from 'lucide-react';

export interface GridFile {
  path: string;
  name: string;
  isDirectory: boolean;
  size?: number;
}

interface FileGridProps {
  /** Pasta aberta na grade (`null` durante uma busca: mostra os resultados). */
  folder: string | null;
  entries: GridFile[];
  selectedPath: string;
  dropTarget: string | null;
  onUp: (() => void) | null;
  onSelect: (file: GridFile) => void;
  onOpen: (file: GridFile) => void;
  onContextMenu: (e: React.MouseEvent, file: GridFile) => void;
  renderIcon: (file: GridFile, size: string) => React.ReactNode;
  renderName: (file: GridFile, className: string) => React.ReactNode;
  dragProps: (file: GridFile) => React.HTMLAttributes<HTMLDivElement>;
  dropProps: (file: GridFile) => React.HTMLAttributes<HTMLDivElement>;
  /** Tooltip por arquivo (ex.: "em breve" do prefab). */
  titleFor: (file: GridFile) => string | undefined;
}

/** AIS-28 — modo grade de ícones: o conteúdo de UMA pasta por vez (duplo clique entra na pasta ou abre o arquivo). */
export const FileGrid: React.FC<FileGridProps> = ({ folder, entries, selectedPath, dropTarget, onUp, onSelect, onOpen, onContextMenu, renderIcon, renderName, dragProps, dropProps, titleFor }) => (
  <div className="flex-1 flex flex-col min-h-0" data-testid="file-grid">
    <div className="flex items-center gap-1.5 px-2 py-1 border-b border-[#2c3345] bg-[#1a1e29] text-[10px] text-[#8b97a8]">
      <button
        onClick={() => onUp?.()}
        disabled={!onUp}
        aria-label="Subir uma pasta"
        title="Subir uma pasta"
        className={`p-0.5 rounded ${onUp ? 'hover:bg-[#2c3345] text-[#b3bed0] hover:text-white' : 'text-[#485368] cursor-not-allowed'}`}
      >
        <ArrowUp className="w-3 h-3" />
      </button>
      <span className="truncate font-mono">{folder ?? 'Resultados da busca'}</span>
    </div>
    <div className="flex-1 overflow-y-auto p-1.5">
      {entries.length === 0 ? (
        <div className="text-[11px] text-[#6e7b91] italic p-2">Pasta vazia.</div>
      ) : (
        <div className="grid gap-1.5" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(64px, 1fr))' }}>
          {entries.map((file) => {
            const selected = selectedPath === file.path;
            return (
              <div
                key={file.path}
                data-path={file.path}
                title={titleFor(file) ?? file.name}
                onClick={() => onSelect(file)}
                onDoubleClick={() => onOpen(file)}
                onContextMenu={(e) => onContextMenu(e, file)}
                {...dragProps(file)}
                {...dropProps(file)}
                className={`flex flex-col items-center gap-1 p-1.5 rounded cursor-pointer border ${
                  dropTarget === file.path ? 'border-[#4982ea] bg-[#273247]' : selected ? 'bg-[#4982ea] text-white border-transparent' : 'hover:bg-[#272e3d] text-[#dfe4ec] border-transparent'
                }`}
              >
                {renderIcon(file, 'w-7 h-7')}
                {renderName(file, 'w-full text-center text-[10px] break-all line-clamp-2 leading-tight')}
              </div>
            );
          })}
        </div>
      )}
    </div>
  </div>
);
