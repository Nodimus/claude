import React, { useEffect } from 'react';
import { FolderInput, FolderPlus, Pencil, Play, RefreshCw, Trash2 } from 'lucide-react';

export interface FileContextMenuProps {
  x: number;
  y: number;
  isDirectory: boolean;
  isRoot: boolean;
  /** Tooltip "em breve" quando o duplo clique do item ainda não tem ação (ex.: prefab). */
  openHint?: string;
  canOpen: boolean;
  onOpen: () => void;
  onNewFolder: () => void;
  onRename: () => void;
  onMove: () => void;
  onDelete: () => void;
  /** AIS-28c: reimportar o recurso (reutiliza as configurações e preserva o resourceId); ausente = não é recurso. */
  onReimport?: () => void;
  onClose: () => void;
}

/** AIS-28 — menu de contexto do FileSystemPanel (Abrir · Nova pasta aqui · Renomear · Mover para... · Excluir). */
export const FileContextMenu: React.FC<FileContextMenuProps> = ({ x, y, isDirectory, isRoot, openHint, canOpen, onOpen, onNewFolder, onRename, onMove, onDelete, onReimport, onClose }) => {
  useEffect(() => {
    const close = () => onClose();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('click', close);
    window.addEventListener('blur', close);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('click', close);
      window.removeEventListener('blur', close);
      window.removeEventListener('keydown', onKey);
    };
  }, [onClose]);

  const item = (label: string, icon: React.ReactNode, onClick: () => void, opts: { disabled?: boolean; title?: string; danger?: boolean } = {}) => (
    <button
      role="menuitem"
      disabled={opts.disabled}
      title={opts.title}
      onClick={(e) => {
        e.stopPropagation();
        onClose();
        onClick();
      }}
      className={`w-full text-left px-2.5 py-1.5 flex items-center gap-2 ${
        opts.disabled ? 'text-[#485368] cursor-not-allowed' : opts.danger ? 'text-rose-300 hover:bg-rose-900/30' : 'text-[#dfe4ec] hover:bg-[#2c3345]'
      }`}
    >
      {icon}
      {label}
    </button>
  );

  return (
    <div
      role="menu"
      aria-label="Menu do arquivo"
      style={{ left: x, top: y }}
      onClick={(e) => e.stopPropagation()}
      className="fixed z-50 min-w-[170px] bg-[#1e232f] border border-[#2c3345] rounded shadow-xl py-1 text-xs"
    >
      {!isDirectory && item('Abrir', <Play className="w-3.5 h-3.5" />, onOpen, { disabled: !canOpen, title: canOpen ? undefined : openHint ?? 'Sem editor associado' })}
      {isDirectory && item('Nova pasta aqui', <FolderPlus className="w-3.5 h-3.5" />, onNewFolder)}
      {!isDirectory && onReimport && item('Reimportar', <RefreshCw className="w-3.5 h-3.5" />, onReimport)}
      {item('Renomear (F2)', <Pencil className="w-3.5 h-3.5" />, onRename, { disabled: isRoot })}
      {item('Mover para...', <FolderInput className="w-3.5 h-3.5" />, onMove, { disabled: isRoot })}
      {item('Excluir', <Trash2 className="w-3.5 h-3.5" />, onDelete, { disabled: isRoot, danger: true })}
    </div>
  );
};
