import React, { useState, useRef, useEffect, useSyncExternalStore } from 'react';
import { useEditor, WorkspaceMode } from '../../core/EditorContext';
import { useEditorStore } from '../../core/editorStore';
import { ProjectStorage } from '../../core/projectStorage';
import { globalCommandManager } from '../../core/commandManager';
import { globalDocumentManager } from '../../core/documents/DocumentManager';
import {
  Play,
  Square,
  Pause,
  Film,
  RotateCcw,
  RotateCw,
  Settings,
  FolderOpen,
  Save,
  Download,
  Plus,
  HelpCircle,
  Code2,
  Box,
  Layers,
  Sparkles,
  Mountain,
  Trees,
  CloudFog,
  Headphones,
  Upload,
  Sliders,
  Terminal,
  FileCode,
  Palette,
  Puzzle,
} from 'lucide-react';

export const TopBar: React.FC = () => {
  // AIS-03f: Workspace mode, dock controls and modal toggles migrated to canonical Zustand EditorStore
  const workspaceMode             = useEditorStore((s) => s.workspaceMode);
  const setWorkspaceMode          = useEditorStore((s) => s.setWorkspaceMode);
  const isBottomOpen              = useEditorStore((s) => s.isBottomOpen);
  const setIsBottomOpen           = useEditorStore((s) => s.setIsBottomOpen);
  const setBottomTab              = useEditorStore((s) => s.setBottomTab);

  // Modal dialog toggles from Zustand
  const setIsPostProcessingOpen   = useEditorStore((s) => s.setIsPostProcessingOpen);
  const setIsTerrainEditorOpen    = useEditorStore((s) => s.setIsTerrainEditorOpen);
  const setIsTreeEditorOpen       = useEditorStore((s) => s.setIsTreeEditorOpen);
  const setIsFogModalOpen         = useEditorStore((s) => s.setIsFogModalOpen);
  const setIsSoundModalOpen       = useEditorStore((s) => s.setIsSoundModalOpen);
  const setIsParticleModalOpen    = useEditorStore((s) => s.setIsParticleModalOpen);
  const setIsAssetImportModalOpen = useEditorStore((s) => s.setIsAssetImportModalOpen);
  const setIsProjectSettingsOpen  = useEditorStore((s) => s.setIsProjectSettingsOpen);
  const setIsProjectManagerOpen   = useEditorStore((s) => s.setIsProjectManagerOpen);
  const setIsCreateNodeModalOpen  = useEditorStore((s) => s.setIsCreateNodeModalOpen);
  const setIsScriptEditorModalOpen= useEditorStore((s) => s.setIsScriptEditorModalOpen);
  const setIsTexturePreviewOpen   = useEditorStore((s) => s.setIsTexturePreviewOpen);
  const isExtensionsPanelOpen     = useEditorStore((s) => s.isExtensionsPanelOpen);
  const setIsExtensionsPanelOpen  = useEditorStore((s) => s.setIsExtensionsPanelOpen);
  const setIsVideoEditorOpen      = useEditorStore((s) => s.setIsVideoEditorOpen);
  const setIsSpriteEditorOpen     = useEditorStore((s) => s.setIsSpriteEditorOpen);

  // AIS-18: rótulos do próximo Undo/Redo (tooltip), reativos ao histórico do CommandManager
  useSyncExternalStore(
    (cb) => globalCommandManager.subscribe(cb),
    () => globalCommandManager.getVersion()
  );
  // AIS-18b: marcador de alterações não salvas (dirty por checkpoint do DocumentManager)
  const openDocuments = useSyncExternalStore(
    (cb) => globalDocumentManager.subscribe(cb),
    () => globalDocumentManager.list()
  );
  const sceneDirty = openDocuments.some((d) => d.kind === 'scene' && d.dirty);
  const undoLabel = globalCommandManager.getUndoLabel();
  const redoLabel = globalCommandManager.getRedoLabel();

  // Facade consumption for project, activeScene, undo/redo, play controls
  const {
    project,
    activeScene,
    isPlaying,
    isPaused,
    canUndo,
    canRedo,
    undo,
    redo,
    playProject,
    playScene,
    playMode,
    pauseGame,
    stopGame,
    saveCurrentScene,
    createNewScene,
  } = useEditor();

  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setActiveMenu(null);
      }
    };
    window.addEventListener('mousedown', handleClickOutside);
    return () => window.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleMenuClick = (menu: string) => {
    setActiveMenu(activeMenu === menu ? null : menu);
  };

  return (
    <header
      ref={menuRef}
      className="h-10 bg-[var(--gl-bg-strong)] border-b border-[var(--gl-border)] px-2 flex items-center justify-between select-none text-xs text-[var(--gl-text)] z-40 relative"
    >
      {/* Left Zone: Brand & Menu bar */}
      <div className="flex items-center gap-1">
        {/* Brand mark */}
        <div
          onClick={() => setIsProjectManagerOpen(true)}
          className="flex items-center gap-1.5 px-2 py-1 rounded bg-[var(--gl-panel-alt)] hover:bg-[var(--gl-accent-bg)] cursor-pointer mr-2 border border-[var(--gl-border-subtle)] transition-colors"
          title="Switch Project"
        >
          <div className="w-4 h-4 rounded bg-[var(--gl-accent)] flex items-center justify-center font-bold text-[10px] text-white">
            N
          </div>
          <span className="font-semibold text-[13px] tracking-wide text-white">Nodimus</span>
          <span className="text-[var(--gl-text-muted)] text-[11px] font-normal truncate max-w-[110px]">
            {project.name}
          </span>
        </div>

        {/* Menu Dropdowns */}
        <div className="flex items-center space-x-0.5">
          {/* Project Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('project')}
              className={`px-2 py-1 rounded hover:bg-[#2c3345] transition-colors ${
                activeMenu === 'project' ? 'bg-[#2c3345] text-white' : 'text-[#c2cbdb]'
              }`}
            >
              Project
            </button>
            {activeMenu === 'project' && (
              <div className="absolute top-full left-0 mt-0.5 w-48 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50">
                <button
                  onClick={() => {
                    setIsProjectSettingsOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Settings className="w-3.5 h-3.5 text-[#8b97a8]" /> Project Settings
                  </span>
                </button>
                <button
                  onClick={() => {
                    setIsExtensionsPanelOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2 text-indigo-300">
                    <Puzzle className="w-3.5 h-3.5 text-indigo-400" /> Extensões & Plugins (stub)
                  </span>
                </button>
                <button
                  onClick={() => {
                    setIsProjectManagerOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <FolderOpen className="w-3.5 h-3.5 text-[#8b97a8]" /> Project Manager
                  </span>
                </button>
                <div className="my-1 border-t border-[#2c3345]" />
                <button
                  onClick={() => {
                    saveCurrentScene();
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Save className="w-3.5 h-3.5 text-[#8b97a8]" /> Save Project
                  </span>
                  <span className="text-[10px] text-[#8b97a8]">Ctrl+S</span>
                </button>
                <button
                  onClick={async () => {
                    setActiveMenu(null);
                    await ProjectStorage.exportProjectAsNodimusFile(project);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Download className="w-3.5 h-3.5 text-[#8b97a8]" /> Export Project (.nodimus)
                  </span>
                </button>
              </div>
            )}
          </div>

          {/* Scene Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('scene')}
              className={`px-2 py-1 rounded hover:bg-[#2c3345] transition-colors ${
                activeMenu === 'scene' ? 'bg-[#2c3345] text-white' : 'text-[#c2cbdb]'
              }`}
            >
              Scene
            </button>
            {activeMenu === 'scene' && (
              <div className="absolute top-full left-0 mt-0.5 w-56 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50">
                <button
                  onClick={() => {
                    createNewScene('3D');
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Plus className="w-3.5 h-3.5 text-emerald-400" /> New 3D Scene
                </button>
                <button
                  onClick={() => {
                    createNewScene('Empty');
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Box className="w-3.5 h-3.5 text-[#8b97a8]" /> New Empty Scene
                </button>
                <button
                  onClick={() => {
                    saveCurrentScene();
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Save className="w-3.5 h-3.5 text-[#8b97a8]" /> Save Scene
                  </span>
                  <span className="text-[10px] text-[#8b97a8]">Ctrl+S</span>
                </button>

                <div className="my-1 border-t border-[#2c3345]" />
                <div className="px-3 py-1 text-[10px] font-semibold text-[#64748b] uppercase tracking-wider">
                  Ambiente da Cena Atual
                </div>

                <button
                  onClick={() => {
                    setIsPostProcessingOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  <span className="text-[#dfe4ec]">Post Processing (Cena)...</span>
                </button>
                <button
                  onClick={() => {
                    setIsFogModalOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <CloudFog className="w-3.5 h-3.5 text-sky-400" />
                  <span className="text-[#dfe4ec]">Fog & Atmosphere (Cena)...</span>
                </button>
                <button
                  onClick={() => {
                    setIsSoundModalOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Headphones className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="text-[#dfe4ec]">Sound & Audio (Cena)...</span>
                </button>
              </div>
            )}
          </div>

          {/* Edit Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('edit')}
              className={`px-2 py-1 rounded hover:bg-[#2c3345] transition-colors ${
                activeMenu === 'edit' ? 'bg-[#2c3345] text-white' : 'text-[#c2cbdb]'
              }`}
            >
              Edit
            </button>
            {activeMenu === 'edit' && (
              <div className="absolute top-full left-0 mt-0.5 w-44 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50">
                <button
                  disabled={!canUndo}
                  title={undoLabel ? `Undo: ${undoLabel}` : undefined}
                  onClick={() => {
                    undo();
                    setActiveMenu(null);
                  }}
                  className={`w-full text-left px-3 py-1.5 flex items-center justify-between ${
                    canUndo ? 'hover:bg-[#2c3345] text-[#dfe4ec]' : 'text-[#586377] cursor-not-allowed'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <RotateCcw className="w-3.5 h-3.5" /> Undo
                  </span>
                  <span className="text-[10px]">Ctrl+Z</span>
                </button>
                <button
                  disabled={!canRedo}
                  title={redoLabel ? `Redo: ${redoLabel}` : undefined}
                  onClick={() => {
                    redo();
                    setActiveMenu(null);
                  }}
                  className={`w-full text-left px-3 py-1.5 flex items-center justify-between ${
                    canRedo ? 'hover:bg-[#2c3345] text-[#dfe4ec]' : 'text-[#586377] cursor-not-allowed'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <RotateCw className="w-3.5 h-3.5" /> Redo
                  </span>
                  <span className="text-[10px]">Ctrl+Y</span>
                </button>
              </div>
            )}
          </div>

          {/* Debug Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('debug')}
              className={`px-2 py-1 rounded hover:bg-[#2c3345] transition-colors ${
                activeMenu === 'debug' ? 'bg-[#2c3345] text-white' : 'text-[#c2cbdb]'
              }`}
            >
              Debug
            </button>
            {activeMenu === 'debug' && (
              <div className="absolute top-full left-0 mt-0.5 w-52 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50">
                <button
                  onClick={() => {
                    playProject();
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Play className="w-3.5 h-3.5 text-emerald-400" /> Play Project
                  </span>
                  <span className="text-[10px] text-[#8b97a8]">F5</span>
                </button>
                <button
                  onClick={() => {
                    playScene();
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Film className="w-3.5 h-3.5 text-sky-400" /> Play Scene
                  </span>
                  <span className="text-[10px] text-[#8b97a8]">F6</span>
                </button>
                <button
                  disabled={!isPlaying}
                  onClick={() => {
                    stopGame();
                    setActiveMenu(null);
                  }}
                  className={`w-full text-left px-3 py-1.5 flex items-center justify-between ${
                    isPlaying ? 'hover:bg-[#2c3345] text-[#dfe4ec]' : 'text-[#485368] cursor-not-allowed'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <Square className="w-3.5 h-3.5 text-rose-400" /> Stop Simulation
                  </span>
                  <span className="text-[10px] text-[#8b97a8]">F8</span>
                </button>
                <div className="my-1 border-t border-[#2c3345]" />
                <button
                  onClick={() => {
                    setIsBottomOpen(true);
                    setBottomTab('debugger');
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Terminal className="w-3.5 h-3.5 text-[#8b97a8]" /> Open Debug Monitor
                </button>
              </div>
            )}
          </div>

          {/* Editor Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('editor')}
              className={`px-2 py-1 rounded hover:bg-[#2c3345] transition-colors ${
                activeMenu === 'editor' ? 'bg-[#2c3345] text-white' : 'text-[#c2cbdb]'
              }`}
            >
              Editor
            </button>
            {activeMenu === 'editor' && (
              <div className="absolute top-full left-0 mt-0.5 w-64 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50">
                <div className="px-3 py-1 text-[10px] font-semibold text-[#64748b] uppercase tracking-wider">
                  Código & Lógica
                </div>
                <button
                  onClick={() => {
                    setWorkspaceMode('Script');
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <FileCode className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-[#dfe4ec]">Modo Editor de Código (CodeMirror)</span>
                </button>
                <button
                  onClick={() => {
                    setIsScriptEditorModalOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Code2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[#dfe4ec]">Janela Script Editor Modal</span>
                </button>
                <button
                  onClick={() => {
                    setWorkspaceMode('VisualLogic');
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-[#dfe4ec]">Editor de Lógica Visual (Nodes)</span>
                </button>

                <div className="my-1 border-t border-[#2c3345]" />
                <div className="px-3 py-1 text-[10px] font-semibold text-[#64748b] uppercase tracking-wider">
                  Editores de Terreno & 3D
                </div>
                <button
                  onClick={() => {
                    setIsTerrainEditorOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Mountain className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[#dfe4ec]">Terrain Editor...</span>
                </button>
                <button
                  onClick={() => {
                    setIsTreeEditorOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Trees className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[#dfe4ec]">Tree Editor...</span>
                </button>
                <button
                  onClick={() => {
                    setIsParticleModalOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-[#dfe4ec]">Particle Generator...</span>
                </button>
                <button
                  onClick={() => {
                    setIsAssetImportModalOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Upload className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-[#dfe4ec]">Import 3D Asset (Mini-Editor)...</span>
                </button>

                <div className="my-1 border-t border-[#2c3345]" />
                <div className="px-3 py-1 text-[10px] font-semibold text-[#64748b] uppercase tracking-wider">
                  Estúdios de Textura, Vídeo & Sprite
                </div>
                <button
                  onClick={() => {
                    setIsTexturePreviewOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Palette className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-[#dfe4ec]">Editor de Textura & Material...</span>
                </button>
                <button
                  onClick={() => {
                    setIsVideoEditorOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Film className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-[#dfe4ec]">Vídeo Studio (Editor & Preview 3D)...</span>
                </button>
                <button
                  onClick={() => {
                    setIsSpriteEditorOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Layers className="w-3.5 h-3.5 text-sky-400" />
                  <span className="text-[#dfe4ec]">Sprite Studio (Pixel Editor & Billboard)...</span>
                </button>
                <button
                  onClick={() => {
                    setIsExtensionsPanelOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Puzzle className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="text-[#dfe4ec]">Painel de Extensões & Plugins (stub)...</span>
                </button>

                <div className="my-1 border-t border-[#2c3345]" />
                <button
                  onClick={() => {
                    setIsCreateNodeModalOpen(true);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Plus className="w-3.5 h-3.5 text-[#8b97a8]" />
                  <span className="text-[#dfe4ec]">Create Node Dialog</span>
                </button>
                <button
                  onClick={() => {
                    setIsBottomOpen(!isBottomOpen);
                    setActiveMenu(null);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#2c3345] flex items-center gap-2"
                >
                  <Sliders className="w-3.5 h-3.5 text-[#8b97a8]" />
                  <span className="text-[#dfe4ec]">Toggle Output Panel</span>
                </button>
              </div>
            )}
          </div>

          {/* Help Menu */}
          <div className="relative">
            <button
              onClick={() => handleMenuClick('help')}
              className={`px-2 py-1 rounded hover:bg-[#2c3345] transition-colors ${
                activeMenu === 'help' ? 'bg-[#2c3345] text-white' : 'text-[#c2cbdb]'
              }`}
            >
              Help
            </button>
            {activeMenu === 'help' && (
              <div className="absolute top-full left-0 mt-0.5 w-52 bg-[#202531] border border-[#2c3345] rounded shadow-xl py-1 z-50">
                <div className="px-3 py-2 text-[11px] text-[#8b97a8] border-b border-[#2c3345]">
                  <strong className="text-white block">Nodimus Game IDE</strong>
                  Modular Godot 3.x-inspired game editor architecture shell.
                </div>
                <div className="px-3 py-2 text-[11px] text-[#9ca7b7]">
                  Shortcuts:
                  <div className="mt-1 space-y-0.5 font-mono text-[10px]">
                    <div>F5 - Play Project</div>
                    <div>F8 - Stop Simulation</div>
                    <div>Ctrl+S - Save Scene</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Center Zone: Workspace Mode Switcher (3D Scene | Visual Logic | Script) */}
      <div className="flex items-center bg-[var(--gl-bg)] p-0.5 rounded-md border border-[var(--gl-border)]">
        <button
          onClick={() => setWorkspaceMode('3D')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-all ${
            workspaceMode === '3D'
              ? 'bg-[var(--gl-accent)] text-white shadow-sm'
              : 'text-[var(--gl-text-muted)] hover:text-[var(--gl-text)] hover:bg-[var(--gl-panel)]'
          }`}
          title="3D Three.js Viewport (with 2D Overlay Layer)"
        >
          <Box className="w-3.5 h-3.5" />
          <span>3D Scene</span>
        </button>

        <button
          onClick={() => setWorkspaceMode('VisualLogic')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-all ${
            workspaceMode === 'VisualLogic'
              ? 'bg-[var(--gl-accent)] text-white shadow-sm'
              : 'text-[var(--gl-text-muted)] hover:text-[var(--gl-text)] hover:bg-[var(--gl-panel)]'
          }`}
          title="Visual Logic (Behaviors, Events & Actions with dnd-kit)"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Visual Logic</span>
        </button>

        <button
          onClick={() => setWorkspaceMode('Script')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-all ${
            workspaceMode === 'Script'
              ? 'bg-[var(--gl-accent)] text-white shadow-sm'
              : 'text-[var(--gl-text-muted)] hover:text-[var(--gl-text)] hover:bg-[var(--gl-panel)]'
          }`}
          title="Editor de Código e Scripts (CodeMirror) — F7"
        >
          <FileCode className="w-3.5 h-3.5 text-blue-400" />
          <span>Script</span>
        </button>
      </div>

      {/* Right Zone: Play / Pause / Stop Simulation Controls */}
      <div className="flex items-center gap-1">
        {/* Current scene name indicator */}
        <div className="px-2 py-0.5 text-[11px] text-[var(--gl-text-muted)] hidden md:block max-w-[150px] truncate">
          {activeScene.name}.scene{sceneDirty ? ' •' : ''}
        </div>

        {/* Play Project (F5) */}
        <button
          onClick={playProject}
          className={`p-1.5 rounded transition-all flex items-center justify-center ${
            isPlaying && !isPaused && playMode === 'project'
              ? 'bg-emerald-600/30 text-emerald-400 border border-emerald-500/40'
              : 'hover:bg-[var(--gl-hover-bg)] text-[#b3bed0] hover:text-emerald-400'
          }`}
          title="Play Project (F5)"
        >
          <Play className="w-4 h-4 fill-current" />
        </button>

        {/* Play Scene (F6) */}
        <button
          onClick={playScene}
          className={`p-1.5 rounded transition-all flex items-center justify-center ${
            isPlaying && !isPaused && playMode === 'scene'
              ? 'bg-sky-600/30 text-sky-400 border border-sky-500/40'
              : 'hover:bg-[var(--gl-hover-bg)] text-[#b3bed0] hover:text-sky-400'
          }`}
          title="Play Scene Atual (F6)"
        >
          <Film className="w-4 h-4 fill-current" />
        </button>

        {/* Pause */}
        <button
          disabled={!isPlaying}
          onClick={pauseGame}
          className={`p-1.5 rounded transition-all flex items-center justify-center ${
            isPaused
              ? 'bg-amber-600/30 text-amber-400 border border-amber-500/40'
              : isPlaying
              ? 'hover:bg-[var(--gl-hover-bg)] text-[#b3bed0] hover:text-amber-400'
              : 'text-[#485368] cursor-not-allowed'
          }`}
          title="Pause / Resume Game"
        >
          <Pause className="w-4 h-4" />
        </button>

        {/* Stop (F8) */}
        <button
          disabled={!isPlaying}
          onClick={stopGame}
          className={`p-1.5 rounded transition-all flex items-center justify-center ${
            isPlaying
              ? 'bg-rose-600/30 text-rose-400 border border-rose-500/40 hover:bg-rose-600/50'
              : 'text-[#485368] cursor-not-allowed'
          }`}
          title="Stop Simulation (F8)"
        >
          <Square className="w-4 h-4 fill-current" />
        </button>
      </div>
    </header>
  );
};
