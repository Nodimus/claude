/**
 * Contract for versioned schema migrations (Vn -> Vn+1)
 * Rule: Prepared for future versions; does not invent V2 prematurely.
 */

import {
  CURRENT_PROJECT_SCHEMA_VERSION,
  CURRENT_SCENE_SCHEMA_VERSION,
  CURRENT_NODE_SCHEMA_VERSION,
  CURRENT_BEHAVIOR_SCHEMA_VERSION,
  CURRENT_PREFAB_SCHEMA_VERSION,
} from '../core/persistenceVersions';
import { migrateSceneV1ToV2, migrateSceneV2ToV3 } from './sceneMigrations';

export interface Migration<From = any, To = any> {
  fromVersion: number;
  toVersion: number;
  description: string;
  migrate: (data: From) => To;
}

export type EntityType = 'project' | 'scene' | 'node' | 'behavior' | 'prefab';

export interface MigrationRegistry {
  entityType: EntityType;
  currentVersion: number;
  migrations: Migration[];
}

/** A versão corrente nasce de `persistenceVersions.ts` (fonte única); `registerMigration` só a eleva junto com a constante. */
const REGISTRIES: Record<EntityType, MigrationRegistry> = {
  project: { entityType: 'project', currentVersion: CURRENT_PROJECT_SCHEMA_VERSION, migrations: [] },
  scene: { entityType: 'scene', currentVersion: CURRENT_SCENE_SCHEMA_VERSION, migrations: [] },
  node: { entityType: 'node', currentVersion: CURRENT_NODE_SCHEMA_VERSION, migrations: [] },
  behavior: { entityType: 'behavior', currentVersion: CURRENT_BEHAVIOR_SCHEMA_VERSION, migrations: [] },
  prefab: { entityType: 'prefab', currentVersion: CURRENT_PREFAB_SCHEMA_VERSION, migrations: [] },
};

/**
 * Registers a new migration step (e.g. from 1 to 2 when a future schema is introduced).
 */
export function registerMigration(entityType: EntityType, migration: Migration): void {
  const registry = REGISTRIES[entityType];
  if (!registry) {
    throw new Error(`[Migrations] Unknown entity type '${entityType}'`);
  }

  if (migration.toVersion !== migration.fromVersion + 1) {
    throw new Error(
      `[Migrations] Migrations must be sequential (from ${migration.fromVersion} to ${migration.fromVersion + 1}, received to=${migration.toVersion})`
    );
  }

  registry.migrations.push(migration);
  if (migration.toVersion > registry.currentVersion) {
    registry.currentVersion = migration.toVersion;
  }
}

/**
 * Applies sequential migrations from data.schemaVersion (or 1 if missing) up to targetVersion
 * (padrão: a versão corrente registrada para o tipo).
 */
export function applyMigrations<T = any>(
  entityType: EntityType,
  data: any,
  targetVersion?: number
): { data: T; migrated: boolean; fromVersion: number; toVersion: number } {
  if (!data || typeof data !== 'object') {
    return { data, migrated: false, fromVersion: 1, toVersion: 1 };
  }

  const registry = REGISTRIES[entityType];
  const target = targetVersion ?? registry.currentVersion;
  const initialVersion = typeof data.schemaVersion === 'number' ? data.schemaVersion : 1;

  if (initialVersion === target) {
    return { data: { ...data, schemaVersion: target }, migrated: false, fromVersion: initialVersion, toVersion: target };
  }

  if (initialVersion > target) {
    console.warn(
      `[Migrations] Warning: ${entityType} has schemaVersion ${initialVersion} which is newer than expected ${target}.`
    );
    return { data, migrated: false, fromVersion: initialVersion, toVersion: initialVersion };
  }

  let current = { ...data };
  let currentVersion = initialVersion;
  let migrated = false;

  while (currentVersion < target) {
    const nextMigration = registry.migrations.find((m) => m.fromVersion === currentVersion);
    if (!nextMigration) {
      console.warn(
        `[Migrations] No migration path found for ${entityType} from version ${currentVersion} to ${currentVersion + 1}`
      );
      break;
    }

    current = nextMigration.migrate(current);
    currentVersion = nextMigration.toVersion;
    current.schemaVersion = currentVersion;
    migrated = true;
  }

  return {
    data: current,
    migrated,
    fromVersion: initialVersion,
    toVersion: currentVersion,
  };
}

// ── Migrações embutidas ──────────────────────────────────────────────────────────────────────

registerMigration('scene', {
  fromVersion: 1,
  toVersion: 2,
  description: 'SceneData direto (id/path/environment…) → formato canônico SceneFile (sceneId/sceneSettings)',
  migrate: migrateSceneV1ToV2,
});

registerMigration('scene', {
  fromVersion: 2,
  toVersion: 3,
  description: 'GameNode.behaviors: IDs de lista global → instâncias inline (BehaviorInstance); lista global removida',
  migrate: migrateSceneV2ToV3,
});

// ── Pipeline passo a passo (AIS-29b) ─────────────────────────────────────────────────────────

export interface MigrationStepReport {
  fromVersion: number;
  toVersion: number;
  description: string;
}

export type MigrationFailureCode = 'migration.invalid_input' | 'migration.invalid_version' | 'migration.version_newer' | 'migration.no_path' | 'migration.step_failed';

export type MigrationOutcome<T = any> =
  | { ok: true; data: T; migrated: boolean; fromVersion: number; toVersion: number; steps: MigrationStepReport[] }
  | { ok: false; code: MigrationFailureCode; message: string; fromVersion: number; toVersion: number; steps: MigrationStepReport[] };

const deepClone = <T>(v: T): T => JSON.parse(JSON.stringify(v));

/**
 * Migra `raw` até a versão corrente da entidade, UM salto por vez (nunca pulando versões), SEM mutar a entrada.
 * Falha (versão inválida, mais nova que a suportada, salto ausente ou erro dentro de um passo) devolve `ok: false` e
 * NENHUM dado parcial: o chamador não deve gravar nada. Sem `schemaVersion` = versão 1 (documentos anteriores ao
 * versionamento). Downgrade não é automático.
 */
export function migrateStepwise<T = any>(entityType: EntityType, raw: unknown, targetVersion?: number): MigrationOutcome<T> {
  const registry = REGISTRIES[entityType];
  const target = targetVersion ?? registry.currentVersion;
  const steps: MigrationStepReport[] = [];
  const fail = (code: MigrationFailureCode, message: string, from: number, to: number): MigrationOutcome<T> => ({ ok: false, code, message, fromVersion: from, toVersion: to, steps });

  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) return fail('migration.invalid_input', 'O documento não é um objeto JSON.', 0, target);

  const declared = (raw as { schemaVersion?: unknown }).schemaVersion;
  if (declared !== undefined && (typeof declared !== 'number' || !Number.isInteger(declared) || declared < 1)) {
    return fail('migration.invalid_version', `schemaVersion inválido (${JSON.stringify(declared)}): esperado um inteiro >= 1.`, 0, target);
  }
  const from = typeof declared === 'number' ? declared : 1;
  if (from > target) {
    return fail('migration.version_newer', `Este documento foi salvo por uma versão mais nova do Nodimus (schemaVersion ${from} > ${target}); downgrade não é automático.`, from, from);
  }

  let current: any = deepClone(raw);
  let version = from;
  while (version < target) {
    const step = registry.migrations.find((m) => m.fromVersion === version);
    if (!step) return fail('migration.no_path', `Não há migração de ${entityType} v${version} para v${version + 1}.`, from, version);
    try {
      current = step.migrate(current);
    } catch (error) {
      return fail('migration.step_failed', `Falha na migração de ${entityType} v${step.fromVersion} → v${step.toVersion}: ${error instanceof Error ? error.message : String(error)}`, from, version);
    }
    if (typeof current !== 'object' || current === null) return fail('migration.step_failed', `A migração v${step.fromVersion} → v${step.toVersion} de ${entityType} não devolveu um documento.`, from, version);
    version = step.toVersion;
    current = { ...current, schemaVersion: version };
    steps.push({ fromVersion: step.fromVersion, toVersion: step.toVersion, description: step.description });
  }
  if (steps.length === 0) current = { ...current, schemaVersion: version };
  return { ok: true, data: current as T, migrated: steps.length > 0, fromVersion: from, toVersion: version, steps };
}
