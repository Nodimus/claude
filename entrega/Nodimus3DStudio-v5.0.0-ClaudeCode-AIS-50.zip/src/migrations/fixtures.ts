import { CURRENT_SCENE_SCHEMA_VERSION } from '../core/persistenceVersions';
/**
 * AIS-29b — fixtures DETERMINÍSTICAS por versão de `*.scene.json` (sem datas/ids aleatórios), usadas pelos testes de
 * migração. Cada fixture é o documento como o editor o gravaria naquela versão.
 */

/** v1 — `SceneData` gravado direto (formato anterior ao AIS-29), com Behavior/Action de ID desconhecido. */
export const SCENE_V1_FIXTURE = {
  schemaVersion: 1,
  id: 'scene_fixture',
  name: 'Fixture',
  path: 'res://scenes/Fixture.scene.json',
  rootNodeId: 'root',
  environmentNodeId: null,
  nodes: {
    root: { schemaVersion: 1, id: 'root', name: 'World', type: 'Spatial', parentId: null, childrenIds: ['cube', 'hero'], visible: true, locked: false, properties: {} },
    cube: {
      schemaVersion: 1,
      id: 'cube',
      name: 'Cubo',
      type: 'MeshInstance',
      parentId: 'root',
      childrenIds: [],
      visible: true,
      locked: false,
      properties: { position: { x: 1, y: 2, z: 3 }, scale: { x: 1, y: 1, z: 1 }, meshType: 'CubeMesh' },
    },
    hero: {
      schemaVersion: 1,
      id: 'hero',
      name: 'Heroi',
      type: 'MeshInstance',
      parentId: 'root',
      childrenIds: [],
      visible: true,
      locked: false,
      properties: { position: { x: 0, y: 1, z: 0 } },
      behaviors: ['b_unknown', 'b_known'],
      visualLogic: {
        behaviors: [
          { id: 'b_unknown', contributionId: 'comportamento_removido', source: 'custom', addonId: 'pacote_legado', properties: { speed: 3, nested: { list: [1, 2, 3] } }, label: 'Meu Comportamento' },
          { id: 'b_known', contributionId: 'simple_wasd_movement', source: 'builtin', properties: { speed: 6 } },
        ],
        actions: [{ id: 'a_unknown', contributionId: 'acao_inexistente', source: 'custom', parameters: { alvo: 'cube', vezes: 2 }, extra: true }],
      },
    },
  },
  environment: { ambientColor: '#334155', ambientIntensity: 0.45 },
  cameraSettings: { fov: 65 },
  fog: { enabled: false },
  createdAt: '2026-10-01T00:00:00.000Z',
  updatedAt: '2026-10-02T00:00:00.000Z',
};

/** v1 já em formato canônico (arquivos gravados pelo AIS-29 antes de a versão virar 2): só o carimbo muda. */
export const SCENE_V1_CANONICAL_FIXTURE = {
  schemaVersion: 1,
  sceneId: 'scene_fixture',
  name: 'Fixture',
  rootNodeId: 'root',
  nodes: {
    root: { id: 'root', name: 'World', type: 'Spatial', parentId: null, childrenIds: ['cube'] },
    cube: { id: 'cube', name: 'Cubo', type: 'MeshInstance', parentId: 'root', properties: { position: [1, 2, 3] } },
  },
  sceneSettings: { environment: { ambientColor: '#334155' } },
  createdAt: '2026-10-01T00:00:00.000Z',
  updatedAt: '2026-10-02T00:00:00.000Z',
};

/** v2 — versão corrente: formato canônico. */
export const SCENE_V2_FIXTURE = {
  schemaVersion: 2,
  sceneId: 'scene_fixture',
  name: 'Fixture',
  rootNodeId: 'root',
  nodes: {
    root: { id: 'root', name: 'World', type: 'Spatial', parentId: null, childrenIds: ['cube'] },
    cube: { id: 'cube', name: 'Cubo', type: 'MeshInstance', parentId: 'root', properties: { position: [1, 2, 3] } },
  },
  createdAt: '2026-10-01T00:00:00.000Z',
  updatedAt: '2026-10-02T00:00:00.000Z',
};

/** Documento sem `schemaVersion` (anterior ao versionamento): tratado como v1. */
export const SCENE_UNVERSIONED_FIXTURE = (() => {
  const { schemaVersion: _drop, ...rest } = SCENE_V1_FIXTURE;
  return rest;
})();

/** Versão futura (a corrente + 1): deve ser recusada, nunca lida pela metade. */
export const SCENE_FUTURE_FIXTURE = { ...SCENE_V2_FIXTURE, schemaVersion: CURRENT_SCENE_SCHEMA_VERSION + 1, campoDoFuturo: { x: 1 } };
