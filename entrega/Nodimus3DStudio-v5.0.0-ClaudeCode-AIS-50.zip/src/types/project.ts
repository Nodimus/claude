import type { ProjectGlobalVariable } from './projectFile';

export type RendererType = 'Three.js (WebGL)' | 'Three.js (WebGL 2.0)';

export interface InputActionBinding {
  type: 'key' | 'mouse' | 'gamepad';
  code: string; // e.g. "KeyW", "ArrowUp", "Button0"
}

export interface InputAction {
  name: string;
  bindings: InputActionBinding[];
}

export interface ProjectSettings {
  general: {
    projectName: string;
    version: string;
    /** AIS-32b: descrição livre do projeto. */
    description: string;
    mainScene: string; // e.g. "res://scenes/Main.scene.json"
    author: string;
  };
  display: {
    width: number;
    height: number;
    resizable: boolean;
    /** Legado: espelha `windowMode === 'fullscreen'` (sem consumidor de runtime hoje). */
    fullscreen: boolean;
    /** AIS-32b: modo de janela do jogo. */
    windowMode: 'windowed' | 'fullscreen' | 'borderless';
    orientation: 'landscape' | 'portrait' | 'auto';
  };
  rendering: {
    renderer: RendererType;
    clearColor: string;
    vsync: boolean;
    msaa: 'disabled' | '2x' | '4x' | '8x';
    shadowsEnabled: boolean;
    /** AIS-32b: qualidade das sombras (gravada; o runtime ainda não a lê). */
    shadowQuality: 'low' | 'medium' | 'high';
    /** AIS-32b: HDR (gravado; o runtime ainda não o lê). */
    hdr: boolean;
  };
  physics: {
    gravity3D: { x: number; y: number; z: number };
    defaultLinearDamp: number;
  };
  input: {
    actions: InputAction[];
  };
  audio: {
    masterVolume: number;
    musicVolume: number;
    sfxVolume: number;
  };
}

export interface VirtualFile {
  path: string; // e.g. "res://scenes/Main.scene.json"
  name: string;
  isDirectory: boolean;
  extension?: string;
  content?: string; // stringified data, json, script text, or base64
  size?: number;
  updatedAt: string;
  /** AIS-28c: identidade persistente do recurso (acompanha o arquivo em renomear/mover). */
  resourceId?: string;
  /** AIS-28c: importador, versão e configurações usadas (reimport as reutiliza). */
  importerId?: string;
  importerVersion?: number;
  importSettings?: Record<string, unknown>;
  contentHash?: string;
}

export interface ProjectData {
  /** Canonical schema version (CURRENT_PROJECT_SCHEMA_VERSION = 1) */
  schemaVersion?: number;
  /** Stable project UUID / ID */
  id: string;
  name: string;
  location: string;
  renderer: RendererType;
  lastOpenedScene: string;
  createdAt: string;
  updatedAt: string;
  settings: ProjectSettings;
  files: Record<string, VirtualFile>;
  /** Variáveis globais do projeto (espelhadas em `project.json`; preservadas em save/import). */
  globalVariables?: ProjectGlobalVariable[];
}

export * from './projectFile';

