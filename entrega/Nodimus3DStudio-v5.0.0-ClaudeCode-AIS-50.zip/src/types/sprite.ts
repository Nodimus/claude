export type BillboardMode = 'spherical' | 'cylindrical_y' | 'flat_quad' | 'isometric';

export type SpriteTool = 'pencil' | 'eraser' | 'picker' | 'bucket';

export type LoopMode = 'loop' | 'once' | 'ping-pong';

export type LightingPreset = 'studio' | 'night' | 'sunset' | 'retro_arcade' | 'cyberpunk';

export interface SpriteFrame {
  id: string;
  index: number;
  x: number;
  y: number;
  width: number;
  height: number;
  durationMs: number;
  customDataUrl?: string; // If edited on canvas
}

export interface SpriteAnimation {
  id: string;
  name: string;
  frameIndices: number[];
  fps: number;
  loopMode: LoopMode;
}

export interface SpriteSheetConfig {
  name: string;
  imageUrl: string;
  imageWidth: number;
  imageHeight: number;
  frameWidth: number;
  frameHeight: number;
  columns: number;
  rows: number;
  spacing: number;
  margin: number;
  totalFrames: number;
}

export interface Sprite3DSettings {
  billboardMode: BillboardMode;
  renderScale: { x: number; y: number };
  pixelPerfectFilter: boolean; // Nearest vs Linear
  tintColor: { r: number; g: number; b: number; a: number };
  emissiveColor: string;
  emissiveIntensity: number;
  alphaTest: number;
  doubleSided: boolean;
  castShadow: boolean;
  receiveShadow: boolean;
  turntableSpeed: number; // 0 = stationary, >0 = rpm
  environmentLighting: LightingPreset;
  showGroundGrid: boolean;
  showPixelWireframe: boolean;
}

export interface SpriteProject {
  id: string;
  name: string;
  sheetConfig: SpriteSheetConfig;
  frames: SpriteFrame[];
  animations: SpriteAnimation[];
  activeAnimationId: string;
  currentFrameIndex: number;
  settings3D: Sprite3DSettings;
  palette: string[];
}

export const DEFAULT_SPRITE_3D_SETTINGS: Sprite3DSettings = {
  billboardMode: 'spherical',
  renderScale: { x: 1.5, y: 1.5 },
  pixelPerfectFilter: true,
  tintColor: { r: 1, g: 1, b: 1, a: 1 },
  emissiveColor: '#000000',
  emissiveIntensity: 0.2,
  alphaTest: 0.5,
  doubleSided: true,
  castShadow: true,
  receiveShadow: true,
  turntableSpeed: 0,
  environmentLighting: 'studio',
  showGroundGrid: true,
  showPixelWireframe: false,
};
