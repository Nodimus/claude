export interface Keyframe {
  time: number; // In seconds
  value: any;
  easing?: 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out';
}

export interface AnimationTrack {
  id: string;
  nodeId: string;
  property: string; // e.g. "position.x", "position.y", "rotation", "scale.x", "scale.y", "visible"
  keyframes: Keyframe[];
}

export interface AnimationClip {
  id: string;
  name: string;
  duration: number; // Total length in seconds
  loop: boolean;
  tracks: AnimationTrack[];
}
