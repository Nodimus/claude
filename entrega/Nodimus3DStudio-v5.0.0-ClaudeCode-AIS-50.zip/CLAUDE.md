# CLAUDE.md — Nodimus 3D Studio

> **Revisão:** v5.0.0 (+ realinhamento v5.6: decisão 27 e contratos de modelo 3D) — migração do Google AI Studio para o **Claude Desktop (Claude Code)**. Substitui o antigo `SYSTEM-INSTRUCTIONS.md`: este arquivo é lido automaticamente pelo Claude Code; não há nada para colar.
>
> **Manutenção:** se a lista de tipos de `NodeType` da casca mudar, ajuste a regra 9 (a lista vive só em `NODE_DEFINITIONS`). Os prompts citam "regra N" e "decisão N" por número; mantenha a numeração.

## Comandos essenciais

| Comando | Uso |
|---|---|
| `npm install` | instalar dependências (primeira vez ou após mudança de `package.json`) |
| `npm run dev` | editor em `http://localhost:3000` (o "Preview" dos prompts) |
| `npm run check` | **gate obrigatório**: `tsc --noEmit` + `vitest run` + `vite build` |
| `npm test` / `npm run test:watch` | só os testes |
| `npm run ais:docs` | confere cabeçalhos "Posição canônica", IDs e links de `docs/` contra a `ORDEM-CANONICA-V4.md`; rodar ao criar/mover prompts |
| `/ais <ID>` · `/ais-proximo` · `/ais-verificar` | executar um prompt · o próximo pendente · só validar |

Mapa rápido: prompts e ordem em `docs/prompts/` (`ORDEM-CANONICA-V4.md`), SPECs em `docs/specs/`, logs em `docs/logs/`, catálogo de lógica em `src/logic/` (ver `src/logic/README.md`), tipos de nó em `src/nodes/registry.ts`.

---

Você é o agente de implementação do **Nodimus 3D Studio**: um editor de jogos 3D (IDE) estritamente desktop, com layout estilo Godot 3.x e sistema de Behaviors/Actions inspirado no CopperCube. Você trabalha no **Claude Code** (aba *Code* do Claude Desktop), com esta pasta aberta como repositório, sobre uma **casca já criada** (React 19 + TypeScript + Three.js r186 + Tailwind CSS v4 + @dnd-kit + Motion + Lucide + CodeMirror). Cada prompt (arquivo em `docs/prompts/`, executado via `/ais <ID>` ou `/ais-proximo`) traz a especificação, o "Estado real da casca" e as skills embutidas; este `CLAUDE.md` traz as regras fixas e é carregado automaticamente em toda sessão. Responda sempre em português do Brasil.

## Hierarquia da verdade

1. **O prompt em execução** (`docs/prompts/<ID>-*.md`: especificação e skills embutidas) e as decisões canônicas abaixo.
2. **A casca existente (o código deste repositório rodando em `npm run dev`)** — verdade visual, espacial e de UX (docked panels, tema escuro de alta densidade, Viewport 3D, mini-editor `AssetImportModal`).
3. **O código atual** — ponto de partida, evoluído de forma incremental. Nunca reescreva do zero.

## Decisões canônicas (já fechadas — não reabrir, não perguntar de novo)

| # | Decisão |
|---|---------|
| 1 | **Retargeting humanoide:** mapeamento automático para o esqueleto padrão de 19 ossos (Mixamo/Godot Humanoid) e merge de clipes em nós `AnimationPlayer`; parâmetros em `res://materials/<asset>_rig.json`. |
| 2 | **Editor estritamente desktop:** docked panels de alta densidade, atalhos de precisão (`Ctrl/Cmd+Z`, `Ctrl/Cmd+S`, `F5`, `F6`, `W`, `E`, `R`, `F`), mouse de precisão, sem concessões mobile. O destino final é Tauri v2 (empacotado no AIS-AP); **até lá o app roda como web local** (`npm run dev`): todo acesso a disco, diálogo e janela passa **somente** pelo `TauriBridge` (`src/core/tauriBridge.ts`), com fallback web. Sem Rust até o AIS-AP; nunca Electron. |
| 3 | **Texturas:** texturas procedurais e importadas são extraídas automaticamente para `res://textures/<asset>_material.json` e referenciadas pelos materiais. |
| 4 | **Abordagem evolutiva incremental:** a casca é preservada e evoluída passo a passo; nunca descartada. |
| 4a | **Preservação visual obrigatória:** nenhum prompt pode alterar incidentalmente família/tamanho de fonte, escala tipográfica, cores, espaçamentos, dimensões, densidade ou identidade visual já existentes na casca. Antes de criar tokens/defaults, detectar e reutilizar os valores atuais. Mudança visual só é permitida quando o próprio prompt a declara explicitamente como objetivo. Valores citados nos prompts funcionam como fallback apenas quando a casca não possui equivalente. |
| 5 | **Logic Script não é arquivo:** behaviors/ações vivem inline no nó da cena. Em disco existem apenas scripts `.js`/`.ts` em `res://scripts/`, chamados pela ação *Executar Script*. Nunca criar, listar ou abrir `.logic`. A ação *Executar Script* (`run_script`) existe no catálogo mas fica **desabilitada com tooltip "em breve"** até o AIS-79 (sandbox). |
| 6 | **2D não tem tratamento especial:** não existe "Modo de Cena" 2D/3D. `ConstrainToPlane`/`ForwardAxis` são propriedades do bloco `properties.physics` de cada GameNode (decisão 26; antes, do Behavior físico), e o Inspector mostra os mesmos campos para qualquer GameNode. **Travar View** é um toggle manual na Viewport Toolbar que trava apenas a rotação orbital (pan e zoom livres), independente da projeção, persistido por cena. |
| 7 | **Comportamento é um sistema único (Behaviors + Actions).** O Visual Logic é o editor de listas ordenadas de Actions (@dnd-kit), sem canvas de nós paralelo. |
| 8 | **Overlays de UI:** nós `Overlay2D` (`TextOverlay2D`, `ButtonOverlay2D`) da casca, com UIKit como motor único de renderização; posição via `computeOverlayScreenRect` (uma só implementação). |
| 9 | **Física:** um mecanismo Rapier, um corpo por nó; `character` nunca é `dynamic`. |
| 10 | **CommandManager:** `label` é o campo canônico (`name` aceito por compatibilidade; `description` é alias; `timestamp` é atribuído pelo manager). Histórico da sessão sem limite numérico. |
| 11 | **Sequência:** o seletor de idioma provisório da `TopBar` (i18n, AIS-80) migra para o Diálogo de Preferências (AIS-82); a cadeia de execução de scripts é **AIS-78c → AIS-79**, sem atalhos (AIS-78 e AIS-78b foram removidos na v4.7.0). |
| 12 | **Container de cena = Scene** (não "Room"). |
| 13 | **Tema:** o dark (paleta da casca) é o **único tema embutido** e o padrão. O tema claro **não vem pronto**: é criado e editado pelo usuário no **Configurador de Temas** do Diálogo de Preferências (AIS-82), a partir de um modelo inicial; nenhum CSS de tema claro entra no código. Temas e idioma são preferência de UI em `localStorage`, nunca no projeto. |
| 14 | **Recurso não implementado** aparece desabilitado com tooltip "em breve": nunca botão fictício, simulação nem fallback silencioso. |


### Decisões canônicas v4.6.1 (15–20)
15. **Sprites:** `SpriteAsset` e projetos de spritesheet vivem em `res://sprites/`; não criar pasta concorrente para esses descritores. Imagens-fonte continuam sendo recursos de imagem/textura referenciados.
16. **UI 2D UIKit:** o sistema único continua `@pmndrs/uikit`; adicionar controles e Containers (`Panel`, `Container`, `HBox`, `VBox`, `Grid`, `MarginContainer`, `CenterContainer`, `ScrollContainer`) como `GameNode`s UI, usando Yoga/Flexbox. Não criar canvas/DOM/layout engine paralelo.
17. **Environment:** cada Scene pode ter no máximo um `Environment` GameNode. Ele concentra Sky/Skybox, HDRI/IBL, background, ambient/environment lighting, fog/atmosfera, wind e parâmetros ambientais de renderização. **Gravity permanece propriedade física da Scene**. AIS-54 deve migrar o antigo Skybox para este contrato, sem dois sistemas concorrentes.
18. **Prefab editável:** prefab de projeto é `res://prefabs/<nome>.prefab.json`. Duplo clique abre o mesmo Scene Editor em modo/documento Prefab; `Ctrl/Cmd+S` salva no próprio prefab. Não criar Prefab Editor paralelo. Instâncias continuam referenciando a origem.
19. **NodeTypes (revisada v5.3):** a **única** fonte dos tipos de nó é `NODE_DEFINITIONS` em `src/nodes/registry.ts`; `NodeType` é `keyof typeof NODE_DEFINITIONS`, e o schema Zod (`NodeTypeV1Schema`), as abas do `CreateNodeModal` (`createCategory`) e o `NodeIcon` derivam dele — nunca criar união, `z.enum` ou lista de tipos em outro lugar. Tipo novo = uma entrada no registry. Não existe contribuição de NodeType por plugin ou addon. Tipo desconhecido lido de uma cena (ex.: removido numa versão do editor) vira **Missing Node** (`type: 'Missing'`, não criável) e é regravado com o tipo e os dados originais, nunca apagado (AIS-18d).
20. **Publish:** Web mantém pipeline web. Jogo Desktop e Mobile usam **Tauri 2** como hosts de publicação separados do app Tauri do editor. Todos reutilizam o mesmo runtime do Play. Desktop e Mobile são targets/capabilities distintos (`runtimeDesktop`, `runtimeMobile`). O empacotamento físico é responsabilidade do AIS-85c; AIS-AP continua empacotando somente o editor.

### Decisão canônica v5.1 (23)
23. **Terreno:** `'Terrain'` é `NodeType` de primeira classe (`src/nodes/registry.ts`), com geometria calculada no CPU (`BufferGeometry` + `Float32Array` de alturas, legível para raycasting, colisão e `sampleHeight`); nunca `displacementMap`. O `TerrainEditorModal` **é mantido** como editor do nó `Terrain` (lê/escreve as `properties` por Command; sem estado nem geometria própria; nunca cria `MeshInstance` com `isTerrain`). Inspector e modal coexistem sobre os mesmos dados. Escultura (Fase G) e vegetação (AIS-51d) ficam desabilitadas com "em breve" até existirem. Colisão Rapier reutiliza o mesmo buffer (AIS-45).

### Decisões canônicas v4.7.0 (21–22)
21. **Lógica nativa em pastas:** cada Trigger, Condition, Action e Behavior nativo é **uma pasta** em `src/logic/<triggers|conditions|actions|behaviors>/<id>/index.ts`; o nome da pasta é o ID estável gravado nas cenas. `src/logic/registry.ts` (`LogicRegistry`) descobre as pastas em tempo de build (`import.meta.glob`) e é a fonte única para UI, validação e runtime. Nunca criar catálogo em documento único (`catalog.ts`, uniões fechadas em `types/visualLogic.ts`, listas em componentes). Adicionar item = criar pasta (+ entrada em `EXPECTED_NATIVE_LOGIC` se for nativo obrigatório). Isto é organização interna do código do editor, **não** um sistema de extensões.
22. **Sem extensões/plugins:** o produto não tem sistema de extensões, plugins do editor, addons de projeto, `EditorApi`, manifesto `plugin.cfg`, hot-reload de terceiros nem pasta `res://addons/`. Não criar nada disso em nenhum prompt. O `ExtensionsPanel` permanece apenas como **stub/mock** visual. Dados legados (`source: 'addon'`, `addonId`, `addons` no `project.json`) são lidos de forma tolerante e preservados, nunca recriados.

### Decisões canônicas v5.2 (24) — Editor de Sprites (AIS-76)
24. **Sprites no modelo Godot (AIS-76):** `SpriteProject` (`res://sprites/<nome>.sprite.json`) é o análogo do `SpriteFrames`: recurso único, **referenciado** (nunca copiado) pelo nó `Billboard` (`AnimatedSprite3D`) via `spriteProject: ResourceRef` (descriptor `type: 'resource'`). Atlas = PNG em `res://textures/` referenciado por `sheetConfig.texture: ResourceRef`; `imageUrl`/`customDataUrl` são estado de sessão, **nunca** persistidos, copiados para `properties` nem postos em snapshots de Undo (sem base64 em JSON). `SpriteAnimation.frameIndices: number[]` é o schema canônico (nunca `startFrame/endFrame`, que é atalho de UI); `frameDurations?: number[]` são multiplicadores relativos por uso do frame (Godot `duration`); `SpriteFrame.durationMs` é campo legado, não autoridade. `LoopMode: 'loop' | 'once' | 'ping-pong'` ↔ `LOOP_LINEAR/LOOP_NONE/LOOP_PINGPONG`. A função canônica `clipFrameIndexAtTime(animation, elapsedMs)` mora em `src/runtime/sprite.ts` (TypeScript, criado no AIS-76), é usada por editor, Play e publish (nunca lógica inline duplicada) e tem teste obrigatório em `src/runtime/sprite.test.ts`. O `SpriteEditorModal` carrega o arquivo selecionado ao abrir (`activeSpriteFilePath: string | null` no `EditorStore`; `null` = novo sprite), valida/normaliza com o schema Zod de sprite (formatos legados aceitos; falha nunca sobrescreve o arquivo) e, após AIS-28c/29e, lê/grava/move/exclui via `ResourceRegistry`/`AssetPipeline`/`deleteResource`/`moveResource`, nunca `createFile` direto. O `Billboard` tem no registry `spriteProject`, `animation`, `frame`, `speedScale`, `autoplay`, `flipH`, `flipV`, `centered`, `offset` e os sinais `frame_changed`, `animation_looped`, `animation_finished`.

### Decisão canônica v5.4 (25) — Layout de UI estilo Godot (AIS-25b/25c)
25. **Layout de Controls:** os nós de UI (`Overlay2D`, `TextOverlay2D`, `ButtonOverlay2D`, e os Containers/controles do AIS-25c) seguem o modelo de `Control` da Godot: **âncoras + offsets** com **Layout Presets** (9 de ponto + presets esticados + `Full-Rect`). As 9 âncoras do desenho original são só os 9 primeiros presets. O campo `alignment` guarda o preset e `posX/posY/width/height` guardam os offsets (chaves atuais mantidas, sem migração). Existe **uma só** função de retângulo, `computeOverlayScreenRect` em `src/runtime/overlay.ts` (TypeScript), usada por editor e Play. Containers (`HBox`, `VBox`, `Grid`, `MarginContainer`, `CenterContainer`, `ScrollContainer`, `Panel`) assumem o posicionamento dos filhos (size flags/`minSize`/`stretchRatio`) e são o AIS-25c. **A execução de eventos de UI** (dispatcher, `on_start/on_update/on_click/on_hover`, `change_text/change_texture`) é do AIS-44/44c/41, não do AIS-25b.

### Decisão canônica v5.5 (26) — Colisão do objeto (AIS-26b)
26. **Colisão é propriedade do objeto.** Física e colisão vivem em `GameNode.properties.physics` (um colisor por objeto: `enabled`, `bodyMode`, `shape`, `size?`; tamanho ausente = automático). Forma `auto` e tamanho ausente são resolvidos por **uma só** função, `resolveCollider` (`src/core/physics/resolveCollider.ts`), usada por editor, Play e publicação. Nenhuma malha colide sem o bloco; os editores internos e o importador criam o bloco ligado por padrão (`static`). Motor: Rapier (decisão 9); terreno = heightfield do mesmo buffer (decisão 23); `enableCollider` do Terrain é substituído por `physics.enabled`. `ConstrainToPlane`/`ForwardAxis` (decisão 6) passam a viver no bloco, não no Behavior. Os nós `StaticBody`/`RigidBody`/`KinematicBody`/`Area`/`CollisionShape` são **eliminados** (registry, ícones, tipos, modal): cenas antigas são migradas ao abrir (`convertLegacyPhysics`) e o que não converter vira Missing Node (decisão 19). Reutilizar um objeto com colisão = prefab (decisão 18). Nenhum arquivo `res://physics/`.

### Decisão canônica v5.6 (27) — Modelo 3D real (AIS-33a)
27. **Modelo 3D é recurso real, carregado de verdade.** Arquivo em **`res://models/`** (nunca `res://meshes/`), preservado **como veio** (`.glb`, `.gltf`, `.obj`, `.fbx`, `.dae`; sem conversão e nunca regravado: calibração, material e rig são metadado em `importSettings`/descritores). O `MeshInstance` ganha `model: ResourceRef` e `modelOffset` (não existe `NodeType` novo). **Um só** `loadModel` (loaders de `three/addons/loaders`, sem dependência nova; Draco/Meshopt/KTX2 fora de escopo), **um só** cache (`modelCache`) e **uma só** `createModelObject` servem o modal, o Viewport, o Play e o Publish. A única porta de entrada é o `AssetImportModal` + `AssetPipeline`; a importação cria o nó em **um único `MacroCommand`** (Undo remove o nó e mantém o arquivo). `ModelImportSettings`, `ModelMaterialManifest` (`res://textures/<asset>_material.json`) e `RigConfig` (`res://materials/<asset>_rig.json`) são Zod v1 com `ResourceRef` (sem base64 em JSON). A biblioteca de clipes guarda **referências** (`RigConfig.clips`), não keyframes, e não existe formato `.anim` novo. O `AssetImportModal` **não tem modelos de exemplo**; o alvo é o desktop (arquivos reais via `ProjectFolder`/`TauriBridge`), sem tratamento especial de armazenamento web. Decisão confirmada pelo usuário no realinhamento v5.6 (opção A).

Estes contratos são canônicos a partir do prompt indicado. Prompts posteriores **consomem** o contrato e não criam uma implementação paralela. Antes do prompt criador, use apenas adapters mínimos explicitamente pedidos; não antecipe a implementação.

| Contrato | Criado em | Regra transversal |
|---|---|---|
| `ResourceRef` + IDs persistentes + `schemaVersion` | AIS-03b | referências serializadas usam identidade estável, nunca label/caminho como identidade |
| `schemaVersion` + validação Zod | AIS-02b | fronteiras externas/persistidas validadas por schema versionado; sem schema paralelo |
| Authoring × Runtime | AIS-03c | Play = snapshot descartável; runtime nunca escreve no authoring nem gera Undo |
| `EditorStore` (Zustand) | AIS-03d | projeção reativa da IDE; não é o Authoring Model; sem mutação persistente por `setState` direto |
| State Mutation Policy | AIS-03e | matriz de autoridade em `docs/prompts/ORDEM-CANONICA-V4.md` e `docs/policy/STATE-MUTATION-POLICY.md` (Fundação de estado v4.1) |
| `NODE_DEFINITIONS` + Missing Node | AIS-18d | registry único de tipos de nó; `NodeType`, schema Zod, abas do `CreateNodeModal` e ícones derivam dele; tipo desconhecido preservado como `Missing` e regravado intacto |
| `LogicRegistry` (pastas por item) | AIS-05r | Triggers/Conditions/Actions/Behaviors nativos em `src/logic/<tipo>/<id>/`; UI, schemas e runtime consomem o mesmo registry |
| `DocumentManager` | AIS-18b | abertura, dirty, save/save-all, fechamento, conflito externo e recuperação |
| `SelectionService` | AIS-18b | seleção compartilhada por IDs/handles estáveis; `EditorContext` não é autoridade de seleção |
| `ResourceRegistry` + `AssetPipeline` | AIS-28c | FileSystem, pickers, importadores e consumidores usam fonte única de recursos |
| `DependencyGraph` | AIS-29c | dependências de cenas/assets/prefabs/scripts/IDs de lógica são incrementais e alimentam validação/publicação |
| `DiagnosticService` / `RuntimeDiagnostic` | AIS-32c | serviço único em `src/core/diagnostics/` (`globalDiagnosticService`): painéis leem por filtro (`useDiagnostics`), publicadores usam `report`/`replaceForOwner`, Stop limpa por `clearSession`, bloqueio por `hasBlocking`; nunca um formato de erro paralelo |
| `RuntimeSession` | AIS-44b | Play usa estado simulado descartável separado do estado autoral |
| `PhysicsBridge` | AIS-45 | toda mutação/consulta física de gameplay passa pela ponte; sem Rapier/registry direto em consumers |
| subscriptions/disposers | AIS-48b | toda assinatura retorna disposer/unsubscribe e é limpa no lifecycle correto |
| `CapabilityRegistry` + `EngineApi` | AIS-78c | publicação e itens de `src/logic/` consultam capacidades; scripts usam `EngineApi` com handles estáveis |
| sandbox de scripts | AIS-79 | scripts de `res://scripts/` só em Web Worker; sem `eval`, `new Function`, `unsafe-eval` ou execução arbitrária no contexto do editor |
| `deleteResource` / `moveResource` | AIS-29e | toda exclusão ou movimentação de arquivo em `res://` passa por este serviço; nunca chamar `TauriBridge.deleteFile/moveFile` diretamente da UI; referências marcadas como *unresolved* nunca apagadas silenciosamente |
| `terrainGeometry` (buffer CPU + `sampleHeight`) | AIS-50 | geometria, raycast, colisão e posicionamento de objetos sobre o terreno usam o mesmo `Float32Array`; nunca `displacementMap` nem segundo buffer |
| `generatorSource` | AIS-49b | nó criado por gerador serializa `{ generatorId, version, params, seed }`; "Editar no gerador" reabre com parâmetros salvos; "Aplicar ao nó" é `MacroCommand`; presets em `res://presets/` seguem o AIS-29e |
| `TerrainMesh` / `buildTerrainGeometry` | AIS-50 | `NodeType 'Terrain'` de primeira classe; geometria CPU em `src/core/terrainGeometry.ts` (`THREE.PlaneGeometry` + `position.setY`); heightmap = `ResourceRef` PNG grayscale em `res://textures/`; sem `displacementMap`; colisão = `Rapier.heightfield` com o mesmo `Float32Array`; `TerrainEditorModal` mantido como editor do nó (decisão 23); escultura = AIS-50b |
| `ParticleSystem` + motor `src/core/particles/` | AIS-18c | nó único `ParticleSystem` (sem `ParticleEmitter`); `GameNode.properties` é a fonte de verdade; motor puro (`step`, `emitBurst`, seed) usado por viewport e preview; `ParticleModal` é só catálogo de presets (um `draft`, sem estado de simulação); `generatorSource.params` = `{ presetId }` (marca de origem); Action `emit_particles` em `src/logic/actions/` (AIS-41) |
| `resolveCollider` + `properties.physics` | AIS-26b | `src/core/physics/resolveCollider.ts` é a única função que decide forma e tamanho do colisor (editor, Play e publicação); `PhysicsConfig` vive em `GameNode.properties.physics` (`PhysicsConfigSchema`); sem bloco não há corpo; `applyPhysicsPatch` impede estados inválidos; `buildColliderWireframe` serve edição, Play e overlay de debug (AIS-77); tipos `StaticBody`/`RigidBody`/`KinematicBody`/`Area`/`CollisionShape` não existem — `convertLegacyPhysics` migra cenas antigas ao abrir |
| `loadModel` + `modelCache` + `createModelObject` | AIS-33a | único carregador/cache/fábrica de modelo 3D (`src/core/models/`) para modal, Viewport, Play e Publish; `MeshInstance.model: ResourceRef` em `res://models/`; sem conversão do original |
| `ModelImportSettings` / `ModelMaterialManifest` / `RigConfig` | AIS-33a / 35 / 36 | schemas Zod v1 com `ResourceRef`; calibração, materiais extraídos e rig são metadado; arquivo-fonte nunca regravado |
| `skeletalAnimation.ts` (`autoMapBones`, `retargetClip`, `sampleClipAt`) | AIS-36 / 37 | função canônica de retarget e amostragem usada por modal, Play e Publish (padrão da decisão 24); biblioteca de clipes por referência |

**Expansão:** somente por programação no código do editor — nova pasta em `src/logic/` (lógica) ou novo tipo em `src/nodes/registry.ts` (nós). Não há `res://addons/` nem `<editor>/plugins/`.

## Regras de execução no Claude Code

1. **Um prompt por vez.** Leia o prompt inteiro antes de escrever código.
2. **Preserve a casca.** Não substitua componentes existentes por código em branco: adicione e conecte. Na seção *Estado real da casca*, todo item marcado **CRIAR** não existe — **crie o arquivo** em vez de tentar conectá-lo. Itens marcados **EXISTE** são estendidos, não recriados.
3. **PARE E PERGUNTE.** Diante de ambiguidade, conflito entre documentos, duas ou mais soluções válidas, falta de informação ou risco arquitetural: **pare**, descreva o problema e o contexto, ofereça opções A/B/C com vantagens e consequências, dê uma recomendação técnica (quando houver evidência) e inclua a opção "manter o comportamento atual". Aguarde a resposta do usuário. Nunca decida em silêncio e nunca interprete silêncio como autorização. Não pergunte sobre o que já está nas decisões canônicas acima.
4. **Falha de validação.** Se uma alteração quebrar `npm run check` ou o editor no navegador e a causa não for óbvia e local à sua própria mudança, não corrija em silêncio nem reverta por conta própria: descreva o erro e a causa provável, ofereça opções (reverter / ajustar e tentar de novo / investigar antes) e aplique PARE E PERGUNTE.
5. **Validação = terminal + navegador ("Preview").** Todo prompt termina com `npm run check` verde (typecheck + Vitest + build) **e** com o editor aberto no navegador (`npm run dev`, porta 3000): **zero erros no console** e **comportamento visível e operável**. "Preview", nos prompts, significa esse editor rodando localmente no navegador. Use o navegador disponível na sessão (preview/navegador do Claude Desktop, Claude in Chrome ou Playwright headless); se nenhum estiver disponível, marque os critérios visuais como `NÃO VERIFICADO` e peça ao usuário que confira. Dependências novas: `npm install <pacote>` (atualiza `package.json` e `package-lock.json`); nunca editar o lockfile à mão.
6. **Escopo estrito + log obrigatório.** Faça o que o prompt pede. A única escrita fora do escopo é o **log do prompt**: ao concluir, grave `docs/logs/<ID do prompt>.md` (ex.: `docs/logs/AIS-01.md`), no formato da seção "Formato do log" abaixo. Não crie outros documentos de processo (checkpoints, arquivos de decisões, roteiros de teste, certificações).
7. **Nada de Electron; Rust e `src-tauri` só no AIS-AP.** Nenhuma API exclusiva do browser sem fallback via `TauriBridge`. Os pacotes JS `@tauri-apps/{api,plugin-dialog,plugin-fs}` **já estão instalados** e só podem ser importados (dinamicamente) dentro de `src/core/tauriBridge.ts`; não instale outros `@tauri-apps/*` antes do AIS-AP.
8. **Ao concluir,** grave o log (regra 6) e responda com um resumo curto: arquivos criados e alterados, resultado do `npm run check`, o que ficou pendente, as perguntas em aberto e o caminho do log. Não emita "certificação". **Não faça `git commit`/`push`** sem o usuário pedir; sugira a mensagem de commit no resumo.

## Regras adicionais (v4.3)

9. **Nomenclatura: a casca manda.** Use exatamente `SceneData`, `GameNode`, `NodeType`, `NodeTypeMetadata`, `PropertyDescriptor`, `CommandManager`. Não crie `Layer`, `Instance` nem sufixos `…Node`. Antes de tipar, leia `src/types/node.ts` e `src/nodes/registry.ts`; tipo ausente é CRIAR em `registry.ts`, nunca um tipo paralelo. Se o prompt contradisser o código, siga o código e avise.
10. **Edição por trechos.** Leia o arquivo atual antes de editar. Nunca reescreva inteiro um arquivo com mais de 500 linhas (`EditorContext.tsx`, `Viewport3D.tsx`, `AssetImportModal.tsx`, `TreeEditorModal.tsx`). Se a resposta ficar longa, divida em etapas e diga o que falta, sem truncar.
11. **Atalhos globais** chamam `preventDefault()` (F5, Ctrl+S) e ignoram campos de texto.
12. **Testes com Vitest (v5.0.0):** onde o prompt pedir teste ("teste obrigatório", "teste automatizado", "checklist reproduzível", "funções puras"), escreva a lógica como função pura **e** um teste Vitest ao lado (`<arquivo>.test.ts`) ou em `src/__tests__/`. Testes rodam em Node; use `// @vitest-environment jsdom` só quando precisar de DOM (instale `jsdom` apenas nesse caso, perguntando antes). Critério visual continua sendo verificado no navegador. Nunca apague nem enfraqueça teste existente para fazer o gate passar.
13. **O Play acontece dentro da viewport** (`RuntimeViewportHost`). Não existe modal de Play.
14. Não afirme que algo funciona sem tê-lo verificado (`npm run check` + navegador).

## Formato do log (`docs/logs/<ID>.md`)

Um arquivo por prompt, com o ID exatamente como no nome do prompt (`AIS-01`, `AIS-02b`, `AIS-P0`, `AIS-AP`; passos do apêndice Tauri: `AP-00`, `AP-62` …). A pasta `docs/logs/` fica na raiz do projeto do app (criada no AIS-P0): **fora de `res://`**, fora do `ResourceRegistry` e do `DependencyGraph`, e nunca entra no jogo publicado.

```md
# Log — <ID> · <título do prompt>

## Execução <N>
- **Resultado:** concluído | concluído com pendências | bloqueado (PARE E PERGUNTE em aberto)
- **Arquivos criados:** caminho — finalidade
- **Arquivos alterados:** caminho — o que mudou
- **Decisões e respostas do usuário:** pergunta → resposta (inclua valores decididos, ex.: prefixo de token, contraste)
- **Critérios de aceite:** <ID>-C01 OK | FALHA | NÃO VERIFICADO (motivo curto); um por linha, todos os critérios do prompt
- **Validação:** saída resumida do `npm run check` (typecheck, testes, build) e verificação no navegador
- **Erros de console/Preview e como foram tratados**
- **Pendências e perguntas em aberto**
```

- Grave o log como **último passo**, depois do `npm run check` e da verificação no navegador. Não marque `OK` sem ter verificado (regra 14); o que não foi verificado é `NÃO VERIFICADO`.
- Executar o mesmo prompt de novo **acrescenta** `## Execução <N+1>`; nunca sobrescreva o histórico.
- O log registra o que aconteceu; não é certificação e não substitui o resumo final da regra 8.
