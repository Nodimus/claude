# AIS-83 — Kit de Widgets de UI/HUD Reutilizáveis

> **Origem:** Prompt 83 · **Módulo 15:** Infraestrutura do Editor e do Produto · **Destino:** Claude Code (Claude Desktop) · **Skills embutidas:** `nodimus-ui-widgets`, `nodimus-gui-hud-uikit`, `nodimus-design-tokens-tema`

> **Posição canônica:** Fase H — Plataforma e produto · nº 130 de 135 · anterior: AIS-82 · próximo: AIS-84
> **Relaciona-se com:** AIS-01
> **Decisão Canônica Relacionada:** Extensão de Escopo (Módulo 13) — complementa o nó `GUI/HUD` já coberto pelo roteiro original (via `nodimus-gui-hud-uikit`) com um catálogo de widgets prontos, reutilizáveis tanto pelo runtime exportado (HUD de jogos) quanto pela própria UI do editor.

---

## 0. Preâmbulo fixo

Identidade, hierarquia da verdade, decisões canônicas (as numeradas no `CLAUDE.md`, até a 32), contratos arquiteturais transversais e regras de execução (1–14) estão no **`CLAUDE.md`** da raiz do repositório (carregado automaticamente pelo Claude Code) e valem para este prompt. Não são repetidos aqui.

---

## 1. Estado real da casca

_Cruzamento feito com o código da casca (`nodimus-studio---game-editor-ide`) e com as SPECs relacionadas ao final deste prompt. **EXISTE** = estender, sem recriar; **CRIAR** = inexistente na casca, criar antes de usar._

| Item | Status | Ação |
|---|---|---|
| EditorLayout → `src/App.tsx` (124 linhas) | **EXISTE** | estender, sem recriar |

## 2. Contexto e integração

Adiciona uma biblioteca `src/components/common/widgets/` (Button, Slider, ProgressBar, Panel, Label) construída sobre os mesmos design tokens do AIS-01, consumível tanto pelos nós de HUD do jogo quanto por futuros modais do editor (reduzindo duplicação de estilo entre eles).

---

## 3. Especificação

```text
Implemente o kit de widgets:
- Componentes React de baixo nível (Button, Slider, ProgressBar, Panel, Label) usando exclusivamente os tokens de tema do AIS-01 (`nodimus-design-tokens-tema`) — nenhuma cor/espaçamento hardcoded fora dos tokens.
- Cada widget tem uma contraparte serializável como propriedade do nó GUI/HUD (para uso no jogo exportado) e é usado internamente pelos próprios modais do editor sempre que fizer sentido, para reduzir divergência visual entre o editor e o HUD do jogo.
```

---

## 4. Diretrizes técnicas

1. **Fonte única de estilo:** Nenhum novo valor de cor/espaçamento fora do que já existe no AIS-01 — o objetivo deste prompt é consolidar, não expandir, o design system.
2. **Uso duplo (editor + runtime):** Documente explicitamente quais widgets são só-editor, só-runtime, ou ambos.

Se houver qualquer incompatibilidade ou dúvida arquitetural durante a execução, aplique **PARE E PERGUNTE** (ver `CLAUDE.md`): pare, descreva o problema com opções A/B/C e recomendação técnica, e aguarde a resposta do usuário antes de continuar.

---

## 5. Critérios de aceite (verificáveis por `npm run check` e no navegador)

- [ ] **AIS-83-C01** Trocar um token de tema (AIS-01) reflete visualmente nos widgets sem exigir alteração em cada componente individualmente.
- [ ] **AIS-83-C02** `npm run check` passa e o editor (`npm run dev`) carrega no navegador e permanece **sem erros no console** (zero erros vermelhos) durante toda a interação com a funcionalidade.
- [ ] **AIS-83-C03** O comportamento descrito na Especificação é **visível e operável no navegador** (`npm run dev`), exercitado manualmente do início ao fim.
- [ ] **AIS-83-C04** Nenhuma funcionalidade pré-existente da casca regrediu (TopBar, SceneTree, FileSystem, Viewport 3D, Inspector, BottomPanel e modais).
- [ ] **AIS-83-C05** Log `docs/logs/AIS-83.md` gravado ao concluir (formato no `CLAUDE.md`), com arquivos, decisões, resultado de cada critério e pendências.

## 6. Contexto de domínio (skills embutidas)

Conhecimento de domínio a seguir; onde a especificação citar uma skill, a regra dela está aqui.

### SKILL: nodimus-ui-widgets

> Widgets de UI de jogo do Nodimus 3D Studio: Button, Checkbox, ProgressBar, EditBox e preset Touch Screen Input, criados por modal de escolha, ligados a variáveis por boundVariable; EditBox usa <input> HTML real. Use ao criar menus, formulários, barras de progresso ou controles de toque.

# UI Widgets (`boundVariable`)

> **Dono de:** tipos dedicados de widget, `boundVariable`, modal de criação de UI. **Depende de:**
> `nodimus-gui-hud-uikit` (base `Overlay2D`), `nodimus-variaveis`. Amplia o original por decisão:
> lá eram só composição sobre um "2D Overlay Item"; aqui são tipos de verdade.

## Modal de criação (mesmo padrão do diálogo de Câmera)

Botão "2D Item" abre a escolha: `Text · Image · Panel · Button · Checkbox · ProgressBar · EditBox ·
Touch Screen Input`. Cada opção pré-configura um `Overlay2D` com o conjunto certo de propriedades.
Ícones de tipo pelo registro central (`nodimus-iconografia`).

## `boundVariable`

``Overlay2D`.boundVariable?: { scope:'global'|'local', name, target?: scenenode }`. Liga o widget a uma
variável (`nodimus-variaveis`) **sem Action manual**; lê/escreve automaticamente durante o Play. Não é sistema
novo de dados — é um consumidor automático a mais do mesmo `Variables`.

## Os tipos

- **Button:** Overlay + `When Clicked do something` já anexado + até 3 imagens (`normal/hover/pressed`).
- **Checkbox:** `boundVariable` `bool`; clique inverte; `image`/`imageChecked` (ou filho "marca" com `visible`
  amarrado ao valor).
- **ProgressBar:** `boundVariable` `number` (somente leitura) + `min/max`; o filho "fill" tem escala
  `(value-min)/(max-min)` recalculada por frame (generaliza a "receita" de barra do HUD).
- **EditBox:** **não** usa UIKit — `<input>`/`<textarea>` HTML real, posicionado sobre o canvas na posição
  do Overlay (pela mesma `computeOverlayScreenRect`). Motivo: teclado virtual mobile, IME, autocomplete e
  acessibilidade só existem em elemento nativo. `boundVariable` `string`, atualizado em `onChange`. Remover o
  elemento no teardown do Play.
- **Touch Screen Input:** preset que gera Overlay com sub-elementos de joystick/botões de toque; o
  `InputManager` consome (`nodimus-input-manager`). É variante de Overlay, não mecanismo à parte.

## Fora de escopo

Skins prontas; máscara de input (numérico-only, data).

## Definição de "pronto"

- Checkbox ligado a `bool` inverte a variável e reflete o estado visual.
- ProgressBar acompanha `health` sem nenhuma Action.
- EditBox abre o teclado virtual em mobile.

---

### SKILL: nodimus-gui-hud-uikit

> GUI/HUD do Nodimus 3D Studio com @pmndrs/uikit (núcleo vanilla, sem R3F): `Overlay2D` em nó `Overlay2D`, passada de renderização em espaço de tela, âncoras de 9 posições com função única computeOverlayScreenRect compartilhada entre editor e runtime, modo de edição 2D e reaproveitamento total de Behaviors/Actions. Use ao criar HUD, overlays, barras de vida ou textos de tela.

# GUI/HUD com UIKit (`@pmndrs/uikit`)

> **Dono de:** `Overlay2D`, modo de edição 2D do viewport, integração com nó `Overlay2D`.
> **Depende de:** `nodimus-scenegraph-modelo`, `nodimus-materiais-pbr`, `nodimus-catalogo-behaviors-actions`.
> Substitui `editor3d-hud-ui` (02) onde divergirem: aqui a renderização é UIKit, não DOM; o modelo
> "overlay é entidade normal" **é mantido**. Widgets → `nodimus-ui-widgets`.

## 1. Modelo

`Overlay2D` só existe como filho de nó `Overlay2D`. Mesmo shape de `GameNode`, com transform 2D:
`position (x,y em px ou %), size (w,h), anchor, text?, image? (imagem `ResourceRef`, ou `SpriteProject` + animação do AIS-76 — o tipo `SpriteAsset` não existe), visible, tags[], behaviors[]`.
Não é um tipo paralelo: mesmo `sceneStore`, mesmos Behaviors/Actions/triggers (`When Clicked` etc.), mesmos
Modais. **HUD não é um sistema à parte.**

## 2. Renderização com UIKit (vanilla)

- Instale `@pmndrs/uikit` (**não** `@react-three/uikit`). Layout em Yoga/flexbox: `Root`/`Fullscreen`,
  `Container`, `Text`, `Image`. Propriedades mudam por `setProperties(...)`.
- **Passada de HUD separada:** `uiScene` + câmera **ortográfica em pixels**; `renderer.autoClear = false`;
  por frame: `renderer.render(scene, cam)` → `renderer.clearDepth()` → `renderer.render(uiScene, uiCam)`.
  Sempre em espaço de tela, **nunca ancorado no mundo 3D** (ancorado no mundo = `Hotspot`, `nodimus-billboards-hotspot`).
- Ordem de desenho pela árvore/`zIndex`; o UIKit ordena por `reversePainterSortStable` (veja a doc da versão).
- **Eventos:** o UIKit vanilla **não traz sistema de eventos**. Para clique/hover use `@pmndrs/pointer-events`
  ou (mais simples e determinístico) **hit-test próprio sobre os retângulos de §3** e despache o trigger normal
  (`When Clicked`, `When Cursor Moved Over`).
- Nomes exatos de propriedade do UIKit mudam entre versões: **consulte a doc/typings da versão instalada**.
- Fontes: UIKit usa MSDF (Inter por padrão; `TTFLoader` para fontes próprias). Caracteres fora do charset
  não aparecem — declare o charset ao carregar a fonte (pt-BR: acentos).

## 3. Âncora e retângulo — **uma função só** (auditoria D-EXTRA-02)

> **Revisão v5.4 (Godot-like):** as **9 âncoras** descritas abaixo são os 9 primeiros **Layout Presets** de um modelo de **âncoras + offsets** (como o `Control` da Godot), que também cobre presets de largura/altura total e `Full-Rect`; o campo `alignment` guarda o preset e `posX/posY/width/height` os offsets (cenas atuais não mudam). A função continua sendo **`computeOverlayScreenRect`** (`src/runtime/overlay.ts`), única para editor e Play. Containers e controles gerais → AIS-25c. Eventos/Behaviors em Play → AIS-44/44c.

Nove âncoras: `top-left, top-center, top-right, center-left, center, center-right, bottom-left, bottom-center,
bottom-right`.
```
size  = overlaySize * scale
pos   = position em px, ou % da viewport quando overlayPositionUnit === '%'
{dx,dy} = anchorOffset(anchor, size.w, size.h)      // ex.: 'center' → dx = w/2, dy = h/2
rect  = { left: pos.x - dx, top: pos.y - dy, width: w, height: h }
```
`computeOverlayScreenRect` vive em **`src/runtime/overlay.js`** e é usada pelo editor **e** pelo runtime
publicado. O bug real do projeto antigo: o publish reimplementou o cálculo **sem** `anchorOffset`, e overlays
com `center`/`bottom-right` saíam deslocados. Teste de paridade obrigatório com todas as 9 âncoras.

## 3.1 Modo de edição 2D

Selecionar um nó `Overlay2D` troca o viewport para edição em **espaço de tela**. O botão "2D Item" da aba
Create fica funcional: desenhar um retângulo arrastando cria um `Overlay2D` (posição/tamanho em px).
Move (W) e Scale (R) operam em 2 eixos.

## 4. Reaproveitamento total (nada novo criado)

- `When Clicked` / `When Cursor Moved Over` funcionam no Overlay como em qualquer objeto.
- **Change 2D Overlay Text** troca `text` (interpolação `"Score: $score$"`).
- **Change Position/Rotation/Scale** operam sobre `position`/`size` → barra de progresso = escalar `size.x`
  proporcional a uma variável, sem Action nova.
- **Change a texture** troca `image`.
- Vídeo 2D → `nodimus-video` (mesma função de retângulo).

## 5. Fora de escopo

Temas/skins prontos de UI (só mecanismo de estado + imagem por estado).

## Definição de "pronto"

- Um Overlay `center` de 100×100 no meio da tela aparece **na mesma posição** no editor, no Play e no publish.
- Uma variável `score` incrementada atualiza o texto sem re-renderizar a cena 3D.

---

### SKILL: nodimus-design-tokens-tema

> Tokens CSS (--gl-*) do Nodimus 3D Studio, classes base (.toolbar__button, .property-grid, .modal), tokens de categoria de Behavior e o mecanismo de temas: o dark é o único tema embutido; o tema claro não vem pronto, é criado e editado pelo usuário no Configurador de Temas (Preferências → Aparência). Use ao estilizar qualquer componente, adicionar cor nova ou mexer no mecanismo de tema.

# Design tokens e temas

> **Dono de:** contrato das variáveis CSS `--gl-*` (nomes **e** valores do dark), classes visuais de base e
> mecanismo de aplicação de temas (`themeService`). **UI de criação/edição de temas** → `nodimus-preferences-dialog`
> (Configurador de Temas, AIS-82). **Conceito** (dark embutido, tema claro criado pelo usuário, persistência) →
> `CLAUDE.md`, decisão 13. Origem: capítulos 08i + 08k do conjunto 01 (valores preservados). Prefixo
> `--gl-` mantido por compatibilidade; pode virar `--nd-` numa migração única e mecânica (não misture os dois).

## Regra de ouro

**Nenhum componente declara cor hex inline** — sempre `var(--gl-*)`. Nomes de token nunca mudam entre temas;
um tema só troca *valores*. Por isso criar ou editar um tema (inclusive o claro) não exige editar componente algum.

## Tokens

`:root` traz **somente o dark** (valores = tokens `--ide-*` já existentes em `src/index.css` da casca). A coluna
"Semente do modelo claro" **não é CSS**: são os valores iniciais que o botão "Novo tema claro" do Configurador
(AIS-82) copia para o tema criado pelo usuário. Não existe bloco `[data-theme="light"]` com essas cores em
`index.css`; a única regra específica de light no CSS é `:root[data-theme="light"] { color-scheme: light; }`
(scrollbars e controles nativos).

| Variável | Dark (embutido) | Semente do modelo claro | Uso |
|---|---|---|---|
| `--gl-bg` | `#181c24` | `#f0f0f0` | fundo base |
| `--gl-panel` | `#202531` | `#f5f5f5` | painéis/barras |
| `--gl-bg-strong` | `#202531` | `#e8e8e8` | toolbar ativa, cabeçalho de diálogo |
| `--gl-panel-alt` | `#2d2d30` | `#e8e8e8` | cabeçalho de seção, aba inativa |
| `--gl-border` | `#2c3345` | `#a0a0a0` | bordas clássicas |
| `--gl-border-subtle` | `#2d2d30` | `#d0d0d0` | bordas internas |
| `--gl-row-divider` | *(avaliar contraste)* | `#e0e0e0` | divisória de linha do grid |
| `--gl-hover-bg` / `--gl-hover-border` | `#2a3140` / *(avaliar)* | `#e0e0e0` / `#b5b5b5` | hover de botão |
| `--gl-accent` | `#4982ea` | `#0078d7` | destaque de seleção |
| `--gl-accent-bg` | `#323b4e` | `#cce8ff` | item/botão ativo |
| `--gl-accent-border` | *(avaliar)* | `#99d1ff` | borda de ativo |
| `--gl-input-bg` | `#2d2d30` | `#ffffff` | input |
| `--gl-input-border` | *(avaliar)* | `#7f9db9` | borda de input |
| `--gl-text` | `#dfe4ec` | `#202225` | texto principal |
| `--gl-text-muted` | `#8b97a8` | `#6b6f76` | label |
| `--gl-text-disabled` | `#555555` | `#a7abb2` | desabilitado |
| `--gl-danger-bg/-border/-text` | `#442727`/`#6a3434`/`#f08080` | `#fdeaea`/`#f0b7b7`/`#b23a3a` | erro |
| `--gl-tag-bg` | `#223e2a` | `#dcefe0` | chip de tag |
| `--gl-overlay` | `rgba(0,0,0,0.65)` | `rgba(20,22,26,0.35)` | fundo de modal |

Prefixo final (`--gl-` × `--ide-` existente) = PARE E PERGUNTE no AIS-01. "*(avaliar)*": sem valor dark na
casca; decida por **verificação visual de contraste** e registre a decisão no log do prompt
(`docs/logs/AIS-01.md`); não invente por estética. Quando o dark ganhar o valor decidido, a semente clara do
mesmo token continua como está.

Tokens de **categoria de Behavior** (`--gl-cat-*` e `-bg`):

| Categoria | Dark (embutido) | Semente do modelo claro |
|---|---|---|
| Movimento | `#5eead4` / `#123734` | `#0f766e` / `#e2f4f1` |
| Física | `#fbbf24` / `#3a2e11` | `#b45309` / `#faedd9` |
| Interação | `#c4b5fd` / `#2c2350` | `#7c3aed` / `#efe6ff` |
| IA | `#f472b6` / `#3a1a2b` | `#be185d` / `#fbe3ee` |
| Câmera | `#38bdf8` / `#0f2e3d` | `#38bdf8` / `#dff1ff` |
| Utilitário | `#94a3b8` / `#2a2f36` | `#475569` / `#e7eaee` |
| Custom (fallback) | `#9ca3af` / `#2a2c30` | `#6b7280` / `#eceef0` |

**Tipografia — preservar a casca existente:** não alterar a família tipográfica, o tamanho-base, pesos, line-height ou escala tipográfica já usados pelo editor. Detecte e reutilize os tokens/CSS existentes. Somente se a casca realmente não possuir qualquer definição tipográfica, use `'Segoe UI', Tahoma, Arial, sans-serif` como *fallback* técnico; isso não autoriza substituir uma fonte existente.

## Classes de base

- `.toolbar__button`: altura 25px, `padding: 2px 6px`; inativo transparente; hover `--gl-hover-*`; ativo
  (`.is-active`) `--gl-accent-bg/border` + `box-shadow: inset 0 1px 2px rgba(0,0,0,.12)` (sem sombra externa).
- `.property-grid .property-row`: label 120px fixo (`--gl-text-muted`), controle no resto, divisória
  `--gl-row-divider`, input com `--gl-input-*`. Use **flexbox** (não `display:grid` puro): linhas de 3 inputs
  (`vect3d`/cor RGB) sem wrapper quebrariam a grade.
- `.modal`/`.modal--native`: barra de título estilo Win32, botão `[X]`, rodapé com botões 75×23px.

## Mecanismo de temas (`src/core/theme/`, criado no AIS-01)

```ts
type ThemeBase = 'dark' | 'light'          // define color-scheme; nunca 'system' nesta fase
interface EditorThemeDef {
  schemaVersion: 1
  id: string                                // 'dark' (embutido) ou UUID gerado ao criar
  name: string
  base: ThemeBase
  builtin?: boolean                         // só o dark
  tokens: Record<string, string>            // nome do token → valor (hex ou rgba())
}
```
- **Embutido:** só `dark` (`builtin: true`, somente leitura). Os valores dark são **lidos do CSS `:root`** na
  inicialização (antes de qualquer override), portanto `index.css` é a fonte única do dark. A semente clara
  vive em TypeScript (`LIGHT_SEED`, mesma lista de nomes) e só é usada pelo Configurador.
- **Temas do usuário:** array em `localStorage['nodimus_themes']`, validado por schema Zod (entrada inválida é
  descartada com aviso no console de saída, sem quebrar o boot). Tema ativo em `localStorage['nodimus_theme']`
  (id); ausente, inválido ou apontando para tema inexistente → **`'dark'`**.
- `themeService`: `listThemes()`, `getActiveThemeId()`, `setActiveTheme(id)`, `saveTheme(def)`,
  `deleteTheme(id)`. Cada escrita grava em `localStorage` **no mesmo passo** e reaplica o tema ativo.
- `applyTheme(def)`: define `data-theme` (= `def.base`) em `document.documentElement` e aplica cada token com
  `documentElement.style.setProperty('--gl-…', valor)`. Para o dark embutido remove **todos** os overrides
  inline (`removeProperty`), voltando ao CSS. Token ausente num tema do usuário cai no valor dark do `:root`.
- Inicialização: `main.tsx` aplica o tema ativo de forma síncrona **antes** de `createRoot().render(...)`, para
  evitar flash de tema errado. Não edite `index.html` sem PARE E PERGUNTE (ver AIS-P0).
- **A viewport 3D não consome `--gl-*`**: trocar tema é só repaint de CSS, não re-renderiza Three.js.
- Persistência é **preferência de UI**, fora do projeto (`CLAUDE.md`, decisão 13).

## Definição de "pronto"

- Instalação nova abre em `dark` idêntico ao atual; o CSS não contém nenhuma paleta clara.
- Sobrescrever `--gl-bg` e `--gl-panel` em `document.documentElement.style` (DevTools) repinta shell e modais sem
  editar componente (prova de que não há hex inline); grep de `#[0-9a-f]{3,8}` fora do CSS de tokens e da
  `LIGHT_SEED` não acha nada.
- O tema claro só existe depois de o usuário criá-lo no Configurador; ele persiste e é reaplicado ao recarregar.

## SPECs relacionadas

- [editor-layout.spec.md](../specs/componentes/editor-layout.spec.md)
