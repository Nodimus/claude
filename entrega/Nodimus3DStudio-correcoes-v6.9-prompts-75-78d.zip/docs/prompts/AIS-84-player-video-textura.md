# AIS-84 — Player de Vídeo como Textura/Node

> **Origem:** Prompt 84 · **Módulo 15:** Infraestrutura do Editor e do Produto · **Destino:** Claude Code (Claude Desktop) · **Skills embutidas:** `nodimus-video`, `nodimus-materiais-pbr`, `nodimus-som`

> **Posição canônica:** Fase H — Plataforma e produto · nº 131 de 135 · anterior: AIS-83 · próximo: AIS-85
> **Relaciona-se com:** AIS-25, AIS-33, AIS-52
> **Decisão Canônica Relacionada:** Extensão de Escopo (Módulo 13) — o `SoundModal.tsx` (AIS-52) já cobre áudio espacial; vídeo (como textura de tela/cutscene) não tinha prompt equivalente.

---

## 0. Preâmbulo fixo

Identidade, hierarquia da verdade, decisões canônicas (as numeradas no `CLAUDE.md`, até a 32), contratos arquiteturais transversais e regras de execução (1–14) estão no **`CLAUDE.md`** da raiz do repositório (carregado automaticamente pelo Claude Code) e valem para este prompt. Não são repetidos aqui.

---

## 1. Estado real da casca

_Cruzamento feito com o código da casca (`nodimus-studio---game-editor-ide`) e com as SPECs relacionadas ao final deste prompt. **EXISTE** = estender, sem recriar; **CRIAR** = inexistente na casca, criar antes de usar._

| Item | Status | Ação |
|---|---|---|
| VideoPreviewCanvas → `src/components/modals/VideoPreviewCanvas.tsx` (525 linhas) | **EXISTE** | estender, sem recriar |
| video → `src/types/video.ts` (79 linhas) | **EXISTE** | estender, sem recriar |
| VideoEditorModal → `src/components/modals/VideoEditorModal.tsx` (1260 linhas) | **EXISTE** | estender, sem recriar |

## 2. Contexto e integração

Adiciona o nó `VideoPlayer` ao `NODE_REGISTRY`, que usa um elemento `<video>` HTML oculto como fonte de uma `THREE.VideoTexture` aplicada a um material (reaproveitando o pipeline de materiais do AIS-25), e reaproveita o player com timeline/scrubbing do AIS-33 para os controles no Inspector.

---

## 3. Especificação

```text
Implemente:
- Nó `VideoPlayer` (Spatial 3D): referencia um arquivo em `res://videos/`, cria `THREE.VideoTexture` a partir de um `<video>` oculto, aplicável como `map` de qualquer material (tela de cinema in-game, telas de UI diegéticas).
- Controles no Inspector reaproveitando o mesmo componente de timeline/scrubbing/loop já construído no AIS-33 (Animation Player), em vez de um novo player do zero.
- Áudio do vídeo integrado ao mixer espacial já existente (AIS-52), não a um `<audio>` desacoplado.
```

### 2.1 Emenda — Migração de Cascas de Editores de Arquivo (2026-09-27)

> Origem: as cascas de editores já estão montadas na casca (estado no `EditorContext`). A lógica de roteamento, gravação e integração é desenvolvida neste prompt; decisões de comportamento fino são confirmações com o usuário.

- **Casca:** `VideoEditorModal.tsx` + `VideoPreviewCanvas.tsx` (Editor e Preview de Vídeos compatíveis com Three.js, `THREE.VideoTexture`), `types/video.ts`, `utils/videoTextureHelper.ts`. Aberta por duplo clique em `*.video.json` e arquivos de vídeo.
- **Contrato da casca (confirmar com o usuário — PARE E PERGUNTE antes de implementar):** persiste `res://videos/<nome>.video.json` (`VideoClipSettings`: trim, taxa, filtros, chroma key, forma de tela). O nó `VideoPlayer` e a leitura do binário de vídeo em `res://videos/` continuam escopo deste prompt. O áudio do vídeo ainda **não** está ligado ao mixer espacial do AIS-52.

---

## 4. Diretrizes técnicas

1. **Reuso do Player de Timeline:** Os controles de play/pause/scrub são os mesmos componentes visuais do AIS-33, não uma reimplementação.
2. **Formatos:** Documente os formatos de vídeo suportados nativamente pelo webview alvo (o navegador do `npm run dev` e, no desktop, o webview do Tauri) — nem todos os codecs são suportados em todas as plataformas; aplicar PARE E PERGUNTE se isso afetar a decisão de formato padrão do projeto.

Se houver qualquer incompatibilidade ou dúvida arquitetural durante a execução, aplique **PARE E PERGUNTE** (ver `CLAUDE.md`): pare, descreva o problema com opções A/B/C e recomendação técnica, e aguarde a resposta do usuário antes de continuar.

---



## Nivelamento transversal — AIS-84

Vídeo/textura é recurso registrado em ResourceRegistry/ResourceRef e participa do DependencyGraph quando referenciado.

## 5. Critérios de aceite (verificáveis por `npm run check` e no navegador)

- [ ] **AIS-84-C01** Vídeo aplicado como textura de um material reproduz corretamente no Viewport3D durante Play Mode.
- [ ] **AIS-84-C02** O duplo clique em `*.video.json` abre o `VideoEditorModal`.
- [ ] **AIS-84-C03** Áudio do vídeo roteado pelo mixer espacial (AIS-52).
- [ ] **AIS-84-C04** `npm run check` passa e o editor (`npm run dev`) carrega no navegador e permanece **sem erros no console** (zero erros vermelhos) durante toda a interação com a funcionalidade.
- [ ] **AIS-84-C05** O comportamento descrito na Especificação é **visível e operável no navegador** (`npm run dev`), exercitado manualmente do início ao fim.
- [ ] **AIS-84-C06** Nenhuma funcionalidade pré-existente da casca regrediu (TopBar, SceneTree, FileSystem, Viewport 3D, Inspector, BottomPanel e modais).
- [ ] **AIS-84-C07** As confirmações com o usuário listadas neste prompt foram respondidas **antes** da implementação (PARE E PERGUNTE), sem decisão silenciosa.
- [ ] **AIS-84-C08** Log `docs/logs/AIS-84.md` gravado ao concluir (formato no `CLAUDE.md`), com arquivos, decisões, resultado de cada critério e pendências.

## 6. Contexto de domínio (skills embutidas)

Conhecimento de domínio a seguir; onde a especificação citar uma skill, a regra dela está aqui.

### SKILL: nodimus-video

> Vídeo no Nodimus 3D Studio: nó Video dedicado (clip, loop, autoplay, mode 2d-overlay | 3d-texture) com THREE.VideoTexture, import mp4/webm, Action Play or stop a video, autoplay mudo do navegador e teardown do <video>. Use ao reproduzir vídeo em overlay ou em superfície 3D.

# Vídeo

> **Dono de:** nó `Video` e Action de vídeo. **Depende de:** `nodimus-som` (mesmo padrão de import de mídia),
> `nodimus-gui-hud-uikit`. **Diverge do original por decisão:** lá não existe nó de vídeo (a Action recebe o
> arquivo direto); aqui é nó dedicado porque `VideoTexture` é stateful o bastante.

## Import

`.mp4/.webm` → `videos/` + sidecar. Só arquivo local nesta fase (streaming de URL externa fora de escopo).

## Nó `Video`

`clip, loop, autoplay, mode: '2d-overlay' | '3d-texture'`.
- `2d-overlay`: `Overlay2D` especial; posicionado pela **mesma** `computeOverlayScreenRect` (âncora!);
  `<video>` por trás alimenta `THREE.VideoTexture` (ou `<video>` HTML posicionado, se UIKit não suportar a textura).
- `3d-texture`: `VideoTexture` como `baseColor`/`emissiveMap` de um material (`nodimus-materiais-pbr`).

## Action

**Play or stop a video**.

## Web

- Autoplay só funciona **mudo** ou após gesto do usuário; comece `muted` e libere som após interação.
- `playsInline` para iOS; `crossOrigin` coerente com as object URLs do projeto.
- Teardown: `video.pause()`, `video.removeAttribute('src')`, `load()`, `texture.dispose()`; nunca deixar `<video>` órfão no DOM após Stop.

## Referência órfã

Excluir o arquivo referenciado deixa a GameNode sem clip (sem erro); excluir a GameNode é Command/Undo.

## Definição de "pronto"

- Vídeo toca em overlay e como textura de uma parede; Stop remove `<video>` do DOM.

---

### SKILL: nodimus-materiais-pbr

> Sistema de material PBR do Nodimus 3D Studio: MaterialAsset (definição reutilizável) × MaterialOverride por GameNode, canais baseColor/normal/roughness/metalness/ao/emissive em MeshStandardMaterial, categoria Images, flag movedByWind, defaults gerados (nada nasce sem textura), regra única de resolução editor×runtime e referências órfãs. Use ao editar materiais, texturas ou causas de textura quebrada.

# Materiais e texturas (PBR)

> **Dono de:** `MaterialAsset`/`MaterialOverride`, Material Editor, categorias `Materials`/`Images`, flag
> `movedByWind`. **Depende de:** `nodimus-scenegraph-modelo`, `nodimus-projetos-workspace`. Cobre a skill
> `editor3d-materiais-texturas` do README de 02 (arquivo ausente no pacote). Diverge do original de propósito
> (lá: até 2 slots fixos; aqui PBR completo).

## Canais e material

`baseColor/diffuse, normalMap, roughnessMap, metalnessMap, aoMap, emissiveMap` → `THREE.MeshStandardMaterial`.
`normalMap` exige `geometry.computeTangents()` (já no import — `nodimus-importador-assets`). Texturas de cor
usam `colorSpace = SRGBColorSpace`; mapas de dados (normal/roughness/metalness/ao) ficam **lineares**
(`NoColorSpace`) — erro comum que "quebra" o visual.

## MaterialAsset, MaterialOverride & Persistência de Texturas (Item 3: Opção A)

- **Item 3: Opção A — Extração Automática de Texturas:** Texturas criadas no gerador procedural do `AssetImportModal` ou extraídas de modelos 3D importados são automaticamente salvas como arquivos independentes em `res://textures/<asset>_material.json` e arquivos de imagem associados.
- **Reuso no FileSystem:** As texturas em `res://textures/` tornam-se recursos de primeira classe no projeto, podendo ser arrastadas diretamente para qualquer malha no Viewport 3D ou selecionadas no Inspetor.
- `MaterialAsset` (em `res://materials/`): definição reutilizável de shader/canais PBR.
- `GameNode.materials[]` (`MaterialOverride`): sobrescreve propriedades em nós específicos sem alterar o arquivo base.
- Canais PBR suportados: Albedo/BaseColor, Normal Map, Roughness, Metalness, Ambient Occlusion (AO), Emissive, Tiling UV horizontal e vertical.

## Flag `movedByWind`

Por material com alpha: desloca vértices na GPU (vertex shader via `onBeforeCompile`) usando o `Wind` do root
da Scene. Genérico (usado por grama/folhagem, `nodimus-terreno-arvore`).

## Defaults — nada nasce sem textura

Todo `MaterialAsset` novo nasce com: `baseColor` = **checker/placeholder** gerado; `normalMap` = normal
neutro (pixel `128,128,255`); fallback branco para `aoMap`/`emissiveMap` vazios. **Gere esses defaults por código
(canvas) ou use assets CC0 próprios** — os arquivos do CopperCube (`default_texture.jpg`,
`~default_normalmap.jpg`, `default_white.png`) não devem ser redistribuídos sem confirmar a licença
(`nodimus-canon-governanca`).

## Regra única de resolução (auditoria D-03)

`MaterialAsset → material Three` é resolvido por **uma função em `src/runtime/materials`** usada pelo editor
e pelo runtime publicado; o ambiente fornece só o **carregador de textura**. Duas implementações paralelas são
risco de manutenção comprovado.

## Referência órfã

Excluir Image/Material referenciado **não é erro**: cai no default acima. Exclusão da Resource Tree →
`nodimus-projetos-workspace` §4.

## Actions/Behaviors habilitados

`Change a texture` e `Animate a texture` (3 modos: lista de arquivos, `SpriteProject` (AIS-76, `.sprite.json` por `ResourceRef`)+animação, `GridMode`;
`nodimus-sprite-editor`).

## Fora de escopo

Texture Packer/atlas automático.

## Definição de "pronto"

- Um mesmo `.glb` com override numa GameNode muda só aquela GameNode.
- Apagar a imagem de um material mostra o checker, sem exceção.
- Editor e publish renderizam o mesmo material (teste de paridade).

---

### SKILL: nodimus-som

> Som no Nodimus 3D Studio: nó Sound (clip, volume, loop, autoplay, spatial) com THREE.Audio/PositionalAudio, import de mp3/ogg/wav, Actions Play/Stop/Stop all sounds, política de autoplay do navegador (AudioContext) e limite de escopo do PlayMode 'Random'. Use ao adicionar áudio ao jogo.

# Som

> **Dono de:** nó `Sound` e Actions de áudio. **Depende de:** `nodimus-projetos-workspace`. Amplia
> `editor3d-audio` (02) — o `audioRegistry` de lá segue o mesmo molde de `bodyRegistry`.

## Import

`.mp3/.ogg/.wav` → `sounds/` + sidecar (duração, sample rate) → categoria `Sounds` da Resource Tree.

## Nó `Sound`

`clip, volume, loop, autoplay, spatial`. `spatial: true` → `THREE.PositionalAudio` (posição 3D, atenuação por
distância); `false` → `THREE.Audio` (2D, música de fundo). Um único `AudioListener` na câmera ativa. Estado de
alta frequência fica em `audioRegistry` (fora do Zustand).

## Actions

**Play a sound** (2D/3D, posição fixa ou relativa a outra GameNode) · **Stop a sound** · **Stop all sounds**.

## Política de autoplay (web)

Navegadores só liberam áudio após **gesto do usuário**: crie/retome o `AudioContext` no primeiro clique/tecla
(o botão Play do editor já é um gesto; no bundle publicado use uma tela "clique para começar" quando a Scene
inicial tiver autoplay). Pause do Play → `audioContext.suspend()`; Stop/Restart → descartar fontes.

## Escopo reduzido (registrado, não bug)

O original tem `PlayMode` `Loop | Once | Random` (com espera mínima/máxima em ms). Aqui `soundLoop` é
**boolean**; `Random` fica de fora. Evolução prevista: enum `'loop'|'once'|'random'` + `randomWaitMinMs/MaxMs`.

## Fora de escopo

Mixagem avançada (buses, reverb, EQ) — Web Audio permite, mas não faz parte desta fase.

## Referência órfã

Excluir o arquivo de som referenciado deixa a GameNode `Sound` sem clip (sem erro). Excluir a GameNode é
Command/Undo (`nodimus-undo-redo-commandstack` §4).

## Definição de "pronto"

- Um som 3D fica mais baixo ao afastar a câmera; música 2D em loop não some na troca de câmera.
- Nenhum erro de "AudioContext não permitido" no primeiro Play.

## SPECs relacionadas

- [video-editor-modal.spec.md](../specs/modais/video-editor-modal.spec.md)
- [video.spec.md](../specs/dominios/video.spec.md)
- [video-preview-canvas.spec.md](../specs/componentes/video-preview-canvas.spec.md)
