# AIS-82 — Diálogo de Preferências do Editor

> **Origem:** Prompt 82 · **Módulo 15:** Infraestrutura do Editor e do Produto · **Destino:** Claude Code (Claude Desktop) · **Skills embutidas:** `nodimus-preferences-dialog`, `nodimus-shell-interface`, `nodimus-design-tokens-tema`, `nodimus-i18n`

> **Posição canônica:** Fase H — Plataforma e produto · nº 129 de 135 · anterior: AIS-81b · próximo: AIS-83
> **Relaciona-se com:** AIS-01, AIS-04, AIS-32, AIS-80
> **Decisão Canônica Relacionada:** Extensão de Escopo (Módulo 13) — os atalhos de teclado (AIS-04) e o tema visual (AIS-01) hoje são fixos no código; não há tela de configuração do próprio editor (distinta do `ProjectSettingsModal.tsx`, que é por-projeto).

---

## 0. Preâmbulo fixo

Identidade, hierarquia da verdade, decisões canônicas (as numeradas no `CLAUDE.md`, até a 32), contratos arquiteturais transversais e regras de execução (1–14) estão no **`CLAUDE.md`** da raiz do repositório (carregado automaticamente pelo Claude Code) e valem para este prompt. Não são repetidos aqui.

---

## 1. Estado real da casca

_Cruzamento feito com o código da casca (`nodimus-studio---game-editor-ide`) e com as SPECs relacionadas ao final deste prompt. **EXISTE** = estender, sem recriar; **CRIAR** = inexistente na casca, criar antes de usar._

| Item | Status | Ação |
|---|---|---|
| ProjectSettingsModal → `src/components/modals/ProjectSettingsModal.tsx` (343 linhas) | **EXISTE** | estender, sem recriar |
| `themeService` / tokens → `src/core/theme/` (criados no AIS-01) | **EXISTE** | consumir; não criar serviço paralelo |
| `PreferencesDialog` → `src/components/modals/PreferencesDialog.tsx` | **CRIAR** | novo modal, mesmo padrão dos existentes |
| Configurador de Temas → `src/components/modals/preferences/ThemeConfigurator.tsx` + funções puras (`parseColor`, `contrastRatio`, `validateTokenValue`, `normalizeThemeDef`) | **CRIAR** | onde o tema claro é criado e editado |

## 2. Contexto e integração

Adiciona um novo modal `PreferencesDialog.tsx` em `src/components/modals/`, seguindo exatamente o mesmo padrão visual/estrutural dos modais já existentes (`FogModal.tsx`, `ProjectSettingsModal.tsx`) e acessível pela `TopBar`.

---

## 3. Especificação

```text
Implemente o Diálogo de Preferências (por usuário/máquina, não por projeto — persistido fora de `res://`, ex.: via `tauriBridge`/armazenamento local do app):
- Aba 'Geral': idioma (integra com o `I18nContext` do AIS-80), intervalo de autosave. **Migre aqui o seletor de idioma provisório criado na `TopBar` pelo AIS-80 — remova-o da `TopBar` assim que a aba 'Geral' assumir essa função, para não ter dois seletores de idioma coexistindo.**
- Aba 'Atalhos': lista os atalhos do AIS-04 com opção de remapeamento (nesta v1, ao menos leitura/visualização; remapeamento editável é desejável mas pode virar pergunta ao usuário (PARE E PERGUNTE) se o tempo apertar).
- Aba 'Aparência': (a) seletor de tema ativo e **Configurador de Temas**, onde o **tema claro é criado e editado pelo usuário** (o dark é o único embutido; o claro não vem pronto — comportamento completo na skill `nodimus-preferences-dialog`); (b) variação de densidade dos painéis docked, reaproveitando os design tokens já definidos no AIS-01.
```

---

## 4. Diretrizes técnicas

1. **Preferências de máquina, não de projeto:** Não confundir com `ProjectSettingsModal.tsx` (AIS-32), que é por-projeto e vive em `res://`.
2. **Reuso visual total:** Zero componentes de modal novos do zero — reaproveite o esqueleto de modal já estabelecido pelos outros 6 modais existentes.
3. **Tema sem CSS claro:** nenhuma paleta clara vai para `index.css`; toda cor vem de tokens `--gl-*` e o Configurador grava apenas em `localStorage` (decisão 13), nunca no projeto.

Se houver qualquer incompatibilidade ou dúvida arquitetural durante a execução, aplique **PARE E PERGUNTE** (ver `CLAUDE.md`): pare, descreva o problema com opções A/B/C e recomendação técnica, e aguarde a resposta do usuário antes de continuar.

---

## 5. Critérios de aceite (verificáveis por `npm run check` e no navegador)

- [ ] **AIS-82-C01** Alterar o idioma na aba Geral reflete imediatamente na UI (integração com AIS-80).
- [ ] **AIS-82-C02** Seletor de idioma provisório da `TopBar` (AIS-80) foi removido/migrado — resta apenas o seletor da aba Geral.
- [ ] **AIS-82-C03** `npm run check` passa e o editor (`npm run dev`) carrega no navegador e permanece **sem erros no console** (zero erros vermelhos) durante toda a interação com a funcionalidade.
- [ ] **AIS-82-C04** O comportamento descrito na Especificação é **visível e operável no navegador** (`npm run dev`), exercitado manualmente do início ao fim.
- [ ] **AIS-82-C05** Nenhuma funcionalidade pré-existente da casca regrediu (TopBar, SceneTree, FileSystem, Viewport 3D, Inspector, BottomPanel e modais).
- [ ] **AIS-82-C06** "Novo tema claro" cria um tema claro completo a partir do modelo inicial, torna-o ativo e o shell e os modais ficam claros sem editar componente e sem hex inline.
- [ ] **AIS-82-C07** Editar uma cor no Configurador (seletor ou campo de texto) repinta a UI na hora; valor inválido não é gravado e o campo mostra erro.
- [ ] **AIS-82-C08** Tema criado e alterado persiste após recarregar; excluir o tema ativo volta ao dark; o dark embutido não é editável (controles desabilitados com tooltip) e pode ser duplicado.
- [ ] **AIS-82-C09** Pares de contraste abaixo do mínimo mostram aviso com a razão calculada, sem bloquear a edição.
- [ ] **AIS-82-C10** Log `docs/logs/AIS-82.md` gravado ao concluir (formato no `CLAUDE.md`), com arquivos, decisões, resultado de cada critério e pendências.

## 6. Contexto de domínio (skills embutidas)

Conhecimento de domínio a seguir; onde a especificação citar uma skill, a regra dela está aqui.

### SKILL: nodimus-preferences-dialog

> Diálogo 'Editor Preferences' do Nodimus 3D Studio: abas Geral (idioma en/pt-BR), Atalhos e Aparência (seletor de tema + Configurador de Temas, onde o tema claro é criado e editado), sem estado de rascunho e sem botão Apply, usando a base .modal--native. Use ao implementar ou ampliar Preferences.

# Preferences dialog

> **Dono de:** a superfície de UI do `PreferencesDialog` e do **Configurador de Temas**. **Depende de:**
> `nodimus-design-tokens-tema` (`themeService`), `nodimus-i18n` (`language/setLanguage`),
> `nodimus-shell-interface`. Não cria estado paralelo de tema/idioma — expõe e edita o que os serviços guardam.

## Estrutura

```
.modal-overlay
  .modal.modal--native.preferences-dialog
    .modal__titlebar  "Editor Preferences" + [×]
    .modal__body
      abas: Geral | Atalhos | Aparência
      Geral      : <select> idioma → 'en' | 'pt-BR'   (onChange = setLanguage)
      Atalhos    : lista dos atalhos do AIS-04 (leitura; remapeamento = PARE E PERGUNTE)
      Aparência  : <select> tema ativo → 'Dark (embutido)' + temas criados pelo usuário  (onChange = setActiveTheme)
                   Configurador de Temas (abaixo)  ·  densidade dos painéis docked
    .modal__footer  [ Close ]
```
- Cada controle lê direto do serviço/store e chama o setter direto: **sem `useState` de rascunho, sem botão
  Apply**; reflete imediatamente na UI. O tema selecionado no `<select>` **é** o tema ativo e o alvo da edição.
- `theme: 'system'` não existe na UI (só temas concretos `dark`/`light`).
- Botão único `[ Close ]`. Estado de abertura (`preferencesDialogOpen`) é transitório e **não** persiste.
- Aberto pela toolbar (fileira extra) e por `Tools → Preferences` — o mesmo comando (`nodimus-shell-interface` §2).
- Todo texto via `t()`; ícone via registro.

## Configurador de Temas (aba Aparência)

É **aqui** que o tema claro nasce e é alterado; o produto não traz tema claro pronto.

- **Novo tema claro:** cria um tema `base: 'light'` copiando a `LIGHT_SEED` (nome "Tema claro N"), salva, torna
  ativo e mostra o editor. **Duplicar** copia qualquer tema (inclusive o dark) mantendo a `base`. **Renomear** e
  **Excluir** valem para temas do usuário; excluir o tema ativo volta para o dark (com confirmação simples).
- **Dark embutido:** controles de edição desabilitados com tooltip "tema embutido — duplique para editar"
  (decisão 14: nada de botão fictício).
- **Editor de tokens:** lista agrupada (Superfícies, Bordas, Destaque, Campos, Texto, Erro/Tag/Overlay,
  Categorias de Behavior). Cada linha: rótulo, `<input type="color">`, campo de texto (hex `#rgb`/`#rrggbb` ou
  `rgba()` — o `--gl-overlay` usa `rgba`) e botão "restaurar" (volta ao valor com que o tema foi aberto). Valor
  inválido: borda de erro, **não grava**, mantém o último válido.
- **Edição ao vivo:** cada alteração válida chama `saveTheme` e o tema ativo é reaplicado na hora — o próprio
  shell é o preview.
- **Avisos de contraste (não bloqueiam):** razão WCAG para os pares `text×bg`, `text×panel`, `text-muted×bg`,
  `text-muted×panel`, `danger-text×danger-bg` e cada `cat×cat-bg` (mínimo 4,5:1; `accent×bg` mínimo 3:1). O
  badge mostra a razão calculada ao lado da linha.
- **Funções puras** (regra 12, entregue com checklist reproduzível): `parseColor`, `contrastRatio`,
  `validateTokenValue`, `normalizeThemeDef`.
- **Persistência:** `localStorage` (`nodimus_themes`, `nodimus_theme`), nunca no projeto.

## Fora de escopo

Importar/exportar temas, tema `system`, editor de fontes/tamanhos, atalhos remapeáveis (decisão via PARE E
PERGUNTE), unidades. Adicionar grupo novo só quando houver preferência real.

## Definição de "pronto"

- Trocar idioma/tema no diálogo atualiza o shell na hora e sobrevive a recarregar a página.
- Criar um tema claro, editar tokens e vê-lo persistir após recarregar, sem tocar em nenhum componente.

---

### SKILL: nodimus-shell-interface

> Shell de interface desktop estilo Godot 3.x do Nodimus 3D Studio: TopBar (40px, menus, play controls, workspaces), layout docked de alta densidade (SceneTree, FileSystem, Viewport 3D, Inspector, BottomPanel), atalhos de teclado desktop (Ctrl+Z, Ctrl+S, F5, F6, W, E, R, F), modais especializados e diretriz estritamente desktop (Item 2 Opção C).

# Shell de Interface Desktop (Godot 3.x Style)

> **Dono de:** Layout desktop, TopBar, docking de painéis, atalhos de teclado, ergonomia de mouse e menus.  
> **Deliberação Canônica:** **Item 2: Opção C — Editor Estritamente Desktop** (Tauri v2 Desktop, zero Electron, docked panels de alta densidade, sem concessões mobile).

---

## 1. Arquitetura do Layout Docked

O layout é desenhado para telas desktop (1080p, 1440p, 4K) em tema escuro (`#181c24`, `#202531`, `#2c3345`):

```text
+-----------------------------------------------------------------------------------+
| TopBar (40px): Menus (Project/Scene/Edit/Debug), Workspaces, Play (F5/F6/F8)       |
+-------------------+-------------------------------------------+-------------------+
| Dock Esquerdo     | Viewport Central                          | Dock Direito      |
|                   |                                           |                   |
| 1. SceneTreePanel | Viewport3D (WebGL Three.js)               | InspectorPanel    |
|    (Hierarquia)   | [Alternador: 3D / Visual Logic / Script]  | (Propriedades     |
|                   |                                           |  dinâmicas)       |
| 2. FileSystem     +-------------------------------------------+                   |
|    Panel (res://) | BottomPanel (Colapsável: Console/Debugger)| NodeSignalsTab    |
+-------------------+-------------------------------------------+-------------------+
```

---

## 2. Componentes Principais do Shell

1. **TopBar (`src/components/layout/TopBar.tsx`):**
   - Menus em cascata: Project, Scene, Edit, Debug, Editor, Help.
   - Workspaces existentes na casca (`WorkspaceMode`): Cena 3D (`Viewport3D`), Lógica Visual (`VisualLogicEditor`) e Script (`CodeEditorWorkspace`).
   - Botões de Execução: Play Project (`F5`), Play Scene (`F6`), Stop (`F8`).
   - Indicador de status de projeto e atalhos rápidos.

2. **Dock Esquerdo:**
   - **SceneTreePanel:** Grafo hierárquico de nós com drag-and-drop, ícones técnicos por tipo de nó, toggles de visibilidade e bloqueio.
   - **FileSystemPanel:** Navegador virtual `res://` com pastas organizadas (`res://scenes/`, `res://textures/`, etc.) e botão de ação rápida "Importar 3D".

3. **Área Central:**
   - **Viewport3D:** Canvas WebGL Three.js com Gizmo TransformControls RGB, iluminação suave, grid infinito e câmera orbital.
   - **BottomPanel:** Console de saída em tempo real (logs de sistema, warnings, erros) e depurador de nós.

4. **Dock Direito:**
   - **InspectorPanel:** Seções colapsáveis baseadas no nó selecionado (Transform, MeshInstance, Light, Camera, Audio, Physics).
   - **PropertyField:** Controles numéricos arrastáveis (drag numbers) calibrados para precisão de mouse e entradas com eixos coloridos RGB.
   - **NodeSignalsTab:** Mapeamento visual de sinais e eventos emitidos pelo nó.

---

## 3. Atalhos Globais de Teclado Desktop

- `F5`: Play Project.
- `F6`: Play Scene atual.
- `F8`: Parar simulação.
- `Ctrl/Cmd + S`: Salvar cena ativa em `res://scenes/`.
- `Ctrl/Cmd + Z`: Desfazer comando via `CommandManager`.
- `Ctrl/Cmd + Y` ou `Ctrl+Shift+Z`: Refazer comando.
- `Ctrl/Cmd + D`: Duplicar nó selecionado na hierarquia.
- `W`: Ativar Gizmo de Translação (Move).
- `E`: Ativar Gizmo de Rotação (Rotate).
- `R`: Ativar Gizmo de Escala (Scale).
- `F`: Enquadrar câmera no nó selecionado (Frame Selected).
- `Delete / Backspace`: Excluir nós selecionados.

---

## 4. Diretriz Anti-Electron e Desktop Estrito

- **Zero Electron:** Interface e empacotamento exclusivamente sob Tauri v2 Desktop com fallback isomorfo web (`tauriBridge.ts`).
- **Sem Concessões Mobile:** A interface preserva densidade total de informações em todas as janelas; não há versões colapsadas ou interfaces simplificadas touch.

---

### SKILL: nodimus-design-tokens-tema

> Tokens CSS (--gl-*) do Nodimus 3D Studio, classes base (.toolbar__button, .property-grid, .modal), tokens de categoria de Behavior e o mecanismo de temas: o dark é o único tema embutido; o tema claro não vem pronto, é criado e editado pelo usuário no Configurador de Temas (Preferências → Aparência). Use ao estilizar qualquer componente, adicionar cor nova ou mexer no mecanismo de tema.

# Design tokens e temas

> **Dono de:** contrato das variáveis CSS `--gl-*` (nomes **e** valores do dark), classes visuais de base e
> mecanismo de aplicação de temas (`themeService`). **UI de criação/edição de temas** → `nodimus-preferences-dialog`
> (Configurador de Temas, AIS-82). **Conceito** (dark embutido, tema claro criado pelo usuário, persistência) →
> `CLAUDE.md`, decisão 13. Origem: capítulos 08i + 08k do conjunto 01 (valores preservados). Prefixo
> `--gl-` mantido por compatibilidade; pode virar `--nd-` numa migração única e mecânica (não misture os dois).

## Regra de ouro

**Nenhum componente declara cor hex inline** — sempre `var(--gl-*)`. Nomes de token nunca mudam entre temas;
um tema só troca *valores*. Por isso criar ou editar um tema (inclusive o claro) não exige editar componente algum.

## Tokens

`:root` traz **somente o dark** (valores = tokens `--ide-*` já existentes em `src/index.css` da casca). A coluna
"Semente do modelo claro" **não é CSS**: são os valores iniciais que o botão "Novo tema claro" do Configurador
(AIS-82) copia para o tema criado pelo usuário. Não existe bloco `[data-theme="light"]` com essas cores em
`index.css`; a única regra específica de light no CSS é `:root[data-theme="light"] { color-scheme: light; }`
(scrollbars e controles nativos).

| Variável | Dark (embutido) | Semente do modelo claro | Uso |
|---|---|---|---|
| `--gl-bg` | `#181c24` | `#f0f0f0` | fundo base |
| `--gl-panel` | `#202531` | `#f5f5f5` | painéis/barras |
| `--gl-bg-strong` | `#202531` | `#e8e8e8` | toolbar ativa, cabeçalho de diálogo |
| `--gl-panel-alt` | `#2d2d30` | `#e8e8e8` | cabeçalho de seção, aba inativa |
| `--gl-border` | `#2c3345` | `#a0a0a0` | bordas clássicas |
| `--gl-border-subtle` | `#2d2d30` | `#d0d0d0` | bordas internas |
| `--gl-row-divider` | *(avaliar contraste)* | `#e0e0e0` | divisória de linha do grid |
| `--gl-hover-bg` / `--gl-hover-border` | `#2a3140` / *(avaliar)* | `#e0e0e0` / `#b5b5b5` | hover de botão |
| `--gl-accent` | `#4982ea` | `#0078d7` | destaque de seleção |
| `--gl-accent-bg` | `#323b4e` | `#cce8ff` | item/botão ativo |
| `--gl-accent-border` | *(avaliar)* | `#99d1ff` | borda de ativo |
| `--gl-input-bg` | `#2d2d30` | `#ffffff` | input |
| `--gl-input-border` | *(avaliar)* | `#7f9db9` | borda de input |
| `--gl-text` | `#dfe4ec` | `#202225` | texto principal |
| `--gl-text-muted` | `#8b97a8` | `#6b6f76` | label |
| `--gl-text-disabled` | `#555555` | `#a7abb2` | desabilitado |
| `--gl-danger-bg/-border/-text` | `#442727`/`#6a3434`/`#f08080` | `#fdeaea`/`#f0b7b7`/`#b23a3a` | erro |
| `--gl-tag-bg` | `#223e2a` | `#dcefe0` | chip de tag |
| `--gl-overlay` | `rgba(0,0,0,0.65)` | `rgba(20,22,26,0.35)` | fundo de modal |

Prefixo final (`--gl-` × `--ide-` existente) = PARE E PERGUNTE no AIS-01. "*(avaliar)*": sem valor dark na
casca; decida por **verificação visual de contraste** e registre a decisão no log do prompt
(`docs/logs/AIS-01.md`); não invente por estética. Quando o dark ganhar o valor decidido, a semente clara do
mesmo token continua como está.

Tokens de **categoria de Behavior** (`--gl-cat-*` e `-bg`):

| Categoria | Dark (embutido) | Semente do modelo claro |
|---|---|---|
| Movimento | `#5eead4` / `#123734` | `#0f766e` / `#e2f4f1` |
| Física | `#fbbf24` / `#3a2e11` | `#b45309` / `#faedd9` |
| Interação | `#c4b5fd` / `#2c2350` | `#7c3aed` / `#efe6ff` |
| IA | `#f472b6` / `#3a1a2b` | `#be185d` / `#fbe3ee` |
| Câmera | `#38bdf8` / `#0f2e3d` | `#38bdf8` / `#dff1ff` |
| Utilitário | `#94a3b8` / `#2a2f36` | `#475569` / `#e7eaee` |
| Custom (fallback) | `#9ca3af` / `#2a2c30` | `#6b7280` / `#eceef0` |

**Tipografia — preservar a casca existente:** não alterar a família tipográfica, o tamanho-base, pesos, line-height ou escala tipográfica já usados pelo editor. Detecte e reutilize os tokens/CSS existentes. Somente se a casca realmente não possuir qualquer definição tipográfica, use `'Segoe UI', Tahoma, Arial, sans-serif` como *fallback* técnico; isso não autoriza substituir uma fonte existente.

## Classes de base

- `.toolbar__button`: altura 25px, `padding: 2px 6px`; inativo transparente; hover `--gl-hover-*`; ativo
  (`.is-active`) `--gl-accent-bg/border` + `box-shadow: inset 0 1px 2px rgba(0,0,0,.12)` (sem sombra externa).
- `.property-grid .property-row`: label 120px fixo (`--gl-text-muted`), controle no resto, divisória
  `--gl-row-divider`, input com `--gl-input-*`. Use **flexbox** (não `display:grid` puro): linhas de 3 inputs
  (`vect3d`/cor RGB) sem wrapper quebrariam a grade.
- `.modal`/`.modal--native`: barra de título estilo Win32, botão `[X]`, rodapé com botões 75×23px.

## Mecanismo de temas (`src/core/theme/`, criado no AIS-01)

```ts
type ThemeBase = 'dark' | 'light'          // define color-scheme; nunca 'system' nesta fase
interface EditorThemeDef {
  schemaVersion: 1
  id: string                                // 'dark' (embutido) ou UUID gerado ao criar
  name: string
  base: ThemeBase
  builtin?: boolean                         // só o dark
  tokens: Record<string, string>            // nome do token → valor (hex ou rgba())
}
```
- **Embutido:** só `dark` (`builtin: true`, somente leitura). Os valores dark são **lidos do CSS `:root`** na
  inicialização (antes de qualquer override), portanto `index.css` é a fonte única do dark. A semente clara
  vive em TypeScript (`LIGHT_SEED`, mesma lista de nomes) e só é usada pelo Configurador.
- **Temas do usuário:** array em `localStorage['nodimus_themes']`, validado por schema Zod (entrada inválida é
  descartada com aviso no console de saída, sem quebrar o boot). Tema ativo em `localStorage['nodimus_theme']`
  (id); ausente, inválido ou apontando para tema inexistente → **`'dark'`**.
- `themeService`: `listThemes()`, `getActiveThemeId()`, `setActiveTheme(id)`, `saveTheme(def)`,
  `deleteTheme(id)`. Cada escrita grava em `localStorage` **no mesmo passo** e reaplica o tema ativo.
- `applyTheme(def)`: define `data-theme` (= `def.base`) em `document.documentElement` e aplica cada token com
  `documentElement.style.setProperty('--gl-…', valor)`. Para o dark embutido remove **todos** os overrides
  inline (`removeProperty`), voltando ao CSS. Token ausente num tema do usuário cai no valor dark do `:root`.
- Inicialização: `main.tsx` aplica o tema ativo de forma síncrona **antes** de `createRoot().render(...)`, para
  evitar flash de tema errado. Não edite `index.html` sem PARE E PERGUNTE (ver AIS-P0).
- **A viewport 3D não consome `--gl-*`**: trocar tema é só repaint de CSS, não re-renderiza Three.js.
- Persistência é **preferência de UI**, fora do projeto (`CLAUDE.md`, decisão 13).

## Definição de "pronto"

- Instalação nova abre em `dark` idêntico ao atual; o CSS não contém nenhuma paleta clara.
- Sobrescrever `--gl-bg` e `--gl-panel` em `document.documentElement.style` (DevTools) repinta shell e modais sem
  editar componente (prova de que não há hex inline); grep de `#[0-9a-f]{3,8}` fora do CSS de tokens e da
  `LIGHT_SEED` não acha nada.
- O tema claro só existe depois de o usuário criá-lo no Configurador; ele persiste e é reaplicado ao recarregar.

---

### SKILL: nodimus-i18n

> Internacionalização do Nodimus 3D Studio (en como canônico + pt-BR) sem biblioteca externa: dicionário tipado, t(language, path, params), hook useTranslation, estado language no store, persistência em localStorage, vocabulário fixo e teste de regressão contra strings literais na UI. Use ao criar qualquer rótulo visível, diálogo ou mensagem de erro.

# i18n nativo (en + pt-BR)

> **Dono de:** mecanismo de i18n (formato do dicionário, `t()`, hook, estado). **Conceito** (idiomas,
> default, persistência) → `CLAUDE.md` (decisão 13). Origem: `08j` + correção D-08/33i das auditorias.

## 1. Por que sem `react-i18next`

Dois idiomas pequenos cabem inteiros em memória; não há I/O de tradução. O dicionário nativo dá **zero
dependência nova**, troca de idioma em tempo real pelo mesmo Zustand e (em TS) chave inexistente vira erro
de build. Em **JavaScript puro** essa garantia de compilação some — substitua-a por **testes** (§4).

## 2. Estrutura

```
src/i18n/
  locales/en.js      dicionário canônico (toda chave nasce aqui)
  locales/ptBR.js    mesma forma de en
  index.js           t(), useTranslation(), readStoredLanguage()
```
Idiomas: `'en'` (padrão) e `'pt-BR'`. Persistência: `localStorage['nodimus_language']`; ausente/inválido → `en`.

## 3. Contrato

```js
t(language, 'toolbar.select', { name })   // caminho "seção.chave"; {param} interpolado
useTranslation() → { t, language, setLanguage }
```
Seções mínimas: `menus, toolbar, contextTabs, panels, dialogs, terrain, preferences` (+ uma por diálogo novo:
`gameSettings, spriteEditor, scenes, water, terrainEdit…`). Presets de Terrain: **Hills / Deserts / Flat**
(não "mountains"). Categorias da Resource Tree e grafia `Behavior` seguem `nodimus-shell-interface` §6.
Sem fallback silencioso: chave ausente em `pt-BR` é falha de teste, não texto em inglês rodando escondido.

## 4. Testes obrigatórios (substituem o typecheck)

1. `ptBR` tem **exatamente** o mesmo conjunto de chaves de `en` (deep keys).
2. Todo `t('a.b')` usado no código existe em `en`.
3. **Regressão de string literal:** varrer `src/ui/**` e `src/viewport/**` por JSX com texto visível ou
   `title=`/`aria-label=`/`placeholder=` literais e falhar se aparecerem fora dos dicionários (mesmo padrão
   do teste de registro de ícones). Isso é o que impede a regressão apontada na auditoria D-08.

## 5. Regras

- Toda string visível (inclusive tooltip, erro, confirmação, diálogo) passa por `t()`; **rótulo novo já
  nasce com `t()`**, não é traduzido depois.
- Hora exibida em 24 h independentemente do locale do host (`hour12: false`).
- Números decimais aceitam vírgula em pt-BR (`nodimus-scenegraph-modelo` §4).
- Nome de Behavior/Action vem do `label` da definição em `src/logic/<tipo>/<id>/` e passa pelo dicionário do editor (chave = ID da pasta).

## Definição de "pronto"

- Trocar o idioma em Preferences atualiza toda a UI sem recarregar.
- Os 3 testes acima passam; adicionar uma string literal em `src/ui` quebra o teste 3.

## SPECs relacionadas

- [project-settings-modal.spec.md](../specs/modais/project-settings-modal.spec.md)
