# AIS-80 — Internacionalização (i18n) do Editor e do Runtime Exportado

> **Origem:** Prompt 80 · **Módulo 15:** Infraestrutura do Editor e do Produto · **Destino:** Claude Code (Claude Desktop) · **Skills embutidas:** `nodimus-i18n`, `nodimus-shell-interface`, `nodimus-preferences-dialog`

> **Posição canônica:** Fase H — Plataforma e produto · nº 126 de 135 · anterior: AIS-79 · próximo: AIS-81
> **Relaciona-se com:** AIS-02, AIS-82
> **Decisão Canônica Relacionada:** Extensão de Escopo (Módulo 13) — toda a casca atual (`src/components/**`) tem strings de UI hardcoded em português/inglês misturados; não há camada de tradução.

---

## 0. Preâmbulo fixo

Identidade, hierarquia da verdade, decisões canônicas (as numeradas no `CLAUDE.md`, até a 32), contratos arquiteturais transversais e regras de execução (1–14) estão no **`CLAUDE.md`** da raiz do repositório (carregado automaticamente pelo Claude Code) e valem para este prompt. Não são repetidos aqui.

---

## 1. Estado real da casca

_Cruzamento feito com o código da casca (`nodimus-studio---game-editor-ide`) e com as SPECs relacionadas ao final deste prompt. **EXISTE** = estender, sem recriar; **CRIAR** = inexistente na casca, criar antes de usar._

| Item | Status | Ação |
|---|---|---|
| node → `src/types/node.ts` (109 linhas) | **EXISTE** | estender, sem recriar |
| scene → `src/types/scene.ts` (103 linhas) | **EXISTE** | estender, sem recriar |

## 2. Contexto e integração

Introduz um hook `useTranslation()`/contexto `I18nContext` em `src/core/` (mesmo padrão de Context já usado pelo `EditorContext.tsx`, AIS-02) e extrai progressivamente as strings visíveis da `TopBar`, painéis e modais para arquivos `res://locales/<idioma>.json`.

---

## 3. Especificação

```text
Implemente a camada de i18n:
- `I18nContext` com idioma ativo e função `t(key: string, vars?: Record<string, string>)`.
- Extração inicial das strings da `TopBar.tsx` e dos títulos/botões dos modais já existentes (não é preciso migrar 100% da casca num único prompt — priorize os textos mais visíveis e documente o restante como dívida rastreada).
- Seletor de idioma **provisório** na `TopBar` (ex.: dropdown compacto próximo ao menu Help), só para permitir testar a troca de idioma antes do Diálogo de Preferências existir. Este seletor provisório é migrado/removido no AIS-82, quando a aba "Geral" do Diálogo de Preferências assume definitivamente essa função.
- O mesmo mecanismo deve poder ser reaproveitado pelo runtime exportado (texto de UI/HUD de jogos publicados), não só pelo editor.
```

> **Nota de sequência (decisão canônica nº 11 do `CLAUDE.md`):** este prompt (80) e o AIS-82 (Diálogo de Preferências) têm dependência cruzada — o 82 precisa do `I18nContext` criado aqui, e o critério "trocar idioma no Diálogo de Preferências" só existe a partir do 82. Para não travar a ordem, o 80 entrega um seletor **provisório** na `TopBar` como critério de aceite intermediário; o critério definitivo "via Diálogo de Preferências" é validado no AIS-82. Decisão registrada em o registro de decisões do projeto.

---

## 4. Diretrizes técnicas

2. **Reuso de Context:** Siga o mesmo padrão arquitetural do `EditorContext.tsx` (AIS-02) em vez de uma biblioteca de i18n externa pesada, mantendo a stack oficial (Seção 2 do `03-arquitetura-stack.md`).

Se houver qualquer incompatibilidade ou dúvida arquitetural durante a execução, aplique **PARE E PERGUNTE** (ver `CLAUDE.md`): pare, descreva o problema com opções A/B/C e recomendação técnica, e aguarde a resposta do usuário antes de continuar.

---

## 5. Critérios de aceite (verificáveis por `npm run check` e no navegador)

- [ ] **AIS-80-C01** Trocar o idioma no seletor provisório da `TopBar` atualiza a UI sem reload da página/app. **(Critério intermediário — a validação definitiva "via Diálogo de Preferências" é do AIS-82, não deste prompt.)**
- [ ] **AIS-80-C02** `npm run check` passa e o editor (`npm run dev`) carrega no navegador e permanece **sem erros no console** (zero erros vermelhos) durante toda a interação com a funcionalidade.
- [ ] **AIS-80-C03** O comportamento descrito na Especificação é **visível e operável no navegador** (`npm run dev`), exercitado manualmente do início ao fim.
- [ ] **AIS-80-C04** Nenhuma funcionalidade pré-existente da casca regrediu (TopBar, SceneTree, FileSystem, Viewport 3D, Inspector, BottomPanel e modais).
- [ ] **AIS-80-C05** Log `docs/logs/AIS-80.md` gravado ao concluir (formato no `CLAUDE.md`), com arquivos, decisões, resultado de cada critério e pendências.

## 6. Contexto de domínio (skills embutidas)

Conhecimento de domínio a seguir; onde a especificação citar uma skill, a regra dela está aqui.

### SKILL: nodimus-i18n

> Internacionalização do Nodimus 3D Studio (en como canônico + pt-BR) sem biblioteca externa: dicionário tipado, t(language, path, params), hook useTranslation, estado language no store, persistência em localStorage, vocabulário fixo e teste de regressão contra strings literais na UI. Use ao criar qualquer rótulo visível, diálogo ou mensagem de erro.

# i18n nativo (en + pt-BR)

> **Dono de:** mecanismo de i18n (formato do dicionário, `t()`, hook, estado). **Conceito** (idiomas,
> default, persistência) → `CLAUDE.md` (decisão 13). Origem: `08j` + correção D-08/33i das auditorias.

## 1. Por que sem `react-i18next`

Dois idiomas pequenos cabem inteiros em memória; não há I/O de tradução. O dicionário nativo dá **zero
dependência nova**, troca de idioma em tempo real pelo mesmo Zustand e (em TS) chave inexistente vira erro
de build. Em **JavaScript puro** essa garantia de compilação some — substitua-a por **testes** (§4).

## 2. Estrutura

```
src/i18n/
  locales/en.js      dicionário canônico (toda chave nasce aqui)
  locales/ptBR.js    mesma forma de en
  index.js           t(), useTranslation(), readStoredLanguage()
```
Idiomas: `'en'` (padrão) e `'pt-BR'`. Persistência: `localStorage['nodimus_language']`; ausente/inválido → `en`.

## 3. Contrato

```js
t(language, 'toolbar.select', { name })   // caminho "seção.chave"; {param} interpolado
useTranslation() → { t, language, setLanguage }
```
Seções mínimas: `menus, toolbar, contextTabs, panels, dialogs, terrain, preferences` (+ uma por diálogo novo:
`gameSettings, spriteEditor, scenes, water, terrainEdit…`). Presets de Terrain: **Hills / Deserts / Flat**
(não "mountains"). Categorias da Resource Tree e grafia `Behavior` seguem `nodimus-shell-interface` §6.
Sem fallback silencioso: chave ausente em `pt-BR` é falha de teste, não texto em inglês rodando escondido.

## 4. Testes obrigatórios (substituem o typecheck)

1. `ptBR` tem **exatamente** o mesmo conjunto de chaves de `en` (deep keys).
2. Todo `t('a.b')` usado no código existe em `en`.
3. **Regressão de string literal:** varrer `src/ui/**` e `src/viewport/**` por JSX com texto visível ou
   `title=`/`aria-label=`/`placeholder=` literais e falhar se aparecerem fora dos dicionários (mesmo padrão
   do teste de registro de ícones). Isso é o que impede a regressão apontada na auditoria D-08.

## 5. Regras

- Toda string visível (inclusive tooltip, erro, confirmação, diálogo) passa por `t()`; **rótulo novo já
  nasce com `t()`**, não é traduzido depois.
- Hora exibida em 24 h independentemente do locale do host (`hour12: false`).
- Números decimais aceitam vírgula em pt-BR (`nodimus-scenegraph-modelo` §4).
- Nome de Behavior/Action vem do `label` da definição em `src/logic/<tipo>/<id>/` e passa pelo dicionário do editor (chave = ID da pasta).

## Definição de "pronto"

- Trocar o idioma em Preferences atualiza toda a UI sem recarregar.
- Os 3 testes acima passam; adicionar uma string literal em `src/ui` quebra o teste 3.

---

### SKILL: nodimus-shell-interface

> Shell de interface desktop estilo Godot 3.x do Nodimus 3D Studio: TopBar (40px, menus, play controls, workspaces), layout docked de alta densidade (SceneTree, FileSystem, Viewport 3D, Inspector, BottomPanel), atalhos de teclado desktop (Ctrl+Z, Ctrl+S, F5, F6, W, E, R, F), modais especializados e diretriz estritamente desktop (Item 2 Opção C).

# Shell de Interface Desktop (Godot 3.x Style)

> **Dono de:** Layout desktop, TopBar, docking de painéis, atalhos de teclado, ergonomia de mouse e menus.  
> **Deliberação Canônica:** **Item 2: Opção C — Editor Estritamente Desktop** (Tauri v2 Desktop, zero Electron, docked panels de alta densidade, sem concessões mobile).

---

## 1. Arquitetura do Layout Docked

O layout é desenhado para telas desktop (1080p, 1440p, 4K) em tema escuro (`#181c24`, `#202531`, `#2c3345`):

```text
+-----------------------------------------------------------------------------------+
| TopBar (40px): Menus (Project/Scene/Edit/Debug), Workspaces, Play (F5/F6/F8)       |
+-------------------+-------------------------------------------+-------------------+
| Dock Esquerdo     | Viewport Central                          | Dock Direito      |
|                   |                                           |                   |
| 1. SceneTreePanel | Viewport3D (WebGL Three.js)               | InspectorPanel    |
|    (Hierarquia)   | [Alternador: 3D / Visual Logic / Script]  | (Propriedades     |
|                   |                                           |  dinâmicas)       |
| 2. FileSystem     +-------------------------------------------+                   |
|    Panel (res://) | BottomPanel (Colapsável: Console/Debugger)| NodeSignalsTab    |
+-------------------+-------------------------------------------+-------------------+
```

---

## 2. Componentes Principais do Shell

1. **TopBar (`src/components/layout/TopBar.tsx`):**
   - Menus em cascata: Project, Scene, Edit, Debug, Editor, Help.
   - Workspaces existentes na casca (`WorkspaceMode`): Cena 3D (`Viewport3D`), Lógica Visual (`VisualLogicEditor`) e Script (`CodeEditorWorkspace`).
   - Botões de Execução: Play Project (`F5`), Play Scene (`F6`), Stop (`F8`).
   - Indicador de status de projeto e atalhos rápidos.

2. **Dock Esquerdo:**
   - **SceneTreePanel:** Grafo hierárquico de nós com drag-and-drop, ícones técnicos por tipo de nó, toggles de visibilidade e bloqueio.
   - **FileSystemPanel:** Navegador virtual `res://` com pastas organizadas (`res://scenes/`, `res://textures/`, etc.) e botão de ação rápida "Importar 3D".

3. **Área Central:**
   - **Viewport3D:** Canvas WebGL Three.js com Gizmo TransformControls RGB, iluminação suave, grid infinito e câmera orbital.
   - **BottomPanel:** Console de saída em tempo real (logs de sistema, warnings, erros) e depurador de nós.

4. **Dock Direito:**
   - **InspectorPanel:** Seções colapsáveis baseadas no nó selecionado (Transform, MeshInstance, Light, Camera, Audio, Physics).
   - **PropertyField:** Controles numéricos arrastáveis (drag numbers) calibrados para precisão de mouse e entradas com eixos coloridos RGB.
   - **NodeSignalsTab:** Mapeamento visual de sinais e eventos emitidos pelo nó.

---

## 3. Atalhos Globais de Teclado Desktop

- `F5`: Play Project.
- `F6`: Play Scene atual.
- `F8`: Parar simulação.
- `Ctrl/Cmd + S`: Salvar cena ativa em `res://scenes/`.
- `Ctrl/Cmd + Z`: Desfazer comando via `CommandManager`.
- `Ctrl/Cmd + Y` ou `Ctrl+Shift+Z`: Refazer comando.
- `Ctrl/Cmd + D`: Duplicar nó selecionado na hierarquia.
- `W`: Ativar Gizmo de Translação (Move).
- `E`: Ativar Gizmo de Rotação (Rotate).
- `R`: Ativar Gizmo de Escala (Scale).
- `F`: Enquadrar câmera no nó selecionado (Frame Selected).
- `Delete / Backspace`: Excluir nós selecionados.

---

## 4. Diretriz Anti-Electron e Desktop Estrito

- **Zero Electron:** Interface e empacotamento exclusivamente sob Tauri v2 Desktop com fallback isomorfo web (`tauriBridge.ts`).
- **Sem Concessões Mobile:** A interface preserva densidade total de informações em todas as janelas; não há versões colapsadas ou interfaces simplificadas touch.

---

### SKILL: nodimus-preferences-dialog

> Diálogo 'Editor Preferences' do Nodimus 3D Studio: abas Geral (idioma en/pt-BR), Atalhos e Aparência (seletor de tema + Configurador de Temas, onde o tema claro é criado e editado), sem estado de rascunho e sem botão Apply, usando a base .modal--native. Use ao implementar ou ampliar Preferences.

# Preferences dialog

> **Dono de:** a superfície de UI do `PreferencesDialog` e do **Configurador de Temas**. **Depende de:**
> `nodimus-design-tokens-tema` (`themeService`), `nodimus-i18n` (`language/setLanguage`),
> `nodimus-shell-interface`. Não cria estado paralelo de tema/idioma — expõe e edita o que os serviços guardam.

## Estrutura

```
.modal-overlay
  .modal.modal--native.preferences-dialog
    .modal__titlebar  "Editor Preferences" + [×]
    .modal__body
      abas: Geral | Atalhos | Aparência
      Geral      : <select> idioma → 'en' | 'pt-BR'   (onChange = setLanguage)
      Atalhos    : lista dos atalhos do AIS-04 (leitura; remapeamento = PARE E PERGUNTE)
      Aparência  : <select> tema ativo → 'Dark (embutido)' + temas criados pelo usuário  (onChange = setActiveTheme)
                   Configurador de Temas (abaixo)  ·  densidade dos painéis docked
    .modal__footer  [ Close ]
```
- Cada controle lê direto do serviço/store e chama o setter direto: **sem `useState` de rascunho, sem botão
  Apply**; reflete imediatamente na UI. O tema selecionado no `<select>` **é** o tema ativo e o alvo da edição.
- `theme: 'system'` não existe na UI (só temas concretos `dark`/`light`).
- Botão único `[ Close ]`. Estado de abertura (`preferencesDialogOpen`) é transitório e **não** persiste.
- Aberto pela toolbar (fileira extra) e por `Tools → Preferences` — o mesmo comando (`nodimus-shell-interface` §2).
- Todo texto via `t()`; ícone via registro.

## Configurador de Temas (aba Aparência)

É **aqui** que o tema claro nasce e é alterado; o produto não traz tema claro pronto.

- **Novo tema claro:** cria um tema `base: 'light'` copiando a `LIGHT_SEED` (nome "Tema claro N"), salva, torna
  ativo e mostra o editor. **Duplicar** copia qualquer tema (inclusive o dark) mantendo a `base`. **Renomear** e
  **Excluir** valem para temas do usuário; excluir o tema ativo volta para o dark (com confirmação simples).
- **Dark embutido:** controles de edição desabilitados com tooltip "tema embutido — duplique para editar"
  (decisão 14: nada de botão fictício).
- **Editor de tokens:** lista agrupada (Superfícies, Bordas, Destaque, Campos, Texto, Erro/Tag/Overlay,
  Categorias de Behavior). Cada linha: rótulo, `<input type="color">`, campo de texto (hex `#rgb`/`#rrggbb` ou
  `rgba()` — o `--gl-overlay` usa `rgba`) e botão "restaurar" (volta ao valor com que o tema foi aberto). Valor
  inválido: borda de erro, **não grava**, mantém o último válido.
- **Edição ao vivo:** cada alteração válida chama `saveTheme` e o tema ativo é reaplicado na hora — o próprio
  shell é o preview.
- **Avisos de contraste (não bloqueiam):** razão WCAG para os pares `text×bg`, `text×panel`, `text-muted×bg`,
  `text-muted×panel`, `danger-text×danger-bg` e cada `cat×cat-bg` (mínimo 4,5:1; `accent×bg` mínimo 3:1). O
  badge mostra a razão calculada ao lado da linha.
- **Funções puras** (regra 12, entregue com checklist reproduzível): `parseColor`, `contrastRatio`,
  `validateTokenValue`, `normalizeThemeDef`.
- **Persistência:** `localStorage` (`nodimus_themes`, `nodimus_theme`), nunca no projeto.

## Fora de escopo

Importar/exportar temas, tema `system`, editor de fontes/tamanhos, atalhos remapeáveis (decisão via PARE E
PERGUNTE), unidades. Adicionar grupo novo só quando houver preferência real.

## Definição de "pronto"

- Trocar idioma/tema no diálogo atualiza o shell na hora e sobrevive a recarregar a página.
- Criar um tema claro, editar tokens e vê-lo persistir após recarregar, sem tocar em nenhum componente.

## SPECs relacionadas

- [node.spec.md](../specs/dominios/node.spec.md)
- [scene.spec.md](../specs/dominios/scene.spec.md)
