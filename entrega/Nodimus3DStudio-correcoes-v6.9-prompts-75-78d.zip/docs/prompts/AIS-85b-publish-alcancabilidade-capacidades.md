# AIS-85b — Publish por Alcançabilidade e Capacidades

> **Origem:** Complemento arquitetural v4/v4.1 (sem prompt-base numerado) · **Destino:** Claude Code (Claude Desktop)
> **Posição canônica:** Fase H — Plataforma e produto · nº 133 de 135 · anterior: AIS-85 · próximo: AIS-85c

> **Complemento evolutivo antecipado** · **Origem:** auditoria cruzada do projeto principal com o projeto paralelo maduro · **Objetivo:** evitar reescrita posterior sem substituir o prompt-base.

## 0. Preâmbulo fixo

Identidade, hierarquia da verdade, decisões canônicas (as numeradas no `CLAUDE.md`, até a 32), contratos arquiteturais transversais e regras de execução (1–14) estão no **`CLAUDE.md`** da raiz do repositório (carregado automaticamente pelo Claude Code) e valem para este prompt. Não são repetidos aqui.

## 1. Estado real da casca

_Este complemento cruza os artefatos abaixo com o código atual da casca: **EXISTE** = estender; **CRIAR** = criar antes de usar. Não invente uma segunda implementação._

| Item | Status | Ação |
|---|---|---|
| LogicRegistry → `src/logic/registry.ts` | **EXISTE** (AIS-05r) | fonte dos requisitos por item |
| tauriBridge → `src/core/tauriBridge.ts` (139 linhas) | **EXISTE** | estender, sem recriar |

## 2. Posição na sequência

Executar **depois do AIS-85** e antes de considerar o pipeline de publicação concluído.

## 3. Grafo de alcançabilidade

Partir da Scene inicial e percorrer Scenes alcançáveis por referências/Actions; depois GameNodes → Behaviors/Actions (executores nativos das pastas de `src/logic/` usadas) → scripts → assets referenciados. Empacotar apenas dependências alcançáveis necessárias ao runtime.

Código editor-only (UI da IDE, `src/logic/**/editor.tsx`, CommandManager, stores autorais) é proibido no bundle em qualquer target.

## 4. Matriz de capacidades

**Já existe (AIS-78c): consumir, não recriar.** `src/core/capabilities.ts` define `CAPABILITY_IDS`, `TARGET_PROFILES` (flags de host por target: `runtimeWeb`, `runtimeDesktop`, `runtimeMobile` distintas), `resolveSupport`/`resolveSupportAll` (puras, `supported | partial | not-supported`, ids desconhecidos preservados como não resolvidos), `buildCatalog` e `unsupportedFor(catalog, target)`. `src/logic/capabilityCatalog.ts` monta o catálogo VIVO (`LogicRegistry` + `NODE_DEFINITIONS` + `ENGINE_OPERATIONS`) sem copiar nada. Os requisitos vêm de `requires?: Capability[]` na definição da pasta (29 pastas já declaradas: física, DOM/Web Audio) e de `requires` em operações da EngineApi.

Este prompt **não** cria `PUBLISH_CAPABILITY_MATRIX` paralela nem lista de flags própria: o grafo de alcançabilidade filtra o catálogo (`unsupportedFor`) pelo conjunto alcançado e exibe o resultado antes do build. Item sem `requires` conta como suportado; id de capacidade desconhecido vira diagnóstico, não erro silencioso.

Scripts `.ts`/`.js` de `res://scripts/` usados no runtime são pré-compilados no build; bundle publicado não depende de `unsafe-eval`/esbuild-wasm no cliente.

## 5. Validação

Publish falha cedo quando uma contribuição alcançável é incompatível e necessária. Recurso não alcançável não bloqueia build. Assets/scripts ausentes geram diagnóstico com caminho de referência.

## 6. Critérios de aceite

- [ ] **AIS-85b-C01** Executor de Action/Behavior nativo não usado por nenhuma cena alcançável não entra no bundle (tree-shaking por pasta).
- [ ] **AIS-85b-C02** Script usado indiretamente por `run_script` entra.
- [ ] **AIS-85b-C03** Código editor-only nunca entra.
- [ ] **AIS-85b-C04** Scene alcançada apenas por Switch Scene entra.
- [ ] **AIS-85b-C05** Target incompatível é mostrado antes do build.
- [ ] **AIS-85b-C06** Bundle não requer compilação dinâmica de TypeScript no cliente.
- [ ] **AIS-85b-C07** Log `docs/logs/AIS-85b.md` gravado ao concluir (formato no `CLAUDE.md`), com arquivos, decisões, resultado de cada critério e pendências.
## Nivelamento definitivo — Publish usa o DependencyGraph canônico

Publish parte da Scene inicial e percorre dependências alcançáveis: Scenes → GameNodes → Prefabs → Behaviors/Actions → Scripts → Assets. Não empacotar todos os executores de `src/logic/` cegamente. A matriz de capabilities é resolvida por target e qualquer requisito não suportado gera diagnóstico bloqueante ou explícito conforme severidade.



## Contexto de domínio (skills embutidas)

### SKILL: nodimus-contratos-transversais

Use exclusivamente os contratos arquiteturais transversais do `CLAUDE.md`. Não crie stores, registries, bridges, serviços de diagnóstico, grafos ou APIs públicas paralelas. Toda contribuição deve ter ownership/lifecycle explícito e preservar IDs persistentes e dados não resolvidos.

## SPECs relacionadas

- [tauri-bridge.spec.md](../specs/dominios/tauri-bridge.spec.md)
- [logic-registry.spec.md](../specs/dominios/logic-registry.spec.md)

## EMENDA CANÔNICA v4.6 — targets de publicação
A matriz formal tem três targets: `web`, `desktop` e `mobile`. `runtimeWeb`, `runtimeDesktop` e `runtimeMobile` são capacidades distintas. O AIS-85b continua responsável por alcançabilidade, exclusão do editor e diagnóstico de compatibilidade; **não** deve implementar o host/empacotador. O empacotamento Desktop/Mobile com Tauri 2 pertence ao AIS-85c.

## Emenda v5.8 — Publish consulta o DiagnosticService (pendência AIS-32c-C04)

Antes de gerar o bundle, o Publish chama `globalDiagnosticService.hasBlocking(filtro)` (AIS-32c) para as cenas **alcançáveis** a partir da Scene inicial (recurso não alcançável não bloqueia, regra já existente). Os problemas de alcançabilidade, assets/scripts ausentes e target incompatível são publicados no serviço (`source: 'publish'`, `replaceForOwner` a cada análise) e mostrados antes do build, no formato `[código] mensagem`. Havendo bloqueio, o build não começa. Sem formato de erro paralelo.

- [ ] **AIS-85b-C08** Cena alcançável com diagnóstico `blocking` impede o build e lista `[código] mensagem`; a mesma pendência numa cena não alcançável não impede.
- [ ] **AIS-85b-C09** Reanalisar após corrigir substitui os diagnósticos do dono `publish` (sem acumular entradas antigas).
