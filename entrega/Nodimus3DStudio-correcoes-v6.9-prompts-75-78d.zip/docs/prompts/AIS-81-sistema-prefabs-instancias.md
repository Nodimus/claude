# AIS-81 — Sistema de Prefabs e Instâncias

> **Origem:** Prompt 81 · **Módulo 15:** Infraestrutura do Editor e do Produto · **Destino:** Claude Code (Claude Desktop) · **Skills embutidas:** `nodimus-prefabs`, `nodimus-scenegraph-modelo`, `nodimus-versionamento-cena`, `nodimus-projetos-workspace`

> **Posição canônica:** Fase H — Plataforma e produto · nº 127 de 135 · anterior: AIS-80 · próximo: AIS-81b
> **Nota v6.0:** o spawn de prefab **em runtime** (Play) já existe desde o AIS-29g (`RuntimeScene.spawnPrefab`, lê `PrefabV1`). Este prompt amplia o prefab autoral (edição, instâncias no authoring, dependências) e **não** cria outro caminho de instanciação em Play; ao mudar o formato, manter o contrato lido pelo AIS-29g.
> **Relaciona-se com:** AIS-16, AIS-18, AIS-20, AIS-29, AIS-31
> **Decisão Canônica Relacionada:** Extensão de Escopo (Módulo 13) — o `FileSystemPanel.tsx` (AIS-28) e o serializador de cenas (AIS-29) já existem; falta o conceito de 'sub-árvore reutilizável' entre cenas.

---

## 0. Preâmbulo fixo

Identidade, hierarquia da verdade, decisões canônicas (as numeradas no `CLAUDE.md`, até a 32), contratos arquiteturais transversais e regras de execução (1–14) estão no **`CLAUDE.md`** da raiz do repositório (carregado automaticamente pelo Claude Code) e valem para este prompt. Não são repetidos aqui.

---

## 1. Estado real da casca

_Cruzamento feito com o código da casca (`nodimus-studio---game-editor-ide`) e com as SPECs relacionadas ao final deste prompt. **EXISTE** = estender, sem recriar; **CRIAR** = inexistente na casca, criar antes de usar._

| Item | Status | Ação |
|---|---|---|
| registry → `src/nodes/registry.ts` (708 linhas) | **EXISTE** | estender, sem recriar |
| scene → `src/types/scene.ts` (103 linhas) | **EXISTE** | estender, sem recriar |

## 2. Contexto e integração

> **Emenda v5.1.1:** o AIS-16 já entregou a ação **Save Branch as Prefab** no menu de contexto e o serializador de ramo (`src/components/sceneTree/branchPrefab.ts`, `PrefabV1`). Este prompt **reutiliza** ambos (não recria) e acrescenta instâncias, referência à origem, "Atualizar instâncias" e a abertura do prefab no Scene Editor (decisão 18).

Adiciona a ação 'Salvar como Prefab' ao menu de contexto de nó já existente (`SceneTreeNode.tsx`, AIS-16), serializando a sub-árvore selecionada em `res://prefabs/<nome>.prefab.json` com o mesmo serializador do AIS-29.

---

## 3. Especificação

```text
Implemente o sistema de Prefabs:
- 'Salvar como Prefab': serializa a sub-árvore do nó selecionado (reaproveitando `sceneSerializer.ts`, AIS-29) em `res://prefabs/`.
- Arrastar um `.prefab.json` do `FileSystemPanel` para o Viewport3D (reaproveitando o drag-and-drop do AIS-31) instancia uma cópia da sub-árvore na cena, marcada internamente com uma referência ao prefab de origem.
- 'Atualizar instâncias' (a partir do prefab): opcional nesta v1; sua ausência não bloqueia o aceite mínimo e não exige pergunta adicional.
```

---

### 3.1 Emenda canônica — dependências portáveis

Prefab transporta somente dados autorais e recursos do projeto (assets e scripts de `res://scripts/`). Behaviors/Actions referenciados são IDs de pastas de `src/logic/`; um ID desconhecido pelo editor de destino é preservado como não resolvido e gera diagnóstico. Não existe dependência de addon/plugin (v4.7.0). Conflitos não sobrescrevem silenciosamente. O contrato completo fica no AIS-81b.

## 4. Diretrizes técnicas

1. **Reuso do Serializador:** Prefab é uma cena parcial — usa exatamente o mesmo formato/versão do `sceneSerializer.ts` (AIS-29), não um formato próprio.
2. **Comandos com Undo/Redo:** Instanciar um prefab passa pelo `CommandManager` (AIS-18), como qualquer outra adição de nó à árvore (AIS-20).

Se houver qualquer incompatibilidade ou dúvida arquitetural durante a execução, aplique **PARE E PERGUNTE** (ver `CLAUDE.md`): pare, descreva o problema com opções A/B/C e recomendação técnica, e aguarde a resposta do usuário antes de continuar.

---



## Nivelamento transversal — AIS-81

Prefabs usam ResourceRef e DependencyGraph (AIS-03b/AIS-29c).

> **Testes (v5.0.0):** onde este prompt pedir "teste obrigatório", "teste automatizado" ou checklist reproduzível, entregue a lógica como funções puras **com testes Vitest** (`*.test.ts`, executados por `npm test` / `npm run check`) e verifique no navegador o que for visual (regra 12 do `CLAUDE.md`).

## 5. Critérios de aceite (verificáveis por `npm run check` e no navegador)

- [ ] **AIS-81-C01** Instanciar o mesmo prefab duas vezes gera duas sub-árvores independentes e desfazíveis (`Ctrl+Z`).
- [ ] **AIS-81-C02** `npm run check` passa e o editor (`npm run dev`) carrega no navegador e permanece **sem erros no console** (zero erros vermelhos) durante toda a interação com a funcionalidade.
- [ ] **AIS-81-C03** O comportamento descrito na Especificação é **visível e operável no navegador** (`npm run dev`), exercitado manualmente do início ao fim.
- [ ] **AIS-81-C04** Nenhuma funcionalidade pré-existente da casca regrediu (TopBar, SceneTree, FileSystem, Viewport 3D, Inspector, BottomPanel e modais).
- [ ] **AIS-81-C05** Log `docs/logs/AIS-81.md` gravado ao concluir (formato no `CLAUDE.md`), com arquivos, decisões, resultado de cada critério e pendências.

## 6. Contexto de domínio (skills embutidas)

Conhecimento de domínio a seguir; onde a especificação citar uma skill, a regra dela está aqui.

### SKILL: nodimus-prefabs

> Prefabs do Nodimus 3D Studio: formato autoral canônico `res://prefabs/<nome>.prefab.json`, com referência de origem nas instâncias. Exportação/importação autocontida pode existir como recurso adicional, sem substituir o prefab de projeto. Use ao salvar, editar, instanciar ou compartilhar uma subárvore de cena.

# Prefabs — contrato v4.6 de projeto

> **Dono de:** formato de arquivo, biblioteca global, fluxo save/instantiate/export/import. **Depende de:**
> `nodimus-scenegraph-modelo`, `nodimus-logic-pastas`, `nodimus-materiais-pbr`, `nodimus-importador-assets`,
> `nodimus-sandbox-seguranca` (confirmação de script). Na v4.6, o formato autoral oficial é **por projeto** em `res://prefabs/`. Uma biblioteca global/exportável pode ser adicionada como conveniência, mas nunca substitui nem contradiz o arquivo `.prefab.json` do projeto.

## Formato

`.zip` (via `fflate`) com: `prefab.json` (subárvore, tags, behaviors resolvidos, refs relativas), `mesh.glb`,
`textures/*`, `scripts/*` (somente scripts realmente referenciados), `thumbnail.png` (gerado do
viewport no save), `prefab.txt` opcional (copyright/descrição).

## Biblioteca global

Uma coleção do editor (não do projeto aberto); a aba `Objects & Prefabs` da Resource Tree é uma **janela**
sobre ela, agrupada por "diretório"/coleção de origem quando houver mais de uma fonte registrada.

## Salvar como Prefab

Seleciona GameNode(s) → "Save as Prefab" → serializa a subárvore em `res://prefabs/<nome>.prefab.json`. Thumbnail/export package são opcionais e derivados; o arquivo autoral permanece no projeto.

## Instanciar — cópia, sem link vivo

Drag da aba/duplo clique **descompacta uma cópia** no projeto atual: `mesh.glb`/`textures/*` gravados
**namespaced** em `models/`/`materials/`/`textures/` (mesmo cuidado de não-colisão do import), subárvore vira
GameNode(s) via CommandManager. Editar a GameNode depois **não** altera o Prefab da biblioteca.
Scripts referenciados passam pela confirmação de §Importar antes da cópia.

## Exportar/Importar (entre bibliotecas)

Export gera o `.zip` autocontido a partir de um item já salvo. Import (de `.zip` externo): detecta
`scripts/*` novos → **confirmação explícita** listando os arquivos de código (`nodimus-sandbox-seguranca`);
IDs de lógica desconhecidos pelo editor são listados como não resolvidos (preservados) → depois copia o `.zip`
para a biblioteca de prefabs. Instanciar no projeto continua sendo o passo separado acima.

## Definição de "pronto"

- Salvar como Prefab e instanciar em outro projeto reproduz a subárvore com thumbnail correto.
- Prefab com script pede confirmação antes de copiar o código.
- Editar a instância copiada não altera o prefab original na biblioteca.

---

### SKILL: nodimus-scenegraph-modelo

> Modelo de dados do Nodimus 3D Studio, **no vocabulário da casca**: `SceneData` → árvore de `GameNode` (`SceneData.nodes: Record<string, GameNode>`, raiz em `rootNodeId`). Ferramentas Select/Move/Rotate/Scale (TransformControls vanilla), Inspector genérico por schema (`PropertyDescriptor`, vect3d com cor por eixo, seção Behaviors em cards por categoria), propriedades do root da cena e o Scene Graph como gerenciador dos recursos em cena e em disco (import cria o nó direto; exclusão). Use ao mexer em hierarquia, Inspector ou em qualquer coisa que crie/remova nós.

# Scene Graph — SceneData, GameNode, Inspector

> **Regra de nomenclatura (decisão B1):** a casca manda. Vocabulário canônico: `SceneData`, `GameNode`, `NodeType`, `NodeTypeMetadata`, `PropertyDescriptor`, `CommandManager`. Não existem `Layer` nem `Instance` como tipos: pasta/agrupamento é um nó `Spatial` (ou tipo de agrupamento existente em `registry.ts`); UI é um nó `Overlay2D` (com `TextOverlay2D`/`ButtonOverlay2D`); `NodeTypeMetadata` já traz `is2D`/`is3D`/`isUI`. Tipo ausente em `src/nodes/registry.ts` → **CRIAR** lá, nunca criar tipo paralelo.

## 1. Hierarquia

`SceneData` → `rootNodeId` → `GameNode` com `parentId`/`childrenIds`. Nós de agrupamento (`Spatial`) servem de pasta e de visibilidade em cascata; **nó de agrupamento não define pose própria além do seu transform local** e a pose mundial é a composição da cadeia de pais.

## 2. GameNode

Campos existentes na casca: `{ id, name, type: NodeType, parentId, childrenIds, visible, locked, collapsed?, properties: Record<string, any>, script?, behaviors?: string[], signals? }`.
- Transform, materiais, tags e variáveis vivem em `properties` (chaves definidas pelo `PropertyDescriptor` do tipo); campos novos entram como propriedade do tipo, sem alterar o formato do `GameNode` sem PARE E PERGUNTE.
- `transform` é **local** ao pai; a pose mundial é a composição da cadeia de pais.
- Tags: propriedade livre; consulta por tag **não existe** na EngineApi 1.4 (`getNodesByTag` nunca foi implementado; `tags` só aparece em `NodeSnapshot`). Este prompt acrescenta `nodes.byTag(tag): NodeHandle[]` à EngineApi **1.5** (`since: '1.5'`, `sync`, segura em Play/Publish, `marshalable`), entrada em `ENGINE_OPERATIONS`, teste em `engineApi*.test.ts` e atualização da decisão 32 e de `src/logic/README.md` — uma tag por chamada, só nós vivos da sessão.
- `type` é sempre um `NodeType` da casca (`Spatial`, `MeshInstance`, `Camera`, `OmniLight`, `Billboard`, `Overlay2D`, `AudioPlayer3D`…); leia as chaves de `NODE_DEFINITIONS` em `src/nodes/registry.ts` (de onde `NodeType` é derivado) antes de tipar. Conceitos sem tipo correspondente (ex.: `AnimationPlayer`) são **CRIAR**.

**Modelo → View:** o Model são dados puros (`SceneData`/`GameNode`) no estado do editor. O módulo de sincronização monta a árvore real de `Object3D` com `parent.add(child)`. Nenhuma referência a `Object3D` entra no estado; nenhum import de `three` entra no estado.

## 3. Ferramentas de transformação

`Q` Select · `W` Move · `E` Rotate · `R` Scale · `F1–F4` Persp/Top/Front/Left. Gizmo = `TransformControls` vanilla (`dragging-changed` desliga o orbit; `objectChange` alimenta o Command). Snaps → `nodimus-multiselecao-snap`.

## 4. Property Inspector — motor de formulário genérico

Uma só máquina, dirigida por `PropertyDescriptor`, renderiza: Attributes (Name/Tags/Position/Rotation/Scale/Visible, + Variables), Materials, Behaviors, e as propriedades de Behavior/Action declaradas nas pastas de `src/logic/` (`LogicRegistry`, skill `nodimus-logic-pastas`).
- **Campos condicionais:** `visibleWhen(get) => boolean` por campo. Sem isso, os 15+ campos de todos os modos aparecem juntos.
- **`vect3d` sempre com cor por eixo** — X vermelho, Y verde, Z azul, igual ao gizmo. Vale para *qualquer* campo X/Y/Z.
- Campo numérico usa rascunho textual e só grava em `blur`/Enter com valor finito; aceita vírgula decimal (pt-BR); entrada inválida permanece com erro acessível, sem exceção.
- **Selecionar a cena (nó raiz)** mostra: `AmbientLight, BackgroundColor, Fog+FogColor, Gravity, Wind, RealtimeShadows`. O grupo `PostEffects` é dado da mesma `SceneData` (`postProcessing`, `fog`), editado no diálogo de pós-processamento existente. Implementação via `EffectComposer` + passes de `three/addons/postprocessing/` (não `@react-three/postprocessing`).

### 4.1 Seção Behaviors — cards colapsáveis por categoria

> **Quem implementa:** os cards de Behavior no Inspector são entregues pelo **AIS-39** (editor de lógica visual; parâmetros de Action no AIS-42). Até lá, o `InspectorPanel` mantém o **resumo de behaviors** (nome + estado, abrindo o Visual Logic). Prompts anteriores ao AIS-39 só **consomem** este contrato e não criam os cards; esta seção descreve o alvo, não uma tarefa do prompt em execução.

Cada Behavior anexado é um **card**: cabeçalho (ícone do registro, nome, chip da categoria, chevron), borda esquerda de 4px na cor da categoria (`--gl-cat-*`; `Custom` = tracejada), corpo = **o mesmo** property-grid genérico. Propriedade `action` vira botão-badge com contagem (`3 actions →`) que abre o Visual Logic. Card colapsado mostra subtítulo agregado. Colapso é **estado efêmero de UI**: não é Command, não persiste, reseta a cada seleção. Sem canvas de nós nem conexões arrastáveis.

## 5. Seleção

Múltipla e estendida → `nodimus-multiselecao-snap`. Undo/Redo → `CommandManager`.

## 6. O Scene Graph é o gerenciador de recursos do projeto

Importar/criar primitiva coloca o nó direto na cena.
- **Import** grava o arquivo original (`.glb`, `.gltf`, `.obj`, `.fbx`, `.dae`, **sem conversão**) em `res://models/` pelo `AssetPipeline` **e já cria o `GameNode`** (`MeshInstance` com `model: ResourceRef`) sob o nó ativo, no mesmo passo (um `MacroCommand`; Undo remove o nó, não o arquivo). Nunca um arquivo "esperando" (AIS-33a/33, decisão 27).
- **Reuso de malha** = duplicar o nó (`Ctrl+D`); a cópia compartilha a referência (`model`) ao mesmo arquivo de `res://models/`.
- A Resource Tree tem só `Objects & Prefabs · Materials · Images · Sounds · Videos · Fonts`.

## 7. Exclusão de nó

É um Command (`deleteNodeCommand`), acionado por `Delete`/`Backspace` (Scene Tree focada, seleção não vazia e foco fora de `input`/`textarea`) e pelo item "Delete" do ContextMenu — **uma só implementação**.
- Respeita a seleção múltipla como **um único Command** (um Undo restaura tudo).
- O nó raiz (`rootNodeId`) não é excluível.
- Excluir nó de mesh **não apaga** o arquivo de `res://models/`; apagar o arquivo passa por `deleteResource` (AIS-29e), que lista os nós que o usam (o `DependencyGraph`, AIS-29c, substitui a antiga "sem reference-counting").
- Recursos excluídos deixam referência órfã → cai no fallback padrão, sem erro.

## Definição de "pronto"

- Reparentar move o filho junto com o pai; mundo composto corretamente.
- Import produz `GameNode` na cena sem passo manual; duplicar reaproveita o arquivo.
- Excluir seleção múltipla + Ctrl+Z restaura todos os nós.

### SKILL: nodimus-versionamento-cena

> Versionamento e migração de schema do JSON de cena do Nodimus 3D Studio: campo schemaVersion no manifest e em cada arquivo de cena, cadeia de migrações puras e testáveis, e recusa de abrir um schema mais novo que o suportado. Use ao mudar o formato de dado salvo em disco (GameNode, Behavior, PhysicsConfig, etc.).

# Versionamento de cena

> **Dono de:** versionamento/migração do JSON de cena entre mudanças de schema. **Depende de:**
> `nodimus-projetos-workspace`, `nodimus-scenegraph-modelo`. Cobre a skill `editor3d-versionamento-cena` que o
> README de 02 lista, sem arquivo entregue.

## Regra

Todo `project.json` e todo `<nome>.nodimus-scene.json` carrega `schemaVersion: number`. **Qualquer** mudança
de shape de dado persistido (novo campo obrigatório em `GameNode`, renomear propriedade de Behavior, mudar
`PhysicsConfig`) incrementa a versão e ganha uma **função pura de migração** `migrateVN_to_VN+1(data) => data`.

## Cadeia de migração

Ao abrir um projeto: aplicar `migrate` em sequência da versão salva até a versão atual, uma função por vez
(nunca pular direto). Cada migração é testada isoladamente (Vitest) com um fixture da versão anterior. Migrar
**nunca** perde dado silenciosamente — campo removido vira log explícito no console de import.

## Versão mais nova que o suportado

Abrir um projeto com `schemaVersion` maior que o que o editor conhece é **recusado explicitamente**
("este projeto foi salvo por uma versão mais nova do Nodimus"), nunca uma tentativa de leitura parcial.

## Onde migração NÃO se aplica

Tema/idioma (`localStorage`, fora do manifest — `nodimus-design-tokens-tema`/`nodimus-i18n`), estado efêmero
de UI. Prefabs (`nodimus-prefabs`) têm o próprio `prefab.json` e podem precisar da mesma disciplina se o
formato mudar — trate como cadeia separada.

## Definição de "pronto"

- Um fixture salvo na versão N-2 abre corretamente após duas migrações em sequência, com teste cobrindo cada passo.
- Um projeto de versão futura mostra erro claro, sem abrir pela metade.

---

### SKILL: nodimus-projetos-workspace

> Gerenciamento de projetos e workspace virtual res:// do Nodimus 3D Studio: esquema canônico de diretórios (res://scenes/, res://textures/, res://materials/, res://audio/, res://scripts/), ponte isomórfica tauriBridge.ts (Tauri v2 Desktop com fallback web), ProjectManagerModal, persistência atômica e exportação .nodimus.

# Projetos — Workspace Virtual `res://`, Persistência e Plataforma

> **Dono de:** Layout do projeto em disco, esquema virtual `res://`, serialização, Project Manager e persistência.  
> **Deliberações Canônicas:**  
> - **Item 2: Opção C:** Editor Estritamente Desktop (Tauri v2, zero Electron, integração com FS do SO).  
> - **Item 3: Opção A:** Pasta `res://textures/` como repositório de primeira classe para texturas extraídas.

---

## 1. Estrutura Canônica de Diretórios (`res://`)

Todos os recursos de um projeto são organizados sob o esquema virtual uniforme `res://`:

```text
res://
├── scenes/               # Cenas serializadas (.scene.json)
│   └── Main.scene
├── textures/             # Texturas extraídas e mapas PBR (.material.json, .png, .jpg)
├── materials/            # Definições de shaders e rigs (.rig.json)
├── audio/                # Áudios posicionais e efeitos (.wav, .mp3, .ogg)
└── scripts/              # Comportamentos e lógica de nós (.js, .ts)
```

---

## 2. Ponte de Plataforma (`tauriBridge.ts`)

O acesso ao sistema de arquivos é mediado de forma isomórfica pela camada `src/core/tauriBridge.ts`:
- **Modo Web (navegador, `npm run dev`):** Persistência automática em `localStorage` e download direto de arquivos `.nodimus` / blobs, operando com zero falhas de permissão no browser.
- **Zero Electron:** É proibido qualquer uso de `ipcRenderer` ou chamadas legadas de Electron.

---

## 3. Gerenciador de Projetos (`ProjectManagerModal.tsx`)

Inspirado no Project Manager do Godot:
- **Projetos Recentes:** Lista de projetos locais com thumbnail, nome, caminho no disco e data de modificação.
- **Novo Projeto:** Cria a estrutura de diretórios canônica `res://` com uma cena inicial padrão (`Main.scene`).
- **Abrir Projeto:** Abre pasta existente via seletor nativo do sistema operacional.
- **Templates de Início Rápido:** FPS Starter, Third-Person Platformer, Top-Down RPG.

---

## 4. Persistência e Salvamento Atômico

- **Atalho `Ctrl/Cmd + S`:** Serializa a cena ativa e grava o estado completo em `projectStorage.ts`.
- **Integridade JSON:** Validação estrita na leitura e escrita; falha de escrita emite alerta no console inferior (`BottomPanel`) sem sobrescrever arquivos corrompidos.
- **Exportação:** Suporte a empacotar o projeto completo em arquivo `.nodimus` (ou zip) para backup e transporte.

## Nivelamento definitivo — Prefab como documento composto

Prefab deve usar IDs/ResourceRefs e o `DependencyGraph` canônico. Não há dependência de addon/plugin. Importação/instanciação resolve script/asset ausente, ID de lógica desconhecido e conflito de conteúdo sem sobrescrita silenciosa.

## SPECs relacionadas

- [scene.spec.md](../specs/dominios/scene.spec.md)
- [registry.spec.md](../specs/dominios/registry.spec.md)


## EMENDA CANÔNICA v4.6 — edição de Prefab no Scene Editor
Duplo clique em `res://prefabs/*.prefab.json` deve abrir **o mesmo Scene Editor** usado por cenas, em `documentKind: prefab` (ou equivalente no `DocumentManager`). O conteúdo do prefab é mostrado como uma pequena cena isolada/editável; SceneTree, Inspector, gizmos, Visual Logic e demais ferramentas compatíveis são reutilizados. `Ctrl/Cmd+S` serializa de volta no próprio `.prefab.json`.

Não criar `PrefabEditor` paralelo. O roteamento deve passar por `resolveFileAction`. Fechar/reabrir preserva o documento; alterações autorais usam CommandManager/Undo. Instâncias em cenas mantêm referência persistente à origem. Atualização automática/propagação para instâncias continua opcional na v1, mas editar e salvar o **asset prefab** é obrigatório.

**Aceite v4.6:** duplo clique → editar filho/propriedade → salvar → fechar → reabrir deve reproduzir a alteração no prefab; nenhuma Scene aberta deve ser sobrescrita.


---

## Emenda v5.1 — CRUD (Plano lacunas de CRUD)

### Excluir prefab, desvincular instância e "Abrir prefab"

**Contexto:** A especificação original cobre criar prefabs e instâncias. Esta emenda formaliza a exclusão de um prefab com instâncias ativas, a desvinculação de instâncias e o "Abrir prefab" (modo Prefab Editor conforme decisão 18).

**Excluir prefab:**
- "Excluir" no menu de contexto do arquivo `.prefab.json` no `FileSystemPanel` passa pelo fluxo do AIS-29e.
- O `DependencyGraph` lista todas as instâncias do prefab na cena/projeto.
- Diálogo de confirmação oferece:
  - **Cancelar** — nenhuma operação.
  - **Excluir e converter instâncias em cópias soltas** — cada instância vira um `GameNode` independente, preservando todos os dados; sem referência ao prefab.
  - **Excluir mantendo referência *unresolved*** — instâncias preservadas com `prefabRef.status: 'unresolved'`; indicador visual na SceneTree.
- Confirmar grava o arquivo de cada cena afetada atomicamente.

**Desvincular instância:**
- "Desvincular instância" no menu de contexto de uma instância de prefab na SceneTree.
- Converte a instância em `GameNode` independente (cópia dos dados do prefab no momento da desvinculação).
- `Command` `unlinkPrefabInstance(nodeId)` — Undo reverte para instância vinculada.

**Abrir prefab:**
- "Abrir prefab" no menu de contexto do arquivo `.prefab.json` ou de uma instância abre o Scene Editor em **modo Prefab** (decisão 18): mesmo editor, contexto de documento diferente.
- `Ctrl/Cmd+S` salva no próprio prefab.
- Fechar o modo Prefab com alterações pendentes dispara confirmação do `DocumentManager`.

**Critérios novos:**
- [ ] **AIS-81-C05** Excluir prefab com instâncias exibe diálogo com lista de instâncias e as opções: cancelar, converter em cópias soltas, manter como *unresolved*.
- [ ] **AIS-81-C06** "Converter em cópias soltas" preserva todos os dados das instâncias; nenhum dado é perdido.
- [ ] **AIS-81-C07** "Desvincular instância" é Command; Undo restaura o vínculo com o prefab.
- [ ] **AIS-81-C08** "Abrir prefab" abre o Scene Editor em modo Prefab; `Ctrl/Cmd+S` salva no prefab; fechar com alterações pendentes dispara confirmação do `DocumentManager`.
