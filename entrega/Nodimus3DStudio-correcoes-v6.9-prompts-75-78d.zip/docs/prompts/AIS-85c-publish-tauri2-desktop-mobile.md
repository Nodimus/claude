# AIS-85c — Publish do Jogo com Tauri 2 (Desktop e Mobile)

> **Origem:** decisão arquitetural v4.6 · **Destino:** Claude Code (Claude Desktop)
> **Posição canônica:** Fase H — Plataforma e produto · nº 134 de 135 · anterior: AIS-85b · próximo: AIS-AP

## 0. Preâmbulo fixo
Identidade, hierarquia da verdade, decisões canônicas (as numeradas no `CLAUDE.md`, até a 32), contratos arquiteturais transversais e regras de execução estão no **`CLAUDE.md`** (`CLAUDE.md`).

## 1. Objetivo
Implementar o empacotamento físico do **jogo publicado** para Desktop e Mobile usando **Tauri 2**, sem confundir esse host com o Tauri do editor (AIS-AP). Web continua sendo publicação web. Todos os targets reutilizam o mesmo runtime usado por `RuntimeSession`/Play; é proibido criar um segundo motor.

## 2. Fronteira obrigatória
- **Editor Tauri App:** AIS-AP; contém IDE, painéis e ferramentas autorais.
- **Game Tauri App:** este prompt; contém somente bootstrap do jogo, runtime compartilhado e bundle alcançável produzido/validado pelo AIS-85b.
- Nunca copiar React/Tailwind da IDE, código editor-only, CommandManager, stores autorais ou APIs internas de edição para o Game App.
- Executores de `src/logic/` e scripts entram somente se alcançáveis e compatíveis.

## 3. Targets
### Web
Não alterar o pipeline definido pelo AIS-85/AIS-85b.

### Desktop — Tauri 2
Gerar projeto/artefato host Tauri 2 para Windows/macOS/Linux conforme suporte efetivamente disponível no ambiente de build. Configurar app identifier, nome, versão, ícones, janela inicial, fullscreen/resizable e permissões mínimas. O frontend carrega o bootstrap/runtime publicado e a Scene inicial.

### Mobile — Tauri 2
Gerar host Tauri 2 Mobile para Android/iOS conforme toolchains disponíveis. Tratar orientação, safe area, lifecycle pause/resume, touch/pointer e fullscreen quando aplicável. Não fingir suporte quando SDK/toolchain/assinatura não estiver disponível: produzir diagnóstico acionável.

## 4. Game Settings
Consumir as abas já definidas `General`, `Web`, `Desktop`, `Mobile`, `Variables`. Acrescentar/ligar campos necessários ao host, sem criar modal concorrente:
- General: name, version, initialScene, identifier base, icons.
- Desktop: window mode/size, resizable, target platforms e opções Tauri permitidas.
- Mobile: orientation, target Android/iOS, package/bundle id derivado/validado e opções de tela.

## 5. Capabilities e segurança
Consultar `CapabilityRegistry` antes do build, pelas funções existentes de `src/core/capabilities.ts` (`resolveSupport`, `unsupportedFor`, `TARGET_PROFILES`; AIS-78c) sobre o grafo do AIS-85b — não reimplementar a resolução. `runtimeDesktop` e `runtimeMobile` são independentes. `requiresDOM`, filesystem, network, gamepad, pointer/fullscreen e demais requisitos recebem suporte/fallback por target. Aplicar allowlist/permissões Tauri mínimas; nenhuma capability é concedida implicitamente só porque o host é Tauri.

## 6. Pipeline
1. Validar Game Settings e Scene inicial.
2. Solicitar ao AIS-85b o grafo alcançável + matriz de compatibilidade do target.
3. Falhar cedo em `not-supported` necessário; mostrar `partial` antes de continuar.
4. Produzir bundle runtime/assets pré-compilado.
5. Gerar/configurar host Tauri 2 do jogo em área de build derivada, nunca dentro dos assets autorais.
6. Executar build quando toolchain estiver disponível; caso contrário, deixar configuração reproduzível + diagnóstico do requisito ausente.
7. Registrar resultado no Debugger/Build output e no log do prompt.

## 7. Critérios de aceite
- [ ] **AIS-85c-C01** Desktop e Mobile usam Tauri 2, mas nenhum deles reutiliza o app Tauri da IDE.
- [ ] **AIS-85c-C02** O jogo publicado inicializa o mesmo runtime/Scene semantics do Play.
- [ ] **AIS-85c-C03** Código editor-only, UI da IDE e estado autoral não entram no bundle.
- [ ] **AIS-85c-C04** `runtimeDesktop` e `runtimeMobile` produzem diagnósticos independentes.
- [ ] **AIS-85c-C05** Build sem toolchain/SDK não é reportado como sucesso; mostra requisito ausente.
- [ ] **AIS-85c-C06** Permissões Tauri são mínimas e derivadas das capabilities alcançáveis.
- [ ] **AIS-85c-C07** Web permanece funcional e não passa pelo host Tauri.
- [ ] **AIS-85c-C08** Log `docs/logs/AIS-85c.md` gravado ao concluir.

## 8. Regra de não duplicação
AIS-85b decide **o que entra** e se é compatível; AIS-85c decide **como o bundle Desktop/Mobile é hospedado/empacotado**. AIS-AP empacota **o editor**. Não fundir essas responsabilidades.

## Emenda v5.7 — Configurações do Projeto na janela do jogo

O host Tauri 2 do jogo (Desktop e Mobile) lê, de `project.settings`: `display.windowMode` (windowed / fullscreen / borderless), `display.width` × `height` (tamanho inicial), `resizable`, `orientation` (Mobile) e `rendering.vsync`; `general.version`, `author` e `description` entram nos metadados do pacote. Só `windowMode` é lido para o modo de janela (`fullscreen` legado é espelho). Ao entregar, retirar o "desabilitado / em breve — AIS-85c" desses campos no `ProjectSettingsModal` e registrar no log. Tabela de donos: `ORDEM-CANONICA-V4.md`.
