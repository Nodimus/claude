# AIS-85 — Paridade de APIs de Plataforma Web no Runtime Exportado

> **Origem:** Prompt 85 · **Módulo 15:** Infraestrutura do Editor e do Produto · **Destino:** Claude Code (Claude Desktop) · **Skills embutidas:** `nodimus-web-features`, `nodimus-publicacao-web`, `nodimus-input-manager`

> **Posição canônica:** Fase H — Plataforma e produto · nº 132 de 135 · anterior: AIS-84 · próximo: AIS-85b
> **Relaciona-se com:** AIS-AP (somente na fase final; não é dependência deste prompt), AIS-47, AIS-58
> **Decisão Canônica Relacionada:** Extensão de Escopo (Módulo 13) — o **editor** é estritamente Desktop (Item 2: Opção C), mas o **jogo publicado/exportado** com o Nodimus 3D Studio continua sendo uma cena Three.js e pode rodar em navegador; este prompt é sobre o runtime do jogo exportado, não sobre o editor.

---

## 0. Preâmbulo fixo

Identidade, hierarquia da verdade, decisões canônicas (as numeradas no `CLAUDE.md`, até a 32), contratos arquiteturais transversais e regras de execução (1–14) estão no **`CLAUDE.md`** da raiz do repositório (carregado automaticamente pelo Claude Code) e valem para este prompt. Não são repetidos aqui.

---

## 1. Estado real da casca

| Item | Status | Ação |
|---|---|---|
| `src/core/webRuntimeFeatures.ts` | **CRIAR** | criar antes de usar |
| LogicRegistry → `src/logic/registry.ts` | **EXISTE** (AIS-05r) | requisitos declarados por pasta |
| tauriBridge → `src/core/tauriBridge.ts` (139 linhas) | **EXISTE** | estender, sem recriar |

> ⚠ Onde o texto abaixo disser que os itens marcados **CRIAR** "já existem", "já estão implementados" ou "já presentes na casca", isso vale apenas para o projeto de origem. **Na casca eles não existem: crie-os.**

## 2. Contexto e integração

Não altera a UI do editor. Estende `tauriBridge.ts` (ou um novo `src/core/webRuntimeFeatures.ts` **(CRIAR — não existe na casca)** no mesmo padrão de classe estática isomórfica) com detecção de capacidades do navegador-alvo para o build exportado do jogo (não do editor).

---

## 3. Especificação

```text
Implemente a camada de paridade de features web para o runtime do jogo exportado (não confundir com o editor, que permanece Desktop-only):
- Detecção de suporte a Pointer Lock API (mira em primeira pessoa, usada pelo controlador do AIS-47/AIS-73), Fullscreen API, e Gamepad API (mapeável no Input Manager, AIS-58).
- Fallbacks graciosos e visíveis ao jogador quando uma API não está disponível no navegador-alvo (ex.: sem Gamepad API → esconder prompt de 'conecte um controle').
- Documentação de matriz de suporte por navegador/engine (Chromium, Firefox, WebKit/Safari), já que o alvo de publicação web roda fora do controle do Tauri.
```

---

### 3.1 Emenda evolutiva — capacidade por alvo

A paridade deve ser consultável por Action/Behavior (pasta em `src/logic/`) e não apenas global. Cada item declara requisitos/capacidades relevantes ao target. Código editor-only nunca entra no runtime publicado. O empacotamento e a análise de alcançabilidade são fechados no AIS-85b.

## 4. Diretrizes técnicas

1. **Não é sobre o editor:** Deixe explícito no cabeçalho do código e nos comentários que isso é exclusivamente sobre o jogo publicado (`nodimus-publicacao-web`), para não reabrir a decisão do Item 2 (editor estritamente Desktop).
2. **Reuso do padrão isomórfico:** Siga a mesma estrutura de detecção-com-fallback já estabelecida pelo `tauriBridge.ts` (`TauriBridge` já existente na casca web; o binding nativo do Apêndice Tauri só ocorre ao final).

Se houver qualquer incompatibilidade ou dúvida arquitetural durante a execução, aplique **PARE E PERGUNTE** (ver `CLAUDE.md`): pare, descreva o problema com opções A/B/C e recomendação técnica, e aguarde a resposta do usuário antes de continuar.

---



## Nivelamento transversal — AIS-85

Este prompt não depende nem referencia implementação do Apêndice Tauri. Capacidades do runtime publicado são abstratas/portáveis e o binding nativo só ocorre no AIS-AP final.

## 5. Critérios de aceite (verificáveis por `npm run check` e no navegador)

- [ ] **AIS-85-C01** Um jogo exportado sem Gamepad API disponível não trava nem mostra erro — apenas oculta a UI de controle correspondente.
- [ ] **AIS-85-C02** `npm run check` passa e o editor (`npm run dev`) carrega no navegador e permanece **sem erros no console** (zero erros vermelhos) durante toda a interação com a funcionalidade.
- [ ] **AIS-85-C03** O comportamento descrito na Especificação é **visível e operável no navegador** (`npm run dev`), exercitado manualmente do início ao fim.
- [ ] **AIS-85-C04** Nenhuma funcionalidade pré-existente da casca regrediu (TopBar, SceneTree, FileSystem, Viewport 3D, Inspector, BottomPanel e modais).
- [ ] **AIS-85-C05** Log `docs/logs/AIS-85.md` gravado ao concluir (formato no `CLAUDE.md`), com arquivos, decisões, resultado de cada critério e pendências.

## 6. Contexto de domínio (skills embutidas)

Conhecimento de domínio a seguir; onde a especificação citar uma skill, a regra dela está aqui.

### SKILL: nodimus-web-features

> Actions específicas do runtime Web publicado no Nodimus 3D Studio: Fullscreen (requestFullscreen), Pointer Lock (requestPointerLock), Local Storage (Load/Store Variable persistente) e Get URL Parameter, todas tratando a rejeição da Promise explicitamente. Use ao implementar essas Actions ou investigar por que uma delas 'não faz nada'.

# Web Features (Actions do runtime publicado)

> **Dono de:** Actions Fullscreen/Pointer Lock/Local Storage/URL params. **Depende de:**
> `nodimus-publicacao-web` (só fazem sentido no bundle publicado, rodando em navegador de verdade — não no
> editor). Corrige achado da Auditoria 3: rejeição de promise sendo engolida.

## Actions

- **Fullscreen:** `document.documentElement.requestFullscreen()`. Precisa de **gesto do usuário** (clique/tecla)
  no mesmo call stack — chamar de dentro de um `setTimeout`/callback assíncrono falha silenciosamente se não
  tratado.
- **Pointer Lock:** `element.requestPointerLock()`; use com câmeras FPS (`nodimus-controle-camera-colisao`)
  para travar o cursor. Escute `pointerlockchange`/`pointerlockerror` para saber o estado real.
- **Read/Write Local Storage:** complementa "Load or Store a Variable" (`nodimus-variaveis` §Actions) como
  persistência do bundle publicado. Namespaced por `appId` do Game Settings para não colidir entre jogos no
  mesmo domínio.
- **Get URL Parameter:** lê a query string da página hospedeira (`new URLSearchParams(location.search)`),
  ex. `?level=2`.

## Regra obrigatória: nunca engolir rejeição

`requestFullscreen()`/`requestPointerLock()` retornam Promise que pode rejeitar (sem gesto do usuário,
permissão negada, iframe sem `allow`). **Sempre** `.catch(...)` e alimentar o console/Action de erro do
projeto — nunca deixar a Action parecer que "não fez nada" sem explicação (achado real de auditoria).

## Fora de escopo

Qualquer Action que dependa de API exclusiva de navegador desktop sem fallback mobile-friendly.

## Definição de "pronto"

- Clicar Fullscreen sem permissão mostra erro tratado, não silêncio.
- `?level=2` chega correto na Action correspondente.

---

### SKILL: nodimus-publicacao-web

> Publish/deploy do Nodimus 3D Studio: pipeline BFS de assets alcançáveis, bundle Web autocontido como fonte única compartilhando o runtime do Play Mode (nunca reimplementado), modal Game Settings (General/Web/Desktop/Mobile/Variables), CSP restritiva sem unsafe-eval, saída fixa em out/<target>, e geração de FONTE (nunca build nativo) para Electron/Capacitor/Tauri. Use ao publicar o jogo ou configurar variáveis globais/ícone/app id.

# Publish/Deploy

> **Dono de:** pipeline de publish, os alvos, modal Game Settings (só o formulário — semântica de variável em
> `nodimus-variaveis`). **Depende de:** `nodimus-play-mode` (runtime compartilhado), `nodimus-scene-management`,
> `nodimus-sandbox-seguranca` (CSP), `nodimus-web-features`.

## 1. Runtime compartilhado (não-negociável)

`EDITOR → PROJETO → BUNDLER → RUNTIME`. O bundle publicado **executa Behaviors/Actions de verdade**,
reaproveitando o **mesmo** `src/runtime/*` do Play (`nodimus-play-mode` §1) — nunca um "player visual" que só
desenha malha/luz/câmera. Toda divergência editor×publish encontrada até hoje (sprite sem loop, âncora de
overlay) veio de reimplementar em vez de compartilhar módulo (`nodimus-auditorias-remediacao`).

### 1.1 Debug overlay (AIS-77)

O overlay de debug (F3) é **somente de Play** e não entra no bundle publicado: a sonda `DebugStats` plugada no `RendererCore` (`setProbe`/`hasProbe`) e o `RuntimeDebugOverlay` são código de editor (AIS-85b-C03). O runtime compartilhado mantém a ordem do quadro (cena → HUD → câmera ativa); a sonda mede o quadro inteiro e, desligada, custa um teste de `null` por quadro. Divergência editor×publish aqui é defeito.

## 2. Alvos

- **Web (padrão):** Bundle autocontido (HTML+JS+WebGL) para hospedagem estática.

## 3. Modal Game Settings (`Tools → Game Settings...`)

Abas: **General** (`App Name, Version, Icon, Default Publish Target, Splash Screen`) · **Web** (`Quality
Preset, Mobile-friendly, Orientation, Pixel Ratio Cap, Fullscreen-on-touch`) · **Desktop**/**Mobile**
(ícone/orientação/App ID específicos) · **Variables** (formulário de `GlobalVariableDeclaration`; a
**semântica** é de `nodimus-variaveis`, este modal só é dono do formulário).

## 4. Pipeline

1. **Grafo** — BFS a partir da Scene inicial + Scenes declaradas explicitamente alcançáveis (troca por nome
   dinâmico não é detectável estaticamente — documente essa limitação, não finja resolver).
2. **Assets** — copia só o que o grafo alcançou, com cache por `lastModified` (evita recopiar sem necessidade).
3. **Bundle** — gera os dados do jogo (Scenes/GameNodes/Behaviors/Actions resolvidos) no formato do runtime.
4. **Build** — compila o runtime via Vite, modo produção.
5. **Pós-processamento por alvo** — Web: CSP restritiva no `index.html` (`default-src 'self'`, **sem
   `unsafe-eval`**, `object-src 'none'` — implica pré-compilar scripts de `Execute JavaScript`, ver
   `nodimus-sandbox-seguranca`). Desktop/Mobile: gera o scaffold do §2.

Saída sempre fixa em `<projeto>/out/<target>/` — nunca picker manual (evita um alvo sobrescrever o outro).

## 5. Sinalização de capacidade (matriz de publish)

**Atualização v6.9:** a fonte de verdade já existe — `CapabilityRegistry` (`src/core/capabilities.ts`, AIS-78c) com `resolveSupport` por target e `requires` nas pastas de `src/logic/`. Onde o texto abaixo diz `PUBLISH_CAPABILITY_MATRIX`, leia "o catálogo do `CapabilityRegistry`"; não crie uma tabela paralela. O restante vale como está.

Uma **única fonte de verdade** por capacidade (`PUBLISH_CAPABILITY_MATRIX`), consumida tanto pelo pipeline
quanto pelo comentário de cabeçalho que a documenta — **os dois devem concordar** (achado D-10: comentário
desatualizado contradizendo a própria tabela). Estado de física: se o bundle Web ainda não incluir simulação
Rapier no momento em que este projeto for implementado, o Publish deve sinalizar `not-supported` por modo
físico com a lista de GameNodes afetadas — **nunca** publicar silenciosamente sem simulação.

## 6. Deploy Web / Test

"Test as Web App" sobe um servidor local temporário e abre no navegador padrão — **nunca `file://` direto**
(bloqueio de CORS de esquema de arquivo para `fetch` de dados do jogo).

## 7. Fora de escopo

limite. Compressão DRACO/KTX2.

## Definição de "pronto"

- Publicar Web e abrir localmente roda Behaviors de verdade, não só visual.
- Um projeto com física mostra aviso explícito quando o alvo Web não simula.

---

### SKILL: nodimus-input-manager

> Abstração de input do Nodimus 3D Studio: dispositivo físico (teclado/mouse/gamepad/toque) → InputManager → ação lógica (ex.: MoveForward) consumida por Behaviors e câmeras; gamepad via navigator.getGamepads, toque via PointerEvent e preset 'Touch Screen Input' de UI. Use ao ler input em qualquer Behavior ou ao suportar gamepad/touch.

# Input Manager

> **Dono de:** abstração de input do `EngineApi`, independente de dispositivo. **Depende de:**
> `nodimus-logic-pastas` (Triggers de teclado/mouse em `src/logic/triggers/`), `nodimus-ui-widgets` (joystick virtual). Amplia o
> "Input Map" de `editor3d-tier1-fundamentos` (02) — o trigger `onInputAction` de lá é consumidor desta camada.

## Camadas

```
Input físico (tecla/mouse/gamepad/toque) → InputManager → Ação lógica ("MoveForward", "Jump", "Fire"…)
```
Behaviors (câmeras de jogo, `Object or Person controlled by keyboard`, controladores 2D, veículos) leem
**ações lógicas**, não códigos de tecla. Mantém compatibilidade com WASD/setas como mapa padrão.

## Dispositivos

- **Teclado/mouse:** eventos do canvas (durante edição a viewport usa o input para navegar a câmera; durante
  Play captura para o jogo — `nodimus-play-mode`).
- **Gamepad:** `navigator.getGamepads()` por polling a cada frame (sem lib); zona morta configurável nos eixos.
- **Toque:** `PointerEvent` + joystick virtual. O widget **é** o preset "Touch Screen Input" do modal de UI
  (`nodimus-ui-widgets`, um `Overlay` comum); este módulo só **consome** arrasto/toque e mapeia a ação lógica.

## Mapa de ações

`{ actionName: string[] }` no projeto (Game Settings/Project Settings). API: `Input.isActionPressed(name)`,
`isActionJustPressed(name)`, `getAxis(neg, pos)`. Trigger genérico `onInputAction { action, phase: pressed|released|held }`.

## Fora de escopo

Remapeamento pelo usuário final dentro do jogo publicado (só com demanda real).

## Definição de "pronto"

- Trocar a tecla de "Jump" no mapa muda todos os Behaviors sem editar nenhum.
- Um gamepad move o personagem com os mesmos Behaviors do teclado.

## Nivelamento definitivo — paridade por contrato, não por duplicação

As APIs de runtime/web/desktop devem preservar os mesmos contratos de domínio. Diferenças de plataforma ficam atrás de adapters/capabilities. Este prompt não deve antecipar Rust/Tauri nativo: a ligação real de plataforma permanece reservada ao AIS-AP.

## SPECs relacionadas

- [tauri-bridge.spec.md](../specs/dominios/tauri-bridge.spec.md)
- [logic-registry.spec.md](../specs/dominios/logic-registry.spec.md)

## Emenda v5.6 — Modelos 3D no Publish

O Publish empacota `res://models/**` referenciados e reutiliza o **mesmo** `loadModel`/`createModelObject` do editor e do Play (AIS-33a), em Web, Desktop e Mobile; sem segundo carregador.

## Emenda v5.7 — Configurações do Projeto: tela cheia na Web

O jogo publicado para Web lê `settings.display.windowMode` (`fullscreen` → Fullscreen API) e o tamanho de `display.width/height`. A Fullscreen API **exige gesto do usuário**: entrar em tela cheia só após um clique/tecla, nunca no carregamento; falha de permissão não é erro fatal. Só `windowMode` é lido (o `fullscreen` legado é espelho). Tabela de donos: `ORDEM-CANONICA-V4.md`.
