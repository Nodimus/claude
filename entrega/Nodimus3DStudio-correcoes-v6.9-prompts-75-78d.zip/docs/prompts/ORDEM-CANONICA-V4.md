# Ordem Canônica Nodimus v5.6

> **Revisão:** v6.9 — alinhamento dos prompts 79–85c à EngineApi 1.4 e ao CapabilityRegistry (sem mudar posições; total 135); AIS-77 reaberto (C06–C08 pendentes). v6.8 — **AIS-78d** (nº 124, IA como serviço da EngineApi 1.4, fecha o último `extra` da decisão 32) inserido entre AIS-78c e AIS-79; posições ≥ 124 deslocadas em +1; total: **135 posições**. v6.4 — **AIS-72 antes do AIS-71** (o Game Actor consome `follow_a_path`; o AIS-72 não depende do 71). Novo **AIS-72b** (nº 114, nó `Waypoint`); AIS-71 passa ao nº 115; posições ≥ 114 deslocadas em +1; total: **133 posições**. v6.3 — **animação simples** (decisão 30): novo **AIS-60b** (nº 107) substitui **AIS-61** (Timeline) e **AIS-61c** (edição de clipes e keyframes), removidos da ordem (os logs ficam como histórico); total: **132 posições**. v6.1 — **AIS-30c** (nº 109, projeto em disco/workspace, decisão 29) inserido antes do AIS-61c; posições ≥ 109 deslocadas em +1; total: **133 posições**. v6.0 — Alinhamento de armas, projéteis e dano. Novos: **AIS-45b** (nº 101, queries físicas na `PhysicsBridge`) e **AIS-29g** (nº 102, spawn/despawn de prefab em runtime), ambos pré-requisitos do **AIS-69**; posicionados logo após o último prompt executado (AIS-59), pois suas dependências já existem; posições 101–105 deslocadas em +2. Também novos (v6.0, análise das pendências dos AIS-01 a 59): **AIS-44e** (nº 103, objetos criados em jogo passam a ser desenhados no Play) e **AIS-59b** (nº 104, fecha os defeitos abertos: `locked`, bloco de física inválido, gatilho × cinemático e Ctrl+D); posições ≥ 103 deslocadas em +2; total: **132 posições** (com o AIS-59c, nº 105: executores das Actions do catálogo); total: **129 posições** (antes do AIS-44e/59b). v5.9 — Câmera independente do movimento (decisão 28). Novos: **AIS-47b** (nº 79, rig de câmera no runtime), **AIS-47c** (nº 80, Behaviors de movimento × câmera) e **AIS-47d** (nº 81, estilos 3D restantes); posições ≥ 79 deslocadas em +3; total: **127 posições**. v5.7 — Consumidores das Configurações do Projeto. Renomeado: **AIS-38b → AIS-32c** (mesma posição, nº 55; o ID passa a combinar com a vizinhança 32/32b/32c/33a). Novo: **AIS-44d** (nº 75, Configurações do Projeto aplicadas ao Play); posições ≥ 75 deslocadas em +1; total: **124 posições**. Tabela "Dono de cada campo de `settings`" ao final deste documento; emendas v5.7 em AIS-45, 52, 55, 85 e 85c. v5.6 — — Realinhamento da ingestão 3D. **Lacuna corrigida:** nenhum prompt carregava modelo 3D real (o `AssetImportModal` só tratava exemplos e guardava o nome do arquivo). Novos: **AIS-33a** (nº 56, fundação de Modelo 3D, decisão 27) e **AIS-38c** (nº 63, reedição e integridade). **AIS-32c movido** do nº 61 para o nº 55 (o DiagnosticService passa a existir antes da cadeia 33–38c, eliminando o adapter provisório). AIS-33 a 38 reescritos sobre dados reais, com as 5 abas canônicas; 33 divide o modal em módulos. Posições ≥ 55 reorganizadas; total: **123 posições**. Próximo prompt pendente: **AIS-32c (nº 55)**. v5.5 — AIS-26b inserido na posição 40 (Colisão do objeto, decisão 26; plano `PLANO-FISICA-COLISAO-v2.md`); posições ≥ 40 deslocadas em +1; total: **121 posições**. v5.4 — AIS-25c inserido na posição 38 (Containers e controles de UI estilo Godot, separados do AIS-25b, que passa a cobrir o motor UIKit e o layout de Controls); posições ≥ 38 deslocadas em +1; total: **120 posições**. v5.3 — AIS-18d inserido na posição 29 (registry único de `NodeType` + Missing Node, decisão 19) e AIS-76b na posição 106 (Actions/Trigger de sprite); posições ≥ 29 deslocadas em +1 e ≥ 106 em +2; total: **119 posições**. v5.1.3 — AIS-18c inserido na posição 28 (partículas: nó único `ParticleSystem` + motor único; `ParticleEmitter` removido); posições ≥ 28 deslocadas em +1; total: **117 posições** (AIS-50b passa à posição 78). v5.1.2 — AIS-50b inserido na posição 77 (edição/escultura de terreno no Inspector e na viewport; AIS-50 fica só com geração); posições ≥ 77 deslocadas em +1; total: **116 posições**. v5.1.1 — árvores divididas em AIS-51, AIS-51a, AIS-51b, AIS-51c e AIS-51d (+4 posições; posições ≥ 78 deslocadas em +4; os "nº X de N" dentro dos prompts são históricos e não são autoridade — vale esta lista). v5.1.0 — Plano de lacunas de CRUD. Seis prompts novos inseridos (AIS-29e, AIS-29f, AIS-32b, AIS-40c, AIS-49b, AIS-61c) e emendas "Emenda v5.1 — CRUD" em 16 prompts existentes. Total: **115 posições** em v5.1.1 (111 em v5.1.0; era 105). Posições 1–12 inalteradas. Próximo prompt a executar: **AIS-06 (nº 13)**.

## Regra de dependências
- **DEPENDE DE**: precisa existir antes.
- **ESTENDE**: amplia contrato existente, sem substituí-lo.
- **INTEGRAÇÃO FUTURA**: ponto previsto, mas não é dependência atual.
- Nenhum prompt deve tratar integração futura como requisito já implementado.

## Fase 0 — Preparação
- AIS-P0 (`AIS-P0-preparatorio.md`) — preparação do ambiente no Claude Code; executar uma vez por máquina/clone (v5.0.0)

## Fase A — Constituição e fronteiras
1. AIS-01
2. AIS-02
3. **AIS-02b NOVO v4.1** — Zod Schema Foundation + schemaVersion/migrations
4. AIS-03
5. AIS-03b — Contratos de arquivos, `ResourceRef`, IDs persistentes e `schemaVersion` (o `CommandManager` é criado/evoluído no AIS-18)
6. **AIS-03c NOVO** — Authoring × Runtime contract
7. **AIS-03d NOVO v4.1** — Zustand EditorStore
8. **AIS-03e NOVO v4.1** — State Mutation Policy (gate; obrigatório antes da migração do EditorContext)
9. **AIS-03f NOVO v4.1** — Migração/fachada EditorContext
10. AIS-04
11. AIS-05
12. **AIS-05r NOVO v4.7.0** — Remoção do sistema de extensões/plugins e lógica nativa em pastas (`src/logic/`)

## Fase B — Viewport e edição espacial
> Numeração = ordem de execução (renumerada na padronização v4.1, pois a versão anterior repetia números). Os identificadores AIS continuam sendo a referência estável.

13. AIS-06
14. **AIS-06b NOVO** — Renderer Core independente do React
15. AIS-07
16. AIS-08 — Gizmo RGB
17. AIS-09
18. AIS-10
19. AIS-11
20. AIS-12
21. AIS-13
22. AIS-14
23. AIS-15 — ✅ executado; emenda v5.1.1: "Terrain" entra via registry (AIS-50; escultura em AIS-50b) e "Terrain Editor..." é mantido
24. AIS-16 — ✅ executado; "Salvar como Cena Filha" implementado como **Save Branch as Prefab** (`.prefab.json`, decisão 18); AIS-81 reutiliza
25. AIS-17

## Fase C — Autoridade editorial / Undo
26. AIS-18
27. AIS-18b
28. **AIS-18c NOVO v5.1.3** — Unificação do `ParticleSystem`, motor único de partículas (`src/core/particles/`) e `ParticleModal` como catálogo; `addNode(initialProperties)`
29. **AIS-18d NOVO v5.3** — Registry único de `NodeType` (`NODE_DEFINITIONS`) e Missing Node: tipo desconhecido lido de cena é preservado e regravado intacto (decisão 19)
30. AIS-19
31. AIS-20
32. AIS-21
33. AIS-22
34. AIS-23
35. AIS-24
36. AIS-25
37. AIS-25b
38. **AIS-25c NOVO v5.4** — Containers e controles de UI estilo Godot sobre UIKit (`Panel`, `HBox`, `VBox`, `Grid`, `MarginContainer`, `CenterContainer`, `ScrollContainer`, `Label`, `Button`, `CheckBox`, `Slider`, `ProgressBar`, `TextInput`); separado do AIS-25b
39. AIS-26
40. **AIS-26b NOVO v5.5** — Colisão do objeto (`properties.physics`: interruptor, tipo de corpo, forma auto, `resolveCollider`, "Mostrar colisores", legados convertidos ao abrir a cena); sem Rapier
41. AIS-27

## Fase D — Assets, persistência e projetos
42. AIS-28
43. AIS-28b
44. AIS-28c
45. AIS-29
46. AIS-29b
47. AIS-29c
48. **AIS-29d NOVO** — Runtime Scene/GameNodes
49. **AIS-29e NOVO v5.1** — Exclusão segura de recursos e integridade de referências
50. **AIS-29f NOVO v5.1** — Cenas do projeto: renomear, duplicar, excluir e cena inicial
51. AIS-30
52. AIS-31
53. AIS-32
54. **AIS-32b NOVO v5.1** — Configurações do Projeto (ProjectSettingsModal)
55. **AIS-32c — renomeado na v5.7** (era **AIS-38b**, movido na v5.6 do nº 61 para cá; o ID acompanha a posição) — DiagnosticService unificado, **antes** da cadeia de importação 3D, para que AIS-33 a 38c emitam diagnósticos direto no serviço final (sem adapter provisório)
56. **AIS-33a NOVO v5.6** — Fundação de Modelo 3D: `loadModel` (loaders do `three`), `res://models/`, `MeshInstance.model` (`ResourceRef`), cache e `createModelObject` únicos; desenha o modelo no Viewport/Play (decisão 27)
57. AIS-33 — **revisado v5.6:** `AssetImportModal` dividido em módulos, 5 abas canônicas, carga real do arquivo, Command único de importação, "Importar com colisão"
58. AIS-34 — **revisado v5.6:** aba Transform & Gizmo sobre o modelo real (calibração pura e testada, referência humana SketchUp)
59. AIS-35 — **revisado v5.6:** aba Texture & Material (materiais reais, manifesto `_material.json` com Zod, `materialSlots`)
60. AIS-36 — **revisado v5.6:** aba Skeleton & Retargeting (19 ossos, `RigConfig`, `skeletalAnimation.ts`)
61. AIS-37 — **revisado v5.6:** aba Animation Player (biblioteca de clipes por referência, player do modal)
62. AIS-38 — **revisado v5.6:** aba Quiz = scanner automático sobre dados reais, correções idempotentes
63. **AIS-38c NOVO v5.6** — Reedição da importação ("Editar importação…"), troca de modelo, reimport e exclusão em pacote

## Fase E — Visual Logic e gameplay mínimo
64. AIS-39
65. AIS-40
66. **AIS-40b NOVO** — InputManager Core
67. **AIS-40c NOVO v5.1** — Catálogo de Conditions
68. AIS-41
69. **AIS-41b NOVO** — Definition × BehaviorInstance
70. AIS-42
71. AIS-43
72. AIS-44
73. AIS-44b — RuntimeSession
74. **AIS-44c NOVO** — Play dentro da viewport
75. **AIS-44d NOVO v5.7** — Configurações do Projeto aplicadas ao Play (`resolveRenderSettings`: sombras, `shadowQuality`, `clearColor`, moldura `width×height`, `hdr`, `msaa`; campos sem leitor ficam desabilitados no modal)
76. AIS-45
77. AIS-46 — deve usar RuntimeSession; não criar runtime/modal concorrente
78. AIS-47 — **emenda v5.9:** composites 1P/3P viram legado; o contrato novo é a decisão 28
79. **AIS-47b NOVO v5.9** — Rig de câmera de jogo no runtime (`src/runtime/cameraRig/`, `viewBasis`), extração sem mudança visível
80. **AIS-47c NOVO v5.9** — Movimento e câmera separados: Behaviors de ator (`first_person_movement`, `third_person_movement`) × Behaviors de câmera (`camera_first_person`, `camera_third_person`), diálogo "Create a new Camera", comando "Separar câmera…"
81. **AIS-47d NOVO v5.9** — Estilos de câmera 3D restantes (Free Flying, Model Viewer, Panorama, RTS)
82. AIS-48
83. AIS-48b
84. AIS-49
85. **AIS-49b NOVO v5.1** — Geradores reeditáveis (`generatorSource`)

## Fase F — Sistemas de mundo/runtime
86. AIS-50 — **⚠️ revisado v5.1 (v5.1.2: só geração; escultura saiu para o AIS-50b):** `NodeType 'Terrain'` de primeira classe; `TerrainEditorModal` mantido como editor do nó; geometria CPU; heightmap por PNG (ver decisão 23)
87. **AIS-50b NOVO v5.1.2** — Edição de terreno no Inspector e na viewport (escultura, pintura, `.height`, Undo)
88. **AIS-51 NOVO v5.1** — Árvores: extrair presets e contrato `TreeParams` (sem mudar comportamento)
89. AIS-51a — **⚠️ revisado v5.1:** motor `TreeGenerator` nativo + preview real + folhagem/vento + instanciar com `MacroCommand`
90. **AIS-51b NOVO v5.1** — Árvores: UVs próprios e casca de tronco como `MaterialAsset`
91. **AIS-51c NOVO v5.1** — Árvores: `generatorSource` e Salvar como Prefab
92. **AIS-51d NOVO v5.1** — Árvores: distribuição no terreno (`InstancedMesh`)
93. AIS-52
94. AIS-53
95. AIS-54
96. AIS-55
97. AIS-56
98. AIS-57
99. AIS-58 — amplia InputManager do AIS-40b; não cria outro
100. AIS-59
101. **AIS-45b NOVO v6.0** — Queries físicas na `PhysicsBridge` (`raycast`, `overlapSphere`; sem Raycaster nem Rapier direto no gameplay) — pré-requisito do AIS-69
102. **AIS-29g NOVO v6.0** — Spawn/despawn de prefab em runtime (`RuntimeScene.spawnPrefab`/`despawn`; único caminho de criação dinâmica) — pré-requisito do AIS-69 e AIS-71
103. **AIS-44e NOVO v6.0** — Objetos criados em jogo aparecem no Play (apresentador de spawns na viewport; reabre AIS-29g-C08) — pré-requisito do AIS-69
104. **AIS-59b NOVO v6.0** — Fechamento de defeitos abertos: `locked` em nó único (AIS-19), bloco de física inválido em silêncio (AIS-45), gatilho × personagem cinemático (AIS-47/48), Ctrl+D que não duplicava (AIS-04/20)
105. **AIS-59c NOVO v6.0** — Executores das Actions/Behaviors do catálogo: `emit_particles` executa; animação e `follow_cursor` "em breve"; `timer_trigger` funcional; teste-guarda de cobertura (regra "executor no mesmo prompt")
106. AIS-60
107. **AIS-60b NOVO v6.3** — Animação simples: objeto animado (`MeshInstance.animation`), Inspector, Actions e Behaviors; remove o nó `AnimationPlayer`, a Timeline e a edição de clipes (decisão 30); substitui AIS-61 e AIS-61c
108. **AIS-61b NOVO — GATE VERTICAL SLICE 1**

> AIS-61b é bloqueante. Não avançar enquanto o fluxo Create -> Edit -> Logic -> Play -> Stop -> Reopen (incluindo os passos de CRUD da Emenda v5.1) falhar.

## Fase G — Conteúdo avançado
109. **AIS-30c NOVO v6.1** — Projeto em disco: workspace em `Documentos/Nodimus3DStudio/<nome>/`, `res://` = pasta do projeto, `.meta` por recurso, escrita atômica em fila, sem migração dos projetos antigos (decisão 29); executa antes do AIS-61c
110. AIS-68
111. AIS-69
112. AIS-70
113. AIS-72 — Editor de Caminhos e Behavior `Follow a Path` (nó `Path`, waypoints 3D, Undo/Redo, execução determinística `once`/`loop`/`pingpong`; sem NavMesh, A* ou pathfinding)
114. **AIS-72b NOVO v6.4** — Nó `Waypoint` (marcador de ponto reutilizável: rota de patrulha por filhos em ordem, helper só no editor, `resolveRoute`); sem física, sem Command novo; consumido pelo AIS-71
115. **AIS-71 — reposicionado v6.4** (depois do AIS-72/72b, que ele consome) — IA de atores: `ai_state_machine` (Idle/Patrol/Chase/Attack/Flee) + `game_actor_with_health` + Action `shoot` sobre o núcleo do AIS-69
116. AIS-73 — v6.7: veículos terrestres (`vehicle_controller`, `vehicle_wheel`) + formulário "Criar Veículo" (`VehicleDialog`, gerador `vehicle`, reedição por reconciliação) + extensão mínima da `PhysicsBridge`; aeronave passa ao AIS-73b
117. **AIS-73b NOVO v6.7** — Aeronaves: `aircraft_controller` + modo Aeronave do `VehicleDialog` (gerador `aircraft`, "Aplicar ao nó" por reconciliação); sem altitude alvo; reaproveita o shell, `vehiclePresets` e a extensão da `PhysicsBridge` do AIS-73
118. AIS-74
119. AIS-75
120. AIS-76 — v5.2: reescrito no modelo Godot-like (`SpriteFrames`/`AtlasTexture`/`AnimatedSprite3D`); depende de AIS-28c, AIS-29e, AIS-32c e AIS-41
121. **AIS-76b NOVO v5.3** — Actions `play_sprite_animation` e `set_sprite_frame` + Trigger `on_sprite_animation_finished` (depende do AIS-76 e do AIS-41)
122. AIS-77

## Fase H — Plataforma e produto
123. AIS-78c — CapabilityRegistry + EngineApi (v4.7.0: sem addons/plugins; AIS-78 e AIS-78b removidos)
124. **AIS-78d NOVO v6.8** — IA como serviço da EngineApi (1.4): estado do cérebro em `state.memory`, registro de atores, `hooks`/`routes`/`diagnostics`; fecha o último `extra` da decisão 32 (contextos 100% derivados); antes do AIS-79, que consome a EngineApi
125. AIS-79
126. AIS-80
127. AIS-81
128. AIS-81b
129. AIS-82
130. AIS-83
131. AIS-84
132. AIS-85
133. AIS-85b
134. **AIS-85c NOVO v4.6** — Publish do jogo Desktop/Mobile com Tauri 2
135. AIS-AP — Tauri (`AIS-AP-tauri.md`, empacotamento desktop do editor; requer Rust)

## Regras especiais de nivelamento
- `Viewport3D` é host/editor UI, não motor de gameplay.
- `RuntimeSession` é a única autoridade durante Play.
- `RuntimeSceneManager` é diferente de `DocumentManager`.
- `InputManager` runtime é diferente de atalhos do editor.
- Gizmos alteram authoring via CommandManager; ficam bloqueados durante Play.
- Behavior/Action Definition é catálogo; GameNode é configuração; estado mutável vive no runtime.
- UIKit é UI do jogo; React/Tailwind permanecem UI do editor.
- Publish deve reutilizar o runtime, não reconstruir um segundo motor.
- Tauri do editor e empacotamento do jogo são responsabilidades distintas.
- Web publica como Web; Desktop e Mobile do jogo usam hosts Tauri 2 separados, definidos no AIS-85c.
- `Environment` é o único nó de ambiente visual por Scene; Gravity permanece na Scene.
- Prefab `.prefab.json` abre no Scene Editor em modo Prefab.
- `res://sprites/` é a pasta canônica de SpriteAsset/spritesheets.
- NodeTypes existem somente em `src/nodes/registry.ts`; tipo desconhecido em cena é preservado como Missing/Unknown Node.
- Triggers/Conditions/Actions/Behaviors nativos: uma pasta por item em `src/logic/<tipo>/<id>/`, descobertas pelo `LogicRegistry`; nunca catálogo em arquivo único.
- Não existe sistema de extensões/plugins nem `res://addons/` (v4.7.0); `ExtensionsPanel` é stub.
- **Modelo 3D (v5.6, decisão 27):** modelo é recurso real em `res://models/`; `MeshInstance.model` é um `ResourceRef`; **um só** `loadModel`, **um só** cache e **uma só** `createModelObject` servem modal, Viewport, Play e Publish; entrada **só** pelo `AssetImportModal` + `AssetPipeline`; o original nunca é regravado (calibração em `importSettings`).
- **Cadeia de importação 3D (v5.6):** `AIS-32c → AIS-33a → AIS-33 → AIS-34 → AIS-35 → AIS-36 → AIS-37 → AIS-38 → AIS-38c`. Cada elo só consome o anterior; nenhum prompt posterior reimplementa carga, cache, calibração, rig ou diagnóstico.
- `rig.json`, manifesto `_material.json` e `ModelImportSettings` são **Zod v1** com `ResourceRef`; sem base64 em JSON; sem formato `.anim` novo (biblioteca de clipes por referência).
- **Executor no mesmo prompt (v6.0, AIS-59c):** toda Action, Behavior ou Trigger que este prompt registrar entrega o **executor/runtime e o teste no mesmo prompt** (`src/logic/<tipo>/<id>/runtime.ts`); se o sistema de que depende ainda não existe, marca `status: 'disabled'` ("em breve") e entra em `DISABLED_OWNERS` de `src/logic/executorCoverage.test.ts` com o prompt dono. "Pertence ao prompt X" sem que o X o entregue é proibido (AIS-59c).
- **Armas, projéteis e dano (v6.0):** consulta espacial só por `PhysicsBridge.raycast`/`overlapSphere` (AIS-45b); criação/destruição dinâmica de GameNode só por `RuntimeScene.spawnPrefab`/`despawn` (AIS-29g); disparo, impacto e dano só pelo núcleo `src/runtime/weapons/` (AIS-69), usado por `weapon_controller`, `fire_projectile` e pela Action `Shoot` do AIS-71. Não existe Trigger `On Projectile Hit`; plano 2D vem de `properties.physics`.
- **IA, caminhos e waypoints (v6.4):** ordem `AIS-72 (Path, `follow_a_path`, `moveNodeToward`) → AIS-72b (nó `Waypoint`, `resolveRoute`) → AIS-71 (`ai_state_machine`, `game_actor_with_health`, Action `shoot`)`. Movimento por tipo de corpo só por `moveNodeToward`; rota de pontos só por `resolveRoute`; ponto de rota = nó `Waypoint` (filhos de um contêiner, na ordem da SceneTree); `Path` continua com `Vector3[]`. A IA não implementa disparo/dano (AIS-69), pathfinding nem NavMesh; o runtime nunca cria a variável `health`.
- **Câmera × movimento (v5.9, decisão 28):** Behavior de movimento (no ator) move/anima e nunca publica pose de câmera; Behavior de câmera (só em `Camera`) é dono de olhar/órbita/PointerLock/pose, com alvo opcional por ID estável; ator lê só `viewBasis`. Cadeia: `AIS-47 → AIS-47b (rig, sem mudança visível) → AIS-47c (Behaviors separados, diálogo, "Separar câmera…") → AIS-47d (demais estilos 3D)`; câmeras 2D = AIS-75; veículos = AIS-73 (câmera opcional via `camera_third_person`); estado de locomoção → AIS-60. Composites `first_person_controller`/`third_person_controller` ficam como legado e nunca são convertidos sozinhos.
- `'Terrain'` é `NodeType` de primeira classe; geometria CPU via `buildTerrainGeometry`; `TerrainEditorModal` mantido como editor do nó (sem estado próprio); heightmap = `ResourceRef` PNG; collider = `Rapier.heightfield` com mesmo buffer (v5.1, decisão 23).


## Fundação de estado v4.1 — regra transversal
`Zod -> valida fronteiras | Authoring Model -> autoridade persistente | CommandManager -> mutações autorais reversíveis | Zustand -> projeção/estado reativo da IDE | RuntimeSession -> estado transitório do jogo`.

Nenhum prompt posterior pode criar um segundo store autoral, histórico de undo paralelo, schema concorrente ou runtime dentro do EditorStore.

## Regras transversais v4.5
- **Log:** todo prompt termina gravando `docs/logs/<ID>.md`; o gate AIS-61b também registra o PASS/FAIL por etapa no seu log.
- **Tema:** entre AIS-01 e AIS-82 só existe o dark. O tema claro passa a existir quando o usuário o cria no Configurador de Temas (AIS-82, nº 127).

## Execução v5.0.0 — Claude Code
- Pendente = prompt desta lista sem `docs/logs/<ID>.md`, ou cujo último `**Resultado:**` do log contém "bloqueado". AIS-P0 vem antes de todos. `/ais-proximo` usa esta regra, na ordem numérica acima.
- Gate de todo prompt: `npm run check` + editor sem erros no console (`npm run dev`). Não avançar para o próximo com gate vermelho.
- AIS-61b continua bloqueante.

## Regras transversais v5.1 — CRUD
- **Dado autoral (nó, regra, condição, conexão de sinal, variável, clipe, keyframe):** criar, editar e excluir é sempre `Command` com Undo.
- **Arquivo em `res://` (cena, recurso, prefab):** criar, mover e excluir não é Command — pede confirmação, passa pelo `deleteResource`/`moveResource` (AIS-29e) e nunca apaga referências silenciosamente.
- **Abrir/reabrir:** mostra o estado salvo; fechar com alterações pendentes passa pelo `DocumentManager` (AIS-18b).
- **Geradores (Terrain, Tree, Sound, Particle):** nó criado guarda `generatorSource`; "Editar no gerador" reabre com parâmetros salvos; "Aplicar ao nó" é `MacroCommand` (AIS-49b).
- **ProjectSettingsModal (AIS-32b):** configurações do projeto em `project.json`; distinto do Diálogo de Preferências do Editor (AIS-82).
- **Input Map:** CRUD de ações e bindings no ProjectSettingsModal (AIS-58); não cria `InputManager` paralelo.
- **Terrain (AIS-50, decisão 23):** `NodeType 'Terrain'`; geometria CPU; sem `displacementMap`; heightmap = `ResourceRef`; `TerrainEditorModal` mantido como editor do nó `Terrain` (geração/texturas); escultura e pintura = AIS-50b.

## Dono de cada campo de `settings` (v5.7)

O AIS-32b **grava** todos os campos de `ProjectSettings` (`project.json`); cada campo tem **um** prompt dono que o **lê**. Campo sem leitor aparece **desabilitado** no `ProjectSettingsModal` com o AIS dono no tooltip (decisão 14; marcação feita no AIS-44d e retirada pelo prompt dono). Nenhum consumidor lê `project.settings.rendering/display` fora de `resolveRenderSettings` (AIS-44d).

| Campo | Leitor / dono | Observação |
|---|---|---|
| `general.projectName`, `mainScene` | AIS-32 / AIS-29f / AIS-32b | já em uso (nome canônico = `ProjectData.name`; cena inicial) |
| `general.version`, `author`, `description` | AIS-85c | metadados do pacote publicado |
| `physics.gravity3D` | AIS-32b (`sceneManager`) | padrão de `Scene.gravity` para cenas novas (decisão 17) — **já em uso** |
| `physics.defaultLinearDamp` | AIS-45 | `PhysicsBridge` aplica o amortecimento padrão aos corpos |
| `audio.masterVolume`, `musicVolume`, `sfxVolume` | AIS-52 | mixer de áudio |
| `input.actions` | AIS-58 | Input Map (amplia o InputManager do AIS-40b); a aba do modal é do AIS-58 |
| `rendering.shadowsEnabled`, `shadowQuality`, `clearColor` | AIS-44d | Play (via `resolveRenderSettings`) |
| `rendering.hdr`, `msaa` | AIS-44d, coordenado com AIS-55 | um só pipeline com o EffectComposer |
| `display.width`, `height` | AIS-44d (moldura do Play); AIS-85c (janela do jogo) | |
| `display.windowMode` e `display.fullscreen` (legado) | AIS-85c (Desktop); AIS-85 (Web: fullscreen exige gesto) | só `windowMode` é lido; `fullscreen` é espelho legado (remoção futura com migração, AIS-29b) |
| `display.resizable`, `orientation` | AIS-85c | janela Tauri / publicação Mobile |
| `rendering.vsync` | AIS-85c | no navegador o RAF já é vsync; no editor fica "em breve" |
| `rendering.renderer` | informativo | não editável |
