# Log — AIS-77 · Overlay de Debug e Diagnóstico em Runtime

## Execução 1
- **Resultado:** concluído
- **Arquivos criados:**
  - `src/core/debug/debugStats.ts` (+ `debugStats.test.ts`) — `FrameTimeWindow` (média móvel de N quadros: FPS, ms, mín/máx), `DebugStats` (sonda: zera `renderer.info` uma vez por quadro com `autoReset` desligado, soma as passadas, devolve o `autoReset` ao desplugar), `buildConsoleFeed` (sinais + regras/Actions por tempo de jogo) e `summarizeDiagnostics`.
  - `src/components/viewports/RuntimeDebugOverlay.tsx` — painel HTML somente leitura: FPS, tempo de quadro (mín/máx), draw calls, triângulos, geometrias/texturas, nós vivos × nós do authoring, checkbox "Wireframe dos colisores", diagnósticos da sessão e console embutido (últimos 12 sinais/Actions).
  - `src/core/rendering/RendererCore.probe.test.ts` — sonda mede o quadro inteiro (cena + HUD), desligada não custa nada, desplugar restaura o `autoReset`.
  - `src/hooks/debugShortcut.test.ts` — F3 só em Play.
- **Arquivos alterados:**
  - `src/core/rendering/RendererCore.ts` — `setProbe`/`hasProbe`; `begin` antes dos callbacks e `end` depois do HUD (um teste de `null` por quadro quando desligado).
  - `src/core/editorStore.ts` — `showDebugOverlay` + `setShowDebugOverlay` (não persistido).
  - `src/hooks/useDesktopShortcuts.ts` — atalho **F3** (`toggle_debug_overlay`); só age e só impede o padrão do navegador durante o Play.
  - `src/schemas/fixtures/index.ts` — fixture K15 passa a contar 15 atalhos; estado de fixture ganha `showDebugOverlay`.
  - `src/components/viewports/Viewport3D.tsx` — monta o overlay só com `isPlaying && showDebugOverlay` e pluga a sonda no `RendererCore` só enquanto ele está visível.
- **Decisões e respostas do usuário:** nenhuma pergunta necessária. O overlay só existe durante o Play (como pede o prompt); o wireframe dos colisores reutiliza o MESMO `ViewportColliders` e a mesma preferência da toolbar (sem um segundo desenho); os erros vêm do `DiagnosticService` (`list({ sessionId })`), sem canal paralelo; o console lê o `SignalBus` e o log de execução da lógica.
- **Critérios de aceite:**
  - AIS-77-C01 OK (navegador: F3 fora do Play não faz nada; em Play abre e fecha o overlay; desligado, o overlay desmonta e a sonda sai do renderer — testes de custo zero)
  - AIS-77-C02 OK (`npm run check` verde; console do editor sem erros)
  - AIS-77-C03 OK (navegador: FPS 13,6, 73,63 ms, 21 draw calls, 3.258 triângulos, 30/9 geometrias/texturas, 13 nós vivos, console mostrando a linha do Behavior de movimento, diagnósticos 0/0; o checkbox liga o mesmo "Mostrar colisores" da toolbar; Parar/F8 fecha tudo). O FPS baixo é do renderizador por software do painel de teste
  - AIS-77-C04 OK (suíte inteira verde; o fluxo normal de Play/Stop segue funcionando)
  - AIS-77-C05 OK
- **Validação:** `npm run check` verde — 181 arquivos, 2269 testes, build ok.
- **Erros de console/Preview e como foram tratados:** nenhum. Nota: o painel do navegador de teste só desenha (e mede) quando está em primeiro plano; escondido, o loop do `requestAnimationFrame` para e os números ficam em 0.
- **Pendências e perguntas em aberto:** a memória de textura em bytes (a skill cita "aproximada") não entrou: o overlay mostra a contagem de texturas e geometrias do `renderer.info`; e o overlay não aparece na edição (o prompt pede só em Play).


## Execução 2 — PENDENTE (reaberta na revisão v6.9)
- **Resultado:** bloqueado — critérios **AIS-77-C06, C07 e C08** (emenda v5.8: aba Problemas no BottomPanel, `project.save_failed` e `ProjectStorage.onSaveSuccess`) nunca foram executados nem citados na execução 1, que só cobriu C01–C05. Confirmado no código: não há aba Problemas nem `project.save_failed` em `src/`.
- **Por que importa:** o AIS-85b-C08/C09 (Publish consulta o `DiagnosticService`) e o AIS-32c-C04 dependem do consumidor "Problemas" e do publicador de erros de gravação.
- **Próximo passo:** rodar `/ais AIS-77` (só a emenda v5.8) ANTES do AIS-79; ao concluir, acrescentar o resultado aqui. Alternativa: mover para um AIS-77b (exigiria renumerar a ordem; decisão do usuário).
