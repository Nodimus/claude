# node

## 0. Alinhamento arquitetural Nodimus v4
- **Status desta SPEC:** baseline observado + contrato de evolução; itens das seções originais descrevem o código analisado, salvo indicação explícita de alvo futuro.
- **Criticidade arquitetural:** CRÍTICA
- **Prompts/etapas relacionados:** AIS-03, AIS-04, AIS-15, AIS-26, AIS-29d, AIS-32c, AIS-41b, AIS-45, AIS-48, AIS-48b, AIS-49, AIS-56, AIS-68, AIS-69, AIS-70, AIS-71, AIS-72, AIS-73, AIS-74, AIS-75, AIS-80
- **Papel no produto:** Definição autoral de nó/instância na cena.
- **Fronteira obrigatória:** Node autoral não é THREE.Object3D nem RuntimeInstance; adapters fazem a materialização.
- **Regra de implementação:** estender o que já existe; antes de criar novo serviço/tipo/estado, procurar o contrato canônico correspondente e evitar implementação paralela.
- **Critério mínimo de aceite:** build/typecheck sem regressão + fluxo existente preservado + nova integração coberta por teste determinístico ou checklist reproduzível.
- **Não presumir:** este cabeçalho define direção arquitetural, não afirma que os recursos futuros já estejam implementados.

> **Atualização v5.3 (AIS-18d):** `NodeType` deriva de `NODE_DEFINITIONS` (`src/nodes/registry.ts`); `NodeTypeMetadata<T>` ganhou `createCategory` (e `creatable?` no AIS-18d). Tipo desconhecido lido de cena vira `Missing` e é regravado intacto.

## 1. Identificação
- **Nome:** node
- **Tipo:** Domínio / modelo / serviço de núcleo
- **Localização no código:** `src/types/node.ts`
- **Linhas (auditado v4.4):** 109

## 2. Finalidade
Define estruturas e/ou serviços existentes relacionados ao domínio `node`.

## 3. Estrutura
- Declarações exportadas: `NodeCategory`, `NodeType`, `Vector2Data`, `Vector3Data`, `ColorData`, `PropertyFieldType`, `PropertyDescriptor`, `NodeTypeMetadata`, `GameNode`

## 4. Campos
### `Vector2Data`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `x` | `number` | Não definido na interface | obrigatório |
| `y` | `number` | Não definido na interface | obrigatório |
### `Vector3Data`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `x` | `number` | Não definido na interface | obrigatório |
| `y` | `number` | Não definido na interface | obrigatório |
| `z` | `number` | Não definido na interface | obrigatório |
### `ColorData`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `r` | `number` | Não definido na interface | obrigatório |
| `g` | `number` | Não definido na interface | obrigatório |
| `b` | `number` | Não definido na interface | obrigatório |
| `a` | `number` | Não definido na interface | obrigatório |
### `PropertyDescriptor`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `key` | `string` | Não definido na interface | obrigatório |
| `label` | `string` | Não definido na interface | obrigatório |
| `type` | `PropertyFieldType` | Não definido na interface | obrigatório |
| `category` | `string` | Não definido na interface | obrigatório |
| `defaultValue` | `any` | Não definido na interface | obrigatório |
| `options` | `{ label: string` | Não definido na interface | opcional |
### `NodeTypeMetadata`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `type` | `NodeType` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `category` | `NodeCategory` | Não definido na interface | obrigatório |
| `is2D` | `boolean` | Não definido na interface | obrigatório |
| `is3D` | `boolean` | Não definido na interface | obrigatório |
| `isUI` | `boolean` | Não definido na interface | obrigatório |
| `description` | `string` | Não definido na interface | obrigatório |
| `icon` | `string` | Não definido na interface | obrigatório |
| `defaultProperties` | `Record<string, any>` | Não definido na interface | obrigatório |
| `propertyDescriptors` | `PropertyDescriptor[]` | Não definido na interface | obrigatório |
| `availableSignals` | `string[]` | Não definido na interface | obrigatório |
### `GameNode`
| Nome | Tipo | Valor padrão | Obrigatoriedade |
|---|---|---|---|
| `id` | `string` | Não definido na interface | obrigatório |
| `name` | `string` | Não definido na interface | obrigatório |
| `type` | `NodeType` | Não definido na interface | obrigatório |
| `parentId` | `string \| null` | Não definido na interface | obrigatório |
| `childrenIds` | `string[]` | Não definido na interface | obrigatório |
| `visible` | `boolean` | Não definido na interface | obrigatório |
| `locked` | `boolean` | Não definido na interface | obrigatório |
| `collapsed` | `boolean` | Não definido na interface | opcional |
| `properties` | `Record<string, any>` | Não definido na interface | obrigatório |
| `script` | `string` | Não definido na interface | opcional |
| `behaviors` | `string[]` | Não definido na interface | opcional |
| `signals` | `{` | Não definido na interface | opcional |
| `id` | `string` | Não definido na interface | obrigatório |
| `signalName` | `string` | Não definido na interface | obrigatório |
| `targetNodeId` | `string` | Não definido na interface | obrigatório |
| `targetMethod` | `string` | Não definido na interface | obrigatório |

## 5. Comportamentos
- Consulte as funções/constantes exportadas listadas em **Estrutura**; não são atribuídos comportamentos não presentes no arquivo.

## 6. Regras
- Tipos union, interfaces, valores padrão e restrições são os definidos diretamente neste arquivo; nenhuma regra externa foi presumida.

## 7. Dependências
- Importações diretas: Nenhuma importação explícita.


## Emenda v5.1.3 — Partículas
- `ParticleEmitter` removido de `NodeType`; `ParticleSystem` é o único tipo de partículas (AIS-18c). Ver `particle-system.spec.md`.


## Emenda v5.5 — Colisão do objeto (decisão 26)
- `GameNode.physics` de primeiro nível **não existe**. Física e colisão vivem em `GameNode.properties.physics` (`PhysicsConfig`: `enabled`, `bodyMode`, `shape`, `size?`, `offset?`, `friction?`, `bounce?`, `mass?`, `layer?`, `mask?`, `constrainToPlane?`, `forwardAxis?`, `floats?`), validado por `PhysicsConfigSchema`. Ausência do bloco = sem corpo.
- `StaticBody`, `RigidBody`, `KinematicBody`, `Area` e `CollisionShape` foram eliminados de `NodeType`; cenas antigas são migradas ao abrir (`convertLegacyPhysics`) e o que não converte vira Missing Node.

## Emenda v5.7 (AIS-33a) — MeshInstance com modelo 3D
`MeshInstance` ganhou `model` (`ResourceRef`, descriptor `type: resource`, visível só quando existe) e `modelOffset` (`Vector3`); **não** existe `NodeType` novo. Com `model`, o nó desenha o modelo real (`res://models/`) e `meshType` fica guardado, sem efeito (fallback/Undo). O objeto é criado por `createModelObject` (`src/core/models/`), a mesma fábrica do editor, do Play e do preview.

## Emenda v6.4 (AIS-68) — WaterPlane
`WaterPlane` é `NodeType` de primeira classe (`createCategory: 'Environment'`; várias por cena). Retângulo XZ `width × depth` (antes da escala do nó); **o nível da água é a posição Y do nó**. `properties` é a fonte da verdade: `color`, `transparency` (0 opaca…1 transparente), `waveScale`, `waveSpeed`, `waveStrength`, `flowDirection` (°), `reflectionMode` (`planar` = render-to-texture por quadro, caro; `environment` = só o HDRI/Skybox ativo, barato; `off`), `reflectionIntensity`, `reflectionResolution` (256/512/1024), `buoyancy`, `drag`. Presets Lago/Rio/Oceano só preenchem estes campos (um Command); `res://materials/<nome>_water.json` (Zod v1, kind `material`) é preset de APARÊNCIA gravado/lido pelo `AssetPipeline`. Desenho: `src/core/water/waterObject.ts` (único para Viewport e fábrica de runtime; `three/addons/objects/Water.js` com patch de uniforms). Flutuação (Emenda v5.5): `PhysicsHost` aplica empuxo + arrasto a corpos `dynamic` com `physics.floats` abaixo da superfície e publica `triggerEnter/triggerExit` (um por participante); a água não tem corpo físico. Personagem nadando continua fora do escopo.

## Emenda v6.5 (AIS-70) — Billboard `faceMode` e Hotspot
- **Billboard:** `faceMode: 'camera' | 'y-axis' | 'none'` (padrão `camera`) substitui o booleano `alwaysFaceCamera`, que cenas antigas mantêm e é lido de forma tolerante (`true`→`camera`, `false`→`none`; `readFaceMode` em `src/core/billboard.ts`). `y-axis` gira só em torno de Y (árvores/vegetação em quad).
- **Hotspot** (`NodeType` de primeira classe, `createCategory: 'Special'`): volume de detecção invisível no jogo. Forma e tamanho = bloco `properties.physics` com corpo `trigger` (esfera por padrão; decisão 26, `resolveCollider` única). Editor: wireframe do volume + marcador; o volume só captura o raycast no Play. Triggers `on_hotspot_enter`/`on_hotspot_exit` (opcional `tag` do corpo) e `on_hotspot_click` (botão), nas regras de um Behavior `hotspot_events` (só em Hotspot). Ícone de tamanho fixo com oclusão (skill) ficou fora do escopo.

## Emenda v6.6 (AIS-72) — `Path` e Behavior `Follow a Path`
- **`Path`** (`NodeType` de primeira classe, `createCategory: 'Special'`, ícone `Route`, âmbar `#f59e0b`): dado autoral puro, sem corpo/colisão. `properties.nodes: {x,y,z}[]` (waypoints no espaço LOCAL do nó; a posição/rotação/escala do nó se aplicam por cima), `closed`, `tightness` (tensão da `CatmullRomCurve3`, 0,5 = padrão) e `showInPlay` (mantém a spline visível no Play). Leitura tolerante e curva única em `src/core/path/pathData.ts` (`readPath`, `buildPathCurve`); persiste pelo serializador normal, sem arquivo próprio.
- **Edição na viewport:** com o Path selecionado a viewport mostra spline, linhas e handles 3D (`src/core/path/pathObject.ts`); o botão "Editar pontos" do Inspector liga `manipulationMode === 'path'` (transitório, como o modo terreno; Esc sai): clique no vazio adiciona, handle arrasta (Shift = só altura), clique num segmento insere, Delete remove o handle selecionado. Cada operação é um Command (`createSetPathNodesCommand`, `ChangePropertyCommand` sobre `nodes`); arrastar emite UM Command ao soltar. Handles e linhas nunca aparecem no Play.
- **`follow_a_path`** (`Movement`, `src/logic/behaviors/follow_a_path/`): `pathId` (ID do nó Path; o seletor lista só nós Path via `LogicParamDescriptor.nodeTypes`), `speed`, `loopMode: once | loop | pingpong`. Executor por propriedades (`replacesRules`); progresso por comprimento de arco em `src/core/path/pathProgress.ts`; referência inválida → diagnóstico `follow_a_path.path_missing | not_a_path | path_too_short | invalid_speed` (uma vez, sem mover).
- **`moveNodeToward`** (`src/runtime/motion/moveToward.ts`): única função de deslocamento por tipo de corpo — `character` (intenção ao controlador da `PhysicsBridge`), `kinematic`/`trigger` e sem corpo (pose do runtime), `dynamic`/`static` incompatíveis (`motion.dynamic_body`, `motion.static_body`). O AIS-71 a reutiliza.

## Emenda v6.7 (AIS-72b) — `Waypoint`
- **`Waypoint`** (`NodeType` de primeira classe, `createCategory: 'Special'`, ícone `MapPin`, ciano `#22d3ee`): marcador de ponto no mundo, sem malha, física nem colisão (sem seção Colisão). `properties`: `label` (rótulo do helper), `waitMs` (>= 0, permanência sugerida; quem consome decide), `color` (`{r,g,b,a}`, padrão da casca para cor; a spec original dizia string). A posição do nó é o ponto; mover/renomear/reordenar/duplicar/excluir usam os Commands existentes.
- **Rota** = nó contêiner qualquer; seus filhos DIRETOS `Waypoint`, na ordem da SceneTree (`childrenIds`), formam a sequência. **`resolveRoute(scene, containerId)`** (`src/core/waypoints/resolveRoute.ts`, pura) é a única leitura: posições em espaço mundial (compõe todos os ancestrais), `{ ok: false, code: 'route.container_missing' | 'route.empty' }` nas falhas, `ok` com 1 ponto. O consumidor (AIS-71) emite o diagnóstico com esses códigos.
- **Helper só de editor** (`waypointObject.ts`, mesmo padrão do Hotspot/Path): sprite de marcador (textura por cor em cache) + sprite de rótulo; some no Play e não captura raycast; o publish não o cria. Com um contêiner de rota (ou um Waypoint filho) selecionado, `RouteLinesHelper` liga os pontos em ordem com linhas retas.

## Emenda v6.8 (AIS-71) — IA de atores
- **Behaviors** `ai_state_machine` (decisão e movimento: percepção por `overlapSphere` em intervalo, 5 estados FIXOS Idle/Patrol/Chase/Attack/Flee por prioridade, patrulha `none | random_area | waypoints | path`) e `game_actor_with_health` (vitais: `on_actor_hit`, `on_actor_die` UMA vez, `dieAnimation`; nada é destruído sozinho), categoria `AI`; Action `shoot` (só configuração sobre `weapons.fire`/`weapons.damage`); Triggers `on_ai_state_changed` (parâmetro `state`), `on_ai_attack`, `on_actor_hit`, `on_actor_die`. Ganchos = regras do PRÓPRIO Behavior, nascem vazias.
- **Estado transitório (revisado pelo AIS-78d, EngineApi 1.4):** o cérebro mora em `state.memory.brain` do Behavior; a `RuntimeSession` guarda só o `ActorRegistry` (`src/runtime/ai/actorRegistry.ts`: mortos e alvo por nó). O `AiService` e o `ctx.ai` não existem mais; Behaviors e a Action `shoot` usam `ctx.engine.ai`/`hooks`/`routes`/`diagnostics`/`random`. A inscrição `damage_taken` é do próprio Behavior `game_actor_with_health`. Descartado no Stop/restart/troca de cena/remoção do Behavior. Lógica pura: `nextState`, `selectTarget`, `randomPatrolPoint`, `nextWaypoint`.
- **Contratos reaproveitados:** movimento só `moveNodeToward` (AIS-72); rota `resolveRoute` (AIS-72b); Path pelo Behavior `follow_a_path` composto; dano/vida `damage_taken` (AIS-69); clipes pelo `AnimationHost` (decisão 30).
- **Vida:** variável Local declarada no authoring; `BehaviorDefinition.presetVariables` declara as que faltam ao ADICIONAR o Behavior (Command com Undo; nunca sobrescreve valor existente); o runtime só lê. `LogicParamDescriptor.variableScope: 'local'` faz o seletor de variável do Behavior listar as Locais do nó dono.
- **Extensões mínimas de contrato:** `FireParams.originOffset` (deslocamento local da origem do disparo), `WeaponService.isProjectile`, `LogicParamDescriptor.nodeTypes` já existente do AIS-72, hooks do runner aceitam `params` (ex.: `state`).
