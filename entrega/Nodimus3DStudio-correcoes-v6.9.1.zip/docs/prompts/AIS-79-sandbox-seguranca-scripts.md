# AIS-79 — Sandbox de Segurança para Scripts

> **Origem:** Prompt 79 · **Módulo 15:** Infraestrutura do Editor e do Produto · **Destino:** Claude Code (Claude Desktop) · **Skills embutidas:** `nodimus-sandbox-seguranca`, `nodimus-play-mode`, `nodimus-canon-governanca`

> **Posição canônica:** Fase H — Plataforma e produto · nº 125 de 135 · anterior: AIS-78d · próximo: AIS-80
> **Relaciona-se com:** AIS-41, AIS-43, AIS-46, AIS-57, AIS-78c, AIS-78d
> **Decisão Canônica Relacionada:** 5 e 22 — pré-requisito explícito para executar scripts customizados do usuário (`res://scripts/*.js|ts`) além da lógica visual declarativa (Behaviors/Actions nativos de `src/logic/`). **v4.7.0:** não existem extensões, addons nem plugins; o sandbox cobre apenas scripts do projeto.

---

## 0. Preâmbulo fixo

Identidade, hierarquia da verdade, decisões canônicas (as numeradas no `CLAUDE.md`, até a 32), contratos arquiteturais transversais e regras de execução (1–14) estão no **`CLAUDE.md`** da raiz do repositório (carregado automaticamente pelo Claude Code) e valem para este prompt. Não são repetidos aqui.

> **Regra local (AIS-79):** execução de código usa **Web Worker isolado + mensagem estruturada + EngineApi segura + Command Buffer validado pelo host**. `new Function`, `eval` e `unsafe-eval` são proibidos no contexto do editor.

---

## 1. Estado real da casca

_Cruzamento feito com o código da casca (`nodimus-studio---game-editor-ide`) e com as SPECs relacionadas ao final deste prompt. **EXISTE** = estender, sem recriar; **CRIAR** = inexistente na casca, criar antes de usar._

| Item | Status | Ação |
|---|---|---|
| CodeMirrorEditor → `src/components/codeEditor/CodeMirrorEditor.tsx` (490 linhas) | **EXISTE** | estender, sem recriar |
| ScriptEditorModal → `src/components/modals/ScriptEditorModal.tsx` (182 linhas) | **EXISTE** | estender, sem recriar |
| CodeEditorWorkspace → `src/components/viewports/CodeEditorWorkspace.tsx` (411 linhas) | **EXISTE** | estender, sem recriar |

## 2. Contexto e integração

Não adiciona UI nova por si só — é a camada de execução de código não confiável baseada em **Web Worker**, chamada pela RuntimeSession quando scripts do projeto (`res://scripts/`) precisarem executar. É separada do isolamento de estado do PlaySimulation (AIS-46).

---

## 3. Especificação

```text
Implemente a camada de sandbox, ANTES de qualquer execução de script do usuário ser liberada (ação run_script, Prompts 41/44):
- Use **Web Worker** como decisão canônica. Comunicação ocorre por snapshot somente-leitura + buffer de comandos; não reabra a escolha Worker × iframe.
- Superfície de API exposta ao script do usuário deliberadamente pequena (ex.: ler/escrever variáveis do AIS-43, escutar sinais do AIS-57) — nunca acesso direto a `window`, `document`, ou ao sistema de arquivos nativo (`tauriBridge`).
- Timeout e limite de execução por frame, para um script do usuário não travar o Play Mode inteiro.
```

### 2.1 Emenda — Migração de Cascas de Editores de Arquivo (2026-09-27)

> Origem: as cascas de editores já estão montadas na casca (estado no `EditorContext`). A lógica de roteamento, gravação e integração é desenvolvida neste prompt; decisões de comportamento fino são confirmações com o usuário.

- Escopo: além de scripts anexados a nós, o sandbox é o **único** caminho de execução para scripts `.js`/`.ts` de `res://scripts/` chamados pela ação **Executar Script** (`src/logic/actions/run_script/`, Prompts 41/44). O `ExtensionsPanel` é stub (v4.7.0) e não gera scripts.

---

### 3.1 Emenda canônica — sandbox obrigatório de código de projeto

Esta emenda prevalece sobre qualquer skill que permita execução no mesmo contexto. Scripts customizados executáveis (`res://scripts/`) usam **Web Worker** como único caminho de execução. O host envia snapshot somente-leitura e recebe buffer de comandos; a `EngineApi` do Worker lê o snapshot e enfileira comandos. Não expor DOM, `window`, `document`, `fetch`, WebSocket, filesystem ou TauriBridge. Timeout encerra o Worker sem derrubar Play.

Estado é `GameNode × BehaviorInstance`; callbacks/Workers pertencem à RuntimeSession e são destruídos no Stop/Restart/troca de cena/hot-reload. Escritas de runtime não entram no CommandManager e somem no Stop. Não existe `EditorApi` nem plugin do editor (v4.7.0). Os executores nativos de `src/logic/<tipo>/<id>/runtime.ts` são código do editor (confiável) e não passam pelo Worker, mas usam a mesma `EngineApi` restrita do AIS-78c.

## 4. Diretrizes técnicas

1. **Prioridade de segurança sobre conveniência:** Em caso de dúvida entre uma API mais poderosa e uma mais restrita, aplique PARE E PERGUNTE e recomende a mais restrita.
2. **Bloqueio de dependência:** a ação `run_script` permanece desabilitada ("em breve") até este prompt estar concluído e validado.

Se houver qualquer incompatibilidade ou dúvida arquitetural durante a execução, aplique **PARE E PERGUNTE** (ver `CLAUDE.md`): pare, descreva o problema com opções A/B/C e recomendação técnica, e aguarde a resposta do usuário antes de continuar.

---

## 5. Critérios de aceite (verificáveis por `npm run check` e no navegador)

- [ ] **AIS-79-C01** Um script de teste que tenta acessar `window.parent`/`document` a partir do sandbox falha silenciosamente ou é bloqueado, sem derrubar o Play Mode.
- [ ] **AIS-79-C02** Scripts de `run_script` (e scripts anexados a nós) só executam dentro do sandbox.
- [ ] **AIS-79-C02b** A ação `run_script` (desabilitada desde o AIS-41) é **habilitada aqui**, ligada exclusivamente ao sandbox; o tooltip "em breve" é removido.
- [ ] **AIS-79-C03** `npm run check` passa e o editor (`npm run dev`) carrega no navegador e permanece **sem erros no console** (zero erros vermelhos) durante toda a interação com a funcionalidade.
- [ ] **AIS-79-C04** O comportamento descrito na Especificação é **visível e operável no navegador** (`npm run dev`), exercitado manualmente do início ao fim.
- [ ] **AIS-79-C05** Nenhuma funcionalidade pré-existente da casca regrediu (TopBar, SceneTree, FileSystem, Viewport 3D, Inspector, BottomPanel e modais).
- [ ] **AIS-79-C06** As confirmações com o usuário listadas neste prompt foram respondidas **antes** da implementação (PARE E PERGUNTE), sem decisão silenciosa.
- [ ] **AIS-79-C07** Log `docs/logs/AIS-79.md` gravado ao concluir (formato no `CLAUDE.md`), com arquivos, decisões, resultado de cada critério e pendências.
- [ ] **AIS-79-C08** A Action `run_script` **executa** (executor em `src/logic/actions/run_script/runtime.ts`, só pelo Worker) e deixa de estar desabilitada; a entrada `action:run_script` sai de `DISABLED_OWNERS` em `src/logic/executorCoverage.test.ts` (regra do AIS-59c).

## 6. Contexto de domínio (skills embutidas)

Conhecimento de domínio a seguir; onde a especificação citar uma skill, a regra dela está aqui.

### SKILL: nodimus-sandbox-seguranca

- CSP permanece sem `unsafe-eval`; `eval` e equivalentes são proibidos.

# Sandbox e segurança

> **Dono de:** política de confiança para código do usuário e superfícies de entrada não confiáveis.
> Cobre a skill `editor3d-sandbox-seguranca` que o README de 02 lista sem arquivo. Origem: `06 §6.3`,
> `10 §10.5`, `12 §12.4`, auditorias A2-01/02 e I4/Auditoria 3 (CSP).

## 1. Modelo de confiança honesto

Scripts customizados do projeto **não rodam no mesmo contexto do frontend**; usam exclusivamente o Web Worker definido neste prompt.
No Tauri Desktop e no preview web, chamadas ao sistema passam pelas permissões estritas da ponte `tauriBridge.ts`.
Portanto:
- O isolamento por **Web Worker** é obrigatório para código executável de projeto; não é opcional nem fica fora do escopo.

## 2. Mitigações mínimas (obrigatórias)

1. **Confirmação explícita** antes de rodar script vindo de fora (script dentro de prefab `.zip`,
   projeto importado): listar arquivo/nome e só então copiar.
2. **Isolamento de erro:** `try/catch` em torno de cada callback de Behavior/Action/script; falha marca o
   item e loga; nunca derruba o loop nem o editor.
3. `executeScript` expõe **só** `{ name, state, setColor }` em `entity` e `pushLog` em `log`; sem `window`,
   `document`, `fetch` por contrato (é convenção, não barreira — ver §1).
4. **Acesso entre entidades** só pela `EngineApi` (por id/tag), nunca por referência direta a `Object3D`.
5. **Entradas não confiáveis** (projeto `.zip`, prefab, glb, nomes de arquivo): validar com Zod; nomes passam
   por `resolveInside` (`nodimus-projetos-workspace`); nunca `innerHTML` com texto do usuário.

## 3. CSP

- Execução de código usa **Web Worker isolado + mensagem estruturada + EngineApi segura + Command Buffer validado pelo host**. `new Function` é proibido.
- CSP permanece sem `unsafe-eval`; `eval` e equivalentes são proibidos.
  **pré-compilar** todo script inline em módulo no build (esbuild) e referenciá-lo por id; a Action publicada
  chama a função já compilada.
- Fullscreen/Pointer Lock: **não engolir a rejeição** da promise (`nodimus-web-features`).

## 4. Fora de escopo

Extensões/plugins de terceiros (não existem no produto — v4.7.0); assinatura de código.

## Definição de "pronto"

- Script que lança exceção não para o Play; aparece marcado com erro.
- Importar prefab com script pede confirmação listando o código a copiar.
- CSP permanece sem `unsafe-eval`; `eval` e equivalentes são proibidos.

---

### SKILL: nodimus-play-mode

> Play Mode do Nodimus 3D Studio: Play/Pause/Stop/Restart dentro do editor sobre cópia em memória da Scene, ordem do tick (input → mixers → behaviors → física → sincronização → render), passo fixo de física, teardown completo (world.free, listeners, áudio, DOM, loop), regra de 5 ciclos idênticos e o runtime compartilhado com o Publish. Use ao implementar/depurar teste de cena no editor ou o ciclo de vida do runtime.

# Play Mode e ciclo de vida do runtime

> **Dono de:** Play/Stop/Pause/Restart, isolamento da edição, ordem do tick, teardown. **Depende de:**
> `nodimus-catalogo-behaviors-actions`, `nodimus-fisica-rapier`. Corrige achados A2-06/I4-05 e D-01.

## 1. Runtime compartilhado (decisão estrutural)

O Play e o bundle publicado usam **o mesmo motor** em `src/runtime/*` (transforms, hierarquia, materiais,
sprites, overlays, câmera, eventos, mídia, dispatcher). Editor e Publish só diferem em **renderizador de UI,
carregamento de assets e ciclo de vida**. Nunca reimplemente lógica inline no gerador de publish — foi
exatamente assim que nasceram as divergências de sprite sem loop e âncora de overlay
(`nodimus-auditorias-remediacao`).

## 2. Botões

- **▶ Play:** congela a edição (Inspector/Scene Graph só leitura, gizmos somem), ativa a câmera marcada ativa,
  executa Behaviors/Actions de verdade, captura teclado/mouse do viewport para o jogo.
- **Stop:** restaura a Scene **exatamente** como antes do Play (nada do teste persiste).
- **Pause/Resume:** **realmente pausa** — para o passo de física, mixers de animação, timers de Behaviors,
  `Every few seconds`, áudio/vídeo (suspende) e contadores; a câmera do editor não assume.
- **Restart:** recomeça do zero sem sair do modo de teste.

## 3. Isolamento

O loop roda sobre **cópia em memória** do estado (nunca escreve no store original). Toda mutação de runtime
usa a via `applyRuntimeMutation` (`nodimus-undo-redo-commandstack` §3). Por isso Stop restaura sem `undo`.

## 4. Ordem do tick (por frame)

1. `InputManager` lê dispositivos.
2. `mixer.update(dt)` de cada `AnimationMixer` (antes de `onUpdate`, para `#obj.progress` já atualizado).
3. Triggers/Behaviors (`onAnimate`, `onUpdate`, `onKeyEvent`…) — **só emitem intenção** de movimento.
4. Física `beforeStep` (aplica intenção: KCC para `character`, velocidades) → **passo fixo** (`world.step`,
   acumulador de 1/60 s; não use `dt` variável direto) → `afterStep` (drena eventos, sincroniza poses).
5. Câmera ativa, overlays/HUD, `renderer.render`.
6. Debug overlay (`nodimus-debug-overlay`).

## 5. Teardown (`dispose` completo)

Ao parar/reiniciar: cancelar o `requestAnimationFrame`/`setAnimationLoop`; `world.free()` (+ `EventQueue.free()`
e controllers removidos); descartar mixers e `PositionalAudio`/`AudioContext` do jogo; remover listeners
(teclado, mouse, gamepad, resize); remover DOM de HUD/`EditBox`; `dispose()` de geometrias/materiais/texturas
**criados pelo Play** (não os do projeto); esvaziar registros (`bodyRegistry`, `animationMixerRegistry`,
`audioRegistry`); descartar `cache` de eventos. Cada Play/Restart cria um **mundo Rapier novo**; em edição não
existe mundo.

## 6. Critérios de aceite (auditoria F1–F5)

- **5 ciclos Play/Stop são idênticos** (contagem de listeners, objetos na cena, memória de texturas estável).
- Pausar congela de fato (nenhum corpo se move).
- Bootstrap/dispose sem duplicação (dois Plays seguidos não geram dois loops).
- O runtime publicado é isolado do editor (não importa nada de `src/ui`).

## 7. Fora de escopo

Multiplayer/rede. O Play dentro do bundle publicado é o runtime de produção, sem a cópia de isolamento.

## Definição de "pronto"

- Mover um objeto por Action durante o Play e dar Stop devolve a posição original.
- Teste automatizado repete Play/Stop 5× e compara contagens.
- **Fronteira EngineApi (v6.9):** teste que percorre `ENGINE_OPERATIONS` e confirma que (a) toda operação `marshalable` e segura em Play é alcançável do Worker, (b) nenhuma operação fora do catálogo é, (c) `physics.bridge` e objetos vivos não cruzam, (d) escrita com dono feita por script sem dono falha com `<grupo>.no_owner`, (e) `engineBoundary.test.ts` continua verde (nenhum `extra`, allowlist de imports vazia).
- O Worker não reimplementa a EngineApi: o host chama a **mesma** `buildEngineApi(host, owner, selfNodeId, behaviorId)` do runtime e só faz o marshal.

---

### SKILL: nodimus-engine-api (resumo; dono: AIS-78c/78d — contrato vivo: `src/runtime/engineApi.ts`, EngineApi 1.4)

> A lista antiga (`getNodeProperty`, `setNodeProperty`, `getNodesByTag`, `getMousePos`, `registerOnFrameEvent`, `invokeAction`) **não existe** e não deve ser implementada. O Worker expõe um **subconjunto marshalável** da EngineApi real.

- **Fonte única:** `ENGINE_OPERATIONS` (`src/runtime/engineApi.ts`). Cada operação declara `sync|async`, `marshalable`, segurança em Play/Publish, `since` e `requires`. O Worker só recebe as operações com `marshalable !== false`, seguras em Play (ex.: `physics.bridge` e qualquer objeto vivo ficam de fora). Nada é copiado para uma lista paralela: se a operação não está no catálogo, não existe para o script.
- **EngineApi 1.5 (este prompt):** `scripts.run` (a Action `run_script` pelo sandbox) é **host-only**: `marshalable: false`, segura só em Play (`safeIn.publish: false` até o publish empacotar scripts). Um script não chama script. Está no catálogo, mas **não** é exposta ao Worker.
- **Grupos da API (1.0–1.4, marshaláveis):** `nodes` (`resolve`, `get`, `getProperty`, `behaviorProperties`), `transform`, `variables`, `signals`, `input`, `physics` (raycast/overlap/eventos), `audio`, `particles`, `animation`, `sprites`, `tweens`, `scene`, `weapons`, `camera`, `materials`, `ai`, `hooks`, `routes`, `diagnostics`, `random`, `frame`, `text`, `ui`, `motion`, `after`. Handles por ID estável (`persistentNodeId`); dados são cópias JSON.
- **Dono e escrita:** operações com dono (`ai.*` de escrita, `camera.publish`, `locomotion.set`, `hooks.fire`, `frame.onUpdate/onInput`) só valem para o nó/Behavior dono do script (`InvocationScope`). Script sem dono recebe o código estável `<grupo>.no_owner`; serviço ausente devolve `<grupo>.unavailable`. O Command Buffer repassa esses erros, não os engole.
- **Versão:** o Worker chama `negotiateEngineApi` na partida (major, minor, features) e falha de forma explícita se o contrato não casar.
- **Assinaturas** (`signals.connect`, `physics.onEvent`, `frame.onUpdate`) devolvem disposer no host; no Worker viram `subscriptionId` + callback por mensagem, e todos morrem com o Worker (Stop/Restart/troca de cena/hot-reload).
- **Consulta por tag:** não existe na EngineApi 1.4. Se o AIS-81 já tiver acrescentado `nodes.byTag` (1.6; a 1.5 é do `scripts.run` deste prompt), ela entra pelo mesmo catálogo; senão, não invente.

---

### SKILL: nodimus-canon-governanca

> Autoridade e governança do Nodimus 3D Studio: regra de ouro (só o dono de um assunto define a regra), decisões-base já fechadas (não reabrir) adaptadas à stack web-first, mapa assunto → skill dona, estados de evidência e regra 'nada fictício'. Leia primeiro, antes de qualquer outra skill nodimus-*. Substitui o 00-CANON do conjunto legado (GameLand) sem tocar nas skills editor3d-*.

# Nodimus 3D Studio — Canon (autoridade e decisões-base)

> Origem: consolidação do `00-CANON.md` do conjunto 01, limpo do produto antigo (GameLand/Electron/R3F)
> e reescrito para a stack de 02. **Dono de:** hierarquia de autoridade entre skills, decisões-base,
> mapa assunto→skill. **Não é dono de:** nenhuma regra de produto (essas vivem nas skills-donas).

## Regra de ouro

Só o dono de um assunto define a regra sobre ele. Qualquer outra skill que toque o tema **referencia
o dono, nunca redefine**. Se você precisa afirmar uma regra e ela não está na skill dona: **pare**,
escreva a regra na skill dona e referencie-a de onde estava.

## Ordem de precedência quando há conflito

1. O `CLAUDE.md` (decisões canônicas) e `nodimus-stack-versoes` (versão/import de biblioteca = lei).
2. A skill dona do assunto (tabela abaixo).
3. As skills `editor3d-*` do conjunto 02 — continuam válidas como visão resumida; **onde houver
   conteúdo divergente, vale a versão nodimus-*** (decisão do usuário: 01 limpo prevalece).

## Decisões-base

As decisões canônicas vivem **somente** no `CLAUDE.md` (`CLAUDE.md`). Esta skill não as repete nem as numera; em caso de conflito, valem o `CLAUDE.md`.

### Mudanças deliberadas em relação ao conjunto legado
- **Editor Estritamente Desktop**: Foco em produtividade com mouse, teclado e docked layout; sem concessões móveis no editor.
- **Sistema de Arquivos `res://`**: `res://scenes/`, `res://textures/`, `res://materials/`, `res://audio/`, `res://scripts/`.
- Assets originais do CopperCube (`default_skyboxb*.jpg`, ícones PNG, sons): usar equivalentes próprios ou procedurais livres.

## Mapa assunto → skill dona

| Assunto | Skill |
|---|---|
| Stack, versões, imports | `nodimus-stack-versoes` |
| SceneData/GameNode, Inspector, recursos em cena | `nodimus-scenegraph-modelo` |
| CommandManager, contrato de mutação | `nodimus-undo-redo-commandstack` |
| Seleção múltipla, snaps | `nodimus-multiselecao-snap` |
| Helpers de Câmera/Luz/Som/áreas | `nodimus-helpers-visuais` |
| Workspace, projeto em disco, Resource Tree, save | `nodimus-projetos-workspace` |
| Import de mesh → `.glb` | `nodimus-importador-assets` |
| Câmera/Luz/Sombras (nós) | `nodimus-cameras-luzes` |
| Shell, menu, toolbar, abas, ContextMenu | `nodimus-shell-interface` |
| Tokens visuais + dark mode | `nodimus-design-tokens-tema` |
| i18n | `nodimus-i18n` |
| Ícones | `nodimus-iconografia` |
| Preferences | `nodimus-preferences-dialog` |
| Lista de Actions (Visual Logic) | `nodimus-visual-logic-editor` |
| Catálogo nativo em pastas (`src/logic/`) | `nodimus-logic-pastas` |
| Segurança de execução | `nodimus-sandbox-seguranca` |
| Input | `nodimus-input-manager` |
| Catálogo de Behaviors/Actions | `nodimus-catalogo-behaviors-actions` |
| Câmeras de jogo + colisão do personagem | `nodimus-controle-camera-colisao` |
| Play/Stop/Pause | `nodimus-play-mode` |
| Variáveis | `nodimus-variaveis` |
| Scenes múltiplas | `nodimus-scene-management` |
| Debug overlay | `nodimus-debug-overlay` |
| Materiais/texturas | `nodimus-materiais-pbr` |
| HUD/overlay, widgets | `nodimus-gui-hud-uikit`, `nodimus-ui-widgets` |
| Som, vídeo | `nodimus-som`, `nodimus-video` |
| Billboard/Hotspot | `nodimus-billboards-hotspot` |
| Sprite/spritesheet | `nodimus-sprite-editor` |
| Skybox | `nodimus-skybox-cubemap` |
| Animação | `nodimus-animacao` |
| Prefabs | `nodimus-prefabs` |
| Terreno/árvore, água, partículas | `nodimus-terreno-arvore`, `nodimus-agua`, `nodimus-particulas` |
| Publish, web features | `nodimus-publicacao-web`, `nodimus-web-features` |
| Física (núcleo, actions/eventos, 2D) | `nodimus-fisica-rapier`, `nodimus-fisica-actions-eventos`, `nodimus-fisica-2d-plano` |
| Armas, movimento 2D, IA, navmesh, veículos | `nodimus-armas-projeteis`, `nodimus-controladores-movimento-2d`, `nodimus-game-actor-ia`, `nodimus-pathfinding-navmesh`, `nodimus-veiculos-aeronaves` |
| Testes e Definition of Done | `nodimus-testes-metodologia` |
| Prontidão de produto | `nodimus-prontidao-produto` |
| Correções das auditorias | `nodimus-auditorias-remediacao` |
| Versionamento de schema | `nodimus-versionamento-cena` |
| Deploy do editor | `nodimus-deploy-editor` |

## Estados de evidência (vale para qualquer afirmação de status)

`Respondida` (teste reproduzível) · `Parcial` (um caminho funciona, alvo/integração sem prova) ·
`Não respondida` (há código/doc, sem execução) · `Bloqueadora` (impede declarar utilizável) ·
`Fora do alvo atual` (deve estar desabilitada ou sinalizada). **Não usar "implementado", "suportado" ou
"pronto" só porque existe componente, manifest, botão ou schema.**

## Nivelamento definitivo — execução segura sem regressão

- Execução de código usa **Web Worker isolado + mensagem estruturada + EngineApi segura + Command Buffer validado pelo host**. `new Function` é proibido.

## SPECs relacionadas

- [code-editor-workspace.spec.md](../specs/telas/code-editor-workspace.spec.md)
- [code-mirror-editor.spec.md](../specs/componentes/code-mirror-editor.spec.md)
- [script-editor-modal.spec.md](../specs/modais/script-editor-modal.spec.md)
