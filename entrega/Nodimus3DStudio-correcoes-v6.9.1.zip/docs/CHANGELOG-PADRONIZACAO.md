## v6.9 — Alinhamento dos prompts 79–85c após AIS-75 a 78d

**Gatilho:** os logs de AIS-75, 76/76b, 77, 78c e 78d (EngineApi 1.0→1.4, contextos 100% derivados, `ActorRegistry`, `CapabilityRegistry`).

| # | Achado | Correção |
|---|---|---|
| 1 | AIS-79: skill `nodimus-engine-api` listava API inexistente (`getNodeProperty`, `getNodesByTag`, `invokeAction`…) | reescrita sobre `ENGINE_OPERATIONS` (`marshalable`, `sync/async`, dono, `negotiateEngineApi`); critérios de fronteira; CSP deduplicada |
| 2 | `getNodesByTag` citado em prompts, mas nunca existiu | AIS-81 cria `nodes.byTag` (EngineApi 1.5); CLAUDE.md decisão 32 registra; prompts já executados ficam como histórico |
| 3 | AIS-85/85b/85c previam matriz de capacidades própria | passam a consumir `src/core/capabilities.ts` (`resolveSupport`, `unsupportedFor`, `TARGET_PROFILES`) |
| 4 | AIS-85 sem menção ao debug overlay (AIS-77) | §1.1: overlay só de Play, fora do bundle |
| 5 | AIS-83/84 citavam `SpriteAsset` (não existe) | trocado por `SpriteProject` (AIS-76) |
| 6 | Preâmbulo "decisões 1–30/1–20" nos prompts 79–85c | "as numeradas no CLAUDE.md, até a 32" |
| 7 | CLAUDE.md apontava a "regra 9" para a lista de `NodeType` | decisão 19 |
| 8 | Incidente do AIS-78c (arquivo existente sobrescrito por "CRIAR") | regra 2 do CLAUDE.md: conferir existência antes de criar |
| 9 | `node.spec.md` descrevia o `AiService` removido no AIS-78d | atualizado (`ActorRegistry`, `state.memory.brain`) |
| 10 | AIS-77 concluído sem C06–C08 (emenda v5.8) | log reaberto como pendente |
| 11 | (v6.9.1) o AIS-79 em andamento usou a EngineApi 1.5 para `scripts.run` | `nodes.byTag` (AIS-81) passa à 1.6; `scripts.run` documentado como host-only no AIS-79 |

Sem prompt novo: a ordem e os cabeçalhos de posição não mudam.

## v5.9 — Câmera independente do movimento (decisão 28)

**Gatilho:** os controladores 1P/3P do AIS-47 misturam locomoção e câmera, a câmera ativa era "a última pose do Map" e o AIS-73 exigia a câmera 3P como parte do veículo.

| # | Achado | Correção |
|---|---|---|
| 1 | Movimento e câmera acoplados | **decisão 28** (CLAUDE.md) + novos **AIS-47b** (extração do rig, sem mudança visível), **AIS-47c** (Behaviors de movimento × câmera, diálogo "Create a new Camera", comando "Separar câmera…") e **AIS-47d** (Free Flying, Model Viewer, Panorama, RTS) |
| 2 | Veículo dono/requisito da câmera | emendas no **AIS-73** (câmera é `camera_third_person` opcional) |
| 3 | Estado de câmera/locomoção sem dono | emendas no **AIS-44b/44c** (estado transitório; host só apresenta; follow implícito mantido) |
| 4 | Entradas de câmera × locomoção × condução | emenda no **AIS-58** |
| 5 | Estado de locomoção sem consumidor | emenda no **AIS-60** |
| 6 | Câmeras 2D sem dono | emenda no **AIS-75** |
| 7 | AIS-47 já executado | emenda que preserva o composite como legado (sem reescrever histórico) |

Ordem: +3 posições (AIS-47b/c/d nos nº 79–81); posições ≥ 79 deslocadas em +3; total: **127 posições**.

## v5.8 — Pendências do AIS-32c

**Gatilho:** o log do AIS-32c deixou cinco pendências sem dono explícito nos prompts.

| # | Pendência | Correção |
|---|---|---|
| 1 | C02 (descarte por sessão) só testado com sessão simulada | emenda no **AIS-44b** (Stop chama `clearSession`; C08/C09) |
| 2 | C04 (`hasBlocking`) só testado | emendas no **AIS-44c** (Play, C11/C12) e **AIS-85b** (Publish, C08/C09) |
| 3 | `legacyPhysicsWarning` sem chamador; códigos `physics.*` sem publicador | emenda no **AIS-45** (C11/C12) |
| 4 | `RuntimeDiagnostic` do AIS-48b conflitava com o contrato do serviço | emenda no **AIS-48b** (C07): tipo único |
| 5 | Sem aba "Problemas" e `onSaveError` fora do serviço | emenda no **AIS-77** (C06–C08): aba, `project.save_failed` e `onSaveSuccess` |

Sem prompt novo: a ordem e os cabeçalhos de posição não mudam.

## v5.7 — Consumidores das Configurações do Projeto (AIS-44d)

**Gatilho:** o log do AIS-32b registrou que vários campos de `ProjectSettings` (`display.*`, `rendering.*`, `physics.defaultLinearDamp`, `audio.*`) são **gravados e nunca lidos**, e nenhum prompt posterior declarava a leitura. Os campos `windowMode`, `shadowQuality` e `hdr` já existem no schema (AIS-32b); faltava o **leitor**.

| # | Achado | Correção |
|---|---|---|
| 1 | Sem leitor para `rendering.shadowsEnabled/shadowQuality/clearColor/hdr/msaa` e `display.width/height` (a viewport usava valores fixos e o `Environment`) | **AIS-44d** (novo, nº 75): `resolveRenderSettings` (função pura, única leitora) aplica ao Play; padrões reproduzem a aparência atual (decisão 4a) |
| 2 | Controles do `ProjectSettingsModal` sem efeito (violavam a decisão 14) | AIS-44d marca como desabilitados "em breve — <AIS dono>" os campos ainda sem leitor |
| 3 | `physics.defaultLinearDamp` sem dono | emenda no **AIS-45** (PhysicsBridge) |
| 4 | `audio.master/music/sfxVolume` sem dono | emenda no **AIS-52** (mixer) |
| 5 | `hdr`/`msaa` sem coordenação com o pós-processamento | emenda no **AIS-55**: um só pipeline (EffectComposer) |
| 6 | `windowMode` e `fullscreen` legado sem consumidor | emendas no **AIS-85** (Web: Fullscreen API exige gesto) e **AIS-85c** (janela Tauri: `windowMode`, tamanho, `resizable`, `orientation`, `vsync`); só `windowMode` é lido |
| 7 | Sem lugar que dissesse quem lê cada campo | tabela "Dono de cada campo de `settings`" na `ORDEM-CANONICA-V4.md`; SPEC `project-settings-modal` ganhou a emenda v5.7 |

| 8 | Revisão de sequência (v5.7): **AIS-38b** (nº 55) tinha critérios C02/C04 (descarte por `RuntimeSession`, bloqueio de Play/Publish) que dependem de prompts posteriores (AIS-44b/44c/85b) | C02/C04 passam a ser verificados por **teste** nesta posição (sessão simulada; consulta `hasBlocking`); integração real nos prompts donos |
| 9 | **AIS-44d**: opção A do `msaa` pressupunha o composer do AIS-55 (posterior) | opção **C é o padrão** até o AIS-55; A vira integração futura; `hdr` usa só o renderer existente |
| 10 | **AIS-29e** (nº 49) listava o AIS-38b (nº 55) em "Depende de" | movido para "Integração futura" (adapter mínimo até o 38b) |
| 11 | **AIS-32** (nº 53) listava o AIS-32b (nº 54) em "Depende de"; `applyProjectName` nasce no 32 | AIS-32b vira "Integração futura"; texto diz que a função é criada no AIS-32 e reutilizada no 32b |
| 12 | **AIS-47** citava "input lógico do AIS-58" (posterior) | corrigido para o `InputManager` core do AIS-40b; AIS-58 só amplia |

| 13 | **ID fora da vizinhança:** o `AIS-38b` ocupava o nº 55 (entre `AIS-32b` e `AIS-33a`), mas o ID sugeria depois do `AIS-38` | **renomeado para `AIS-32c`** (mesma posição, mesmo conteúdo): arquivo `AIS-32c-diagnostic-service.md`; referências atualizadas em ORDEM, 13 prompts, SPECs, MATRIZ, `CLAUDE.md`, skills, logs e comentários de código. Menções a "AIS-38b" nas entradas v5.6 e anteriores deste arquivo são históricas e valem para o `AIS-32c` |

**Contagem:** posição nova no nº 75; posições ≥ 75 deslocadas em +1; total **124**. Cabeçalhos "nº X de N" regravados a partir da ordem; `ais-check-docs` verde. Nenhum código da aplicação mudou nesta revisão.

## v5.6 — Realinhamento da ingestão 3D (AIS-33a, AIS-38c; AIS-33 a 38 revisados; AIS-38b movido)

**Gatilho:** auditoria do pacote v5.0.0 ao chegar no AIS-33: o `AssetImportModal` (2375 linhas) só trabalhava com modelos de exemplo (agora eliminados) — "Carregar Arquivo…" e o drop guardavam só o **nome**, a importação criava um `MeshInstance` sem geometria nem referência, e **nenhum prompt (33–37, 60, 61b, 45, 81, 85) previa o carregamento do modelo**. Opção adotada: **A — carregar de verdade** (decisão 27).

### Inconsistências, gaps e redundâncias corrigidos
| # | Achado | Correção |
|---|---|---|
| 1 | Nenhum loader 3D no projeto; AIS-34–37 pressupunham modelo carregado | **AIS-33a** (novo): `loadModel`, `modelCache`, `createModelObject`, `MeshInstance.model` |
| 2 | Duplo clique em modelo abre o modal **sem arquivo** (`openFile → setIsAssetImportModalOpen(true)`); só o drop do AIS-31 pré-carrega | AIS-33 §3.3: todos os caminhos entregam os bytes ao mesmo `loadModel` |
| 3 | `res://models/` (código, AIS-33) × `res://meshes/` (bloco embutido em 18 prompts e na estrutura do AIS-03b/AIS-81); "`.glb` convertido" sem decisão de conversão | pasta canônica `res://models/`, original preservado; bloco corrigido nos 18 prompts + AIS-03b/81 |
| 4 | "Excluir nó de mesh não apaga o `.glb` (sem reference-counting)" já superado por AIS-29c/29e | texto atualizado (apagar arquivo passa por `deleteResource`) |
| 5 | Emenda v5.5 do AIS-33 dizia que o importador "não carrega geometria", mas "Malha exata" (decisão 26, AIS-45) exige geometria real | emenda removida; AIS-33a entrega a geometria; AIS-45 ganhou emenda |
| 6 | Modal ainda grava `_material.json`/`_rig.json` **fabricados a partir dos exemplos**, sem schema/`ResourceRef` | AIS-33 remove; AIS-35/36/37 reintroduzem com dados reais + Zod (`ModelMaterialManifest`, `RigConfig`) |
| 7 | AIS-35 trazia um "PARE E PERGUNTE" sobre `textures/<asset>_material.json` × `materials/<nome>.mat.json` ainda aberto | resolvido pela decisão 3: manifesto de extração ≠ material autoral (AIS-35 §2–3.3) |
| 8 | AIS-36/37 afirmavam que `AnimationPlayer` não existe em `NodeType`; ele existe em `registry.ts`, com `rigConfig` `type 'file'` apontando para `res://materials/rig.json` (inexistente → sempre `unresolved`) | notas corrigidas; `rigConfig` vira `ResourceRef` com padrão vazio (AIS-36) |
| 9 | "5 abas" (prompt) × "6 abas" (skill) × `activeTab` com `animation`+`player` separadas; AIS-34 chamava a aba de "Transform" | 5 abas canônicas fixadas no AIS-33 §3.2; Referência Humana vive na aba 1 |
| 10 | Quiz: especificação pede **scanner automático**; o código tem 4 **perguntas manuais** | AIS-38 reescrito: scanner + `DiagnosticService`; perguntas só para o ambíguo |
| 11 | AIS-38b (DiagnosticService) vinha **depois** da cadeia 33–38, que já precisava dele ("adapter provisório") | **AIS-38b movido** para o nº 55 |
| 12 | Modal monolítico (2375 linhas) editado por 6 prompts em sequência (regra 10 proíbe reescrever) | AIS-33 §3.1 divide em `assetImport/` + `core/modelImport/` sem mudança visual |
| 13 | Ciclo de vida do modelo incompleto: sem reabrir/editar importação, trocar modelo, reimportar, excluir pacote | **AIS-38c** (novo) |
| 14 | `AssetPipeline`/`ResourceRegistry`/`DependencyGraph` não eram consumidos pelo import (log do AIS-28c: pendência) | AIS-33 §3.5 e AIS-33a §3.6 |
| 15 | Cota de ≈ 5 MB do `localStorage` inviabiliza modelos grandes na web | decisão do usuário: desktop é o alvo; arquivos reais via `ProjectFolder`; sem tratamento especial da web |
| 16 | Calibração/materiais/rig/clipes sem lugar definido para persistir; risco de formato `.anim` paralelo | `ModelImportSettings` (AIS-33a) estendido de forma aditiva; clipes por referência em `RigConfig.clips` (AIS-37) |
| 17 | Gizmo próprio do modal × Gizmo da viewport (AIS-08); duas definições da régua (0.5 m × marcas 0.5/1.0/1.5/1.8/2.0) | AIS-34 §3.2–3.3: gizmo só edita o rascunho; régua a cada 0.5 m |
| 18 | AIS-60 (player) e AIS-61 (timeline) sem dependência explícita do rig/clipes e com risco de segundo mixer; `blendTimeMs` × `crossfadeDuration` (s) | emendas em AIS-60/61; um só `skeletalAnimation.ts`; unidade em segundos |
| 19 | AIS-61b ("Importar GLB") sem exigir carga/persistência reais | critérios C19–C22 |
| 20 | "Preferência do editor" de colisão do importador sem lugar (AIS-82 só existe depois) | `localStorage` (como tema/idioma) até o AIS-82 |
| 21 | Preâmbulo "decisões canônicas (1–22)" em 96 prompts (hoje vão até 27); `CLAUDE.md` com linha de tabela quebrada (`$1|`); regra 7 contradizia `package.json` (`@tauri-apps/*` já instalados) | corrigidos |
| 22 | `MATRIZ-PROMPT-SPEC-CASCA.md` e `RELATORIO-BLOQUEIOS.md` com nº de posição defasados (desde v5.1) | números regravados pela ORDEM; AIS-33a/38c entram na matriz |
| 23 | Este CHANGELOG não registrava a v5.5 (AIS-26b) | registrada abaixo |

### Auditoria das Fases E–H (nº 64–123)
Varredura de dependências (cada prompt só consome contratos de prompts anteriores): sem violações reais; as citações a prompts posteriores já são notas de "integração futura" (AIS-44→44b, AIS-47→58, AIS-41→76/76b, AIS-80↔82). Redundância removida: o bloco "Item 1/2/3 — Opção A/C/A" (65 prompts, duplicava as decisões 1–3 do `CLAUDE.md` com rótulos legados) virou uma linha de ponteiro. Sem prompt eliminado: todos têm escopo próprio.

### Nova sequência (Fase D, nº 55–63)
`AIS-38b → AIS-33a → AIS-33 → AIS-34 → AIS-35 → AIS-36 → AIS-37 → AIS-38 → AIS-38c` (total: **123 posições**; posições ≥ 64 deslocadas em +2).

### Decisões do usuário (v5.6)
- **Modelos de exemplo do modal eliminados** (AIS-33 §3.3); sem arquivo, importar fica desabilitado.
- **Desktop é o alvo:** armazenamento de binário na web não é o modelo padrão; sem limite/IndexedDB (AIS-33a §3.2). Código `model.too_large_for_web` descartado.
- **`materialSlots` por nome** (AIS-35) e **biblioteca de clipes por referência** (AIS-37): aceitos.

## v5.5 — Colisão do objeto (registro retroativo)
AIS-26b inserido na posição 40 (decisão 26; `PLANO-FISICA-COLISAO-v2.md`); tipos `StaticBody`/`RigidBody`/`KinematicBody`/`Area`/`CollisionShape` eliminados; emendas v5.5 em AIS-33, 38b, 45 e correlatos; total 121 posições.


## v5.4 — UI estilo Godot: AIS-25b revisado e AIS-25c novo (2026-10-01)
- **AIS-25c** inserido na posição 38 (Containers e controles de UI estilo Godot sobre UIKit, antes uma emenda do AIS-25b); total **120 posições** (posições ≥ 38 deslocadas em +1; cabeçalhos "Posição canônica" regravados).
- **AIS-25b** passa a cobrir só o motor UIKit e o layout de Controls (âncoras + offsets, Layout Presets do Godot, mantendo as chaves `posX/posY/width/height/alignment`); o motor de eventos (dispatcher, `on_start/on_update/on_click/on_hover`, Actions `change_text/change_texture`) foi para o AIS-44/AIS-44c/AIS-41.

## v5.3 — Revisão de numeração, links e índices (2026-10-01)
- Novos **AIS-18d** (posição 29) e **AIS-76b** (posição 106); total **119 posições**.
- Todos os cabeçalhos "Posição canônica" (nº, total, anterior, próximo, fase) regravados a partir de `ORDEM-CANONICA-V4.md`; AIS-AP ganhou o seu.
- Referências "Prompt NN" (numeração original) convertidas para IDs `AIS-NN`; as posições citadas no corpo (`nº N`) e na `MATRIZ-PROMPT-SPEC-CASCA.md` regravadas; os sub-passos do apêndice Tauri passaram de `AIS-00/62/63/65/66/67` para `AP-00/62/63/65/66/67` (sem colisão com IDs reais).
- Índice de SPECs completo (`terrain-sculpt-section`), link quebrado de `editor-context.spec.md` corrigido.
- Script de verificação: `node scripts/ais-check-docs.mjs` (cabeçalhos, IDs e links).

# v5.1.2 — divisão AIS-50 / AIS-50b (geração × edição de terreno)

## Decisão do usuário (01/10/2026)
- AIS-50 fica só com geração (modal Gerar + Texturas, presets, heightmap PNG, colisão, `sampleHeight`); a escultura/pintura vira o **AIS-50b**, na posição 77.
- Buffer editado em `res://terrain/<nome>.height` (binário com cabeçalho; ResourceRegistry + DependencyGraph + AIS-29e). Reabrir o modal após escultura não regenera geometria; "Regenerar geometria" é explícito e descarta a escultura.
- Atalhos do modo terreno: `[`/`]` raio, `Shift` inverte, `Esc` sai; gizmo e W/E/R/F bloqueados.

## Arquivos criados
- `docs/prompts/AIS-50b-edicao-terreno-inspector-viewport.md`
- `docs/specs/componentes/terrain-sculpt-section.spec.md`

## Arquivos alterados
- `AIS-50` (sem escultura; Regenerar geometria; contrato `.height`; C14), `AIS-49b`, `AIS-51` (+ posições de AIS-51a–d), `AIS-51d`, `AIS-72` (nota na skill histórica), `ORDEM-CANONICA-V4.md` (posições ≥ 77 +1; total **116**), `prompts/README.md`
- SPECs: `terrain-editor-modal`, `inspector-panel`, `viewport-3d`, `state-architecture`; `MATRIZ-PROMPT-SPEC-CASCA.md`

## Ajustes em relação ao plano original
- A seção do Inspector depende de `node.type === 'Terrain'` (não de `generatorSource.generatorId`).
- `sampleHeight` e `normalAt` ficam em `terrainGeometry.ts` (uma só implementação); `terrainBrush.ts` os importa.
- `ManipulationMode` real é `'select' | 'translate' | 'rotate' | 'scale'`; ganha `'terrain'`.

---

# v5.0.0 — migração do Google AI Studio para o Claude Desktop (Claude Code)

## Decisões do usuário (30/09/2026)
- Superfície: **Claude Code** (aba Code do Claude Desktop), com o repositório aberto.
- Validação: **terminal + Vitest já** (antecipado do AIS-AP) + verificação no navegador.
- Tauri: **mantido no AIS-AP**.
- Restos do AI Studio no código: **remover**.

## Repositório
- `SYSTEM-INSTRUCTIONS.md` → **`CLAUDE.md`** (raiz). Adaptados: hierarquia (casca = código em `npm run dev`), decisão 2 (web local até o AIS-AP), regras 2/4/5/7/8/12/14 e formato do log (linha **Validação**). Nova seção "Comandos essenciais".
- Prompts movidos para **`docs/prompts/`** (com `ORDEM-CANONICA-V4.md` e `README.md`); links `../docs/specs/` → `../specs/`.
- **`.claude/skills/`**: `/ais <ID>`, `/ais-proximo`, `/ais-verificar` e a skill de domínio `nodimus-logic-pastas`. **`.claude/settings.json`** com permissões de `npm run check`/testes/git leitura e bloqueio de `git push` e `.env`.
- **`scripts/ais-status.mjs`** (`npm run ais:status`): status da sequência a partir da ordem e dos logs.
- **Vitest**: `vitest` em devDependencies; scripts `typecheck`, `test`, `test:watch`, `check`; `test` configurado no `vite.config.ts`; testes `src/__tests__/foundation.test.ts` (verificadores AIS-02b…05r) e `src/logic/registry.test.ts`. Os `require()` dos verificadores viraram imports ESM.
- **Removidos:** `@google/genai`, `express`, `dotenv`, `@types/express`, `tsx`, `esbuild`, `metadata.json`, `.env.example`, `bun.lock`, `public/assets/aistudio/`, `dist/`, lógica `DISABLE_HMR`; `Readme.md` do AI Studio → `README.md` local. `prompts-adaptacao-nodimus.md` → `docs/legado/`.

## Prompts
- Preâmbulo: "System Instructions do AI Studio" → "`CLAUDE.md` (carregado automaticamente)" em todos.
- Critérios: "(verificáveis no Preview)" → "(verificáveis por `npm run check` e no navegador)"; "O Preview carrega…" → "`npm run check` passa e o editor (`npm run dev`) carrega…"; "visível e operável no Preview" → "no navegador".
- "Decisão B2 (testes)" → testes Vitest (regra 12).
- **AIS-P0** reescrito: preparação do ambiente no Claude Code (Node, `npm install`, gate, git, próximo prompt).
- **AIS-AP**: Parte B2 (limpeza) marcada concluída; Parte B3 (Vitest) antecipada; resta Tauri/Rust e `tsc -b`.
- Ajustes pontuais: AIS-01/82/83 (`index.html`), AIS-03d, AIS-04, AIS-05r, AIS-28b, AIS-29b, AIS-30, AIS-78c, AIS-84; `ORDEM` ganhou a seção "Execução v5.0.0" (regra de pendência).
- As seções históricas (v4.x) deste changelog, do `README.md` e do `RELATORIO-BLOQUEIOS.md` foram mantidas como estavam.

# v4.7.0 — remoção do sistema de extensões/plugins e lógica nativa em pastas

## Decisão do usuário (30/09/2026)
Eliminar o sistema de extensões e o sistema de plug-ins; a pasta `res://addons/` deixa de existir junto com as implementações futuras. Behaviors e Actions deixam de ficar em documento único e passam a ficar em pastas dentro do editor — não como extensão/plugin, e sim como organização do código para facilitar a expansão por programação futura. Painéis desse conjunto ficam como stub/mock.

## Casca (código) — já aplicado
- **Removido:** `src/types/extension.ts`; sample `res://addons/zylann.hterrain/` do projeto default; `addons` em `ProjectFile`/`ProjectFileSchema`; `addonId`/`contributionId` em `ResourceRef`; `source: 'addon'`/`addonId`/`addonVersion` em `PersistedBehavior/ActionInstance`; item "Extensão / Plugin (plugin.cfg)" e roteamento de `plugin.cfg` no FileSystem.
- **Stub:** `ExtensionsPanel.tsx` (982 → 80 linhas), mesma casca visual, sem funcionalidade; rótulos dos menus com "(stub)".
- **Novo:** `src/logic/` — `types.ts`, `registry.ts` (`LogicRegistry`, `verifyLogicRegistry`), `README.md` e 27 pastas (7 triggers, 5 conditions, 9 actions, 6 behaviors).
- **Alterado:** `types/visualLogic.ts` (IDs `string`), `schemas/v1/visualLogic.schema.ts` (`LogicIdV1Schema` em vez de enums), `VisualLogicEditor.tsx` (consome o registry, sem mudança visual).
- **Compatibilidade:** `source: 'addon'` legado → `'custom'` com campos extras preservados; `removeLegacyAddonSample()` apaga só o sample gerado pelo editor (inclusive a entrada em `project.json`) e preserva arquivos do usuário em `res://addons/`.
- **Testes (funções puras):** `verifyZodSchemas` (`UnknownBehaviorPreservation`), `verifyDefaultProjectAndStorage` (`AIS-05r-T15`, `AIS-05r-T16`), `verifyLogicRegistry`.

## Pacote de prompts
- **Removidos:** `AIS-78` (sistema de extensões) e `AIS-78b` (lifecycle de addons/plugins). Total da ordem: 106 → 105.
- **Novo:** `AIS-05r` (nº 12) — registro/verificação da revisão.
- **Reescritos:** `AIS-78c` (CapabilityRegistry + EngineApi, sem EditorApi/addons/NodeTypeContribution), `AIS-79` (sandbox só de scripts `res://scripts/`), `AIS-81b` (dependências de prefab sem addons).
- **Ajustados:** AIS-03, 03b, 05, P0 (banner v4.7.0), 02b, 15, 18, 18b, 25b, 28, 28c, 29, 29b, 29c, 38, 38b, 39, 40, 41, 41b, 43, 44b, 45, 46, 48, 48b, 58, 74, 80, 81, 82, 85, 85b, 85c, AP; skill `nodimus-extensoes` substituída por `nodimus-logic-pastas` em todos os prompts; `src/core/actions/catalog.ts` não é mais criado por nenhum prompt.
- **System Instructions:** decisões 11 e 19 revisadas; 21 (lógica em pastas) e 22 (sem extensões/plugins) novas; contratos `LogicRegistry` (AIS-05r), `CapabilityRegistry + EngineApi` (AIS-78c) e sandbox de scripts (AIS-79) atualizados.
- **Specs:** `extension.spec.md` removida; `logic-registry.spec.md` nova; `extensions-panel.spec.md` reescrita como stub; `visual-logic`, `visual-logic-editor`, `default-project`, `editor-layout`, `README`, `MATRIZ` e `MAPA-ARQUITETURA` atualizados.
- Cabeçalhos "Posição canônica" renumerados (nº X de 105, anterior/próximo).

# v4.6.3 — consistência arquitetural da fundação

## v4.6.3 — Correção de nomenclatura da fundação
- Renumerados os prompts para refletir a ordem canônica: AIS-03e = State Mutation Policy; AIS-03f = Migração/fachada EditorContext.
- Atualizadas referências cruzadas, dependências, anterior/próximo, critérios e nomes de logs correspondentes.
- Nenhuma funcionalidade nova adicionada.


- Reordenado o bloco para `AIS-03 → 03b → 03c → 03d → 03f → 03e → AIS-04`; o State Mutation Policy agora é gate anterior à migração do `EditorContext`.
- `AIS-03f` passa a depender explicitamente de `AIS-03e`.
- `AIS-03b` remove `layers`/`instances` do schema de cena e fixa `rootNodeId + nodes: Record<string, GameNode>` como persistência canônica.
- `AIS-03c` passa a ser o dono formal do contrato mínimo do **Authoring Model**, eliminando a lacuna de autoridade durante a migração.
- `AIS-03d` herda B2: funções puras + checklist no Preview; Vitest somente no AIS-AP.
- `AIS-03` trata `ResourceRef` como ponto de extensão até o 03b e normaliza `OmniLight` como NodeType; `THREE.PointLight` é detalhe interno de renderer.
- `RELATORIO-BLOQUEIOS.md` teve alternativas históricas `Scene/Layer/Instance` marcadas explicitamente como não executáveis.


## v4.6.1 — preservação tipográfica

- AIS-01 deixa de impor `Segoe UI`/12px e passa a preservar a tipografia existente da casca.
- A mesma correção foi propagada às cópias do design system em AIS-82 e AIS-83, evitando reintrodução posterior.
- `SYSTEM-INSTRUCTIONS.md` ganha trava transversal de preservação visual: fonte, escala tipográfica, cores, espaçamentos, dimensões, densidade e identidade visual não podem mudar incidentalmente.
- A pilha `Segoe UI, Tahoma, Arial, sans-serif` permanece somente como fallback quando não existir definição tipográfica prévia.

# Changelog da padronização (v4.1 → v4.1-padronizado)

Escopo: **somente forma e consistência**. Nenhuma decisão canônica foi reaberta e nenhuma especificação técnica foi removida. Linhas originais que deixaram de existir: placeholders da seção "Estado real da casca", cabeçalhos dos 11 prompts curtos (convertidos para o padrão) e 1 linha do AIS-18 (ver 3).

## 1. Mudanças mecânicas (todos os arquivos)

| Mudança | Arquivos |
|---|---|
| seção "Estado real da casca" preenchida/atualizada  | 91 |
| linha "Posição canônica" + contratos v4.1 na tabela transversal | 81 |
| campo "Prompts/etapas relacionados" recalculado (união spec ↔ prompts) | 53 |
| linha "Posição canônica" + "Origem" + contratos v4.1 na tabela transversal | 12 |
| reestruturado no formato padrão (Preâmbulo, 1–6, critérios com ID AIS-XX-Cnn, SP | 11 |
| seção "Estado real da casca" preenchida/atualizada  + nota | 11 |
| heading "Preâmbulo fixo" renumerado 1→0 (colidia com "1. Estado real da casca") | 7 |
| adicionado bloco "0. Alinhamento" + "1. Identificação" no padrão das demais SPEC | 3 |
| numeração sequencial 1..105 (havia números repetidos/fora de ordem na Fase B) | 1 |
| índice inclui as 3 SPECs v4.1 que faltavam; total corrigido 53→56 | 1 |
| linha "limite configurável (máx. 100)" corrigida: contradizia decisão canônica 1 | 1 |

## 2. Estrutura padrão (agora igual nos 104 prompts)

`# título` → `> Origem` → `> Posição canônica` → Preâmbulo fixo (0) → Hierarquia da verdade → Decisões canônicas → Contratos transversais (agora com Zod/Authoring×Runtime/EditorStore/State Mutation Policy) → Regras de execução → **1. Estado real da casca** (tabela EXISTE/CRIAR com arquivo e nº de linhas) → 2. Contexto → 3. Especificação → 4. Diretrizes → **5. Critérios de aceite com IDs `AIS-XX-Cnn`** → 6. Skills → SPECs relacionadas.
Os 12 prompts "complemento v4" mantêm suas seções próprias (Posição na sequência, Objetivo etc.) entre a seção 1 e os critérios; só receberam cabeçalho, contratos, tabela da casca e SPECs.

## 3. Mudanças de conteúdo (revisar e vetar se discordar)

| Onde | O que mudou | Por quê |
|---|---|---|
| AIS-18, linha "Pilhas undoStack e redoStack…" | "limite configurável (máx. 100)" → "sem limite numérico" | Contradizia a decisão canônica 10 e o próprio prompt (linha "sem limite de profundidade"); a casca usa 50 |
| Todos os prompts com "casca-esperada.json" (12) | referência trocada por "código atual da casca" | O arquivo não existe no pacote e os prompts se declaram autossuficientes |
| AIS-03, 03b | nota apontando PARE E PERGUNTA sobre vocabulário do modelo de dados | Ver RELATORIO-BLOQUEIOS B1 |
| AIS-04 | nota: `preventDefault()` em F5/Ctrl+S no Preview web | F5 recarrega o Preview e apaga o estado |
| AIS-25b, 44, 46, 47, 77 | nota de nivelamento (Play canônico = host do AIS-44c; 44 usa `RuntimeSessionContract` do 03c; 47 usa InputManager do 40b) | Dependências para frente que a regra da ORDEM proíbe |
| AIS-36, 37 | nota: `AnimationPlayer` não existe em `NodeType` da casca | Docs da casca afirmam o contrário |
| Vínculos SPEC↔prompt inferidos | AIS-13→node-icon; AIS-35→texture-preview (modal+canvas); AIS-76→4 componentes sprite; AIS-02b/03c-f/61b→specs v4.1/telas | 6 SPECs e 11 prompts estavam sem par (evidência: skill `nodimus-iconografia` em AIS-13, texto de AIS-76, título de AIS-35) |

## 4. SPECs

- 53 SPECs: campo *Prompts/etapas relacionados* recalculado pela união (SPEC lista ∪ prompt linka). Antes, 38 de 56 traziam "Sequência canônica Nodimus v4" ou vazio.
- 3 SPECs v4.1 (`editor-store`, `state-architecture`, `zod-schemas`) ganharam o bloco "0. Alinhamento" e "1. Identificação" e entraram no índice (`README.md` dizia 53; são 56).

## 5. ORDEM-CANONICA-V4.md

Renumerada 1..105 (havia 12→9→10→11 na Fase B). Nenhuma mudança de ordem de execução.


## v4.2 — aplicação das decisões B1/B2/B3/R1
- **B1:** bloco de skill `nodimus-scenegraph-modelo` reescrito em 18 prompts (SceneData → GameNode, sem Layer/Instance); `CommandStack` → `CommandManager` (26 prompts); `OverlayInstance`/`Layer(kind:'ui')` → `Overlay2D`; tipos `…Node` → nomes de `NodeType`; APIs `…Instance…` → `…Node…` (ex.: `getNodesByTag`, `deleteNodeCommand`); linha 8 do Preâmbulo atualizada nos 104 prompts. AIS-25b deixou de propor "quebra deliberada": mantém `Overlay2D`/`TextOverlay2D`/`ButtonOverlay2D` e troca só o motor de render. AIS-41b: `Definition × BehaviorInstance`. Revisar: AIS-25b (mudança de escopo) e o AIS-03 (tipos ausentes na casca continuam CRIAR).
- **B2:** nota "Decisão B2" em 18 prompts; AIS-AP ganhou Parte B3 e critério C08.
- **B3:** AIS-P0 e AIS-AP adicionados a `prompts/`; ORDEM atualizada; P0 sem `PlaySimulationModal.tsx` no inventário nem `OverlayInstance`.
- **R1 / Play:** AIS-46, 77, 25b, 44c e P0 sem `PlaySimulationModal`; Play dentro da viewport.
- **AIS-44:** depende só de `RuntimeSessionContract` (AIS-03c).

## v4.3 — preâmbulo movido para System Instructions
- Seção "0. Preâmbulo fixo" dos 104 prompts substituída por ponteiro; AIS-P0 também. AIS-79 mantém a regra local do Worker/Command Buffer.
- Novo `SYSTEM-INSTRUCTIONS.md` (~9,6 mil caracteres): identidade, hierarquia, decisões 1–12, contratos transversais, regras 1–8 (numeração preservada) e regras 9–14 (nomenclatura da casca, edição por trechos, preventDefault, testes por checklist, Play na viewport, verificar no Preview).
- Referências "ver Preâmbulo" passaram a "ver System Instructions". Economia: ~770 mil caracteres no pacote (~7,4 mil por prompt).

## v4.4 — decisões do usuário sobre os conflitos internos (auditoria de 2026-09-30)
- **Tema:** dark permanece padrão (valores dark = tokens reais da casca); tema claro vira opcional. Skill de tokens ajustada em AIS-01/82/83; critério AIS-01-C04; seletor do AIS-80/82 passa a `'dark' (padrão) | 'light'`; decisão 13 nas System Instructions. Prefixo de token (`--gl-` × `--ide-`) segue como PARE E PERGUNTA no AIS-01.
- **Decisões:** a tabela de 25 decisões embutida em AIS-78, 79 e AP foi removida; System Instructions é a única fonte (decisões 13 e 14 adicionadas). Referências a "decisão 19/22/23" reapontadas.
- **`run_script`:** catálogo e picker mostram a ação desabilitada ("em breve") até o AIS-79; AIS-41 (C04), AIS-42, AIS-44 e AIS-79 (C02b) ajustados.
- **Armazenamento web:** sem mudança (fase inicial), por decisão do usuário.
- **Casca real:** contagens de linhas corrigidas em prompts, MATRIZ e RELATORIO (Viewport3D 1690, EditorContext 1044); P0 com inventário real; `AssetLibraryView` e `DesktopDocsExportModal` não existem no zip (Asset Library = CRIAR); `ORDEM` item 5 corrigido; skill `nodimus-scenegraph-modelo`: "Layer/Instance". Specs: linhas por arquivo e bloco "8. Auditoria da casca (v4.4)" em 10 specs.
- **Pendente:** regra de log (ver pergunta ao usuário); colisão de numeração "Prompt 62–67" dentro do AIS-AP.

## v4.5 — decisões do usuário (2026-09-30)
- **Asset Library e modal órfão eliminados:** `AssetLibraryView` (workspace `AssetLibrary`) e `DesktopDocsExportModal` deixam de ser citados em qualquer prompt ou documento. Removidos: o item CRIAR do AIS-P0 e do AIS-01, a frase "A Biblioteca de Assets… (CRIAR)" da skill `nodimus-shell-interface` (8 prompts), o "Asset Lib" do diagrama do layout, a verificação e o critério do modal na Limpeza final do AIS-AP e a nota da SPEC `editor-layout`. Os alternadores da TopBar ficam `3D | Visual Logic | Script`. (As linhas do v4.4 acima são histórico e não foram reescritas.)
- **Proibição de log eliminada; log obrigatório por prompt:** regra 6 das System Instructions e regra 1 da higienização do AIS-P0 reescritas; nova seção "Formato do log" nas System Instructions; cada prompt ganhou um critério final de aceite exigindo `docs/logs/<ID>.md` (104 prompts + AIS-P0; no AIS-AP, um log por prompt do apêndice e `AIS-AP.md`). O AIS-P0 cria a pasta `docs/logs/`. Segue proibido criar outros documentos de processo (checkpoints, arquivos de decisões, roteiros de teste, certificações).
- **Tema claro criado e alterado pelo configurador do editor:** decisão 13 reescrita (dark é o único tema embutido). AIS-01 passa a criar só o mecanismo (`themeService`, `applyTheme`, `data-theme`, temas do usuário em `localStorage`) e não entrega CSS claro; C04 reescrito. AIS-82 ganha o Configurador de Temas (novo tema claro a partir de um modelo inicial, duplicar, renomear, excluir, editor de tokens ao vivo, avisos de contraste, dark somente leitura) e critérios C06–C09. As skills `nodimus-design-tokens-tema` (AIS-01/82/83) e `nodimus-preferences-dialog` (AIS-80/82) foram reescritas e as cópias mantidas idênticas; os valores claros antigos viraram a "semente do modelo claro" (não são CSS).
- **Correções de coerência feitas junto:** (a) o script inline no `index.html` contra flash de tema foi trocado por aplicação síncrona em `main.tsx`, porque o AIS-P0 proíbe editar `index.html`; (b) a skill `nodimus-preferences-dialog` dizia "só duas seções, sem abas", contra a especificação do AIS-82 (abas Geral/Atalhos/Aparência) — alinhada à especificação; (c) os preâmbulos diziam "decisões canônicas (1–12)"; agora "(1–14)".


## v4.6 — Environment, Prefab editável, UIKit Containers, NodeTypes e Publish Tauri 2
- Pasta canônica de SpriteAsset/spritesheet: `res://sprites/`.
- UI 2D ampliada com Containers/layouts UIKit.
- Environment unificado em GameNode único por Scene; Gravity permanece na Scene.
- `.prefab.json` abre no Scene Editor em modo Prefab e salva no próprio asset.
- ~~Plugins/addons podem contribuir NodeTypes via registry/capabilities~~ (revogado na v4.7.0) com Missing/Unknown Node resiliente.
- `runtimeMobile` formalizado.
- AIS-85c adicionado: Game App Desktop/Mobile em Tauri 2, separado do AIS-AP (Editor App).

## v5.1.2 (complemento) — cabeçalhos de posição
- Todos os cabeçalhos "nº X de N" dos prompts regravados a partir da `ORDEM-CANONICA-V4.md` (N = 116; antes: 105/111). `AIS-49` → próximo = AIS-49b. Referência cruzada em `AIS-61` ("AIS-61c, nº 94 de 116").
- Pendente (pré-existente, não alterado): `anterior/próximo` de AIS-29d, 30, 32, 33, 40b, 41, 61b e 68 seguem a dependência lógica e diferem da ordem linear.

# v5.1.3 — AIS-18c e contrato de partículas
- Novo **AIS-18c** (posição 28, após AIS-18b): remove `ParticleEmitter`, consolida `ParticleSystem`, cria o motor único `src/core/particles/` (tipos, engine com acumulador de spawn, 8 presets, texturas procedurais), adaptador `THREE.Points`, `addNode(initialProperties)` no mesmo Command e `ParticleModal` como catálogo (um `draft`). Sem alias: só a cena de testes é ajustada.
- Total **117 posições**; AIS-50b passa à 78; todos os cabeçalhos "nº X de N" regravados.
- AIS-53 reduzido a modo editar, `generatorSource` (`params = { presetId }`, nó = fonte de verdade, modelo Godot), "Aplicar ao nó" e critérios C09–C14. Emendas em AIS-03, 15, 23, 41, 44c, 49b, 56, 77.
- Specs: nova `dominios/particle-system.spec.md`; reescrita `modais/particle-modal.spec.md`; notas em node, registry, inspector-panel, viewport-3d, create-node-modal; `MATRIZ` e `specs/README.md` atualizados.
- `CLAUDE.md`: nova linha na tabela de contratos transversais (partículas).
- Divergência registrada: a skill `nodimus-particulas` não existe como arquivo (só embutida no AIS-53); `nodimus-terreno-arvore`/`nodimus-agua` idem.

## v6.4 — IA, caminhos e waypoints (ordem e inconsistências)
- **Ordem:** AIS-72 passa a preceder o AIS-71 (o Game Actor consome `follow_a_path`); novo **AIS-72b** (nó `Waypoint`, nº 114); AIS-71 vai ao nº 115; posições ≥ 114 +1; total 133. Cabeçalhos "Posição canônica" regerados.
- **AIS-72:** arquivo renomeado de `AIS-72-navmesh-pathfinding.md` para `AIS-72-editor-caminhos-follow-a-path.md` (o conteúdo nunca foi NavMesh); exporta `moveNodeToward`; removida a diretriz "sem regressão em AIS-71".
- **AIS-71 reescrito:** dois Behaviors (`ai_state_machine`, `game_actor_with_health`) + Action `shoot`; IDs `snake_case`; transições com prioridade e timers definidos; `health` declarada no authoring (runtime nunca cria); ganchos como regras do Behavior (não existe tipo de parâmetro `action`); animação pela decisão 30; modo "This is the player" removido (decisão 28); "Collide When Moved" substituído por `properties.physics` (decisão 26); `Shoot` entra no teste de contrato de `weapons.test.ts`; tabela "Estado real da casca" refeita.
- **AIS-70:** nota pós-execução alinhando o prompt às decisões registradas no log.
- **CLAUDE.md:** decisão 31.
